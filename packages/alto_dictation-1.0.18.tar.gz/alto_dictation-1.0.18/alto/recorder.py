"""
Audio recording module for Alto service.
"""

import io
import logging
import wave
from pathlib import Path
from threading import Lock
from typing import Optional

import numpy as np
import sounddevice as sd

logger = logging.getLogger(__name__)


class AudioRecorder:
    """Handles audio recording from microphone.

    Records audio in streaming mode using sounddevice.InputStream.
    Outputs 16kHz, mono, 16-bit PCM WAV format by default.

    Args:
        sample_rate: Audio sample rate in Hz. Default is 16000.
        channels: Number of audio channels. Default is 1 (mono).
        dtype: Data type for audio samples. Default is 'int16'.
        blocksize: Number of frames per buffer (0 = auto). Default is 0.
        enable_noise_suppression: Enable simple noise gate. Default is False.
        enable_agc: Enable automatic gain control. Default is False.
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        channels: int = 1,
        dtype: str = "int16",
        blocksize: int = 0,
        enable_noise_suppression: bool = False,
        enable_agc: bool = False,
    ):
        """Initialize the audio recorder.

        Args:
            sample_rate: Audio sample rate in Hz. Default is 16000.
            channels: Number of audio channels. Default is 1 (mono).
            dtype: Data type for audio samples. Default is 'int16'.
            blocksize: Number of frames per buffer (0 = auto). Default is 0.
            enable_noise_suppression: Enable simple noise gate. Default is False.
            enable_agc: Enable automatic gain control. Default is False.
        """
        self.sample_rate = sample_rate
        self.channels = channels
        self.dtype = dtype
        # Optimize blocksize for low latency if not specified
        # 512 frames = ~32ms latency at 16kHz (good balance of latency vs CPU)
        self.blocksize = blocksize if blocksize > 0 else 512
        self.enable_noise_suppression = enable_noise_suppression
        self.enable_agc = enable_agc

        self._stream: Optional[sd.InputStream] = None
        self._recording = False
        self._lock = Lock()
        self._audio_data: list[np.ndarray] = []
        # Pre-allocate array capacity to reduce reallocation overhead
        self._estimated_chunks = 100  # Typical for 3-5 second recordings

        # Audio processing parameters
        self._noise_gate_threshold = 0.02  # Amplitude threshold for noise gate
        self._agc_target_level = 0.5  # Target RMS level for AGC

        logger.debug(
            f"AudioRecorder initialized: sample_rate={sample_rate}, "
            f"channels={channels}, dtype={dtype}, blocksize={self.blocksize}, "
            f"noise_suppression={enable_noise_suppression}, agc={enable_agc}"
        )

    def start(self) -> None:
        """Start recording audio from the microphone.

        Raises:
            RuntimeError: If recording is already in progress or audio device cannot be opened.
        """
        with self._lock:
            if self._recording:
                raise RuntimeError("Recording is already in progress")

            self._recording = True
            self._audio_data = []

            logger.info("Starting audio recording")

            try:
                # Create and start the input stream with optimized settings
                self._stream = sd.InputStream(
                    samplerate=self.sample_rate,
                    channels=self.channels,
                    dtype=self.dtype,
                    blocksize=self.blocksize,
                    callback=self._audio_callback,
                    # Use lower latency setting for faster response
                    latency='low',
                )
                self._stream.start()
                logger.debug("Audio stream started successfully")

            except Exception as e:
                # Clean up on failure
                self._recording = False
                self._audio_data = []
                if self._stream is not None:
                    try:
                        self._stream.close()
                    except Exception:
                        pass
                    self._stream = None

                error_type = type(e).__name__
                logger.error(f"Failed to start audio recording: {error_type}: {e}")
                raise RuntimeError(f"Failed to open audio device: {e}") from e

    def stop(self) -> tuple[bytes, float]:
        """Stop recording and return the audio data.

        Returns:
            A tuple containing:
                - bytes: WAV-encoded audio data (16kHz, mono, 16-bit PCM)
                - float: Duration of the recording in seconds

        Raises:
            RuntimeError: If no recording is in progress or stream cannot be stopped.
        """
        # Phase 1: Signal stop and grab stream reference (inside lock)
        with self._lock:
            if not self._recording:
                raise RuntimeError("No recording in progress")

            logger.info("Stopping audio recording")
            self._recording = False  # Signal callback to stop appending
            stream = self._stream
            self._stream = None

        # Phase 2: Stop stream OUTSIDE lock to avoid deadlock with audio callback
        # (stream.stop() waits for any running callback, which needs the lock)
        stream_error = None
        if stream is not None:
            try:
                stream.stop()
                stream.close()
                logger.debug("Audio stream stopped successfully")
            except Exception as e:
                stream_error = e
                logger.error(f"Error stopping audio stream: {type(e).__name__}: {e}")

        # Phase 3: Process audio data (safe - stream stopped, callback won't append)
        if not self._audio_data:
            logger.warning("No audio data recorded")
            audio_array = np.array([], dtype=self.dtype)
        else:
            try:
                if len(self._audio_data) == 1:
                    audio_array = self._audio_data[0]
                else:
                    # Pre-allocate output array for faster concatenation
                    total_samples = sum(chunk.shape[0] for chunk in self._audio_data)
                    audio_array = np.empty((total_samples, self.channels) if self.channels > 1 else (total_samples,), dtype=self.dtype)
                    offset = 0
                    for chunk in self._audio_data:
                        chunk_len = chunk.shape[0]
                        audio_array[offset:offset + chunk_len] = chunk
                        offset += chunk_len
            except Exception as e:
                logger.error(f"Error concatenating audio data: {type(e).__name__}: {e}")
                # Fallback to simple concatenation
                try:
                    audio_array = np.concatenate(self._audio_data)
                except Exception:
                    audio_array = np.array([], dtype=self.dtype)

        # Apply audio processing if enabled
        if len(audio_array) > 0:
            try:
                audio_array = self._process_audio(audio_array)
            except Exception as e:
                logger.error(f"Error processing audio: {type(e).__name__}: {e}")
                # Continue with unprocessed audio

        # Calculate duration
        duration = len(audio_array) / (self.sample_rate * self.channels)

        logger.info(
            f"Recording stopped: {len(audio_array)} samples, {duration:.2f}s"
        )

        # Convert to WAV bytes
        try:
            wav_bytes = self._to_wav_bytes(audio_array)
        except Exception as e:
            logger.error(f"Error converting audio to WAV: {type(e).__name__}: {e}")
            # Re-raise as this is a critical error
            raise RuntimeError(f"Failed to encode audio as WAV: {e}") from e

        # If there was a stream error, raise it now
        if stream_error is not None:
            logger.warning("Audio data retrieved despite stream error")

        return wav_bytes, duration

    def is_recording(self) -> bool:
        """Check if recording is in progress.

        Returns:
            True if recording is in progress, False otherwise.
        """
        with self._lock:
            return self._recording

    def _audio_callback(
        self,
        indata: np.ndarray,
        frames: int,
        time_info,
        status: sd.CallbackFlags,
    ) -> None:
        """Callback function for the audio input stream.

        This is called by sounddevice for each audio chunk.

        Args:
            indata: Input audio data as numpy array.
            frames: Number of frames in this chunk.
            time_info: Time information (unused).
            status: Status flags indicating any issues.
        """
        if status:
            logger.warning(f"Audio callback status: {status}")

        # Optimize: minimize lock contention by checking recording flag first
        if self._recording:
            # Squeeze mono (N,1) -> (N,) for consistent shape with pre-allocation
            chunk = indata.copy().squeeze()
            with self._lock:
                # Double-check recording flag inside lock
                if self._recording:
                    self._audio_data.append(chunk)

    def _process_audio(self, audio_array: np.ndarray) -> np.ndarray:
        """Apply audio processing (noise suppression, AGC) to recorded audio.

        Args:
            audio_array: Raw audio data as numpy array.

        Returns:
            Processed audio data as numpy array.
        """
        # Convert to float for processing
        if self.dtype == "int16":
            audio_float = audio_array.astype(np.float32) / 32768.0
        elif self.dtype == "int32":
            audio_float = audio_array.astype(np.float32) / 2147483648.0
        else:
            audio_float = audio_array.copy()

        # Apply noise suppression (simple noise gate)
        if self.enable_noise_suppression:
            audio_float = self._apply_noise_gate(audio_float)

        # Apply automatic gain control
        if self.enable_agc:
            audio_float = self._apply_agc(audio_float)

        # Convert back to original dtype
        if self.dtype == "int16":
            # Clip to prevent overflow
            audio_float = np.clip(audio_float, -1.0, 1.0)
            processed = (audio_float * 32767).astype(np.int16)
        elif self.dtype == "int32":
            audio_float = np.clip(audio_float, -1.0, 1.0)
            processed = (audio_float * 2147483647).astype(np.int32)
        else:
            processed = audio_float

        logger.debug("Audio processing completed")
        return processed

    def _apply_noise_gate(self, audio: np.ndarray) -> np.ndarray:
        """Apply simple noise gate to suppress low-level background noise.

        Args:
            audio: Audio data as float32 array (range -1.0 to 1.0).

        Returns:
            Audio with noise gate applied.
        """
        # Calculate absolute amplitude
        amplitude = np.abs(audio)

        # Create gate mask (1 where signal is above threshold, 0 below)
        gate_mask = (amplitude > self._noise_gate_threshold).astype(np.float32)

        # Apply smooth attack/release to avoid clicks
        # Simple moving average for smoothing
        window_size = int(self.sample_rate * 0.01)  # 10ms window
        if window_size > 1:
            gate_mask = np.convolve(
                gate_mask, np.ones(window_size) / window_size, mode="same"
            )

        # Apply gate
        gated_audio = audio * gate_mask

        logger.debug(
            f"Noise gate applied: threshold={self._noise_gate_threshold}, "
            f"gated {(1 - np.mean(gate_mask)) * 100:.1f}% of audio"
        )

        return gated_audio

    def _apply_agc(self, audio: np.ndarray) -> np.ndarray:
        """Apply automatic gain control to normalize audio levels.

        Args:
            audio: Audio data as float32 array (range -1.0 to 1.0).

        Returns:
            Audio with AGC applied.
        """
        # Calculate current RMS level
        rms = np.sqrt(np.mean(audio**2))

        if rms < 0.001:  # Avoid division by zero for silence
            logger.debug("AGC skipped: audio is silent")
            return audio

        # Calculate gain to reach target level
        gain = self._agc_target_level / rms

        # Limit gain to prevent excessive amplification
        max_gain = 10.0  # Maximum 20dB boost
        min_gain = 0.1  # Maximum 20dB reduction
        gain = np.clip(gain, min_gain, max_gain)

        # Apply gain
        normalized_audio = audio * gain

        # Soft clip to prevent hard clipping
        normalized_audio = np.tanh(normalized_audio)

        logger.debug(
            f"AGC applied: rms={rms:.3f}, gain={gain:.2f}x ({20 * np.log10(gain):.1f}dB)"
        )

        return normalized_audio

    def _to_wav_bytes(self, audio_array: np.ndarray) -> bytes:
        """Convert audio array to WAV-encoded bytes.

        Args:
            audio_array: Audio data as numpy array.

        Returns:
            WAV-encoded audio data as bytes.
        """
        # Create a bytes buffer
        wav_buffer = io.BytesIO()

        # Write WAV file to buffer
        with wave.open(wav_buffer, "wb") as wav_file:
            wav_file.setnchannels(self.channels)
            wav_file.setsampwidth(2)  # 16-bit = 2 bytes
            wav_file.setframerate(self.sample_rate)
            wav_file.writeframes(audio_array.tobytes())

        # Get the bytes
        wav_bytes = wav_buffer.getvalue()

        logger.debug(f"Converted audio to WAV: {len(wav_bytes)} bytes")

        return wav_bytes

    def save_to_file(self, audio_bytes: bytes, file_path: Path) -> None:
        """Save WAV audio bytes to a file.

        Args:
            audio_bytes: WAV-encoded audio data.
            file_path: Path to save the audio file.
        """
        with open(file_path, "wb") as f:
            f.write(audio_bytes)

        logger.info(f"Audio saved to {file_path}")
