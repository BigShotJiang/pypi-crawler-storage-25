"""
Logging configuration for Alto service.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional


def setup_logging(
    log_level: str = "INFO",
    log_dir: Optional[Path] = None,
) -> None:
    """Set up logging configuration for Alto service.

    Configures logging to both stderr and a rotating log file.
    The log file is stored in ~/.local/share/alto/alto.log by default.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        log_dir: Directory for log files. If None, uses ~/.local/share/alto.

    Raises:
        ValueError: If log_level is not a valid logging level.
    """
    # Validate log level
    valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
    if log_level not in valid_levels:
        raise ValueError(
            f"Invalid log level '{log_level}'. Must be one of: {valid_levels}"
        )

    # Determine log directory
    if log_dir is None:
        log_dir = Path.home() / ".local" / "share" / "alto"

    # Create log directory if it doesn't exist
    log_dir.mkdir(parents=True, exist_ok=True)

    # Log file path
    log_file = log_dir / "alto.log"

    # Create formatters
    formatter = logging.Formatter(
        fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Create handlers
    # 1. Stderr handler for console output
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(getattr(logging, log_level))
    stderr_handler.setFormatter(formatter)

    # 2. Rotating file handler for persistent logs
    # Max file size: 10 MB, keep 5 backup files
    file_handler = RotatingFileHandler(
        filename=log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(getattr(logging, log_level))
    file_handler.setFormatter(formatter)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level))

    # Remove any existing handlers to avoid duplicates
    root_logger.handlers.clear()

    # Add our handlers
    root_logger.addHandler(stderr_handler)
    root_logger.addHandler(file_handler)

    # Log initialization message
    logger = logging.getLogger(__name__)
    logger.info("=" * 60)
    logger.info(f"Logging initialized: level={log_level}")
    logger.info(f"Log file: {log_file}")
    logger.info("=" * 60)


def get_log_file_path(log_dir: Optional[Path] = None) -> Path:
    """Get the path to the log file.

    Args:
        log_dir: Directory for log files. If None, uses ~/.local/share/alto.

    Returns:
        Path to the alto.log file.
    """
    if log_dir is None:
        log_dir = Path.home() / ".local" / "share" / "alto"

    return log_dir / "alto.log"
