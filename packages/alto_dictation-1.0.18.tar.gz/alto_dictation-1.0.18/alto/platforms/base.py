"""
Abstract base classes for platform-specific components.

Each platform (Linux, macOS, Windows) must implement these interfaces.
"""

from abc import ABC, abstractmethod
from typing import Callable, Optional


class BaseHotkeyListener(ABC):
    """Abstract hotkey listener interface."""

    @abstractmethod
    def start(self) -> None:
        """Start listening for hotkey events."""
        ...

    @abstractmethod
    def stop(self) -> None:
        """Stop listening for hotkey events."""
        ...

    @abstractmethod
    def suspend(self) -> None:
        """Suspend the listener (e.g., before system sleep)."""
        ...

    @abstractmethod
    def resume(self) -> bool:
        """Resume the listener (e.g., after system wake).

        Returns:
            True if resumed successfully, False otherwise.
        """
        ...

    @abstractmethod
    def is_running(self) -> bool:
        """Check if the listener is currently running."""
        ...


class BaseTextInjector(ABC):
    """Abstract text injection interface."""

    @abstractmethod
    def type_text(self, text: str) -> None:
        """Inject text into the currently focused application."""
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """Check if text injection is available."""
        ...


class BaseSleepMonitor(ABC):
    """Abstract sleep/wake monitor interface."""

    @abstractmethod
    def start(self) -> bool:
        """Start monitoring sleep/wake events.

        Returns:
            True if started successfully, False otherwise.
        """
        ...

    @abstractmethod
    def stop(self) -> None:
        """Stop monitoring sleep/wake events."""
        ...
