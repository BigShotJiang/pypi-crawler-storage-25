"""
Platform abstraction layer.

Detects the current platform and exposes the correct implementations
of HotkeyListener, TextInjector, and SleepMonitor.
"""

import sys

if sys.platform == "linux":
    from alto.platforms.linux.hotkey import HotkeyListener
    from alto.platforms.linux.hotkey import detect_key_interactive
    from alto.platforms.linux.injector import TextInjector
    from alto.platforms.linux.sleep import SleepMonitor
elif sys.platform == "darwin":
    raise NotImplementedError("macOS support coming soon")
elif sys.platform == "win32":
    raise NotImplementedError("Windows support coming soon")
else:
    raise NotImplementedError(f"Unsupported platform: {sys.platform}")

__all__ = ["HotkeyListener", "TextInjector", "SleepMonitor", "detect_key_interactive"]
