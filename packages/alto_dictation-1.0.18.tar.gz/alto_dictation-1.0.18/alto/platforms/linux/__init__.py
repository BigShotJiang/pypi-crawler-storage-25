"""Linux platform implementations."""
