"""
Text injection module for Alto service.
"""

import logging
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional

from alto.platforms.base import BaseTextInjector

logger = logging.getLogger(__name__)

# ydotool keycodes for Ctrl+V / Ctrl+Shift+V paste
_KEY_LEFTCTRL = 29
_KEY_LEFTSHIFT = 42
_KEY_V = 47


class TextInjector(BaseTextInjector):
    """Handles typing text into any application via clipboard paste.

    Uses the system clipboard (xclip/xsel/wl-copy) to set the text,
    then simulates Ctrl+V via ydotool to paste it. This approach is
    keyboard-layout-independent (works with AZERTY, QWERTY, etc.).

    Requires ydotoold daemon running and a clipboard tool installed.

    Args:
        delay_ms: Delay between keystrokes in milliseconds (unused with clipboard mode).
        timeout: Timeout for commands in seconds. Default is 10s.
    """

    def __init__(
        self,
        delay_ms: int = 12,
        timeout: int = 10,
    ):
        self.delay_ms = delay_ms
        self.base_timeout = timeout

        # Performance tracking
        self._total_chars_typed = 0
        self._total_time = 0.0
        self._fastest_wpm = 0.0
        self._slowest_wpm = float('inf')

        # Detect clipboard tool
        self._clipboard_cmd = self._detect_clipboard_tool()

        logger.debug(
            f"TextInjector initialized: clipboard={self._clipboard_cmd}, "
            f"base_timeout={timeout}s"
        )

        # Verify ydotool installation and daemon status
        self._verify_ydotool()

    def _detect_clipboard_tool(self) -> list[str]:
        """Detect the available clipboard tool based on display server."""
        is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))

        if is_wayland:
            if shutil.which("wl-copy"):
                logger.info("Clipboard tool: wl-copy (Wayland)")
                return ["wl-copy"]
            if shutil.which("xclip"):
                logger.info("Clipboard tool: xclip (Wayland/XWayland)")
                return ["xclip", "-selection", "clipboard"]
        else:
            if shutil.which("xclip"):
                logger.info("Clipboard tool: xclip (X11)")
                return ["xclip", "-selection", "clipboard"]
            if shutil.which("xsel"):
                logger.info("Clipboard tool: xsel (X11)")
                return ["xsel", "--clipboard", "--input"]
            if shutil.which("wl-copy"):
                logger.info("Clipboard tool: wl-copy (fallback)")
                return ["wl-copy"]

        raise RuntimeError(
            "No clipboard tool found. Install one with: "
            "sudo apt install xclip (Ubuntu/Debian) or "
            "sudo pacman -S xclip (Arch) or "
            "sudo apt install wl-clipboard (Wayland)"
        )

    def _verify_ydotool(self) -> None:
        """Verify that ydotool is installed and ydotoold daemon is running."""
        ydotool_path = shutil.which("ydotool")
        if not ydotool_path:
            raise RuntimeError(
                "ydotool is not installed. Install it with: "
                "sudo apt install ydotool (Ubuntu/Debian) or "
                "sudo pacman -S ydotool (Arch)"
            )

        logger.debug(f"Found ydotool at: {ydotool_path}")

        try:
            result = subprocess.run(
                ["ydotool", "key", "0:0"],
                capture_output=True,
                text=True,
                timeout=self.base_timeout,
                check=False,
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip() if result.stderr else "Unknown error"

                if "connect" in error_msg.lower() or "socket" in error_msg.lower():
                    raise RuntimeError(
                        "ydotoold daemon is not running. Start it with: "
                        "sudo systemctl start ydotool or "
                        "sudo ydotoold --socket-path=/run/ydotool/ydotoold.socket"
                    )

                raise RuntimeError(f"ydotool verification failed: {error_msg}")

            logger.info("ydotool is installed and ydotoold daemon is running")

        except subprocess.TimeoutExpired:
            raise RuntimeError(
                f"ydotool command timed out after {self.base_timeout}s. "
                "The ydotoold daemon may not be running."
            )
        except FileNotFoundError:
            raise RuntimeError("ydotool binary not found in PATH")

    def _copy_to_clipboard(self, text: str) -> None:
        """Copy text to system clipboard."""
        try:
            proc = subprocess.Popen(
                self._clipboard_cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            try:
                _, stderr = proc.communicate(
                    input=text.encode("utf-8"), timeout=2
                )
                if proc.returncode != 0:
                    error_msg = stderr.decode().strip() if stderr else "Unknown error"
                    raise RuntimeError(f"Clipboard copy failed: {error_msg}")
            except subprocess.TimeoutExpired:
                self._clipboard_proc = proc
                logger.debug("Clipboard process still running (xclip behavior), will clean up after paste")

        except FileNotFoundError:
            raise RuntimeError(
                f"Clipboard tool not found: {self._clipboard_cmd[0]}"
            )

    def _cleanup_clipboard_proc(self) -> None:
        """Kill lingering clipboard process after paste."""
        proc = getattr(self, "_clipboard_proc", None)
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                proc.kill()
            logger.debug("Cleaned up lingering clipboard process")
        self._clipboard_proc = None

    def _simulate_paste(self) -> None:
        """Simulate Ctrl+Shift+V via ydotool to paste clipboard."""
        try:
            result = subprocess.run(
                [
                    "ydotool", "key",
                    f"{_KEY_LEFTCTRL}:1",
                    f"{_KEY_LEFTSHIFT}:1",
                    f"{_KEY_V}:1",
                    f"{_KEY_V}:0",
                    f"{_KEY_LEFTSHIFT}:0",
                    f"{_KEY_LEFTCTRL}:0",
                ],
                capture_output=True,
                text=True,
                timeout=self.base_timeout,
                check=False,
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip() if result.stderr else "Unknown error"
                raise RuntimeError(f"ydotool paste simulation failed: {error_msg}")

        except subprocess.TimeoutExpired:
            raise RuntimeError("ydotool paste simulation timed out")
        except FileNotFoundError:
            raise RuntimeError("ydotool binary not found")

    def type_text(self, text: str) -> None:
        """Inject text via clipboard paste (layout-independent)."""
        if not text:
            raise ValueError("Cannot type empty text")

        text_len = len(text)
        logger.info(f"Injecting text: {text_len} characters (clipboard paste)")
        logger.debug(f"Text content: {text[:100]}...")

        start_time = time.time()

        self._cleanup_clipboard_proc()
        self._clipboard_proc = None

        try:
            self._copy_to_clipboard(text)
            time.sleep(0.05)
            self._simulate_paste()
            self._cleanup_clipboard_proc()

            elapsed = time.time() - start_time
            self._update_performance_metrics(text_len, elapsed)

            logger.info(f"Text injected successfully in {elapsed:.2f}s")

        except RuntimeError:
            self._cleanup_clipboard_proc()
            raise
        except Exception as e:
            self._cleanup_clipboard_proc()
            raise RuntimeError(f"Unexpected error during text injection: {e}") from e

    def is_available(self) -> bool:
        try:
            self._verify_ydotool()
            return True
        except RuntimeError:
            return False

    def _update_performance_metrics(self, chars: int, elapsed_time: float) -> None:
        self._total_chars_typed += chars
        self._total_time += elapsed_time

        if elapsed_time > 0:
            wpm = (chars / 5.0) / (elapsed_time / 60.0)
            self._fastest_wpm = max(self._fastest_wpm, wpm)
            self._slowest_wpm = min(self._slowest_wpm, wpm)

    def get_average_wpm(self) -> float:
        if self._total_time == 0:
            return 0.0
        total_words = self._total_chars_typed / 5.0
        total_minutes = self._total_time / 60.0
        return total_words / total_minutes if total_minutes > 0 else 0.0

    def get_performance_stats(self) -> dict:
        return {
            "total_chars_typed": self._total_chars_typed,
            "total_time_s": self._total_time,
            "average_wpm": self.get_average_wpm(),
            "fastest_wpm": self._fastest_wpm if self._total_chars_typed > 0 else 0.0,
            "slowest_wpm": self._slowest_wpm if self._slowest_wpm != float('inf') else 0.0,
        }
