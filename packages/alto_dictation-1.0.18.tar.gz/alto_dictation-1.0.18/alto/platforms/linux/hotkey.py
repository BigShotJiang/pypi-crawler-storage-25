"""
Hotkey listener module using evdev for global key detection.

Supports single keys (e.g. "KEY_GRAVE") and modifier combos
(e.g. "ALT+KEY_A", "CTRL+SHIFT+KEY_D").
"""

import logging
import select
import time
from threading import Event, Lock, Thread
from typing import Callable, Optional

import evdev
from evdev import InputDevice, UInput, categorize, ecodes

from alto.platforms.base import BaseHotkeyListener

logger = logging.getLogger(__name__)

# --- Hotkey parsing and validation ---

# Modifier names -> evdev keycodes (left + right variants)
_MODIFIER_CODES = {
    "CTRL": {ecodes.KEY_LEFTCTRL, ecodes.KEY_RIGHTCTRL},
    "SHIFT": {ecodes.KEY_LEFTSHIFT, ecodes.KEY_RIGHTSHIFT},
    "ALT": {ecodes.KEY_LEFTALT, ecodes.KEY_RIGHTALT},
    "SUPER": {ecodes.KEY_LEFTMETA, ecodes.KEY_RIGHTMETA},
}

# All modifier keycodes (flat set)
_ALL_MODIFIER_CODES = set()
for _codes in _MODIFIER_CODES.values():
    _ALL_MODIFIER_CODES |= _codes

# Blocked combos: modifier set -> blocked keys
_BLOCKED_COMBOS = {
    # Ctrl + key: too many system/app conflicts
    frozenset({"CTRL"}): None,  # None = block ALL keys with this modifier alone
    # Super + key: GNOME uses most
    frozenset({"SUPER"}): None,
    # Alt: only block common system shortcuts
    frozenset({"ALT"}): {
        "KEY_TAB", "KEY_F4", "KEY_F1", "KEY_F2", "KEY_F3",
    },
    # Ctrl+Alt: block common system shortcuts
    frozenset({"CTRL", "ALT"}): {
        "KEY_DELETE", "KEY_T", "KEY_L", "KEY_F1", "KEY_F2", "KEY_BACKSPACE",
    },
    # Ctrl+Shift: block common shortcuts
    frozenset({"CTRL", "SHIFT"}): {
        "KEY_C", "KEY_V", "KEY_Q", "KEY_T", "KEY_N", "KEY_Z", "KEY_ESC",
        "KEY_U", "KEY_I",
    },
}


def parse_hotkey(hotkey_str: str) -> tuple[frozenset[str], str]:
    """Parse a hotkey string into (modifiers, key).

    Examples:
        "KEY_GRAVE" -> (frozenset(), "KEY_GRAVE")
        "ALT+KEY_A" -> (frozenset({"ALT"}), "KEY_A")
        "CTRL+SHIFT+KEY_D" -> (frozenset({"CTRL", "SHIFT"}), "KEY_D")
    """
    parts = hotkey_str.upper().split("+")
    modifiers = set()
    key = None

    for part in parts:
        part = part.strip()
        if part in _MODIFIER_CODES:
            modifiers.add(part)
        elif part.startswith("KEY_"):
            if key is not None:
                raise ValueError(f"Multiple non-modifier keys in '{hotkey_str}'")
            key = part
        else:
            raise ValueError(f"Unknown key or modifier: '{part}' in '{hotkey_str}'")

    if key is None:
        raise ValueError(f"No key specified in '{hotkey_str}' (only modifiers)")

    # Validate key exists in evdev
    if key not in ecodes.ecodes:
        raise ValueError(f"Invalid key name: {key}")

    return frozenset(modifiers), key


def validate_hotkey(hotkey_str: str) -> str:
    """Validate a hotkey string and return a normalized version.

    Raises ValueError if the combo is blocked or invalid.
    """
    modifiers, key = parse_hotkey(hotkey_str)

    if modifiers:
        blocked = _BLOCKED_COMBOS.get(modifiers)
        if blocked is None and modifiers in _BLOCKED_COMBOS:
            # None means ALL keys blocked with this modifier
            raise ValueError(
                f"Modifier combination {'+'.join(sorted(modifiers))} is reserved "
                f"by the system. Try ALT+key, CTRL+SHIFT+key, or CTRL+ALT+key."
            )
        if blocked and key in blocked:
            combo_str = "+".join(sorted(modifiers)) + "+" + key
            raise ValueError(
                f"{combo_str} is a common system shortcut and cannot be used."
            )

    # Return normalized form: sorted modifiers + key
    if modifiers:
        return "+".join(sorted(modifiers)) + "+" + key
    return key


def format_hotkey_display(hotkey_str: str) -> str:
    """Human-friendly display of a hotkey (e.g. "Ctrl+Shift+D")."""
    try:
        modifiers, key = parse_hotkey(hotkey_str)
    except ValueError:
        return hotkey_str

    parts = []
    for mod in sorted(modifiers):
        parts.append(mod.capitalize())

    # Make the key name friendlier
    key_display = key.replace("KEY_", "")
    if len(key_display) == 1:
        key_display = key_display.upper()
    else:
        key_display = key_display.capitalize()
    parts.append(key_display)

    return "+".join(parts)


# --- Hotkey listener ---

class HotkeyListener(BaseHotkeyListener):
    """Listens for global hotkey presses using evdev.

    Supports single keys (grabbed exclusively) and modifier combos
    (monitored without grab).

    Args:
        key_name: Hotkey string (e.g. "KEY_GRAVE", "ALT+KEY_A").
        on_press: Callback when the hotkey is pressed.
        on_release: Callback when the hotkey is released.
        devices: Device paths or "auto".
    """

    def __init__(
        self,
        key_name: str,
        on_press: Optional[Callable[[], None]] = None,
        on_release: Optional[Callable[[], None]] = None,
        devices: str | list[str] = "auto",
    ):
        self.key_name = key_name
        self.on_press = on_press
        self.on_release = on_release

        # Parse the hotkey
        self._modifiers, self._key = parse_hotkey(key_name)
        self._is_combo = bool(self._modifiers)

        # Convert to evdev keycodes
        self.keycode = ecodes.ecodes[self._key]

        # Required modifier keycodes (any left/right variant counts)
        self._required_mod_codes = set()
        for mod_name in self._modifiers:
            self._required_mod_codes |= _MODIFIER_CODES[mod_name]

        # Track held modifiers (for combo mode)
        self._held_modifiers: set[int] = set()
        self._combo_active = False

        # Initialize devices
        if devices == "auto":
            self._devices = self._detect_keyboard_devices()
        else:
            self._devices = [InputDevice(path) for path in devices]

        if not self._devices:
            raise RuntimeError("No keyboard devices found")

        mode = "combo" if self._is_combo else "single key"
        logger.info(
            f"HotkeyListener initialized for {key_name} ({mode}) "
            f"on {len(self._devices)} device(s)"
        )
        for device in self._devices:
            logger.debug(f"  Monitoring: {device.path} - {device.name}")

        # Threading control
        self._thread: Optional[Thread] = None
        self._stop_event = Event()
        self._suspended = Event()      # Sleep/wake suspend
        self._resume_event = Event()   # Sleep/wake resume
        self._paused = Event()         # Settings pause (no timeout)
        self._unpause_event = Event()  # Settings unpause
        self._running = False
        self._lock = Lock()
        self._device_config = devices

    def _detect_keyboard_devices(self) -> list[InputDevice]:
        """Auto-detect keyboard input devices."""
        devices = []

        for device_path in evdev.list_devices():
            device = None
            try:
                device = InputDevice(device_path)
                capabilities = device.capabilities(verbose=False)

                if ecodes.EV_KEY not in capabilities:
                    device.close()
                    device = None
                    continue

                key_codes = capabilities[ecodes.EV_KEY]
                if self.keycode in key_codes:
                    devices.append(device)
                    device = None
                    logger.debug(
                        f"Found keyboard device: {devices[-1].path} - {devices[-1].name}"
                    )
                else:
                    device.close()
                    device = None

            except (OSError, PermissionError) as e:
                logger.warning(f"Cannot access device {device_path}: {e}")
                if device is not None:
                    try:
                        device.close()
                    except Exception:
                        pass

        if not devices:
            logger.warning(
                f"No keyboard devices found supporting {self._key}. "
                f"You may need to run with sudo or add your user to the 'input' group."
            )

        return devices

    def start(self) -> None:
        with self._lock:
            if self._running:
                raise RuntimeError("Hotkey listener is already running")

            self._running = True
            self._stop_event.clear()

            self._thread = Thread(target=self._listen_loop, daemon=True)
            self._thread.start()

            logger.info(f"Hotkey listener started for {self.key_name}")

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                logger.warning("Hotkey listener is not running")
                return

            logger.info("Stopping hotkey listener")
            # Unblock thread from any wait state before signaling stop
            self._resume_event.set()
            self._unpause_event.set()
            self._stop_event.set()

        if self._thread is not None:
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                logger.warning("Hotkey listener thread did not terminate cleanly")

        with self._lock:
            self._running = False
            logger.info("Hotkey listener stopped")

    def pause(self) -> None:
        """Pause the listener for settings (no timeout — waits until unpause)."""
        with self._lock:
            if not self._running:
                return

        logger.info("Pausing hotkey listener for settings")
        self._unpause_event.clear()
        self._paused.set()

        # Wait for the listen loop to confirm it released the grabs
        deadline = time.time() + 2.0
        while self._paused.is_set() and time.time() < deadline:
            time.sleep(0.05)

        if self._paused.is_set():
            logger.warning("Hotkey listener did not confirm pause in time, force-releasing grabs")
            if not self._is_combo:
                with self._lock:
                    for dev in self._devices:
                        try:
                            dev.ungrab()
                        except Exception:
                            pass
        else:
            logger.info("Hotkey listener paused, devices released")

    def unpause(self) -> bool:
        """Resume the listener after settings close."""
        with self._lock:
            if not self._running:
                return False

        # Check if thread is actually alive
        if self._thread is None or not self._thread.is_alive():
            logger.warning("Hotkey listener thread is dead, cannot unpause")
            with self._lock:
                self._running = False
            return False

        logger.info("Unpausing hotkey listener")

        if self._device_config == "auto":
            new_devices = self._detect_keyboard_devices()
        else:
            new_devices = [InputDevice(path) for path in self._device_config]

        if not new_devices:
            logger.warning("No keyboard devices found for unpause")
            return False

        with self._lock:
            old_devices = self._devices
            self._devices = new_devices

        for dev in old_devices:
            try:
                dev.close()
            except Exception:
                pass

        self._unpause_event.set()
        logger.info(f"Hotkey listener unpaused with {len(new_devices)} device(s)")
        return True

    def suspend(self) -> None:
        with self._lock:
            if not self._running:
                return

        logger.info("Suspending hotkey listener")
        self._suspended.set()

        deadline = time.time() + 2.0
        while self._suspended.is_set() and time.time() < deadline:
            time.sleep(0.05)

        if self._suspended.is_set():
            logger.warning(
                "Hotkey listener did not confirm suspension in time, "
                "force-releasing device grabs"
            )
            if not self._is_combo:
                with self._lock:
                    for dev in self._devices:
                        try:
                            dev.ungrab()
                        except Exception:
                            pass
        else:
            logger.info("Hotkey listener suspended, devices released")

    def resume(self) -> bool:
        with self._lock:
            if not self._running:
                return False

        logger.info("Resuming hotkey listener")

        if self._device_config == "auto":
            new_devices = self._detect_keyboard_devices()
        else:
            new_devices = [InputDevice(path) for path in self._device_config]

        if not new_devices:
            logger.warning("No keyboard devices found after wake (will retry)")
            return False

        with self._lock:
            old_devices = self._devices
            self._devices = new_devices

        for dev in old_devices:
            try:
                dev.close()
            except Exception:
                pass

        self._resume_event.set()

        logger.info(
            f"Hotkey listener resumed with {len(new_devices)} device(s)"
        )
        return True

    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def _grab_devices(self) -> tuple[Optional[UInput], list[InputDevice]]:
        """Grab input devices and create UInput passthrough (single-key mode only)."""
        uinput = None
        grabbed = []

        try:
            with self._lock:
                devices = list(self._devices)

            uinput = UInput.from_device(*devices, name="alto-passthrough")
            for dev in devices:
                dev.grab()
                grabbed.append(dev)
            logger.info(
                f"Grabbed {len(grabbed)} device(s) for exclusive "
                f"{self.key_name} access"
            )
        except Exception as e:
            logger.warning(
                f"Could not grab input devices: {e}. "
                f"The hotkey character may be typed when pressed."
            )
            for dev in grabbed:
                try:
                    dev.ungrab()
                except Exception:
                    pass
            grabbed = []
            if uinput is not None:
                try:
                    uinput.close()
                except Exception:
                    pass
                uinput = None

        return uinput, grabbed

    def _release_devices(
        self, uinput: Optional[UInput], grabbed: list[InputDevice]
    ) -> None:
        """Release grabbed devices and close UInput."""
        for dev in grabbed:
            try:
                dev.ungrab()
                logger.debug(f"Ungrabbed device: {dev.path}")
            except Exception as e:
                logger.warning(f"Error ungrabbing device {dev.path}: {e}")
        if uinput is not None:
            try:
                uinput.close()
                logger.debug("UInput device closed")
            except Exception as e:
                logger.warning(f"Error closing UInput: {e}")

    def _listen_loop(self) -> None:
        """Main listening loop that runs in a background thread."""
        uinput = None
        grabbed_devices = []

        try:
            logger.debug("Entering hotkey listen loop")

            # Only grab in single-key mode
            if not self._is_combo:
                uinput, grabbed_devices = self._grab_devices()

            with self._lock:
                fd_to_device = {dev.fd: dev for dev in self._devices}
                devices_version = id(self._devices)

            while not self._stop_event.is_set():
                # --- Handle suspend/resume ---
                if self._suspended.is_set():
                    logger.info("Hotkey listener releasing devices")
                    if not self._is_combo:
                        self._release_devices(uinput, grabbed_devices)
                        uinput = None
                        grabbed_devices = []

                    self._resume_event.clear()
                    self._suspended.clear()

                    resumed = self._resume_event.wait(timeout=30.0)
                    if self._stop_event.is_set() or not resumed:
                        if not resumed:
                            logger.error(
                                "Timed out waiting for device recovery "
                                "after wake (30s). Hotkey listener stopped."
                            )
                        break

                    logger.info("Hotkey listener re-grabbing devices after wake")
                    if not self._is_combo:
                        uinput, grabbed_devices = self._grab_devices()
                    with self._lock:
                        fd_to_device = {dev.fd: dev for dev in self._devices}
                        devices_version = id(self._devices)

                    for dev in fd_to_device.values():
                        try:
                            while dev.read_one() is not None:
                                pass
                        except (OSError, BlockingIOError):
                            pass
                    logger.debug("Flushed stale events after resume")

                # --- Handle pause (settings) — no timeout ---
                if self._paused.is_set():
                    logger.info("Hotkey listener pausing for settings")
                    if not self._is_combo:
                        self._release_devices(uinput, grabbed_devices)
                        uinput = None
                        grabbed_devices = []

                    self._paused.clear()  # Confirm pause to caller

                    # Wait indefinitely until unpause or stop
                    while not self._stop_event.is_set():
                        if self._unpause_event.wait(timeout=1.0):
                            break

                    if self._stop_event.is_set():
                        break

                    self._unpause_event.clear()
                    logger.info("Hotkey listener re-grabbing devices after settings")
                    if not self._is_combo:
                        uinput, grabbed_devices = self._grab_devices()
                    with self._lock:
                        fd_to_device = {dev.fd: dev for dev in self._devices}
                        devices_version = id(self._devices)

                    for dev in fd_to_device.values():
                        try:
                            while dev.read_one() is not None:
                                pass
                        except (OSError, BlockingIOError):
                            pass

                if id(self._devices) != devices_version:
                    with self._lock:
                        fd_to_device = {dev.fd: dev for dev in self._devices}
                        devices_version = id(self._devices)

                # --- Normal event processing ---
                try:
                    r, w, x = select.select(
                        fd_to_device.keys(), [], [], 0.5
                    )
                except (OSError, ValueError) as e:
                    logger.warning(f"select() error (device may have changed): {e}")
                    time.sleep(0.5)
                    continue

                if r:
                    for fd in r:
                        device = fd_to_device.get(fd)
                        if device is None:
                            continue

                        try:
                            for event in device.read():
                                if event.type != ecodes.EV_KEY:
                                    # Pass through non-key events in grab mode
                                    if uinput is not None:
                                        if not (event.type == ecodes.EV_SYN
                                                and event.code == ecodes.SYN_DROPPED):
                                            uinput.write_event(event)
                                    continue

                                if self._is_combo:
                                    self._handle_combo_event(event)
                                else:
                                    if event.code == self.keycode:
                                        self._handle_key_event(event)
                                    elif uinput is not None:
                                        uinput.write_event(event)
                        except OSError as e:
                            logger.error(
                                f"Error reading from device {device.path}: {e}"
                            )

        except Exception as e:
            logger.error(f"Error in hotkey listen loop: {e}", exc_info=True)
        finally:
            if not self._is_combo:
                self._release_devices(uinput, grabbed_devices)
            with self._lock:
                self._running = False
            logger.debug("Exiting hotkey listen loop")

    def _check_modifiers_held(self) -> bool:
        """Check if all required modifiers are currently held."""
        for mod_name in self._modifiers:
            mod_codes = _MODIFIER_CODES[mod_name]
            if not (self._held_modifiers & mod_codes):
                return False
        return True

    def _handle_combo_event(self, event) -> None:
        """Handle a key event in combo mode (track modifiers + detect combo)."""
        code = event.code

        # Track modifier state
        if code in _ALL_MODIFIER_CODES:
            if event.value == 1:  # Press
                self._held_modifiers.add(code)
            elif event.value == 0:  # Release
                self._held_modifiers.discard(code)
                # If a required modifier is released while combo is active, stop
                if self._combo_active and not self._check_modifiers_held():
                    self._combo_active = False
                    logger.debug(f"{self.key_name} combo released (modifier up)")
                    if self.on_release is not None:
                        try:
                            self.on_release()
                        except Exception as e:
                            logger.error(f"Error in on_release callback: {e}", exc_info=True)
            return

        # Non-modifier key
        if code == self.keycode:
            if event.value == 1:  # Press
                if self._check_modifiers_held():
                    self._combo_active = True
                    logger.debug(f"{self.key_name} combo pressed")
                    if self.on_press is not None:
                        try:
                            self.on_press()
                        except Exception as e:
                            logger.error(f"Error in on_press callback: {e}", exc_info=True)
            elif event.value == 0:  # Release
                if self._combo_active:
                    self._combo_active = False
                    logger.debug(f"{self.key_name} combo released")
                    if self.on_release is not None:
                        try:
                            self.on_release()
                        except Exception as e:
                            logger.error(f"Error in on_release callback: {e}", exc_info=True)

    def _handle_key_event(self, event) -> None:
        """Handle a key event for single-key mode."""
        if event.value == 1:  # Key press
            logger.debug(f"{self.key_name} pressed")
            if self.on_press is not None:
                try:
                    self.on_press()
                except Exception as e:
                    logger.error(f"Error in on_press callback: {e}", exc_info=True)

        elif event.value == 0:  # Key release
            logger.debug(f"{self.key_name} released")
            if self.on_release is not None:
                try:
                    self.on_release()
                except Exception as e:
                    logger.error(f"Error in on_release callback: {e}", exc_info=True)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()


# --- Key detection utilities ---

def _detect_single_key(timeout: float = 30.0) -> str:
    """Wait for a single key press or combo and return the hotkey string.

    If modifiers are held when a key is pressed, returns a combo string
    like "ALT+KEY_A". Otherwise returns just "KEY_X".

    Returns empty string on timeout or error.
    """
    devices = []
    for device_path in evdev.list_devices():
        try:
            device = InputDevice(device_path)
            if ecodes.EV_KEY in device.capabilities(verbose=False):
                devices.append(device)
        except (OSError, PermissionError):
            continue

    if not devices:
        return ""

    fd_to_device = {dev.fd: dev for dev in devices}
    held_modifiers: set[int] = set()
    deadline = time.time() + timeout

    try:
        while time.time() < deadline:
            r, _, _ = select.select(fd_to_device.keys(), [], [], 0.2)
            for fd in r:
                for event in fd_to_device[fd].read():
                    if event.type != ecodes.EV_KEY:
                        continue

                    code = event.code

                    # Track modifiers
                    if code in _ALL_MODIFIER_CODES:
                        if event.value == 1:
                            held_modifiers.add(code)
                        elif event.value == 0:
                            held_modifiers.discard(code)
                        continue

                    # Non-modifier key pressed
                    if event.value == 1 and code < 272:
                        key_event = categorize(event)
                        name = key_event.keycode
                        if isinstance(name, (list, tuple)):
                            name = name[0]

                        # Build modifier prefix
                        mod_names = set()
                        for mod_name, mod_codes in _MODIFIER_CODES.items():
                            if held_modifiers & mod_codes:
                                mod_names.add(mod_name)

                        if mod_names:
                            combo = "+".join(sorted(mod_names)) + "+" + name
                            # Validate the combo
                            try:
                                return validate_hotkey(combo)
                            except ValueError:
                                # Blocked combo — ignore, keep waiting
                                continue
                        else:
                            return name
    finally:
        for dev in devices:
            try:
                dev.close()
            except Exception:
                pass
    return ""


def detect_key_interactive() -> str:
    """Interactive utility to detect which key the user presses."""
    print("Key detection mode - Press any key or combo to detect (Ctrl+C to exit)")
    print("Supported combos: Alt+key, Ctrl+Shift+key, Ctrl+Alt+key")
    print()

    devices = []
    for device_path in evdev.list_devices():
        try:
            device = InputDevice(device_path)
            capabilities = device.capabilities(verbose=False)

            if ecodes.EV_KEY in capabilities:
                devices.append(device)
                print(f"Monitoring: {device.path} - {device.name}")

        except (OSError, PermissionError) as e:
            print(f"Warning: Cannot access {device_path}: {e}")

    if not devices:
        print("\nError: No keyboard devices found!")
        print("You may need to run with sudo or add your user to the 'input' group:")
        print("  sudo usermod -a -G input $USER")
        print("  (then log out and back in)")
        return ""

    print("\nWaiting for key press...")
    print()

    held_modifiers: set[int] = set()

    try:
        fd_to_device = {dev.fd: dev for dev in devices}

        while True:
            r, w, x = select.select(fd_to_device.keys(), [], [], 0.1)

            for fd in r:
                device = fd_to_device[fd]

                for event in device.read():
                    if event.type != ecodes.EV_KEY:
                        continue

                    code = event.code

                    if code in _ALL_MODIFIER_CODES:
                        if event.value == 1:
                            held_modifiers.add(code)
                        elif event.value == 0:
                            held_modifiers.discard(code)
                        continue

                    if event.value == 1:
                        key_event = categorize(event)
                        key_name = key_event.keycode
                        if isinstance(key_name, list):
                            key_name = key_name[0]

                        mod_names = set()
                        for mod_name, mod_codes in _MODIFIER_CODES.items():
                            if held_modifiers & mod_codes:
                                mod_names.add(mod_name)

                        if mod_names:
                            combo = "+".join(sorted(mod_names)) + "+" + key_name
                            try:
                                combo = validate_hotkey(combo)
                                print(f"Detected combo: {combo}")
                                print(f"  Display: {format_hotkey_display(combo)}")
                                print()
                                return combo
                            except ValueError as e:
                                print(f"  Blocked: {combo} ({e})")
                                print("  Try a different combination.")
                                print()
                        else:
                            print(f"Detected key: {key_name}")
                            print(f"  Device: {device.name}")
                            print()
                            return key_name

    except KeyboardInterrupt:
        print("\n\nKey detection cancelled")
        return ""
    finally:
        for device in devices:
            device.close()
