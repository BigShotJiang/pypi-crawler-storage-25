"""
Sleep/wake monitor using systemd-logind DBus signals.

Listens to org.freedesktop.login1.Manager.PrepareForSleep to detect
when the system is about to sleep and when it wakes up. Uses gdbus
subprocess to avoid adding Python DBus dependencies.

Holds a systemd sleep inhibitor (delay mode) to guarantee that the
on_sleep callback completes before the system actually suspends.
"""

import logging
import shutil
import subprocess
from threading import Event, Thread
from typing import Callable, Optional

from alto.platforms.base import BaseSleepMonitor

logger = logging.getLogger(__name__)


class SleepMonitor(BaseSleepMonitor):
    """Monitors system sleep/wake events via systemd-logind DBus signals.

    Spawns a gdbus monitor subprocess that watches for PrepareForSleep
    signals. Calls on_sleep before the system suspends and on_wake after
    it resumes.

    Holds a delay sleep inhibitor so that on_sleep is guaranteed to
    finish before the system actually suspends. The inhibitor is released
    after on_sleep completes, then re-acquired after on_wake.

    Args:
        on_sleep: Callback invoked before the system goes to sleep.
        on_wake: Callback invoked after the system wakes up.
    """

    def __init__(
        self,
        on_sleep: Optional[Callable[[], None]] = None,
        on_wake: Optional[Callable[[], None]] = None,
    ):
        self.on_sleep = on_sleep
        self.on_wake = on_wake
        self._process: Optional[subprocess.Popen] = None
        self._inhibitor: Optional[subprocess.Popen] = None
        self._thread: Optional[Thread] = None
        self._stop_event = Event()

    def start(self) -> bool:
        if not shutil.which("gdbus"):
            logger.warning(
                "gdbus not found, sleep/wake monitoring disabled. "
                "Install glib2 tools if you want sleep/wake support."
            )
            return False

        self._stop_event.clear()
        self._acquire_inhibitor()
        self._thread = Thread(
            target=self._monitor_loop, daemon=True, name="SleepMonitor"
        )
        self._thread.start()
        logger.info("Sleep/wake monitor started")
        return True

    def stop(self) -> None:
        self._stop_event.set()
        self._release_inhibitor()

        if self._process is not None:
            try:
                self._process.terminate()
                self._process.wait(timeout=2)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
            self._process = None

        if self._thread is not None:
            self._thread.join(timeout=3)
            self._thread = None

        logger.info("Sleep/wake monitor stopped")

    def _acquire_inhibitor(self) -> None:
        if self._inhibitor is not None:
            return

        if not shutil.which("systemd-inhibit"):
            logger.warning("systemd-inhibit not found, sleep inhibitor disabled")
            return

        try:
            self._inhibitor = subprocess.Popen(
                [
                    "systemd-inhibit",
                    "--what=sleep",
                    "--who=Alto",
                    "--why=Releasing input device grabs",
                    "--mode=delay",
                    "cat",
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            logger.info("Sleep inhibitor acquired (delay mode)")
        except Exception as e:
            logger.warning(f"Failed to acquire sleep inhibitor: {e}")
            self._inhibitor = None

    def _release_inhibitor(self) -> None:
        if self._inhibitor is None:
            return

        try:
            self._inhibitor.stdin.close()
            self._inhibitor.wait(timeout=2)
        except Exception:
            try:
                self._inhibitor.kill()
            except Exception:
                pass
        self._inhibitor = None
        logger.info("Sleep inhibitor released")

    def _monitor_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._process = subprocess.Popen(
                    [
                        "gdbus", "monitor", "--system",
                        "--dest", "org.freedesktop.login1",
                        "--object-path", "/org/freedesktop/login1",
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )

                logger.debug("gdbus monitor subprocess started")

                for line in self._process.stdout:
                    if self._stop_event.is_set():
                        break

                    if "PrepareForSleep" not in line:
                        continue

                    if "(true)" in line or "(true,)" in line:
                        logger.info("System preparing for sleep")
                        self._invoke_callback(self.on_sleep)
                        self._release_inhibitor()
                    elif "(false)" in line or "(false,)" in line:
                        logger.info("System waking from sleep")
                        self._acquire_inhibitor()
                        self._invoke_callback(self.on_wake)

                if self._process is not None:
                    self._process.wait()

                if not self._stop_event.is_set():
                    logger.warning("gdbus monitor exited, restarting in 5s")
                    self._stop_event.wait(timeout=5)

            except Exception as e:
                if not self._stop_event.is_set():
                    logger.error(f"Sleep monitor error: {e}", exc_info=True)
                    self._stop_event.wait(timeout=10)

    def _invoke_callback(self, callback: Optional[Callable[[], None]]) -> None:
        if callback is None:
            return
        try:
            callback()
        except Exception as e:
            logger.error(f"Sleep monitor callback error: {e}", exc_info=True)
