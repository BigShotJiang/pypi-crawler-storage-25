"""macOS platform implementations (not yet available)."""
