"""
Configuration management for Alto service.
"""

import json
import logging
import os
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class ServiceConfig:
    """Configuration for Alto speech-to-text service."""

    model: str = "voxtral-mini-latest"
    language: str = "en"
    evdev_key: str = "KEY_GRAVE"
    evdev_devices: str = "auto"
    typing_delay_ms: int = 12
    log_level: str = "INFO"

    # Audio recording parameters
    audio_sample_rate: int = 16000
    audio_channels: int = 1
    audio_dtype: str = "int16"
    audio_blocksize: int = 0  # 0 = auto (based on latency)
    audio_enable_noise_suppression: bool = False
    audio_enable_agc: bool = False

    # Feedback and telemetry
    feedback_url: str = "mailto:contact@alto-dictation.com"
    enable_telemetry: bool = False  # Opt-in telemetry for anonymized usage data

    # Auto-update settings
    check_for_updates: bool = True  # Check for updates on startup
    repository_url: str = ""

    # Cloud API settings
    api_base_url: str = "https://api.alto-dictation.com"

    @classmethod
    def from_dict(cls, config_dict: dict) -> "ServiceConfig":
        """Create a ServiceConfig instance from a dictionary.

        Args:
            config_dict: Dictionary containing configuration values

        Returns:
            ServiceConfig instance with values from dictionary
        """
        # Filter out any unexpected keys
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered_dict = {k: v for k, v in config_dict.items() if k in valid_fields}

        return cls(**filtered_dict)

    def validate(self) -> None:
        """Validate configuration values.

        Raises:
            ValueError: If any configuration value is invalid
        """
        if not self.model:
            raise ValueError("model cannot be empty")

        if not self.language:
            raise ValueError("language cannot be empty")

        if not self.evdev_key:
            raise ValueError("evdev_key cannot be empty")

        if not self.evdev_devices:
            raise ValueError("evdev_devices cannot be empty")

        if self.typing_delay_ms < 0:
            raise ValueError("typing_delay_ms must be non-negative")

        valid_log_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if self.log_level not in valid_log_levels:
            raise ValueError(
                f"log_level must be one of {valid_log_levels}, got '{self.log_level}'"
            )

        # Validate audio parameters
        if self.audio_sample_rate not in [8000, 16000, 22050, 44100, 48000]:
            raise ValueError(
                f"audio_sample_rate must be one of [8000, 16000, 22050, 44100, 48000], "
                f"got {self.audio_sample_rate}"
            )

        if self.audio_channels not in [1, 2]:
            raise ValueError(
                f"audio_channels must be 1 (mono) or 2 (stereo), got {self.audio_channels}"
            )

        valid_dtypes = {"int16", "int32", "float32"}
        if self.audio_dtype not in valid_dtypes:
            raise ValueError(
                f"audio_dtype must be one of {valid_dtypes}, got '{self.audio_dtype}'"
            )

        if self.audio_blocksize < 0:
            raise ValueError("audio_blocksize must be non-negative (0 = auto)")

        if not isinstance(self.audio_enable_noise_suppression, bool):
            raise ValueError("audio_enable_noise_suppression must be a boolean")

        if not isinstance(self.audio_enable_agc, bool):
            raise ValueError("audio_enable_agc must be a boolean")

        # Validate feedback parameters
        if not isinstance(self.feedback_url, str) or not self.feedback_url:
            raise ValueError("feedback_url must be a non-empty string")

        if not isinstance(self.enable_telemetry, bool):
            raise ValueError("enable_telemetry must be a boolean")

        # Validate auto-update parameters
        if not isinstance(self.check_for_updates, bool):
            raise ValueError("check_for_updates must be a boolean")

        if not isinstance(self.repository_url, str):
            raise ValueError("repository_url must be a string")



def save_config(config_path: Path, config: ServiceConfig) -> None:
    """Save configuration to JSON file atomically.

    Reads the existing JSON (if any) to preserve keys not managed by the UI,
    updates with the current config values, then writes atomically via
    tmp file + rename.

    Args:
        config_path: Path to config.json file.
        config: ServiceConfig instance to save.
    """
    # Load existing data to preserve unknown keys
    existing = {}
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # Update with current config fields
    existing.update(asdict(config))

    # Write atomically: tmp file in same directory, then rename
    dir_path = config_path.parent
    dir_path.mkdir(parents=True, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(dir=dir_path, suffix=".tmp", prefix=".config_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2, ensure_ascii=False)
            f.write("\n")
        os.replace(tmp_path, config_path)
        logger.info(f"Configuration saved to {config_path}")
    except Exception:
        # Clean up tmp file on failure
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def load_config(config_path: Optional[Path] = None) -> ServiceConfig:
    """Load and validate configuration from JSON file.

    Args:
        config_path: Path to config.json file. If None, looks for config.json
                    in the current directory.

    Returns:
        ServiceConfig instance with loaded configuration

    Raises:
        FileNotFoundError: If config file does not exist
        ValueError: If config file is invalid or contains invalid values
        json.JSONDecodeError: If config file contains invalid JSON
    """
    if config_path is None:
        config_path = Path("config.json")

    if not config_path.exists():
        logger.warning(
            f"Config file not found at {config_path}, using default configuration"
        )
        config = ServiceConfig()
        config.validate()
        return config

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config_dict = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in config file {config_path}: {e}") from e
    except Exception as e:
        raise ValueError(f"Error reading config file {config_path}: {e}") from e

    if not isinstance(config_dict, dict):
        raise ValueError(f"Config file must contain a JSON object, got {type(config_dict)}")

    config = ServiceConfig.from_dict(config_dict)
    config.validate()

    logger.info(f"Loaded configuration from {config_path}")
    return config
