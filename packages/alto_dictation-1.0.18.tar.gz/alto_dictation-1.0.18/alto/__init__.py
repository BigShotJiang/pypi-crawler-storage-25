"""
Alto - System-wide push-to-talk speech-to-text service for Linux.
"""

__version__ = "1.0.18"

from alto.daemon import AltoDaemon, preflight_check

__all__ = ["AltoDaemon", "preflight_check"]
