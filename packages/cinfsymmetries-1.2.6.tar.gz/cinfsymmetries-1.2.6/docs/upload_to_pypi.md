# How to Upload `cinfsymmetries` to PyPI

To upload your library to PyPI (Python Package Index) so others can install it via `pip install cinfsymmetries`, follow these steps.

### 1. Create a PyPI Account
1.  Go to [PyPI.org](https://pypi.org/account/register/) and create an account.
2.  Go to **Account Settings** and create an **API Token**. 
3.  **Save the token** somewhere safe; you will need it for the upload.

### 2. Install Build Tools
Run this in your terminal to install the tools inside your existing virtual environment:
```bash
source .venv/bin/activate
pip install build twine
```

### 3. Build the Distribution Files
This creates a `dist/` folder containing a `.tar.gz` (source) and a `.whl` (built) file.
```bash
# Ensure you are still in the virtual environment
python3 -m build
```

### 4. Upload to PyPI
Use `twine` to upload the files. When prompted for a username, use `__token__`. For the password, paste the API token you generated in Step 1.
```bash
python3 -m twine upload dist/*
```

### 5. Verify the Upload
Once successful, anyone (including you in Colab!) can install it with:
```bash
pip install cinfsymmetries
```

> [!IMPORTANT]
> **Name Congestion**: The name `cinfsymmetries` might already be taken on PyPI (though it's unlikely). If it is, we will need to change the `name` field in `pyproject.toml` slightly (e.g., `cinfsymmetries-ode`).
