# How to Update `cinfsymmetries` on PyPI

When we add new features (like Jet Spaces or prolongations) and you want to release a new version to the public, follow these steps.

### 1. Update the Version Number
Open `pyproject.toml` and increase the version number.
*   If it was `0.1.0`, change it to `0.1.1` (for small fixes) or `0.2.0` (for new features).

```toml
[project]
name = "cinfsymmetries"
version = "1.2.0"  # Update this!
```

### 2. Clean Old Builds (Optional but Recommended)
Navigate to the root directory of the project (`06_python_library`) and delete the old `dist/` folder.
```bash
cd "/home/antoniojpan/Dropbox/MIMUNDO/05 archivos cálculos/06_python_library"
rm -rf dist/
```

### 3. Rebuild the Library
Ensure you are in the root directory and run the following commands. We use `uv` to manage the environment and dependencies.

```bash
# Clear any active venv first
deactivate 2>/dev/null

# Sync dependencies (installs build and twine into the project environment)
uv sync

# Build the library
uv run python -m build
```

### 4. Upload the New Version
Upload the new files in the `dist/` folder.
```bash
uv run python -m twine upload dist/*
```
*   **Username**: `__token__`
*   **Password**: Your PyPI API token.

### 5. Update your local installation
To test your own changes locally after building but before uploading, you can run:
```bash
uv pip install -e .
```
This "editable" install means that any changes we make to the code files in the `cinfsymmetries/` folder will be immediately available in your Python environment without reinstalling.
