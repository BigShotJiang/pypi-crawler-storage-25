# Python Geometric ODE Library Plan

This plan aims to bridge the gap in Python for the geometric study of differential equations (Lie Symmetries, $\lambda$-symmetries, $C^{\infty}$-structures, Solvable Structures), migrating the functionality from your Maple package (`CinfStructures.mpl`) into a modern Python library heavily based on `sympy`.

## Phase 1: Project Configuration & Architecture
- [x] **Project Setup**: Initialize a standard Python library layout (`pyproject.toml`) and testing infrastructure (`pytest`).
- [x] **Architecture Design**: We chose to implement custom `VectorField` and `Distribution` classes for flexibility, and added `Chart` and `JetSpaceChart` to manage coordinates.

## Phase 2: Core Primitives
- [x] **Jet Spaces Definition**: Implemented `Chart` and `JetSpaceChart` to easily define $(x, u, u_1, \dots, u_k)$.
- [x] **Vector Fields & Operations**: Implemented `VectorField` with scalar multiplication, sum, evaluation, and Lie Bracket.
- [x] **Differential Forms**: Implemented `DifferentialForm` class with wedge product ($\wedge$), exterior derivative ($d$), and interior product ($i_X$).

## Phase 3: Base Geometric Operations
- [x] **Associated Vector Field**: Added `JetSpaceChart.total_derivative()`. Added `get_determining_equations` to derive symmetry conditions.
- [x] **Prolongations**: Implemented standard and $\lambda$-prolongation of vector fields in jet spaces.
- [x] **Involutivity**: Implemented `Distribution.is_involutive()` and `Distribution.check_symmetry(X)`.
- [x] **Cinf-Symmetries**: Implemented `Distribution.check_cinf_symmetry(X)` for generalized and $\lambda$-symmetries.
- [ ] **Pfaffian Systems**: Implement `PfaffianSystem` class and operations to compute and work with duals to distributions, and vice-versa.

## Phase 4: Symmetries, Invariants & High-Level Solving
- [x] **Determining Equations**: Implemented `get_determining_equations` for Lie and $\lambda$-symmetries. Also added `Distribution.get_cinf_determining_equations` for general distributions.
- [ ] **Solving Symmetries**: Port or bridge to SymPy's PDE solvers to automatically solve the determining equations for simple cases.
- [x] **Invariants**: Implement algorithms to calculate invariants of a vector field (functions $I$ such that $pr^{(n)} X(I) = 0$).
- [x] **Structure Checking**: Implement `check_structure` for Solvable and $C^{\infty}$-structures.
- [ ] **Solving/Reduction**: Implement reduction to orbit spaces and `dsolvejet`.

## Next Steps

1. **Pfaffian Systems**: Create a `PfaffianSystem` class to represent systems of differential forms, implement the duality with distributions.
2. **Invariants Calculation**: Implement a method to find basic invariants (functions) for a given symmetry.
3. **Solving Symmetries**: Integrate with SymPy's `pdsolve` to automate finding infinitesimal generators.
4. **Documentation**: Enhance `manual.md` with examples for differential forms and symmetry search.

