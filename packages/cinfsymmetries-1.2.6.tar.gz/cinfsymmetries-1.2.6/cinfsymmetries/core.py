import sympy as sp
import warnings
from typing import Union, Optional, List, Dict, Tuple, Any, Set

class ScalarField:
    def __init__(self, expr: Any, chart: Optional['Chart'] = None):
        """Represents a scalar function (0-form) associated with a chart."""
        self.expr = sp.sympify(expr)
        self.chart = chart

    def _validate_charts(self, other):
        if hasattr(other, 'chart') and self.chart and other.chart and self.chart != other.chart:
            raise ValueError("Operation between objects on different charts")

    def __add__(self, other):
        if isinstance(other, ScalarField):
            self._validate_charts(other)
            return ScalarField(self.expr + other.expr, self.chart or other.chart)
        return ScalarField(self.expr + sp.sympify(other), self.chart)

    def __radd__(self, other):
        return self.__add__(other)

    def __mul__(self, other):
        if isinstance(other, ScalarField):
            self._validate_charts(other)
            return ScalarField(self.expr * other.expr, self.chart or other.chart)
        if hasattr(other, '__mul__') and not isinstance(other, (int, float, sp.Basic, str)):
            # Delegate to the other object's multiplication if it's not a simple type
            # This handles DifferentialForm and VectorField
            return other.__rmul__(self)
        return ScalarField(self.expr * sp.sympify(other), self.chart)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __sub__(self, other):
        return self + (other * -1)

    def __truediv__(self, other):
        if isinstance(other, ScalarField):
            self._validate_charts(other)
            return ScalarField(self.expr / other.expr, self.chart or other.chart)
        return ScalarField(self.expr / sp.sympify(other), self.chart)

    def __pow__(self, other):
        if isinstance(other, ScalarField):
            self._validate_charts(other)
            return ScalarField(self.expr ** other.expr, self.chart or other.chart)
        return ScalarField(self.expr ** sp.sympify(other), self.chart)

    def d(self) -> 'DifferentialForm':
        """Computes the exterior derivative d(f)."""
        if self.chart is None:
            raise ValueError("Exterior derivative .d() requires a chart link.")
        return self.chart.d(self.expr)

    def lie_derivative(self, X: 'VectorField') -> 'ScalarField':
        """Computes the Lie derivative of this scalar field along vector field X: L_X(f) = X(f)."""
        if not hasattr(X, '__call__'):
            raise TypeError("Lie derivative of a scalar field requires a VectorField (or a derivation)")
        return X(self)

    def __call__(self, *args, **kwargs):
        # Allow evaluation if it behaves like a function
        return self.expr.subs(*args, **kwargs)

    def __repr__(self):
        return f"ScalarField({self.expr})"

    def _repr_latex_(self):
        return "$" + sp.latex(self.expr) + "$"

    def _sympy_(self):
        return self.expr


class VectorField:
    def __init__(self, components: Dict[sp.Symbol, Any], chart: Optional['Chart'] = None, simplify: bool = False):
        """
        Initializes a symbolic vector field X = sum f_i * d/dx_i.
        
        Args:
            components: Mapping from coordinate symbols to coefficients.
            chart: Associated coordinate chart.
            simplify: Whether to call sp.simplify on components.
        """
        self.chart = chart
        self.components = {}
        for k, v in components.items():
            val = sp.simplify(v) if simplify else sp.sympify(v)
            if val != 0:
                self.components[k] = val
                
    def __call__(self, expr):
        """
        Applies the vector field as a derivation operator to a scalar expression.
        """
        if isinstance(expr, ScalarField):
            self._validate_charts(expr)
            res = self._apply(expr.expr)
            return ScalarField(res, self.chart or expr.chart)
        return self._apply(expr)

    def _apply(self, expr):
        expr = sp.sympify(expr)
        result = 0
        for var, coeff in self.components.items():
            result += coeff * sp.diff(expr, var)
        return sp.simplify(result)

    def _validate_charts(self, other):
        if hasattr(other, 'chart') and self.chart and other.chart and self.chart != other.chart:
            raise ValueError("Operation between objects on different charts")

    def __add__(self, other):
        if not isinstance(other, VectorField):
            raise TypeError("Can only add two vector fields")
        self._validate_charts(other)
        all_vars = set(self.components.keys()).union(other.components.keys())
        new_comp = {}
        for v in all_vars:
            val = sp.simplify(self.components.get(v, 0) + other.components.get(v, 0))
            if val != 0:
                new_comp[v] = val
        return VectorField(new_comp, self.chart or other.chart)

    def __mul__(self, scalar):
        """Right multiplication by a scalar function"""
        if isinstance(scalar, ScalarField):
            self._validate_charts(scalar)
            scalar_expr = scalar.expr
        else:
            scalar_expr = sp.sympify(scalar)
            
        new_comp = {k: sp.simplify(v * scalar_expr) for k, v in self.components.items()}
        return VectorField(new_comp, self.chart)

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def __sub__(self, other):
        return self + (other * -1)

    def lie_derivative(self, other: Union['VectorField', 'DifferentialForm', 'ScalarField']) -> Union['VectorField', 'DifferentialForm', 'ScalarField']:
        """
        Computes the Lie derivative of 'other' along this vector field.
        Handles VectorFields ([X, Y]), DifferentialForms (L_X omega), and Scalars (X(f)).
        """
        if isinstance(other, VectorField):
            return LieBracket(self, other)
        elif hasattr(other, 'lie_derivative'):
            # This handles DifferentialForm and ScalarField
            return other.lie_derivative(self)
        else:
            # Fallback to applying self as a derivation (handles SymPy expressions)
            res = self(other)
            if isinstance(other, ScalarField):
                return ScalarField(res, self.chart or other.chart)
            return res


    def __repr__(self):
        terms = [f"({c}) * ∂/∂{v}" for v, c in self.components.items()]
        return " + ".join(terms) if terms else "0"

    def _repr_latex_(self):
        terms = []
        # Sort by variable name for deterministic output
        sorted_vars = sorted(self.components.keys(), key=lambda x: str(x))
        for v in sorted_vars:
            c = self.components[v]
            c_latex = sp.latex(c)
            v_latex = sp.latex(v)
            terms.append(rf"\left( {c_latex} \right) \frac{{\partial}}{{\partial {v_latex}}}")
        return "$" + (" + ".join(terms) if terms else "0") + "$"

    def get_invariants(self) -> List[sp.Basic]:
        """Calculates a basis of independent invariants I such that X(I) = 0."""
        if self.chart:
            vars = list(self.chart.coords)
        else:
            vars = list(self.components.keys())
            
        if not vars:
            return []
        if len(vars) == 1 and self.components.get(vars[0], 0) != 0:
            # For X = f(x) d/dx, there are no non-constant invariants in 1D
            return []
            
        # 0. Trivial Invariants: variables with zero component
        trivials = [v for v in vars if self.components.get(v, 0) == 0]
        # We still need to find invariants among the non-trivial ones if possible.
        # But for now, let's at least return the trivials if they exist.
        if len(trivials) == len(vars) - 1:
            # Only one variable is moving, so all others are independent invariants.
            return trivials
        
        # If all components are 0, all variables are invariants (X=0)
        if len(trivials) == len(vars):
            return vars
            
        # We need to solve the first-order PDE X(I) = 0.
        # SymPy's pdsolve can handle this.
        I_func = sp.Function('I')(*vars)
        eq = sp.Equality(self(I_func), 0)
        
        try:
            # For 2 variables, pdsolve works well
            if len(vars) == 2:
                I_func = sp.Function('I')(*vars)
                eq = sp.Equality(self(I_func), 0)
                sol = sp.pdsolve(eq)
                if isinstance(sol, sp.Equality) and sol.lhs == I_func:
                    rhs = sol.rhs
                    return list(rhs.args)
            
            # For n >= 2, use method of characteristics: dx_i/dt = xi_i
            # This is equivalent to solving dx_i/dx_1 = xi_i/xi_1 if xi_1 != 0
            t = sp.Symbol('t_param')
            funcs = [sp.Function(f'x{i}')(t) for i in range(len(vars))]
            # Map variables to these functions for substitution
            sub_map = {vars[i]: funcs[i] for i in range(len(vars))}
            
            odes = []
            for i in range(len(vars)):
                xi_i = self.components.get(vars[i], 0)
                odes.append(sp.Equality(funcs[i].diff(t), xi_i.subs(sub_map)))
            
            # Solve the system of ODEs
            sol_system = sp.dsolve(odes)
            
            # Extract constants C1, C2, ...
            # Each solution is x_i(t) = expr(t, C1, C2, ...)
            # We want to solve for the constants in terms of x_i and then eliminate t.
            # This is generally hard, but for many cases it works.
            
            # Simpler fallback for translation/scaling:
            if all(xi.is_number or (xi/vars[i]).is_number for i, xi in enumerate([self.components.get(vars[j], 0) for j in range(len(vars))])):
                # For translation X = sum a_i d/dx_i => invariants a_j x_i - a_i x_j
                # For scaling X = sum a_i x_i d/dx_i => invariants x_i^(1/a_i) / x_j^(1/a_j)
                pass
                
        except Exception:
            pass
            
            # Robust Fallback for common cases:
        # If X = sum a_i d/dx_i (constant coefficients)
        components_list = [self.components.get(v, 0) for v in vars]
        
        # Check for constant coefficients (translation)
        if all(c.is_number for c in components_list):
            invariants = []
            idx0 = -1
            for i, c in enumerate(components_list):
                if c != 0:
                    idx0 = i
                    break
            if idx0 != -1:
                c0 = components_list[idx0]
                v0 = vars[idx0]
                for i in range(len(vars)):
                    if i == idx0: continue
                    ci = components_list[i]
                    vi = vars[i]
                    invariants.append(sp.simplify(c0*vi - ci*v0))
                return invariants

        # Check for scaling X = sum a_i x_i d/dx_i
        is_scaling = True
        a_coeffs = []
        for i in range(len(vars)):
            xi_i = self.components.get(vars[i], 0)
            # Check if xi_i = a_i * x_k (usually k=i)
            # More generally, check if xi_i / vars[i] is a constant
            try:
                frac = sp.simplify(xi_i / vars[i])
                if frac.is_number:
                    a_coeffs.append(frac)
                else:
                    is_scaling = False
                    break
            except Exception:
                is_scaling = False
                break
        
        if is_scaling and a_coeffs:
            invariants = []
            idx0 = -1
            for i, a in enumerate(a_coeffs):
                if a != 0:
                    idx0 = i
                    break
            if idx0 != -1:
                a0 = a_coeffs[idx0]
                v0 = vars[idx0]
                for i in range(len(vars)):
                    if i == idx0: continue
                    ai = a_coeffs[i]
                    vi = vars[i]
                    # I = vi^(1/ai) / v0^(1/a0)  or more simply vi^a0 / v0^ai
                    invariants.append(sp.simplify(vi**a0 / v0**ai))
                return invariants

        warnings.warn("get_invariants: could not find invariants for this vector field. Returning [].")
        return []


def LieBracket(X: 'VectorField', Y: 'VectorField') -> 'VectorField':
    """
    Computes the Lie Bracket [X, Y] = X(Y) - Y(X).
    
    Args:
        X: The first vector field.
        Y: The second vector field.
    """
    all_vars = set(X.components.keys()).union(Y.components.keys())
    new_comp = {}
    for var in all_vars:
        eta = Y.components.get(var, 0)
        xi = X.components.get(var, 0)
        val = sp.simplify(X(eta) - Y(xi))
        if val != 0:
            new_comp[var] = val
    return VectorField(new_comp)


def _canonicalize_wedge(vars_tuple):
    """
    Sorts a tuple of variables and calculates the sign of the permutation.
    Returns (sorted_tuple, sign). If there are duplicates, returns (None, 0).
    """
    n = len(vars_tuple)
    if n <= 1:
        return vars_tuple, 1
    
    l = list(vars_tuple)
    swaps = 0
    # Use symbol names for sorting
    for i in range(n):
        for j in range(0, n-i-1):
            if str(l[j]) > str(l[j+1]):
                l[j], l[j+1] = l[j+1], l[j]
                swaps += 1
            elif str(l[j]) == str(l[j+1]):
                return None, 0
    return tuple(l), (-1)**swaps


class DifferentialForm:
    def __init__(self, degree: int, components: Dict[Tuple[sp.Symbol, ...], Any], chart: Optional['Chart'] = None):
        """
        Initializes a differential k-form.
        
        Args:
            degree: The degree k of the form.
            components: Mapping from tuples of coordinate symbols to coefficients.
            chart: The coordinate chart.
        """
        self.degree = degree
        self.chart = chart
        self.components = {}
        
        for k, v in components.items():
            if not isinstance(k, tuple):
                k = (k,)
            
            if len(k) != degree:
                raise ValueError(f"Component key {k} does not match degree {degree}")
            
            canon_k, sign = _canonicalize_wedge(k)
            if sign != 0:
                val = sp.simplify(sign * v)
                if val != 0:
                    self.components[canon_k] = self.components.get(canon_k, 0) + val
        
        # Final simplification of components
        self.components = {k: sp.simplify(v) for k, v in self.components.items() if sp.simplify(v) != 0}

    def _validate_charts(self, other):
        if hasattr(other, 'chart') and self.chart and other.chart and self.chart != other.chart:
            raise ValueError("Operation between objects on different charts")

    def __add__(self, other):
        if not isinstance(other, DifferentialForm) or self.degree != other.degree:
            raise TypeError("Can only add differential forms of the same degree")
        self._validate_charts(other)
        
        new_components = self.components.copy()
        for k, v in other.components.items():
            new_components[k] = new_components.get(k, 0) + v
            
        return DifferentialForm(self.degree, new_components, self.chart or other.chart)

    def __sub__(self, other):
        return self + (other * -1)

    def __mul__(self, scalar):
        if isinstance(scalar, ScalarField):
            self._validate_charts(scalar)
            scalar = scalar.expr
        else:
            scalar = sp.sympify(scalar)
            
        new_comp = {k: v * scalar for k, v in self.components.items()}
        return DifferentialForm(self.degree, new_comp, self.chart)

    def __rmul__(self, scalar):
        return self.__mul__(scalar)

    def wedge(self, other: Union['DifferentialForm', Any]) -> 'DifferentialForm':
        """Computes the exterior product self ^ other."""
        if not isinstance(other, DifferentialForm):
            # Treat as scalar multiplication if other is a sympifiable expression
            try:
                return self * other
            except Exception:
                raise TypeError("Wedge product requires another DifferentialForm or a scalar")
        
        self._validate_charts(other)
        new_degree = self.degree + other.degree
        new_components = {}
        
        for k1, v1 in self.components.items():
            for k2, v2 in other.components.items():
                combined_k = k1 + k2
                canon_k, sign = _canonicalize_wedge(combined_k)
                if sign != 0:
                    val = sign * v1 * v2
                    new_components[canon_k] = new_components.get(canon_k, 0) + val
                    
        return DifferentialForm(new_degree, new_components, self.chart or other.chart)

    def __xor__(self, other):
        """Operator ^ for wedge product"""
        return self.wedge(other)

    def d(self) -> 'DifferentialForm':
        """Computes the exterior derivative d(self)."""
        if self.chart is None:
            raise ValueError("Exterior derivative requires a chart to identify variables")
            
        new_degree = self.degree + 1
        new_components = {}
        
        for k, v in self.components.items():
            # For each term f * dx^I, d(f * dx^I) = df ^ dx^I
            # df = sum (df/dx_j * dx^j)
            for var in self.chart.coords:
                df_dvar = sp.diff(v, var)
                if df_dvar != 0:
                    # Wedge (dx^j) with (dx^I)
                    combined_k = (var,) + k
                    canon_k, sign = _canonicalize_wedge(combined_k)
                    if sign != 0:
                        val = sign * df_dvar
                        new_components[canon_k] = new_components.get(canon_k, 0) + val
                        
        return DifferentialForm(new_degree, new_components, self.chart)

    def i(self, X: 'VectorField') -> 'DifferentialForm':
        """Computes the interior product i_X(self)."""
        if not isinstance(X, VectorField):
            raise TypeError("Interior product requires a VectorField")
            
        if self.degree == 0:
            return 0
            
        new_degree = self.degree - 1
        new_components = {}
        
        for k, v in self.components.items():
            # i_X (f * dx^i1 ^ ... ^ dx^ik) = f * sum_j (-1)^(j-1) X(x^ij) dx^i1 ^ ... ^ skip dx^ij ^ ... ^ dx^ik
            for j in range(len(k)):
                var_j = k[j]
                X_j = X.components.get(var_j, 0)
                if X_j != 0:
                    remaining_k = k[:j] + k[j+1:]
                    sign = (-1)**j
                    val = sign * v * X_j
                    new_components[remaining_k] = new_components.get(remaining_k, 0) + val
                    
        return DifferentialForm(new_degree, new_components, self.chart)

    def lie_derivative(self, X: 'VectorField') -> 'DifferentialForm':
        """Computes the Lie derivative L_X(omega) = i_X(d omega) + d(i_X omega)."""
        if not isinstance(X, VectorField):
            raise TypeError("Lie derivative requires a VectorField")
        
        # Cartan's Magic Formula: L_X = i_X d + d i_X
        term1 = self.d().i(X)
        if self.degree > 0:
            term2 = self.i(X).d()
        else:
            # For 0-form f, i_X(f) = 0, so L_X(f) = X(f) which is a 0-form.
            # But the result should be consistent. L_X(f) is a 0-form.
            f = self.components.get((), 0)
            return DifferentialForm(0, {(): X(f)}, self.chart)
            
        return term1 + term2

    def __call__(self, *vector_fields):
        """Evaluates the k-form on k vector fields: omega(X1, ..., Xk)"""
        if len(vector_fields) != self.degree:
            raise ValueError(f"Differential form of degree {self.degree} requires {self.degree} vector fields, got {len(vector_fields)}")
            
        # Interior product with each vector field sequentially
        res = self
        for X in vector_fields:
            if not isinstance(X, VectorField):
                raise TypeError("All arguments must be VectorField objects")
            res = res.i(X)
            
        # The result should be a 0-form, which we return as a scalar
        if isinstance(res, DifferentialForm) and res.degree == 0:
            return res.components.get((), 0)
        return res

    def __repr__(self):
        if self.degree == 0:
            return str(self.components.get((), 0))
            
        terms = []
        for k, v in self.components.items():
            wedge_part = " ^ ".join([f"d{var}" for var in k])
            terms.append(f"({v})*{wedge_part}")
            
        if not terms:
            return "0"
        return " + ".join(terms)

    def _repr_latex_(self):
        if self.degree == 0:
            return "$" + sp.latex(self.components.get((), 0)) + "$"
            
        terms = []
        # Sort keys for deterministic output
        sorted_keys = sorted(self.components.keys(), key=lambda x: [str(v) for v in x])
        for k in sorted_keys:
            v = self.components[k]
            v_latex = sp.latex(v)
            wedge_part = " \\wedge ".join([f"d {sp.latex(var)}" for var in k])
            terms.append(rf"\left( {v_latex} \right) {wedge_part}")
            
        if not terms:
            return "$0$"
        return "$" + " + ".join(terms) + "$"




class ExteriorDifferentialSystem:
    def __init__(self, generators: List['DifferentialForm'], chart: Optional['Chart'] = None):
        """
        Initializes an Exterior Differential System (EDS).
        Automatically constructs the differential ideal generated by the provided forms.
        
        Args:
            generators: List of DifferentialForm objects.
            chart: Associated coordinate chart.
        """
        self.base_generators = list(generators)
        self.chart = chart or (self.base_generators[0].chart if self.base_generators else None)
        
        # Construct the differential ideal: generated algebraically by {omega_i, d_omega_i}
        closed_generators = []
        seen = set()
        for omega in self.base_generators:
            s_omega = str(omega)
            if s_omega != "0" and s_omega not in seen:
                closed_generators.append(omega)
                seen.add(s_omega)
            
            d_omega = omega.d()
            s_d_omega = str(d_omega)
            if s_d_omega != "0" and s_d_omega not in seen:
                closed_generators.append(d_omega)
                seen.add(s_d_omega)
        self.generators = closed_generators

    def is_in_ideal(self, omega):
        """
        Checks if a k-form 'omega' belongs to the algebraic ideal generated 
        by the system's generators.
        
        For algebraic ideals generated by 1-forms, this is equivalent to 
        checking if omega restricted to the kernel of the 1-forms is zero.
        """
        if not isinstance(omega, DifferentialForm):
            return False
            
        if not self.generators:
            return str(omega) == "0"

        return self.is_in_algebraic_ideal(omega, self.generators)

    def is_in_algebraic_ideal(self, omega, generators):
        """
        Checks if a k-form 'omega' belongs to the algebraic ideal generated 
        by the provided 'generators'.
        """
        if not isinstance(omega, DifferentialForm):
            return False
            
        if not generators:
            return str(omega) == "0"

        # 1. Degree check: forms of degree 0 (functions) must be 0
        if omega.degree == 0:
            return sp.simplify(omega.components.get((), 0)) == 0

        # 2. Check if it is in the C^inf span of same-degree generators
        if self.is_in_span(omega, generators):
            return True

        # 3. For higher degree forms, check if it belongs to the ideal generated by 1-forms
        one_forms = [g for g in generators if g.degree == 1]
        if one_forms and omega.degree > 1:
            # Kernel-based check: omega is in the ideal generated by one_forms 
            # if it vanishes on their common kernel.
            coords = self.chart.coords
            matrix_rows = [[g.components.get((var,), 0) for var in coords] for g in one_forms]
            M = sp.Matrix(matrix_rows)
            null_space = M.nullspace()
            
            basis = []
            for vec in null_space:
                components = {coords[i]: vec[i] for i in range(len(coords)) if vec[i] != 0}
                basis.append(VectorField(components, chart=self.chart))
            
            if not basis:
                return True # 1-forms span T*M, any higher form is in the ideal
                
            from itertools import combinations
            for comb in combinations(basis, omega.degree):
                val = omega(*comb)
                if sp.simplify(val) != 0:
                    return False
            return True

        return False

    def is_in_span(self, omega, forms):
        """
        Checks if omega is in the C^inf-span of the provided 'forms' of the same degree.
        """
        if not isinstance(omega, DifferentialForm):
            return False
            
        same_degree_forms = [g for g in forms if g.degree == omega.degree]
        if not same_degree_forms:
            return str(omega) == "0"

        # Coordinate-wise comparison
        all_components = set(omega.components.keys())
        for g in same_degree_forms:
            all_components.update(g.components.keys())
        all_components = sorted(list(all_components), key=lambda x: str(x))

        M_rows = []
        w_col = []
        for comp in all_components:
            M_rows.append([g.components.get(comp, 0) for g in same_degree_forms])
            w_col.append(omega.components.get(comp, 0))

        M = sp.Matrix(M_rows)
        W = sp.Matrix(w_col)
        
        try:
            M_aug = M.row_join(W)
            return M.rank() == M_aug.rank()
        except Exception:
            # Fallback for complex symbolic systems
            c = sp.symbols(f'c1:{len(same_degree_forms)+1}')
            sol = sp.linsolve((M, W), c)
            return bool(sol)

    def check_symmetry(self, X: 'VectorField') -> bool:
        """Checks if vector field X is a symmetry of the EDS: L_X(I) subset I."""
        for omega in self.generators:
            lie_deriv = omega.lie_derivative(X)
            if not self.is_in_ideal(lie_deriv):
                return False
        return True

    def reduce_ideal(self, X: 'VectorField') -> 'ExteriorDifferentialSystem':
        """Computes the sub-ideal I^X = { omega in I : i_X omega in I }."""
        if not isinstance(X, VectorField):
            raise TypeError("reduce_ideal requires a VectorField")
            
        one_forms = [g for g in self.generators if g.degree == 1]
        if not one_forms:
            return ExteriorDifferentialSystem([], chart=self.chart)
            
        # Compute i_X theta_i for each 1-form theta_i
        ix_theta = []
        for omega in one_forms:
            res = omega.i(X)
            # res is a 0-form (DifferentialForm of degree 0)
            val = res.components.get((), 0)
            ix_theta.append(val)
        
        # Solve sum a_i * ix_theta[i] = 0
        # We use SymPy's nullspace on the row vector of coefficients
        M = sp.Matrix([ix_theta])
        ns = M.nullspace()
        
        sub_generators = []
        for vec in ns:
            # New generator: sum vec[i] * one_forms[i]
            new_form = one_forms[0] * vec[0]
            for i in range(1, len(one_forms)):
                new_form = new_form + (one_forms[i] * vec[i])
            sub_generators.append(new_form)
            
        return ExteriorDifferentialSystem(sub_generators, chart=self.chart)

    def check_cinf_symmetry(self, X: 'VectorField') -> Tuple[bool, 'ExteriorDifferentialSystem']:
        """
        Checks if X is a cinf-symmetry of the system (d(I^X) subset I^X).
        Returns (is_cinf, sub_ideal).
        """
        sub_ideal = self.reduce_ideal(X)
        if not sub_ideal.generators:
            return False, sub_ideal
            
        # Basic forms (algebraic generators of I^X)
        basic_forms = sub_ideal.base_generators
        
        for alpha in basic_forms:
            if not self.is_in_algebraic_ideal(alpha.d(), basic_forms):
                return False, sub_ideal
        return True, sub_ideal

    def reduce_by_flow(self, X):
        """
        Reduces the EDS to the quotient manifold N = M/<X>.
        Returns (reduced_eds, connection_forms, invariants).
        
        This method identifies the basic sub-ideal, finds invariants of X, 
        and projects the basic forms to the quotient manifold.
        """
        is_cinf, sub_ideal = self.check_cinf_symmetry(X)
        if not is_cinf:
            raise ValueError("Vector field X is not a cinf-symmetry; reduction not possible.")
            
        # 1. Find invariants
        invariants = X.get_invariants()
        if not invariants:
            # If no invariants found, we might be in 1D or X=0
            raise ValueError("Could not find invariants for the vector field flow.")
            
        # 2. Create quotient chart
        # Try to use meaningful names if invariants are simple symbols
        new_names = []
        for i, inv in enumerate(invariants):
            if isinstance(inv, sp.Symbol):
                new_names.append(str(inv))
            else:
                new_names.append(f"y{i+1}")
        
        N = Chart(new_names)
        
        # 3. Project forms
        # We represent basic forms sum b_i dx_i as sum c_j d(inv_j)
        reduced_generators = []
        
        # Jacobians of invariants: J_ji = d(inv_j)/d(x_i)
        jac_invariants = []
        for inv in invariants:
            row = [sp.diff(inv, v) for v in self.chart.coords]
            jac_invariants.append(row)
        
        A_mat = sp.Matrix(jac_invariants).T
        
        for alpha in sub_ideal.generators:
            if alpha.degree == 1:
                b_vec = sp.Matrix([alpha.components.get((v,), 0) for v in self.chart.coords])
                
                # Solve A * c = b
                sol = sp.linsolve((A_mat, b_vec))
                if sol:
                    c_vals = list(list(sol)[0])
                    new_comp = {}
                    for j, c in enumerate(c_vals):
                        if c != 0:
                            # Attempt to express coefficient in terms of invariants
                            # For the basic forms of a cinf-symmetry, coefficients 
                            # should be functions of invariants.
                            # substitution heuristic:
                            c_reduced = c
                            # (In a more robust system, we would use a full algebraic 
                            # solver to rewrite c in terms of invariants)
                            new_comp[(N.coords[j],)] = c_reduced
                    reduced_generators.append(DifferentialForm(1, new_comp, N))
            else:
                # For higher degree forms, we could use a similar logic with wedge products
                pass
                
        # 4. Connection forms
        connection_forms = []
        # We want forms that complete the basis of I
        for g in self.generators:
            if g.degree == 1 and not sub_ideal.is_in_ideal(g):
                connection_forms.append(g)
                
        return ExteriorDifferentialSystem(reduced_generators, chart=N), connection_forms, invariants

    def get_pfaffian_part(self) -> 'Distribution':
        """Computes the distribution annihilated by the 1-forms in the ideal (I^1)."""
        one_forms = [g for g in self.generators if g.degree == 1]
        if not one_forms:
            # If no 1-forms, the distribution is the entire tangent space?
            # Or depends on the chart.
            if self.chart:
                return Distribution([VectorField({v: 1}, chart=self.chart) for v in self.chart.coords])
            return Distribution([])
        
        if self.chart is None:
            raise ValueError("Computing the distribution requires a chart link.")

        coords = self.chart.coords
        matrix_rows = []
        for omega in one_forms:
            row = [omega.components.get((var,), 0) for var in coords]
            matrix_rows.append(row)
            
        M = sp.Matrix(matrix_rows)
        null_space = M.nullspace()
        
        vector_fields = []
        for vec in null_space:
            components = {coords[i]: vec[i] for i in range(len(coords)) if vec[i] != 0}
            vector_fields.append(VectorField(components, chart=self.chart))
            
        return Distribution(vector_fields)

    def get_cauchy_characteristics(self) -> 'Distribution':
        """Computes the Cauchy characteristic distribution: {X | i_X I subset I}."""
        dist_i1 = self.get_pfaffian_part()
        basis = dist_i1.vector_fields
        if not basis:
            return dist_i1
            
        two_forms = [g for g in self.generators if g.degree == 2]
        n_basis = len(basis)
        if not two_forms:
            return dist_i1

        # We look for X = sum c_i Z_i such that d theta(X, Z_j) = 0 for all j
        all_equations = []
        c_symbols = sp.symbols(f'c1:{n_basis+1}')
        
        for omega in two_forms:
            for j in range(n_basis):
                eq = 0
                for i in range(n_basis):
                    # omega(basis[i], basis[j])
                    val = omega(basis[i], basis[j])
                    eq += c_symbols[i] * val
                all_equations.append(eq)
        
        # Convert equations to a matrix
        if not all_equations:
            return dist_i1
            
        M_eq = sp.Matrix([[sp.diff(eq, c) for c in c_symbols] for eq in all_equations])
        ns = M_eq.nullspace()
        
        cauchy_vfs = []
        for vec in ns:
            # Construct VF: sum vec[i] * basis[i]
            vf = basis[0] * vec[0]
            for i in range(1, n_basis):
                vf = vf + (basis[i] * vec[i])
            cauchy_vfs.append(vf)
            
        return Distribution(cauchy_vfs)

    def is_integrable(self):
        """
        Checks if the EDS is completely integrable (in the sense of a Pfaffian system).
        Returns True if the 1-form part is involutive.
        """
        dist = self.get_pfaffian_part()
        return dist.is_involutive()

    def __repr__(self):
        if not self.generators:
            return "Empty EDS"
        return "ExteriorDifferentialSystem([\n  " + ",\n  ".join([str(f) for f in self.generators]) + "\n])"

    def _repr_latex_(self):
        if not self.generators:
            return "$\\mathcal{I} = \\langle 0 \\rangle$"
        gens_latex = ", ".join([g._repr_latex_().strip("$") for g in self.generators])
        return f"$\\mathcal{{I}} = \\langle {gens_latex} \\rangle$"


class PfaffianSystem(ExteriorDifferentialSystem):
    def __init__(self, forms: List['DifferentialForm'], chart: Optional['Chart'] = None):
        """
        Initializes a Pfaffian system from a list of 1-forms.
        """
        for omega in forms:
            if not isinstance(omega, DifferentialForm) or omega.degree != 1:
                raise ValueError("Pfaffian system must be composed of 1-forms")
        super().__init__(forms, chart)
        # Store the 1-forms for convenience
        self.forms = [f for f in self.base_generators if f.degree == 1]

    def get_distribution(self) -> 'Distribution':
        """For a Pfaffian system, returns the distribution annihilated by its defining 1-forms."""
        return self.get_pfaffian_part()

    def __repr__(self):
        if not self.forms:
            return "Empty Pfaffian System"
        return "PfaffianSystem([\n  " + ",\n  ".join([str(f) for f in self.forms]) + "\n])"

    def _repr_latex_(self):
        if not self.forms:
            return "$\\mathcal{I} = \\langle 0 \\rangle$"
        gens_latex = ", ".join([g._repr_latex_().strip("$") for g in self.forms])
        return f"$\\mathcal{{I}} = \\langle {gens_latex} \\rangle$"



class Distribution:
    def __init__(self, vector_fields):
        """
        Initializes a distribution from a list of VectorFields.
        """
        self.vector_fields = list(vector_fields)

    def __repr__(self):
        if not self.vector_fields:
            return "Empty Distribution"
        fields_str = ", ".join([str(X) for X in self.vector_fields])
        return f"Distribution(span{{ {fields_str} }})"

    def _repr_latex_(self):
        if not self.vector_fields:
            return r"$\mathcal{D} = \text{span}\{0\}$"
        fields_latex = ", ".join([X._repr_latex_().strip("$") for X in self.vector_fields])
        return r"$\mathcal{D} = \text{span}\left\{ " + fields_latex + r" \right\}$"
        
    def is_in_span(self, w):
        """
        Checks if vector field w is in the span of this distribution
        (with coefficients being functions).
        """
        if not self.vector_fields:
            # If the distribution is empty, w must be exactly 0
            return all(sp.simplify(coeff) == 0 for coeff in w.components.values())

        all_vars = set(w.components.keys())
        for Z in self.vector_fields:
            all_vars.update(Z.components.keys())
        all_vars = list(all_vars)

        M_rows = []
        w_col = []
        for var in all_vars:
            M_rows.append([Z.components.get(var, 0) for Z in self.vector_fields])
            w_col.append(w.components.get(var, 0))
            
        M = sp.Matrix(M_rows)
        W = sp.Matrix(w_col)
        
        # We need to know if W is in the column space of M.
        # Check if there are symbolic functions c_i such that M * c = W
        c = sp.symbols(f'c1:{len(self.vector_fields)+1}')
        try:
            sol = sp.linsolve((M, W), c)
            if sol:
                return True
            return False
        except Exception:
            # Fallback to checking ranks of augmented matrix over the fraction field
            M_aug = M.row_join(W)
            return M.rank() == M_aug.rank()

    def is_involutive(self):
        """
        Returns True if the distribution is involutive.
        That is, [Z_i, Z_j] is in the span of the distribution for all pairs i, j.
        """
        for i in range(len(self.vector_fields)):
            for j in range(i + 1, len(self.vector_fields)):
                bracket = LieBracket(self.vector_fields[i], self.vector_fields[j])
                if not self.is_in_span(bracket):
                    return False
        return True

    def check_symmetry(self, X: 'VectorField') -> bool:
        """Checks if the vector field X is a symmetry of the distribution: [X, D] subset D."""
        for Z in self.vector_fields:
            bracket = LieBracket(X, Z)
            if not self.is_in_span(bracket):
                return False
        return True

    def get_pfaffian_system(self, chart: Optional['Chart'] = None) -> 'PfaffianSystem':
        """Computes the dual Pfaffian system annihilated by the distribution."""
        if not self.vector_fields:
            return PfaffianSystem([])
            
        actual_chart = chart
        if actual_chart is None:
            # Try to infer chart variables from the distribution
            all_vars = set()
            for X in self.vector_fields:
                all_vars.update(X.components.keys())
            if not all_vars:
                return PfaffianSystem([])
            actual_chart = Chart(list(all_vars))

        coords = actual_chart.coords
        n = len(coords)
        
        matrix_rows = []
        for X in self.vector_fields:
            row = []
            for var in coords:
                row.append(X.components.get(var, 0))
            matrix_rows.append(row)
            
        M = sp.Matrix(matrix_rows)
        # We need omega such that M * omega_coeffs = 0
        # This is the nullspace of M (acting on column vectors of coefficients)
        null_space = M.nullspace()
        
        forms = []
        for vec in null_space:
            components = {(coords[i],): vec[i] for i in range(n) if vec[i] != 0}
            forms.append(DifferentialForm(1, components, actual_chart))
            
        return PfaffianSystem(forms, actual_chart)

    def check_cinf_symmetry(self, X: 'VectorField') -> bool:
        """Checks if the vector field X is a C^inf-symmetry of the distribution: [X, D] subset D + span{X}."""
        # We create an extended distribution D' = D + span{X}
        extended_fields = self.vector_fields + [X]
        extended_dist = Distribution(extended_fields)
        
        for Y in self.vector_fields:
            bracket = LieBracket(X, Y)
            if not extended_dist.is_in_span(bracket):
                return False
        return True

    def _are_independent(self, vfs):
        """Helper to check if a list of vector fields is linearly independent."""
        if not vfs: return True
        all_vars = set()
        for v in vfs:
            all_vars.update(v.components.keys())
        all_vars = sorted(list(all_vars), key=lambda x: str(x))
        
        M_rows = []
        for var in all_vars:
            M_rows.append([v.components.get(var, 0) for v in vfs])
            
        M = sp.Matrix(M_rows)
        return M.rank() == len(vfs)

    def get_cinf_determining_equations(self, X: 'VectorField', chart: Optional['Chart'] = None) -> List[sp.Basic]:
        """Derives determining equations for X to be a C^inf-symmetry of this distribution."""
        if not isinstance(X, VectorField):
            raise TypeError("X must be a VectorField object")

        actual_chart = chart
        if actual_chart is None:
            # Try to infer chart from the distribution or X
            all_vars = set(X.components.keys())
            for Z in self.vector_fields:
                all_vars.update(Z.components.keys())
            if not all_vars:
                return []
            actual_chart = Chart(list(all_vars))

        # Get the dual Pfaffian system to this distribution
        pfaff = self.get_pfaffian_system(actual_chart)
        omegas = pfaff.forms
        
        if not omegas:
            # Distribution is the whole space or empty
            return []

        system = []
        
        # For each generator Z of the distribution
        for Z in self.vector_fields:
            bracket = LieBracket(X, Z)
            
            # Condition: [X, Z] is in span(Distribution, X)
            # This is equivalent to: omega_j([X, Z]) * omega_k(X) - omega_k([X, Z]) * omega_j(X) = 0
            # for all pairs of annihilating 1-forms omega_j, omega_k.
            
            # Evaluations
            vals = [omega(bracket) for omega in omegas]
            x_vals = [omega(X) for omega in omegas]
            
            for j in range(len(vals)):
                for k in range(j + 1, len(vals)):
                    eq = vals[j] * x_vals[k] - vals[k] * x_vals[j]
                    system.append(sp.simplify(eq))
                    
        return [eq for eq in system if eq != 0]

    def check_structure(self, X_list, chart=None):
        """
        Checks if the ordered collection of vector fields X_list forms a 
        solvable structure, a C^inf-structure, or neither, for this distribution.
        
        Args:
            X_list (list): Ordered collection of VectorField objects.
            chart (Chart, optional): The coordinate chart to determine the space dimension.

        Returns:
            int: 
                1 if it's a solvable structure.
                2 if it's a C^inf-structure.
                0 if vector fields are not independent.
                -1 if not enough vectors to span the space.
                -2 if the base distribution is not involutive.
                -3 if no relationship (failed symmetry/involutivity).
        """
        Z = self.vector_fields
        X = list(X_list)
        S = Z + X
        
        # 1. Independent check
        if not self._are_independent(S):
            return 0
            
        # 2. Dimension check
        if chart:
            dim = len(chart.coords)
        else:
            all_vars = set()
            for v in S:
                all_vars.update(v.components.keys())
            dim = len(all_vars)
            
        if len(S) < dim:
            return -1

            
        # 3. Base distribution involutivity
        if not self.is_involutive():
            return -2
            
        # 4. Successive check
        is_solvable = True
        is_cinf = True
        
        for i in range(len(Z), len(S)):
            # Distribution D_{i-1} = span(S[0...i-1])
            D_prev = Distribution(S[:i])
            # Distribution D_i = span(S[0...i])
            D_curr = Distribution(S[:i+1])
            
            for j in range(i):
                bracket = LieBracket(S[i], S[j])
                
                # C^inf symmetry check: bracket in span(S[0...i])
                if not D_curr.is_in_span(bracket):
                    is_cinf = False
                    is_solvable = False
                    break 
                
                # Solvable (standard) symmetry check: bracket in span(S[0...i-1])
                if not D_prev.is_in_span(bracket):
                    is_solvable = False
            
            if not is_cinf:
                break
                
        if is_solvable: 
            return 1
        if is_cinf: 
            return 2
        return -3

    def get_adapted_pfaffian_basis(self, X_list, chart=None):
        r"""
        Given a C^inf-structure or solvable structure X_list for this distribution,
        constructs a basis (omega_1, ..., omega_k) for the dual Pfaffian system
        such that omega_i(X_j) = delta_ij and omega_i(Z) = 0 for all Z in the distribution.
        
        This uses the interior product formula:
        omega_i = X_{m-r} \contract ... \widehat{X_i} ... \contract X_1 \contract Y_r \contract ... \contract Y_1 \contract Omega
        where Omega is the volume form and Y_j are the generators of the distribution.
        
        Args:
            X_list (list): An ordered collection of VectorField objects forming the structure.
            chart (Chart, optional): The coordinate chart.
            
        Returns:
            list: A list of DifferentialForm objects (1-forms) representing the adapted basis.
        """
        Z = self.vector_fields
        X = list(X_list)
        S = Z + X
        
        # 1. Chart and dimension check
        actual_chart = chart
        if actual_chart is None:
            all_vars = set()
            for v in S:
                all_vars.update(v.components.keys())
            if not all_vars:
                return []
            
            # Sort variables to ensure consistent orientation
            sorted_vars = sorted(list(all_vars), key=lambda x: str(x))
            actual_chart = Chart(sorted_vars)
        else:
            sorted_vars = list(actual_chart.coords)
            
        m = len(sorted_vars)
        
        if len(S) != m:
            # Fallback to linear solver if they don't exactly span the tangent space
            return self._get_adapted_pfaffian_basis_linsolve(X_list, actual_chart)
            
        if not self._are_independent(S):
            raise ValueError("The vector fields in the distribution and the structure are not linearly independent.")
            
        # 2. Volume form Omega = dx_1 ^ ... ^ dx_m
        Omega = DifferentialForm(m, {tuple(sorted_vars): 1}, actual_chart)
        
        # 3. Apply formula: Omega.i(Y1).i(Y2)...i(Yr).i(X1)... (skipping Xi)
        res_Y = Omega
        for y_field in Z:
            res_Y = res_Y.i(y_field)
            
        basis = []
        for i in range(len(X)):
            w_i = res_Y
            # Contract with all X_j except X_i
            for j in range(len(X)):
                if i == j:
                    continue
                w_i = w_i.i(X[j])
                
            # Now w_i is a 1-form. We normalize it such that w_i(X_i) = 1
            eval_Xi = w_i(X[i])
            if sp.simplify(eval_Xi) == 0:
                raise ValueError(f"Normalization failed for omega_{i+1}. Vector fields are likely dependent.")
                
            w_i_norm = w_i * (1 / eval_Xi)
            basis.append(w_i_norm)
            
        return basis

    def _get_adapted_pfaffian_basis_linsolve(self, X_list, chart):
        """Fallback method using linear solver when r + k != m"""
        coords = chart.coords
        n = len(coords)
        
        M_rows = []
        for Z in self.vector_fields:
            M_rows.append([Z.components.get(var, 0) for var in coords])
        for X in X_list:
            M_rows.append([X.components.get(var, 0) for var in coords])
            
        M = sp.Matrix(M_rows)
        k = len(X_list)
        r = len(self.vector_fields)
        
        if M.rank() < r + k:
            raise ValueError("The vector fields are not linearly independent.")
            
        basis = []
        for i in range(k):
            B = sp.zeros(r + k, 1)
            B[r + i, 0] = 1
            
            C_syms = sp.symbols(f'c1:{n+1}')
            sol = sp.linsolve((M, B), C_syms)
            
            if not sol:
                raise ValueError(f"Could not find adapted 1-form for X_{i+1}.")
                
            sol_tuple = list(sol)[0]
            
            free_symbols = set()
            for expr in sol_tuple:
                if hasattr(expr, 'free_symbols'):
                    free_symbols.update(expr.free_symbols)
            free_symbols = free_symbols.intersection(set(C_syms))
            
            subs_dict = {sym: 0 for sym in free_symbols}
            
            components = {}
            for j, var in enumerate(coords):
                val = sp.simplify(sol_tuple[j].subs(subs_dict))
                if val != 0:
                    components[(var,)] = val
                    
            basis.append(DifferentialForm(1, components, chart))
            
        return basis

class Chart:
    def __init__(self, names):
        """
        Initializes a manifold chart with a set of coordinate variables.
        
        Args:
            names: A list of strings or sympy Symbols.
        """
        self.vars = {}
        for name in names:
            if isinstance(name, str):
                s = sp.Symbol(name)
            else:
                s = name
            self.vars[str(s)] = s
            
    def __getitem__(self, name):
        return self.vars[name]
    
    def __getattr__(self, name: str) -> sp.Symbol:
        if name in self.vars:
            return self.vars[name]
        raise AttributeError(f"Chart has no coordinate '{name}'")
        
    @property
    def coords(self) -> Tuple[sp.Symbol, ...]:
        """Returns the coordinate symbols as a tuple for easy unpacking."""
        return tuple(self.vars.values())

    def inject(self, namespace: Dict[str, Any]):
        """Injects the coordinate symbols into the given namespace (e.g., globals())."""
        namespace.update(self.vars)

    def __repr__(self):
        return f"Chart({list(self.vars.values())})"

    def diff_form(self, degree: int, components: Dict[Tuple[sp.Symbol, ...], Any]) -> 'DifferentialForm':
        """Creates a differential form associated with this chart."""
        return DifferentialForm(degree, components, chart=self)
    
    def d(self, expr: Any) -> 'DifferentialForm':
        """Computes the exterior derivative of a 0-form (function)."""
        expr = sp.sympify(expr)
        components = {}
        for var in self.coords:
            df_dvar = sp.diff(expr, var)
            if df_dvar != 0:
                components[(var,)] = df_dvar
        return DifferentialForm(1, components, chart=self)

    def map_to(self, target_chart, expressions):
        """Creates a transformation from this chart to another."""
        return Transformation(self, target_chart, expressions)

    def scalar_field(self, expr: Any) -> 'ScalarField':
        """Creates a ScalarField linked to this chart."""
        return ScalarField(expr, chart=self)

    def vector_field(self, components: Dict[sp.Symbol, Any]) -> 'VectorField':
        """Creates a VectorField linked to this chart."""
        return VectorField(components, chart=self)


class Transformation:
    def __init__(self, source_chart, target_chart, expressions):
        """
        Defines a transformation (map) between two charts.
        
        Args:
            source_chart (Chart): The source manifold M.
            target_chart (Chart): The target manifold N.
            expressions (dict): Mapping from target coordinate symbols to 
                                expressions in source coordinate symbols.
                                Example: {u: x**2 + y**2, v: x/y}
        """
        self.source = source_chart
        self.target = target_chart
        # Ensure keys and values are sympified
        self.expressions = {sp.sympify(k): sp.sympify(v) for k, v in expressions.items()}
        
    def jacobian(self) -> sp.Matrix:
        """Returns the Jacobian matrix of the transformation: J_ij = d(phi^i)/d(x^j)."""
        src = list(self.source.coords)
        tgt = list(self.expressions.keys())
        return sp.Matrix([
            [sp.diff(self.expressions[t], s) for s in src]
            for t in tgt
        ])
        
    def pullback_function(self, f):
        """Computes the pullback of a function: f_source = f_target ∘ phi."""
        f = sp.sympify(f)
        return sp.simplify(f.subs(self.expressions))
        
    def pullback_form(self, omega: Union['DifferentialForm', Any]) -> Union['DifferentialForm', sp.Basic]:
        """Computes the pullback of a differential form or function: phi* omega."""
        if not isinstance(omega, DifferentialForm):
            # Try to treat as a 0-form (function)
            try:
                return self.pullback_function(omega)
            except Exception:
                raise TypeError("Pullback requires a DifferentialForm or a scalar function.")
            
        new_degree = omega.degree
        if new_degree == 0:
            val = omega.components.get((), 0)
            return DifferentialForm(0, {(): self.pullback_function(val)}, self.source)
            
        res = None
        for k, v in omega.components.items():
            # For a term f * du^i1 ^ ... ^ du^ik
            # Pullback is (f ∘ phi) * d(phi^i1) ^ ... ^ d(phi^ik)
            
            term_coeff = self.pullback_function(v)
            
            # Start with the pulled back coefficient as a 0-form
            term_form = DifferentialForm(0, {(): term_coeff}, self.source)
            
            for var in k:
                # d(phi^var)
                phi_var = self.expressions[var]
                d_phi_var = self.source.d(phi_var)
                term_form = term_form.wedge(d_phi_var)
            
            if res is None:
                res = term_form
            else:
                res = res + term_form
                
        return res if res is not None else DifferentialForm(new_degree, {}, self.source)

    def inverse(self, preferred_vars=None):
        """
        Calculates the inverse of the transformation if it is a diffeomorphism,
        or a section (quasi-inverse) if it is a submersion.
        
        Args:
            preferred_vars (list, optional): List of source variables to solve for 
                                            in case of a submersion.
                                            
        Returns:
            Transformation: A new transformation from target to source.
        """
        source_vars = list(self.source.coords)
        
        # System: target_var_i = expression_i(source_vars)
        # self.expressions maps target_var to expression in source_vars
        system = [t_var - expr for t_var, expr in self.expressions.items()]
        
        # Determine variables to solve for
        if preferred_vars:
            solve_vars = [v for v in preferred_vars if v in source_vars]
        else:
            solve_vars = source_vars
            
        # Attempt to solve
        try:
            # We want to solve the system for solve_vars
            sol = sp.solve(system, solve_vars, dict=True)
            if not sol:
                # Try solving for any variables
                sol = sp.solve(system, source_vars, dict=True)
                if not sol:
                    raise ValueError("Transformation could not be inverted symbolically.")
            
            # Take the first solution
            sol_dict = sol[0]
            
            # Identify variables that are still free in the solution or were not solved
            # We set these to constants (0) to define a specific section.
            all_free = set()
            for val in sol_dict.values():
                if hasattr(val, 'free_symbols'):
                    all_free.update(val.free_symbols)
            
            # Intersection with source vars gives the "moving" variables we didn't solve for
            remaining_source = all_free.intersection(set(source_vars))
            # Union with variables not in the solution at all
            unsolved_source = set(source_vars) - set(sol_dict.keys())
            remaining_source.update(unsolved_source)
            
            # Mapping for the section (slice)
            slice_subs = {v: 0 for v in remaining_source}
            
            # Final mapping: source_var -> expression(target_vars)
            inv_expressions = {}
            for v in source_vars:
                if v in sol_dict:
                    # Substitute any remaining source variables with 0
                    expr = sol_dict[v].subs(slice_subs)
                else:
                    # Variable was not solved, set it to 0 in this section
                    expr = sp.sympify(0)
                inv_expressions[v] = sp.simplify(expr)
                
            return Transformation(self.target, self.source, inv_expressions)
            
        except Exception as e:
            raise ValueError(f"Inverse calculation failed: {str(e)}")

    def pushforward_vector_field(self, X: 'VectorField', auto_invert: bool = True) -> 'VectorField':
        """Computes the pushforward of a vector field: phi_* X."""
        if not isinstance(X, VectorField):
            raise TypeError("X must be a VectorField")
            
        new_components = {}
        for target_var, target_expr in self.expressions.items():
            # (phi_* X)^j = X(phi^j)
            val = sp.simplify(X(target_expr))
            if val != 0:
                new_components[target_var] = val
                
        result_raw = VectorField(new_components)

        if auto_invert:
            try:
                inv_trans = self.inverse()
                # Re-express components in target coordinates
                inv_exprs = inv_trans.expressions
                final_components = {
                    tv: sp.simplify(comp.subs(inv_exprs))
                    for tv, comp in new_components.items()
                }
                return VectorField(final_components, self.target)
            except Exception:
                return result_raw
        
        return result_raw

    def pullback_vector_field(self, Y):
        """
        Computes the pullback of a vector field: phi^* Y.
        Requires phi to be a diffeomorphism.
        This solves d phi (phi^* Y) = Y ∘ phi.
        """
        if not isinstance(Y, VectorField):
            raise TypeError("Y must be a VectorField")
            
        target_vars = self.target.coords
        source_vars = self.source.coords
        
        # Pull back each component of Y (eta^j ∘ phi)
        eta_pulled = {var: self.pullback_function(Y.components.get(var, 0)) for var in target_vars}
        
        # Jacobian matrix J_ij = d(phi^i)/d(x^j)
        jacobian = []
        for t_var in target_vars:
            expr = self.expressions[t_var]
            row = [sp.diff(expr, s_var) for s_var in source_vars]
            jacobian.append(row)
            
        J = sp.Matrix(jacobian)
        V_target = sp.Matrix([eta_pulled[var] for var in target_vars])
        
        # Solve J * V_source = V_target
        V_source_syms = sp.symbols(f'v_src_1:{len(source_vars)+1}')
        sol = sp.linsolve((J, V_target), V_source_syms)
        
        if not sol:
            raise ValueError("Vector field pullback failed. The map might not be a diffeomorphism or is singular.")
            
        sol_vals = list(sol)[0]
        new_components = {source_vars[i]: sol_vals[i] for i in range(len(source_vars)) if sol_vals[i] != 0}
        
        return VectorField(new_components)


class JetSpaceChart(Chart):
    def __init__(self, x_names='x', u_names='u', order=1):
        """
        Initializes a Jet Space chart of a given order for any number of 
        independent and dependent variables.
        
        Args:
            x_names: String or list/tuple of strings for independent variables.
            u_names: String or list/tuple of strings for dependent variables.
            order: The maximum order of derivatives.
        """
        if isinstance(x_names, str):
            x_names = [x_names]
        if isinstance(u_names, str):
            u_names = [u_names]
            
        self.x_names = list(x_names)
        self.u_names = list(u_names)
        self.order = order
        
        # All base variables
        names = self.x_names + self.u_names
        
        # Store metadata for derivatives
        # self.derivatives[u_name][multi_index] = Symbol
        self.derivatives = {u: {} for u in self.u_names}
        
        # Multi-index notation: tuple of length len(x_names)
        n = len(self.x_names)
        
        import itertools
        
        # Generate all multi-indices of order 1 to order
        for k in range(1, order + 1):
            # Combinations with replacement of indices 0 to n-1 of length k
            for combo in itertools.combinations_with_replacement(range(n), k):
                # Count occurrences of each index to form the multi-index
                m_idx = [0] * n
                for idx in combo:
                    m_idx[idx] += 1
                m_idx = tuple(m_idx)
                
                # Naming: u_name + "_" + "".join(x_names[i] for i in combo)
                # If only one x, we could use u1, u2 but plan said unified u_x, u_xx
                subscript = "".join(self.x_names[i] for i in combo)
                
                for u_name in self.u_names:
                    if m_idx not in self.derivatives[u_name]:
                        deriv_name = f"{u_name}_{subscript}"
                        names.append(deriv_name)
                        # We'll set the actual symbol in Chart.__init__
        
        super().__init__(names)
        
        # Populate the derivatives mapping with actual symbols from self.vars
        for k in range(1, order + 1):
            for combo in itertools.combinations_with_replacement(range(n), k):
                m_idx = [0] * n
                for idx in combo:
                    m_idx[idx] += 1
                m_idx = tuple(m_idx)
                subscript = "".join(self.x_names[i] for i in combo)
                for u_name in self.u_names:
                    deriv_name = f"{u_name}_{subscript}"
                    self.derivatives[u_name][m_idx] = self.vars[deriv_name]

    def total_derivative(self, i: int = 0) -> 'VectorField':
        """
        Returns the i-th Total Derivative operator (truncated to the chart's order).
        D_i = d/dx_i + sum_{alpha, J} u^alpha_{J+e_i} d/du^alpha_J
        
        Args:
            i: Index of the independent variable (defaults to 0).
        """
        if i >= len(self.x_names):
            raise IndexError(f"Independent variable index {i} out of range")
            
        xi_name = self.x_names[i]
        xi = self.vars[xi_name]
        
        components = {xi: 1}
        n = len(self.x_names)
        
        # Derivative components
        for u_name in self.u_names:
            u_base = self.vars[u_name]
            
            # d/du component is u_i
            e_i = [0] * n
            e_i[i] = 1
            e_i = tuple(e_i)
            components[u_base] = self.derivatives[u_name][e_i]
            
            # d/du_J component is u_{J+e_i}
            for m_idx, deriv_sym in self.derivatives[u_name].items():
                if sum(m_idx) < self.order:
                    # New multi-index J + e_i
                    next_idx = list(m_idx)
                    next_idx[i] += 1
                    next_idx = tuple(next_idx)
                    
                    if next_idx in self.derivatives[u_name]:
                        components[deriv_sym] = self.derivatives[u_name][next_idx]
                        
        return VectorField(components)

    def total_derivatives(self) -> List['VectorField']:
        """Returns a list of all total derivatives D_1, ..., D_n."""
        return [self.total_derivative(i) for i in range(len(self.x_names))]

    def prolong(self, X: 'VectorField', order: Optional[int] = None) -> 'VectorField':
        """
        Prolongs a vector field X to the jet space using Olver's recursive formula.
        
        Args:
            X: The vector field to prolong.
            order: The order of prolongation. Defaults to chart order.
        """
        if order is None:
            order = self.order
            
        n = len(self.x_names)
        m = len(self.u_names)
        
        # Extract xi^i and phi^alpha
        xis = [X(self.vars[name]) for name in self.x_names]
        phis = {name: X(self.vars[name]) for name in self.u_names}
        
        prolonged_components = {}
        for i, name in enumerate(self.x_names):
            prolonged_components[self.vars[name]] = xis[i]
        for name in self.u_names:
            prolonged_components[self.vars[name]] = phis[name]
            
        Ds = self.total_derivatives()
        
        # phi_coeffs[u_name][multi_index] = expression
        # Initialize with phis (order 0)
        phi_coeffs = {u_name: {tuple([0]*n): phis[u_name]} for u_name in self.u_names}
        
        import itertools
        
        # Compute order by order
        for k in range(1, order + 1):
            for combo in itertools.combinations_with_replacement(range(n), k):
                m_idx = [0] * n
                for idx in combo:
                    m_idx[idx] += 1
                m_idx = tuple(m_idx)
                
                # To compute J+e_i, we find an existing J = m_idx - e_i
                # Pick the first non-zero index in m_idx as i
                i = 0
                for idx in range(n):
                    if m_idx[idx] > 0:
                        i = idx
                        break
                
                prev_idx = list(m_idx)
                prev_idx[i] -= 1
                prev_idx = tuple(prev_idx)
                
                for u_name in self.u_names:
                    phi_J = phi_coeffs[u_name][prev_idx]
                    # phi_{J,i} = D_i(phi_J) - sum_k D_i(xi^k) * u^alpha_{J,k}
                    
                    term1 = Ds[i](phi_J)
                    term2 = 0
                    for k in range(n):
                        # u^alpha_{J,k} is the coordinate for multi-index J+e_k
                        juk_idx = list(prev_idx)
                        juk_idx[k] += 1
                        juk_idx = tuple(juk_idx)
                        
                        # Find the coordinate symbol for juk_idx
                        # J+e_k might be of order k (already computed) or k-1?
                        # No, J is order k-1, so J+e_k is order k.
                        # It must be in self.derivatives.
                        juk_sym = self.derivatives[u_name][juk_idx]
                        term2 += Ds[i](xis[k]) * juk_sym
                        
                    phi_curr = sp.simplify(term1 - term2)
                    phi_coeffs[u_name][m_idx] = phi_curr
                    
                    # Add to prolonged components
                    deriv_sym = self.derivatives[u_name][m_idx]
                    prolonged_components[deriv_sym] = phi_curr
                    
        return VectorField(prolonged_components)

    def lambda_prolong(self, X: 'VectorField', lambd: Any, order: Optional[int] = None) -> 'VectorField':
        """
        Prolongs a vector field X with a lambda-factor.
        
        Args:
            X: The vector field to prolong.
            lambd: The lambda function or list of lambda functions (one for each D_i).
            order: The order of prolongation. Defaults to chart order.
        """
        if order is None:
            order = self.order
            
        n = len(self.x_names)
        if isinstance(lambd, (list, tuple)):
            lambds = [sp.sympify(l) for l in lambd]
        else:
            # If single lambd, apply same to all D_i or just D_0?
            # Standard lambda-symmetry for ODEs has only one D.
            # For PDEs, it's usually a vector of lambdas.
            lambds = [sp.sympify(lambd)] * n
            
        xis = [X(self.vars[name]) for name in self.x_names]
        phis = {name: X(self.vars[name]) for name in self.u_names}
        
        prolonged_components = {}
        for i, name in enumerate(self.x_names):
            prolonged_components[self.vars[name]] = xis[i]
        for name in self.u_names:
            prolonged_components[self.vars[name]] = phis[name]
            
        Ds = self.total_derivatives()
        phi_coeffs = {u_name: {tuple([0]*n): phis[u_name]} for u_name in self.u_names}
        
        import itertools
        for k in range(1, order + 1):
            for combo in itertools.combinations_with_replacement(range(n), k):
                m_idx = [0] * n
                for idx in combo:
                    m_idx[idx] += 1
                m_idx = tuple(m_idx)
                
                i = 0
                for idx in range(n):
                    if m_idx[idx] > 0:
                        i = idx
                        break
                
                prev_idx = list(m_idx)
                prev_idx[i] -= 1
                prev_idx = tuple(prev_idx)
                
                for u_name in self.u_names:
                    phi_J = phi_coeffs[u_name][prev_idx]
                    # Using (D_i + lambd_i) operator
                    term1 = Ds[i](phi_J) + lambds[i] * phi_J
                    term2 = 0
                    for k in range(n):
                        juk_idx = list(prev_idx)
                        juk_idx[k] += 1
                        juk_idx = tuple(juk_idx)
                        juk_sym = self.derivatives[u_name][juk_idx]
                        term2 += (Ds[i](xis[k]) + lambds[i] * xis[k]) * juk_sym
                        
                    phi_curr = sp.simplify(term1 - term2)
                    phi_coeffs[u_name][m_idx] = phi_curr
                    deriv_sym = self.derivatives[u_name][m_idx]
                    prolonged_components[deriv_sym] = phi_curr
                    
        return VectorField(prolonged_components)


def Prolongation(X: 'VectorField', J: 'JetSpaceChart', order: Optional[int] = None) -> 'VectorField':
    """
    Standard prolongation of a vector field pr^{(k)} X.
    
    Args:
        X: The vector field to prolong.
        J: The jet space chart.
        order: The order of prolongation.
    """
    if not isinstance(J, JetSpaceChart):
        raise TypeError("J must be a JetSpaceChart")
    return J.prolong(X, order)


def LambdaProlongation(X: 'VectorField', lambd: Any, J: 'JetSpaceChart', order: Optional[int] = None) -> 'VectorField':
    """
    Lambda-prolongation of a vector field.
    
    Args:
        X: The vector field to prolong.
        lambd: Lambda factor or list of lambda factors.
        J: The jet space chart.
        order: The order of prolongation.
    """
    if not isinstance(J, JetSpaceChart):
        raise TypeError("J must be a JetSpaceChart")
    return J.lambda_prolong(X, lambd, order)
def get_determining_equations(eqs: Union[sp.Basic, List[sp.Basic]], J: 'JetSpaceChart', type: str = 'lie', lambd: Optional[Any] = None) -> List[sp.Basic]:
    """
    Derives the determining equations for Lie or lambda symmetries of an ODE/PDE system.
    
    Args:
        eqs: The system of equations (usually top_derivative - expression).
        J: The jet space chart.
        type: 'lie' or 'lambda'.
        lambd: Lambda factor(s) (required if type='lambda').
    """
    if not isinstance(J, JetSpaceChart):
        raise TypeError("J must be a JetSpaceChart")
    
    if not isinstance(eqs, (list, tuple)):
        eqs = [eqs]
        
    x_vars = [J.vars[name] for name in J.x_names]
    u_vars = [J.vars[name] for name in J.u_names]
    order = J.order
    
    # Define xi^i and phi^alpha as unknown functions of (x, u)
    xi_funcs = []
    for i, name in enumerate(J.x_names):
        xi_funcs.append(sp.Function(f'xi^{name}')(*x_vars, *u_vars))
        
    phi_funcs = []
    for alpha, name in enumerate(J.u_names):
        phi_funcs.append(sp.Function(f'phi^{name}')(*x_vars, *u_vars))
        
    # Create the symmetry generator X = sum xi^i d/dx_i + sum phi^alpha d/du^alpha
    comp = {}
    for i, var in enumerate(x_vars):
        comp[var] = xi_funcs[i]
    for alpha, var in enumerate(u_vars):
        comp[var] = phi_funcs[alpha]
        
    X = VectorField(comp)
    
    # Prolong the vector field
    if type == 'lie':
        prX = J.prolong(X, order)
    elif type == 'lambda':
        if lambd is None:
            raise ValueError("lambd must be provided for lambda-symmetries")
        prX = J.lambda_prolong(X, lambd, order)
    else:
        raise ValueError("type must be 'lie' or 'lambda'")
    
    # The condition is: pr X (Eq) = 0, evaluated on the system
    all_conds = []
    for eq in eqs:
        cond = prX(eq)
        # Substitute the equations themselves to eliminate top-order derivatives
        # This is a bit complex for general systems. 
        # For now, we assume eqs are in the form (top_deriv - expr).
        # We try to extract the top_deriv from the expression if it's a simple subtraction.
        # But a more robust way is to just use .subs() if the user provides 
        # a list of (lhs, rhs) pairs.
        # Let's assume eq is just the expression that should vanish.
        all_conds.append(cond)
        
    # All jet variables (derivatives) to collect coefficients from
    jet_vars = []
    for u_name in J.u_names:
        for deriv_sym in J.derivatives[u_name].values():
            jet_vars.append(deriv_sym)
            
    system = []
    for cond in all_conds:
        # Each condition prX(eq) = 0 must be satisfied independently
        # and on the manifold defined by the system.
        # For now, we collect coefficients of all jet variables.
        try:
            poly_coeffs = sp.Poly(cond, *jet_vars).coeffs()
            system.extend(poly_coeffs)
        except sp.PolynomialError:
            system.append(cond)
            
    return [sp.simplify(eq) for eq in system if eq != 0]


def get_cinf_determining_equations(dist, X, chart=None):
    """
    Standalone function to derive determining equations for a C^inf-symmetry.
    """
    if not isinstance(dist, Distribution):
        raise TypeError("dist must be a Distribution object")
    return dist.get_cinf_determining_equations(X, chart)
