import sympy as sp
import warnings

def simplify(expr):
    """
    Advanced simplification wrapper. 
    Attempts multiple SymPy strategies to find the most compact form.
    """
    if isinstance(expr, (list, tuple)):
        return [simplify(e) for e in expr]
    
    expr = sp.sympify(expr)
    # Try standard simplify
    res = sp.simplify(expr)
    
    # Try to expand and simplify again (often catches missed cancellations)
    res2 = sp.simplify(sp.expand(res))
    
    # Return the one with fewer symbols/operations
    if sp.count_ops(res2) < sp.count_ops(res):
        return res2
    return res

def solve(equations, variables):
    """
    Algebraic solver with 'Maple' heuristics.
    Uses Gröbner bases for non-linear systems to find the simplest relations.
    """
    if not isinstance(equations, (list, tuple)):
        equations = [equations]
    
    # Clean up equations (set to 0)
    eqs = []
    for eq in equations:
        if isinstance(eq, sp.Equality):
            eqs.append(eq.lhs - eq.rhs)
        else:
            eqs.append(sp.sympify(eq))
            
    # Check if linear
    is_linear = True
    for eq in eqs:
        for v in variables:
            if sp.degree(eq, v) > 1:
                is_linear = False
                break
        if not is_linear: break
        
    if is_linear:
        return sp.linsolve(eqs, variables)
    
    # For non-linear: Use Gröbner Basis for reduction
    try:
        gb = sp.groebner(eqs, variables, order='lex')
        return list(gb)
    except Exception:
        # Fallback to standard non-linear solver
        return sp.nonlinsolve(eqs, variables)

def dsolve(equation, function, **kwargs):
    """
    ODE solver wrapper. 
    Future: Will integrate symmetry-based reduction before calling SymPy.
    """
    return sp.dsolve(equation, function, **kwargs)

def pdsolve(system, unknown_functions, independent_vars, param_vars=None):
    """
    Advanced 'Symmetry Cracker' for overdetermined systems of PDEs.
    Implements the 'Splitting' algorithm used in symmetry analysis.
    
    Args:
        system (list): List of PDE expressions (assumed = 0).
        unknown_functions (list): Functions to solve for (e.g., [f(x,u), g(x,u)]).
        independent_vars (list): Variables the functions depend on.
        param_vars (list): Variables the functions DO NOT depend on, but appear 
                          in the equations (used for splitting).
    """
    if not isinstance(system, (list, tuple)):
        system = [system]
        
    # 1. Splitting Logic
    # If param_vars is provided, we collect coefficients of all monomials in param_vars.
    if param_vars:
        split_system = []
        for eq in system:
            # We treat the unknown functions and their derivatives as 'constants' 
            # for the purpose of collecting param_vars.
            try:
                poly = sp.Poly(eq, *param_vars)
                split_system.extend(poly.coeffs())
            except sp.PolynomialError:
                # Fallback to sp.collect if not a simple polynomial
                temp_eq = eq
                for p_var in param_vars:
                    # This is a bit more complex for non-polynomials
                    # We skip for now or use a heuristic
                    pass
                split_system.append(eq)
        system = split_system

    # 2. Basic Differential Reduction (Riquier-Janet inspired)
    # Sort equations by complexity/order
    system = [sp.simplify(eq) for eq in system if eq != 0]
    
    # 3. Iterative Solving of 'pure' derivatives
    # Example: if f_x = 0, we know f = f(y, z, ...)
    # This is where the AI-ready logic thrives.
    
    # For now, we return the simplified, split system.
    # In a full CAS, this would be an iterative loop.
    return [s for s in system if s != 0]

def split_equations(eq, vars_to_split):
    """
    The core 'Maple' algorithm for symmetry search.
    Splits an equation into a system by collecting coefficients of vars_to_split.
    """
    eq = sp.expand(eq)
    # We want to collect coefficients of all combinations of vars_to_split
    # including powers and products.
    try:
        poly = sp.Poly(eq, *vars_to_split)
        return poly.coeffs()
    except Exception:
        # If it's not a polynomial in vars_to_split (e.g., contains sin(x))
        # we try a more manual collection
        coeffs = []
        # Heuristic: find all 'atoms' containing vars_to_split
        # This is complex to do robustly in a single pass.
        return [eq]
