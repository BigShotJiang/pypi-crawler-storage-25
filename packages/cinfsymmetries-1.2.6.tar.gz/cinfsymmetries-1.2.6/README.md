# cinfsymmetries

A Python library for the geometric study of differential equations, bridging the gap from `sympy` to advanced concepts such as Lie symmetries, $\lambda$-symmetries, $C^{\infty}$-structures, and solvable structures. 

Originally inspired by functionality from Maple packages for Differential Geometry.

## Features
- **VectorFields and Distributions:** Define symbolic vector fields over an arbitrary set of variables.
- **Lie Brackets:** Compute Lie Brackets of vector fields analytically.
- **Involutivity:** Check if a distribution is involutive.
- **Symmetries:** Check if a given vector field is a symmetry of a distribution.
- **C^inf-Symmetries:** Specialized check for Generalized symmetries including $\lambda$-symmetries.
- **Prolongations:** Automatically prolong vector fields to higher-order jet spaces (any number of independent and dependent variables).
- **Differential Forms:** Support for $k$-forms, exterior derivative, wedge product, interior product, and unified Lie derivatives ($\mathcal{L}_X$).
- **Symmetry Search:** Automatically derive determining equations for Lie and lambda-symmetries of systems of ODEs or PDEs.
- **Pfaffian Systems:** Compute dual distributions from 1-forms and vice versa.
- **Invariants:** Calculate fundamental invariants of a vector field.

## Documentation
For a detailed guide on how to use the library, including how to create vector fields and check for symmetries, please refer to the [Manual](docs/manual.md).

## Installation

```bash
pip install -e .
```

## Quick Start
```python
import sympy as sp
from cinfsymmetries import VectorField, LieBracket, Distribution

x, y = sp.symbols('x y')

# Define Vector Fields X = d/dx, Y = x*d/dy
X = VectorField({x: 1})
Y = VectorField({y: x})

# Lie Bracket [X, Y] = d/dy
bracket = LieBracket(X, Y)
print(bracket) # Outputs: (1)*d_y

# Create an ODE-like rank 1 distribution (spanned by X + Y)
D = Distribution([X + Y])

# Check if X is a symmetry of D
# [X, X+Y] = [X, Y] = d/dy, which is NOT in the span of (d/dx + x*d/dy), so False.
print(D.check_symmetry(X))

# Get invariants of X
print(X.get_invariants()) # No non-constant invariants in 1D
```
