import sympy as sp
from cinfsymmetries import Chart, VectorField, LieBracket

def example_charts_and_vector_fields():
    """
    Illustrates how to define coordinate charts and vector fields.
    """
    print("\n--- 1. Charts and Vector Fields ---")
    # Define a Chart with arbitrary names (r, theta, phi)
    C = Chart(['r', 'theta', 'phi'])
    print(f"Chart C: {C}")
    
    # Unpack the symbols for cleaner expression building
    r, theta, phi = C.coords
    
    # Define a radial vector field R = d/dr
    R = VectorField({r: 1})
    
    # Define a rotational vector field S = d/dtheta + r^2 d/dphi
    S = VectorField({theta: 1, phi: r**2})
    
    print(f"Radial Vector Field R: {R}")
    print(f"Rotational Vector Field S: {S}")
    
    # Compute the Lie Bracket [R, S]
    bracket = LieBracket(R, S)
    print(f"Lie Bracket [R, S]: {bracket}")

def example_injecting_symbols():
    """
    Demonstrates how to inject chart symbols into the global namespace.
    """
    print("\n--- 2. Injecting Symbols ---")
    C = Chart(['x', 'y', 'z'])
    C.inject(globals())
    
    # Now x, y, z are available as variables
    X = VectorField({x: y, y: -x})
    print(f"Vector Field X (using injected symbols): {X}")

def example_scalar_fields_and_helpers():
    """
    Illustrates ScalarFields and chart-aware object creation.
    """
    print("\n--- 3. ScalarFields and Helpers ---")
    C = Chart(['x', 'y'])
    x, y = C.coords
    
    # Define a ScalarField linked to a chart
    f = C.scalar_field(x**2 + y)
    print(f"ScalarField f = {f}")
    
    # Convenience methods: .d() on the function itself
    df = f.d()
    print(f"df = f.d() = {df}")
    
    # Chart-aware VectorField creation
    X = C.vector_field({x: 1, y: 2*x})
    print(f"VectorField X = {X}")
    
    # Application X(f) returns a ScalarField
    res = X(f)
    print(f"X(f) = {res}")

if __name__ == "__main__":
    print("="*60)
    print("EXAMPLE 001: BASIC DEFINITIONS (CHARTS AND VECTOR FIELDS)")
    print("="*60)
    example_charts_and_vector_fields()
    example_injecting_symbols()
    example_scalar_fields_and_helpers()
