import sympy as sp
from cinfsymmetries import Chart, VectorField, Distribution, PfaffianSystem

def example_differential_forms():
    """
    Illustrates basic operations with differential forms.
    """
    print("\n--- 1. Differential Forms ---")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Define a 1-form omega = y*dx + dz
    omega = C.diff_form(1, {(x,): y, (z,): 1})
    print(f"1-form omega: {omega}")
    
    # Exterior Derivative
    d_omega = omega.d()
    print(f"Exterior Derivative d(omega): {d_omega}")
    
    # Wedge Product
    alpha = C.diff_form(1, {(y,): 1}) # alpha = dy
    beta = omega ^ alpha
    print(f"Wedge Product beta = omega ^ dy: {beta}")
    
    # Interior Product (Contraction)
    X = VectorField({x: 1, y: 1})
    print(f"Contraction i_X(beta) with X={X}: {beta.i(X)}")

def example_distributions_and_pfaffian_systems():
    """
    Shows how to define distributions and Pfaffian systems and their duality.
    """
    print("\n--- 2. Distributions and Pfaffian Systems ---")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # 1. Start with a Pfaffian System: omega = dz - y*dx (Contact system)
    omega = C.diff_form(1, {(z,): 1, (x,): -y})
    P = PfaffianSystem([omega], chart=C)
    print(f"Pfaffian System P:\n{P}")
    
    # 2. Get the dual Distribution D
    D = P.get_distribution()
    print(f"Dual Distribution D spanned by:\n{D.vector_fields}")
    
    # 3. Check Integrability (Frobenius)
    print(f"Is the Pfaffian System integrable? {P.is_integrable()}")
    
    # 3. Verify: omega(X) = 0 for all X in D
    for X in D.vector_fields:
        print(f"  Evaluation omega({X}) = {omega(X)}")
        
    # 4. Inverse: Start with Distribution and get Pfaffian System
    P_dual = D.get_pfaffian_system(chart=C)
    print(f"Dual Pfaffian System P_dual:\n{P_dual}")

def example_adapted_pfaffian_basis():
    """
    Computes an adapted basis for the dual Pfaffian system.
    """
    print("\n--- 3. Adapted Pfaffian Basis ---")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Distribution D = span{ d/dx + y*d/dz }
    Z1 = VectorField({x: 1, z: y})
    D = Distribution([Z1])
    
    # Complementary fields for the basis
    X1 = VectorField({y: 1})
    X2 = VectorField({z: 1})
    
    print(f"Computing adapted basis for D = <{Z1}> using X1={X1}, X2={X2}")
    basis = D.get_adapted_pfaffian_basis([X1, X2], chart=C)
    for i, omega in enumerate(basis):
        print(f"  omega_{i+1} = {omega}")

if __name__ == "__main__":
    print("="*60)
    print("EXAMPLE 002: ADVANCED OBJECTS (FORMS, DISTRIBUTIONS, PFAFFIAN)")
    print("="*60)
    example_differential_forms()
    example_distributions_and_pfaffian_systems()
    example_adapted_pfaffian_basis()
