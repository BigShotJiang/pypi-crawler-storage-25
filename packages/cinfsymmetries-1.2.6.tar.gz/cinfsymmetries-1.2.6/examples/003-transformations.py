import sympy as sp
from cinfsymmetries import Chart, VectorField, DifferentialForm, Transformation

def example_transformations():
    print("\n--- Example: Transformations, Inverses, and Sections ---")
    
    # 1. Define Charts
    C1 = Chart(['x', 'y'])
    x, y = C1.coords
    
    C2 = Chart(['u', 'v'])
    u, v = C2.coords
    
    # Define a transformation phi: C1 -> C2
    # u = x + y, v = x * y
    phi = C1.map_to(C2, {u: x + y, v: x * y})
    
    print(f"Source Chart: {C1}")
    print(f"Target Chart: {C2}")
    print(f"Transformation phi: u = {phi.expressions[u]}, v = {phi.expressions[v]}")
    
    # 2. Inverting a Diffeomorphism
    # Since phi is (mostly) a diffeomorphism, we can calculate its inverse
    print("\nAttempting to invert phi...")
    try:
        phi_inv = phi.inverse()
        print("Inverse transformation phi^-1:")
        for var, expr in phi_inv.expressions.items():
            print(f"  {var} = {expr}")
    except Exception as e:
        print(f"Inverse failed: {e}")
    
    # 3. Pullback of a differential form
    omega = C2.diff_form(1, {(u,): v, (v,): 1}) # omega = v du + dv
    omega_star = phi.pullback_form(omega)
    print(f"\nPullback of 1-form omega = {omega}:")
    print(f"phi^* omega = {omega_star}")
    
    # 4. Pushforward of a vector field (Auto-inverted)
    # The new pushforward automatically uses inverse() for coordinate re-expression
    X = VectorField({x: 1, y: -1}, chart=C1)
    X_push = phi.pushforward_vector_field(X)
    print(f"\nPushforward of vector field X = {X}:")
    print(f"phi_* X = {X_push}")
    
    # 5. Submersions and Sections (The "Manual" workflow)
    print("\n--- Submersions and Sections ---")
    
    M = Chart(['x1', 'x2', 'x3'])
    N = Chart(['y1', 'y2'])
    x1, x2, x3 = M.coords
    y1, y2 = N.coords
    
    # pi: M -> N is a submersion
    pi = M.map_to(N, {y1: x1 + x2, y2: x3})
    print(f"Submersion pi: {pi.expressions}")
    
    # Get a section s: N -> M (quasi-inverse)
    s = pi.inverse(preferred_vars=[x1, x3]) # Ask to solve for x1 and x3 specifically
    print("Section s: N -> M (automatically sets free variable x2=0):")
    for var, expr in s.expressions.items():
        print(f"  {var} = {expr}")
        
    # Project a basic form from M to N
    # alpha = d(x1 + x2) + x3*dx3
    alpha = M.d(x1 + x2) + x3 * M.d(x3)
    print(f"\nBasic form alpha on M: {alpha}")
    
    # The projected form bar_alpha is obtained by pulling back through the section
    bar_alpha = s.pullback_form(alpha)
    print(f"Projected form bar_alpha = s^* alpha on N: {bar_alpha}")
    
    # Verify by pulling back to M
    alpha_recovered = pi.pullback_form(bar_alpha)
    print(f"Verification (pi^* bar_alpha): {alpha_recovered}")

if __name__ == "__main__":
    example_transformations()
