import sympy as sp
from cinfsymmetries import (
    Chart, VectorField, Distribution, PfaffianSystem, 
    JetSpaceChart, Prolongation, LambdaProlongation,
    get_determining_equations, get_cinf_determining_equations
)

def example_ode_symmetries():
    """
    Classical Lie symmetries of an ODE represented as a distribution.
    """
    print("\n--- 1. ODE Symmetries (Distribution Approach) ---")
    # For u'' = 0, we use a distribution on J^1 spanned by the Total Derivative
    J = JetSpaceChart(x_names='x', u_names='u', order=1)
    x, u, u_x = J.coords
    
    # Total Derivative D = d/dx + u_x*d/du
    D_op = J.total_derivative()
    Dist = Distribution([D_op])
    print(f"Distribution D (representing u''=0): {D_op}")
    
    # Check if X = d/du is a symmetry
    X = VectorField({u: 1})
    print(f"Is X = d/du a symmetry? {Dist.check_symmetry(X)}")

def example_prolongation():
    """
    Automated prolongation of point symmetries.
    """
    print("\n--- 2. Automated Prolongation ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    # Point symmetry X = u*d/du (Scaling)
    X = VectorField({u: u})
    print(f"Point symmetry X: {X}")
    
    # Standard Prolongation
    prX = Prolongation(X, J)
    print(f"Prolonged pr X: {prX}")
    
    # Lambda-Prolongation with lambda = 1/x
    prX_lambda = LambdaProlongation(X, lambd=1/x, J=J)
    print(f"Lambda-Prolonged (lambda=1/x) pr_lambda X: {prX_lambda}")

def example_symmetry_search():
    """
    Searching for symmetries by solving determining equations.
    """
    print("\n--- 3. Symmetry Search (Determining Equations) ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    # ODE: u_xx = 0
    ode_expr = u_xx
    print("Deriving Lie symmetry equations for u'' = 0:")
    eqs = get_determining_equations(ode_expr, J)
    for i, eq in enumerate(eqs[:5]):
        print(f"  {i+1}: {eq} = 0")

    # Heat Equation: u_t = u_xx
    print("\nDeriving equations for Heat Equation (u_t - u_xx = 0):")
    J_pde = JetSpaceChart(x_names=['t', 'x'], u_names='u', order=2)
    t, x, u, u_t, u_x, u_tt, u_tx, u_xx = J_pde.coords
    heat_eq = u_t - u_xx
    eqs_heat = get_determining_equations(heat_eq, J_pde)
    print(f"Found {len(eqs_heat)} equations for the heat equation.")

def example_cinf_symmetries():
    """
    C^inf-symmetries and their determining equations.
    """
    print("\n--- 4. C^inf-Symmetries ---")
    # For u' = 0, D = <d/dx>
    x, u = sp.symbols('x u')
    chart = Chart([x, u])
    D = Distribution([VectorField({x: 1})])
    
    # Candidate X = exp(x)*d/du
    X_cinf = VectorField({u: sp.exp(x)})
    print(f"Checking if X = exp(x)*d/du is a C^inf-symmetry of D = <d/dx>:")
    print(f"  Is regular symmetry? {D.check_symmetry(X_cinf)}")
    print(f"  Is C^inf-symmetry? {D.check_cinf_symmetry(X_cinf)}")

    # Search for C^inf symmetries
    print("\nDeriving C^inf determining equations for D = <d/dx>:")
    xi_x = sp.Function('xi_x')(x, u)
    xi_u = sp.Function('xi_u')(x, u)
    X_gen = VectorField({x: xi_x, u: xi_u})
    eqs = get_cinf_determining_equations(D, X_gen, chart)
    print(f"Found {len(eqs)} C^inf determining equations.")

def example_pfaffian_symmetries():
    """
    Symmetries of Pfaffian systems.
    """
    print("\n--- 5. Pfaffian System Symmetries ---")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Contact system: omega = dz - y*dx
    omega = C.diff_form(1, {(z,): 1, (x,): -y})
    P = PfaffianSystem([omega], chart=C)
    
    # Translation in x: X = d/dx
    X = VectorField({x: 1})
    is_sym = P.check_symmetry(X)
    print(f"Is X = d/dx a symmetry of P = <dz - y*dx>? {is_sym}")

def example_invariants():
    """
    Computing invariants of a vector field.
    """
    print("\n--- 6. Invariants of a Vector Field ---")
    x, y, z = sp.symbols('x y z')
    
    # Scaling: X = x d/dx + y d/dy + z d/dz
    X = VectorField({x: x, y: y, z: z})
    inv = X.get_invariants()
    print(f"Vector Field X: {X}")
    print(f"Invariants of X: {inv}")

def example_vessiot_and_structure():
    """
    Verification of Vessiot distribution and C^inf-structure check.
    """
    print("\n--- 7. Vessiot Distribution and C^inf-structure ---")
    J = JetSpaceChart(x_names=['x', 'y'], u_names='u', order=1)
    x, y, u, u_x, u_y = J.coords
    
    # Ax = ∂x + u_x*∂u + 1/2*u_x^2*∂u_x + e^u*∂u_y
    # Ay = ∂y + u_y*∂u + e^u*∂u_x + 1/2*u_y^2*∂u_y
    Ax = VectorField({x: 1, u: u_x, u_x: sp.Rational(1, 2) * u_x**2, u_y: sp.exp(u)})
    Ay = VectorField({y: 1, u: u_y, u_x: sp.exp(u), u_y: sp.Rational(1, 2) * u_y**2})
    
    print(f"Vessiot Distribution generators:\n  Ax = {Ax}\n  Ay = {Ay}")
    print(f"Is [Ax, Ay] == 0? {LieBracket(Ax, Ay)}")
    
    # Vertical fields
    X1 = VectorField({u_y: 1, u_x: -u_y/u_x})
    X2 = VectorField({u_x: 1, u_y: -u_x/2})
    X3 = VectorField({u: 1})
    
    # Verify C^inf-structure [X3, X1, X2, Ax, Ay]
    full_sequence = [X3, X1, X2, Ax, Ay]
    result = Distribution([]).check_structure(full_sequence, chart=J)
    print(f"Structure check result: {result} (2 = C^inf-structure)")

if __name__ == "__main__":
    print("="*60)
    print("EXAMPLE 004: SYMMETRIES, PROLONGATION, AND SEARCH")
    print("="*60)
    example_ode_symmetries()
    example_prolongation()
    example_symmetry_search()
    example_cinf_symmetries()
    example_pfaffian_symmetries()
    example_invariants()
    example_vessiot_and_structure()
