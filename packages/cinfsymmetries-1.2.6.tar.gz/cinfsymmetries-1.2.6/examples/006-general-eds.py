import sympy as sp
from cinfsymmetries import Chart, VectorField, DifferentialForm, ExteriorDifferentialSystem

def example_general_eds():
    print("\n--- Example 006: General Exterior Differential System (EDS) ---")
    
    # 1. Define Chart (M = R^3)
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # 2. Define a Contact Form alpha = dz - y*dx
    alpha = C.diff_form(1, {(z,): 1, (x,): -y})
    
    print(f"Generator 1-form: alpha = {alpha}")
    
    # 3. Create the EDS
    # This automatically adds d(alpha) to the generators to form a differential ideal
    eds = ExteriorDifferentialSystem([alpha], chart=C)
    
    print("\nEDS initialized with alpha (algebraic-differential closure):")
    print(eds)
    
    # 5. Check if a form is in the ideal
    # A generator is obviously in the ideal
    print(f"Is alpha in the ideal? {eds.is_in_ideal(alpha)}")
    
    # d(alpha) should also be in the ideal
    d_alpha = alpha.d()
    print(f"Is d(alpha) = {d_alpha} in the ideal? {eds.is_in_ideal(d_alpha)}")
    
    # A random form should not be
    beta = C.diff_form(1, {(x,): 1})
    print(f"Is beta = {beta} in the ideal? {eds.is_in_ideal(beta)}")
    
    # 6. Check Symmetries
    # X = d/dz is a symmetry of the contact system
    X = VectorField({z: 1}, chart=C)
    print(f"\nChecking symmetry X = {X}:")
    is_sym = eds.check_symmetry(X)
    print(f"  Is X a symmetry? {is_sym}")
    
    # Y = d/dy is NOT a symmetry (it doesn't preserve the contact structure)
    # L_Y alpha = i_Y d_alpha + d i_Y alpha
    # d_alpha = -dx ^ dy
    # i_Y (-dx ^ dy) = dx
    # d i_Y (dz - y*dx) = d(0) = 0
    # L_Y alpha = dx, which is not in the ideal
    Y = VectorField({y: 1}, chart=C)
    print(f"\nChecking symmetry Y = {Y}:")
    is_sym_Y = eds.check_symmetry(Y)
    print(f"  Is Y a symmetry? {is_sym_Y}")
    
    # 7. Distributions Associated with the EDS
    # The Pfaffian part (I^1)
    dist = eds.get_pfaffian_part()
    print(f"\nPfaffian Part Distribution (kernel of 1-forms):")
    print(dist)

    # Integrability
    print(f"Is the EDS integrable? {eds.is_integrable()}")
    
    # Cauchy Characteristics
    cauchy = eds.get_cauchy_characteristics()
    print(f"Cauchy Characteristics: {cauchy}")

def example_laplace_equation():
    print("\n--- Example: Laplace Equation (u_xx + u_yy = 0) ---")
    C = Chart(['x', 'y', 'u', 'p', 'q'])
    x, y, u, p, q = C.coords
    
    # theta = du - p dx - q dy
    theta = C.diff_form(1, {(u,): 1, (x,): -p, (y,): -q})
    # Omega = dp ^ dy - dq ^ dx
    Omega = C.diff_form(2, {(p, y): 1, (q, x): -1})
    
    eds = ExteriorDifferentialSystem([theta, Omega])
    
    # Rotation Symmetry: X = -y d/dx + x d/dy - q d/dp + p d/dq
    X = VectorField({x: -y, y: x, p: -q, q: p}, chart=C)
    print(f"Checking Rotation Symmetry X = {X}")
    print(f"  Is X a symmetry? {eds.check_symmetry(X)}")

def example_wave_equation():
    print("\n--- Example: 1D Wave Equation (u_tt - c^2 u_xx = 0) ---")
    c = sp.Symbol('c', positive=True)
    C = Chart(['x', 't', 'u', 'p', 'q'])
    x, t, u, p, q = C.coords
    
    # theta = du - p dx - q dt
    theta = C.diff_form(1, {(u,): 1, (x,): -p, (t,): -q})
    # Omega = c^2 dp ^ dt - dq ^ dx
    Omega = C.diff_form(2, {(p, t): c**2, (q, x): -1})
    
    eds = ExteriorDifferentialSystem([theta, Omega])
    
    # Scaling Symmetry: X = x d/dx + t d/t - p d/dp - q d/dq
    X = VectorField({x: x, t: t, p: -p, q: -q}, chart=C)
    print(f"Checking Scaling Symmetry X = {X}")
    print(f"  Is X a symmetry? {eds.check_symmetry(X)}")

def example_sine_gordon_equation():
    print("\n--- Example: Sine-Gordon Equation (u_xy = sin(u)) ---")
    C = Chart(['x', 'y', 'u', 'p', 'q'])
    x, y, u, p, q = C.coords
    
    # theta = du - p dx - q dy
    theta = C.diff_form(1, {(u,): 1, (x,): -p, (y,): -q})
    # Omega = dp ^ dx + sin(u) dx ^ dy
    Omega = C.diff_form(2, {(p, x): 1, (x, y): sp.sin(u)})
    
    eds = ExteriorDifferentialSystem([theta, Omega])
    
    # Lorentz boost type scaling: X = x d/dx - y d/dy - p d/dp + q d/dq
    X = VectorField({x: x, y: -y, p: -p, q: q}, chart=C)
    print(f"Checking Lorentz-style Symmetry X = {X}")
    print(f"  Is X a symmetry? {eds.check_symmetry(X)}")

if __name__ == "__main__":
    example_general_eds()
    example_laplace_equation()
    example_wave_equation()
    example_sine_gordon_equation()
