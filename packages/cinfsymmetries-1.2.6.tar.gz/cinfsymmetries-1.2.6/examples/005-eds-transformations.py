import sympy as sp
from cinfsymmetries import Chart, VectorField, Transformation, DifferentialForm, PfaffianSystem

def example_eds_transformation():
    print("\n--- Example 012: EDS Transformation ---")
    
    # 1. Define Source Chart (M = R^4)
    C1 = Chart(['x', 'y', 'z', 'w'])
    x, y, z, w = C1.coords
    
    # 2. Define Target Chart
    C2 = Chart(['u', 'v', 'q', 'p'])
    u, v, q, p = C2.coords
    
    # 3. Define Differential Forms and Vector Field on C1
    # omega1 = y*dx + z*dz + w*dw
    omega1 = C1.diff_form(1, {(x,): y, (z,): z, (w,): w})
    
    # omega2 = dx
    omega2 = C1.diff_form(1, {(x,): 1})
    
    # Omega = y*dy ^ dz + y^2*dy ^ dw
    Omega = C1.diff_form(2, {(y, z): y, (y, w): y**2})
    
    # Vector Field X = d/dy
    X = VectorField({y: 1}, chart=C1)
    
    print("Original Elements on M(x,y,z,w):")
    print(f"  omega1 = {omega1}")
    print(f"  omega2 = {omega2}")
    print(f"  Omega  = {Omega}")
    print(f"  X      = {X}")
    
    # 4. Define the Transformation phi: C1 -> C2
    # u = x + y + z, v = x*z - y*w, q = y/x, p = w - x
    exprs = {
        u: x + y + z,
        v: x*z - y*w,
        q: y/x,
        p: w - x
    }
    phi = C1.map_to(C2, exprs)
    
    print("\nTransformation phi: C1 -> C2:")
    for target_var, expr in exprs.items():
        print(f"  {target_var} = {expr}")
        
    # 5. Compute Pushforward of Vector Field X
    # phi_* X = X(phi^j) d/du^j
    print("\nPushing forward vector field X to C2 (auto-inverting coordinates)...")
    try:
        X_push = phi.pushforward_vector_field(X)
        print(f"  phi_* X = {X_push}")
    except Exception as e:
        print(f"  Error computing pushforward: {e}")
        
    # 6. Compute Elements in New Coordinates for Forms
    print("\nAttempting to invert the transformation to express forms in (u, v, q, p)...")
    
    # Solve the system of equations for x, y, z, w
    equations = [
        sp.Equality(u, x + y + z),
        sp.Equality(v, x*z - y*w),
        sp.Equality(q, y/x),
        sp.Equality(p, w - x)
    ]
    
    try:
        solutions = sp.solve(equations, [x, y, z, w], dict=True)
        
        if not solutions:
            print("Could not find symbolic inverse for the transformation.")
        else:
            # We take the first solution (usually there might be multiple due to quadratics)
            sol = solutions[0]
            print("Found Inverse Transformation branch.")
            
            # Define the inverse map psi: C2 -> C1
            psi = C2.map_to(C1, sol)
            
            # Pullback forms from C1 to C2 using psi
            print("  Transforming omega1...")
            omega1_new = psi.pullback_form(omega1)
            print(f"  omega1_new = {omega1_new}")
            
            print("  Transforming omega2...")
            omega2_new = psi.pullback_form(omega2)
            print(f"  omega2_new = {omega2_new}")
            
            print("  Transforming Omega (this may take a moment)...")
            Omega_new = psi.pullback_form(Omega)
            # We don't print Omega_new if it's too long, but let's try
            print(f"  Omega_new  = {Omega_new}")
            
            # 7. Define the EDS Ideal in new coordinates
            I_pfaff = PfaffianSystem([omega1_new, omega2_new], chart=C2)
            
            print("\nExterior Differential System in New Coordinates:")
            print(f"  I = <omega1_new, omega2_new, Omega_new>")
            print("\nSuccessfully computed all elements in the new coordinate system.")

    except Exception as e:
        print(f"Error during symbolic inversion: {e}")

if __name__ == "__main__":
    example_eds_transformation()
