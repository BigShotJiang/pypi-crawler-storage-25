import sympy as sp
from cinfsymmetries import Chart, VectorField, DifferentialForm, ExteriorDifferentialSystem

# 1. Setup the 4D manifold M = R^4 with coordinates (x, y, u, v)
M = Chart(['x', 'y', 'u', 'v'])
M.inject(globals())
dx, dy, du, dv = M.d('x'), M.d('y'), M.d('u'), M.d('v')

# 2. Define the EDS I
theta1 = du - x*dx - dy
theta2 = dv + x*dx - dy
I = ExteriorDifferentialSystem([theta1, theta2], chart=M)

# 3. Define the Vector Field X = y d/dx
X = VectorField({x: y}, chart=M)

# 4. Manual Reduction Workflow
print("--- Manual Reduction Workflow ---")

# Step A: Find the basic sub-ideal on the original manifold M
sub_I = I.reduce_ideal(X)
print(f"Basic sub-ideal I^X generators: {sub_I.generators}")

# Step B: Find the invariants
invs = X.get_invariants()
print(f"Invariants found: {invs}")

# Step C: Define the Quotient Chart N
# We use new symbols to avoid confusion with original coordinates
N = Chart(['y_inv', 'u_inv', 'v_inv'])
y_inv, u_inv, v_inv = N.coords

# Step D: Define the submersion phi: M -> N using the invariants
phi = M.map_to(N, {y_inv: invs[0], u_inv: invs[1], v_inv: invs[2]})

# Step E: Get the section s: N -> M (the "quasi-inverse")
# This automatically chooses a 'slice' (setting free variables to 0)
s = phi.inverse()
print("\nSection (Quasi-Inverse) expressions from N to M:")
for k, v in s.expressions.items():
    print(f"  {k} = {v}")

# Step F: Project the basic generators to N by pulling them back via the section
# Basic property: bar_alpha = s* alpha
reduced_generators = [s.pullback_form(alpha) for alpha in sub_I.generators]
reduced_I_manual = ExteriorDifferentialSystem(reduced_generators, chart=N)

print("\nReduced EDS on quotient manifold N:")
print(reduced_I_manual)

# 5. Verification: Pull the reduced system back to M to see if we recover the sub-ideal
recovered_sub_I = [phi.pullback_form(g) for g in reduced_I_manual.generators]
print("\nRecovered Sub-ideal on M (Pullback of Reduced EDS):")
for g in recovered_sub_I:
    print(f"  {g}")

# 6. Reconstruction Step: Identifying connection forms
connection_forms = [g for g in I.generators if g.degree == 1 and not sub_I.is_in_ideal(g)]
print("\nConnection Forms to be solved during reconstruction:")
for g in connection_forms:
    print(f"  {g}")
