import sympy as sp
from cinfsymmetries import Chart, VectorField, Transformation

def test_transformations():
    print("\n--- Testing Transformations and Pullbacks ---")
    
    # 1. Setup Charts
    # Source: Cartesian (x, y)
    M = Chart(['x', 'y'])
    x, y = M.coords
    
    # Target: Polar (r, theta)
    N = Chart(['r', 'theta'])
    r, theta = N.coords
    
    # Map phi: M -> N defined by r = sqrt(x^2 + y^2), theta = atan2(y, x)
    phi = M.map_to(N, {
        r: sp.sqrt(x**2 + y**2),
        theta: sp.atan2(y, x)
    })
    
    # 2. Function Pullback
    # f(r, theta) = r^2
    f_target = r**2
    f_pulled = phi.pullback_function(f_target)
    print(f"Function pullback: phi^*({f_target}) = {f_pulled}")
    assert sp.simplify(f_pulled - (x**2 + y**2)) == 0
    
    # 3. Differential Form Pullback
    # omega = dr
    omega_target = N.diff_form(1, {(r,): 1})
    omega_pulled = phi.pullback_form(omega_target)
    print(f"Form pullback: phi^*({omega_target}) = {omega_pulled}")
    # d(sqrt(x^2+y^2)) = (x dx + y dy) / sqrt(x^2+y^2)
    
    # Verify phi*(df) = d(phi*f)
    df_pulled = phi.pullback_form(N.d(r))
    d_f_pulled = M.d(phi.pullback_function(r))
    print(f"phi*(dr) = {df_pulled}")
    print(f"d(phi*r) = {d_f_pulled}")
    # They should be equal
    # Difference should be 0
    diff = df_pulled - d_f_pulled
    print(f"Difference: {diff}")
    assert str(diff) == "0"

    # 4. Vector Field Pushforward
    # X = d/dx
    X = VectorField({x: 1})
    Y_pushed = phi.pushforward_vector_field(X)
    print(f"Pushforward: phi_*({X}) = {Y_pushed}")
    # Components should be d(phi^r)/dx and d(phi^theta)/dx
    
    # 5. Vector Field Pullback
    # Define a simple map where we know the inverse
    # phi: (x, y) -> (u, v) = (x+y, x-y)
    M2 = Chart(['x', 'y'])
    x, y = M2.coords
    N2 = Chart(['u', 'v'])
    u, v = N2.coords
    
    phi2 = M2.map_to(N2, {u: x + y, v: x - y})
    
    # Y = d/du
    Y = VectorField({u: 1})
    X_pulled = phi2.pullback_vector_field(Y)
    print(f"Pullback: phi2^*({Y}) = {X_pulled}")
    # u = x+y, v = x-y => x = (u+v)/2, y = (u-v)/2
    # d/du = d/dx * dx/du + d/dy * dy/du = 1/2 d/dx + 1/2 d/dy
    assert X_pulled.components[x] == sp.Rational(1, 2)
    assert X_pulled.components[y] == sp.Rational(1, 2)

    print("\nAll tests passed!")

if __name__ == "__main__":
    test_transformations()
