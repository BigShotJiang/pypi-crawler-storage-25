import sympy as sp
from cinfsymmetries import Chart, VectorField, ScalarField, DifferentialForm, LieBracket

def test_lie_derivative_unification():
    print("Testing Lie Derivative Unification...")
    
    # Setup
    C = Chart(['x', 'y', 'z', 'w'])
    C.inject(globals())
    
    X = VectorField({x: y, y: -x, z: 1})
    Y = VectorField({x: 1, y: 1})
    f = ScalarField(x**2 + y**2 + z**2, chart=C)
    
    # 1. Scalar Field
    # L_X(f) = X(f)
    L_X_f = f.lie_derivative(X)
    expected_X_f = X(f)
    print(f"ScalarField: L_X(f) = {L_X_f}")
    assert sp.simplify(L_X_f.expr - expected_X_f.expr) == 0
    
    # 2. Vector Field
    # L_X(Y) = [X, Y]
    L_X_Y = X.lie_derivative(Y)
    expected_bracket = LieBracket(X, Y)
    print(f"VectorField: L_X(Y) = {L_X_Y}")
    assert all(sp.simplify(L_X_Y.components.get(v, 0) - expected_bracket.components.get(v, 0)) == 0 for v in C.coords)
    
    # 3. Vector Field acting on others
    assert sp.simplify(X.lie_derivative(f).expr - L_X_f.expr) == 0
    
    # 4. Differential Forms (1-form)
    omega = C.diff_form(1, {(x,): y, (y,): x})
    L_X_omega = omega.lie_derivative(X)
    L_X_omega_alt = X.lie_derivative(omega)
    print(f"1-form: L_X(omega) = {L_X_omega}")
    assert str(L_X_omega) == str(L_X_omega_alt)
    
    # 5. Higher-order forms (3-form in 4D)
    # rho = x * dx ^ dy ^ dz
    rho = C.diff_form(3, {(x, y, z): x})
    L_X_rho = rho.lie_derivative(X)
    print(f"3-form: L_X(rho) = {L_X_rho}")
    
    # Cartan verification for rho
    term1 = rho.d().i(X)
    term2 = rho.i(X).d()
    expected_L_X_rho = term1 + term2
    assert str(L_X_rho) == str(expected_L_X_rho)
    
    print("All tests passed!")

if __name__ == "__main__":
    test_lie_derivative_unification()
