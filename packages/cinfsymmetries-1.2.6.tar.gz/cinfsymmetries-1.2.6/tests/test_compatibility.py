from cinfsymmetries import Chart, DifferentialForm, PfaffianSystem, ExteriorDifferentialSystem
import sympy as sp

def test_pfaffian_eds_compatibility():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    dx, dy, dz = C.d(x), C.d(y), C.d(z)

    # Integrable case: theta = dz
    theta_int = dz
    p_int = PfaffianSystem([theta_int], chart=C)
    eds_int = ExteriorDifferentialSystem([theta_int], chart=C)

    assert p_int.is_integrable() is True
    assert eds_int.is_integrable() is True
    assert len(p_int.get_distribution().vector_fields) == 2
    assert len(eds_int.get_pfaffian_part().vector_fields) == 2

    # Non-integrable case: theta = dz - y*dx
    theta_ni = dz - y*dx
    p_ni = PfaffianSystem([theta_ni], chart=C)
    eds_ni = ExteriorDifferentialSystem([theta_ni], chart=C)

    assert p_ni.is_integrable() is False
    assert eds_ni.is_integrable() is False
    
    # Cauchy characteristics
    # For dz - y*dx, there are no Cauchy characteristics in 3D
    assert len(eds_ni.get_cauchy_characteristics().vector_fields) == 0

def test_ideal_membership():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    dx, dy, dz = C.d(x), C.d(y), C.d(z)

    theta = dz - y*dx
    eds = ExteriorDifferentialSystem([theta], chart=C)

    # 1-form in ideal
    assert eds.is_in_ideal(theta) is True
    assert eds.is_in_ideal(dx) is False

    # 2-form in ideal
    d_theta = theta.d() # dx ^ dy
    assert eds.is_in_ideal(d_theta) is True
    
    # Algebraic ideal membership (dx ^ dz contains theta/y)
    # Actually dz ^ dx = theta ^ dx
    assert eds.is_in_ideal(dz ^ dx) is True
    
    # Not in ideal
    assert eds.is_in_ideal(dy ^ dz) is False

def test_higher_degree_eds():
    # Symplectic-like system
    C = Chart(['p', 'q', 'x', 'y'])
    p, q, x, y = C.coords
    dp, dq, dx, dy = C.d(p), C.d(q), C.d(x), C.d(y)

    omega = (dp ^ dq) + (dx ^ dy)
    eds = ExteriorDifferentialSystem([omega], chart=C)

    # No 1-forms, so pfaffian part is the whole space
    assert len(eds.get_pfaffian_part().vector_fields) == 4
    
    # Cauchy characteristics of a symplectic form are 0
    cc = eds.get_cauchy_characteristics()
    print(f"Symplectic Cauchy characteristics: {cc.vector_fields}")
    assert len(cc.vector_fields) == 0

if __name__ == "__main__":
    test_pfaffian_eds_compatibility()
    test_ideal_membership()
    test_higher_degree_eds()
    print("All compatibility tests passed!")
