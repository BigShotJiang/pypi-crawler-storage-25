import sympy as sp
from cinfsymmetries import Chart, VectorField, ScalarField, DifferentialForm

def test_consistency():
    print("\n--- Testing Chart-Aware Consistency ---")
    
    C1 = Chart(['x', 'y'])
    x, y = C1.coords
    
    # 1. ScalarField Creation
    f = C1.scalar_field(x**2 + y)
    print(f"ScalarField f: {f} (Chart: {f.chart})")
    assert f.chart == C1
    
    # 2. Derivative .d()
    df = f.d()
    print(f"df = f.d() = {df}")
    assert df.chart == C1
    assert df.degree == 1
    
    # 3. VectorField Creation
    X = C1.vector_field({x: 1, y: x})
    print(f"VectorField X: {X} (Chart: {X.chart})")
    assert X.chart == C1
    
    # 4. Evaluation X(f)
    res = X(f)
    print(f"X(f) = {res} (Type: {type(res)})")
    assert isinstance(res, ScalarField)
    assert res.chart == C1
    
    # 5. Validation: Conflicting charts
    C2 = Chart(['u', 'v'])
    u, v = C2.coords
    g = C2.scalar_field(u**2)
    
    try:
        f + g
        assert False, "Should have raised ValueError for conflicting charts"
    except ValueError as e:
        print(f"Caught expected error: {e}")
        
    # 6. Backward Compatibility: Chart-less objects
    X_old = VectorField({x: 1})
    print(f"Old VectorField (no chart): {X_old}")
    
    # Adding old to new should work
    X_sum = X + X_old
    print(f"X + X_old = {X_sum} (Chart: {X_sum.chart})")
    assert X_sum.chart == C1
    
    # X_old(f) should work
    res_old = X_old(f)
    print(f"X_old(f) = {res_old} (Type: {type(res_old)})")
    # Note: if X_old has no chart, should it return a ScalarField with f's chart?
    # Current implementation: X_old._apply returns sympy expr, X_old.__call__ wraps it?
    # Let's check VectorField.__call__ again.
    
    # 7. ScalarField and DifferentialForm interaction
    omega = C1.diff_form(1, {(x,): 1})
    omega_scaled = f * omega
    print(f"f * omega = {omega_scaled} (Chart: {omega_scaled.chart})")
    assert omega_scaled.chart == C1

    print("\nConsistency tests passed!")

if __name__ == "__main__":
    test_consistency()
