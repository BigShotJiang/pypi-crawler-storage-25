import sympy as sp
from cinfsymmetries import Chart, JetSpaceChart, VectorField

def test_chart_basic():
    C = Chart(['x', 'y', 'z'])
    assert isinstance(C.x, sp.Symbol)
    assert C.x == sp.Symbol('x')
    assert C['y'] == sp.Symbol('y')
    
def test_jet_space_chart():
    J = JetSpaceChart(x_names='x', u_names='u', order=2)
    # Vars should be x, u, u_x, u_xx
    assert J.x == sp.Symbol('x')
    assert J.u == sp.Symbol('u')
    assert J.u_x == sp.Symbol('u_x')
    assert J.u_xx == sp.Symbol('u_xx')
    
def test_total_derivative():
    J = JetSpaceChart(x_names='x', u_names='u', order=2)
    D = J.total_derivative()
    
    # D = d/dx + u_x*d/du + u_xx*d/u_x
    assert D.components[J.x] == 1
    assert D.components[J.u] == J.u_x
    assert D.components[J.u_x] == J.u_xx
    assert len(D.components) == 3
    
    # Test application
    expr = J.u**2 + J.x * J.u_x
    # D(expr) = 2*u*u_x + 1*u_x + x*u_xx
    res = D(expr)
    expected = 2*J.u*J.u_x + J.u_x + J.x*J.u_xx
    assert sp.simplify(res - expected) == 0

def test_jet_space_order_1():
    J = JetSpaceChart(x_names='x', u_names='u', order=1)
    D = J.total_derivative()
    # D = d/dx + u_x*d/du
    assert D.components[J.x] == 1
    assert D.components[J.u] == J.u_x
    assert len(D.components) == 2
