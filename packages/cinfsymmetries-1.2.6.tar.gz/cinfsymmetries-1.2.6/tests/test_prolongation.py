import sympy as sp
from cinfsymmetries import VectorField, JetSpaceChart, Prolongation, LambdaProlongation

def test_prolongation_basic():
    J = JetSpaceChart(x_names='x', u_names='u', order=2)
    x, u, u_x, u_xx = J.coords
    
    # 1. Translation in u: X = d/du
    X1 = VectorField({u: 1})
    prX1 = J.prolong(X1)
    # pr X1 should be d/du (all higher components are 0)
    assert u_x not in prX1.components
    assert u_xx not in prX1.components
    assert prX1.components[u] == 1
    
    # 2. Scaling in u: X = u * d/du
    # phi = u, xi = 0
    # phi^(1) = D(u) - u_x*D(0) = u_x
    # phi^(2) = D(u_x) - u_xx*D(0) = u_xx
    X2 = VectorField({u: u})
    prX2 = J.prolong(X2)
    assert sp.simplify(prX2.components[u] - u) == 0
    assert sp.simplify(prX2.components[u_x] - u_x) == 0
    assert sp.simplify(prX2.components[u_xx] - u_xx) == 0

    # 3. Translation in x: X = d/dx
    # phi = 0, xi = 1
    # phi^(1) = D(0) - u_x*D(1) = 0
    X3 = VectorField({x: 1})
    prX3 = J.prolong(X3)
    assert prX3.components[x] == 1
    assert len(prX3.components) == 1

def test_lambda_prolongation():
    J = JetSpaceChart(x_names='x', u_names='u', order=1)
    x, u, u_x = J.coords
    
    # X = exp(x) * d/du, lambda = -1
    # phi = exp(x), xi = 0
    # phi^(1) = (D - 1)(exp(x)) - u_x*(D - 1)(0) = D(exp(x)) - exp(x) = 0
    X = VectorField({u: sp.exp(x)})
    prX = LambdaProlongation(X, lambd=-1, J=J)
    
    assert sp.simplify(prX.components[u] - sp.exp(x)) == 0
    assert u_x not in prX.components or prX.components[u_x] == 0

    # X = d/du, lambda = x
    # phi = 1, xi = 0
    # phi^(1) = (D + x)(1) - u_x*(D + x)(0) = x
    prX2 = LambdaProlongation(VectorField({u: 1}), lambd=x, J=J)
    assert sp.simplify(prX2.components[u_x] - x) == 0

def test_prolongation_order():
    J = JetSpaceChart(x_names='x', u_names='u', order=5)
    X = VectorField({J.u: J.u})
    # Prolong to order 2 only
    prX = J.prolong(X, order=2)
    assert J.u_x in prX.components
    assert J.u_xx in prX.components
    assert sp.Symbol('u_xxx') not in prX.components

if __name__ == "__main__":
    test_prolongation_basic()
    test_lambda_prolongation()
    test_prolongation_order()
    print("All prolongation tests passed!")
