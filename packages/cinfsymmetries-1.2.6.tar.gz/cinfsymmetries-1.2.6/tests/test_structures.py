import sympy as sp
from cinfsymmetries import VectorField, Distribution, Chart

def test_check_structure_solvable():
    x, y, z = sp.symbols('x y z')
    
    # Base distribution Z = <d/dx>
    Z = Distribution([VectorField({x: 1})])
    
    # X = <d/dy, d/dz>
    # This should be a solvable structure
    X = [VectorField({y: 1}), VectorField({z: 1})]
    
    assert Z.check_structure(X) == 1

def test_check_structure_cinf():
    x, y = sp.symbols('x y')
    
    # Base distribution Z = <d/dx>
    Z = Distribution([VectorField({x: 1})])
    
    # Z = d/dx, X = e^x d/dy
    # [X, Z] = [e^x d/dy, d/dx] = -e^x d/dy = -1 * X.
    # Not a symmetry because -X is not in span(Z).
    # But it is a C^inf symmetry because it's in span(Z, X).
    
    Z2 = Distribution([VectorField({x: 1})])
    X_cinf = [VectorField({y: sp.exp(x)})]
    
    assert Z2.check_structure(X_cinf) == 2

def test_check_structure_independence():
    x, y = sp.symbols('x y')
    Z = Distribution([VectorField({x: 1})])
    X = [VectorField({x: 1})] # Not independent
    assert Z.check_structure(X) == 0

def test_check_structure_dim():
    x, y, z = sp.symbols('x y z')
    chart = Chart([x, y, z])
    Z = Distribution([VectorField({x: 1})])
    X = [VectorField({y: 1})] # 2 vectors, 3 variables in chart
    assert Z.check_structure(X, chart=chart) == -1

def test_check_structure_involutive():
    x, y, z = sp.symbols('x y z')
    # Non-involutive distribution
    # Y1 = d/dx, Y2 = x*d/dy + d/dz
    # [Y1, Y2] = d/dy. 
    # d/dy is not in span(d/dx, x*d/dy + d/dz)
    Y1 = VectorField({x: 1})
    Y2 = VectorField({y: x, z: 1})
    Z = Distribution([Y1, Y2])
    
    X = [VectorField({y: 1})] # dummy
    assert Z.check_structure(X) == -2

def test_check_structure_none():
    x, y, z = sp.symbols('x y z')
    chart = Chart([x, y, z])
    
    # Z = <d/dx>
    # X1 = d/dy + x*d/dz
    # X2 = d/dz
    # [X1, Z] = -d/dz. 
    # Is d/dz in span(d/dx, d/dy + x*d/dz)?
    # No. 
    
    Z = Distribution([VectorField({x: 1})])
    X = [VectorField({y: 1, z: x}), VectorField({z: 1})]
    
    # This should fail because X1 is not a cinf-symmetry of Z
    assert Z.check_structure(X, chart=chart) == -3


def test_get_cinf_determining_equations():
    x, y, z = sp.symbols('x y z')
    chart = Chart([x, y, z])
    
    # Distribution D = <d/dx>
    D = Distribution([VectorField({x: 1})])
    
    # Candidate X with unknown components
    xi_x = sp.Function('xi_x')(x, y, z)
    xi_y = sp.Function('xi_y')(x, y, z)
    xi_z = sp.Function('xi_z')(x, y, z)
    X = VectorField({x: xi_x, y: xi_y, z: xi_z})
    
    # Get equations
    eqs = D.get_cinf_determining_equations(X, chart)
    
    # In 3D rank 1, there should be 1 equation relating xi^y and xi^z components
    assert len(eqs) == 1
    
    # The equation involves partial derivatives with respect to x
    eq_str = str(eqs[0])
    assert "Derivative(xi_y(x, y, z), x)" in eq_str or "xi_y(x, y, z).diff(x)" in eq_str
    assert "xi_z" in eq_str

