import sympy as sp
import pytest
from cinfsymmetries import Chart, VectorField, JetSpaceChart, Transformation, get_determining_equations

def test_pushforward_inversion():
    C1 = Chart(['x', 'y'])
    C2 = Chart(['u', 'v'])
    # phi: u = x+y, v = x-y
    # Inversion: x = (u+v)/2, y = (u-v)/2
    phi = C1.map_to(C2, {C2.u: C1.x + C1.y, C2.v: C1.x - C1.y})
    
    # X = d/dx
    X = VectorField({C1.x: 1})
    
    # phi_* X = d/dx(x+y) d/du + d/dx(x-y) d/dv = 1 d/du + 1 d/dv
    # Result should be in u, v coordinates
    pfX = phi.pushforward_vector_field(X)
    
    assert pfX.chart == C2
    assert pfX.components[C2.u] == 1
    assert pfX.components[C2.v] == 1
    # Check if they are truly target vars (though 1 is a constant)
    
    # X2 = x*d/dx
    X2 = VectorField({C1.x: C1.x})
    # phi_* X2 = x d/du + x d/dv = (u+v)/2 d/du + (u+v)/2 d/dv
    pfX2 = phi.pushforward_vector_field(X2)
    assert pfX2.chart == C2
    assert sp.simplify(pfX2.components[C2.u] - (C2.u + C2.v)/2) == 0
    assert sp.simplify(pfX2.components[C2.v] - (C2.u + C2.v)/2) == 0

def test_jacobian():
    C1 = Chart(['x', 'y'])
    C2 = Chart(['u', 'v'])
    phi = C1.map_to(C2, {C2.u: C1.x**2, C2.v: C1.x * C1.y})
    
    J = phi.jacobian()
    # J = [[2*x, 0], [y, x]]
    expected = sp.Matrix([[2*C1.x, 0], [C1.y, C1.x]])
    assert J == expected

def test_repr_improved():
    C = Chart(['x'])
    X = VectorField({C.x: sp.sin(C.x)})
    r = repr(X)
    assert "∂/∂x" in r
    assert "sin(x)" in r
    
    latex = X._repr_latex_()
    assert "\\frac{\\partial}{\\partial x}" in latex
    assert "\\sin" in latex

def test_multi_equation_determining():
    J = JetSpaceChart(x_names='x', u_names='u', order=2)
    # System: u_xx = 0, u_x = 0 (trivial but tests multiple eqs)
    eqs = [J.u_xx, J.u_x]
    det_eqs = get_determining_equations(eqs, J)
    # Should not crash and should return some equations
    assert len(det_eqs) > 0

def test_performance_no_simplify():
    # Construct a relatively large jet space vector field
    J = JetSpaceChart(x_names=['x1', 'x2'], u_names=['u1', 'u2'], order=3)
    # This has many coordinates.
    # Initializing a VectorField with complex components should be fast now.
    import time
    start = time.time()
    comp = {v: sp.sin(v)**2 + sp.cos(v)**2 for v in J.coords}
    X = VectorField(comp, simplify=False)
    end = time.time()
    # Without simplify, it should be near-instant.
    # If simplify=True, it would take much longer.
    assert end - start < 0.5 
