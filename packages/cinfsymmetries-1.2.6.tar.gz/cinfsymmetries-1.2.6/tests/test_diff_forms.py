import sympy as sp
from cinfsymmetries import Chart, VectorField, DifferentialForm

def test_form_initialization():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # 1-form
    omega = C.diff_form(1, {x: 1, y: x})
    assert omega.degree == 1
    assert omega.components[(x,)] == 1
    assert omega.components[(y,)] == x
    
    # 2-form with canonicalization
    eta = C.diff_form(2, {(y, x): -1, (x, z): 2})
    assert eta.degree == 2
    assert eta.components[(x, y)] == 1
    assert eta.components[(x, z)] == 2

def test_form_arithmetic():
    C = Chart(['x', 'y'])
    x, y = C.coords
    omega1 = C.diff_form(1, {x: 1})
    omega2 = C.diff_form(1, {y: 1})
    
    # Addition
    omega3 = omega1 + omega2
    assert omega3.components[(x,)] == 1
    assert omega3.components[(y,)] == 1
    
    # Scalar multiplication
    omega4 = x * omega1
    assert omega4.components[(x,)] == x

def test_wedge_product():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    dx = C.diff_form(1, {x: 1})
    dy = C.diff_form(1, {y: 1})
    dz = C.diff_form(1, {z: 1})
    
    # dx ^ dy
    dx_dy = dx ^ dy
    assert dx_dy.degree == 2
    assert dx_dy.components[(x, y)] == 1
    
    # dy ^ dx = -dx ^ dy
    dy_dx = dy ^ dx
    assert dy_dx.components[(x, y)] == -1
    
    # dx ^ dx = 0
    dx_dx = dx ^ dx
    assert len(dx_dx.components) == 0
    
    # (dx ^ dy) ^ dz
    vol = (dx ^ dy) ^ dz
    assert vol.degree == 3
    assert vol.components[(x, y, z)] == 1

def test_exterior_derivative():
    C = Chart(['x', 'y'])
    x, y = C.coords
    
    # d(x*y) = y*dx + x*dy
    df = C.d(x*y)
    assert df.degree == 1
    assert df.components[(x,)] == y
    assert df.components[(y,)] == x
    
    # d(d(f)) = 0
    ddf = df.d()
    assert len(ddf.components) == 0
    
    # d(y * dx) = dy ^ dx = -dx ^ dy
    omega = C.diff_form(1, {(x,): y})
    d_omega = omega.d()
    assert d_omega.degree == 2
    assert d_omega.components[(x, y)] == -1

def test_interior_product():
    C = Chart(['x', 'y'])
    x, y = C.coords
    X = VectorField({x: 1, y: x**2})
    
    # i_X (dx) = X(x) = 1
    dx = C.diff_form(1, {x: 1})
    val = dx.i(X)
    assert val.degree == 0
    assert val.components[()] == 1
    
    # i_X (dx ^ dy) = (i_X dx) ^ dy - dx ^ (i_X dy) = 1 * dy - dx * x^2
    dx_dy = dx ^ C.diff_form(1, {y: 1})
    res = dx_dy.i(X)
    assert res.degree == 1
    assert res.components[(x,)] == -x**2
    assert res.components[(y,)] == 1

def test_form_call():
    C = Chart(['x', 'y'])
    x, y = C.coords
    X = VectorField({x: 1, y: 0})
    Y = VectorField({x: 0, y: 1})
    
    omega = C.diff_form(2, {(x, y): x*y})
    
    # omega(X, Y) = x*y
    val = omega(X, Y)
    assert sp.simplify(val - x*y) == 0
    
    # omega(Y, X) = -x*y
    val2 = omega(Y, X)
    assert sp.simplify(val2 + x*y) == 0

def test_lie_derivative():
    C = Chart(['x', 'y'])
    x, y = C.coords
    X = VectorField({x: y, y: -x})
    omega = C.diff_form(1, {x: x, y: y}) # r dr = x dx + y dy
    
    # L_X (x dx + y dy) = i_X d(x dx + y dy) + d i_X (x dx + y dy)
    # d(x dx + y dy) = dx ^ dx + dy ^ dy = 0
    # i_X (x dx + y dy) = x*y + y*(-x) = 0
    # So L_X(omega) should be 0
    L_omega = omega.lie_derivative(X)
    assert len(L_omega.components) == 0
    
    # Test L_X f = X(f)
    f_form = C.diff_form(0, {(): x**2})
    L_f = f_form.lie_derivative(X)
    assert L_f.degree == 0
    assert sp.simplify(L_f.components[()] - 2*x*y) == 0
