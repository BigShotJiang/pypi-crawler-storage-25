import sympy as sp
from cinfsymmetries import VectorField, LieBracket, Distribution

def test_vector_field_bracket():
    x, y = sp.symbols('x y')
    # X = y * d/dx
    X = VectorField({x: y})
    # Y = x * d/dy
    Y = VectorField({y: x})
    
    # [X, Y] = X(Y) - Y(X) = X(x*d/dy) - Y(y*d/dx)
    # X(x) = y, Y(y) = x
    # [X, Y] = y*d/dy - x*d/dx
    Z = LieBracket(X, Y)
    
    assert sp.simplify(Z.components[y] - y) == 0
    assert sp.simplify(Z.components[x] - (-x)) == 0

def test_distribution_symmetry():
    x, u, u1 = sp.symbols('x u u1')
    
    # A simple 1st order equivalent ODE u' = u1, but let's just make a generic associated vector field A
    # A = d/dx + u1 * d/du  (rank 1 distribution)
    A = VectorField({x: 1, u: u1})
    D = Distribution([A])
    
    # Symmetry 1: translation in x: X_sym = d/dx
    X_sym = VectorField({x: 1})
    assert D.check_symmetry(X_sym) is True
    
    # Symmetry 2: translation in u: Y_sym = d/du
    Y_sym = VectorField({u: 1})
    assert D.check_symmetry(Y_sym) is True
    
    # Symmetry 3: Z_sym = x * d/dx + u * d/du
    # A(x) = 1, A(u) = u1
    # Z_sym(1) = 0, Z_sym(u1) = 0
    # [Z_sym, A] = -d/dx - u1*d/du = -A
    # This is clearly in the span of A
    Z_sym = VectorField({x: x, u: u})
    assert D.check_symmetry(Z_sym) is True
    
    # Non-symmetry: W_bad = x * u1 * d/du
    # A(x * u1) = u1. So [W_bad, A] = W_bad(A) - A(W_bad) = 0 - u1*d/du != c*A
    W_bad = VectorField({u: x * u1})
    assert D.check_symmetry(W_bad) is False

def test_distribution_involutive():
    x, y, z = sp.symbols('x y z')
    
    # Two commuting vector fields
    X1 = VectorField({x: 1})
    X2 = VectorField({y: 1})
    D1 = Distribution([X1, X2])
    assert D1.is_involutive() is True
    
    # Two vector fields that don't commute but are in span
    # Actually wait, [x d/dx, x d/dy] = x d/dy = X4
    X3 = VectorField({x: x})
    X4 = VectorField({y: x})
    D2 = Distribution([X3, X4])
    assert D2.is_involutive() is True
    
    # Non-involutive distribution
    # X5 = d/dx, X6 = x * d/dy
    # [X5, X6] = d/dy 
    # d/dy is NOT in span(d/dx, x d/dy) unless x is invertible, but over fractions it is!
    # Let's use something else:
    Y1 = VectorField({x: 1})
    Y2 = VectorField({y: x, z: 1})
    # [Y1, Y2] = d/dy. 
    # M = [1,  0
    #      0,  x
    #      0,  1] -> rank is 2. 
    # span doesn't include d/dy (which is [0, 1, 0]^T) since it requires a linear combination to kill z, which kills y too.
    D3 = Distribution([Y1, Y2])
    assert D3.is_involutive() is False
