import pytest
import sympy as sp
from cinfsymmetries import Chart, VectorField, ExteriorDifferentialSystem

def test_cinf_symmetry_reduction_example():
    # Setup from the "tonto" example
    M = Chart(['x', 'y', 'u', 'v'])
    x, y, u, v = M.coords
    
    dx, dy, du, dv = M.d('x'), M.d('y'), M.d('u'), M.d('v')
    
    theta1 = du - x*dx - dy
    theta2 = dv + x*dx - dy
    
    I = ExteriorDifferentialSystem([theta1, theta2], chart=M)
    X = VectorField({x: y}, chart=M)
    
    # 1. Standard symmetry check
    assert I.check_symmetry(X) is False
    
    # 2. Sub-ideal calculation
    sub_I = I.reduce_ideal(X)
    # Generators should be proportional to du + dv - 2dy
    assert len(sub_I.generators) == 1
    # Check if du + dv - 2dy is in the ideal
    alpha = du + dv - 2*dy
    assert sub_I.is_in_ideal(alpha)
    
    # 3. Cinf-symmetry check
    is_cinf, sub_I_v = I.check_cinf_symmetry(X)
    assert is_cinf is True
    
    # 4. Reduction
    reduced_I, connection_forms, invariants = I.reduce_by_flow(X)
    
    assert set(invariants) == {y, u, v}
    assert len(reduced_I.generators) == 1
    # The reduced form should be du + dv - 2dy in the new chart
    # (The names might be different, but coefficients match)
    gen = reduced_I.generators[0]
    # Check coefficients
    coeffs = [gen.components.get((v,), 0) for v in reduced_I.chart.coords]
    # Sort or check set to be robust to coordinate ordering
    assert set(coeffs) == {1, 1, -2}

def test_no_cinf_symmetry():
    M = Chart(['x', 'y', 'z'])
    x, y, z = M.coords
    dx, dy, dz = M.d('x'), M.d('y'), M.d('z')
    
    # A system that doesn't have this property
    I = ExteriorDifferentialSystem([dz - y*dx], chart=M)
    X = VectorField({y: 1}, chart=M) # X = d/dy
    
    # I^X: i_X(dz - y dx) = 0 => 0 = 0. So I^X = I.
    # d(I^X) = d(dz - y dx) = -dy ^ dx.
    # Is -dy ^ dx in I? No.
    
    is_cinf, _ = I.check_cinf_symmetry(X)
    assert is_cinf is False
