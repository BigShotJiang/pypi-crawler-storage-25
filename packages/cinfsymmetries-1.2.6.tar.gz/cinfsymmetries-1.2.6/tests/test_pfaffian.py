import sympy as sp
import pytest
from cinfsymmetries.core import VectorField, Distribution, DifferentialForm, PfaffianSystem, Chart

def test_pfaffian_duality():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Distribution D = span{d/dx + z d/dy}
    D = Distribution([VectorField({x: 1, y: z})])
    
    # Dual Pfaffian system: omega(d/dx + z d/dy) = 0
    # One solution: dz = 0, another: dy - z dx = 0
    P = D.get_pfaffian_system(chart=C)
    
    # Check if elements of P annihilate elements of D
    for omega in P.forms:
        for X in D.vector_fields:
            assert sp.simplify(omega(X)) == 0

    # Backwards: get distribution from Pfaffian system
    D_back = P.get_distribution()
    for X in D_back.vector_fields:
        for omega in P.forms:
            assert sp.simplify(omega(X)) == 0

def test_integrability():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Contact structure: omega = dy - z dx
    omega = DifferentialForm(1, {(y,): 1, (x,): -z}, chart=C)
    P = PfaffianSystem([omega])
    
    # The contact structure is NOT integrable (dz ^ omega ^ d_omega != 0)
    # The dual distribution D = span{d/dz, d/dx + z d/dy}
    # [d/dz, d/dx + z d/dy] = d/dy, which is NOT in D.
    assert P.is_integrable() is False
    
    # Rectifiable system: omega = dx, dz
    P2 = PfaffianSystem([DifferentialForm(1, {(x,): 1}, chart=C), 
                         DifferentialForm(1, {(z,): 1}, chart=C)])
    assert P2.is_integrable() is True

def test_adapted_pfaffian_basis():
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Distribution D = span{d/dx + y d/dz}
    Z1 = VectorField({x: 1, z: y})
    D = Distribution([Z1])
    
    # C^inf-structure: X1 = d/dy, X2 = d/dz
    X1 = VectorField({y: 1})
    X2 = VectorField({z: 1})
    
    X_list = [X1, X2]
    
    # Get adapted basis
    basis = D.get_adapted_pfaffian_basis(X_list, chart=C)
    
    assert len(basis) == 2
    omega_1, omega_2 = basis
    
    # Verify omega_i(Z) = 0
    assert sp.simplify(omega_1(Z1)) == 0
    assert sp.simplify(omega_2(Z1)) == 0
    
    # Verify omega_i(X_j) = delta_ij
    assert sp.simplify(omega_1(X1)) == 1
    assert sp.simplify(omega_1(X2)) == 0
    assert sp.simplify(omega_2(X1)) == 0
    assert sp.simplify(omega_2(X2)) == 1
    
    # Test Fallback Method using a different chart dimension vs vector fields
    # Here dim=3, r=1, k=1 -> r+k = 2 < 3. Should use _get_adapted_pfaffian_basis_linsolve
    X_list_partial = [X1]
    basis_partial = D.get_adapted_pfaffian_basis(X_list_partial, chart=C)
    
    assert len(basis_partial) == 1
    omega_partial = basis_partial[0]
    
    assert sp.simplify(omega_partial(Z1)) == 0
    assert sp.simplify(omega_partial(X1)) == 1
