import sympy as sp
from cinfsymmetries.core import VectorField

def test_invariants_translation():
    x, y = sp.symbols('x y')
    X = VectorField({x: 1, y: 1})
    invs = X.get_invariants()
    # Should find y-x or x-y
    for inv in invs:
        assert sp.simplify(X(inv)) == 0
    assert len(invs) >= 1

def test_invariants_scaling():
    x, y = sp.symbols('x y')
    X = VectorField({x: x, y: y})
    invs = X.get_invariants()
    # Should find y/x or x/y
    for inv in invs:
        assert sp.simplify(X(inv)) == 0
    assert len(invs) >= 1

def test_invariants_rotation():
    x, y = sp.symbols('x y')
    X = VectorField({x: -y, y: x})
    invs = X.get_invariants()
    # Should find x**2 + y**2
    for inv in invs:
        assert sp.simplify(X(inv)) == 0
    assert len(invs) >= 1

def test_invariants_3d():
    x, y, z = sp.symbols('x y z')
    X = VectorField({x: 1, y: 1, z: 1})
    invs = X.get_invariants()
    for inv in invs:
        assert sp.simplify(X(inv)) == 0
    # For 3D, we expect 2 independent invariants
    # pdsolve for I_x + I_y + I_z = 0 -> I = F(x-y, x-z)
    assert len(invs) >= 2

def test_invariants_3d_scaling():
    x, y, z = sp.symbols('x y z')
    X = VectorField({x: x, y: y, z: z})
    invs = X.get_invariants()
    for inv in invs:
        assert sp.simplify(X(inv)) == 0
    assert len(invs) >= 2
