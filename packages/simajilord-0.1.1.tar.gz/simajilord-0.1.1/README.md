---
license: apache-2.0
base_model:
- cappuccino-27b-base
pipeline_tag: text-generation
tags:
- cappuccino
- multimodal
- tool-use
- thinking
- local-runtime
library_name: transformers
---

# Cappuccino-27B

Cappuccino-27B is the local Cappuccino foundation checkpoint used by this repository for runtime serving, continual pretraining, and supervised fine-tuning.

## Identity

- Public model name: `Cappuccino-27B`
- Public base-model identity: `cappuccino-27b-base`
- Repository root stores the original-precision MLX weights.
- `artifacts/q6` is a separate 6-bit inference copy for serving and benchmarking.
- Model and processor identifiers in the model directory are branded as `Cappuccino`.

## Architecture

- Type: causal language model with a vision encoder
- Scale: 27B-class multimodal model
- Decoder layers: 64
- Native context window: `262144`
- Context length: 262,144 natively and extensible up to 1,010,000 tokens.
- Training and runtime surface: text, image, video placeholders, tool calls, tool responses, and thinking traces

## Runtime

Cappuccino exposes the OpenAI API through the local wrapper, with the Responses API as the default interface for tools and multimodal turns, and can be inspected, trained, quantized, and served with the `cappuccino` CLI.

```bash
./.venv/bin/cappuccino inspect-model --model-path /Users/megantemeteo/Desktop/cappuccino
```

```bash
./.venv/bin/cappuccino train \
  --model-path /Users/megantemeteo/Desktop/cappuccino \
  --dataset-path /path/to/train.jsonl \
  --output-dir /path/to/out \
  --dry-run
```

## Storage

- `inspect-model` reports `weight_bytes` for the base checkpoint already stored in the model directory.
- `train --dry-run` reports `saved_trainable_tensor_bytes` separately so the saved trainable tensors can be accounted for without conflating them with the base checkpoint.
- If adapters are merged back into a full checkpoint later, the merged checkpoint size stays close to the base model size because the architecture does not grow.
