# Cappuccino

`simajilord` is the package and CLI that exposes a local OpenAI-compatible runtime for Cappuccino-class models on Apple Silicon.

まだまだ未完成です。

## Install

The model name stays `cappuccino`, but the package name is:

```bash
pip install simajilord
```

Public import and CLI:

```bash
python -c "import simajilord; print(simajilord.__file__)"
simajilord --help
```

## Serve a local OpenAI-compatible endpoint

```bash
simajilord serve \
  --default-model-path /path/to/Cappuccino-27B \
  --public-model-id cappuccino \
  --host 127.0.0.1 \
  --port 8020
```

## Quickstart with the OpenAI Python SDK

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:8020/v1",
    api_key="dummy",
)

response = client.chat.completions.create(
    model="cappuccino",
    messages=[
        {"role": "user", "content": "日本語で一文だけ自己紹介して。"},
    ],
)

print(response.choices[0].message.content)
```

## Quickstart with skill selection

Skill selection is a Cappuccino extension. The request stays OpenAI-compatible because skill metadata is converted into ordinary upstream instructions before the model call.

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:8020/v1",
    api_key="dummy",
)

response = client.responses.create(
    model="cappuccino",
    input="OpenAI API の公式情報だけで確認して要点をまとめて。",
    extra_body={
        "skill_choice": "auto",
    },
)

print(response.output_text)
```

Explicit skill selection:

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:8020/v1",
    api_key="dummy",
)

response = client.responses.create(
    model="cappuccino",
    input="最新の API 仕様を確認して。",
    extra_body={
        "skills": ["openai-docs"],
    },
)

print(response.output_text)
```

## Skill registry layout

Each skill lives in its own directory and uses `SKILL.md` frontmatter:

```md
---
name: openai-docs
description: Use when a task needs current OpenAI API documentation and official references.
---

Read the official docs first.
```

Load the registry at serve time:

```bash
simajilord serve \
  --default-model-path /path/to/Cappuccino-27B \
  --skill-registry /path/to/skills
```

Compatibility CLI alias:

```bash
cappuccino --help
```
