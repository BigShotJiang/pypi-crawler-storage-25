import json
from pathlib import Path

from cappuccino.context_windows import (
    DEFAULT_EXTENDED_CONTEXT_WINDOW,
    apply_context_window_to_config,
    configure_model_context_window,
)


def test_apply_context_window_to_config_enables_yarn_for_1m() -> None:
    updated = apply_context_window_to_config(
        {
            "text_config": {
                "max_position_embeddings": 262144,
                "rope_parameters": {
                    "mrope_interleaved": True,
                    "mrope_section": [11, 11, 10],
                    "rope_type": "default",
                    "rope_theta": 10000000,
                    "partial_rotary_factor": 0.25,
                },
            }
        }
    )

    assert updated["text_config"]["max_position_embeddings"] == DEFAULT_EXTENDED_CONTEXT_WINDOW
    assert updated["text_config"]["rope_parameters"]["rope_type"] == "yarn"
    assert updated["text_config"]["rope_parameters"]["factor"] == 4.0
    assert updated["text_config"]["rope_parameters"]["original_max_position_embeddings"] == 262144


def test_configure_model_context_window_writes_config(tmp_path: Path) -> None:
    config_path = tmp_path / "config.json"
    config_path.write_text(
        json.dumps(
            {
                "text_config": {
                    "max_position_embeddings": 262144,
                    "rope_parameters": {
                        "mrope_interleaved": True,
                        "mrope_section": [11, 11, 10],
                        "rope_type": "default",
                        "rope_theta": 10000000,
                        "partial_rotary_factor": 0.25,
                    },
                }
            }
        ),
        encoding="utf-8",
    )

    report = configure_model_context_window(tmp_path)
    updated = json.loads(config_path.read_text(encoding="utf-8"))

    assert report.configured_context_window == DEFAULT_EXTENDED_CONTEXT_WINDOW
    assert updated["text_config"]["rope_parameters"]["rope_type"] == "yarn"
