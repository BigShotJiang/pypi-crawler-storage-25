from pathlib import Path

from cappuccino.openai_contract import (
    build_openai_contract_report,
    expected_server_routes,
    write_openai_contract_report,
)
from cappuccino.server import create_app


def test_build_openai_contract_report_matches_core_sdk_routes() -> None:
    report = build_openai_contract_report(
        app=create_app(),
        include_latest_release=False,
    )

    assert report.installed_sdk_version is not None
    assert report.sdk_module_path is not None
    assert report.core_resources.responses is True
    assert report.core_resources.chat_completions is True
    assert report.core_resources.completions is True
    assert report.core_resources.models is True
    assert "id" in report.type_shapes.model_object_fields
    assert "choices" in report.type_shapes.completion_object_fields
    assert report.missing_server_routes == []
    for route in expected_server_routes(report.core_resources):
        assert route in report.present_server_routes


def test_write_openai_contract_report_persists_json(tmp_path: Path) -> None:
    output_path = tmp_path / "openai_api_contract.json"

    report = write_openai_contract_report(
        output_path=output_path,
        app=create_app(),
        include_latest_release=False,
    )

    assert output_path.exists()
    text = output_path.read_text(encoding="utf-8")
    assert report.installed_sdk_version is not None
    assert report.installed_sdk_version in text
    assert '"required_server_routes"' in text
