from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import httpx
import pytest
from openai import AsyncOpenAI, BadRequestError

import cappuccino.server as server_module
import cappuccino.tool_runtime as tool_runtime
from cappuccino.server import create_app


@pytest.mark.anyio
async def test_async_openai_sdk_supports_public_cappuccino_model_id(
    monkeypatch: Any,
) -> None:
    model_root = Path(__file__).resolve().parents[1]
    seen_chat_payloads: list[dict[str, Any]] = []
    seen_reasoning_payloads: list[dict[str, Any]] = []

    async def fake_call_model(path: str, payload: dict[str, Any]) -> dict[str, Any]:
        assert path == "/v1/chat/completions"
        seen_chat_payloads.append(payload)
        return {
            "id": "chatcmpl_123",
            "object": "chat.completion",
            "created": 123,
            "model": payload["model"],
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {
                        "role": "assistant",
                        "content": "hello from cappuccino",
                    },
                }
            ],
            "usage": {
                "prompt_tokens": 4,
                "completion_tokens": 3,
                "total_tokens": 7,
            },
        }

    async def fake_reasoning_chat_completion(
        *,
        payload: dict[str, object],
        control: Any,
        call_model: Any,
        reasoning_log_path: str,
    ) -> dict[str, object]:
        seen_reasoning_payloads.append(dict(payload))
        return {
            "id": "chatcmpl_reasoning",
            "object": "chat.completion",
            "created": 456,
            "model": payload["model"],
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {
                        "role": "assistant",
                        "content": "chat completion ok",
                    },
                }
            ],
            "usage": {
                "prompt_tokens": 5,
                "completion_tokens": 4,
                "total_tokens": 9,
            },
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    monkeypatch.setattr(
        server_module,
        "run_structured_reasoning_chat_completion",
        fake_reasoning_chat_completion,
    )

    app = create_app(default_model_path=model_root, public_model_id="cappuccino")
    http_client = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver/v1",
    )
    client = AsyncOpenAI(
        api_key="dummy",
        base_url="http://testserver/v1",
        http_client=http_client,
    )

    models = await client.models.list()
    assert any(model.id == "cappuccino" for model in models.data)

    model = await client.models.retrieve("cappuccino")
    assert model.id == "cappuccino"

    response = await client.responses.create(model="cappuccino", input="hi")
    assert response.output_text == "hello from cappuccino"
    assert seen_chat_payloads[0]["model"] == str(model_root.resolve())

    chat_completion = await client.chat.completions.create(
        model="cappuccino",
        messages=[{"role": "user", "content": "hello"}],
    )
    assert chat_completion.choices[0].message.content == "chat completion ok"
    assert seen_reasoning_payloads[0]["model"] == str(model_root.resolve())

    completion = await client.completions.create(model="cappuccino", prompt="hello")
    assert completion.choices[0].text == "hello from cappuccino"
    assert seen_chat_payloads[-1]["model"] == str(model_root.resolve())

    await http_client.aclose()


@pytest.mark.anyio
async def test_async_openai_sdk_supports_responses_tools_with_public_cappuccino_model_id(
    monkeypatch: Any,
) -> None:
    model_root = Path(__file__).resolve().parents[1]
    call_count = {"value": 0}
    seen_payloads: list[dict[str, Any]] = []

    async def fake_call_model(path: str, payload: dict[str, Any]) -> dict[str, Any]:
        assert path == "/v1/chat/completions"
        seen_payloads.append(payload)
        call_count["value"] += 1
        if call_count["value"] == 1:
            return {
                "id": "chatcmpl_tools_1",
                "object": "chat.completion",
                "created": 123,
                "model": payload["model"],
                "choices": [
                    {
                        "index": 0,
                        "finish_reason": "tool_calls",
                        "message": {
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [
                                {
                                    "type": "function",
                                    "id": "call_wiki_1",
                                    "function": {
                                        "name": "wikipedia_search",
                                        "arguments": '{"query":"富士山","language":"ja"}',
                                    },
                                }
                            ],
                        },
                    }
                ],
            }
        return {
            "id": "chatcmpl_tools_2",
            "object": "chat.completion",
            "created": 124,
            "model": payload["model"],
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {
                        "role": "assistant",
                        "content": "富士山は日本で最も高い山です。",
                    },
                }
            ],
            "usage": {
                "prompt_tokens": 12,
                "completion_tokens": 7,
                "total_tokens": 19,
            },
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    monkeypatch.setattr(
        tool_runtime,
        "wikipedia_tool_output",
        lambda arguments: '{"query":"富士山","results":[{"title":"富士山"}]}',
    )

    app = create_app(default_model_path=model_root, public_model_id="cappuccino")
    http_client = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver/v1",
    )
    client = AsyncOpenAI(
        api_key="dummy",
        base_url="http://testserver/v1",
        http_client=http_client,
    )

    response = await client.responses.create(
        model="cappuccino",
        input="富士山を説明して",
        tools=cast(
            Any,
            [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        ),
    )

    assert response.output_text == "富士山は日本で最も高い山です。"
    assert response.output[0].type == "function_call"
    assert response.output[1].type == "message"
    assert seen_payloads[0]["model"] == str(model_root.resolve())
    assert call_count["value"] == 2

    await http_client.aclose()


@pytest.mark.anyio
async def test_async_openai_sdk_reports_unimplemented_endpoint_with_openai_error(
    monkeypatch: Any,
) -> None:
    model_root = Path(__file__).resolve().parents[1]

    class FakeUpstreamResponse:
        status_code = 404
        headers = {"content-type": "application/json"}

        async def aread(self) -> bytes:
            return b'{"error":{"message":"not found"}}'

        async def aclose(self) -> None:
            return None

    class FakeAsyncClient:
        async def __aenter__(self) -> "FakeAsyncClient":
            return self

        async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
            return None

        def build_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
            return {"method": method, "path": path, **kwargs}

        async def send(self, request: dict[str, Any], stream: bool = False) -> FakeUpstreamResponse:
            assert request["path"] == "/v1/embeddings"
            return FakeUpstreamResponse()

    monkeypatch.setattr(server_module, "_mlx_vlm_client", lambda: FakeAsyncClient())

    app = create_app(default_model_path=model_root, public_model_id="cappuccino")
    http_client = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver/v1",
    )
    client = AsyncOpenAI(
        api_key="dummy",
        base_url="http://testserver/v1",
        http_client=http_client,
    )

    with pytest.raises(BadRequestError) as exc_info:
        await client.embeddings.create(model="cappuccino", input="hello")

    assert "does not support the endpoint '/v1/embeddings'" in str(exc_info.value)
    assert exc_info.value.code == "endpoint_not_supported"
    await http_client.aclose()
