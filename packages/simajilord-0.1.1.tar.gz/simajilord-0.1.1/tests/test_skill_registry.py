from __future__ import annotations

from pathlib import Path

import pytest

from cappuccino.skill_registry import SkillRegistry


def test_skill_registry_loads_frontmatter_and_searches_description(tmp_path: Path) -> None:
    skill_dir = tmp_path / "openai-docs"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        """---
name: openai-docs
description: Use when a task needs current OpenAI API documentation and official references.
---

# OpenAI Docs

Read the official docs first.
""",
        encoding="utf-8",
    )

    registry = SkillRegistry.from_path(tmp_path)
    hits = registry.search("official OpenAI API references", limit=1)

    assert registry.skill_count == 1
    assert hits
    assert hits[0].name == "openai-docs"
    assert "description" in hits[0].matched_fields


def test_skill_registry_reads_body_only_when_selected(tmp_path: Path) -> None:
    skill_dir = tmp_path / "playwright"
    skill_dir.mkdir(parents=True)
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(
        """---
name: playwright
description: Browser automation and screenshots.
---

Use Playwright for real browser flows.
""",
        encoding="utf-8",
    )

    registry = SkillRegistry.from_path(tmp_path)
    skill = registry.resolve("playwright")

    assert "Use Playwright" in skill.read_instructions()


def test_skill_registry_rejects_ambiguous_skill_names(tmp_path: Path) -> None:
    for parent_name in ("repo", "user"):
        skill_dir = tmp_path / parent_name / "shared"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            """---
name: shared
description: Shared description.
---

Shared body.
""",
            encoding="utf-8",
        )

    registry = SkillRegistry.from_path(tmp_path)

    with pytest.raises(ValueError, match="Ambiguous skill name"):
        registry.resolve("shared")


def test_skill_registry_honors_allow_implicit_invocation_flag(tmp_path: Path) -> None:
    skill_dir = tmp_path / "explicit-only"
    (skill_dir / "agents").mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        """---
name: explicit-only
description: Only trigger when explicitly requested.
---

Explicit only.
""",
        encoding="utf-8",
    )
    (skill_dir / "agents" / "openai.yaml").write_text(
        """interface:
  display_name: Explicit Only
policy:
  allow_implicit_invocation: false
""",
        encoding="utf-8",
    )

    registry = SkillRegistry.from_path(tmp_path)
    implicit_hits = registry.search(
        "only trigger when explicitly requested",
        limit=5,
        description_only=True,
        implicit_only=True,
    )

    assert implicit_hits == []
