import json
from asyncio import run
from pathlib import Path
from typing import Any

from cappuccino.auto_reasoning import (
    _merge_internal_system_instruction,
    _looks_like_direct_answer,
    run_auto_chat_completion,
    run_on_chat_completion,
)
from cappuccino.reasoning import resolve_reasoning_control


def test_auto_reasoning_runs_checkpoint_then_final_answer(tmp_path: Path) -> None:
    state = {"count": 0}

    async def call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": json.dumps(
                                {
                                    "reasoning_content": "1. Analyze request.\n2. Draft answer.",
                                    "candidate_answer": "",
                                    "continue_thinking": False,
                                    "accept_answer": False,
                                    "confidence": "medium",
                                    "rationale": "enough",
                                },
                                ensure_ascii=False,
                            ),
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "私は AI アシスタントです。",
                    }
                }
            ]
        }

    async def runner() -> dict[str, Any]:
        control = resolve_reasoning_control(
            {"reasoning": {"mode": "auto", "summary": "concise", "max_rounds": 2}}
        )
        return await run_auto_chat_completion(
            payload={
                "model": "local-q6",
                "messages": [{"role": "user", "content": "自己紹介して"}],
                "max_tokens": 64,
            },
            control=control,
            call_model=call_model,
            reasoning_log_path=str(tmp_path / "reasoning.jsonl"),
        )

    body = run(runner())

    assert state["count"] == 2
    message = body["choices"][0]["message"]
    assert message["content"] == "私は AI アシスタントです。"
    assert message["reasoning_content"] == "1. Analyze request.\n2. Draft answer."
    assert "reasoning_summary" in message

    records = [
        json.loads(line)
        for line in (tmp_path / "reasoning.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    assert records


def test_auto_reasoning_can_accept_candidate_answer_without_final_pass(
    tmp_path: Path,
) -> None:
    state = {"count": 0}

    async def call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": json.dumps(
                            {
                                "reasoning_content": "1. Analyze request.",
                                "candidate_answer": "最終回答です。",
                                "continue_thinking": False,
                                "accept_answer": True,
                                "confidence": "high",
                                "rationale": "already done",
                            },
                            ensure_ascii=False,
                        ),
                    }
                }
            ]
        }

    async def runner() -> dict[str, Any]:
        control = resolve_reasoning_control(
            {"reasoning": {"mode": "auto", "summary": "concise", "max_rounds": 2}}
        )
        return await run_auto_chat_completion(
            payload={
                "model": "local-q6",
                "messages": [{"role": "user", "content": "答えて"}],
                "max_tokens": 64,
            },
            control=control,
            call_model=call_model,
            reasoning_log_path=str(tmp_path / "reasoning.jsonl"),
        )

    body = run(runner())

    assert state["count"] == 1
    assert body["choices"][0]["message"]["content"] == "最終回答です。"


def test_auto_reasoning_falls_back_to_single_final_pass_when_checkpoint_is_missing(
    tmp_path: Path,
) -> None:
    state = {"count": 0}

    async def call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "1. Analyze request.\n2. Need more formatting.",
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "fallback final",
                    }
                }
            ]
        }

    async def runner() -> dict[str, Any]:
        control = resolve_reasoning_control(
            {"reasoning": {"mode": "auto", "summary": "concise", "max_rounds": 2}}
        )
        return await run_auto_chat_completion(
            payload={
                "model": "local-q6",
                "messages": [{"role": "user", "content": "答えて"}],
                "max_tokens": 64,
            },
            control=control,
            call_model=call_model,
            reasoning_log_path=str(tmp_path / "reasoning.jsonl"),
        )

    body = run(runner())

    assert state["count"] == 2
    assert body["choices"][0]["message"]["content"] == "fallback final"

    records = [
        json.loads(line)
        for line in (tmp_path / "reasoning.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    assert records[0]["metadata"]["decision"]["source"] == "fallback_heuristic"


def test_on_reasoning_uses_private_json_channel_then_final_answer(tmp_path: Path) -> None:
    state = {"count": 0}

    async def call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": json.dumps(
                                {
                                    "reasoning_content": "1. Problemを整理する。\n2. 回答方針を決める。",
                                    "candidate_answer": "",
                                    "continue_thinking": False,
                                    "accept_answer": False,
                                    "confidence": "medium",
                                    "rationale": "final pass needed",
                                },
                                ensure_ascii=False,
                            ),
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "構造化 reasoning channel で処理します。",
                    }
                }
            ]
        }

    async def runner() -> dict[str, Any]:
        control = resolve_reasoning_control(
            {"reasoning": {"mode": "on", "summary": "concise"}}
        )
        return await run_on_chat_completion(
            payload={
                "model": "local-q6",
                "messages": [{"role": "user", "content": "どう処理する?"}],
                "max_tokens": 64,
            },
            control=control,
            call_model=call_model,
            reasoning_log_path=str(tmp_path / "reasoning.jsonl"),
        )

    body = run(runner())

    assert state["count"] == 2
    message = body["choices"][0]["message"]
    assert message["content"] == "構造化 reasoning channel で処理します。"
    assert message["reasoning_content"] == "1. Problemを整理する。\n2. 回答方針を決める。"
    assert "reasoning_summary" in message


def test_direct_answer_heuristic_rejects_multiline_meta_answer() -> None:
    payload = {
        "messages": [{"role": "user", "content": "2分探索の計算量を一文で答えて"}],
    }

    assert (
        _looks_like_direct_answer(
            "2分探索の計算量は、最悪の場合でも O(log n) である。\nこれを一文で答える必要がある。",
            payload,
        )
        is False
    )


def test_internal_system_instruction_stays_after_leading_developer() -> None:
    merged = _merge_internal_system_instruction(
        messages=[
            {"role": "developer", "content": "Developer guidance."},
            {"role": "user", "content": "hello"},
        ],
        instruction="Internal guidance.",
    )

    assert merged[0]["role"] == "developer"
    assert merged[0]["content"] == "Developer guidance."
    assert merged[1]["role"] == "system"
    assert merged[1]["content"] == "Internal guidance."
    assert merged[2]["role"] == "user"
