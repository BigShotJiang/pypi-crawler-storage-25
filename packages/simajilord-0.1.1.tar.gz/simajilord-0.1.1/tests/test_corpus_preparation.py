import io
import json
import tarfile
import zipfile
from pathlib import Path
from typing import Any

import cappuccino.corpus_preparation as corpus_module
import cappuccino.trainer as trainer_module
from cappuccino.corpus_preparation import (
    _clean_aozora_body,
    inspect_prepared_dataset_status,
    parse_manifest_dataset_specs,
    prepare_aozora_bunko_cpt,
    prepare_github_repositories_cpt,
    prepare_input_output_txt_sft,
    prepare_kaken_cpt,
    prepare_kokkai_cpt,
    prepare_kotobank_cpt,
    prepare_ndl_next_digital_library_cpt,
    prepare_openai_docs_cpt,
    prepare_pixiv_dictionary_cpt,
    prepare_pixiv_novels_cpt,
    prepare_wikipedia_cited_sources_cpt,
    prepare_wikipedia_cpt,
    prepare_wikipedia_recent_changes_cpt,
)
from cappuccino.dataset_manifests import load_sequential_cpt_manifest
from cappuccino.model_inspector import ModelCapabilities, ModelProfile, ModelQuantization
from cappuccino.trainer import LoRAHyperparameters, MemoryEstimate, TrainerConfig, run_training


def test_prepare_input_output_txt_sft_writes_chat_records_and_manifest(tmp_path: Path) -> None:
    source_dir = tmp_path / "style"
    source_dir.mkdir()
    (source_dir / "0001.txt").write_text(
        "input\n質問です\noutput\n回答です\n",
        encoding="utf-8",
    )

    report = prepare_input_output_txt_sft(
        input_dir=source_dir,
        output_dir=tmp_path / "out",
        copy_source=True,
        repeat=2,
    )

    assert report.kind == "input_output_txt_sft"
    assert report.total_records == 1
    dataset_path = Path(report.output_paths["sft"])
    record = json.loads(dataset_path.read_text(encoding="utf-8").splitlines()[0])
    assert record["task_type"] == "chat_sft"
    assert record["messages"][0]["content"] == "質問です"
    assert record["messages"][1]["content"] == "回答です"

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 2


def test_prepare_input_output_txt_sft_skips_invalid_files_with_warning(tmp_path: Path) -> None:
    source_dir = tmp_path / "style"
    source_dir.mkdir()
    (source_dir / "0001.txt").write_text(
        "input\n質問です\noutput\n回答です\n",
        encoding="utf-8",
    )
    (source_dir / "0002.txt").write_text(
        "このファイルは形式が違います\n",
        encoding="utf-8",
    )

    report = prepare_input_output_txt_sft(
        input_dir=source_dir,
        output_dir=tmp_path / "out",
        copy_source=True,
        repeat=2,
    )

    assert report.total_records == 1
    assert report.source_paths == [str((source_dir / "0001.txt").resolve())]
    assert report.warnings == [
        "Skipped 0002.txt: input/output markers were not found in txt training file."
    ]


def test_parse_manifest_dataset_specs_supports_repeat_and_label(tmp_path: Path) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text("", encoding="utf-8")

    parsed = parse_manifest_dataset_specs([f"{dataset_path}::3::demo"])

    assert len(parsed) == 1
    assert parsed[0].repeat == 3
    assert parsed[0].label == "demo"
    assert parsed[0].path == str(dataset_path.resolve())


def test_prepare_pixiv_novels_cpt_writes_full_text_and_bonus_copy(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_default_pixiv_ranking_tasks",
        lambda: [{"mode": "weekly", "page": 1}],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_pixiv_ranking_items",
        lambda *, mode, page: ([{"id": "42", "user_id": "7"}], False),
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_pixiv_user_novel_ids",
        lambda user_id: [],
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_pixiv_json",
        lambda url, *, referer: {
            "body": {
                "title": "完全版",
                "content": "これは全文です。\n続きも入っています。",
                "bookmarkCount": 100,
                "isOriginal": True,
                "restrict": 1,
                "xRestrict": 1,
            }
        },
    )

    report = prepare_pixiv_novels_cpt(output_dir=tmp_path / "pixiv")

    base_shards = sorted((tmp_path / "pixiv" / "shards").glob("*.jsonl"))
    bonus_shards = sorted((tmp_path / "pixiv" / "original_bonus_shards").glob("*.jsonl"))
    assert len(base_shards) == 1
    assert len(bonus_shards) == 1
    base_record = json.loads(base_shards[0].read_text(encoding="utf-8").splitlines()[0])
    bonus_record = json.loads(bonus_shards[0].read_text(encoding="utf-8").splitlines()[0])
    assert "これは全文です。" in base_record["text"]
    assert base_record["text"] == bonus_record["text"]

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert len(manifest.datasets) == 2


def test_prepare_pixiv_novels_cpt_splits_long_text_on_natural_boundaries(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(corpus_module, "JAPANESE_LONG_RECORD_MAX_CHARS", 40)
    monkeypatch.setattr(
        corpus_module,
        "_default_pixiv_ranking_tasks",
        lambda: [{"mode": "weekly", "page": 1}],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_pixiv_ranking_items",
        lambda *, mode, page: ([{"id": "42", "user_id": "7"}], False),
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_pixiv_user_novel_ids",
        lambda user_id: [],
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_pixiv_json",
        lambda url, *, referer: {
            "body": {
                "title": "長編",
                "content": "第一章\n\n" + ("あ" * 28) + "\n\n" + ("い" * 28),
                "bookmarkCount": 100,
                "isOriginal": True,
                "restrict": 0,
                "xRestrict": 0,
            }
        },
    )

    prepare_pixiv_novels_cpt(output_dir=tmp_path / "pixiv")

    base_shard = next((tmp_path / "pixiv" / "shards").glob("*.jsonl"))
    records = [
        json.loads(line)
        for line in base_shard.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(records) == 2
    assert records[0]["metadata"]["part_index"] == 1
    assert records[1]["metadata"]["part_index"] == 2
    assert records[0]["metadata"]["part_count"] == 2
    assert records[0]["text"].startswith("長編")
    assert "あ" * 28 in records[0]["text"]
    assert "い" * 28 in records[1]["text"]


def test_prepare_kokkai_cpt_groups_entire_meeting_and_tracks_progress(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    captured_calls: list[dict[str, int]] = []

    def fake_fetch(
        *,
        start_record: int,
        maximum_records: int,
        session_from: int,
        session_to: int,
    ) -> dict[str, Any]:
        captured_calls.append(
            {
                "start_record": start_record,
                "maximum_records": maximum_records,
                "session_from": session_from,
                "session_to": session_to,
            }
        )
        return {
            "numberOfRecords": 2,
            "numberOfReturn": 1,
            "startRecord": start_record,
            "nextRecordPosition": 2,
            "meetingRecord": [
                {
                    "issueID": "issue-1",
                    "session": 221,
                    "nameOfHouse": "衆議院",
                    "nameOfMeeting": "予算委員会",
                    "issue": "第1号",
                    "date": "2026-03-19",
                    "meetingURL": "https://example.invalid/meeting-1",
                    "speechRecord": [
                        {
                            "speechID": "a",
                            "speaker": "会議録情報",
                            "speech": "会議情報本文",
                        },
                        {
                            "speechID": "b",
                            "speaker": "山田太郎",
                            "speech": "○山田議員　答弁本文です。\r\n続きます。",
                        },
                    ],
                }
            ],
        }

    monkeypatch.setattr(corpus_module, "_fetch_kokkai_meeting_batch", fake_fetch)
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_kokkai_cpt(
        output_dir=tmp_path / "kokkai",
        max_meetings_per_run=1,
        records_per_shard=8,
        repeat=1,
        request_interval_sec=0.0,
    )

    assert report.kind == "kokkai_cpt"
    assert report.total_records == 1
    assert captured_calls == [
        {
            "start_record": 1,
            "maximum_records": 1,
            "session_from": 1,
            "session_to": 999,
        }
    ]
    shard_path = next((tmp_path / "kokkai" / "shards").glob("kokkai_*.jsonl"))
    record = json.loads(shard_path.read_text(encoding="utf-8").splitlines()[0])
    assert record["text"] == "予算委員会\n第1号\n2026-03-19\n\n会議情報本文\n\n○山田議員 答弁本文です。\n続きます。"
    assert record["metadata"]["speech_count"] == 2
    assert record["metadata"]["issue_id"] == "issue-1"

    state = json.loads((tmp_path / "kokkai" / "progress.json").read_text(encoding="utf-8"))
    assert state["next_start_record"] == 2
    assert state["api_mode"] == "meeting"
    assert state["completed"] is False

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 1


def test_prepare_kokkai_cpt_splits_long_meeting_by_speech_blocks(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(corpus_module, "JAPANESE_LONG_RECORD_MAX_CHARS", 60)

    def fake_fetch(
        *,
        start_record: int,
        maximum_records: int,
        session_from: int,
        session_to: int,
    ) -> dict[str, Any]:
        return {
            "numberOfRecords": 1,
            "numberOfReturn": 1,
            "startRecord": start_record,
            "nextRecordPosition": None,
            "meetingRecord": [
                {
                    "issueID": "issue-2",
                    "session": 221,
                    "nameOfHouse": "衆議院",
                    "nameOfMeeting": "本会議",
                    "issue": "第2号",
                    "date": "2026-03-20",
                    "meetingURL": "https://example.invalid/meeting-2",
                    "speechRecord": [
                        {"speechID": "a", "speech": "○甲議員　" + ("あ" * 30)},
                        {"speechID": "b", "speech": "○乙議員　" + ("い" * 30)},
                    ],
                }
            ],
        }

    monkeypatch.setattr(corpus_module, "_fetch_kokkai_meeting_batch", fake_fetch)
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_kokkai_cpt(
        output_dir=tmp_path / "kokkai",
        max_meetings_per_run=1,
        records_per_shard=8,
        repeat=1,
        request_interval_sec=0.0,
    )

    assert report.total_records == 2
    shard_path = next((tmp_path / "kokkai" / "shards").glob("kokkai_*.jsonl"))
    records = [
        json.loads(line)
        for line in shard_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(records) == 2
    assert records[0]["metadata"]["meeting_part_index"] == 1
    assert records[1]["metadata"]["meeting_part_index"] == 2
    assert records[0]["metadata"]["meeting_part_count"] == 2
    assert "○甲議員" in records[0]["text"]
    assert "○乙議員" in records[1]["text"]


def test_prepare_openai_docs_cpt_collects_docs_and_reference_pages(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_sitemap_index_urls",
        lambda url: ["https://developers.openai.com/sitemap-0.xml"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_urlset_urls",
        lambda url: [
            "https://developers.openai.com/api/docs/models",
            "https://developers.openai.com/api/reference/resources/responses/methods/retrieve",
            "https://developers.openai.com/cookbook/examples/ignore-me",
        ],
    )

    def fake_http_get_text(url: str, **kwargs: Any) -> str:
        if url.endswith("/index.md"):
            return "# Retrieve response\n\nReturn a stored response."
        if url == "https://developers.openai.com/api/docs/models":
            return (
                "<html><body><main><h1>Models</h1><p>Choose the right model.</p>"
                "<nav>Ignore this nav text.</nav></main></body></html>"
            )
        raise AssertionError(f"unexpected URL {url}")

    monkeypatch.setattr(corpus_module, "_http_get_text", fake_http_get_text)

    report = prepare_openai_docs_cpt(
        output_dir=tmp_path / "openai",
        max_pages_per_run=None,
        records_per_shard=8,
        repeat=2,
    )

    assert report.kind == "openai_docs_cpt"
    assert report.total_records == 2
    shard_path = next((tmp_path / "openai" / "shards").glob("openai_docs_*.jsonl"))
    records = [
        json.loads(line)
        for line in shard_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert [record["metadata"]["url"] for record in records] == [
        "https://developers.openai.com/api/docs/models",
        "https://developers.openai.com/api/reference/resources/responses/methods/retrieve",
    ]
    assert records[0]["text"].startswith("models\n\nModels")
    assert "Ignore this nav text" not in records[0]["text"]
    assert records[1]["text"] == "Retrieve response\n\nReturn a stored response."

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 2


def test_prepare_openai_docs_cpt_splits_large_reference_pages_on_headings(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_sitemap_index_urls",
        lambda url: ["https://developers.openai.com/sitemap-0.xml"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_urlset_urls",
        lambda url: ["https://developers.openai.com/api/reference/resources/responses"],
    )
    monkeypatch.setattr(corpus_module, "OPENAI_DOC_SECTION_MAX_CHARS", 120)

    def fake_http_get_text(url: str, **kwargs: Any) -> str:
        if url.endswith("/index.md"):
            return (
                "# Responses\n\n"
                + "Intro paragraph.\n\n"
                + "## Create a response\n\n"
                + ("A" * 90)
                + "\n\n"
                + "## Retrieve a response\n\n"
                + ("B" * 90)
            )
        raise AssertionError(f"unexpected URL {url}")

    monkeypatch.setattr(corpus_module, "_http_get_text", fake_http_get_text)

    report = prepare_openai_docs_cpt(
        output_dir=tmp_path / "openai",
        max_pages_per_run=None,
        records_per_shard=8,
        repeat=2,
    )

    shard_path = next((tmp_path / "openai" / "shards").glob("openai_docs_*.jsonl"))
    records = [
        json.loads(line)
        for line in shard_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert report.total_records == len(records)
    assert len(records) > 1
    assert records[0]["metadata"]["section_count"] == len(records)
    assert records[0]["metadata"]["section_index"] == 1
    assert records[-1]["metadata"]["section_index"] == len(records)
    assert all(record["metadata"]["title"] == "Responses" for record in records)
    state = json.loads((tmp_path / "openai" / "progress.json").read_text(encoding="utf-8"))
    assert state["last_url"] == "https://developers.openai.com/api/reference/resources/responses"


def test_prepare_kaken_cpt_flattens_html_and_follows_report_pages(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_kaken_project_urls",
        lambda: ["https://kaken.nii.ac.jp/grant/KAKENHI-PROJECT-24240014/"],
    )

    def fake_http_get_text(url: str, **kwargs: Any) -> str:
        if url == "https://kaken.nii.ac.jp/grant/KAKENHI-PROJECT-24240014/":
            return """
<div class="page-title project"><h1>創発的な創作活動の研究</h1></div>
<table class="summary-table">
  <tr><th>研究課題/領域番号</th><td>24240014</td></tr>
  <tr><th>研究種目</th><td><a>基盤研究(A)</a></td></tr>
  <tr><th>キーワード</th><td>人工知能 / 協調制作</td></tr>
  <tr><th>研究成果の概要</th><td><p>概要本文です。<br />続きです。</p></td></tr>
</table>
<a href="/report/KAKENHI-PROJECT-24240014/242400142014jisseki/">Annual</a>
<a href="/report/KAKENHI-PROJECT-24240014/24240014seika/">Final</a>
"""
        if url.endswith("242400142014jisseki/"):
            return """
<div class="report-title"><h2>2014年度 実績報告書</h2></div>
<table class="summary-table">
  <tr><th>研究実績の概要</th><td><p>年次本文です。<br />改行あり。</p></td></tr>
  <tr><th>今後の研究の推進方策</th><td><p>今後の方策です。</p></td></tr>
</table>
"""
        if url.endswith("24240014seika/"):
            return """
<div class="report-title"><h2>最終報告書</h2></div>
<table class="summary-table">
  <tr><th>研究成果の概要</th><td><p>最終成果です。</p></td></tr>
</table>
"""
        raise AssertionError(f"unexpected URL {url}")

    monkeypatch.setattr(corpus_module, "_http_get_text", fake_http_get_text)
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_kaken_cpt(output_dir=tmp_path / "kaken", repeat=2, request_interval_sec=0.0)

    shard_path = next((tmp_path / "kaken" / "shards").glob("kaken_*.jsonl"))
    record = json.loads(shard_path.read_text(encoding="utf-8").splitlines()[0])
    assert report.kind == "kaken_cpt"
    assert report.total_records >= 1
    assert record["metadata"]["project_id"] == "24240014"
    assert "<p>" not in record["text"]
    assert "研究課題/領域番号: 24240014" in record["text"]
    assert "2014年度 実績報告書" in record["text"]
    assert "年次本文です。" in record["text"]
    assert "最終成果です。" in record["text"]
    assert (tmp_path / "kaken" / "seen_project_ids.txt").read_text(encoding="utf-8").splitlines() == ["24240014"]

    state = json.loads((tmp_path / "kaken" / "progress.json").read_text(encoding="utf-8"))
    assert state["processed_projects"] == 1
    assert state["pending_project_urls"] == []

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 2


def test_load_ndl_next_digital_library_catalog_entries_filters_public_domain_and_deduplicates(
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_ndl_next_digital_library_catalog_urls",
        lambda: ["https://example.invalid/t.zip", "https://example.invalid/k.zip"],
    )

    def build_catalog_zip(tsv_text: str) -> bytes:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, mode="w") as archive:
            archive.writestr("catalog.tsv", tsv_text)
        return buffer.getvalue()

    catalog_payloads = {
        "https://example.invalid/t.zip": build_catalog_zip(
            "\n".join(
                [
                    "永続的識別子\tタイトル\t巻次又は部編番号\t著者\t出版者\t出版日\t容量・大きさ\t分類（NDC9）\t件名（NDLSH）\t公開範囲\t権利区分",
                    "info:ndljp/pid/100\t図書A\t上\t著者A\t出版社A\t1920\t123p\t913\t小説\tインターネット公開\t保護期間満了",
                    "info:ndljp/pid/101\t図書B\t\t著者B\t出版社B\t1921\t50p\t914\t随筆\tインターネット公開\t許諾",
                    "info:ndljp/pid/100\t図書A\t上\t著者A\t出版社A\t1920\t123p\t913\t小説\tインターネット公開\t保護期間満了",
                ]
            )
            + "\n"
        ),
        "https://example.invalid/k.zip": build_catalog_zip(
            "\n".join(
                [
                    "永続的識別子\tタイトル\t巻次又は部編番号\t著者\t出版者\t出版日\t容量・大きさ\t件名\tコレクション\t公開範囲\t権利区分",
                    "info:ndljp/pid/200\t古典A\t巻一\t\t\t1850\t1冊\t記録\t古典籍\tインターネット公開\t保護期間満了",
                ]
            )
            + "\n"
        ),
    }

    monkeypatch.setattr(corpus_module, "_http_get_bytes", lambda url, **kwargs: catalog_payloads[url])

    entries = corpus_module._load_ndl_next_digital_library_catalog_entries()

    assert [entry.pid for entry in entries] == ["100", "200"]
    assert entries[0].title == "図書A"
    assert entries[0].catalog_source_url == "https://example.invalid/t.zip"
    assert entries[1].collection == "古典籍"


def test_prepare_ndl_next_digital_library_cpt_uses_catalog_entries_and_fulltext(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_ndl_next_digital_library_catalog_entries",
        lambda: [
            corpus_module.NdlNextDigitalLibraryCatalogEntry(
                pid="897115",
                title="帝国図書館一覧",
                volume="",
                responsibility="",
                publisher="帝国図書館",
                published="1901",
                size="62p",
                subjects="図書館",
                ndc="010",
                collection="",
                catalog_source_url="https://example.invalid/catalog.zip",
            )
        ],
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_ndl_next_digital_library_fulltext",
        lambda pid: {
            "list": [
                {"contents": "目次です。"},
                {"contents": "本文です。"},
            ]
        },
    )
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_ndl_next_digital_library_cpt(
        output_dir=tmp_path / "ndl",
        repeat=2,
        request_interval_sec=0.0,
    )

    assert report.kind == "ndl_next_digital_library_cpt"
    assert report.total_records == 1
    shard_path = next((tmp_path / "ndl" / "shards").glob("ndl_next_digital_library_*.jsonl"))
    record = json.loads(shard_path.read_text(encoding="utf-8").splitlines()[0])
    assert record["metadata"]["pid"] == "897115"
    assert "出版者: 帝国図書館" in record["text"]
    assert "目次です。" in record["text"]
    assert "本文です。" in record["text"]

    state = json.loads((tmp_path / "ndl" / "progress.json").read_text(encoding="utf-8"))
    assert state["processed_pids"] == 1
    assert state["pending_retry_pids"] == []

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 2


def test_prepare_github_repositories_cpt_extracts_text_files_only(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_iter_github_repositories",
        lambda *, min_stars: iter(
            [
                {
                    "full_name": "octo/demo",
                    "name": "demo",
                    "default_branch": "main",
                    "stargazers_count": 1234,
                    "html_url": "https://github.com/octo/demo",
                    "owner": {"login": "octo"},
                }
            ]
        ),
    )

    archive_buffer = io.BytesIO()
    with tarfile.open(fileobj=archive_buffer, mode="w:gz") as archive:
        files = {
            "demo-main/README.md": "# Demo\n\nRepository overview.\n",
            "demo-main/src/app.py": "print('hello')\n",
            "demo-main/dist/bundle.js": "bundled = true;\n",
            "demo-main/assets/logo.png": "\x89PNG",
        }
        for name, text in files.items():
            payload = text.encode("utf-8", errors="ignore")
            info = tarfile.TarInfo(name=name)
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))

    monkeypatch.setattr(corpus_module, "_http_get_bytes", lambda url, **kwargs: archive_buffer.getvalue())
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_github_repositories_cpt(
        output_dir=tmp_path / "github",
        min_stars=10000,
        max_repos_per_run=1,
        records_per_shard=8,
        repeat=1,
        request_interval_sec=0.0,
    )

    assert report.kind == "github_repositories_cpt"
    assert report.total_records == 2
    assert report.warnings == [
        "GITHUB_TOKEN is not set. GitHub Search API rate limits will be much lower, so full discovery will be slow."
    ]
    shard_path = next((tmp_path / "github" / "shards").glob("github_repositories_*.jsonl"))
    records = [
        json.loads(line)
        for line in shard_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert [record["metadata"]["file_path"] for record in records] == ["README.md", "src/app.py"]
    assert records[0]["metadata"]["repository"] == "octo/demo"
    assert "Repository overview." in records[0]["text"]
    assert "bundled = true" not in "".join(record["text"] for record in records)
    assert (tmp_path / "github" / "processed_repo_names.txt").read_text(encoding="utf-8").strip() == "octo/demo"

    manifest = load_sequential_cpt_manifest(report.output_paths["manifest"])
    assert manifest is not None
    assert manifest.datasets[0].repeat == 1


def test_prepare_kotobank_cpt_separates_dictionary_manifests(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_sitemap_index_urls",
        lambda url: ["https://kotobank.example/sitemap_001.xml.gz"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_urlset_urls",
        lambda url: ["https://kotobank.jp/word/example"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_http_get_text",
        lambda url, **kwargs: """
<article class="dictype cf daijisen">
  <h2><a href="/dictionary/daijisen/1/">デジタル大辞泉</a></h2>
  <div class="ex cf">
    <h3>見出し</h3>
    <section class="description">
      本文です。<div class="media">広告</div><br clear="all">更新日: 2026-03-26
    </section>
  </div>
</article>
""",
    )

    report = prepare_kotobank_cpt(output_dir=tmp_path / "kotobank", repeat=2)

    dictionary_dirs = [path for path in (tmp_path / "kotobank" / "dictionary_shards").iterdir() if path.is_dir()]
    assert len(dictionary_dirs) == 1
    record = json.loads(next(dictionary_dirs[0].glob("*.jsonl")).read_text(encoding="utf-8").splitlines()[0])
    assert "本文です。" in record["text"]
    assert "更新日" not in record["text"]
    manifest = load_sequential_cpt_manifest(report.output_paths["base_manifest"])
    assert manifest is not None
    assert len(manifest.datasets) == 1


def test_clean_aozora_body_strips_leading_metadata_and_guide_block() -> None:
    raw_text = """作品タイトル
著者名
翻訳者訳

-------------------------------------------------------
【テキスト中に現れる記号について】
《》：ルビ
-------------------------------------------------------

［＃ここから１段階小さな文字］
本文の前書き、
［＃ここで小さな文字終わり］

　ここから本文です。
"""

    cleaned = _clean_aozora_body(raw_text, title="作品タイトル")

    assert "作品タイトル" not in cleaned
    assert "著者名" not in cleaned
    assert "翻訳者訳" not in cleaned
    assert cleaned.startswith("本文の前書き、")
    assert "ここから本文です。" in cleaned


def test_prepare_aozora_bunko_cpt_resumes_without_duplicate_works(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    output_dir = tmp_path / "aozora"
    shards_dir = output_dir / "shards"
    shards_dir.mkdir(parents=True)
    (shards_dir / "aozora_bunko_00001.jsonl").write_text(
        json.dumps(
            {
                "task_type": "cpt",
                "text": "既存作品\n\n既存本文です。",
                "focus": ["knowledge", "style"],
                "metadata": {"source_label": "aozora_bunko", "title": "既存作品", "work_id": "000001"},
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (output_dir / "progress.json").write_text('{"next_work_index": 0, "completed": false}\n', encoding="utf-8")

    monkeypatch.setattr(
        corpus_module,
        "_iter_aozora_public_domain_works",
        lambda: iter(
            [
                {"作品ID": "000001", "作品名": "既存作品", "テキストファイルURL": "https://example.invalid/1.txt"},
                {"作品ID": "000002", "作品名": "新規作品", "テキストファイルURL": "https://example.invalid/2.txt"},
            ]
        ),
    )
    monkeypatch.setattr(
        corpus_module,
        "_download_aozora_body",
        lambda text_url: "新規作品\n著者\n\n本文です。" if text_url.endswith("2.txt") else "既存作品\n著者\n\n既存本文です。",
    )

    report = prepare_aozora_bunko_cpt(output_dir=output_dir, max_works_per_run=2, repeat=1)

    records = [
        json.loads(line)
        for path in sorted(shards_dir.glob("aozora_bunko_*.jsonl"))
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert report.total_records == 2
    assert len(records) == 2
    assert {record["metadata"]["work_id"] for record in records} == {"000001", "000002"}
    assert (output_dir / "seen_work_ids.txt").read_text(encoding="utf-8").splitlines() == ["000001", "000002"]
    state = json.loads((output_dir / "progress.json").read_text(encoding="utf-8"))
    assert state["processed_works"] == 2
    assert state["next_work_index"] == 2


def test_prepare_pixiv_dictionary_cpt_reads_article_from_swr_fallback(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_load_sitemap_index_urls",
        lambda url: ["https://dic.pixiv.net/sitemap/part/1"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_load_urlset_urls",
        lambda url: ["https://dic.pixiv.net/a/example"],
    )
    monkeypatch.setattr(
        corpus_module,
        "_http_get_text",
        lambda url, **kwargs: json.dumps(
            {
                "props": {
                    "pageProps": {
                        "swrFallback": {
                            '@"openapi-","/get_article/{tagName}",#params:#query:#lang:"ja",,path:#tagName:"初音ミク",,,,': {
                                "tagName": "初音ミク",
                                "yomigana": "はつねみく",
                                "abstract": "概要本文",
                                "text": "本文だけです。",
                            }
                        },
                        "initialSwrFallback": {
                            '@"openapi-","/get_attentions",#params:#query:#lang:"ja",,,,': []
                        },
                    }
                }
            },
            ensure_ascii=False,
        ).join(
            [
                '<script id="__NEXT_DATA__" type="application/json">',
                "</script>",
            ]
        ),
    )

    report = prepare_pixiv_dictionary_cpt(output_dir=tmp_path / "pixiv_dictionary")

    shard_paths = sorted((tmp_path / "pixiv_dictionary" / "shards").glob("*.jsonl"))
    assert len(shard_paths) == 1
    record = json.loads(shard_paths[0].read_text(encoding="utf-8").splitlines()[0])
    assert record["metadata"]["title"] == "初音ミク"
    assert "本文だけです。" in record["text"]
    assert report.total_records == 1


def test_fetch_wikipedia_page_batch_sets_user_agent(monkeypatch: Any) -> None:
    captured_headers: dict[str, str] = {}

    class FakeResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, Any]:
            return {"query": {"pages": {}}}

    class FakeClient:
        def __init__(self, **kwargs: Any) -> None:
            captured_headers.update(kwargs.get("headers", {}))

        def __enter__(self) -> "FakeClient":
            return self

        def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
            return None

        def get(self, url: str, params: dict[str, Any]) -> FakeResponse:
            return FakeResponse()

    monkeypatch.setattr(corpus_module.httpx, "Client", FakeClient)

    payload = corpus_module._fetch_wikipedia_page_batch(language="ja", continuation=None)

    assert payload == {"query": {"pages": {}}}
    assert "User-Agent" in captured_headers
    assert captured_headers["User-Agent"]


def test_prepare_wikipedia_cpt_emits_text_and_image_grounded_records(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_fetch_wikipedia_page_batch",
        lambda **kwargs: {
            "query": {
                "pages": {
                    "1": {
                        "pageid": 1,
                        "title": "富士山",
                        "extract": "日本一高い山です。",
                        "fullurl": "https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
                        "pageimage": "Mount_Fuji.jpg",
                        "thumbnail": {
                            "source": "https://upload.wikimedia.org/thumb/fuji.jpg/1024px-fuji.jpg",
                        },
                        "original": {
                            "source": "https://upload.wikimedia.org/fuji.jpg",
                        },
                    }
                }
            }
        },
    )

    report = prepare_wikipedia_cpt(
        output_dir=tmp_path / "wikipedia",
        max_pages_per_run=1,
        repeat=2,
        include_images=True,
    )

    shard_paths = sorted((tmp_path / "wikipedia" / "shards").glob("wikipedia_*.jsonl"))
    records = [
        json.loads(line)
        for path in shard_paths
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert report.total_records == 2
    assert len(records) == 2
    assert any(record["task_type"] == "cpt" for record in records)
    image_record = next(record for record in records if record["task_type"] == "chat_sft")
    assert image_record["messages"][0]["content"][0] == {
        "type": "input_image",
        "image_url": "https://upload.wikimedia.org/thumb/fuji.jpg/1024px-fuji.jpg",
        "detail": "auto",
    }
    assert image_record["messages"][0]["content"][1]["type"] == "text"
    assert "Wikipedia記事" in image_record["messages"][0]["content"][1]["text"]
    assert image_record["messages"][1]["content"] == "富士山\n\n日本一高い山です。"
    assert image_record["focus"] == ["knowledge", "multimodal", "vision"]
    assert image_record["metadata"]["lead_image_url"] == "https://upload.wikimedia.org/thumb/fuji.jpg/1024px-fuji.jpg"
    assert image_record["metadata"]["lead_image_original_url"] == "https://upload.wikimedia.org/fuji.jpg"
    assert report.warnings == [
        "Wikipedia lead images are emitted as multimodal chat_sft examples. "
        "The current trainer preserves vision tokens but does not fine-tune the vision encoder itself."
    ]


def test_prepare_wikipedia_cpt_resumes_without_duplicate_pages(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    output_dir = tmp_path / "wikipedia"
    shards_dir = output_dir / "shards"
    shards_dir.mkdir(parents=True)
    (shards_dir / "wikipedia_00001.jsonl").write_text(
        json.dumps(
            {
                "task_type": "cpt",
                "text": "富士山\n\n既存本文です。",
                "focus": ["knowledge"],
                "metadata": {
                    "source_label": "wikipedia",
                    "language": "ja",
                    "title": "富士山",
                    "pageid": 1,
                    "url": "https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
                },
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (output_dir / "progress.json").write_text(
        '{"language": "ja", "continue": {"continue": "||info|pageimages"}, "completed": false}\n',
        encoding="utf-8",
    )
    monkeypatch.setattr(corpus_module, "_fetch_wikipedia_article_count", lambda language: 100)
    monkeypatch.setattr(
        corpus_module,
        "_fetch_wikipedia_page_batch",
        lambda **kwargs: {
            "query": {
                "pages": {
                    "1": {
                        "pageid": 1,
                        "title": "富士山",
                        "extract": "重複してはいけない本文です。",
                        "fullurl": "https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
                    },
                    "2": {
                        "pageid": 2,
                        "title": "筑波山",
                        "extract": "新規本文です。",
                        "fullurl": "https://ja.wikipedia.org/wiki/%E7%AD%91%E6%B3%A2%E5%B1%B1",
                    },
                }
            }
        },
    )

    report = prepare_wikipedia_cpt(
        output_dir=output_dir,
        max_pages_per_run=2,
        repeat=1,
        include_images=False,
    )

    records = [
        json.loads(line)
        for path in sorted(shards_dir.glob("wikipedia_*.jsonl"))
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert report.total_records == 2
    assert len(records) == 2
    assert {str(record["metadata"]["pageid"]) for record in records} == {"1", "2"}
    assert (output_dir / "seen_page_ids.txt").read_text(encoding="utf-8").splitlines() == ["1", "2"]
    state = json.loads((output_dir / "progress.json").read_text(encoding="utf-8"))
    assert state["processed_pages"] == 2
    assert state["approximate_total_articles"] == 100


def test_prepare_wikipedia_recent_changes_cpt_emits_append_only_records(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    monkeypatch.setattr(
        corpus_module,
        "_fetch_wikipedia_recent_changes_batch",
        lambda **kwargs: {
            "query": {
                "recentchanges": [
                    {
                        "rcid": 10,
                        "pageid": 1,
                        "type": "edit",
                        "timestamp": "2026-03-28T13:48:26Z",
                        "revid": 123,
                        "old_revid": 122,
                    }
                ]
            }
        },
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_wikipedia_page_by_id",
        lambda **kwargs: {
            "pageid": 1,
            "title": "富士山",
            "extract": "更新後の本文です。",
            "fullurl": "https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
            "lastrevid": 123,
            "touched": "2026-03-28T13:48:26Z",
            "revisions": [{"revid": 123, "timestamp": "2026-03-28T13:48:26Z"}],
        },
    )
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_wikipedia_recent_changes_cpt(
        output_dir=tmp_path / "wikipedia_recent_changes",
        max_changes_per_run=1,
        include_images=False,
    )

    shard_path = next((tmp_path / "wikipedia_recent_changes" / "shards").glob("wikipedia_recent_changes_*.jsonl"))
    record = json.loads(shard_path.read_text(encoding="utf-8").splitlines()[0])
    state = json.loads((tmp_path / "wikipedia_recent_changes" / "progress.json").read_text(encoding="utf-8"))

    assert report.kind == "wikipedia_recent_changes_cpt"
    assert record["metadata"]["source_label"] == "wikipedia_recent_changes"
    assert record["metadata"]["change_id"] == "10"
    assert record["metadata"]["change_type"] == "edit"
    assert record["metadata"]["lastrevid"] == 123
    assert state["processed_changes"] == 1
    assert "10" in (tmp_path / "wikipedia_recent_changes" / "seen_change_ids.txt").read_text(encoding="utf-8")


def test_prepare_wikipedia_cited_sources_cpt_uses_source_shards_and_deduplicates_per_source_page(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    source_dir = tmp_path / "wikipedia"
    source_shards = source_dir / "shards"
    source_shards.mkdir(parents=True)
    source_record = {
        "task_type": "cpt",
        "text": "富士山\n\n本文です。",
        "focus": ["knowledge"],
        "metadata": {
            "source_label": "wikipedia",
            "language": "ja",
            "title": "富士山",
            "pageid": 1,
            "url": "https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
            "lastrevid": 123,
            "revision_timestamp": "2026-03-28T13:48:26Z",
        },
    }
    (source_shards / "wikipedia_00001.jsonl").write_text(
        "\n".join(
            [
                json.dumps(source_record, ensure_ascii=False),
                json.dumps(source_record, ensure_ascii=False),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (source_dir / "progress.json").write_text(
        json.dumps({"dataset_kind": "wikipedia_cpt", "completed": True}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_wikipedia_parsed_html",
        lambda **kwargs: '<div><ol class="references"><li><a href="https://example.com/ref1">ref</a></li></ol></div>',
    )
    monkeypatch.setattr(
        corpus_module,
        "_fetch_reference_document",
        lambda url: corpus_module.WikipediaReferenceDocument(
            url=url,
            final_url=url,
            title="参照先",
            text="HTML を除いた本文です。",
            content_type="text/html",
            source_format="html",
        ),
    )
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_wikipedia_cited_sources_cpt(
        source_wikipedia_dir=source_dir,
        output_dir=tmp_path / "wikipedia_cited_sources",
        max_pages_per_run=2,
    )

    shard_path = next((tmp_path / "wikipedia_cited_sources" / "shards").glob("wikipedia_cited_sources_*.jsonl"))
    records = [json.loads(line) for line in shard_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    state = json.loads((tmp_path / "wikipedia_cited_sources" / "progress.json").read_text(encoding="utf-8"))

    assert report.kind == "wikipedia_cited_sources_cpt"
    assert len(records) == 1
    assert records[0]["metadata"]["source_label"] == "wikipedia_cited_source"
    assert records[0]["metadata"]["source_pageid"] == 1
    assert records[0]["metadata"]["reference_url"] == "https://example.com/ref1"
    assert state["processed_source_pages"] == 1
    assert "1:123" in (tmp_path / "wikipedia_cited_sources" / "seen_source_keys.txt").read_text(encoding="utf-8")


def test_prepare_wikipedia_cited_sources_cpt_deduplicates_across_source_pages_by_url_and_text(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    source_dir = tmp_path / "wikipedia"
    source_shards = source_dir / "shards"
    source_shards.mkdir(parents=True)
    source_records = [
        {
            "task_type": "cpt",
            "text": "記事A\n\n本文です。",
            "focus": ["knowledge"],
            "metadata": {
                "source_label": "wikipedia",
                "language": "ja",
                "title": "記事A",
                "pageid": 1,
                "url": "https://ja.wikipedia.org/wiki/A",
                "lastrevid": 101,
                "revision_timestamp": "2026-03-28T13:48:26Z",
            },
        },
        {
            "task_type": "cpt",
            "text": "記事B\n\n本文です。",
            "focus": ["knowledge"],
            "metadata": {
                "source_label": "wikipedia",
                "language": "ja",
                "title": "記事B",
                "pageid": 2,
                "url": "https://ja.wikipedia.org/wiki/B",
                "lastrevid": 202,
                "revision_timestamp": "2026-03-28T13:48:27Z",
            },
        },
    ]
    (source_shards / "wikipedia_00001.jsonl").write_text(
        "\n".join(json.dumps(record, ensure_ascii=False) for record in source_records) + "\n",
        encoding="utf-8",
    )
    (source_dir / "progress.json").write_text(
        json.dumps({"dataset_kind": "wikipedia_cpt", "completed": True}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    def fake_parsed_html(*, language: str, pageid: str) -> str:
        if pageid == "1":
            return '<div><ol class="references"><li><a href="https://example.com/ref1">ref</a></li></ol></div>'
        return '<div><ol class="references"><li><a href="https://example.com/ref1#dup">ref</a></li><li><a href="https://example.com/ref2">ref</a></li></ol></div>'

    def fake_document(url: str) -> Any:
        normalized_url = url.removesuffix("#dup")
        if normalized_url.endswith("/ref2"):
            return corpus_module.WikipediaReferenceDocument(
                url=url,
                final_url="https://example.com/ref2",
                title="別参照",
                text="別の本文です。",
                content_type="text/html",
                source_format="html",
            )
        return corpus_module.WikipediaReferenceDocument(
            url=url,
            final_url="https://example.com/ref1",
            title="参照先",
            text="重複本文です。",
            content_type="text/html",
            source_format="html",
        )

    monkeypatch.setattr(corpus_module, "_fetch_wikipedia_parsed_html", fake_parsed_html)
    monkeypatch.setattr(corpus_module, "_fetch_reference_document", fake_document)
    monkeypatch.setattr(corpus_module.time, "sleep", lambda seconds: None)

    report = prepare_wikipedia_cited_sources_cpt(
        source_wikipedia_dir=source_dir,
        output_dir=tmp_path / "wikipedia_cited_sources",
        max_pages_per_run=2,
    )

    shard_path = next((tmp_path / "wikipedia_cited_sources" / "shards").glob("wikipedia_cited_sources_*.jsonl"))
    records = [json.loads(line) for line in shard_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    state = json.loads((tmp_path / "wikipedia_cited_sources" / "progress.json").read_text(encoding="utf-8"))

    assert report.total_records == 2
    assert len(records) == 2
    assert {record["metadata"]["reference_final_url"] for record in records} == {
        "https://example.com/ref1",
        "https://example.com/ref2",
    }
    assert state["processed_source_pages"] == 2
    assert state["processed_reference_urls"] == 2
    assert state["skipped_duplicate_references"] == 1
    assert "https://example.com/ref1" in (
        tmp_path / "wikipedia_cited_sources" / "seen_reference_url_keys.txt"
    ).read_text(encoding="utf-8")


def test_inspect_prepared_dataset_status_reports_progress_and_storage(tmp_path: Path) -> None:
    output_dir = tmp_path / "wikipedia"
    shards_dir = output_dir / "shards"
    shards_dir.mkdir(parents=True)
    (shards_dir / "wikipedia_00001.jsonl").write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "task_type": "cpt",
                        "text": "富士山\n\n本文です。",
                        "focus": ["knowledge"],
                        "metadata": {"source_label": "wikipedia", "language": "ja", "title": "富士山", "pageid": 1},
                    },
                    ensure_ascii=False,
                ),
                json.dumps(
                    {
                        "task_type": "cpt",
                        "text": "筑波山\n\n本文です。",
                        "focus": ["knowledge"],
                        "metadata": {"source_label": "wikipedia", "language": "ja", "title": "筑波山", "pageid": 2},
                    },
                    ensure_ascii=False,
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (output_dir / "progress.json").write_text(
        json.dumps(
            {
                "dataset_kind": "wikipedia_cpt",
                "processed_items": 25,
                "processed_pages": 25,
                "total_items": 100,
                "approximate_total_articles": 100,
                "rate_per_min": 12.5,
                "eta_seconds": 3600,
                "completed": False,
                "last_updated_at": "2026-03-27T00:00:00Z",
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    report = inspect_prepared_dataset_status(output_dir=output_dir)

    assert report.kind == "wikipedia_cpt"
    assert report.shard_count == 1
    assert report.total_records == 2
    assert report.processed_items == 25
    assert report.total_items == 100
    assert report.remaining_items == 75
    assert report.progress == "25/100"
    assert report.progress_percent == 25.0
    assert report.eta == "01:00:00"
    assert report.storage_bytes > 0


def test_run_training_uses_sequential_manifest_dataset(tmp_path: Path, monkeypatch: Any) -> None:
    shard_dir = tmp_path / "shards"
    shard_dir.mkdir()
    shard_a = shard_dir / "a.jsonl"
    shard_b = shard_dir / "b.jsonl"
    shard_a.write_text(json.dumps({"task_type": "cpt", "text": "alpha"}, ensure_ascii=False) + "\n", encoding="utf-8")
    shard_b.write_text(json.dumps({"task_type": "cpt", "text": "beta"}, ensure_ascii=False) + "\n", encoding="utf-8")
    manifest_path = tmp_path / "train_manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "kind": "sequential_cpt_manifest",
                "datasets": [{"path": str(shard_a)}, {"path": str(shard_b)}],
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    class FakeModel:
        def freeze(self) -> None:
            return None

        def trainable_parameters(self) -> dict[str, object]:
            return {}

    captured: dict[str, Any] = {}

    monkeypatch.setattr(
        trainer_module,
        "load",
        lambda *args, **kwargs: (
            FakeModel(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=False,
                video=False,
                tool_calling=True,
                tool_response=True,
                thinking=True,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(trainer_module, "_prepare_training_model", lambda model, lora, base_update: None)
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "_run_training_loop",
        lambda **kwargs: captured.update(kwargs),
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(manifest_path),
            output_dir=str(tmp_path / "out"),
            iters=1,
            validation_fraction=0,
            lora=LoRAHyperparameters(num_layers=2, rank=4, scale=8.0, dropout=0.0),
        )
    )

    assert report.status == "completed"
    train_dataset = captured["train_dataset"]
    assert len(train_dataset) == 2
    assert train_dataset.itemlen(0) > 0
