import json
from pathlib import Path
from typing import Any

import cappuccino.tool_runtime as tool_runtime
from cappuccino.tool_runtime import ToolExecutor
from cappuccino.tool_search import ToolRegistry


REGISTRY_PATH = (
    Path(__file__).resolve().parents[1] / "examples" / "tool_registry.sample.json"
)


def test_tool_executor_runs_builtin_tool_search() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)
    executor = ToolExecutor(registry)

    output = executor.execute(
        name="tool_search",
        arguments={"query": "video caption timeline", "limit": 1},
    )

    assert output is not None
    body = json.loads(output)
    assert body["results"][0]["name"] == "describe_video"


def test_tool_executor_runs_builtin_current_time() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)
    executor = ToolExecutor(registry)

    output = executor.execute(
        name="current_time",
        arguments={"timezone": "UTC"},
    )

    assert output is not None
    body = json.loads(output)
    assert body["timezone"] == "UTC"
    assert isinstance(body["unix"], int)


def test_tool_executor_supports_http_json_handler(tmp_path: Path, monkeypatch: Any) -> None:
    registry_path = tmp_path / "registry.json"
    registry_path.write_text(
        """
        [
          {
            "type": "function",
            "name": "lookup_item",
            "description": "Lookup an item from an HTTP JSON endpoint.",
            "server_handler": {
              "type": "http_json",
              "method": "GET",
              "url": "https://example.com/{{resource}}",
              "params": {
                "q": "{{query}}",
                "limit": "{{limit}}"
              },
              "result_path": "data.0"
            }
          }
        ]
        """.strip(),
        encoding="utf-8",
    )
    registry = ToolRegistry.from_path(registry_path)
    executor = ToolExecutor(registry)
    seen: dict[str, Any] = {}

    class FakeResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, object]:
            return {"data": [{"name": "ok"}]}

    class FakeClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            return None

        def __enter__(self) -> "FakeClient":
            return self

        def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
            return None

        def request(
            self,
            method: str,
            url: str,
            *,
            params: dict[str, object] | None = None,
            json: Any = None,
        ) -> FakeResponse:
            seen["method"] = method
            seen["url"] = url
            seen["params"] = params
            seen["json"] = json
            return FakeResponse()

    monkeypatch.setattr(tool_runtime.httpx, "Client", FakeClient)

    output = executor.execute(
        name="lookup_item",
        arguments={"resource": "anime", "query": "spirited away", "limit": 3},
    )

    assert output is not None
    assert seen["method"] == "GET"
    assert seen["url"] == "https://example.com/anime"
    assert seen["params"] == {"q": "spirited away", "limit": 3}
    assert json.loads(output) == {"name": "ok"}
