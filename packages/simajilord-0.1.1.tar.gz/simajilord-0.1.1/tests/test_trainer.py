import json
from pathlib import Path
from typing import Any

import cappuccino.trainer as trainer_module
from cappuccino.model_inspector import ModelCapabilities, ModelProfile, ModelQuantization
from cappuccino.trainer import (
    CheckpointSampleConfig,
    DatasetComposition,
    LoRAHyperparameters,
    MemoryEstimate,
    TrainerConfig,
    run_training,
)


def test_run_training_dry_run_reports_multimodal_tool_and_thinking_warnings(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text(
        "\n".join(
            [
                json.dumps({"task_type": "cpt", "text": "knowledge example"}, ensure_ascii=False),
                json.dumps(
                    {
                        "task_type": "chat_sft",
                        "messages": [
                            {"role": "user", "content": [{"type": "text", "text": "動画要約"}]},
                            {
                                "role": "assistant",
                                "content": "<think>internal</think>\n外部回答",
                                "tool_calls": [
                                    {
                                        "type": "function",
                                        "function": {
                                            "name": "tool_search",
                                            "arguments": {"query": "video"},
                                        },
                                    }
                                ],
                            },
                            {
                                "role": "tool",
                                "name": "tool_search",
                                "content": '[{"name":"describe_video"}]',
                            },
                            {
                                "role": "user",
                                "content": [
                                    {"type": "video", "video": "sample.mp4", "fps": 1.0, "max_frames": 16}
                                ],
                            },
                        ],
                    },
                    ensure_ascii=False,
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        trainer_module,
        "load",
        lambda *args, **kwargs: (
            object(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3, 4]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=True,
                video=True,
                tool_calling=True,
                tool_response=True,
                thinking=True,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "_prepare_training_model",
        lambda model, lora, base_update: None,
    )
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(trainer_module, "_count_saved_trainable_tensor_bytes", lambda model: 2468)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            dry_run=True,
            lora=LoRAHyperparameters(num_layers=2, rank=4, scale=8.0, dropout=0.0),
        )
    )

    assert report.status == "ready"
    assert report.dataset.cpt_examples == 1
    assert report.dataset.chat_examples == 1
    assert report.dataset.multimodal_chat_examples == 1
    assert report.dataset.tool_call_messages == 1
    assert report.dataset.tool_result_messages == 1
    assert report.dataset.thinking_examples == 1
    assert any("vision encoder" in warning for warning in report.warnings)
    assert any("Tool-use traces" in warning for warning in report.warnings)
    assert any("Thinking traces" in warning for warning in report.warnings)


def test_run_training_invokes_mlx_train_for_actual_run(tmp_path: Path, monkeypatch: Any) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text(
        json.dumps({"task_type": "cpt", "text": "knowledge example"}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    class FakeModel:
        def freeze(self) -> None:
            return None

        def trainable_parameters(self) -> dict[str, object]:
            return {}

    captured: dict[str, Any] = {}

    monkeypatch.setattr(
        trainer_module,
        "load",
        lambda *args, **kwargs: (
            FakeModel(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=True,
                video=True,
                tool_calling=True,
                tool_response=True,
                thinking=True,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "_prepare_training_model",
        lambda model, lora, base_update: None,
    )
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )

    def fake_train(**kwargs: Any) -> None:
        captured.update(kwargs)

    monkeypatch.setattr(trainer_module, "_run_training_loop", fake_train)
    monkeypatch.setattr(
        trainer_module,
        "sample_saved_checkpoints",
        lambda **kwargs: trainer_module.CheckpointSamplingReport(
            model_path=str(tmp_path),
            train_output_dir=str(tmp_path / "out"),
            checkpoint_count=1,
            prompt="AIについて説明してください",
            max_tokens=8192,
            records_path=str(tmp_path / "out" / "saved_checkpoint_samples.jsonl"),
            sample_dir=str(tmp_path / "out" / "saved_checkpoint_samples"),
            checkpoints=[str(tmp_path / "out" / "adapters.safetensors")],
        ),
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            iters=1,
            lora=LoRAHyperparameters(num_layers=2, rank=4, scale=8.0, dropout=0.0),
        )
    )

    assert report.status == "completed"
    assert "train_dataset" in captured
    assert "tokenizer" in captured
    assert "checkpoint_sample" in captured
    assert "checkpoint_samples_path" in captured
    assert report.adapter_file is not None
    assert report.checkpoint_samples_path is not None
    adapter_config = json.loads((tmp_path / "out" / "adapter_config.json").read_text(encoding="utf-8"))
    assert adapter_config == {
        "fine_tune_type": "lora",
        "num_layers": 2,
        "lora_parameters": {"rank": 4, "scale": 8.0, "dropout": 0.0},
        "rank": 4,
        "alpha": 8.0,
        "dropout": 0.0,
    }
    assert (tmp_path / "out" / "training_config.json").exists()


def test_run_training_passes_adapter_path_to_loader(tmp_path: Path, monkeypatch: Any) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text(
        json.dumps({"task_type": "cpt", "text": "knowledge example"}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    adapter_dir = tmp_path / "existing_adapter"
    adapter_dir.mkdir()

    captured: dict[str, Any] = {}

    class FakeModel:
        def freeze(self) -> None:
            return None

        def trainable_parameters(self) -> dict[str, object]:
            return {}

    def fake_load(*args: Any, **kwargs: Any) -> Any:
        captured["adapter_path"] = kwargs.get("adapter_path")
        return (
            FakeModel(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        )

    monkeypatch.setattr(trainer_module, "load", fake_load)
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=True,
                video=True,
                tool_calling=True,
                tool_response=True,
                thinking=True,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(trainer_module, "_prepare_training_model", lambda model, lora, base_update: None)
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(trainer_module, "_count_saved_trainable_tensor_bytes", lambda model: 2468)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            adapter_path=str(adapter_dir),
            dry_run=True,
        )
    )

    assert report.status == "ready"
    assert captured["adapter_path"] == str(adapter_dir.resolve())


def test_run_training_resolves_iterations_from_epochs(tmp_path: Path, monkeypatch: Any) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text(
        "\n".join(
            json.dumps({"task_type": "cpt", "text": f"example {index}"}, ensure_ascii=False)
            for index in range(3)
        )
        + "\n",
        encoding="utf-8",
    )
    captured: dict[str, Any] = {}

    class FakeModel:
        def freeze(self) -> None:
            return None

        def trainable_parameters(self) -> dict[str, object]:
            return {}

    monkeypatch.setattr(
        trainer_module,
        "load",
        lambda *args, **kwargs: (
            FakeModel(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3, 4]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=False,
                video=False,
                tool_calling=False,
                tool_response=False,
                thinking=False,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(trainer_module, "_prepare_training_model", lambda model, lora, base_update: None)
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(trainer_module, "_count_saved_trainable_tensor_bytes", lambda model: 2468)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )

    def fake_train(**kwargs: Any) -> None:
        captured["iters"] = kwargs["args"].iters

    monkeypatch.setattr(trainer_module, "_run_training_loop", fake_train)
    monkeypatch.setattr(
        trainer_module,
        "sample_saved_checkpoints",
        lambda **kwargs: trainer_module.CheckpointSamplingReport(
            model_path=str(tmp_path),
            train_output_dir=str(tmp_path / "out"),
            checkpoint_count=1,
            prompt="AIについて説明してください",
            max_tokens=8192,
            records_path=str(tmp_path / "out" / "saved_checkpoint_samples.jsonl"),
            sample_dir=str(tmp_path / "out" / "saved_checkpoint_samples"),
            checkpoints=[str(tmp_path / "out" / "adapters.safetensors")],
        ),
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            batch_size=2,
            validation_fraction=0,
            epochs=2,
            iters=1,
        )
    )

    assert report.status == "completed"
    assert captured["iters"] == 4
    assert any("Epoch-based iteration scheduling is enabled" in warning for warning in report.warnings)


def test_run_training_rejects_quantized_base_model(tmp_path: Path) -> None:
    dataset_path = tmp_path / "train.jsonl"
    dataset_path.write_text(
        json.dumps({"task_type": "cpt", "text": "knowledge example"}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (tmp_path / "config.json").write_text(
        json.dumps(
            {
                "model_type": "cappuccino",
                "architectures": ["CappuccinoForConditionalGeneration"],
                "quantization": {"group_size": 64, "bits": 6, "mode": "affine"},
                "text_config": {"max_position_embeddings": 262144},
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "tokenizer_config.json").write_text("{}", encoding="utf-8")
    (tmp_path / "tokenizer.json").write_text("{}", encoding="utf-8")
    (tmp_path / "chat_template.jinja").write_text("", encoding="utf-8")
    (tmp_path / "model.safetensors.index.json").write_text(
        json.dumps({"metadata": {"total_size": 1234}}),
        encoding="utf-8",
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            dry_run=True,
        )
    )

    assert report.status == "failed"
    assert report.error == "quantized_model_unsupported"
    assert any("re-download it before starting CPT or fine-tuning" in warning for warning in report.warnings)


def test_run_training_invokes_orpo_loop_for_preference_dataset(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    dataset_path = tmp_path / "preferences.jsonl"
    dataset_path.write_text(
        json.dumps(
            {
                "task_type": "preference",
                "chosen": [
                    {"role": "user", "content": "良い設計とは?"},
                    {"role": "assistant", "content": "責務分離です。"},
                ],
                "rejected": [
                    {"role": "user", "content": "良い設計とは?"},
                    {"role": "assistant", "content": "特にありません。"},
                ],
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    class FakeModel:
        layers = [object()]

        def freeze(self) -> None:
            return None

        def trainable_parameters(self) -> dict[str, object]:
            return {}

    captured: dict[str, Any] = {}

    monkeypatch.setattr(
        trainer_module,
        "load",
        lambda *args, **kwargs: (
            FakeModel(),
            type(
                "Tokenizer",
                (),
                {
                    "eos_token_id": 0,
                    "encode": staticmethod(lambda text: [1, 2, 3]),
                    "apply_chat_template": staticmethod(lambda messages, **kwargs: [1, 2, 3, 4]),
                },
            )(),
            {"text_config": {"max_position_embeddings": 1010000}},
        ),
    )
    monkeypatch.setattr(
        trainer_module,
        "inspect_model_dir",
        lambda path: ModelProfile(
            model_dir=str(path),
            model_name="fake",
            model_type="cappuccino",
            text_context_window=1010000,
            extended_context_claim=None,
            weight_bytes=1234,
            quantization=ModelQuantization(),
            capabilities=ModelCapabilities(
                image=False,
                video=False,
                tool_calling=False,
                tool_response=False,
                thinking=False,
                openai_chat_template=True,
                openai_api_serving_docs=False,
            ),
        ),
    )
    monkeypatch.setattr(trainer_module, "_prepare_training_model", lambda model, lora, base_update: None)
    monkeypatch.setattr(trainer_module, "_count_trainable_parameters", lambda model: 1234)
    monkeypatch.setattr(trainer_module, "_count_saved_trainable_tensor_bytes", lambda model: 2468)
    monkeypatch.setattr(
        trainer_module,
        "_estimate_memory",
        lambda **kwargs: MemoryEstimate(
            trainable_parameter_count=1234,
            estimated_activation_bytes=100,
            estimated_optimizer_bytes=200,
            estimated_peak_working_set_bytes=300,
            fits_recommended_working_set=True,
        ),
    )

    def fake_orpo_train(**kwargs: Any) -> None:
        captured.update(kwargs)

    monkeypatch.setattr(trainer_module, "_run_preference_training_loop", fake_orpo_train)

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            train_mode="orpo",
            iters=1,
            orpo_beta=0.2,
            checkpoint_sample=CheckpointSampleConfig(enabled=False),
        )
    )

    assert report.status == "completed"
    assert "train_dataset" in captured
    assert captured["args"].beta == 0.2


def test_run_training_rejects_preference_examples_when_train_mode_is_sft(tmp_path: Path) -> None:
    dataset_path = tmp_path / "preferences.jsonl"
    dataset_path.write_text(
        json.dumps(
            {
                "task_type": "preference",
                "chosen": [
                    {"role": "user", "content": "Q"},
                    {"role": "assistant", "content": "A"},
                ],
                "rejected": [
                    {"role": "user", "content": "Q"},
                    {"role": "assistant", "content": "B"},
                ],
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    report = run_training(
        TrainerConfig(
            model_path=str(tmp_path),
            dataset_path=str(dataset_path),
            output_dir=str(tmp_path / "out"),
            dry_run=True,
        )
    )

    assert report.status == "failed"
    assert report.error == "preference_examples_require_train_mode_orpo"


def test_enable_grad_checkpoint_once_is_idempotent(monkeypatch: Any) -> None:
    class DummyLayer:
        def __call__(self, value: str) -> str:
            return value

    wrapped_calls: list[type[DummyLayer]] = []

    def fake_grad_checkpoint(layer: DummyLayer) -> None:
        wrapped_calls.append(type(layer))
        original = type(layer).__call__

        def wrapped(self: DummyLayer, value: str) -> str:
            return original(self, value)

        setattr(type(layer), "__call__", wrapped)

    monkeypatch.setattr(trainer_module, "mlx_grad_checkpoint", fake_grad_checkpoint)

    layer = DummyLayer()
    trainer_module._enable_grad_checkpoint_once(layer)
    first_wrapper = DummyLayer.__call__
    trainer_module._enable_grad_checkpoint_once(layer)

    assert len(wrapped_calls) == 1
    assert DummyLayer.__call__ is first_wrapper


def test_count_saved_trainable_tensor_bytes_uses_dtype_sizes() -> None:
    class FakeDType:
        def __init__(self, size: int) -> None:
            self.size = size

    class FakeArray:
        def __init__(self, size: int, dtype_size: int) -> None:
            self.size = size
            self.dtype = FakeDType(dtype_size)

    class FakeModel:
        def trainable_parameters(self) -> dict[str, FakeArray]:
            return {
                "lora_a": FakeArray(size=10, dtype_size=2),
                "norm": FakeArray(size=5, dtype_size=4),
            }

    assert trainer_module._count_saved_trainable_tensor_bytes(FakeModel()) == 40


def test_iterate_batches_accepts_overlong_sequences_when_cap_disabled() -> None:
    dataset = [
        ([1] * 1500, 0),
    ]

    batch_iter = trainer_module._iterate_batches(
        dataset=dataset,
        batch_size=1,
        max_seq_length=0,
        loop=False,
    )

    batch, lengths = next(batch_iter)
    assert tuple(batch.shape) == (1, 1505)
    assert lengths.tolist() == [[0, 1500]]


def test_configure_metal_memory_limits_uses_recommended_working_set(monkeypatch: Any) -> None:
    captured: list[tuple[str, int]] = []

    class FakeMetal:
        @staticmethod
        def is_available() -> bool:
            return True

    monkeypatch.setattr(trainer_module.mx, "metal", FakeMetal())
    monkeypatch.setattr(
        trainer_module.mx,
        "device_info",
        lambda: {
            "max_recommended_working_set_size": 123456,
            "memory_size": 654321,
        },
    )
    monkeypatch.setattr(
        trainer_module.mx,
        "set_memory_limit",
        lambda limit: captured.append(("memory", limit)),
    )
    monkeypatch.setattr(
        trainer_module.mx,
        "set_wired_limit",
        lambda limit: captured.append(("wired", limit)),
    )
    monkeypatch.setattr(
        trainer_module.mx,
        "set_cache_limit",
        lambda limit: captured.append(("cache", limit)),
    )

    trainer_module._configure_metal_memory_limits(
        stability=trainer_module.StabilityConfig(
            metal_memory_budget_mode="recommended",
            metal_cache_limit_bytes=0,
        )
    )

    assert captured == [("memory", 123456), ("wired", 123456), ("cache", 0)]


def test_generate_checkpoint_sample_record_writes_text_and_metadata(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    class FakeModel:
        def __init__(self) -> None:
            self.eval_calls = 0
            self.train_calls = 0

        def eval(self) -> None:
            self.eval_calls += 1

        def train(self) -> None:
            self.train_calls += 1

    class FakeTokenizer:
        @staticmethod
        def apply_chat_template(messages: list[dict[str, str]], **kwargs: Any) -> list[int]:
            assert messages == [{"role": "user", "content": "AIについて説明してください"}]
            assert kwargs["add_generation_prompt"] is True
            assert kwargs["return_dict"] is False
            return [11, 22, 33]

    responses = [
        type(
            "Response",
            (),
            {
                "text": "AIは",
                "prompt_tokens": 3,
                "generation_tokens": 1,
                "finish_reason": None,
                "prompt_tps": 10.0,
                "generation_tps": 4.0,
                "peak_memory": 1.5,
            },
        )(),
        type(
            "Response",
            (),
            {
                "text": "情報処理システムです。",
                "prompt_tokens": 3,
                "generation_tokens": 2,
                "finish_reason": "stop",
                "prompt_tps": 10.0,
                "generation_tps": 4.0,
                "peak_memory": 1.5,
            },
        )(),
    ]

    monkeypatch.setattr(trainer_module, "stream_generate", lambda *args, **kwargs: iter(responses))

    record = trainer_module._generate_checkpoint_sample_record(
        model=FakeModel(),
        tokenizer=FakeTokenizer(),
        checkpoint_file=tmp_path / "0000001_adapters.safetensors",
        iteration=1,
        prompt="AIについて説明してください",
        max_tokens=8192,
    )
    records_path = tmp_path / "checkpoint_samples.jsonl"
    trainer_module._append_checkpoint_sample_record(record=record, records_path=records_path)

    saved_record = json.loads(records_path.read_text(encoding="utf-8").splitlines()[0])
    sample_text = (tmp_path / "checkpoint_samples" / "0000001.txt").read_text(encoding="utf-8")

    assert saved_record["output_text"] == "AIは情報処理システムです。"
    assert saved_record["finish_reason"] == "stop"
    assert saved_record["effective_max_kv_size"] == 2048
    assert saved_record["effective_kv_bits"] == 4
    assert saved_record["effective_kv_group_size"] == 64
    assert saved_record["retry_count"] == 0
    assert "AIについて説明してください" in sample_text
    assert "AIは情報処理システムです。" in sample_text
    assert "kv_bits=4" in sample_text


def test_generate_checkpoint_sample_record_retries_with_smaller_kv_cache_on_memory_error(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    class FakeModel:
        def eval(self) -> None:
            return None

        def train(self) -> None:
            return None

    class FakeTokenizer:
        @staticmethod
        def apply_chat_template(messages: list[dict[str, str]], **kwargs: Any) -> list[int]:
            return [11, 22, 33]

    attempts: list[tuple[int | None, int | None, int]] = []

    def fake_stream_generate(*args: Any, **kwargs: Any) -> Any:
        attempts.append((kwargs["max_kv_size"], kwargs["kv_bits"], kwargs["kv_group_size"]))
        if kwargs["max_kv_size"] == 2048:
            raise RuntimeError("Metal out of memory while allocating KV cache")
        return iter(
            [
                type(
                    "Response",
                    (),
                    {
                        "text": "成功",
                        "prompt_tokens": 3,
                        "generation_tokens": 1,
                        "finish_reason": "stop",
                        "prompt_tps": 10.0,
                        "generation_tps": 5.0,
                        "peak_memory": 1.0,
                    },
                )()
            ]
        )

    monkeypatch.setattr(trainer_module, "stream_generate", fake_stream_generate)

    record = trainer_module._generate_checkpoint_sample_record(
        model=FakeModel(),
        tokenizer=FakeTokenizer(),
        checkpoint_file=tmp_path / "0000001_adapters.safetensors",
        iteration=1,
        prompt="AIについて説明してください",
        max_tokens=8192,
        max_kv_size=2048,
        kv_bits=4,
        kv_group_size=64,
    )

    assert attempts == [(2048, 4, 64), (1024, 4, 64)]
    assert record.output_text == "成功"
    assert record.effective_max_kv_size == 1024
    assert record.effective_kv_bits == 4
    assert record.retry_count == 1


def test_record_checkpoint_sample_keeps_training_running_on_generation_error(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    class FakeModel:
        def eval(self) -> None:
            return None

        def train(self) -> None:
            return None

    class FakeTokenizer:
        @staticmethod
        def apply_chat_template(messages: list[dict[str, str]], **kwargs: Any) -> list[int]:
            return [1, 2, 3]

    def fail_stream_generate(*args: Any, **kwargs: Any) -> Any:
        raise RuntimeError("generation exploded")

    monkeypatch.setattr(trainer_module, "stream_generate", fail_stream_generate)

    records_path = tmp_path / "checkpoint_samples.jsonl"
    trainer_module._record_checkpoint_sample(
        model=FakeModel(),
        tokenizer=FakeTokenizer(),
        checkpoint_file=tmp_path / "0000001_adapters.safetensors",
        iteration=1,
        config=trainer_module.CheckpointSampleConfig(),
        records_path=records_path,
    )

    saved_record = json.loads(records_path.read_text(encoding="utf-8").splitlines()[0])
    assert saved_record["error"] == "generation exploded"
    assert "generation exploded" in (tmp_path / "checkpoint_samples" / "0000001.txt").read_text(encoding="utf-8")


def test_resolve_checkpoint_adapter_path_builds_loadable_bundle_from_legacy_training_output(
    tmp_path: Path,
) -> None:
    output_dir = tmp_path / "train"
    output_dir.mkdir()
    checkpoint_file = output_dir / "0000001_adapters.safetensors"
    checkpoint_file.write_bytes(b"weights")
    (output_dir / "training_config.json").write_text(
        json.dumps(
            {
                "lora": {
                    "num_layers": 2,
                    "rank": 4,
                    "scale": 8.0,
                    "dropout": 0.0,
                }
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    bundle_dir = trainer_module._resolve_checkpoint_adapter_path(
        output_dir=output_dir,
        checkpoint_path=checkpoint_file,
    )

    adapter_config = json.loads((bundle_dir / "adapter_config.json").read_text(encoding="utf-8"))
    assert bundle_dir == output_dir / "checkpoint_bundles" / "0000001"
    assert adapter_config["num_layers"] == 2
    assert adapter_config["lora_parameters"] == {"rank": 4, "scale": 8.0, "dropout": 0.0}
    assert (bundle_dir / "adapters.safetensors").exists()
