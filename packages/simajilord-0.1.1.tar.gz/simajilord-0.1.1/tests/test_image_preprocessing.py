from pathlib import Path

from PIL import Image

from cappuccino.image_preprocessing import (
    ImageNormalizationPolicy,
    normalize_image_source,
    normalize_payload_images,
)


def test_large_image_is_downscaled_into_cache(tmp_path: Path) -> None:
    source_path = tmp_path / "huge.png"
    Image.new("RGB", (5000, 3000), color="white").save(source_path)
    cache_dir = tmp_path / "cache"
    policy = ImageNormalizationPolicy(
        max_long_edge=1536,
        max_pixels=1536 * 1536,
        cache_dir=str(cache_dir),
    )

    normalized_path = Path(normalize_image_source(str(source_path), policy))

    assert normalized_path != source_path
    assert normalized_path.exists()
    with Image.open(normalized_path) as resized:
        assert max(resized.size) <= 1536


def test_small_image_keeps_original_reference(tmp_path: Path) -> None:
    source_path = tmp_path / "small.png"
    Image.new("RGB", (512, 512), color="white").save(source_path)
    policy = ImageNormalizationPolicy(
        max_long_edge=1536,
        max_pixels=1536 * 1536,
        cache_dir=str(tmp_path / "cache"),
    )

    normalized = normalize_image_source(str(source_path), policy)

    assert normalized == str(source_path)


def test_payload_normalization_updates_openai_image_items(tmp_path: Path) -> None:
    source_path = tmp_path / "huge.png"
    Image.new("RGB", (4096, 4096), color="white").save(source_path)
    policy = ImageNormalizationPolicy(
        max_long_edge=1536,
        max_pixels=1536 * 1536,
        cache_dir=str(tmp_path / "cache"),
    )

    payload = {
        "messages": [
            {
                "role": "user",
                "content": [{"type": "input_image", "image_url": str(source_path)}],
            }
        ]
    }

    normalized = normalize_payload_images(payload, policy)
    normalized_path = Path(normalized["messages"][0]["content"][0]["image_url"])

    assert normalized_path.exists()
    assert normalized_path != source_path
