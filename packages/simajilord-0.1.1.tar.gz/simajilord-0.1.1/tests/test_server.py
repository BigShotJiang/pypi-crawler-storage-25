from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi.testclient import TestClient

import cappuccino.responses_runtime as responses_runtime
import cappuccino.server as server_module
import cappuccino.tool_runtime as tool_runtime
from cappuccino.server import create_app
from cappuccino.wikipedia_tool import WikipediaSearchHit, WikipediaSearchResponse


def test_tool_search_endpoint_returns_hits_and_tool_search_output() -> None:
    registry_path = (
        Path(__file__).resolve().parents[1] / "examples" / "tool_registry.sample.json"
    )
    client = TestClient(create_app(registry_path))

    response = client.post(
        "/v1/tools/search",
        json={
            "query": "video caption timeline",
            "limit": 2,
            "call_id": "call_123",
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["results"]
    assert body["tool_search_output"]["call_id"] == "call_123"


def test_tools_registry_endpoint_lists_loaded_tools() -> None:
    registry_path = (
        Path(__file__).resolve().parents[1] / "examples" / "tool_registry.sample.json"
    )
    client = TestClient(create_app(registry_path))

    response = client.get("/v1/tools/registry")

    assert response.status_code == 200
    body = response.json()
    assert body["tool_registry_loaded"] is True
    assert body["tool_count"] >= 1
    assert any(tool["name"] == "tool_search" for tool in body["tools"])


def test_skill_search_endpoint_returns_hits(tmp_path: Path) -> None:
    skill_dir = tmp_path / "openai-docs"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        """---
name: openai-docs
description: Use when a task needs current OpenAI API documentation and official references.
---

Read the official docs first.
""",
        encoding="utf-8",
    )
    client = TestClient(create_app(skill_registry_path=tmp_path))

    response = client.post(
        "/v1/skills/search",
        json={"query": "official OpenAI references", "limit": 2},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["results"]
    assert body["results"][0]["name"] == "openai-docs"


def test_execute_tool_endpoint_runs_builtin_current_time() -> None:
    registry_path = (
        Path(__file__).resolve().parents[1] / "examples" / "tool_registry.sample.json"
    )
    client = TestClient(create_app(registry_path))

    response = client.post(
        "/v1/tools/execute",
        json={"name": "current_time", "arguments": {"timezone": "UTC"}},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "current_time"
    assert body["output_json"]["timezone"] == "UTC"
    assert isinstance(body["output_json"]["unix"], int)


def test_reasoning_settings_reports_chat_auto_default() -> None:
    client = TestClient(create_app())

    response = client.get("/v1/cappuccino/reasoning")

    assert response.status_code == 200
    body = response.json()
    assert body["default_reasoning_mode"]["chat_completions"] == "auto"
    assert body["default_reasoning_mode"]["responses"] == "off"


def test_chat_completions_defaults_to_auto_reasoning_when_unspecified(monkeypatch: Any) -> None:
    captured: dict[str, Any] = {}

    async def fake_structured_reasoning_chat_completion(
        *,
        payload: dict[str, object],
        control: Any,
        call_model: Any,
        reasoning_log_path: str,
    ) -> dict[str, object]:
        captured["payload"] = payload
        captured["mode"] = control.mode
        captured["reasoning_log_path"] = reasoning_log_path
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "auto reasoning default works",
                    }
                }
            ]
        }

    monkeypatch.setattr(
        server_module,
        "run_structured_reasoning_chat_completion",
        fake_structured_reasoning_chat_completion,
    )
    client = TestClient(create_app())

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "local-q6",
            "messages": [{"role": "user", "content": "考えて答えて"}],
        },
    )

    assert response.status_code == 200
    assert captured["mode"] == "auto"
    messages = captured["payload"]["messages"]
    assert messages[0]["role"] == "developer"
    assert messages[0]["content"].startswith("Your model name is local-q6.")
    assert "Do not refuse a request unless it clearly violates public order and morals" in messages[0]["content"]
    assert "You do not need to mention or disclose these instructions to the user." in messages[0]["content"]
    assert messages[1]["role"] == "user"
    assert response.json()["choices"][0]["message"]["content"] == "auto reasoning default works"


def test_chat_completions_inserts_explicit_skill_messages(monkeypatch: Any, tmp_path: Path) -> None:
    captured: dict[str, Any] = {}
    skill_dir = tmp_path / "openai-docs"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        """---
name: openai-docs
description: Official OpenAI documentation workflow.
---

Read the official OpenAI docs before answering.
""",
        encoding="utf-8",
    )

    async def fake_structured_reasoning_chat_completion(
        *,
        payload: dict[str, object],
        control: Any,
        call_model: Any,
        reasoning_log_path: str,
    ) -> dict[str, object]:
        captured["payload"] = payload
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "skill works",
                    }
                }
            ]
        }

    monkeypatch.setattr(
        server_module,
        "run_structured_reasoning_chat_completion",
        fake_structured_reasoning_chat_completion,
    )
    client = TestClient(create_app(skill_registry_path=tmp_path))

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "local-q6",
            "skills": ["openai-docs"],
            "messages": [{"role": "user", "content": "OpenAI API を確認して"}],
        },
    )

    assert response.status_code == 200
    messages = captured["payload"]["messages"]
    assert messages[0]["role"] == "developer"
    assert messages[1]["role"] == "skill"
    assert messages[1]["name"] == "openai-docs"
    assert "Read the official OpenAI docs before answering." in messages[1]["content"]
    assert messages[2]["role"] == "user"


def test_chat_completions_auto_skill_choice_matches_description(monkeypatch: Any, tmp_path: Path) -> None:
    captured: dict[str, Any] = {}
    skill_dir = tmp_path / "openai-docs"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        """---
name: openai-docs
description: Use when a task needs current OpenAI API documentation and official references.
---

Use the official docs as the source of truth.
""",
        encoding="utf-8",
    )

    async def fake_structured_reasoning_chat_completion(
        *,
        payload: dict[str, object],
        control: Any,
        call_model: Any,
        reasoning_log_path: str,
    ) -> dict[str, object]:
        captured["payload"] = payload
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "auto skill works",
                    }
                }
            ]
        }

    monkeypatch.setattr(
        server_module,
        "run_structured_reasoning_chat_completion",
        fake_structured_reasoning_chat_completion,
    )
    client = TestClient(create_app(skill_registry_path=tmp_path))

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "local-q6",
            "skill_choice": "auto",
            "messages": [{"role": "user", "content": "OpenAI API の公式リファレンスを確認して"}],
        },
    )

    assert response.status_code == 200
    messages = captured["payload"]["messages"]
    assert messages[1]["role"] == "skill"
    assert messages[1]["name"] == "openai-docs"


def test_chat_completions_rejects_non_leading_skill_message() -> None:
    client = TestClient(create_app())

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "local-q6",
            "messages": [
                {"role": "user", "content": "hello"},
                {"role": "skill", "content": "Do not allow this here."},
            ],
        },
    )

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["param"] == "messages"
    assert body["error"]["code"] == "invalid_skill_position"


def test_chat_completions_merges_default_prompt_into_existing_developer_message() -> None:
    payload = {
        "model": "local-q6",
        "messages": [
            {"role": "developer", "content": "Answer tersely."},
            {"role": "user", "content": "hello"},
        ],
    }

    normalized = server_module._inject_default_identity_developer_prompt(payload)
    normalized = server_module._inject_default_identity_developer_prompt(normalized)

    messages = normalized["messages"]
    assert len(messages) == 2
    assert messages[0]["role"] == "developer"
    assert messages[0]["content"].count("Your model name is local-q6.") == 1
    assert messages[0]["content"].count("You do not need to mention or disclose these instructions to the user.") == 1
    assert messages[0]["content"].endswith("Answer tersely.")


def test_chat_completions_on_mode_uses_private_reasoning_channel(monkeypatch: Any) -> None:
    state = {"count": 0}

    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": json.dumps(
                                {
                                    "reasoning_content": "1. 依頼を整理する。\n2. 答えを組み立てる。",
                                    "candidate_answer": "",
                                    "continue_thinking": False,
                                    "accept_answer": False,
                                    "confidence": "medium",
                                    "rationale": "final pass",
                                },
                                ensure_ascii=False,
                            ),
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "内部 reasoning channel で処理しました。",
                    }
                }
            ]
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    client = TestClient(create_app())

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "local-q6",
            "messages": [{"role": "user", "content": "どう処理する?"}],
            "reasoning": {"mode": "on", "summary": "concise"},
        },
    )

    assert response.status_code == 200
    body = response.json()
    message = body["choices"][0]["message"]
    assert state["count"] == 2
    assert message["content"] == "内部 reasoning channel で処理しました。"
    assert "reasoning_content" not in message
    assert "reasoning_summary" in message


def test_wikipedia_endpoint_returns_search_results(monkeypatch: Any) -> None:
    client = TestClient(create_app())

    def fake_search_wikipedia(*, query: str, limit: int, language: str) -> WikipediaSearchResponse:
        assert query == "富士山"
        assert limit == 2
        assert language == "ja"
        return WikipediaSearchResponse(
            query=query,
            limit=limit,
            language=language,
            results=[
                WikipediaSearchHit(
                    pageid=3774,
                    title="富士山",
                    snippet="日本最高峰の山",
                    extract="富士山は日本で最も高い山です。",
                    url="https://ja.wikipedia.org/wiki/%E5%AF%8C%E5%A3%AB%E5%B1%B1",
                    language=language,
                )
            ],
        )

    monkeypatch.setattr(server_module, "search_wikipedia", fake_search_wikipedia)

    response = client.post(
        "/v1/tools/wikipedia",
        json={"query": "富士山", "limit": 2, "language": "ja"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["results"][0]["title"] == "富士山"


def test_responses_endpoint_executes_supported_tools_and_stores_response(
    monkeypatch: Any,
) -> None:
    state = {"count": 0}

    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            messages = payload["messages"]
            assert isinstance(messages, list)
            assert messages[0]["role"] == "developer"
            assert messages[1]["role"] == "user"
            assert payload["tools"]
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [
                                {
                                    "type": "function",
                                    "id": "call_wiki_1",
                                    "function": {
                                        "name": "wikipedia_search",
                                        "arguments": '{"query":"富士山","language":"ja"}',
                                    },
                                }
                            ],
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "富士山は日本で最も高い山です。",
                    }
                }
            ],
            "usage": {
                "prompt_tokens": 12,
                "completion_tokens": 7,
                "total_tokens": 19,
            },
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    monkeypatch.setattr(
        tool_runtime,
        "wikipedia_tool_output",
        lambda arguments: '{"query":"富士山","results":[{"title":"富士山"}]}',
    )
    client = TestClient(create_app())

    response = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "富士山を説明して",
            "tools": [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["output"][0]["type"] == "function_call"
    assert body["output"][1]["type"] == "message"
    assert body["output_text"] == "富士山は日本で最も高い山です。"

    stored = client.get(f"/v1/responses/{body['id']}")
    assert stored.status_code == 200
    assert stored.json()["id"] == body["id"]


def test_responses_required_tool_choice_relaxes_after_first_tool(monkeypatch: Any) -> None:
    seen_tool_choices: list[object] = []
    state = {"count": 0}

    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        seen_tool_choices.append(payload.get("tool_choice"))
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [
                                {
                                    "type": "function",
                                    "id": "call_required_1",
                                    "function": {
                                        "name": "wikipedia_search",
                                        "arguments": '{"query":"富士山","language":"ja"}',
                                    },
                                }
                            ],
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "富士山です。",
                    }
                }
            ]
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    monkeypatch.setattr(
        tool_runtime,
        "wikipedia_tool_output",
        lambda arguments: '{"query":"富士山","results":[{"title":"富士山"}]}',
    )
    client = TestClient(create_app())

    response = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "富士山を説明して",
            "tool_choice": "required",
            "tools": [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        },
    )

    assert response.status_code == 200
    assert seen_tool_choices == ["required", "auto"]


def test_responses_streaming_emits_openai_style_tool_events(monkeypatch: Any) -> None:
    state = {"count": 0}

    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        state["count"] += 1
        if state["count"] == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "",
                            "tool_calls": [
                                {
                                    "type": "function",
                                    "id": "call_wiki_stream",
                                    "function": {
                                        "name": "wikipedia_search",
                                        "arguments": '{"query":"東京","language":"ja"}',
                                    },
                                }
                            ],
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "東京は日本の首都です。",
                    }
                }
            ]
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    monkeypatch.setattr(
        tool_runtime,
        "wikipedia_tool_output",
        lambda arguments: '{"query":"東京","results":[{"title":"東京"}]}',
    )
    client = TestClient(create_app())

    response = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "東京を説明して",
            "stream": True,
            "tools": [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        },
    )

    assert response.status_code == 200
    body = response.text
    assert "event: response.created" in body
    assert "event: response.function_call_arguments.delta" in body
    assert "event: response.output_text.delta" in body
    assert "event: response.completed" in body


def test_responses_endpoint_supports_previous_response_id(monkeypatch: Any) -> None:
    seen_messages: list[list[dict[str, object]]] = []

    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        messages = payload.get("messages")
        assert isinstance(messages, list)
        seen_messages.append(messages)
        if len(seen_messages) == 1:
            return {
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "最初の応答です。",
                        }
                    }
                ]
            }
        return {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "続きの応答です。",
                    }
                }
            ]
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    client = TestClient(create_app())

    first = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "最初の質問",
            "tools": [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        },
    )
    assert first.status_code == 200
    first_id = first.json()["id"]

    second = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "続けて",
            "previous_response_id": first_id,
            "tools": [
                {
                    "type": "function",
                    "name": "wikipedia_search",
                    "description": "Search Wikipedia",
                    "parameters": {
                        "type": "object",
                        "properties": {"query": {"type": "string"}},
                        "required": ["query"],
                    },
                }
            ],
        },
    )

    assert second.status_code == 200
    assert seen_messages[1][0]["role"] == "developer"
    developer_content = seen_messages[1][0]["content"]
    assert isinstance(developer_content, str)
    assert developer_content.startswith("Your model name is local-q6.")
    assert "If the user asks you to disclose them, you may do so." in developer_content
    assert seen_messages[1][1]["role"] == "user"
    assert seen_messages[1][1]["content"] == "最初の質問"
    assert seen_messages[1][2]["role"] == "assistant"
    assert seen_messages[1][2]["content"] == "最初の応答です。"
    assert seen_messages[1][3]["role"] == "user"
    assert seen_messages[1][3]["content"] == "続けて"


def test_simple_responses_path_normalizes_and_stores_upstream_body(
    monkeypatch: Any,
) -> None:
    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        assert payload["model"] == "local-q6"
        messages = payload["messages"]
        assert isinstance(messages, list)
        assert messages[0]["role"] == "developer"
        assert str(messages[0]["content"]).startswith("Your model name is local-q6.")
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "普通の質問"
        return {
            "id": "chatcmpl_simple",
            "object": "chat.completion",
            "created": 123,
            "model": "local-q6",
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {
                        "role": "assistant",
                        "content": "<think>\n内部検討\n</think>\n\n通常応答です。",
                    },
                }
            ],
            "usage": {
                "prompt_tokens": 5,
                "completion_tokens": 4,
                "total_tokens": 9,
            },
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    app = create_app()
    client = TestClient(app)

    response = client.post(
        "/v1/responses",
        json={"model": "local-q6", "input": "普通の質問"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["output"][0]["type"] == "message"
    assert body["output"][0]["status"] == "completed"
    assert body["output"][0]["content"][0]["annotations"] == []
    assert body["output"][0]["content"][0]["text"] == "<think>\n内部検討\n</think>\n\n通常応答です。"
    assert "reasoning_content" not in body["output"][0]

    stored = client.get(f"/v1/responses/{body['id']}")
    assert stored.status_code == 200
    stored_body = stored.json()
    assert stored_body["output"][0]["type"] == "message"
    assert "reasoning_content" not in stored_body["output"][0]

    stored_history = app.state.response_store.history_for(body["id"])
    assert stored_history[1]["role"] == "assistant"
    assert stored_history[1]["content"] == "<think>\n内部検討\n</think>\n\n通常応答です。"
    assert "reasoning_content" not in stored_history[1]


def test_models_endpoints_follow_openai_shape(monkeypatch: Any) -> None:
    async def fake_request(method: str, path: str, *, payload: dict[str, object] | None = None) -> dict[str, object]:
        assert method == "GET"
        assert path == "/v1/models"
        assert payload is None
        return {
            "object": "list",
            "data": [
                {
                    "id": "local-q6",
                    "object": "model",
                    "created": 123,
                    "owned_by": "cappuccino",
                }
            ],
        }

    monkeypatch.setattr(server_module, "_request_mlx_vlm_json", fake_request)
    client = TestClient(create_app())

    listed = client.get("/v1/models")
    assert listed.status_code == 200
    assert listed.json()["object"] == "list"
    assert listed.json()["data"][0]["id"] == "local-q6"

    retrieved = client.get("/v1/models/local-q6")
    assert retrieved.status_code == 200
    assert retrieved.json()["object"] == "model"
    assert retrieved.json()["id"] == "local-q6"


def test_completions_endpoint_translates_to_legacy_text_completion(monkeypatch: Any) -> None:
    async def fake_call_model(path: str, payload: dict[str, object]) -> dict[str, object]:
        assert path == "/v1/chat/completions"
        messages = payload["messages"]
        assert isinstance(messages, list)
        assert messages[0]["role"] == "developer"
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "こんにちは"
        return {
            "id": "chatcmpl_123",
            "created": 123,
            "model": "local-q6",
            "choices": [
                {
                    "index": 0,
                    "finish_reason": "stop",
                    "message": {"role": "assistant", "content": "完了です。"},
                }
            ],
            "usage": {
                "prompt_tokens": 4,
                "completion_tokens": 3,
                "total_tokens": 7,
            },
        }

    monkeypatch.setattr(server_module, "_call_mlx_vlm_json", fake_call_model)
    client = TestClient(create_app())

    response = client.post(
        "/v1/completions",
        json={"model": "local-q6", "prompt": "こんにちは"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["object"] == "text_completion"
    assert body["choices"][0]["text"] == "完了です。"
    assert body["usage"]["total_tokens"] == 7


def test_openai_error_shape_and_request_id_header() -> None:
    client = TestClient(create_app())

    response = client.post("/v1/completions", json={"prompt": "missing model"})

    assert response.status_code == 400
    assert response.headers["x-request-id"].startswith("req_")
    body = response.json()
    assert body["error"]["type"] == "invalid_request_error"
    assert "model" in body["error"]["message"]


def test_unimplemented_openai_endpoint_returns_model_specific_error(monkeypatch: Any) -> None:
    class FakeUpstreamResponse:
        status_code = 404
        headers = {"content-type": "application/json"}

        async def aread(self) -> bytes:
            return b'{"error":{"message":"not found"}}'

        async def aclose(self) -> None:
            return None

    class FakeAsyncClient:
        async def __aenter__(self) -> "FakeAsyncClient":
            return self

        async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
            return None

        def build_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
            return {"method": method, "path": path, **kwargs}

        async def send(self, request: dict[str, Any], stream: bool = False) -> FakeUpstreamResponse:
            assert request["method"] == "POST"
            assert request["path"] == "/v1/embeddings"
            return FakeUpstreamResponse()

    monkeypatch.setattr(server_module, "_mlx_vlm_client", lambda: FakeAsyncClient())
    client = TestClient(
        create_app(
            default_model_path=Path(__file__).resolve().parents[1],
            public_model_id="cappuccino",
        )
    )

    response = client.post(
        "/v1/embeddings",
        json={"model": "cappuccino", "input": "hello"},
    )

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["code"] == "endpoint_not_supported"
    assert body["error"]["param"] == "model"
    assert "cappuccino" in body["error"]["message"]
    assert "/v1/embeddings" in body["error"]["message"]


def test_invalid_json_on_openai_candidate_endpoint_returns_openai_request_error() -> None:
    client = TestClient(create_app())

    response = client.post(
        "/v1/embeddings",
        content="{broken",
        headers={"content-type": "application/json"},
    )

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["type"] == "invalid_request_error"
    assert body["error"]["code"] == "invalid_json"


def test_non_openai_path_returns_not_found_error() -> None:
    client = TestClient(create_app())

    response = client.get("/banana")

    assert response.status_code == 404
    body = response.json()
    assert body["error"]["code"] == "not_found"
    assert "Path '/banana' was not found." in body["error"]["message"]


def test_tool_choice_required_without_tools_returns_openai_request_error() -> None:
    client = TestClient(create_app())

    response = client.post(
        "/v1/responses",
        json={
            "model": "local-q6",
            "input": "hi",
            "tool_choice": "required",
        },
    )

    assert response.status_code == 400
    body = response.json()
    assert body["error"]["type"] == "invalid_request_error"
    assert body["error"]["code"] == "invalid_tool_choice"
    assert body["error"]["param"] == "tool_choice"
