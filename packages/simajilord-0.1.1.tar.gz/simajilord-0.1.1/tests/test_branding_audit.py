from __future__ import annotations

import subprocess
from pathlib import Path


def test_workspace_contains_no_legacy_brand_strings() -> None:
    root = Path(__file__).resolve().parents[1]
    legacy_terms = ("Q" + "wen", "q" + "wen")
    excluded_dir_names = {
        ".venv",
        ".mypy_cache",
        "__pycache__",
        ".pytest_cache",
        ".cache",
        "artifacts",
    }
    excluded_suffixes = {
        ".safetensors",
        ".pyc",
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".pdf",
        ".lock",
    }

    for path in root.rglob("*"):
        if any(part in excluded_dir_names for part in path.parts):
            continue
        if any(term in str(path.relative_to(root)) for term in legacy_terms):
            raise AssertionError(f"Legacy brand found in path: {path}")
        if not path.is_file() or path.suffix in excluded_suffixes:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for term in legacy_terms:
            assert term not in text, f"Legacy brand found in {path}"


def test_ripgrep_finds_no_legacy_brand_strings() -> None:
    root = Path(__file__).resolve().parents[1]
    legacy_pattern = "|".join(("Q" + "wen", "q" + "wen"))
    command = [
        "rg",
        "-n",
        "--glob",
        "!.venv/**",
        "--glob",
        "!.mypy_cache/**",
        "--glob",
        "!**/__pycache__/**",
        "--glob",
        "!artifacts/**",
        legacy_pattern,
        str(root),
    ]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    assert result.returncode == 1, result.stdout + result.stderr
