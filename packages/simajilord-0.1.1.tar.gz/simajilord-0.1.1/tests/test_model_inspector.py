from pathlib import Path

from cappuccino.model_inspector import inspect_model_dir


def test_inspect_model_dir_reports_expected_capabilities() -> None:
    profile = inspect_model_dir(Path(__file__).resolve().parents[1])

    assert profile.model_name == "Cappuccino-27B"
    assert profile.base_model == ["cappuccino-27b-base"]
    assert profile.model_type == "cappuccino"
    assert "CappuccinoForConditionalGeneration" in profile.architectures
    assert profile.capabilities.image is True
    assert profile.capabilities.video is True
    assert profile.capabilities.tool_calling is True
    assert profile.quantization.is_quantized is False
    assert profile.native_text_context_window == 262144
    assert profile.text_context_window == 1048576
    assert profile.extended_context_claim == 1010000


def test_inspect_model_dir_handles_quantized_layout_without_readme(tmp_path: Path) -> None:
    (tmp_path / "config.json").write_text(
        (
            "{"
            '"model_type":"cappuccino",'
            '"architectures":["CappuccinoForConditionalGeneration"],'
            '"quantization":{"group_size":64,"bits":6,"mode":"affine"},'
            '"text_config":{"max_position_embeddings":262144},'
            '"vision_config":{},'
            '"image_token_id":151652,'
            '"video_token_id":151656'
            "}"
        ),
        encoding="utf-8",
    )
    (tmp_path / "tokenizer_config.json").write_text("{}", encoding="utf-8")
    (tmp_path / "tokenizer.json").write_text(
        '{"added_tokens":[{"content":"<tool_call>"},{"content":"<tool_response>"},{"content":"<think>"}]}',
        encoding="utf-8",
    )
    (tmp_path / "chat_template.jinja").write_text(
        "{% if tools %}<tools></tools>{% endif %}\n<think>\n</think>\n",
        encoding="utf-8",
    )
    (tmp_path / "model.safetensors.index.json").write_text(
        '{"metadata":{"total_size":1234}}',
        encoding="utf-8",
    )
    (tmp_path / "video_preprocessor_config.json").write_text("{}", encoding="utf-8")

    profile = inspect_model_dir(tmp_path)

    assert profile.model_name == tmp_path.name
    assert profile.weight_bytes == 1234
    assert profile.capabilities.image is True
    assert profile.capabilities.video is True
    assert profile.capabilities.tool_calling is True
    assert profile.capabilities.tool_response is True
    assert profile.capabilities.thinking is True
    assert profile.capabilities.openai_chat_template is True
    assert profile.quantization.is_quantized is True
    assert profile.quantization.bits == 6
    assert profile.quantization.group_size == 64
    assert profile.quantization.mode == "affine"
    assert profile.native_text_context_window == 262144
    assert profile.extended_context_claim is None
    assert any("README.md is missing" in note for note in profile.notes)
    assert any("original-precision MLX model" in note for note in profile.notes)


def test_inspect_model_dir_reports_cappuccino_identity_for_q6_copy() -> None:
    profile = inspect_model_dir(Path(__file__).resolve().parents[1] / "artifacts" / "q6")

    assert profile.model_name == "Cappuccino-27B"
    assert profile.base_model == ["cappuccino-27b-base"]
    assert profile.model_type == "cappuccino"
    assert "CappuccinoForConditionalGeneration" in profile.architectures
    assert profile.quantization.is_quantized is True
    assert profile.quantization.bits == 6
