from __future__ import annotations


def test_simajilord_namespace_exposes_public_imports() -> None:
    import simajilord
    from simajilord.cli import build_parser, main
    from simajilord.server import create_app

    assert simajilord.__version__ == "0.1.1"
    assert callable(build_parser)
    assert callable(main)
    assert callable(create_app)
