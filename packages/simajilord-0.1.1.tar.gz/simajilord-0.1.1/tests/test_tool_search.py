from pathlib import Path

import pytest

from cappuccino.tool_search import ToolRegistry


REGISTRY_PATH = (
    Path(__file__).resolve().parents[1] / "examples" / "tool_registry.sample.json"
)


def test_tool_search_matches_name_description_and_tags() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)

    hits = registry.search("video caption timeline", limit=3)

    assert hits
    assert hits[0].name == "describe_video"
    assert "tags" in hits[0].matched_fields or "description" in hits[0].matched_fields


def test_tool_search_builds_openai_compatible_output() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)

    output = registry.build_tool_search_output(
        query="shell command execution",
        limit=2,
        call_id="call_abc123",
    )

    assert output.type == "tool_search_output"
    assert output.call_id == "call_abc123"
    assert output.tools
    assert output.tools[0]["type"] == "function"


def test_tool_search_can_find_wikipedia_tool() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)

    hits = registry.search("wikipedia facts reference", limit=1)

    assert hits
    assert hits[0].name == "wikipedia_search"


def test_tool_search_can_find_tool_search_tool() -> None:
    registry = ToolRegistry.from_file(REGISTRY_PATH)

    hits = registry.search("registry search discovery", limit=1)

    assert hits
    assert hits[0].name == "tool_search"


def test_tool_registry_can_load_directory(tmp_path: Path) -> None:
    (tmp_path / "00-web.json").write_text(
        """
        {
          "type": "namespace",
          "name": "web",
          "description": "web tools",
          "tools": [
            {
              "type": "function",
              "name": "search_web",
              "description": "search pages"
            }
          ]
        }
        """.strip(),
        encoding="utf-8",
    )
    (tmp_path / "10-tools.json").write_text(
        """
        {
          "type": "namespace",
          "name": "tools",
          "description": "runtime tools",
          "tools": [
            {
              "type": "function",
              "name": "tool_search",
              "description": "search registry"
            }
          ]
        }
        """.strip(),
        encoding="utf-8",
    )

    registry = ToolRegistry.from_path(tmp_path)

    assert registry.tool_count == 2
    assert registry.get_tool("tool_search") is not None


def test_tool_registry_rejects_duplicate_tool_names(tmp_path: Path) -> None:
    (tmp_path / "a.json").write_text(
        '[{"type":"function","name":"dup","description":"first"}]',
        encoding="utf-8",
    )
    (tmp_path / "b.json").write_text(
        '[{"type":"function","name":"dup","description":"second"}]',
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="Duplicate tool names"):
        ToolRegistry.from_path(tmp_path)
