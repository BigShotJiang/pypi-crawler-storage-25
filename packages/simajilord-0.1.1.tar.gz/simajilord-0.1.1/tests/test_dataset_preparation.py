from contextlib import nullcontext
import json
from pathlib import Path
from typing import Any

import cappuccino.dataset_preparation as dataset_preparation_module
from cappuccino.dataset_preparation import (
    _parse_quizjam_page_words,
    prepare_egov_six_codes,
    prepare_legal_corpus,
    prepare_quizjam_pdf,
)


def test_parse_quizjam_page_words_separates_question_answer_and_notes() -> None:
    words = [
        {"text": "2", "x0": 255.0, "x1": 261.0, "top": 686.0, "bottom": 695.0, "size": 9.0},
        {"text": "1.", "x0": 49.0, "x1": 56.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {"text": "食べ物のジャムの中でも、オレンジなど柑橘類", "x0": 75.0, "x1": 267.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {"text": "かんきつるい", "x0": 238.0, "x1": 268.0, "top": 220.0, "bottom": 225.0, "size": 5.0},
        {"text": "を原料とし、皮を含むものを何という？", "x0": 75.0, "x1": 280.0, "top": 245.0, "bottom": 254.0, "size": 9.0},
        {"text": "マーマレード", "x0": 361.0, "x1": 415.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {"text": "【◯：柑橘系ジャム】", "x0": 361.0, "x1": 440.0, "top": 245.0, "bottom": 253.0, "size": 8.0},
    ]

    records = _parse_quizjam_page_words(
        words=words,
        page_width=515.88,
        page_height=728.52,
        pdf_page_index=4,
    )

    assert len(records) == 1
    record = records[0]
    assert record.number == 1
    assert record.book_page == 2
    assert record.section == "season1"
    assert record.question_clean == "食べ物のジャムの中でも、オレンジなど柑橘類を原料とし、皮を含むものを何という?"
    assert record.answer_clean == "マーマレード"
    assert record.notes == ["【◯:柑橘系ジャム】"]
    assert record.reading_tokens == ["かんきつるい"]


def test_parse_quizjam_page_words_drops_answer_furigana_and_joins_wrapped_notes() -> None:
    words = [
        {"text": "475.", "x0": 42.0, "x1": 58.0, "top": 301.0, "bottom": 310.0, "size": 9.0},
        {"text": "江戸時代の藩で、毛利氏が代々藩主を務めたのはどこ?", "x0": 75.0, "x1": 300.0, "top": 301.0, "bottom": 310.0, "size": 9.0},
        {"text": "長", "x0": 364.0, "x1": 379.0, "top": 301.0, "bottom": 310.0, "size": 9.0},
        {"text": "州", "x0": 379.0, "x1": 390.0, "top": 301.0, "bottom": 310.0, "size": 9.0},
        {"text": "藩", "x0": 391.0, "x1": 400.0, "top": 301.0, "bottom": 310.0, "size": 9.0},
        {"text": "ちょうしゅう", "x0": 361.0, "x1": 392.0, "top": 295.4, "bottom": 300.4, "size": 5.0},
        {"text": "【〇:萩", "x0": 361.0, "x1": 390.0, "top": 321.8, "bottom": 329.8, "size": 8.0},
        {"text": "はぎ", "x0": 385.0, "x1": 397.0, "top": 315.5, "bottom": 320.5, "size": 5.0},
        {"text": "藩、山口藩】", "x0": 395.0, "x1": 440.0, "top": 321.8, "bottom": 329.8, "size": 8.0},
    ]

    records = _parse_quizjam_page_words(
        words=words,
        page_width=515.88,
        page_height=728.52,
        pdf_page_index=54,
    )

    assert len(records) == 1
    record = records[0]
    assert record.answer_clean == "長州藩"
    assert record.notes == ["【〇:萩藩、山口藩】"]


def test_parse_quizjam_page_words_keeps_full_size_hiragana_answer() -> None:
    words = [
        {"text": "193.", "x0": 43.1, "x1": 61.8, "top": 111.5, "bottom": 120.5, "size": 9.0},
        {"text": "「水に流さない」というゲン担ぎから、どれだけ汚れても洗濯をしな", "x0": 74.8, "x1": 349.7, "top": 111.5, "bottom": 120.5, "size": 9.0},
        {"text": "いという風習がある、相撲で力士が締めるふんどしの一種を何とい", "x0": 74.8, "x1": 349.5, "top": 131.5, "bottom": 140.5, "size": 9.0},
        {"text": "う?", "x0": 74.8, "x1": 92.8, "top": 151.6, "bottom": 160.6, "size": 9.0},
        {"text": "まわし", "x0": 361.1, "x1": 388.1, "top": 111.5, "bottom": 120.5, "size": 9.0},
        {"text": "【〇:しめこみ】", "x0": 361.1, "x1": 425.2, "top": 132.4, "bottom": 140.4, "size": 8.0},
    ]

    records = _parse_quizjam_page_words(
        words=words,
        page_width=515.88,
        page_height=728.52,
        pdf_page_index=25,
    )

    assert len(records) == 1
    record = records[0]
    assert record.number == 193
    assert record.answer_clean == "まわし"
    assert record.notes == ["【〇:しめこみ】"]


def test_parse_quizjam_page_words_drops_long_small_furigana_answer_line() -> None:
    words = [
        {"text": "467.", "x0": 42.1, "x1": 61.8, "top": 427.4, "bottom": 436.4, "size": 9.0},
        {"text": "奈良時代に三世一身法の後を受けて制定された、新たに開墾した土地の私有化を永久に認める法律は何?", "x0": 74.8, "x1": 347.3, "top": 427.4, "bottom": 436.4, "size": 9.0},
        {"text": "こんでんえいねんしざいほう", "x0": 361.1, "x1": 428.0, "top": 421.9, "bottom": 426.9, "size": 5.0},
        {"text": "墾田", "x0": 361.6, "x1": 381.6, "top": 427.4, "bottom": 436.4, "size": 9.0},
        {"text": "永年", "x0": 381.6, "x1": 401.0, "top": 427.4, "bottom": 436.4, "size": 9.0},
        {"text": "私財法", "x0": 401.0, "x1": 430.0, "top": 427.4, "bottom": 436.4, "size": 9.0},
    ]

    records = _parse_quizjam_page_words(
        words=words,
        page_width=515.88,
        page_height=728.52,
        pdf_page_index=53,
    )

    assert len(records) == 1
    record = records[0]
    assert record.number == 467
    assert record.answer_clean == "墾田永年私財法"


def test_parse_quizjam_page_words_keeps_bottom_question_line_and_ignores_printed_page_number() -> None:
    words = [
        {"text": "3", "x0": 254.9, "x1": 261.0, "top": 686.2, "bottom": 695.2, "size": 9.0},
        {"text": "17.", "x0": 46.2, "x1": 58.7, "top": 623.6, "bottom": 632.6, "size": 9.0},
        {"text": "「気軽には行きにくい」という意味で誤用されることが多い言葉で、", "x0": 74.8, "x1": 354.2, "top": 623.6, "bottom": 632.6, "size": 9.0},
        {"text": "敷", "x0": 361.6, "x1": 370.6, "top": 623.6, "bottom": 632.6, "size": 9.0},
        {"text": "居", "x0": 371.1, "x1": 380.1, "top": 623.6, "bottom": 632.6, "size": 9.0},
        {"text": "が高い", "x0": 380.1, "x1": 407.1, "top": 623.6, "bottom": 632.6, "size": 9.0},
        {"text": "「不義理などをしたため相手の家に行きにくい」ということを「何が", "x0": 74.8, "x1": 349.7, "top": 643.5, "bottom": 652.5, "size": 9.0},
        {"text": "高い」という?", "x0": 74.8, "x1": 137.8, "top": 663.6, "bottom": 672.6, "size": 9.0},
    ]

    records = _parse_quizjam_page_words(
        words=words,
        page_width=515.88,
        page_height=728.52,
        pdf_page_index=5,
    )

    assert len(records) == 1
    record = records[0]
    assert record.book_page == 3
    assert record.question_clean == (
        "「気軽には行きにくい」という意味で誤用されることが多い言葉で、 "
        "「不義理などをしたため相手の家に行きにくい」ということを「何が高い」という?"
    )
    assert record.answer_clean == "敷居が高い"


def test_prepare_legal_corpus_writes_cpt_examples(tmp_path: Path) -> None:
    source_path = tmp_path / "civil_code_excerpt.txt"
    source_path.write_text(
        "\n".join(
            [
                "民法",
                "第1条 私権は、公共の福祉に適合しなければならない。",
                "第2条 権利の行使及び義務の履行は、信義に従い誠実に行わなければならない。",
            ]
        ),
        encoding="utf-8",
    )
    output_path = tmp_path / "legal_cpt.jsonl"

    report = prepare_legal_corpus(
        input_paths=[source_path],
        output_path=output_path,
        kind="law",
        source_label="six_codes",
        max_chars=80,
        min_chars=20,
    )

    assert report.kind == "legal_corpus"
    assert report.total_records >= 2
    records = [json.loads(line) for line in output_path.read_text(encoding="utf-8").splitlines()]
    assert records
    assert all(record["task_type"] == "cpt" for record in records)
    assert all(record["metadata"]["source_label"] == "six_codes" for record in records)
    assert any("法令継続事前学習コーパス" in record["text"] for record in records)


def test_prepare_egov_six_codes_writes_article_cpt(tmp_path: Path, monkeypatch: Any) -> None:
    lawlist_xml = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawNameListInfo><LawId>321CONSTITUTION</LawId><LawName>日本国憲法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>129AC0000000089</LawId><LawName>民法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>132AC0000000048</LawId><LawName>商法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>140AC0000000045</LawId><LawName>刑法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>408AC0000000109</LawId><LawName>民事訴訟法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>323AC0000000131</LawId><LawName>刑事訴訟法</LawName></LawNameListInfo>
  </ApplData>
</DataRoot>
"""
    template = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawFullText>
      <Law>
        <LawNum>テスト法令番号</LawNum>
        <LawBody>
          <LawTitle>{title}</LawTitle>
          <Preamble>
            <Paragraph Num="1"><ParagraphSentence><Sentence>{title}の前文です。</Sentence></ParagraphSentence></Paragraph>
          </Preamble>
          <MainProvision>
            <Article Num="1">
              <ArticleTitle>第一条</ArticleTitle>
              <ArticleCaption>（総則）</ArticleCaption>
              <Paragraph Num="1"><ParagraphSentence><Sentence>{title}の第一条本文です。</Sentence></ParagraphSentence></Paragraph>
            </Article>
          </MainProvision>
        </LawBody>
      </Law>
    </LawFullText>
  </ApplData>
</DataRoot>
"""
    title_by_id = {
        "321CONSTITUTION": "日本国憲法",
        "129AC0000000089": "民法",
        "132AC0000000048": "商法",
        "140AC0000000045": "刑法",
        "408AC0000000109": "民事訴訟法",
        "323AC0000000131": "刑事訴訟法",
    }

    def fake_download(url: str) -> str:
        if url.endswith("/lawlists/1"):
            return lawlist_xml
        law_id = url.rsplit("/", 1)[-1]
        return template.format(title=title_by_id[law_id])

    monkeypatch.setattr(dataset_preparation_module, "_download_text", fake_download)

    report = prepare_egov_six_codes(output_dir=tmp_path / "egov")

    assert report.kind == "egov_six_codes"
    assert report.total_records == 24
    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]
    assert len(cpt_records) == 24
    assert any("条文: 第一条" in record["text"] for record in cpt_records)
    assert any("条文: 前文" in record["text"] for record in cpt_records)
    assert any("項番号: 第一項" in record["text"] for record in cpt_records)
    assert all("条項パス:" in record["text"] for record in cpt_records)
    assert all("\n第二項: 2 " not in record["text"] for record in cpt_records)


def test_prepare_egov_six_codes_splits_long_article_for_cpt(tmp_path: Path, monkeypatch: Any) -> None:
    lawlist_xml = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawNameListInfo><LawId>321CONSTITUTION</LawId><LawName>日本国憲法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>129AC0000000089</LawId><LawName>民法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>132AC0000000048</LawId><LawName>商法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>140AC0000000045</LawId><LawName>刑法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>408AC0000000109</LawId><LawName>民事訴訟法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>323AC0000000131</LawId><LawName>刑事訴訟法</LawName></LawNameListInfo>
  </ApplData>
</DataRoot>
"""
    short_body = "短い条文です。"
    long_body = " ".join(["長い本文です。" + ("あ" * 700), "さらに本文が続きます。" + ("い" * 700), "末尾です。" + ("う" * 700)])
    title_by_id = {
        "321CONSTITUTION": "日本国憲法",
        "129AC0000000089": "民法",
        "132AC0000000048": "商法",
        "140AC0000000045": "刑法",
        "408AC0000000109": "民事訴訟法",
        "323AC0000000131": "刑事訴訟法",
    }

    def fake_download(url: str) -> str:
        if url.endswith("/lawlists/1"):
            return lawlist_xml
        law_id = url.rsplit("/", 1)[-1]
        body = long_body if law_id == "323AC0000000131" else short_body
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawFullText>
      <Law>
        <LawNum>テスト法令番号</LawNum>
        <LawBody>
          <LawTitle>{title_by_id[law_id]}</LawTitle>
          <Preamble>
            <Paragraph Num="1"><ParagraphSentence><Sentence>{title_by_id[law_id]}の前文です。</Sentence></ParagraphSentence></Paragraph>
          </Preamble>
          <MainProvision>
            <Article Num="1">
              <ArticleTitle>第一条</ArticleTitle>
              <ArticleCaption>（総則）</ArticleCaption>
              <Paragraph Num="1"><ParagraphSentence><Sentence>{body}</Sentence></ParagraphSentence></Paragraph>
            </Article>
          </MainProvision>
        </LawBody>
      </Law>
    </LawFullText>
  </ApplData>
</DataRoot>
"""

    monkeypatch.setattr(dataset_preparation_module, "_download_text", fake_download)

    report = prepare_egov_six_codes(output_dir=tmp_path / "egov")

    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]
    assert report.total_records > 12
    assert any(record["metadata"].get("chunk_count", 1) > 1 for record in cpt_records)
    assert any("本文断片:" in record["text"] for record in cpt_records)
    assert any(record["metadata"].get("paragraph_chunk_count", 1) > 1 for record in cpt_records)
    assert any("項本文断片:" in record["text"] for record in cpt_records)


def test_prepare_egov_six_codes_preserves_suppl_provision_context(tmp_path: Path, monkeypatch: Any) -> None:
    lawlist_xml = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawNameListInfo><LawId>321CONSTITUTION</LawId><LawName>日本国憲法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>129AC0000000089</LawId><LawName>民法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>132AC0000000048</LawId><LawName>商法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>140AC0000000045</LawId><LawName>刑法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>408AC0000000109</LawId><LawName>民事訴訟法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>323AC0000000131</LawId><LawName>刑事訴訟法</LawName></LawNameListInfo>
  </ApplData>
</DataRoot>
"""
    title_by_id = {
        "321CONSTITUTION": "日本国憲法",
        "129AC0000000089": "民法",
        "132AC0000000048": "商法",
        "140AC0000000045": "刑法",
        "408AC0000000109": "民事訴訟法",
        "323AC0000000131": "刑事訴訟法",
    }

    def fake_download(url: str) -> str:
        if url.endswith("/lawlists/1"):
            return lawlist_xml
        law_id = url.rsplit("/", 1)[-1]
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawFullText>
      <Law>
        <LawNum>テスト法令番号</LawNum>
        <LawBody>
          <LawTitle>{title_by_id[law_id]}</LawTitle>
          <MainProvision>
            <Part>
              <PartTitle>第一編 総則</PartTitle>
              <Article Num="1">
                <ArticleTitle>第一条</ArticleTitle>
                <Paragraph Num="1"><ParagraphSentence><Sentence>本則本文です。</Sentence></ParagraphSentence></Paragraph>
              </Article>
            </Part>
          </MainProvision>
          <SupplProvision AmendLawNum="令和六年法律第七号">
            <SupplProvisionLabel>附則</SupplProvisionLabel>
            <Article Num="1">
              <ArticleTitle>第一条</ArticleTitle>
              <Paragraph Num="1"><ParagraphSentence><Sentence>附則本文です。</Sentence></ParagraphSentence></Paragraph>
            </Article>
          </SupplProvision>
        </LawBody>
      </Law>
    </LawFullText>
  </ApplData>
</DataRoot>
"""

    monkeypatch.setattr(dataset_preparation_module, "_download_text", fake_download)

    report = prepare_egov_six_codes(output_dir=tmp_path / "egov")

    structured_records = [
        json.loads(line)
        for line in Path(report.output_paths["articles"]).read_text(encoding="utf-8").splitlines()
    ]
    suppl_record = next(
        record
        for record in structured_records
        if record["article_text"].startswith("第一項: 附則本文です。")
    )
    assert suppl_record["article_context"] == "附則 [令和六年法律第七号]"
    assert suppl_record["article_path"] == ["附則 [令和六年法律第七号]", "第一条"]

    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]
    suppl_paragraph_record = next(
        record
        for record in cpt_records
        if record["metadata"].get("record_kind") == "paragraph"
        and record["metadata"].get("article_context") == "附則 [令和六年法律第七号]"
    )
    assert "条項パス: 附則 [令和六年法律第七号] > 第一条 > 第一項" in suppl_paragraph_record["text"]


def test_prepare_egov_six_codes_strips_paragraph_number_from_body(tmp_path: Path, monkeypatch: Any) -> None:
    lawlist_xml = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawNameListInfo><LawId>321CONSTITUTION</LawId><LawName>日本国憲法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>129AC0000000089</LawId><LawName>民法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>132AC0000000048</LawId><LawName>商法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>140AC0000000045</LawId><LawName>刑法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>408AC0000000109</LawId><LawName>民事訴訟法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>323AC0000000131</LawId><LawName>刑事訴訟法</LawName></LawNameListInfo>
  </ApplData>
</DataRoot>
"""
    title_by_id = {
        "321CONSTITUTION": "日本国憲法",
        "129AC0000000089": "民法",
        "132AC0000000048": "商法",
        "140AC0000000045": "刑法",
        "408AC0000000109": "民事訴訟法",
        "323AC0000000131": "刑事訴訟法",
    }

    def fake_download(url: str) -> str:
        if url.endswith("/lawlists/1"):
            return lawlist_xml
        law_id = url.rsplit("/", 1)[-1]
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawFullText>
      <Law>
        <LawNum>テスト法令番号</LawNum>
        <LawBody>
          <LawTitle>{title_by_id[law_id]}</LawTitle>
          <MainProvision>
            <Article Num="1">
              <ArticleTitle>第一条</ArticleTitle>
              <Paragraph Num="1">
                <ParagraphNum />
                <ParagraphSentence><Sentence>第一項本文です。</Sentence></ParagraphSentence>
              </Paragraph>
              <Paragraph Num="2">
                <ParagraphNum>２</ParagraphNum>
                <ParagraphSentence><Sentence>第二項本文です。</Sentence></ParagraphSentence>
              </Paragraph>
            </Article>
          </MainProvision>
        </LawBody>
      </Law>
    </LawFullText>
  </ApplData>
</DataRoot>
"""

    monkeypatch.setattr(dataset_preparation_module, "_download_text", fake_download)

    report = prepare_egov_six_codes(output_dir=tmp_path / "egov")
    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]
    second_paragraph = next(
        record
        for record in cpt_records
        if record["metadata"].get("record_kind") == "paragraph"
        and record["metadata"].get("paragraph_index") == 2
    )

    assert "第二項: 2 第二項本文です。" not in second_paragraph["text"]
    assert "第二項: 第二項本文です。" in second_paragraph["text"]


def test_build_cpt_dataset_text_does_not_inline_metadata_dict(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    lawlist_xml = """<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawNameListInfo><LawId>321CONSTITUTION</LawId><LawName>日本国憲法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>129AC0000000089</LawId><LawName>民法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>132AC0000000048</LawId><LawName>商法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>140AC0000000045</LawId><LawName>刑法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>408AC0000000109</LawId><LawName>民事訴訟法</LawName></LawNameListInfo>
    <LawNameListInfo><LawId>323AC0000000131</LawId><LawName>刑事訴訟法</LawName></LawNameListInfo>
  </ApplData>
</DataRoot>
"""
    title_by_id = {
        "321CONSTITUTION": "日本国憲法",
        "129AC0000000089": "民法",
        "132AC0000000048": "商法",
        "140AC0000000045": "刑法",
        "408AC0000000109": "民事訴訟法",
        "323AC0000000131": "刑事訴訟法",
    }

    def fake_download(url: str) -> str:
        if url.endswith("/lawlists/1"):
            return lawlist_xml
        law_id = url.rsplit("/", 1)[-1]
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<DataRoot>
  <ApplData>
    <LawFullText>
      <Law>
        <LawNum>テスト法令番号</LawNum>
        <LawBody>
          <LawTitle>{title_by_id[law_id]}</LawTitle>
          <MainProvision>
            <Article Num="1">
              <ArticleTitle>第一条</ArticleTitle>
              <Paragraph Num="1"><ParagraphSentence><Sentence>本文です。</Sentence></ParagraphSentence></Paragraph>
            </Article>
          </MainProvision>
        </LawBody>
      </Law>
    </LawFullText>
  </ApplData>
</DataRoot>
"""

    monkeypatch.setattr(dataset_preparation_module, "_download_text", fake_download)

    report = prepare_egov_six_codes(output_dir=tmp_path / "egov")
    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]

    assert cpt_records
    assert all("{'source_label':" not in record["text"] for record in cpt_records)
    assert all('"source_label":' not in record["text"] for record in cpt_records)
    assert all("metadata" not in record["text"] for record in cpt_records)


def test_is_quizjam_relative_time_question_filters_only_creation_time_dependent_clues() -> None:
    assert dataset_preparation_module._is_quizjam_relative_time_question(
        "今年、万国博覧会が開催される日本の都市はどこ?"
    )
    assert dataset_preparation_module._is_quizjam_relative_time_question(
        "昨シーズンのメジャーリーグで前人未到の記録を達成した選手は誰?"
    )
    assert not dataset_preparation_module._is_quizjam_relative_time_question(
        "2024年大会から出場制限が撤廃された、お笑い賞レースは何?"
    )
    assert not dataset_preparation_module._is_quizjam_relative_time_question(
        "現在は渋谷駅構内のコンコースに展示されている絵画は何?"
    )


def test_prepare_quizjam_pdf_excludes_relative_time_questions_from_outputs(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    relative_time_words = [
        {"text": "4", "x0": 255.0, "x1": 261.0, "top": 686.0, "bottom": 695.0, "size": 9.0},
        {"text": "24.", "x0": 46.0, "x1": 61.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {
            "text": "今年、万国博覧会が開催される日本の都市はどこ?",
            "x0": 75.0,
            "x1": 310.0,
            "top": 225.0,
            "bottom": 234.0,
            "size": 9.0,
        },
        {"text": "大阪市", "x0": 361.0, "x1": 405.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
    ]
    stable_words = [
        {"text": "2", "x0": 255.0, "x1": 261.0, "top": 686.0, "bottom": 695.0, "size": 9.0},
        {"text": "1.", "x0": 49.0, "x1": 56.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {
            "text": "食べ物のジャムの中でも、オレンジなど柑橘類",
            "x0": 75.0,
            "x1": 267.0,
            "top": 225.0,
            "bottom": 234.0,
            "size": 9.0,
        },
        {"text": "かんきつるい", "x0": 238.0, "x1": 268.0, "top": 220.0, "bottom": 225.0, "size": 5.0},
        {"text": "を原料とし、皮を含むものを何という？", "x0": 75.0, "x1": 280.0, "top": 245.0, "bottom": 254.0, "size": 9.0},
        {"text": "マーマレード", "x0": 361.0, "x1": 415.0, "top": 225.0, "bottom": 234.0, "size": 9.0},
        {"text": "【◯：柑橘系ジャム】", "x0": 361.0, "x1": 440.0, "top": 245.0, "bottom": 253.0, "size": 8.0},
    ]

    class FakePage:
        width = 515.88
        height = 728.52

        def __init__(self, words: list[dict[str, Any]]) -> None:
            self._words = words

        def extract_words(
            self,
            *,
            use_text_flow: bool,
            keep_blank_chars: bool,
            extra_attrs: list[str],
        ) -> list[dict[str, Any]]:
            assert use_text_flow is False
            assert keep_blank_chars is False
            assert extra_attrs == ["size"]
            return self._words

    class FakePdf:
        def __init__(self, pages: list[FakePage]) -> None:
            self.pages = pages

    def fake_open(_path: Path) -> Any:
        return nullcontext(FakePdf([FakePage(relative_time_words), FakePage(stable_words)]))

    monkeypatch.setattr(dataset_preparation_module.pdfplumber, "open", fake_open)

    report = prepare_quizjam_pdf(
        pdf_path=tmp_path / "quizjam.pdf",
        output_dir=tmp_path / "out",
        copy_source=False,
    )

    assert report.total_records == 1
    assert any("Excluded 1 QuizJam records" in warning for warning in report.warnings)

    records = [
        json.loads(line)
        for line in Path(report.output_paths["records"]).read_text(encoding="utf-8").splitlines()
    ]
    assert [record["number"] for record in records] == [1]

    cpt_records = [
        json.loads(line)
        for line in Path(report.output_paths["cpt"]).read_text(encoding="utf-8").splitlines()
    ]
    answer_sft_records = [
        json.loads(line)
        for line in Path(report.output_paths["answer_sft"]).read_text(encoding="utf-8").splitlines()
    ]
    writer_sft_records = [
        json.loads(line)
        for line in Path(report.output_paths["question_writer_sft"]).read_text(encoding="utf-8").splitlines()
    ]
    mixed_records = [
        json.loads(line)
        for line in Path(report.output_paths["mixed"]).read_text(encoding="utf-8").splitlines()
    ]

    assert len(cpt_records) == 1
    assert len(answer_sft_records) == 1
    assert len(writer_sft_records) == 1
    assert len(mixed_records) == 3
    assert all(record["metadata"]["question_number"] == 1 for record in cpt_records)
    assert all(record["metadata"]["question_number"] == 1 for record in answer_sft_records)
    assert all(record["metadata"]["question_number"] == 1 for record in writer_sft_records)
    assert all(record["metadata"]["question_number"] == 1 for record in mixed_records)


def test_quizjam_question_writer_example_uses_answer_to_question_sft_format() -> None:
    record = dataset_preparation_module.QuizJamQuestion(
        number=1,
        pdf_page_index=4,
        book_page=2,
        section="season1",
        question_raw="食べ物のジャムの中でも...",
        question_clean="食べ物のジャムの中でも、オレンジなど柑橘類を原料とし、皮を含んでいるものを何という?",
        answer_raw="マーマレード",
        answer_clean="マーマレード",
        notes=["【◯:柑橘系ジャム】"],
        reading_tokens=["かんきつるい"],
    )

    example = dataset_preparation_module._quizjam_question_writer_example(record)
    messages = example["messages"]

    assert messages[0]["role"] == "system"
    assert "return only the question text" in messages[0]["content"]
    assert messages[1] == {
        "role": "user",
        "content": "答えが「マーマレード」になるクイズを一問作成してください。",
    }
    assert messages[2] == {
        "role": "assistant",
        "content": "食べ物のジャムの中でも、オレンジなど柑橘類を原料とし、皮を含んでいるものを何という?",
    }
