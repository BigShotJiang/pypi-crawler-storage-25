from cappuccino.benchmarking import (
    BenchmarkCaseResult,
    _extract_candidate_code,
    _summaries,
    normalize_benchmark_modes,
)


def test_extract_candidate_code_prefers_fenced_python_block() -> None:
    text = """
    Here is the implementation.

    ```python
    def hello() -> str:
        return "world"
    ```
    """

    code = _extract_candidate_code(text)

    assert code.startswith("def hello")
    assert 'return "world"' in code


def test_summaries_compute_quality_and_speed() -> None:
    results = [
        BenchmarkCaseResult(
            mode="off",
            task="a",
            passed=True,
            elapsed_sec=1.0,
            prompt_tps=10.0,
            generation_tps=5.0,
            assistant_content="def a():\n    return 1",
            candidate_code="def a():\n    return 1",
            evaluation_output="ok",
        ),
        BenchmarkCaseResult(
            mode="off",
            task="b",
            passed=False,
            elapsed_sec=3.0,
            prompt_tps=20.0,
            generation_tps=7.0,
            assistant_content="def b():\n    return 2",
            candidate_code="def b():\n    return 2",
            evaluation_output="AssertionError",
        ),
    ]

    summaries = _summaries(results)

    assert len(summaries) == 1
    assert summaries[0].mode == "off"
    assert summaries[0].quality_score == 0.5
    assert summaries[0].avg_elapsed_sec == 2.0
    assert summaries[0].avg_prompt_tps == 15.0


def test_normalize_benchmark_modes_dedupes_and_preserves_order() -> None:
    modes = normalize_benchmark_modes(["auto", "off", "adaptive"])

    assert modes == ("auto", "off")
