import json
from pathlib import Path
from typing import Any

import cappuccino.preference_loop as loop_module
from cappuccino.model_inspector import ModelCapabilities, ModelProfile, ModelQuantization
from cappuccino.preference_loop import PreferenceCandidate, PreferenceLoopConfig, run_preference_loop
from cappuccino.trainer import DatasetComposition, MemoryEstimate, TrainingRunReport


def _fake_model_profile(path: Path) -> ModelProfile:
    return ModelProfile(
        model_dir=str(path),
        model_name="fake",
        model_type="cappuccino",
        text_context_window=1010000,
        extended_context_claim=None,
        weight_bytes=1234,
        quantization=ModelQuantization(),
        capabilities=ModelCapabilities(
            image=False,
            video=False,
            tool_calling=False,
            tool_response=False,
            thinking=False,
            openai_chat_template=True,
            openai_api_serving_docs=False,
        ),
    )


def test_run_preference_loop_persists_feedback_before_training(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    output_dir = tmp_path / "preference-loop"
    monkeypatch.setattr(loop_module, "inspect_model_dir", lambda path: _fake_model_profile(Path(path)))
    monkeypatch.setattr(
        loop_module,
        "_generate_candidate_pair",
        lambda **kwargs: (
            PreferenceCandidate(label="A", seed=1, temperature=0.6, output_text="良い回答A"),
            PreferenceCandidate(label="B", seed=2, temperature=0.9, output_text="良い回答B"),
        ),
    )
    monkeypatch.setattr("builtins.input", lambda prompt="": "a")

    def fake_run_training(config: Any) -> TrainingRunReport:
        return TrainingRunReport(
            mode="train",
            status="completed",
            model_path=config.model_path,
            dataset_path=config.dataset_path,
            output_dir=config.output_dir,
            dataset=DatasetComposition(
                train_examples=1,
                valid_examples=0,
                cpt_examples=0,
                chat_examples=0,
                multimodal_chat_examples=0,
                tool_call_messages=0,
                tool_result_messages=0,
                thinking_examples=0,
                placeholder_only_multimodal_examples=0,
            ),
            memory=MemoryEstimate(
                trainable_parameter_count=1,
                estimated_activation_bytes=1,
                estimated_optimizer_bytes=1,
                estimated_peak_working_set_bytes=1,
            ),
            adapter_file=str(Path(config.output_dir) / "adapters.safetensors"),
        )

    monkeypatch.setattr(loop_module, "run_training", fake_run_training)

    report = run_preference_loop(
        PreferenceLoopConfig(
            model_path=str(tmp_path / "model"),
            output_dir=str(output_dir),
            prompt="良いコードレビューとは?",
            max_rounds=1,
        )
    )

    assert report.completed_rounds == 1
    assert report.total_preferences == 1
    assert report.exit_reason == "max_rounds_reached"

    preference_path = output_dir / "preferences.jsonl"
    record = json.loads(preference_path.read_text(encoding="utf-8").splitlines()[0])
    assert record["chosen"][1]["content"] == "良い回答A"
    assert record["rejected"][1]["content"] == "良い回答B"

    state = json.loads((output_dir / "preference_loop_state.json").read_text(encoding="utf-8"))
    assert state["completed_rounds"] == 1
    assert state["current_adapter_path"].endswith("adapters.safetensors")


def test_run_preference_loop_allows_skip_then_safe_quit(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    output_dir = tmp_path / "preference-loop"
    monkeypatch.setattr(loop_module, "inspect_model_dir", lambda path: _fake_model_profile(Path(path)))
    generated_pairs = iter(
        [
            (
                PreferenceCandidate(label="A", seed=1, temperature=0.6, output_text="最初のA"),
                PreferenceCandidate(label="B", seed=2, temperature=0.9, output_text="最初のB"),
            ),
            (
                PreferenceCandidate(label="A", seed=3, temperature=0.6, output_text="次のA"),
                PreferenceCandidate(label="B", seed=4, temperature=0.9, output_text="次のB"),
            ),
        ]
    )
    monkeypatch.setattr(loop_module, "_generate_candidate_pair", lambda **kwargs: next(generated_pairs))
    inputs = iter(["s", ":quit"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(inputs))

    def fail_run_training(config: Any) -> TrainingRunReport:
        raise AssertionError("training should not start when the user quits before choosing")

    monkeypatch.setattr(loop_module, "run_training", fail_run_training)

    report = run_preference_loop(
        PreferenceLoopConfig(
            model_path=str(tmp_path / "model"),
            output_dir=str(output_dir),
            prompt="別の質問",
        )
    )

    assert report.completed_rounds == 0
    assert report.total_preferences == 0
    assert report.exit_reason == "user_quit"
    assert not (output_dir / "preferences.jsonl").exists()
