import argparse
from pathlib import Path
from typing import Any

import cappuccino.cli as cli_module
from cappuccino.cli import build_parser
from cappuccino.trainer import DatasetComposition, MemoryEstimate, TrainingRunReport


def test_train_parser_enables_grad_checkpoint_by_default() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "train",
            "--model-path",
            "/tmp/model",
            "--dataset-path",
            "/tmp/train.jsonl",
            "--output-dir",
            "/tmp/out",
        ]
    )

    assert args.grad_checkpoint is True
    assert args.base_last_layers == 0
    assert args.max_seq_length == 0
    assert args.metal_memory_budget_mode == "device"
    assert args.metal_cache_limit_bytes == 0
    assert args.metal_cache_clear_interval == 1
    assert args.training_memory_reserve_bytes == 64 * 1024 * 1024
    assert args.strict_token_audit is True
    assert args.checkpoint_sample is True
    assert args.checkpoint_sample_prompt == "AIについて説明してください"
    assert args.checkpoint_sample_max_tokens == 8192
    assert args.checkpoint_sample_max_kv_size == 2048
    assert args.checkpoint_sample_kv_bits == 4
    assert args.checkpoint_sample_kv_group_size == 64
    assert args.train_mode == "sft"
    assert args.orpo_beta == 0.1
    assert args.train_vision is False
    assert args.adapter_path is None
    assert args.epochs is None
    assert args.delete_dataset_after_success is False
    assert args.auto_desktop_input_output is True
    assert args.preserve_dataset_state is True


def test_sync_openai_api_contract_parser_defaults() -> None:
    parser = build_parser()

    args = parser.parse_args(["sync-openai-api-contract"])

    assert str(args.output_path) == "artifacts/openai_api_contract.json"
    assert args.check_latest_release is True
    assert args.timeout_sec == 30.0


def test_train_parser_allows_disabling_grad_checkpoint() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "train",
            "--model-path",
            "/tmp/model",
            "--dataset-path",
            "/tmp/train.jsonl",
            "--output-dir",
            "/tmp/out",
            "--no-grad-checkpoint",
        ]
    )

    assert args.grad_checkpoint is False


def test_train_parser_accepts_metal_cache_overrides() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "train",
            "--model-path",
            "/tmp/model",
            "--dataset-path",
            "/tmp/train.jsonl",
            "--output-dir",
            "/tmp/out",
            "--metal-cache-limit-bytes",
            "268435456",
            "--metal-cache-clear-interval",
            "2",
        ]
    )

    assert args.metal_cache_limit_bytes == 268435456
    assert args.metal_cache_clear_interval == 2


def test_prepare_quizjam_pdf_parser_defaults_to_copying_source() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-quizjam-pdf",
            "--pdf-path",
            "/tmp/quizjam.pdf",
            "--output-dir",
            "/tmp/out",
        ]
    )

    assert args.copy_source is True


def test_dataset_status_parser_reads_output_dir() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "dataset-status",
            "--output-dir",
            "/tmp/wikipedia",
        ]
    )

    assert str(args.output_dir) == "/tmp/wikipedia"


def test_skill_search_parser_reads_registry_and_query() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "skill-search",
            "--registry",
            "/tmp/skills",
            "--query",
            "openai docs",
        ]
    )

    assert str(args.registry) == "/tmp/skills"
    assert args.query == "openai docs"
    assert args.limit == 5


def test_list_skills_parser_reads_registry() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "list-skills",
            "--registry",
            "/tmp/skills",
        ]
    )

    assert str(args.registry) == "/tmp/skills"


def test_prepare_legal_corpus_parser_reads_multiple_inputs() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-legal-corpus",
            "--input",
            "/tmp/law.txt",
            "/tmp/case.pdf",
            "--output-path",
            "/tmp/legal.jsonl",
            "--kind",
            "case",
        ]
    )

    assert [str(path) for path in args.input] == ["/tmp/law.txt", "/tmp/case.pdf"]
    assert args.kind == "case"


def test_prepare_egov_six_codes_parser_reads_output_dir() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-egov-six-codes",
            "--output-dir",
            "/tmp/egov",
        ]
    )

    assert str(args.output_dir) == "/tmp/egov"


def test_prepare_kokkai_cpt_parser_defaults_to_single_epoch() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-kokkai-cpt",
            "--output-dir",
            "/tmp/kokkai",
        ]
    )

    assert str(args.output_dir) == "/tmp/kokkai"
    assert args.repeat == 1
    assert args.session_from == 1
    assert args.session_to == 999
    assert args.max_meetings_per_run is None


def test_prepare_openai_docs_cpt_parser_defaults_to_two_epochs() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-openai-docs-cpt",
            "--output-dir",
            "/tmp/openai-docs",
        ]
    )

    assert str(args.output_dir) == "/tmp/openai-docs"
    assert args.max_pages_per_run is None
    assert args.repeat == 2


def test_prepare_kaken_cpt_parser_defaults_to_two_epochs() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-kaken-cpt",
            "--output-dir",
            "/tmp/kaken",
        ]
    )

    assert str(args.output_dir) == "/tmp/kaken"
    assert args.max_projects_per_run is None
    assert args.repeat == 2
    assert args.request_interval_sec == 0.5


def test_prepare_ndl_next_digital_library_cpt_parser_defaults_to_two_epochs() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-ndl-next-digital-library-cpt",
            "--output-dir",
            "/tmp/ndl",
        ]
    )

    assert str(args.output_dir) == "/tmp/ndl"
    assert args.max_items_per_run is None
    assert args.repeat == 2
    assert args.request_interval_sec == 0.5


def test_prepare_wikipedia_cpt_parser_includes_images_by_default() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-wikipedia-cpt",
            "--output-dir",
            "/tmp/wikipedia",
        ]
    )

    assert str(args.output_dir) == "/tmp/wikipedia"
    assert args.include_images is True
    assert args.image_detail == "auto"
    assert args.repeat == 2


def test_prepare_wikipedia_recent_changes_cpt_parser_defaults() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-wikipedia-recent-changes-cpt",
            "--output-dir",
            "/tmp/wikipedia-updates",
        ]
    )

    assert str(args.output_dir) == "/tmp/wikipedia-updates"
    assert args.language == "ja"
    assert args.max_changes_per_run is None
    assert args.repeat == 1
    assert args.include_images is False
    assert args.initial_lookback_hours == 72.0
    assert args.request_interval_sec == 0.5


def test_serve_parser_accepts_skill_registry() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "serve",
            "--tool-registry",
            "/tmp/tools.json",
            "--skill-registry",
            "/tmp/skills",
        ]
    )

    assert str(args.tool_registry) == "/tmp/tools.json"
    assert str(args.skill_registry) == "/tmp/skills"


def test_prepare_wikipedia_cited_sources_cpt_parser_defaults() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-wikipedia-cited-sources-cpt",
            "--source-wikipedia-dir",
            "/tmp/wikipedia",
            "--output-dir",
            "/tmp/wikipedia-cited",
        ]
    )

    assert str(args.source_wikipedia_dir) == "/tmp/wikipedia"
    assert str(args.output_dir) == "/tmp/wikipedia-cited"
    assert args.language == "ja"
    assert args.max_pages_per_run is None
    assert args.repeat == 1
    assert args.request_interval_sec == 0.5


def test_prepare_github_repositories_cpt_parser_defaults_to_single_epoch() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "prepare-github-repositories-cpt",
            "--output-dir",
            "/tmp/github-cpt",
        ]
    )

    assert str(args.output_dir) == "/tmp/github-cpt"
    assert args.min_stars == 10000
    assert args.max_repos_per_run is None
    assert args.repeat == 1


def test_sample_checkpoints_parser_uses_fixed_prompt_and_8192_cap() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "sample-checkpoints",
            "--model-path",
            "/tmp/model",
            "--train-output-dir",
            "/tmp/train",
        ]
    )

    assert str(args.model_path) == "/tmp/model"
    assert str(args.train_output_dir) == "/tmp/train"
    assert args.prompt == "AIについて説明してください"
    assert args.max_tokens == 8192
    assert args.max_kv_size == 2048
    assert args.kv_bits == 4
    assert args.kv_group_size == 64


def test_preference_loop_parser_defaults() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "preference-loop",
            "--model-path",
            "/tmp/model",
            "--output-dir",
            "/tmp/preference-loop",
        ]
    )

    assert str(args.model_path) == "/tmp/model"
    assert str(args.output_dir) == "/tmp/preference-loop"
    assert args.prompt is None
    assert args.max_rounds is None
    assert args.max_regenerations_per_round == 20
    assert args.max_tokens == 1024
    assert args.candidate_a_temperature == 0.6
    assert args.candidate_b_temperature == 0.9
    assert args.train_grad_checkpoint is True
    assert args.train_vision is False
    assert args.orpo_beta == 0.1


def test_cmd_train_auto_wraps_desktop_input_output_dataset(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}
    monkeypatch.setattr(
        cli_module,
        "locate_default_desktop_input_output_dir",
        lambda: Path("/tmp/style"),
    )
    monkeypatch.setattr(
        cli_module,
        "prepare_input_output_txt_sft",
        lambda **kwargs: type(
            "Report",
            (),
            {"output_paths": {"manifest": "/tmp/style/manifest.json"}},
        )(),
    )
    monkeypatch.setattr(
        cli_module,
        "build_wrapped_training_manifest",
        lambda **kwargs: Path("/tmp/resolved_train_dataset.json"),
    )

    def fake_run_training(config: Any) -> TrainingRunReport:
        captured["dataset_path"] = config.dataset_path
        captured["checkpoint_sample"] = config.checkpoint_sample
        return TrainingRunReport(
            mode="dry_run",
            status="ready",
            model_path=config.model_path,
            dataset_path=config.dataset_path,
            output_dir=config.output_dir,
            dataset=DatasetComposition(
                train_examples=0,
                valid_examples=0,
                cpt_examples=0,
                chat_examples=0,
                multimodal_chat_examples=0,
                tool_call_messages=0,
                tool_result_messages=0,
                thinking_examples=0,
                placeholder_only_multimodal_examples=0,
            ),
            memory=MemoryEstimate(
                trainable_parameter_count=0,
                estimated_activation_bytes=0,
                estimated_optimizer_bytes=0,
                estimated_peak_working_set_bytes=0,
            ),
        )

    monkeypatch.setattr(cli_module, "run_training", fake_run_training)

    cli_module.cmd_train(
        argparse.Namespace(
            model_path=Path("/tmp/model"),
            dataset_path=Path("/tmp/train.jsonl"),
            output_dir=Path("/tmp/out"),
            valid_path=None,
            max_examples=None,
            validation_fraction=0.1,
            seed=0,
            batch_size=1,
            epochs=1,
            iters=1,
            val_batches=1,
            learning_rate=1e-5,
            steps_per_report=1,
            steps_per_eval=1,
            save_every=1,
            max_seq_length=1024,
            grad_checkpoint=True,
            grad_accumulation_steps=1,
            optimizer="adafactor",
            mask_prompt=False,
            dry_run=True,
            allow_overlimit=False,
            context_window=None,
            yarn_factor=None,
            lora_num_layers=2,
            lora_rank=4,
            lora_scale=8.0,
            lora_dropout=0.0,
            base_last_layers=0,
            base_include_norms=True,
            base_include_biases=False,
            base_include_lm_head=False,
            base_include_embeddings=False,
            base_learning_rate_scale=0.05,
            base_l2_sp_weight=1e-4,
            replay_dataset_path=None,
            replay_target_fraction=0.2,
            grad_clip_norm=1.0,
            metal_cache_limit_bytes=0,
            metal_cache_clear_interval=10,
            checkpoint_sample=True,
            checkpoint_sample_prompt="AIについて説明してください",
            checkpoint_sample_max_tokens=8192,
            checkpoint_sample_max_kv_size=2048,
            checkpoint_sample_kv_bits=4,
            checkpoint_sample_kv_group_size=64,
            auto_desktop_input_output=True,
            preserve_dataset_state=True,
        )
    )

    assert captured["dataset_path"] == "/tmp/resolved_train_dataset.json"
    assert captured["checkpoint_sample"].enabled is True
    assert captured["checkpoint_sample"].max_tokens == 8192
    assert captured["checkpoint_sample"].max_kv_size == 2048
    assert captured["checkpoint_sample"].kv_bits == 4
    assert "ready" in capsys.readouterr().out


def test_cmd_train_skips_auto_wrap_when_dataset_is_already_desktop_input_output(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    captured: dict[str, Any] = {}
    monkeypatch.setattr(
        cli_module,
        "locate_default_desktop_input_output_dir",
        lambda: Path("/tmp/style"),
    )

    def fail_prepare(**kwargs: Any) -> Any:
        raise AssertionError("desktop auto-prepare should be skipped")

    monkeypatch.setattr(cli_module, "prepare_input_output_txt_sft", fail_prepare)

    def fail_wrap(**kwargs: Any) -> Path:
        raise AssertionError("desktop auto-wrap should be skipped")

    monkeypatch.setattr(cli_module, "build_wrapped_training_manifest", fail_wrap)

    def fake_run_training(config: Any) -> TrainingRunReport:
        captured["dataset_path"] = config.dataset_path
        captured["checkpoint_sample"] = config.checkpoint_sample
        return TrainingRunReport(
            mode="dry_run",
            status="ready",
            model_path=config.model_path,
            dataset_path=config.dataset_path,
            output_dir=config.output_dir,
            dataset=DatasetComposition(
                train_examples=0,
                valid_examples=0,
                cpt_examples=0,
                chat_examples=0,
                multimodal_chat_examples=0,
                tool_call_messages=0,
                tool_result_messages=0,
                thinking_examples=0,
                placeholder_only_multimodal_examples=0,
            ),
            memory=MemoryEstimate(
                trainable_parameter_count=0,
                estimated_activation_bytes=0,
                estimated_optimizer_bytes=0,
                estimated_peak_working_set_bytes=0,
            ),
        )

    monkeypatch.setattr(cli_module, "run_training", fake_run_training)

    cli_module.cmd_train(
        argparse.Namespace(
            model_path=Path("/tmp/model"),
            dataset_path=Path("/tmp/desktop_input_output_manifest.json"),
            output_dir=Path("/tmp/out"),
            valid_path=None,
            max_examples=None,
            validation_fraction=0.1,
            seed=0,
            batch_size=1,
            epochs=1,
            iters=1,
            val_batches=1,
            learning_rate=1e-5,
            steps_per_report=1,
            steps_per_eval=1,
            save_every=1,
            max_seq_length=1024,
            grad_checkpoint=True,
            grad_accumulation_steps=1,
            optimizer="adafactor",
            mask_prompt=False,
            dry_run=True,
            allow_overlimit=False,
            context_window=None,
            yarn_factor=None,
            lora_num_layers=2,
            lora_rank=4,
            lora_scale=8.0,
            lora_dropout=0.0,
            base_last_layers=0,
            base_include_norms=True,
            base_include_biases=False,
            base_include_lm_head=False,
            base_include_embeddings=False,
            base_learning_rate_scale=0.05,
            base_l2_sp_weight=1e-4,
            replay_dataset_path=None,
            replay_target_fraction=0.2,
            grad_clip_norm=1.0,
            metal_cache_limit_bytes=0,
            metal_cache_clear_interval=10,
            checkpoint_sample=True,
            checkpoint_sample_prompt="AIについて説明してください",
            checkpoint_sample_max_tokens=8192,
            checkpoint_sample_max_kv_size=2048,
            checkpoint_sample_kv_bits=4,
            checkpoint_sample_kv_group_size=64,
            auto_desktop_input_output=True,
            preserve_dataset_state=True,
        )
    )

    assert captured["dataset_path"] == "/tmp/desktop_input_output_manifest.json"
    assert captured["checkpoint_sample"].prompt == "AIについて説明してください"
    assert "ready" in capsys.readouterr().out


def test_cmd_sample_checkpoints_prints_report(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_sample_saved_checkpoints(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
                "Report",
                (),
                {
                    "model_dump": lambda self: {
                    "model_path": str(kwargs["model_path"]),
                    "train_output_dir": str(kwargs["train_output_dir"]),
                    "checkpoint_count": 2,
                    "prompt": kwargs["prompt"],
                    "max_tokens": kwargs["max_tokens"],
                    "records_path": "/tmp/out/saved_checkpoint_samples.jsonl",
                    "sample_dir": "/tmp/out/saved_checkpoint_samples",
                    "checkpoints": ["/tmp/out/0000001_adapters.safetensors", "/tmp/out/adapters.safetensors"],
                }
            },
        )()

    monkeypatch.setattr(cli_module, "sample_saved_checkpoints", fake_sample_saved_checkpoints)

    cli_module.cmd_sample_checkpoints(
        argparse.Namespace(
            model_path=Path("/tmp/model"),
            train_output_dir=Path("/tmp/out"),
            prompt="AIについて説明してください",
            max_tokens=8192,
            max_kv_size=2048,
            kv_bits=4,
            kv_group_size=64,
        )
    )

    assert captured == {
        "model_path": Path("/tmp/model"),
        "train_output_dir": Path("/tmp/out"),
        "prompt": "AIについて説明してください",
        "max_tokens": 8192,
        "max_kv_size": 2048,
        "kv_bits": 4,
        "kv_group_size": 64,
    }
    assert "saved_checkpoint_samples.jsonl" in capsys.readouterr().out


def test_cmd_preference_loop_invokes_runner(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_run_preference_loop(config: Any) -> Any:
        captured.update(config.model_dump())
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "output_dir": config.output_dir,
                    "prompt": config.prompt or "stored prompt",
                    "preference_dataset_path": "/tmp/preference-loop/preferences.jsonl",
                    "current_adapter_path": "/tmp/preference-loop/round_0001/adapters.safetensors",
                    "completed_rounds": 1,
                    "total_preferences": 1,
                    "exit_reason": "max_rounds_reached",
                    "last_round_output_dir": "/tmp/preference-loop/round_0001",
                }
            },
        )()

    monkeypatch.setattr(cli_module, "run_preference_loop", fake_run_preference_loop)

    cli_module.cmd_preference_loop(
        argparse.Namespace(
            model_path=Path("/tmp/model"),
            output_dir=Path("/tmp/preference-loop"),
            prompt="良いコードレビューとは何か?",
            adapter_path=None,
            max_rounds=1,
            max_regenerations_per_round=20,
            max_tokens=1024,
            candidate_a_temperature=0.6,
            candidate_b_temperature=0.9,
            candidate_top_p=0.95,
            seed=0,
            train_batch_size=1,
            train_iters=1,
            train_learning_rate=1e-6,
            train_grad_checkpoint=True,
            train_vision=False,
            context_window=None,
            yarn_factor=None,
            lora_num_layers=8,
            lora_rank=8,
            lora_scale=20.0,
            lora_dropout=0.0,
            base_last_layers=0,
            base_include_norms=True,
            base_include_biases=False,
            base_include_lm_head=False,
            base_include_embeddings=False,
            base_learning_rate_scale=0.05,
            base_l2_sp_weight=1e-4,
            grad_clip_norm=1.0,
            metal_memory_budget_mode="device",
            metal_memory_limit_bytes=None,
            metal_wired_limit_bytes=None,
            metal_cache_limit_bytes=0,
            metal_cache_clear_interval=1,
            training_memory_reserve_bytes=64 * 1024 * 1024,
            strict_token_audit=True,
            orpo_beta=0.1,
        )
    )

    assert captured["prompt"] == "良いコードレビューとは何か?"
    assert captured["max_rounds"] == 1
    assert captured["train_iters"] == 1
    assert captured["orpo_beta"] == 0.1
    assert "preferences.jsonl" in capsys.readouterr().out


def test_purge_dataset_artifacts_deletes_leaf_files_and_nested_manifests(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    leaf = source_dir / "records.jsonl"
    leaf.write_text('{"task_type":"cpt","text":"hello"}\n', encoding="utf-8")

    nested_manifest = source_dir / "nested_manifest.json"
    nested_manifest.write_text(
        '{"kind":"sequential_cpt_manifest","datasets":[{"path":"%s","repeat":1,"label":"leaf"}]}\n'
        % leaf.resolve(),
        encoding="utf-8",
    )

    root_manifest = tmp_path / "root_manifest.json"
    root_manifest.write_text(
        '{"kind":"sequential_cpt_manifest","datasets":[{"path":"%s","repeat":1,"label":"nested"}]}\n'
        % nested_manifest.resolve(),
        encoding="utf-8",
    )

    deleted = cli_module._purge_dataset_artifacts(root_manifest)

    assert str(root_manifest.resolve()) in deleted
    assert str(nested_manifest.resolve()) in deleted
    assert str(leaf.resolve()) in deleted
    assert not root_manifest.exists()
    assert not nested_manifest.exists()
    assert not leaf.exists()


def test_purge_dataset_artifacts_preserves_progress_state_by_default(tmp_path: Path) -> None:
    dataset_dir = tmp_path / "dataset"
    dataset_dir.mkdir()
    leaf = dataset_dir / "records.jsonl"
    leaf.write_text('{"task_type":"cpt","text":"hello"}\n', encoding="utf-8")
    progress = dataset_dir / "progress.json"
    progress.write_text('{"completed": false}\n', encoding="utf-8")

    root_manifest = dataset_dir / "root_manifest.json"
    root_manifest.write_text(
        '{"kind":"sequential_cpt_manifest","datasets":[{"path":"%s","repeat":1,"label":"leaf"}]}\n'
        % leaf.resolve(),
        encoding="utf-8",
    )

    deleted = cli_module._purge_dataset_artifacts(root_manifest, preserve_state=True)

    assert str(leaf.resolve()) in deleted
    assert str(root_manifest.resolve()) in deleted
    assert progress.exists()


def test_cmd_train_can_disable_auto_desktop_input_output(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    captured: dict[str, Any] = {}
    monkeypatch.setattr(
        cli_module,
        "locate_default_desktop_input_output_dir",
        lambda: Path("/tmp/style"),
    )

    def fail_prepare(**kwargs: Any) -> Any:
        raise AssertionError("desktop auto-prepare should be disabled")

    monkeypatch.setattr(cli_module, "prepare_input_output_txt_sft", fail_prepare)

    def fake_run_training(config: Any) -> TrainingRunReport:
        captured["dataset_path"] = config.dataset_path
        return TrainingRunReport(
            mode="dry_run",
            status="ready",
            model_path=config.model_path,
            dataset_path=config.dataset_path,
            output_dir=config.output_dir,
            dataset=DatasetComposition(
                train_examples=0,
                valid_examples=0,
                cpt_examples=0,
                chat_examples=0,
                multimodal_chat_examples=0,
                tool_call_messages=0,
                tool_result_messages=0,
                thinking_examples=0,
                placeholder_only_multimodal_examples=0,
            ),
            memory=MemoryEstimate(
                trainable_parameter_count=0,
                estimated_activation_bytes=0,
                estimated_optimizer_bytes=0,
                estimated_peak_working_set_bytes=0,
            ),
        )

    monkeypatch.setattr(cli_module, "run_training", fake_run_training)

    cli_module.cmd_train(
        argparse.Namespace(
            model_path=Path("/tmp/model"),
            dataset_path=Path("/tmp/train.jsonl"),
            output_dir=Path("/tmp/out"),
            valid_path=None,
            max_examples=None,
            validation_fraction=0.1,
            seed=0,
            batch_size=1,
            epochs=1,
            iters=1,
            val_batches=1,
            learning_rate=1e-5,
            steps_per_report=1,
            steps_per_eval=1,
            save_every=1,
            max_seq_length=1024,
            grad_checkpoint=True,
            grad_accumulation_steps=1,
            optimizer="adafactor",
            mask_prompt=False,
            dry_run=True,
            allow_overlimit=False,
            context_window=None,
            yarn_factor=None,
            lora_num_layers=2,
            lora_rank=4,
            lora_scale=8.0,
            lora_dropout=0.0,
            base_last_layers=0,
            base_include_norms=True,
            base_include_biases=False,
            base_include_lm_head=False,
            base_include_embeddings=False,
            base_learning_rate_scale=0.05,
            base_l2_sp_weight=1e-4,
            replay_dataset_path=None,
            replay_target_fraction=0.2,
            grad_clip_norm=1.0,
            metal_cache_limit_bytes=0,
            metal_cache_clear_interval=10,
            checkpoint_sample=True,
            checkpoint_sample_prompt="AIについて説明してください",
            checkpoint_sample_max_tokens=8192,
            checkpoint_sample_max_kv_size=2048,
            checkpoint_sample_kv_bits=4,
            checkpoint_sample_kv_group_size=64,
            auto_desktop_input_output=False,
            preserve_dataset_state=True,
        )
    )

    assert captured["dataset_path"] == "/tmp/train.jsonl"
    assert "ready" in capsys.readouterr().out


def test_cmd_prepare_openai_docs_cpt_calls_preparation(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_openai_docs_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "openai_docs_cpt",
                    "output_paths": {"manifest": "/tmp/openai/openai_docs_train_manifest.json"},
                }
            },
        )()

    monkeypatch.setattr(cli_module, "prepare_openai_docs_cpt", fake_prepare_openai_docs_cpt)

    cli_module.cmd_prepare_openai_docs_cpt(
        argparse.Namespace(
            output_dir=Path("/tmp/openai"),
            max_pages_per_run=100,
            records_per_shard=32,
            repeat=2,
        )
    )

    assert captured == {
        "output_dir": Path("/tmp/openai"),
        "max_pages_per_run": 100,
        "records_per_shard": 32,
        "repeat": 2,
    }
    assert "openai_docs_train_manifest.json" in capsys.readouterr().out


def test_cmd_sync_openai_api_contract_writes_report(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_write_openai_contract_report(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "installed_sdk_version": "2.30.0",
                    "required_server_routes": ["/responses", "/v1/responses"],
                    "missing_server_routes": [],
                }
            },
        )()

    monkeypatch.setattr(cli_module, "write_openai_contract_report", fake_write_openai_contract_report)

    cli_module.cmd_sync_openai_api_contract(
        argparse.Namespace(
            output_path=Path("/tmp/openai-contract.json"),
            check_latest_release=False,
            timeout_sec=5.0,
        )
    )

    assert captured["output_path"] == Path("/tmp/openai-contract.json")
    assert captured["include_latest_release"] is False
    assert captured["timeout_sec"] == 5.0
    assert "2.30.0" in capsys.readouterr().out


def test_cmd_prepare_wikipedia_recent_changes_cpt_calls_preparation(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_wikipedia_recent_changes_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "wikipedia_recent_changes_cpt",
                    "output_paths": {
                        "manifest": "/tmp/wikipedia-updates/wikipedia_recent_changes_train_manifest.json"
                    },
                }
            },
        )()

    monkeypatch.setattr(cli_module, "prepare_wikipedia_recent_changes_cpt", fake_prepare_wikipedia_recent_changes_cpt)

    cli_module.cmd_prepare_wikipedia_recent_changes_cpt(
        argparse.Namespace(
            output_dir=Path("/tmp/wikipedia-updates"),
            language="ja",
            max_changes_per_run=50,
            records_per_shard=16,
            repeat=1,
            include_images=False,
            image_detail="auto",
            initial_lookback_hours=72.0,
            request_interval_sec=0.5,
        )
    )

    assert captured == {
        "output_dir": Path("/tmp/wikipedia-updates"),
        "language": "ja",
        "max_changes_per_run": 50,
        "records_per_shard": 16,
        "repeat": 1,
        "include_images": False,
        "image_detail": "auto",
        "initial_lookback_hours": 72.0,
        "request_interval_sec": 0.5,
    }
    assert "wikipedia_recent_changes_train_manifest.json" in capsys.readouterr().out


def test_cmd_prepare_wikipedia_cited_sources_cpt_calls_preparation(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_wikipedia_cited_sources_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "wikipedia_cited_sources_cpt",
                    "output_paths": {
                        "manifest": "/tmp/wikipedia-cited/wikipedia_cited_sources_train_manifest.json"
                    },
                }
            },
        )()

    monkeypatch.setattr(cli_module, "prepare_wikipedia_cited_sources_cpt", fake_prepare_wikipedia_cited_sources_cpt)

    cli_module.cmd_prepare_wikipedia_cited_sources_cpt(
        argparse.Namespace(
            source_wikipedia_dir=Path("/tmp/wikipedia"),
            output_dir=Path("/tmp/wikipedia-cited"),
            language="ja",
            max_pages_per_run=25,
            records_per_shard=8,
            repeat=1,
            request_interval_sec=0.5,
        )
    )

    assert captured == {
        "source_wikipedia_dir": Path("/tmp/wikipedia"),
        "output_dir": Path("/tmp/wikipedia-cited"),
        "language": "ja",
        "max_pages_per_run": 25,
        "records_per_shard": 8,
        "repeat": 1,
        "request_interval_sec": 0.5,
    }
    assert "wikipedia_cited_sources_train_manifest.json" in capsys.readouterr().out


def test_cmd_prepare_kaken_cpt_calls_preparation(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_kaken_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "kaken_cpt",
                    "output_paths": {"manifest": "/tmp/kaken/kaken_train_manifest.json"},
                }
            },
        )()

    monkeypatch.setattr(cli_module, "prepare_kaken_cpt", fake_prepare_kaken_cpt)

    cli_module.cmd_prepare_kaken_cpt(
        argparse.Namespace(
            output_dir=Path("/tmp/kaken"),
            max_projects_per_run=25,
            records_per_shard=16,
            repeat=2,
            request_interval_sec=0.5,
        )
    )

    assert captured == {
        "output_dir": Path("/tmp/kaken"),
        "max_projects_per_run": 25,
        "records_per_shard": 16,
        "repeat": 2,
        "request_interval_sec": 0.5,
    }
    assert "kaken_train_manifest.json" in capsys.readouterr().out


def test_cmd_prepare_ndl_next_digital_library_cpt_calls_preparation(monkeypatch: Any, capsys: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_ndl_next_digital_library_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "ndl_next_digital_library_cpt",
                    "output_paths": {"manifest": "/tmp/ndl/ndl_next_digital_library_train_manifest.json"},
                }
            },
        )()

    monkeypatch.setattr(
        cli_module,
        "prepare_ndl_next_digital_library_cpt",
        fake_prepare_ndl_next_digital_library_cpt,
    )

    cli_module.cmd_prepare_ndl_next_digital_library_cpt(
        argparse.Namespace(
            output_dir=Path("/tmp/ndl"),
            max_items_per_run=50,
            records_per_shard=32,
            repeat=2,
            request_interval_sec=0.5,
        )
    )

    assert captured == {
        "output_dir": Path("/tmp/ndl"),
        "max_items_per_run": 50,
        "records_per_shard": 32,
        "repeat": 2,
        "request_interval_sec": 0.5,
    }
    assert "ndl_next_digital_library_train_manifest.json" in capsys.readouterr().out


def test_cmd_dataset_status_prints_report(monkeypatch: Any, capsys: Any) -> None:
    monkeypatch.setattr(
        cli_module,
        "inspect_prepared_dataset_status",
        lambda **kwargs: type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "wikipedia_cpt",
                    "output_dir": str(kwargs["output_dir"]),
                    "processed_items": 25,
                    "total_items": 100,
                }
            },
        )(),
    )

    cli_module.cmd_dataset_status(argparse.Namespace(output_dir=Path("/tmp/wikipedia")))

    output = capsys.readouterr().out
    assert "wikipedia_cpt" in output
    assert '"processed_items": 25' in output


def test_cmd_prepare_github_repositories_cpt_calls_preparation(
    monkeypatch: Any,
    capsys: Any,
) -> None:
    captured: dict[str, Any] = {}

    def fake_prepare_github_repositories_cpt(**kwargs: Any) -> Any:
        captured.update(kwargs)
        return type(
            "Report",
            (),
            {
                "model_dump": lambda self: {
                    "kind": "github_repositories_cpt",
                    "output_paths": {"manifest": "/tmp/github/github_repositories_train_manifest.json"},
                }
            },
        )()

    monkeypatch.setattr(cli_module, "prepare_github_repositories_cpt", fake_prepare_github_repositories_cpt)

    cli_module.cmd_prepare_github_repositories_cpt(
        argparse.Namespace(
            output_dir=Path("/tmp/github"),
            min_stars=10000,
            max_repos_per_run=25,
            records_per_shard=16,
            repeat=1,
            request_interval_sec=2.0,
        )
    )

    assert captured == {
        "output_dir": Path("/tmp/github"),
        "min_stars": 10000,
        "max_repos_per_run": 25,
        "records_per_shard": 16,
        "repeat": 1,
        "request_interval_sec": 2.0,
    }
    assert "github_repositories_train_manifest.json" in capsys.readouterr().out
