from pathlib import Path

from cappuccino.training_schemas import parse_training_example, validate_jsonl


def test_parse_chat_sft_example_with_video_and_tools() -> None:
    payload = {
        "focus": ["multimodal", "video"],
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "この動画を要約して。"},
                    {"type": "video", "video": "sample.mp4", "fps": 1.0},
                ],
            },
            {"role": "assistant", "reasoning_content": "要点を整理する。", "content": "要約します。"},
        ],
        "tools": [{"type": "tool_search", "execution": "client"}],
    }

    parsed = parse_training_example(payload)

    assert parsed.task_type == "chat_sft"


def test_parse_preference_example_without_explicit_task_type() -> None:
    payload = {
        "chosen": [
            {"role": "user", "content": "日本の首都は?"},
            {"role": "assistant", "content": "東京です。"},
        ],
        "rejected": [
            {"role": "user", "content": "日本の首都は?"},
            {"role": "assistant", "content": "大阪です。"},
        ],
        "focus": ["reasoning"],
    }

    parsed = parse_training_example(payload)

    assert parsed.task_type == "preference"


def test_validate_jsonl_counts_modalities() -> None:
    dataset_path = (
        Path(__file__).resolve().parents[1]
        / "examples"
        / "datasets"
        / "chat_sft_train.jsonl"
    )
    report = validate_jsonl(dataset_path)

    assert report.total_examples == 2
    assert report.task_counts["chat_sft"] == 2
    assert report.modality_counts["video"] >= 1
    assert report.modality_counts["tool_calls"] >= 1
    assert report.modality_counts["tool_results"] >= 1
    assert report.modality_counts["reasoning_messages"] >= 1
    assert report.focus_counts["video"] >= 1
    assert report.focus_counts["tools"] >= 1


def test_validate_jsonl_counts_preference_examples(tmp_path: Path) -> None:
    dataset_path = tmp_path / "preferences.jsonl"
    dataset_path.write_text(
        '{"task_type":"preference","chosen":[{"role":"user","content":"Q"},{"role":"assistant","content":"A"}],"rejected":[{"role":"user","content":"Q"},{"role":"assistant","content":"B"}]}\n',
        encoding="utf-8",
    )

    report = validate_jsonl(dataset_path)

    assert report.total_examples == 1
    assert report.task_counts["preference"] == 1
