import json
from pathlib import Path

from cappuccino.reasoning import (
    extract_reasoning_and_answer,
    postprocess_response_body,
    resolve_reasoning_control,
    summarize_reasoning,
)


def test_resolve_reasoning_control_defaults_to_thinking_off() -> None:
    control = resolve_reasoning_control({})

    assert control.enable_thinking is False
    assert control.mode == "off"
    assert control.summary == "none"


def test_resolve_reasoning_control_can_default_to_auto() -> None:
    control = resolve_reasoning_control({}, default_mode="auto")

    assert control.enable_thinking is False
    assert control.mode == "auto"


def test_resolve_reasoning_control_accepts_adaptive_alias() -> None:
    control = resolve_reasoning_control({"reasoning": {"mode": "adaptive"}})

    assert control.mode == "auto"


def test_extract_reasoning_and_answer_splits_think_block() -> None:
    reasoning, answer = extract_reasoning_and_answer(
        "<think>\nstep one\nstep two\n</think>\n\nfinal answer"
    )

    assert reasoning == "step one\nstep two"
    assert answer == "final answer"


def test_extract_reasoning_and_answer_keeps_literal_think_text_without_visible_answer() -> None:
    reasoning, answer = extract_reasoning_and_answer("<think>test</think>")

    assert reasoning is None
    assert answer == "<think>test</think>"


def test_summarize_reasoning_returns_short_joined_summary() -> None:
    summary = summarize_reasoning(
        "Thinking Process:\n1. Analyze request.\n2. Select concise answer.\n3. Produce Japanese sentence.",
        "concise",
    )

    assert summary is not None
    assert "Analyze request." in summary


def test_postprocess_chat_completion_logs_full_reasoning_and_returns_answer(tmp_path: Path) -> None:
    log_path = tmp_path / "reasoning.jsonl"
    body = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "<think>\n1. Analyze request.\n2. Pick short answer.\n</think>\n\n私は AI アシスタントです。",
                }
            }
        ]
    }
    control = resolve_reasoning_control(
        {"enable_thinking": True, "reasoning": {"summary": "concise"}}
    )

    processed = postprocess_response_body(
        path="/v1/chat/completions",
        body=body,
        payload={"model": "local-q6"},
        control=control,
        reasoning_log_path=log_path,
    )

    message = processed["choices"][0]["message"]
    assert message["content"] == "私は AI アシスタントです。"
    assert message["reasoning_content"] == "1. Analyze request.\n2. Pick short answer."
    assert "reasoning_summary" in message

    records = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
    assert len(records) == 1
    assert records[0]["reasoning_full"] == "1. Analyze request.\n2. Pick short answer."


def test_postprocess_responses_normalizes_upstream_shape_for_sdk() -> None:
    body = {
        "id": "resp_test",
        "created_at": 123,
        "status": "completed",
        "model": "local-q6",
        "output": [
            {
                "role": "assistant",
                "content": [{"text": "こんにちは", "type": "output_text"}],
                "tool_calls": [],
            }
        ],
        "output_text": "こんにちは",
        "usage": {
            "input_tokens": 3,
            "output_tokens": 4,
            "total_tokens": 7,
        },
    }

    processed = postprocess_response_body(
        path="/v1/responses",
        body=body,
        payload={"model": "local-q6", "input": "挨拶して"},
        control=resolve_reasoning_control({}),
        reasoning_log_path=Path("/tmp/unused.jsonl"),
    )

    item = processed["output"][0]
    assert item["type"] == "message"
    assert item["status"] == "completed"
    assert item["role"] == "assistant"
    assert item["id"].startswith("msg_")
    assert item["content"][0]["type"] == "output_text"
    assert item["content"][0]["annotations"] == []
    assert processed["text"] == {"format": {"type": "text"}}
    assert processed["tool_choice"] == "none"
    assert processed["usage"]["input_tokens_details"] == {"cached_tokens": 0}
    assert processed["usage"]["output_tokens_details"] == {"reasoning_tokens": 0}


def test_postprocess_responses_extracts_reasoning_into_internal_field() -> None:
    body = {
        "id": "resp_reasoning",
        "created_at": 123,
        "status": "completed",
        "model": "local-q6",
        "output": [
            {
                "role": "assistant",
                "content": [
                    {
                        "text": "<think>\nstep one\nstep two\n</think>\n\nfinal answer",
                        "type": "output_text",
                    }
                ],
            }
        ],
        "output_text": "<think>\nstep one\nstep two\n</think>\n\nfinal answer",
    }

    processed = postprocess_response_body(
        path="/v1/responses",
        body=body,
        payload={"model": "local-q6", "input": "答えて"},
        control=resolve_reasoning_control({"reasoning": {"mode": "on", "summary": "concise"}}),
        reasoning_log_path=Path("/tmp/unused.jsonl"),
    )

    item = processed["output"][0]
    assert processed["output_text"] == "final answer"
    assert item["content"][0]["text"] == "final answer"
    assert item["reasoning_content"] == "step one\nstep two"


def test_postprocess_chat_completion_does_not_split_literal_think_text_in_off_mode() -> None:
    body = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "<think>test</think>こんにちは",
                }
            }
        ]
    }

    processed = postprocess_response_body(
        path="/v1/chat/completions",
        body=body,
        payload={"model": "local-q6"},
        control=resolve_reasoning_control({"enable_thinking": False}),
        reasoning_log_path=Path("/tmp/unused.jsonl"),
    )

    message = processed["choices"][0]["message"]
    assert message["content"] == "<think>test</think>こんにちは"
    assert "reasoning_content" not in message
