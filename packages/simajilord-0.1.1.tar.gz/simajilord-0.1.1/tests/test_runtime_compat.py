from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cappuccino.runtime_compat as runtime_compat
import pytest


def test_convert_model_restores_public_branding_after_quantization(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    legacy_term = ("q" + "wen")
    source = tmp_path / "source"
    output = tmp_path / "output"
    source.mkdir()

    (source / "config.json").write_text(
        json.dumps(
            {
                "model_type": "cappuccino",
                "architectures": ["CappuccinoForConditionalGeneration"],
                "text_config": {
                    "model_type": "cappuccino_text",
                    "max_position_embeddings": 32,
                },
                "vision_config": {"model_type": "cappuccino_vision"},
                "image_token_id": 1,
                "video_token_id": 2,
            }
        ),
        encoding="utf-8",
    )
    (source / "preprocessor_config.json").write_text(
        json.dumps(
            {
                "processor_class": "CappuccinoProcessor",
                "image_processor_type": "CappuccinoImageProcessorFast",
            }
        ),
        encoding="utf-8",
    )
    (source / "tokenizer_config.json").write_text(
        json.dumps({"tokenizer_class": "CappuccinoTokenizer"}),
        encoding="utf-8",
    )
    (source / "video_preprocessor_config.json").write_text(
        json.dumps(
            {
                "processor_class": "CappuccinoProcessor",
                "video_processor_type": "CappuccinoVideoProcessor",
            }
        ),
        encoding="utf-8",
    )
    (source / "README.md").write_text("# Cappuccino-27B\n", encoding="utf-8")
    (source / "chat_template.jinja").write_text("", encoding="utf-8")
    (source / "generation_config.json").write_text("{}", encoding="utf-8")
    (source / "tokenizer.json").write_text("{}", encoding="utf-8")
    (source / "vocab.json").write_text("{}", encoding="utf-8")
    (source / "merges.txt").write_text("", encoding="utf-8")
    for file_name in (
        "cappuccino_remote_base.py",
        "configuration_cappuccino.py",
        "modeling_cappuccino.py",
        "processing_cappuccino.py",
        "tokenization_cappuccino.py",
    ):
        (source / file_name).write_text("# remote code\n", encoding="utf-8")

    def fake_convert(**kwargs: Any) -> None:
        compat_path = Path(kwargs["hf_path"])
        compat_config = json.loads((compat_path / "config.json").read_text(encoding="utf-8"))
        assert compat_config["model_type"] != "cappuccino"
        destination = Path(kwargs["mlx_path"])
        destination.mkdir(parents=True, exist_ok=True)
        (destination / "config.json").write_text(
            json.dumps(
                {
                    **compat_config,
                    "eos_token_id": [7, 8],
                    "quantization": {"bits": 6, "group_size": 64, "mode": "affine"},
                    "quantization_config": {"bits": 6, "group_size": 64, "mode": "affine"},
                    "text_config": {
                        **compat_config["text_config"],
                        "quantization_config": {"bits": 6, "group_size": 64, "mode": "affine"},
                    },
                }
            ),
            encoding="utf-8",
        )

    monkeypatch.setattr(runtime_compat, "_convert_multimodal_model", fake_convert)

    runtime_compat.convert_model(
        hf_path=source,
        mlx_path=output,
        quantize=True,
        q_bits=6,
        q_group_size=64,
        trust_remote_code=True,
        quant_predicate=None,
    )

    output_config = json.loads((output / "config.json").read_text(encoding="utf-8"))
    assert output_config["model_type"] == "cappuccino"
    assert output_config["architectures"] == ["CappuccinoForConditionalGeneration"]
    assert output_config["eos_token_id"] == [7, 8]
    assert output_config["quantization"]["bits"] == 6
    assert output_config["text_config"]["model_type"] == "cappuccino_text"
    assert output_config["text_config"]["quantization_config"]["group_size"] == 64
    readme_text = (output / "README.md").read_text(encoding="utf-8")
    assert readme_text.startswith("# Cappuccino-27B")
    assert "OpenAI API" in readme_text
    assert not (output / "processor_config.json").exists()
    assert legacy_term not in readme_text.lower()
    assert legacy_term not in (output / "config.json").read_text(encoding="utf-8").lower()


def test_restore_public_model_files_rejects_legacy_branding_in_copied_files(
    tmp_path: Path,
) -> None:
    legacy_heading = "Q" + "wen leak"
    source = tmp_path / "source"
    output = tmp_path / "output"
    source.mkdir()
    output.mkdir()

    (source / "config.json").write_text(
        json.dumps(
            {
                "model_type": "cappuccino",
                "architectures": ["CappuccinoForConditionalGeneration"],
                "text_config": {"model_type": "cappuccino_text"},
                "vision_config": {"model_type": "cappuccino_vision"},
            }
        ),
        encoding="utf-8",
    )
    (source / "preprocessor_config.json").write_text(
        json.dumps({"processor_class": "CappuccinoProcessor"}),
        encoding="utf-8",
    )
    (source / "tokenizer_config.json").write_text(
        json.dumps({"tokenizer_class": "CappuccinoTokenizer"}),
        encoding="utf-8",
    )
    (source / "video_preprocessor_config.json").write_text(
        json.dumps({"processor_class": "CappuccinoProcessor"}),
        encoding="utf-8",
    )
    (source / "README.md").write_text("# Cappuccino-27B\n", encoding="utf-8")
    (source / "chat_template.jinja").write_text("", encoding="utf-8")
    (source / "generation_config.json").write_text("{}", encoding="utf-8")
    for file_name in (
        "cappuccino_remote_base.py",
        "configuration_cappuccino.py",
        "modeling_cappuccino.py",
        "processing_cappuccino.py",
        "tokenization_cappuccino.py",
    ):
        content = "# remote code\n"
        if file_name == "configuration_cappuccino.py":
            content = f"# {legacy_heading}\n"
        (source / file_name).write_text(content, encoding="utf-8")

    (output / "config.json").write_text(
        json.dumps(
            {
                "model_type": ("q" + "wen") + "3_5",
                "text_config": {"model_type": ("q" + "wen") + "3_5_text"},
            }
        ),
        encoding="utf-8",
    )
    (output / "README.md").write_text(f"# {legacy_heading}\n", encoding="utf-8")

    with pytest.raises(ValueError, match="Public model files must keep Cappuccino branding only"):
        runtime_compat.restore_public_model_files(source_path=source, output_path=output)


def test_normalize_runtime_payload_collapses_leading_skill_messages_into_system() -> None:
    payload = {
        "model": "/tmp/model",
        "messages": [
            {"role": "developer", "content": "Answer tersely."},
            {
                "role": "skill",
                "name": "openai-docs",
                "description": "Current OpenAI docs guidance.",
                "path": "/tmp/skills/openai-docs/SKILL.md",
                "content": "Read the latest official docs first.",
            },
            {"role": "user", "content": "最新の API 仕様を確認して"},
        ],
    }

    normalized = runtime_compat.normalize_runtime_payload(payload)

    messages = normalized["messages"]
    assert messages[0]["role"] == "system"
    assert "Answer tersely." in messages[0]["content"]
    assert "<skill>" in messages[0]["content"]
    assert "name: openai-docs" in messages[0]["content"]
    assert "Read the latest official docs first." in messages[0]["content"]
    assert messages[1]["role"] == "user"


def test_normalize_runtime_payload_strips_internal_skill_fields() -> None:
    payload = {
        "model": "/tmp/model",
        "skill_choice": "auto",
        "skill_limit": 4,
        "skills": ["openai-docs"],
        "messages": [{"role": "user", "content": "hi"}],
    }

    normalized = runtime_compat.normalize_runtime_payload(payload)

    assert "skills" not in normalized
    assert "skill_choice" not in normalized
    assert "skill_limit" not in normalized
    assert payload["skills"] == ["openai-docs"]
