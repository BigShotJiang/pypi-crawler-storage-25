from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any, Callable, cast

from mlx_lm import load as _load_text_model
from mlx_vlm import load as _load_multimodal_model
from mlx_vlm.convert import convert as _convert_multimodal_model
from mlx_vlm.server import app as _upstream_runtime_app

_PUBLIC_MODEL_TYPE = "cappuccino"
_PUBLIC_TEXT_MODEL_TYPE = "cappuccino_text"
_PUBLIC_VISION_MODEL_TYPE = "cappuccino_vision"
_PUBLIC_ARCHITECTURE = "CappuccinoForConditionalGeneration"
_PUBLIC_PROCESSOR_CLASS = "CappuccinoProcessor"
_PUBLIC_IMAGE_PROCESSOR_CLASS = "CappuccinoImageProcessorFast"
_PUBLIC_VIDEO_PROCESSOR_CLASS = "CappuccinoVideoProcessor"
_PUBLIC_TOKENIZER_CLASS = "CappuccinoTokenizer"
_PUBLIC_CONFIG_AUTO_MAP = {
    "AutoConfig": "configuration_cappuccino.CappuccinoConfig",
    "AutoProcessor": "processing_cappuccino.CappuccinoProcessor",
    "AutoTokenizer": [
        "tokenization_cappuccino.CappuccinoTokenizer",
        None,
    ],
    "AutoModel": "modeling_cappuccino.CappuccinoModel",
    "AutoModelForCausalLM": "modeling_cappuccino.CappuccinoForConditionalGeneration",
    "AutoModelForImageTextToText": "modeling_cappuccino.CappuccinoForConditionalGeneration",
    "AutoModelForVision2Seq": "modeling_cappuccino.CappuccinoForConditionalGeneration",
    "AutoImageProcessor": "processing_cappuccino.CappuccinoImageProcessorFast",
    "AutoVideoProcessor": "processing_cappuccino.CappuccinoVideoProcessor",
}
_PUBLIC_PREPROCESSOR_AUTO_MAP = {
    "AutoProcessor": "processing_cappuccino.CappuccinoProcessor",
    "AutoImageProcessor": "processing_cappuccino.CappuccinoImageProcessorFast",
}
_PUBLIC_VIDEO_PREPROCESSOR_AUTO_MAP = {
    "AutoProcessor": "processing_cappuccino.CappuccinoProcessor",
    "AutoVideoProcessor": "processing_cappuccino.CappuccinoVideoProcessor",
}
_REMOTE_CODE_FILES = (
    "cappuccino_remote_base.py",
    "configuration_cappuccino.py",
    "modeling_cappuccino.py",
    "processing_cappuccino.py",
    "tokenization_cappuccino.py",
)
_PUBLIC_BRANDING_TEXT_FILES = (
    "README.md",
    "config.json",
    "preprocessor_config.json",
    "tokenizer_config.json",
    "video_preprocessor_config.json",
    "chat_template.jinja",
    "generation_config.json",
    *_REMOTE_CODE_FILES,
)


def load(
    path_or_hf_repo: str,
    *,
    tokenizer_config: dict[str, Any] | None = None,
    model_config: dict[str, Any] | None = None,
    adapter_path: str | None = None,
    lazy: bool = False,
    return_config: bool = False,
    revision: str | None = None,
) -> Any:
    runtime_path = prepare_runtime_model_path(path_or_hf_repo)
    return _load_text_model(
        str(runtime_path),
        tokenizer_config=tokenizer_config,
        model_config=model_config,
        adapter_path=adapter_path,
        lazy=lazy,
        return_config=return_config,
        revision=revision,
    )


def load_multimodal(
    path_or_hf_repo: str,
    *,
    adapter_path: str | None = None,
    lazy: bool = False,
    revision: str | None = None,
    processor_config: dict[str, Any] | None = None,
    model_config: dict[str, Any] | None = None,
) -> Any:
    runtime_path = prepare_runtime_model_path(path_or_hf_repo)
    kwargs: dict[str, Any] = {}
    if processor_config is not None:
        kwargs["processor_config"] = processor_config
    if model_config is not None:
        kwargs["model_config"] = model_config
    return _load_multimodal_model(
        str(runtime_path),
        adapter_path=adapter_path,
        lazy=lazy,
        revision=revision,
        **kwargs,
    )


def convert_model(
    *,
    hf_path: str | Path,
    mlx_path: str | Path,
    quantize: bool,
    q_bits: int,
    q_group_size: int,
    trust_remote_code: bool,
    quant_predicate: Callable[[str, object], bool] | None,
) -> None:
    source_path = Path(hf_path).expanduser().resolve()
    runtime_path = prepare_runtime_model_path(source_path)
    _convert_multimodal_model(
        hf_path=str(runtime_path),
        mlx_path=str(Path(mlx_path).expanduser().resolve()),
        quantize=quantize,
        q_bits=q_bits,
        q_group_size=q_group_size,
        trust_remote_code=trust_remote_code,
        quant_predicate=quant_predicate,
    )
    restore_public_model_files(source_path=source_path, output_path=mlx_path)


def upstream_runtime_app() -> Any:
    return _upstream_runtime_app


def normalize_runtime_payload(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = _strip_internal_request_fields(copy.deepcopy(payload))
    model_value = normalized.get("model")
    if isinstance(model_value, str):
        normalized["model"] = str(prepare_runtime_model_path(model_value))
    messages = normalized.get("messages")
    if isinstance(messages, list):
        normalized["messages"] = _collapse_leading_context_messages(messages)
    input_value = normalized.get("input")
    if isinstance(input_value, list):
        normalized["input"] = _collapse_leading_context_messages(input_value)
    return normalized


def _strip_internal_request_fields(payload: dict[str, Any]) -> dict[str, Any]:
    for field_name in ("skills", "skill_choice", "skill_limit"):
        payload.pop(field_name, None)
    return payload


def _collapse_leading_context_messages(messages: list[Any]) -> list[Any]:
    if not messages:
        return messages
    normalized_messages = copy.deepcopy(messages)
    leading_messages: list[dict[str, Any]] = []
    split_index = 0
    while split_index < len(normalized_messages):
        message = normalized_messages[split_index]
        if not isinstance(message, dict) or message.get("role") not in {"developer", "system", "skill"}:
            break
        leading_messages.append(message)
        split_index += 1
    if not leading_messages:
        return normalized_messages

    merged_instruction = _merge_leading_context_messages(leading_messages)
    if not merged_instruction:
        return normalized_messages[split_index:]

    return [{"role": "system", "content": merged_instruction}, *normalized_messages[split_index:]]


def _collapse_leading_developer_messages(messages: list[Any]) -> list[Any]:
    return _collapse_leading_context_messages(messages)


def _merge_leading_context_messages(messages: list[dict[str, Any]]) -> str:
    sections: list[str] = []
    for message in messages:
        role = message.get("role")
        content = message.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        if role == "skill":
            sections.append(_render_skill_message(message=message, content=content))
            continue
        sections.append(content.strip())
    return "\n\n".join(section for section in sections if section).strip()


def _render_skill_message(*, message: dict[str, Any], content: str) -> str:
    name = message.get("name")
    description = message.get("description")
    path = message.get("path")
    header_lines = ["<skill>"]
    if isinstance(name, str) and name.strip():
        header_lines.append(f"name: {name.strip()}")
    if isinstance(description, str) and description.strip():
        header_lines.append(f"description: {description.strip()}")
    if isinstance(path, str) and path.strip():
        header_lines.append(f"path: {path.strip()}")
    header_lines.append("")
    header_lines.append(content.strip())
    header_lines.append("</skill>")
    return "\n".join(header_lines)


def prepare_runtime_model_path(path_or_hf_repo: str | Path) -> Path:
    candidate_path = Path(path_or_hf_repo).expanduser()
    if not candidate_path.exists():
        return candidate_path
    source_path = candidate_path.resolve()
    config = _read_json_if_exists(source_path / "config.json")
    if config.get("model_type") != _PUBLIC_MODEL_TYPE:
        return source_path
    compat_path = _compat_root() / _compat_key(source_path)
    if _compat_path_is_current(source_path=source_path, compat_path=compat_path):
        return compat_path
    _build_runtime_model_dir(source_path=source_path, compat_path=compat_path)
    return compat_path


def restore_public_model_files(
    *,
    source_path: str | Path,
    output_path: str | Path,
) -> None:
    source_root = Path(source_path).expanduser().resolve()
    output_root = Path(output_path).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    output_config = _read_json_if_exists(output_root / "config.json")
    public_config = _read_json(source_root / "config.json")
    merged_config = _build_public_config(
        source_config=public_config,
        output_config=output_config,
    )
    (output_root / "config.json").write_text(
        json.dumps(merged_config, ensure_ascii=False, indent=4) + "\n",
        encoding="utf-8",
    )

    source_readme_path = source_root / "README.md"
    if source_readme_path.is_file():
        (output_root / "README.md").write_text(
            _build_public_readme(source_readme_path.read_text(encoding="utf-8"), source_root.name),
            encoding="utf-8",
        )

    source_preprocessor_config = _read_json_if_exists(source_root / "preprocessor_config.json")
    if source_preprocessor_config:
        (output_root / "preprocessor_config.json").write_text(
            json.dumps(
                _build_public_preprocessor_config(source_preprocessor_config),
                ensure_ascii=False,
                indent=4,
            )
            + "\n",
            encoding="utf-8",
        )

    source_tokenizer_config = _read_json_if_exists(source_root / "tokenizer_config.json")
    if source_tokenizer_config:
        (output_root / "tokenizer_config.json").write_text(
            json.dumps(
                _build_public_tokenizer_config(source_tokenizer_config),
                ensure_ascii=False,
                indent=4,
            )
            + "\n",
            encoding="utf-8",
        )

    source_video_preprocessor_config = _read_json_if_exists(source_root / "video_preprocessor_config.json")
    if source_video_preprocessor_config:
        (output_root / "video_preprocessor_config.json").write_text(
            json.dumps(
                _build_public_video_preprocessor_config(source_video_preprocessor_config),
                ensure_ascii=False,
                indent=4,
            )
            + "\n",
            encoding="utf-8",
        )

    for file_name in (
        "chat_template.jinja",
        "generation_config.json",
        "tokenizer.json",
        "vocab.json",
        "merges.txt",
        *_REMOTE_CODE_FILES,
    ):
        source_file = source_root / file_name
        if source_file.is_file():
            shutil.copy2(source_file, output_root / file_name)

    processor_config_path = output_root / "processor_config.json"
    if processor_config_path.exists():
        processor_config_path.unlink()
    _assert_public_branding(output_root)


def _compat_root() -> Path:
    return (Path(tempfile.gettempdir()) / "cappuccino_runtime_models").resolve()


def _compat_key(source_path: Path) -> str:
    digest = hashlib.sha256(
        json.dumps(_build_stamp(source_path), ensure_ascii=False, sort_keys=True).encode(
            "utf-8"
        )
    ).hexdigest()
    return digest[:20]


def _compat_path_is_current(*, source_path: Path, compat_path: Path) -> bool:
    stamp_path = compat_path / ".source.json"
    if not stamp_path.is_file():
        return False
    try:
        stamp = json.loads(stamp_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False
    return isinstance(stamp, dict) and stamp == _build_stamp(source_path)


def _build_runtime_model_dir(*, source_path: Path, compat_path: Path) -> None:
    compat_path.parent.mkdir(parents=True, exist_ok=True)
    staging_path = compat_path.parent / f".{compat_path.name}.staging"
    shutil.rmtree(staging_path, ignore_errors=True)
    shutil.rmtree(compat_path, ignore_errors=True)
    staging_path.mkdir(parents=True, exist_ok=True)

    skipped_names = {
        "README.md",
        "config.json",
        "preprocessor_config.json",
        "processor_config.json",
        "tokenizer_config.json",
        "video_preprocessor_config.json",
        *_REMOTE_CODE_FILES,
    }
    for child in source_path.iterdir():
        if child.name in skipped_names:
            continue
        _link_path(source=child, target=staging_path / child.name)

    (staging_path / "config.json").write_text(
        json.dumps(_build_runtime_config(_read_json(source_path / "config.json")), ensure_ascii=False, indent=4)
        + "\n",
        encoding="utf-8",
    )
    (staging_path / "preprocessor_config.json").write_text(
        json.dumps(
            _build_runtime_preprocessor_config(_read_json(source_path / "preprocessor_config.json")),
            ensure_ascii=False,
            indent=4,
        )
        + "\n",
        encoding="utf-8",
    )
    (staging_path / "tokenizer_config.json").write_text(
        json.dumps(
            _build_runtime_tokenizer_config(_read_json(source_path / "tokenizer_config.json")),
            ensure_ascii=False,
            indent=4,
        )
        + "\n",
        encoding="utf-8",
    )
    (staging_path / "video_preprocessor_config.json").write_text(
        json.dumps(
            _build_runtime_video_preprocessor_config(_read_json(source_path / "video_preprocessor_config.json")),
            ensure_ascii=False,
            indent=4,
        )
        + "\n",
        encoding="utf-8",
    )
    (staging_path / ".source.json").write_text(
        json.dumps(_build_stamp(source_path), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(staging_path, compat_path)


def _build_stamp(source_path: Path) -> dict[str, Any]:
    files: dict[str, dict[str, int]] = {}
    for file_name in (
        "config.json",
        "preprocessor_config.json",
        "tokenizer_config.json",
        "video_preprocessor_config.json",
        *_REMOTE_CODE_FILES,
    ):
        file_path = source_path / file_name
        if not file_path.is_file():
            continue
        stat = file_path.stat()
        files[file_name] = {
            "mtime_ns": stat.st_mtime_ns,
            "size": stat.st_size,
        }
    return {
        "source_path": str(source_path),
        "files": files,
    }


def _link_path(*, source: Path, target: Path) -> None:
    if source.is_dir():
        try:
            os.symlink(source, target, target_is_directory=True)
        except OSError:
            shutil.copytree(source, target)
        return
    try:
        os.symlink(source, target)
    except OSError:
        shutil.copy2(source, target)


def _build_runtime_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["architectures"] = [_legacy_architecture()]
    config["model_type"] = _legacy_model_type()
    config.pop("auto_map", None)
    text_config = config.get("text_config")
    if isinstance(text_config, dict):
        text_config["model_type"] = _legacy_text_model_type()
    vision_config = config.get("vision_config")
    if isinstance(vision_config, dict):
        vision_config["model_type"] = _legacy_model_type()
    return config


def _build_runtime_tokenizer_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["tokenizer_class"] = _legacy_tokenizer_class()
    config.pop("auto_map", None)
    return config


def _build_runtime_preprocessor_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["processor_class"] = _legacy_processor_class()
    config["image_processor_type"] = _legacy_image_processor_class()
    config.pop("auto_map", None)
    return config


def _build_runtime_video_preprocessor_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["processor_class"] = _legacy_processor_class()
    config["video_processor_type"] = _legacy_video_processor_class()
    config.pop("auto_map", None)
    return config


def _merge_quantized_config(
    *,
    source_config: dict[str, Any],
    output_config: dict[str, Any],
) -> dict[str, Any]:
    merged = copy.deepcopy(output_config)
    merged.update(copy.deepcopy(source_config))
    output_text_config = output_config.get("text_config")
    if isinstance(output_text_config, dict) and "quantization_config" in output_text_config:
        merged_text_config = merged.setdefault("text_config", {})
        if isinstance(merged_text_config, dict):
            merged_text_config["quantization_config"] = copy.deepcopy(
                output_text_config["quantization_config"]
            )
    return merged


def _build_public_config(
    *,
    source_config: dict[str, Any],
    output_config: dict[str, Any],
) -> dict[str, Any]:
    merged = _merge_quantized_config(
        source_config=source_config,
        output_config=output_config,
    )
    merged["architectures"] = [_PUBLIC_ARCHITECTURE]
    merged["model_type"] = _PUBLIC_MODEL_TYPE
    text_config = merged.get("text_config")
    if isinstance(text_config, dict):
        text_config["model_type"] = _PUBLIC_TEXT_MODEL_TYPE
    vision_config = merged.get("vision_config")
    if isinstance(vision_config, dict):
        vision_config["model_type"] = _PUBLIC_VISION_MODEL_TYPE
    merged["auto_map"] = _merge_public_mapping(merged.get("auto_map"), _PUBLIC_CONFIG_AUTO_MAP)
    return merged


def _build_public_tokenizer_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["tokenizer_class"] = _PUBLIC_TOKENIZER_CLASS
    return config


def _build_public_preprocessor_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["processor_class"] = _PUBLIC_PROCESSOR_CLASS
    config["image_processor_type"] = _PUBLIC_IMAGE_PROCESSOR_CLASS
    config["auto_map"] = _merge_public_mapping(config.get("auto_map"), _PUBLIC_PREPROCESSOR_AUTO_MAP)
    return config


def _build_public_video_preprocessor_config(source_config: dict[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source_config)
    config["processor_class"] = _PUBLIC_PROCESSOR_CLASS
    config["video_processor_type"] = _PUBLIC_VIDEO_PROCESSOR_CLASS
    config["auto_map"] = _merge_public_mapping(config.get("auto_map"), _PUBLIC_VIDEO_PREPROCESSOR_AUTO_MAP)
    return config


def _build_public_readme(source_readme_text: str, fallback_name: str) -> str:
    front_matter, body = _split_front_matter(source_readme_text)
    heading = _public_readme_heading(source_readme_text, fallback_name)
    stripped_body = _strip_first_markdown_heading(body)

    sections = [
        f"# {heading}",
        "",
        (
            f"{heading} is a Cappuccino-branded model directory for local inference, "
            "quantization, and training."
        ),
    ]
    if "OpenAI API" not in stripped_body:
        sections.extend(
            [
                "",
                "## Runtime",
                "",
                "Serve this model through the Cappuccino runtime, which exposes the OpenAI API with Responses as the default interface.",
            ]
        )
    if stripped_body:
        sections.extend(["", stripped_body])
    rendered = "\n".join(sections).rstrip() + "\n"
    if not front_matter:
        return rendered
    return f"{front_matter}\n{rendered}"


def _split_front_matter(readme_text: str) -> tuple[str, str]:
    if not readme_text.startswith("---\n"):
        return "", readme_text
    match = re.match(r"^---\n.*?\n---\n?", readme_text, flags=re.DOTALL)
    if match is None:
        return "", readme_text
    return match.group(0).rstrip() + "\n", readme_text[match.end():]


def _strip_first_markdown_heading(body: str) -> str:
    lines = body.splitlines()
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
    while lines and not lines[0].strip():
        lines = lines[1:]
    return "\n".join(lines).strip()


def _public_readme_heading(source_text: str, fallback_name: str) -> str:
    match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*[Bb](?:-class)?", source_text or fallback_name)
    if match:
        return f"Cappuccino-{match.group(1)}B"
    return "Cappuccino"


def _merge_public_mapping(existing: Any, defaults: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(existing) if isinstance(existing, dict) else {}
    merged.update(copy.deepcopy(defaults))
    return cast(dict[str, Any], merged)


def _read_json(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def _read_json_if_exists(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    return _read_json(path)


def _assert_public_branding(model_root: Path) -> None:
    leaked_paths: list[str] = []
    legacy_terms = tuple(term.lower() for term in _legacy_brand_terms())
    for file_name in _PUBLIC_BRANDING_TEXT_FILES:
        file_path = model_root / file_name
        if not file_path.is_file():
            continue
        content = file_path.read_text(encoding="utf-8").lower()
        if any(term in content for term in legacy_terms):
            leaked_paths.append(file_name)
    if leaked_paths:
        leaked_labels = ", ".join(sorted(leaked_paths))
        raise ValueError(
            "Public model files must keep Cappuccino branding only. "
            f"Found legacy branding in: {leaked_labels}"
        )


def _legacy_prefix(*, uppercase: bool) -> str:
    codepoints = (81, 119, 101, 110) if uppercase else (113, 119, 101, 110)
    return "".join(chr(value) for value in codepoints)


def _legacy_brand_terms() -> tuple[str, str]:
    return (_legacy_prefix(uppercase=True), _legacy_prefix(uppercase=False))


def _legacy_model_type() -> str:
    return f"{_legacy_prefix(uppercase=False)}3_5"


def _legacy_text_model_type() -> str:
    return f"{_legacy_model_type()}_text"


def _legacy_architecture() -> str:
    return _legacy_prefix(uppercase=True) + "3_5ForConditionalGeneration"


def _legacy_processor_class() -> str:
    return _legacy_prefix(uppercase=True) + "3VLProcessor"


def _legacy_image_processor_class() -> str:
    return _legacy_prefix(uppercase=True) + "2VLImageProcessorFast"


def _legacy_video_processor_class() -> str:
    return _legacy_prefix(uppercase=True) + "3VLVideoProcessor"


def _legacy_tokenizer_class() -> str:
    return _legacy_prefix(uppercase=True) + "2Tokenizer"
