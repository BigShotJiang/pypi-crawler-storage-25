from __future__ import annotations

import fcntl
import json
import os
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


class WorkloadLockError(RuntimeError):
    pass


_LOCK_ROOT = (Path(tempfile.gettempdir()) / "cappuccino_locks").resolve()
_LOCK_PATH = _LOCK_ROOT / "heavy_job.lock"
_METADATA_PATH = _LOCK_ROOT / "heavy_job.json"


@contextmanager
def acquire_heavy_job_lock(*, task: str, detail: str | None = None) -> Iterator[None]:
    _LOCK_ROOT.mkdir(parents=True, exist_ok=True)
    handle = _LOCK_PATH.open("a+", encoding="utf-8")
    try:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise WorkloadLockError(_format_lock_error(task=task)) from exc
        metadata = {
            "task": task,
            "detail": detail,
            "pid": os.getpid(),
            "started_at_epoch": time.time(),
        }
        _METADATA_PATH.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        yield
    finally:
        _METADATA_PATH.unlink(missing_ok=True)
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def _format_lock_error(*, task: str) -> str:
    holder = _read_lock_metadata()
    if holder is None:
        return (
            f"Cannot start {task} because another heavy Cappuccino job is already running. "
            "Avoid running training, checkpoint sampling, quantization, or corpus scraping in parallel."
        )
    holder_task = holder.get("task")
    holder_detail = holder.get("detail")
    holder_pid = holder.get("pid")
    detail_suffix = f" ({holder_detail})" if isinstance(holder_detail, str) and holder_detail else ""
    pid_suffix = f" pid={holder_pid}" if isinstance(holder_pid, int) else ""
    return (
        f"Cannot start {task} because another heavy Cappuccino job is already running: "
        f"{holder_task or 'unknown'}{detail_suffix}{pid_suffix}. "
        "Avoid running training, checkpoint sampling, quantization, or corpus scraping in parallel."
    )


def _read_lock_metadata() -> dict[str, object] | None:
    if not _METADATA_PATH.is_file():
        return None
    try:
        payload = json.loads(_METADATA_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    return payload
