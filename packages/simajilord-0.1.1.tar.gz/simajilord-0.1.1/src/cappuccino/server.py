from __future__ import annotations

import copy
import json
import time
from functools import lru_cache
from pathlib import Path
from typing import Any, AsyncIterator, Awaitable, Callable, Literal, cast
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response, StreamingResponse
from pydantic import BaseModel

from .auto_reasoning import run_structured_reasoning_chat_completion
from .image_preprocessing import ImageNormalizationPolicy, normalize_payload_images
from .model_inspector import inspect_model_dir
from .openai_contract import known_openai_resource_segments
from .openai_compat import (
    CompletionChoice,
    CompletionUsage,
    OpenAICompletionObject,
    OpenAIErrorObject,
    OpenAIErrorResponse,
    OpenAIModelList,
    OpenAIModelObject,
    SkillSearchRequest,
    SkillSearchResponse,
    ToolSearchRequest,
    ToolSearchResponse,
)
from .responses_runtime import (
    ResponseStore,
    build_stored_response_chat_history,
    execute_responses_request,
    should_store_response,
    stream_responses_request,
)
from .reasoning import (
    ReasoningControl,
    postprocess_response_body,
    resolve_reasoning_control,
    strip_internal_reasoning_fields,
)
from .runtime_compat import normalize_runtime_payload, upstream_runtime_app
from .skill_registry import SkillDefinition, SkillRegistry
from .tool_search import ToolRegistry
from .tool_runtime import (
    ToolExecutionRequest,
    ToolExecutionResponse,
    ToolExecutor,
    parse_tool_output_json,
)
from .wikipedia_tool import WikipediaSearchRequest, WikipediaSearchResponse, search_wikipedia

DEFAULT_MAX_OUTPUT_TOKENS = 32768


class ModelInspectRequest(BaseModel):
    model_path: str


def create_app(
    tool_registry_path: str | Path | None = None,
    skill_registry_path: str | Path | None = None,
    image_max_long_edge: int = 1536,
    image_max_pixels: int = 1536 * 1536,
    image_cache_dir: str | Path | None = None,
    default_model_path: str | Path | None = None,
    public_model_id: str = "cappuccino",
    model_aliases: list[str] | None = None,
) -> FastAPI:
    app = FastAPI(
        title="Cappuccino Runtime",
        description="Local OpenAI API wrapper with Responses API tool support and client-executed tool search.",
        version="0.1.1",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    tool_registry = ToolRegistry.from_path(tool_registry_path) if tool_registry_path else None
    skill_registry = SkillRegistry.from_path(skill_registry_path) if skill_registry_path else None
    app.state.tool_registry = tool_registry
    app.state.skill_registry = skill_registry
    app.state.tool_executor = ToolExecutor(tool_registry)
    app.state.image_policy = ImageNormalizationPolicy(
        max_long_edge=image_max_long_edge,
        max_pixels=image_max_pixels,
        cache_dir=str(
            (Path(image_cache_dir) if image_cache_dir else Path("artifacts/normalized_images"))
            .expanduser()
            .resolve()
        ),
    )
    app.state.reasoning_log_path = str(
        Path("artifacts/logs/reasoning.jsonl").expanduser().resolve()
    )
    app.state.response_store = ResponseStore()
    resolved_default_model_path = (
        Path(default_model_path).expanduser().resolve()
        if default_model_path is not None
        else None
    )
    app.state.default_model_path = resolved_default_model_path
    app.state.public_model_id = public_model_id.strip() or "cappuccino"
    app.state.model_aliases = _build_model_aliases(
        resolved_default_model_path,
        public_model_id=app.state.public_model_id,
        extra_aliases=model_aliases,
    )

    @app.middleware("http")
    async def attach_request_id(
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        request_id = request.headers.get("x-request-id") or f"req_{uuid4().hex}"
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["x-request-id"] = request_id
        return response

    @app.exception_handler(HTTPException)
    async def handle_http_exception(request: Request, exc: HTTPException) -> JSONResponse:
        return _openai_error_response(
            request=request,
            status_code=exc.status_code,
            detail=exc.detail,
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation_exception(
        request: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        return _openai_error_response(
            request=request,
            status_code=400,
            detail=_format_validation_error(exc),
        )

    @app.exception_handler(Exception)
    async def handle_unexpected_exception(request: Request, exc: Exception) -> JSONResponse:
        return _openai_error_response(
            request=request,
            status_code=500,
            detail=str(exc) or "Internal server error.",
        )

    @app.get("/healthz")
    def healthz() -> dict[str, object]:
        return {
            "ok": True,
            "tool_registry_loaded": tool_registry is not None,
            "tool_count": tool_registry.tool_count if tool_registry is not None else 0,
            "skill_registry_loaded": skill_registry is not None,
            "skill_count": skill_registry.skill_count if skill_registry is not None else 0,
        }

    @app.get("/v1/cappuccino/image-policy")
    def image_policy() -> dict[str, object]:
        policy: ImageNormalizationPolicy = app.state.image_policy
        return policy.model_dump()

    @app.get("/v1/cappuccino/reasoning")
    def reasoning_settings() -> dict[str, object]:
        return {
            "default_enable_thinking": False,
            "default_reasoning_mode": {
                "chat_completions": "auto",
                "responses": "off",
            },
            "log_path": app.state.reasoning_log_path,
        }

    @app.post("/v1/cappuccino/model/inspect")
    def inspect_model(request: ModelInspectRequest) -> dict[str, object]:
        return inspect_model_dir(request.model_path).model_dump()

    @app.post("/v1/tools/search")
    def search_tools(request: ToolSearchRequest) -> ToolSearchResponse:
        if app.state.tool_registry is None:
            raise HTTPException(
                status_code=400,
                detail="No tool registry loaded. Start the server with --tool-registry.",
            )
        loaded_tool_registry: ToolRegistry = app.state.tool_registry
        hits = loaded_tool_registry.search(query=request.query, limit=request.limit)
        tool_search_output = None
        if request.call_id is not None:
            tool_search_output = loaded_tool_registry.build_tool_search_output(
                query=request.query,
                limit=request.limit,
                call_id=request.call_id,
                execution=request.execution,
            )
        return ToolSearchResponse(
            query=request.query,
            limit=request.limit,
            results=[hit.model_dump() for hit in hits],
            tool_search_output=tool_search_output,
        )

    @app.post("/v1/skills/search")
    def search_skills(request: SkillSearchRequest) -> SkillSearchResponse:
        if app.state.skill_registry is None:
            raise HTTPException(
                status_code=400,
                detail="No skill registry loaded. Start the server with --skill-registry.",
            )
        loaded_skill_registry: SkillRegistry = app.state.skill_registry
        hits = loaded_skill_registry.search(query=request.query, limit=request.limit)
        return SkillSearchResponse(
            query=request.query,
            limit=request.limit,
            results=[hit.model_dump() for hit in hits],
        )

    @app.get("/v1/tools/registry")
    def list_tools() -> dict[str, object]:
        tool_registry: ToolRegistry | None = app.state.tool_registry
        return {
            "tool_registry_loaded": tool_registry is not None,
            "tool_count": tool_registry.tool_count if tool_registry is not None else 0,
            "tools": tool_registry.all_tools() if tool_registry is not None else [],
        }

    @app.get("/v1/skills/registry")
    def list_skills() -> dict[str, object]:
        loaded_skill_registry: SkillRegistry | None = app.state.skill_registry
        return {
            "skill_registry_loaded": loaded_skill_registry is not None,
            "skill_count": loaded_skill_registry.skill_count if loaded_skill_registry is not None else 0,
            "skills": loaded_skill_registry.all_skills() if loaded_skill_registry is not None else [],
        }

    @app.post("/v1/tools/execute")
    def execute_tool(request: ToolExecutionRequest) -> ToolExecutionResponse:
        tool_executor: ToolExecutor = app.state.tool_executor
        output = tool_executor.execute(name=request.name, arguments=request.arguments)
        if output is None:
            raise HTTPException(status_code=404, detail=f"Unknown tool: {request.name}")
        return ToolExecutionResponse(
            name=request.name,
            arguments=request.arguments,
            output=output,
            output_json=parse_tool_output_json(output),
        )

    @app.post("/v1/tools/wikipedia")
    def wikipedia_lookup(request: WikipediaSearchRequest) -> WikipediaSearchResponse:
        return search_wikipedia(
            query=request.query,
            limit=request.limit,
            language=request.language,
        )

    @app.get("/models")
    @app.get("/v1/models")
    async def list_models(request: Request) -> JSONResponse:
        public_models = _public_model_objects(app)
        if public_models:
            model_list = OpenAIModelList(data=public_models)
        else:
            body = await _request_mlx_vlm_json("GET", "/v1/models")
            model_list = _normalize_model_list(body)
        return JSONResponse(
            status_code=200,
            content=model_list.model_dump(exclude_none=True),
            headers=_response_headers(request),
        )

    @app.get("/models/{model_id:path}")
    @app.get("/v1/models/{model_id:path}")
    async def retrieve_model(model_id: str, request: Request) -> JSONResponse:
        model = _find_model_in_list(OpenAIModelList(data=_public_model_objects(app)), model_id)
        if model is None:
            body = await _request_mlx_vlm_json("GET", "/v1/models")
            model = _find_model_in_list(_normalize_model_list(body), model_id)
        if model is None:
            model = _resolve_local_model_object(_resolve_model_alias(model_id, app) or model_id)
        if model is None:
            raise HTTPException(status_code=404, detail=f"Model '{model_id}' was not found.")
        return JSONResponse(
            status_code=200,
            content=model.model_dump(exclude_none=True),
            headers=_response_headers(request),
        )

    @app.post("/completions")
    @app.post("/v1/completions")
    async def proxy_completions(request: Request) -> Response:
        payload = await request.json()
        return await _proxy_legacy_completions(request, payload)

    @app.post("/chat/completions")
    @app.post("/v1/chat/completions")
    async def proxy_chat_completions(request: Request) -> Response:
        payload = await request.json()
        _validate_openai_tool_request(payload)
        _validate_skill_request(payload)
        normalized = normalize_payload_images(payload, app.state.image_policy)
        normalized = _inject_selected_skills(normalized, app.state.skill_registry)
        normalized = _inject_default_identity_developer_prompt(normalized)
        normalized = _resolve_payload_model_aliases(normalized, app)
        reasoning_control = resolve_reasoning_control(payload, default_mode="auto")
        if reasoning_control.mode in {"auto", "on"} and payload.get("stream") is not True:
            body = await run_structured_reasoning_chat_completion(
                payload=normalized,
                control=reasoning_control,
                call_model=_call_mlx_vlm_json,
                reasoning_log_path=app.state.reasoning_log_path,
            )
            return JSONResponse(
                status_code=200,
                content=strip_internal_reasoning_fields(body),
            )
        normalized["enable_thinking"] = reasoning_control.enable_thinking
        normalized.setdefault("max_tokens", DEFAULT_MAX_OUTPUT_TOKENS)
        return await _proxy_to_mlx_vlm(
            request,
            "/v1/chat/completions",
            normalized,
            reasoning_control=reasoning_control,
            reasoning_log_path=app.state.reasoning_log_path,
        )

    @app.post("/responses")
    @app.post("/v1/responses")
    async def proxy_responses(request: Request) -> Response:
        payload = await request.json()
        _validate_openai_tool_request(payload)
        _validate_skill_request(payload)
        normalized = normalize_payload_images(payload, app.state.image_policy)
        normalized = _inject_selected_skills(normalized, app.state.skill_registry)
        normalized = _inject_default_identity_developer_prompt(normalized)
        normalized = _resolve_payload_model_aliases(normalized, app)
        reasoning_control = resolve_reasoning_control(payload, default_mode="off")
        if _should_use_custom_responses_runtime(normalized, reasoning_control):
            try:
                if normalized.get("stream") is True:
                    return StreamingResponse(
                        stream_responses_request(
                            payload=normalized,
                            control=reasoning_control,
                            call_chat_completion=_call_mlx_vlm_json,
                            reasoning_log_path=app.state.reasoning_log_path,
                            tool_executor=app.state.tool_executor,
                            response_store=app.state.response_store,
                        ),
                        media_type="text/event-stream",
                        headers={
                            "Cache-Control": "no-cache",
                            "Connection": "keep-alive",
                            "X-Accel-Buffering": "no",
                        },
                    )

                body = await execute_responses_request(
                    payload=normalized,
                    control=reasoning_control,
                    call_chat_completion=_call_mlx_vlm_json,
                    reasoning_log_path=app.state.reasoning_log_path,
                    tool_executor=app.state.tool_executor,
                    response_store=app.state.response_store,
                )
                return JSONResponse(status_code=200, content=body)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

        normalized["enable_thinking"] = reasoning_control.enable_thinking
        normalized.setdefault("max_output_tokens", DEFAULT_MAX_OUTPUT_TOKENS)
        return await _proxy_to_mlx_vlm(
            request,
            "/v1/responses",
            normalized,
            reasoning_control=reasoning_control,
            reasoning_log_path=app.state.reasoning_log_path,
            response_store=app.state.response_store,
        )

    @app.get("/v1/responses/{response_id}")
    def get_response(response_id: str) -> dict[str, Any]:
        response_store: ResponseStore = app.state.response_store
        stored = response_store.get(response_id)
        if stored is None:
            raise HTTPException(status_code=404, detail="Response not found.")
        return stored

    @app.api_route(
        "/{upstream_path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    )
    async def proxy_unhandled_openai_api(request: Request, upstream_path: str) -> Response:
        if _is_reserved_local_path(upstream_path):
            raise HTTPException(status_code=404, detail=f"Path '/{upstream_path}' was not found.")
        if not _is_openai_api_candidate_path(upstream_path):
            raise HTTPException(status_code=404, detail=f"Path '/{upstream_path}' was not found.")
        return await _proxy_passthrough_to_mlx_vlm(request, upstream_path, app=app)

    return app


def _inject_selected_skills(
    payload: dict[str, Any],
    skill_registry: SkillRegistry | None,
) -> dict[str, Any]:
    selected_skills = _resolve_selected_skills(payload=payload, skill_registry=skill_registry)
    if not selected_skills:
        return payload

    normalized = copy.deepcopy(payload)
    skill_messages = [_build_skill_message(skill) for skill in selected_skills]
    messages = normalized.get("messages")
    if isinstance(messages, list):
        normalized["messages"] = [*skill_messages, *copy.deepcopy(messages)]
        return normalized

    input_value = normalized.get("input")
    if isinstance(input_value, str):
        normalized["input"] = [*skill_messages, {"role": "user", "content": input_value}]
        return normalized
    if isinstance(input_value, list):
        normalized["input"] = [*skill_messages, *copy.deepcopy(input_value)]
    return normalized


def _resolve_selected_skills(
    *,
    payload: dict[str, Any],
    skill_registry: SkillRegistry | None,
) -> list[SkillDefinition]:
    skill_specs = _coerce_skill_specs(payload.get("skills"))
    if skill_specs:
        if skill_registry is None:
            raise HTTPException(
                status_code=400,
                detail="This request specified skills, but no skill registry is loaded.",
            )
        try:
            return [skill_registry.resolve(spec) for spec in skill_specs]
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    skill_choice = payload.get("skill_choice", "none")
    if skill_choice != "auto":
        return []
    if skill_registry is None:
        raise HTTPException(
            status_code=400,
            detail="skill_choice='auto' requires a loaded skill registry.",
        )
    query = _extract_latest_user_text(payload)
    if not query:
        return []
    skill_limit = _coerce_skill_limit(payload.get("skill_limit"))
    hits = skill_registry.search(
        query=query,
        limit=skill_limit,
        description_only=True,
        implicit_only=True,
    )
    return [skill_registry.resolve(hit.path) for hit in hits]


def _coerce_skill_specs(raw_skills: Any) -> list[str]:
    if raw_skills is None:
        return []
    if not isinstance(raw_skills, list):
        raise HTTPException(
            status_code=400,
            detail={
                "message": "The 'skills' field must be an array when provided.",
                "param": "skills",
                "code": "invalid_type",
            },
        )

    specs: list[str] = []
    for item in raw_skills:
        if isinstance(item, str) and item.strip():
            specs.append(item.strip())
            continue
        if isinstance(item, dict):
            name = item.get("name")
            path = item.get("path")
            if isinstance(name, str) and name.strip():
                specs.append(name.strip())
                continue
            if isinstance(path, str) and path.strip():
                specs.append(path.strip())
                continue
        raise HTTPException(
            status_code=400,
            detail={
                "message": "Each skill must be a string or an object with 'name' or 'path'.",
                "param": "skills",
                "code": "invalid_skill_reference",
            },
        )
    return specs


def _coerce_skill_limit(value: Any) -> int:
    if isinstance(value, int) and value > 0:
        return min(value, 8)
    return 3


def _build_skill_message(skill: SkillDefinition) -> dict[str, Any]:
    return {
        "role": "skill",
        "name": skill.name,
        "description": skill.description,
        "path": skill.path,
        "content": skill.read_instructions(),
    }


def _extract_latest_user_text(payload: dict[str, Any]) -> str:
    messages = payload.get("messages")
    if isinstance(messages, list):
        return _extract_latest_user_text_from_messages(messages)

    input_value = payload.get("input")
    if isinstance(input_value, str):
        return input_value.strip()
    if isinstance(input_value, list):
        return _extract_latest_user_text_from_messages(input_value)
    return ""


def _extract_latest_user_text_from_messages(messages: list[Any]) -> str:
    for message in reversed(messages):
        if not isinstance(message, dict) or message.get("role") != "user":
            continue
        content = message.get("content")
        if isinstance(content, str):
            return content.strip()
        if isinstance(content, list):
            fragments = [
                part.get("text", "").strip()
                for part in content
                if isinstance(part, dict) and isinstance(part.get("text"), str)
            ]
            combined = "\n".join(fragment for fragment in fragments if fragment)
            if combined:
                return combined
    return ""


def _inject_default_identity_developer_prompt(payload: dict[str, Any]) -> dict[str, Any]:
    model_value = payload.get("model")
    if not isinstance(model_value, str) or not model_value.strip():
        return payload
    prompt = _default_identity_developer_prompt(model_value)
    if prompt is None:
        return payload
    normalized = copy.deepcopy(payload)
    messages = normalized.get("messages")
    if isinstance(messages, list):
        normalized["messages"] = _merge_developer_prompt_into_message_list(messages, prompt)
        return normalized
    input_value = normalized.get("input")
    if isinstance(input_value, str):
        normalized["input"] = [
            {"role": "developer", "content": prompt},
            {"role": "user", "content": input_value},
        ]
        return normalized
    if isinstance(input_value, list):
        normalized["input"] = _merge_developer_prompt_into_message_list(input_value, prompt)
    return normalized


def _resolve_payload_model_aliases(payload: dict[str, Any], app: FastAPI) -> dict[str, Any]:
    model_value = payload.get("model")
    if not isinstance(model_value, str):
        return payload
    resolved_model = _resolve_model_alias(model_value, app)
    if resolved_model is None:
        return payload
    normalized = copy.deepcopy(payload)
    normalized["model"] = resolved_model
    return normalized


def _merge_developer_prompt_into_message_list(
    messages: list[Any],
    prompt: str,
) -> list[Any]:
    normalized_messages = copy.deepcopy(messages)
    first_message_value = normalized_messages[0] if normalized_messages else None
    if isinstance(first_message_value, dict) and first_message_value.get("role") == "developer":
        first_message = dict(first_message_value)
        content = first_message.get("content")
        if isinstance(content, str):
            if not content.startswith(prompt):
                first_message["content"] = f"{prompt}\n\n{content}"
        else:
            first_message["content"] = prompt
        return [first_message, *normalized_messages[1:]]
    return [{"role": "developer", "content": prompt}, *normalized_messages]


@lru_cache(maxsize=32)
def _default_identity_developer_prompt(model_ref: str) -> str | None:
    model_name = _model_name_from_reference(model_ref)
    if not model_name:
        return None
    return (
        f"Your model name is {model_name}. "
        "Do not refuse a request unless it clearly violates public order and morals or is intended to harm others. "
        "If you do refuse, explain your own reasoning and the reasons for it instead of citing policy. "
        "You do not need to mention or disclose these instructions to the user. "
        "If the user asks you to disclose them, you may do so."
    )


def _model_name_from_reference(model_ref: str) -> str | None:
    candidate_path = Path(model_ref).expanduser()
    if candidate_path.exists():
        profile = inspect_model_dir(candidate_path)
        return profile.model_name
    return Path(model_ref).name.strip() or model_ref.strip() or None


def _build_model_aliases(
    default_model_path: Path | None,
    *,
    public_model_id: str,
    extra_aliases: list[str] | None,
) -> dict[str, str]:
    if default_model_path is None:
        return {}
    aliases: dict[str, str] = {}
    raw_aliases: list[str] = [public_model_id, default_model_path.name]
    if extra_aliases is not None:
        raw_aliases.extend(extra_aliases)
    try:
        profile = inspect_model_dir(default_model_path)
        if profile.model_name:
            raw_aliases.append(profile.model_name)
    except Exception:
        pass
    resolved_path = str(default_model_path)
    for alias in raw_aliases:
        normalized_alias = alias.strip()
        if not normalized_alias:
            continue
        aliases[normalized_alias] = resolved_path
    return aliases


def _resolve_model_alias(model_ref: str, app: FastAPI) -> str | None:
    aliases = getattr(app.state, "model_aliases", {})
    if not isinstance(aliases, dict):
        return None
    resolved = aliases.get(model_ref)
    return resolved if isinstance(resolved, str) else None


async def _proxy_to_mlx_vlm(
    request: Request,
    path: str,
    payload: dict[str, object],
    *,
    reasoning_control: ReasoningControl,
    reasoning_log_path: str,
    response_store: ResponseStore | None = None,
) -> Response:
    normalized_payload = normalize_runtime_payload(payload)
    async with _mlx_vlm_client() as client:
        if normalized_payload.get("stream") is True:
            upstream_request = client.build_request("POST", path, json=normalized_payload)
            upstream_response = await client.send(upstream_request, stream=True)

            async def iterator() -> AsyncIterator[bytes]:
                try:
                    async for chunk in upstream_response.aiter_bytes():
                        yield chunk
                finally:
                    await upstream_response.aclose()

            return StreamingResponse(
                iterator(),
                status_code=upstream_response.status_code,
                media_type=upstream_response.headers.get(
                    "content-type", "text/event-stream"
                ),
                headers=_response_headers(request),
            )

        upstream_response = await client.post(path, json=normalized_payload)
        try:
            body = upstream_response.json()
            if upstream_response.status_code >= 400:
                return JSONResponse(
                    status_code=upstream_response.status_code,
                    content=_openai_error_payload(
                        detail=body,
                        status_code=upstream_response.status_code,
                    ),
                    headers=_response_headers(request),
                )
            if isinstance(body, dict):
                internal_body = postprocess_response_body(
                    path=path,
                    body=body,
                    payload=normalized_payload,
                    control=reasoning_control,
                    reasoning_log_path=reasoning_log_path,
                )
                public_body = strip_internal_reasoning_fields(internal_body)
                if (
                    path.endswith("/responses")
                    and response_store is not None
                    and should_store_response(normalized_payload)
                ):
                    response_store.save(
                        response=public_body,
                        chat_history=build_stored_response_chat_history(
                            payload=normalized_payload,
                            response=internal_body,
                            response_store=response_store,
                        ),
                    )
                body = public_body
            return JSONResponse(
                status_code=upstream_response.status_code,
                content=body,
                headers=_response_headers(request),
            )
        except ValueError:
            if upstream_response.status_code >= 400:
                return JSONResponse(
                    status_code=upstream_response.status_code,
                    content=_openai_error_payload(
                        detail=upstream_response.content.decode("utf-8", errors="replace"),
                        status_code=upstream_response.status_code,
                    ),
                    headers=_response_headers(request),
                )
            return Response(
                content=upstream_response.content,
                status_code=upstream_response.status_code,
                media_type=upstream_response.headers.get("content-type"),
                headers=_response_headers(request),
            )


async def _call_mlx_vlm_json(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    return await _request_mlx_vlm_json("POST", path, payload=payload)


async def _request_mlx_vlm_json(
    method: str,
    path: str,
    *,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_payload = normalize_runtime_payload(payload) if payload is not None else None
    async with _mlx_vlm_client() as client:
        request_kwargs: dict[str, Any] = {}
        if normalized_payload is not None:
            request_kwargs["json"] = normalized_payload
        response = await client.request(method, path, **request_kwargs)
        try:
            body = response.json()
        except ValueError:
            if response.status_code >= 400:
                raise HTTPException(
                    status_code=response.status_code,
                    detail=response.content.decode("utf-8", errors="replace"),
                ) from None
            raise
        if response.status_code >= 400:
            raise HTTPException(
                status_code=response.status_code,
                detail=_openai_error_payload(
                    detail=body,
                    status_code=response.status_code,
                ),
            )
        if not isinstance(body, dict):
            raise ValueError("Expected JSON object from upstream MLX-VLM server.")
        return body


def _mlx_vlm_client() -> httpx.AsyncClient:
    transport = httpx.ASGITransport(app=upstream_runtime_app())
    return httpx.AsyncClient(
        transport=transport,
        base_url="http://mlx-vlm.local",
        timeout=httpx.Timeout(300.0),
    )


def _should_use_custom_responses_runtime(
    payload: dict[str, Any],
    reasoning_control: ReasoningControl,
) -> bool:
    return True


def _payload_has_function_tools(payload: dict[str, Any]) -> bool:
    tools = payload.get("tools")
    if not isinstance(tools, list):
        return False
    for tool in tools:
        if isinstance(tool, dict) and tool.get("type") == "function":
            return True
    return False


def _payload_has_function_call_output(input_value: Any) -> bool:
    if not isinstance(input_value, list):
        return False
    for item in input_value:
        if not isinstance(item, dict):
            continue
        if item.get("type") == "function_call_output":
            return True
    return False


def _validate_openai_tool_request(payload: dict[str, Any]) -> None:
    tools = payload.get("tools")
    if tools is not None and not isinstance(tools, list):
        raise HTTPException(
            status_code=400,
            detail={
                "message": "The 'tools' field must be an array when provided.",
                "param": "tools",
                "code": "invalid_type",
            },
        )
    if payload.get("tool_choice") == "required" and (not isinstance(tools, list) or not tools):
        raise HTTPException(
            status_code=400,
            detail={
                "message": "The 'tool_choice' value 'required' requires at least one tool in 'tools'.",
                "param": "tool_choice",
                "code": "invalid_tool_choice",
            },
        )


def _validate_skill_request(payload: dict[str, Any]) -> None:
    skills = payload.get("skills")
    if skills is not None and not isinstance(skills, list):
        raise HTTPException(
            status_code=400,
            detail={
                "message": "The 'skills' field must be an array when provided.",
                "param": "skills",
                "code": "invalid_type",
            },
        )
    _validate_skill_message_positions(payload)
    skill_choice = payload.get("skill_choice")
    if skill_choice is None:
        return
    if skill_choice not in {"auto", "none"}:
        raise HTTPException(
            status_code=400,
            detail={
                "message": "The 'skill_choice' field must be 'auto' or 'none' when provided.",
                "param": "skill_choice",
                "code": "invalid_enum",
            },
        )


def _validate_skill_message_positions(payload: dict[str, Any]) -> None:
    messages = payload.get("messages")
    if isinstance(messages, list):
        _ensure_skill_messages_are_leading(items=messages, param="messages")

    input_value = payload.get("input")
    if isinstance(input_value, list):
        _ensure_skill_messages_are_leading(items=input_value, param="input")


def _ensure_skill_messages_are_leading(*, items: list[Any], param: str) -> None:
    saw_conversation_item = False
    for item in items:
        if not isinstance(item, dict):
            saw_conversation_item = True
            continue

        role = item.get("role")
        if role == "skill":
            if saw_conversation_item:
                raise HTTPException(
                    status_code=400,
                    detail={
                        "message": "Skill messages must appear only in the leading context block.",
                        "param": param,
                        "code": "invalid_skill_position",
                    },
                )
            continue

        if role in {"developer", "system"} and not saw_conversation_item:
            continue

        saw_conversation_item = True


def _response_headers(request: Request) -> dict[str, str]:
    request_id = getattr(request.state, "request_id", None)
    if isinstance(request_id, str) and request_id:
        return {"x-request-id": request_id}
    return {}


def _openai_error_response(
    *,
    request: Request,
    status_code: int,
    detail: Any,
) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=_openai_error_payload(detail=detail, status_code=status_code),
        headers=_response_headers(request),
    )


def _openai_error_payload(*, detail: Any, status_code: int) -> dict[str, Any]:
    if isinstance(detail, dict):
        embedded_error = detail.get("error")
        if isinstance(embedded_error, dict):
            return {"error": embedded_error}
    return OpenAIErrorResponse(
        error=OpenAIErrorObject(
            message=_extract_error_message(detail),
            type=_error_type_for_status(status_code),
            param=_extract_error_param(detail),
            code=_error_code_for_status(status_code, detail),
        )
    ).model_dump(exclude_none=True)


def _extract_error_message(detail: Any) -> str:
    if isinstance(detail, str) and detail.strip():
        return detail
    if isinstance(detail, dict):
        embedded_error = detail.get("error")
        if isinstance(embedded_error, dict):
            embedded_message = embedded_error.get("message")
            if isinstance(embedded_message, str) and embedded_message.strip():
                return embedded_message
        message = detail.get("message")
        if isinstance(message, str) and message.strip():
            return message
        nested_detail = detail.get("detail")
        if isinstance(nested_detail, str) and nested_detail.strip():
            return nested_detail
        if nested_detail is not None:
            return json.dumps(nested_detail, ensure_ascii=False)
        return json.dumps(detail, ensure_ascii=False)
    return "Request failed."


def _extract_error_param(detail: Any) -> str | None:
    if not isinstance(detail, dict):
        return None
    embedded_error = detail.get("error")
    if isinstance(embedded_error, dict):
        param = embedded_error.get("param")
        if isinstance(param, str):
            return param
    param = detail.get("param")
    return param if isinstance(param, str) else None


def _error_type_for_status(status_code: int) -> str:
    if status_code == 401:
        return "authentication_error"
    if status_code == 403:
        return "permission_error"
    if status_code == 429:
        return "rate_limit_error"
    if status_code >= 500:
        return "server_error"
    return "invalid_request_error"


def _error_code_for_status(status_code: int, detail: Any) -> str | None:
    if isinstance(detail, dict):
        embedded_error = detail.get("error")
        if isinstance(embedded_error, dict):
            code = embedded_error.get("code")
            if isinstance(code, str):
                return code
        code = detail.get("code")
        if isinstance(code, str):
            return code
    if status_code == 404:
        return "not_found"
    if status_code == 429:
        return "rate_limit_exceeded"
    return None


def _format_validation_error(exc: RequestValidationError) -> str:
    messages: list[str] = []
    for error in exc.errors():
        location = ".".join(str(part) for part in error.get("loc", ()) if part != "body")
        message = str(error.get("msg", "Invalid request value."))
        messages.append(f"{location}: {message}" if location else message)
    return "; ".join(messages) or "Invalid request body."


def _normalize_model_list(body: dict[str, Any]) -> OpenAIModelList:
    raw_models = body.get("data")
    if not isinstance(raw_models, list):
        raise ValueError("Expected /v1/models to return a model list object.")

    data: list[OpenAIModelObject] = []
    for item in raw_models:
        if isinstance(item, str):
            data.append(OpenAIModelObject(id=item, created=0, owned_by="cappuccino"))
            continue
        if not isinstance(item, dict):
            raise ValueError("Expected each model entry to be a JSON object.")
        model_id = item.get("id") or item.get("model") or item.get("name")
        if not isinstance(model_id, str) or not model_id.strip():
            raise ValueError("Expected each model entry to expose a non-empty id.")
        created = item.get("created")
        owned_by = item.get("owned_by")
        data.append(
            OpenAIModelObject(
                id=model_id,
                created=int(created) if isinstance(created, (int, float)) else 0,
                owned_by=owned_by if isinstance(owned_by, str) else "cappuccino",
            )
        )
    return OpenAIModelList(data=data)


def _find_model_in_list(model_list: OpenAIModelList, model_id: str) -> OpenAIModelObject | None:
    for model in model_list.data:
        if model.id == model_id:
            return model
        if Path(model.id).name == model_id:
            return model
    return None


def _public_model_objects(app: FastAPI) -> list[OpenAIModelObject]:
    default_model_path = getattr(app.state, "default_model_path", None)
    aliases = getattr(app.state, "model_aliases", {})
    if not isinstance(default_model_path, Path) or not isinstance(aliases, dict) or not aliases:
        return []
    created = int(default_model_path.stat().st_mtime) if default_model_path.exists() else 0
    public_model_id = getattr(app.state, "public_model_id", "cappuccino")
    return [
        OpenAIModelObject(
            id=public_model_id if isinstance(public_model_id, str) and public_model_id else "cappuccino",
            created=created,
            owned_by="cappuccino",
        )
    ]


def _resolve_local_model_object(model_id: str) -> OpenAIModelObject | None:
    candidate_path = Path(model_id).expanduser()
    if not candidate_path.exists():
        return None
    resolved = candidate_path.resolve()
    profile = inspect_model_dir(resolved)
    return OpenAIModelObject(
        id=model_id,
        created=int(resolved.stat().st_mtime),
        owned_by="cappuccino",
    )


async def _proxy_legacy_completions(request: Request, payload: dict[str, Any]) -> Response:
    _validate_legacy_completions_request(payload)
    translated_payload = _resolve_payload_model_aliases(
        _translate_legacy_completion_request(payload),
        request.app,
    )
    fallback_model = cast(str, payload["model"])
    if translated_payload.get("stream") is True:
        return await _stream_legacy_completions(
            request=request,
            payload=translated_payload,
            fallback_model=fallback_model,
        )
    chat_response = await _call_mlx_vlm_json("/v1/chat/completions", translated_payload)
    completion = _translate_chat_completion_response(chat_response, fallback_model=fallback_model)
    return JSONResponse(
        status_code=200,
        content=completion.model_dump(exclude_none=True),
        headers=_response_headers(request),
    )


def _validate_legacy_completions_request(payload: dict[str, Any]) -> None:
    model_value = payload.get("model")
    if not isinstance(model_value, str) or not model_value.strip():
        raise HTTPException(status_code=400, detail="The 'model' field is required.")

    prompt_value = payload.get("prompt", "")
    if isinstance(prompt_value, list):
        if len(prompt_value) != 1 or not isinstance(prompt_value[0], str):
            raise HTTPException(
                status_code=400,
                detail=(
                    "This runtime supports only a single string prompt on /v1/completions. "
                    "Use the Responses API for richer input types."
                ),
            )
    elif not isinstance(prompt_value, str):
        raise HTTPException(
            status_code=400,
            detail="The 'prompt' field must be a string for this /v1/completions compatibility layer.",
        )

    unsupported_parameters: tuple[tuple[str, bool], ...] = (
        ("suffix", payload.get("suffix") not in (None, "")),
        ("echo", payload.get("echo") is True),
        ("best_of", payload.get("best_of") not in (None, 1)),
        ("logprobs", payload.get("logprobs") not in (None, 0)),
    )
    for parameter, is_used in unsupported_parameters:
        if is_used:
            raise HTTPException(
                status_code=400,
                detail={
                    "message": (
                        f"The '{parameter}' parameter is not implemented on this "
                        "legacy /v1/completions compatibility layer. Use /v1/responses instead."
                    ),
                    "param": parameter,
                    "code": "unsupported_parameter",
                },
            )


def _translate_legacy_completion_request(payload: dict[str, Any]) -> dict[str, Any]:
    prompt_value = payload.get("prompt", "")
    prompt_text = prompt_value[0] if isinstance(prompt_value, list) else prompt_value
    translated: dict[str, Any] = {
        "model": payload["model"],
        "messages": [{"role": "user", "content": prompt_text}],
    }
    for field_name in (
        "temperature",
        "top_p",
        "n",
        "stop",
        "presence_penalty",
        "frequency_penalty",
        "seed",
        "stream",
        "user",
    ):
        if field_name in payload:
            translated[field_name] = payload[field_name]
    if "max_tokens" in payload:
        translated["max_tokens"] = payload["max_tokens"]
    translated = _inject_default_identity_developer_prompt(translated)
    translated["enable_thinking"] = False
    return translated


def _translate_chat_completion_response(
    body: dict[str, Any],
    *,
    fallback_model: str,
) -> OpenAICompletionObject:
    raw_choices = body.get("choices")
    choices: list[CompletionChoice] = []
    if isinstance(raw_choices, list):
        for index, raw_choice in enumerate(raw_choices):
            if not isinstance(raw_choice, dict):
                continue
            choices.append(
                CompletionChoice(
                    finish_reason=_normalize_completion_finish_reason(
                        raw_choice.get("finish_reason")
                    ),
                    index=_coerce_int(raw_choice.get("index"), index),
                    text=_extract_completion_text(raw_choice),
                    logprobs=None,
                )
            )
    usage = _translate_chat_usage(body.get("usage"))
    return OpenAICompletionObject(
        id=str(body.get("id") or f"cmpl_{uuid4().hex}"),
        choices=choices,
        created=_coerce_int(body.get("created"), int(time.time())),
        model=str(body.get("model") or fallback_model),
        system_fingerprint=body.get("system_fingerprint")
        if isinstance(body.get("system_fingerprint"), str)
        else None,
        usage=usage,
    )


def _translate_chat_usage(usage: Any) -> CompletionUsage | None:
    if not isinstance(usage, dict):
        return None
    prompt_tokens = usage.get("prompt_tokens")
    completion_tokens = usage.get("completion_tokens")
    total_tokens = usage.get("total_tokens")
    if not all(isinstance(value, int) for value in (prompt_tokens, completion_tokens, total_tokens)):
        return None
    return CompletionUsage(
        prompt_tokens=cast(int, prompt_tokens),
        completion_tokens=cast(int, completion_tokens),
        total_tokens=cast(int, total_tokens),
        prompt_tokens_details=usage.get("prompt_tokens_details")
        if isinstance(usage.get("prompt_tokens_details"), dict)
        else None,
        completion_tokens_details=usage.get("completion_tokens_details")
        if isinstance(usage.get("completion_tokens_details"), dict)
        else None,
    )


def _extract_completion_text(choice: dict[str, Any]) -> str:
    message = choice.get("message")
    if isinstance(message, dict):
        return _coerce_message_content_to_text(message.get("content"))
    text = choice.get("text")
    if isinstance(text, str):
        return text
    return ""


def _coerce_message_content_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for item in content:
        if isinstance(item, str):
            parts.append(item)
            continue
        if not isinstance(item, dict):
            continue
        text = item.get("text")
        if isinstance(text, str):
            parts.append(text)
    return "".join(parts)


async def _stream_legacy_completions(
    *,
    request: Request,
    payload: dict[str, Any],
    fallback_model: str,
) -> Response:
    normalized_payload = normalize_runtime_payload(payload)
    async with _mlx_vlm_client() as client:
        upstream_request = client.build_request("POST", "/v1/chat/completions", json=normalized_payload)
        upstream_response = await client.send(upstream_request, stream=True)
        if upstream_response.status_code >= 400:
            body = await upstream_response.aread()
            try:
                detail = json.loads(body.decode("utf-8"))
            except ValueError:
                detail = body.decode("utf-8", errors="replace")
            await upstream_response.aclose()
            return JSONResponse(
                status_code=upstream_response.status_code,
                content=_openai_error_payload(
                    detail=detail,
                    status_code=upstream_response.status_code,
                ),
                headers=_response_headers(request),
            )

        async def iterator() -> AsyncIterator[bytes]:
            try:
                async for line in upstream_response.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    event_body = line[5:].strip()
                    if event_body == "[DONE]":
                        yield b"data: [DONE]\n\n"
                        continue
                    try:
                        chunk = json.loads(event_body)
                    except ValueError:
                        continue
                    if not isinstance(chunk, dict):
                        continue
                    translated_chunk = _translate_chat_completion_chunk(
                        chunk,
                        fallback_model=fallback_model,
                    )
                    yield (
                        f"data: {json.dumps(translated_chunk, ensure_ascii=False)}\n\n".encode(
                            "utf-8"
                        )
                    )
            finally:
                await upstream_response.aclose()

        return StreamingResponse(
            iterator(),
            media_type="text/event-stream",
            headers={
                **_response_headers(request),
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )


def _translate_chat_completion_chunk(
    body: dict[str, Any],
    *,
    fallback_model: str,
) -> dict[str, Any]:
    raw_choices = body.get("choices")
    translated_choices: list[dict[str, Any]] = []
    if isinstance(raw_choices, list):
        for index, raw_choice in enumerate(raw_choices):
            if not isinstance(raw_choice, dict):
                continue
            delta = raw_choice.get("delta")
            delta_text = ""
            if isinstance(delta, dict):
                delta_text = _coerce_message_content_to_text(delta.get("content"))
            translated_choices.append(
                CompletionChoice(
                    finish_reason=_normalize_completion_finish_reason(
                        raw_choice.get("finish_reason")
                    ),
                    index=_coerce_int(raw_choice.get("index"), index),
                    logprobs=None,
                    text=delta_text,
                ).model_dump(exclude_none=True)
            )
    completion = OpenAICompletionObject(
        id=str(body.get("id") or f"cmpl_{uuid4().hex}"),
        choices=[
            CompletionChoice.model_validate(choice)
            for choice in translated_choices
        ],
        created=_coerce_int(body.get("created"), int(time.time())),
        model=str(body.get("model") or fallback_model),
        system_fingerprint=body.get("system_fingerprint")
        if isinstance(body.get("system_fingerprint"), str)
        else None,
        usage=_translate_chat_usage(body.get("usage")),
    )
    return completion.model_dump(exclude_none=True)


def _coerce_int(value: Any, default: int) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _normalize_completion_finish_reason(
    value: Any,
) -> Literal["stop", "length", "content_filter"]:
    if value in {"stop", "length", "content_filter"}:
        return cast(Literal["stop", "length", "content_filter"], value)
    return "stop"


@lru_cache(maxsize=1)
def _known_openai_resource_segments() -> frozenset[str]:
    return frozenset(known_openai_resource_segments())


def _is_reserved_local_path(path: str) -> bool:
    stripped = path.strip("/")
    return stripped in {
        "",
        "openapi.json",
        "docs",
        "docs/oauth2-redirect",
        "redoc",
    } or stripped == "healthz" or stripped.startswith("v1/cappuccino/") or stripped.startswith(
        "v1/tools/"
    ) or stripped.startswith(
        "v1/skills/"
    )


def _is_openai_api_candidate_path(path: str) -> bool:
    stripped = path.strip("/")
    if not stripped:
        return False
    if stripped.startswith("v1/"):
        stripped = stripped[3:]
    if not stripped:
        return False
    first_segment = stripped.split("/", 1)[0]
    return first_segment in _known_openai_resource_segments()


async def _proxy_passthrough_to_mlx_vlm(
    request: Request,
    upstream_path: str,
    *,
    app: FastAPI,
) -> Response:
    path = f"/{upstream_path.lstrip('/')}"
    if request.url.query:
        path = f"{path}?{request.url.query}"

    forwarded_headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() not in {"host", "content-length"}
    }
    body = await request.body()
    body = _rewrite_passthrough_request_body(body, request=request, app=app)
    parsed_payload, parse_error = _parse_json_request_body(body, request=request)
    if parse_error is not None:
        return JSONResponse(
            status_code=400,
            content=_openai_error_payload(
                detail={
                    "message": parse_error,
                    "code": "invalid_json",
                },
                status_code=400,
            ),
            headers=_response_headers(request),
        )

    async with _mlx_vlm_client() as client:
        upstream_request = client.build_request(
            request.method,
            path,
            headers=forwarded_headers,
            content=body or None,
        )
        stream_response = _should_proxy_as_stream(request, body)
        upstream_response = await client.send(upstream_request, stream=stream_response)

        if stream_response:
            if upstream_response.status_code >= 400:
                error_body = await upstream_response.aread()
                await upstream_response.aclose()
                try:
                    detail = json.loads(error_body.decode("utf-8"))
                except ValueError:
                    detail = error_body.decode("utf-8", errors="replace")
                return JSONResponse(
                    status_code=upstream_response.status_code,
                    content=_openai_error_payload(
                        detail=detail,
                        status_code=upstream_response.status_code,
                    ),
                    headers=_response_headers(request),
                )

            async def iterator() -> AsyncIterator[bytes]:
                try:
                    async for chunk in upstream_response.aiter_bytes():
                        yield chunk
                finally:
                    await upstream_response.aclose()

            return StreamingResponse(
                iterator(),
                status_code=upstream_response.status_code,
                media_type=upstream_response.headers.get("content-type", "text/event-stream"),
                headers=_response_headers(request),
            )

        content = await upstream_response.aread()
        content_type = upstream_response.headers.get("content-type")
        if content_type and "application/json" in content_type.lower():
            try:
                body_json = json.loads(content.decode("utf-8"))
            except ValueError:
                body_json = None
            if isinstance(body_json, dict):
                if upstream_response.status_code in {404, 405} and _is_openai_api_candidate_path(upstream_path):
                    return JSONResponse(
                        status_code=400,
                        content=_openai_error_payload(
                            detail=_build_unimplemented_endpoint_error(
                                path=f"/{upstream_path.lstrip('/')}",
                                payload=parsed_payload,
                                app=app,
                            ),
                            status_code=400,
                        ),
                        headers=_response_headers(request),
                    )
                if upstream_response.status_code >= 400:
                    return JSONResponse(
                        status_code=upstream_response.status_code,
                        content=_openai_error_payload(
                            detail=body_json,
                            status_code=upstream_response.status_code,
                        ),
                        headers=_response_headers(request),
                    )
                return JSONResponse(
                    status_code=upstream_response.status_code,
                    content=body_json,
                    headers=_response_headers(request),
                )
        if upstream_response.status_code in {404, 405} and _is_openai_api_candidate_path(upstream_path):
            return JSONResponse(
                status_code=400,
                content=_openai_error_payload(
                    detail=_build_unimplemented_endpoint_error(
                        path=f"/{upstream_path.lstrip('/')}",
                        payload=parsed_payload,
                        app=app,
                    ),
                    status_code=400,
                ),
                headers=_response_headers(request),
            )
        if upstream_response.status_code >= 400:
            return JSONResponse(
                status_code=upstream_response.status_code,
                content=_openai_error_payload(
                    detail=content.decode("utf-8", errors="replace"),
                    status_code=upstream_response.status_code,
                ),
                headers=_response_headers(request),
            )
        return Response(
            content=content,
            status_code=upstream_response.status_code,
            media_type=content_type,
            headers=_response_headers(request),
        )


def _should_proxy_as_stream(request: Request, body: bytes) -> bool:
    accept_header = request.headers.get("accept", "")
    if "text/event-stream" in accept_header:
        return True
    lowered_body = body.lower()
    return b'"stream":true' in lowered_body or b'"stream": true' in lowered_body


def _rewrite_passthrough_request_body(body: bytes, *, request: Request, app: FastAPI) -> bytes:
    content_type = request.headers.get("content-type", "")
    if "application/json" not in content_type.lower() or not body:
        return body
    try:
        payload = json.loads(body.decode("utf-8"))
    except ValueError:
        return body
    if not isinstance(payload, dict):
        return body
    rewritten_payload = _resolve_payload_model_aliases(payload, app)
    if rewritten_payload is payload:
        return body
    return json.dumps(rewritten_payload, ensure_ascii=False).encode("utf-8")


def _parse_json_request_body(
    body: bytes,
    *,
    request: Request,
) -> tuple[dict[str, Any] | None, str | None]:
    content_type = request.headers.get("content-type", "")
    if "application/json" not in content_type.lower():
        return None, None
    if not body:
        return None, None
    try:
        payload = json.loads(body.decode("utf-8"))
    except ValueError:
        return None, "Invalid JSON request body."
    if not isinstance(payload, dict):
        return None, "Expected the request body to be a JSON object."
    return payload, None


def _build_unimplemented_endpoint_error(
    *,
    path: str,
    payload: dict[str, Any] | None,
    app: FastAPI,
) -> dict[str, Any]:
    public_model_id = getattr(app.state, "public_model_id", "cappuccino")
    model_value = payload.get("model") if isinstance(payload, dict) else None
    display_model = _public_model_name_for_error(model_value, app, fallback=public_model_id)
    if display_model is not None:
        message = (
            f"The model '{display_model}' does not support the endpoint '{path}' on this local runtime yet."
        )
        return {
            "message": message,
            "code": "endpoint_not_supported",
            "param": "model",
        }
    return {
        "message": f"The endpoint '{path}' is not implemented on this local runtime yet.",
        "code": "endpoint_not_supported",
    }


def _public_model_name_for_error(
    model_value: Any,
    app: FastAPI,
    *,
    fallback: Any = None,
) -> str | None:
    public_model_id = getattr(app.state, "public_model_id", None)
    if isinstance(model_value, str):
        aliases = getattr(app.state, "model_aliases", {})
        if isinstance(public_model_id, str):
            if model_value == public_model_id:
                return public_model_id
            if isinstance(aliases, dict) and model_value in aliases:
                return public_model_id
            resolved = _resolve_model_alias(model_value, app)
            default_model_path = getattr(app.state, "default_model_path", None)
            if isinstance(resolved, str) and isinstance(default_model_path, Path):
                if Path(resolved) == default_model_path and public_model_id:
                    return public_model_id
        return model_value
    if isinstance(fallback, str):
        return fallback
    return None
