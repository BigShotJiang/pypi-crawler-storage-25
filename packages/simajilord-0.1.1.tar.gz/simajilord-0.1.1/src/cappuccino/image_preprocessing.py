from __future__ import annotations

import base64
import copy
import hashlib
from io import BytesIO
from pathlib import Path
from typing import Any

import httpx
from PIL import Image, ImageOps
from pydantic import BaseModel, Field


class ImageNormalizationPolicy(BaseModel):
    max_long_edge: int = Field(default=1536, ge=256)
    max_pixels: int = Field(default=1536 * 1536, ge=256 * 256)
    cache_dir: str


def normalize_payload_images(
    payload: dict[str, Any],
    policy: ImageNormalizationPolicy,
) -> dict[str, Any]:
    normalized = copy.deepcopy(payload)

    if isinstance(normalized.get("messages"), list):
        _normalize_messages(normalized["messages"], policy)

    if isinstance(normalized.get("input"), list):
        _normalize_messages(normalized["input"], policy)

    return normalized


def _normalize_messages(messages: list[dict[str, Any]], policy: ImageNormalizationPolicy) -> None:
    for message in messages:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for item in content:
            if not isinstance(item, dict):
                continue
            _normalize_image_item(item, policy)


def _normalize_image_item(item: dict[str, Any], policy: ImageNormalizationPolicy) -> None:
    item_type = item.get("type")
    if item_type == "input_image":
        source = item.get("image_url")
        if isinstance(source, str):
            item["image_url"] = normalize_image_source(source, policy)
    elif item_type == "image_url":
        image_url = item.get("image_url")
        if isinstance(image_url, dict) and isinstance(image_url.get("url"), str):
            image_url["url"] = normalize_image_source(image_url["url"], policy)


def normalize_image_source(source: str, policy: ImageNormalizationPolicy) -> str:
    image_bytes = _load_image_bytes(source)
    with Image.open(BytesIO(image_bytes)) as raw_image:
        image = ImageOps.exif_transpose(raw_image)
        width, height = image.size
        scale = _compute_safe_scale(width=width, height=height, policy=policy)
        if scale >= 1.0:
            return source

        new_width = max(1, int(width * scale))
        new_height = max(1, int(height * scale))
        resized = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        cache_dir = Path(policy.cache_dir).expanduser().resolve()
        cache_dir.mkdir(parents=True, exist_ok=True)

        has_alpha = _has_alpha_channel(resized)
        suffix = ".png" if has_alpha else ".jpg"
        digest = hashlib.sha256(
            image_bytes
            + f":{policy.max_long_edge}:{policy.max_pixels}".encode("utf-8")
        ).hexdigest()[:24]
        output_path = cache_dir / f"{digest}{suffix}"

        if not output_path.exists():
            if has_alpha:
                resized.save(output_path, format="PNG")
            else:
                resized.convert("RGB").save(output_path, format="JPEG", quality=92)
        return str(output_path)


def _compute_safe_scale(
    *,
    width: int,
    height: int,
    policy: ImageNormalizationPolicy,
) -> float:
    longest_edge = max(width, height)
    pixel_count = width * height

    edge_scale = min(1.0, policy.max_long_edge / float(longest_edge))
    pixel_scale = min(1.0, (policy.max_pixels / float(pixel_count)) ** 0.5)
    return float(min(edge_scale, pixel_scale))


def _load_image_bytes(source: str) -> bytes:
    if source.startswith("data:image/"):
        _, encoded = source.split(",", 1)
        return base64.b64decode(encoded)
    if source.startswith(("http://", "https://")):
        response = httpx.get(source, timeout=30.0)
        response.raise_for_status()
        return response.content
    return Path(source).expanduser().read_bytes()


def _has_alpha_channel(image: Image.Image) -> bool:
    if image.mode in ("RGBA", "LA"):
        return True
    return bool(image.info.get("transparency"))
