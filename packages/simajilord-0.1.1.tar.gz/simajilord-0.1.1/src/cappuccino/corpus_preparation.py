from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tarfile
import time
import unicodedata
import zipfile
from bisect import bisect_right
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Iterator, Literal, Sequence, cast
from urllib.parse import urljoin, urlparse
from xml.etree import ElementTree

import httpx
from pydantic import BaseModel, Field
from pypdf import PdfReader

from .dataset_manifests import SequentialCptSource, load_sequential_cpt_manifest, write_sequential_cpt_manifest
from .dataset_preparation import PreparedDatasetReport

DEFAULT_SHARD_RECORDS = 256
DESKTOP_INPUT_OUTPUT_DIR_BASENAME = "ファインチューニング"
PIXIV_NOVEL_MIN_BOOKMARKS = 70
PIXIV_ORIGINAL_NOVEL_BONUS_MIN_BOOKMARKS = 100
DEFAULT_HTTP_USER_AGENT = "cappuccino-corpus-preparation/1.0 (+https://github.com/openai/codex)"

AOZORA_LIST_URL = "https://www.aozora.gr.jp/index_pages/list_person_all_extended_utf8.zip"
AOZORA_IMPERIAL_CONSTITUTION_TITLE = "大日本帝国憲法"
KOTOBANK_SITEMAP_INDEX_URL = "https://kotobank.jp/sitemap-xml/sitemap_index.xml"
PIXIV_DICTIONARY_SITEMAP_INDEX_URL = "https://dic.pixiv.net/sitemap.xml"
PIXIV_NOVEL_RANKING_URL = "https://www.pixiv.net/novel/ranking.php"
PIXIV_NOVEL_DETAIL_API_URL = "https://www.pixiv.net/ajax/novel/{novel_id}"
PIXIV_USER_PROFILE_ALL_API_URL = "https://www.pixiv.net/ajax/user/{user_id}/profile/all"
WIKIPEDIA_API_URL_TEMPLATE = "https://{language}.wikipedia.org/w/api.php"
KOKKAI_MEETING_API_URL = "https://kokkai.ndl.go.jp/api/meeting"
OPENAI_DEVELOPERS_SITEMAP_INDEX_URL = "https://developers.openai.com/sitemap-index.xml"
GITHUB_SEARCH_API_URL = "https://api.github.com/search/repositories"
GITHUB_CODELOAD_TARBALL_URL = "https://codeload.github.com/{owner}/{repo}/tar.gz/refs/heads/{ref}"
KAKEN_SITEMAP_INDEX_URL = "https://kaken.nii.ac.jp/sitemaps/kakenhi/sitemapindex.xml"
NDL_NEXT_DIGITAL_LIBRARY_DATASET_PAGE_URL = "https://www.ndl.go.jp/jp/dlib/standards/opendataset/index.html#opendataset01"
NDL_NEXT_DIGITAL_LIBRARY_FULLTEXT_API_URL = "https://lab.ndl.go.jp/dl/api/book/fulltext-json/{pid}"
WIKIPEDIA_PARSE_API_URL_TEMPLATE = "https://{language}.wikipedia.org/w/api.php"
KOKKAI_DEFAULT_SESSION_FROM = 1
KOKKAI_DEFAULT_SESSION_TO = 999
KOKKAI_DEFAULT_REQUEST_INTERVAL_SEC = 2.0
KOKKAI_API_MODE = "meeting"
GITHUB_MIN_STARS = 10000
GITHUB_SEARCH_SEGMENT_MAX_RESULTS = 900
GITHUB_MAX_TEXT_FILE_BYTES = 512 * 1024
GITHUB_DEFAULT_REQUEST_INTERVAL_SEC = 2.0
KAKEN_DEFAULT_REQUEST_INTERVAL_SEC = 0.5
NDL_NEXT_DIGITAL_LIBRARY_DEFAULT_REQUEST_INTERVAL_SEC = 0.5
WIKIPEDIA_REFERENCE_DEFAULT_REQUEST_INTERVAL_SEC = 0.5
WIKIPEDIA_RECENT_CHANGES_INITIAL_LOOKBACK_HOURS = 72.0

OPENAI_DOCS_ALLOWED_PREFIXES = (
    "https://developers.openai.com/api/docs/",
    "https://developers.openai.com/api/reference/",
)
JAPANESE_LONG_RECORD_MAX_CHARS = 6000
OPENAI_DOC_SECTION_MAX_CHARS = 12000
WIKIPEDIA_IMAGE_THUMBNAIL_WIDTH = 1024
AOZORA_SEEN_WORK_IDS_FILENAME = "seen_work_ids.txt"
WIKIPEDIA_SEEN_PAGE_IDS_FILENAME = "seen_page_ids.txt"
WIKIPEDIA_SEEN_CHANGE_IDS_FILENAME = "seen_change_ids.txt"
WIKIPEDIA_SEEN_SOURCE_KEYS_FILENAME = "seen_source_keys.txt"
WIKIPEDIA_SEEN_REFERENCE_URL_KEYS_FILENAME = "seen_reference_url_keys.txt"
WIKIPEDIA_SEEN_REFERENCE_TEXT_HASHES_FILENAME = "seen_reference_text_hashes.txt"
KAKEN_SEEN_PROJECT_IDS_FILENAME = "seen_project_ids.txt"
NDL_NEXT_DIGITAL_LIBRARY_SEEN_PIDS_FILENAME = "seen_pids.txt"
OPENAI_REFERENCE_LANGUAGE_PREFIXES = {
    "go",
    "java",
    "python",
    "ruby",
    "typescript",
}
GITHUB_IGNORED_PATH_PARTS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "target",
    "__pycache__",
    ".next",
    ".nuxt",
    "coverage",
}
GITHUB_TEXT_FILE_EXTENSIONS = {
    ".c",
    ".cc",
    ".cfg",
    ".cpp",
    ".cs",
    ".css",
    ".go",
    ".h",
    ".hpp",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".json",
    ".jsx",
    ".kt",
    ".kts",
    ".lua",
    ".md",
    ".mdx",
    ".php",
    ".proto",
    ".ps1",
    ".py",
    ".rb",
    ".rs",
    ".rst",
    ".scala",
    ".scss",
    ".sh",
    ".sql",
    ".swift",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}
GITHUB_TEXT_FILENAMES = {
    "dockerfile",
    "license",
    "makefile",
    "readme",
}

AOZORA_FOOTER_MARKERS = (
    "\n底本：",
    "\n底本:",
    "\n入力：",
    "\n入力:",
    "\n校正：",
    "\n校正:",
    "\n公開：",
    "\n公開:",
    "\n修正：",
    "\n修正:",
)
AOZORA_OLD_TO_NEW_MAP = str.maketrans(
    {
        "萬": "万",
        "國": "国",
        "體": "体",
        "舊": "旧",
        "舎": "舎",
        "對": "対",
        "會": "会",
        "權": "権",
        "條": "条",
        "效": "効",
        "竝": "並",
        "學": "学",
        "總": "総",
        "與": "与",
        "將": "将",
        "爲": "為",
        "實": "実",
        "從": "従",
        "觸": "触",
        "卽": "即",
        "處": "処",
        "號": "号",
        "榮": "栄",
        "顯": "顕",
        "勅": "勅",
        "澤": "沢",
        "冨": "富",
        "廣": "広",
        "獨": "独",
        "隸": "隷",
        "聲": "声",
        "證": "証",
        "罷": "罷",
        "歸": "帰",
        "關": "関",
        "壓": "圧",
        "壞": "壊",
        "亞": "亜",
        "嚴": "厳",
        "圓": "円",
        "應": "応",
        "變": "変",
        "傳": "伝",
        "勞": "労",
        "勳": "勲",
        "兩": "両",
    }
)
IMPERIAL_CONSTITUTION_ARTICLE_PATTERN = re.compile(
    r"(?=第[一二三四五六七八九十百千万〇零\d]+条(?:ノ[一二三四五六七八九十百千万〇零\d]+)?)"
)
AOZORA_CHAPTER_PATTERN = re.compile(
    r"(?=第[一二三四五六七八九十百千万〇零\d]+(?:編|章|節|部))"
)
WIKIPEDIA_IMAGE_PROMPTS = {
    "ja": "このWikipedia記事の代表画像に対応する内容を説明してください。",
    "default": "Describe the corresponding Wikipedia article from this lead image.",
}
WIKIPEDIA_IMAGE_CAPTION_PROMPTS = {
    "ja": "このWikipedia記事の代表画像に付いている説明文を答えてください。",
    "default": "Answer with the caption attached to this Wikipedia lead image.",
}


class _TagStripper(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self._parts.append(data)

    def handle_entityref(self, name: str) -> None:
        self._parts.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self._parts.append(f"&#{name};")

    def text(self) -> str:
        return unescape("".join(self._parts))


class _WikipediaReferenceLinkExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._reference_depth = 0
        self._links: list[str] = []
        self._seen_links: set[str] = set()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = {name: value or "" for name, value in attrs}
        class_names = set(attributes.get("class", "").split())
        if tag in {"ol", "div"} and "references" in class_names:
            self._reference_depth += 1
        if self._reference_depth <= 0 or tag != "a":
            return
        href = attributes.get("href", "").strip()
        if not href:
            return
        normalized_href = urljoin("https://ja.wikipedia.org/", href)
        if normalized_href in self._seen_links:
            return
        self._seen_links.add(normalized_href)
        self._links.append(normalized_href)

    def handle_endtag(self, tag: str) -> None:
        if self._reference_depth > 0 and tag in {"ol", "div"}:
            self._reference_depth -= 1

    def links(self) -> list[str]:
        return list(self._links)


class _WikipediaLeadImageCaptionExtractor(HTMLParser):
    def __init__(self, *, target_image_name: str) -> None:
        super().__init__()
        self._target_image_name = target_image_name
        self._tag_stack: list[str] = []
        self._infobox_table_depth: int | None = None
        self._infobox_td_depth = 0
        self._matched_infobox_td_depth: int | None = None
        self._figure_depth = 0
        self._matched_figure_depth: int | None = None
        self._capture_figcaption_depth: int | None = None
        self._captured_parts: list[str] = []
        self.title: str | None = None
        self.caption: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = {name: value or "" for name, value in attrs}
        self._tag_stack.append(tag)
        current_depth = len(self._tag_stack)
        class_names = set(attributes.get("class", "").split())
        if tag == "table" and "infobox" in class_names and self._infobox_table_depth is None:
            self._infobox_table_depth = current_depth
        if tag == "td" and self._in_infobox():
            self._infobox_td_depth += 1
        if tag == "figure":
            self._figure_depth += 1
        if self._matches_target_image(tag=tag, attributes=attributes):
            self._remember_title_candidate(attributes)
            if self._in_infobox() and self._infobox_td_depth > 0 and self._matched_infobox_td_depth is None:
                self._matched_infobox_td_depth = self._infobox_td_depth
                self._captured_parts = []
            elif self._figure_depth > 0 and self._matched_figure_depth is None:
                self._matched_figure_depth = self._figure_depth
        if (
            tag == "figcaption"
            and self._matched_figure_depth is not None
            and self._figure_depth >= self._matched_figure_depth
        ):
            self._capture_figcaption_depth = current_depth
            self._captured_parts = []

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        current_depth = len(self._tag_stack)
        if tag == "figcaption" and self._capture_figcaption_depth == current_depth:
            self._maybe_finalize_caption()
            self._capture_figcaption_depth = None
        if tag == "td" and self._matched_infobox_td_depth == self._infobox_td_depth:
            self._maybe_finalize_caption()
            self._matched_infobox_td_depth = None
        if tag == "td" and self._in_infobox() and self._infobox_td_depth > 0:
            self._infobox_td_depth -= 1
        if tag == "figure" and self._matched_figure_depth == self._figure_depth:
            self._matched_figure_depth = None
        if tag == "figure" and self._figure_depth > 0:
            self._figure_depth -= 1
        if tag == "table" and self._infobox_table_depth == current_depth:
            self._infobox_table_depth = None
        if self._tag_stack:
            self._tag_stack.pop()

    def handle_data(self, data: str) -> None:
        if self._capture_figcaption_depth is not None:
            self._captured_parts.append(data)
            return
        if (
            self._matched_infobox_td_depth is not None
            and self._infobox_td_depth == self._matched_infobox_td_depth
        ):
            self._captured_parts.append(data)

    def handle_entityref(self, name: str) -> None:
        self.handle_data(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self.handle_data(f"&#{name};")

    def _in_infobox(self) -> bool:
        return (
            self._infobox_table_depth is not None
            and len(self._tag_stack) >= self._infobox_table_depth
        )

    def _matches_target_image(
        self,
        *,
        tag: str,
        attributes: dict[str, str],
    ) -> bool:
        if tag not in {"a", "img"}:
            return False
        candidate_names = [
            _normalize_wikipedia_image_name(attributes.get("href", "")),
            _normalize_wikipedia_image_name(attributes.get("src", "")),
            _normalize_wikipedia_image_name(attributes.get("srcset", "")),
        ]
        return any(candidate_name == self._target_image_name for candidate_name in candidate_names)

    def _remember_title_candidate(self, attributes: dict[str, str]) -> None:
        for raw_value in (attributes.get("alt", ""), attributes.get("title", "")):
            candidate = _normalize_space(unescape(raw_value))
            if candidate:
                self.title = candidate
                return

    def _maybe_finalize_caption(self) -> None:
        if self.caption is not None:
            self._captured_parts = []
            return
        candidate = _normalize_space(unescape("".join(self._captured_parts)))
        if candidate:
            self.caption = candidate
        self._captured_parts = []


@dataclass(slots=True)
class _ShardInfo:
    path: Path
    records: int


@dataclass(frozen=True, slots=True)
class NdlNextDigitalLibraryCatalogEntry:
    pid: str
    title: str
    volume: str
    responsibility: str
    publisher: str
    published: str
    size: str
    subjects: str
    ndc: str
    collection: str
    catalog_source_url: str


@dataclass(frozen=True, slots=True)
class WikipediaReferenceDocument:
    url: str
    final_url: str
    title: str
    text: str
    content_type: str
    source_format: Literal["html", "pdf", "text"]


@dataclass(frozen=True, slots=True)
class WikipediaLeadImageSupervision:
    title: str | None
    caption: str | None
    supervision_text: str
    supervision_kind: Literal["caption", "title"]


class GitHubRateLimitError(RuntimeError):
    pass


class PreparedDatasetStatusReport(BaseModel):
    kind: str
    output_dir: str
    state_path: str | None = None
    base_manifest_path: str | None = None
    manifest_path: str | None = None
    shard_roots: list[str] = Field(default_factory=list)
    shard_count: int = 0
    total_records: int = 0
    storage_bytes: int = 0
    completed: bool | None = None
    processed_items: int | None = None
    total_items: int | None = None
    remaining_items: int | None = None
    progress: str | None = None
    progress_percent: float | None = None
    rate_per_min: float | None = None
    eta: str | None = None
    eta_seconds: int | None = None
    last_updated_at: str | None = None
    cursor: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class JsonlShardWriter:
    def __init__(
        self,
        *,
        output_dir: str | Path,
        prefix: str,
        records_per_shard: int = DEFAULT_SHARD_RECORDS,
    ) -> None:
        self._output_dir = Path(output_dir).expanduser().resolve()
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._prefix = prefix
        self._records_per_shard = max(1, records_per_shard)
        self._handle: io.TextIOWrapper | None = None
        self._current_path: Path | None = None
        self._records_in_current_shard = 0
        existing = sorted(self._output_dir.glob(f"{self._prefix}_*.jsonl"))
        self._next_index = len(existing) + 1
        self._written_paths: list[Path] = []

    def write(self, record: dict[str, Any]) -> None:
        if self._handle is None or self._records_in_current_shard >= self._records_per_shard:
            self._open_next_shard()
        assert self._handle is not None
        self._handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._records_in_current_shard += 1

    def close(self) -> list[str]:
        if self._handle is not None:
            self._handle.close()
            self._handle = None
        return [str(path) for path in self.shard_paths()]

    def shard_paths(self) -> list[Path]:
        all_paths = sorted(self._output_dir.glob(f"{self._prefix}_*.jsonl"))
        return all_paths

    def _open_next_shard(self) -> None:
        if self._handle is not None:
            self._handle.close()
        path = self._output_dir / f"{self._prefix}_{self._next_index:05d}.jsonl"
        self._current_path = path
        self._handle = path.open("w", encoding="utf-8")
        self._records_in_current_shard = 0
        self._written_paths.append(path)
        self._next_index += 1


def prepare_input_output_txt_sft(
    *,
    input_dir: str | Path,
    output_dir: str | Path,
    copy_source: bool = True,
    repeat: int = 2,
) -> PreparedDatasetReport:
    source_dir = Path(input_dir).expanduser().resolve()
    if not source_dir.is_dir():
        raise ValueError(f"Input directory not found: {source_dir}")
    output_dir_path = Path(output_dir).expanduser().resolve()
    output_dir_path.mkdir(parents=True, exist_ok=True)
    copied_source_dir = output_dir_path / "source_txt"
    if copy_source:
        copied_source_dir.mkdir(parents=True, exist_ok=True)

    source_paths = sorted(path for path in source_dir.glob("*.txt") if path.is_file())
    if not source_paths:
        raise ValueError(f"No .txt files were found in {source_dir}")

    records: list[dict[str, Any]] = []
    copied_sources: list[str] = []
    valid_source_paths: list[str] = []
    warnings: list[str] = []
    for source_path in source_paths:
        try:
            prompt, completion = _parse_input_output_txt(source_path.read_text(encoding="utf-8"))
        except ValueError as exc:
            warnings.append(f"Skipped {source_path.name}: {exc}")
            continue
        valid_source_paths.append(str(source_path))
        if copy_source:
            copied_path = copied_source_dir / source_path.name
            shutil.copy2(source_path, copied_path)
            copied_sources.append(str(copied_path))
        records.append(
            {
                "task_type": "chat_sft",
                "messages": [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": completion},
                ],
                "focus": ["style"],
                "metadata": {
                    "source_label": "desktop_input_output_txt",
                    "source_file": str(source_path),
                },
            }
        )
    if not records:
        raise ValueError(f"No valid input/output .txt files were found in {source_dir}")

    dataset_path = output_dir_path / "desktop_input_output_sft.jsonl"
    dataset_path.write_text(
        "".join(json.dumps(record, ensure_ascii=False) + "\n" for record in records),
        encoding="utf-8",
    )
    manifest_path = output_dir_path / "desktop_input_output_manifest.json"
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(dataset_path),
                repeat=max(1, repeat),
                label="desktop_input_output_sft",
            )
        ],
    )
    output_paths = {
        "sft": str(dataset_path),
        "manifest": str(manifest_path),
    }
    if copy_source:
        output_paths["copied_source_dir"] = str(copied_source_dir)
    return PreparedDatasetReport(
        kind="input_output_txt_sft",
        source_paths=valid_source_paths,
        output_paths=output_paths,
        total_records=len(records),
        warnings=warnings,
    )


def build_wrapped_training_manifest(
    *,
    dataset_path: str | Path,
    output_path: str | Path,
    extra_sources: Sequence[SequentialCptSource],
) -> Path:
    normalized_dataset_path = Path(dataset_path).expanduser().resolve()
    manifest = load_sequential_cpt_manifest(normalized_dataset_path)
    merged_sources: list[SequentialCptSource] = []
    if manifest is None:
        merged_sources.append(SequentialCptSource(path=str(normalized_dataset_path), repeat=1))
    else:
        merged_sources.extend(manifest.datasets)
    merged_sources.extend(extra_sources)
    write_sequential_cpt_manifest(output_path, datasets=merged_sources)
    return Path(output_path).expanduser().resolve()


def build_training_manifest(
    *,
    output_path: str | Path,
    datasets: Sequence[SequentialCptSource],
) -> Path:
    write_sequential_cpt_manifest(output_path, datasets=list(datasets))
    return Path(output_path).expanduser().resolve()


def parse_manifest_dataset_specs(specs: Sequence[str]) -> list[SequentialCptSource]:
    parsed: list[SequentialCptSource] = []
    for spec in specs:
        parts = spec.split("::")
        if len(parts) == 1:
            path = parts[0]
            repeat = 1
            label = None
        elif len(parts) == 2:
            path, repeat_text = parts
            repeat = int(repeat_text)
            label = None
        elif len(parts) == 3:
            path, repeat_text, label = parts
            repeat = int(repeat_text)
        else:
            raise ValueError(f"Invalid dataset manifest spec: {spec}")
        parsed.append(
            SequentialCptSource(
                path=str(Path(path).expanduser().resolve()),
                repeat=max(1, repeat),
                label=label,
            )
        )
    return parsed


def locate_default_desktop_input_output_dir() -> Path | None:
    desktop_dir = Path.home() / "Desktop"
    if not desktop_dir.is_dir():
        return None
    target = unicodedata.normalize("NFC", DESKTOP_INPUT_OUTPUT_DIR_BASENAME)
    for child in desktop_dir.iterdir():
        if not child.is_dir():
            continue
        if unicodedata.normalize("NFC", child.name) == target:
            return child.resolve()
    return None


def _parse_input_output_txt(text: str) -> tuple[str, str]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = normalized.splitlines()
    try:
        input_index = next(index for index, line in enumerate(lines) if line.strip().lower() == "input")
        output_index = next(index for index, line in enumerate(lines) if line.strip().lower() == "output")
    except StopIteration as exc:
        raise ValueError("input/output markers were not found in txt training file.") from exc
    if output_index <= input_index:
        raise ValueError("output marker must appear after input marker.")
    prompt = "\n".join(lines[input_index + 1 : output_index]).strip()
    completion = "\n".join(lines[output_index + 1 :]).strip()
    if not prompt or not completion:
        raise ValueError("input/output txt files must contain non-empty prompt and completion text.")
    return prompt, completion


def _http_get_text(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout_sec: float = 60.0,
) -> str:
    with httpx.Client(
        follow_redirects=True,
        timeout=timeout_sec,
        headers=_build_http_headers(headers),
    ) as client:
        response = client.get(url)
        response.raise_for_status()
        return response.text


def _http_get_bytes(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    timeout_sec: float = 60.0,
) -> bytes:
    with httpx.Client(
        follow_redirects=True,
        timeout=timeout_sec,
        headers=_build_http_headers(headers),
    ) as client:
        response = client.get(url)
        response.raise_for_status()
        return response.content


def _strip_html_preserving_breaks(html: str) -> str:
    text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    text = re.sub(r"</p\s*>", "\n\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</h[1-6]\s*>", "\n\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(?:article|section|div)\s*>", "\n\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</li\s*>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<rt\b.*?</rt>", "", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"</?(?:ruby|rb|rp)\b[^>]*>", "", text, flags=re.IGNORECASE)
    stripper = _TagStripper()
    stripper.feed(text)
    return _normalize_space(stripper.text())


def _normalize_space(text: str) -> str:
    normalized = text.replace("\u3000", " ")
    normalized = normalized.replace("\r\n", "\n").replace("\r", "\n")
    normalized = re.sub(r"[ \t]+\n", "\n", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    normalized = re.sub(r"[ \t]{2,}", " ", normalized)
    return normalized.strip()


def _build_http_headers(headers: dict[str, str] | None = None) -> dict[str, str]:
    merged_headers = {"User-Agent": DEFAULT_HTTP_USER_AGENT}
    if headers:
        merged_headers.update(headers)
    return merged_headers


def _emit_prepare_progress(stage: str, event: str, **fields: Any) -> None:
    parts = [f"[{stage}]", event]
    for key, value in fields.items():
        if value is None:
            continue
        if isinstance(value, str):
            if not value.strip():
                continue
            rendered = json.dumps(value, ensure_ascii=False)
        else:
            rendered = str(value)
        parts.append(f"{key}={rendered}")
    print(" ".join(parts), file=sys.stderr, flush=True)


def _should_emit_progress(processed: int, *, every: int) -> bool:
    return processed <= 3 or (every > 0 and processed % every == 0)


def _format_progress_fraction(current: int, total: int | None) -> str | None:
    if total is None or total <= 0:
        return None
    return f"{current}/{total}"


def _format_duration(seconds: float) -> str:
    total_seconds = max(int(seconds), 0)
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _progress_timing_metrics(
    *,
    started_at: float,
    completed_this_run: int,
    current_absolute: int | None = None,
    total: int | None = None,
) -> dict[str, float | int]:
    elapsed_seconds = max(time.perf_counter() - started_at, 0.0)
    metrics: dict[str, float | int] = {
        "elapsed_seconds": round(elapsed_seconds, 3),
    }
    if completed_this_run <= 0 or elapsed_seconds <= 0:
        return metrics
    rate_per_min = completed_this_run / elapsed_seconds * 60.0
    metrics["rate_per_min"] = round(rate_per_min, 2)
    if total is not None and current_absolute is not None and total > current_absolute:
        remaining = total - current_absolute
        eta_seconds = remaining / max(completed_this_run / elapsed_seconds, 1e-9)
        metrics["eta_seconds"] = max(int(eta_seconds), 0)
    return metrics


def _progress_timing_fields(
    *,
    started_at: float,
    completed_this_run: int,
    current_absolute: int | None = None,
    total: int | None = None,
) -> dict[str, Any]:
    metrics = _progress_timing_metrics(
        started_at=started_at,
        completed_this_run=completed_this_run,
        current_absolute=current_absolute,
        total=total,
    )
    elapsed_seconds = float(metrics.get("elapsed_seconds", 0.0))
    fields: dict[str, Any] = {"elapsed": _format_duration(elapsed_seconds)}
    if "rate_per_min" not in metrics:
        return fields
    fields["rate_per_min"] = metrics["rate_per_min"]
    eta_seconds = metrics.get("eta_seconds")
    if isinstance(eta_seconds, int):
        fields["eta"] = _format_duration(eta_seconds)
    return fields


def _split_text_into_blocks(
    text: str,
    *,
    heading_pattern: re.Pattern[str] | None = None,
) -> list[str]:
    normalized = _normalize_space(text)
    if not normalized:
        return []
    if heading_pattern is not None:
        blocks = [block.strip() for block in heading_pattern.split(normalized) if block.strip()]
        if blocks:
            return blocks
    return [
        block.strip()
        for block in re.split(r"\n\s*\n", normalized)
        if block.strip()
    ] or [normalized]


def _prefix_header(header: str | None, body: str) -> str:
    normalized_body = _normalize_space(body)
    normalized_header = _normalize_space(header or "")
    if not normalized_header:
        return normalized_body
    return _normalize_space(f"{normalized_header}\n\n{normalized_body}")


def _group_text_blocks_into_sections(
    *,
    header: str | None,
    blocks: Sequence[str],
    max_chars: int,
) -> list[str]:
    sections: list[str] = []
    current_blocks: list[str] = []
    for block in blocks:
        normalized_block = _normalize_space(block)
        if not normalized_block:
            continue
        candidate_body = "\n\n".join([*current_blocks, normalized_block])
        candidate = _prefix_header(header, candidate_body)
        if current_blocks and len(candidate) > max_chars:
            sections.append(_prefix_header(header, "\n\n".join(current_blocks)))
            current_blocks = [normalized_block]
            continue
        if len(candidate) > max_chars:
            available_chars = max_chars - len(_normalize_space(header or "")) - 2
            split_blocks = _split_text_by_natural_blocks(
                normalized_block,
                max_chars=max(available_chars, max_chars // 2),
            )
            sections.extend(_prefix_header(header, part) for part in split_blocks)
            current_blocks = []
            continue
        current_blocks.append(normalized_block)
    if current_blocks:
        sections.append(_prefix_header(header, "\n\n".join(current_blocks)))
    return [_normalize_space(section) for section in sections if section.strip()]


def _build_chunked_cpt_records(
    *,
    title: str,
    body: str,
    focus: list[str],
    metadata: dict[str, Any],
    max_chars: int | None = None,
    heading_pattern: re.Pattern[str] | None = None,
    section_key: str = "part_index",
) -> list[dict[str, Any]]:
    resolved_max_chars = max_chars if max_chars is not None else JAPANESE_LONG_RECORD_MAX_CHARS
    blocks = _split_text_into_blocks(body, heading_pattern=heading_pattern)
    sections = _group_text_blocks_into_sections(
        header=title,
        blocks=blocks,
        max_chars=resolved_max_chars,
    )
    if not sections:
        return []
    records: list[dict[str, Any]] = []
    for section_index, section_text in enumerate(sections, start=1):
        section_metadata = dict(metadata)
        if len(sections) > 1:
            section_metadata[section_key] = section_index
            section_metadata["part_count"] = len(sections)
        records.append(
            {
                "task_type": "cpt",
                "text": section_text,
                "focus": focus,
                "metadata": section_metadata,
            }
        )
    return records


def _build_sectioned_cpt_records(
    *,
    title: str,
    blocks: Sequence[str],
    focus: list[str],
    metadata: dict[str, Any],
    max_chars: int | None = None,
    section_key: str = "part_index",
) -> list[dict[str, Any]]:
    resolved_max_chars = max_chars if max_chars is not None else JAPANESE_LONG_RECORD_MAX_CHARS
    sections = _group_text_blocks_into_sections(
        header=title,
        blocks=[_normalize_space(block) for block in blocks if _normalize_space(block)],
        max_chars=resolved_max_chars,
    )
    if not sections:
        return []
    records: list[dict[str, Any]] = []
    for section_index, section_text in enumerate(sections, start=1):
        section_metadata = dict(metadata)
        if len(sections) > 1:
            section_metadata[section_key] = section_index
            section_metadata["part_count"] = len(sections)
        records.append(
            {
                "task_type": "cpt",
                "text": section_text,
                "focus": focus,
                "metadata": section_metadata,
            }
        )
    return records


def _read_state(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def _write_state(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _utc_now_isoformat() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _utc_hours_ago_isoformat(hours: float) -> str:
    offset = max(float(hours), 0.0)
    return (datetime.now(UTC) - timedelta(hours=offset)).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _read_optional_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if stripped and re.fullmatch(r"-?\d+", stripped):
            return int(stripped)
    return None


def _read_optional_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            try:
                return float(stripped)
            except ValueError:
                return None
    return None


def _write_seen_ids(path: Path, values: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = sorted(value for value in values if value.strip())
    path.write_text("".join(line + "\n" for line in lines), encoding="utf-8")


def _bootstrap_seen_ids_from_shards(
    *,
    shard_paths: Sequence[Path],
    seen_ids_path: Path,
    metadata_key: str,
) -> set[str]:
    seen_ids = _load_seen_ids(seen_ids_path)
    if not shard_paths:
        return seen_ids
    latest_shard_mtime = max(path.stat().st_mtime for path in shard_paths)
    seen_ids_mtime = seen_ids_path.stat().st_mtime if seen_ids_path.exists() else 0.0
    if seen_ids and seen_ids_mtime >= latest_shard_mtime:
        return seen_ids
    recovered_ids: set[str] = set()
    for shard_path in shard_paths:
        for line in shard_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                payload = cast(dict[str, Any], json.loads(line))
            except json.JSONDecodeError:
                continue
            metadata = payload.get("metadata")
            if not isinstance(metadata, dict):
                continue
            raw_value = metadata.get(metadata_key)
            if raw_value is None:
                continue
            value = str(raw_value).strip()
            if value:
                recovered_ids.add(value)
    recovered_ids.update(seen_ids)
    if recovered_ids:
        _write_seen_ids(seen_ids_path, recovered_ids)
    return recovered_ids


def _normalize_wikipedia_continuation(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    continuation = {str(key): item for key, item in value.items()}
    if not continuation:
        return {}
    if "continue" not in continuation or "gapcontinue" not in continuation:
        return {}
    return continuation


def _normalize_wikipedia_recent_changes_continuation(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    continuation = {str(key): item for key, item in value.items()}
    if not continuation:
        return {}
    if "continue" not in continuation or "rccontinue" not in continuation:
        return {}
    return continuation


def _write_progress_snapshot(
    path: Path,
    *,
    state: dict[str, Any],
    dataset_kind: str,
    progress_unit: str,
    processed_items: int | None = None,
    total_items: int | None = None,
    completed: bool | None = None,
    started_at: float | None = None,
    completed_this_run: int | None = None,
    current_absolute: int | None = None,
    total_for_timing: int | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    snapshot = dict(state)
    snapshot["dataset_kind"] = dataset_kind
    snapshot["progress_unit"] = progress_unit
    if processed_items is not None:
        snapshot["processed_items"] = processed_items
    if total_items is not None:
        snapshot["total_items"] = total_items
    if completed is not None:
        snapshot["completed"] = completed
    if started_at is not None and completed_this_run is not None:
        timing_metrics = _progress_timing_metrics(
            started_at=started_at,
            completed_this_run=completed_this_run,
            current_absolute=current_absolute,
            total=total_for_timing,
        )
        snapshot.update(timing_metrics)
    snapshot["last_updated_at"] = _utc_now_isoformat()
    if extra:
        for key, value in extra.items():
            if value is not None:
                snapshot[key] = value
    _write_state(path, snapshot)
    return snapshot


def _count_matching_files(root: Path, pattern: str) -> int:
    return sum(1 for _ in root.rglob(pattern))


def _directory_storage_bytes(root: Path) -> int:
    if not root.exists():
        return 0
    total_bytes = 0
    for path in root.rglob("*"):
        if path.is_file():
            total_bytes += path.stat().st_size
    return total_bytes


def _existing_dataset_kind(output_dir: Path) -> str:
    manifest_names = {
        "wikipedia_train_manifest.json": "wikipedia_cpt",
        "wikipedia_recent_changes_train_manifest.json": "wikipedia_recent_changes_cpt",
        "wikipedia_cited_sources_train_manifest.json": "wikipedia_cited_sources_cpt",
        "aozora_bunko_train_manifest.json": "aozora_bunko",
        "openai_docs_train_manifest.json": "openai_docs_cpt",
        "kaken_train_manifest.json": "kaken_cpt",
        "ndl_next_digital_library_train_manifest.json": "ndl_next_digital_library_cpt",
        "pixiv_dictionary_train_manifest.json": "pixiv_dictionary_cpt",
        "pixiv_novels_train_manifest.json": "pixiv_novels_cpt",
        "kotobank_train_manifest.json": "kotobank_cpt",
        "kokkai_train_manifest.json": "kokkai_cpt",
        "github_repositories_train_manifest.json": "github_repositories_cpt",
    }
    for manifest_name, kind in manifest_names.items():
        if (output_dir / manifest_name).exists():
            return kind
    return output_dir.name


def inspect_prepared_dataset_status(*, output_dir: str | Path) -> PreparedDatasetStatusReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    if not output_dir_path.exists():
        raise ValueError(f"Dataset output directory not found: {output_dir_path}")
    state_path = output_dir_path / "progress.json"
    state = _read_state(state_path)
    kind = str(state.get("dataset_kind") or _existing_dataset_kind(output_dir_path))
    shard_roots = [
        path
        for path in (
            output_dir_path / "shards",
            output_dir_path / "bonus_shards",
            output_dir_path / "dictionary_shards",
        )
        if path.exists()
    ]
    total_records = sum(_count_jsonl_records(path) for root in shard_roots for path in root.rglob("*.jsonl"))
    shard_count = sum(_count_matching_files(root, "*.jsonl") for root in shard_roots)
    processed_items = _read_optional_int(state.get("processed_items"))
    total_items = _read_optional_int(state.get("total_items"))
    warnings: list[str] = []

    if kind == "wikipedia_cpt":
        seen_page_ids = _bootstrap_seen_ids_from_shards(
            shard_paths=sorted((output_dir_path / "shards").glob("wikipedia_*.jsonl")),
            seen_ids_path=output_dir_path / WIKIPEDIA_SEEN_PAGE_IDS_FILENAME,
            metadata_key="pageid",
        )
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids))
        total_items = total_items or _read_optional_int(state.get("approximate_total_articles"))
        if total_items is None:
            warnings.append("Wikipedia の総記事数見積りが state にないため、残り件数は概算を表示できません。")
    elif kind == "wikipedia_recent_changes_cpt":
        seen_change_ids = _load_seen_ids(output_dir_path / WIKIPEDIA_SEEN_CHANGE_IDS_FILENAME)
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids))
        warnings.append("Wikipedia recent changes はストリーム型のため、総件数の完了率は表示できません。")
    elif kind == "wikipedia_cited_sources_cpt":
        seen_source_keys = _load_seen_ids(output_dir_path / WIKIPEDIA_SEEN_SOURCE_KEYS_FILENAME)
        processed_items = max(
            processed_items or 0,
            _read_optional_int(state.get("processed_source_pages")) or 0,
            len(seen_source_keys),
        )
        failed_reference_urls = _read_optional_int(state.get("failed_reference_urls")) or 0
        if failed_reference_urls > 0:
            warnings.append(
                f"Wikipedia 参照クロールでテキスト化できなかった URL が {failed_reference_urls} 件あります。"
            )
        skipped_duplicate_references = _read_optional_int(state.get("skipped_duplicate_references")) or 0
        if skipped_duplicate_references > 0:
            warnings.append(
                f"Wikipedia 参照クロールで重複排除された URL/本文が {skipped_duplicate_references} 件あります。"
            )
    elif kind == "aozora_bunko":
        seen_work_ids = _bootstrap_seen_ids_from_shards(
            shard_paths=sorted((output_dir_path / "shards").glob("aozora_bunko_*.jsonl")),
            seen_ids_path=output_dir_path / AOZORA_SEEN_WORK_IDS_FILENAME,
            metadata_key="work_id",
        )
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_works")) or 0, len(seen_work_ids))
        total_items = total_items or _read_optional_int(state.get("total_works"))
        if total_items is None and state.get("completed") and processed_items is not None:
            total_items = processed_items
    elif kind == "openai_docs_cpt":
        processed_items = max(processed_items or 0, _read_optional_int(state.get("next_url_index")) or 0)
        total_items = total_items or _read_optional_int(state.get("total_urls"))
    elif kind == "kaken_cpt":
        seen_project_ids = _bootstrap_seen_ids_from_shards(
            shard_paths=sorted((output_dir_path / "shards").glob("kaken_*.jsonl")),
            seen_ids_path=output_dir_path / KAKEN_SEEN_PROJECT_IDS_FILENAME,
            metadata_key="project_id",
        )
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids))
        total_items = total_items or _read_optional_int(state.get("total_project_urls"))
        pending_project_urls = cast(list[str], state.get("pending_project_urls", []))
        if pending_project_urls:
            warnings.append(f"KAKEN の再試行待ちプロジェクトが {len(pending_project_urls)} 件あります。")
    elif kind == "ndl_next_digital_library_cpt":
        seen_pids = _bootstrap_seen_ids_from_shards(
            shard_paths=sorted((output_dir_path / "shards").glob("ndl_next_digital_library_*.jsonl")),
            seen_ids_path=output_dir_path / NDL_NEXT_DIGITAL_LIBRARY_SEEN_PIDS_FILENAME,
            metadata_key="pid",
        )
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_pids")) or 0, len(seen_pids))
        total_items = total_items or _read_optional_int(state.get("total_pids"))
        pending_retry_pids = cast(list[str], state.get("pending_retry_pids", []))
        if pending_retry_pids:
            warnings.append(
                "次世代デジタルライブラリーの再試行待ち PID が "
                f"{len(pending_retry_pids)} 件あります。"
            )
    elif kind == "kokkai_cpt":
        processed_items = processed_items or _read_optional_int(state.get("next_start_record"))
        total_items = total_items or _read_optional_int(state.get("total_records"))
    elif kind in {"pixiv_dictionary_cpt", "kotobank_cpt"}:
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_articles")) or 0)
        total_items = total_items or _read_optional_int(state.get("total_urls"))
    elif kind == "github_repositories_cpt":
        processed_items = max(processed_items or 0, _read_optional_int(state.get("processed_repo_count")) or 0)
    elif kind == "pixiv_novels_cpt":
        processed_items = max(
            processed_items or 0,
            _read_optional_int(state.get("processed_novels")) or 0,
            len(_load_seen_ids(output_dir_path / "seen_novel_ids.txt")),
        )

    remaining_items: int | None = None
    progress: str | None = None
    progress_percent: float | None = None
    if processed_items is not None and total_items is not None and total_items > 0:
        remaining_items = max(total_items - processed_items, 0)
        progress = _format_progress_fraction(processed_items, total_items)
        progress_percent = round(processed_items / total_items * 100.0, 2)
    rate_per_min = _read_optional_float(state.get("rate_per_min"))
    eta_seconds = _read_optional_int(state.get("eta_seconds"))
    if eta_seconds is None and remaining_items is not None and rate_per_min and rate_per_min > 0:
        eta_seconds = int(remaining_items / (rate_per_min / 60.0))
    cursor = {
        key: value
        for key, value in {
            "continue": state.get("continue"),
            "next_work_index": state.get("next_work_index"),
            "next_url_index": state.get("next_url_index"),
            "next_project_index": state.get("next_project_index"),
            "next_pid_index": state.get("next_pid_index"),
            "next_start_record": state.get("next_start_record"),
            "recentchanges_start": state.get("recentchanges_start"),
            "recentchanges_high_watermark": state.get("recentchanges_high_watermark"),
            "next_source_shard_index": state.get("next_source_shard_index"),
            "next_source_line_index": state.get("next_source_line_index"),
            "sitemap_index": state.get("sitemap_index"),
            "url_index": state.get("url_index"),
            "pending_user_ids": state.get("pending_user_ids"),
            "ranking_tasks": state.get("ranking_tasks"),
        }.items()
        if value not in (None, [], {})
    }

    manifest_candidates = {
        "manifest_path": next(
            (
                str(path)
                for path in (
                    output_dir_path / "wikipedia_train_manifest.json",
                    output_dir_path / "wikipedia_recent_changes_train_manifest.json",
                    output_dir_path / "wikipedia_cited_sources_train_manifest.json",
                    output_dir_path / "aozora_bunko_train_manifest.json",
                    output_dir_path / "openai_docs_train_manifest.json",
                    output_dir_path / "kaken_train_manifest.json",
                    output_dir_path / "ndl_next_digital_library_train_manifest.json",
                    output_dir_path / "pixiv_dictionary_train_manifest.json",
                    output_dir_path / "pixiv_novels_train_manifest.json",
                    output_dir_path / "kotobank_train_manifest.json",
                    output_dir_path / "kokkai_train_manifest.json",
                    output_dir_path / "github_repositories_train_manifest.json",
                )
                if path.exists()
            ),
            None,
        ),
        "base_manifest_path": next(
            (
                str(path)
                for path in (
                    output_dir_path / "wikipedia_manifest.json",
                    output_dir_path / "wikipedia_recent_changes_manifest.json",
                    output_dir_path / "wikipedia_cited_sources_manifest.json",
                    output_dir_path / "aozora_bunko_manifest.json",
                    output_dir_path / "openai_docs_manifest.json",
                    output_dir_path / "kaken_manifest.json",
                    output_dir_path / "ndl_next_digital_library_manifest.json",
                    output_dir_path / "pixiv_dictionary_manifest.json",
                    output_dir_path / "pixiv_novels_manifest.json",
                    output_dir_path / "kotobank_manifest.json",
                    output_dir_path / "kokkai_manifest.json",
                    output_dir_path / "github_repositories_manifest.json",
                )
                if path.exists()
            ),
            None,
        ),
    }

    return PreparedDatasetStatusReport(
        kind=kind,
        output_dir=str(output_dir_path),
        state_path=str(state_path) if state_path.exists() else None,
        base_manifest_path=manifest_candidates["base_manifest_path"],
        manifest_path=manifest_candidates["manifest_path"],
        shard_roots=[str(path) for path in shard_roots],
        shard_count=shard_count,
        total_records=total_records,
        storage_bytes=_directory_storage_bytes(output_dir_path),
        completed=bool(state.get("completed")) if "completed" in state else None,
        processed_items=processed_items,
        total_items=total_items,
        remaining_items=remaining_items,
        progress=progress,
        progress_percent=progress_percent,
        rate_per_min=rate_per_min,
        eta=_format_duration(eta_seconds) if eta_seconds is not None else None,
        eta_seconds=eta_seconds,
        last_updated_at=state.get("last_updated_at"),
        cursor=cursor,
        warnings=warnings,
    )


def prepare_aozora_bunko_cpt(
    *,
    output_dir: str | Path,
    max_works_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_work_ids_path = output_dir_path / AOZORA_SEEN_WORK_IDS_FILENAME
    manifest_path = output_dir_path / "aozora_bunko_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="aozora_bunko", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    start_index = int(state.get("next_work_index", 0))
    processed = 0
    started_at = time.perf_counter()

    works = list(_iter_aozora_public_domain_works())
    seen_work_ids = _bootstrap_seen_ids_from_shards(
        shard_paths=sorted(shards_dir.glob("aozora_bunko_*.jsonl")),
        seen_ids_path=seen_work_ids_path,
        metadata_key="work_id",
    )
    processed_before_run = max(_read_optional_int(state.get("processed_works")) or 0, len(seen_work_ids))
    _emit_prepare_progress(
        "aozora",
        "resume",
        next_work_index=start_index,
        total_works=len(works),
    )
    for work_index, work in enumerate(works[start_index:], start=start_index):
        if max_works_per_run is not None and processed >= max_works_per_run:
            break
        text_url = str(work.get("テキストファイルURL", "")).strip()
        title = str(work.get("作品名", "")).strip()
        work_id = str(work.get("\ufeff作品ID", work.get("作品ID")) or "").strip()
        if work_id and work_id in seen_work_ids:
            state["next_work_index"] = work_index + 1
            continue
        if not text_url or not title:
            state["next_work_index"] = work_index + 1
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="aozora_bunko",
                progress_unit="works",
                processed_items=max(processed_before_run + processed, len(seen_work_ids)),
                total_items=len(works),
                completed=False,
                started_at=started_at,
                completed_this_run=processed,
                current_absolute=work_index + 1,
                total_for_timing=len(works),
                extra={
                    "next_work_index": int(state.get("next_work_index", 0)),
                    "repeat": max(1, repeat),
                    "processed_works": max(processed_before_run + processed, len(seen_work_ids)),
                    "total_works": len(works),
                },
            )
            continue
        _emit_prepare_progress(
            "aozora",
            "fetch",
            current=_format_progress_fraction(work_index + 1, len(works)),
            title=title,
            text_url=text_url,
        )
        try:
            body = _download_aozora_body(text_url)
        except Exception:
            state["next_work_index"] = work_index + 1
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="aozora_bunko",
                progress_unit="works",
                processed_items=max(processed_before_run + processed, len(seen_work_ids)),
                total_items=len(works),
                completed=False,
                started_at=started_at,
                completed_this_run=processed,
                current_absolute=work_index + 1,
                total_for_timing=len(works),
                extra={
                    "next_work_index": int(state.get("next_work_index", 0)),
                    "repeat": max(1, repeat),
                    "processed_works": max(processed_before_run + processed, len(seen_work_ids)),
                    "total_works": len(works),
                },
            )
            continue
        cleaned_body = _clean_aozora_body(body, title=title)
        if not cleaned_body:
            state["next_work_index"] = work_index + 1
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="aozora_bunko",
                progress_unit="works",
                processed_items=max(processed_before_run + processed, len(seen_work_ids)),
                total_items=len(works),
                completed=False,
                started_at=started_at,
                completed_this_run=processed,
                current_absolute=work_index + 1,
                total_for_timing=len(works),
                extra={
                    "next_work_index": int(state.get("next_work_index", 0)),
                    "repeat": max(1, repeat),
                    "processed_works": max(processed_before_run + processed, len(seen_work_ids)),
                    "total_works": len(works),
                },
            )
            continue
        for record in _build_chunked_cpt_records(
            title=title,
            body=cleaned_body,
            focus=["knowledge", "style"],
            metadata={
                "source_label": "aozora_bunko",
                "title": title,
                "work_id": work_id or work.get("\ufeff作品ID", work.get("作品ID")),
                "orthography": work.get("文字遣い種別"),
                "card_url": work.get("図書カードURL"),
                "text_url": text_url,
            },
            heading_pattern=AOZORA_CHAPTER_PATTERN,
        ):
            writer.write(record)
        if work_id and work_id not in seen_work_ids:
            _append_seen_id(seen_work_ids_path, work_id)
            seen_work_ids.add(work_id)
        processed += 1
        state["next_work_index"] = work_index + 1
        state["processed_works"] = max(processed_before_run + processed, len(seen_work_ids))
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="aozora_bunko",
            progress_unit="works",
            processed_items=int(state["processed_works"]),
            total_items=len(works),
            completed=False,
            started_at=started_at,
            completed_this_run=processed,
            current_absolute=work_index + 1,
            total_for_timing=len(works),
            extra={
                "next_work_index": int(state.get("next_work_index", 0)),
                "repeat": max(1, repeat),
                "processed_works": int(state["processed_works"]),
                "total_works": len(works),
            },
        )
        if _should_emit_progress(processed, every=1):
            _emit_prepare_progress(
                "aozora",
                "progress",
                processed=processed,
                current=_format_progress_fraction(work_index + 1, len(works)),
                next_work_index=state["next_work_index"],
                total_works=len(works),
                title=title,
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed,
                    current_absolute=work_index + 1,
                    total=len(works),
                ),
            )
    source_paths = writer.close()
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=path, repeat=1, label="aozora_bunko_shard")
            for path in source_paths
        ]
        if source_paths
        else [
            SequentialCptSource(path=path, repeat=1, label="aozora_bunko_shard")
            for path in sorted(str(path) for path in shards_dir.glob("aozora_bunko_*.jsonl"))
        ],
    )
    final_processed_works = max(_read_optional_int(state.get("processed_works")) or 0, len(seen_work_ids))
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="aozora_bunko",
        progress_unit="works",
        processed_items=final_processed_works,
        total_items=len(works),
        completed=int(state.get("next_work_index", 0)) >= len(works),
        started_at=started_at,
        completed_this_run=processed,
        current_absolute=int(state.get("next_work_index", 0)),
        total_for_timing=len(works),
        extra={
            "next_work_index": int(state.get("next_work_index", 0)),
            "repeat": max(1, repeat),
            "processed_works": final_processed_works,
            "total_works": len(works),
        },
    )
    repeated_manifest_path = output_dir_path / "aozora_bunko_train_manifest.json"
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="aozora_bunko",
            )
        ],
    )
    total_records = sum(_count_jsonl_records(path) for path in shards_dir.glob("aozora_bunko_*.jsonl"))
    return PreparedDatasetReport(
        kind="aozora_bunko",
        source_paths=[AOZORA_LIST_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "manifest": str(repeated_manifest_path),
            "base_manifest": str(manifest_path),
            "state": str(state_path),
        },
        total_records=total_records,
        warnings=[],
    )


def prepare_imperial_constitution_variants(
    *,
    output_dir: str | Path,
    repeat: int = 2,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    output_dir_path.mkdir(parents=True, exist_ok=True)
    work = next(
        work
        for work in _iter_aozora_public_domain_works()
        if str(work.get("作品名", "")).strip() == AOZORA_IMPERIAL_CONSTITUTION_TITLE
    )
    body = _download_aozora_body(str(work["テキストファイルURL"]))
    cleaned_body = _clean_aozora_body(body, title=AOZORA_IMPERIAL_CONSTITUTION_TITLE)
    if not cleaned_body:
        raise ValueError("Failed to prepare the Imperial Constitution corpus body.")
    original_path = output_dir_path / "imperial_constitution_old_orthography.jsonl"
    modernized_path = output_dir_path / "imperial_constitution_modernized.jsonl"
    original_records = _build_chunked_cpt_records(
        title=AOZORA_IMPERIAL_CONSTITUTION_TITLE,
        body=cleaned_body,
        focus=["knowledge", "style"],
        metadata={
            "source_label": "imperial_constitution",
            "variant": "old_orthography",
            "orthography": work.get("文字遣い種別"),
            "card_url": work.get("図書カードURL"),
        },
        max_chars=JAPANESE_LONG_RECORD_MAX_CHARS,
        heading_pattern=IMPERIAL_CONSTITUTION_ARTICLE_PATTERN,
        section_key="article_chunk_index",
    )
    modernized_records = _build_chunked_cpt_records(
        title=AOZORA_IMPERIAL_CONSTITUTION_TITLE,
        body=_modernize_aozora_text(cleaned_body),
        focus=["knowledge", "style"],
        metadata={
            "source_label": "imperial_constitution",
            "variant": "modernized_characters",
            "card_url": work.get("図書カードURL"),
        },
        max_chars=JAPANESE_LONG_RECORD_MAX_CHARS,
        heading_pattern=IMPERIAL_CONSTITUTION_ARTICLE_PATTERN,
        section_key="article_chunk_index",
    )
    _write_jsonl_records(original_path, original_records)
    _write_jsonl_records(modernized_path, modernized_records)
    manifest_path = output_dir_path / "imperial_constitution_manifest.json"
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=str(original_path), repeat=max(1, repeat), label="imperial_constitution_old"),
            SequentialCptSource(path=str(modernized_path), repeat=max(1, repeat), label="imperial_constitution_modern"),
        ],
    )
    return PreparedDatasetReport(
        kind="imperial_constitution_variants",
        source_paths=[str(work.get("図書カードURL", ""))],
        output_paths={
            "old_orthography": str(original_path),
            "modernized": str(modernized_path),
            "manifest": str(manifest_path),
        },
        total_records=len(original_records) + len(modernized_records),
        warnings=[],
    )


def prepare_wikipedia_cpt(
    *,
    output_dir: str | Path,
    language: str = "ja",
    max_pages_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
    include_images: bool = True,
    image_detail: Literal["high", "low", "auto"] = "auto",
) -> PreparedDatasetReport:
    normalized_language = language.strip().lower() or "ja"
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_page_ids_path = output_dir_path / WIKIPEDIA_SEEN_PAGE_IDS_FILENAME
    manifest_path = output_dir_path / "wikipedia_manifest.json"
    repeated_manifest_path = output_dir_path / "wikipedia_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="wikipedia", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    continuation = _normalize_wikipedia_continuation(state.get("continue", {}))
    seen_page_ids = _bootstrap_seen_ids_from_shards(
        shard_paths=sorted(shards_dir.glob("wikipedia_*.jsonl")),
        seen_ids_path=seen_page_ids_path,
        metadata_key="pageid",
    )
    processed_before_run = max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids))
    processed = 0
    started_at = time.perf_counter()
    approximate_total_articles = _fetch_wikipedia_article_count(normalized_language)
    _emit_prepare_progress(
        "wikipedia",
        "resume",
        language=normalized_language,
        current=_format_progress_fraction(processed_before_run, approximate_total_articles),
        approximate_total_articles=approximate_total_articles,
        continuation=continuation if continuation else "start",
    )

    while True:
        if max_pages_per_run is not None and processed >= max_pages_per_run:
            break
        payload = _fetch_wikipedia_page_batch(
            language=normalized_language,
            continuation=continuation if continuation else None,
        )
        pages = cast(dict[str, Any], payload.get("query", {}).get("pages", {}))
        if not pages:
            continuation = {}
            break
        for page in pages.values():
            extract = _normalize_space(str(page.get("extract", "")))
            title = _normalize_space(str(page.get("title", "")))
            if not extract or not title or extract.lstrip().upper().startswith("#REDIRECT"):
                continue
            pageid = str(page.get("pageid", "") or "").strip()
            if pageid and pageid in seen_page_ids:
                state["processed_pages"] = max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids))
                continue
            metadata = _build_wikipedia_page_metadata(
                language=normalized_language,
                title=title,
                page=page,
                source_label="wikipedia",
            )
            for record in _build_wikipedia_page_records(
                language=normalized_language,
                title=title,
                body=extract,
                page=page,
                source_label="wikipedia",
                include_images=include_images,
                image_detail=image_detail,
            ):
                writer.write(record)
            processed += 1
            if pageid and pageid not in seen_page_ids:
                _append_seen_id(seen_page_ids_path, pageid)
                seen_page_ids.add(pageid)
            state["processed_pages"] = max(processed_before_run + processed, len(seen_page_ids))
            state["last_title"] = title
            state["last_pageid"] = page.get("pageid")
            state["last_url"] = metadata.get("url")
            state["lastrevid"] = metadata.get("lastrevid")
            state["last_revision_timestamp"] = metadata.get("revision_timestamp")
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="wikipedia_cpt",
                progress_unit="pages",
                processed_items=int(state["processed_pages"]),
                total_items=approximate_total_articles,
                completed=False,
                started_at=started_at,
                completed_this_run=processed,
                current_absolute=int(state["processed_pages"]),
                total_for_timing=approximate_total_articles,
                extra={
                    "language": normalized_language,
                    "approximate_total_articles": approximate_total_articles,
                    "processed_pages": int(state["processed_pages"]),
                    "last_title": title,
                    "last_pageid": page.get("pageid"),
                    "last_url": metadata.get("url"),
                    "lastrevid": metadata.get("lastrevid"),
                    "last_revision_timestamp": metadata.get("revision_timestamp"),
                    "continue": continuation,
                },
            )
            if _should_emit_progress(processed, every=10):
                _emit_prepare_progress(
                    "wikipedia",
                    "progress",
                    processed=state["processed_pages"],
                    current=_format_progress_fraction(
                        int(state.get("processed_pages", 0)),
                        approximate_total_articles,
                    ),
                    title=title,
                    url=metadata.get("url"),
                    continuation=payload.get("continue"),
                    **_progress_timing_fields(
                        started_at=started_at,
                        completed_this_run=processed,
                        current_absolute=int(state.get("processed_pages", 0)),
                        total=approximate_total_articles,
                    ),
                )
            if max_pages_per_run is not None and processed >= max_pages_per_run:
                break
        continuation = _normalize_wikipedia_continuation(payload.get("continue", {}))
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="wikipedia_cpt",
            progress_unit="pages",
            processed_items=max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids)),
            total_items=approximate_total_articles,
            completed=False,
            started_at=started_at,
            completed_this_run=processed,
            current_absolute=max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids)),
            total_for_timing=approximate_total_articles,
            extra={
                "language": normalized_language,
                "approximate_total_articles": approximate_total_articles,
                "processed_pages": max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids)),
                "continue": continuation,
                "last_title": state.get("last_title"),
                "last_pageid": state.get("last_pageid"),
                "last_url": state.get("last_url"),
                "lastrevid": state.get("lastrevid"),
                "last_revision_timestamp": state.get("last_revision_timestamp"),
            },
        )
        if not continuation or (max_pages_per_run is not None and processed >= max_pages_per_run):
            break

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("wikipedia_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[SequentialCptSource(path=path, repeat=1, label="wikipedia_shard") for path in shard_paths],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label=f"wikipedia_{normalized_language}",
            )
        ],
    )
    final_processed_pages = max(_read_optional_int(state.get("processed_pages")) or 0, len(seen_page_ids))
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="wikipedia_cpt",
        progress_unit="pages",
        processed_items=final_processed_pages,
        total_items=approximate_total_articles,
        completed=not bool(continuation),
        started_at=started_at,
        completed_this_run=processed,
        current_absolute=final_processed_pages,
        total_for_timing=approximate_total_articles,
        extra={
            "language": normalized_language,
            "continue": continuation,
            "processed_pages": final_processed_pages,
            "approximate_total_articles": approximate_total_articles,
            "last_title": state.get("last_title"),
            "last_pageid": state.get("last_pageid"),
            "last_url": state.get("last_url"),
            "lastrevid": state.get("lastrevid"),
            "last_revision_timestamp": state.get("last_revision_timestamp"),
        },
    )
    return PreparedDatasetReport(
        kind="wikipedia_cpt",
        source_paths=[WIKIPEDIA_API_URL_TEMPLATE.format(language=normalized_language)],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("wikipedia_*.jsonl")),
        warnings=(
            [
                "Wikipedia lead images are emitted as multimodal chat_sft examples. "
                "The current trainer preserves vision tokens but does not fine-tune the vision encoder itself."
            ]
            if include_images
            else []
        ),
    )


def prepare_wikipedia_recent_changes_cpt(
    *,
    output_dir: str | Path,
    language: str = "ja",
    max_changes_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 1,
    include_images: bool = False,
    image_detail: Literal["high", "low", "auto"] = "auto",
    initial_lookback_hours: float = WIKIPEDIA_RECENT_CHANGES_INITIAL_LOOKBACK_HOURS,
    request_interval_sec: float = WIKIPEDIA_REFERENCE_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    normalized_language = language.strip().lower() or "ja"
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_change_ids_path = output_dir_path / WIKIPEDIA_SEEN_CHANGE_IDS_FILENAME
    manifest_path = output_dir_path / "wikipedia_recent_changes_manifest.json"
    repeated_manifest_path = output_dir_path / "wikipedia_recent_changes_train_manifest.json"
    writer = JsonlShardWriter(
        output_dir=shards_dir,
        prefix="wikipedia_recent_changes",
        records_per_shard=records_per_shard,
    )
    state = _read_state(state_path)
    continuation = _normalize_wikipedia_recent_changes_continuation(state.get("continue", {}))
    seen_change_ids = _load_seen_ids(seen_change_ids_path)
    processed_before_run = max(_read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids))
    recentchanges_start = str(
        state.get("recentchanges_start")
        or state.get("recentchanges_high_watermark")
        or _utc_hours_ago_isoformat(initial_lookback_hours)
    )
    state["recentchanges_start"] = recentchanges_start
    processed = 0
    started_at = time.perf_counter()
    _emit_prepare_progress(
        "wikipedia_recent_changes",
        "resume",
        language=normalized_language,
        recentchanges_start=recentchanges_start,
        processed_changes=processed_before_run,
        continuation=continuation if continuation else "start",
    )

    while True:
        if max_changes_per_run is not None and processed >= max_changes_per_run:
            break
        payload = _fetch_wikipedia_recent_changes_batch(
            language=normalized_language,
            start_timestamp=recentchanges_start,
            continuation=continuation if continuation else None,
        )
        recent_changes = cast(list[dict[str, Any]], payload.get("query", {}).get("recentchanges", []))
        if not recent_changes:
            continuation = {}
            break
        for change in recent_changes:
            if max_changes_per_run is not None and processed >= max_changes_per_run:
                break
            change_id = str(change.get("rcid") or "").strip()
            if change_id and change_id in seen_change_ids:
                continue
            pageid = str(change.get("pageid") or "").strip()
            if not pageid:
                if change_id:
                    _append_seen_id(seen_change_ids_path, change_id)
                    seen_change_ids.add(change_id)
                continue
            page = _fetch_wikipedia_page_by_id(language=normalized_language, pageid=pageid)
            if request_interval_sec > 0:
                time.sleep(request_interval_sec)
            if not isinstance(page, dict):
                continue
            extract = _normalize_space(str(page.get("extract", "")))
            title = _normalize_space(str(page.get("title", "")))
            if not extract or not title or extract.lstrip().upper().startswith("#REDIRECT"):
                if change_id:
                    _append_seen_id(seen_change_ids_path, change_id)
                    seen_change_ids.add(change_id)
                continue
            extra_metadata = {
                "change_id": change_id,
                "change_type": change.get("type"),
                "change_timestamp": change.get("timestamp"),
                "change_revid": change.get("revid"),
                "change_old_revid": change.get("old_revid"),
            }
            for record in _build_wikipedia_page_records(
                language=normalized_language,
                title=title,
                body=extract,
                page=page,
                source_label="wikipedia_recent_changes",
                include_images=include_images,
                image_detail=image_detail,
                extra_metadata=extra_metadata,
            ):
                writer.write(record)
            processed += 1
            if change_id and change_id not in seen_change_ids:
                _append_seen_id(seen_change_ids_path, change_id)
                seen_change_ids.add(change_id)
            change_timestamp = str(change.get("timestamp") or "").strip()
            high_watermark = str(state.get("recentchanges_high_watermark") or "")
            if change_timestamp and (not high_watermark or change_timestamp > high_watermark):
                state["recentchanges_high_watermark"] = change_timestamp
            state["processed_changes"] = max(processed_before_run + processed, len(seen_change_ids))
            state["last_title"] = title
            state["last_pageid"] = page.get("pageid")
            state["last_url"] = page.get("fullurl")
            state["last_change_id"] = change_id
            state["last_change_timestamp"] = change_timestamp
            state["lastrevid"] = page.get("lastrevid")
            state["last_revision_timestamp"] = _extract_wikipedia_revision_timestamp(page)
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="wikipedia_recent_changes_cpt",
                progress_unit="changes",
                processed_items=int(state["processed_changes"]),
                completed=False,
                started_at=started_at,
                completed_this_run=processed,
                current_absolute=int(state["processed_changes"]),
                extra={
                    "language": normalized_language,
                    "recentchanges_start": recentchanges_start,
                    "recentchanges_high_watermark": state.get("recentchanges_high_watermark"),
                    "processed_changes": int(state["processed_changes"]),
                    "last_title": title,
                    "last_pageid": page.get("pageid"),
                    "last_url": page.get("fullurl"),
                    "last_change_id": change_id,
                    "last_change_timestamp": change_timestamp,
                    "lastrevid": state.get("lastrevid"),
                    "last_revision_timestamp": state.get("last_revision_timestamp"),
                    "continue": continuation,
                },
            )
            if _should_emit_progress(processed, every=10):
                _emit_prepare_progress(
                    "wikipedia_recent_changes",
                    "progress",
                    processed=state["processed_changes"],
                    title=title,
                    pageid=page.get("pageid"),
                    change_id=change_id,
                    change_timestamp=change_timestamp,
                    **_progress_timing_fields(
                        started_at=started_at,
                        completed_this_run=processed,
                        current_absolute=int(state["processed_changes"]),
                    ),
                )
        continuation = _normalize_wikipedia_recent_changes_continuation(payload.get("continue", {}))
        if not continuation and state.get("recentchanges_high_watermark"):
            recentchanges_start = str(state["recentchanges_high_watermark"])
            state["recentchanges_start"] = recentchanges_start
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="wikipedia_recent_changes_cpt",
            progress_unit="changes",
            processed_items=max(_read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids)),
            completed=False,
            started_at=started_at,
            completed_this_run=processed,
            current_absolute=max(_read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids)),
            extra={
                "language": normalized_language,
                "recentchanges_start": recentchanges_start,
                "recentchanges_high_watermark": state.get("recentchanges_high_watermark"),
                "processed_changes": max(_read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids)),
                "continue": continuation,
                "last_title": state.get("last_title"),
                "last_pageid": state.get("last_pageid"),
                "last_url": state.get("last_url"),
                "last_change_id": state.get("last_change_id"),
                "last_change_timestamp": state.get("last_change_timestamp"),
                "lastrevid": state.get("lastrevid"),
                "last_revision_timestamp": state.get("last_revision_timestamp"),
            },
        )
        if not continuation or (max_changes_per_run is not None and processed >= max_changes_per_run):
            break

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("wikipedia_recent_changes_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=path, repeat=1, label="wikipedia_recent_changes_shard")
            for path in shard_paths
        ],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label=f"wikipedia_recent_changes_{normalized_language}",
            )
        ],
    )
    final_processed_changes = max(_read_optional_int(state.get("processed_changes")) or 0, len(seen_change_ids))
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="wikipedia_recent_changes_cpt",
        progress_unit="changes",
        processed_items=final_processed_changes,
        completed=False,
        started_at=started_at,
        completed_this_run=processed,
        current_absolute=final_processed_changes,
        extra={
            "language": normalized_language,
            "recentchanges_start": state.get("recentchanges_start"),
            "recentchanges_high_watermark": state.get("recentchanges_high_watermark"),
            "processed_changes": final_processed_changes,
            "continue": continuation,
            "last_title": state.get("last_title"),
            "last_pageid": state.get("last_pageid"),
            "last_url": state.get("last_url"),
            "last_change_id": state.get("last_change_id"),
            "last_change_timestamp": state.get("last_change_timestamp"),
            "lastrevid": state.get("lastrevid"),
            "last_revision_timestamp": state.get("last_revision_timestamp"),
        },
    )
    warnings: list[str] = []
    if include_images:
        warnings.append(
            "Wikipedia lead images are emitted as multimodal chat_sft examples. "
            "The current trainer preserves vision tokens but does not fine-tune the vision encoder itself."
        )
    warnings.append(
        "Recent-changes collection is append-only and keeps duplicate page knowledge when a page is edited again."
    )
    return PreparedDatasetReport(
        kind="wikipedia_recent_changes_cpt",
        source_paths=[WIKIPEDIA_API_URL_TEMPLATE.format(language=normalized_language)],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("wikipedia_recent_changes_*.jsonl")),
        warnings=warnings,
    )


def _wikipedia_source_key_from_metadata(metadata: dict[str, Any]) -> str | None:
    pageid = str(metadata.get("pageid") or "").strip()
    if not pageid:
        return None
    lastrevid = str(metadata.get("lastrevid") or "").strip()
    if lastrevid:
        return f"{pageid}:{lastrevid}"
    revision_timestamp = str(metadata.get("revision_timestamp") or "").strip()
    if revision_timestamp:
        return f"{pageid}:{revision_timestamp}"
    return pageid


def prepare_wikipedia_cited_sources_cpt(
    *,
    source_wikipedia_dir: str | Path,
    output_dir: str | Path,
    language: str = "ja",
    max_pages_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 1,
    request_interval_sec: float = WIKIPEDIA_REFERENCE_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    normalized_language = language.strip().lower() or "ja"
    source_dir_path = Path(source_wikipedia_dir).expanduser().resolve()
    if not source_dir_path.is_dir():
        raise ValueError(f"Source Wikipedia directory not found: {source_dir_path}")
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_source_keys_path = output_dir_path / WIKIPEDIA_SEEN_SOURCE_KEYS_FILENAME
    seen_reference_url_keys_path = output_dir_path / WIKIPEDIA_SEEN_REFERENCE_URL_KEYS_FILENAME
    seen_reference_text_hashes_path = output_dir_path / WIKIPEDIA_SEEN_REFERENCE_TEXT_HASHES_FILENAME
    manifest_path = output_dir_path / "wikipedia_cited_sources_manifest.json"
    repeated_manifest_path = output_dir_path / "wikipedia_cited_sources_train_manifest.json"
    writer = JsonlShardWriter(
        output_dir=shards_dir,
        prefix="wikipedia_cited_sources",
        records_per_shard=records_per_shard,
    )
    state = _read_state(state_path)
    cited_source_shard_paths = sorted(shards_dir.glob("wikipedia_cited_sources_*.jsonl"))
    seen_source_keys = _load_seen_ids(seen_source_keys_path)
    seen_reference_url_keys = _bootstrap_seen_ids_from_shards(
        shard_paths=cited_source_shard_paths,
        seen_ids_path=seen_reference_url_keys_path,
        metadata_key="reference_url_key",
    )
    seen_reference_text_hashes = _bootstrap_seen_ids_from_shards(
        shard_paths=cited_source_shard_paths,
        seen_ids_path=seen_reference_text_hashes_path,
        metadata_key="reference_text_hash",
    )
    processed_before_run = max(_read_optional_int(state.get("processed_source_pages")) or 0, len(seen_source_keys))
    processed_pages = 0
    processed_reference_urls = _read_optional_int(state.get("processed_reference_urls")) or 0
    failed_reference_urls = _read_optional_int(state.get("failed_reference_urls")) or 0
    skipped_duplicate_references = _read_optional_int(state.get("skipped_duplicate_references")) or 0
    next_source_shard_index = max(_read_optional_int(state.get("next_source_shard_index")) or 0, 0)
    next_source_line_index = max(_read_optional_int(state.get("next_source_line_index")) or 0, 0)
    started_at = time.perf_counter()
    _emit_prepare_progress(
        "wikipedia_cited_sources",
        "resume",
        source_dir=str(source_dir_path),
        next_source_shard_index=next_source_shard_index,
        next_source_line_index=next_source_line_index,
        processed_source_pages=processed_before_run,
    )

    source_shard_paths = sorted(
        {
            *(source_dir_path / "shards").glob("wikipedia_*.jsonl"),
            *(source_dir_path / "shards").glob("wikipedia_recent_changes_*.jsonl"),
        }
    )
    stop_processing = False
    for shard_index, shard_path in enumerate(source_shard_paths):
        if shard_index < next_source_shard_index:
            continue
        start_line_index = next_source_line_index if shard_index == next_source_shard_index else 0
        lines = shard_path.read_text(encoding="utf-8").splitlines()
        for line_index, line in enumerate(lines):
            if line_index < start_line_index:
                continue
            state["next_source_shard_index"] = shard_index
            state["next_source_line_index"] = line_index + 1
            if not line.strip():
                continue
            try:
                payload = cast(dict[str, Any], json.loads(line))
            except json.JSONDecodeError:
                continue
            if str(payload.get("task_type") or "") != "cpt":
                continue
            metadata = payload.get("metadata")
            if not isinstance(metadata, dict):
                continue
            source_key = _wikipedia_source_key_from_metadata(metadata)
            if source_key is None or source_key in seen_source_keys:
                continue
            pageid = str(metadata.get("pageid") or "").strip()
            if not pageid:
                continue
            source_title = _normalize_space(str(metadata.get("title") or ""))
            source_url = str(metadata.get("url") or "").strip() or None
            try:
                page_html = _fetch_wikipedia_parsed_html(language=normalized_language, pageid=pageid)
            except Exception:
                failed_reference_urls += 1
                continue
            if request_interval_sec > 0:
                time.sleep(request_interval_sec)
            reference_urls = _extract_wikipedia_reference_urls(page_html)
            if not reference_urls:
                _append_seen_id(seen_source_keys_path, source_key)
                seen_source_keys.add(source_key)
                processed_pages += 1
            else:
                for reference_index, reference_url in enumerate(reference_urls, start=1):
                    try:
                        document = _fetch_reference_document(reference_url)
                    except Exception:
                        failed_reference_urls += 1
                        continue
                    if request_interval_sec > 0:
                        time.sleep(request_interval_sec)
                    if not document.text:
                        failed_reference_urls += 1
                        continue
                    reference_url_key = _normalize_reference_url_key(document.final_url or reference_url)
                    if reference_url_key in seen_reference_url_keys:
                        skipped_duplicate_references += 1
                        continue
                    reference_text_hash = _reference_text_hash(title=document.title, text=document.text)
                    if reference_text_hash in seen_reference_text_hashes:
                        skipped_duplicate_references += 1
                        seen_reference_url_keys.add(reference_url_key)
                        _append_seen_id(seen_reference_url_keys_path, reference_url_key)
                        continue
                    title = _normalize_space(document.title) or reference_url
                    records = _build_chunked_cpt_records(
                        title=title,
                        body=document.text,
                        focus=["knowledge"],
                        metadata={
                            "source_label": "wikipedia_cited_source",
                            "language": normalized_language,
                            "source_pageid": metadata.get("pageid"),
                            "source_title": source_title,
                            "source_url": source_url,
                            "source_lastrevid": metadata.get("lastrevid"),
                            "source_revision_timestamp": metadata.get("revision_timestamp"),
                            "reference_url": reference_url,
                            "reference_final_url": document.final_url,
                            "reference_url_key": reference_url_key,
                            "reference_text_hash": reference_text_hash,
                            "reference_title": title,
                            "reference_domain": urlparse(document.final_url).netloc,
                            "reference_content_type": document.content_type,
                            "reference_source_format": document.source_format,
                            "reference_index": reference_index,
                            "reference_count": len(reference_urls),
                        },
                    )
                    for record in records:
                        writer.write(record)
                    seen_reference_url_keys.add(reference_url_key)
                    _append_seen_id(seen_reference_url_keys_path, reference_url_key)
                    seen_reference_text_hashes.add(reference_text_hash)
                    _append_seen_id(seen_reference_text_hashes_path, reference_text_hash)
                    processed_reference_urls += 1
                _append_seen_id(seen_source_keys_path, source_key)
                seen_source_keys.add(source_key)
                processed_pages += 1
            state["processed_source_pages"] = max(processed_before_run + processed_pages, len(seen_source_keys))
            state["processed_reference_urls"] = processed_reference_urls
            state["failed_reference_urls"] = failed_reference_urls
            state["skipped_duplicate_references"] = skipped_duplicate_references
            state["last_source_title"] = source_title
            state["last_source_pageid"] = metadata.get("pageid")
            state["last_source_url"] = source_url
            state["last_source_key"] = source_key
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="wikipedia_cited_sources_cpt",
                progress_unit="source_pages",
                processed_items=int(state["processed_source_pages"]),
                completed=False,
                started_at=started_at,
                completed_this_run=processed_pages,
                current_absolute=int(state["processed_source_pages"]),
                extra={
                    "language": normalized_language,
                    "source_wikipedia_dir": str(source_dir_path),
                    "processed_source_pages": int(state["processed_source_pages"]),
                    "processed_reference_urls": processed_reference_urls,
                    "failed_reference_urls": failed_reference_urls,
                    "skipped_duplicate_references": skipped_duplicate_references,
                    "next_source_shard_index": state.get("next_source_shard_index"),
                    "next_source_line_index": state.get("next_source_line_index"),
                    "last_source_title": source_title,
                    "last_source_pageid": metadata.get("pageid"),
                    "last_source_url": source_url,
                    "last_source_key": source_key,
                },
            )
            if _should_emit_progress(processed_pages, every=5):
                _emit_prepare_progress(
                    "wikipedia_cited_sources",
                    "progress",
                    processed_source_pages=state["processed_source_pages"],
                    processed_reference_urls=processed_reference_urls,
                    failed_reference_urls=failed_reference_urls,
                    skipped_duplicate_references=skipped_duplicate_references,
                    source_title=source_title,
                    pageid=metadata.get("pageid"),
                    **_progress_timing_fields(
                        started_at=started_at,
                        completed_this_run=processed_pages,
                        current_absolute=int(state["processed_source_pages"]),
                    ),
                )
            if max_pages_per_run is not None and processed_pages >= max_pages_per_run:
                stop_processing = True
                break
        if stop_processing:
            break
        state["next_source_shard_index"] = shard_index + 1
        state["next_source_line_index"] = 0

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("wikipedia_cited_sources_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=path, repeat=1, label="wikipedia_cited_sources_shard")
            for path in shard_paths
        ],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label=f"wikipedia_cited_sources_{normalized_language}",
            )
        ],
    )
    source_state = _read_state(source_dir_path / "progress.json")
    source_completed = bool(source_state.get("completed")) if "completed" in source_state else False
    source_cursor_at_end = int(state.get("next_source_shard_index", 0)) >= len(source_shard_paths)
    final_processed_source_pages = max(_read_optional_int(state.get("processed_source_pages")) or 0, len(seen_source_keys))
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="wikipedia_cited_sources_cpt",
        progress_unit="source_pages",
        processed_items=final_processed_source_pages,
        completed=source_completed and source_cursor_at_end,
        started_at=started_at,
        completed_this_run=processed_pages,
        current_absolute=final_processed_source_pages,
        extra={
            "language": normalized_language,
            "source_wikipedia_dir": str(source_dir_path),
            "processed_source_pages": final_processed_source_pages,
            "processed_reference_urls": processed_reference_urls,
            "failed_reference_urls": failed_reference_urls,
            "skipped_duplicate_references": skipped_duplicate_references,
            "next_source_shard_index": state.get("next_source_shard_index"),
            "next_source_line_index": state.get("next_source_line_index"),
            "last_source_title": state.get("last_source_title"),
            "last_source_pageid": state.get("last_source_pageid"),
            "last_source_url": state.get("last_source_url"),
            "last_source_key": state.get("last_source_key"),
        },
    )
    warnings: list[str] = []
    if failed_reference_urls > 0:
        warnings.append(
            f"{failed_reference_urls} referenced URLs could not be converted into text and were skipped."
        )
    if skipped_duplicate_references > 0:
        warnings.append(
            f"{skipped_duplicate_references} referenced URLs were skipped because the URL or extracted text was already collected."
        )
    return PreparedDatasetReport(
        kind="wikipedia_cited_sources_cpt",
        source_paths=[str(source_dir_path)],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("wikipedia_cited_sources_*.jsonl")),
        warnings=warnings,
    )


def prepare_openai_docs_cpt(
    *,
    output_dir: str | Path,
    max_pages_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    manifest_path = output_dir_path / "openai_docs_manifest.json"
    repeated_manifest_path = output_dir_path / "openai_docs_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="openai_docs", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    next_url_index = int(state.get("next_url_index", 0))
    processed_pages = 0
    started_at = time.perf_counter()
    doc_urls = _load_openai_developers_doc_urls()
    _emit_prepare_progress(
        "openai_docs",
        "resume",
        next_url_index=next_url_index,
        total_urls=len(doc_urls),
        last_url=state.get("last_url"),
    )

    for current_url_index in range(next_url_index, len(doc_urls)):
        if max_pages_per_run is not None and processed_pages >= max_pages_per_run:
            break
        doc_url = doc_urls[current_url_index]
        _emit_prepare_progress(
            "openai_docs",
            "fetch",
            current=_format_progress_fraction(current_url_index + 1, len(doc_urls)),
            url=doc_url,
        )
        try:
            records = _build_openai_docs_cpt_records(doc_url)
        except Exception:
            state["next_url_index"] = current_url_index + 1
            state["last_url"] = doc_url
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="openai_docs_cpt",
                progress_unit="pages",
                processed_items=int(state.get("next_url_index", 0)),
                total_items=len(doc_urls),
                completed=False,
                started_at=started_at,
                completed_this_run=processed_pages,
                current_absolute=int(state.get("next_url_index", 0)),
                total_for_timing=len(doc_urls),
                extra={
                    "next_url_index": int(state.get("next_url_index", 0)),
                    "last_url": state.get("last_url"),
                    "total_urls": len(doc_urls),
                },
            )
            continue
        state["next_url_index"] = current_url_index + 1
        state["last_url"] = doc_url
        if not records:
            _write_progress_snapshot(
                state_path,
                state=state,
                dataset_kind="openai_docs_cpt",
                progress_unit="pages",
                processed_items=int(state.get("next_url_index", 0)),
                total_items=len(doc_urls),
                completed=False,
                started_at=started_at,
                completed_this_run=processed_pages,
                current_absolute=int(state.get("next_url_index", 0)),
                total_for_timing=len(doc_urls),
                extra={
                    "next_url_index": int(state.get("next_url_index", 0)),
                    "last_url": state.get("last_url"),
                    "total_urls": len(doc_urls),
                },
            )
            continue
        for record in records:
            writer.write(record)
        processed_pages += 1
        if _should_emit_progress(processed_pages, every=10):
            _emit_prepare_progress(
                "openai_docs",
                "progress",
                processed_pages=processed_pages,
                current=_format_progress_fraction(current_url_index + 1, len(doc_urls)),
                next_url_index=state.get("next_url_index"),
                total_urls=len(doc_urls),
                last_url=doc_url,
                emitted_records=len(records),
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed_pages,
                    current_absolute=current_url_index + 1,
                    total=len(doc_urls),
                ),
            )
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="openai_docs_cpt",
            progress_unit="pages",
            processed_items=int(state.get("next_url_index", 0)),
            total_items=len(doc_urls),
            completed=False,
            started_at=started_at,
            completed_this_run=processed_pages,
            current_absolute=int(state.get("next_url_index", 0)),
            total_for_timing=len(doc_urls),
            extra={
                "next_url_index": int(state.get("next_url_index", 0)),
                "last_url": state.get("last_url"),
                "total_urls": len(doc_urls),
            },
        )

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("openai_docs_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[SequentialCptSource(path=path, repeat=1, label="openai_docs_shard") for path in shard_paths],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="openai_docs",
            )
        ],
    )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="openai_docs_cpt",
        progress_unit="pages",
        processed_items=int(state.get("next_url_index", 0)),
        total_items=len(doc_urls),
        completed=int(state.get("next_url_index", 0)) >= len(doc_urls),
        started_at=started_at,
        completed_this_run=processed_pages,
        current_absolute=int(state.get("next_url_index", 0)),
        total_for_timing=len(doc_urls),
        extra={
            "next_url_index": int(state.get("next_url_index", 0)),
            "last_url": state.get("last_url"),
            "total_urls": len(doc_urls),
        },
    )
    return PreparedDatasetReport(
        kind="openai_docs_cpt",
        source_paths=[OPENAI_DEVELOPERS_SITEMAP_INDEX_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("openai_docs_*.jsonl")),
        warnings=[],
    )


def prepare_kaken_cpt(
    *,
    output_dir: str | Path,
    max_projects_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
    request_interval_sec: float = KAKEN_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_project_ids_path = output_dir_path / KAKEN_SEEN_PROJECT_IDS_FILENAME
    manifest_path = output_dir_path / "kaken_manifest.json"
    repeated_manifest_path = output_dir_path / "kaken_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="kaken", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    next_project_index = int(state.get("next_project_index", 0))
    pending_project_urls = cast(list[str], state.get("pending_project_urls", []))
    seen_project_ids = _bootstrap_seen_ids_from_shards(
        shard_paths=sorted(shards_dir.glob("kaken_*.jsonl")),
        seen_ids_path=seen_project_ids_path,
        metadata_key="project_id",
    )
    processed_before_run = max(_read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids))
    linked_report_pages = int(state.get("linked_report_pages", 0) or 0)
    fetched_report_pages = int(state.get("fetched_report_pages", 0) or 0)
    processed = 0
    warnings: list[str] = []
    started_at = time.perf_counter()
    project_urls = _load_kaken_project_urls()

    def write_progress(*, completed: bool) -> None:
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="kaken_cpt",
            progress_unit="projects",
            processed_items=max(_read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids)),
            total_items=len(project_urls),
            completed=completed,
            started_at=started_at,
            completed_this_run=processed,
            current_absolute=int(state.get("next_project_index", next_project_index)),
            total_for_timing=len(project_urls),
            extra={
                "next_project_index": int(state.get("next_project_index", next_project_index)),
                "repeat": max(1, repeat),
                "request_interval_sec": request_interval_sec,
                "processed_projects": max(_read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids)),
                "total_project_urls": len(project_urls),
                "pending_project_urls": state.get("pending_project_urls", []),
                "linked_report_pages": state.get("linked_report_pages", linked_report_pages),
                "fetched_report_pages": state.get("fetched_report_pages", fetched_report_pages),
            },
        )

    _emit_prepare_progress(
        "kaken",
        "resume",
        next_project_index=next_project_index,
        total_project_urls=len(project_urls),
        pending_project_urls=len(pending_project_urls),
    )

    retry_queue = [
        project_url
        for project_url in pending_project_urls
        if (project_id := _extract_kaken_project_id(project_url)) is None or project_id not in seen_project_ids
    ]
    pending_project_urls = []
    state["pending_project_urls"] = pending_project_urls

    for retry_index, project_url in enumerate(retry_queue):
        if max_projects_per_run is not None and processed >= max_projects_per_run:
            pending_project_urls.extend(retry_queue[retry_index:])
            state["pending_project_urls"] = pending_project_urls
            break
        project_id = _extract_kaken_project_id(project_url)
        if project_id and project_id in seen_project_ids:
            continue
        try:
            records, project_metadata = _build_kaken_project_records(project_url)
        except Exception:
            pending_project_urls.append(project_url)
            state["pending_project_urls"] = pending_project_urls
            write_progress(completed=False)
            continue
        if not records:
            pending_project_urls.append(project_url)
            state["pending_project_urls"] = pending_project_urls
            write_progress(completed=False)
            continue
        for record in records:
            writer.write(record)
        if project_id:
            _append_seen_id(seen_project_ids_path, project_id)
            seen_project_ids.add(project_id)
        processed += 1
        linked_report_pages += int(project_metadata.get("linked_report_count", 0) or 0)
        fetched_report_pages += int(project_metadata.get("fetched_report_count", 0) or 0)
        state["processed_projects"] = max(processed_before_run + processed, len(seen_project_ids))
        state["last_project_id"] = project_metadata.get("project_id")
        state["last_title"] = project_metadata.get("title")
        state["last_url"] = project_url
        state["linked_report_pages"] = linked_report_pages
        state["fetched_report_pages"] = fetched_report_pages
        state["pending_project_urls"] = pending_project_urls
        if _should_emit_progress(processed, every=10):
            _emit_prepare_progress(
                "kaken",
                "progress",
                processed=state["processed_projects"],
                current=_format_progress_fraction(int(state["processed_projects"]), len(project_urls)),
                title=project_metadata.get("title"),
                project_url=project_url,
                pending_project_urls=len(pending_project_urls),
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed,
                    current_absolute=int(state.get("processed_projects", 0)),
                    total=len(project_urls),
                ),
            )
        write_progress(completed=False)
        if request_interval_sec > 0:
            time.sleep(request_interval_sec)

    for current_project_index in range(next_project_index, len(project_urls)):
        if max_projects_per_run is not None and processed >= max_projects_per_run:
            break
        project_url = project_urls[current_project_index]
        project_id = _extract_kaken_project_id(project_url)
        state["next_project_index"] = current_project_index + 1
        if project_id and project_id in seen_project_ids:
            state["processed_projects"] = max(_read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids))
            write_progress(completed=False)
            continue
        if _should_emit_progress(current_project_index + 1, every=10):
            _emit_prepare_progress(
                "kaken",
                "fetch",
                current=_format_progress_fraction(current_project_index + 1, len(project_urls)),
                project_url=project_url,
            )
        try:
            records, project_metadata = _build_kaken_project_records(project_url)
        except Exception:
            pending_project_urls.append(project_url)
            state["pending_project_urls"] = pending_project_urls
            write_progress(completed=False)
            continue
        if not records:
            pending_project_urls.append(project_url)
            state["pending_project_urls"] = pending_project_urls
            write_progress(completed=False)
            continue
        for record in records:
            writer.write(record)
        if project_id:
            _append_seen_id(seen_project_ids_path, project_id)
            seen_project_ids.add(project_id)
        processed += 1
        linked_report_pages += int(project_metadata.get("linked_report_count", 0) or 0)
        fetched_report_pages += int(project_metadata.get("fetched_report_count", 0) or 0)
        state["processed_projects"] = max(processed_before_run + processed, len(seen_project_ids))
        state["last_project_id"] = project_metadata.get("project_id")
        state["last_title"] = project_metadata.get("title")
        state["last_url"] = project_url
        state["linked_report_pages"] = linked_report_pages
        state["fetched_report_pages"] = fetched_report_pages
        state["pending_project_urls"] = pending_project_urls
        if _should_emit_progress(processed, every=10):
            _emit_prepare_progress(
                "kaken",
                "progress",
                processed=state["processed_projects"],
                current=_format_progress_fraction(int(state["processed_projects"]), len(project_urls)),
                title=project_metadata.get("title"),
                project_url=project_url,
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed,
                    current_absolute=int(state.get("processed_projects", 0)),
                    total=len(project_urls),
                ),
            )
        write_progress(completed=False)
        if request_interval_sec > 0:
            time.sleep(request_interval_sec)

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("kaken_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[SequentialCptSource(path=path, repeat=1, label="kaken_shard") for path in shard_paths],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="kaken",
            )
        ],
    )
    state["pending_project_urls"] = pending_project_urls
    state["processed_projects"] = max(_read_optional_int(state.get("processed_projects")) or 0, len(seen_project_ids))
    write_progress(completed=int(state.get("next_project_index", next_project_index)) >= len(project_urls) and not pending_project_urls)
    if pending_project_urls:
        warnings.append(f"Pending retry projects: {len(pending_project_urls)}")
    return PreparedDatasetReport(
        kind="kaken_cpt",
        source_paths=[KAKEN_SITEMAP_INDEX_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
            "seen_project_ids": str(seen_project_ids_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("kaken_*.jsonl")),
        warnings=warnings,
    )


def prepare_ndl_next_digital_library_cpt(
    *,
    output_dir: str | Path,
    max_items_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
    request_interval_sec: float = NDL_NEXT_DIGITAL_LIBRARY_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    seen_pids_path = output_dir_path / NDL_NEXT_DIGITAL_LIBRARY_SEEN_PIDS_FILENAME
    manifest_path = output_dir_path / "ndl_next_digital_library_manifest.json"
    repeated_manifest_path = output_dir_path / "ndl_next_digital_library_train_manifest.json"
    writer = JsonlShardWriter(
        output_dir=shards_dir,
        prefix="ndl_next_digital_library",
        records_per_shard=records_per_shard,
    )
    state = _read_state(state_path)
    next_pid_index = int(state.get("next_pid_index", 0))
    pending_retry_pids = cast(list[str], state.get("pending_retry_pids", []))
    seen_pids = _bootstrap_seen_ids_from_shards(
        shard_paths=sorted(shards_dir.glob("ndl_next_digital_library_*.jsonl")),
        seen_ids_path=seen_pids_path,
        metadata_key="pid",
    )
    processed_before_run = max(_read_optional_int(state.get("processed_pids")) or 0, len(seen_pids))
    processed = 0
    warnings: list[str] = []
    started_at = time.perf_counter()
    catalog_entries = _load_ndl_next_digital_library_catalog_entries()
    catalog_by_pid = {entry.pid: entry for entry in catalog_entries}
    catalog_source_urls = sorted({entry.catalog_source_url for entry in catalog_entries if entry.catalog_source_url})

    def write_progress(*, completed: bool) -> None:
        _write_progress_snapshot(
            state_path,
            state=state,
            dataset_kind="ndl_next_digital_library_cpt",
            progress_unit="pids",
            processed_items=max(_read_optional_int(state.get("processed_pids")) or 0, len(seen_pids)),
            total_items=len(catalog_entries),
            completed=completed,
            started_at=started_at,
            completed_this_run=processed,
            current_absolute=int(state.get("next_pid_index", next_pid_index)),
            total_for_timing=len(catalog_entries),
            extra={
                "next_pid_index": int(state.get("next_pid_index", next_pid_index)),
                "repeat": max(1, repeat),
                "request_interval_sec": request_interval_sec,
                "processed_pids": max(_read_optional_int(state.get("processed_pids")) or 0, len(seen_pids)),
                "total_pids": len(catalog_entries),
                "pending_retry_pids": state.get("pending_retry_pids", []),
                "catalog_source_urls": catalog_source_urls,
            },
        )

    state["catalog_source_urls"] = catalog_source_urls
    _emit_prepare_progress(
        "ndl_next_digital_library",
        "resume",
        next_pid_index=next_pid_index,
        total_pids=len(catalog_entries),
        pending_retry_pids=len(pending_retry_pids),
    )

    retry_queue = [pid for pid in pending_retry_pids if pid not in seen_pids]
    pending_retry_pids = []
    state["pending_retry_pids"] = pending_retry_pids

    for retry_index, pid in enumerate(retry_queue):
        if max_items_per_run is not None and processed >= max_items_per_run:
            pending_retry_pids.extend(retry_queue[retry_index:])
            state["pending_retry_pids"] = pending_retry_pids
            break
        entry = catalog_by_pid.get(pid)
        if entry is None:
            continue
        try:
            records = _build_ndl_next_digital_library_records(entry)
        except Exception:
            pending_retry_pids.append(pid)
            state["pending_retry_pids"] = pending_retry_pids
            write_progress(completed=False)
            continue
        if not records:
            pending_retry_pids.append(pid)
            state["pending_retry_pids"] = pending_retry_pids
            write_progress(completed=False)
            continue
        for record in records:
            writer.write(record)
        _append_seen_id(seen_pids_path, pid)
        seen_pids.add(pid)
        processed += 1
        state["processed_pids"] = max(processed_before_run + processed, len(seen_pids))
        state["last_pid"] = pid
        state["last_title"] = entry.title
        state["pending_retry_pids"] = pending_retry_pids
        if _should_emit_progress(processed, every=10):
            _emit_prepare_progress(
                "ndl_next_digital_library",
                "progress",
                processed=state["processed_pids"],
                current=_format_progress_fraction(int(state["processed_pids"]), len(catalog_entries)),
                pid=pid,
                title=entry.title,
                pending_retry_pids=len(pending_retry_pids),
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed,
                    current_absolute=int(state.get("processed_pids", 0)),
                    total=len(catalog_entries),
                ),
            )
        write_progress(completed=False)
        if request_interval_sec > 0:
            time.sleep(request_interval_sec)

    for current_pid_index, entry in enumerate(catalog_entries[next_pid_index:], start=next_pid_index):
        if max_items_per_run is not None and processed >= max_items_per_run:
            break
        pid = entry.pid
        state["next_pid_index"] = current_pid_index + 1
        if pid in seen_pids:
            state["processed_pids"] = max(_read_optional_int(state.get("processed_pids")) or 0, len(seen_pids))
            write_progress(completed=False)
            continue
        if _should_emit_progress(current_pid_index + 1, every=10):
            _emit_prepare_progress(
                "ndl_next_digital_library",
                "fetch",
                current=_format_progress_fraction(current_pid_index + 1, len(catalog_entries)),
                pid=pid,
                title=entry.title,
            )
        try:
            records = _build_ndl_next_digital_library_records(entry)
        except Exception:
            pending_retry_pids.append(pid)
            state["pending_retry_pids"] = pending_retry_pids
            write_progress(completed=False)
            continue
        if not records:
            pending_retry_pids.append(pid)
            state["pending_retry_pids"] = pending_retry_pids
            write_progress(completed=False)
            continue
        for record in records:
            writer.write(record)
        _append_seen_id(seen_pids_path, pid)
        seen_pids.add(pid)
        processed += 1
        state["processed_pids"] = max(processed_before_run + processed, len(seen_pids))
        state["last_pid"] = pid
        state["last_title"] = entry.title
        state["pending_retry_pids"] = pending_retry_pids
        if _should_emit_progress(processed, every=10):
            _emit_prepare_progress(
                "ndl_next_digital_library",
                "progress",
                processed=state["processed_pids"],
                current=_format_progress_fraction(int(state["processed_pids"]), len(catalog_entries)),
                pid=pid,
                title=entry.title,
                **_progress_timing_fields(
                    started_at=started_at,
                    completed_this_run=processed,
                    current_absolute=int(state.get("processed_pids", 0)),
                    total=len(catalog_entries),
                ),
            )
        write_progress(completed=False)
        if request_interval_sec > 0:
            time.sleep(request_interval_sec)

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("ndl_next_digital_library_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=path, repeat=1, label="ndl_next_digital_library_shard")
            for path in shard_paths
        ],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="ndl_next_digital_library",
            )
        ],
    )
    state["processed_pids"] = max(_read_optional_int(state.get("processed_pids")) or 0, len(seen_pids))
    state["pending_retry_pids"] = pending_retry_pids
    write_progress(completed=int(state.get("next_pid_index", next_pid_index)) >= len(catalog_entries) and not pending_retry_pids)
    if pending_retry_pids:
        warnings.append(f"Pending retry PIDs: {len(pending_retry_pids)}")
    return PreparedDatasetReport(
        kind="ndl_next_digital_library_cpt",
        source_paths=catalog_source_urls or [NDL_NEXT_DIGITAL_LIBRARY_DATASET_PAGE_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
            "seen_pids": str(seen_pids_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("ndl_next_digital_library_*.jsonl")),
        warnings=warnings,
    )


def prepare_github_repositories_cpt(
    *,
    output_dir: str | Path,
    min_stars: int = GITHUB_MIN_STARS,
    max_repos_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 1,
    request_interval_sec: float = GITHUB_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    processed_repos_path = output_dir_path / "processed_repo_names.txt"
    manifest_path = output_dir_path / "github_repositories_manifest.json"
    repeated_manifest_path = output_dir_path / "github_repositories_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="github_repositories", records_per_shard=records_per_shard)
    processed_repo_names = _load_seen_ids(processed_repos_path)
    state = _read_state(state_path)
    processed_repositories_this_run = 0
    completed_scan = True
    warnings: list[str] = []

    try:
        for repository in _iter_github_repositories(min_stars=min_stars):
            full_name = str(repository.get("full_name", "")).strip()
            if not full_name or full_name in processed_repo_names:
                continue
            if max_repos_per_run is not None and processed_repositories_this_run >= max_repos_per_run:
                completed_scan = False
                break
            record_count = 0
            try:
                for record in _iter_github_repository_records(repository):
                    writer.write(record)
                    record_count += 1
            except Exception:
                _append_seen_id(processed_repos_path, full_name)
                processed_repo_names.add(full_name)
                if request_interval_sec > 0:
                    time.sleep(request_interval_sec)
                continue
            _append_seen_id(processed_repos_path, full_name)
            processed_repo_names.add(full_name)
            if record_count:
                processed_repositories_this_run += 1
            if request_interval_sec > 0:
                time.sleep(request_interval_sec)
    except GitHubRateLimitError as exc:
        completed_scan = False
        warnings.append(str(exc))

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("github_repositories_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(path=path, repeat=1, label="github_repositories_shard")
            for path in shard_paths
        ],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="github_repositories",
            )
        ],
    )
    if not os.environ.get("GITHUB_TOKEN"):
        warnings.append(
            "GITHUB_TOKEN is not set. GitHub Search API rate limits will be much lower, so full discovery will be slow."
        )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="github_repositories_cpt",
        progress_unit="repositories",
        processed_items=len(processed_repo_names),
        total_items=None,
        completed=completed_scan,
        extra={
            "min_stars": max(min_stars, 0),
            "repeat": max(1, repeat),
            "request_interval_sec": request_interval_sec,
            "processed_repo_count": len(processed_repo_names),
            "completed_last_scan": completed_scan,
        },
    )
    return PreparedDatasetReport(
        kind="github_repositories_cpt",
        source_paths=[GITHUB_SEARCH_API_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
            "processed_repos": str(processed_repos_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("github_repositories_*.jsonl")),
        warnings=warnings,
    )


def prepare_kokkai_cpt(
    *,
    output_dir: str | Path,
    max_meetings_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 1,
    session_from: int = KOKKAI_DEFAULT_SESSION_FROM,
    session_to: int = KOKKAI_DEFAULT_SESSION_TO,
    request_interval_sec: float = KOKKAI_DEFAULT_REQUEST_INTERVAL_SEC,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    manifest_path = output_dir_path / "kokkai_manifest.json"
    repeated_manifest_path = output_dir_path / "kokkai_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="kokkai", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    if state.get("api_mode") != KOKKAI_API_MODE:
        state = {}
    next_start_record = int(state.get("next_start_record", 1))
    processed = 0
    total_records = int(state.get("total_records", 0) or 0)
    completed = bool(state.get("completed", False))
    _emit_prepare_progress(
        "kokkai",
        "resume",
        next_start_record=next_start_record,
        total_records=total_records or None,
        session_from=session_from,
        session_to=session_to,
        completed=completed,
    )

    if completed:
        next_start_record = int(state.get("next_start_record", next_start_record))
    else:
        while max_meetings_per_run is None or processed < max_meetings_per_run:
            remaining = None
            if max_meetings_per_run is not None:
                remaining = max_meetings_per_run - processed
                if remaining <= 0:
                    break
            maximum_records = min(10, remaining) if remaining is not None else 10
            payload = _fetch_kokkai_meeting_batch(
                start_record=next_start_record,
                maximum_records=maximum_records,
                session_from=session_from,
                session_to=session_to,
            )
            payload_total = payload.get("numberOfRecords")
            if isinstance(payload_total, int):
                total_records = payload_total
            raw_records = cast(list[dict[str, Any]], payload.get("meetingRecord", []))
            if not raw_records:
                completed = True
                break

            batch_start_record = next_start_record
            consumed_records = 0
            stop_after_batch = False
            for offset, meeting_record in enumerate(raw_records):
                consumed_records = offset + 1
                records = _build_kokkai_cpt_records(meeting_record)
                if records:
                    for record in records:
                        writer.write(record)
                    processed += 1
                    if _should_emit_progress(processed, every=10):
                        _emit_prepare_progress(
                            "kokkai",
                            "progress",
                            processed=processed,
                            next_start_record=batch_start_record + consumed_records,
                            total_records=total_records or None,
                            meeting=meeting_record.get("nameOfMeeting"),
                            date=meeting_record.get("date"),
                            meeting_url=meeting_record.get("meetingURL"),
                        )
                if max_meetings_per_run is not None and processed >= max_meetings_per_run:
                    stop_after_batch = True
                    break

            next_position = payload.get("nextRecordPosition")
            if stop_after_batch:
                next_start_record = batch_start_record + consumed_records
                break
            if isinstance(next_position, int):
                next_start_record = next_position
            else:
                next_start_record = batch_start_record + len(raw_records)
                completed = True
                break
            if request_interval_sec > 0:
                time.sleep(request_interval_sec)

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("kokkai_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[SequentialCptSource(path=path, repeat=1, label="kokkai_shard") for path in shard_paths],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="kokkai",
            )
        ],
    )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="kokkai_cpt",
        progress_unit="meetings",
        processed_items=processed,
        total_items=total_records or None,
        completed=completed,
        extra={
            "next_start_record": next_start_record,
            "api_mode": KOKKAI_API_MODE,
            "session_from": session_from,
            "session_to": session_to,
            "request_interval_sec": request_interval_sec,
            "total_records": total_records,
        },
    )
    return PreparedDatasetReport(
        kind="kokkai_cpt",
        source_paths=[KOKKAI_MEETING_API_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("kokkai_*.jsonl")),
        warnings=[],
    )


def _iter_aozora_public_domain_works() -> Iterator[dict[str, str]]:
    payload = _http_get_bytes(AOZORA_LIST_URL, timeout_sec=120.0)
    archive = zipfile.ZipFile(io.BytesIO(payload))
    first_name = archive.namelist()[0]
    csv_text = archive.read(first_name).decode("utf-8")
    reader = csv.DictReader(csv_text.splitlines())
    for row in reader:
        if row.get("作品著作権フラグ") != "なし":
            continue
        if not row.get("テキストファイルURL"):
            continue
        yield {str(key): str(value) for key, value in row.items() if key is not None and value is not None}


def _download_aozora_body(text_url: str) -> str:
    payload = _http_get_bytes(text_url, timeout_sec=120.0)
    if text_url.endswith(".zip"):
        archive = zipfile.ZipFile(io.BytesIO(payload))
        first_name = archive.namelist()[0]
        raw = archive.read(first_name)
    else:
        raw = payload
    for encoding in ("utf-8", "cp932", "shift_jis"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise UnicodeDecodeError("aozora", b"", 0, 1, "Unable to decode Aozora text.")


def _clean_aozora_body(text: str, *, title: str | None = None) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    normalized = _drop_aozora_guide_block(normalized)
    normalized = re.sub(r"《[^》]*》", "", normalized)
    normalized = normalized.replace("｜", "")
    normalized = re.sub(r"［＃.*?］", "", normalized)
    normalized = normalized.strip()
    for marker in AOZORA_FOOTER_MARKERS:
        marker_index = normalized.find(marker)
        if marker_index >= 0:
            normalized = normalized[:marker_index].rstrip()
            break
    lines = [line.rstrip() for line in normalized.splitlines()]
    filtered_lines = [
        line
        for line in lines
        if line and not re.fullmatch(r"[一二三四五六七八九〇零\d]{4}年.*", line)
    ]
    filtered_lines = _drop_aozora_leading_metadata_lines(filtered_lines, title=title)
    if filtered_lines and filtered_lines[0] == AOZORA_IMPERIAL_CONSTITUTION_TITLE:
        filtered_lines = filtered_lines[1:]
    return _normalize_space("\n".join(filtered_lines))


def _drop_aozora_guide_block(text: str) -> str:
    lines = text.splitlines()
    dash_indexes = [
        index
        for index, line in enumerate(lines[:40])
        if re.fullmatch(r"-{20,}", line.strip())
    ]
    if len(dash_indexes) >= 2 and dash_indexes[0] <= 12:
        return "\n".join(lines[dash_indexes[1] + 1 :])
    return text


def _drop_aozora_leading_metadata_lines(
    lines: Sequence[str],
    *,
    title: str | None,
) -> list[str]:
    trimmed_lines = [line.strip() for line in lines if line.strip()]
    if title:
        while trimmed_lines and trimmed_lines[0] == title:
            trimmed_lines.pop(0)
    dropped_metadata = 0
    while trimmed_lines and dropped_metadata < 3:
        if not _looks_like_aozora_metadata_line(trimmed_lines[0]):
            break
        trimmed_lines.pop(0)
        dropped_metadata += 1
    return trimmed_lines


def _looks_like_aozora_metadata_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or stripped.startswith("　") or len(stripped) > 80:
        return False
    if any(punctuation in stripped for punctuation in ("。", "、", "！", "？", "「", "」", "『", "』")):
        return False
    if any(marker in stripped for marker in ("訳", "編纂", "校訂", "著", "作", "詩", "補")):
        return True
    if re.search(r"[A-Za-z]", stripped):
        return True
    return len(stripped) <= 30


def _modernize_aozora_text(text: str) -> str:
    modernized = text.translate(AOZORA_OLD_TO_NEW_MAP)
    return _normalize_space(modernized)


def _fetch_wikipedia_page_batch(
    *,
    language: str,
    continuation: dict[str, Any] | None,
) -> dict[str, Any]:
    params: dict[str, Any] = {
        "action": "query",
        "format": "json",
        "generator": "allpages",
        "gapnamespace": 0,
        "gaplimit": 50,
        "prop": "extracts|info|pageimages|revisions",
        "explaintext": 1,
        "exlimit": "max",
        "exintro": 0,
        "inprop": "url",
        "pilimit": "max",
        "piprop": "thumbnail|name|original",
        "pithumbsize": WIKIPEDIA_IMAGE_THUMBNAIL_WIDTH,
        "rvprop": "ids|timestamp",
    }
    if continuation:
        params.update(continuation)
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(WIKIPEDIA_API_URL_TEMPLATE.format(language=language), params=params)
        response.raise_for_status()
        return cast(dict[str, Any], response.json())


def _fetch_wikipedia_page_by_id(
    *,
    language: str,
    pageid: str,
) -> dict[str, Any] | None:
    params: dict[str, Any] = {
        "action": "query",
        "format": "json",
        "pageids": pageid,
        "prop": "extracts|info|pageimages|revisions",
        "explaintext": 1,
        "exintro": 0,
        "inprop": "url",
        "piprop": "thumbnail|name|original",
        "pithumbsize": WIKIPEDIA_IMAGE_THUMBNAIL_WIDTH,
        "rvprop": "ids|timestamp",
    }
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(WIKIPEDIA_API_URL_TEMPLATE.format(language=language), params=params)
        response.raise_for_status()
        payload = cast(dict[str, Any], response.json())
    pages = cast(dict[str, Any], payload.get("query", {}).get("pages", {}))
    page = pages.get(str(pageid))
    if isinstance(page, dict) and "missing" not in page:
        return page
    return None


def _fetch_wikipedia_recent_changes_batch(
    *,
    language: str,
    start_timestamp: str,
    continuation: dict[str, Any] | None,
) -> dict[str, Any]:
    params: dict[str, Any] = {
        "action": "query",
        "format": "json",
        "list": "recentchanges",
        "rcnamespace": 0,
        "rctype": "new|edit",
        "rclimit": 50,
        "rcdir": "newer",
        "rcstart": start_timestamp,
        "rcprop": "title|ids|timestamp",
    }
    if continuation:
        params.update(continuation)
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(WIKIPEDIA_API_URL_TEMPLATE.format(language=language), params=params)
        response.raise_for_status()
        return cast(dict[str, Any], response.json())


def _fetch_wikipedia_parsed_html(
    *,
    language: str,
    pageid: str,
) -> str:
    params: dict[str, Any] = {
        "action": "parse",
        "format": "json",
        "pageid": pageid,
        "prop": "text",
    }
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(WIKIPEDIA_PARSE_API_URL_TEMPLATE.format(language=language), params=params)
        response.raise_for_status()
        payload = cast(dict[str, Any], response.json())
    parsed = cast(dict[str, Any], payload.get("parse", {}))
    text_payload = cast(dict[str, Any], parsed.get("text", {}))
    html = str(text_payload.get("*") or "").strip()
    if not html:
        raise ValueError(f"Wikipedia parse response did not include HTML for pageid={pageid}.")
    return html


def _fetch_wikipedia_article_count(language: str) -> int | None:
    params: dict[str, Any] = {
        "action": "query",
        "format": "json",
        "meta": "siteinfo",
        "siprop": "statistics",
    }
    try:
        with httpx.Client(
            follow_redirects=True,
            timeout=30.0,
            headers=_build_http_headers(),
        ) as client:
            response = client.get(WIKIPEDIA_API_URL_TEMPLATE.format(language=language), params=params)
            response.raise_for_status()
            payload = cast(dict[str, Any], response.json())
    except Exception:
        return None
    statistics = payload.get("query", {}).get("statistics", {})
    if not isinstance(statistics, dict):
        return None
    articles = statistics.get("articles")
    if isinstance(articles, int) and articles > 0:
        return articles
    return None


def _extract_wikipedia_revision_timestamp(page: dict[str, Any]) -> str | None:
    revisions = page.get("revisions")
    if not isinstance(revisions, list) or not revisions:
        return None
    first_revision = revisions[0]
    if not isinstance(first_revision, dict):
        return None
    timestamp = first_revision.get("timestamp")
    if isinstance(timestamp, str) and timestamp.strip():
        return timestamp.strip()
    return None


def _build_wikipedia_page_metadata(
    *,
    language: str,
    title: str,
    page: dict[str, Any],
    source_label: str,
    extra_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "source_label": source_label,
        "language": language,
        "title": title,
        "pageid": page.get("pageid"),
        "url": page.get("fullurl"),
        "lastrevid": page.get("lastrevid"),
        "touched": page.get("touched"),
        "revision_timestamp": _extract_wikipedia_revision_timestamp(page),
    }
    if extra_metadata:
        for key, value in extra_metadata.items():
            if value is not None:
                metadata[key] = value
    return metadata


def _build_wikipedia_page_records(
    *,
    language: str,
    title: str,
    body: str,
    page: dict[str, Any],
    source_label: str,
    include_images: bool,
    image_detail: Literal["high", "low", "auto"],
    extra_metadata: dict[str, Any] | None = None,
    lead_image_supervision: WikipediaLeadImageSupervision | None = None,
) -> list[dict[str, Any]]:
    metadata = _build_wikipedia_page_metadata(
        language=language,
        title=title,
        page=page,
        source_label=source_label,
        extra_metadata=extra_metadata,
    )
    records = _build_chunked_cpt_records(
        title=title,
        body=body,
        focus=["knowledge"],
        metadata=metadata,
    )
    if not include_images:
        return records
    return [
        *records,
        *_build_wikipedia_image_chat_records(
            language=language,
            title=title,
            body=body,
            metadata=metadata,
            page=page,
            image_detail=image_detail,
            lead_image_supervision=lead_image_supervision,
        ),
    ]


def _extract_wikipedia_reference_urls(html: str) -> list[str]:
    extractor = _WikipediaReferenceLinkExtractor()
    extractor.feed(html)
    extracted_urls: list[str] = []
    seen_urls: set[str] = set()
    for url in extractor.links():
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            continue
        normalized_url = url.strip()
        if normalized_url in seen_urls:
            continue
        seen_urls.add(normalized_url)
        extracted_urls.append(normalized_url)
    return extracted_urls


def _extract_html_title(html: str) -> str:
    match = re.search(r"<title\b[^>]*>(.*?)</title>", html, flags=re.IGNORECASE | re.DOTALL)
    if match is None:
        return ""
    return _clean_html_fragment_to_text(match.group(1))


def _fetch_reference_document(url: str) -> WikipediaReferenceDocument:
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(url)
        response.raise_for_status()
        content_type = str(response.headers.get("content-type") or "").strip().lower()
        final_url = str(response.url)
        if "pdf" in content_type or final_url.lower().endswith(".pdf"):
            text_parts: list[str] = []
            reader = PdfReader(io.BytesIO(response.content))
            for page in reader.pages:
                extracted = _normalize_space(page.extract_text() or "")
                if extracted:
                    text_parts.append(extracted)
            text = _normalize_space("\n\n".join(text_parts))
            title = Path(urlparse(final_url).path).name or final_url
            return WikipediaReferenceDocument(
                url=url,
                final_url=final_url,
                title=title,
                text=text,
                content_type=content_type or "application/pdf",
                source_format="pdf",
            )
        raw_text = response.text
    cleaned_text = _clean_html_fragment_to_text(raw_text)
    title = _extract_html_title(raw_text) or Path(urlparse(final_url).path).name or final_url
    source_format: Literal["html", "pdf", "text"] = "html"
    if "html" not in content_type and "xml" not in content_type:
        source_format = "text"
    return WikipediaReferenceDocument(
        url=url,
        final_url=final_url,
        title=title,
        text=cleaned_text,
        content_type=content_type or "text/plain",
        source_format=source_format,
    )


def _normalize_reference_url_key(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme not in {"http", "https"}:
        return url.strip()
    normalized_path = parsed.path or "/"
    normalized_query = parsed.query
    return parsed._replace(path=normalized_path, fragment="", query=normalized_query).geturl()


def _reference_text_hash(*, title: str, text: str) -> str:
    normalized_title = _normalize_space(title)
    normalized_text = _normalize_space(text)
    payload = f"{normalized_title}\n\n{normalized_text}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _build_wikipedia_image_chat_records(
    *,
    language: str,
    title: str,
    body: str,
    metadata: dict[str, Any],
    page: dict[str, Any],
    image_detail: Literal["high", "low", "auto"],
    lead_image_supervision: WikipediaLeadImageSupervision | None,
) -> list[dict[str, Any]]:
    image_url = _extract_wikipedia_image_url(page)
    if image_url is None:
        return []
    blocks = _split_text_into_blocks(body)
    sections = _group_text_blocks_into_sections(
        header=title,
        blocks=blocks,
        max_chars=JAPANESE_LONG_RECORD_MAX_CHARS,
    )
    if not sections:
        return []
    records: list[dict[str, Any]] = []
    if lead_image_supervision is not None:
        records.append(
            {
                "task_type": "chat_sft",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "input_image",
                                "image_url": image_url,
                                "detail": image_detail,
                            },
                            {
                                "type": "text",
                                "text": _wikipedia_image_caption_prompt(language),
                            },
                        ],
                    },
                    {
                        "role": "assistant",
                        "content": lead_image_supervision.supervision_text,
                    },
                ],
                "focus": ["knowledge", "multimodal", "vision"],
                "metadata": {
                    **metadata,
                    "lead_image_url": image_url,
                    "lead_image_name": page.get("pageimage"),
                    "lead_image_original_url": _extract_wikipedia_original_image_url(page),
                    "lead_image_title": lead_image_supervision.title,
                    "lead_image_caption": lead_image_supervision.caption,
                    "lead_image_supervision_text": lead_image_supervision.supervision_text,
                    "lead_image_supervision_kind": lead_image_supervision.supervision_kind,
                },
            }
        )
    prompt_text = _wikipedia_image_prompt(language)
    for section_index, section_text in enumerate(sections, start=1):
        section_metadata = {
            **metadata,
            "lead_image_url": image_url,
            "lead_image_name": page.get("pageimage"),
            "lead_image_original_url": _extract_wikipedia_original_image_url(page),
        }
        if lead_image_supervision is not None:
            section_metadata["lead_image_title"] = lead_image_supervision.title
            section_metadata["lead_image_caption"] = lead_image_supervision.caption
        if len(sections) > 1:
            section_metadata["image_part_index"] = section_index
            section_metadata["image_part_count"] = len(sections)
        records.append(
            {
                "task_type": "chat_sft",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "input_image",
                                "image_url": image_url,
                                "detail": image_detail,
                            },
                            {
                                "type": "text",
                                "text": prompt_text,
                            },
                        ],
                    },
                    {
                        "role": "assistant",
                        "content": section_text,
                    },
                ],
                "focus": ["knowledge", "multimodal", "vision"],
                "metadata": section_metadata,
            }
        )
    return records


def _extract_wikipedia_image_url(page: dict[str, Any]) -> str | None:
    thumbnail = page.get("thumbnail")
    if isinstance(thumbnail, dict):
        source = thumbnail.get("source")
        if isinstance(source, str) and source.strip():
            return source.strip()
    original = page.get("original")
    if isinstance(original, dict):
        source = original.get("source")
        if isinstance(source, str) and source.strip():
            return source.strip()
    return None


def _extract_wikipedia_original_image_url(page: dict[str, Any]) -> str | None:
    original = page.get("original")
    if not isinstance(original, dict):
        return None
    source = original.get("source")
    if isinstance(source, str) and source.strip():
        return source.strip()
    return None


def _fetch_wikipedia_lead_image_supervision(
    *,
    language: str,
    title: str,
    page: dict[str, Any],
) -> WikipediaLeadImageSupervision | None:
    if _extract_wikipedia_image_url(page) is None:
        return None
    pageid = str(page.get("pageid") or "").strip()
    if not pageid:
        return None
    page_html = _fetch_wikipedia_parsed_html(language=language, pageid=pageid)
    return _extract_wikipedia_lead_image_supervision(
        title=title,
        page=page,
        page_html=page_html,
    )


def _extract_wikipedia_lead_image_supervision(
    *,
    title: str,
    page: dict[str, Any],
    page_html: str,
) -> WikipediaLeadImageSupervision | None:
    target_image_name = _wikipedia_target_image_name(page)
    if target_image_name is None or not page_html.strip():
        return None
    extractor = _WikipediaLeadImageCaptionExtractor(target_image_name=target_image_name)
    extractor.feed(page_html)
    raw_title = _normalize_space(extractor.title or "")
    raw_caption = _normalize_space(extractor.caption or "")
    normalized_page_title = _normalize_space(title)
    if raw_caption:
        return WikipediaLeadImageSupervision(
            title=raw_title or None,
            caption=raw_caption,
            supervision_text=raw_caption,
            supervision_kind="caption",
        )
    if raw_title and raw_title != normalized_page_title and not _looks_like_filename(raw_title):
        return WikipediaLeadImageSupervision(
            title=raw_title,
            caption=None,
            supervision_text=raw_title,
            supervision_kind="title",
        )
    return None


def _wikipedia_target_image_name(page: dict[str, Any]) -> str | None:
    for raw_value in (
        str(page.get("pageimage") or ""),
        _extract_wikipedia_original_image_url(page) or "",
        _extract_wikipedia_image_url(page) or "",
    ):
        normalized = _normalize_wikipedia_image_name(raw_value)
        if normalized:
            return normalized
    return None


def _normalize_wikipedia_image_name(value: str) -> str | None:
    candidate = value.strip()
    if not candidate:
        return None
    parsed = urlparse(candidate)
    path = parsed.path or candidate
    parts = [unescape(part) for part in path.split("/") if part]
    if not parts:
        return None
    file_name = parts[-1]
    if file_name.startswith(("File:", "file:", "ファイル:")):
        file_name = file_name.split(":", 1)[1]
    if re.match(r"[0-9]+px-", file_name) and len(parts) >= 2:
        file_name = parts[-2]
    if file_name.startswith(("File:", "file:", "ファイル:")):
        file_name = file_name.split(":", 1)[1]
    normalized = file_name.replace("_", " ").strip().lower()
    return normalized or None


def _looks_like_filename(value: str) -> bool:
    lowered = value.strip().lower()
    return bool(re.search(r"\.(?:jpg|jpeg|png|gif|svg|webp|tiff|tif)$", lowered))


def _wikipedia_image_prompt(language: str) -> str:
    normalized_language = language.strip().lower()
    return WIKIPEDIA_IMAGE_PROMPTS.get(normalized_language, WIKIPEDIA_IMAGE_PROMPTS["default"])


def _wikipedia_image_caption_prompt(language: str) -> str:
    normalized_language = language.strip().lower()
    return WIKIPEDIA_IMAGE_CAPTION_PROMPTS.get(
        normalized_language,
        WIKIPEDIA_IMAGE_CAPTION_PROMPTS["default"],
    )


def _count_jsonl_records(path: Path) -> int:
    count = 0
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                count += 1
    return count


def _write_single_record_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.write_text(json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_jsonl_records(path: Path, records: Sequence[dict[str, Any]]) -> None:
    path.write_text(
        "".join(json.dumps(record, ensure_ascii=False) + "\n" for record in records),
        encoding="utf-8",
    )


def _fetch_kokkai_meeting_batch(
    *,
    start_record: int,
    maximum_records: int,
    session_from: int,
    session_to: int,
) -> dict[str, Any]:
    params: dict[str, str | int] = {
        "startRecord": max(1, start_record),
        "maximumRecords": max(1, min(10, maximum_records)),
        "sessionFrom": max(1, session_from),
        "sessionTo": max(session_from, session_to),
        "recordPacking": "json",
    }
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(),
    ) as client:
        response = client.get(KOKKAI_MEETING_API_URL, params=params)
        response.raise_for_status()
        return cast(dict[str, Any], response.json())


def _build_kokkai_cpt_records(meeting_record: dict[str, Any]) -> list[dict[str, Any]]:
    speech_records = cast(list[dict[str, Any]], meeting_record.get("speechRecord", []))
    speech_parts = [
        cleaned
        for speech_record in speech_records
        if (cleaned := _clean_kokkai_speech(str(speech_record.get("speech") or "")))
    ]
    if not speech_parts:
        return []
    header = _normalize_space(
        "\n".join(
            part
            for part in (
                str(meeting_record.get("nameOfMeeting") or "").strip(),
                str(meeting_record.get("issue") or "").strip(),
                str(meeting_record.get("date") or "").strip(),
            )
            if part
        )
    )
    sections = _group_text_blocks_into_sections(
        header=header,
        blocks=speech_parts,
        max_chars=JAPANESE_LONG_RECORD_MAX_CHARS,
    )
    records: list[dict[str, Any]] = []
    for part_index, section_text in enumerate(sections, start=1):
        metadata = {
            "source_label": "kokkai",
            "issue_id": meeting_record.get("issueID"),
            "session": meeting_record.get("session"),
            "name_of_house": meeting_record.get("nameOfHouse"),
            "name_of_meeting": meeting_record.get("nameOfMeeting"),
            "issue": meeting_record.get("issue"),
            "date": meeting_record.get("date"),
            "meeting_url": meeting_record.get("meetingURL"),
            "pdf_url": meeting_record.get("pdfURL"),
            "image_kind": meeting_record.get("imageKind"),
            "speech_count": len(speech_parts),
            "first_speech_id": speech_records[0].get("speechID") if speech_records else None,
            "last_speech_id": speech_records[-1].get("speechID") if speech_records else None,
        }
        if len(sections) > 1:
            metadata["meeting_part_index"] = part_index
            metadata["meeting_part_count"] = len(sections)
        records.append(
            {
                "task_type": "cpt",
                "text": section_text,
                "focus": ["knowledge", "style"],
                "metadata": metadata,
            }
        )
    return records


def _clean_kokkai_speech(text: str) -> str:
    normalized = _normalize_space(text)
    normalized = re.sub(r"\n[ \t]*\n[ \t]*\n+", "\n\n", normalized)
    return normalized.strip()


def prepare_pixiv_dictionary_cpt(
    *,
    output_dir: str | Path,
    max_articles_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 1,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    state_path = output_dir_path / "progress.json"
    manifest_path = output_dir_path / "pixiv_dictionary_manifest.json"
    repeated_manifest_path = output_dir_path / "pixiv_dictionary_train_manifest.json"
    writer = JsonlShardWriter(output_dir=shards_dir, prefix="pixiv_dictionary", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    sitemap_index = int(state.get("sitemap_index", 0))
    url_index = int(state.get("url_index", 0))
    processed = 0
    sitemap_urls = _load_sitemap_index_urls(PIXIV_DICTIONARY_SITEMAP_INDEX_URL)
    _emit_prepare_progress(
        "pixiv_dictionary",
        "resume",
        sitemap_index=sitemap_index,
        url_index=url_index,
        sitemap_count=len(sitemap_urls),
    )

    for current_sitemap_index in range(sitemap_index, len(sitemap_urls)):
        article_urls = _load_urlset_urls(sitemap_urls[current_sitemap_index])
        start_url_index = url_index if current_sitemap_index == sitemap_index else 0
        for current_url_index in range(start_url_index, len(article_urls)):
            if max_articles_per_run is not None and processed >= max_articles_per_run:
                state["sitemap_index"] = current_sitemap_index
                state["url_index"] = current_url_index
                break
            article_url = article_urls[current_url_index]
            if _should_emit_progress(current_url_index + 1, every=10):
                _emit_prepare_progress(
                    "pixiv_dictionary",
                    "fetch",
                    sitemap=_format_progress_fraction(current_sitemap_index + 1, len(sitemap_urls)),
                    url_index=_format_progress_fraction(current_url_index + 1, len(article_urls)),
                    article_url=article_url,
                )
            try:
                record = _build_pixiv_dictionary_record(article_url)
            except Exception:
                continue
            if record is None:
                continue
            writer.write(record)
            processed += 1
            state["sitemap_index"] = current_sitemap_index
            state["url_index"] = current_url_index + 1
            if _should_emit_progress(processed, every=10):
                _emit_prepare_progress(
                    "pixiv_dictionary",
                    "progress",
                    processed=processed,
                    sitemap_index=current_sitemap_index,
                    url_index=current_url_index + 1,
                    title=record.get("metadata", {}).get("title"),
                    article_url=article_url,
                )
        else:
            state["sitemap_index"] = current_sitemap_index + 1
            state["url_index"] = 0
            continue
        break

    writer.close()
    shard_paths = sorted(str(path) for path in shards_dir.glob("pixiv_dictionary_*.jsonl"))
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[SequentialCptSource(path=path, repeat=1, label="pixiv_dictionary_shard") for path in shard_paths],
    )
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(manifest_path),
                repeat=max(1, repeat),
                label="pixiv_dictionary",
            )
        ],
    )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="pixiv_dictionary_cpt",
        progress_unit="articles",
        processed_items=processed,
        total_items=None,
        completed=int(state.get("sitemap_index", 0)) >= len(sitemap_urls),
        extra={
            "processed_articles": processed,
            "completed": int(state.get("sitemap_index", 0)) >= len(sitemap_urls),
        },
    )
    return PreparedDatasetReport(
        kind="pixiv_dictionary_cpt",
        source_paths=[PIXIV_DICTIONARY_SITEMAP_INDEX_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "base_manifest": str(manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.glob("pixiv_dictionary_*.jsonl")),
        warnings=[],
    )


def prepare_kotobank_cpt(
    *,
    output_dir: str | Path,
    max_articles_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
    repeat: int = 2,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_root = output_dir_path / "dictionary_shards"
    state_path = output_dir_path / "progress.json"
    sitemap_manifest_path = output_dir_path / "kotobank_manifest.json"
    repeated_manifest_path = output_dir_path / "kotobank_train_manifest.json"
    state = _read_state(state_path)
    sitemap_urls = _load_sitemap_index_urls(KOTOBANK_SITEMAP_INDEX_URL)
    sitemap_index = int(state.get("sitemap_index", 0))
    url_index = int(state.get("url_index", 0))
    processed = 0
    _emit_prepare_progress(
        "kotobank",
        "resume",
        sitemap_index=sitemap_index,
        url_index=url_index,
        sitemap_count=len(sitemap_urls),
    )

    for current_sitemap_index in range(sitemap_index, len(sitemap_urls)):
        word_urls = _load_urlset_urls(sitemap_urls[current_sitemap_index])
        start_url_index = url_index if current_sitemap_index == sitemap_index else 0
        for current_url_index in range(start_url_index, len(word_urls)):
            if max_articles_per_run is not None and processed >= max_articles_per_run:
                state["sitemap_index"] = current_sitemap_index
                state["url_index"] = current_url_index
                break
            if _should_emit_progress(current_url_index + 1, every=10):
                _emit_prepare_progress(
                    "kotobank",
                    "fetch",
                    sitemap=_format_progress_fraction(current_sitemap_index + 1, len(sitemap_urls)),
                    url_index=_format_progress_fraction(current_url_index + 1, len(word_urls)),
                    word_url=word_urls[current_url_index],
                )
            try:
                entries = _extract_kotobank_records(word_urls[current_url_index])
            except Exception:
                continue
            if not entries:
                continue
            for dictionary_key, record in entries:
                writer = JsonlShardWriter(
                    output_dir=shards_root / dictionary_key,
                    prefix=dictionary_key,
                    records_per_shard=records_per_shard,
                )
                writer.write(record)
                writer.close()
            processed += 1
            state["sitemap_index"] = current_sitemap_index
            state["url_index"] = current_url_index + 1
            if _should_emit_progress(processed, every=10):
                dictionary_names = ",".join(sorted(dictionary_key for dictionary_key, _ in entries))
                _emit_prepare_progress(
                    "kotobank",
                    "progress",
                    processed=processed,
                    sitemap_index=current_sitemap_index,
                    url_index=current_url_index + 1,
                    dictionaries=dictionary_names,
                    word_url=word_urls[current_url_index],
                )
        else:
            state["sitemap_index"] = current_sitemap_index + 1
            state["url_index"] = 0
            continue
        break

    dictionary_manifests: list[SequentialCptSource] = []
    for dictionary_dir in sorted(path for path in shards_root.glob("*") if path.is_dir()):
        shard_paths = sorted(str(path) for path in dictionary_dir.glob("*.jsonl"))
        if not shard_paths:
            continue
        dictionary_manifest_path = output_dir_path / f"{dictionary_dir.name}_manifest.json"
        write_sequential_cpt_manifest(
            dictionary_manifest_path,
            datasets=[
                SequentialCptSource(path=path, repeat=max(1, repeat), label=dictionary_dir.name)
                for path in shard_paths
            ],
        )
        dictionary_manifests.append(
            SequentialCptSource(
                path=str(dictionary_manifest_path),
                repeat=1,
                label=dictionary_dir.name,
            )
        )
    write_sequential_cpt_manifest(sitemap_manifest_path, datasets=dictionary_manifests)
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[SequentialCptSource(path=str(sitemap_manifest_path), repeat=1, label="kotobank_all")],
    )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="kotobank_cpt",
        progress_unit="articles",
        processed_items=processed,
        total_items=None,
        completed=int(state.get("sitemap_index", 0)) >= len(sitemap_urls),
        extra={
            "processed_articles": processed,
            "completed": int(state.get("sitemap_index", 0)) >= len(sitemap_urls),
        },
    )
    total_records = sum(_count_jsonl_records(path) for path in shards_root.rglob("*.jsonl"))
    return PreparedDatasetReport(
        kind="kotobank_cpt",
        source_paths=[KOTOBANK_SITEMAP_INDEX_URL],
        output_paths={
            "dictionary_shards_dir": str(shards_root),
            "base_manifest": str(sitemap_manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=total_records,
        warnings=[],
    )


def prepare_pixiv_novels_cpt(
    *,
    output_dir: str | Path,
    min_bookmark_count: int = PIXIV_NOVEL_MIN_BOOKMARKS,
    max_items_per_run: int | None = None,
    records_per_shard: int = DEFAULT_SHARD_RECORDS,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    shards_dir = output_dir_path / "shards"
    bonus_shards_dir = output_dir_path / "original_bonus_shards"
    state_path = output_dir_path / "progress.json"
    seen_novels_path = output_dir_path / "seen_novel_ids.txt"
    seen_users_path = output_dir_path / "seen_user_ids.txt"
    base_manifest_path = output_dir_path / "pixiv_novels_manifest.json"
    bonus_manifest_path = output_dir_path / "pixiv_novels_original_bonus_manifest.json"
    repeated_manifest_path = output_dir_path / "pixiv_novels_train_manifest.json"

    writer = JsonlShardWriter(output_dir=shards_dir, prefix="pixiv_novels", records_per_shard=records_per_shard)
    bonus_writer = JsonlShardWriter(output_dir=bonus_shards_dir, prefix="pixiv_novels_original_bonus", records_per_shard=records_per_shard)
    state = _read_state(state_path)
    ranking_tasks = cast(list[dict[str, Any]], state.get("ranking_tasks", _default_pixiv_ranking_tasks()))
    pending_user_ids = cast(list[str], state.get("pending_user_ids", []))
    seen_novel_ids = _load_seen_ids(seen_novels_path)
    seen_user_ids = _load_seen_ids(seen_users_path)
    processed = 0
    _emit_prepare_progress(
        "pixiv_novels",
        "resume",
        ranking_tasks=len(ranking_tasks),
        pending_user_ids=len(pending_user_ids),
        seen_novels=len(seen_novel_ids),
        seen_users=len(seen_user_ids),
        min_bookmark_count=min_bookmark_count,
    )

    while max_items_per_run is None or processed < max_items_per_run:
        if pending_user_ids:
            user_id = pending_user_ids.pop(0)
            if user_id in seen_user_ids:
                continue
            seen_user_ids.add(user_id)
            _append_seen_id(seen_users_path, user_id)
            for novel_id in _load_pixiv_user_novel_ids(user_id):
                if novel_id in seen_novel_ids:
                    continue
                if _should_emit_progress(processed + 1, every=5):
                    _emit_prepare_progress(
                        "pixiv_novels",
                        "fetch",
                        current_user_id=user_id,
                        novel_id=novel_id,
                        pending_user_ids=len(pending_user_ids),
                        ranking_tasks=len(ranking_tasks),
                    )
                processed += _try_write_pixiv_novel_record(
                    novel_id=novel_id,
                    min_bookmark_count=min_bookmark_count,
                    writer=writer,
                    bonus_writer=bonus_writer,
                    seen_novel_ids=seen_novel_ids,
                    seen_novels_path=seen_novels_path,
                )
                if _should_emit_progress(processed, every=5):
                    _emit_prepare_progress(
                        "pixiv_novels",
                        "progress",
                        processed=processed,
                        current_user_id=user_id,
                        pending_user_ids=len(pending_user_ids),
                        ranking_tasks=len(ranking_tasks),
                    )
                if max_items_per_run is not None and processed >= max_items_per_run:
                    break
            continue
        if not ranking_tasks:
            break
        task = ranking_tasks.pop(0)
        ranking_items, has_next = _load_pixiv_ranking_items(mode=str(task["mode"]), page=int(task["page"]))
        if has_next:
            ranking_tasks.append({"mode": task["mode"], "page": int(task["page"]) + 1})
        for item in ranking_items:
            novel_id = str(item.get("id", "")).strip()
            user_id = str(item.get("user_id", "")).strip()
            if user_id and user_id not in seen_user_ids:
                pending_user_ids.append(user_id)
            if not novel_id or novel_id in seen_novel_ids:
                continue
            if _should_emit_progress(processed + 1, every=5):
                _emit_prepare_progress(
                    "pixiv_novels",
                    "fetch",
                    novel_id=novel_id,
                    current_user_id=user_id,
                    pending_user_ids=len(pending_user_ids),
                    ranking_tasks=len(ranking_tasks),
                )
            processed += _try_write_pixiv_novel_record(
                novel_id=novel_id,
                min_bookmark_count=min_bookmark_count,
                writer=writer,
                bonus_writer=bonus_writer,
                seen_novel_ids=seen_novel_ids,
                seen_novels_path=seen_novels_path,
            )
            if _should_emit_progress(processed, every=5):
                _emit_prepare_progress(
                    "pixiv_novels",
                    "progress",
                    processed=processed,
                    current_novel_id=novel_id,
                    current_user_id=user_id,
                    pending_user_ids=len(pending_user_ids),
                    ranking_tasks=len(ranking_tasks),
                )
            if max_items_per_run is not None and processed >= max_items_per_run:
                break

    writer.close()
    bonus_writer.close()
    base_sources = [
        SequentialCptSource(path=str(path), repeat=1, label="pixiv_novels")
        for path in sorted(shards_dir.glob("pixiv_novels_*.jsonl"))
    ]
    bonus_sources = [
        SequentialCptSource(path=str(path), repeat=1, label="pixiv_novels_original_bonus")
        for path in sorted(bonus_shards_dir.glob("pixiv_novels_original_bonus_*.jsonl"))
    ]
    write_sequential_cpt_manifest(base_manifest_path, datasets=base_sources)
    if bonus_sources:
        write_sequential_cpt_manifest(bonus_manifest_path, datasets=bonus_sources)
    write_sequential_cpt_manifest(
        repeated_manifest_path,
        datasets=[
            SequentialCptSource(path=str(base_manifest_path), repeat=1, label="pixiv_novels_base"),
            SequentialCptSource(path=str(bonus_manifest_path), repeat=1, label="pixiv_novels_original_bonus"),
        ]
        if bonus_sources
        else [SequentialCptSource(path=str(base_manifest_path), repeat=1, label="pixiv_novels_base")],
    )
    _write_progress_snapshot(
        state_path,
        state=state,
        dataset_kind="pixiv_novels_cpt",
        progress_unit="novels",
        processed_items=len(seen_novel_ids),
        total_items=None,
        completed=not ranking_tasks and not pending_user_ids,
        extra={
            "ranking_tasks": ranking_tasks,
            "pending_user_ids": pending_user_ids,
            "min_bookmark_count": min_bookmark_count,
            "processed_novels": len(seen_novel_ids),
        },
    )
    return PreparedDatasetReport(
        kind="pixiv_novels_cpt",
        source_paths=[PIXIV_NOVEL_RANKING_URL],
        output_paths={
            "shards_dir": str(shards_dir),
            "bonus_shards_dir": str(bonus_shards_dir),
            "base_manifest": str(base_manifest_path),
            "manifest": str(repeated_manifest_path),
            "state": str(state_path),
        },
        total_records=sum(_count_jsonl_records(path) for path in shards_dir.rglob("*.jsonl"))
        + sum(_count_jsonl_records(path) for path in bonus_shards_dir.rglob("*.jsonl")),
        warnings=[],
    )


def _build_pixiv_dictionary_record(article_url: str) -> dict[str, Any] | None:
    html = _http_get_text(article_url, timeout_sec=60.0)
    article = _extract_pixiv_dictionary_article_payload(html)
    if article is None:
        return None
    title = _normalize_space(str(article.get("tagName", "")))
    reading = _normalize_space(str(article.get("yomigana", "")))
    abstract = _normalize_space(_strip_html_preserving_breaks(str(article.get("abstract", ""))))
    body = _normalize_space(_strip_html_preserving_breaks(str(article.get("text", ""))))
    if not title or not body:
        return None
    text_parts = [title]
    if reading:
        text_parts.append(f"読み: {reading}")
    if abstract and abstract != body and abstract not in body:
        text_parts.append(f"概要:\n{abstract}")
    text_parts.append(body)
    return {
        "task_type": "cpt",
        "text": "\n\n".join(text_parts),
        "focus": ["knowledge", "style"],
        "metadata": {
            "source_label": "pixiv_dictionary",
            "title": title,
            "reading": reading,
            "url": article_url,
        },
    }


def _extract_pixiv_dictionary_article_payload(html: str) -> dict[str, Any] | None:
    next_data = _load_next_data_payload(html)
    page_props = cast(dict[str, Any], next_data.get("props", {}).get("pageProps", {}))
    for swr_field_name in ("swrFallback", "initialSwrFallback"):
        swr = cast(dict[str, Any], page_props.get(swr_field_name, {}))
        for key, value in swr.items():
            if "/get_article" not in str(key):
                continue
            if not isinstance(value, dict):
                continue
            if value.get("tagName") and value.get("text"):
                return value
    return None


def _extract_kotobank_records(article_url: str) -> list[tuple[str, dict[str, Any]]]:
    html = _http_get_text(article_url, timeout_sec=60.0)
    article_blocks = re.findall(r"<article\b[^>]*class=\"dictype cf [^\"]+\".*?</article>", html, flags=re.DOTALL)
    records: list[tuple[str, dict[str, Any]]] = []
    for article_block in article_blocks:
        source_name = _normalize_space(_extract_first_match(article_block, r"<h2>\s*<a [^>]*>(.*?)</a>", default=""))
        dictionary_key = _slugify_dictionary_name(source_name)
        if not source_name or not dictionary_key:
            continue
        for entry_heading, description_html in re.findall(
            r"<div class=\"ex cf\">.*?<h3>(.*?)</h3>.*?<section class=\"description\">(.*?)</section>",
            article_block,
            flags=re.DOTALL,
        ):
            heading = _normalize_space(_strip_html_preserving_breaks(entry_heading))
            description = _normalize_space(_strip_html_preserving_breaks(_strip_kotobank_noise(description_html)))
            if not heading or not description:
                continue
            records.append(
                (
                    dictionary_key,
                    {
                        "task_type": "cpt",
                        "text": "\n\n".join([heading, description]),
                        "focus": ["knowledge", "style"],
                        "metadata": {
                            "source_label": "kotobank",
                            "dictionary": source_name,
                            "entry_heading": heading,
                            "url": article_url,
                        },
                    },
                )
            )
    return records


def _strip_kotobank_noise(html: str) -> str:
    stripped = re.sub(r"<div class=\"media\">.*?</div>\s*<br clear=\"all\">", "", html, flags=re.DOTALL)
    stripped = re.sub(r"更新日:.*", "", stripped)
    stripped = re.sub(r"出典.*", "", stripped)
    return stripped


def _load_next_data_payload(html: str) -> dict[str, Any]:
    match = re.search(r"<script id=\"__NEXT_DATA__\" type=\"application/json\">(.*?)</script>", html, flags=re.DOTALL)
    if match is None:
        raise ValueError("Could not locate __NEXT_DATA__ payload.")
    return cast(dict[str, Any], json.loads(match.group(1)))


def _load_sitemap_index_urls(url: str) -> list[str]:
    xml_text = _http_get_text(url, timeout_sec=120.0)
    root = ElementTree.fromstring(xml_text)
    namespace = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    return [element.text or "" for element in root.findall(".//sm:loc", namespace) if element.text]


def _load_urlset_urls(url: str) -> list[str]:
    payload = _http_get_bytes(url, timeout_sec=120.0)
    if url.endswith(".gz"):
        payload = gzip.decompress(payload)
    xml_text = payload.decode("utf-8")
    root = ElementTree.fromstring(xml_text)
    namespace = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    return [element.text or "" for element in root.findall(".//sm:loc", namespace) if element.text]


def _load_openai_developers_doc_urls() -> list[str]:
    sitemap_urls = _load_sitemap_index_urls(OPENAI_DEVELOPERS_SITEMAP_INDEX_URL)
    seen_urls: set[str] = set()
    collected_urls: list[str] = []
    for sitemap_url in sitemap_urls:
        for candidate_url in _load_urlset_urls(sitemap_url):
            normalized_url = candidate_url.strip().rstrip("/")
            if not _is_supported_openai_doc_url(normalized_url):
                continue
            if normalized_url in seen_urls:
                continue
            seen_urls.add(normalized_url)
            collected_urls.append(normalized_url)
    return collected_urls


def _is_supported_openai_doc_url(url: str) -> bool:
    if not any(url.startswith(prefix) for prefix in OPENAI_DOCS_ALLOWED_PREFIXES):
        return False
    reference_marker = "/api/reference/"
    if reference_marker in url:
        tail = url.split(reference_marker, 1)[1]
        first_segment = tail.split("/", 1)[0]
        if first_segment in OPENAI_REFERENCE_LANGUAGE_PREFIXES:
            return False
    if "/cookbook/" in url or url.endswith(".ipynb/"):
        return False
    return True


def _build_openai_docs_cpt_records(url: str) -> list[dict[str, Any]]:
    text = _load_openai_docs_text(url)
    cleaned_text = _normalize_space(text)
    if not cleaned_text:
        return []
    title = _extract_openai_doc_title(cleaned_text=cleaned_text, url=url)
    heading_prefix = f"# {title}" if title else ""
    if title and cleaned_text.startswith(heading_prefix):
        cleaned_text = _normalize_space(cleaned_text[len(heading_prefix) :])
    if title and not cleaned_text.startswith(title):
        cleaned_text = f"{title}\n\n{cleaned_text}"
    sections = _split_openai_doc_into_sections(cleaned_text)
    records: list[dict[str, Any]] = []
    for section_index, section_text in enumerate(sections, start=1):
        metadata: dict[str, Any] = {
            "source_label": "openai_docs",
            "url": url,
            "title": title,
        }
        if len(sections) > 1:
            metadata["section_index"] = section_index
            metadata["section_count"] = len(sections)
        records.append(
            {
                "task_type": "cpt",
                "text": section_text,
                "focus": ["knowledge", "style"],
                "metadata": metadata,
            }
        )
    return records


def _split_openai_doc_into_sections(text: str) -> list[str]:
    normalized = _normalize_space(text)
    if not normalized:
        return []
    if len(normalized) <= OPENAI_DOC_SECTION_MAX_CHARS:
        return [normalized]

    lines = normalized.splitlines()
    title = lines[0].strip()
    body_lines = lines[1:]
    grouped_sections: list[str] = []
    current_lines: list[str] = []

    for raw_line in body_lines:
        line = raw_line.rstrip()
        if line.startswith("## ") and current_lines:
            grouped_sections.append(_normalize_space("\n".join(current_lines)))
            current_lines = [line]
            continue
        current_lines.append(line)

    if current_lines:
        grouped_sections.append(_normalize_space("\n".join(current_lines)))

    if not grouped_sections:
        grouped_sections = [normalized]

    split_sections: list[str] = []
    for section in grouped_sections:
        if not section:
            continue
        section_text = _normalize_space(
            "\n\n".join(part for part in (title, section) if part)
        )
        split_sections.extend(
            _split_text_by_natural_blocks(
                section_text,
                max_chars=OPENAI_DOC_SECTION_MAX_CHARS,
            )
        )
    return [section for section in split_sections if section.strip()]


def _split_text_by_natural_blocks(text: str, *, max_chars: int) -> list[str]:
    normalized = _normalize_space(text)
    if not normalized:
        return []
    if len(normalized) <= max_chars:
        return [normalized]

    paragraphs = [
        paragraph.strip()
        for paragraph in re.split(r"\n\s*\n", normalized)
        if paragraph.strip()
    ]
    if len(paragraphs) <= 1:
        return _split_oversized_block(normalized, max_chars=max_chars)

    sections: list[str] = []
    current = ""
    for paragraph in paragraphs:
        candidate = paragraph if not current else f"{current}\n\n{paragraph}"
        if current and len(candidate) > max_chars:
            sections.append(current)
            current = paragraph
            continue
        if len(candidate) > max_chars:
            sections.extend(_split_oversized_block(paragraph, max_chars=max_chars))
            current = ""
            continue
        current = candidate
    if current:
        sections.append(current)
    return [_normalize_space(section) for section in sections if section.strip()]


def _split_oversized_block(text: str, *, max_chars: int) -> list[str]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) > 1:
        return _split_units_into_sections(lines, max_chars=max_chars, separator="\n")
    sentences = [segment for segment in _split_sentence_like_units(text) if segment]
    if len(sentences) > 1:
        return _split_units_into_sections(sentences, max_chars=max_chars, separator=" ")
    return _hard_split_text(text, max_chars=max_chars)


def _split_units_into_sections(
    units: Sequence[str],
    *,
    max_chars: int,
    separator: str,
) -> list[str]:
    sections: list[str] = []
    current = ""
    for unit in units:
        cleaned_unit = _normalize_space(unit)
        if not cleaned_unit:
            continue
        candidate = cleaned_unit if not current else f"{current}{separator}{cleaned_unit}"
        if current and len(candidate) > max_chars:
            sections.append(_normalize_space(current))
            current = cleaned_unit
            continue
        if len(candidate) > max_chars:
            sections.extend(_hard_split_text(cleaned_unit, max_chars=max_chars))
            current = ""
            continue
        current = candidate
    if current:
        sections.append(_normalize_space(current))
    return [section for section in sections if section]


def _split_sentence_like_units(text: str) -> list[str]:
    units = re.split(r"(?<=[。！？.!?])\s+", _normalize_space(text))
    return [unit.strip() for unit in units if unit.strip()]


def _hard_split_text(text: str, *, max_chars: int) -> list[str]:
    remaining = _normalize_space(text)
    if not remaining:
        return []
    sections: list[str] = []
    while len(remaining) > max_chars:
        cut = max_chars
        while cut > max_chars // 2 and not remaining[cut - 1].isspace():
            cut -= 1
        if cut <= max_chars // 2:
            cut = max_chars
        sections.append(_normalize_space(remaining[:cut]))
        remaining = _normalize_space(remaining[cut:])
    if remaining:
        sections.append(remaining)
    return [section for section in sections if section]


def _load_openai_docs_text(url: str) -> str:
    markdown_url = _openai_docs_markdown_url(url)
    if markdown_url is not None:
        try:
            return _clean_openai_docs_text(_http_get_text(markdown_url, timeout_sec=60.0))
        except Exception:
            pass
    html = _http_get_text(url, timeout_sec=60.0)
    main_html = _extract_openai_main_html(html)
    return _clean_openai_docs_text(_strip_html_preserving_breaks(main_html))


def _openai_docs_markdown_url(url: str) -> str | None:
    normalized_url = url.rstrip("/")
    if "/api/reference/" in normalized_url:
        return f"{normalized_url}/index.md"
    return None


def _extract_openai_main_html(html: str) -> str:
    match = re.search(r"<main\b[^>]*>(.*?)</main>", html, flags=re.IGNORECASE | re.DOTALL)
    main_html = match.group(1) if match is not None else html
    main_html = re.sub(r"<script\b.*?</script>", "", main_html, flags=re.IGNORECASE | re.DOTALL)
    main_html = re.sub(r"<style\b.*?</style>", "", main_html, flags=re.IGNORECASE | re.DOTALL)
    main_html = re.sub(r"<svg\b.*?</svg>", "", main_html, flags=re.IGNORECASE | re.DOTALL)
    main_html = re.sub(r"<(?:nav|header|footer|aside)\b.*?</(?:nav|header|footer|aside)>", "", main_html, flags=re.IGNORECASE | re.DOTALL)
    return main_html


def _extract_openai_doc_title(*, cleaned_text: str, url: str) -> str:
    first_line = cleaned_text.splitlines()[0].strip() if cleaned_text.strip() else ""
    if first_line.startswith("#"):
        return first_line.lstrip("#").strip()
    title = url.rstrip("/").rsplit("/", 1)[-1].replace("-", " ").replace("_", " ").strip()
    return title


def _clean_openai_docs_text(text: str) -> str:
    cleaned = text
    cleaned = re.sub(r"copy\s*page\s*more\s*page\s*actions", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"copy\s*page", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"more\s*page\s*actions", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"^\s*(on this page|table of contents|back to top)\s*$", "", cleaned, flags=re.IGNORECASE | re.MULTILINE)
    return _normalize_space(cleaned)


def _kaken_request_headers() -> dict[str, str]:
    return {"Accept-Language": "ja"}


def _load_kaken_project_urls() -> list[str]:
    seen_urls: set[str] = set()
    project_urls: list[str] = []
    for sitemap_url in _load_sitemap_index_urls(KAKEN_SITEMAP_INDEX_URL):
        for project_url in _load_urlset_urls(sitemap_url):
            normalized_url = project_url.strip()
            if not normalized_url or normalized_url in seen_urls:
                continue
            seen_urls.add(normalized_url)
            project_urls.append(normalized_url)
    return project_urls


def _extract_kaken_project_id(project_url: str) -> str | None:
    match = re.search(r"KAKENHI-PROJECT-([A-Za-z0-9-]+)", project_url)
    if match is None:
        return None
    project_id = match.group(1).strip()
    return project_id or None


def _build_kaken_project_records(project_url: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    html = _http_get_text(project_url, headers=_kaken_request_headers(), timeout_sec=60.0)
    title = _extract_kaken_page_heading(html) or _extract_kaken_project_id(project_url) or "KAKEN"
    base_rows = _extract_kaken_summary_rows(html)
    base_block = _normalize_space(
        "\n".join(f"{label}: {value}" for label, value in base_rows if label and value)
    )
    blocks: list[str] = [f"基礎情報\n{base_block}"] if base_block else []
    seen_blocks = {_normalize_space(block) for block in blocks if _normalize_space(block)}
    report_links = _extract_kaken_report_links(html)
    fetched_report_count = 0
    for report_url in report_links:
        report_html = _http_get_text(report_url, headers=_kaken_request_headers(), timeout_sec=60.0)
        report_title = _extract_kaken_report_title(report_html)
        for block in _build_kaken_report_blocks(report_title=report_title, rows=_extract_kaken_summary_rows(report_html)):
            normalized_block = _normalize_space(block)
            if not normalized_block or normalized_block in seen_blocks:
                continue
            seen_blocks.add(normalized_block)
            blocks.append(normalized_block)
        fetched_report_count += 1
    row_map = {label: value for label, value in base_rows if label and value}
    project_id = _extract_kaken_project_id(project_url)
    metadata = {
        "source_label": "kaken",
        "project_id": project_id,
        "title": title,
        "project_url": project_url,
        "project_number": row_map.get("研究課題/領域番号"),
        "keywords": row_map.get("キーワード"),
        "research_category": row_map.get("研究種目"),
        "research_field": row_map.get("研究分野"),
        "institution": row_map.get("研究機関"),
        "linked_report_count": len(report_links),
        "fetched_report_count": fetched_report_count,
    }
    return (
        _build_sectioned_cpt_records(
            title=title,
            blocks=blocks,
            focus=["knowledge"],
            metadata=metadata,
        ),
        metadata,
    )


def _extract_kaken_page_heading(html: str) -> str:
    heading = _extract_first_match(html, r"<div class=\"page-title project\">\s*<h1>(.*?)</h1>", default="")
    if heading:
        return _clean_html_fragment_to_text(heading)
    document_title = _extract_first_match(html, r"<title>(.*?)</title>", default="")
    return _clean_html_fragment_to_text(document_title)


def _extract_kaken_report_title(html: str) -> str:
    report_title = _extract_first_match(html, r"<div class=\"report-title\">\s*<h2>(.*?)</h2>", default="")
    return _clean_html_fragment_to_text(report_title)


def _extract_kaken_summary_rows(html: str) -> list[tuple[str, str]]:
    summary_html = _extract_first_match(
        html,
        r"<table class=\"summary-table\">(.*?)</table>",
        default="",
    )
    if not summary_html:
        return []
    rows: list[tuple[str, str]] = []
    for heading_html, value_html in re.findall(
        r"<tr[^>]*>\s*<th[^>]*>(.*?)</th>\s*<td[^>]*>(.*?)</td>\s*</tr>",
        summary_html,
        flags=re.DOTALL | re.IGNORECASE,
    ):
        heading = _clean_html_fragment_to_text(heading_html)
        value = _clean_html_fragment_to_text(value_html)
        if not heading or not value:
            continue
        rows.append((heading, value))
    return rows


def _extract_kaken_report_links(html: str) -> list[str]:
    report_links: list[str] = []
    seen_links: set[str] = set()
    for relative_url in re.findall(
        r'href="(/report/KAKENHI-PROJECT-[^"/]+/[^"/]+/)"',
        html,
        flags=re.IGNORECASE,
    ):
        absolute_url = f"https://kaken.nii.ac.jp{relative_url}"
        if absolute_url in seen_links:
            continue
        seen_links.add(absolute_url)
        report_links.append(absolute_url)
    return report_links


def _build_kaken_report_blocks(*, report_title: str, rows: Sequence[tuple[str, str]]) -> list[str]:
    report_field_names = {
        "研究実績の概要",
        "研究成果の概要",
        "現在までの達成度",
        "今後の研究の推進方策",
        "Research Progress Summary",
        "Outline of Annual Research Achievements",
        "Outline of Final Research Achievements",
        "Current Status of Research Progress",
        "Strategy for Future Research Activity",
    }
    blocks: list[str] = []
    for label, value in rows:
        if label not in report_field_names:
            continue
        block_parts = [part for part in (report_title, label, value) if _normalize_space(part)]
        block = _normalize_space("\n".join(block_parts))
        if block:
            blocks.append(block)
    return blocks


def _clean_html_fragment_to_text(fragment: str) -> str:
    cleaned = re.sub(r"<!--.*?-->", "", fragment, flags=re.DOTALL)
    cleaned = re.sub(r"<script\b.*?</script>", "", cleaned, flags=re.IGNORECASE | re.DOTALL)
    cleaned = re.sub(r"<style\b.*?</style>", "", cleaned, flags=re.IGNORECASE | re.DOTALL)
    return _strip_html_preserving_breaks(cleaned)


def _load_ndl_next_digital_library_catalog_urls() -> list[str]:
    page_html = _http_get_text(NDL_NEXT_DIGITAL_LIBRARY_DATASET_PAGE_URL, timeout_sec=120.0)
    urls = [
        *re.findall(
            r"https://dl\.ndl\.go\.jp/static/files/dataset/dataset_\d{6}_t_internet_\d{2}\.zip",
            page_html,
        ),
        *re.findall(
            r"https://dl\.ndl\.go\.jp/static/files/dataset/dataset_\d{6}_k_internet\.zip",
            page_html,
        ),
    ]
    normalized_urls: list[str] = []
    seen_urls: set[str] = set()
    for url in urls:
        if url in seen_urls:
            continue
        seen_urls.add(url)
        normalized_urls.append(url)
    if not normalized_urls:
        raise ValueError("Could not discover NDL next digital library catalog URLs.")
    return normalized_urls


def _load_ndl_next_digital_library_catalog_entries() -> list[NdlNextDigitalLibraryCatalogEntry]:
    catalog_entries: list[NdlNextDigitalLibraryCatalogEntry] = []
    seen_pids: set[str] = set()
    for catalog_url in _load_ndl_next_digital_library_catalog_urls():
        payload = _http_get_bytes(catalog_url, timeout_sec=120.0)
        archive = zipfile.ZipFile(io.BytesIO(payload))
        catalog_name = next(
            (name for name in archive.namelist() if name.lower().endswith(".tsv")),
            None,
        )
        if catalog_name is None:
            continue
        catalog_text = archive.read(catalog_name).decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(catalog_text), delimiter="\t")
        for row in reader:
            if str(row.get("公開範囲") or "").strip() != "インターネット公開":
                continue
            if str(row.get("権利区分") or "").strip() != "保護期間満了":
                continue
            pid = _extract_ndl_pid(str(row.get("永続的識別子") or ""))
            if pid is None or pid in seen_pids:
                continue
            seen_pids.add(pid)
            catalog_entries.append(
                NdlNextDigitalLibraryCatalogEntry(
                    pid=pid,
                    title=_normalize_space(str(row.get("タイトル") or "")),
                    volume=_normalize_space(str(row.get("巻次又は部編番号") or "")),
                    responsibility=_normalize_space(str(row.get("著者") or "")),
                    publisher=_normalize_space(str(row.get("出版者") or "")),
                    published=_normalize_space(str(row.get("出版日") or "")),
                    size=_normalize_space(str(row.get("容量・大きさ") or "")),
                    subjects=_normalize_space(str(row.get("件名（NDLSH）") or row.get("件名") or "")),
                    ndc=_normalize_space(
                        str(
                            row.get("分類（NDC9）")
                            or row.get("分類（NDC8）")
                            or row.get("分類（NDC）")
                            or ""
                        )
                    ),
                    collection=_normalize_space(str(row.get("コレクション") or "")),
                    catalog_source_url=catalog_url,
                )
            )
    return catalog_entries


def _extract_ndl_pid(identifier: str) -> str | None:
    match = re.search(r"info:ndljp/pid/(\d+)", identifier)
    if match is None:
        return None
    pid = match.group(1).strip()
    return pid or None


def _build_ndl_next_digital_library_records(
    entry: NdlNextDigitalLibraryCatalogEntry,
) -> list[dict[str, Any]]:
    payload = _fetch_ndl_next_digital_library_fulltext(entry.pid)
    raw_pages = cast(list[dict[str, Any]], payload.get("list", []))
    page_blocks = [
        cleaned
        for page in raw_pages
        if (cleaned := _normalize_space(str(page.get("contents") or "")))
    ]
    if not page_blocks:
        return []
    title = _build_ndl_next_digital_library_title(entry)
    metadata_block = _build_ndl_next_digital_library_metadata_block(entry)
    blocks = [metadata_block, *page_blocks] if metadata_block else page_blocks
    return _build_sectioned_cpt_records(
        title=title,
        blocks=blocks,
        focus=["knowledge", "style"],
        metadata={
            "source_label": "ndl_next_digital_library",
            "pid": entry.pid,
            "title": entry.title,
            "volume": entry.volume,
            "responsibility": entry.responsibility,
            "publisher": entry.publisher,
            "published": entry.published,
            "catalog_source_url": entry.catalog_source_url,
            "fulltext_api_url": NDL_NEXT_DIGITAL_LIBRARY_FULLTEXT_API_URL.format(pid=entry.pid),
        },
    )


def _fetch_ndl_next_digital_library_fulltext(pid: str) -> dict[str, Any]:
    text = _http_get_text(
        NDL_NEXT_DIGITAL_LIBRARY_FULLTEXT_API_URL.format(pid=pid),
        timeout_sec=120.0,
    )
    return cast(dict[str, Any], json.loads(text))


def _build_ndl_next_digital_library_title(entry: NdlNextDigitalLibraryCatalogEntry) -> str:
    return _normalize_space(" ".join(part for part in (entry.title, entry.volume) if part))


def _build_ndl_next_digital_library_metadata_block(entry: NdlNextDigitalLibraryCatalogEntry) -> str:
    lines = [
        f"著者: {entry.responsibility}" if entry.responsibility else "",
        f"出版者: {entry.publisher}" if entry.publisher else "",
        f"出版日: {entry.published}" if entry.published else "",
        f"大きさ: {entry.size}" if entry.size else "",
        f"分類: {entry.ndc}" if entry.ndc else "",
        f"件名: {entry.subjects}" if entry.subjects else "",
        f"コレクション: {entry.collection}" if entry.collection else "",
    ]
    return _normalize_space("\n".join(line for line in lines if line))


def _iter_github_repositories(*, min_stars: int) -> Iterator[dict[str, Any]]:
    max_stars = _fetch_github_max_star_count(min_stars=min_stars)
    if max_stars < min_stars:
        return
    for lower_bound, upper_bound in _split_github_star_range(lower_bound=min_stars, upper_bound=max_stars):
        page = 1
        while True:
            payload = _search_github_repositories(
                lower_bound=lower_bound,
                upper_bound=upper_bound,
                page=page,
            )
            items = cast(list[dict[str, Any]], payload.get("items", []))
            if not items:
                break
            for item in items:
                yield item
            if len(items) < 100:
                break
            page += 1


def _split_github_star_range(*, lower_bound: int, upper_bound: int) -> list[tuple[int, int]]:
    payload = _search_github_repositories(
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        page=1,
        per_page=1,
    )
    total_count = int(payload.get("total_count", 0) or 0)
    if total_count <= GITHUB_SEARCH_SEGMENT_MAX_RESULTS or lower_bound >= upper_bound:
        return [(lower_bound, upper_bound)]
    midpoint = (lower_bound + upper_bound) // 2
    if midpoint <= lower_bound:
        return [(lower_bound, upper_bound)]
    upper_segments = _split_github_star_range(lower_bound=midpoint + 1, upper_bound=upper_bound)
    lower_segments = _split_github_star_range(lower_bound=lower_bound, upper_bound=midpoint)
    return [*upper_segments, *lower_segments]


def _fetch_github_max_star_count(*, min_stars: int) -> int:
    payload = _search_github_repositories(
        lower_bound=min_stars,
        upper_bound=None,
        page=1,
        per_page=1,
        descending=True,
    )
    items = cast(list[dict[str, Any]], payload.get("items", []))
    if not items:
        return 0
    return int(items[0].get("stargazers_count", 0) or 0)


def _search_github_repositories(
    *,
    lower_bound: int,
    upper_bound: int | None,
    page: int,
    per_page: int = 100,
    descending: bool = True,
) -> dict[str, Any]:
    stars_query = (
        f"stars:{lower_bound}..{upper_bound}"
        if upper_bound is not None
        else f"stars:>={lower_bound}"
    )
    params = {
        "q": f"{stars_query} fork:false archived:false",
        "sort": "stars",
        "order": "desc" if descending else "asc",
        "per_page": max(1, min(per_page, 100)),
        "page": max(page, 1),
    }
    headers: dict[str, str] = {
        "Accept": "application/vnd.github+json",
    }
    github_token = os.environ.get("GITHUB_TOKEN")
    if github_token:
        headers["Authorization"] = f"Bearer {github_token}"
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers(headers),
    ) as client:
        for _attempt in range(5):
            response = client.get(GITHUB_SEARCH_API_URL, params=params)
            if response.status_code < 400:
                return cast(dict[str, Any], response.json())
            if response.status_code != 403 or not _github_response_is_rate_limited(response):
                response.raise_for_status()
            time.sleep(_github_rate_limit_sleep_seconds(response))
        raise GitHubRateLimitError(
            "GitHub Search API rate limit persisted after retries. "
            "Set GITHUB_TOKEN to increase the limit and continue reliably."
        )


def _github_response_is_rate_limited(response: httpx.Response) -> bool:
    body = response.text.lower()
    return "rate limit exceeded" in body or "secondary rate limit" in body


def _github_rate_limit_sleep_seconds(response: httpx.Response) -> float:
    retry_after = response.headers.get("retry-after")
    if retry_after is not None:
        try:
            return max(float(retry_after), 1.0)
        except ValueError:
            pass
    reset_header = response.headers.get("x-ratelimit-reset")
    if reset_header is not None:
        try:
            reset_epoch = float(reset_header)
            return max(reset_epoch - time.time(), 1.0) + 1.0
        except ValueError:
            pass
    return 60.0


def _iter_github_repository_records(repository: dict[str, Any]) -> Iterator[dict[str, Any]]:
    full_name = str(repository.get("full_name", "")).strip()
    owner = cast(dict[str, Any], repository.get("owner", {})).get("login")
    default_branch = str(repository.get("default_branch", "")).strip()
    repo_name = str(repository.get("name", "")).strip()
    if not full_name or not owner or not repo_name or not default_branch:
        return
    tarball_url = GITHUB_CODELOAD_TARBALL_URL.format(
        owner=str(owner),
        repo=repo_name,
        ref=default_branch,
    )
    payload = _http_get_bytes(tarball_url, timeout_sec=120.0)
    archive = tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz")
    repo_root_prefix = f"{repo_name}-{default_branch}"
    for member in archive.getmembers():
        if not member.isfile() or member.size <= 0 or member.size > GITHUB_MAX_TEXT_FILE_BYTES:
            continue
        relative_path = _normalize_github_archive_path(member.name, repo_root_prefix=repo_root_prefix)
        if relative_path is None or not _should_include_github_file(relative_path):
            continue
        extracted = archive.extractfile(member)
        if extracted is None:
            continue
        raw_bytes = extracted.read()
        content = _decode_github_text(raw_bytes)
        if content is None:
            continue
        cleaned = _normalize_space(content)
        if not cleaned:
            continue
        yield {
            "task_type": "cpt",
            "text": f"{full_name}\n{relative_path}\n\n{cleaned}",
            "focus": ["knowledge", "code", "style"],
            "metadata": {
                "source_label": "github_repositories",
                "repository": full_name,
                "stars": int(repository.get("stargazers_count", 0) or 0),
                "default_branch": default_branch,
                "file_path": relative_path,
                "repo_url": repository.get("html_url"),
                "raw_url": f"https://raw.githubusercontent.com/{full_name}/{default_branch}/{relative_path}",
            },
        }


def _normalize_github_archive_path(path: str, *, repo_root_prefix: str) -> str | None:
    parts = [part for part in path.split("/") if part]
    if not parts:
        return None
    if parts[0] == repo_root_prefix:
        parts = parts[1:]
    elif len(parts) >= 2:
        parts = parts[1:]
    if not parts:
        return None
    return "/".join(parts)


def _should_include_github_file(path: str) -> bool:
    lowered_path = path.lower()
    parts = [part.lower() for part in path.split("/") if part]
    if any(part in GITHUB_IGNORED_PATH_PARTS for part in parts[:-1]):
        return False
    file_name = parts[-1]
    if file_name.endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".pdf", ".zip", ".gz", ".tar", ".mp4", ".mp3")):
        return False
    if file_name in {"package-lock.json", "pnpm-lock.yaml", "yarn.lock", "poetry.lock", "cargo.lock"}:
        return False
    if Path(lowered_path).suffix in GITHUB_TEXT_FILE_EXTENSIONS:
        return True
    stem = Path(file_name).stem.lower()
    return stem in GITHUB_TEXT_FILENAMES


def _decode_github_text(payload: bytes) -> str | None:
    for encoding in ("utf-8", "utf-8-sig", "cp932", "shift_jis", "latin-1"):
        try:
            text = payload.decode(encoding)
        except UnicodeDecodeError:
            continue
        if "\x00" in text:
            return None
        return text
    return None


def _default_pixiv_ranking_tasks() -> list[dict[str, Any]]:
    return [
        {"mode": "daily", "page": 1},
        {"mode": "weekly", "page": 1},
        {"mode": "monthly", "page": 1},
        {"mode": "weekly_original", "page": 1},
    ]


def _load_pixiv_ranking_items(*, mode: str, page: int) -> tuple[list[dict[str, Any]], bool]:
    html = _http_get_text(f"{PIXIV_NOVEL_RANKING_URL}?mode={mode}&p={page}", timeout_sec=60.0)
    payload = _load_next_data_payload(html)
    display = cast(dict[str, Any], payload.get("props", {}).get("pageProps", {}).get("assign", {}).get("display_a", {}))
    items = cast(list[dict[str, Any]], display.get("rank_a", []))
    return items, bool(display.get("next"))


def _load_pixiv_user_novel_ids(user_id: str) -> list[str]:
    payload = _fetch_pixiv_json(
        PIXIV_USER_PROFILE_ALL_API_URL.format(user_id=user_id),
        referer=f"https://www.pixiv.net/users/{user_id}",
    )
    novels = cast(dict[str, Any], payload.get("body", {}).get("novels", {}))
    return [str(novel_id) for novel_id in novels if str(novel_id).strip()]


def _try_write_pixiv_novel_record(
    *,
    novel_id: str,
    min_bookmark_count: int,
    writer: JsonlShardWriter,
    bonus_writer: JsonlShardWriter,
    seen_novel_ids: set[str],
    seen_novels_path: Path,
) -> int:
    if novel_id in seen_novel_ids:
        return 0
    payload = _fetch_pixiv_json(
        PIXIV_NOVEL_DETAIL_API_URL.format(novel_id=novel_id),
        referer=f"https://www.pixiv.net/novel/show.php?id={novel_id}",
    )
    body = cast(dict[str, Any], payload.get("body", {}))
    bookmark_count = int(body.get("bookmarkCount", 0) or 0)
    if bookmark_count < min_bookmark_count:
        seen_novel_ids.add(novel_id)
        _append_seen_id(seen_novels_path, novel_id)
        return 0
    content = _normalize_space(str(body.get("content", "")))
    title = _normalize_space(str(body.get("title", "")))
    if not content or not title:
        seen_novel_ids.add(novel_id)
        _append_seen_id(seen_novels_path, novel_id)
        return 0
    record = {
        "source_label": "pixiv_novels",
        "novel_id": novel_id,
        "title": title,
        "bookmark_count": bookmark_count,
        "is_original": bool(body.get("isOriginal")),
        "restrict": body.get("restrict"),
        "x_restrict": body.get("xRestrict"),
        "url": f"https://www.pixiv.net/novel/show.php?id={novel_id}",
    }
    records = _build_chunked_cpt_records(
        title=title,
        body=content,
        focus=["style", "knowledge"],
        metadata=record,
    )
    for chunk in records:
        writer.write(chunk)
    if bool(body.get("isOriginal")) and bookmark_count >= PIXIV_ORIGINAL_NOVEL_BONUS_MIN_BOOKMARKS:
        for chunk in records:
            bonus_writer.write(chunk)
    seen_novel_ids.add(novel_id)
    _append_seen_id(seen_novels_path, novel_id)
    return 1


def _fetch_pixiv_json(url: str, *, referer: str) -> dict[str, Any]:
    with httpx.Client(
        follow_redirects=True,
        timeout=60.0,
        headers=_build_http_headers({"Referer": referer}),
    ) as client:
        response = client.get(url)
        response.raise_for_status()
        return cast(dict[str, Any], response.json())


def _load_seen_ids(path: Path) -> set[str]:
    if not path.is_file():
        return set()
    return {line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def _append_seen_id(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(value + "\n")


def _slugify_dictionary_name(name: str) -> str:
    normalized = unicodedata.normalize("NFKC", name).strip().lower()
    normalized = re.sub(r"\s+", "_", normalized)
    normalized = re.sub(r"[^0-9a-zA-Zぁ-んァ-ヶ一-龯_]+", "_", normalized)
    normalized = re.sub(r"_+", "_", normalized).strip("_")
    return normalized


def _extract_first_match(text: str, pattern: str, *, default: str = "") -> str:
    match = re.search(pattern, text, flags=re.DOTALL)
    if match is None:
        return default
    return match.group(1)
