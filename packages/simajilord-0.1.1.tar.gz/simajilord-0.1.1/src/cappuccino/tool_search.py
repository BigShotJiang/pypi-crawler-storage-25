from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .openai_compat import ToolSearchOutput


class FunctionTool(BaseModel):
    model_config = ConfigDict(extra="allow")

    type: Literal["function"] = "function"
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(
        default_factory=lambda: {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        }
    )
    defer_loading: bool = True
    strict: bool = True
    server_handler: dict[str, Any] | None = None


class NamespaceTool(BaseModel):
    model_config = ConfigDict(extra="allow")

    type: Literal["namespace"] = "namespace"
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)
    tools: list[FunctionTool]


ToolDefinition = FunctionTool | NamespaceTool


class IndexedTool(BaseModel):
    namespace: str | None = None
    namespace_description: str | None = None
    namespace_tags: list[str] = Field(default_factory=list)
    tool: FunctionTool


class ToolSearchHit(BaseModel):
    score: float
    name: str
    namespace: str | None = None
    description: str
    tags: list[str] = Field(default_factory=list)
    matched_fields: list[str] = Field(default_factory=list)
    tool: dict[str, Any]


class ToolRegistry:
    def __init__(self, tools: list[ToolDefinition]) -> None:
        self._tools = tools
        self._indexed = self._flatten_tools(tools)
        self._by_name = self._build_name_index(self._indexed)

    @classmethod
    def from_path(cls, path: str | Path) -> "ToolRegistry":
        tool_path = Path(path).expanduser().resolve()
        raw_items = _load_registry_items(tool_path)
        parsed: list[ToolDefinition] = []
        for item in raw_items:
            parsed.append(_parse_tool(item))
        return cls(parsed)

    @classmethod
    def from_file(cls, path: str | Path) -> "ToolRegistry":
        return cls.from_path(path)

    def search(self, query: str, limit: int = 5) -> list[ToolSearchHit]:
        normalized_query = _normalize(query)
        if not normalized_query:
            return []
        query_tokens = _tokens(normalized_query)

        scored_hits: list[ToolSearchHit] = []
        for indexed in self._indexed:
            score, matched_fields = _score_indexed_tool(indexed, normalized_query, query_tokens)
            if score <= 0:
                continue
            scored_hits.append(
                ToolSearchHit(
                    score=round(score, 4),
                    name=indexed.tool.name,
                    namespace=indexed.namespace,
                    description=indexed.tool.description,
                    tags=list(indexed.tool.tags),
                    matched_fields=matched_fields,
                    tool=indexed.tool.model_dump(exclude_none=True),
                )
            )

        return sorted(
            scored_hits,
            key=lambda item: (-item.score, item.namespace or "", item.name),
        )[:limit]

    def loaded_tools(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        return [hit.tool for hit in self.search(query=query, limit=limit)]

    def build_tool_search_output(
        self,
        *,
        query: str,
        limit: int = 5,
        call_id: str | None,
        execution: Literal["client", "server"] = "client",
    ) -> ToolSearchOutput:
        return ToolSearchOutput(
            execution=execution,
            call_id=call_id,
            tools=self.loaded_tools(query=query, limit=limit),
        )

    def get_tool(self, name: str) -> FunctionTool | None:
        return self._by_name.get(name)

    def all_tools(self) -> list[dict[str, Any]]:
        return [indexed.tool.model_dump(exclude_none=True) for indexed in self._indexed]

    @property
    def tool_count(self) -> int:
        return len(self._indexed)

    @staticmethod
    def _flatten_tools(tools: list[ToolDefinition]) -> list[IndexedTool]:
        indexed: list[IndexedTool] = []
        for tool in tools:
            if isinstance(tool, FunctionTool):
                indexed.append(IndexedTool(tool=tool))
                continue
            for child in tool.tools:
                indexed.append(
                    IndexedTool(
                        namespace=tool.name,
                        namespace_description=tool.description,
                        namespace_tags=list(tool.tags),
                        tool=child,
                    )
                )
        return indexed

    @staticmethod
    def _build_name_index(indexed_tools: list[IndexedTool]) -> dict[str, FunctionTool]:
        by_name: dict[str, FunctionTool] = {}
        collisions: dict[str, list[str]] = {}
        for indexed in indexed_tools:
            tool = indexed.tool
            location = tool.name
            if indexed.namespace:
                location = f"{indexed.namespace}.{tool.name}"
            existing = by_name.get(tool.name)
            if existing is not None:
                collisions.setdefault(tool.name, []).append(location)
                continue
            by_name[tool.name] = tool
        if collisions:
            rendered = ", ".join(
                f"{name} ({', '.join(sorted(locations))})"
                for name, locations in sorted(collisions.items())
            )
            raise ValueError(f"Duplicate tool names are not allowed: {rendered}")
        return by_name


def _load_registry_items(path: Path) -> list[dict[str, Any]]:
    if path.is_file():
        return _load_registry_items_from_file(path)
    if path.is_dir():
        items: list[dict[str, Any]] = []
        for child in sorted(candidate for candidate in path.rglob("*.json") if candidate.is_file()):
            items.extend(_load_registry_items_from_file(child))
        return items
    raise ValueError(f"Tool registry path does not exist: {path}")


def _load_registry_items_from_file(path: Path) -> list[dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(raw, dict):
        raw_items = [raw]
    elif isinstance(raw, list):
        raw_items = raw
    else:
        raise ValueError(f"Tool registry file must contain an object or array: {path}")
    items: list[dict[str, Any]] = []
    for item in raw_items:
        if not isinstance(item, dict):
            raise ValueError(f"Tool registry entries must be JSON objects: {path}")
        items.append(item)
    return items


def _parse_tool(item: dict[str, Any]) -> ToolDefinition:
    tool_type = item.get("type")
    if tool_type == "function":
        return FunctionTool.model_validate(item)
    if tool_type == "namespace":
        return NamespaceTool.model_validate(item)
    raise ValueError(f"Unsupported tool type: {tool_type}")


def _normalize(value: str) -> str:
    collapsed = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", collapsed).strip()


def _tokens(value: str) -> list[str]:
    return [token for token in value.split(" ") if token]


def _score_indexed_tool(
    indexed: IndexedTool,
    normalized_query: str,
    query_tokens: list[str],
) -> tuple[float, list[str]]:
    matched_fields: list[str] = []

    tool_name = _normalize(indexed.tool.name.replace("_", " "))
    tool_description = _normalize(indexed.tool.description)
    tool_tags = _normalize(" ".join(indexed.tool.tags))
    namespace_name = _normalize((indexed.namespace or "").replace("_", " "))
    namespace_description = _normalize(indexed.namespace_description or "")
    namespace_tags = _normalize(" ".join(indexed.namespace_tags))

    score = 0.0
    score += _field_score(
        normalized_query,
        query_tokens,
        tool_name,
        exact_phrase_weight=12.0,
        token_weight=4.0,
        prefix_weight=1.5,
        label="name",
        matched_fields=matched_fields,
    )
    score += _field_score(
        normalized_query,
        query_tokens,
        tool_description,
        exact_phrase_weight=8.0,
        token_weight=2.5,
        prefix_weight=1.0,
        label="description",
        matched_fields=matched_fields,
    )
    score += _field_score(
        normalized_query,
        query_tokens,
        tool_tags,
        exact_phrase_weight=7.0,
        token_weight=3.0,
        prefix_weight=1.0,
        label="tags",
        matched_fields=matched_fields,
    )
    score += _field_score(
        normalized_query,
        query_tokens,
        namespace_name,
        exact_phrase_weight=4.0,
        token_weight=1.5,
        prefix_weight=0.5,
        label="namespace",
        matched_fields=matched_fields,
    )
    score += _field_score(
        normalized_query,
        query_tokens,
        namespace_description,
        exact_phrase_weight=3.0,
        token_weight=1.0,
        prefix_weight=0.5,
        label="namespace_description",
        matched_fields=matched_fields,
    )
    score += _field_score(
        normalized_query,
        query_tokens,
        namespace_tags,
        exact_phrase_weight=3.0,
        token_weight=1.0,
        prefix_weight=0.5,
        label="namespace_tags",
        matched_fields=matched_fields,
    )

    if tool_name == normalized_query:
        score += 20.0
    if indexed.namespace and namespace_name == normalized_query:
        score += 5.0

    deduped_fields = list(dict.fromkeys(matched_fields))
    return score, deduped_fields


def _field_score(
    normalized_query: str,
    query_tokens: list[str],
    field_text: str,
    *,
    exact_phrase_weight: float,
    token_weight: float,
    prefix_weight: float,
    label: str,
    matched_fields: list[str],
) -> float:
    if not field_text:
        return 0.0

    field_tokens = set(_tokens(field_text))
    score = 0.0
    if normalized_query in field_text:
        score += exact_phrase_weight
        matched_fields.append(label)

    matching_tokens = [token for token in query_tokens if token in field_tokens]
    if matching_tokens:
        score += token_weight * len(matching_tokens)
        matched_fields.append(label)

    prefix_matches = [
        token
        for token in query_tokens
        if token not in field_tokens and any(candidate.startswith(token) for candidate in field_tokens)
    ]
    if prefix_matches:
        score += prefix_weight * len(prefix_matches)
        matched_fields.append(label)
    return score
