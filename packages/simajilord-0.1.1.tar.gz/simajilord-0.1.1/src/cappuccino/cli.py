from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

import httpx
import uvicorn

from .benchmarking import BENCHMARK_MODES, BenchmarkMode, normalize_benchmark_modes, run_reasoning_benchmark
from .context_windows import (
    DEFAULT_EXTENDED_CONTEXT_WINDOW,
    configure_model_context_window,
)
from .corpus_preparation import (
    build_training_manifest,
    build_wrapped_training_manifest,
    inspect_prepared_dataset_status,
    locate_default_desktop_input_output_dir,
    parse_manifest_dataset_specs,
    prepare_aozora_bunko_cpt,
    prepare_github_repositories_cpt,
    prepare_kaken_cpt,
    prepare_imperial_constitution_variants,
    prepare_input_output_txt_sft,
    prepare_kokkai_cpt,
    prepare_kotobank_cpt,
    prepare_ndl_next_digital_library_cpt,
    prepare_openai_docs_cpt,
    prepare_pixiv_dictionary_cpt,
    prepare_pixiv_novels_cpt,
    prepare_wikipedia_cited_sources_cpt,
    prepare_wikipedia_cpt,
    prepare_wikipedia_recent_changes_cpt,
)
from .dataset_manifests import (
    SequentialCptSource,
    iter_sequential_cpt_source_paths,
    load_sequential_cpt_manifest,
)
from .dataset_preparation import (
    prepare_egov_six_codes,
    prepare_legal_corpus,
    prepare_quizjam_pdf,
)
from .model_inspector import inspect_model_dir
from .openai_contract import write_openai_contract_report
from .preference_loop import PreferenceLoopConfig, run_preference_loop
from .quantization import quantize_model
from .reasoning import normalize_reasoning_mode
from .server import create_app
from .skill_registry import SkillRegistry
from .tool_search import ToolRegistry
from .tool_runtime import ToolExecutor, parse_tool_output_json
from .trainer import (
    BaseWeightUpdateConfig,
    CheckpointSampleConfig,
    LoRAHyperparameters,
    StabilityConfig,
    TrainerConfig,
    run_training,
    sample_saved_checkpoints,
)
from .training_schemas import validate_jsonl


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="simajilord")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser("inspect-model")
    inspect_parser.add_argument("--model-path", type=Path, required=True)
    inspect_parser.set_defaults(func=cmd_inspect_model)

    context_parser = subparsers.add_parser("set-context-window")
    context_parser.add_argument("--model-path", type=Path, required=True)
    context_parser.add_argument("--context-window", type=int, default=DEFAULT_EXTENDED_CONTEXT_WINDOW)
    context_parser.add_argument("--yarn-factor", type=float, default=None)
    context_parser.set_defaults(func=cmd_set_context_window)

    openai_contract_parser = subparsers.add_parser("sync-openai-api-contract")
    openai_contract_parser.add_argument(
        "--output-path",
        type=Path,
        default=Path("artifacts/openai_api_contract.json"),
    )
    openai_contract_parser.add_argument(
        "--check-latest-release",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    openai_contract_parser.add_argument("--timeout-sec", type=float, default=30.0)
    openai_contract_parser.set_defaults(func=cmd_sync_openai_api_contract)

    tool_search_parser = subparsers.add_parser("tool-search")
    tool_search_parser.add_argument("--registry", type=Path, required=True)
    tool_search_parser.add_argument("--query", type=str, required=True)
    tool_search_parser.add_argument("--limit", type=int, default=5)
    tool_search_parser.add_argument("--call-id", type=str, default=None)
    tool_search_parser.set_defaults(func=cmd_tool_search)

    list_tools_parser = subparsers.add_parser("list-tools")
    list_tools_parser.add_argument("--registry", type=Path, required=True)
    list_tools_parser.set_defaults(func=cmd_list_tools)

    skill_search_parser = subparsers.add_parser("skill-search")
    skill_search_parser.add_argument("--registry", type=Path, required=True)
    skill_search_parser.add_argument("--query", type=str, required=True)
    skill_search_parser.add_argument("--limit", type=int, default=5)
    skill_search_parser.set_defaults(func=cmd_skill_search)

    list_skills_parser = subparsers.add_parser("list-skills")
    list_skills_parser.add_argument("--registry", type=Path, required=True)
    list_skills_parser.set_defaults(func=cmd_list_skills)

    execute_tool_parser = subparsers.add_parser("execute-tool")
    execute_tool_parser.add_argument("--registry", type=Path, required=True)
    execute_tool_parser.add_argument("--name", type=str, required=True)
    execute_tool_parser.add_argument("--arguments-json", type=str, default="{}")
    execute_tool_parser.set_defaults(func=cmd_execute_tool)

    validate_parser = subparsers.add_parser("validate-dataset")
    validate_parser.add_argument("--path", type=Path, required=True)
    validate_parser.set_defaults(func=cmd_validate_dataset)

    dataset_status_parser = subparsers.add_parser("dataset-status")
    dataset_status_parser.add_argument("--output-dir", type=Path, required=True)
    dataset_status_parser.set_defaults(func=cmd_dataset_status)

    quizjam_parser = subparsers.add_parser("prepare-quizjam-pdf")
    quizjam_parser.add_argument("--pdf-path", type=Path, required=True)
    quizjam_parser.add_argument("--output-dir", type=Path, required=True)
    quizjam_parser.add_argument(
        "--copy-source",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    quizjam_parser.set_defaults(func=cmd_prepare_quizjam_pdf)

    legal_parser = subparsers.add_parser("prepare-legal-corpus")
    legal_parser.add_argument("--input", type=Path, nargs="+", required=True)
    legal_parser.add_argument("--output-path", type=Path, required=True)
    legal_parser.add_argument(
        "--kind",
        choices=["law", "case", "mixed"],
        default="mixed",
    )
    legal_parser.add_argument("--source-label", type=str, default="legal_corpus")
    legal_parser.add_argument("--max-chars", type=int, default=1200)
    legal_parser.add_argument("--min-chars", type=int, default=200)
    legal_parser.set_defaults(func=cmd_prepare_legal_corpus)

    egov_parser = subparsers.add_parser("prepare-egov-six-codes")
    egov_parser.add_argument("--output-dir", type=Path, required=True)
    egov_parser.set_defaults(func=cmd_prepare_egov_six_codes)

    input_output_parser = subparsers.add_parser("prepare-input-output-txt-sft")
    input_output_parser.add_argument("--input-dir", type=Path, required=True)
    input_output_parser.add_argument("--output-dir", type=Path, required=True)
    input_output_parser.add_argument(
        "--copy-source",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    input_output_parser.add_argument("--repeat", type=int, default=2)
    input_output_parser.set_defaults(func=cmd_prepare_input_output_txt_sft)

    aozora_parser = subparsers.add_parser("prepare-aozora-bunko")
    aozora_parser.add_argument("--output-dir", type=Path, required=True)
    aozora_parser.add_argument("--max-works-per-run", type=int, default=None)
    aozora_parser.add_argument("--records-per-shard", type=int, default=256)
    aozora_parser.add_argument("--repeat", type=int, default=2)
    aozora_parser.set_defaults(func=cmd_prepare_aozora_bunko)

    imperial_parser = subparsers.add_parser("prepare-imperial-constitution-variants")
    imperial_parser.add_argument("--output-dir", type=Path, required=True)
    imperial_parser.add_argument("--repeat", type=int, default=2)
    imperial_parser.set_defaults(func=cmd_prepare_imperial_constitution_variants)

    wikipedia_parser = subparsers.add_parser("prepare-wikipedia-cpt")
    wikipedia_parser.add_argument("--output-dir", type=Path, required=True)
    wikipedia_parser.add_argument("--language", type=str, default="ja")
    wikipedia_parser.add_argument("--max-pages-per-run", type=int, default=None)
    wikipedia_parser.add_argument("--records-per-shard", type=int, default=256)
    wikipedia_parser.add_argument("--repeat", type=int, default=2)
    wikipedia_parser.add_argument(
        "--include-images",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wikipedia_parser.add_argument(
        "--image-detail",
        choices=["high", "low", "auto"],
        default="auto",
    )
    wikipedia_parser.set_defaults(func=cmd_prepare_wikipedia_cpt)

    wikipedia_recent_changes_parser = subparsers.add_parser("prepare-wikipedia-recent-changes-cpt")
    wikipedia_recent_changes_parser.add_argument("--output-dir", type=Path, required=True)
    wikipedia_recent_changes_parser.add_argument("--language", type=str, default="ja")
    wikipedia_recent_changes_parser.add_argument("--max-changes-per-run", type=int, default=None)
    wikipedia_recent_changes_parser.add_argument("--records-per-shard", type=int, default=256)
    wikipedia_recent_changes_parser.add_argument("--repeat", type=int, default=1)
    wikipedia_recent_changes_parser.add_argument(
        "--include-images",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wikipedia_recent_changes_parser.add_argument(
        "--image-detail",
        choices=["high", "low", "auto"],
        default="auto",
    )
    wikipedia_recent_changes_parser.add_argument("--initial-lookback-hours", type=float, default=72.0)
    wikipedia_recent_changes_parser.add_argument("--request-interval-sec", type=float, default=0.5)
    wikipedia_recent_changes_parser.set_defaults(func=cmd_prepare_wikipedia_recent_changes_cpt)

    wikipedia_cited_sources_parser = subparsers.add_parser("prepare-wikipedia-cited-sources-cpt")
    wikipedia_cited_sources_parser.add_argument("--source-wikipedia-dir", type=Path, required=True)
    wikipedia_cited_sources_parser.add_argument("--output-dir", type=Path, required=True)
    wikipedia_cited_sources_parser.add_argument("--language", type=str, default="ja")
    wikipedia_cited_sources_parser.add_argument("--max-pages-per-run", type=int, default=None)
    wikipedia_cited_sources_parser.add_argument("--records-per-shard", type=int, default=256)
    wikipedia_cited_sources_parser.add_argument("--repeat", type=int, default=1)
    wikipedia_cited_sources_parser.add_argument("--request-interval-sec", type=float, default=0.5)
    wikipedia_cited_sources_parser.set_defaults(func=cmd_prepare_wikipedia_cited_sources_cpt)

    openai_docs_parser = subparsers.add_parser("prepare-openai-docs-cpt")
    openai_docs_parser.add_argument("--output-dir", type=Path, required=True)
    openai_docs_parser.add_argument("--max-pages-per-run", type=int, default=None)
    openai_docs_parser.add_argument("--records-per-shard", type=int, default=256)
    openai_docs_parser.add_argument("--repeat", type=int, default=2)
    openai_docs_parser.set_defaults(func=cmd_prepare_openai_docs_cpt)

    kaken_parser = subparsers.add_parser("prepare-kaken-cpt")
    kaken_parser.add_argument("--output-dir", type=Path, required=True)
    kaken_parser.add_argument("--max-projects-per-run", type=int, default=None)
    kaken_parser.add_argument("--records-per-shard", type=int, default=256)
    kaken_parser.add_argument("--repeat", type=int, default=2)
    kaken_parser.add_argument("--request-interval-sec", type=float, default=0.5)
    kaken_parser.set_defaults(func=cmd_prepare_kaken_cpt)

    ndl_next_dl_parser = subparsers.add_parser("prepare-ndl-next-digital-library-cpt")
    ndl_next_dl_parser.add_argument("--output-dir", type=Path, required=True)
    ndl_next_dl_parser.add_argument("--max-items-per-run", type=int, default=None)
    ndl_next_dl_parser.add_argument("--records-per-shard", type=int, default=256)
    ndl_next_dl_parser.add_argument("--repeat", type=int, default=2)
    ndl_next_dl_parser.add_argument("--request-interval-sec", type=float, default=0.5)
    ndl_next_dl_parser.set_defaults(func=cmd_prepare_ndl_next_digital_library_cpt)

    pixiv_dictionary_parser = subparsers.add_parser("prepare-pixiv-dictionary-cpt")
    pixiv_dictionary_parser.add_argument("--output-dir", type=Path, required=True)
    pixiv_dictionary_parser.add_argument("--max-articles-per-run", type=int, default=None)
    pixiv_dictionary_parser.add_argument("--records-per-shard", type=int, default=256)
    pixiv_dictionary_parser.add_argument("--repeat", type=int, default=1)
    pixiv_dictionary_parser.set_defaults(func=cmd_prepare_pixiv_dictionary_cpt)

    pixiv_novels_parser = subparsers.add_parser("prepare-pixiv-novels-cpt")
    pixiv_novels_parser.add_argument("--output-dir", type=Path, required=True)
    pixiv_novels_parser.add_argument("--min-bookmark-count", type=int, default=70)
    pixiv_novels_parser.add_argument("--max-items-per-run", type=int, default=None)
    pixiv_novels_parser.add_argument("--records-per-shard", type=int, default=256)
    pixiv_novels_parser.set_defaults(func=cmd_prepare_pixiv_novels_cpt)

    kotobank_parser = subparsers.add_parser("prepare-kotobank-cpt")
    kotobank_parser.add_argument("--output-dir", type=Path, required=True)
    kotobank_parser.add_argument("--max-articles-per-run", type=int, default=None)
    kotobank_parser.add_argument("--records-per-shard", type=int, default=256)
    kotobank_parser.add_argument("--repeat", type=int, default=2)
    kotobank_parser.set_defaults(func=cmd_prepare_kotobank_cpt)

    kokkai_parser = subparsers.add_parser("prepare-kokkai-cpt")
    kokkai_parser.add_argument("--output-dir", type=Path, required=True)
    kokkai_parser.add_argument("--max-meetings-per-run", type=int, default=None)
    kokkai_parser.add_argument("--records-per-shard", type=int, default=256)
    kokkai_parser.add_argument("--repeat", type=int, default=1)
    kokkai_parser.add_argument("--session-from", type=int, default=1)
    kokkai_parser.add_argument("--session-to", type=int, default=999)
    kokkai_parser.add_argument("--request-interval-sec", type=float, default=2.0)
    kokkai_parser.set_defaults(func=cmd_prepare_kokkai_cpt)

    github_repositories_parser = subparsers.add_parser("prepare-github-repositories-cpt")
    github_repositories_parser.add_argument("--output-dir", type=Path, required=True)
    github_repositories_parser.add_argument("--min-stars", type=int, default=10000)
    github_repositories_parser.add_argument("--max-repos-per-run", type=int, default=None)
    github_repositories_parser.add_argument("--records-per-shard", type=int, default=256)
    github_repositories_parser.add_argument("--repeat", type=int, default=1)
    github_repositories_parser.add_argument("--request-interval-sec", type=float, default=2.0)
    github_repositories_parser.set_defaults(func=cmd_prepare_github_repositories_cpt)

    manifest_parser = subparsers.add_parser("build-training-manifest")
    manifest_parser.add_argument("--output-path", type=Path, required=True)
    manifest_parser.add_argument(
        "--dataset",
        action="append",
        required=True,
        help="Dataset spec in path::repeat or path::repeat::label format.",
    )
    manifest_parser.set_defaults(func=cmd_build_training_manifest)

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--model-path", type=Path, required=True)
    train_parser.add_argument("--dataset-path", type=Path, required=True)
    train_parser.add_argument("--output-dir", type=Path, required=True)
    train_parser.add_argument(
        "--train-mode",
        choices=["sft", "orpo"],
        default="sft",
    )
    train_parser.add_argument("--adapter-path", type=Path, default=None)
    train_parser.add_argument("--valid-path", type=Path, default=None)
    train_parser.add_argument("--max-examples", type=int, default=None)
    train_parser.add_argument("--validation-fraction", type=float, default=0.1)
    train_parser.add_argument("--seed", type=int, default=0)
    train_parser.add_argument("--batch-size", type=int, default=1)
    train_parser.add_argument("--epochs", type=int, default=None)
    train_parser.add_argument("--iters", type=int, default=100)
    train_parser.add_argument("--val-batches", type=int, default=8)
    train_parser.add_argument("--learning-rate", type=float, default=1e-5)
    train_parser.add_argument("--steps-per-report", type=int, default=1)
    train_parser.add_argument("--steps-per-eval", type=int, default=10)
    train_parser.add_argument("--save-every", type=int, default=25)
    train_parser.add_argument(
        "--max-seq-length",
        type=int,
        default=0,
        help="Maximum token length per example. Use 0 to disable the repository-side cap and keep full example lengths.",
    )
    train_parser.add_argument(
        "--grad-checkpoint",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Enable gradient checkpointing to reduce activation memory (enabled by default).",
    )
    train_parser.add_argument("--grad-accumulation-steps", type=int, default=1)
    train_parser.add_argument(
        "--optimizer",
        choices=["adam", "adamw", "sgd", "adafactor"],
        default="adafactor",
    )
    train_parser.add_argument("--mask-prompt", action="store_true")
    train_parser.add_argument("--dry-run", action="store_true")
    train_parser.add_argument("--allow-overlimit", action="store_true")
    train_parser.add_argument("--context-window", type=int, default=None)
    train_parser.add_argument("--yarn-factor", type=float, default=None)
    train_parser.add_argument("--lora-num-layers", type=int, default=8)
    train_parser.add_argument("--lora-rank", type=int, default=8)
    train_parser.add_argument("--lora-scale", type=float, default=20.0)
    train_parser.add_argument("--lora-dropout", type=float, default=0.0)
    train_parser.add_argument("--base-last-layers", type=int, default=0)
    train_parser.add_argument(
        "--base-include-norms",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    train_parser.add_argument(
        "--base-include-biases",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    train_parser.add_argument(
        "--base-include-lm-head",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    train_parser.add_argument(
        "--base-include-embeddings",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    train_parser.add_argument("--base-learning-rate-scale", type=float, default=0.05)
    train_parser.add_argument("--base-l2-sp-weight", type=float, default=1e-4)
    train_parser.add_argument("--replay-dataset-path", type=Path, default=None)
    train_parser.add_argument("--replay-target-fraction", type=float, default=0.2)
    train_parser.add_argument("--grad-clip-norm", type=float, default=1.0)
    train_parser.add_argument(
        "--metal-memory-budget-mode",
        choices=["recommended", "device", "none"],
        default="device",
        help="How aggressively to use unified memory. 'device' uses the full memory_size instead of the lower recommended working set.",
    )
    train_parser.add_argument("--metal-memory-limit-bytes", type=int, default=None)
    train_parser.add_argument("--metal-wired-limit-bytes", type=int, default=None)
    train_parser.add_argument("--metal-cache-limit-bytes", type=int, default=0)
    train_parser.add_argument("--metal-cache-clear-interval", type=int, default=1)
    train_parser.add_argument("--training-memory-reserve-bytes", type=int, default=64 * 1024 * 1024)
    train_parser.add_argument(
        "--strict-token-audit",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Before training, tokenize the full dataset and record the exact longest examples to avoid surprise OOMs.",
    )
    train_parser.add_argument(
        "--checkpoint-sample",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="After saving each checkpoint, run a fixed prompt and save the generated output for quick comparison.",
    )
    train_parser.add_argument(
        "--checkpoint-sample-prompt",
        type=str,
        default="AIについて説明してください",
    )
    train_parser.add_argument(
        "--checkpoint-sample-max-tokens",
        type=int,
        default=8192,
        help="Maximum generated tokens for each checkpoint sample run.",
    )
    train_parser.add_argument(
        "--checkpoint-sample-max-kv-size",
        type=int,
        default=2048,
        help="Cap the KV cache used during checkpoint sampling. Lower values reduce memory pressure.",
    )
    train_parser.add_argument(
        "--checkpoint-sample-kv-bits",
        type=int,
        default=4,
        help="KV cache quantization bit-width for checkpoint sampling. Use 0 to disable KV quantization.",
    )
    train_parser.add_argument(
        "--checkpoint-sample-kv-group-size",
        type=int,
        default=64,
        help="KV cache quantization group size for checkpoint sampling.",
    )
    train_parser.add_argument("--orpo-beta", type=float, default=0.1)
    train_parser.add_argument(
        "--train-vision",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="When image-grounded examples are present, switch to the multimodal trainer and unfreeze the vision stack.",
    )
    train_parser.add_argument(
        "--delete-dataset-after-success",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="After a successful non-dry-run stage, permanently delete the consumed dataset artifacts instead of moving them to Trash.",
    )
    train_parser.add_argument(
        "--auto-desktop-input-output",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Automatically append Desktop input/output examples unless they are already present in the dataset manifest.",
    )
    train_parser.add_argument(
        "--preserve-dataset-state",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="When deleting consumed dataset artifacts, keep small progress files such as progress.json and seen-id state for the next stage.",
    )
    train_parser.set_defaults(func=cmd_train)

    quantize_parser = subparsers.add_parser("quantize")
    quantize_parser.add_argument("--model-path", type=Path, required=True)
    quantize_parser.add_argument("--out", type=Path, required=True)
    quantize_parser.add_argument("--bits", type=int, default=6)
    quantize_parser.add_argument("--group-size", type=int, default=64)
    quantize_parser.add_argument(
        "--exclude-multimodal",
        action="store_true",
        help="Keep the upstream MLX-VLM behavior and skip vision or audio stacks.",
    )
    quantize_parser.set_defaults(func=cmd_quantize)

    serve_parser = subparsers.add_parser("serve")
    serve_parser.add_argument("--tool-registry", type=Path, default=None)
    serve_parser.add_argument("--skill-registry", type=Path, default=None)
    serve_parser.add_argument("--host", type=str, default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8020)
    serve_parser.add_argument("--image-max-long-edge", type=int, default=1536)
    serve_parser.add_argument("--image-max-pixels", type=int, default=1536 * 1536)
    serve_parser.add_argument("--image-cache-dir", type=Path, default=None)
    serve_parser.add_argument("--default-model-path", type=Path, default=None)
    serve_parser.add_argument("--public-model-id", type=str, default="cappuccino")
    serve_parser.add_argument("--model-alias", action="append", default=None)
    serve_parser.set_defaults(func=cmd_serve)

    smoke_api_parser = subparsers.add_parser("smoke-api")
    smoke_api_parser.add_argument("--base-url", type=str, default="http://127.0.0.1:8020")
    smoke_api_parser.add_argument("--model-path", type=Path, required=True)
    smoke_api_parser.add_argument("--prompt", type=str, required=True)
    smoke_api_parser.add_argument("--system", type=str, default=None)
    smoke_api_parser.add_argument("--max-tokens", type=int, default=None)
    smoke_api_parser.add_argument(
        "--thinking",
        choices=["off", "on"],
        default=None,
    )
    smoke_api_parser.add_argument(
        "--reasoning-summary",
        choices=["none", "auto", "concise", "detailed"],
        default="none",
    )
    smoke_api_parser.add_argument(
        "--reasoning-mode",
        type=str,
        default=None,
    )
    smoke_api_parser.set_defaults(func=cmd_smoke_api)

    benchmark_parser = subparsers.add_parser("benchmark-reasoning")
    benchmark_parser.add_argument("--base-url", type=str, default="http://127.0.0.1:8020")
    benchmark_parser.add_argument("--model-path", type=Path, required=True)
    benchmark_parser.add_argument("--modes", type=str, default="off,on,auto")
    benchmark_parser.add_argument("--max-tokens", type=int, default=None)
    benchmark_parser.add_argument("--auto-checkpoint-tokens", type=int, default=64)
    benchmark_parser.add_argument(
        "--adaptive-checkpoint-tokens",
        dest="auto_checkpoint_tokens",
        type=int,
        help=argparse.SUPPRESS,
    )
    benchmark_parser.add_argument("--auto-max-rounds", type=int, default=3)
    benchmark_parser.add_argument(
        "--adaptive-max-rounds",
        dest="auto_max_rounds",
        type=int,
        help=argparse.SUPPRESS,
    )
    benchmark_parser.add_argument("--request-timeout-sec", type=float, default=120.0)
    benchmark_parser.add_argument("--no-warmup", action="store_true")
    benchmark_parser.add_argument("--output", type=Path, default=None)
    benchmark_parser.set_defaults(func=cmd_benchmark_reasoning)

    sample_checkpoints_parser = subparsers.add_parser("sample-checkpoints")
    sample_checkpoints_parser.add_argument("--model-path", type=Path, required=True)
    sample_checkpoints_parser.add_argument("--train-output-dir", type=Path, required=True)
    sample_checkpoints_parser.add_argument(
        "--prompt",
        type=str,
        default="AIについて説明してください",
    )
    sample_checkpoints_parser.add_argument("--max-tokens", type=int, default=8192)
    sample_checkpoints_parser.add_argument("--max-kv-size", type=int, default=2048)
    sample_checkpoints_parser.add_argument("--kv-bits", type=int, default=4)
    sample_checkpoints_parser.add_argument("--kv-group-size", type=int, default=64)
    sample_checkpoints_parser.set_defaults(func=cmd_sample_checkpoints)

    preference_loop_parser = subparsers.add_parser("preference-loop")
    preference_loop_parser.add_argument("--model-path", type=Path, required=True)
    preference_loop_parser.add_argument("--output-dir", type=Path, required=True)
    preference_loop_parser.add_argument("--prompt", type=str, default=None)
    preference_loop_parser.add_argument("--adapter-path", type=Path, default=None)
    preference_loop_parser.add_argument("--max-rounds", type=int, default=None)
    preference_loop_parser.add_argument("--max-regenerations-per-round", type=int, default=20)
    preference_loop_parser.add_argument("--max-tokens", type=int, default=1024)
    preference_loop_parser.add_argument("--candidate-a-temperature", type=float, default=0.6)
    preference_loop_parser.add_argument("--candidate-b-temperature", type=float, default=0.9)
    preference_loop_parser.add_argument("--candidate-top-p", type=float, default=0.95)
    preference_loop_parser.add_argument("--seed", type=int, default=0)
    preference_loop_parser.add_argument("--train-batch-size", type=int, default=1)
    preference_loop_parser.add_argument("--train-iters", type=int, default=1)
    preference_loop_parser.add_argument("--train-learning-rate", type=float, default=1e-6)
    preference_loop_parser.add_argument(
        "--train-grad-checkpoint",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    preference_loop_parser.add_argument(
        "--train-vision",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    preference_loop_parser.add_argument("--context-window", type=int, default=None)
    preference_loop_parser.add_argument("--yarn-factor", type=float, default=None)
    preference_loop_parser.add_argument("--lora-num-layers", type=int, default=8)
    preference_loop_parser.add_argument("--lora-rank", type=int, default=8)
    preference_loop_parser.add_argument("--lora-scale", type=float, default=20.0)
    preference_loop_parser.add_argument("--lora-dropout", type=float, default=0.0)
    preference_loop_parser.add_argument("--base-last-layers", type=int, default=0)
    preference_loop_parser.add_argument(
        "--base-include-norms",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    preference_loop_parser.add_argument(
        "--base-include-biases",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    preference_loop_parser.add_argument(
        "--base-include-lm-head",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    preference_loop_parser.add_argument(
        "--base-include-embeddings",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    preference_loop_parser.add_argument("--base-learning-rate-scale", type=float, default=0.05)
    preference_loop_parser.add_argument("--base-l2-sp-weight", type=float, default=1e-4)
    preference_loop_parser.add_argument("--grad-clip-norm", type=float, default=1.0)
    preference_loop_parser.add_argument(
        "--metal-memory-budget-mode",
        choices=["recommended", "device", "none"],
        default="device",
    )
    preference_loop_parser.add_argument("--metal-memory-limit-bytes", type=int, default=None)
    preference_loop_parser.add_argument("--metal-wired-limit-bytes", type=int, default=None)
    preference_loop_parser.add_argument("--metal-cache-limit-bytes", type=int, default=0)
    preference_loop_parser.add_argument("--metal-cache-clear-interval", type=int, default=1)
    preference_loop_parser.add_argument("--training-memory-reserve-bytes", type=int, default=64 * 1024 * 1024)
    preference_loop_parser.add_argument(
        "--strict-token-audit",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    preference_loop_parser.add_argument("--orpo-beta", type=float, default=0.1)
    preference_loop_parser.set_defaults(func=cmd_preference_loop)

    return parser


def cmd_inspect_model(args: argparse.Namespace) -> None:
    profile = inspect_model_dir(args.model_path)
    print(json.dumps(profile.model_dump(), ensure_ascii=False, indent=2))


def cmd_set_context_window(args: argparse.Namespace) -> None:
    report = configure_model_context_window(
        args.model_path,
        target_context_window=args.context_window,
        yarn_factor=args.yarn_factor,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_tool_search(args: argparse.Namespace) -> None:
    registry = ToolRegistry.from_path(args.registry)
    hits = registry.search(query=args.query, limit=args.limit)
    payload: dict[str, Any] = {"results": [hit.model_dump() for hit in hits]}
    if args.call_id is not None:
        payload["tool_search_output"] = registry.build_tool_search_output(
            query=args.query,
            limit=args.limit,
            call_id=args.call_id,
        ).model_dump(exclude_none=True)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def cmd_list_tools(args: argparse.Namespace) -> None:
    registry = ToolRegistry.from_path(args.registry)
    payload = {
        "tool_count": registry.tool_count,
        "tools": registry.all_tools(),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def cmd_skill_search(args: argparse.Namespace) -> None:
    registry = SkillRegistry.from_path(args.registry)
    payload = {
        "query": args.query,
        "limit": args.limit,
        "results": [hit.model_dump() for hit in registry.search(query=args.query, limit=args.limit)],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def cmd_list_skills(args: argparse.Namespace) -> None:
    registry = SkillRegistry.from_path(args.registry)
    payload = {
        "skill_count": registry.skill_count,
        "skills": registry.all_skills(),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def cmd_execute_tool(args: argparse.Namespace) -> None:
    registry = ToolRegistry.from_path(args.registry)
    executor = ToolExecutor(registry)
    arguments = json.loads(args.arguments_json)
    if not isinstance(arguments, dict):
        raise ValueError("--arguments-json must decode to a JSON object.")
    output = executor.execute(name=args.name, arguments=arguments)
    if output is None:
        raise ValueError(f"Unknown tool: {args.name}")
    payload = {
        "name": args.name,
        "arguments": arguments,
        "output": output,
        "output_json": parse_tool_output_json(output),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def cmd_validate_dataset(args: argparse.Namespace) -> None:
    report = validate_jsonl(args.path)
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_dataset_status(args: argparse.Namespace) -> None:
    report = inspect_prepared_dataset_status(output_dir=args.output_dir)
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_quizjam_pdf(args: argparse.Namespace) -> None:
    report = prepare_quizjam_pdf(
        pdf_path=args.pdf_path,
        output_dir=args.output_dir,
        copy_source=args.copy_source,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_legal_corpus(args: argparse.Namespace) -> None:
    report = prepare_legal_corpus(
        input_paths=args.input,
        output_path=args.output_path,
        kind=args.kind,
        source_label=args.source_label,
        max_chars=args.max_chars,
        min_chars=args.min_chars,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_egov_six_codes(args: argparse.Namespace) -> None:
    report = prepare_egov_six_codes(output_dir=args.output_dir)
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_input_output_txt_sft(args: argparse.Namespace) -> None:
    report = prepare_input_output_txt_sft(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        copy_source=args.copy_source,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_aozora_bunko(args: argparse.Namespace) -> None:
    report = prepare_aozora_bunko_cpt(
        output_dir=args.output_dir,
        max_works_per_run=args.max_works_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_imperial_constitution_variants(args: argparse.Namespace) -> None:
    report = prepare_imperial_constitution_variants(
        output_dir=args.output_dir,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_wikipedia_cpt(args: argparse.Namespace) -> None:
    report = prepare_wikipedia_cpt(
        output_dir=args.output_dir,
        language=args.language,
        max_pages_per_run=args.max_pages_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        include_images=args.include_images,
        image_detail=args.image_detail,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_wikipedia_recent_changes_cpt(args: argparse.Namespace) -> None:
    report = prepare_wikipedia_recent_changes_cpt(
        output_dir=args.output_dir,
        language=args.language,
        max_changes_per_run=args.max_changes_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        include_images=args.include_images,
        image_detail=args.image_detail,
        initial_lookback_hours=args.initial_lookback_hours,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_wikipedia_cited_sources_cpt(args: argparse.Namespace) -> None:
    report = prepare_wikipedia_cited_sources_cpt(
        source_wikipedia_dir=args.source_wikipedia_dir,
        output_dir=args.output_dir,
        language=args.language,
        max_pages_per_run=args.max_pages_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_openai_docs_cpt(args: argparse.Namespace) -> None:
    report = prepare_openai_docs_cpt(
        output_dir=args.output_dir,
        max_pages_per_run=args.max_pages_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_sync_openai_api_contract(args: argparse.Namespace) -> None:
    report = write_openai_contract_report(
        output_path=args.output_path,
        app=create_app(),
        include_latest_release=args.check_latest_release,
        timeout_sec=args.timeout_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_kaken_cpt(args: argparse.Namespace) -> None:
    report = prepare_kaken_cpt(
        output_dir=args.output_dir,
        max_projects_per_run=args.max_projects_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_ndl_next_digital_library_cpt(args: argparse.Namespace) -> None:
    report = prepare_ndl_next_digital_library_cpt(
        output_dir=args.output_dir,
        max_items_per_run=args.max_items_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_pixiv_dictionary_cpt(args: argparse.Namespace) -> None:
    report = prepare_pixiv_dictionary_cpt(
        output_dir=args.output_dir,
        max_articles_per_run=args.max_articles_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_pixiv_novels_cpt(args: argparse.Namespace) -> None:
    report = prepare_pixiv_novels_cpt(
        output_dir=args.output_dir,
        min_bookmark_count=args.min_bookmark_count,
        max_items_per_run=args.max_items_per_run,
        records_per_shard=args.records_per_shard,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_kotobank_cpt(args: argparse.Namespace) -> None:
    report = prepare_kotobank_cpt(
        output_dir=args.output_dir,
        max_articles_per_run=args.max_articles_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_kokkai_cpt(args: argparse.Namespace) -> None:
    report = prepare_kokkai_cpt(
        output_dir=args.output_dir,
        max_meetings_per_run=args.max_meetings_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        session_from=args.session_from,
        session_to=args.session_to,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_prepare_github_repositories_cpt(args: argparse.Namespace) -> None:
    report = prepare_github_repositories_cpt(
        output_dir=args.output_dir,
        min_stars=args.min_stars,
        max_repos_per_run=args.max_repos_per_run,
        records_per_shard=args.records_per_shard,
        repeat=args.repeat,
        request_interval_sec=args.request_interval_sec,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_build_training_manifest(args: argparse.Namespace) -> None:
    manifest_path = build_training_manifest(
        output_path=args.output_path,
        datasets=parse_manifest_dataset_specs(args.dataset),
    )
    print(
        json.dumps(
            {"manifest": str(manifest_path)},
            ensure_ascii=False,
            indent=2,
        )
    )


def cmd_train(args: argparse.Namespace) -> None:
    dataset_path = args.dataset_path
    default_input_output_dir = locate_default_desktop_input_output_dir()
    if (
        getattr(args, "auto_desktop_input_output", True)
        and default_input_output_dir is not None
        and not _dataset_already_includes_desktop_input_output(dataset_path)
    ):
        auto_sft_dir = args.output_dir.expanduser().resolve() / "auto_desktop_input_output"
        auto_report = prepare_input_output_txt_sft(
            input_dir=default_input_output_dir,
            output_dir=auto_sft_dir,
            copy_source=True,
            repeat=2,
        )
        dataset_path = build_wrapped_training_manifest(
            dataset_path=args.dataset_path,
            output_path=args.output_dir.expanduser().resolve() / "resolved_train_dataset.json",
            extra_sources=[
                SequentialCptSource(
                    path=auto_report.output_paths["manifest"],
                    repeat=1,
                    label="desktop_input_output_auto",
                )
            ],
        )
    report = run_training(
        TrainerConfig(
            model_path=str(args.model_path),
            dataset_path=str(dataset_path),
            output_dir=str(args.output_dir),
            train_mode=getattr(args, "train_mode", "sft"),
            adapter_path=(
                str(args.adapter_path)
                if getattr(args, "adapter_path", None) is not None
                else None
            ),
            valid_path=str(args.valid_path) if args.valid_path is not None else None,
            max_examples=args.max_examples,
            validation_fraction=args.validation_fraction,
            seed=args.seed,
            batch_size=args.batch_size,
            epochs=args.epochs,
            iters=args.iters,
            val_batches=args.val_batches,
            learning_rate=args.learning_rate,
            steps_per_report=args.steps_per_report,
            steps_per_eval=args.steps_per_eval,
            save_every=args.save_every,
            max_seq_length=args.max_seq_length,
            grad_checkpoint=args.grad_checkpoint,
            grad_accumulation_steps=args.grad_accumulation_steps,
            optimizer=args.optimizer,
            mask_prompt=args.mask_prompt,
            dry_run=args.dry_run,
            allow_overlimit=args.allow_overlimit,
            context_window=args.context_window,
            yarn_factor=args.yarn_factor,
            lora=LoRAHyperparameters(
                num_layers=args.lora_num_layers,
                rank=args.lora_rank,
                scale=args.lora_scale,
                dropout=args.lora_dropout,
            ),
            base_update=BaseWeightUpdateConfig(
                last_layer_count=args.base_last_layers,
                include_norms=args.base_include_norms,
                include_biases=args.base_include_biases,
                include_lm_head=args.base_include_lm_head,
                include_embeddings=args.base_include_embeddings,
                learning_rate_scale=args.base_learning_rate_scale,
                l2_sp_weight=args.base_l2_sp_weight,
            ),
            stability=StabilityConfig(
                replay_dataset_path=(
                    str(args.replay_dataset_path)
                    if args.replay_dataset_path is not None
                    else None
                ),
                replay_target_fraction=args.replay_target_fraction,
                grad_clip_norm=args.grad_clip_norm,
                metal_memory_budget_mode=getattr(args, "metal_memory_budget_mode", "device"),
                metal_memory_limit_bytes=getattr(args, "metal_memory_limit_bytes", None),
                metal_wired_limit_bytes=getattr(args, "metal_wired_limit_bytes", None),
                metal_cache_limit_bytes=args.metal_cache_limit_bytes,
                metal_cache_clear_interval=args.metal_cache_clear_interval,
                training_memory_reserve_bytes=getattr(args, "training_memory_reserve_bytes", 64 * 1024 * 1024),
                strict_token_audit=getattr(args, "strict_token_audit", True),
            ),
            checkpoint_sample=CheckpointSampleConfig(
                enabled=args.checkpoint_sample,
                prompt=args.checkpoint_sample_prompt,
                max_tokens=args.checkpoint_sample_max_tokens,
                max_kv_size=(
                    args.checkpoint_sample_max_kv_size
                    if args.checkpoint_sample_max_kv_size > 0
                    else None
                ),
                kv_bits=(args.checkpoint_sample_kv_bits if args.checkpoint_sample_kv_bits > 0 else None),
                kv_group_size=args.checkpoint_sample_kv_group_size,
            ),
            orpo_beta=getattr(args, "orpo_beta", 0.1),
            train_vision=getattr(args, "train_vision", False),
        )
    )
    if (
        report.status == "completed"
        and not args.dry_run
        and getattr(args, "delete_dataset_after_success", False)
    ):
        deleted_paths = _purge_dataset_artifacts(
            Path(dataset_path),
            preserve_state=getattr(args, "preserve_dataset_state", True),
        )
        print(
            json.dumps(
                {
                    "deleted_dataset_artifacts": deleted_paths,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def _dataset_already_includes_desktop_input_output(dataset_path: Path) -> bool:
    normalized_dataset_path = dataset_path.expanduser().resolve()
    for source_path in iter_sequential_cpt_source_paths(normalized_dataset_path):
        if _looks_like_desktop_input_output_path(source_path):
            return True
    return False


def _looks_like_desktop_input_output_path(path: Path) -> bool:
    lowered = str(path).lower()
    return "desktop_input_output" in lowered or "auto_desktop_input_output" in lowered


def _purge_dataset_artifacts(
    dataset_path: Path,
    *,
    preserve_state: bool = True,
) -> list[str]:
    normalized_path = dataset_path.expanduser().resolve()
    deleted_paths: list[str] = []
    dataset_roots: set[Path] = set()

    manifest_stack = [normalized_path]
    seen_manifests: set[Path] = set()
    while manifest_stack:
        manifest_path = manifest_stack.pop()
        if manifest_path in seen_manifests or not manifest_path.exists():
            continue
        seen_manifests.add(manifest_path)
        dataset_roots.add(manifest_path.parent)
        manifest = load_sequential_cpt_manifest(manifest_path)
        if manifest is not None:
            for dataset in manifest.datasets:
                manifest_stack.append(Path(dataset.path).expanduser().resolve())
        for source_path in iter_sequential_cpt_source_paths(manifest_path):
            if source_path.exists():
                source_path.unlink()
                deleted_paths.append(str(source_path))
        if manifest_path.is_file():
            manifest_path.unlink()
            deleted_paths.append(str(manifest_path))

    for dataset_root in sorted(dataset_roots, reverse=True):
        for helper_name in (
            "shards",
            "bonus_shards",
            "dictionary_shards",
            "source_txt",
            "raw_xml",
        ):
            helper_path = dataset_root / helper_name
            if helper_path.exists():
                shutil.rmtree(helper_path, ignore_errors=True)
                deleted_paths.append(str(helper_path))
        for helper_file in (
            "wikipedia_manifest.json",
            "wikipedia_train_manifest.json",
            "wikipedia_recent_changes_manifest.json",
            "wikipedia_recent_changes_train_manifest.json",
            "wikipedia_cited_sources_manifest.json",
            "wikipedia_cited_sources_train_manifest.json",
            "kokkai_manifest.json",
            "kokkai_train_manifest.json",
            "openai_docs_manifest.json",
            "openai_docs_train_manifest.json",
            "kaken_manifest.json",
            "kaken_train_manifest.json",
            "ndl_next_digital_library_manifest.json",
            "ndl_next_digital_library_train_manifest.json",
            "pixiv_dictionary_manifest.json",
            "pixiv_dictionary_train_manifest.json",
            "pixiv_novels_manifest.json",
            "pixiv_novels_original_bonus_manifest.json",
            "pixiv_novels_train_manifest.json",
            "kotobank_manifest.json",
            "kotobank_train_manifest.json",
            "aozora_bunko_manifest.json",
            "aozora_bunko_train_manifest.json",
            "desktop_input_output_manifest.json",
            "desktop_input_output_sft.jsonl",
            "six_codes_train_manifest.json",
            "quizjam_train_manifest.json",
        ):
            helper_path = dataset_root / helper_file
            if helper_path.exists():
                helper_path.unlink()
                deleted_paths.append(str(helper_path))
        if not preserve_state:
            for state_file in (
                "progress.json",
                "processed_repo_names.txt",
                "seen_project_ids.txt",
                "seen_pids.txt",
                "seen_novel_ids.txt",
                "seen_user_ids.txt",
                "seen_page_ids.txt",
                "seen_change_ids.txt",
                "seen_source_keys.txt",
                "seen_reference_url_keys.txt",
                "seen_reference_text_hashes.txt",
                "seen_work_ids.txt",
            ):
                state_path = dataset_root / state_file
                if state_path.exists():
                    state_path.unlink()
                    deleted_paths.append(str(state_path))
        _prune_empty_parents(dataset_root)
    return sorted(set(deleted_paths))


def _prune_empty_parents(start: Path) -> None:
    current = start
    while current.exists():
        try:
            current.rmdir()
        except OSError:
            break
        parent = current.parent
        if parent == current:
            break
        current = parent


def _detect_cappuccino_model_dir(start: Path) -> Path | None:
    candidate = start.expanduser().resolve()
    config_path = candidate / "config.json"
    if not config_path.is_file():
        return None
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except ValueError:
        return None
    if not isinstance(payload, dict):
        return None
    model_type = payload.get("model_type")
    if isinstance(model_type, str) and model_type == "cappuccino":
        return candidate
    return None


def cmd_quantize(args: argparse.Namespace) -> None:
    quantize_model(
        hf_path=args.model_path,
        mlx_path=args.out,
        q_bits=args.bits,
        q_group_size=args.group_size,
        include_multimodal=not args.exclude_multimodal,
    )


def cmd_serve(args: argparse.Namespace) -> None:
    default_model_path = args.default_model_path
    if default_model_path is None:
        detected_model_path = _detect_cappuccino_model_dir(Path.cwd())
        if detected_model_path is not None:
            default_model_path = detected_model_path
    app = create_app(
        tool_registry_path=args.tool_registry,
        skill_registry_path=args.skill_registry,
        image_max_long_edge=args.image_max_long_edge,
        image_max_pixels=args.image_max_pixels,
        image_cache_dir=args.image_cache_dir,
        default_model_path=default_model_path,
        public_model_id=args.public_model_id,
        model_aliases=args.model_alias,
    )
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


def cmd_smoke_api(args: argparse.Namespace) -> None:
    base_url = args.base_url.rstrip("/")
    messages: list[dict[str, Any]] = []
    if args.system:
        messages.append({"role": "system", "content": args.system})
    messages.append({"role": "user", "content": args.prompt})

    payload: dict[str, Any] = {
        "model": str(args.model_path.expanduser().resolve()),
        "messages": messages,
        "temperature": 0.2,
        "stream": False,
    }
    if args.max_tokens is not None:
        payload["max_tokens"] = args.max_tokens

    reasoning_mode = args.reasoning_mode
    if reasoning_mode is None and args.thinking is not None:
        reasoning_mode = args.thinking
    if reasoning_mode is None:
        reasoning_mode = "auto"
    normalized_reasoning_mode = normalize_reasoning_mode(reasoning_mode)
    if normalized_reasoning_mode is None:
        raise ValueError("Unsupported reasoning mode. Expected off, on, or auto.")
    reasoning_mode = normalized_reasoning_mode

    if reasoning_mode == "on":
        payload["enable_thinking"] = True
    elif reasoning_mode == "off":
        payload["enable_thinking"] = False
    if args.reasoning_summary != "none" or reasoning_mode == "auto":
        payload["reasoning"] = {
            "mode": reasoning_mode,
            "effort": "low" if reasoning_mode == "on" else "none",
            "summary": args.reasoning_summary,
        }

    response = httpx.post(
        f"{base_url}/v1/chat/completions",
        json=payload,
        timeout=httpx.Timeout(300.0),
    )
    response.raise_for_status()
    print(json.dumps(response.json(), ensure_ascii=False, indent=2))


def cmd_benchmark_reasoning(args: argparse.Namespace) -> None:
    benchmark_modes = _parse_benchmark_modes(args.modes)
    report = run_reasoning_benchmark(
        base_url=args.base_url,
        model=args.model_path,
        modes=benchmark_modes,
        max_tokens=args.max_tokens,
        auto_checkpoint_tokens=args.auto_checkpoint_tokens,
        auto_max_rounds=args.auto_max_rounds,
        request_timeout_sec=args.request_timeout_sec,
        warmup=not args.no_warmup,
        output_path=args.output,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_sample_checkpoints(args: argparse.Namespace) -> None:
    report = sample_saved_checkpoints(
        model_path=args.model_path,
        train_output_dir=args.train_output_dir,
        prompt=args.prompt,
        max_tokens=args.max_tokens,
        max_kv_size=(args.max_kv_size if args.max_kv_size > 0 else None),
        kv_bits=(args.kv_bits if args.kv_bits > 0 else None),
        kv_group_size=args.kv_group_size,
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def cmd_preference_loop(args: argparse.Namespace) -> None:
    report = run_preference_loop(
        PreferenceLoopConfig(
            model_path=str(args.model_path),
            output_dir=str(args.output_dir),
            prompt=args.prompt,
            adapter_path=(str(args.adapter_path) if args.adapter_path is not None else None),
            max_rounds=args.max_rounds,
            max_regenerations_per_round=args.max_regenerations_per_round,
            max_tokens=args.max_tokens,
            candidate_a_temperature=args.candidate_a_temperature,
            candidate_b_temperature=args.candidate_b_temperature,
            candidate_top_p=args.candidate_top_p,
            seed=args.seed,
            train_batch_size=args.train_batch_size,
            train_iters=args.train_iters,
            train_learning_rate=args.train_learning_rate,
            train_grad_checkpoint=args.train_grad_checkpoint,
            train_vision=args.train_vision,
            context_window=args.context_window,
            yarn_factor=args.yarn_factor,
            lora=LoRAHyperparameters(
                num_layers=args.lora_num_layers,
                rank=args.lora_rank,
                scale=args.lora_scale,
                dropout=args.lora_dropout,
            ),
            base_update=BaseWeightUpdateConfig(
                last_layer_count=args.base_last_layers,
                include_norms=args.base_include_norms,
                include_biases=args.base_include_biases,
                include_lm_head=args.base_include_lm_head,
                include_embeddings=args.base_include_embeddings,
                learning_rate_scale=args.base_learning_rate_scale,
                l2_sp_weight=args.base_l2_sp_weight,
            ),
            stability=StabilityConfig(
                replay_dataset_path=None,
                replay_target_fraction=0.0,
                grad_clip_norm=args.grad_clip_norm,
                metal_memory_budget_mode=args.metal_memory_budget_mode,
                metal_memory_limit_bytes=args.metal_memory_limit_bytes,
                metal_wired_limit_bytes=args.metal_wired_limit_bytes,
                metal_cache_limit_bytes=args.metal_cache_limit_bytes,
                metal_cache_clear_interval=args.metal_cache_clear_interval,
                training_memory_reserve_bytes=args.training_memory_reserve_bytes,
                strict_token_audit=args.strict_token_audit,
            ),
            orpo_beta=args.orpo_beta,
        )
    )
    print(json.dumps(report.model_dump(), ensure_ascii=False, indent=2))


def _parse_benchmark_modes(value: str) -> tuple[BenchmarkMode, ...]:
    raw_modes = [item.strip() for item in value.split(",") if item.strip()]
    if not raw_modes:
        raise ValueError(
            f"--modes must include at least one of {', '.join(BENCHMARK_MODES)}."
        )
    return normalize_benchmark_modes(raw_modes)


if __name__ == "__main__":
    main()
