from __future__ import annotations

import copy
import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, cast

from pydantic import BaseModel


SummaryMode = Literal["none", "auto", "concise", "detailed"]
ReasoningMode = Literal["off", "on", "auto"]


class ReasoningControl(BaseModel):
    mode: ReasoningMode = "off"
    enable_thinking: bool = False
    summary: SummaryMode = "none"
    auto_checkpoint_tokens: int = 32
    auto_max_rounds: int = 3

    def summary_for_internal_judge(self) -> SummaryMode:
        if self.summary == "none":
            return "concise"
        return self.summary

    @property
    def adaptive_checkpoint_tokens(self) -> int:
        return self.auto_checkpoint_tokens

    @property
    def adaptive_max_rounds(self) -> int:
        return self.auto_max_rounds


def normalize_reasoning_mode(mode: str | None) -> ReasoningMode | None:
    if mode in {"off", "on", "auto"}:
        return cast(ReasoningMode, mode)
    if mode == "adaptive":
        return "auto"
    return None


def resolve_reasoning_control(
    payload: dict[str, Any],
    *,
    default_mode: ReasoningMode = "off",
) -> ReasoningControl:
    explicit_enable = payload.get("enable_thinking")
    raw_reasoning = payload.get("reasoning")
    reasoning = raw_reasoning if isinstance(raw_reasoning, dict) else {}
    effort = reasoning.get("effort")
    raw_mode = reasoning.get("mode")
    mode = normalize_reasoning_mode(raw_mode if isinstance(raw_mode, str) else None)
    summary = reasoning.get("summary", "none")
    thinking_budget = payload.get("thinking_budget")
    auto_checkpoint_tokens = reasoning.get("checkpoint_tokens", 32)
    auto_max_rounds = reasoning.get("max_rounds", 3)

    if isinstance(explicit_enable, bool):
        mode = "on" if explicit_enable else "off"
        enable_thinking = explicit_enable
    elif mode is not None:
        enable_thinking = mode == "on"
    elif thinking_budget is not None:
        mode = "on"
        enable_thinking = True
    elif isinstance(effort, str):
        mode = "on" if effort != "none" else "off"
        enable_thinking = effort != "none"
    else:
        mode = default_mode
        enable_thinking = default_mode == "on"

    if summary not in {"none", "auto", "concise", "detailed"}:
        summary = "none"

    return ReasoningControl(
        mode=mode,
        enable_thinking=enable_thinking,
        summary=summary,
        auto_checkpoint_tokens=max(1, int(auto_checkpoint_tokens)),
        auto_max_rounds=max(1, int(auto_max_rounds)),
    )


def postprocess_response_body(
    *,
    path: str,
    body: dict[str, Any],
    payload: dict[str, Any],
    control: ReasoningControl,
    reasoning_log_path: str | Path,
) -> dict[str, Any]:
    if path.endswith("/chat/completions"):
        return _postprocess_chat_body(
            body=body,
            payload=payload,
            control=control,
            reasoning_log_path=reasoning_log_path,
        )
    if path.endswith("/responses"):
        return _postprocess_responses_body(
            body=body,
            payload=payload,
            control=control,
            reasoning_log_path=reasoning_log_path,
        )
    return body


def _postprocess_chat_body(
    *,
    body: dict[str, Any],
    payload: dict[str, Any],
    control: ReasoningControl,
    reasoning_log_path: str | Path,
) -> dict[str, Any]:
    if control.mode == "off":
        return body
    choices = body.get("choices")
    if not isinstance(choices, list):
        return body

    for choice in choices:
        if not isinstance(choice, dict):
            continue
        message = choice.get("message")
        if not isinstance(message, dict):
            continue
        content = message.get("content")
        if not isinstance(content, str):
            continue
        reasoning, answer = extract_reasoning_and_answer(content)
        if not reasoning:
            continue
        summary = summarize_reasoning(reasoning, control.summary)
        write_reasoning_log(
            reasoning_log_path=reasoning_log_path,
            payload=payload,
            reasoning=reasoning,
            summary=summary,
            answer=answer,
        )
        message["reasoning_content"] = reasoning
        if summary:
            message["reasoning_summary"] = summary
        message["content"] = answer or summary or content
    return body


def _postprocess_responses_body(
    *,
    body: dict[str, Any],
    payload: dict[str, Any],
    control: ReasoningControl,
    reasoning_log_path: str | Path,
) -> dict[str, Any]:
    if control.mode == "off":
        return _normalize_responses_body(body=body, payload=payload)
    output_items = body.get("output")
    extracted_reasoning: str | None = None
    extracted_answer: str | None = None
    if isinstance(output_items, list):
        for item in output_items:
            if not isinstance(item, dict):
                continue
            content = item.get("content")
            if not isinstance(content, list):
                continue
            for part in content:
                if not isinstance(part, dict):
                    continue
                text = part.get("text")
                if isinstance(text, str):
                    reasoning, answer = extract_reasoning_and_answer(text)
                    if not reasoning:
                        continue
                    if extracted_reasoning is None:
                        extracted_reasoning = reasoning
                        extracted_answer = answer
                    part["text"] = answer or text
                    item["reasoning_content"] = reasoning
                    break

    output_text = body.get("output_text")
    if extracted_reasoning is None and isinstance(output_text, str):
        extracted_reasoning, extracted_answer = extract_reasoning_and_answer(output_text)

    if not extracted_reasoning:
        return _normalize_responses_body(body=body, payload=payload)

    answer_text = extracted_answer or ""
    summary = summarize_reasoning(extracted_reasoning, control.summary)
    write_reasoning_log(
        reasoning_log_path=reasoning_log_path,
        payload=payload,
        reasoning=extracted_reasoning,
        summary=summary,
        answer=answer_text,
    )

    if summary:
        body["reasoning_summary"] = summary
    if isinstance(output_text, str):
        body["output_text"] = answer_text or summary or output_text

    if isinstance(output_items, list):
        for item in output_items:
            if not isinstance(item, dict):
                continue
            if summary and isinstance(item.get("reasoning_content"), str):
                item["reasoning_summary"] = summary
            content = item.get("content")
            if not isinstance(content, list):
                continue
            for part in content:
                if not isinstance(part, dict):
                    continue
                if summary and isinstance(part.get("text"), str):
                    part["reasoning_summary"] = summary
                    break
    return _normalize_responses_body(body=body, payload=payload)


def _normalize_responses_body(*, body: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    output_items = body.get("output")
    normalized_output: list[dict[str, Any]] = []
    if isinstance(output_items, list):
        for item in output_items:
            if isinstance(item, dict):
                normalized_output.append(_normalize_response_output_item(item))
    body["output"] = normalized_output

    derived_output_text = _response_output_text(normalized_output)
    if not isinstance(body.get("output_text"), str) or (
        body.get("output_text") == "" and derived_output_text
    ):
        body["output_text"] = derived_output_text

    body.setdefault("object", "response")
    body.setdefault("status", "completed")

    created_at = body.get("created_at")
    if body.get("status") == "completed" and body.get("completed_at") is None:
        if isinstance(created_at, int):
            body["completed_at"] = created_at

    if not isinstance(body.get("parallel_tool_calls"), bool):
        body["parallel_tool_calls"] = bool(payload.get("parallel_tool_calls", True))

    previous_response_id = payload.get("previous_response_id")
    if body.get("previous_response_id") is None and isinstance(previous_response_id, str):
        body["previous_response_id"] = previous_response_id

    reasoning = body.get("reasoning")
    if not isinstance(reasoning, dict):
        reasoning = {}
    request_reasoning = payload.get("reasoning")
    if not isinstance(request_reasoning, dict):
        request_reasoning = {}
    if "effort" not in reasoning and isinstance(request_reasoning.get("effort"), str):
        reasoning["effort"] = request_reasoning["effort"]
    if "summary" not in reasoning:
        summary = body.get("reasoning_summary")
        reasoning["summary"] = summary if isinstance(summary, str) else None
    body["reasoning"] = reasoning

    if not isinstance(body.get("store"), bool):
        store = payload.get("store", True)
        body["store"] = store if isinstance(store, bool) else True

    if body.get("temperature") is None and payload.get("temperature") is not None:
        body["temperature"] = payload.get("temperature")
    if body.get("top_p") is None and payload.get("top_p") is not None:
        body["top_p"] = payload.get("top_p")

    if not isinstance(body.get("text"), dict):
        text_config = payload.get("text")
        body["text"] = copy.deepcopy(text_config) if isinstance(text_config, dict) else {
            "format": {"type": "text"}
        }

    if body.get("tool_choice") is None:
        requested_tool_choice = payload.get("tool_choice")
        if requested_tool_choice is not None:
            body["tool_choice"] = copy.deepcopy(requested_tool_choice)
        else:
            tools = payload.get("tools")
            body["tool_choice"] = "auto" if isinstance(tools, list) and tools else "none"

    if not isinstance(body.get("tools"), list):
        raw_tools = payload.get("tools")
        body["tools"] = copy.deepcopy(raw_tools) if isinstance(raw_tools, list) else []

    if body.get("max_output_tokens") is None and payload.get("max_output_tokens") is not None:
        body["max_output_tokens"] = payload.get("max_output_tokens")
    if body.get("max_tool_calls") is None and payload.get("max_tool_calls") is not None:
        body["max_tool_calls"] = payload.get("max_tool_calls")
    if body.get("background") is None and isinstance(payload.get("background"), bool):
        body["background"] = payload.get("background")
    if body.get("service_tier") is None and isinstance(payload.get("service_tier"), str):
        body["service_tier"] = payload.get("service_tier")
    if body.get("top_logprobs") is None and payload.get("top_logprobs") is not None:
        body["top_logprobs"] = payload.get("top_logprobs")

    if body.get("truncation") is None:
        body["truncation"] = payload.get("truncation", "disabled")

    if not isinstance(body.get("metadata"), dict):
        metadata = payload.get("metadata")
        body["metadata"] = copy.deepcopy(metadata) if isinstance(metadata, dict) else {}

    if body.get("user") is None and isinstance(payload.get("user"), str):
        body["user"] = payload.get("user")

    usage = body.get("usage")
    if isinstance(usage, dict):
        input_details = usage.get("input_tokens_details")
        if not isinstance(input_details, dict):
            usage["input_tokens_details"] = {"cached_tokens": 0}
        output_details = usage.get("output_tokens_details")
        if not isinstance(output_details, dict):
            reasoning_tokens = usage.get("reasoning_tokens")
            if isinstance(reasoning_tokens, int):
                normalized_reasoning_tokens = reasoning_tokens
            elif isinstance(reasoning_tokens, str):
                try:
                    normalized_reasoning_tokens = int(reasoning_tokens)
                except ValueError:
                    normalized_reasoning_tokens = 0
            else:
                normalized_reasoning_tokens = 0
            usage["output_tokens_details"] = {"reasoning_tokens": normalized_reasoning_tokens}
        usage.pop("reasoning_tokens", None)

    return body


def _normalize_response_output_item(item: dict[str, Any]) -> dict[str, Any]:
    normalized = copy.deepcopy(item)
    item_type = normalized.get("type")
    if not isinstance(item_type, str):
        if normalized.get("role") == "assistant":
            item_type = "message"
        elif isinstance(normalized.get("call_id"), str) and isinstance(normalized.get("name"), str):
            item_type = "function_call"

    if item_type == "message":
        normalized["type"] = "message"
        normalized.setdefault("id", f"msg_{uuid.uuid4().hex}")
        normalized.setdefault("status", "completed")
        normalized.setdefault("role", "assistant")
        normalized["content"] = _normalize_response_message_content(normalized.get("content"))
        return normalized

    if item_type == "function_call":
        normalized["type"] = "function_call"
        normalized.setdefault("id", f"fc_{uuid.uuid4().hex}")
        normalized.setdefault("status", "completed")
        return normalized

    return normalized


def _normalize_response_message_content(content: Any) -> list[dict[str, Any]]:
    if isinstance(content, str):
        return [{"type": "output_text", "text": content, "annotations": []}]
    if not isinstance(content, list):
        return []

    normalized_content: list[dict[str, Any]] = []
    for part in content:
        if not isinstance(part, dict):
            continue
        normalized_part = copy.deepcopy(part)
        part_type = normalized_part.get("type")
        if not isinstance(part_type, str) and isinstance(normalized_part.get("text"), str):
            normalized_part["type"] = "output_text"
        elif part_type == "text":
            normalized_part["type"] = "output_text"
        if normalized_part.get("type") == "output_text":
            if not isinstance(normalized_part.get("annotations"), list):
                normalized_part["annotations"] = []
        normalized_content.append(normalized_part)
    return normalized_content


def _response_output_text(output_items: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for item in output_items:
        if item.get("type") != "message":
            continue
        content = item.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if isinstance(part, dict) and isinstance(part.get("text"), str):
                parts.append(part["text"])
    return "\n".join(part for part in parts if part)


def extract_reasoning_and_answer(
    text: str,
    *,
    allow_reasoning_only: bool = False,
) -> tuple[str | None, str]:
    stripped = text.lstrip()
    if stripped.startswith("<think>") and "</think>" in stripped:
        thinking_text, answer = stripped.split("</think>", 1)
        thinking_text = thinking_text.replace("<think>", "", 1).strip()
        answer = answer.strip()
        if answer or allow_reasoning_only:
            return thinking_text or None, answer
        return None, text.strip()
    if allow_reasoning_only and stripped.startswith("<think>"):
        _, thinking_text = stripped.split("<think>", 1)
        return thinking_text.strip() or None, ""
    if text.lstrip().startswith("Thinking Process:"):
        return text.strip(), ""
    return None, text.strip()


def summarize_reasoning(reasoning: str, mode: SummaryMode) -> str | None:
    if mode == "none":
        return None

    cleaned_lines: list[str] = []
    for raw_line in reasoning.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.lower() == "thinking process:":
            continue
        line = re.sub(r"^[\-\*\d\.\)\s]+", "", line)
        line = line.replace("**", "").strip()
        if len(line) < 8:
            continue
        cleaned_lines.append(line)

    if not cleaned_lines:
        cleaned_lines = [
            sentence.strip()
            for sentence in re.split(r"(?<=[.!?。！？])\s+", reasoning.replace("\n", " "))
            if len(sentence.strip()) >= 8
        ]

    line_budget = {"auto": 3, "concise": 2, "detailed": 5}[mode]
    selected = cleaned_lines[:line_budget]
    if not selected:
        return None
    return " / ".join(selected)


def write_reasoning_log(
    *,
    reasoning_log_path: str | Path,
    payload: dict[str, Any],
    reasoning: str,
    summary: str | None,
    answer: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    log_path = Path(reasoning_log_path).expanduser().resolve()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "model": payload.get("model"),
        "reasoning_full": reasoning,
        "reasoning_summary": summary,
        "answer": answer,
    }
    if metadata:
        record["metadata"] = metadata
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def strip_internal_reasoning_fields(body: dict[str, Any]) -> dict[str, Any]:
    cleaned = copy.deepcopy(body)
    choices = cleaned.get("choices")
    if isinstance(choices, list):
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            message = choice.get("message")
            if isinstance(message, dict):
                message.pop("reasoning_content", None)

    output_items = cleaned.get("output")
    if isinstance(output_items, list):
        for item in output_items:
            if not isinstance(item, dict):
                continue
            item.pop("reasoning_content", None)
            content = item.get("content")
            if not isinstance(content, list):
                continue
            for part in content:
                if isinstance(part, dict):
                    part.pop("reasoning_content", None)
    return cleaned
