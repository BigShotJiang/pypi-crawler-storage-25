from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from textwrap import dedent
from typing import Iterable, Literal

import httpx
from pydantic import BaseModel

from .reasoning import extract_reasoning_and_answer, normalize_reasoning_mode


BenchmarkMode = Literal["off", "on", "auto"]
BENCHMARK_MODES: tuple[BenchmarkMode, ...] = ("off", "on", "auto")


class BenchmarkTask(BaseModel):
    name: str
    prompt: str
    evaluator: str


class BenchmarkCaseResult(BaseModel):
    mode: BenchmarkMode
    task: str
    passed: bool
    elapsed_sec: float
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None
    prompt_tps: float | None = None
    generation_tps: float | None = None
    reasoning_summary: str | None = None
    request_error: str | None = None
    assistant_content: str
    candidate_code: str
    evaluation_output: str


class BenchmarkModeSummary(BaseModel):
    mode: BenchmarkMode
    task_count: int
    passed_tasks: int
    quality_score: float
    avg_elapsed_sec: float
    avg_prompt_tps: float | None = None
    avg_generation_tps: float | None = None


class BenchmarkReport(BaseModel):
    created_at: str
    base_url: str
    model: str
    modes: list[BenchmarkMode]
    max_tokens: int | None = None
    tasks: list[str]
    results: list[BenchmarkCaseResult]
    summaries: list[BenchmarkModeSummary]


def run_reasoning_benchmark(
    *,
    base_url: str,
    model: str | Path,
    modes: tuple[BenchmarkMode, ...] = BENCHMARK_MODES,
    max_tokens: int | None = None,
    auto_checkpoint_tokens: int = 64,
    auto_max_rounds: int = 3,
    request_timeout_sec: float = 120.0,
    warmup: bool = True,
    output_path: str | Path | None = None,
) -> BenchmarkReport:
    normalized_model = str(Path(model).expanduser().resolve())
    normalized_base_url = base_url.rstrip("/")
    normalized_modes = normalize_benchmark_modes(modes)
    results: list[BenchmarkCaseResult] = []
    tasks = default_benchmark_tasks()

    if warmup:
        _warmup_model(
            base_url=normalized_base_url,
            model=normalized_model,
            request_timeout_sec=request_timeout_sec,
        )

    for mode in normalized_modes:
        for task in tasks:
            results.append(
                _run_single_case(
                    base_url=normalized_base_url,
                    model=normalized_model,
                    task=task,
                    mode=mode,
                    max_tokens=max_tokens,
                    auto_checkpoint_tokens=auto_checkpoint_tokens,
                    auto_max_rounds=auto_max_rounds,
                    request_timeout_sec=request_timeout_sec,
                )
            )

    report = BenchmarkReport(
        created_at=datetime.now(timezone.utc).isoformat(),
        base_url=normalized_base_url,
        model=normalized_model,
        modes=list(normalized_modes),
        max_tokens=max_tokens,
        tasks=[task.name for task in tasks],
        results=results,
        summaries=_summaries(results),
    )
    if output_path is not None:
        report_path = Path(output_path).expanduser().resolve()
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(
            json.dumps(report.model_dump(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return report


def normalize_benchmark_modes(
    modes: Iterable[BenchmarkMode | str],
) -> tuple[BenchmarkMode, ...]:
    normalized_modes: list[BenchmarkMode] = []
    for raw_mode in modes:
        normalized_mode = normalize_reasoning_mode(str(raw_mode))
        if normalized_mode is None or normalized_mode not in BENCHMARK_MODES:
            raise ValueError(
                f"Unsupported benchmark mode: {raw_mode}. Expected one of {BENCHMARK_MODES}."
            )
        mode = normalized_mode
        if mode not in normalized_modes:
            normalized_modes.append(mode)
    if not normalized_modes:
        raise ValueError("At least one benchmark mode must be selected.")
    return tuple(normalized_modes)


def default_benchmark_tasks() -> list[BenchmarkTask]:
    return [
        BenchmarkTask(
            name="compress_ranges",
            prompt=dedent(
                """
                Write Python code that defines `compress_ranges(values: list[int]) -> str`.

                Requirements:
                - `values` is a sorted list of unique integers.
                - Consecutive runs of length 3 or more become `"start-end"`.
                - Runs of length 2 become `"a,b"`.
                - Single values become `"a"`.
                - Join all pieces with commas.
                - Return only Python code. No explanation.

                Examples:
                - `compress_ranges([]) == ""`
                - `compress_ranges([1]) == "1"`
                - `compress_ranges([1, 2]) == "1,2"`
                - `compress_ranges([1, 2, 3, 5, 6, 8, 9, 10]) == "1-3,5,6,8-10"`
                - `compress_ranges([-3, -2, -1, 2, 4, 5, 6]) == "-3--1,2,4-6"`
                """
            ).strip(),
            evaluator=dedent(
                """
                from candidate import compress_ranges

                assert compress_ranges([]) == ""
                assert compress_ranges([1]) == "1"
                assert compress_ranges([1, 2]) == "1,2"
                assert compress_ranges([1, 2, 3]) == "1-3"
                assert compress_ranges([1, 2, 3, 5, 6, 8, 9, 10]) == "1-3,5,6,8-10"
                assert compress_ranges([-3, -2, -1, 2, 4, 5, 6]) == "-3--1,2,4-6"
                assert compress_ranges([0, 2, 3, 4, 8, 9, 11]) == "0,2-4,8,9,11"
                """
            ).strip(),
        ),
        BenchmarkTask(
            name="merge_patch",
            prompt=dedent(
                """
                Write Python code that defines `merge_patch(base: dict[str, object], patch: dict[str, object]) -> dict[str, object]`.

                Requirements:
                - Return a new dictionary and do not mutate either input.
                - Start from a deep copy of `base`.
                - For each key in `patch`:
                  - if the patch value is `None`, remove that key from the result if present;
                  - if both the current result value and the patch value are dictionaries, recurse with the same rules;
                  - otherwise replace the result value with a deep copy of the patch value.
                - Return only Python code. No explanation.
                """
            ).strip(),
            evaluator=dedent(
                """
                from candidate import merge_patch

                base = {
                    "service": {"name": "cappuccino", "ports": [80, 443]},
                    "enabled": True,
                    "region": "tokyo",
                }
                patch = {
                    "service": {"ports": [8080], "owner": "ml"},
                    "enabled": None,
                    "retries": 3,
                }
                result = merge_patch(base, patch)
                assert result == {
                    "service": {"name": "cappuccino", "ports": [8080], "owner": "ml"},
                    "region": "tokyo",
                    "retries": 3,
                }
                assert base == {
                    "service": {"name": "cappuccino", "ports": [80, 443]},
                    "enabled": True,
                    "region": "tokyo",
                }
                assert patch == {
                    "service": {"ports": [8080], "owner": "ml"},
                    "enabled": None,
                    "retries": 3,
                }
                result["service"]["ports"].append(9000)
                assert base["service"]["ports"] == [80, 443]
                nested = merge_patch({"a": {"b": {"c": 1, "d": 2}}}, {"a": {"b": {"c": None}}})
                assert nested == {"a": {"b": {"d": 2}}}
                """
            ).strip(),
        ),
        BenchmarkTask(
            name="rank_tool_matches",
            prompt=dedent(
                """
                Write Python code that defines
                `rank_tool_matches(tools: list[dict[str, object]], query: str, limit: int = 5) -> list[str]`.

                Requirements:
                - Each tool has keys `name`, `description`, and optional `tags`.
                - Normalize strings to lowercase alphanumeric tokens.
                - Score each tool as follows:
                  - name exact phrase match: +5
                  - description exact phrase match: +3
                  - tags exact phrase match: +4
                  - each matching query token in name: +1
                  - each matching query token in description: +0.5
                  - each matching query token in tags: +0.75
                - Ignore tools with score `<= 0`.
                - Return the top tool names sorted by descending score, then ascending name.
                - Return only Python code. No explanation.
                """
            ).strip(),
            evaluator=dedent(
                """
                from candidate import rank_tool_matches

                tools = [
                    {
                        "name": "tool_search",
                        "description": "Search tools by name description and tags",
                        "tags": ["tools", "search", "registry"],
                    },
                    {
                        "name": "video_caption_timeline",
                        "description": "Generate caption timeline from uploaded video",
                        "tags": ["video", "caption", "timeline"],
                    },
                    {
                        "name": "image_resize",
                        "description": "Downscale oversized images before vision inference",
                        "tags": ["image", "vision", "resize"],
                    },
                ]

                assert rank_tool_matches(tools, "video caption timeline", limit=2) == [
                    "video_caption_timeline",
                    "tool_search",
                ]
                assert rank_tool_matches(tools, "resize vision", limit=5) == ["image_resize"]
                assert rank_tool_matches(tools, "registry search", limit=5)[0] == "tool_search"
                assert rank_tool_matches(tools, "nonexistent", limit=5) == []
                """
            ).strip(),
        ),
    ]


def _run_single_case(
    *,
    base_url: str,
    model: str,
    task: BenchmarkTask,
    mode: BenchmarkMode,
    max_tokens: int | None,
    auto_checkpoint_tokens: int,
    auto_max_rounds: int,
    request_timeout_sec: float,
) -> BenchmarkCaseResult:
    payload = _build_payload(
        model=model,
        task=task,
        mode=mode,
        max_tokens=max_tokens,
        auto_checkpoint_tokens=auto_checkpoint_tokens,
        auto_max_rounds=auto_max_rounds,
    )

    started_at = time.perf_counter()
    try:
        response = httpx.post(
            f"{base_url}/v1/chat/completions",
            json=payload,
            timeout=httpx.Timeout(request_timeout_sec),
        )
        elapsed_sec = round(time.perf_counter() - started_at, 3)
        response.raise_for_status()

        body = response.json()
        if not isinstance(body, dict):
            raise ValueError("Benchmark expected a JSON object response.")
        assistant_content, reasoning_summary = _extract_content_and_summary(body)
        candidate_code = _extract_candidate_code(assistant_content)
        passed, evaluation_output = _evaluate_candidate(
            task=task,
            candidate_code=candidate_code,
        )
        usage = body.get("usage")
        usage_dict = usage if isinstance(usage, dict) else {}

        return BenchmarkCaseResult(
            mode=mode,
            task=task.name,
            passed=passed,
            elapsed_sec=elapsed_sec,
            prompt_tokens=_optional_int(
                usage_dict.get("prompt_tokens", usage_dict.get("input_tokens"))
            ),
            completion_tokens=_optional_int(
                usage_dict.get("completion_tokens", usage_dict.get("output_tokens"))
            ),
            total_tokens=_optional_int(usage_dict.get("total_tokens")),
            prompt_tps=_optional_float(usage_dict.get("prompt_tps")),
            generation_tps=_optional_float(usage_dict.get("generation_tps")),
            reasoning_summary=reasoning_summary,
            assistant_content=assistant_content,
            candidate_code=candidate_code,
            evaluation_output=evaluation_output,
        )
    except Exception as exc:
        elapsed_sec = round(time.perf_counter() - started_at, 3)
        return BenchmarkCaseResult(
            mode=mode,
            task=task.name,
            passed=False,
            elapsed_sec=elapsed_sec,
            request_error=str(exc),
            assistant_content="",
            candidate_code="",
            evaluation_output=f"request failed: {exc}",
        )


def _warmup_model(*, base_url: str, model: str, request_timeout_sec: float) -> None:
    warmup_payload = {
        "model": model,
        "messages": [{"role": "user", "content": "日本語で短く自己紹介して。"}],
        "enable_thinking": False,
        "stream": False,
    }
    response = httpx.post(
        f"{base_url}/v1/chat/completions",
        json=warmup_payload,
        timeout=httpx.Timeout(request_timeout_sec),
    )
    response.raise_for_status()


def _build_payload(
    *,
    model: str,
    task: BenchmarkTask,
    mode: BenchmarkMode,
    max_tokens: int | None,
    auto_checkpoint_tokens: int,
    auto_max_rounds: int,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are a careful Python coding assistant. Return only executable Python code.",
            },
            {
                "role": "user",
                "content": task.prompt,
            },
        ],
        "temperature": 0.0,
        "stream": False,
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens

    if mode == "off":
        payload["enable_thinking"] = False
    elif mode == "on":
        payload["enable_thinking"] = True
    else:
        payload["reasoning"] = {
            "mode": "auto",
            "summary": "none",
            "checkpoint_tokens": auto_checkpoint_tokens,
            "max_rounds": auto_max_rounds,
        }
    return payload


def _extract_content_and_summary(body: dict[str, object]) -> tuple[str, str | None]:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return "", None
    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        return "", None
    message = first_choice.get("message")
    if not isinstance(message, dict):
        return "", None
    content = message.get("content")
    reasoning_summary = message.get("reasoning_summary")
    if not isinstance(content, str):
        content = ""
    if not isinstance(reasoning_summary, str):
        reasoning_summary = None
    return content, reasoning_summary


def _extract_candidate_code(text: str) -> str:
    _, answer = extract_reasoning_and_answer(text)
    source = answer or text
    fenced_blocks: list[str] = re.findall(
        r"```(?:python)?\s*(.*?)```",
        source,
        flags=re.DOTALL | re.IGNORECASE,
    )
    if fenced_blocks:
        return max(fenced_blocks, key=len).strip()

    for marker in ("from ", "import ", "def ", "class "):
        offset = source.find(marker)
        if offset >= 0:
            return source[offset:].strip()
    return source.strip()


def _evaluate_candidate(*, task: BenchmarkTask, candidate_code: str) -> tuple[bool, str]:
    with tempfile.TemporaryDirectory(prefix="cappuccino-bench-") as temp_dir:
        temp_path = Path(temp_dir)
        candidate_path = temp_path / "candidate.py"
        evaluator_path = temp_path / "evaluate_candidate.py"
        candidate_path.write_text(candidate_code + "\n", encoding="utf-8")
        evaluator_path.write_text(task.evaluator + "\n", encoding="utf-8")

        completed = subprocess.run(
            [sys.executable, str(evaluator_path)],
            cwd=temp_path,
            capture_output=True,
            text=True,
            check=False,
        )
        output = "\n".join(
            part.strip()
            for part in (completed.stdout, completed.stderr)
            if part.strip()
        )
        if not output:
            output = "ok"
        return completed.returncode == 0, output


def _summaries(results: list[BenchmarkCaseResult]) -> list[BenchmarkModeSummary]:
    summaries: list[BenchmarkModeSummary] = []
    for mode in BENCHMARK_MODES:
        mode_results = [result for result in results if result.mode == mode]
        if not mode_results:
            continue
        prompt_tps_values = [
            result.prompt_tps for result in mode_results if result.prompt_tps is not None
        ]
        generation_tps_values = [
            result.generation_tps
            for result in mode_results
            if result.generation_tps is not None
        ]
        summaries.append(
            BenchmarkModeSummary(
                mode=mode,
                task_count=len(mode_results),
                passed_tasks=sum(1 for result in mode_results if result.passed),
                quality_score=round(
                    sum(1 for result in mode_results if result.passed) / len(mode_results),
                    3,
                ),
                avg_elapsed_sec=round(
                    sum(result.elapsed_sec for result in mode_results) / len(mode_results),
                    3,
                ),
                avg_prompt_tps=_average_or_none(prompt_tps_values),
                avg_generation_tps=_average_or_none(generation_tps_values),
            )
        )
    return summaries


def _average_or_none(values: list[float]) -> float | None:
    if not values:
        return None
    return round(sum(values) / len(values), 3)


def _optional_float(value: object) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _optional_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None
