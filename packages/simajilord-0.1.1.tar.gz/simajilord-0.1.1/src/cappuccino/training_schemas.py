from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Any, Iterator, Literal

from pydantic import BaseModel, Field, TypeAdapter, model_validator

from .dataset_manifests import iter_sequential_cpt_source_paths


class TextPart(BaseModel):
    type: Literal["text", "input_text"]
    text: str


class ImagePart(BaseModel):
    type: Literal["image", "input_image", "image_url"]
    image: str | None = None
    image_url: str | None = None
    detail: Literal["high", "low", "auto"] = "auto"

    @model_validator(mode="after")
    def validate_source(self) -> "ImagePart":
        if not self.image and not self.image_url:
            raise ValueError("image or image_url is required for image parts.")
        return self


class AudioPart(BaseModel):
    type: Literal["audio", "input_audio"]
    audio: str | None = None
    input_audio: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_source(self) -> "AudioPart":
        if self.audio is None and self.input_audio is None:
            raise ValueError("audio or input_audio is required for audio parts.")
        return self


class VideoPart(BaseModel):
    type: Literal["video", "input_video", "video_url"]
    video: str | None = None
    video_url: str | None = None
    fps: float | None = None
    max_frames: int | None = None

    @model_validator(mode="after")
    def validate_source(self) -> "VideoPart":
        if not self.video and not self.video_url:
            raise ValueError("video or video_url is required for video parts.")
        return self


ContentPart = Annotated[TextPart | ImagePart | AudioPart | VideoPart, Field(discriminator="type")]


class ToolFunction(BaseModel):
    name: str
    arguments: dict[str, Any]


class ToolCall(BaseModel):
    id: str | None = None
    type: Literal["function"] = "function"
    function: ToolFunction


class TrainingMessage(BaseModel):
    role: Literal["system", "developer", "user", "assistant", "tool"]
    content: str | list[ContentPart] | None = None
    reasoning_content: str | None = None
    tool_calls: list[ToolCall] = Field(default_factory=list)
    name: str | None = None

    @model_validator(mode="after")
    def validate_reasoning_channel(self) -> "TrainingMessage":
        if self.reasoning_content is None:
            return self
        if self.role != "assistant":
            raise ValueError("reasoning_content is only supported on assistant messages.")
        if isinstance(self.content, list):
            raise ValueError("reasoning_content requires string or null assistant content.")
        return self


TrainingFocus = Literal[
    "style",
    "knowledge",
    "reasoning",
    "tools",
    "retrieval",
    "multiturn",
    "multimodal",
    "vision",
    "video",
    "audio",
    "coding",
]


class ContinualPretrainingExample(BaseModel):
    task_type: Literal["cpt"] = "cpt"
    text: str
    focus: list[TrainingFocus] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatSFTExample(BaseModel):
    task_type: Literal["chat_sft"] = "chat_sft"
    messages: list[TrainingMessage]
    tools: list[dict[str, Any]] = Field(default_factory=list)
    focus: list[TrainingFocus] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


PreferenceSequence = str | list[TrainingMessage]


class PreferenceExample(BaseModel):
    task_type: Literal["preference"] = "preference"
    chosen: PreferenceSequence
    rejected: PreferenceSequence
    tools: list[dict[str, Any]] = Field(default_factory=list)
    focus: list[TrainingFocus] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


TrainingExample = Annotated[
    ContinualPretrainingExample | ChatSFTExample | PreferenceExample,
    Field(discriminator="task_type"),
]


class DatasetValidationReport(BaseModel):
    path: str
    total_examples: int
    task_counts: dict[str, int]
    modality_counts: dict[str, int]
    focus_counts: dict[str, int]


TRAINING_EXAMPLE_ADAPTER: TypeAdapter[
    ContinualPretrainingExample | ChatSFTExample | PreferenceExample
] = TypeAdapter(TrainingExample)


def parse_training_example(
    payload: dict[str, Any],
) -> ContinualPretrainingExample | ChatSFTExample | PreferenceExample:
    if "task_type" not in payload:
        if "messages" in payload:
            payload = {"task_type": "chat_sft", **payload}
        elif "chosen" in payload and "rejected" in payload:
            payload = {"task_type": "preference", **payload}
        elif "text" in payload:
            payload = {"task_type": "cpt", **payload}
        else:
            raise ValueError("Unable to infer task_type from payload.")
    parsed = TRAINING_EXAMPLE_ADAPTER.validate_python(payload)
    return parsed


def validate_jsonl(path: str | Path) -> DatasetValidationReport:
    task_counts = {"cpt": 0, "chat_sft": 0, "preference": 0}
    modality_counts = {
        "image": 0,
        "audio": 0,
        "video": 0,
        "tool_calls": 0,
        "tool_results": 0,
        "reasoning_messages": 0,
    }
    focus_counts = {
        "style": 0,
        "knowledge": 0,
        "reasoning": 0,
        "tools": 0,
        "retrieval": 0,
        "multiturn": 0,
        "multimodal": 0,
        "vision": 0,
        "video": 0,
        "audio": 0,
        "coding": 0,
    }
    total_examples = 0

    for payload in _iter_training_example_payloads(path):
        parsed = parse_training_example(payload)
        total_examples += 1
        task_counts[parsed.task_type] = task_counts.get(parsed.task_type, 0) + 1
        for focus in parsed.focus:
            focus_counts[focus] = focus_counts.get(focus, 0) + 1
        if isinstance(parsed, ChatSFTExample):
            for message in parsed.messages:
                if message.reasoning_content is not None:
                    modality_counts["reasoning_messages"] += 1
                if message.tool_calls:
                    modality_counts["tool_calls"] += 1
                if message.role == "tool":
                    modality_counts["tool_results"] += 1
                if not isinstance(message.content, list):
                    continue
                for part in message.content:
                    if isinstance(part, ImagePart):
                        modality_counts["image"] += 1
                    elif isinstance(part, AudioPart):
                        modality_counts["audio"] += 1
                    elif isinstance(part, VideoPart):
                        modality_counts["video"] += 1
        elif isinstance(parsed, PreferenceExample):
            for sequence in (parsed.chosen, parsed.rejected):
                if not isinstance(sequence, list):
                    continue
                for message in sequence:
                    if message.reasoning_content is not None:
                        modality_counts["reasoning_messages"] += 1
                    if message.tool_calls:
                        modality_counts["tool_calls"] += 1
                    if message.role == "tool":
                        modality_counts["tool_results"] += 1
                    if not isinstance(message.content, list):
                        continue
                    for part in message.content:
                        if isinstance(part, ImagePart):
                            modality_counts["image"] += 1
                        elif isinstance(part, AudioPart):
                            modality_counts["audio"] += 1
                        elif isinstance(part, VideoPart):
                            modality_counts["video"] += 1

    return DatasetValidationReport(
        path=str(Path(path).expanduser().resolve()),
        total_examples=total_examples,
        task_counts=task_counts,
        modality_counts=modality_counts,
        focus_counts=focus_counts,
    )


def _iter_training_example_payloads(path: str | Path) -> Iterator[dict[str, Any]]:
    resolved_path = Path(path).expanduser().resolve()
    for source_path in iter_sequential_cpt_source_paths(resolved_path):
        for line in source_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            yield json.loads(line)
