from __future__ import annotations

import html
import json
import re
from typing import Any

import httpx
from pydantic import BaseModel, Field


class WikipediaSearchHit(BaseModel):
    pageid: int
    title: str
    snippet: str
    extract: str
    url: str
    language: str


class WikipediaSearchRequest(BaseModel):
    query: str
    limit: int = Field(default=5, ge=1, le=10)
    language: str = Field(default="ja", min_length=2, max_length=12)


class WikipediaSearchResponse(BaseModel):
    query: str
    limit: int
    language: str
    results: list[WikipediaSearchHit]

    def as_tool_output(self) -> str:
        return json.dumps(self.model_dump(), ensure_ascii=False)


def search_wikipedia(
    *,
    query: str,
    limit: int = 5,
    language: str = "ja",
) -> WikipediaSearchResponse:
    normalized_language = re.sub(r"[^a-zA-Z-]", "", language).lower() or "ja"
    base_url = f"https://{normalized_language}.wikipedia.org/w/api.php"
    with httpx.Client(
        timeout=httpx.Timeout(20.0),
        headers={
            "User-Agent": "Cappuccino/0.1 (local runtime; contact: local-only)",
            "Accept": "application/json",
        },
    ) as client:
        search_response = client.get(
            base_url,
            params={
                "action": "query",
                "list": "search",
                "srsearch": query,
                "srlimit": limit,
                "srprop": "snippet",
                "utf8": 1,
                "format": "json",
            },
        )
        search_response.raise_for_status()
        search_body = search_response.json()
        search_items = search_body.get("query", {}).get("search", [])
        if not isinstance(search_items, list) or not search_items:
            return WikipediaSearchResponse(
                query=query,
                limit=limit,
                language=normalized_language,
                results=[],
            )

        page_ids = [
            str(item["pageid"])
            for item in search_items
            if isinstance(item, dict) and isinstance(item.get("pageid"), int)
        ]
        extract_lookup: dict[int, dict[str, Any]] = {}
        if page_ids:
            extract_response = client.get(
                base_url,
                params={
                    "action": "query",
                    "pageids": "|".join(page_ids),
                    "prop": "extracts|info",
                    "exintro": 1,
                    "explaintext": 1,
                    "inprop": "url",
                    "utf8": 1,
                    "format": "json",
                },
            )
            extract_response.raise_for_status()
            extract_body = extract_response.json()
            pages = extract_body.get("query", {}).get("pages", {})
            if isinstance(pages, dict):
                for page in pages.values():
                    if isinstance(page, dict) and isinstance(page.get("pageid"), int):
                        extract_lookup[page["pageid"]] = page

    hits: list[WikipediaSearchHit] = []
    for item in search_items:
        if not isinstance(item, dict):
            continue
        pageid = item.get("pageid")
        title = item.get("title")
        if not isinstance(pageid, int) or not isinstance(title, str):
            continue
        page = extract_lookup.get(pageid, {})
        snippet = _clean_wikipedia_text(item.get("snippet"))
        extract = _clean_wikipedia_text(page.get("extract"))
        url = page.get("fullurl")
        if not isinstance(url, str):
            url = f"https://{normalized_language}.wikipedia.org/?curid={pageid}"
        hits.append(
            WikipediaSearchHit(
                pageid=pageid,
                title=title,
                snippet=snippet,
                extract=extract,
                url=url,
                language=normalized_language,
            )
        )

    return WikipediaSearchResponse(
        query=query,
        limit=limit,
        language=normalized_language,
        results=hits,
    )


def wikipedia_tool_output(arguments: dict[str, Any]) -> str:
    query = arguments.get("query")
    if not isinstance(query, str) or not query.strip():
        raise ValueError("wikipedia_search requires a non-empty query string.")
    limit = arguments.get("limit", 5)
    language = arguments.get("language", "ja")
    try:
        response = search_wikipedia(
            query=query,
            limit=max(1, int(limit)),
            language=str(language),
        )
    except httpx.HTTPError as exc:
        raise ValueError(f"wikipedia_search failed: {exc}") from exc
    return response.as_tool_output()


def _clean_wikipedia_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    text = html.unescape(value)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()
