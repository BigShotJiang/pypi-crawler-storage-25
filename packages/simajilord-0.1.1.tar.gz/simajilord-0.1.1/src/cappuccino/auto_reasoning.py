from __future__ import annotations

import copy
import json
import re
from typing import Any, Awaitable, Callable

from .reasoning import ReasoningControl, SummaryMode, summarize_reasoning, write_reasoning_log

JsonCaller = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]


async def run_structured_reasoning_chat_completion(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_model: JsonCaller,
    reasoning_log_path: str,
) -> dict[str, Any]:
    if control.mode == "auto":
        return await run_auto_chat_completion(
            payload=payload,
            control=control,
            call_model=call_model,
            reasoning_log_path=reasoning_log_path,
        )
    if control.mode == "on":
        return await run_on_chat_completion(
            payload=payload,
            control=control,
            call_model=call_model,
            reasoning_log_path=reasoning_log_path,
        )
    raise ValueError("Structured reasoning runtime only supports mode=on or mode=auto.")


async def run_on_chat_completion(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_model: JsonCaller,
    reasoning_log_path: str,
) -> dict[str, Any]:
    envelope = await _generate_reasoning_envelope(
        payload=payload,
        control=control,
        call_model=call_model,
        scratchpad_summaries=[],
        max_tokens=_reasoning_token_budget(payload),
        default_continue=False,
        mode="on",
    )
    summary = _reasoning_summary(
        envelope["reasoning_content"],
        control.summary_for_internal_judge(),
    )
    scratchpad_summaries = [summary] if summary else []
    final_summary = _final_summary(scratchpad_summaries, control.summary)

    write_reasoning_log(
        reasoning_log_path=reasoning_log_path,
        payload=payload,
        reasoning=envelope["reasoning_content"],
        summary=summary,
        answer=envelope["candidate_answer"],
        metadata={
            "phase": "on_think",
            "round": 1,
            "decision": {
                "accept_answer": envelope["accept_answer"],
                "continue_thinking": envelope["continue_thinking"],
                "confidence": envelope["confidence"],
                "rationale": envelope["rationale"],
                "source": envelope["source"],
            },
        },
    )

    if _can_short_circuit_with_candidate(
        payload=payload,
        candidate_answer=envelope["candidate_answer"],
        accept_answer=envelope["accept_answer"],
    ):
        final_body = _build_direct_answer_body(payload=payload, answer=envelope["candidate_answer"])
        _attach_reasoning_artifacts(
            final_body,
            reasoning_content=envelope["reasoning_content"],
            summary=final_summary,
        )
        _write_final_log(
            reasoning_log_path=reasoning_log_path,
            payload=payload,
            reasoning=envelope["reasoning_content"],
            summary=final_summary,
            final_body=final_body,
            phase="on_direct_answer",
        )
        return final_body

    final_body = await _generate_final_answer(
        payload=payload,
        scratchpad_summaries=scratchpad_summaries,
        call_model=call_model,
    )
    _attach_reasoning_artifacts(
        final_body,
        reasoning_content=envelope["reasoning_content"],
        summary=final_summary,
    )
    _write_final_log(
        reasoning_log_path=reasoning_log_path,
        payload=payload,
        reasoning=envelope["reasoning_content"],
        summary=final_summary,
        final_body=final_body,
        phase="on_final",
    )
    return final_body


async def run_auto_chat_completion(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_model: JsonCaller,
    reasoning_log_path: str,
) -> dict[str, Any]:
    scratchpad_summaries: list[str] = []
    last_reasoning = ""
    for round_index in range(control.auto_max_rounds):
        envelope = await _generate_reasoning_envelope(
            payload=payload,
            control=control,
            call_model=call_model,
            scratchpad_summaries=scratchpad_summaries,
            max_tokens=control.auto_checkpoint_tokens,
            default_continue=True,
            mode="auto",
        )
        reasoning = envelope["reasoning_content"]
        candidate_answer = envelope["candidate_answer"]
        summary = _reasoning_summary(reasoning, control.summary_for_internal_judge())
        if summary:
            scratchpad_summaries.append(summary)
        last_reasoning = reasoning or last_reasoning

        decision = _resolve_auto_decision(payload=payload, envelope=envelope)
        write_reasoning_log(
            reasoning_log_path=reasoning_log_path,
            payload=payload,
            reasoning=reasoning,
            summary=summary,
            answer=candidate_answer,
            metadata={
                "phase": "auto_think",
                "round": round_index + 1,
                "decision": decision,
            },
        )

        if _can_short_circuit_with_candidate(
            payload=payload,
            candidate_answer=candidate_answer,
            accept_answer=bool(decision.get("accept_answer", False)),
        ):
            final_body = _build_direct_answer_body(payload=payload, answer=candidate_answer)
            final_summary = _final_summary(scratchpad_summaries, control.summary)
            _attach_reasoning_artifacts(
                final_body,
                reasoning_content=reasoning,
                summary=final_summary,
            )
            _write_final_log(
                reasoning_log_path=reasoning_log_path,
                payload=payload,
                reasoning=reasoning,
                summary=final_summary,
                final_body=final_body,
                phase="auto_direct_answer",
            )
            return final_body

        if not bool(decision.get("continue_thinking", False)):
            final_body = await _generate_final_answer(
                payload=payload,
                scratchpad_summaries=scratchpad_summaries,
                call_model=call_model,
            )
            final_summary = _final_summary(scratchpad_summaries, control.summary)
            _attach_reasoning_artifacts(
                final_body,
                reasoning_content=reasoning or _reasoning_history_content(scratchpad_summaries),
                summary=final_summary,
            )
            _write_final_log(
                reasoning_log_path=reasoning_log_path,
                payload=payload,
                reasoning=reasoning or last_reasoning,
                summary=final_summary,
                final_body=final_body,
                phase="auto_final",
            )
            return final_body

    final_body = await _generate_final_answer(
        payload=payload,
        scratchpad_summaries=scratchpad_summaries,
        call_model=call_model,
    )
    final_summary = _final_summary(scratchpad_summaries, control.summary)
    _attach_reasoning_artifacts(
        final_body,
        reasoning_content=last_reasoning or _reasoning_history_content(scratchpad_summaries),
        summary=final_summary,
    )
    _write_final_log(
        reasoning_log_path=reasoning_log_path,
        payload=payload,
        reasoning=last_reasoning,
        summary=final_summary,
        final_body=final_body,
        phase="auto_final",
    )
    return final_body


async def _generate_reasoning_envelope(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_model: JsonCaller,
    scratchpad_summaries: list[str],
    max_tokens: int,
    default_continue: bool,
    mode: str,
) -> dict[str, Any]:
    think_payload = copy.deepcopy(payload)
    think_payload["stream"] = False
    think_payload["enable_thinking"] = False
    think_payload["max_tokens"] = max(32, max_tokens)
    messages = list(think_payload.get("messages", []))
    messages = _merge_internal_system_instruction(
        messages=messages,
        instruction=_build_reasoning_instruction(
            payload=payload,
            control=control,
            scratchpad_summaries=scratchpad_summaries,
            mode=mode,
        ),
    )
    think_payload["messages"] = messages
    think_body = await call_model("/v1/chat/completions", think_payload)
    think_text = _extract_chat_text(think_body)
    parsed = _parse_reasoning_envelope(think_text)
    fallback_candidate = think_text.strip() if _looks_like_direct_answer(think_text, payload) else ""
    return _normalize_reasoning_envelope(
        raw=parsed,
        fallback_reasoning=think_text.strip(),
        fallback_candidate=fallback_candidate,
        default_continue=default_continue,
    )


def _build_reasoning_instruction(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    scratchpad_summaries: list[str],
    mode: str,
) -> str:
    budget_note = (
        f"Use at most about {control.auto_checkpoint_tokens} tokens worth of private notes."
        if mode == "auto"
        else "Think as much as needed, but keep the private notes compact and directly useful."
    )
    base = (
        "You are the private reasoning channel for the same assistant. "
        "Return exactly one JSON object and nothing else. "
        "Do not use Markdown fences. Do not use XML tags such as <think>. "
        "The JSON object must have these keys: "
        "reasoning_content, candidate_answer, continue_thinking, accept_answer, confidence, rationale. "
        "reasoning_content is private and will never be shown to the user. "
        "candidate_answer is the best direct user-facing answer so far, or an empty string if not ready. "
        "continue_thinking must be true only if another private reasoning round would materially help. "
        "accept_answer must be true only if candidate_answer can be returned as-is without another model pass. "
        "If tools are available, do not call them here; only note whether a tool-aware final pass is still needed. "
        f"{budget_note}"
    )
    if scratchpad_summaries:
        recent = "\n".join(f"- {item}" for item in scratchpad_summaries[-2:])
        base = (
            f"{base}\n\n"
            "Previous private checkpoints:\n"
            f"{recent}\n"
            "Continue from them without repeating the full chain."
        )
    if _payload_has_tools(payload):
        base = (
            f"{base}\n\n"
            "This request has tools available, so accept_answer should usually stay false unless no tool use is needed."
        )
    return base


async def _generate_final_answer(
    *,
    payload: dict[str, Any],
    scratchpad_summaries: list[str],
    call_model: JsonCaller,
) -> dict[str, Any]:
    final_payload = copy.deepcopy(payload)
    final_payload["stream"] = False
    final_payload["enable_thinking"] = False
    messages = list(final_payload.get("messages", []))
    hidden_summary = _final_summary(scratchpad_summaries, "detailed")
    if hidden_summary:
        messages = _merge_internal_system_instruction(
            messages=messages,
            instruction=(
                "Use this hidden scratchpad silently and answer the user directly. "
                "Do not emit JSON. Do not emit <think> tags.\n"
                f"{hidden_summary}"
            ),
        )
    else:
        messages = _merge_internal_system_instruction(
            messages=messages,
            instruction="Answer the user directly. Do not emit JSON. Do not emit <think> tags.",
        )
    final_payload["messages"] = messages
    return await call_model("/v1/chat/completions", final_payload)


def _build_direct_answer_body(*, payload: dict[str, Any], answer: str) -> dict[str, Any]:
    return {
        "model": payload.get("model"),
        "choices": [
            {
                "finish_reason": "stop",
                "message": {
                    "role": "assistant",
                    "content": answer,
                },
            }
        ],
    }


def _parse_reasoning_envelope(text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            parsed, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return parsed
    return None


def _normalize_reasoning_envelope(
    *,
    raw: dict[str, Any] | None,
    fallback_reasoning: str,
    fallback_candidate: str,
    default_continue: bool,
) -> dict[str, Any]:
    parsed = copy.deepcopy(raw) if isinstance(raw, dict) else {}

    reasoning_content = parsed.get("reasoning_content")
    if not isinstance(reasoning_content, str):
        reasoning_content = fallback_reasoning

    candidate_answer = parsed.get("candidate_answer")
    if not isinstance(candidate_answer, str):
        candidate_answer = fallback_candidate
    candidate_answer = candidate_answer.strip()

    continue_thinking = _coerce_bool(
        parsed.get("continue_thinking"),
        default=default_continue and not candidate_answer,
    )
    accept_answer = _coerce_bool(parsed.get("accept_answer"), default=False)
    if accept_answer and not candidate_answer:
        accept_answer = False

    confidence = parsed.get("confidence")
    if not isinstance(confidence, str) or confidence not in {"low", "medium", "high"}:
        confidence = None

    rationale = parsed.get("rationale")
    if not isinstance(rationale, str):
        rationale = None

    return {
        "reasoning_content": reasoning_content.strip(),
        "candidate_answer": candidate_answer,
        "continue_thinking": continue_thinking,
        "accept_answer": accept_answer,
        "confidence": confidence,
        "rationale": rationale,
        "source": "json" if raw is not None else "fallback",
    }


def _resolve_auto_decision(
    *,
    payload: dict[str, Any],
    envelope: dict[str, Any],
) -> dict[str, Any]:
    if envelope["source"] != "fallback":
        return envelope
    candidate_answer = str(envelope.get("candidate_answer", "")).strip()
    if _looks_like_direct_answer(candidate_answer, payload):
        return {
            **envelope,
            "continue_thinking": False,
            "accept_answer": True,
            "confidence": "low",
            "rationale": "fallback_heuristic_direct_answer",
            "source": "fallback_heuristic",
        }
    return {
        **envelope,
        "continue_thinking": False,
        "accept_answer": False,
        "confidence": "low",
        "rationale": "fallback_generate_final",
        "source": "fallback_heuristic",
    }


def _coerce_bool(value: Any, *, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes"}
    if value is None:
        return default
    return bool(value)


def _reasoning_token_budget(payload: dict[str, Any]) -> int:
    budget = payload.get("thinking_budget")
    if budget is None:
        budget = payload.get("max_tokens")
    try:
        return int(budget) if budget is not None else 512
    except (TypeError, ValueError):
        return 512


def _extract_chat_text(body: dict[str, Any]) -> str:
    choices = body.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message")
        if isinstance(message, dict):
            content = message.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                fragments: list[str] = []
                for item in content:
                    if isinstance(item, dict) and isinstance(item.get("text"), str):
                        fragments.append(item["text"])
                return "\n".join(fragments)
    return ""


def _extract_last_user_text(payload: dict[str, Any]) -> str:
    messages = payload.get("messages")
    if not isinstance(messages, list):
        return ""
    for message in reversed(messages):
        if not isinstance(message, dict) or message.get("role") != "user":
            continue
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            fragments: list[str] = []
            for item in content:
                if isinstance(item, dict) and isinstance(item.get("text"), str):
                    fragments.append(item["text"])
            return "\n".join(fragments)
    return ""


def _can_short_circuit_with_candidate(
    *,
    payload: dict[str, Any],
    candidate_answer: str,
    accept_answer: bool,
) -> bool:
    if not accept_answer or _payload_has_tools(payload):
        return False
    return _looks_like_direct_answer(candidate_answer, payload)


def _payload_has_tools(payload: dict[str, Any]) -> bool:
    tools = payload.get("tools")
    if not isinstance(tools, list):
        return False
    return any(isinstance(tool, dict) and tool.get("type") == "function" for tool in tools)


def _looks_like_direct_answer(candidate_answer: str, payload: dict[str, Any]) -> bool:
    text = candidate_answer.strip()
    if not text:
        return False
    lowered = text.lower()
    meta_markers = (
        "thinking process",
        "the user wants",
        "let me break down",
        "analyze request",
        "requirements:",
        "the task is",
        "このタスク",
        "ユーザーは",
        "要件",
        "答える必要",
        "必要がある",
        "一文で答える",
        "need to answer",
        "i need to",
        "i should",
        "must answer",
    )
    if any(marker in lowered for marker in meta_markers):
        return False
    if "```" in text or re.search(r"^\s*(from |import |def |class )", text, flags=re.MULTILINE):
        return True
    non_empty_lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(non_empty_lines) != 1:
        return False
    if text.endswith(("「", '"', "'", ":", "：", "(", "（")):
        return False
    user_text = _extract_last_user_text(payload).strip()
    if len(text) <= 240 and len(user_text) <= 240:
        return True
    return False


def _reasoning_summary(reasoning: str, mode: SummaryMode) -> str | None:
    if not reasoning:
        return None
    summary = summarize_reasoning(reasoning, mode)
    if summary:
        return summary
    return reasoning[:400] if reasoning else None


def _reasoning_history_content(scratchpad_summaries: list[str]) -> str:
    return "\n".join(item for item in scratchpad_summaries if item).strip()


def _final_summary(summaries: list[str], mode: str) -> str | None:
    if mode == "none" or not summaries:
        return None
    if mode in {"concise", "auto"}:
        return summaries[-1]
    return " / ".join(summaries)


def _attach_reasoning_artifacts(
    body: dict[str, Any],
    *,
    reasoning_content: str,
    summary: str | None,
) -> None:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return
    message = choices[0].get("message")
    if not isinstance(message, dict):
        return
    if reasoning_content.strip():
        message["reasoning_content"] = reasoning_content.strip()
    if summary:
        message["reasoning_summary"] = summary


def _write_final_log(
    *,
    reasoning_log_path: str,
    payload: dict[str, Any],
    reasoning: str,
    summary: str | None,
    final_body: dict[str, Any],
    phase: str,
) -> None:
    if not reasoning:
        return
    write_reasoning_log(
        reasoning_log_path=reasoning_log_path,
        payload=payload,
        reasoning=reasoning,
        summary=summary,
        answer=_extract_chat_text(final_body),
        metadata={"phase": phase},
    )


def _merge_internal_system_instruction(
    *,
    messages: list[dict[str, Any]],
    instruction: str,
) -> list[dict[str, Any]]:
    leading_developer_count = 0
    while leading_developer_count < len(messages):
        if messages[leading_developer_count].get("role") != "developer":
            break
        leading_developer_count += 1

    if (
        leading_developer_count < len(messages)
        and messages[leading_developer_count].get("role") == "system"
    ):
        first_message = dict(messages[leading_developer_count])
        content = first_message.get("content")
        if isinstance(content, str):
            first_message["content"] = f"{instruction}\n\n{content}"
        else:
            first_message["content"] = instruction
        return [
            *messages[:leading_developer_count],
            first_message,
            *messages[leading_developer_count + 1 :],
        ]
    return [
        *messages[:leading_developer_count],
        {"role": "system", "content": instruction},
        *messages[leading_developer_count:],
    ]


run_adaptive_chat_completion = run_auto_chat_completion
