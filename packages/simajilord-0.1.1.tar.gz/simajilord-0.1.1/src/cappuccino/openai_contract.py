from __future__ import annotations

import importlib
import importlib.metadata
import importlib.util
import json
import pkgutil
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import urlopen

from fastapi import FastAPI
from pydantic import BaseModel, Field

PYPI_OPENAI_JSON_URL = "https://pypi.org/pypi/openai/json"


class OpenAICoreResources(BaseModel):
    responses: bool
    chat_completions: bool
    completions: bool
    models: bool


class OpenAITypeShapes(BaseModel):
    model_object_fields: list[str] = Field(default_factory=list)
    completion_object_fields: list[str] = Field(default_factory=list)


class OpenAIContractReport(BaseModel):
    installed_sdk_version: str | None = None
    latest_pypi_version: str | None = None
    sdk_module_path: str | None = None
    core_resources: OpenAICoreResources
    type_shapes: OpenAITypeShapes
    required_server_routes: list[str] = Field(default_factory=list)
    present_server_routes: list[str] = Field(default_factory=list)
    missing_server_routes: list[str] = Field(default_factory=list)


def build_openai_contract_report(
    *,
    app: FastAPI | None = None,
    include_latest_release: bool = True,
    timeout_sec: float = 30.0,
) -> OpenAIContractReport:
    core_resources = OpenAICoreResources(
        responses=_class_has_attribute("openai", "OpenAI", "responses"),
        chat_completions=_class_has_attribute("openai.resources.chat.chat", "Chat", "completions"),
        completions=_class_has_attribute("openai", "OpenAI", "completions"),
        models=_class_has_attribute("openai", "OpenAI", "models"),
    )
    required_server_routes = expected_server_routes(core_resources)
    present_server_routes = collect_app_routes(app) if app is not None else []
    missing_server_routes = sorted(
        route for route in required_server_routes if route not in set(present_server_routes)
    )
    return OpenAIContractReport(
        installed_sdk_version=_installed_openai_sdk_version(),
        latest_pypi_version=_latest_openai_pypi_version(timeout_sec) if include_latest_release else None,
        sdk_module_path=_openai_module_path(),
        core_resources=core_resources,
        type_shapes=OpenAITypeShapes(
            model_object_fields=_class_annotation_fields("openai.types.model", "Model"),
            completion_object_fields=_class_annotation_fields("openai.types.completion", "Completion"),
        ),
        required_server_routes=required_server_routes,
        present_server_routes=present_server_routes,
        missing_server_routes=missing_server_routes,
    )


def write_openai_contract_report(
    *,
    output_path: str | Path,
    app: FastAPI | None = None,
    include_latest_release: bool = True,
    timeout_sec: float = 30.0,
) -> OpenAIContractReport:
    report = build_openai_contract_report(
        app=app,
        include_latest_release=include_latest_release,
        timeout_sec=timeout_sec,
    )
    output_path = Path(output_path).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report.model_dump(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return report


def expected_server_routes(resources: OpenAICoreResources) -> list[str]:
    routes: list[str] = []
    if resources.responses:
        routes.extend(["/responses", "/v1/responses"])
    if resources.chat_completions:
        routes.extend(["/chat/completions", "/v1/chat/completions"])
    if resources.completions:
        routes.extend(["/completions", "/v1/completions"])
    if resources.models:
        routes.extend(["/models", "/v1/models"])
    return routes


def collect_app_routes(app: FastAPI | None) -> list[str]:
    if app is None:
        return []
    paths = {
        getattr(route, "path", "")
        for route in app.router.routes
        if getattr(route, "path", "")
    }
    return sorted(paths)


def known_openai_resource_segments() -> set[str]:
    resource_segments: set[str] = {
        "chat",
        "responses",
        "completions",
        "models",
    }
    try:
        resources_module = importlib.import_module("openai.resources")
    except ImportError:
        return resource_segments

    package_path = getattr(resources_module, "__path__", None)
    if package_path is None:
        return resource_segments

    for module_info in pkgutil.walk_packages(package_path, prefix="openai.resources."):
        name = module_info.name.rsplit(".", 1)[-1]
        if not name.startswith("_"):
            resource_segments.add(name)
    return resource_segments


def _installed_openai_sdk_version() -> str | None:
    try:
        return importlib.metadata.version("openai")
    except importlib.metadata.PackageNotFoundError:
        return None


def _openai_module_path() -> str | None:
    spec = importlib.util.find_spec("openai")
    if spec is None:
        return None
    return spec.origin


def _latest_openai_pypi_version(timeout_sec: float) -> str | None:
    try:
        with urlopen(PYPI_OPENAI_JSON_URL, timeout=timeout_sec) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (OSError, URLError, TimeoutError, ValueError):
        return None
    info = payload.get("info")
    if not isinstance(info, dict):
        return None
    version = info.get("version")
    return version if isinstance(version, str) else None


def _class_has_attribute(module_name: str, class_name: str, attribute_name: str) -> bool:
    try:
        module = importlib.import_module(module_name)
        target = getattr(module, class_name)
    except (ImportError, AttributeError):
        return False
    return hasattr(target, attribute_name)


def _class_annotation_fields(module_name: str, class_name: str) -> list[str]:
    try:
        module = importlib.import_module(module_name)
        target = getattr(module, class_name)
    except (ImportError, AttributeError):
        return []
    annotations = getattr(target, "__annotations__", {})
    if not isinstance(annotations, dict):
        return []
    return sorted(str(key) for key in annotations.keys())
