from __future__ import annotations

import copy
import json
import time
import uuid
from dataclasses import dataclass
from typing import Any, AsyncIterator, Awaitable, Callable, Literal

from .auto_reasoning import run_structured_reasoning_chat_completion
from .openai_compat import (
    OpenAIResponseObject,
    ResponseCompletedEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseCreatedEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseFunctionCallItem,
    ResponseInProgressEvent,
    ResponseMessageItem,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseOutputTextDeltaEvent,
    ResponseOutputTextDoneEvent,
    ResponseOutputTextPart,
    ResponseReasoning,
    ResponseUsage,
)
from .reasoning import ReasoningControl, postprocess_response_body
from .tool_runtime import ToolExecutor

JsonCaller = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]
ResponseStatus = Literal["completed", "failed", "in_progress", "incomplete"]


@dataclass
class StoredResponse:
    response: dict[str, Any]
    chat_history: list[dict[str, Any]]


class ResponseStore:
    def __init__(self) -> None:
        self._responses: dict[str, StoredResponse] = {}

    def save(
        self,
        *,
        response: dict[str, Any],
        chat_history: list[dict[str, Any]],
    ) -> None:
        response_id = response.get("id")
        if not isinstance(response_id, str):
            return
        self._responses[response_id] = StoredResponse(
            response=copy.deepcopy(response),
            chat_history=copy.deepcopy(chat_history),
        )

    def get(self, response_id: str) -> dict[str, Any] | None:
        stored = self._responses.get(response_id)
        if stored is None:
            return None
        return copy.deepcopy(stored.response)

    def history_for(self, response_id: str) -> list[dict[str, Any]]:
        stored = self._responses.get(response_id)
        if stored is None:
            raise KeyError(response_id)
        return [
            message
            for message in copy.deepcopy(stored.chat_history)
            if message.get("role") not in {"system", "developer", "skill"}
        ]


def should_store_response(payload: dict[str, Any]) -> bool:
    return _should_store_response(payload)


def build_stored_response_chat_history(
    *,
    payload: dict[str, Any],
    response: dict[str, Any],
    response_store: ResponseStore,
) -> list[dict[str, Any]]:
    request_context = _build_request_context(payload=payload, response_store=response_store)
    chat_history = copy.deepcopy(request_context.chat_history)
    output_items = response.get("output")
    if isinstance(output_items, list):
        for item in output_items:
            if not isinstance(item, dict):
                continue
            if item.get("type") != "message" or item.get("role") != "assistant":
                continue
            assistant_message = {
                "role": "assistant",
                "content": _assistant_text_from_response_item(item),
            }
            reasoning_content = _assistant_reasoning_content_from_response_item(item)
            if reasoning_content is not None:
                assistant_message["reasoning_content"] = reasoning_content
            chat_history.append(assistant_message)
    return chat_history


async def execute_responses_request(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_chat_completion: JsonCaller,
    reasoning_log_path: str,
    tool_executor: ToolExecutor | None,
    response_store: ResponseStore,
) -> dict[str, Any]:
    created_at = int(time.time())
    response_id = f"resp_{uuid.uuid4().hex}"
    request_context = _build_request_context(payload=payload, response_store=response_store)
    working_messages = copy.deepcopy(request_context.chat_history)
    tools = _normalize_function_tools(payload.get("tools"))
    output_items: list[dict[str, Any]] = []
    max_tool_steps = max(1, _coerce_optional_int(payload.get("max_tool_calls")) or 8)
    tool_choice: Any = copy.deepcopy(payload.get("tool_choice"))

    for _ in range(max_tool_steps):
        chat_payload = _build_chat_payload(
            payload=payload,
            messages=working_messages,
            tools=tools,
            tool_choice_override=tool_choice,
        )
        chat_body = await _generate_chat_completion(
            payload=chat_payload,
            control=control,
            call_chat_completion=call_chat_completion,
            reasoning_log_path=reasoning_log_path,
        )
        assistant_message = _extract_assistant_message(chat_body)
        assistant_text = _assistant_text_from_message(assistant_message)
        reasoning_summary = _assistant_reasoning_summary(assistant_message)
        tool_calls = _extract_tool_calls(assistant_message)

        if tool_calls:
            assistant_history = {
                "role": "assistant",
                "content": assistant_text,
                "tool_calls": copy.deepcopy(tool_calls),
            }
            reasoning_content = _assistant_reasoning_content(assistant_message)
            if reasoning_content is not None:
                assistant_history["reasoning_content"] = reasoning_content
            working_messages.append(assistant_history)

            supported_calls: list[tuple[dict[str, Any], str]] = []
            unsupported_call_found = False
            for tool_call in tool_calls:
                function_call_item = _build_function_call_item(tool_call)
                output_items.append(function_call_item.model_dump(exclude_none=True))
                tool_output = _execute_supported_tool(
                    tool_call=tool_call,
                    tool_executor=tool_executor,
                )
                if tool_output is None:
                    unsupported_call_found = True
                    continue
                supported_calls.append((tool_call, tool_output))

            if unsupported_call_found:
                response = _build_response_object(
                    response_id=response_id,
                    created_at=created_at,
                    payload=payload,
                    output_items=output_items,
                    reasoning_summary=reasoning_summary,
                    usage=_chat_usage(chat_body),
                )
                if _should_store_response(payload):
                    response_store.save(response=response, chat_history=working_messages)
                return response

            for tool_call, tool_output in supported_calls:
                working_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": tool_output,
                    }
                )
            if supported_calls and tool_choice == "required":
                tool_choice = "auto"
            continue

        message_item = _build_message_item(
            text=assistant_text,
            reasoning_summary=reasoning_summary,
            phase=_extract_message_phase(assistant_message),
        )
        output_items.append(message_item.model_dump(exclude_none=True))
        assistant_history = {
            "role": "assistant",
            "content": assistant_text,
        }
        reasoning_content = _assistant_reasoning_content(assistant_message)
        if reasoning_content is not None:
            assistant_history["reasoning_content"] = reasoning_content
        working_messages.append(assistant_history)
        response = _build_response_object(
            response_id=response_id,
            created_at=created_at,
            payload=payload,
            output_items=output_items,
            reasoning_summary=reasoning_summary,
            usage=_chat_usage(chat_body),
        )
        if _should_store_response(payload):
            response_store.save(response=response, chat_history=working_messages)
        return response

    response = _build_response_object(
        response_id=response_id,
        created_at=created_at,
        payload=payload,
        output_items=output_items,
        reasoning_summary=None,
        usage=None,
        status="incomplete",
        incomplete_details={"reason": "max_tool_calls_exceeded"},
    )
    if _should_store_response(payload):
        response_store.save(response=response, chat_history=working_messages)
    return response


async def stream_responses_request(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_chat_completion: JsonCaller,
    reasoning_log_path: str,
    tool_executor: ToolExecutor | None,
    response_store: ResponseStore,
) -> AsyncIterator[bytes]:
    final_response = await execute_responses_request(
        payload=payload,
        control=control,
        call_chat_completion=call_chat_completion,
        reasoning_log_path=reasoning_log_path,
        tool_executor=tool_executor,
        response_store=response_store,
    )
    response_model = OpenAIResponseObject.model_validate(final_response)
    base_response = response_model.model_copy(update={"status": "in_progress", "usage": None})
    sequence_number = 0

    yield _event_bytes(
        ResponseCreatedEvent(
            response=base_response,
            sequence_number=sequence_number,
        )
    )
    sequence_number += 1
    yield _event_bytes(
        ResponseInProgressEvent(
            response=base_response,
            sequence_number=sequence_number,
        )
    )
    sequence_number += 1

    for output_index, item in enumerate(response_model.output):
        item_type = item.get("type")
        item_id = item.get("id")
        if not isinstance(item_id, str):
            item_id = f"item_{uuid.uuid4().hex}"
            item["id"] = item_id
        added_item = dict(item)
        added_item["status"] = "in_progress"
        yield _event_bytes(
            ResponseOutputItemAddedEvent(
                output_index=output_index,
                item=added_item,
                response_id=response_model.id,
                sequence_number=sequence_number,
            )
        )
        sequence_number += 1

        if item_type == "function_call":
            arguments = item.get("arguments", "")
            if isinstance(arguments, str):
                for delta in _chunk_text(arguments, size=96):
                    yield _event_bytes(
                        ResponseFunctionCallArgumentsDeltaEvent(
                            item_id=item_id,
                            output_index=output_index,
                            delta=delta,
                            response_id=response_model.id,
                            sequence_number=sequence_number,
                        )
                    )
                    sequence_number += 1
            yield _event_bytes(
                ResponseFunctionCallArgumentsDoneEvent(
                    output_index=output_index,
                    item=item,
                    response_id=response_model.id,
                    sequence_number=sequence_number,
                )
            )
            sequence_number += 1
            yield _event_bytes(
                ResponseOutputItemDoneEvent(
                    output_index=output_index,
                    item=item,
                    response_id=response_model.id,
                    sequence_number=sequence_number,
                )
            )
            sequence_number += 1
            continue

        if item_type == "message":
            content = item.get("content", [])
            if isinstance(content, list):
                for content_index, part in enumerate(content):
                    if not isinstance(part, dict):
                        continue
                    yield _event_bytes(
                        ResponseContentPartAddedEvent(
                            item_id=item_id,
                            output_index=output_index,
                            content_index=content_index,
                            part=part,
                            response_id=response_model.id,
                            sequence_number=sequence_number,
                        )
                    )
                    sequence_number += 1
                    text = part.get("text", "")
                    if isinstance(text, str):
                        for delta in _chunk_text(text, size=48):
                            yield _event_bytes(
                                ResponseOutputTextDeltaEvent(
                                    item_id=item_id,
                                    output_index=output_index,
                                    content_index=content_index,
                                    delta=delta,
                                    response_id=response_model.id,
                                    sequence_number=sequence_number,
                                )
                            )
                            sequence_number += 1
                        yield _event_bytes(
                            ResponseOutputTextDoneEvent(
                                item_id=item_id,
                                output_index=output_index,
                                content_index=content_index,
                                text=text,
                                response_id=response_model.id,
                                sequence_number=sequence_number,
                            )
                        )
                        sequence_number += 1
                    yield _event_bytes(
                        ResponseContentPartDoneEvent(
                            item_id=item_id,
                            output_index=output_index,
                            content_index=content_index,
                            part=part,
                            response_id=response_model.id,
                            sequence_number=sequence_number,
                        )
                    )
                    sequence_number += 1
            yield _event_bytes(
                ResponseOutputItemDoneEvent(
                    output_index=output_index,
                    item=item,
                    response_id=response_model.id,
                    sequence_number=sequence_number,
                )
            )
            sequence_number += 1

    yield _event_bytes(
        ResponseCompletedEvent(
            response=response_model,
            sequence_number=sequence_number,
        )
    )


@dataclass
class RequestContext:
    chat_history: list[dict[str, Any]]


def _build_request_context(
    *,
    payload: dict[str, Any],
    response_store: ResponseStore,
) -> RequestContext:
    request_messages = _request_messages_from_payload(payload)
    leading_context, conversation_messages = _split_leading_context_messages(request_messages)
    leading_developer_messages, leading_nondeveloper_messages = _split_leading_developer_messages(
        leading_context
    )
    chat_history: list[dict[str, Any]] = []
    chat_history.extend(leading_developer_messages)

    instructions = payload.get("instructions")
    if isinstance(instructions, str) and instructions.strip():
        chat_history.append({"role": "system", "content": instructions})

    chat_history.extend(leading_nondeveloper_messages)
    previous_response_id = payload.get("previous_response_id")
    if isinstance(previous_response_id, str):
        try:
            chat_history.extend(response_store.history_for(previous_response_id))
        except KeyError as exc:
            raise ValueError(f"Unknown previous_response_id: {previous_response_id}") from exc

    chat_history.extend(conversation_messages)

    return RequestContext(chat_history=chat_history)


def _request_messages_from_payload(payload: dict[str, Any]) -> list[dict[str, Any]]:
    input_value = payload.get("input")
    if isinstance(input_value, str):
        return [{"role": "user", "content": input_value}]
    if isinstance(input_value, list):
        return _input_items_to_chat_messages(input_value)
    if isinstance(payload.get("messages"), list):
        return copy.deepcopy(payload["messages"])
    raise ValueError("Responses requests must include a string or list input.")


def _split_leading_context_messages(
    messages: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    split_index = 0
    while split_index < len(messages):
        role = messages[split_index].get("role")
        if role not in {"developer", "system", "skill"}:
            break
        split_index += 1
    return messages[:split_index], messages[split_index:]


def _split_leading_developer_messages(
    messages: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    split_index = 0
    while split_index < len(messages):
        if messages[split_index].get("role") != "developer":
            break
        split_index += 1
    return messages[:split_index], messages[split_index:]


def _input_items_to_chat_messages(items: list[Any]) -> list[dict[str, Any]]:
    chat_messages: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        item_type = item.get("type")
        role = item.get("role")

        if isinstance(role, str):
            normalized_message = _normalize_role_message(role=role, item=item)
            if normalized_message is not None:
                chat_messages.append(normalized_message)
            continue

        if item_type == "function_call_output":
            call_id = item.get("call_id")
            if isinstance(call_id, str):
                chat_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": _stringify_tool_output(item.get("output")),
                    }
                )
            continue

        if item_type in {"input_text", "text", "input_image", "image_url", "input_audio"}:
            _append_user_content(chat_messages, copy.deepcopy(item))

    return chat_messages


def _normalize_role_message(*, role: str, item: dict[str, Any]) -> dict[str, Any] | None:
    reasoning_content = item.get("reasoning_content")
    content = item.get("content")
    if role == "tool":
        tool_call_id = item.get("tool_call_id") or item.get("call_id")
        if isinstance(tool_call_id, str):
            return {
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": _stringify_tool_output(content),
            }
    if isinstance(content, str):
        message: dict[str, Any] = {"role": role, "content": content}
        if role == "assistant" and isinstance(reasoning_content, str):
            message["reasoning_content"] = reasoning_content
        return message
    if isinstance(content, list):
        normalized_parts: list[dict[str, Any]] = []
        for part in content:
            if isinstance(part, dict):
                part_type = part.get("type")
                if part_type == "output_text":
                    normalized_parts.append(
                        {"type": "text", "text": part.get("text", "")}
                    )
                else:
                    normalized_parts.append(copy.deepcopy(part))
        message = {"role": role, "content": normalized_parts}
        if role == "assistant" and isinstance(reasoning_content, str):
            message["reasoning_content"] = reasoning_content
        return message
    if content is None:
        message = {"role": role, "content": ""}
        if role == "assistant" and isinstance(reasoning_content, str):
            message["reasoning_content"] = reasoning_content
        return message
    return None


def _append_user_content(chat_messages: list[dict[str, Any]], item: dict[str, Any]) -> None:
    if chat_messages and chat_messages[-1].get("role") == "user":
        content = chat_messages[-1].get("content")
        if isinstance(content, list):
            content.append(item)
            return
    chat_messages.append({"role": "user", "content": [item]})


def _normalize_function_tools(raw_tools: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_tools, list):
        return []
    function_tools: list[dict[str, Any]] = []
    for tool in raw_tools:
        if not isinstance(tool, dict):
            continue
        if tool.get("type") != "function":
            continue
        function_tools.append(copy.deepcopy(tool))
    return function_tools


def _build_chat_payload(
    *,
    payload: dict[str, Any],
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    tool_choice_override: Any,
) -> dict[str, Any]:
    chat_payload: dict[str, Any] = {
        "model": payload["model"],
        "messages": copy.deepcopy(messages),
        "temperature": payload.get("temperature", 1.0),
        "top_p": payload.get("top_p", 1.0),
        "stream": False,
    }
    max_output_tokens = payload.get("max_output_tokens")
    if max_output_tokens is not None:
        chat_payload["max_tokens"] = max_output_tokens
    if tools:
        chat_payload["tools"] = copy.deepcopy(tools)
    tool_choice = tool_choice_override
    if tool_choice is not None:
        chat_payload["tool_choice"] = copy.deepcopy(tool_choice)
    if "parallel_tool_calls" in payload:
        chat_payload["parallel_tool_calls"] = payload["parallel_tool_calls"]
    for passthrough_key in (
        "adapter_path",
        "seed",
        "resize_shape",
        "thinking_budget",
    ):
        if passthrough_key in payload:
            chat_payload[passthrough_key] = copy.deepcopy(payload[passthrough_key])
    reasoning = payload.get("reasoning")
    if isinstance(reasoning, dict):
        chat_payload["reasoning"] = copy.deepcopy(reasoning)
    return chat_payload


async def _generate_chat_completion(
    *,
    payload: dict[str, Any],
    control: ReasoningControl,
    call_chat_completion: JsonCaller,
    reasoning_log_path: str,
) -> dict[str, Any]:
    if control.mode in {"auto", "on"}:
        return await run_structured_reasoning_chat_completion(
            payload=payload,
            control=control,
            call_model=call_chat_completion,
            reasoning_log_path=reasoning_log_path,
        )

    payload = copy.deepcopy(payload)
    payload["enable_thinking"] = control.enable_thinking
    response = await call_chat_completion("/v1/chat/completions", payload)
    return postprocess_response_body(
        path="/v1/chat/completions",
        body=response,
        payload=payload,
        control=control,
        reasoning_log_path=reasoning_log_path,
    )


def _extract_assistant_message(body: dict[str, Any]) -> dict[str, Any]:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return {"role": "assistant", "content": ""}
    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        return {"role": "assistant", "content": ""}
    message = first_choice.get("message")
    if not isinstance(message, dict):
        return {"role": "assistant", "content": ""}
    return message


def _assistant_text_from_message(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        fragments: list[str] = []
        for item in content:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                fragments.append(item["text"])
        return "\n".join(fragments)
    return ""


def _assistant_text_from_response_item(item: dict[str, Any]) -> str:
    content = item.get("content")
    if not isinstance(content, list):
        return ""
    fragments: list[str] = []
    for part in content:
        if isinstance(part, dict) and isinstance(part.get("text"), str):
            fragments.append(part["text"])
    return "\n".join(fragments)


def _assistant_reasoning_content_from_response_item(item: dict[str, Any]) -> str | None:
    reasoning_content = item.get("reasoning_content")
    if isinstance(reasoning_content, str) and reasoning_content.strip():
        return reasoning_content
    return None


def _assistant_reasoning_summary(message: dict[str, Any]) -> str | None:
    summary = message.get("reasoning_summary")
    if isinstance(summary, str):
        return summary
    return None


def _assistant_reasoning_content(message: dict[str, Any]) -> str | None:
    reasoning_content = message.get("reasoning_content")
    if isinstance(reasoning_content, str) and reasoning_content.strip():
        return reasoning_content
    return None


def _extract_message_phase(message: dict[str, Any]) -> str | None:
    phase = message.get("phase")
    if isinstance(phase, str):
        return phase
    return None


def _extract_tool_calls(message: dict[str, Any]) -> list[dict[str, Any]]:
    tool_calls = message.get("tool_calls")
    if not isinstance(tool_calls, list):
        return []
    return [tool_call for tool_call in tool_calls if isinstance(tool_call, dict)]


def _build_function_call_item(tool_call: dict[str, Any]) -> ResponseFunctionCallItem:
    function = tool_call.get("function")
    if not isinstance(function, dict):
        function = {}
    call_id = tool_call.get("id")
    if not isinstance(call_id, str):
        call_id = f"call_{uuid.uuid4().hex}"
    arguments = function.get("arguments")
    if not isinstance(arguments, str):
        arguments = json.dumps(arguments or {}, ensure_ascii=False)
    name = function.get("name")
    if not isinstance(name, str):
        name = "unknown_tool"
    return ResponseFunctionCallItem(
        id=f"fc_{uuid.uuid4().hex}",
        call_id=call_id,
        name=name,
        arguments=arguments,
        status="completed",
    )


def _build_message_item(
    *,
    text: str,
    reasoning_summary: str | None,
    phase: str | None,
) -> ResponseMessageItem:
    content_part = ResponseOutputTextPart(text=text, reasoning_summary=reasoning_summary)
    return ResponseMessageItem(
        id=f"msg_{uuid.uuid4().hex}",
        status="completed",
        content=[content_part],
        phase=phase,
    )


def _execute_supported_tool(
    *,
    tool_call: dict[str, Any],
    tool_executor: ToolExecutor | None,
) -> str | None:
    function = tool_call.get("function")
    if not isinstance(function, dict):
        return None
    name = function.get("name")
    arguments = function.get("arguments", "{}")
    if not isinstance(name, str):
        return None
    parsed_arguments = _parse_arguments(arguments)
    if tool_executor is None:
        return None
    return tool_executor.execute(name=name, arguments=parsed_arguments)


def _parse_arguments(arguments: Any) -> dict[str, Any]:
    if isinstance(arguments, dict):
        return copy.deepcopy(arguments)
    if not isinstance(arguments, str):
        return {}
    try:
        parsed = json.loads(arguments)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return parsed


def _build_response_object(
    *,
    response_id: str,
    created_at: int,
    payload: dict[str, Any],
    output_items: list[dict[str, Any]],
    reasoning_summary: str | None,
    usage: ResponseUsage | None,
    status: ResponseStatus = "completed",
    incomplete_details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_text_parts: list[str] = []
    for item in output_items:
        if item.get("type") != "message":
            continue
        content = item.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if isinstance(part, dict) and isinstance(part.get("text"), str):
                output_text_parts.append(part["text"])

    metadata = payload.get("metadata")
    response = OpenAIResponseObject(
        id=response_id,
        created_at=created_at,
        completed_at=created_at if status == "completed" else None,
        status=status,
        incomplete_details=incomplete_details,
        instructions=payload.get("instructions")
        if isinstance(payload.get("instructions"), str)
        else None,
        max_output_tokens=_coerce_optional_int(payload.get("max_output_tokens")),
        model=str(payload["model"]),
        output=copy.deepcopy(output_items),
        output_text="\n".join(output_text_parts) if output_text_parts else None,
        parallel_tool_calls=bool(payload.get("parallel_tool_calls", True)),
        previous_response_id=payload.get("previous_response_id")
        if isinstance(payload.get("previous_response_id"), str)
        else None,
        reasoning=ResponseReasoning(
            effort=_requested_reasoning_effort(payload),
            summary=reasoning_summary,
        ),
        store=_should_store_response(payload),
        temperature=_coerce_optional_float(payload.get("temperature")),
        tool_choice=_resolve_tool_choice(payload, payload.get("tools")),
        tools=_copy_tool_list(payload.get("tools")),
        top_p=_coerce_optional_float(payload.get("top_p")),
        truncation=str(payload.get("truncation", "disabled")),
        usage=usage,
        user=payload.get("user") if isinstance(payload.get("user"), str) else None,
        metadata=copy.deepcopy(metadata) if isinstance(metadata, dict) else {},
    )
    return response.model_dump(exclude_none=True)


def _chat_usage(chat_body: dict[str, Any]) -> ResponseUsage | None:
    usage = chat_body.get("usage")
    if not isinstance(usage, dict):
        return None
    input_tokens = _coerce_optional_int(usage.get("prompt_tokens", usage.get("input_tokens")))
    output_tokens = _coerce_optional_int(
        usage.get("completion_tokens", usage.get("output_tokens"))
    )
    total_tokens = _coerce_optional_int(usage.get("total_tokens"))
    output_tokens_details: dict[str, Any] = {"reasoning_tokens": 0}
    reasoning_tokens = _coerce_optional_int(usage.get("reasoning_tokens"))
    if reasoning_tokens is not None:
        output_tokens_details["reasoning_tokens"] = reasoning_tokens
    return ResponseUsage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        input_tokens_details={"cached_tokens": 0},
        output_tokens_details=output_tokens_details,
    )


def _event_bytes(event: Any) -> bytes:
    event_type = getattr(event, "type")
    payload = event.model_dump_json(exclude_none=True)
    return f"event: {event_type}\ndata: {payload}\n\n".encode("utf-8")


def _chunk_text(text: str, *, size: int) -> list[str]:
    if not text:
        return [""]
    return [text[index : index + size] for index in range(0, len(text), size)]


def _stringify_tool_output(output: Any) -> str:
    if isinstance(output, str):
        return output
    return json.dumps(output, ensure_ascii=False)


def _requested_reasoning_effort(payload: dict[str, Any]) -> str | None:
    reasoning = payload.get("reasoning")
    if isinstance(reasoning, dict):
        effort = reasoning.get("effort")
        if isinstance(effort, str):
            return effort
    return None


def _resolve_tool_choice(payload: dict[str, Any], tools: Any) -> Any:
    if "tool_choice" in payload:
        return copy.deepcopy(payload["tool_choice"])
    if isinstance(tools, list) and tools:
        return "auto"
    return "none"


def _copy_tool_list(raw_tools: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_tools, list):
        return []
    return [copy.deepcopy(tool) for tool in raw_tools if isinstance(tool, dict)]


def _coerce_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _coerce_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _should_store_response(payload: dict[str, Any]) -> bool:
    store = payload.get("store", True)
    if isinstance(store, bool):
        return store
    return True
