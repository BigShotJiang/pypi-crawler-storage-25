from __future__ import annotations

import shutil
from pathlib import Path
from typing import Callable

from .runtime_compat import convert_model


def quantize_model(
    *,
    hf_path: str | Path,
    mlx_path: str | Path,
    q_bits: int = 6,
    q_group_size: int = 64,
    include_multimodal: bool = True,
) -> None:
    hf_path_resolved = Path(hf_path).expanduser().resolve()
    mlx_path_resolved = Path(mlx_path).expanduser().resolve()
    staging_path = _pick_staging_path(
        model_path=hf_path_resolved,
        output_path=mlx_path_resolved,
    )
    quant_predicate = build_quant_predicate(
        q_group_size=q_group_size,
        include_multimodal=include_multimodal,
    )
    if staging_path != mlx_path_resolved:
        shutil.rmtree(mlx_path_resolved, ignore_errors=True)
    shutil.rmtree(staging_path, ignore_errors=True)
    convert_model(
        hf_path=str(hf_path_resolved),
        mlx_path=str(staging_path),
        quantize=True,
        q_bits=q_bits,
        q_group_size=q_group_size,
        trust_remote_code=True,
        quant_predicate=quant_predicate,
    )
    if staging_path != mlx_path_resolved:
        shutil.rmtree(mlx_path_resolved, ignore_errors=True)
        mlx_path_resolved.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(staging_path), str(mlx_path_resolved))


def build_quant_predicate(
    *,
    q_group_size: int,
    include_multimodal: bool,
) -> Callable[[str, object], bool]:
    def predicate(path: str, module: object) -> bool:
        if not include_multimodal and _is_multimodal_path(path):
            return False
        if not hasattr(module, "to_quantized"):
            return False
        weight = getattr(module, "weight", None)
        if weight is None or not hasattr(weight, "shape"):
            return False
        shape = getattr(weight, "shape")
        if len(shape) < 2:
            return False
        return int(shape[1]) % q_group_size == 0

    return predicate


def _is_multimodal_path(path: str) -> bool:
    return any(
        key in path
        for key in (
            "vision_model",
            "vision_tower",
            "vl_connector",
            "sam_model",
            "audio_model",
            "audio_tower",
            "code_predictor",
        )
    )


def _pick_staging_path(model_path: Path, output_path: Path) -> Path:
    try:
        output_path.relative_to(model_path)
    except ValueError:
        return output_path

    return model_path.parent / f".{output_path.name}.quantizing"
