from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ToolSearchCall(BaseModel):
    type: Literal["tool_search_call"] = "tool_search_call"
    execution: Literal["client", "server"] = "client"
    call_id: str
    status: Literal["completed"] = "completed"
    arguments: dict[str, Any] = Field(default_factory=dict)


class ToolSearchOutput(BaseModel):
    type: Literal["tool_search_output"] = "tool_search_output"
    execution: Literal["client", "server"] = "client"
    call_id: str | None = None
    status: Literal["completed"] = "completed"
    tools: list[dict[str, Any]] = Field(default_factory=list)


class ToolSearchRequest(BaseModel):
    query: str
    limit: int = Field(default=5, ge=1, le=50)
    call_id: str | None = None
    execution: Literal["client", "server"] = "client"


class ToolSearchResponse(BaseModel):
    query: str
    limit: int
    results: list[dict[str, Any]]
    tool_search_output: ToolSearchOutput | None = None


class SkillSearchRequest(BaseModel):
    query: str
    limit: int = Field(default=5, ge=1, le=50)


class SkillSearchResponse(BaseModel):
    query: str
    limit: int
    results: list[dict[str, Any]]


class OpenAIErrorObject(BaseModel):
    message: str
    type: str = "invalid_request_error"
    param: str | None = None
    code: str | None = None


class OpenAIErrorResponse(BaseModel):
    error: OpenAIErrorObject


class OpenAIModelObject(BaseModel):
    id: str
    object: Literal["model"] = "model"
    created: int
    owned_by: str


class OpenAIModelList(BaseModel):
    object: Literal["list"] = "list"
    data: list[OpenAIModelObject] = Field(default_factory=list)


class CompletionUsage(BaseModel):
    completion_tokens: int
    prompt_tokens: int
    total_tokens: int
    completion_tokens_details: dict[str, Any] | None = None
    prompt_tokens_details: dict[str, Any] | None = None


class CompletionChoice(BaseModel):
    finish_reason: Literal["stop", "length", "content_filter"]
    index: int
    logprobs: dict[str, Any] | None = None
    text: str


class OpenAICompletionObject(BaseModel):
    id: str
    choices: list[CompletionChoice]
    created: int
    model: str
    object: Literal["text_completion"] = "text_completion"
    system_fingerprint: str | None = None
    usage: CompletionUsage | None = None


class ResponseOutputTextPart(BaseModel):
    type: Literal["output_text"] = "output_text"
    text: str
    annotations: list[dict[str, Any]] = Field(default_factory=list)
    reasoning_summary: str | None = None


class ResponseMessageItem(BaseModel):
    id: str
    type: Literal["message"] = "message"
    status: Literal["in_progress", "completed"] = "completed"
    role: Literal["assistant"] = "assistant"
    content: list[ResponseOutputTextPart] = Field(default_factory=list)
    phase: str | None = None


class ResponseFunctionCallItem(BaseModel):
    id: str
    type: Literal["function_call"] = "function_call"
    call_id: str
    name: str
    arguments: str
    status: Literal["in_progress", "completed"] = "completed"


class ResponseUsage(BaseModel):
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    input_tokens_details: dict[str, Any] = Field(default_factory=dict)
    output_tokens_details: dict[str, Any] = Field(default_factory=dict)


class ResponseReasoning(BaseModel):
    effort: str | None = None
    summary: str | None = None


class OpenAIResponseObject(BaseModel):
    id: str
    object: Literal["response"] = "response"
    created_at: int
    status: Literal["completed", "failed", "in_progress", "incomplete"]
    completed_at: int | None = None
    error: dict[str, Any] | None = None
    incomplete_details: dict[str, Any] | None = None
    instructions: str | None = None
    max_output_tokens: int | None = None
    model: str
    output: list[dict[str, Any]] = Field(default_factory=list)
    output_text: str | None = None
    parallel_tool_calls: bool = True
    previous_response_id: str | None = None
    reasoning: ResponseReasoning = Field(default_factory=ResponseReasoning)
    store: bool = True
    temperature: float | None = None
    text: dict[str, Any] = Field(default_factory=lambda: {"format": {"type": "text"}})
    tool_choice: Any = "auto"
    tools: list[dict[str, Any]] = Field(default_factory=list)
    top_p: float | None = None
    truncation: str = "disabled"
    usage: ResponseUsage | None = None
    user: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class BaseResponsesStreamEvent(BaseModel):
    type: str
    sequence_number: int | None = None


class ResponseCreatedEvent(BaseResponsesStreamEvent):
    type: Literal["response.created"] = "response.created"
    response: OpenAIResponseObject


class ResponseInProgressEvent(BaseResponsesStreamEvent):
    type: Literal["response.in_progress"] = "response.in_progress"
    response: OpenAIResponseObject


class ResponseOutputItemAddedEvent(BaseResponsesStreamEvent):
    type: Literal["response.output_item.added"] = "response.output_item.added"
    output_index: int
    item: dict[str, Any]
    response_id: str | None = None


class ResponseOutputItemDoneEvent(BaseResponsesStreamEvent):
    type: Literal["response.output_item.done"] = "response.output_item.done"
    output_index: int
    item: dict[str, Any]
    response_id: str | None = None


class ResponseContentPartAddedEvent(BaseResponsesStreamEvent):
    type: Literal["response.content_part.added"] = "response.content_part.added"
    item_id: str
    output_index: int
    content_index: int
    part: dict[str, Any]
    response_id: str | None = None


class ResponseContentPartDoneEvent(BaseResponsesStreamEvent):
    type: Literal["response.content_part.done"] = "response.content_part.done"
    item_id: str
    output_index: int
    content_index: int
    part: dict[str, Any]
    response_id: str | None = None


class ResponseOutputTextDeltaEvent(BaseResponsesStreamEvent):
    type: Literal["response.output_text.delta"] = "response.output_text.delta"
    item_id: str
    output_index: int
    content_index: int
    delta: str
    response_id: str | None = None


class ResponseOutputTextDoneEvent(BaseResponsesStreamEvent):
    type: Literal["response.output_text.done"] = "response.output_text.done"
    item_id: str
    output_index: int
    content_index: int
    text: str
    response_id: str | None = None


class ResponseFunctionCallArgumentsDeltaEvent(BaseResponsesStreamEvent):
    type: Literal["response.function_call_arguments.delta"] = (
        "response.function_call_arguments.delta"
    )
    item_id: str
    output_index: int
    delta: str
    response_id: str | None = None


class ResponseFunctionCallArgumentsDoneEvent(BaseResponsesStreamEvent):
    type: Literal["response.function_call_arguments.done"] = (
        "response.function_call_arguments.done"
    )
    output_index: int
    item: dict[str, Any]
    response_id: str | None = None


class ResponseCompletedEvent(BaseResponsesStreamEvent):
    type: Literal["response.completed"] = "response.completed"
    response: OpenAIResponseObject
