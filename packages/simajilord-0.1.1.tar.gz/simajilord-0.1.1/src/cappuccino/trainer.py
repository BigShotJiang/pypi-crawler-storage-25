from __future__ import annotations

import gc
import json
import os
import random
import shutil
import time
from bisect import bisect_right
from collections.abc import Sequence
from functools import partial
from pathlib import Path
from typing import Any, Iterator, Literal, cast

import mlx.core as mx
import mlx.optimizers as optim
import mlx.nn as nn
from mlx_lm import stream_generate
from mlx.nn.utils import average_gradients
from mlx.utils import tree_flatten, tree_map, tree_unflatten
from mlx_lm.tuner import TrainingArgs, linear_to_lora_layers
from mlx_lm.tuner.callbacks import TrainingCallback
from mlx_lm.tuner.datasets import CacheDataset, ChatDataset, ConcatenatedDataset, TextDataset
from mlx_lm.tuner.trainer import default_loss as mlx_default_loss
from mlx_lm.tuner.trainer import evaluate as mlx_evaluate
from mlx_lm.tuner.trainer import grad_checkpoint as mlx_grad_checkpoint
from mlx_lm.tuner.trainer import iterate_batches as mlx_iterate_batches
from mlx_vlm.trainer.datasets import PreferenceVisionDataset
from mlx_vlm.trainer.orpo_trainer import (
    ORPOTrainingArgs,
    evaluate_orpo as vlm_evaluate_orpo,
    get_logps as vlm_orpo_get_logps,
    iterate_batches as vlm_orpo_iterate_batches,
    orpo_loss as vlm_orpo_loss,
)
from mlx_vlm.trainer.sft_trainer import (
    TrainingArgs as VlmTrainingArgs,
    evaluate as vlm_evaluate,
    iterate_batches as vlm_iterate_batches,
    vision_language_loss_fn as vlm_vision_language_loss_fn,
)
from mlx_vlm.trainer.utils import (
    find_all_linear_names as vlm_find_all_linear_names,
    get_peft_model as vlm_get_peft_model,
    save_adapter as vlm_save_adapter,
    unfreeze_modules as vlm_unfreeze_modules,
)
from pydantic import BaseModel, Field

from .context_windows import DEFAULT_EXTENDED_CONTEXT_WINDOW, apply_context_window_to_config
from .dataset_manifests import is_sequential_cpt_manifest_path, iter_sequential_cpt_source_paths
from .model_inspector import ModelProfile, inspect_model_dir
from .runtime_compat import load, load_multimodal, prepare_runtime_model_path
from .training_schemas import (
    ChatSFTExample,
    ContinualPretrainingExample,
    PreferenceExample,
    parse_training_example,
)

GRAD_CHECKPOINT_MARKER = "__cappuccino_grad_checkpoint_wrapped__"
ParsedTrainingExample = ContinualPretrainingExample | ChatSFTExample | PreferenceExample


class LoRAHyperparameters(BaseModel):
    num_layers: int = 8
    rank: int = 8
    scale: float = 20.0
    dropout: float = 0.0


class BaseWeightUpdateConfig(BaseModel):
    last_layer_count: int = 0
    include_norms: bool = True
    include_biases: bool = False
    include_lm_head: bool = False
    include_embeddings: bool = False
    learning_rate_scale: float = 0.05
    l2_sp_weight: float = 1e-4


class StabilityConfig(BaseModel):
    replay_dataset_path: str | None = None
    replay_target_fraction: float = 0.2
    grad_clip_norm: float = 1.0
    metal_memory_budget_mode: Literal["recommended", "device", "none"] = "device"
    metal_memory_limit_bytes: int | None = None
    metal_wired_limit_bytes: int | None = None
    metal_cache_limit_bytes: int | None = 0
    metal_cache_clear_interval: int = 1
    training_memory_reserve_bytes: int = 64 * 1024 * 1024
    strict_token_audit: bool = True


class CheckpointSampleConfig(BaseModel):
    enabled: bool = True
    prompt: str = "AIについて説明してください"
    max_tokens: int = 8192
    mode: Literal["inline", "after_training"] = "after_training"
    max_kv_size: int | None = 2048
    kv_bits: int | None = 4
    kv_group_size: int = 64


class TrainerConfig(BaseModel):
    model_path: str
    dataset_path: str
    output_dir: str
    train_mode: Literal["sft", "orpo"] = "sft"
    adapter_path: str | None = None
    valid_path: str | None = None
    max_examples: int | None = None
    validation_fraction: float = 0.1
    seed: int = 0
    batch_size: int = 1
    epochs: int | None = None
    iters: int = 100
    val_batches: int = 8
    learning_rate: float = 1e-5
    steps_per_report: int = 1
    steps_per_eval: int = 10
    save_every: int = 25
    max_seq_length: int = 0
    grad_checkpoint: bool = True
    grad_accumulation_steps: int = 1
    optimizer: Literal["adam", "adamw", "sgd", "adafactor"] = "adafactor"
    mask_prompt: bool = False
    dry_run: bool = False
    allow_overlimit: bool = False
    context_window: int | None = None
    yarn_factor: float | None = None
    lora: LoRAHyperparameters = Field(default_factory=LoRAHyperparameters)
    base_update: BaseWeightUpdateConfig = Field(default_factory=BaseWeightUpdateConfig)
    stability: StabilityConfig = Field(default_factory=StabilityConfig)
    checkpoint_sample: CheckpointSampleConfig = Field(default_factory=CheckpointSampleConfig)
    orpo_beta: float = 0.1
    train_vision: bool = False


class DatasetComposition(BaseModel):
    train_examples: int
    valid_examples: int
    cpt_examples: int
    chat_examples: int
    preference_examples: int = 0
    multimodal_chat_examples: int
    multimodal_preference_examples: int = 0
    image_chat_examples: int = 0
    video_chat_examples: int = 0
    audio_chat_examples: int = 0
    image_preference_examples: int = 0
    video_preference_examples: int = 0
    audio_preference_examples: int = 0
    tool_call_messages: int
    tool_result_messages: int
    thinking_examples: int
    placeholder_only_multimodal_examples: int


class MemoryEstimate(BaseModel):
    device_name: str | None = None
    device_memory_bytes: int | None = None
    recommended_working_set_bytes: int | None = None
    applied_memory_budget_bytes: int | None = None
    effective_training_budget_bytes: int | None = None
    memory_budget_mode: Literal["recommended", "device", "none"] | None = None
    model_weight_bytes: int | None = None
    trainable_parameter_count: int
    saved_trainable_tensor_bytes: int | None = None
    estimated_activation_bytes: int
    estimated_optimizer_bytes: int
    estimated_peak_working_set_bytes: int
    fits_memory_budget: bool | None = None
    fits_recommended_working_set: bool | None = None


class TokenAuditSample(BaseModel):
    dataset_name: str
    index: int
    token_length: int
    location: str | None = None


class TokenAuditReport(BaseModel):
    train_examples_audited: int
    valid_examples_audited: int
    train_longest_tokens: int
    valid_longest_tokens: int
    overall_longest_tokens: int
    effective_sequence_length: int
    longest_examples: list[TokenAuditSample] = Field(default_factory=list)


class TrainingRunReport(BaseModel):
    mode: Literal["dry_run", "train"]
    status: Literal["ready", "completed", "failed"]
    model_path: str
    dataset_path: str
    output_dir: str
    configured_context_window: int | None = None
    dataset: DatasetComposition
    memory: MemoryEstimate
    warnings: list[str] = Field(default_factory=list)
    token_audit: TokenAuditReport | None = None
    adapter_file: str | None = None
    metrics_path: str | None = None
    checkpoint_samples_path: str | None = None
    elapsed_sec: float | None = None
    error: str | None = None


class CheckpointSampleRecord(BaseModel):
    iteration: int | None = None
    checkpoint_file: str
    prompt: str
    max_tokens: int
    effective_max_kv_size: int | None = None
    effective_kv_bits: int | None = None
    effective_kv_group_size: int | None = None
    retry_count: int = 0
    output_text: str | None = None
    prompt_tokens: int | None = None
    generation_tokens: int | None = None
    finish_reason: str | None = None
    prompt_tps: float | None = None
    generation_tps: float | None = None
    peak_memory_gb: float | None = None
    error: str | None = None


class CheckpointSamplingReport(BaseModel):
    model_path: str
    train_output_dir: str
    checkpoint_count: int
    prompt: str
    max_tokens: int
    records_path: str
    sample_dir: str
    checkpoints: list[str] = Field(default_factory=list)


class _SequentialJsonlTrainingDataset:
    def __init__(
        self,
        *,
        source_paths: list[Path],
        tokenizer: Any,
        mask_prompt: bool,
    ) -> None:
        self._source_paths = [path.expanduser().resolve() for path in source_paths]
        self._file_sizes = {path: path.stat().st_size for path in self._source_paths}
        self._tokenizer = tokenizer
        self._mask_prompt = mask_prompt
        self._line_counts = [_count_nonempty_lines(path) for path in self._source_paths]
        self._cumulative_counts: list[int] = []
        total = 0
        for count in self._line_counts:
            total += count
            self._cumulative_counts.append(total)
        self._offsets_cache: dict[Path, list[int]] = {}

    def __len__(self) -> int:
        return self._cumulative_counts[-1] if self._cumulative_counts else 0

    def itemlen(self, idx: int) -> int:
        return len(self[idx][0])

    def describe_index(self, idx: int) -> str:
        source_index, line_index = self._resolve_index(idx)
        source_path = self._source_paths[source_index]
        line = self._read_nonempty_line(source_path, line_index)
        try:
            payload = cast(dict[str, Any], json.loads(line))
        except json.JSONDecodeError:
            return f"{source_path}:{line_index + 1}"
        source_ref = _extract_source_reference_from_payload(payload)
        if source_ref is None:
            return f"{source_path}:{line_index + 1}"
        return f"{source_path}:{line_index + 1} ({source_ref})"

    def __getitem__(self, idx: int) -> tuple[list[int], int]:
        source_index, line_index = self._resolve_index(idx)
        line = self._read_nonempty_line(self._source_paths[source_index], line_index)
        example = parse_training_example(json.loads(line))
        if isinstance(example, ContinualPretrainingExample):
            tokens = self._tokenizer.encode(example.text)
            if tokens and tokens[-1] != self._tokenizer.eos_token_id:
                tokens.append(self._tokenizer.eos_token_id)
            return tokens, 0
        if isinstance(example, PreferenceExample):
            raise ValueError("preference_examples_require_train_mode_orpo")
        record = _chat_record(example)
        messages = cast(list[dict[str, Any]], record["messages"])
        tools = record.get("tools")
        tokens = cast(list[int], self._tokenizer.apply_chat_template(messages, tools=tools, return_dict=False))
        if not self._mask_prompt:
            return tokens, 0
        add_generation_prompt = messages[-1].get("role") == "assistant"
        prompt_tokens = cast(
            list[int],
            self._tokenizer.apply_chat_template(
                messages[:-1],
                tools=tools,
                add_generation_prompt=add_generation_prompt,
                return_dict=False,
            ),
        )
        return tokens, len(prompt_tokens)

    def _resolve_index(self, idx: int) -> tuple[int, int]:
        if idx < 0 or idx >= len(self):
            raise IndexError(idx)
        source_index = bisect_right(self._cumulative_counts, idx)
        previous_total = self._cumulative_counts[source_index - 1] if source_index > 0 else 0
        return source_index, idx - previous_total

    def _read_nonempty_line(self, path: Path, line_index: int) -> str:
        offsets = self._offsets_cache.get(path)
        if offsets is None:
            offsets = []
            with path.open("rb") as handle:
                snapshot_size = self._file_sizes[path]
                while True:
                    offset = handle.tell()
                    if offset >= snapshot_size:
                        break
                    remaining = snapshot_size - offset
                    line = handle.readline(remaining)
                    if not line or not line.endswith(b"\n"):
                        break
                    if line.strip():
                        offsets.append(offset)
            self._offsets_cache[path] = offsets
        with path.open("rb") as handle:
            handle.seek(offsets[line_index])
            return handle.readline().decode("utf-8")


class _MetricsJsonlCallback(TrainingCallback):
    def __init__(self, path: Path) -> None:
        self._path = path
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def on_train_loss_report(self, train_info: dict) -> None:
        self._append("train", train_info)

    def on_val_loss_report(self, val_info: dict) -> None:
        self._append("val", val_info)

    def _append(self, event: str, payload: dict[str, Any]) -> None:
        record = {"event": event, **payload}
        with self._path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


class _MultimodalTrainingDataset:
    def __init__(
        self,
        *,
        examples: Sequence[ContinualPretrainingExample | ChatSFTExample],
        processor: Any,
        image_token_index: int,
        use_external_images: bool,
    ) -> None:
        self._examples = list(examples)
        self._processor = processor
        self._tokenizer = getattr(processor, "tokenizer", processor)
        self._image_token_index = image_token_index
        self._use_external_images = use_external_images
        self._cache: dict[int, dict[str, Any]] = {}

    def __len__(self) -> int:
        return len(self._examples)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        cached = self._cache.get(idx)
        if cached is not None:
            return cached
        example = self._examples[idx]
        record = _build_multimodal_training_record(
            example=example,
            processor=self._processor,
            tokenizer=self._tokenizer,
            image_token_index=self._image_token_index,
            use_external_images=self._use_external_images,
        )
        self._cache[idx] = record
        return record

    def itemlen(self, idx: int) -> int:
        record = self[idx]
        input_ids = record.get("input_ids")
        if input_ids is not None and hasattr(input_ids, "__len__"):
            return len(cast(Any, input_ids))
        raise TypeError(f"Unable to determine multimodal token length for example {idx}.")

    def describe_index(self, idx: int) -> str | None:
        example = self._examples[idx]
        metadata = example.metadata
        source_ref = _extract_source_reference_from_payload({"metadata": metadata})
        if source_ref is not None:
            return source_ref
        title = metadata.get("title")
        if isinstance(title, str) and title.strip():
            return title.strip()
        return None


def _build_multimodal_training_record(
    *,
    example: ContinualPretrainingExample | ChatSFTExample,
    processor: Any,
    tokenizer: Any,
    image_token_index: int,
    use_external_images: bool,
) -> dict[str, Any]:
    if isinstance(example, ContinualPretrainingExample):
        tokens = tokenizer.encode(example.text)
        eos_token_id = getattr(tokenizer, "eos_token_id", None)
        if eos_token_id is not None and tokens and tokens[-1] != eos_token_id:
            tokens.append(eos_token_id)
        attention_mask = [1] * len(tokens)
        return {
            "input_ids": mx.array(tokens, dtype=mx.int32),
            "attention_mask": mx.array(attention_mask, dtype=mx.int32),
            "pixel_values": None,
        }
    record = _chat_record(example)
    messages = cast(list[dict[str, Any]], record["messages"])
    prompt = _apply_multimodal_chat_template(
        processor=processor,
        tokenizer=tokenizer,
        messages=messages,
        tools=record.get("tools"),
    )
    images = _extract_image_sources_from_messages(messages)
    inputs = _prepare_multimodal_inputs(
        processor=processor,
        prompts=[prompt],
        images=images if use_external_images else (),
        image_token_index=image_token_index,
    )
    payload: dict[str, Any] = {
        "input_ids": _squeeze_batch_tensor(inputs["input_ids"]),
        "attention_mask": _squeeze_batch_tensor(
            inputs.get("attention_mask", mx.ones_like(inputs["input_ids"]))
        ),
        "pixel_values": _squeeze_optional_batch_tensor(inputs.get("pixel_values")),
    }
    for key, value in inputs.items():
        if key in {"input_ids", "attention_mask", "pixel_values"}:
            continue
        payload[key] = _squeeze_optional_batch_tensor(value)
    return payload


class _PreferenceTrainingDataset:
    def __init__(
        self,
        *,
        examples: Sequence[PreferenceExample],
        tokenizer: Any,
    ) -> None:
        self._examples = list(examples)
        self._tokenizer = tokenizer
        self._cache: dict[int, dict[str, Any]] = {}

    def __len__(self) -> int:
        return len(self._examples)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        cached = self._cache.get(idx)
        if cached is not None:
            return cached
        record = _build_preference_record(example=self._examples[idx], tokenizer=self._tokenizer)
        self._cache[idx] = record
        return record

    def itemlen(self, idx: int) -> int:
        record = self[idx]
        return max(len(record["chosen_input_ids"]), len(record["rejected_input_ids"]))

    def describe_index(self, idx: int) -> str | None:
        metadata = self._examples[idx].metadata
        source_ref = _extract_source_reference_from_payload({"metadata": metadata})
        if source_ref is not None:
            return source_ref
        title = metadata.get("title")
        if isinstance(title, str) and title.strip():
            return title.strip()
        return None


class _WrappedPreferenceVisionDataset:
    def __init__(
        self,
        *,
        examples: Sequence[PreferenceExample],
        processor: Any,
        raw_config: dict[str, Any],
    ) -> None:
        self._examples = list(examples)
        dataset_payload = [
            {
                "chosen": _preference_sequence_record(example.chosen),
                "rejected": _preference_sequence_record(example.rejected),
                "images": _merge_preference_image_sources(example),
            }
            for example in self._examples
        ]
        self._dataset = PreferenceVisionDataset(dataset_payload, raw_config, processor)

    def __len__(self) -> int:
        return len(self._dataset)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        return cast(dict[str, Any], self._dataset[idx])

    def itemlen(self, idx: int) -> int:
        record = self[idx]
        return max(len(record["chosen_input_ids"]), len(record["rejected_input_ids"]))

    def describe_index(self, idx: int) -> str | None:
        metadata = self._examples[idx].metadata
        source_ref = _extract_source_reference_from_payload({"metadata": metadata})
        if source_ref is not None:
            return source_ref
        title = metadata.get("title")
        if isinstance(title, str) and title.strip():
            return title.strip()
        return None


def _build_preference_record(
    *,
    example: PreferenceExample,
    tokenizer: Any,
) -> dict[str, Any]:
    chosen_tokens = _preference_sequence_tokens(
        sequence=example.chosen,
        tokenizer=tokenizer,
        tools=example.tools,
    )
    rejected_tokens = _preference_sequence_tokens(
        sequence=example.rejected,
        tokenizer=tokenizer,
        tools=example.tools,
    )
    return {
        "chosen_input_ids": mx.array(chosen_tokens, dtype=mx.int32),
        "chosen_attention_mask": mx.ones((len(chosen_tokens),), dtype=mx.int32),
        "chosen_pixel_values": None,
        "rejected_input_ids": mx.array(rejected_tokens, dtype=mx.int32),
        "rejected_attention_mask": mx.ones((len(rejected_tokens),), dtype=mx.int32),
        "rejected_pixel_values": None,
    }


def _preference_sequence_tokens(
    *,
    sequence: str | list[Any],
    tokenizer: Any,
    tools: list[dict[str, Any]],
) -> list[int]:
    if isinstance(sequence, str):
        tokens = tokenizer.encode(sequence)
        eos_token_id = getattr(tokenizer, "eos_token_id", None)
        if eos_token_id is not None and tokens and tokens[-1] != eos_token_id:
            tokens.append(eos_token_id)
        return cast(list[int], tokens)
    payload = cast(list[dict[str, Any]], _preference_sequence_record(sequence))
    try:
        tokens = tokenizer.apply_chat_template(
            payload,
            tools=tools or None,
            return_dict=False,
        )
    except TypeError:
        tokens = tokenizer.apply_chat_template(
            payload,
            return_dict=False,
        )
    return cast(list[int], tokens)


def _preference_sequence_record(sequence: str | list[Any]) -> str | list[dict[str, Any]]:
    if isinstance(sequence, str):
        return sequence
    return [_message_record(message) for message in sequence]


def _extract_image_sources_from_preference_sequence(sequence: str | list[Any]) -> list[str]:
    if isinstance(sequence, str):
        return []
    return _extract_image_sources_from_messages(
        [_message_record(message) for message in sequence]
    )


def _merge_preference_image_sources(example: PreferenceExample) -> list[str]:
    merged: list[str] = []
    for source in (
        *_extract_image_sources_from_preference_sequence(example.chosen),
        *_extract_image_sources_from_preference_sequence(example.rejected),
    ):
        if source and source not in merged:
            merged.append(source)
    return merged


def _apply_multimodal_chat_template(
    *,
    processor: Any,
    tokenizer: Any,
    messages: list[dict[str, Any]],
    tools: Any,
) -> str:
    apply_chat_template = getattr(tokenizer, "apply_chat_template", None)
    if callable(apply_chat_template):
        kwargs: dict[str, Any] = {
            "tokenize": False,
            "add_generation_prompt": False,
        }
        if tools:
            kwargs["tools"] = tools
        try:
            prompt = apply_chat_template(messages, **kwargs)
        except TypeError:
            kwargs.pop("tools", None)
            prompt = apply_chat_template(messages, **kwargs)
        if isinstance(prompt, str):
            return prompt
    process_apply_chat_template = getattr(processor, "apply_chat_template", None)
    if callable(process_apply_chat_template):
        prompt = process_apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=False,
        )
        if isinstance(prompt, str):
            return prompt
    raise ValueError("multimodal_apply_chat_template_missing")


def _extract_image_sources_from_messages(messages: Sequence[dict[str, Any]]) -> list[str]:
    images: list[str] = []
    for message in messages:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict):
                continue
            item_type = str(part.get("type") or "")
            if item_type not in {"image", "input_image", "image_url"}:
                continue
            image = part.get("image")
            if isinstance(image, str) and image.strip():
                images.append(image.strip())
                continue
            image_url = part.get("image_url")
            if isinstance(image_url, str) and image_url.strip():
                images.append(image_url.strip())
    return images


def _prepare_multimodal_inputs(
    *,
    processor: Any,
    prompts: list[str],
    images: Sequence[str],
    image_token_index: int,
) -> dict[str, Any]:
    from mlx_vlm import prepare_inputs

    return cast(
        dict[str, Any],
        prepare_inputs(
            processor=processor,
            prompts=prompts,
            images=list(images) if images else None,
            image_token_index=image_token_index,
            padding=False,
            return_tensors="mlx",
        ),
    )


def _squeeze_batch_tensor(value: Any) -> Any:
    if hasattr(value, "ndim") and hasattr(value, "shape") and value.ndim > 1 and value.shape[0] == 1:
        return value[0]
    return value


def _squeeze_optional_batch_tensor(value: Any) -> Any:
    if value is None:
        return None
    return _squeeze_batch_tensor(value)


def _multimodal_image_token_index_from_config(raw_config: dict[str, Any]) -> int:
    raw_token = raw_config.get("image_token_index") or raw_config.get("image_token_id")
    if isinstance(raw_token, int):
        return raw_token
    raise ValueError("multimodal_image_token_missing")


def _should_use_multimodal_backend(
    *,
    config: TrainerConfig,
    composition: DatasetComposition,
    model_profile: ModelProfile,
) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    total_image_examples = composition.image_chat_examples + composition.image_preference_examples
    total_video_examples = composition.video_chat_examples + composition.video_preference_examples
    total_audio_examples = composition.audio_chat_examples + composition.audio_preference_examples
    if not config.train_vision:
        return False, warnings
    if total_image_examples <= 0:
        warnings.append(
            "Vision training was requested, but the dataset does not contain image-grounded examples."
        )
        return False, warnings
    if total_video_examples > 0 or total_audio_examples > 0:
        warnings.append(
            "Vision training currently supports image-grounded examples only. Video/audio examples will stay on the text training backend."
        )
        return False, warnings
    if not model_profile.capabilities.image:
        warnings.append(
            "Vision training was requested, but the model config does not advertise image capability."
        )
        return False, warnings
    return True, warnings


def _load_multimodal_raw_config(model_path: str) -> dict[str, Any]:
    runtime_path = prepare_runtime_model_path(model_path)
    config_path = runtime_path / "config.json"
    return cast(dict[str, Any], json.loads(config_path.read_text(encoding="utf-8")))


def _multimodal_uses_external_images(raw_config: dict[str, Any]) -> bool:
    model_type = str(raw_config.get("model_type") or "")
    return not (
        model_type.startswith("gemma")
        or model_type == "smolvlm"
    )


def _build_multimodal_dataset(
    *,
    examples: list[ContinualPretrainingExample | ChatSFTExample],
    processor: Any,
    raw_config: dict[str, Any],
) -> _MultimodalTrainingDataset:
    return _MultimodalTrainingDataset(
        examples=examples,
        processor=processor,
        image_token_index=_multimodal_image_token_index_from_config(raw_config),
        use_external_images=_multimodal_uses_external_images(raw_config),
    )


def _build_preference_dataset(
    *,
    examples: list[PreferenceExample],
    tokenizer: Any,
) -> _PreferenceTrainingDataset:
    if not examples:
        raise ValueError("No preference examples were provided.")
    return _PreferenceTrainingDataset(examples=examples, tokenizer=tokenizer)


def _build_multimodal_preference_dataset(
    *,
    examples: list[PreferenceExample],
    processor: Any,
    raw_config: dict[str, Any],
) -> _WrappedPreferenceVisionDataset:
    if not examples:
        raise ValueError("No preference examples were provided.")
    return _WrappedPreferenceVisionDataset(
        examples=examples,
        processor=processor,
        raw_config=raw_config,
    )


def _prepare_multimodal_training_model(
    *,
    model: Any,
    lora: LoRAHyperparameters,
    train_vision: bool,
) -> None:
    if lora.num_layers <= 0:
        model.freeze()
    else:
        modules = vlm_find_all_linear_names(model.language_model)
        vlm_get_peft_model(
            model,
            modules,
            rank=lora.rank,
            alpha=lora.scale,
            dropout=lora.dropout,
            freeze=True,
            verbose=False,
        )
    if train_vision:
        vlm_unfreeze_modules(
            model,
            [
                "vision_model",
                "vision_tower",
                "mm_projector",
                "multi_modal_projector",
                "aligner",
                "connector",
                "vision_resampler",
            ],
        )


def run_training(config: TrainerConfig) -> TrainingRunReport:
    started_at = time.perf_counter()
    normalized_config = _normalize_config(config)
    output_dir_path = Path(normalized_config.output_dir).expanduser().resolve()
    output_dir_path.mkdir(parents=True, exist_ok=True)
    checkpoint_samples_path = _checkpoint_samples_output_path(
        output_dir=output_dir_path,
        checkpoint_sample=normalized_config.checkpoint_sample,
    )

    try:
        use_sequential_streaming = _should_use_sequential_streaming(
            dataset_path=normalized_config.dataset_path,
            valid_path=normalized_config.valid_path,
            max_examples=normalized_config.max_examples,
            replay_dataset_path=normalized_config.stability.replay_dataset_path,
        )
        if normalized_config.train_vision or normalized_config.train_mode == "orpo":
            use_sequential_streaming = False
        train_examples: list[ParsedTrainingExample] = []
        valid_examples: list[ParsedTrainingExample] = []
        train_source_paths: list[Path] = []
        valid_source_paths: list[Path] = []
        token_audit: TokenAuditReport | None = None
        if use_sequential_streaming:
            train_source_paths, valid_source_paths = _split_sequential_source_paths(
                dataset_path=normalized_config.dataset_path,
                valid_path=normalized_config.valid_path,
                validation_fraction=normalized_config.validation_fraction,
                seed=normalized_config.seed,
            )
            composition = _dataset_composition_from_source_paths(
                train_source_paths=train_source_paths,
                valid_source_paths=valid_source_paths,
            )
        else:
            train_examples, valid_examples = _load_and_split_examples(
                dataset_path=normalized_config.dataset_path,
                valid_path=normalized_config.valid_path,
                validation_fraction=normalized_config.validation_fraction,
                seed=normalized_config.seed,
                max_examples=normalized_config.max_examples,
            )
            if normalized_config.train_mode != "orpo":
                train_examples = _mix_replay_examples(
                    train_examples=train_examples,
                    replay_dataset_path=normalized_config.stability.replay_dataset_path,
                    replay_target_fraction=normalized_config.stability.replay_target_fraction,
                    seed=normalized_config.seed,
                )
            composition = _dataset_composition(train_examples, valid_examples)
        warnings: list[str] = []
        warnings.extend(_replay_warnings(normalized_config))
        train_mode_error = _train_mode_dataset_error(
            config=normalized_config,
            train_examples=train_examples,
            valid_examples=valid_examples,
        )
        if train_mode_error is not None:
            return TrainingRunReport(
                mode="dry_run" if normalized_config.dry_run else "train",
                status="failed",
                model_path=normalized_config.model_path,
                dataset_path=normalized_config.dataset_path,
                output_dir=str(output_dir_path),
                configured_context_window=normalized_config.context_window,
                dataset=composition,
                memory=MemoryEstimate(
                    trainable_parameter_count=0,
                    estimated_activation_bytes=0,
                    estimated_optimizer_bytes=0,
                    estimated_peak_working_set_bytes=0,
                ),
                warnings=warnings,
                checkpoint_samples_path=(
                    str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
                ),
                elapsed_sec=round(time.perf_counter() - started_at, 3),
                error=train_mode_error,
            )
        if normalized_config.train_mode == "orpo":
            warnings.append(
                f"Preference optimization is enabled with ORPO (beta={normalized_config.orpo_beta:.3f})."
            )
        resolved_iters = normalized_config.iters
        if normalized_config.epochs is not None:
            resolved_iters = _resolve_epoch_iterations(
                train_examples=composition.train_examples,
                batch_size=normalized_config.batch_size,
                epochs=normalized_config.epochs,
            )
            warnings.append(
                "Epoch-based iteration scheduling is enabled: "
                f"{normalized_config.epochs} epoch(s) across {composition.train_examples} train examples "
                f"at batch_size={normalized_config.batch_size} resolves to {resolved_iters} training step(s)."
            )
        model_profile = inspect_model_dir(normalized_config.model_path)
        use_multimodal_backend, multimodal_backend_warnings = _should_use_multimodal_backend(
            config=normalized_config,
            composition=composition,
            model_profile=model_profile,
        )
        warnings.extend(multimodal_backend_warnings)
        warnings.extend(
            _dataset_warnings(
                composition,
                train_vision=normalized_config.train_vision,
                use_multimodal_backend=use_multimodal_backend,
            )
        )
        quantized_model_error = _quantized_training_error(model_profile)
        if quantized_model_error is not None:
            warnings.append(quantized_model_error)
            return TrainingRunReport(
                mode="dry_run" if normalized_config.dry_run else "train",
                status="failed",
                model_path=normalized_config.model_path,
                dataset_path=normalized_config.dataset_path,
                output_dir=str(output_dir_path),
                configured_context_window=model_profile.text_context_window,
                dataset=composition,
                memory=MemoryEstimate(
                    device_name=None,
                    device_memory_bytes=None,
                    recommended_working_set_bytes=None,
                    model_weight_bytes=model_profile.weight_bytes,
                    trainable_parameter_count=0,
                    saved_trainable_tensor_bytes=0,
                    estimated_activation_bytes=0,
                    estimated_optimizer_bytes=0,
                    estimated_peak_working_set_bytes=0,
                    fits_recommended_working_set=None,
                ),
                warnings=warnings,
                checkpoint_samples_path=(
                    str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
                ),
                elapsed_sec=round(time.perf_counter() - started_at, 3),
                error="quantized_model_unsupported",
            )
        if use_multimodal_backend:
            raw_config = _load_multimodal_raw_config(normalized_config.model_path)
            loaded_multimodal = load_multimodal(
                normalized_config.model_path,
                processor_config={"trust_remote_code": True},
                model_config=_optional_model_config_override(
                    normalized_config.model_path,
                    context_window=normalized_config.context_window,
                    yarn_factor=normalized_config.yarn_factor,
                ),
                adapter_path=normalized_config.adapter_path,
                lazy=normalized_config.dry_run,
            )
            model, processor = cast(tuple[Any, Any], loaded_multimodal)
            tokenizer = getattr(processor, "tokenizer", processor)
        else:
            loaded = load(
                normalized_config.model_path,
                tokenizer_config={"trust_remote_code": True},
                model_config=_optional_model_config_override(
                    normalized_config.model_path,
                    context_window=normalized_config.context_window,
                    yarn_factor=normalized_config.yarn_factor,
                ),
                adapter_path=normalized_config.adapter_path,
                lazy=normalized_config.dry_run,
                return_config=True,
            )
            model, tokenizer, raw_config = cast(tuple[Any, Any, dict[str, Any]], loaded)
        train_dataset: Any
        valid_dataset: Any | None
        if normalized_config.train_mode == "orpo":
            train_preference_examples = cast(list[PreferenceExample], train_examples)
            valid_preference_examples = cast(list[PreferenceExample], valid_examples)
            if use_multimodal_backend:
                train_dataset = _build_multimodal_preference_dataset(
                    examples=train_preference_examples,
                    processor=processor,
                    raw_config=raw_config,
                )
                valid_dataset = (
                    _build_multimodal_preference_dataset(
                        examples=valid_preference_examples,
                        processor=processor,
                        raw_config=raw_config,
                    )
                    if valid_preference_examples
                    else None
                )
            else:
                train_dataset = _build_preference_dataset(
                    examples=train_preference_examples,
                    tokenizer=tokenizer,
                )
                valid_dataset = (
                    _build_preference_dataset(
                        examples=valid_preference_examples,
                        tokenizer=tokenizer,
                    )
                    if valid_preference_examples
                    else None
                )
        elif use_multimodal_backend:
            train_dataset = _build_multimodal_dataset(
                examples=cast(list[ContinualPretrainingExample | ChatSFTExample], train_examples),
                processor=processor,
                raw_config=raw_config,
            )
            valid_dataset = (
                _build_multimodal_dataset(
                    examples=cast(list[ContinualPretrainingExample | ChatSFTExample], valid_examples),
                    processor=processor,
                    raw_config=raw_config,
                )
                if valid_examples
                else None
            )
        elif use_sequential_streaming:
            train_dataset = _build_sequential_dataset(
                source_paths=train_source_paths,
                tokenizer=tokenizer,
                mask_prompt=normalized_config.mask_prompt,
            )
            valid_dataset = (
                _build_sequential_dataset(
                    source_paths=valid_source_paths,
                    tokenizer=tokenizer,
                    mask_prompt=normalized_config.mask_prompt,
                )
                if valid_source_paths
                else None
            )
        else:
            train_dataset = _build_dataset(
                examples=train_examples,
                tokenizer=tokenizer,
                mask_prompt=normalized_config.mask_prompt,
            )
            valid_dataset = (
                _build_dataset(
                    examples=valid_examples,
                    tokenizer=tokenizer,
                    mask_prompt=normalized_config.mask_prompt,
                )
                if valid_examples
                else None
            )
        token_audit = _audit_training_datasets(
            train_dataset=train_dataset,
            valid_dataset=valid_dataset,
            config=normalized_config,
        )
        if use_multimodal_backend:
            _prepare_multimodal_training_model(
                model=model,
                lora=normalized_config.lora,
                train_vision=normalized_config.train_vision,
            )
            if normalized_config.base_update.model_dump() != BaseWeightUpdateConfig().model_dump():
                warnings.append(
                    "Vision training currently ignores custom base-weight update scope and uses language-model LoRA plus optional vision-stack unfreezing."
                )
            if normalized_config.lora.num_layers > 0:
                warnings.append(
                    "Vision training applies LoRA across the full language-model linear set; lora.num_layers is not enforced on the multimodal backend."
                )
        else:
            _prepare_training_model(
                model=model,
                lora=normalized_config.lora,
                base_update=normalized_config.base_update,
            )
        trainable_parameter_count = _count_trainable_parameters(model)
        saved_trainable_tensor_bytes = _count_saved_trainable_tensor_bytes(model)
        if not use_multimodal_backend:
            warnings.extend(
                _base_update_warnings(
                    config=normalized_config,
                    trainable_parameter_count=trainable_parameter_count,
                )
            )
        memory = _estimate_memory(
            model_profile=model_profile,
            raw_config=raw_config,
            trainable_parameter_count=trainable_parameter_count,
            saved_trainable_tensor_bytes=saved_trainable_tensor_bytes,
            batch_size=normalized_config.batch_size,
            sequence_length=token_audit.effective_sequence_length,
            grad_checkpoint=normalized_config.grad_checkpoint,
            lora=normalized_config.lora,
            base_update=normalized_config.base_update,
            optimizer_name=normalized_config.optimizer,
            stability=normalized_config.stability,
        )
        warnings.extend(
            _memory_safety_warnings(
                memory=memory,
                config=normalized_config,
                token_audit=token_audit,
            )
        )
        effective_checkpoint_sample = normalized_config.checkpoint_sample
        if use_multimodal_backend and normalized_config.checkpoint_sample.enabled:
            warnings.append(
                "Checkpoint sampling is disabled on the multimodal training backend because the saved adapters may include vision weights."
            )
            effective_checkpoint_sample = CheckpointSampleConfig(
                enabled=False,
                prompt=normalized_config.checkpoint_sample.prompt,
                max_tokens=normalized_config.checkpoint_sample.max_tokens,
                mode=normalized_config.checkpoint_sample.mode,
                max_kv_size=normalized_config.checkpoint_sample.max_kv_size,
                kv_bits=normalized_config.checkpoint_sample.kv_bits,
                kv_group_size=normalized_config.checkpoint_sample.kv_group_size,
            )
            checkpoint_samples_path = None
        checkpoint_sample_error = None
        if not use_multimodal_backend:
            checkpoint_sample_error = _inline_checkpoint_sample_error(
                raw_config=raw_config,
                tokenizer=tokenizer,
                memory=memory,
                checkpoint_sample=effective_checkpoint_sample,
            )
        if checkpoint_sample_error is not None:
            warnings.append(checkpoint_sample_error)
            if not normalized_config.allow_overlimit:
                return TrainingRunReport(
                    mode="dry_run" if normalized_config.dry_run else "train",
                    status="failed",
                    model_path=normalized_config.model_path,
                    dataset_path=normalized_config.dataset_path,
                    output_dir=str(output_dir_path),
                    configured_context_window=_configured_context_window(raw_config),
                    dataset=composition,
                    memory=memory,
                    warnings=warnings,
                    token_audit=token_audit,
                    checkpoint_samples_path=(
                        str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
                    ),
                    elapsed_sec=round(time.perf_counter() - started_at, 3),
                    error="inline_checkpoint_sampling_exceeded",
                )
        if (
            memory.fits_memory_budget is False
            and not normalized_config.allow_overlimit
        ):
            warnings.append(
                "Estimated peak working set exceeds the effective training memory budget for full-length examples. "
                "On Apple GPUs the wired working-set ceiling still dominates training-time OOM behavior, so lower batch size, LoRA depth/rank, or base-update scope, or use --allow-overlimit to force training."
            )
            return TrainingRunReport(
                mode="dry_run" if normalized_config.dry_run else "train",
                status="failed",
                model_path=normalized_config.model_path,
                dataset_path=normalized_config.dataset_path,
                output_dir=str(output_dir_path),
                configured_context_window=_configured_context_window(raw_config),
                dataset=composition,
                memory=memory,
                warnings=warnings,
                token_audit=token_audit,
                checkpoint_samples_path=(
                    str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
                ),
                elapsed_sec=round(time.perf_counter() - started_at, 3),
                error="estimated_working_set_exceeded",
            )

        if normalized_config.dry_run:
            return TrainingRunReport(
                mode="dry_run",
                status="ready",
                model_path=normalized_config.model_path,
                dataset_path=normalized_config.dataset_path,
                output_dir=str(output_dir_path),
                configured_context_window=_configured_context_window(raw_config),
                dataset=composition,
                memory=memory,
                warnings=warnings,
                token_audit=token_audit,
                checkpoint_samples_path=(
                    str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
                ),
                elapsed_sec=round(time.perf_counter() - started_at, 3),
            )
        _ensure_dataset_fits_sequence_limit(
            dataset=train_dataset,
            max_seq_length=normalized_config.max_seq_length,
            dataset_name="train",
        )
        if valid_dataset is not None:
            _ensure_dataset_fits_sequence_limit(
                dataset=valid_dataset,
                max_seq_length=normalized_config.max_seq_length,
                dataset_name="validation",
            )

        callback = _MetricsJsonlCallback(output_dir_path / "train_metrics.jsonl")
        has_base_updates = _has_base_trainable_parameters(model)
        optimizer = _build_optimizer(
            optimizer_name=normalized_config.optimizer,
            learning_rate=normalized_config.learning_rate,
            base_learning_rate_scale=normalized_config.base_update.learning_rate_scale,
            has_base_updates=has_base_updates,
        )
        _write_training_config(normalized_config)
        _write_adapter_config(normalized_config)
        if normalized_config.train_mode == "orpo":
            training_args = ORPOTrainingArgs(
                batch_size=normalized_config.batch_size,
                iters=resolved_iters,
                val_batches=normalized_config.val_batches,
                steps_per_report=normalized_config.steps_per_report,
                steps_per_eval=normalized_config.steps_per_eval,
                steps_per_save=normalized_config.save_every,
                max_seq_length=normalized_config.max_seq_length,
                adapter_file=str(output_dir_path / "adapters.safetensors"),
                grad_checkpoint=normalized_config.grad_checkpoint,
                learning_rate=normalized_config.learning_rate,
                grad_clip=normalized_config.stability.grad_clip_norm,
                full_finetune=False,
                gradient_accumulation_steps=normalized_config.grad_accumulation_steps,
                beta=normalized_config.orpo_beta,
            )
            if use_multimodal_backend:
                _run_multimodal_preference_training_loop(
                    model=model,
                    optimizer=optimizer,
                    train_dataset=train_dataset,
                    val_dataset=valid_dataset,
                    args=training_args,
                    training_callback=callback,
                    stability=normalized_config.stability,
                )
                checkpoint_samples_path = None
            else:
                _run_preference_training_loop(
                    model=model,
                    tokenizer=tokenizer,
                    optimizer=optimizer,
                    train_dataset=train_dataset,
                    val_dataset=valid_dataset,
                    args=training_args,
                    training_callback=callback,
                    stability=normalized_config.stability,
                    has_base_updates=has_base_updates,
                    base_learning_rate_scale=normalized_config.base_update.learning_rate_scale,
                    checkpoint_sample=effective_checkpoint_sample,
                    checkpoint_samples_path=(
                        checkpoint_samples_path
                        if effective_checkpoint_sample.mode == "inline"
                        else None
                    ),
                )
        elif use_multimodal_backend:
            training_args = VlmTrainingArgs(
                batch_size=normalized_config.batch_size,
                iters=resolved_iters,
                val_batches=normalized_config.val_batches,
                steps_per_report=normalized_config.steps_per_report,
                steps_per_eval=normalized_config.steps_per_eval,
                steps_per_save=normalized_config.save_every,
                max_seq_length=normalized_config.max_seq_length,
                adapter_file=str(output_dir_path / "adapters.safetensors"),
                grad_checkpoint=normalized_config.grad_checkpoint,
                learning_rate=normalized_config.learning_rate,
                grad_clip=normalized_config.stability.grad_clip_norm,
                full_finetune=False,
                gradient_accumulation_steps=normalized_config.grad_accumulation_steps,
            )
            _run_multimodal_training_loop(
                model=model,
                processor=processor,
                optimizer=optimizer,
                train_dataset=train_dataset,
                val_dataset=valid_dataset,
                args=training_args,
                training_callback=callback,
                stability=normalized_config.stability,
            )
            checkpoint_samples_path = None
        else:
            training_args = TrainingArgs(
                batch_size=normalized_config.batch_size,
                iters=resolved_iters,
                val_batches=normalized_config.val_batches,
                steps_per_report=normalized_config.steps_per_report,
                steps_per_eval=normalized_config.steps_per_eval,
                steps_per_save=normalized_config.save_every,
                max_seq_length=normalized_config.max_seq_length,
                adapter_file=str(output_dir_path / "adapters.safetensors"),
                grad_checkpoint=normalized_config.grad_checkpoint,
                grad_accumulation_steps=normalized_config.grad_accumulation_steps,
            )
            loss_function = _build_training_loss(
                model=model,
                l2_sp_weight=normalized_config.base_update.l2_sp_weight,
            )
            _run_training_loop(
                model=model,
                tokenizer=tokenizer,
                optimizer=optimizer,
                train_dataset=train_dataset,
                val_dataset=valid_dataset,
                args=training_args,
                loss=loss_function,
                training_callback=callback,
                stability=normalized_config.stability,
                has_base_updates=has_base_updates,
                base_learning_rate_scale=normalized_config.base_update.learning_rate_scale,
                checkpoint_sample=effective_checkpoint_sample,
                checkpoint_samples_path=(
                    checkpoint_samples_path
                    if effective_checkpoint_sample.mode == "inline"
                    else None
                ),
            )
        if (
            not use_multimodal_backend
            and effective_checkpoint_sample.enabled
            and effective_checkpoint_sample.mode == "after_training"
        ):
            del optimizer
            del train_dataset
            del valid_dataset
            del callback
            del model
            del tokenizer
            gc.collect()
            _maybe_clear_metal_cache()
            try:
                sampling_report = sample_saved_checkpoints(
                    model_path=normalized_config.model_path,
                    train_output_dir=output_dir_path,
                    prompt=effective_checkpoint_sample.prompt,
                    max_tokens=effective_checkpoint_sample.max_tokens,
                    max_kv_size=effective_checkpoint_sample.max_kv_size,
                    kv_bits=effective_checkpoint_sample.kv_bits,
                    kv_group_size=effective_checkpoint_sample.kv_group_size,
                )
                checkpoint_samples_path = Path(sampling_report.records_path)
            except Exception as exc:
                warnings.append(
                    "Post-training checkpoint sampling failed after the weights were saved: "
                    f"{exc}"
                )
                checkpoint_samples_path = None
        return TrainingRunReport(
            mode="train",
            status="completed",
            model_path=normalized_config.model_path,
            dataset_path=normalized_config.dataset_path,
            output_dir=str(output_dir_path),
            configured_context_window=_configured_context_window(raw_config),
            dataset=composition,
            memory=memory,
            warnings=warnings,
            token_audit=token_audit,
            adapter_file=str(output_dir_path / "adapters.safetensors"),
            metrics_path=str(output_dir_path / "train_metrics.jsonl"),
            checkpoint_samples_path=(
                str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
            ),
            elapsed_sec=round(time.perf_counter() - started_at, 3),
        )
    except Exception as exc:
        return TrainingRunReport(
            mode="dry_run" if normalized_config.dry_run else "train",
            status="failed",
            model_path=normalized_config.model_path,
            dataset_path=normalized_config.dataset_path,
            output_dir=str(output_dir_path),
            configured_context_window=normalized_config.context_window,
            dataset=DatasetComposition(
                train_examples=0,
                valid_examples=0,
                cpt_examples=0,
                chat_examples=0,
                multimodal_chat_examples=0,
                tool_call_messages=0,
                tool_result_messages=0,
                thinking_examples=0,
                placeholder_only_multimodal_examples=0,
            ),
            memory=MemoryEstimate(
                trainable_parameter_count=0,
                estimated_activation_bytes=0,
                estimated_optimizer_bytes=0,
                estimated_peak_working_set_bytes=0,
            ),
            checkpoint_samples_path=(
                str(checkpoint_samples_path) if checkpoint_samples_path is not None else None
            ),
            elapsed_sec=round(time.perf_counter() - started_at, 3),
            error=str(exc),
        )


def _normalize_config(config: TrainerConfig) -> TrainerConfig:
    payload = config.model_dump()
    payload["model_path"] = str(Path(config.model_path).expanduser().resolve())
    payload["dataset_path"] = str(Path(config.dataset_path).expanduser().resolve())
    payload["adapter_path"] = (
        str(Path(config.adapter_path).expanduser().resolve())
        if config.adapter_path is not None
        else None
    )
    payload["valid_path"] = (
        str(Path(config.valid_path).expanduser().resolve())
        if config.valid_path is not None
        else None
    )
    payload["output_dir"] = str(Path(config.output_dir).expanduser().resolve())
    replay_dataset_path = config.stability.replay_dataset_path
    if replay_dataset_path is not None:
        payload["stability"]["replay_dataset_path"] = str(
            Path(replay_dataset_path).expanduser().resolve()
        )
    return TrainerConfig(**payload)


def _resolve_epoch_iterations(
    *,
    train_examples: int,
    batch_size: int,
    epochs: int,
) -> int:
    if epochs <= 0:
        raise ValueError("epochs must be positive when provided.")
    if batch_size <= 0:
        raise ValueError("batch_size must be positive.")
    if train_examples <= 0:
        return epochs
    batches_per_epoch = max(1, (train_examples + batch_size - 1) // batch_size)
    return batches_per_epoch * epochs


def _write_training_config(config: TrainerConfig) -> None:
    output_dir_path = Path(config.output_dir).expanduser().resolve()
    (output_dir_path / "training_config.json").write_text(
        json.dumps(config.model_dump(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _write_adapter_config(config: TrainerConfig) -> None:
    output_dir_path = Path(config.output_dir).expanduser().resolve()
    adapter_config_path = output_dir_path / "adapter_config.json"
    adapter_config_path.write_text(
        json.dumps(
            _build_adapter_config_payload(
                lora_num_layers=config.lora.num_layers,
                lora_rank=config.lora.rank,
                lora_scale=config.lora.scale,
                lora_dropout=config.lora.dropout,
            ),
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def _load_and_split_examples(
    *,
    dataset_path: str,
    valid_path: str | None,
    validation_fraction: float,
    seed: int,
    max_examples: int | None,
) -> tuple[list[ParsedTrainingExample], list[ParsedTrainingExample]]:
    train_examples = _load_examples(Path(dataset_path), max_examples=max_examples)
    if valid_path is not None:
        valid_examples = _load_examples(Path(valid_path), max_examples=max_examples)
        return train_examples, valid_examples
    if not train_examples:
        return [], []
    if validation_fraction <= 0:
        return train_examples, []

    shuffled = list(train_examples)
    random.Random(seed).shuffle(shuffled)
    valid_count = min(max(int(round(len(shuffled) * validation_fraction)), 1), len(shuffled) - 1)
    return shuffled[valid_count:], shuffled[:valid_count]


def _should_use_sequential_streaming(
    *,
    dataset_path: str,
    valid_path: str | None,
    max_examples: int | None,
    replay_dataset_path: str | None,
) -> bool:
    if max_examples is not None or replay_dataset_path is not None:
        return False
    if valid_path is not None and not is_sequential_cpt_manifest_path(valid_path):
        return False
    return is_sequential_cpt_manifest_path(dataset_path)


def _split_sequential_source_paths(
    *,
    dataset_path: str,
    valid_path: str | None,
    validation_fraction: float,
    seed: int,
) -> tuple[list[Path], list[Path]]:
    train_source_paths = list(iter_sequential_cpt_source_paths(Path(dataset_path)))
    if valid_path is not None:
        return train_source_paths, list(iter_sequential_cpt_source_paths(Path(valid_path)))
    if validation_fraction <= 0 or len(train_source_paths) <= 1:
        return train_source_paths, []
    shuffled = list(train_source_paths)
    random.Random(seed).shuffle(shuffled)
    valid_count = min(max(int(round(len(shuffled) * validation_fraction)), 1), len(shuffled) - 1)
    return shuffled[valid_count:], shuffled[:valid_count]


def _load_examples(
    path: Path,
    *,
    max_examples: int | None,
) -> list[ParsedTrainingExample]:
    loaded: list[ParsedTrainingExample] = []
    for source_path in iter_sequential_cpt_source_paths(path):
        for line in _iter_jsonl_lines(source_path):
            loaded.append(parse_training_example(json.loads(line)))
            if max_examples is not None and len(loaded) >= max_examples:
                return loaded
    return loaded


def _dataset_composition_from_source_paths(
    *,
    train_source_paths: list[Path],
    valid_source_paths: list[Path],
) -> DatasetComposition:
    cpt_examples = 0
    chat_examples = 0
    preference_examples = 0
    multimodal_chat_examples = 0
    multimodal_preference_examples = 0
    image_chat_examples = 0
    video_chat_examples = 0
    audio_chat_examples = 0
    image_preference_examples = 0
    video_preference_examples = 0
    audio_preference_examples = 0
    tool_call_messages = 0
    tool_result_messages = 0
    thinking_examples = 0
    placeholder_only_multimodal_examples = 0
    for source_path in [*train_source_paths, *valid_source_paths]:
        for line in _iter_jsonl_lines(source_path):
            example = parse_training_example(json.loads(line))
            if isinstance(example, ContinualPretrainingExample):
                cpt_examples += 1
                continue
            if isinstance(example, ChatSFTExample):
                chat_examples += 1
                saw_multimodal, saw_image, saw_video, saw_audio = _inspect_training_messages(
                    messages=example.messages,
                )
                if saw_multimodal:
                    multimodal_chat_examples += 1
                    placeholder_only_multimodal_examples += 1
                if saw_image:
                    image_chat_examples += 1
                if saw_video:
                    video_chat_examples += 1
                if saw_audio:
                    audio_chat_examples += 1
                tool_call_messages += _count_tool_call_messages(example.messages)
                tool_result_messages += _count_tool_result_messages(example.messages)
                thinking_examples += _count_thinking_messages(example.messages)
                continue
            preference_examples += 1
            tool_call_messages += _count_tool_call_messages_in_preference(example)
            tool_result_messages += _count_tool_result_messages_in_preference(example)
            thinking_examples += _count_thinking_messages_in_preference(example)
            saw_multimodal, saw_image, saw_video, saw_audio = _inspect_preference_example(example)
            if saw_multimodal:
                multimodal_preference_examples += 1
                placeholder_only_multimodal_examples += 1
            if saw_image:
                image_preference_examples += 1
            if saw_video:
                video_preference_examples += 1
            if saw_audio:
                audio_preference_examples += 1
    return DatasetComposition(
        train_examples=sum(_count_nonempty_lines(path) for path in train_source_paths),
        valid_examples=sum(_count_nonempty_lines(path) for path in valid_source_paths),
        cpt_examples=cpt_examples,
        chat_examples=chat_examples,
        preference_examples=preference_examples,
        multimodal_chat_examples=multimodal_chat_examples,
        multimodal_preference_examples=multimodal_preference_examples,
        image_chat_examples=image_chat_examples,
        video_chat_examples=video_chat_examples,
        audio_chat_examples=audio_chat_examples,
        image_preference_examples=image_preference_examples,
        video_preference_examples=video_preference_examples,
        audio_preference_examples=audio_preference_examples,
        tool_call_messages=tool_call_messages,
        tool_result_messages=tool_result_messages,
        thinking_examples=thinking_examples,
        placeholder_only_multimodal_examples=placeholder_only_multimodal_examples,
    )


def _mix_replay_examples(
    *,
    train_examples: list[ParsedTrainingExample],
    replay_dataset_path: str | None,
    replay_target_fraction: float,
    seed: int,
) -> list[ParsedTrainingExample]:
    if replay_dataset_path is None or replay_target_fraction <= 0 or not train_examples:
        return train_examples
    replay_examples = _load_examples(Path(replay_dataset_path), max_examples=None)
    if not replay_examples:
        return train_examples
    replay_count = max(
        1,
        int(
            round(
                len(train_examples)
                * min(max(replay_target_fraction, 0.0), 0.95)
                / max(1.0 - min(max(replay_target_fraction, 0.0), 0.95), 0.05)
            )
        ),
    )
    rng = random.Random(seed)
    selected = [rng.choice(replay_examples) for _ in range(replay_count)]
    mixed = [*train_examples, *selected]
    rng.shuffle(mixed)
    return mixed


def _dataset_composition(
    train_examples: list[ParsedTrainingExample],
    valid_examples: list[ParsedTrainingExample],
) -> DatasetComposition:
    cpt_examples = 0
    chat_examples = 0
    preference_examples = 0
    multimodal_chat_examples = 0
    multimodal_preference_examples = 0
    image_chat_examples = 0
    video_chat_examples = 0
    audio_chat_examples = 0
    image_preference_examples = 0
    video_preference_examples = 0
    audio_preference_examples = 0
    tool_call_messages = 0
    tool_result_messages = 0
    thinking_examples = 0
    placeholder_only_multimodal_examples = 0
    for example in [*train_examples, *valid_examples]:
        if isinstance(example, ContinualPretrainingExample):
            cpt_examples += 1
            continue
        if isinstance(example, ChatSFTExample):
            chat_examples += 1
            saw_multimodal, saw_image, saw_video, saw_audio = _inspect_training_messages(
                messages=example.messages,
            )
            if saw_multimodal:
                multimodal_chat_examples += 1
                placeholder_only_multimodal_examples += 1
            if saw_image:
                image_chat_examples += 1
            if saw_video:
                video_chat_examples += 1
            if saw_audio:
                audio_chat_examples += 1
            tool_call_messages += _count_tool_call_messages(example.messages)
            tool_result_messages += _count_tool_result_messages(example.messages)
            thinking_examples += _count_thinking_messages(example.messages)
            continue
        preference_examples += 1
        tool_call_messages += _count_tool_call_messages_in_preference(example)
        tool_result_messages += _count_tool_result_messages_in_preference(example)
        thinking_examples += _count_thinking_messages_in_preference(example)
        saw_multimodal, saw_image, saw_video, saw_audio = _inspect_preference_example(example)
        if saw_multimodal:
            multimodal_preference_examples += 1
            placeholder_only_multimodal_examples += 1
        if saw_image:
            image_preference_examples += 1
        if saw_video:
            video_preference_examples += 1
        if saw_audio:
            audio_preference_examples += 1
    return DatasetComposition(
        train_examples=len(train_examples),
        valid_examples=len(valid_examples),
        cpt_examples=cpt_examples,
        chat_examples=chat_examples,
        preference_examples=preference_examples,
        multimodal_chat_examples=multimodal_chat_examples,
        multimodal_preference_examples=multimodal_preference_examples,
        image_chat_examples=image_chat_examples,
        video_chat_examples=video_chat_examples,
        audio_chat_examples=audio_chat_examples,
        image_preference_examples=image_preference_examples,
        video_preference_examples=video_preference_examples,
        audio_preference_examples=audio_preference_examples,
        tool_call_messages=tool_call_messages,
        tool_result_messages=tool_result_messages,
        thinking_examples=thinking_examples,
        placeholder_only_multimodal_examples=placeholder_only_multimodal_examples,
    )


def _inspect_training_messages(
    *,
    messages: Sequence[Any],
) -> tuple[bool, bool, bool, bool]:
    saw_multimodal = False
    saw_image = False
    saw_video = False
    saw_audio = False
    for message in messages:
        content = getattr(message, "content", None)
        if not isinstance(content, list):
            continue
        for part in content:
            part_type = getattr(part, "type", None)
            if part_type in {"image", "input_image", "image_url"}:
                saw_multimodal = True
                saw_image = True
            elif part_type in {"video", "input_video", "video_url"}:
                saw_multimodal = True
                saw_video = True
            elif part_type in {"audio", "input_audio"}:
                saw_multimodal = True
                saw_audio = True
    return saw_multimodal, saw_image, saw_video, saw_audio


def _inspect_preference_example(example: PreferenceExample) -> tuple[bool, bool, bool, bool]:
    saw_multimodal = False
    saw_image = False
    saw_video = False
    saw_audio = False
    for sequence in (example.chosen, example.rejected):
        if not isinstance(sequence, list):
            continue
        seq_saw_multimodal, seq_saw_image, seq_saw_video, seq_saw_audio = _inspect_training_messages(
            messages=sequence,
        )
        saw_multimodal = saw_multimodal or seq_saw_multimodal
        saw_image = saw_image or seq_saw_image
        saw_video = saw_video or seq_saw_video
        saw_audio = saw_audio or seq_saw_audio
    return saw_multimodal, saw_image, saw_video, saw_audio


def _count_tool_call_messages(messages: Sequence[Any]) -> int:
    return sum(1 for message in messages if getattr(message, "tool_calls", None))


def _count_tool_result_messages(messages: Sequence[Any]) -> int:
    return sum(1 for message in messages if getattr(message, "role", None) == "tool")


def _count_thinking_messages(messages: Sequence[Any]) -> int:
    count = 0
    for message in messages:
        reasoning_content = getattr(message, "reasoning_content", None)
        content = getattr(message, "content", None)
        if reasoning_content is not None:
            count += 1
        elif isinstance(content, str) and "<think>" in content:
            count += 1
    return count


def _count_tool_call_messages_in_preference(example: PreferenceExample) -> int:
    total = 0
    for sequence in (example.chosen, example.rejected):
        if isinstance(sequence, list):
            total += _count_tool_call_messages(sequence)
    return total


def _count_tool_result_messages_in_preference(example: PreferenceExample) -> int:
    total = 0
    for sequence in (example.chosen, example.rejected):
        if isinstance(sequence, list):
            total += _count_tool_result_messages(sequence)
    return total


def _count_thinking_messages_in_preference(example: PreferenceExample) -> int:
    total = 0
    for sequence in (example.chosen, example.rejected):
        if isinstance(sequence, list):
            total += _count_thinking_messages(sequence)
    return total


def _train_mode_dataset_error(
    *,
    config: TrainerConfig,
    train_examples: Sequence[ParsedTrainingExample],
    valid_examples: Sequence[ParsedTrainingExample],
) -> str | None:
    all_examples = [*train_examples, *valid_examples]
    if config.train_mode == "orpo":
        if not all_examples:
            return "orpo_requires_preference_dataset"
        if any(not isinstance(example, PreferenceExample) for example in all_examples):
            return "orpo_requires_preference_dataset"
        return None
    if any(isinstance(example, PreferenceExample) for example in all_examples):
        return "preference_examples_require_train_mode_orpo"
    return None


def _dataset_warnings(
    composition: DatasetComposition,
    *,
    train_vision: bool,
    use_multimodal_backend: bool,
) -> list[str]:
    warnings: list[str] = []
    total_multimodal_examples = (
        composition.multimodal_chat_examples + composition.multimodal_preference_examples
    )
    total_image_examples = composition.image_chat_examples + composition.image_preference_examples
    if total_multimodal_examples:
        if use_multimodal_backend and train_vision and total_image_examples > 0:
            warnings.append(
                "Image-grounded examples will use the multimodal training backend and unfreeze the vision stack."
            )
        else:
            warnings.append(
                "Multimodal image/video examples are preserved as chat-template vision tokens, "
                "but this trainer does not fine-tune the vision encoder itself."
            )
    if composition.tool_call_messages or composition.tool_result_messages:
        warnings.append(
            "Tool-use traces are included in the training set and will train tool calling/output formatting behavior."
        )
    if composition.thinking_examples:
        warnings.append(
            "Thinking traces are preserved and included in the language-model loss, whether they arrive via reasoning_content or <think> blocks."
        )
    return warnings


def _replay_warnings(config: TrainerConfig) -> list[str]:
    if config.train_mode == "orpo":
        if config.stability.replay_dataset_path is not None:
            return [
                "Replay data is ignored for ORPO preference training. The configured replay_dataset_path will not be mixed."
            ]
        return []
    replay_dataset_path = config.stability.replay_dataset_path
    if replay_dataset_path is None:
        return [
            "No replay dataset is configured. Forgetting risk is lower with LoRA plus selective base updates, but rehearsal data is still recommended."
        ]
    return [
        f"Replay data is mixed from {replay_dataset_path} at about {config.stability.replay_target_fraction:.0%} target fraction to reduce forgetting."
    ]


def _build_dataset(
    *,
    examples: list[ParsedTrainingExample],
    tokenizer: Any,
    mask_prompt: bool,
) -> CacheDataset:
    datasets: list[Any] = []
    text_records = [
        {"text": example.text}
        for example in examples
        if isinstance(example, ContinualPretrainingExample)
    ]
    chat_records = [
        _chat_record(example)
        for example in examples
        if isinstance(example, ChatSFTExample)
    ]
    if text_records:
        datasets.append(TextDataset(text_records, tokenizer))
    if chat_records:
        datasets.append(ChatDataset(chat_records, tokenizer, mask_prompt=mask_prompt))
    if not datasets:
        raise ValueError("No supported training examples were found.")
    if len(datasets) == 1:
        return CacheDataset(datasets[0])
    return CacheDataset(ConcatenatedDataset(datasets))


def _build_sequential_dataset(
    *,
    source_paths: list[Path],
    tokenizer: Any,
    mask_prompt: bool,
) -> _SequentialJsonlTrainingDataset:
    if not source_paths:
        raise ValueError("No sequential source paths were provided.")
    return _SequentialJsonlTrainingDataset(
        source_paths=source_paths,
        tokenizer=tokenizer,
        mask_prompt=mask_prompt,
    )


def _audit_training_datasets(
    *,
    train_dataset: Any,
    valid_dataset: Any | None,
    config: TrainerConfig,
) -> TokenAuditReport:
    train_stats = _scan_dataset_token_lengths(dataset=train_dataset, dataset_name="train")
    valid_stats = (
        _scan_dataset_token_lengths(dataset=valid_dataset, dataset_name="validation")
        if valid_dataset is not None and config.stability.strict_token_audit
        else _empty_token_stats(dataset_name="validation")
    )
    effective_sequence_length = (
        config.max_seq_length
        if config.max_seq_length > 0
        else max(train_stats["longest_tokens"], valid_stats["longest_tokens"])
    )
    longest_examples = [
        *train_stats["longest_examples"],
        *valid_stats["longest_examples"],
    ]
    longest_examples.sort(key=lambda sample: sample.token_length, reverse=True)
    return TokenAuditReport(
        train_examples_audited=train_stats["audited_examples"],
        valid_examples_audited=valid_stats["audited_examples"],
        train_longest_tokens=train_stats["longest_tokens"],
        valid_longest_tokens=valid_stats["longest_tokens"],
        overall_longest_tokens=max(train_stats["longest_tokens"], valid_stats["longest_tokens"]),
        effective_sequence_length=effective_sequence_length,
        longest_examples=longest_examples[:5],
    )


def _empty_token_stats(*, dataset_name: str) -> dict[str, Any]:
    return {
        "dataset_name": dataset_name,
        "audited_examples": 0,
        "longest_tokens": 0,
        "longest_examples": [],
    }


def _scan_dataset_token_lengths(*, dataset: Any, dataset_name: str) -> dict[str, Any]:
    longest_examples: list[TokenAuditSample] = []
    longest_tokens = 0
    dataset_length = len(dataset)
    for index in range(dataset_length):
        token_length = _dataset_item_length(dataset=dataset, index=index)
        if token_length > longest_tokens:
            longest_tokens = token_length
        sample = TokenAuditSample(
            dataset_name=dataset_name,
            index=index,
            token_length=token_length,
            location=_describe_dataset_index(dataset=dataset, index=index),
        )
        longest_examples.append(sample)
        longest_examples.sort(key=lambda item: item.token_length, reverse=True)
        if len(longest_examples) > 5:
            longest_examples.pop()
    return {
        "dataset_name": dataset_name,
        "audited_examples": dataset_length,
        "longest_tokens": longest_tokens,
        "longest_examples": longest_examples,
    }


def _dataset_item_length(*, dataset: Any, index: int) -> int:
    item = dataset[index]
    if isinstance(item, tuple) and item:
        tokens = item[0]
        if hasattr(tokens, "__len__"):
            return len(tokens)
    if isinstance(item, list) and item:
        tokens = item[0]
        if hasattr(tokens, "__len__"):
            return len(tokens)
    if hasattr(dataset, "itemlen"):
        return int(dataset.itemlen(index))
    raise TypeError(f"Unable to determine token length for dataset item at index {index}.")


def _describe_dataset_index(*, dataset: Any, index: int) -> str | None:
    describe_index = getattr(dataset, "describe_index", None)
    if callable(describe_index):
        described = describe_index(index)
        if isinstance(described, str):
            return described
    return None


def _extract_source_reference_from_payload(payload: dict[str, Any]) -> str | None:
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        return None
    for key in (
        "url",
        "meeting_url",
        "speech_url",
        "text_url",
        "card_url",
        "page_url",
        "source_url",
        "pdf_url",
    ):
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _chat_record(example: ChatSFTExample) -> dict[str, Any]:
    record: dict[str, Any] = {
        "messages": [_message_record(message) for message in example.messages],
    }
    if example.tools:
        record["tools"] = example.tools
    return record


def _message_record(message: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"role": message.role}
    serialized_content = _serialize_training_message_content(message)
    if serialized_content is not None:
        if isinstance(serialized_content, str):
            payload["content"] = serialized_content
        else:
            payload["content"] = [part.model_dump(exclude_none=True) for part in serialized_content]
    if message.tool_calls:
        payload["tool_calls"] = [tool_call.model_dump(exclude_none=True) for tool_call in message.tool_calls]
    if message.name is not None:
        payload["name"] = message.name
    return payload


def _serialize_training_message_content(message: Any) -> str | list[Any] | None:
    reasoning_content = getattr(message, "reasoning_content", None)
    if reasoning_content is None:
        content = message.content
        if content is None or isinstance(content, str) or isinstance(content, list):
            return content
        return None
    answer = ""
    if isinstance(message.content, str):
        answer = message.content
    return _combine_reasoning_and_answer(reasoning_content, answer)


def _combine_reasoning_and_answer(reasoning_content: str, answer: str) -> str:
    reasoning = reasoning_content.strip()
    if not reasoning:
        return answer
    if not answer:
        return f"<think>\n{reasoning}\n</think>"
    return f"<think>\n{reasoning}\n</think>\n\n{answer}"


def _prepare_training_model(
    *,
    model: Any,
    lora: LoRAHyperparameters,
    base_update: BaseWeightUpdateConfig,
) -> None:
    model.freeze()
    linear_to_lora_layers(
        model,
        lora.num_layers,
        {
            "rank": lora.rank,
            "scale": lora.scale,
            "dropout": lora.dropout,
        },
    )
    _apply_base_weight_updates(model=model, base_update=base_update)


def _apply_base_weight_updates(
    *,
    model: Any,
    base_update: BaseWeightUpdateConfig,
) -> None:
    if base_update.last_layer_count > 0:
        for layer in model.layers[-base_update.last_layer_count :]:
            layer.unfreeze()
    if base_update.include_norms:
        for _, module in model.named_modules():
            module_type = type(module).__name__.lower()
            if "norm" in module_type:
                module.unfreeze()
    if base_update.include_biases:
        for _, module in model.named_modules():
            module.unfreeze(keys="bias")
    if base_update.include_lm_head:
        _unfreeze_named_module(model=model, module_name="language_model.lm_head")
    if base_update.include_embeddings:
        _unfreeze_named_module(model=model, module_name="language_model.model.embed_tokens")


def _unfreeze_named_module(*, model: Any, module_name: str) -> None:
    for name, module in model.named_modules():
        if name == module_name:
            module.unfreeze()
            return


def _count_trainable_parameters(model: Any) -> int:
    flattened = cast(list[tuple[str, Any]], tree_flatten(model.trainable_parameters()))
    return sum(getattr(value, "size", 0) for _, value in flattened)


def _count_saved_trainable_tensor_bytes(model: Any) -> int:
    flattened = cast(list[tuple[str, Any]], tree_flatten(model.trainable_parameters()))
    return sum(
        int(getattr(value, "size", 0)) * int(getattr(getattr(value, "dtype", None), "size", 0) or 0)
        for _, value in flattened
    )


def _estimate_memory(
    *,
    model_profile: ModelProfile,
    raw_config: dict[str, Any],
    trainable_parameter_count: int,
    saved_trainable_tensor_bytes: int,
    batch_size: int,
    sequence_length: int,
    grad_checkpoint: bool,
    lora: LoRAHyperparameters,
    base_update: BaseWeightUpdateConfig,
    optimizer_name: str,
    stability: StabilityConfig,
) -> MemoryEstimate:
    device_info = mx.device_info() if mx.metal.is_available() else {}
    text_config = raw_config.get("text_config", {})
    hidden_size = _coerce_int(text_config.get("hidden_size"), default=0)
    num_hidden_layers = _coerce_int(text_config.get("num_hidden_layers"), default=0)
    tuned_layers = _effective_trainable_layer_depth(
        num_hidden_layers=num_hidden_layers,
        lora=lora,
        base_update=base_update,
    )
    bytes_per_activation = 2
    activation_multiplier = 12 if grad_checkpoint else 20
    if sequence_length <= 0:
        activation_bytes = 0
    else:
        activation_bytes = (
            batch_size
            * sequence_length
            * max(hidden_size, 1)
            * max(tuned_layers, 1)
            * bytes_per_activation
            * activation_multiplier
        )
    optimizer_bytes = _estimated_optimizer_bytes(
        optimizer_name=optimizer_name,
        trainable_parameter_count=trainable_parameter_count,
    )
    peak_bytes = int((model_profile.weight_bytes or 0) + activation_bytes + optimizer_bytes)
    recommended_working_set_bytes = _coerce_optional_int(
        device_info.get("max_recommended_working_set_size")
    )
    applied_memory_budget_bytes = _resolve_memory_budget_bytes(
        device_info=device_info,
        stability=stability,
    )
    effective_training_budget_bytes = applied_memory_budget_bytes
    if recommended_working_set_bytes is not None:
        if effective_training_budget_bytes is None:
            effective_training_budget_bytes = recommended_working_set_bytes
        else:
            effective_training_budget_bytes = min(
                effective_training_budget_bytes,
                recommended_working_set_bytes,
            )
    reserve_bytes = max(stability.training_memory_reserve_bytes, 0)
    if effective_training_budget_bytes is not None:
        effective_training_budget_bytes = max(
            effective_training_budget_bytes - reserve_bytes,
            0,
        )
    fits_memory_budget = None
    if sequence_length > 0 and effective_training_budget_bytes is not None:
        fits_memory_budget = peak_bytes <= effective_training_budget_bytes
    fits_recommended = None
    if sequence_length > 0 and recommended_working_set_bytes is not None:
        fits_recommended = peak_bytes <= recommended_working_set_bytes
    return MemoryEstimate(
        device_name=_coerce_optional_str(device_info.get("device_name")),
        device_memory_bytes=_coerce_optional_int(device_info.get("memory_size")),
        recommended_working_set_bytes=recommended_working_set_bytes,
        applied_memory_budget_bytes=applied_memory_budget_bytes,
        effective_training_budget_bytes=effective_training_budget_bytes,
        memory_budget_mode=stability.metal_memory_budget_mode,
        model_weight_bytes=model_profile.weight_bytes,
        trainable_parameter_count=trainable_parameter_count,
        saved_trainable_tensor_bytes=saved_trainable_tensor_bytes,
        estimated_activation_bytes=int(activation_bytes),
        estimated_optimizer_bytes=int(optimizer_bytes),
        estimated_peak_working_set_bytes=peak_bytes,
        fits_memory_budget=fits_memory_budget,
        fits_recommended_working_set=fits_recommended,
    )


def _quantized_training_error(model_profile: ModelProfile) -> str | None:
    if not model_profile.quantization.is_quantized:
        return None
    quantization_bits = model_profile.quantization.bits
    quantization_label = (
        f"{quantization_bits}-bit quantized"
        if quantization_bits is not None
        else "quantized"
    )
    return (
        "Training requires the original-precision MLX model weights, but "
        f"{model_profile.model_dir} contains {quantization_label} weights. "
        "Point --model-path at the unquantized base model instead of artifacts/q6. "
        "If the original model is no longer present locally, re-download it before starting CPT or fine-tuning."
    )


def _base_update_warnings(
    *,
    config: TrainerConfig,
    trainable_parameter_count: int,
) -> list[str]:
    warnings: list[str] = []
    base_update = config.base_update
    if base_update.last_layer_count > 0:
        warnings.append(
            f"Hybrid training is enabled: LoRA adapters plus full base-weight updates on the last {base_update.last_layer_count} decoder layers."
        )
    if base_update.include_norms:
        warnings.append("Normalization weights remain trainable to improve adaptation stability.")
    if base_update.include_lm_head or base_update.include_embeddings:
        warnings.append(
            "LM head or embedding updates can increase forgetting and memory use substantially."
        )
    if trainable_parameter_count == 0:
        warnings.append("No trainable parameters were selected. Increase LoRA depth or base-update scope.")
    return warnings


def _memory_safety_warnings(
    *,
    memory: MemoryEstimate,
    config: TrainerConfig,
    token_audit: TokenAuditReport,
) -> list[str]:
    warnings: list[str] = []
    if config.max_seq_length <= 0:
        warnings.append(
            "Sequence cap is disabled. Training will use full example lengths without truncation, and the trainer audited full token lengths before starting."
        )
    warnings.append(
        f"Exact token audit found longest train example = {token_audit.train_longest_tokens} tokens"
        + (
            f", longest validation example = {token_audit.valid_longest_tokens} tokens."
            if token_audit.valid_examples_audited
            else "."
        )
    )
    if config.stability.training_memory_reserve_bytes > 0:
        warnings.append(
            f"Training reserves {config.stability.training_memory_reserve_bytes} bytes of headroom below the effective Metal limit to reduce kernel-level OOM risk."
        )
    if config.checkpoint_sample.enabled:
        sample_mode = (
            "during training"
            if config.checkpoint_sample.mode == "inline"
            else "after training completes"
        )
        warnings.append(
            "Each saved checkpoint will run a fixed sample prompt "
            f"capped at {config.checkpoint_sample.max_tokens} generated tokens {sample_mode} "
            "and write the output under the training output directory."
        )
        if config.checkpoint_sample.max_kv_size is not None:
            warnings.append(
                "Checkpoint sampling uses a bounded KV cache "
                f"({config.checkpoint_sample.max_kv_size} tokens)"
                + (
                    f" with {config.checkpoint_sample.kv_bits}-bit KV quantization."
                    if config.checkpoint_sample.kv_bits is not None
                    else "."
                )
            )
    if not config.grad_checkpoint:
        warnings.append(
            "Gradient checkpointing is disabled. Enable --grad-checkpoint to reduce activation memory during training."
        )
    if config.optimizer != "adafactor" and _has_expensive_base_updates(config.base_update):
        warnings.append(
            "Base-weight updates are enabled without Adafactor. Memory use and NaN risk are usually lower with --optimizer adafactor."
        )
    if config.stability.metal_cache_limit_bytes == 0:
        warnings.append(
            "Metal cache is disabled for training to reduce unified-memory pressure. This is slower, but it lowers the chance of driver-level memory spikes."
        )
    if config.stability.metal_memory_budget_mode == "device":
        warnings.append(
            "Metal memory budget uses full unified memory instead of the lower recommended working set. This gives macOS compressed memory and swap a chance to absorb pressure, at the cost of speed."
        )
        warnings.append(
            "Metal wired allocations are still capped at the device's recommended working-set ceiling, because MLX rejects larger wired limits on Apple GPUs."
        )
    effective_training_budget_bytes = memory.effective_training_budget_bytes
    if effective_training_budget_bytes is None or effective_training_budget_bytes <= 0:
        return warnings
    usage_ratio = memory.estimated_peak_working_set_bytes / effective_training_budget_bytes
    if usage_ratio >= 0.8:
        warnings.append(
            f"Estimated peak working set is {usage_ratio:.0%} of the effective training memory budget. "
            "If training is unstable, lower batch size, LoRA depth/rank, or base-update scope."
        )
    return warnings


def _has_expensive_base_updates(base_update: BaseWeightUpdateConfig) -> bool:
    return (
        base_update.last_layer_count > 0
        or base_update.include_lm_head
        or base_update.include_embeddings
    )


def _checkpoint_samples_output_path(
    *,
    output_dir: Path,
    checkpoint_sample: CheckpointSampleConfig,
) -> Path | None:
    if not checkpoint_sample.enabled:
        return None
    file_name = (
        "checkpoint_samples.jsonl"
        if checkpoint_sample.mode == "inline"
        else "saved_checkpoint_samples.jsonl"
    )
    return output_dir / file_name


def _inline_checkpoint_sample_error(
    *,
    raw_config: dict[str, Any],
    tokenizer: Any,
    memory: MemoryEstimate,
    checkpoint_sample: CheckpointSampleConfig,
) -> str | None:
    if not checkpoint_sample.enabled or checkpoint_sample.mode != "inline":
        return None
    effective_budget = memory.effective_training_budget_bytes
    if effective_budget is None or effective_budget <= 0:
        return None
    prompt_tokens = _build_checkpoint_sample_prompt_tokens(
        tokenizer=tokenizer,
        prompt=checkpoint_sample.prompt,
    )
    kv_cache_bytes = _estimate_checkpoint_sample_kv_cache_bytes(
        raw_config=raw_config,
        prompt_tokens=len(prompt_tokens),
        checkpoint_sample=checkpoint_sample,
    )
    inline_peak_bytes = memory.estimated_peak_working_set_bytes + kv_cache_bytes
    if inline_peak_bytes <= effective_budget:
        return None
    return (
        "Inline checkpoint sampling is estimated to exceed the effective Metal memory budget. "
        "Use `--checkpoint-sample-mode after_training` to save checkpoints first and sample them after training releases the optimizer state, "
        "or lower the checkpoint KV cache settings."
    )


def _estimate_checkpoint_sample_kv_cache_bytes(
    *,
    raw_config: dict[str, Any],
    prompt_tokens: int,
    checkpoint_sample: CheckpointSampleConfig,
) -> int:
    text_config = raw_config.get("text_config", {})
    num_hidden_layers = _coerce_int(text_config.get("num_hidden_layers"), default=0)
    num_key_value_heads = _coerce_int(text_config.get("num_key_value_heads"), default=0)
    head_dim = _coerce_int(text_config.get("head_dim"), default=0)
    total_tokens = prompt_tokens + max(checkpoint_sample.max_tokens, 0)
    if checkpoint_sample.max_kv_size is not None:
        total_tokens = min(total_tokens, max(checkpoint_sample.max_kv_size, 0))
    if total_tokens <= 0:
        return 0
    if checkpoint_sample.kv_bits is None:
        bytes_per_scalar = 2.0
    else:
        bytes_per_scalar = max(checkpoint_sample.kv_bits, 1) / 8.0
    per_token_scalars = (
        max(num_hidden_layers, 1)
        * max(num_key_value_heads, 1)
        * max(head_dim, 1)
        * 2
    )
    return int(per_token_scalars * total_tokens * bytes_per_scalar)


def _effective_trainable_layer_depth(
    *,
    num_hidden_layers: int,
    lora: LoRAHyperparameters,
    base_update: BaseWeightUpdateConfig,
) -> int:
    if num_hidden_layers <= 0:
        return max(lora.num_layers, base_update.last_layer_count, 1)
    if base_update.include_norms or base_update.include_biases:
        return num_hidden_layers
    return min(
        num_hidden_layers,
        max(lora.num_layers, base_update.last_layer_count, 1),
    )


def _resolve_memory_budget_bytes(
    *,
    device_info: dict[str, Any],
    stability: StabilityConfig,
) -> int | None:
    if stability.metal_memory_limit_bytes is not None:
        return max(stability.metal_memory_limit_bytes, 0)
    if stability.metal_memory_budget_mode == "none":
        return None
    if stability.metal_memory_budget_mode == "device":
        return _coerce_optional_int(device_info.get("memory_size"))
    return _coerce_optional_int(device_info.get("max_recommended_working_set_size"))


def _optional_model_config_override(
    model_path: str,
    *,
    context_window: int | None,
    yarn_factor: float | None,
) -> dict[str, Any] | None:
    if context_window is None:
        return None
    config_path = Path(model_path).expanduser().resolve() / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    updated = apply_context_window_to_config(
        config,
        target_context_window=context_window,
        yarn_factor=yarn_factor,
    )
    return {"text_config": updated["text_config"]}


def _configured_context_window(raw_config: dict[str, Any]) -> int | None:
    return _coerce_optional_int(raw_config.get("text_config", {}).get("max_position_embeddings"))


def _ensure_dataset_fits_sequence_limit(
    *,
    dataset: Any,
    max_seq_length: int,
    dataset_name: str,
) -> None:
    if max_seq_length <= 0:
        return
    overlong_indices: list[int] = []
    longest = 0
    for index in range(len(dataset)):
        sequence_length = _dataset_item_length(dataset=dataset, index=index)
        if sequence_length <= max_seq_length:
            continue
        overlong_indices.append(index)
        longest = max(longest, sequence_length)
    if not overlong_indices:
        return
    raise ValueError(
        f"{dataset_name}_dataset_sequence_too_long: found {len(overlong_indices)} examples longer than "
        f"max_seq_length={max_seq_length}; longest={longest}. Refusing to truncate tokens during training."
    )


def _count_nonempty_lines(path: Path) -> int:
    count = 0
    for _ in _iter_jsonl_lines(path):
        count += 1
    return count


def _iter_jsonl_lines(path: Path) -> Iterator[str]:
    snapshot_size = path.stat().st_size
    with path.open("rb") as handle:
        while True:
            offset = handle.tell()
            if offset >= snapshot_size:
                break
            remaining = snapshot_size - offset
            line = handle.readline(remaining)
            if not line:
                break
            if not line.endswith(b"\n"):
                break
            if not line.strip():
                continue
            yield line.decode("utf-8")


def _iterate_batches(
    dataset: Any,
    batch_size: int,
    max_seq_length: int,
    loop: bool = False,
    seed: int | None = None,
    comm_group: Any = None,
) -> Any:
    idx = sorted(range(len(dataset)), key=lambda item_index: _dataset_item_length(dataset=dataset, index=item_index))
    if len(dataset) < batch_size:
        raise ValueError(
            f"Dataset must have at least batch_size={batch_size}"
            f" examples but only has {len(dataset)}."
        )
    if comm_group is not None:
        offset = comm_group.rank()
        step = comm_group.size()
    else:
        offset = 0
        step = 1
    if batch_size % step != 0:
        raise ValueError("The batch size must be divisible by the number of workers")
    batch_idx = [
        idx[i + offset : i + offset + batch_size : step]
        for i in range(0, len(idx) - batch_size + 1, batch_size)
    ]
    if seed:
        import numpy as np

        np.random.seed(seed)
    while True:
        import numpy as np

        indices = np.random.permutation(len(batch_idx))
        for i in indices:
            _set_current_batch_trace(dataset=dataset, indices=batch_idx[i])
            raw_batch = [dataset[j] for j in batch_idx[i]]
            if len(raw_batch[0]) == 2:
                token_batch, offsets_tuple = zip(*raw_batch)
                batch = list(token_batch)
                offsets: list[int] = list(offsets_tuple)
            else:
                batch = list(raw_batch)
                offsets = [0] * len(batch)
            lengths = [len(tokens) for tokens in batch]
            if max_seq_length > 0 and max(lengths) > max_seq_length:
                raise ValueError("batch_contains_overlong_sequence")
            pad_to = 32
            max_length_in_batch = 1 + pad_to * ((max(lengths) + pad_to - 1) // pad_to)
            if max_seq_length > 0:
                max_length_in_batch = min(max_length_in_batch, max_seq_length)
            import numpy as np

            batch_arr = np.zeros((batch_size // step, max_length_in_batch), np.int32)
            for j in range(batch_size // step):
                batch_arr[j, : lengths[j]] = batch[j][: lengths[j]]
            yield mx.array(batch_arr), mx.array(list(zip(offsets, lengths)))
        if not loop:
            break


def _set_current_batch_trace(*, dataset: Any, indices: list[int]) -> None:
    descriptions = [
        description
        for index in indices
        if (description := _describe_dataset_index(dataset=dataset, index=index)) is not None
    ]
    try:
        setattr(dataset, "_last_batch_trace", descriptions)
    except (AttributeError, TypeError):
        return


def _last_batch_trace(dataset: Any) -> list[str]:
    trace = getattr(dataset, "_last_batch_trace", None)
    if isinstance(trace, list):
        return [item for item in trace if isinstance(item, str)]
    return []


def _has_base_trainable_parameters(model: Any) -> bool:
    flattened = cast(list[tuple[str, Any]], tree_flatten(model.trainable_parameters()))
    return any(not _is_lora_parameter_name(name) for name, _ in flattened)


def _capture_base_parameter_reference(model: Any) -> dict[str, Any]:
    flattened = cast(list[tuple[str, Any]], tree_flatten(model.trainable_parameters()))
    return {
        name: value
        for name, value in flattened
        if not _is_lora_parameter_name(name)
    }


def _build_training_loss(
    *,
    model: Any,
    l2_sp_weight: float,
) -> Any:
    if l2_sp_weight <= 0:
        return mlx_default_loss
    base_reference = _capture_base_parameter_reference(model)
    if not base_reference:
        return mlx_default_loss

    def loss(model: Any, batch: Any, lengths: Any) -> tuple[Any, Any]:
        ce, ntoks = mlx_default_loss(model, batch, lengths)
        flattened = cast(list[tuple[str, Any]], tree_flatten(model.trainable_parameters()))
        penalties = [
            (value.astype(mx.float32) - base_reference[name].astype(mx.float32)).square().mean()
            for name, value in flattened
            if name in base_reference
        ]
        if not penalties:
            return ce, ntoks
        penalty = penalties[0]
        for term in penalties[1:]:
            penalty = penalty + term
        penalty = penalty / len(penalties)
        return ce + (l2_sp_weight * penalty), ntoks

    return loss


def _run_training_loop(
    *,
    model: Any,
    tokenizer: Any,
    optimizer: Any,
    train_dataset: Any,
    val_dataset: Any | None,
    args: TrainingArgs,
    loss: Any,
    training_callback: TrainingCallback | None,
    stability: StabilityConfig,
    has_base_updates: bool,
    base_learning_rate_scale: float,
    checkpoint_sample: CheckpointSampleConfig,
    checkpoint_samples_path: Path | None,
) -> None:
    _configure_metal_memory_limits(stability=stability)
    print(f"Starting training..., iters: {args.iters}")
    world = mx.distributed.init()
    world_size = world.size()
    rank = world.rank()
    if world_size > 1:
        print(f"Node {rank} of {world_size}")

    if args.grad_checkpoint:
        _enable_grad_checkpoint_once(model.layers[0])

    loss_value_and_grad = nn.value_and_grad(model, loss)
    grad_accum_steps = args.grad_accumulation_steps
    grad_clip_norm = stability.grad_clip_norm
    cache_clear_interval = max(stability.metal_cache_clear_interval, 0)
    if grad_accum_steps < 1:
        raise ValueError("grad_accumulation_steps must be at least 1")

    state = [model.state, optimizer.state, mx.random.state]

    def eager_step(
        batch: Any,
        prev_grad: Any,
        do_update: bool,
        grad_divisor: int,
    ) -> tuple[Any, Any, Any, Any, Any]:
        (lvalue, toks), grad = loss_value_and_grad(model, *batch)
        if prev_grad is not None:
            grad = tree_map(lambda x, y: x + y, grad, prev_grad)
        grad_isfinite = _tree_all_finite(grad)
        grad_norm = None
        if do_update:
            grad = average_gradients(grad)
            if grad_divisor > 1:
                grad = tree_map(lambda x: x / grad_divisor, grad)
            if grad_clip_norm > 0:
                grad, grad_norm = optim.clip_grad_norm(grad, grad_clip_norm)
            if has_base_updates and base_learning_rate_scale != 1.0:
                grad = _scale_base_parameter_gradients(
                    gradients=grad,
                    scale=base_learning_rate_scale,
                )
            optimizer.update(model, grad)
            grad = None
        return lvalue, toks, grad, grad_norm, grad_isfinite

    if grad_clip_norm > 0:
        step = eager_step
        use_compiled_step = False
    else:
        @partial(mx.compile, inputs=state, outputs=state)
        def compiled_step(
            batch: Any,
            prev_grad: Any,
            do_update: bool,
            grad_divisor: int,
        ) -> tuple[Any, Any, Any, Any, Any]:
            return eager_step(batch, prev_grad, do_update, grad_divisor)

        step = compiled_step
        use_compiled_step = True

    model.train()
    losses = 0
    n_tokens = 0
    steps = 0
    trained_tokens = 0
    train_time = 0.0
    grad_accum = None
    accumulated_steps = 0

    for it, batch in zip(
        range(1, args.iters + 1),
        _iterate_batches(
            dataset=train_dataset,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length,
            loop=True,
            comm_group=world,
        ),
    ):
        if val_dataset and (it == 1 or it % args.steps_per_eval == 0 or it == args.iters):
            _maybe_clear_metal_cache()
            tic = time.perf_counter()
            val_loss = mlx_evaluate(
                model=model,
                dataset=val_dataset,
                loss=loss,
                batch_size=args.batch_size,
                num_batches=args.val_batches,
                max_seq_length=args.max_seq_length,
                iterate_batches=_iterate_batches,
            )
            model.train()
            val_time = time.perf_counter() - tic
            if rank == 0:
                print(
                    f"Iter {it}: Val loss {val_loss:.3f}, Val took {val_time:.3f}s",
                    flush=True,
                )
            if training_callback is not None:
                training_callback.on_val_loss_report(
                    {
                        "iteration": it - 1,
                        "val_loss": val_loss,
                        "val_time": val_time,
                    }
                )
            _maybe_clear_metal_cache()

        tic = time.perf_counter()
        accumulated_steps += 1
        should_update = (it % grad_accum_steps == 0) or (it == args.iters)
        lvalue, toks, grad_accum, grad_norm, grad_isfinite = step(
            batch,
            grad_accum,
            should_update,
            accumulated_steps,
        )
        losses += lvalue
        n_tokens += toks
        steps += 1
        if use_compiled_step:
            mx.eval(state, losses, n_tokens, grad_accum, grad_norm, grad_isfinite)
        else:
            _eval_trees(state, losses, n_tokens, grad_accum, grad_norm, grad_isfinite)
        if not _is_finite_scalar(lvalue):
            raise ValueError("non_finite_loss")
        if not bool(grad_isfinite.item()):
            raise ValueError("non_finite_gradients")

        grad_norm_value: float | None = None
        if should_update:
            if grad_clip_norm > 0 and grad_norm is not None:
                grad_norm_value = float(grad_norm.item())
                if not _is_finite_scalar(grad_norm):
                    raise ValueError("non_finite_grad_norm")
            grad_accum = None
            accumulated_steps = 0

        train_time += time.perf_counter() - tic

        if it % args.steps_per_report == 0 or it == args.iters:
            train_loss = mx.distributed.all_sum(losses, stream=cast(Any, mx.cpu)).item()
            train_loss /= steps * world_size
            n_tokens_total = mx.distributed.all_sum(n_tokens, stream=cast(Any, mx.cpu)).item()
            learning_rate = optimizer.learning_rate.item()
            it_sec = steps / max(train_time, 1e-6)
            tokens_sec = float(n_tokens_total) / max(train_time, 1e-6)
            trained_tokens += int(n_tokens_total)
            peak_mem = mx.get_peak_memory() / 1e9
            current_sources = _last_batch_trace(train_dataset)
            current_source_display = " | ".join(current_sources[:2]) if current_sources else None
            if rank == 0:
                print(
                    f"Iter {it}: Train loss {train_loss:.3f}, "
                    f"Learning Rate {learning_rate:.3e}, "
                    f"It/sec {it_sec:.3f}, "
                    f"Tokens/sec {tokens_sec:.3f}, "
                    f"Trained Tokens {trained_tokens}, "
                    f"Peak mem {peak_mem:.3f} GB"
                    + (
                        f", Source {current_source_display}"
                        if current_source_display is not None
                        else ""
                    ),
                    flush=True,
                )
            if training_callback is not None:
                train_info: dict[str, Any] = {
                    "iteration": it,
                    "train_loss": train_loss,
                    "learning_rate": learning_rate,
                    "iterations_per_second": it_sec,
                    "tokens_per_second": tokens_sec,
                    "trained_tokens": trained_tokens,
                    "peak_memory": peak_mem,
                }
                if current_source_display is not None:
                    train_info["current_source"] = current_source_display
                if grad_norm_value is not None:
                    train_info["grad_norm"] = grad_norm_value
                training_callback.on_train_loss_report(train_info)

            losses = 0
            n_tokens = 0
            steps = 0
            train_time = 0.0

        if it % args.steps_per_save == 0 and rank == 0:
            adapter_weights = dict(tree_flatten(model.trainable_parameters()))
            mx.save_safetensors(str(args.adapter_file), adapter_weights)
            checkpoint = Path(args.adapter_file).parent / f"{it:07d}_adapters.safetensors"
            mx.save_safetensors(str(checkpoint), adapter_weights)
            _resolve_checkpoint_adapter_path(
                output_dir=Path(args.adapter_file).parent,
                checkpoint_path=checkpoint,
            )
            print(
                f"Iter {it}: Saved adapter weights to {args.adapter_file} and {checkpoint}.",
                flush=True,
            )
            if checkpoint_sample.enabled and checkpoint_samples_path is not None:
                _record_checkpoint_sample(
                    model=model,
                    tokenizer=tokenizer,
                    checkpoint_file=checkpoint,
                    iteration=it,
                    config=checkpoint_sample,
                    records_path=checkpoint_samples_path,
                )
            _maybe_clear_metal_cache()

        if cache_clear_interval > 0 and it % cache_clear_interval == 0:
            _maybe_clear_metal_cache()

    if rank == 0:
        adapter_weights = dict(tree_flatten(model.trainable_parameters()))
        mx.save_safetensors(str(args.adapter_file), adapter_weights)
        _ensure_output_dir_adapter_config(Path(args.adapter_file).parent)
        print(f"Saved final weights to {args.adapter_file}.", flush=True)
        if checkpoint_sample.enabled and checkpoint_samples_path is not None:
            _record_checkpoint_sample(
                model=model,
                tokenizer=tokenizer,
                checkpoint_file=Path(args.adapter_file),
                iteration=args.iters,
                config=checkpoint_sample,
                records_path=checkpoint_samples_path,
            )


def _text_preference_get_logps(model: Any, batch: dict[str, Any]) -> tuple[Any, Any]:
    input_ids = batch["input_ids"]
    attention_mask = batch["attention_mask"]
    shifted_input_ids = input_ids[:, :-1]
    shifted_attention_mask = attention_mask[:, :-1]
    targets = input_ids[:, 1:]
    logits = model(shifted_input_ids).astype(mx.float32)
    lengths = mx.sum(shifted_attention_mask, axis=1)
    lengths = mx.minimum(lengths, shifted_input_ids.shape[1])
    steps = mx.arange(shifted_input_ids.shape[1])[None, :]
    mask = steps < lengths[:, None]
    log_probs = -nn.losses.cross_entropy(logits, targets, reduction="none")
    mask_f = mask.astype(log_probs.dtype)
    token_counts = mx.maximum(mask_f.sum(-1), 1)
    logp_seq_avg = (log_probs * mask_f).sum(-1) / token_counts
    logits_mean = logits.sum() / mx.maximum(mask_f.sum(), 1)
    return logp_seq_avg, logits_mean


def _evaluate_preference_dataset(
    *,
    model: Any,
    dataset: Any,
    batch_size: int,
    num_batches: int,
    max_seq_length: int,
    beta: float,
    get_logps_fn: Any,
    iterate_batches_fn: Any,
) -> float:
    model.eval()
    total_loss = mx.array(0.0)
    total_tokens = mx.array(0)
    index_iterator = iter(range(num_batches)) if num_batches != -1 else iter(int, 1)
    for _, batch in zip(
        index_iterator,
        iterate_batches_fn(
            dataset=dataset,
            batch_size=batch_size,
            max_seq_length=max_seq_length,
            train=False,
        ),
    ):
        chosen_batch = batch["chosen"]
        rejected_batch = batch["rejected"]
        chosen_logps, chosen_logits_mean = get_logps_fn(model, chosen_batch)
        rejected_logps, rejected_logits_mean = get_logps_fn(model, rejected_batch)
        losses, _, num_tokens, _ = vlm_orpo_loss(
            chosen_logps,
            chosen_logits_mean,
            rejected_logps,
            rejected_logits_mean,
            chosen_batch["attention_mask"],
            rejected_batch["attention_mask"],
            beta=beta,
        )
        total_loss += losses * num_tokens
        total_tokens += num_tokens
        mx.eval(total_loss, total_tokens)
    total_loss = mx.distributed.all_sum(total_loss, stream=cast(Any, mx.cpu))
    total_tokens = mx.distributed.all_sum(total_tokens, stream=cast(Any, mx.cpu))
    _maybe_clear_metal_cache()
    return (total_loss / mx.maximum(total_tokens, 1)).item()


def _run_preference_training_loop(
    *,
    model: Any,
    tokenizer: Any,
    optimizer: Any,
    train_dataset: Any,
    val_dataset: Any | None,
    args: ORPOTrainingArgs,
    training_callback: TrainingCallback | None,
    stability: StabilityConfig,
    has_base_updates: bool,
    base_learning_rate_scale: float,
    checkpoint_sample: CheckpointSampleConfig,
    checkpoint_samples_path: Path | None,
) -> None:
    _configure_metal_memory_limits(stability=stability)
    print(f"Starting ORPO training..., iters: {args.iters}")
    world = mx.distributed.init()
    world_size = world.size()
    rank = world.rank()
    if world_size > 1:
        print(f"Node {rank} of {world_size}")

    if args.grad_checkpoint:
        _enable_grad_checkpoint_once(model.layers[0])

    grad_accum_steps = max(args.gradient_accumulation_steps, 1)
    grad_clip_norm = stability.grad_clip_norm
    cache_clear_interval = max(stability.metal_cache_clear_interval, 0)
    state = [model.state, optimizer.state, mx.random.state]

    def preference_loss(model_obj: Any, batch: dict[str, Any]) -> tuple[Any, Any]:
        chosen_batch = batch["chosen"]
        rejected_batch = batch["rejected"]
        chosen_logps, chosen_logits_mean = _text_preference_get_logps(model_obj, chosen_batch)
        rejected_logps, rejected_logits_mean = _text_preference_get_logps(model_obj, rejected_batch)
        losses, _, num_tokens, _ = vlm_orpo_loss(
            chosen_logps,
            chosen_logits_mean,
            rejected_logps,
            rejected_logits_mean,
            chosen_batch["attention_mask"],
            rejected_batch["attention_mask"],
            beta=args.beta,
        )
        return losses, num_tokens

    loss_value_and_grad = nn.value_and_grad(model, preference_loss)

    def step(
        batch: dict[str, Any],
        prev_grad: Any,
        do_update: bool,
        grad_divisor: int,
    ) -> tuple[Any, Any, Any, Any, Any]:
        (lvalue, toks), grad = loss_value_and_grad(model, batch)
        if prev_grad is not None:
            grad = tree_map(lambda x, y: x + y, grad, prev_grad)
        grad_isfinite = _tree_all_finite(grad)
        grad_norm = None
        if do_update:
            grad = average_gradients(grad)
            if grad_divisor > 1:
                grad = tree_map(lambda x: x / grad_divisor, grad)
            if grad_clip_norm > 0:
                grad, grad_norm = optim.clip_grad_norm(grad, grad_clip_norm)
            if has_base_updates and base_learning_rate_scale != 1.0:
                grad = _scale_base_parameter_gradients(
                    gradients=grad,
                    scale=base_learning_rate_scale,
                )
            optimizer.update(model, grad)
            grad = None
        return lvalue, toks, grad, grad_norm, grad_isfinite

    model.train()
    losses = 0
    n_tokens = 0
    steps = 0
    trained_tokens = 0
    train_time = 0.0
    grad_accum = None
    accumulated_steps = 0

    for it, batch in zip(
        range(1, args.iters + 1),
        vlm_orpo_iterate_batches(
            dataset=train_dataset,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length,
            train=True,
        ),
    ):
        if val_dataset is not None and (it == 1 or it % args.steps_per_eval == 0 or it == args.iters):
            _maybe_clear_metal_cache()
            tic_val = time.perf_counter()
            val_loss = _evaluate_preference_dataset(
                model=model,
                dataset=val_dataset,
                batch_size=args.batch_size,
                num_batches=args.val_batches,
                max_seq_length=args.max_seq_length,
                beta=args.beta,
                get_logps_fn=_text_preference_get_logps,
                iterate_batches_fn=vlm_orpo_iterate_batches,
            )
            model.train()
            val_time = time.perf_counter() - tic_val
            if rank == 0:
                print(f"Iter {it}: Val loss {val_loss:.3f}, Val took {val_time:.3f}s", flush=True)
            if training_callback is not None:
                training_callback.on_val_loss_report(
                    {
                        "iteration": it - 1,
                        "val_loss": val_loss,
                        "val_time": val_time,
                    }
                )

        tic = time.perf_counter()
        accumulated_steps += 1
        should_update = (it % grad_accum_steps == 0) or (it == args.iters)
        lvalue, toks, grad_accum, grad_norm, grad_isfinite = step(
            batch,
            grad_accum,
            should_update,
            accumulated_steps,
        )
        losses += lvalue
        n_tokens += toks
        steps += 1
        _eval_trees(state, losses, n_tokens, grad_accum, grad_norm, grad_isfinite)
        if not _is_finite_scalar(lvalue):
            raise ValueError("non_finite_loss")
        if not bool(grad_isfinite.item()):
            raise ValueError("non_finite_gradients")

        grad_norm_value: float | None = None
        if should_update:
            if grad_clip_norm > 0 and grad_norm is not None:
                grad_norm_value = float(grad_norm.item())
                if not _is_finite_scalar(grad_norm):
                    raise ValueError("non_finite_grad_norm")
            grad_accum = None
            accumulated_steps = 0

        train_time += time.perf_counter() - tic

        if it % args.steps_per_report == 0 or it == args.iters:
            train_loss = mx.distributed.all_sum(losses, stream=cast(Any, mx.cpu)).item()
            train_loss /= steps * world_size
            n_tokens_total = mx.distributed.all_sum(n_tokens, stream=cast(Any, mx.cpu)).item()
            learning_rate = (
                optimizer.learning_rate.item()
                if hasattr(optimizer.learning_rate, "item")
                else args.learning_rate
            )
            it_sec = steps / max(train_time, 1e-6)
            tokens_sec = float(n_tokens_total) / max(train_time, 1e-6)
            trained_tokens += int(n_tokens_total)
            peak_mem = mx.get_peak_memory() / 1e9
            if rank == 0:
                print(
                    f"Iter {it}: Train loss {train_loss:.3f}, "
                    f"Learning Rate {learning_rate:.3e}, "
                    f"It/sec {it_sec:.3f}, "
                    f"Tokens/sec {tokens_sec:.3f}, "
                    f"Trained Tokens {trained_tokens}, "
                    f"Peak mem {peak_mem:.3f} GB",
                    flush=True,
                )
            if training_callback is not None:
                train_info: dict[str, Any] = {
                    "iteration": it,
                    "train_loss": train_loss,
                    "learning_rate": learning_rate,
                    "iterations_per_second": it_sec,
                    "tokens_per_second": tokens_sec,
                    "trained_tokens": trained_tokens,
                    "peak_memory": peak_mem,
                }
                if grad_norm_value is not None:
                    train_info["grad_norm"] = grad_norm_value
                training_callback.on_train_loss_report(train_info)
            losses = 0
            n_tokens = 0
            steps = 0
            train_time = 0.0

        if it % args.steps_per_save == 0 and rank == 0:
            adapter_weights = dict(tree_flatten(model.trainable_parameters()))
            mx.save_safetensors(str(args.adapter_file), adapter_weights)
            checkpoint = Path(args.adapter_file).parent / f"{it:07d}_adapters.safetensors"
            mx.save_safetensors(str(checkpoint), adapter_weights)
            _resolve_checkpoint_adapter_path(
                output_dir=Path(args.adapter_file).parent,
                checkpoint_path=checkpoint,
            )
            print(
                f"Iter {it}: Saved adapter weights to {args.adapter_file} and {checkpoint}.",
                flush=True,
            )
            if checkpoint_sample.enabled and checkpoint_samples_path is not None:
                _record_checkpoint_sample(
                    model=model,
                    tokenizer=tokenizer,
                    checkpoint_file=checkpoint,
                    iteration=it,
                    config=checkpoint_sample,
                    records_path=checkpoint_samples_path,
                )
            _maybe_clear_metal_cache()

        if cache_clear_interval > 0 and it % cache_clear_interval == 0:
            _maybe_clear_metal_cache()

    if rank == 0:
        adapter_weights = dict(tree_flatten(model.trainable_parameters()))
        mx.save_safetensors(str(args.adapter_file), adapter_weights)
        _ensure_output_dir_adapter_config(Path(args.adapter_file).parent)
        print(f"Saved final weights to {args.adapter_file}.", flush=True)
        if checkpoint_sample.enabled and checkpoint_samples_path is not None:
            _record_checkpoint_sample(
                model=model,
                tokenizer=tokenizer,
                checkpoint_file=Path(args.adapter_file),
                iteration=args.iters,
                config=checkpoint_sample,
                records_path=checkpoint_samples_path,
            )


def _run_multimodal_training_loop(
    *,
    model: Any,
    processor: Any,
    optimizer: Any,
    train_dataset: Any,
    val_dataset: Any | None,
    args: VlmTrainingArgs,
    training_callback: TrainingCallback | None,
    stability: StabilityConfig,
) -> None:
    _configure_metal_memory_limits(stability=stability)
    print(f"Starting multimodal training..., iters: {args.iters}")
    world = mx.distributed.init()
    world_size = world.size()
    rank = world.rank()
    if world_size > 1:
        print(f"Node {rank} of {world_size}")

    if args.grad_checkpoint:
        for module in model.children().values():
            layers = getattr(module, "layers", None)
            if isinstance(layers, Sequence) and layers:
                _enable_grad_checkpoint_once(layers[0])
                break

    loss_value_and_grad = nn.value_and_grad(
        model,
        partial(vlm_vision_language_loss_fn, train_on_completions=False),
    )
    state = [model.state, optimizer.state, mx.random.state]
    grad_accum_steps = max(args.gradient_accumulation_steps, 1)
    cache_clear_interval = max(stability.metal_cache_clear_interval, 0)
    model.train()
    losses = 0
    n_tokens = 0
    steps = 0
    trained_tokens = 0
    train_time = 0.0
    grad_accum = None

    def step(batch: Any, prev_grad: Any, do_update: bool) -> tuple[Any, Any, Any]:
        lengths = batch["attention_mask"].sum(axis=1)
        toks = lengths.sum()
        lvalue, grad = loss_value_and_grad(model, batch)
        if args.grad_clip is not None:
            grad = tree_map(lambda g: mx.clip(g, -args.grad_clip, args.grad_clip), grad)
        if prev_grad is not None:
            grad = tree_map(lambda x, y: x + y, grad, prev_grad)
        if do_update:
            grad = average_gradients(grad)
            if grad_accum_steps > 1:
                grad = tree_map(lambda x: x / grad_accum_steps, grad)
            optimizer.update(model, grad)
            grad = None
        return lvalue, toks, grad

    for it, batch in zip(
        range(1, args.iters + 1),
        vlm_iterate_batches(
            dataset=train_dataset,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length,
            train=True,
        ),
    ):
        if val_dataset is not None and (it == 1 or it % args.steps_per_eval == 0 or it == args.iters):
            _maybe_clear_metal_cache()
            tic_val = time.perf_counter()
            val_loss = vlm_evaluate(
                model=model,
                dataset=val_dataset,
                batch_size=args.batch_size,
                num_batches=args.val_batches,
                max_seq_length=args.max_seq_length,
            )
            model.train()
            val_time = time.perf_counter() - tic_val
            if rank == 0:
                print(f"Iter {it}: Val loss {val_loss:.3f}, Val took {val_time:.3f}s", flush=True)
            if training_callback is not None:
                training_callback.on_val_loss_report(
                    {
                        "iteration": it - 1,
                        "val_loss": val_loss,
                        "val_time": val_time,
                    }
                )

        tic = time.perf_counter()
        lvalue, toks, grad_accum = step(
            batch,
            grad_accum,
            (it % grad_accum_steps == 0) or (it == args.iters),
        )
        losses += lvalue
        n_tokens += toks
        steps += 1
        mx.eval(state, losses, n_tokens, grad_accum)
        train_time += time.perf_counter() - tic

        if it % args.steps_per_report == 0 or it == args.iters:
            train_loss = mx.distributed.all_sum(losses, stream=cast(Any, mx.cpu)).item()
            train_loss /= steps * world_size
            n_tokens_total = mx.distributed.all_sum(n_tokens, stream=cast(Any, mx.cpu)).item()
            learning_rate = (
                optimizer.learning_rate.item()
                if hasattr(optimizer.learning_rate, "item")
                else args.learning_rate
            )
            it_sec = steps / max(train_time, 1e-6)
            tokens_sec = float(n_tokens_total) / max(train_time, 1e-6)
            trained_tokens += int(n_tokens_total)
            peak_mem = mx.get_peak_memory() / 1e9
            if rank == 0:
                print(
                    f"Iter {it}: Train loss {train_loss:.3f}, "
                    f"Learning Rate {learning_rate:.3e}, "
                    f"It/sec {it_sec:.3f}, Tokens/sec {tokens_sec:.3f}, "
                    f"Trained Tokens {trained_tokens}, Peak mem {peak_mem:.3f} GB",
                    flush=True,
                )
            if training_callback is not None:
                training_callback.on_train_loss_report(
                    {
                        "iteration": it,
                        "train_loss": train_loss,
                        "learning_rate": learning_rate,
                        "iterations_per_second": it_sec,
                        "tokens_per_second": tokens_sec,
                        "trained_tokens": trained_tokens,
                        "peak_memory": peak_mem,
                    }
                )
            losses = 0
            n_tokens = 0
            steps = 0
            train_time = 0.0

        if it % args.steps_per_save == 0 and rank == 0:
            vlm_save_adapter(model, args.adapter_file)
            checkpoint = Path(args.adapter_file).parent / f"{it:07d}_adapters.safetensors"
            vlm_save_adapter(model, checkpoint)
            print(
                f"Iter {it}: Saved adapter weights to {args.adapter_file} and {checkpoint}.",
                flush=True,
            )
            _maybe_clear_metal_cache()

        if cache_clear_interval > 0 and it % cache_clear_interval == 0:
            _maybe_clear_metal_cache()

    if rank == 0:
        vlm_save_adapter(model, args.adapter_file)
        print(f"Saved final weights to {args.adapter_file}.", flush=True)


def _run_multimodal_preference_training_loop(
    *,
    model: Any,
    optimizer: Any,
    train_dataset: Any,
    val_dataset: Any | None,
    args: ORPOTrainingArgs,
    training_callback: TrainingCallback | None,
    stability: StabilityConfig,
) -> None:
    _configure_metal_memory_limits(stability=stability)
    print(f"Starting multimodal ORPO training..., iters: {args.iters}")
    world = mx.distributed.init()
    world_size = world.size()
    rank = world.rank()
    if world_size > 1:
        print(f"Node {rank} of {world_size}")

    if args.grad_checkpoint:
        for module in model.children().values():
            layers = getattr(module, "layers", None)
            if isinstance(layers, Sequence) and layers:
                _enable_grad_checkpoint_once(layers[0])
                break

    grad_accum_steps = max(args.gradient_accumulation_steps, 1)
    cache_clear_interval = max(stability.metal_cache_clear_interval, 0)

    def preference_loss(model_obj: Any, batch: dict[str, Any]) -> tuple[Any, Any]:
        chosen_batch = batch["chosen"]
        rejected_batch = batch["rejected"]
        chosen_logps, chosen_logits_mean = vlm_orpo_get_logps(model_obj, chosen_batch)
        rejected_logps, rejected_logits_mean = vlm_orpo_get_logps(model_obj, rejected_batch)
        losses, _, num_tokens, _ = vlm_orpo_loss(
            chosen_logps,
            chosen_logits_mean,
            rejected_logps,
            rejected_logits_mean,
            chosen_batch["attention_mask"],
            rejected_batch["attention_mask"],
            beta=args.beta,
        )
        return losses, num_tokens

    loss_value_and_grad = nn.value_and_grad(model, preference_loss)
    state = [model.state, optimizer.state, mx.random.state]
    model.train()
    losses = 0
    n_tokens = 0
    steps = 0
    trained_tokens = 0
    train_time = 0.0
    grad_accum = None

    def step(batch: Any, prev_grad: Any, do_update: bool) -> tuple[Any, Any, Any]:
        (lvalue, toks), grad = loss_value_and_grad(model, batch)
        if args.grad_clip is not None:
            grad = tree_map(lambda g: mx.clip(g, -args.grad_clip, args.grad_clip), grad)
        if prev_grad is not None:
            grad = tree_map(lambda x, y: x + y, grad, prev_grad)
        if do_update:
            grad = average_gradients(grad)
            if grad_accum_steps > 1:
                grad = tree_map(lambda x: x / grad_accum_steps, grad)
            optimizer.update(model, grad)
            grad = None
        return lvalue, toks, grad

    multimodal_get_logps = lambda model_obj, batch: vlm_orpo_get_logps(model_obj, batch)

    for it, batch in zip(
        range(1, args.iters + 1),
        vlm_orpo_iterate_batches(
            dataset=train_dataset,
            batch_size=args.batch_size,
            max_seq_length=args.max_seq_length,
            train=True,
        ),
    ):
        if val_dataset is not None and (it == 1 or it % args.steps_per_eval == 0 or it == args.iters):
            _maybe_clear_metal_cache()
            tic_val = time.perf_counter()
            val_loss = _evaluate_preference_dataset(
                model=model,
                dataset=val_dataset,
                batch_size=args.batch_size,
                num_batches=args.val_batches,
                max_seq_length=args.max_seq_length,
                beta=args.beta,
                get_logps_fn=multimodal_get_logps,
                iterate_batches_fn=vlm_orpo_iterate_batches,
            )
            model.train()
            val_time = time.perf_counter() - tic_val
            if rank == 0:
                print(f"Iter {it}: Val loss {val_loss:.3f}, Val took {val_time:.3f}s", flush=True)
            if training_callback is not None:
                training_callback.on_val_loss_report(
                    {
                        "iteration": it - 1,
                        "val_loss": val_loss,
                        "val_time": val_time,
                    }
                )

        tic = time.perf_counter()
        lvalue, toks, grad_accum = step(
            batch,
            grad_accum,
            (it % grad_accum_steps == 0) or (it == args.iters),
        )
        losses += lvalue
        n_tokens += toks
        steps += 1
        mx.eval(state, losses, n_tokens, grad_accum)
        train_time += time.perf_counter() - tic

        if it % args.steps_per_report == 0 or it == args.iters:
            train_loss = mx.distributed.all_sum(losses, stream=cast(Any, mx.cpu)).item()
            train_loss /= steps * world_size
            n_tokens_total = mx.distributed.all_sum(n_tokens, stream=cast(Any, mx.cpu)).item()
            learning_rate = (
                optimizer.learning_rate.item()
                if hasattr(optimizer.learning_rate, "item")
                else args.learning_rate
            )
            it_sec = steps / max(train_time, 1e-6)
            tokens_sec = float(n_tokens_total) / max(train_time, 1e-6)
            trained_tokens += int(n_tokens_total)
            peak_mem = mx.get_peak_memory() / 1e9
            if rank == 0:
                print(
                    f"Iter {it}: Train loss {train_loss:.3f}, "
                    f"Learning Rate {learning_rate:.3e}, "
                    f"It/sec {it_sec:.3f}, Tokens/sec {tokens_sec:.3f}, "
                    f"Trained Tokens {trained_tokens}, Peak mem {peak_mem:.3f} GB",
                    flush=True,
                )
            if training_callback is not None:
                training_callback.on_train_loss_report(
                    {
                        "iteration": it,
                        "train_loss": train_loss,
                        "learning_rate": learning_rate,
                        "iterations_per_second": it_sec,
                        "tokens_per_second": tokens_sec,
                        "trained_tokens": trained_tokens,
                        "peak_memory": peak_mem,
                    }
                )
            losses = 0
            n_tokens = 0
            steps = 0
            train_time = 0.0

        if it % args.steps_per_save == 0 and rank == 0:
            vlm_save_adapter(model, args.adapter_file)
            checkpoint = Path(args.adapter_file).parent / f"{it:07d}_adapters.safetensors"
            vlm_save_adapter(model, checkpoint)
            print(
                f"Iter {it}: Saved adapter weights to {args.adapter_file} and {checkpoint}.",
                flush=True,
            )
            _maybe_clear_metal_cache()

        if cache_clear_interval > 0 and it % cache_clear_interval == 0:
            _maybe_clear_metal_cache()

    if rank == 0:
        vlm_save_adapter(model, args.adapter_file)
        print(f"Saved final weights to {args.adapter_file}.", flush=True)


def sample_saved_checkpoints(
    *,
    model_path: str | Path,
    train_output_dir: str | Path,
    prompt: str = "AIについて説明してください",
    max_tokens: int = 8192,
    max_kv_size: int | None = 2048,
    kv_bits: int | None = 4,
    kv_group_size: int = 64,
) -> CheckpointSamplingReport:
    normalized_model_path = str(Path(model_path).expanduser().resolve())
    output_dir = Path(train_output_dir).expanduser().resolve()
    checkpoint_paths = _list_saved_checkpoint_paths(output_dir)
    if not checkpoint_paths:
        raise ValueError(f"No saved checkpoint files were found in {output_dir}.")
    records_path = output_dir / "saved_checkpoint_samples.jsonl"
    sample_dir = output_dir / "saved_checkpoint_samples"
    records_path.unlink(missing_ok=True)
    if sample_dir.exists():
        for existing in sample_dir.iterdir():
            if existing.is_file():
                existing.unlink()
    for checkpoint_path in checkpoint_paths:
        _maybe_clear_metal_cache()
        gc.collect()
        adapter_path = _resolve_checkpoint_adapter_path(
            output_dir=output_dir,
            checkpoint_path=checkpoint_path,
        )
        model, tokenizer, _ = cast(
            tuple[Any, Any, dict[str, Any]],
            load(
                normalized_model_path,
                tokenizer_config={"trust_remote_code": True},
                adapter_path=str(adapter_path),
                lazy=False,
                return_config=True,
            ),
        )
        try:
            record = _generate_checkpoint_sample_record(
                model=model,
                tokenizer=tokenizer,
                checkpoint_file=checkpoint_path,
                iteration=_checkpoint_iteration_from_path(checkpoint_path),
                prompt=prompt,
                max_tokens=max_tokens,
                max_kv_size=max_kv_size,
                kv_bits=kv_bits,
                kv_group_size=kv_group_size,
            )
        except Exception as exc:
            record = CheckpointSampleRecord(
                iteration=_checkpoint_iteration_from_path(checkpoint_path),
                checkpoint_file=str(checkpoint_path),
                prompt=prompt,
                max_tokens=max_tokens,
                error=str(exc),
            )
        _append_checkpoint_sample_record(record=record, records_path=records_path)
        del model
        del tokenizer
        gc.collect()
        _maybe_clear_metal_cache()
    return CheckpointSamplingReport(
        model_path=normalized_model_path,
        train_output_dir=str(output_dir),
        checkpoint_count=len(checkpoint_paths),
        prompt=prompt,
        max_tokens=max_tokens,
        records_path=str(records_path),
        sample_dir=str(sample_dir),
        checkpoints=[str(path) for path in checkpoint_paths],
    )


def _record_checkpoint_sample(
    *,
    model: Any,
    tokenizer: Any,
    checkpoint_file: Path,
    iteration: int,
    config: CheckpointSampleConfig,
    records_path: Path,
) -> None:
    try:
        record = _generate_checkpoint_sample_record(
            model=model,
            tokenizer=tokenizer,
            checkpoint_file=checkpoint_file,
            iteration=iteration,
            prompt=config.prompt,
            max_tokens=config.max_tokens,
            max_kv_size=config.max_kv_size,
            kv_bits=config.kv_bits,
            kv_group_size=config.kv_group_size,
        )
        print(
            "Iter "
            f"{iteration}: Wrote checkpoint sample for {checkpoint_file.name} "
            f"(finish_reason={record.finish_reason}, generation_tokens={record.generation_tokens}).",
            flush=True,
        )
    except Exception as exc:
        record = CheckpointSampleRecord(
            iteration=iteration,
            checkpoint_file=str(checkpoint_file),
            prompt=config.prompt,
            max_tokens=config.max_tokens,
            error=str(exc),
        )
        print(
            f"Iter {iteration}: Checkpoint sample failed for {checkpoint_file.name}: {exc}",
            flush=True,
        )
    _append_checkpoint_sample_record(record=record, records_path=records_path)


def _generate_checkpoint_sample_record(
    *,
    model: Any,
    tokenizer: Any,
    checkpoint_file: Path,
    iteration: int | None,
    prompt: str,
    max_tokens: int,
    max_kv_size: int | None = 2048,
    kv_bits: int | None = 4,
    kv_group_size: int = 64,
) -> CheckpointSampleRecord:
    if max_tokens < 1:
        raise ValueError("checkpoint_sample_max_tokens_must_be_positive")
    prompt_tokens = _build_checkpoint_sample_prompt_tokens(tokenizer=tokenizer, prompt=prompt)
    attempts = _checkpoint_sample_attempts(
        max_kv_size=max_kv_size,
        kv_bits=kv_bits,
        kv_group_size=kv_group_size,
    )
    last_error: Exception | None = None
    for retry_count, (attempt_max_kv_size, attempt_kv_bits, attempt_kv_group_size) in enumerate(attempts):
        _maybe_clear_metal_cache()
        model.eval()
        generated_segments: list[str] = []
        last_response: Any | None = None
        try:
            for response in stream_generate(
                model,
                tokenizer,
                prompt_tokens,
                max_tokens=max_tokens,
                max_kv_size=attempt_max_kv_size,
                kv_bits=attempt_kv_bits,
                kv_group_size=attempt_kv_group_size,
            ):
                generated_segments.append(str(response.text))
                last_response = response
        except Exception as exc:
            last_error = exc
            if not _looks_like_memory_pressure_error(exc) or retry_count >= len(attempts) - 1:
                raise
            continue
        finally:
            model.train()
            _maybe_clear_metal_cache()
        if last_response is None:
            raise ValueError("checkpoint_sample_generation_failed")
        return CheckpointSampleRecord(
            iteration=iteration,
            checkpoint_file=str(checkpoint_file),
            prompt=prompt,
            max_tokens=max_tokens,
            effective_max_kv_size=attempt_max_kv_size,
            effective_kv_bits=attempt_kv_bits,
            effective_kv_group_size=attempt_kv_group_size,
            retry_count=retry_count,
            output_text="".join(generated_segments),
            prompt_tokens=int(last_response.prompt_tokens),
            generation_tokens=int(last_response.generation_tokens),
            finish_reason=(
                str(last_response.finish_reason)
                if last_response.finish_reason is not None
                else None
            ),
            prompt_tps=float(last_response.prompt_tps),
            generation_tps=float(last_response.generation_tps),
            peak_memory_gb=float(last_response.peak_memory),
        )
    if last_error is not None:
        raise last_error
    raise ValueError("checkpoint_sample_generation_failed")


def _checkpoint_sample_attempts(
    *,
    max_kv_size: int | None,
    kv_bits: int | None,
    kv_group_size: int,
) -> list[tuple[int | None, int | None, int]]:
    normalized_group_size = max(kv_group_size, 1)
    normalized_bits = kv_bits if kv_bits is not None and kv_bits > 0 else None
    normalized_max_kv_size = max_kv_size if max_kv_size is None else max(max_kv_size, 0)
    attempts: list[tuple[int | None, int | None, int]] = []

    def add_attempt(size: int | None, bits: int | None) -> None:
        attempt = (size, bits, normalized_group_size)
        if attempt not in attempts:
            attempts.append(attempt)

    add_attempt(normalized_max_kv_size, normalized_bits)

    fallback_bits = 4 if normalized_bits is None else min(max(normalized_bits, 1), 4)
    if fallback_bits != normalized_bits:
        add_attempt(normalized_max_kv_size, fallback_bits)

    fallback_size = normalized_max_kv_size
    if fallback_size is None:
        fallback_size = 4096
        add_attempt(fallback_size, fallback_bits)
    while fallback_size > 512:
        fallback_size = max(fallback_size // 2, 512)
        add_attempt(fallback_size, fallback_bits)
        if fallback_size == 512:
            break
    return attempts


def _looks_like_memory_pressure_error(exc: Exception) -> bool:
    message = str(exc).strip().lower()
    if not message:
        return False
    return any(
        token in message
        for token in (
            "out of memory",
            "oom",
            "memory",
            "allocation",
            "cache",
            "metal",
        )
    )


def _build_checkpoint_sample_prompt_tokens(*, tokenizer: Any, prompt: str) -> list[int]:
    template_kwargs: dict[str, Any] = {
        "add_generation_prompt": True,
        "return_dict": False,
        "enable_thinking": False,
    }
    try:
        tokens = tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            **template_kwargs,
        )
    except TypeError:
        template_kwargs.pop("enable_thinking", None)
        tokens = tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            **template_kwargs,
        )
    return cast(list[int], tokens)


def _append_checkpoint_sample_record(
    *,
    record: CheckpointSampleRecord,
    records_path: Path,
) -> None:
    records_path.parent.mkdir(parents=True, exist_ok=True)
    with records_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record.model_dump(), ensure_ascii=False) + "\n")
    sample_file = _checkpoint_sample_text_path(records_path=records_path, checkpoint_file=record.checkpoint_file)
    sample_file.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"Prompt:\n{record.prompt}\n"]
    if record.error is not None:
        lines.append(f"Error:\n{record.error}\n")
    else:
        lines.append(f"Output:\n{record.output_text or ''}\n")
    lines.append(
        "KV settings:\n"
        f"max_kv_size={record.effective_max_kv_size}, "
        f"kv_bits={record.effective_kv_bits}, "
        f"kv_group_size={record.effective_kv_group_size}, "
        f"retries={record.retry_count}\n"
    )
    sample_file.write_text("\n".join(lines), encoding="utf-8")


def _checkpoint_sample_text_path(*, records_path: Path, checkpoint_file: str) -> Path:
    checkpoint_path = Path(checkpoint_file)
    return records_path.parent / records_path.stem / f"{_checkpoint_sample_label(checkpoint_path)}.txt"


def _checkpoint_sample_label(checkpoint_path: Path) -> str:
    if checkpoint_path.name == "adapters.safetensors":
        return "final"
    suffix = "_adapters.safetensors"
    if checkpoint_path.name.endswith(suffix):
        return checkpoint_path.name[: -len(suffix)]
    return checkpoint_path.stem


def _list_saved_checkpoint_paths(output_dir: Path) -> list[Path]:
    checkpoint_paths = sorted(
        output_dir.glob("*_adapters.safetensors"),
        key=lambda path: path.name,
    )
    final_adapter = output_dir / "adapters.safetensors"
    if final_adapter.is_file():
        checkpoint_paths.append(final_adapter)
    return checkpoint_paths


def _checkpoint_iteration_from_path(checkpoint_path: Path) -> int | None:
    label = _checkpoint_sample_label(checkpoint_path)
    if label == "final":
        return None
    if label.isdigit():
        return int(label)
    return None


def _build_adapter_config_payload(
    *,
    lora_num_layers: int,
    lora_rank: int,
    lora_scale: float,
    lora_dropout: float,
) -> dict[str, Any]:
    return {
        "fine_tune_type": "lora" if lora_num_layers > 0 else "full",
        "num_layers": lora_num_layers,
        "lora_parameters": {
            "rank": lora_rank,
            "scale": lora_scale,
            "dropout": lora_dropout,
        },
        "rank": lora_rank,
        "alpha": lora_scale,
        "dropout": lora_dropout,
    }


def _resolve_checkpoint_adapter_path(*, output_dir: Path, checkpoint_path: Path) -> Path:
    output_dir = output_dir.expanduser().resolve()
    checkpoint_path = checkpoint_path.expanduser().resolve()
    if checkpoint_path.name == "adapters.safetensors":
        _ensure_output_dir_adapter_config(output_dir)
        return output_dir
    bundle_dir = output_dir / "checkpoint_bundles" / _checkpoint_sample_label(checkpoint_path)
    bundle_dir.mkdir(parents=True, exist_ok=True)
    adapter_config_payload = _load_or_build_adapter_config_payload(output_dir)
    (bundle_dir / "adapter_config.json").write_text(
        json.dumps(adapter_config_payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    _symlink_or_copy_file(source=checkpoint_path, target=bundle_dir / "adapters.safetensors")
    training_config_path = output_dir / "training_config.json"
    if training_config_path.is_file():
        shutil.copy2(training_config_path, bundle_dir / "training_config.json")
    return bundle_dir


def _ensure_output_dir_adapter_config(output_dir: Path) -> None:
    output_dir = output_dir.expanduser().resolve()
    adapter_config_path = output_dir / "adapter_config.json"
    payload = _load_or_build_adapter_config_payload(output_dir)
    adapter_config_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _load_or_build_adapter_config_payload(output_dir: Path) -> dict[str, Any]:
    output_dir = output_dir.expanduser().resolve()
    adapter_config_path = output_dir / "adapter_config.json"
    training_config_path = output_dir / "training_config.json"
    existing_payload = _read_json_file(adapter_config_path) if adapter_config_path.is_file() else None
    training_payload = _read_json_file(training_config_path) if training_config_path.is_file() else None
    if isinstance(existing_payload, dict) and "num_layers" in existing_payload and "lora_parameters" in existing_payload:
        return existing_payload
    if isinstance(training_payload, dict):
        lora_payload = training_payload.get("lora", {})
        if isinstance(lora_payload, dict):
            return _build_adapter_config_payload(
                lora_num_layers=int(lora_payload.get("num_layers", 0)),
                lora_rank=int(lora_payload.get("rank", 8)),
                lora_scale=float(lora_payload.get("scale", 20.0)),
                lora_dropout=float(lora_payload.get("dropout", 0.0)),
            )
    if isinstance(existing_payload, dict):
        alpha_or_scale = existing_payload.get("alpha")
        if alpha_or_scale is None:
            alpha_or_scale = existing_payload.get("scale", 20.0)
        return _build_adapter_config_payload(
            lora_num_layers=0,
            lora_rank=int(existing_payload.get("rank", 8)),
            lora_scale=float(alpha_or_scale),
            lora_dropout=float(existing_payload.get("dropout", 0.0)),
        )
    raise FileNotFoundError(
        f"Could not resolve adapter configuration from {adapter_config_path} or {training_config_path}."
    )


def _read_json_file(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def _symlink_or_copy_file(*, source: Path, target: Path) -> None:
    target.unlink(missing_ok=True)
    try:
        os.symlink(source, target)
    except OSError:
        shutil.copy2(source, target)


def _tree_isfinite(tree: Any) -> bool:
    flattened = cast(list[tuple[str, Any]], tree_flatten(tree))
    for _, value in flattened:
        mx.eval(value)
        if not bool(mx.all(mx.isfinite(value)).item()):
            return False
    return True


def _eval_trees(*trees: Any) -> None:
    values: list[Any] = []
    for tree in trees:
        values.extend(_tree_eval_values(tree))
    if values:
        mx.eval(*values)


def _tree_eval_values(tree: Any) -> list[Any]:
    if tree is None or isinstance(tree, (bool, int, float, str)):
        return []
    if hasattr(tree, "shape") and hasattr(tree, "dtype"):
        return [tree]
    flattened = cast(list[tuple[str, Any]], tree_flatten(tree))
    return [
        value
        for _, value in flattened
        if hasattr(value, "shape") and hasattr(value, "dtype")
    ]


def _tree_all_finite(tree: Any) -> Any:
    flattened = cast(list[tuple[str, Any]], tree_flatten(tree))
    result = mx.array(True)
    for _, value in flattened:
        result = mx.logical_and(result, mx.all(mx.isfinite(value)))
    return result


def _is_finite_scalar(value: Any) -> bool:
    mx.eval(value)
    return bool(mx.all(mx.isfinite(value)).item())


def _build_optimizer(
    *,
    optimizer_name: str,
    learning_rate: float,
    base_learning_rate_scale: float,
    has_base_updates: bool,
) -> Any:
    normalized = optimizer_name.lower()
    return _build_single_optimizer(
        optimizer_name=normalized,
        learning_rate=learning_rate,
    )


def _build_single_optimizer(*, optimizer_name: str, learning_rate: float) -> Any:
    if optimizer_name == "adam":
        return optim.Adam(learning_rate=learning_rate)
    if optimizer_name == "adamw":
        return optim.AdamW(learning_rate=learning_rate)
    if optimizer_name == "sgd":
        return optim.SGD(learning_rate=learning_rate)
    if optimizer_name == "adafactor":
        return optim.Adafactor(learning_rate=learning_rate)
    raise ValueError(f"Unsupported optimizer: {optimizer_name}")


def _estimated_optimizer_bytes(*, optimizer_name: str, trainable_parameter_count: int) -> int:
    normalized = optimizer_name.lower()
    if normalized == "adafactor":
        return trainable_parameter_count * 8
    if normalized == "sgd":
        return trainable_parameter_count * 4
    return trainable_parameter_count * 16


def _is_lora_parameter_name(name: str) -> bool:
    return name.endswith("lora_a") or name.endswith("lora_b")


def _scale_base_parameter_gradients(*, gradients: Any, scale: float) -> Any:
    if scale == 1.0:
        return gradients
    flattened = cast(list[tuple[str, Any]], tree_flatten(gradients))
    scaled = [
        (
            name,
            value if _is_lora_parameter_name(name) else value * scale,
        )
        for name, value in flattened
    ]
    return tree_unflatten(scaled)


def _enable_grad_checkpoint_once(layer: Any) -> None:
    layer_type = type(layer)
    if bool(getattr(layer_type, GRAD_CHECKPOINT_MARKER, False)):
        return
    mlx_grad_checkpoint(layer)
    setattr(layer_type, GRAD_CHECKPOINT_MARKER, True)


def _configure_metal_memory_limits(
    *,
    stability: StabilityConfig,
) -> None:
    if not mx.metal.is_available():
        return
    device_info = cast(dict[str, Any], mx.device_info())
    memory_limit = _resolve_memory_budget_bytes(
        device_info=device_info,
        stability=stability,
    )
    wired_limit = stability.metal_wired_limit_bytes
    if wired_limit is None:
        wired_limit = memory_limit
    recommended_limit = _coerce_optional_int(
        device_info.get("max_recommended_working_set_size")
    )
    if wired_limit is not None and recommended_limit is not None:
        wired_limit = min(wired_limit, recommended_limit)
    if memory_limit is not None:
        mx.set_memory_limit(memory_limit)
    if wired_limit is not None:
        mx.set_wired_limit(max(wired_limit, 0))
    if stability.metal_cache_limit_bytes is not None:
        mx.set_cache_limit(max(stability.metal_cache_limit_bytes, 0))


def _maybe_clear_metal_cache() -> None:
    if not mx.metal.is_available():
        return
    mx.clear_cache()


def _coerce_int(value: Any, *, default: int) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _coerce_optional_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None


def _coerce_optional_str(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    return None
