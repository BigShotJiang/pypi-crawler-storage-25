from __future__ import annotations

import gc
import json
import os
import time
from pathlib import Path
from typing import Any

import mlx.core as mx
from mlx_lm import stream_generate as stream_text_generate
from mlx_lm.sample_utils import make_sampler
from mlx_vlm.generate import stream_generate as stream_multimodal_generate
from pydantic import BaseModel, Field

from .model_inspector import inspect_model_dir
from .runtime_compat import load, load_multimodal
from .trainer import (
    BaseWeightUpdateConfig,
    CheckpointSampleConfig,
    LoRAHyperparameters,
    StabilityConfig,
    TrainerConfig,
    TrainingRunReport,
    _apply_multimodal_chat_template,
    _build_checkpoint_sample_prompt_tokens,
    run_training,
)


class PreferenceLoopConfig(BaseModel):
    model_path: str
    output_dir: str
    prompt: str | None = None
    adapter_path: str | None = None
    max_rounds: int | None = None
    max_regenerations_per_round: int = 20
    max_tokens: int = 1024
    candidate_a_temperature: float = 0.6
    candidate_b_temperature: float = 0.9
    candidate_top_p: float = 0.95
    seed: int = 0
    train_batch_size: int = 1
    train_iters: int = 1
    train_learning_rate: float = 1e-6
    train_grad_checkpoint: bool = True
    train_vision: bool = False
    context_window: int | None = None
    yarn_factor: float | None = None
    lora: LoRAHyperparameters = Field(default_factory=LoRAHyperparameters)
    base_update: BaseWeightUpdateConfig = Field(default_factory=BaseWeightUpdateConfig)
    stability: StabilityConfig = Field(default_factory=StabilityConfig)
    orpo_beta: float = 0.1


class PreferenceLoopState(BaseModel):
    model_path: str
    output_dir: str
    prompt: str
    preference_dataset_path: str
    current_adapter_path: str | None = None
    completed_rounds: int = 0
    total_preferences: int = 0
    last_round_output_dir: str | None = None
    updated_at: float = 0.0


class PreferenceCandidate(BaseModel):
    label: str
    seed: int
    temperature: float
    output_text: str
    prompt_tokens: int | None = None
    generation_tokens: int | None = None
    finish_reason: str | None = None


class PreferenceLoopReport(BaseModel):
    output_dir: str
    prompt: str
    preference_dataset_path: str
    current_adapter_path: str | None = None
    completed_rounds: int = 0
    total_preferences: int = 0
    exit_reason: str
    last_round_output_dir: str | None = None


def run_preference_loop(config: PreferenceLoopConfig) -> PreferenceLoopReport:
    normalized_config = _normalize_loop_config(config)
    output_dir = Path(normalized_config.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    state_path = output_dir / "preference_loop_state.json"
    preference_dataset_path = output_dir / "preferences.jsonl"
    state = _load_loop_state(state_path)
    state = _resolve_loop_state(
        config=normalized_config,
        state=state,
        state_path=state_path,
        preference_dataset_path=preference_dataset_path,
    )
    model_profile = inspect_model_dir(normalized_config.model_path)
    exit_reason = "user_quit"

    while True:
        if (
            normalized_config.max_rounds is not None
            and state.completed_rounds >= normalized_config.max_rounds
        ):
            exit_reason = "max_rounds_reached"
            break

        regeneration_count = 0
        candidate_a: PreferenceCandidate
        candidate_b: PreferenceCandidate
        while True:
            if regeneration_count > normalized_config.max_regenerations_per_round:
                exit_reason = "max_regenerations_reached"
                _save_loop_state(state_path=state_path, state=state)
                return PreferenceLoopReport(
                    output_dir=state.output_dir,
                    prompt=state.prompt,
                    preference_dataset_path=state.preference_dataset_path,
                    current_adapter_path=state.current_adapter_path,
                    completed_rounds=state.completed_rounds,
                    total_preferences=state.total_preferences,
                    exit_reason=exit_reason,
                    last_round_output_dir=state.last_round_output_dir,
                )

            candidate_a, candidate_b = _generate_candidate_pair(
                model_path=normalized_config.model_path,
                adapter_path=state.current_adapter_path,
                prompt=state.prompt,
                max_tokens=normalized_config.max_tokens,
                candidate_a_temperature=normalized_config.candidate_a_temperature,
                candidate_b_temperature=normalized_config.candidate_b_temperature,
                candidate_top_p=normalized_config.candidate_top_p,
                seed=normalized_config.seed + state.completed_rounds + regeneration_count * 17,
                use_multimodal_generation=normalized_config.train_vision and model_profile.capabilities.image,
            )
            _print_candidate_pair(
                round_index=state.completed_rounds + 1,
                prompt=state.prompt,
                candidate_a=candidate_a,
                candidate_b=candidate_b,
                regeneration_count=regeneration_count,
            )
            choice = input("Choose `a`, `b`, `s` (skip/regenerate), or `:quit`: ").strip().lower()
            if choice in {":quit", "quit", "exit"}:
                exit_reason = "user_quit"
                _save_loop_state(state_path=state_path, state=state)
                return PreferenceLoopReport(
                    output_dir=state.output_dir,
                    prompt=state.prompt,
                    preference_dataset_path=state.preference_dataset_path,
                    current_adapter_path=state.current_adapter_path,
                    completed_rounds=state.completed_rounds,
                    total_preferences=state.total_preferences,
                    exit_reason=exit_reason,
                    last_round_output_dir=state.last_round_output_dir,
                )
            if choice in {"s", "skip", "r", "regen", "regenerate"}:
                regeneration_count += 1
                continue
            if choice in {"a", "b"}:
                break
            print("Unknown choice. Use `a`, `b`, `s`, or `:quit`.")

        chosen = candidate_a if choice == "a" else candidate_b
        rejected = candidate_b if choice == "a" else candidate_a
        _append_preference_record(
            preference_dataset_path=preference_dataset_path,
            prompt=state.prompt,
            chosen=chosen,
            rejected=rejected,
            round_index=state.completed_rounds + 1,
        )
        state.total_preferences += 1
        state.updated_at = time.time()
        _save_loop_state(state_path=state_path, state=state)

        round_output_dir = output_dir / f"round_{state.completed_rounds + 1:04d}"
        training_report = run_training(
            TrainerConfig(
                model_path=normalized_config.model_path,
                dataset_path=str(preference_dataset_path),
                output_dir=str(round_output_dir),
                train_mode="orpo",
                adapter_path=state.current_adapter_path,
                validation_fraction=0.0,
                batch_size=normalized_config.train_batch_size,
                iters=normalized_config.train_iters,
                learning_rate=normalized_config.train_learning_rate,
                grad_checkpoint=normalized_config.train_grad_checkpoint,
                context_window=normalized_config.context_window,
                yarn_factor=normalized_config.yarn_factor,
                lora=normalized_config.lora,
                base_update=normalized_config.base_update,
                stability=normalized_config.stability,
                checkpoint_sample=CheckpointSampleConfig(enabled=False),
                orpo_beta=normalized_config.orpo_beta,
                train_vision=normalized_config.train_vision,
            )
        )
        if training_report.status != "completed" or training_report.adapter_file is None:
            raise RuntimeError(
                f"preference_round_training_failed: {training_report.error or training_report.status}"
            )
        state.completed_rounds += 1
        state.current_adapter_path = training_report.adapter_file
        state.last_round_output_dir = str(round_output_dir)
        state.updated_at = time.time()
        _save_loop_state(state_path=state_path, state=state)

    return PreferenceLoopReport(
        output_dir=state.output_dir,
        prompt=state.prompt,
        preference_dataset_path=state.preference_dataset_path,
        current_adapter_path=state.current_adapter_path,
        completed_rounds=state.completed_rounds,
        total_preferences=state.total_preferences,
        exit_reason=exit_reason,
        last_round_output_dir=state.last_round_output_dir,
    )


def _normalize_loop_config(config: PreferenceLoopConfig) -> PreferenceLoopConfig:
    payload = config.model_dump()
    payload["model_path"] = str(Path(config.model_path).expanduser().resolve())
    payload["output_dir"] = str(Path(config.output_dir).expanduser().resolve())
    if config.adapter_path is not None:
        payload["adapter_path"] = str(Path(config.adapter_path).expanduser().resolve())
    return PreferenceLoopConfig(**payload)


def _resolve_loop_state(
    *,
    config: PreferenceLoopConfig,
    state: PreferenceLoopState | None,
    state_path: Path,
    preference_dataset_path: Path,
) -> PreferenceLoopState:
    if state is None:
        if config.prompt is None or not config.prompt.strip():
            raise ValueError("prompt is required when starting a new preference loop.")
        resolved = PreferenceLoopState(
            model_path=config.model_path,
            output_dir=config.output_dir,
            prompt=config.prompt.strip(),
            preference_dataset_path=str(preference_dataset_path),
            current_adapter_path=config.adapter_path,
            updated_at=time.time(),
        )
        _save_loop_state(state_path=state_path, state=resolved)
        return resolved
    if state.model_path != config.model_path:
        raise ValueError("existing_preference_loop_state_uses_different_model")
    if config.prompt is not None and config.prompt.strip() and config.prompt.strip() != state.prompt:
        raise ValueError("existing_preference_loop_state_uses_different_prompt")
    state.output_dir = config.output_dir
    state.preference_dataset_path = str(preference_dataset_path)
    state.updated_at = time.time()
    if state.current_adapter_path is None and config.adapter_path is not None:
        state.current_adapter_path = config.adapter_path
    _save_loop_state(state_path=state_path, state=state)
    return state


def _load_loop_state(state_path: Path) -> PreferenceLoopState | None:
    if not state_path.exists():
        return None
    return PreferenceLoopState.model_validate_json(state_path.read_text(encoding="utf-8"))


def _save_loop_state(*, state_path: Path, state: PreferenceLoopState) -> None:
    _write_json(state_path, state.model_dump())


def _append_preference_record(
    *,
    preference_dataset_path: Path,
    prompt: str,
    chosen: PreferenceCandidate,
    rejected: PreferenceCandidate,
    round_index: int,
) -> None:
    preference_dataset_path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "task_type": "preference",
        "chosen": [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": chosen.output_text},
        ],
        "rejected": [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": rejected.output_text},
        ],
        "focus": ["reasoning"],
        "metadata": {
            "round_index": round_index,
            "chosen_label": chosen.label,
            "rejected_label": rejected.label,
            "chosen_seed": chosen.seed,
            "rejected_seed": rejected.seed,
            "chosen_temperature": chosen.temperature,
            "rejected_temperature": rejected.temperature,
        },
    }
    with preference_dataset_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _generate_candidate_pair(
    *,
    model_path: str,
    adapter_path: str | None,
    prompt: str,
    max_tokens: int,
    candidate_a_temperature: float,
    candidate_b_temperature: float,
    candidate_top_p: float,
    seed: int,
    use_multimodal_generation: bool,
) -> tuple[PreferenceCandidate, PreferenceCandidate]:
    candidate_a = _generate_candidate(
        label="A",
        model_path=model_path,
        adapter_path=adapter_path,
        prompt=prompt,
        max_tokens=max_tokens,
        temperature=candidate_a_temperature,
        top_p=candidate_top_p,
        seed=seed,
        use_multimodal_generation=use_multimodal_generation,
    )
    candidate_b = _generate_candidate(
        label="B",
        model_path=model_path,
        adapter_path=adapter_path,
        prompt=prompt,
        max_tokens=max_tokens,
        temperature=candidate_b_temperature,
        top_p=candidate_top_p,
        seed=seed + 1,
        use_multimodal_generation=use_multimodal_generation,
    )
    if candidate_a.output_text.strip() == candidate_b.output_text.strip():
        candidate_b = _generate_candidate(
            label="B",
            model_path=model_path,
            adapter_path=adapter_path,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=max(candidate_b_temperature, candidate_a_temperature + 0.2),
            top_p=candidate_top_p,
            seed=seed + 97,
            use_multimodal_generation=use_multimodal_generation,
        )
    return candidate_a, candidate_b


def _generate_candidate(
    *,
    label: str,
    model_path: str,
    adapter_path: str | None,
    prompt: str,
    max_tokens: int,
    temperature: float,
    top_p: float,
    seed: int,
    use_multimodal_generation: bool,
) -> PreferenceCandidate:
    if use_multimodal_generation:
        return _generate_multimodal_candidate(
            label=label,
            model_path=model_path,
            adapter_path=adapter_path,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            seed=seed,
        )
    return _generate_text_candidate(
        label=label,
        model_path=model_path,
        adapter_path=adapter_path,
        prompt=prompt,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        seed=seed,
    )


def _generate_text_candidate(
    *,
    label: str,
    model_path: str,
    adapter_path: str | None,
    prompt: str,
    max_tokens: int,
    temperature: float,
    top_p: float,
    seed: int,
) -> PreferenceCandidate:
    sampler = make_sampler(temp=temperature, top_p=top_p)
    mx.random.seed(seed)
    loaded = load(
        model_path,
        tokenizer_config={"trust_remote_code": True},
        adapter_path=adapter_path,
        lazy=False,
        return_config=False,
    )
    model, tokenizer = loaded
    prompt_tokens = _build_checkpoint_sample_prompt_tokens(tokenizer=tokenizer, prompt=prompt)
    generated_segments: list[str] = []
    last_response: Any | None = None
    try:
        for response in stream_text_generate(
            model,
            tokenizer,
            prompt_tokens,
            max_tokens=max_tokens,
            sampler=sampler,
        ):
            last_response = response
            generated_segments.append(response.text)
    finally:
        del model
        del tokenizer
        gc.collect()
        _maybe_clear_cache()
    return PreferenceCandidate(
        label=label,
        seed=seed,
        temperature=temperature,
        output_text="".join(generated_segments).strip(),
        prompt_tokens=getattr(last_response, "prompt_tokens", len(prompt_tokens)),
        generation_tokens=getattr(last_response, "generation_tokens", None),
        finish_reason=getattr(last_response, "finish_reason", None),
    )


def _generate_multimodal_candidate(
    *,
    label: str,
    model_path: str,
    adapter_path: str | None,
    prompt: str,
    max_tokens: int,
    temperature: float,
    top_p: float,
    seed: int,
) -> PreferenceCandidate:
    sampler = make_sampler(temp=temperature, top_p=top_p)
    mx.random.seed(seed)
    model, processor = load_multimodal(
        model_path,
        adapter_path=adapter_path,
        lazy=False,
        processor_config={"trust_remote_code": True},
    )
    tokenizer = getattr(processor, "tokenizer", processor)
    prompt_text = _apply_multimodal_chat_template(
        processor=processor,
        tokenizer=tokenizer,
        messages=[{"role": "user", "content": prompt}],
        tools=None,
    )
    generated_segments: list[str] = []
    last_response: Any | None = None
    try:
        for response in stream_multimodal_generate(
            model,
            processor,
            prompt_text,
            image=None,
            max_tokens=max_tokens,
            sampler=sampler,
        ):
            last_response = response
            generated_segments.append(response.text)
    finally:
        del model
        del processor
        gc.collect()
        _maybe_clear_cache()
    return PreferenceCandidate(
        label=label,
        seed=seed,
        temperature=temperature,
        output_text="".join(generated_segments).strip(),
        prompt_tokens=getattr(last_response, "prompt_tokens", None),
        generation_tokens=getattr(last_response, "generation_tokens", None),
        finish_reason=getattr(last_response, "finish_reason", None),
    )


def _print_candidate_pair(
    *,
    round_index: int,
    prompt: str,
    candidate_a: PreferenceCandidate,
    candidate_b: PreferenceCandidate,
    regeneration_count: int,
) -> None:
    print("")
    print(f"[Round {round_index} | regeneration {regeneration_count}]")
    print("Exit command: :quit")
    print("Prompt:")
    print(prompt)
    print("")
    print("[A]")
    print(candidate_a.output_text or "(empty)")
    print("")
    print("[B]")
    print(candidate_b.output_text or "(empty)")
    print("")


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp_path.replace(path)


def _maybe_clear_cache() -> None:
    if mx.metal.is_available():
        mx.clear_cache()
