from __future__ import annotations

import json
import re
import shutil
import unicodedata
import urllib.request
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Literal, TypedDict, cast
from xml.etree import ElementTree

import pdfplumber
from pydantic import BaseModel, Field
from pypdf import PdfReader

from .dataset_manifests import SequentialCptSource, write_sequential_cpt_manifest


KANJI_NUMERALS = "一二三四五六七八九十百千万〇零"
ARTICLE_HEADING_PATTERN = re.compile(
    rf"(?=第[{KANJI_NUMERALS}\d]+(?:編|章|節|款|目|条(?:の[{KANJI_NUMERALS}\d]+)?))"
)
CASE_HEADING_PATTERN = re.compile(r"(?=(主文|理由|事実及び理由|判旨|裁判要旨|参照法条))")
QUESTION_NUMBER_PATTERN = re.compile(r"^\d+\.$")
ASCII_WORD_PATTERN = re.compile(r"[A-Za-z0-9]")
HIRAGANA_PATTERN = re.compile(r"^[ぁ-ゖゝゞー・･\s]+$")
SPACE_PATTERN = re.compile(r"\s+")
JAPANESE_INLINE_SPACE_PATTERN = re.compile(r"(?<=[一-龯ぁ-ゖァ-ヶー々〆ヵヶ])\s+(?=[一-龯ぁ-ゖァ-ヶー々〆ヵヶ])")
WHITESPACE_BEFORE_PUNCTUATION_PATTERN = re.compile(r"\s+([、。！？）」』】〉》])")
WHITESPACE_AFTER_OPENING_BRACKET_PATTERN = re.compile(r"([（「『【〈《])\s+")
LEGAL_SENTENCE_BOUNDARY_PATTERN = re.compile(r"(?<=[。！？])\s+")
QUIZJAM_RELATIVE_TIME_PATTERN = re.compile(
    r"(?:今|昨|来)年度|(?:今|昨|来)年|一昨年|前年|翌年|本年|(?:今|昨|来)シーズン|(?:今|昨|来)季"
)
SUPPORTED_CORPUS_SUFFIXES = {
    ".txt",
    ".md",
    ".html",
    ".htm",
    ".xml",
    ".json",
    ".jsonl",
    ".pdf",
}

EGOV_ARTICLE_CHUNK_MAX_CHARS = 1200
EGOV_ARTICLE_CHUNK_MIN_CHARS = 200
EGOV_PARAGRAPH_CHUNK_MAX_CHARS = 800
EGOV_PARAGRAPH_CHUNK_MIN_CHARS = 120


EGOV_API_BASE_URL = "https://laws.e-gov.go.jp/api/1"
EGOV_SIX_CODE_TITLES = [
    "日本国憲法",
    "民法",
    "商法",
    "刑法",
    "民事訴訟法",
    "刑事訴訟法",
]


class PreparedDatasetReport(BaseModel):
    kind: str
    source_paths: list[str]
    output_paths: dict[str, str]
    total_records: int
    warnings: list[str] = Field(default_factory=list)


class QuizJamQuestion(BaseModel):
    number: int
    pdf_page_index: int
    book_page: int | None = None
    section: str | None = None
    question_raw: str
    question_clean: str
    answer_raw: str
    answer_clean: str
    notes: list[str] = Field(default_factory=list)
    reading_tokens: list[str] = Field(default_factory=list)


class EgovLawArticle(BaseModel):
    law_id: str
    law_name: str
    law_num: str | None = None
    article_order: int
    article_title: str
    article_caption: str | None = None
    article_context: str | None = None
    article_path: list[str] = Field(default_factory=list)
    article_text: str
    paragraph_texts: list[str] = Field(default_factory=list)


class PositionedWord(TypedDict):
    text: str
    x0: float
    x1: float
    top: float
    bottom: float
    size: float


class RenderedLine(TypedDict):
    text: str
    average_size: float


class _TagStripper(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self._parts.append(data)

    def handle_entityref(self, name: str) -> None:
        self._parts.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self._parts.append(f"&#{name};")

    def text(self) -> str:
        return unescape("".join(self._parts))


def prepare_quizjam_pdf(
    *,
    pdf_path: str | Path,
    output_dir: str | Path,
    copy_source: bool = True,
) -> PreparedDatasetReport:
    source_path = Path(pdf_path).expanduser().resolve()
    output_dir_path = Path(output_dir).expanduser().resolve()
    output_dir_path.mkdir(parents=True, exist_ok=True)

    copied_source_path: Path | None = None
    if copy_source:
        copied_source_path = output_dir_path / source_path.name
        if copied_source_path != source_path:
            shutil.copy2(source_path, copied_source_path)

    records: list[QuizJamQuestion] = []
    with pdfplumber.open(source_path) as pdf:
        for pdf_page_index, page in enumerate(pdf.pages, start=1):
            raw_words = cast(
                list[dict[str, Any]],
                page.extract_words(
                    use_text_flow=False,
                    keep_blank_chars=False,
                    extra_attrs=["size"],
                )
                or [],
            )
            records.extend(
                _parse_quizjam_page_words(
                    words=raw_words,
                    page_width=float(page.width),
                    page_height=float(page.height),
                    pdf_page_index=pdf_page_index,
                )
            )

    if not records:
        raise ValueError(f"No quiz records were extracted from {source_path}.")

    records, excluded_records = _filter_quizjam_training_records(records)
    if not records:
        raise ValueError(
            f"All quiz records extracted from {source_path} were excluded because they depend on relative time references."
        )

    records_path = output_dir_path / "quizjam_questions.jsonl"
    cpt_path = output_dir_path / "quizjam_cpt.jsonl"
    answer_sft_path = output_dir_path / "quizjam_answer_sft.jsonl"
    writer_sft_path = output_dir_path / "quizjam_question_writer_sft.jsonl"
    mixed_path = output_dir_path / "quizjam_train_mixed.jsonl"
    manifest_path = output_dir_path / "quizjam_train_manifest.json"

    _write_jsonl(records_path, [record.model_dump() for record in records])

    cpt_examples = [_quizjam_cpt_example(record) for record in records]
    answer_sft_examples = [_quizjam_answer_sft_example(record) for record in records]
    writer_sft_examples = [_quizjam_question_writer_example(record) for record in records]
    _write_jsonl(cpt_path, cpt_examples)
    _write_jsonl(answer_sft_path, answer_sft_examples)
    _write_jsonl(writer_sft_path, writer_sft_examples)
    _write_jsonl(
        mixed_path,
        [*cpt_examples, *answer_sft_examples, *writer_sft_examples],
    )
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(mixed_path),
                repeat=2,
                label="quizjam_train_mixed",
            )
        ],
    )

    warnings: list[str] = []
    if excluded_records:
        excluded_preview = ", ".join(str(record.number) for record in excluded_records[:10])
        if len(excluded_records) > 10:
            excluded_preview += ", ..."
        warnings.append(
            "Excluded "
            f"{len(excluded_records)} QuizJam records with relative time references from output datasets "
            f"(question numbers: {excluded_preview})."
        )
    if any(record.book_page is None for record in records):
        warnings.append("Some PDF pages did not expose a printed page number; section assignment may be incomplete.")
    if any(record.reading_tokens for record in records):
        warnings.append(
            "Furigana-sized tokens are preserved separately in reading_tokens, while training text uses a cleaned surface form."
        )

    output_paths = {
        "records": str(records_path),
        "cpt": str(cpt_path),
        "answer_sft": str(answer_sft_path),
        "question_writer_sft": str(writer_sft_path),
        "mixed": str(mixed_path),
        "manifest": str(manifest_path),
    }
    if copied_source_path is not None and copied_source_path.exists():
        output_paths["copied_pdf"] = str(copied_source_path)

    return PreparedDatasetReport(
        kind="quizjam_pdf",
        source_paths=[str(source_path)],
        output_paths=output_paths,
        total_records=len(records),
        warnings=warnings,
    )


def prepare_legal_corpus(
    *,
    input_paths: Iterable[str | Path],
    output_path: str | Path,
    kind: Literal["law", "case", "mixed"] = "mixed",
    source_label: str = "legal_corpus",
    max_chars: int = 1200,
    min_chars: int = 200,
) -> PreparedDatasetReport:
    resolved_inputs = [Path(path).expanduser().resolve() for path in input_paths]
    corpus_files = _collect_corpus_files(resolved_inputs)
    if not corpus_files:
        raise ValueError("No supported corpus files were found.")

    normalized_max_chars = max(200, max_chars)
    normalized_min_chars = min(max(50, min_chars), normalized_max_chars)
    output_path_obj = Path(output_path).expanduser().resolve()
    output_path_obj.parent.mkdir(parents=True, exist_ok=True)

    records: list[dict[str, Any]] = []
    for source_path in corpus_files:
        extracted_text = _read_corpus_text(source_path)
        normalized_text = _normalize_text(extracted_text)
        if not normalized_text:
            continue
        title = _infer_document_title(source_path, normalized_text)
        sections = _split_legal_text(
            text=normalized_text,
            kind=kind,
            max_chars=normalized_max_chars,
            min_chars=normalized_min_chars,
        )
        for chunk_index, section_text in enumerate(sections, start=1):
            records.append(
                {
                    "task_type": "cpt",
                    "text": _format_legal_cpt_text(
                        title=title,
                        section_text=section_text,
                        kind=kind,
                    ),
                    "focus": ["knowledge", "reasoning"],
                    "metadata": {
                        "source_label": source_label,
                        "kind": kind,
                        "source_file": str(source_path),
                        "title": title,
                        "chunk_index": chunk_index,
                    },
                }
            )

    if not records:
        raise ValueError("The provided legal corpus inputs did not yield any training text.")

    _write_jsonl(output_path_obj, records)
    return PreparedDatasetReport(
        kind="legal_corpus",
        source_paths=[str(path) for path in corpus_files],
        output_paths={"cpt": str(output_path_obj)},
        total_records=len(records),
        warnings=[],
    )


def prepare_egov_six_codes(
    *,
    output_dir: str | Path,
) -> PreparedDatasetReport:
    output_dir_path = Path(output_dir).expanduser().resolve()
    raw_dir = output_dir_path / "raw_xml"
    raw_dir.mkdir(parents=True, exist_ok=True)

    title_to_law_id = _fetch_egov_title_map()
    missing_titles = [title for title in EGOV_SIX_CODE_TITLES if title not in title_to_law_id]
    if missing_titles:
        raise ValueError(f"Missing e-Gov law ids for: {', '.join(missing_titles)}")

    structured_records: list[dict[str, Any]] = []
    cpt_records: list[dict[str, Any]] = []
    source_paths: list[str] = []
    for title in EGOV_SIX_CODE_TITLES:
        law_id = title_to_law_id[title]
        xml_text = _download_text(f"{EGOV_API_BASE_URL}/lawdata/{law_id}")
        xml_path = raw_dir / f"{law_id}.xml"
        xml_path.write_text(xml_text, encoding="utf-8")
        source_paths.append(str(xml_path))

        articles = _parse_egov_law_articles(xml_text, law_id=law_id)
        for article in articles:
            structured_records.append(article.model_dump())
            section_texts = _chunk_text_block(
                article.article_text,
                max_chars=EGOV_ARTICLE_CHUNK_MAX_CHARS,
                min_chars=EGOV_ARTICLE_CHUNK_MIN_CHARS,
            )
            for section_index, section_text in enumerate(section_texts, start=1):
                cpt_records.append(
                    {
                        "task_type": "cpt",
                        "text": _format_egov_article_text(
                            article,
                            section_text=section_text,
                            chunk_index=section_index,
                            chunk_count=len(section_texts),
                        ),
                        "focus": ["knowledge", "reasoning"],
                        "metadata": {
                            "source_label": "egov_six_codes",
                            "law_id": article.law_id,
                            "law_name": article.law_name,
                            "law_num": article.law_num,
                            "article_order": article.article_order,
                            "article_title": article.article_title,
                            "article_caption": article.article_caption,
                            "article_context": article.article_context,
                            "article_path": article.article_path,
                            "chunk_index": section_index,
                            "chunk_count": len(section_texts),
                            "record_kind": "article_chunk",
                        },
                    }
                )
            for paragraph_index, paragraph_text in enumerate(article.paragraph_texts, start=1):
                paragraph_label, paragraph_body = _split_egov_paragraph_text(
                    paragraph_text,
                    paragraph_index=paragraph_index,
                )
                paragraph_sections = _chunk_text_block(
                    paragraph_body,
                    max_chars=EGOV_PARAGRAPH_CHUNK_MAX_CHARS,
                    min_chars=EGOV_PARAGRAPH_CHUNK_MIN_CHARS,
                )
                for section_index, section_text in enumerate(paragraph_sections, start=1):
                    cpt_records.append(
                        {
                            "task_type": "cpt",
                            "text": _format_egov_paragraph_text(
                                article,
                                paragraph_label=paragraph_label,
                                paragraph_text=section_text,
                                paragraph_index=paragraph_index,
                                chunk_index=section_index,
                                chunk_count=len(paragraph_sections),
                            ),
                            "focus": ["knowledge", "reasoning"],
                            "metadata": {
                                "source_label": "egov_six_codes",
                                "law_id": article.law_id,
                                "law_name": article.law_name,
                                "law_num": article.law_num,
                                "article_order": article.article_order,
                                "article_title": article.article_title,
                                "article_caption": article.article_caption,
                                "article_context": article.article_context,
                                "article_path": article.article_path,
                                "paragraph_index": paragraph_index,
                                "paragraph_label": paragraph_label,
                                "paragraph_chunk_index": section_index,
                                "paragraph_chunk_count": len(paragraph_sections),
                                "record_kind": "paragraph",
                            },
                        }
                    )

    articles_path = output_dir_path / "six_codes_articles.jsonl"
    cpt_path = output_dir_path / "six_codes_cpt.jsonl"
    manifest_path = output_dir_path / "six_codes_train_manifest.json"
    _write_jsonl(articles_path, structured_records)
    _write_jsonl(cpt_path, cpt_records)
    write_sequential_cpt_manifest(
        manifest_path,
        datasets=[
            SequentialCptSource(
                path=str(cpt_path),
                repeat=3,
                label="egov_six_codes",
            )
        ],
    )

    warnings: list[str] = [
        "This dataset is article-centered CPT. Add case law and explanatory prose separately if you want stronger legal explanation behavior."
    ]
    return PreparedDatasetReport(
        kind="egov_six_codes",
        source_paths=source_paths,
        output_paths={
            "articles": str(articles_path),
            "cpt": str(cpt_path),
            "manifest": str(manifest_path),
            "raw_xml_dir": str(raw_dir),
        },
        total_records=len(cpt_records),
        warnings=warnings,
    )


def _parse_quizjam_page_words(
    *,
    words: list[dict[str, Any]],
    page_width: float,
    page_height: float,
    pdf_page_index: int,
) -> list[QuizJamQuestion]:
    normalized_words: list[PositionedWord] = [
        {
            "text": str(word.get("text", "")).strip(),
            "x0": float(word.get("x0", 0.0)),
            "x1": float(word.get("x1", 0.0)),
            "top": float(word.get("top", 0.0)),
            "bottom": float(word.get("bottom", 0.0)),
            "size": float(word.get("size", 0.0)),
        }
        for word in words
        if str(word.get("text", "")).strip()
    ]
    if not normalized_words:
        return []

    printed_page_word = _extract_printed_page_number_word(
        words=normalized_words,
        page_width=page_width,
        page_height=page_height,
    )
    if printed_page_word is not None:
        normalized_words = [word for word in normalized_words if word is not printed_page_word]

    content_bottom_limit = page_height - 5.0
    column_boundary = page_width * 0.68
    left_words = [word for word in normalized_words if word["x0"] < column_boundary and word["top"] < content_bottom_limit]
    right_words = [word for word in normalized_words if word["x0"] >= column_boundary and word["top"] < content_bottom_limit]
    numbered_words = [
        word
        for word in left_words
        if word["size"] >= 8.0 and QUESTION_NUMBER_PATTERN.match(word["text"])
    ]
    numbered_words.sort(key=lambda word: (word["top"], word["x0"]))
    if not numbered_words:
        return []

    printed_page_number = int(printed_page_word["text"]) if printed_page_word is not None else None
    section = _quizjam_section_for_book_page(printed_page_number)
    records: list[QuizJamQuestion] = []

    for index, number_word in enumerate(numbered_words):
        next_top = numbered_words[index + 1]["top"] if index + 1 < len(numbered_words) else content_bottom_limit
        block_top = max(0.0, number_word["top"] - 6.0)
        block_bottom = next_top - 6.0

        question_words = [
            word
            for word in left_words
            if block_top <= word["top"] < block_bottom and word is not number_word
        ]
        answer_words = [
            word
            for word in right_words
            if block_top <= word["top"] < block_bottom
        ]

        question_raw = _render_words(question_words)
        question_clean = _normalize_text(
            _render_words([word for word in question_words if word["size"] >= 8.0])
        )
        answer_lines, note_lines = _split_answer_and_notes(answer_words)
        answer_raw = "\n".join(answer_lines)
        answer_clean = _normalize_text("".join(answer_lines))
        reading_tokens = [
            word["text"]
            for word in sorted(question_words, key=lambda word: (word["top"], word["x0"]))
            if word["size"] < 8.0 and _looks_like_furigana(word["text"])
        ]

        if not question_clean or not answer_clean:
            continue

        question_number = int(number_word["text"].replace(".", ""))
        records.append(
            QuizJamQuestion(
                number=question_number,
                pdf_page_index=pdf_page_index,
                book_page=printed_page_number,
                section=section,
                question_raw=question_raw,
                question_clean=question_clean,
                answer_raw=answer_raw,
                answer_clean=answer_clean,
                notes=note_lines,
                reading_tokens=reading_tokens,
            )
        )

    return records


def _split_answer_and_notes(words: list[PositionedWord]) -> tuple[list[str], list[str]]:
    if not words:
        return [], []
    lines = _rendered_lines(words)
    answer_lines: list[str] = []
    note_lines: list[str] = []
    current_note = ""
    for line in lines:
        normalized_line = _normalize_text(line["text"])
        if not normalized_line:
            continue
        note_like = _is_note_like_line(normalized_line)
        if note_like:
            current_note += normalized_line
            continue
        if _is_small_furigana_line(line):
            continue
        if current_note:
            note_lines.append(current_note)
            current_note = ""
        answer_lines.append(normalized_line)
    if current_note:
        note_lines.append(current_note)
    return answer_lines, note_lines


def _extract_printed_page_number(
    *,
    words: list[PositionedWord],
    page_width: float,
    page_height: float,
) -> int | None:
    page_number_word = _extract_printed_page_number_word(
        words=words,
        page_width=page_width,
        page_height=page_height,
    )
    if page_number_word is None:
        return None
    return int(page_number_word["text"])


def _extract_printed_page_number_word(
    *,
    words: list[PositionedWord],
    page_width: float,
    page_height: float,
) -> PositionedWord | None:
    candidates = [
        word
        for word in words
        if word["top"] >= page_height - 60.0 and word["text"].isdigit()
    ]
    if not candidates:
        return None
    page_center = page_width / 2.0
    candidates.sort(key=lambda word: (abs(((word["x0"] + word["x1"]) / 2.0) - page_center), word["top"]))
    return candidates[0]


def _group_rendered_lines(words: list[PositionedWord], tolerance: float = 3.0) -> list[str]:
    grouped: list[list[PositionedWord]] = []
    for word in sorted(words, key=lambda item: (item["top"], item["x0"])):
        if not grouped or abs(grouped[-1][0]["top"] - word["top"]) > tolerance:
            grouped.append([word])
        else:
            grouped[-1].append(word)
    return [_join_word_tokens([word["text"] for word in line]) for line in grouped]


def _render_words(words: list[PositionedWord]) -> str:
    return "\n".join(line for line in _group_rendered_lines(words) if line)


def _rendered_lines(words: list[PositionedWord], tolerance: float = 3.0) -> list[RenderedLine]:
    grouped: list[list[PositionedWord]] = []
    for word in sorted(words, key=lambda item: (item["top"], item["x0"])):
        if not grouped or abs(grouped[-1][0]["top"] - word["top"]) > tolerance:
            grouped.append([word])
        else:
            grouped[-1].append(word)
    rendered: list[RenderedLine] = []
    for line_words in grouped:
        text = _join_word_tokens([word["text"] for word in line_words])
        if not text:
            continue
        rendered.append(
            {
                "text": text,
                "average_size": sum(word["size"] for word in line_words) / len(line_words),
            }
        )
    return rendered


def _join_word_tokens(tokens: list[str]) -> str:
    pieces: list[str] = []
    for token in tokens:
        cleaned_token = token.strip()
        if not cleaned_token:
            continue
        if not pieces:
            pieces.append(cleaned_token)
            continue
        previous = pieces[-1]
        if _needs_space(previous[-1], cleaned_token[0]):
            pieces.append(f" {cleaned_token}")
        else:
            pieces.append(cleaned_token)
    return _normalize_text("".join(pieces))


def _needs_space(previous_char: str, next_char: str) -> bool:
    return bool(ASCII_WORD_PATTERN.match(previous_char) and ASCII_WORD_PATTERN.match(next_char))


def _looks_like_furigana(text: str) -> bool:
    compact = text.strip()
    return bool(compact) and len(compact) <= 24 and HIRAGANA_PATTERN.fullmatch(compact) is not None


def _is_small_furigana_line(line: RenderedLine) -> bool:
    return line["average_size"] < 8.0 and _looks_like_furigana(line["text"])


def _is_note_like_line(text: str) -> bool:
    normalized = _normalize_text(text)
    if not normalized:
        return False
    return any(marker in normalized for marker in ("【", "】", "〇", "◯", "△", "×"))


def _normalize_text(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text)
    normalized = normalized.replace("⽤", "用")
    normalized = normalized.replace("\u3000", " ")
    normalized = normalized.replace("\r\n", "\n").replace("\r", "\n")
    normalized = SPACE_PATTERN.sub(" ", normalized)
    normalized = JAPANESE_INLINE_SPACE_PATTERN.sub("", normalized)
    normalized = WHITESPACE_BEFORE_PUNCTUATION_PATTERN.sub(r"\1", normalized)
    normalized = WHITESPACE_AFTER_OPENING_BRACKET_PATTERN.sub(r"\1", normalized)
    return normalized.strip()


def _quizjam_section_for_book_page(book_page: int | None) -> str | None:
    if book_page is None:
        return None
    if 2 <= book_page < 22:
        return "season1"
    if 22 <= book_page < 42:
        return "season2"
    if 42 <= book_page < 62:
        return "season3"
    if book_page >= 62:
        return "real_quizjam"
    return None


def _filter_quizjam_training_records(
    records: list[QuizJamQuestion],
) -> tuple[list[QuizJamQuestion], list[QuizJamQuestion]]:
    kept_records: list[QuizJamQuestion] = []
    excluded_records: list[QuizJamQuestion] = []
    for record in records:
        if _is_quizjam_relative_time_question(record.question_clean):
            excluded_records.append(record)
            continue
        kept_records.append(record)
    return kept_records, excluded_records


def _is_quizjam_relative_time_question(question: str) -> bool:
    normalized_question = _normalize_text(question)
    return QUIZJAM_RELATIVE_TIME_PATTERN.search(normalized_question) is not None


def _quizjam_cpt_example(record: QuizJamQuestion) -> dict[str, Any]:
    statement = _rewrite_question_as_statement(
        question=record.question_clean,
        answer=record.answer_clean,
    )
    text_parts = [
        f"項目: {record.answer_clean}",
        f"知識: {statement}",
        f"クイズの問い: {record.question_clean}",
    ]
    if record.notes:
        text_parts.append(f"判定メモ: {' '.join(record.notes)}")
    return {
        "task_type": "cpt",
        "text": "\n".join(text_parts),
        "focus": ["knowledge", "reasoning"],
        "metadata": _quizjam_metadata(record, task="knowledge_card"),
    }


def _quizjam_answer_sft_example(record: QuizJamQuestion) -> dict[str, Any]:
    return {
        "task_type": "chat_sft",
        "messages": [
            {
                "role": "system",
                "content": (
                    "You answer Japanese quiz questions. Think through the clue structure first, then return the best concise answer."
                ),
            },
            {
                "role": "user",
                "content": record.question_clean,
            },
            {
                "role": "assistant",
                "reasoning_content": _quiz_reasoning_trace(record.question_clean),
                "content": record.answer_clean,
            },
        ],
        "focus": ["knowledge", "reasoning", "multiturn"],
        "metadata": _quizjam_metadata(record, task="answer_question"),
    }


def _quizjam_question_writer_example(record: QuizJamQuestion) -> dict[str, Any]:
    return {
        "task_type": "chat_sft",
        "messages": [
            {
                "role": "system",
                "content": (
                    "You write fair Japanese quiz questions from a target answer. "
                    "Use clue-based wording instead of parroting the answer, and return only the question text."
                ),
            },
            {
                "role": "user",
                "content": f"答えが「{record.answer_clean}」になるクイズを一問作成してください。",
            },
            {
                "role": "assistant",
                "content": record.question_clean,
            },
        ],
        "focus": ["knowledge", "reasoning", "style"],
        "metadata": _quizjam_metadata(record, task="write_question"),
    }


def _quizjam_metadata(record: QuizJamQuestion, *, task: str) -> dict[str, Any]:
    return {
        "task": task,
        "question_number": record.number,
        "pdf_page_index": record.pdf_page_index,
        "book_page": record.book_page,
        "section": record.section,
        "notes": record.notes,
        "reading_tokens": record.reading_tokens,
        "question_raw": record.question_raw,
        "answer_raw": record.answer_raw,
        "source": "quizjam_official_problem_book",
    }


def _quiz_reasoning_trace(question: str) -> str:
    clue = question.rstrip("？?。")
    clue = clue[:80] + "..." if len(clue) > 80 else clue
    return (
        "1. 問われている対象の種類を見極める。 "
        f"2. 問題文の決め手は「{clue}」である。 "
        "3. 条件に一致する候補を一つに絞って答える。"
    )


def _rewrite_question_as_statement(*, question: str, answer: str) -> str:
    patterns = [
        (r"^(.*)を何という\?$", r"\1を" + answer + "という。"),
        (r"^(.*)を何という？$", r"\1を" + answer + "という。"),
        (r"^(.*)は何という\?$", r"\1は" + answer + "という。"),
        (r"^(.*)は何という？$", r"\1は" + answer + "という。"),
        (r"^(.*)は誰\?$", r"\1は" + answer + "である。"),
        (r"^(.*)は誰？$", r"\1は" + answer + "である。"),
        (r"^(.*)は何\?$", r"\1は" + answer + "である。"),
        (r"^(.*)は何？$", r"\1は" + answer + "である。"),
        (r"^(.*)はどこ\?$", r"\1は" + answer + "である。"),
        (r"^(.*)はどこ？$", r"\1は" + answer + "である。"),
        (r"^(.*)はどれ\?$", r"\1は" + answer + "である。"),
        (r"^(.*)はどれ？$", r"\1は" + answer + "である。"),
    ]
    normalized_question = question.strip()
    for pattern, replacement in patterns:
        if re.match(pattern, normalized_question):
            return re.sub(pattern, replacement, normalized_question)
    return f"問題「{normalized_question}」の正答は{answer}である。"


def _collect_corpus_files(paths: list[Path]) -> list[Path]:
    collected: list[Path] = []
    for path in paths:
        if path.is_file() and path.suffix.lower() in SUPPORTED_CORPUS_SUFFIXES:
            collected.append(path)
            continue
        if not path.is_dir():
            continue
        for child in sorted(path.rglob("*")):
            if child.is_file() and child.suffix.lower() in SUPPORTED_CORPUS_SUFFIXES:
                collected.append(child)
    return collected


def _read_corpus_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md"}:
        return path.read_text(encoding="utf-8")
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    if suffix in {".html", ".htm"}:
        return _strip_html(path.read_text(encoding="utf-8"))
    if suffix == ".xml":
        try:
            root = ElementTree.fromstring(path.read_text(encoding="utf-8"))
            return "".join(root.itertext())
        except ElementTree.ParseError:
            return _strip_html(path.read_text(encoding="utf-8"))
    if suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        return _flatten_json_text(payload)
    if suffix == ".jsonl":
        texts: list[str] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                texts.append(line)
                continue
            texts.append(_flatten_json_text(payload))
        return "\n".join(texts)
    raise ValueError(f"Unsupported corpus file type: {path}")


def _strip_html(text: str) -> str:
    stripper = _TagStripper()
    stripper.feed(text)
    return stripper.text()


def _flatten_json_text(payload: Any) -> str:
    if isinstance(payload, str):
        return payload
    if isinstance(payload, list):
        pieces = [_flatten_json_text(item) for item in payload]
        return "\n".join(piece for piece in pieces if piece)
    if isinstance(payload, dict):
        pieces = [
            _flatten_json_text(value)
            for key, value in payload.items()
            if key.lower() not in {"url", "id"}
        ]
        return "\n".join(piece for piece in pieces if piece)
    return ""


def _infer_document_title(path: Path, text: str) -> str:
    for line in text.splitlines():
        normalized_line = _normalize_text(line)
        if normalized_line:
            return normalized_line[:120]
    return path.stem


def _split_legal_text(
    *,
    text: str,
    kind: Literal["law", "case", "mixed"],
    max_chars: int,
    min_chars: int,
) -> list[str]:
    if kind == "law":
        base_segments = _regex_split_preserving_delimiter(text, ARTICLE_HEADING_PATTERN)
    elif kind == "case":
        base_segments = _regex_split_preserving_delimiter(text, CASE_HEADING_PATTERN)
    else:
        base_segments = _regex_split_preserving_delimiter(text, ARTICLE_HEADING_PATTERN)
        if len(base_segments) <= 1:
            base_segments = _regex_split_preserving_delimiter(text, CASE_HEADING_PATTERN)

    cleaned_segments = [_normalize_text(segment) for segment in base_segments if _normalize_text(segment)]
    if not cleaned_segments:
        cleaned_segments = [_normalize_text(text)]

    if kind in {"law", "case"} and len(cleaned_segments) > 1:
        segmented_chunks: list[str] = []
        for segment in cleaned_segments:
            if len(segment) > max_chars:
                segmented_chunks.extend(_chunk_long_segment(segment, max_chars=max_chars))
            else:
                segmented_chunks.append(segment)
        return [chunk for chunk in segmented_chunks if chunk]

    chunks: list[str] = []
    buffer = ""
    for segment in cleaned_segments:
        if not buffer:
            buffer = segment
            continue
        if len(buffer) + 2 + len(segment) <= max_chars:
            buffer = f"{buffer}\n\n{segment}"
            continue
        if len(buffer) >= min_chars:
            chunks.append(buffer)
            buffer = segment
            continue
        combined = f"{buffer}\n\n{segment}"
        if len(combined) <= max_chars:
            buffer = combined
        else:
            chunks.extend(_chunk_long_segment(combined, max_chars=max_chars))
            buffer = ""
    if buffer:
        if len(buffer) > max_chars:
            chunks.extend(_chunk_long_segment(buffer, max_chars=max_chars))
        else:
            chunks.append(buffer)
    return [chunk for chunk in chunks if chunk]


def _regex_split_preserving_delimiter(text: str, pattern: re.Pattern[str]) -> list[str]:
    pieces = pattern.split(text)
    if len(pieces) <= 1:
        return [text]
    segments: list[str] = []
    current = ""
    for piece in pieces:
        normalized_piece = _normalize_text(piece)
        if not normalized_piece:
            continue
        if pattern.match(normalized_piece):
            if current:
                segments.append(current)
            current = normalized_piece
        else:
            current = f"{current}\n{normalized_piece}".strip()
    if current:
        segments.append(current)
    return segments


def _chunk_long_segment(segment: str, *, max_chars: int) -> list[str]:
    lines = [line for line in segment.splitlines() if line.strip()]
    chunks: list[str] = []
    buffer = ""
    for line in lines:
        units = _split_chunk_units(line, max_chars=max_chars)
        for unit in units:
            candidate = f"{buffer}\n{unit}".strip() if buffer else unit
            if len(candidate) <= max_chars:
                buffer = candidate
                continue
            if buffer:
                chunks.append(buffer)
            buffer = unit
    if buffer:
        chunks.append(buffer)
    return chunks


def _chunk_text_block(text: str, *, max_chars: int, min_chars: int) -> list[str]:
    normalized = _normalize_text(text)
    if not normalized:
        return []
    sentence_units = _split_chunk_units(normalized, max_chars=max_chars)
    chunks: list[str] = []
    buffer = ""
    for unit in sentence_units:
        candidate = f"{buffer}\n{unit}".strip() if buffer else unit
        if len(candidate) <= max_chars:
            buffer = candidate
            continue
        if buffer and len(buffer) >= min_chars:
            chunks.append(buffer)
            buffer = unit
            continue
        if buffer:
            merged = f"{buffer}\n{unit}".strip()
            chunks.extend(_split_chunk_units(merged, max_chars=max_chars))
            buffer = ""
            continue
        chunks.extend(_split_chunk_units(unit, max_chars=max_chars))
    if buffer:
        chunks.append(buffer)
    return [chunk for chunk in chunks if chunk]


def _split_chunk_units(text: str, *, max_chars: int) -> list[str]:
    normalized = _normalize_text(text)
    if not normalized:
        return []
    sentence_units = [
        unit
        for unit in LEGAL_SENTENCE_BOUNDARY_PATTERN.split(normalized)
        if unit
    ]
    if len(sentence_units) <= 1:
        return _split_oversized_text(normalized, max_chars=max_chars)

    units: list[str] = []
    for unit in sentence_units:
        if len(unit) <= max_chars:
            units.append(unit)
            continue
        units.extend(_split_oversized_text(unit, max_chars=max_chars))
    return units


def _split_oversized_text(text: str, *, max_chars: int) -> list[str]:
    normalized = _normalize_text(text)
    if len(normalized) <= max_chars:
        return [normalized]
    separators = ["。", "；", ";", "、", "，", ",", " "]
    chunks: list[str] = []
    remaining = normalized
    lower_bound = max(max_chars // 2, 1)
    while len(remaining) > max_chars:
        split_index = -1
        window = remaining[: max_chars + 1]
        for separator in separators:
            candidate = window.rfind(separator)
            if candidate >= lower_bound:
                split_index = max(split_index, candidate + 1)
        if split_index <= 0:
            split_index = max_chars
        chunks.append(remaining[:split_index].strip())
        remaining = remaining[split_index:].strip()
    if remaining:
        chunks.append(remaining)
    return [chunk for chunk in chunks if chunk]


def _format_legal_cpt_text(*, title: str, section_text: str, kind: Literal["law", "case", "mixed"]) -> str:
    heading = {
        "law": "法令継続事前学習コーパス",
        "case": "判例継続事前学習コーパス",
        "mixed": "法令・判例継続事前学習コーパス",
    }[kind]
    return f"{heading}\n資料名: {title}\n\n{section_text}"


def _write_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def _fetch_egov_title_map() -> dict[str, str]:
    xml_text = _download_text(f"{EGOV_API_BASE_URL}/lawlists/1")
    root = ElementTree.fromstring(xml_text)
    title_to_law_id: dict[str, str] = {}
    for law_info in root.findall(".//LawNameListInfo"):
        law_name = _normalize_text(law_info.findtext("LawName") or "")
        law_id = _normalize_text(law_info.findtext("LawId") or "")
        if law_name and law_id:
            title_to_law_id[law_name] = law_id
    return title_to_law_id


def _download_text(url: str) -> str:
    with urllib.request.urlopen(url, timeout=60) as response:
        payload = cast(bytes, response.read())
    return payload.decode("utf-8")


def _parse_egov_law_articles(xml_text: str, *, law_id: str) -> list[EgovLawArticle]:
    root = ElementTree.fromstring(xml_text)
    law = root.find(".//Law")
    if law is None:
        raise ValueError(f"e-Gov lawdata for {law_id} did not contain a Law node.")
    law_num = _normalize_text(law.findtext("./LawNum") or "")
    law_name = _normalize_text(law.findtext(".//LawTitle") or "")

    articles: list[EgovLawArticle] = []
    article_order = 0
    preamble = law.find(".//Preamble")
    if preamble is not None:
        preamble_paragraphs = _extract_egov_paragraph_texts(preamble)
        preamble_text = "\n".join(preamble_paragraphs) if preamble_paragraphs else _normalize_text("".join(preamble.itertext()))
        if preamble_text:
            article_order += 1
            articles.append(
                EgovLawArticle(
                    law_id=law_id,
                    law_name=law_name,
                    law_num=law_num or None,
                    article_order=article_order,
                    article_title="前文",
                    article_caption=None,
                    article_context="前文",
                    article_path=["前文"],
                    article_text=preamble_text,
                    paragraph_texts=preamble_paragraphs,
                )
            )

    law_body = law.find("./LawBody")
    if law_body is not None:
        article_order = _collect_egov_articles(
            node=law_body,
            law_id=law_id,
            law_name=law_name,
            law_num=law_num or None,
            context=[],
            articles=articles,
            article_order=article_order,
        )
    return articles


def _collect_egov_articles(
    *,
    node: ElementTree.Element,
    law_id: str,
    law_name: str,
    law_num: str | None,
    context: list[str],
    articles: list[EgovLawArticle],
    article_order: int,
) -> int:
    for child in list(node):
        if child.tag == "Article":
            article = _build_egov_article(
                article_node=child,
                law_id=law_id,
                law_name=law_name,
                law_num=law_num,
                context=context,
                article_order=article_order + 1,
            )
            if article is None:
                continue
            articles.append(article)
            article_order += 1
            continue
        child_context = list(context)
        context_label = _egov_context_label(child)
        if context_label:
            child_context.append(context_label)
        article_order = _collect_egov_articles(
            node=child,
            law_id=law_id,
            law_name=law_name,
            law_num=law_num,
            context=child_context,
            articles=articles,
            article_order=article_order,
        )
    return article_order


def _build_egov_article(
    *,
    article_node: ElementTree.Element,
    law_id: str,
    law_name: str,
    law_num: str | None,
    context: list[str],
    article_order: int,
) -> EgovLawArticle | None:
    article_title = _normalize_text(article_node.findtext("./ArticleTitle") or "")
    if not article_title:
        return None
    article_caption = _normalize_text(article_node.findtext("./ArticleCaption") or "")
    paragraph_texts = _extract_egov_paragraph_texts(article_node)
    body_parts = paragraph_texts or _extract_egov_body_parts(article_node)
    article_text = "\n".join(body_parts)
    if not article_text:
        return None
    article_path = [*context, article_title]
    article_context = " > ".join(context) if context else "本則"
    return EgovLawArticle(
        law_id=law_id,
        law_name=law_name,
        law_num=law_num,
        article_order=article_order,
        article_title=article_title,
        article_caption=article_caption or None,
        article_context=article_context,
        article_path=article_path,
        article_text=article_text,
        paragraph_texts=paragraph_texts,
    )


def _egov_context_label(node: ElementTree.Element) -> str | None:
    if node.tag == "MainProvision":
        return "本則"
    title_map = {
        "Part": "PartTitle",
        "Chapter": "ChapterTitle",
        "Section": "SectionTitle",
        "Subsection": "SubsectionTitle",
        "Division": "DivisionTitle",
    }
    if node.tag == "SupplProvision":
        label = _normalize_text(node.findtext("./SupplProvisionLabel") or "附則")
        amend_law_num = _normalize_text(node.attrib.get("AmendLawNum", ""))
        if amend_law_num:
            return f"{label} [{amend_law_num}]"
        return label
    title_tag = title_map.get(node.tag)
    if title_tag is None:
        return None
    title_text = _normalize_text(node.findtext(f"./{title_tag}") or "")
    return title_text or None


def _extract_egov_paragraph_texts(node: ElementTree.Element) -> list[str]:
    paragraph_texts: list[str] = []
    for child in list(node):
        if child.tag != "Paragraph":
            continue
        paragraph_text = _normalize_text("".join(child.itertext()))
        paragraph_num_text = _normalize_text(child.findtext("./ParagraphNum") or "")
        if paragraph_num_text and paragraph_text.startswith(paragraph_num_text):
            paragraph_text = _normalize_text(paragraph_text[len(paragraph_num_text) :])
        if not paragraph_text:
            continue
        paragraph_num = _normalize_text(child.attrib.get("Num", "1")) or "1"
        paragraph_texts.append(f"{_format_paragraph_label(paragraph_num)}: {paragraph_text}")
    return paragraph_texts


def _split_egov_paragraph_text(
    paragraph_text: str,
    *,
    paragraph_index: int,
) -> tuple[str, str]:
    normalized = _normalize_text(paragraph_text)
    if not normalized:
        fallback_label = _format_paragraph_label(str(paragraph_index))
        return fallback_label, ""
    for separator in (":", "："):
        if separator in normalized:
            candidate_label, candidate_body = normalized.split(separator, 1)
            label = _normalize_text(candidate_label)
            body = _normalize_text(candidate_body)
            if label and body:
                return label, body
    label_match = re.match(r"^(第[^\s:：]+項)\s*(.*)$", normalized)
    if label_match:
        label = _normalize_text(label_match.group(1))
        body = _normalize_text(label_match.group(2))
        if label and body:
            return label, body
    fallback_label = _format_paragraph_label(str(paragraph_index))
    return fallback_label, normalized


def _extract_egov_body_parts(node: ElementTree.Element) -> list[str]:
    body_parts: list[str] = []
    for child in list(node):
        if child.tag in {"ArticleTitle", "ArticleCaption"}:
            continue
        child_text = _normalize_text("".join(child.itertext()))
        if child_text:
            body_parts.append(child_text)
    return body_parts


def _format_paragraph_label(paragraph_num: str) -> str:
    if paragraph_num.isdigit():
        return f"第{_int_to_kanji(int(paragraph_num))}項"
    return f"{paragraph_num}項"


def _int_to_kanji(value: int) -> str:
    if value <= 0:
        return str(value)
    numerals = {0: "零", 1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "七", 8: "八", 9: "九"}
    units = [(1000, "千"), (100, "百"), (10, "十")]
    remaining = value
    parts: list[str] = []
    for unit_value, unit_label in units:
        digit, remaining = divmod(remaining, unit_value)
        if digit == 0:
            continue
        if digit > 1:
            parts.append(numerals[digit])
        parts.append(unit_label)
    if remaining > 0:
        parts.append(numerals[remaining])
    return "".join(parts) or numerals[0]


def _format_egov_article_text(
    article: EgovLawArticle,
    *,
    section_text: str | None = None,
    chunk_index: int | None = None,
    chunk_count: int | None = None,
) -> str:
    parts = [
        "法令継続事前学習コーパス",
        f"法令名: {article.law_name}",
    ]
    if article.law_num:
        parts.append(f"法令番号: {article.law_num}")
    parts.append(f"条文: {article.article_title}")
    if article.article_caption:
        parts.append(f"見出し: {article.article_caption}")
    parts.append(f"条項パス: {_format_egov_path(article.article_path)}")
    if (
        chunk_index is not None
        and chunk_count is not None
        and chunk_count > 1
    ):
        parts.append(f"本文断片: {chunk_index}/{chunk_count}")
    parts.append("本文:")
    parts.append(section_text if section_text is not None else article.article_text)
    return "\n".join(parts)


def _format_egov_paragraph_text(
    article: EgovLawArticle,
    *,
    paragraph_label: str,
    paragraph_text: str,
    paragraph_index: int,
    chunk_index: int | None = None,
    chunk_count: int | None = None,
) -> str:
    parts = [
        "法令継続事前学習コーパス",
        f"法令名: {article.law_name}",
    ]
    if article.law_num:
        parts.append(f"法令番号: {article.law_num}")
    parts.append(f"条文: {article.article_title}")
    if article.article_caption:
        parts.append(f"見出し: {article.article_caption}")
    parts.append(f"条項パス: {_format_egov_path([*article.article_path, paragraph_label])}")
    parts.append(f"項番号: {paragraph_label}")
    if (
        chunk_index is not None
        and chunk_count is not None
        and chunk_count > 1
    ):
        parts.append(f"項本文断片: {chunk_index}/{chunk_count}")
    parts.append("本文:")
    parts.append(f"{paragraph_label}: {paragraph_text}")
    return "\n".join(parts)


def _format_egov_path(path_parts: list[str]) -> str:
    cleaned_parts = [_normalize_text(part) for part in path_parts if _normalize_text(part)]
    return " > ".join(cleaned_parts)
