from __future__ import annotations

import copy
import json
import re
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx
from pydantic import BaseModel, Field

from .tool_search import ToolRegistry
from .wikipedia_tool import wikipedia_tool_output


class ToolExecutionRequest(BaseModel):
    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class ToolExecutionResponse(BaseModel):
    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    output: str
    output_json: Any | None = None


class ToolExecutor:
    def __init__(self, tool_registry: ToolRegistry | None = None) -> None:
        self._tool_registry = tool_registry

    def execute(self, *, name: str, arguments: dict[str, Any]) -> str | None:
        tool = self._tool_registry.get_tool(name) if self._tool_registry is not None else None
        if tool is not None and tool.server_handler is not None:
            return self._execute_handler(tool.server_handler, arguments)

        builtin_name = _builtin_name_for_tool(name)
        if builtin_name is None:
            return None
        return self._execute_builtin(builtin_name, arguments)

    def list_tools(self) -> list[dict[str, Any]]:
        if self._tool_registry is None:
            return []
        return self._tool_registry.all_tools()

    def _execute_handler(self, handler: dict[str, Any], arguments: dict[str, Any]) -> str:
        handler_type = handler.get("type")
        if handler_type == "builtin":
            builtin_name = handler.get("name")
            if not isinstance(builtin_name, str):
                raise ValueError("builtin tool handler requires a name.")
            return self._execute_builtin(builtin_name, arguments)
        if handler_type == "http_json":
            return self._execute_http_json(handler, arguments)
        if handler_type == "static_json":
            payload = _render_template(handler.get("value", {}), arguments)
            return json.dumps(payload, ensure_ascii=False)
        raise ValueError(f"Unsupported server_handler type: {handler_type}")

    def _execute_builtin(self, name: str, arguments: dict[str, Any]) -> str:
        if name == "tool_search":
            return self._execute_tool_search(arguments)
        if name == "wikipedia_search":
            return wikipedia_tool_output(arguments)
        if name == "current_time":
            return _current_time_tool_output(arguments)
        raise ValueError(f"Unsupported builtin tool handler: {name}")

    def _execute_tool_search(self, arguments: dict[str, Any]) -> str:
        if self._tool_registry is None:
            raise ValueError("tool_search requires a loaded tool registry.")
        query = arguments.get("query", arguments.get("goal"))
        if not isinstance(query, str) or not query.strip():
            raise ValueError("tool_search requires query or goal.")
        limit_raw = arguments.get("limit", 5)
        try:
            limit = max(1, int(limit_raw))
        except (TypeError, ValueError):
            limit = 5
        return json.dumps(
            {
                "query": query,
                "limit": limit,
                "results": [
                    hit.model_dump()
                    for hit in self._tool_registry.search(query=query, limit=limit)
                ],
            },
            ensure_ascii=False,
        )

    def _execute_http_json(self, handler: dict[str, Any], arguments: dict[str, Any]) -> str:
        url = _render_template(handler.get("url"), arguments)
        if not isinstance(url, str) or not url:
            raise ValueError("http_json tool handler requires a url.")
        method = str(handler.get("method", "GET")).upper()
        headers = _render_template(handler.get("headers", {}), arguments)
        params = _render_template(handler.get("params", {}), arguments)
        json_body = _render_template(handler.get("json"), arguments)
        timeout_sec = handler.get("timeout_sec", 20.0)
        try:
            timeout = float(timeout_sec)
        except (TypeError, ValueError):
            timeout = 20.0

        request_headers = headers if isinstance(headers, dict) else {}
        request_params = params if isinstance(params, dict) else {}
        request_json = json_body if json_body is not None else None
        with httpx.Client(timeout=httpx.Timeout(timeout), headers=request_headers) as client:
            response = client.request(
                method,
                url,
                params=request_params,
                json=request_json,
            )
            response.raise_for_status()

            response_format = handler.get("response_format", "json")
            if response_format == "text":
                return response.text

            payload = response.json()
            result_path = handler.get("result_path")
            if isinstance(result_path, str) and result_path:
                payload = _lookup_json_path(payload, result_path)
            return json.dumps(payload, ensure_ascii=False)


def parse_tool_output_json(output: str) -> Any | None:
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        return None


def _builtin_name_for_tool(name: str) -> str | None:
    alias_map = {
        "tool_search": "tool_search",
        "search_tools": "tool_search",
        "wikipedia_search": "wikipedia_search",
        "search_wikipedia": "wikipedia_search",
        "current_time": "current_time",
        "get_current_time": "current_time",
    }
    return alias_map.get(name)


def _current_time_tool_output(arguments: dict[str, Any]) -> str:
    timezone_name = arguments.get("timezone", "UTC")
    if not isinstance(timezone_name, str) or not timezone_name.strip():
        timezone_name = "UTC"
    try:
        zone = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown timezone: {timezone_name}") from exc
    now = datetime.now(zone)
    return json.dumps(
        {
            "timezone": timezone_name,
            "iso8601": now.isoformat(),
            "unix": int(now.timestamp()),
        },
        ensure_ascii=False,
    )


_TEMPLATE_PATTERN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


def _render_template(value: Any, arguments: dict[str, Any]) -> Any:
    if isinstance(value, str):
        exact_match = _TEMPLATE_PATTERN.fullmatch(value)
        if exact_match:
            return copy.deepcopy(arguments.get(exact_match.group(1)))
        return _TEMPLATE_PATTERN.sub(
            lambda match: str(arguments.get(match.group(1), "")),
            value,
        )
    if isinstance(value, list):
        return [_render_template(item, arguments) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _render_template(item, arguments)
            for key, item in value.items()
        }
    return copy.deepcopy(value)


def _lookup_json_path(value: Any, path: str) -> Any:
    current = value
    for part in path.split("."):
        if not part:
            continue
        if isinstance(current, dict):
            current = current.get(part)
            continue
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return None
            continue
        return None
    return current
