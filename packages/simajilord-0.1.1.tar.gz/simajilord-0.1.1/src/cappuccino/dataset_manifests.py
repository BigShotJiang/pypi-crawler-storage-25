from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator, Literal

from pydantic import BaseModel, Field


class SequentialCptSource(BaseModel):
    path: str
    repeat: int = Field(default=1, ge=1)
    label: str | None = None


class SequentialCptManifest(BaseModel):
    kind: Literal["sequential_cpt_manifest"] = "sequential_cpt_manifest"
    datasets: list[SequentialCptSource] = Field(default_factory=list)


def is_sequential_cpt_manifest_path(path: str | Path) -> bool:
    return load_sequential_cpt_manifest(path) is not None


def load_sequential_cpt_manifest(path: str | Path) -> SequentialCptManifest | None:
    manifest_path = Path(path).expanduser().resolve()
    if not manifest_path.is_file():
        return None
    if manifest_path.suffix.lower() != ".json":
        return None
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get("kind") != "sequential_cpt_manifest":
        return None
    return SequentialCptManifest.model_validate(payload)


def write_sequential_cpt_manifest(
    path: str | Path,
    *,
    datasets: list[SequentialCptSource],
) -> SequentialCptManifest:
    manifest_path = Path(path).expanduser().resolve()
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest = SequentialCptManifest(datasets=datasets)
    manifest_path.write_text(
        json.dumps(manifest.model_dump(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def iter_sequential_cpt_source_paths(path: str | Path) -> Iterator[Path]:
    yield from _iter_sequential_cpt_source_paths(
        path=Path(path).expanduser().resolve(),
        seen_manifests=set(),
    )


def _iter_sequential_cpt_source_paths(
    *,
    path: Path,
    seen_manifests: set[Path],
) -> Iterator[Path]:
    manifest = load_sequential_cpt_manifest(path)
    if manifest is None:
        yield path
        return
    if path in seen_manifests:
        raise ValueError(f"Manifest cycle detected at {path}.")
    next_seen = set(seen_manifests)
    next_seen.add(path)
    for source in manifest.datasets:
        source_path = Path(source.path).expanduser().resolve()
        for _ in range(source.repeat):
            yield from _iter_sequential_cpt_source_paths(
                path=source_path,
                seen_manifests=next_seen,
            )
