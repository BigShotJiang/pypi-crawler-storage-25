from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

DEFAULT_NATIVE_CONTEXT_WINDOW = 262_144
DEFAULT_EXTENDED_CONTEXT_WINDOW = 1_048_576
DEFAULT_YARN_FACTOR = 4.0


class ContextWindowReport(BaseModel):
    model_dir: str
    config_path: str
    original_context_window: int | None = None
    configured_context_window: int
    yarn_factor: float | None = None
    rope_type: str


def default_yarn_factor(*, target_context_window: int, native_context_window: int) -> float:
    if (
        native_context_window == DEFAULT_NATIVE_CONTEXT_WINDOW
        and target_context_window >= DEFAULT_EXTENDED_CONTEXT_WINDOW
    ):
        return DEFAULT_YARN_FACTOR
    return max(float(target_context_window) / float(native_context_window), 1.0)


def apply_context_window_to_config(
    config: dict[str, Any],
    *,
    target_context_window: int = DEFAULT_EXTENDED_CONTEXT_WINDOW,
    yarn_factor: float | None = None,
) -> dict[str, Any]:
    updated = copy.deepcopy(config)
    text_config = copy.deepcopy(updated.get("text_config", {}))
    native_context_window = _coerce_int(
        text_config.get("max_position_embeddings"),
        default=DEFAULT_NATIVE_CONTEXT_WINDOW,
    )
    factor = yarn_factor
    if factor is None:
        factor = default_yarn_factor(
            target_context_window=target_context_window,
            native_context_window=native_context_window,
        )

    rope_parameters = copy.deepcopy(text_config.get("rope_parameters", {}))
    rope_parameters["mrope_interleaved"] = True
    rope_parameters["mrope_section"] = [11, 11, 10]
    rope_parameters["rope_type"] = "yarn"
    rope_parameters["rope_theta"] = 10_000_000
    rope_parameters["partial_rotary_factor"] = 0.25
    rope_parameters["factor"] = factor
    rope_parameters["original_max_position_embeddings"] = native_context_window

    text_config["max_position_embeddings"] = target_context_window
    text_config["rope_parameters"] = rope_parameters
    updated["text_config"] = text_config
    return updated


def configure_model_context_window(
    model_dir: str | Path,
    *,
    target_context_window: int = DEFAULT_EXTENDED_CONTEXT_WINDOW,
    yarn_factor: float | None = None,
) -> ContextWindowReport:
    root = Path(model_dir).expanduser().resolve()
    config_path = root / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    updated = apply_context_window_to_config(
        config,
        target_context_window=target_context_window,
        yarn_factor=yarn_factor,
    )
    config_path.write_text(json.dumps(updated, ensure_ascii=False, indent=4) + "\n", encoding="utf-8")
    text_config = updated.get("text_config", {})
    rope_parameters = text_config.get("rope_parameters", {})
    return ContextWindowReport(
        model_dir=str(root),
        config_path=str(config_path),
        original_context_window=_coerce_optional_int(
            rope_parameters.get("original_max_position_embeddings"),
        ),
        configured_context_window=_coerce_int(
            text_config.get("max_position_embeddings"),
            default=target_context_window,
        ),
        yarn_factor=_coerce_optional_float(rope_parameters.get("factor")),
        rope_type=str(rope_parameters.get("rope_type", "default")),
    )


def _coerce_int(value: Any, *, default: int) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _coerce_optional_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None


def _coerce_optional_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None
