from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, cast

from pydantic import BaseModel, Field


class ModelCapabilities(BaseModel):
    image: bool
    video: bool
    tool_calling: bool
    tool_response: bool
    thinking: bool
    openai_chat_template: bool
    openai_api_serving_docs: bool


class ModelQuantization(BaseModel):
    is_quantized: bool = False
    bits: int | None = None
    group_size: int | None = None
    mode: str | None = None


class ModelProfile(BaseModel):
    model_dir: str
    model_name: str | None
    parameter_count: str | None = None
    base_model: list[str] = Field(default_factory=list)
    model_type: str
    architectures: list[str] = Field(default_factory=list)
    native_text_context_window: int | None = None
    text_context_window: int | None
    extended_context_claim: int | None
    weight_bytes: int | None
    tags: list[str] = Field(default_factory=list)
    quantization: ModelQuantization = Field(default_factory=ModelQuantization)
    capabilities: ModelCapabilities
    notes: list[str] = Field(default_factory=list)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _read_optional_text(path: Path) -> str:
    if not path.exists():
        return ""
    return _read_text(path)


def _read_json(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(_read_text(path)))


def _read_optional_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return _read_json(path)


def _parse_front_matter(readme_text: str) -> dict[str, Any]:
    if not readme_text.startswith("---\n"):
        return {}
    match = re.match(r"^---\n(.*?)\n---\n", readme_text, flags=re.DOTALL)
    if not match:
        return {}

    front_matter: dict[str, Any] = {}
    current_key: str | None = None
    for line in match.group(1).splitlines():
        if not line.strip():
            continue
        if re.match(r"^[A-Za-z0-9_]+:", line):
            key, raw_value = line.split(":", 1)
            key = key.strip()
            raw_value = raw_value.strip()
            current_key = key
            if raw_value == "":
                front_matter[key] = []
            elif raw_value == ">-":
                front_matter[key] = ""
            else:
                front_matter[key] = raw_value
        elif line.lstrip().startswith("- ") and current_key is not None:
            current_value = front_matter.setdefault(current_key, [])
            if isinstance(current_value, list):
                current_value.append(line.lstrip()[2:].strip())
        elif current_key is not None and isinstance(front_matter.get(current_key), str):
            front_matter[current_key] += f" {line.strip()}".rstrip()
    return front_matter


def _extract_heading(readme_text: str) -> str | None:
    for line in readme_text.splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            if title:
                return title
    return None


def _extract_extended_context_claim(readme_text: str) -> int | None:
    match = re.search(
        r"extensible up to ([0-9][0-9,]*) tokens",
        readme_text,
        flags=re.IGNORECASE,
    )
    if not match:
        return None
    return int(match.group(1).replace(",", ""))


def inspect_model_dir(model_dir: str | Path) -> ModelProfile:
    root = Path(model_dir).expanduser().resolve()
    config = _read_json(root / "config.json")
    tokenizer_config = _read_json(root / "tokenizer_config.json")
    readme_text = _read_optional_text(root / "README.md")
    chat_template_text = _read_optional_text(root / "chat_template.jinja")
    tokenizer_json_text = _read_optional_text(root / "tokenizer.json")
    model_index = _read_optional_json(root / "model.safetensors.index.json")

    front_matter = _parse_front_matter(readme_text)
    text_config = config.get("text_config", {})
    rope_parameters = text_config.get("rope_parameters", {})
    quantization = _extract_quantization(config)
    special_text = "\n".join(
        (
            json.dumps(tokenizer_config, ensure_ascii=False),
            tokenizer_json_text,
            chat_template_text,
        )
    )

    notes: list[str] = []
    configured_context = text_config.get("max_position_embeddings")
    native_context = rope_parameters.get("original_max_position_embeddings", configured_context)
    extended_context = _extract_extended_context_claim(readme_text)
    if not readme_text:
        notes.append(
            "README.md is missing, so model-name and extended-context inspection are based on local config only."
        )
    if (
        isinstance(native_context, int)
        and isinstance(extended_context, int)
        and extended_context > native_context
    ):
        notes.append(
            "Extended context requires a YaRN or rope override. The local config still has the native context length."
        )
    if rope_parameters.get("rope_type") == "yarn":
        notes.append(
            "Configured with static YaRN rope scaling. Short-text behavior can shift compared with the native context setting."
        )

    if readme_text and config.get("model_type") == "cappuccino":
        notes.append(
            "This repository is a local model directory, not an application codebase. The runtime foundation has to be added on top."
        )
    if quantization.is_quantized:
        quantization_label = _format_quantization_label(quantization)
        notes.append(
            "This model directory contains "
            f"{quantization_label} quantized weights. Use the original-precision MLX model for CPT or fine-tuning."
        )

    return ModelProfile(
        model_dir=str(root),
        model_name=_extract_heading(readme_text) or root.name,
        parameter_count=_extract_parameter_count_label(
            readme_text=readme_text,
            heading=_extract_heading(readme_text),
            fallback_name=root.name,
        ),
        base_model=_coerce_list(front_matter.get("base_model")),
        model_type=str(config.get("model_type", "")),
        architectures=[str(item) for item in config.get("architectures", [])],
        native_text_context_window=native_context if isinstance(native_context, int) else None,
        text_context_window=configured_context if isinstance(configured_context, int) else None,
        extended_context_claim=extended_context,
        weight_bytes=_extract_weight_bytes(model_index),
        tags=_coerce_list(front_matter.get("tags")),
        quantization=quantization,
        capabilities=ModelCapabilities(
            image="vision_config" in config and "image_token_id" in config,
            video="video_token_id" in config and (root / "video_preprocessor_config.json").exists(),
            tool_calling="<tool_call>" in special_text,
            tool_response="<tool_response>" in special_text,
            thinking="<think>" in special_text,
            openai_chat_template="tools" in chat_template_text,
            openai_api_serving_docs="OpenAI API" in readme_text,
        ),
        notes=notes,
    )


def _coerce_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def _extract_parameter_count_label(
    *,
    readme_text: str,
    heading: str | None,
    fallback_name: str,
) -> str | None:
    for candidate in (heading, readme_text, fallback_name):
        if not candidate:
            continue
        match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*[Bb](?:-class)?", candidate)
        if match:
            return f"{match.group(1)}B"
    return None


def _extract_weight_bytes(model_index: dict[str, Any]) -> int | None:
    metadata = model_index.get("metadata", {})
    total_size = metadata.get("total_size")
    return total_size if isinstance(total_size, int) else None


def _extract_quantization(config: dict[str, Any]) -> ModelQuantization:
    quantization_config = config.get("quantization")
    if not isinstance(quantization_config, dict):
        quantization_config = config.get("quantization_config")
    if not isinstance(quantization_config, dict):
        return ModelQuantization()

    bits = _coerce_optional_int(quantization_config.get("bits"))
    group_size = _coerce_optional_int(quantization_config.get("group_size"))
    mode = quantization_config.get("mode")
    return ModelQuantization(
        is_quantized=True,
        bits=bits,
        group_size=group_size,
        mode=mode if isinstance(mode, str) else None,
    )


def _format_quantization_label(quantization: ModelQuantization) -> str:
    if quantization.bits is None:
        return "quantized"
    return f"{quantization.bits}-bit"


def _coerce_optional_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return None
