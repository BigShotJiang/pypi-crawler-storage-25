from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class SkillDefinition(BaseModel):
    name: str
    description: str
    path: str
    directory: str
    allow_implicit_invocation: bool = True

    def read_instructions(self) -> str:
        _, body = _parse_skill_markdown(Path(self.path))
        return body


class SkillSearchHit(BaseModel):
    score: float
    name: str
    description: str
    path: str
    directory: str
    allow_implicit_invocation: bool = True
    matched_fields: list[str] = Field(default_factory=list)


class SkillRegistry:
    def __init__(self, skills: list[SkillDefinition]) -> None:
        self._skills = list(skills)

    @classmethod
    def from_path(cls, path: str | Path) -> "SkillRegistry":
        skill_path = Path(path).expanduser().resolve()
        skill_files = _load_skill_files(skill_path)
        parsed = [_parse_skill_definition(skill_file) for skill_file in skill_files]
        return cls(parsed)

    def search(
        self,
        query: str,
        limit: int = 5,
        *,
        description_only: bool = False,
        implicit_only: bool = False,
    ) -> list[SkillSearchHit]:
        normalized_query = _normalize(query)
        if not normalized_query:
            return []
        query_tokens = _tokens(normalized_query)

        hits: list[SkillSearchHit] = []
        for skill in self._skills:
            if implicit_only and not skill.allow_implicit_invocation:
                continue
            score, matched_fields = _score_skill(
                skill=skill,
                normalized_query=normalized_query,
                query_tokens=query_tokens,
                description_only=description_only,
            )
            if score <= 0:
                continue
            hits.append(
                SkillSearchHit(
                    score=round(score, 4),
                    name=skill.name,
                    description=skill.description,
                    path=skill.path,
                    directory=skill.directory,
                    allow_implicit_invocation=skill.allow_implicit_invocation,
                    matched_fields=matched_fields,
                )
            )

        return sorted(hits, key=lambda item: (-item.score, item.name, item.path))[:limit]

    def resolve(self, reference: str) -> SkillDefinition:
        raw_reference = reference.strip()
        if not raw_reference:
            raise ValueError("Skill reference must not be empty.")

        skill_reference = raw_reference[1:] if raw_reference.startswith("$") else raw_reference
        candidate_path = Path(skill_reference).expanduser()
        if candidate_path.exists():
            resolved_path = candidate_path.resolve()
            matches = [
                skill
                for skill in self._skills
                if Path(skill.path) == resolved_path or Path(skill.directory) == resolved_path
            ]
            if not matches:
                raise ValueError(f"Skill path is not loaded: {resolved_path}")
            return matches[0]

        matches = [skill for skill in self._skills if skill.name == skill_reference]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            locations = ", ".join(sorted(skill.path for skill in matches))
            raise ValueError(f"Ambiguous skill name '{skill_reference}': {locations}")
        raise ValueError(f"Unknown skill: {skill_reference}")

    def all_skills(self) -> list[dict[str, Any]]:
        return [skill.model_dump() for skill in self._skills]

    @property
    def skill_count(self) -> int:
        return len(self._skills)


def _load_skill_files(path: Path) -> list[Path]:
    if path.is_file():
        if path.name != "SKILL.md":
            raise ValueError(f"Skill file must be named SKILL.md: {path}")
        return [path]
    if not path.is_dir():
        raise ValueError(f"Skill registry path does not exist: {path}")
    if (path / "SKILL.md").is_file():
        return [path / "SKILL.md"]
    return sorted(candidate for candidate in path.rglob("SKILL.md") if candidate.is_file())


def _parse_skill_definition(skill_file: Path) -> SkillDefinition:
    metadata, _ = _parse_skill_markdown(skill_file)
    name = str(metadata.get("name") or "").strip()
    description = str(metadata.get("description") or "").strip()
    if not name:
        raise ValueError(f"Skill frontmatter is missing name: {skill_file}")
    if not description:
        raise ValueError(f"Skill frontmatter is missing description: {skill_file}")
    return SkillDefinition(
        name=name,
        description=description,
        path=str(skill_file.resolve()),
        directory=str(skill_file.parent.resolve()),
        allow_implicit_invocation=_load_allow_implicit_invocation(skill_file.parent),
    )


def _parse_skill_markdown(path: Path) -> tuple[dict[str, str], str]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError(f"Skill file must start with YAML frontmatter: {path}")

    metadata: dict[str, str] = {}
    end_index: int | None = None
    for index in range(1, len(lines)):
        stripped = lines[index].strip()
        if stripped == "---":
            end_index = index
            break
        if not stripped or lines[index].startswith((" ", "\t")) or ":" not in lines[index]:
            continue
        key, raw_value = lines[index].split(":", 1)
        metadata[key.strip()] = _strip_yaml_scalar(raw_value.strip())

    if end_index is None:
        raise ValueError(f"Skill frontmatter is not terminated: {path}")
    body = "\n".join(lines[end_index + 1 :]).strip()
    return metadata, body


def _strip_yaml_scalar(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def _load_allow_implicit_invocation(skill_dir: Path) -> bool:
    config_path = skill_dir / "agents" / "openai.yaml"
    if not config_path.is_file():
        return True

    lines = config_path.read_text(encoding="utf-8").splitlines()
    policy_indent: int | None = None
    inside_policy = False
    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        if stripped == "policy:" or stripped.startswith("policy:"):
            inside_policy = True
            policy_indent = indent
            continue
        if inside_policy and policy_indent is not None:
            if indent <= policy_indent:
                inside_policy = False
            elif stripped.startswith("allow_implicit_invocation:"):
                value = stripped.split(":", 1)[1].strip().lower()
                if value in {"false", "no"}:
                    return False
                if value in {"true", "yes"}:
                    return True
    return True


def _normalize(value: str) -> str:
    collapsed = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return re.sub(r"\s+", " ", collapsed).strip()


def _tokens(value: str) -> list[str]:
    return [token for token in value.split(" ") if token]


def _score_skill(
    *,
    skill: SkillDefinition,
    normalized_query: str,
    query_tokens: list[str],
    description_only: bool,
) -> tuple[float, list[str]]:
    matched_fields: list[str] = []
    score = 0.0
    if not description_only:
        score += _field_score(
            normalized_query=normalized_query,
            query_tokens=query_tokens,
            haystack=_normalize(skill.name.replace("_", " ")),
            exact_phrase_weight=10.0,
            token_weight=3.0,
            prefix_weight=1.0,
            label="name",
            matched_fields=matched_fields,
        )
    score += _field_score(
        normalized_query=normalized_query,
        query_tokens=query_tokens,
        haystack=_normalize(skill.description),
        exact_phrase_weight=8.0,
        token_weight=2.5,
        prefix_weight=1.0,
        label="description",
        matched_fields=matched_fields,
    )
    if not description_only:
        score += _field_score(
            normalized_query=normalized_query,
            query_tokens=query_tokens,
            haystack=_normalize(skill.directory),
            exact_phrase_weight=1.0,
            token_weight=0.5,
            prefix_weight=0.0,
            label="path",
            matched_fields=matched_fields,
        )
    return score, matched_fields


def _field_score(
    *,
    normalized_query: str,
    query_tokens: list[str],
    haystack: str,
    exact_phrase_weight: float,
    token_weight: float,
    prefix_weight: float,
    label: str,
    matched_fields: list[str],
) -> float:
    if not haystack:
        return 0.0

    score = 0.0
    matched = False
    if normalized_query == haystack:
        score += exact_phrase_weight * 1.25
        matched = True
    elif normalized_query in haystack:
        score += exact_phrase_weight
        matched = True

    for token in query_tokens:
        if token == haystack:
            score += token_weight * 1.25
            matched = True
            continue
        if f" {token} " in f" {haystack} ":
            score += token_weight
            matched = True
            continue
        if prefix_weight > 0 and any(word.startswith(token) for word in haystack.split(" ")):
            score += prefix_weight
            matched = True

    if matched and label not in matched_fields:
        matched_fields.append(label)
    return score
