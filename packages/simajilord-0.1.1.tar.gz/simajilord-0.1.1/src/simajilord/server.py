from cappuccino.server import create_app

__all__ = ["create_app"]
