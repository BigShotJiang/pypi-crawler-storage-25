"""Token Savior — structural code indexer with MCP server for AI-assisted development."""

__version__ = "3.4.0"
