"""Compatibility checks for tgcalc template-goal validation."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tgcalc.core import (
    _ALIAS_RE,
    TgCalcError,
    load_toml,
)


class SpecError(TgCalcError):
    """Raised when a config/spec file is structurally invalid."""


@dataclass(frozen=True)
class ParameterSpec:
    """Parameter contract for template-goal compatibility checks."""

    name: str
    type: str
    unit: str


@dataclass(frozen=True)
class GoalValueTypeMismatch:
    """One goal value whose Python type does not match the template type."""

    parameter: str
    index: int
    expected_type: str
    actual_type: str
    value: Any


@dataclass(frozen=True)
class ValueGroupLengthMismatch:
    """Goal value_group arrays with inconsistent lengths."""

    group_index: int
    lengths: dict[str, int]


@dataclass(frozen=True)
class TemplateGoalCheckResult:
    """Result of checking whether a goal correctly uses its templates."""

    missing_goal_parameters: list[str]
    unknown_goal_parameters: list[str]
    duplicate_goal_parameters: list[str]
    non_array_values: list[str]
    value_group_length_mismatches: list[ValueGroupLengthMismatch]
    type_mismatches: list[GoalValueTypeMismatch]
    iter_issues: list[str]
    structure_issues: list[str]

    @property
    def valid(self) -> bool:
        return not (
            self.missing_goal_parameters
            or self.unknown_goal_parameters
            or self.duplicate_goal_parameters
            or self.non_array_values
            or self.value_group_length_mismatches
            or self.type_mismatches
            or self.iter_issues
            or self.structure_issues
        )

    def summary(self) -> str:
        if self.valid:
            return "Goal/template are valid."

        sections: list[str] = ["Goal/template are not valid."]

        if self.structure_issues:
            sections.extend(
                _format_name_section(
                    "Structure issues:",
                    self.structure_issues,
                )
            )

        if self.missing_goal_parameters:
            sections.extend(
                _format_name_section(
                    "Template parameters missing from goal:",
                    self.missing_goal_parameters,
                )
            )

        if self.unknown_goal_parameters:
            sections.extend(
                _format_name_section(
                    "Goal parameters not defined by template:",
                    self.unknown_goal_parameters,
                )
            )

        if self.duplicate_goal_parameters:
            sections.extend(
                _format_name_section(
                    "Parameters appearing in multiple value_groups:",
                    self.duplicate_goal_parameters,
                )
            )

        if self.non_array_values:
            sections.extend(
                _format_name_section(
                    "Goal values must be arrays:",
                    self.non_array_values,
                )
            )

        if self.value_group_length_mismatches:
            sections.extend(
                _format_value_group_length_section(
                    "Value group length mismatches:",
                    self.value_group_length_mismatches,
                )
            )

        if self.type_mismatches:
            sections.extend(
                _format_goal_type_mismatch_section(
                    "Type mismatches:",
                    self.type_mismatches,
                )
            )

        if self.iter_issues:
            sections.extend(
                _format_name_section("Iter issues:", self.iter_issues)
            )

        return "\n\n".join(sections)


def check_template_goal_compatibility(
    templates: Mapping[str, Mapping[str, Any]],
    goal: Mapping[str, Any],
) -> TemplateGoalCheckResult:
    """Check whether a goal correctly and completely uses its templates."""
    structure_issues: list[str] = []

    if "template" in goal:
        structure_issues.append(
            "Old field 'template' is no longer supported. "
            'Use [templates] with alias = "file.t.toml" instead.'
        )

    templates_table = goal.get("templates")
    if not isinstance(templates_table, dict) or not templates_table:
        structure_issues.append("Goal must contain [templates] table")
        return TemplateGoalCheckResult(
            missing_goal_parameters=[],
            unknown_goal_parameters=[],
            duplicate_goal_parameters=[],
            non_array_values=[],
            value_group_length_mismatches=[],
            type_mismatches=[],
            iter_issues=[],
            structure_issues=structure_issues,
        )

    for alias in templates_table:
        if not isinstance(alias, str) or not _ALIAS_RE.match(alias):
            structure_issues.append(
                f"[templates] alias {alias!r} is not valid"
            )

    if structure_issues:
        return TemplateGoalCheckResult(
            missing_goal_parameters=[],
            unknown_goal_parameters=[],
            duplicate_goal_parameters=[],
            non_array_values=[],
            value_group_length_mismatches=[],
            type_mismatches=[],
            iter_issues=[],
            structure_issues=structure_issues,
        )

    all_template_specs: dict[str, ParameterSpec] = {}
    for alias, template in templates.items():
        template_parameters = _parameter_specs(
            template, owner=f"template {alias!r}"
        )
        for name, spec in template_parameters.items():
            dotted = f"{alias}.{name}"
            all_template_specs[dotted] = spec

    value_groups = _goal_value_group_tables(goal)

    seen_parameters: set[str] = set()
    goal_parameters: set[str] = set()
    goal_parameter_names: list[str] = []
    duplicate_goal_parameters: list[str] = []
    non_array_values: list[str] = []
    value_group_length_mismatches: list[ValueGroupLengthMismatch] = []
    type_mismatches: list[GoalValueTypeMismatch] = []

    for group_index, group in enumerate(value_groups, start=1):
        array_lengths: dict[str, int] = {}

        for key, value in group.items():
            if isinstance(value, dict):
                alias = key
                if alias not in templates_table:
                    structure_issues.append(
                        f"value_group #{group_index}: unknown template "
                        f"alias {alias!r}"
                    )
                    continue
                for param_name, param_values in value.items():
                    dotted = f"{alias}.{param_name}"
                    _process_goal_param(
                        dotted,
                        param_values,
                        group_index,
                        all_template_specs,
                        seen_parameters,
                        goal_parameters,
                        goal_parameter_names,
                        duplicate_goal_parameters,
                        non_array_values,
                        array_lengths,
                        type_mismatches,
                    )
            elif isinstance(value, list):
                if "." in key:
                    structure_issues.append(
                        f"value_group #{group_index}: quoted dotted key "
                        f"{key!r} is not allowed. Use bare dotted key "
                        f"notation instead."
                    )
                else:
                    structure_issues.append(
                        f"value_group #{group_index}: bare parameter "
                        f"{key!r} is not allowed. Use alias.parameter "
                        f"notation."
                    )
            else:
                structure_issues.append(
                    f"value_group #{group_index}: unexpected value type "
                    f"for key {key!r}"
                )

        if len(set(array_lengths.values())) > 1:
            value_group_length_mismatches.append(
                ValueGroupLengthMismatch(
                    group_index=group_index,
                    lengths=array_lengths,
                )
            )

    missing_goal_parameters = [
        name for name in all_template_specs if name not in goal_parameters
    ]
    unknown_goal_parameters = [
        name
        for name in goal_parameter_names
        if name not in all_template_specs
    ]

    return TemplateGoalCheckResult(
        missing_goal_parameters=missing_goal_parameters,
        unknown_goal_parameters=unknown_goal_parameters,
        duplicate_goal_parameters=duplicate_goal_parameters,
        non_array_values=non_array_values,
        value_group_length_mismatches=value_group_length_mismatches,
        type_mismatches=type_mismatches,
        iter_issues=_iter_issues(goal),
        structure_issues=structure_issues,
    )


def check_template_goal_files(
    goal_path: str | Path,
    template_dir: str | Path,
) -> TemplateGoalCheckResult:
    """Load a goal and its referenced templates, then validate consistency."""
    goal = load_toml(goal_path)
    template_dir_path = Path(template_dir)

    if "template" in goal:
        raise SpecError(
            "Old field 'template' is no longer supported. "
            'Use [templates] with alias = "file.t.toml" instead.'
        )

    templates_table = goal.get("templates")
    if not isinstance(templates_table, dict) or not templates_table:
        raise SpecError("Goal must contain [templates] table")

    templates: dict[str, Mapping[str, Any]] = {}
    for alias, template_name in templates_table.items():
        if isinstance(template_name, str) and template_name:
            template_path = template_dir_path / template_name
            if template_path.is_file():
                templates[alias] = load_toml(template_path)

    return check_template_goal_compatibility(templates, goal)


def _process_goal_param(
    dotted: str,
    values: Any,
    group_index: int,
    all_template_specs: dict[str, ParameterSpec],
    seen_parameters: set[str],
    goal_parameters: set[str],
    goal_parameter_names: list[str],
    duplicate_goal_parameters: list[str],
    non_array_values: list[str],
    array_lengths: dict[str, int],
    type_mismatches: list[GoalValueTypeMismatch],
) -> None:
    if dotted not in goal_parameters:
        goal_parameter_names.append(dotted)
    goal_parameters.add(dotted)

    if dotted in seen_parameters:
        _append_unique(duplicate_goal_parameters, dotted)
    seen_parameters.add(dotted)

    if not isinstance(values, list):
        _append_unique(non_array_values, dotted)
        return

    array_lengths[dotted] = len(values)
    template_parameter = all_template_specs.get(dotted)
    if template_parameter is None:
        return

    _validate_supported_goal_type(template_parameter)

    for value_index, value in enumerate(values):
        if not _matches_template_type(value, template_parameter.type):
            type_mismatches.append(
                GoalValueTypeMismatch(
                    parameter=dotted,
                    index=value_index,
                    expected_type=template_parameter.type,
                    actual_type=_goal_value_type_name(value),
                    value=value,
                )
            )


def _goal_value_group_tables(
    goal: Mapping[str, Any],
) -> list[dict[str, Any]]:
    raw_value_groups = goal.get("value_groups")

    if not isinstance(raw_value_groups, list) or not raw_value_groups:
        raise SpecError(
            "goal must contain at least one [[value_groups]] table"
        )

    groups: list[dict[str, Any]] = []

    for group_index, raw_group in enumerate(raw_value_groups, start=1):
        if not isinstance(raw_group, dict) or not raw_group:
            raise SpecError(
                f"goal value_group #{group_index} must be a non-empty table"
            )
        groups.append(raw_group)

    return groups


def _parameter_specs(
    document: Mapping[str, Any],
    *,
    owner: str,
) -> dict[str, ParameterSpec]:
    raw_parameters = document.get("parameters")

    if not isinstance(raw_parameters, list):
        raise SpecError(f"{owner} must contain [[parameters]]")

    specs: dict[str, ParameterSpec] = {}

    for index, item in enumerate(raw_parameters, start=1):
        if not isinstance(item, dict):
            raise SpecError(f"{owner} parameter #{index} must be a table")

        spec = _parameter_spec(item, owner=owner, index=index)

        if spec.name in specs:
            raise SpecError(
                f"{owner} contains duplicate parameter: {spec.name}"
            )

        specs[spec.name] = spec

    if not specs:
        raise SpecError(f"{owner} must define at least one parameter")

    return specs


def _parameter_spec(
    item: Mapping[str, Any],
    *,
    owner: str,
    index: int,
) -> ParameterSpec:
    return ParameterSpec(
        name=_require_non_empty_str(item, "name", owner=owner, index=index),
        type=_require_non_empty_str(item, "type", owner=owner, index=index),
        unit=_require_non_empty_str(item, "unit", owner=owner, index=index),
    )


def _require_non_empty_str(
    item: Mapping[str, Any],
    field: str,
    *,
    owner: str,
    index: int,
) -> str:
    value = item.get(field)
    if not isinstance(value, str) or not value:
        raise SpecError(
            f"{owner} parameter #{index} must contain non-empty string "
            f"field {field!r}"
        )
    return value


def _validate_supported_goal_type(parameter: ParameterSpec) -> None:
    if parameter.type not in {"string", "number", "boolean"}:
        raise SpecError(
            f"template parameter {parameter.name!r} has unsupported type "
            f"{parameter.type!r}"
        )


def _matches_template_type(value: Any, expected_type: str) -> bool:
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "number":
        return (isinstance(value, int | float)) and not isinstance(
            value, bool
        )
    if expected_type == "boolean":
        return isinstance(value, bool)
    return False


def _goal_value_type_name(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, str):
        return "string"
    if isinstance(value, int | float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "table"
    return type(value).__name__


def _iter_issues(goal: Mapping[str, Any]) -> list[str]:
    raw_iter = goal.get("iter")
    if raw_iter is None:
        return []

    if not isinstance(raw_iter, dict):
        return ["[iter] must be a table"]

    repeat = raw_iter.get("repeat")
    values = raw_iter.get("values")

    if repeat is not None and values is not None:
        return ["[iter] cannot have both 'repeat' and 'values'"]

    if repeat is not None:
        if not isinstance(repeat, int) or repeat < 1:
            return ["[iter].repeat must be a positive integer"]
        return []

    if values is not None:
        if not isinstance(values, list) or not values:
            return ["[iter].values must be a non-empty array"]

    return []


def _append_unique(items: list[str], item: str) -> None:
    if item not in items:
        items.append(item)


def _format_name_section(title: str, names: list[str]) -> list[str]:
    lines = [title]
    lines.extend(f"  - {name}" for name in names)
    return ["\n".join(lines)]


def _format_value_group_length_section(
    title: str,
    mismatches: list[ValueGroupLengthMismatch],
) -> list[str]:
    lines = [title]
    for mismatch in mismatches:
        lengths = ", ".join(
            f"{parameter}={length}"
            for parameter, length in mismatch.lengths.items()
        )
        lines.append(f"  - value_group #{mismatch.group_index}: {lengths}")
    return ["\n".join(lines)]


def _format_goal_type_mismatch_section(
    title: str,
    mismatches: list[GoalValueTypeMismatch],
) -> list[str]:
    lines = [title]
    lines.extend(
        f"  - {mismatch.parameter}[{mismatch.index}]: expected type "
        f'"{mismatch.expected_type}", got {mismatch.actual_type} value '
        f"{_format_value(mismatch.value)}"
        for mismatch in mismatches
    )
    return ["\n".join(lines)]


def _format_value(value: Any) -> str:
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    return repr(value)
