"""
Core expansion logic for tgcalc.

tgcalc uses three file types:

- *.t.toml: template files
- *.g.toml: goal files
- *.c.toml: concrete calc files

This module expands a goal file into canonical concrete calc payloads,
deduplicates them by SHA256, and writes *.c.toml files.

This layer intentionally does not manage:
- execution status
- stale / orphan tasks
- source-goal indexes
- job IDs
- working directories
- result files
"""

from __future__ import annotations

import hashlib
import itertools
import json
import math
import re
import tomllib
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

JsonObject = dict[str, Any]
AliasParam = tuple[str, str]

_ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class TgCalcError(Exception):
    """Base exception for tgcalc errors."""


class TemplateError(TgCalcError):
    """Raised when a template file is invalid."""


class GoalError(TgCalcError):
    """Raised when a goal file is invalid."""


class CalcWriteError(TgCalcError):
    """Raised when writing a calc file would be unsafe."""


@dataclass(frozen=True)
class CalcFile:
    """Result of writing or reusing one concrete calc file."""

    calc_id: str
    sha256: str
    path: Path
    created: bool
    payload: JsonObject


def load_toml(path: str | Path) -> JsonObject:
    """Load a TOML file as a Python dictionary."""
    path = Path(path)
    with path.open("rb") as f:
        data = tomllib.load(f)

    if not isinstance(data, dict):
        raise TgCalcError(f"TOML root must be a table: {path}")

    return data


def flatten_dotted_parameter_tree(
    tree: Mapping[str, Any],
) -> dict[AliasParam, Any]:
    """Convert nested {alias: {param: value}} to {(alias, param): value}."""
    flat: dict[AliasParam, Any] = {}
    for alias, params in tree.items():
        if not isinstance(params, dict):
            raise GoalError(
                f"Expected nested table for alias {alias!r}, "
                f"got {type(params).__name__}"
            )
        for param, value in params.items():
            flat[(alias, param)] = value
    return flat


def unflatten_to_nested_parameters(
    flat: Mapping[AliasParam, Any],
) -> dict[str, dict[str, Any]]:
    """Convert {(alias, param): value} to {alias: {param: value}}."""
    nested: dict[str, dict[str, Any]] = {}
    for (alias, param), value in flat.items():
        nested.setdefault(alias, {})[param] = value
    return nested


def expand_goal_file(
    goal_path: str | Path,
    *,
    template_dir: str | Path,
    output_dir: str | Path,
    hash_len: int | None = 64,
    file_prefix: str = "",
    overwrite: bool = False,
) -> list[CalcFile]:
    """
    Expand one *.g.toml file into deduplicated *.c.toml files.

    Parameters
    ----------
    goal_path:
        Path to the goal file.
    template_dir:
        Directory containing template files.
    output_dir:
        Directory where *.c.toml files will be written.
    hash_len:
        Number of SHA256 characters used in the filename.
        Use None or 64 for the full hash.
    file_prefix:
        Optional filename prefix. Default: no prefix.
    overwrite:
        If False, existing calc files are reused.
        If True, existing files are overwritten with deterministic content.

    Returns
    -------
    list[CalcFile]
        One item per expanded calc. If the same calc appears multiple times
        within one goal, it is returned only once.
    """
    goal_path = Path(goal_path)
    template_dir = Path(template_dir)
    output_dir = Path(output_dir)

    goal = load_toml(goal_path)
    _reject_old_template_field(goal, str(goal_path))
    templates_table = _require_templates(goal, str(goal_path))

    templates: dict[str, Mapping[str, Any]] = {}
    for alias, template_name in templates_table.items():
        template_path = template_dir / template_name
        templates[alias] = load_toml(template_path)

    payloads = list(expand_goal(goal, templates=templates))

    output_dir.mkdir(parents=True, exist_ok=True)

    results: list[CalcFile] = []
    seen_by_calc_id: dict[str, str] = {}
    seen_sha: set[str] = set()

    for payload in payloads:
        sha = calc_sha256(payload)

        if sha in seen_sha:
            continue
        seen_sha.add(sha)

        calc_id = calc_id_from_sha(sha, prefix=file_prefix, hash_len=hash_len)
        existing_sha = seen_by_calc_id.get(calc_id)
        if existing_sha is not None and existing_sha != sha:
            raise CalcWriteError(
                f"Hash prefix collision for {calc_id}; use a longer hash_len"
            )
        seen_by_calc_id[calc_id] = sha

        path = output_dir / f"{calc_id}.c.toml"
        created = write_calc_file(path, payload, overwrite=overwrite)

        results.append(
            CalcFile(
                calc_id=calc_id,
                sha256=sha,
                path=path,
                created=created,
                payload=payload,
            )
        )

    return results


def expand_goal(
    goal: Mapping[str, Any],
    *,
    templates: Mapping[str, Mapping[str, Any]],
) -> Iterable[JsonObject]:
    """
    Expand a goal dictionary into canonical calc payloads.

    The goal format uses [templates] and dotted-key value_groups:

        [templates]
        model = "model.t.toml"
        loading = "loading.t.toml"

        [[value_groups]]
        model.temperature = [300]
        loading.strain_mode = ["x"]

        [iter]
        values = [1, 2, 3]

    Rules:
    - Every template parameter must appear in exactly one value_group.
    - All values must be arrays, even fixed values.
    - Parameters in the same value_group are zipped by index.
    - Different value_groups are crossed by Cartesian product.
    - iter.values is crossed with the parameter combinations.
    """
    templates_table = _require_templates(goal, "goal")
    _reject_old_template_field(goal, "goal")
    all_template_params = _all_template_params(templates)
    value_groups = _require_value_groups(goal)
    flat_groups = _flatten_and_validate_value_groups(
        value_groups, templates_table, templates, all_template_params,
    )

    expanded_groups = [_expand_flat_value_group(group) for group in flat_groups]

    iter_values = _iter_values(goal)

    for group_combo in itertools.product(*expanded_groups):
        parameters: dict[AliasParam, Any] = {}

        for record in group_combo:
            overlap = parameters.keys() & record.keys()
            if overlap:
                repeated = ", ".join(
                    f"{a}.{p}" for a, p in sorted(overlap)
                )
                raise GoalError(f"Repeated parameters while expanding goal: {repeated}")
            parameters.update(record)

        nested = unflatten_to_nested_parameters(parameters)

        for iter_value in iter_values:
            yield canonical_calc_payload(
                templates=templates_table,
                parameters=nested,
                iter_value=iter_value,
            )


def _all_template_params(
    templates: Mapping[str, Mapping[str, Any]],
) -> set[AliasParam]:
    """Build set of (alias, param) for all templates."""
    result: set[AliasParam] = set()
    for alias, template in templates.items():
        _validate_template(template, alias)
        for item in template.get("parameters", []):
            name = item.get("name")
            if not isinstance(name, str) or not name:
                raise TemplateError(
                    f"Template {alias!r} parameter must have a string name"
                )
            result.add((alias, name))
    return result


def _validate_template(template: Mapping[str, Any], alias: str) -> None:
    """Validate a template has no [[groups]]."""
    if "groups" in template:
        raise TemplateError(
            f"Template {alias!r} contains [[groups]] which is no longer "
            f"supported. Remove [[groups]] from the template file."
        )

    raw_parameters = template.get("parameters")
    if not isinstance(raw_parameters, list):
        raise TemplateError(f"Template {alias!r} must contain [[parameters]]")

    names: set[str] = set()
    for index, item in enumerate(raw_parameters, start=1):
        if not isinstance(item, dict):
            raise TemplateError(
                f"Template {alias!r} parameter #{index} must be a table"
            )
        name = item.get("name")
        if not isinstance(name, str) or not name:
            raise TemplateError(
                f"Template {alias!r} parameter #{index} must have a string name"
            )
        if name in names:
            raise TemplateError(
                f"Template {alias!r} has duplicate parameter: {name}"
            )
        names.add(name)

    if not names:
        raise TemplateError(f"Template {alias!r} must define at least one parameter")


def canonical_calc_payload(
    *,
    templates: Mapping[str, str],
    parameters: Mapping[str, Mapping[str, Any]],
    iter_value: Any,
) -> JsonObject:
    """
    Build the semantic payload used for hashing and writing *.c.toml.

    Only this payload is hashed. Comments, TOML formatting, goal filename,
    goal description, updated_at, status, paths and source information are
    intentionally excluded.
    """
    return {
        "templates": dict(templates),
        "parameters": {
            alias: dict(sorted(params.items()))
            for alias, params in parameters.items()
        },
        "iter": {"value": iter_value},
    }


def canonical_json(payload: Mapping[str, Any]) -> str:
    """Return deterministic JSON used as the SHA256 input."""
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def calc_sha256(payload: Mapping[str, Any]) -> str:
    """Return SHA256 of the canonical JSON payload."""
    text = canonical_json(payload)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def calc_id_from_sha(
    sha256: str,
    *,
    prefix: str = "",
    hash_len: int | None = 64,
) -> str:
    """Build a calc ID from a SHA256 digest."""
    if hash_len is None:
        hash_part = sha256
    else:
        if hash_len <= 0 or hash_len > 64:
            raise ValueError("hash_len must be in 1..64, or None")
        hash_part = sha256[:hash_len]

    if not prefix:
        return hash_part

    return f"{prefix}_{hash_part}"


def write_calc_file(
    path: str | Path,
    payload: Mapping[str, Any],
    *,
    overwrite: bool = False,
) -> bool:
    """
    Write one *.c.toml file.

    Returns True if a file was created or overwritten.
    Returns False if the file already existed and overwrite=False.
    """
    path = Path(path)
    text = render_calc_toml(payload)

    if path.exists() and path.is_dir():
        raise CalcWriteError(f"Cannot write calc file; path is a directory: {path}")

    if path.exists() and not overwrite:
        return False

    path.write_text(text, encoding="utf-8")
    return True


def render_calc_toml(payload: Mapping[str, Any]) -> str:
    """Render a canonical calc payload as TOML with dotted-key parameters."""
    templates = payload.get("templates")
    if not isinstance(templates, dict):
        raise CalcWriteError("calc payload must contain [templates] table")

    parameters = payload.get("parameters")
    if not isinstance(parameters, dict):
        raise CalcWriteError("calc payload must contain [parameters] table")

    iter_table = payload.get("iter")
    if not isinstance(iter_table, dict) or "value" not in iter_table:
        raise CalcWriteError("calc payload must contain [iter].value")

    lines: list[str] = []

    lines.append("[templates]")
    for alias, template_name in templates.items():
        lines.append(f"{_toml_key(alias)} = {_toml_scalar(template_name)}")
    lines.append("")

    lines.append("[parameters]")
    for alias in parameters.keys():
        alias_params = parameters[alias]
        if not isinstance(alias_params, dict):
            raise CalcWriteError(
                f"calc payload parameters[{alias!r}] must be a table"
            )
        for param_name, value in sorted(alias_params.items()):
            dotted = f"{alias}.{param_name}"
            lines.append(f"{dotted} = {_toml_scalar(value)}")
    lines.append("")

    lines.append("[iter]")
    lines.append(f"value = {_toml_scalar(iter_table['value'])}")
    lines.append("")

    return "\n".join(lines)


def _reject_old_template_field(goal: Mapping[str, Any], owner: str) -> None:
    if "template" in goal:
        raise GoalError(
            f"{owner}: old field 'template' is no longer supported. "
            f"Use [templates] with alias = \"file.t.toml\" instead."
        )


def _require_templates(goal: Mapping[str, Any], owner: str) -> dict[str, str]:
    raw = goal.get("templates")
    if not isinstance(raw, dict) or not raw:
        raise GoalError(f"{owner} must contain [templates] table")

    result: dict[str, str] = {}
    seen_files: dict[str, str] = {}
    for alias, template_name in raw.items():
        if not isinstance(alias, str) or not alias:
            raise GoalError(f"{owner} [templates] alias must be a non-empty string")
        if not _ALIAS_RE.match(alias):
            raise GoalError(
                f"{owner} [templates] alias {alias!r} is not valid. "
                f"Alias must match ^[A-Za-z_][A-Za-z0-9_]*$"
            )
        if not isinstance(template_name, str) or not template_name:
            raise GoalError(
                f"{owner} [templates] value for {alias!r} must be a non-empty string"
            )
        if alias in result:
            raise GoalError(f"{owner} [templates] has duplicate alias: {alias!r}")
        if template_name in seen_files:
            raise GoalError(
                f"Duplicate template file in [templates]: {template_name!r} is "
                f"referenced by aliases {seen_files[template_name]!r} and "
                f"{alias!r}. The first version of tgcalc does not support "
                f"using the same t.toml multiple times in one goal."
            )
        seen_files[template_name] = alias
        result[alias] = template_name

    return result


def _require_value_groups(goal: Mapping[str, Any]) -> list[dict[str, Any]]:
    raw = goal.get("value_groups")

    if not isinstance(raw, list) or not raw:
        raise GoalError("Goal must contain at least one [[value_groups]] table")

    groups: list[dict[str, Any]] = []

    for index, group in enumerate(raw, start=1):
        if not isinstance(group, dict) or not group:
            raise GoalError(f"value_group #{index} must be a non-empty table")
        groups.append(group)

    return groups


def _flatten_and_validate_value_groups(
    value_groups: Sequence[Mapping[str, Any]],
    templates_table: Mapping[str, str],
    templates: Mapping[str, Mapping[str, Any]],
    all_template_params: set[AliasParam],
) -> list[dict[AliasParam, Any]]:
    """Flatten nested value_groups and validate against templates."""
    flat_groups: list[dict[AliasParam, Any]] = []
    seen: set[AliasParam] = set()

    for group_index, group in enumerate(value_groups, start=1):
        flat: dict[AliasParam, Any] = {}

        for key, value in group.items():
            if isinstance(value, dict):
                alias = key
                if alias not in templates_table:
                    raise GoalError(
                        f"value_group #{group_index} references unknown "
                        f"template alias: {alias!r}"
                    )
                for param_name, param_values in value.items():
                    ap = (alias, param_name)
                    if ap not in all_template_params:
                        raise GoalError(
                            f"value_group #{group_index} contains parameter "
                            f"not in template: {alias}.{param_name}"
                        )
                    if ap in seen:
                        raise GoalError(
                            f"Parameter appears in multiple value_groups: "
                            f"{alias}.{param_name}"
                        )
                    _validate_param_values(
                        ap, param_values, group_index,
                    )
                    flat[ap] = param_values
                    seen.add(ap)
            elif isinstance(value, list):
                if "." in key:
                    raise GoalError(
                        f"value_group #{group_index}: quoted dotted key "
                        f"{key!r} is not allowed. Use bare dotted key "
                        f"notation instead, e.g. md.temperature = [300]"
                    )
                raise GoalError(
                    f"value_group #{group_index}: bare parameter {key!r} "
                    f"is not allowed. Use alias.parameter notation, "
                    f"e.g. model.{key} = [...] "
                    f"(alias must be declared in [templates])"
                )
            else:
                raise GoalError(
                    f"value_group #{group_index}: unexpected value type "
                    f"for key {key!r}: {type(value).__name__}"
                )

        if not flat:
            raise GoalError(f"value_group #{group_index} must be a non-empty table")

        lengths = {len(v) for v in flat.values()}
        if len(lengths) != 1:
            raise GoalError(
                f"value_group #{group_index} has arrays with different lengths"
            )

        flat_groups.append(flat)

    missing = all_template_params - seen
    if missing:
        missing_str = ", ".join(f"{a}.{p}" for a, p in sorted(missing))
        raise GoalError(
            "Goal is missing template parameters: " + missing_str
        )

    return flat_groups


def _validate_param_values(
    ap: AliasParam,
    values: Any,
    group_index: int,
) -> None:
    alias, name = ap
    if not isinstance(values, list):
        raise GoalError(
            f"Parameter {alias}.{name!r} must be an array; "
            f"fixed values must also be arrays, e.g. "
            f"{alias}.{name} = [300]"
        )
    if not values:
        raise GoalError(
            f"Parameter {alias}.{name!r} has an empty value array"
        )
    _validate_scalar_list(f"{alias}.{name}", values)


def _matches_template_type(value: Any, expected_type: str) -> bool:
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "number":
        return (isinstance(value, int | float)) and not isinstance(value, bool)
    if expected_type == "boolean":
        return isinstance(value, bool)
    return False


def _goal_value_type_name(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, str):
        return "string"
    if isinstance(value, int | float):
        return "number"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "table"
    return type(value).__name__


def _format_value(value: Any) -> str:
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    return repr(value)


def _expand_flat_value_group(
    group: Mapping[AliasParam, Any],
) -> list[dict[AliasParam, Any]]:
    names = list(group.keys())
    first_values = group[names[0]]
    if not isinstance(first_values, list):
        raise GoalError(f"Parameter {names[0]!r} must be an array")

    records: list[dict[AliasParam, Any]] = []

    for index in range(len(first_values)):
        records.append({name: group[name][index] for name in names})

    return records


def _iter_values(goal: Mapping[str, Any]) -> list[Any]:
    raw_iter = goal.get("iter")

    if raw_iter is None:
        return [1]

    if not isinstance(raw_iter, dict):
        raise GoalError("[iter] must be a table")

    repeat = raw_iter.get("repeat")
    values = raw_iter.get("values")

    if repeat is not None and values is not None:
        raise GoalError(
            "[iter] cannot have both 'repeat' and 'values'"
        )

    if repeat is not None:
        if not isinstance(repeat, int) or repeat < 1:
            raise GoalError(
                "[iter].repeat must be a positive integer"
            )
        return list(range(1, repeat + 1))

    if values is not None:
        if not isinstance(values, list) or not values:
            raise GoalError("[iter].values must be a non-empty array")
        _validate_scalar_list("iter.values", values)
        return values

    return [1]


def _validate_scalar_list(name: str, values: list[Any]) -> None:
    for value in values:
        try:
            _toml_scalar(value)
        except TypeError as exc:
            raise GoalError(
                f"{name!r} contains unsupported value: {value!r}"
            ) from exc


def _require_str(mapping: Mapping[str, Any], key: str, *, owner: str) -> str:
    value = mapping.get(key)
    if not isinstance(value, str) or not value:
        raise TgCalcError(f"{owner} must contain non-empty string field {key!r}")
    return value


def _toml_key(key: str) -> str:
    is_bare = bool(key) and all(
        ch.isascii() and (ch.isalnum() or ch in "_-") for ch in key
    )
    if is_bare:
        return key
    return json.dumps(key, ensure_ascii=False)


def _toml_scalar(value: Any) -> str:
    """
    Render a supported Python scalar as TOML.

    Supported values:
    - str
    - bool
    - int
    - float

    Arrays are intentionally not needed in *.c.toml, because concrete calc
    files contain exactly one value per parameter.
    """
    if isinstance(value, bool):
        return "true" if value else "false"

    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)

    if isinstance(value, float):
        if math.isnan(value):
            raise TypeError("NaN is not supported in tgcalc TOML output")
        if math.isinf(value):
            raise TypeError("Infinity is not supported in tgcalc TOML output")
        return repr(value)

    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)

    raise TypeError(f"Unsupported TOML scalar type: {type(value).__name__}")
