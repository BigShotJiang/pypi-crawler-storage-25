"""Goal index: calc filename stem to varying parameter values."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Literal

from tgcalc.core import (
    GoalError,
    _reject_old_template_field,
    _require_templates,
    calc_id_from_sha,
    calc_sha256,
    expand_goal,
    load_toml,
)


def build_goal_index(
    goal_path: str | Path,
    *,
    template_dir: str | Path,
    hash_len: int | None = 64,
    variables: Literal["varying", "all"] | Sequence[str] = "varying",
    file_prefix: str = "",
) -> dict[str, dict[str, Any]]:
    """Build a mapping from calc file stem to parameter values.

    The returned keys are exactly the filename stems that
    :func:`~tgcalc.core.expand_goal_file` would produce for the same
    *goal_path*, *template_dir*, *hash_len*, and *file_prefix*.

    Parameters
    ----------
    goal_path:
        Path to a ``*.g.toml`` file.
    template_dir:
        Directory containing the referenced ``*.t.toml`` files.
    hash_len:
        Hash prefix length, must match the value used by ``expand``.
    variables:
        ``"varying"`` (default) — only include parameters whose values
        actually differ across the expanded calcs, plus ``iter.value``
        when there are multiple iter values.

        ``"all"`` — include every parameter and ``iter.value``.

        A list of field names — include only those fields (e.g.
        ``["model.height_layers", "iter.value"]``).
    file_prefix:
        Optional filename prefix, must match the value used by ``expand``.
    """
    goal_path = Path(goal_path)
    template_dir = Path(template_dir)

    goal = load_toml(goal_path)
    _reject_old_template_field(goal, str(goal_path))
    templates_table = _require_templates(goal, str(goal_path))

    templates: dict[str, Mapping[str, Any]] = {}
    for alias, tpl_name in templates_table.items():
        templates[alias] = load_toml(template_dir / tpl_name)

    payloads = list(expand_goal(goal, templates=templates))

    iter_values_raw = goal.get("iter", {})
    iter_values: list[Any] = [1]
    if isinstance(iter_values_raw, dict):
        v = iter_values_raw.get("values")
        if isinstance(v, list) and v:
            iter_values = v

    raw_entries: list[tuple[str, dict[str, Any], Any]] = []
    seen_sha: set[str] = set()

    for payload in payloads:
        sha = calc_sha256(payload)
        if sha in seen_sha:
            continue
        seen_sha.add(sha)

        stem = calc_id_from_sha(sha, prefix=file_prefix, hash_len=hash_len)
        flat = _flatten_parameters(payload.get("parameters", {}))
        iter_val = payload.get("iter", {}).get("value", 1)
        raw_entries.append((stem, flat, iter_val))

    if isinstance(variables, str):
        if variables == "all":
            return {
                stem: {**flat, "iter.value": iter_val}
                for stem, flat, iter_val in raw_entries
            }
        if variables != "varying":
            raise GoalError(
                f"variables must be 'varying', 'all', or a list of "
                f"field names, got {variables!r}"
            )

        return _build_varying_index(raw_entries, iter_values)

    return _build_explicit_index(raw_entries, variables)


def _flatten_parameters(
    parameters: Mapping[str, Any],
) -> dict[str, Any]:
    flat: dict[str, Any] = {}
    for alias, params in parameters.items():
        if isinstance(params, dict):
            for name, value in params.items():
                flat[f"{alias}.{name}"] = value
        else:
            flat[alias] = params
    return flat


def _build_varying_index(
    entries: list[tuple[str, dict[str, Any], Any]],
    iter_values: list[Any],
) -> dict[str, dict[str, Any]]:
    if not entries:
        return {}

    all_fields: set[str] = set()
    for _, flat, _ in entries:
        all_fields.update(flat.keys())

    varying: set[str] = set()
    for field in all_fields:
        unique = {flat.get(field) for _, flat, _ in entries}
        if len(unique) > 1:
            varying.add(field)

    include_iter = len(iter_values) > 1

    result: dict[str, dict[str, Any]] = {}
    for stem, flat, iter_val in entries:
        row: dict[str, Any] = {}
        if include_iter:
            row["iter.value"] = iter_val
        for field in sorted(varying):
            row[field] = flat[field]
        result[stem] = row

    return result


def _build_explicit_index(
    entries: list[tuple[str, dict[str, Any], Any]],
    fields: Sequence[str],
) -> dict[str, dict[str, Any]]:
    if not entries:
        return {}

    _, sample_flat, _ = entries[0]
    available = set(sample_flat.keys()) | {"iter.value"}

    for field in fields:
        if field not in available:
            raise GoalError(
                f"Requested field {field!r} is not available. "
                f"Available fields: {', '.join(sorted(available))}"
            )

    result: dict[str, dict[str, Any]] = {}
    for stem, flat, iter_val in entries:
        row: dict[str, Any] = {}
        for field in fields:
            if field == "iter.value":
                row[field] = iter_val
            else:
                row[field] = flat[field]
        result[stem] = row

    return result
