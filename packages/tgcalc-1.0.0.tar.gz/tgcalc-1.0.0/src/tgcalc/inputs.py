"""Calc input generation via template functions and explicit bindings."""

from __future__ import annotations

import functools
import inspect
import os
import shutil
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypeVar

from tgcalc.core import TgCalcError, load_toml

_TF_META = "__tgcalc_template_function__"
_TF_ALIAS = "__tgcalc_alias__"
_TF_TPLFILE = "__tgcalc_template_file__"


class InputGenError(TgCalcError):
    """Base error for input generation."""


class InvalidTemplateFunctionError(InputGenError):
    """Raised when a template function has an invalid signature."""


class BindingError(InputGenError):
    """Raised when bindings are invalid or mismatched."""


class MissingParameterError(InputGenError):
    """Raised when a required parameter is missing."""


class DuplicateTemplateFileError(InputGenError):
    """Raised when the same t.toml is referenced by multiple aliases."""


_F = TypeVar("_F", bound=Callable[..., Any])


def template_function(
    template_file: str,
) -> Callable[[_F], _F]:
    """Decorator marking a function as accepting a specific template's params.

    Usage::

        @template_function("model.t.toml")
        def generate_model_inputs(model):
            ...

    The decorated function must accept exactly one positional argument.
    When called, the wrapper verifies that the passed
    :class:`TemplateParams` object was built from the expected template.
    """

    if not template_file or not isinstance(template_file, str):
        raise InvalidTemplateFunctionError(
            "template_file must be a non-empty string."
        )

    def decorator(fn: _F) -> _F:
        if not callable(fn):
            raise InvalidTemplateFunctionError(
                f"@template_function can only decorate callable objects, "
                f"got {type(fn).__name__}."
            )

        sig = inspect.signature(fn)
        params = [
            p
            for p in sig.parameters.values()
            if p.kind
            in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ]
        if len(params) != 1:
            raise InvalidTemplateFunctionError(
                f"Template function {fn.__name__!r} must accept exactly "
                f"one argument: params."
            )

        @functools.wraps(fn)
        def wrapper(params: Any) -> Any:
            if isinstance(params, TemplateParams):
                actual = getattr(params, _TF_TPLFILE, None)
                if actual is not None and actual != template_file:
                    raise BindingError(
                        f"Template mismatch:\n"
                        f"  function {fn.__name__!r} expects "
                        f"{template_file}\n"
                        f"  got {actual}"
                    )
            return fn(params)

        setattr(
            wrapper,
            _TF_META,
            {
                "template_file": template_file,
                "name": fn.__name__,
            },
        )
        return wrapper  # type: ignore[return-value]

    return decorator


def _get_tf_meta(fn: Any) -> dict[str, Any] | None:
    return getattr(fn, _TF_META, None)


class TemplateParams:
    """Read-only parameter object with attribute and dict access.

    Each instance carries metadata about its source alias and template
    file, used by ``@template_function`` for mismatch detection.
    """

    def __init__(
        self,
        values: Mapping[str, Any],
        *,
        alias: str,
        template_file: str,
    ) -> None:
        object.__setattr__(self, "_data", dict(values))
        object.__setattr__(self, _TF_ALIAS, alias)
        object.__setattr__(self, _TF_TPLFILE, template_file)

    def __getattr__(self, name: str) -> Any:
        data = object.__getattribute__(self, "_data")
        if name in data:
            return data[name]
        alias = object.__getattribute__(self, _TF_ALIAS)
        tpl = object.__getattribute__(self, _TF_TPLFILE)
        raise MissingParameterError(
            f"Missing parameter {name!r} for alias {alias} "
            f"from template {tpl}."
        )

    def __getitem__(self, name: str) -> Any:
        data = object.__getattribute__(self, "_data")
        if name in data:
            return data[name]
        alias = object.__getattribute__(self, _TF_ALIAS)
        tpl = object.__getattribute__(self, _TF_TPLFILE)
        raise MissingParameterError(
            f"Missing parameter {name!r} for alias {alias} "
            f"from template {tpl}."
        )

    def get(self, name: str, default: Any = None) -> Any:
        data = object.__getattribute__(self, "_data")
        return data.get(name, default)

    def __contains__(self, name: object) -> bool:
        data = object.__getattribute__(self, "_data")
        return name in data

    def __iter__(self) -> Any:
        return iter(object.__getattribute__(self, "_data"))

    def __len__(self) -> int:
        return len(object.__getattribute__(self, "_data"))

    def to_dict(self) -> dict[str, Any]:
        return dict(object.__getattribute__(self, "_data"))

    def __repr__(self) -> str:
        data = object.__getattribute__(self, "_data")
        alias = object.__getattribute__(self, _TF_ALIAS)
        tpl = object.__getattribute__(self, _TF_TPLFILE)
        return f"TemplateParams({data!r}, alias={alias!r}, template={tpl!r})"


class Calc:
    """Parsed ``*.c.toml`` with attribute access to per-alias parameter sets.

    Usage::

        calc = load_calc("path/to.c.toml")
        calc.model              # TemplateParams for the "model" alias
        calc["model"]           # same
        calc.get("model.size")  # dotted access
        calc.require("model.size")
    """

    def __init__(
        self,
        calc_id: str,
        path: Path,
        templates: dict[str, str],
        parameters: dict[str, dict[str, Any]],
        iter_value: Any,
    ) -> None:
        object.__setattr__(self, "_calc_id", calc_id)
        object.__setattr__(self, "_path", path)
        object.__setattr__(self, "_templates", dict(templates))
        object.__setattr__(self, "_iter_value", iter_value)
        params_map: dict[str, TemplateParams] = {}
        for alias, tpl_file in templates.items():
            raw = parameters.get(alias, {})
            params_map[alias] = TemplateParams(
                raw, alias=alias, template_file=tpl_file,
            )
        object.__setattr__(self, "_params", params_map)

    @property
    def calc_id(self) -> str:
        return str(object.__getattribute__(self, "_calc_id"))

    @property
    def path(self) -> Path:
        return Path(object.__getattribute__(self, "_path"))

    @property
    def templates(self) -> dict[str, str]:
        return dict(object.__getattribute__(self, "_templates"))

    @property
    def iter(self) -> Any:
        return object.__getattribute__(self, "_iter_value")

    def __getattr__(self, alias: str) -> TemplateParams:
        params: dict[str, TemplateParams] = object.__getattribute__(self, "_params")
        if alias in params:
            return params[alias]
        raise AttributeError(
            f"Calc has no alias {alias!r}. "
            f"Available aliases: {', '.join(params)}"
        )

    def __getitem__(self, alias: str) -> TemplateParams:
        params: dict[str, TemplateParams] = object.__getattribute__(self, "_params")
        if alias in params:
            return params[alias]
        raise KeyError(alias)

    def get(self, dotted: str, default: Any = None) -> Any:
        if "." in dotted:
            alias, _, param = dotted.partition(".")
            params = object.__getattribute__(self, "_params")
            tp = params.get(alias)
            if tp is not None and param in tp:
                return tp[param]
        return default

    def require(self, dotted: str) -> Any:
        if "." in dotted:
            alias, _, param = dotted.partition(".")
            params = object.__getattribute__(self, "_params")
            tp = params.get(alias)
            if tp is not None:
                return tp[param]
        raise MissingParameterError(
            f"Missing parameter {dotted!r}."
        )


def load_calc(calc_path: str | Path) -> Calc:
    """Load a ``*.c.toml`` file into a :class:`Calc` object."""
    calc_path = Path(calc_path)
    data = load_toml(calc_path)
    _validate_calc(data, str(calc_path))

    templates: dict[str, str] = data["templates"]
    parameters: dict[str, dict[str, Any]] = data.get("parameters", {})
    iter_table = data.get("iter", {})
    iter_value = (
        iter_table.get("value", 1) if isinstance(iter_table, dict) else 1
    )

    name = calc_path.name
    calc_id = (
        name.removesuffix(".c.toml") if name.endswith(".c.toml")
        else calc_path.stem
    )

    return Calc(
        calc_id=calc_id,
        path=calc_path,
        templates=templates,
        parameters=parameters,
        iter_value=iter_value,
    )


@dataclass
class InputGenerationResult:
    """Outcome of :func:`generate_inputs`."""

    calc_id: str
    calc_path: Path
    input_dir: Path
    functions_called: list[str]
    templates_processed: list[str]


def generate_inputs(
    calc_path: str | Path,
    input_dir: str | Path = ".",
    *,
    bindings: Sequence[Callable[..., Any]],
    temp_dir: str | Path | None = None,
    overwrite: bool = False,
    keep_temp_on_error: bool = True,
) -> InputGenerationResult:
    """Generate input files for a calc by calling template functions.

    Parameters
    ----------
    calc_path:
        Path to a ``*.c.toml`` file.
    input_dir:
        Base directory.  A subdirectory named after the calc file stem
        is created inside it (e.g. ``inputs/abc123/``).
    bindings:
        List of callables decorated with ``@template_function``.  The
        template file is extracted from each function's metadata; the
        binding set must exactly match the calc's ``[templates]``.
    temp_dir:
        Override for the temporary working directory.
    overwrite:
        If *True*, delete the output and temp directories if they
        already exist.
    keep_temp_on_error:
        If *True* (default), keep the temp directory on failure so
        users can inspect partial output.
    """
    calc_path = Path(calc_path).resolve()
    base_dir = Path(input_dir).resolve()

    calc = load_calc(calc_path)

    binding_map = _resolve_bindings(bindings, calc)

    out_dir = base_dir / calc.calc_id

    if out_dir.exists():
        if overwrite:
            shutil.rmtree(out_dir)
        else:
            raise InputGenError(
                f"Input directory already exists: {out_dir}. "
                f"Use overwrite=True to replace it."
            )

    if temp_dir is None:
        tmp = out_dir.parent / (out_dir.name + ".tmp")
    else:
        tmp = Path(temp_dir).resolve()

    if tmp.exists():
        if overwrite:
            shutil.rmtree(tmp)
        else:
            raise InputGenError(
                f"Temp directory already exists: {tmp}. "
                f"Use overwrite=True to replace it."
            )

    tmp.mkdir(parents=True, exist_ok=True)

    original_cwd = Path.cwd()
    functions_called: list[str] = []
    templates_processed: list[str] = []

    try:
        os.chdir(tmp)

        for alias, tpl_file in calc.templates.items():
            func = binding_map[tpl_file]
            params = calc[alias]
            func(params)
            functions_called.append(getattr(func, "__name__", repr(func)))
            templates_processed.append(tpl_file)

    except Exception:
        os.chdir(original_cwd)
        if keep_temp_on_error:
            pass
        else:
            shutil.rmtree(tmp, ignore_errors=True)
        raise
    else:
        os.chdir(original_cwd)
        shutil.move(str(tmp), str(out_dir))
    finally:
        os.chdir(original_cwd)

    return InputGenerationResult(
        calc_id=calc.calc_id,
        calc_path=calc_path,
        input_dir=out_dir,
        functions_called=functions_called,
        templates_processed=templates_processed,
    )


def _resolve_bindings(
    bindings: Sequence[Callable[..., Any]],
    calc: Calc,
) -> dict[str, Callable[..., Any]]:
    if not bindings:
        raise BindingError("bindings must not be empty.")

    mapping: dict[str, Callable[..., Any]] = {}

    for func in bindings:
        if not callable(func):
            raise BindingError(
                f"Binding item {func!r} is not callable."
            )
        meta = _get_tf_meta(func)
        if meta is None:
            raise BindingError(
                f"{getattr(func, '__name__', repr(func))!r} is not "
                f"decorated with @template_function. Cannot use as "
                f"binding."
            )
        tpl_file = meta["template_file"]
        if tpl_file in mapping:
            raise BindingError(
                f"Duplicate binding for template {tpl_file!r}: "
                f"both {mapping[tpl_file].__name__!r} and "
                f"{meta['name']!r} declare the same template."
            )
        mapping[tpl_file] = func

    calc_tpls = set(calc.templates.values())

    missing = calc_tpls - set(mapping.keys())
    if missing:
        raise BindingError(
            f"Calc requires bindings for: "
            f"{', '.join(sorted(missing))}"
        )

    extra = set(mapping.keys()) - calc_tpls
    if extra:
        raise BindingError(
            f"Bindings contain templates not in calc: "
            f"{', '.join(sorted(extra))}"
        )

    return mapping


def _validate_calc(calc: dict[str, Any], owner: str) -> None:
    if "template" in calc:
        raise InputGenError(
            f"{owner}: old field 'template' is no longer supported. "
            f"Use [templates] instead."
        )

    templates = calc.get("templates")
    if not isinstance(templates, dict) or not templates:
        raise InputGenError(f"{owner} must contain [templates] table")

    parameters = calc.get("parameters")
    if not isinstance(parameters, dict):
        raise InputGenError(f"{owner} must contain [parameters] table")

    seen_files: dict[str, str] = {}
    for alias, tf in templates.items():
        if not isinstance(tf, str) or not tf:
            raise InputGenError(
                f"{owner} [templates] value for alias {alias!r} "
                f"must be a non-empty string."
            )
        if tf in seen_files:
            raise DuplicateTemplateFileError(
                f"Duplicate template file in [templates]: {tf!r} is "
                f"referenced by aliases {seen_files[tf]!r} and {alias!r}. "
                f"The first version of tgcalc does not support using the "
                f"same t.toml multiple times in one goal."
            )
        seen_files[tf] = alias
