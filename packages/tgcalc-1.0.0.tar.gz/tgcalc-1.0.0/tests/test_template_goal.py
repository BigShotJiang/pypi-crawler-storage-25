from __future__ import annotations

from typing import Any

import pytest

from tgcalc.compat import (
    SpecError,
    check_template_goal_compatibility,
)


def test_template_goal_valid() -> None:
    result = check_template_goal_compatibility(
        _templates(
            ("t", _param("material", "string", "dimensionless"),
             _param("temperature", "number", "K"),
             _param("periodic_z", "boolean", "dimensionless")),
        ),
        _goal(
            {"t": {"material": ["Au"], "temperature": [300], "periodic_z": [False]}},
        ),
    )

    assert result.valid is True
    assert result.summary() == "Goal/template are valid."


def test_goal_missing_templates_field_is_invalid() -> None:
    goal = _goal({"t": {"temperature": [300]}})
    del goal["templates"]

    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        goal,
    )

    assert result.valid is False
    assert any("templates" in issue for issue in result.structure_issues)


def test_goal_old_template_field_is_invalid() -> None:
    goal: dict[str, Any] = {
        "template": "template.t.toml",
        "templates": {"t": "template.t.toml"},
        "value_groups": [{"t": {"temperature": [300]}}],
    }

    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        goal,
    )

    assert result.valid is False
    assert any("no longer supported" in issue for issue in result.structure_issues)


def test_goal_missing_value_groups_raises_spec_error() -> None:
    goal: dict[str, Any] = {"templates": {"t": "template.t.toml"}}

    with pytest.raises(SpecError, match="value_groups"):
        check_template_goal_compatibility(
            _templates(("t", _param("temperature", "number", "K"))),
            goal,
        )


@pytest.mark.parametrize("missing_field", ["name", "type", "unit"])
def test_template_parameter_missing_required_field_raises_spec_error(
    missing_field: str,
) -> None:
    parameter = _param("temperature", "number", "K")
    del parameter[missing_field]

    with pytest.raises(SpecError, match=missing_field):
        check_template_goal_compatibility(
            {"t": {"parameters": [parameter]}},
            _goal({"t": {"temperature": [300]}}),
        )


def test_duplicate_template_parameter_raises_spec_error() -> None:
    with pytest.raises(SpecError, match="duplicate parameter"):
        check_template_goal_compatibility(
            {"t": {"parameters": [
                _param("temperature", "number", "K"),
                _param("temperature", "number", "K"),
            ]}},
            _goal({"t": {"temperature": [300]}}),
        )


def test_template_parameter_missing_from_goal_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(
            ("t", _param("temperature", "number", "K"),
             _param("height_layers", "number", "layers")),
        ),
        _goal({"t": {"temperature": [300]}}),
    )

    assert result.valid is False
    assert result.missing_goal_parameters == ["t.height_layers"]


def test_goal_parameter_unknown_to_template_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal({"t": {"temperature": [300], "height": [3, 5]}}),
    )

    assert result.valid is False
    assert result.unknown_goal_parameters == ["t.height"]


def test_duplicate_goal_parameter_across_value_groups_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal(
            {"t": {"temperature": [300]}},
            {"t": {"temperature": [500]}},
        ),
    )

    assert result.valid is False
    assert result.duplicate_goal_parameters == ["t.temperature"]


def test_goal_fixed_value_must_be_array() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal({"t": {"temperature": 300}}),
    )

    assert result.valid is False
    assert result.non_array_values == ["t.temperature"]


def test_value_group_length_mismatch_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(
            ("t", _param("height_layers", "number", "layers"),
             _param("periodic_z", "boolean", "dimensionless")),
        ),
        _goal({"t": {"height_layers": [3, 5, 10], "periodic_z": [False, True]}}),
    )

    assert result.valid is False
    assert len(result.value_group_length_mismatches) == 1
    mismatch = result.value_group_length_mismatches[0]
    assert mismatch.group_index == 1
    assert mismatch.lengths == {"t.height_layers": 3, "t.periodic_z": 2}


def test_string_type_check() -> None:
    valid = check_template_goal_compatibility(
        _templates(("t", _param("material", "string", "dimensionless"))),
        _goal({"t": {"material": ["Au"]}}),
    )
    invalid = check_template_goal_compatibility(
        _templates(("t", _param("material", "string", "dimensionless"))),
        _goal({"t": {"material": [300]}}),
    )

    assert valid.valid is True
    assert invalid.valid is False
    assert invalid.type_mismatches[0].actual_type == "number"


def test_number_type_check_excludes_bool() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal({"t": {"temperature": [300, 300.5, True]}}),
    )

    assert result.valid is False
    assert len(result.type_mismatches) == 1
    assert result.type_mismatches[0].parameter == "t.temperature"
    assert result.type_mismatches[0].index == 2
    assert result.type_mismatches[0].actual_type == "boolean"


def test_boolean_type_check() -> None:
    valid = check_template_goal_compatibility(
        _templates(("t", _param("periodic_z", "boolean", "dimensionless"))),
        _goal({"t": {"periodic_z": [False, True]}}),
    )
    invalid = check_template_goal_compatibility(
        _templates(("t", _param("periodic_z", "boolean", "dimensionless"))),
        _goal({"t": {"periodic_z": ["false"]}}),
    )

    assert valid.valid is True
    assert invalid.valid is False
    assert invalid.type_mismatches[0].actual_type == "string"


def test_multiple_goal_template_issues_are_reported_together() -> None:
    result = check_template_goal_compatibility(
        _templates(
            ("t",
             _param("missing", "number", "dimensionless"),
             _param("duplicate", "number", "dimensionless"),
             _param("fixed", "number", "K"),
             _param("number_param", "number", "K"),
             _param("len_a", "number", "dimensionless"),
             _param("len_b", "number", "dimensionless")),
        ),
        _goal(
            {"t": {"duplicate": [1], "unknown": [1]}},
            {"t": {"duplicate": [2], "fixed": 300}},
            {"t": {"number_param": [False]}},
            {"t": {"len_a": [1, 2], "len_b": [3]}},
        ),
    )

    assert result.valid is False
    assert result.missing_goal_parameters == ["t.missing"]
    assert result.unknown_goal_parameters == ["t.unknown"]
    assert result.duplicate_goal_parameters == ["t.duplicate"]
    assert result.non_array_values == ["t.fixed"]
    assert [m.group_index for m in result.value_group_length_mismatches] == [4]
    assert [m.parameter for m in result.type_mismatches] == ["t.number_param"]

    summary = result.summary()
    assert "Template parameters missing from goal:" in summary
    assert "Goal parameters not defined by template:" in summary
    assert "Parameters appearing in multiple value_groups:" in summary
    assert "Goal values must be arrays:" in summary
    assert "Value group length mismatches:" in summary
    assert "Type mismatches:" in summary


def test_iter_values_valid_non_empty_array() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal({"t": {"temperature": [300]}}, iter_values=[1, 2]),
    )

    assert result.valid is True
    assert result.iter_issues == []


def test_iter_values_empty_array_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        _goal({"t": {"temperature": [300]}}, iter_values=[]),
    )

    assert result.valid is False
    assert result.iter_issues == ["[iter].values must be a non-empty array"]


def test_bare_parameter_in_value_group_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        {"templates": {"t": "t.t.toml"}, "value_groups": [{"temperature": [300]}]},
    )

    assert result.valid is False
    assert any("bare parameter" in issue for issue in result.structure_issues)


def test_quoted_dotted_key_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        {"templates": {"t": "t.t.toml"}, "value_groups": [{"t.temperature": [300]}]},
    )

    assert result.valid is False
    assert any("quoted dotted key" in issue for issue in result.structure_issues)


def test_unknown_alias_is_invalid() -> None:
    result = check_template_goal_compatibility(
        _templates(("t", _param("temperature", "number", "K"))),
        {
            "templates": {"t": "t.t.toml"},
            "value_groups": [{"x": {"temperature": [300]}}],
        },
    )

    assert result.valid is False
    assert any("unknown template alias" in issue for issue in result.structure_issues)


def _param(name: str, type_: str, unit: str) -> dict[str, str]:
    return {"name": name, "type": type_, "unit": unit}


def _templates(*alias_params: tuple[Any, ...]) -> dict[str, dict[str, Any]]:
    return {alias: {"parameters": list(params)} for alias, *params in alias_params}


def _goal(
    *value_groups: dict[str, Any],
    iter_values: list[Any] | None = None,
) -> dict[str, Any]:
    goal: dict[str, Any] = {
        "templates": {"t": "template.t.toml"},
        "value_groups": list(value_groups),
    }
    if iter_values is not None:
        goal["iter"] = {"values": iter_values}
    return goal

