"""Tests for tgcalc.index — build_goal_index."""

from __future__ import annotations

from pathlib import Path

import pytest

from tgcalc.core import GoalError, expand_goal_file
from tgcalc.index import build_goal_index


def _write_templates(template_dir: Path) -> None:
    template_dir.mkdir(parents=True, exist_ok=True)
    (template_dir / "model.t.toml").write_text(
        '[[parameters]]\nname = "chemical_formula"\ntype = "string"\n'
        'unit = "dimensionless"\n\n'
        '[[parameters]]\nname = "height_layers"\ntype = "number"\n'
        'unit = "layers"\n',
        encoding="utf-8",
    )
    (template_dir / "loading.t.toml").write_text(
        '[[parameters]]\nname = "strain_mode"\ntype = "string"\n'
        'unit = "dimensionless"\n\n'
        '[[parameters]]\nname = "strain_rate"\ntype = "number"\n'
        'unit = "s^-1"\n',
        encoding="utf-8",
    )


def _goal_text(
    height_layers: str = "[3]",
    strain_mode: str = '["x"]',
    iter_values: str = "[1]",
) -> str:
    return (
        "[templates]\n"
        'model = "model.t.toml"\n'
        'loading = "loading.t.toml"\n\n'
        "[[value_groups]]\n"
        'model.chemical_formula = ["Au"]\n\n'
        "[[value_groups]]\n"
        f"model.height_layers = {height_layers}\n\n"
        "[[value_groups]]\n"
        f"loading.strain_mode = {strain_mode}\n"
        "loading.strain_rate = [5e7]\n\n"
        "[iter]\n"
        f"values = {iter_values}\n"
    )


def test_keys_match_expand_stems(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1]"),
        encoding="utf-8",
    )

    calcs = expand_goal_file(
        goal, template_dir=tpl,
        output_dir=tmp_path / "calcs", hash_len=16,
    )
    index = build_goal_index(goal, template_dir=tpl, hash_len=16)

    expand_stems = {r.calc_id for r in calcs}
    assert set(index.keys()) == expand_stems


def test_varying_excludes_fixed(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1]"),
        encoding="utf-8",
    )

    index = build_goal_index(goal, template_dir=tpl, hash_len=16)
    for row in index.values():
        assert "model.height_layers" in row
        assert "model.chemical_formula" not in row
        assert "loading.strain_rate" not in row
        assert "iter.value" not in row


def test_varying_includes_iter_when_multiple(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(iter_values="[1, 2]"),
        encoding="utf-8",
    )

    index = build_goal_index(goal, template_dir=tpl, hash_len=16)
    for row in index.values():
        assert "iter.value" in row


def test_varying_linked_group_both_varying(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(
            height_layers="[3, 5, 10]",
            strain_mode='["x", "y", "z"]',
        ).replace(
            "loading.strain_rate = [5e7]",
            "loading.strain_rate = [5e7, 5e7, 5e7]",
        ),
        encoding="utf-8",
    )

    index = build_goal_index(goal, template_dir=tpl, hash_len=16)
    for row in index.values():
        assert "model.height_layers" in row
        assert "loading.strain_mode" in row
        assert "loading.strain_rate" not in row


def test_all_variables(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(_goal_text(), encoding="utf-8")

    index = build_goal_index(
        goal, template_dir=tpl, hash_len=16, variables="all",
    )
    for row in index.values():
        assert "model.chemical_formula" in row
        assert "model.height_layers" in row
        assert "loading.strain_rate" in row
        assert "iter.value" in row


def test_explicit_variables(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1, 2]"),
        encoding="utf-8",
    )

    index = build_goal_index(
        goal, template_dir=tpl, hash_len=16,
        variables=["model.height_layers", "iter.value"],
    )
    for row in index.values():
        assert set(row.keys()) == {"model.height_layers", "iter.value"}


def test_explicit_variables_missing_field(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(_goal_text(), encoding="utf-8")

    with pytest.raises(GoalError, match="not available"):
        build_goal_index(
            goal, template_dir=tpl, hash_len=16,
            variables=["nonexistent.field"],
        )


def test_prefix_matches_expand(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1]"),
        encoding="utf-8",
    )

    calcs = expand_goal_file(
        goal, template_dir=tpl,
        output_dir=tmp_path / "calcs", hash_len=16, file_prefix="gold",
    )
    index = build_goal_index(
        goal, template_dir=tpl, hash_len=16, file_prefix="gold",
    )

    expand_stems = {r.calc_id for r in calcs}
    assert set(index.keys()) == expand_stems
    for stem in index:
        assert stem.startswith("gold_")


def test_dedup_matches_expand(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1, 1]"),
        encoding="utf-8",
    )

    calcs = expand_goal_file(
        goal, template_dir=tpl,
        output_dir=tmp_path / "calcs", hash_len=16,
    )
    index = build_goal_index(goal, template_dir=tpl, hash_len=16)

    expand_stems = {r.calc_id for r in calcs}
    assert set(index.keys()) == expand_stems


def test_old_template_field_rejected(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "bad.g.toml"
    goal.write_text(
        'template = "model.t.toml"\n\n'
        "[[value_groups]]\n"
        'model.chemical_formula = ["Au"]\n'
        "model.height_layers = [3]\n\n"
        "[iter]\nvalues = [1]\n",
        encoding="utf-8",
    )

    with pytest.raises(GoalError, match="no longer supported"):
        build_goal_index(goal, template_dir=tpl, hash_len=16)


def test_no_groups_in_return(tmp_path: Path) -> None:
    tpl = tmp_path / "templates"
    _write_templates(tpl)
    goal = tmp_path / "test.g.toml"
    goal.write_text(
        _goal_text(height_layers="[3, 5]", iter_values="[1]"),
        encoding="utf-8",
    )

    index = build_goal_index(goal, template_dir=tpl, hash_len=16)
    for row in index.values():
        for key in row:
            assert "group" not in key.lower()
            assert "vg" not in key.lower()
