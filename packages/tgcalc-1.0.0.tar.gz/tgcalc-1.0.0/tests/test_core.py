from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import pytest

from tgcalc.core import (
    GoalError,
    TemplateError,
    calc_id_from_sha,
    calc_sha256,
    canonical_json,
    expand_goal,
    expand_goal_file,
    flatten_dotted_parameter_tree,
    unflatten_to_nested_parameters,
)


def _template(*names: str) -> dict[str, Any]:
    return {"parameters": [{"name": name} for name in names]}


def _templates(*aliases: str) -> dict[str, str]:
    return {a: f"{a}.t.toml" for a in aliases}


def _multi_templates(**alias_names: list[str]) -> dict[str, dict[str, Any]]:
    return {
        alias: _template(*names)
        for alias, names in alias_names.items()
    }


def test_missing_template_parameter_raises() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1]}}],
    }
    templates = {"t": _template("a", "b")}

    with pytest.raises(GoalError, match="missing template parameters"):
        list(expand_goal(goal, templates=templates))


def test_same_group_length_mismatch_raises() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1, 2], "b": [3]}}],
    }
    templates = {"t": _template("a", "b")}

    with pytest.raises(GoalError, match="different lengths"):
        list(expand_goal(goal, templates=templates))


def test_parameter_in_multiple_value_groups_raises() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [
            {"t": {"a": [1]}},
            {"t": {"a": [2], "b": [3]}},
        ],
    }
    templates = {"t": _template("a", "b")}

    with pytest.raises(GoalError, match="multiple value_groups"):
        list(expand_goal(goal, templates=templates))


def test_different_value_groups_use_cartesian_product() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [
            {"t": {"a": [1, 2]}},
            {"t": {"b": ["x", "y"]}},
            {"t": {"c": [True]}},
        ],
    }
    templates = {"t": _template("a", "b", "c")}

    payloads = list(expand_goal(goal, templates=templates))

    combos = set()
    for payload in payloads:
        p = payload["parameters"]["t"]
        combos.add((p["a"], p["b"], p["c"]))
    assert combos == {
        (1, "x", True),
        (1, "y", True),
        (2, "x", True),
        (2, "y", True),
    }


def test_same_group_parameters_are_zipped_by_position() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1, 2], "b": ["x", "y"]}}],
    }
    templates = {"t": _template("a", "b")}

    payloads = list(expand_goal(goal, templates=templates))

    assert [payload["parameters"]["t"] for payload in payloads] == [
        {"a": 1, "b": "x"},
        {"a": 2, "b": "y"},
    ]


def test_iter_values_participate_in_expansion() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1, 2]}}],
        "iter": {"values": [10, 20]},
    }
    templates = {"t": _template("a")}

    payloads = list(expand_goal(goal, templates=templates))

    assert [
        (payload["parameters"]["t"]["a"], payload["iter"]["value"])
        for payload in payloads
    ] == [(1, 10), (1, 20), (2, 10), (2, 20)]


def test_iter_repeat_participate_in_expansion() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1, 2]}}],
        "iter": {"repeat": 3},
    }
    templates = {"t": _template("a")}

    payloads = list(expand_goal(goal, templates=templates))

    assert [
        (payload["parameters"]["t"]["a"], payload["iter"]["value"])
        for payload in payloads
    ] == [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3)]


def test_iter_default_single() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1]}}],
    }
    templates = {"t": _template("a")}

    payloads = list(expand_goal(goal, templates=templates))

    assert len(payloads) == 1
    assert payloads[0]["iter"]["value"] == 1


def test_canonical_json_key_sorting_makes_hash_stable() -> None:
    payload_a = {
        "templates": {"t": "t.t.toml"},
        "parameters": {"t": {"b": 2, "a": 1}},
        "iter": {"value": 1},
    }
    payload_b = {
        "iter": {"value": 1},
        "parameters": {"t": {"a": 1, "b": 2}},
        "templates": {"t": "t.t.toml"},
    }

    assert canonical_json(payload_a) == canonical_json(payload_b)
    assert calc_sha256(payload_a) == calc_sha256(payload_b)
    expected = (
        '{"iter":{"value":1},"parameters":{"t":{"a":1,"b":2}},'
        '"templates":{"t":"t.t.toml"}}'
    )
    assert canonical_json(payload_a) == expected


def test_calc_id_defaults_to_hash_without_prefix() -> None:
    sha = "a" * 64

    assert calc_id_from_sha(sha, hash_len=16) == "a" * 16
    assert calc_id_from_sha(sha, prefix="calc", hash_len=16) == f"calc_{'a' * 16}"


def test_repeated_run_reuses_existing_calc_files(tmp_path: Path) -> None:
    template_dir = tmp_path / "templates"
    output_dir = tmp_path / "calcs"
    goal_path = tmp_path / "goals" / "simple.g.toml"
    _write_project_files(template_dir=template_dir, goal_path=goal_path)

    first = expand_goal_file(
        goal_path,
        template_dir=template_dir,
        output_dir=output_dir,
        hash_len=16,
    )
    second = expand_goal_file(
        goal_path,
        template_dir=template_dir,
        output_dir=output_dir,
        hash_len=16,
    )

    assert len(first) == 1
    assert len(second) == 1
    assert first[0].created is True
    assert second[0].created is False
    assert first[0].path == second[0].path
    assert first[0].path.name == f"{first[0].sha256[:16]}.c.toml"
    assert len(list(output_dir.glob("*.c.toml"))) == 1


def test_generated_calc_toml_can_be_read_back(tmp_path: Path) -> None:
    template_dir = tmp_path / "templates"
    output_dir = tmp_path / "calcs"
    goal_path = tmp_path / "goals" / "simple.g.toml"
    _write_project_files(template_dir=template_dir, goal_path=goal_path)

    result = expand_goal_file(
        goal_path,
        template_dir=template_dir,
        output_dir=output_dir,
        hash_len=16,
    )[0]

    with result.path.open("rb") as f:
        data = tomllib.load(f)

    assert data == result.payload


def test_multi_template_expansion() -> None:
    goal = {
        "templates": {"m": "m.t.toml", "l": "l.t.toml"},
        "value_groups": [
            {"m": {"a": [1, 2]}},
            {"l": {"b": ["x", "y"]}},
        ],
    }
    templates = {"m": _template("a"), "l": _template("b")}

    payloads = list(expand_goal(goal, templates=templates))

    assert len(payloads) == 4
    combos = set()
    for payload in payloads:
        combos.add((payload["parameters"]["m"]["a"], payload["parameters"]["l"]["b"]))
    assert combos == {(1, "x"), (1, "y"), (2, "x"), (2, "y")}


def test_cross_template_zip() -> None:
    goal = {
        "templates": {"m": "m.t.toml", "l": "l.t.toml"},
        "value_groups": [
            {"m": {"a": [1, 2, 3]}, "l": {"b": ["x", "y", "z"]}},
        ],
    }
    templates = {"m": _template("a"), "l": _template("b")}

    payloads = list(expand_goal(goal, templates=templates))

    assert len(payloads) == 3
    pairs = [
        (p["parameters"]["m"]["a"], p["parameters"]["l"]["b"])
        for p in payloads
    ]
    assert pairs == [(1, "x"), (2, "y"), (3, "z")]


def test_same_name_different_aliases_no_conflict() -> None:
    goal = {
        "templates": {"m": "m.t.toml", "l": "l.t.toml"},
        "value_groups": [
            {"m": {"size": [10]}},
            {"l": {"size": [20]}},
        ],
    }
    templates = {"m": _template("size"), "l": _template("size")}

    payloads = list(expand_goal(goal, templates=templates))

    assert len(payloads) == 1
    assert payloads[0]["parameters"]["m"]["size"] == 10
    assert payloads[0]["parameters"]["l"]["size"] == 20


def test_old_template_field_raises() -> None:
    goal = {
        "template": "old.t.toml",
        "templates": _templates("t"),
        "value_groups": [{"t": {"a": [1]}}],
    }
    templates = {"t": _template("a")}

    with pytest.raises(GoalError, match="no longer supported"):
        list(expand_goal(goal, templates=templates))


def test_template_with_groups_raises() -> None:
    template = {
        "parameters": [{"name": "a"}],
        "groups": [{"name": "g", "parameters": ["a"]}],
    }
    with pytest.raises(TemplateError, match="groups"):
        list(expand_goal(
            {"templates": _templates("t"), "value_groups": [{"t": {"a": [1]}}]},
            templates={"t": template},
        ))


def test_bare_parameter_in_value_group_raises() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"temperature": [300]}],
    }
    templates = {"t": _template("temperature")}

    with pytest.raises(GoalError, match="bare parameter"):
        list(expand_goal(goal, templates=templates))


def test_quoted_dotted_key_raises() -> None:
    goal = {
        "templates": _templates("t"),
        "value_groups": [{"t.temperature": [300]}],
    }
    templates = {"t": _template("temperature")}

    with pytest.raises(GoalError, match="quoted dotted key"):
        list(expand_goal(goal, templates=templates))


def test_flatten_unflatten_roundtrip() -> None:
    nested = {"model": {"a": 1, "b": 2}, "loading": {"c": 3}}
    flat = flatten_dotted_parameter_tree(nested)
    assert flat == {("model", "a"): 1, ("model", "b"): 2, ("loading", "c"): 3}
    result = unflatten_to_nested_parameters(flat)
    assert result == nested


def test_calc_toml_uses_dotted_keys(tmp_path: Path) -> None:
    template_dir = tmp_path / "templates"
    output_dir = tmp_path / "calcs"
    goal_path = tmp_path / "goals" / "multi.g.toml"
    _write_multi_template_files(template_dir=template_dir, goal_path=goal_path)

    results = expand_goal_file(
        goal_path,
        template_dir=template_dir,
        output_dir=output_dir,
        hash_len=16,
    )

    assert len(results) == 1
    text = results[0].path.read_text(encoding="utf-8")
    assert "[templates]" in text
    assert "model.material" in text
    assert "md.temperature" in text
    assert "template =" not in text
    assert "[parameters.model]" not in text


def _write_project_files(*, template_dir: Path, goal_path: Path) -> None:
    template_dir.mkdir(parents=True, exist_ok=True)
    goal_path.parent.mkdir(parents=True, exist_ok=True)

    (template_dir / "simple.t.toml").write_text(
        """
[[parameters]]
name = "material"

[[parameters]]
name = "temperature"
""".strip()
        + "\n",
        encoding="utf-8",
    )
    goal_path.write_text(
        """
[templates]
simple = "simple.t.toml"

[[value_groups]]
simple.material = ["Au"]
simple.temperature = [300]
""".strip()
        + "\n",
        encoding="utf-8",
    )


def _write_multi_template_files(*, template_dir: Path, goal_path: Path) -> None:
    template_dir.mkdir(parents=True, exist_ok=True)
    goal_path.parent.mkdir(parents=True, exist_ok=True)

    (template_dir / "model.t.toml").write_text(
        """
[[parameters]]
name = "material"
type = "string"
unit = "dimensionless"
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (template_dir / "md.t.toml").write_text(
        """
[[parameters]]
name = "temperature"
type = "number"
unit = "K"
""".strip()
        + "\n",
        encoding="utf-8",
    )
    goal_path.write_text(
        """
[templates]
model = "model.t.toml"
md = "md.t.toml"

[[value_groups]]
model.material = ["Au"]
md.temperature = [300]
""".strip()
        + "\n",
        encoding="utf-8",
    )
