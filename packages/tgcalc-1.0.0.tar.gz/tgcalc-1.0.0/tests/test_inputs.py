"""Tests for tgcalc.inputs."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from tgcalc.core import render_calc_toml
from tgcalc.inputs import (
    BindingError,
    DuplicateTemplateFileError,
    InputGenError,
    InvalidTemplateFunctionError,
    MissingParameterError,
    TemplateParams,
    generate_inputs,
    load_calc,
    template_function,
)

# ── decorator ──────────────────────────────────────────────────────────


def test_decorator_marks_function() -> None:
    @template_function("model.t.toml")
    def build_model(model: Any) -> None:
        pass

    meta = build_model.__tgcalc_template_function__  # type: ignore[attr-defined]
    assert meta["template_file"] == "model.t.toml"
    assert meta["name"] == "build_model"


def test_empty_template_file_rejected() -> None:
    with pytest.raises(InvalidTemplateFunctionError, match="non-empty"):
        template_function("")


def test_handler_zero_args_rejected() -> None:
    with pytest.raises(InvalidTemplateFunctionError, match="exactly one"):
        @template_function("model.t.toml")
        def bad() -> None:
            pass


def test_handler_two_args_rejected() -> None:
    with pytest.raises(InvalidTemplateFunctionError, match="exactly one"):
        @template_function("model.t.toml")
        def bad(a: Any, b: Any) -> None:
            pass


def test_handler_one_arg_accepted() -> None:
    @template_function("model.t.toml")
    def build_model(model: Any) -> None:
        pass

    assert callable(build_model)


def test_call_with_matching_template() -> None:
    @template_function("model.t.toml")
    def build_model(model: Any) -> Any:
        return model.size

    params = TemplateParams(
        {"size": 10}, alias="m", template_file="model.t.toml",
    )
    assert build_model(params) == 10


def test_call_with_mismatched_template() -> None:
    @template_function("model.t.toml")
    def build_model(model: Any) -> None:
        pass

    params = TemplateParams(
        {"size": 10}, alias="l", template_file="loading.t.toml",
    )
    with pytest.raises(BindingError, match="mismatch"):
        build_model(params)


# ── TemplateParams ─────────────────────────────────────────────────────


def test_params_attribute_access() -> None:
    params = TemplateParams(
        {"size": 10, "name": "Au"}, alias="m",
        template_file="model.t.toml",
    )
    assert params.size == 10
    assert params.name == "Au"


def test_params_dict_access() -> None:
    params = TemplateParams(
        {"size": 10}, alias="m", template_file="model.t.toml",
    )
    assert params["size"] == 10


def test_params_get() -> None:
    params = TemplateParams(
        {"size": 10}, alias="m", template_file="model.t.toml",
    )
    assert params.get("size") == 10
    assert params.get("missing", 42) == 42
    assert params.get("missing") is None


def test_params_contains() -> None:
    params = TemplateParams(
        {"size": 10}, alias="m", template_file="model.t.toml",
    )
    assert "size" in params
    assert "missing" not in params


def test_params_missing_attr_error() -> None:
    params = TemplateParams(
        {"size": 10}, alias="model", template_file="model.t.toml",
    )
    with pytest.raises(MissingParameterError, match="height_layers"):
        _ = params.height_layers


def test_params_missing_item_error() -> None:
    params = TemplateParams(
        {"size": 10}, alias="model", template_file="model.t.toml",
    )
    with pytest.raises(MissingParameterError, match="height_layers"):
        params["height_layers"]


def test_params_method_name_collision() -> None:
    params = TemplateParams(
        {"get": "value", "size": 10}, alias="m",
        template_file="model.t.toml",
    )
    assert params["get"] == "value"
    assert params.size == 10


def test_params_to_dict() -> None:
    params = TemplateParams(
        {"size": 10}, alias="m", template_file="model.t.toml",
    )
    assert params.to_dict() == {"size": 10}


def test_params_metadata() -> None:
    params = TemplateParams(
        {"size": 10}, alias="model", template_file="model.t.toml",
    )
    assert params.__tgcalc_alias__ == "model"
    assert params.__tgcalc_template_file__ == "model.t.toml"


def test_params_len_iter() -> None:
    params = TemplateParams(
        {"a": 1, "b": 2}, alias="m", template_file="model.t.toml",
    )
    assert len(params) == 2
    assert set(params) == {"a", "b"}


# ── Calc ───────────────────────────────────────────────────────────────


def test_calc_attribute_access(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"m": "model.t.toml", "l": "loading.t.toml"},
        "parameters": {"m": {"size": 10}, "l": {"rate": 1e7}},
        "iter": {"value": 1},
    })
    calc = load_calc(calc_path)
    assert calc.m.size == 10
    assert calc.l.rate == 1e7


def test_calc_dict_access(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"m": "model.t.toml"},
        "parameters": {"m": {"size": 10}},
        "iter": {"value": 1},
    })
    calc = load_calc(calc_path)
    assert calc["m"].size == 10


def test_calc_dotted_get(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    calc = load_calc(calc_path)
    assert calc.get("model.size") == 10
    assert calc.get("model.missing") is None
    assert calc.get("model.missing", 42) == 42


def test_calc_require(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    calc = load_calc(calc_path)
    assert calc.require("model.size") == 10
    with pytest.raises(MissingParameterError, match="missing"):
        calc.require("model.missing")


def test_calc_templates_preserve_order(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {
            "loading": "loading.t.toml",
            "model": "model.t.toml",
            "simulation": "simulation.t.toml",
        },
        "parameters": {
            "loading": {"rate": 1e7},
            "model": {"size": 10},
            "simulation": {"temp": 300},
        },
        "iter": {"value": 1},
    })
    calc = load_calc(calc_path)
    assert list(calc.templates.keys()) == [
        "loading", "model", "simulation",
    ]


def test_calc_iter_value(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"m": "model.t.toml"},
        "parameters": {"m": {"size": 10}},
        "iter": {"value": 42},
    })
    calc = load_calc(calc_path)
    assert calc.iter == 42


# ── generate_inputs ────────────────────────────────────────────────────


def test_generate_inputs_basic(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def build_model(model: Any) -> None:
        with open("model.in", "w", encoding="utf-8") as f:
            f.write(f"size = {model.size}\n")

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    result = generate_inputs(calc_path, base, bindings=[build_model])
    assert result.functions_called == ["build_model"]
    assert result.input_dir == base / "test"
    assert (result.input_dir / "model.in").read_text(
        encoding="utf-8",
    ) == "size = 10\n"


def test_generate_inputs_output_is_calc_stem(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    result = generate_inputs(calc_path, base, bindings=[gen_model])
    assert result.input_dir == base / "test"


def test_generate_inputs_preserves_c_toml_order(tmp_path: Path) -> None:
    order: list[str] = []

    @template_function("loading.t.toml")
    def gen_loading(loading: Any) -> None:
        order.append("loading")

    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        order.append("model")

    @template_function("simulation.t.toml")
    def gen_simulation(sim: Any) -> None:
        order.append("simulation")

    calc_path = _write_calc(tmp_path, {
        "templates": {
            "model": "model.t.toml",
            "loading": "loading.t.toml",
            "simulation": "simulation.t.toml",
        },
        "parameters": {
            "model": {"size": 10},
            "loading": {"rate": 1e7},
            "simulation": {"temp": 300},
        },
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    generate_inputs(
        calc_path, base,
        bindings=[gen_model, gen_loading, gen_simulation],
    )
    assert order == ["model", "loading", "simulation"]


def test_generate_inputs_empty_bindings_rejected(tmp_path: Path) -> None:
    calc_path = _write_calc(tmp_path, {
        "templates": {"m": "model.t.toml"},
        "parameters": {"m": {"size": 10}},
        "iter": {"value": 1},
    })
    with pytest.raises(BindingError, match="empty"):
        generate_inputs(calc_path, tmp_path / "out", bindings=[])


def test_generate_inputs_undecorated_rejected(tmp_path: Path) -> None:
    def plain(model: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {"m": "model.t.toml"},
        "parameters": {"m": {"size": 10}},
        "iter": {"value": 1},
    })
    with pytest.raises(BindingError, match="not decorated"):
        generate_inputs(
            calc_path, tmp_path / "out", bindings=[plain],
        )


def test_generate_inputs_extra_binding_rejected(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        pass

    @template_function("loading.t.toml")
    def gen_loading(loading: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    with pytest.raises(BindingError, match="not in calc"):
        generate_inputs(
            calc_path, tmp_path / "out",
            bindings=[gen_model, gen_loading],
        )


def test_generate_inputs_missing_binding_rejected(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {
            "model": "model.t.toml",
            "loading": "loading.t.toml",
        },
        "parameters": {
            "model": {"size": 10},
            "loading": {"rate": 1e7},
        },
        "iter": {"value": 1},
    })
    with pytest.raises(BindingError, match="requires bindings"):
        generate_inputs(
            calc_path, tmp_path / "out", bindings=[gen_model],
        )


def test_generate_inputs_failure_no_output(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def bad(model: Any) -> None:
        raise RuntimeError("boom")

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    with pytest.raises(RuntimeError, match="boom"):
        generate_inputs(calc_path, base, bindings=[bad])

    assert not (base / "test").exists()


def test_generate_inputs_keep_temp_on_error(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def bad(model: Any) -> None:
        raise RuntimeError("boom")

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    with pytest.raises(RuntimeError):
        generate_inputs(
            calc_path, base, bindings=[bad], keep_temp_on_error=True,
        )
    tmp_dir = base / "test.tmp"
    assert tmp_dir.exists()


def test_generate_inputs_remove_temp_on_error(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def bad(model: Any) -> None:
        raise RuntimeError("boom")

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"

    with pytest.raises(RuntimeError):
        generate_inputs(
            calc_path, base, bindings=[bad], keep_temp_on_error=False,
        )
    tmp_dir = base / "test.tmp"
    assert not tmp_dir.exists()


def test_generate_inputs_overwrite_existing(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        with open("model.in", "w", encoding="utf-8") as f:
            f.write("ok")

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"
    out = base / "test"
    out.mkdir(parents=True)
    (out / "stale.txt").write_text("old", encoding="utf-8")

    generate_inputs(
        calc_path, base, bindings=[gen_model], overwrite=True,
    )
    assert (out / "model.in").exists()
    assert not (out / "stale.txt").exists()


def test_generate_inputs_no_overwrite_error(tmp_path: Path) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"
    (base / "test").mkdir(parents=True)

    with pytest.raises(InputGenError, match="already exists"):
        generate_inputs(calc_path, base, bindings=[gen_model])


def test_generate_inputs_temp_dir_exists_no_overwrite(
    tmp_path: Path,
) -> None:
    @template_function("model.t.toml")
    def gen_model(model: Any) -> None:
        pass

    calc_path = _write_calc(tmp_path, {
        "templates": {"model": "model.t.toml"},
        "parameters": {"model": {"size": 10}},
        "iter": {"value": 1},
    })
    base = tmp_path / "inputs"
    tmp_dir = base / "test.tmp"
    tmp_dir.mkdir(parents=True)

    with pytest.raises(InputGenError, match="Temp directory"):
        generate_inputs(
            calc_path, base, bindings=[gen_model], overwrite=False,
        )


def test_duplicate_template_in_calc_rejected(tmp_path: Path) -> None:
    calc_path = tmp_path / "dup.c.toml"
    calc_path.write_text(
        '[templates]\na = "model.t.toml"\nb = "model.t.toml"\n\n'
        "[parameters]\na.size = 10\nb.size = 20\n\n[iter]\nvalue = 1\n",
        encoding="utf-8",
    )
    with pytest.raises(DuplicateTemplateFileError, match="Duplicate"):
        load_calc(calc_path)


def test_old_template_field_rejected(tmp_path: Path) -> None:
    calc_path = tmp_path / "bad.c.toml"
    calc_path.write_text(
        'template = "model.t.toml"\n\n'
        "[parameters]\nmodel.size = 10\n\n[iter]\nvalue = 1\n",
        encoding="utf-8",
    )
    with pytest.raises(InputGenError, match="no longer supported"):
        load_calc(calc_path)


# ── helpers ────────────────────────────────────────────────────────────


def _write_calc(tmp_path: Path, data: dict[str, Any]) -> Path:
    calc_path = tmp_path / "test.c.toml"
    calc_path.write_text(render_calc_toml(data), encoding="utf-8")
    return calc_path
