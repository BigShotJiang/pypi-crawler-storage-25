"""Blue-Tap: Bluetooth/BLE Penetration Testing Toolkit for Automotive IVI Systems."""

__version__ = "2.2.0"
