from typing import Optional
from pydantic import BaseModel


class ServiceConfig(BaseModel):
    back_url: str
    front_url: str
    key: str = ''
    verify: bool = False


class ClientConfig(BaseModel):
    server_url: str
    grant_type: str
    client_id: str
    realm_name: str = "nkunyim"
    client_secret: str
    scope: str
    redirect_uri: Optional[str]

