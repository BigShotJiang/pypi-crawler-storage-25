from __future__ import annotations

from typing import Optional
from uuid import UUID

from django.db.models import Q, QuerySet

from nkunyim_iam.models import User


class UserQuery:
    @staticmethod
    def queryset() -> QuerySet[User]:
        return User.objects.all()

    @staticmethod
    def get(id: UUID) -> Optional[User]:
        return UserQuery.queryset().filter(id=id).first()

    @staticmethod
    def all(**filters) -> QuerySet[User]:
        return UserQuery.queryset().filter(**filters)

    @staticmethod
    def find(**filters) -> Optional[User]:
        return UserQuery.queryset().filter(**filters).first()

    @staticmethod
    def check(username: str, email_address: str, phone_number: str) -> Optional[User]:
        return UserQuery.queryset().filter(
            Q(username=username) | Q(email_address=email_address) | Q(phone_number=phone_number)
        ).first()

    @staticmethod
    def find_by_email(email_address: str) -> Optional[User]:
        return UserQuery.queryset().filter(email_address=email_address).first()

    @staticmethod
    def find_by_phone(phone_number: str) -> Optional[User]:
        return UserQuery.queryset().filter(phone_number=phone_number).first()

    @staticmethod
    def find_by_username(username: str) -> Optional[User]:
        return UserQuery.queryset().filter(username=username).first()
