from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel


class UserModel(BaseModel):
    id: UUID
    username: str
    first_name: str
    last_name: str
    email_address: str
    phone_number: str
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool
    created_at: datetime
    updated_at: datetime


class UserInfoData(BaseModel):
    id: UUID
    username: str
    first_name: str
    last_name: str
    email_address: str
    phone_number: str
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool


class InitAuthData(BaseModel):
    state: str
    nonce: str
    code_challenge: str
    code_challenge_method: str
    

class ClaimData(BaseModel):
    roles: list[str] = []


class AccessTokenData(BaseModel):
    exp: int
    iat: int
    jti: str
    iss: str
    aud: str
    sub: UUID
    typ: str
    azp: str
    user: Optional[UserInfoData]
    resource_access: dict[str, ClaimData]
    scope: str
    email_verified: bool
    clientHost: str
    preferred_username: str
    clientAddress: str
    client_id: str


class RefreshTokenData(BaseModel):
    exp: int
    iat: int
    sub: UUID
    sid: UUID
    jti: UUID
    azp: str
