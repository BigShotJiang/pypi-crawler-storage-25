from __future__ import annotations

from typing import Optional
from uuid import UUID

from nkunyim_iam.data import UserModel
from nkunyim_iam.queries import UserQuery


class UserUseCase:
    @staticmethod
    def get(id: UUID) -> Optional[UserModel]:
        user = UserQuery.get(id=id)
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)

    @staticmethod
    def all(**filters) -> list[UserModel]:
        return [
            UserModel.model_validate(user, from_attributes=True)
            for user in UserQuery.all(**filters)
        ]

    @staticmethod
    def find(**filters) -> Optional[UserModel]:
        user = UserQuery.find(**filters)
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)

    @staticmethod
    def check(username: str, email_address: str, phone_number: str) -> Optional[UserModel]:
        user = UserQuery.check(
            username=username,
            email_address=email_address,
            phone_number=phone_number,
        )
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)

    @staticmethod
    def find_by_email(email_address: str) -> Optional[UserModel]:
        user = UserQuery.find_by_email(email_address=email_address)
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)

    @staticmethod
    def find_by_phone(phone_number: str) -> Optional[UserModel]:
        user = UserQuery.find_by_phone(phone_number=phone_number)
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)

    @staticmethod
    def find_by_username(username: str) -> Optional[UserModel]:
        user = UserQuery.find_by_username(username=username)
        if not user:
            return None
        return UserModel.model_validate(user, from_attributes=True)
