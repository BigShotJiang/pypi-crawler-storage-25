from django.contrib import admin

class UserAdmin(admin.ModelAdmin):
    fields = [
        'username',
        'first_name',
        'last_name',
        'email_address',
        'phone_number',
        'is_active',
        'is_admin',
        'is_superuser',
        'is_verified',
    ]
    list_display = [
        'first_name', 
        'last_name', 
        'email_address',
        'phone_number',
        'is_active',
        'is_admin',
        'is_superuser',
        'is_verified'
    ]
    list_filter = ['is_active', 'is_admin', 'is_superuser', 'is_verified']
    search_fields = ['username', 'first_name', 'last_name', 'email_address', 'phone_number']


class LoggingAdmin(admin.ModelAdmin):
    fields = [
        'level',
        'message',
        'trace',
        'context',
    ]
    list_display = ['created_at', 'level', 'message',]
    list_filter = ['level', 'created_at']
    search_fields = ['message', 'trace', 'context']