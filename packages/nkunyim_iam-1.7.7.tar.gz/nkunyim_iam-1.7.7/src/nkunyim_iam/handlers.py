from typing import Optional
from uuid import UUID

from nkunyim_iam.encryption import Hashing, HashingAlgo
from nkunyim_iam.models import Logging, User
from nkunyim_iam.commands import (
    LoggingCommand,
    LoggingLevel,
    UserCommand,
)
from nkunyim_iam.queries import UserQuery

class UserHandler:
    @staticmethod
    def handle(command: UserCommand) -> User:
        password = Hashing(input_string=command.id.hex).make(algo=HashingAlgo.S512)
        user = UserQuery.find(id=command.id)
        if not user:
            user = User(id=command.id)
        
        user.username = command.username
        user.first_name = command.first_name
        user.last_name = command.last_name
        user.email_address = command.email_address
        user.phone_number = command.phone_number
        user.is_verified = command.is_verified
        user.is_active = command.is_active
        user.is_admin = command.is_admin
        user.is_superuser = command.is_superuser

        user.set_password(password)
        user.save()
        return user


    @staticmethod
    def create(data: dict) -> User:
        command = UserCommand(
            id=UUID(data['id']),
            username=data['username'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            email_address=data['email_address'],
            phone_number=data['phone_number'],
            is_active=data.get('is_active', True),
            is_admin=data.get('is_admin', False),
            is_superuser=data.get('is_superuser', False),
            is_verified=data.get('is_verified', False),
        )
        return UserHandler.handle(command=command)
    
    @staticmethod
    def create_user(data: dict) -> User:
        return User.objects.create_user(
            username=data['username'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone_number=data['phone_number'],
            email_address=data['email_address'],
            password=data['password']
        )

    @staticmethod
    def create_superuser(data: dict) -> User:
        return User.objects.create_superuser(
            username=data['username'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone_number=data['phone_number'],
            email_address=data['email_address'],
            password=data['password']
        )
        
    @staticmethod
    def delete(id: UUID) -> bool:
        delete = User.objects.get(pk=id).delete()
        return len(delete) > 0


class LoggingHandler:
    @staticmethod
    def find(id: UUID) -> Optional[Logging]:
        return Logging.objects.filter(pk=id).first()
        
    @staticmethod
    def handle(logging: LoggingCommand) -> Logging:
        create = Logging()
        create.level = logging.level
        create.message = logging.message
        create.trace = dict(logging.trace)
        create.context = dict(logging.context)
        create.save()
        return create
    
    @staticmethod
    def create(message: str, trace: dict, level: LoggingLevel = LoggingLevel.INFO, context: dict = {}) -> Logging:
        logging = LoggingCommand(level=level, message=message, trace=trace, context=context)
        return LoggingHandler.handle(logging)
        
    @staticmethod
    def delete(id: UUID) -> bool:
        delete = Logging.objects.get(pk=id).delete()
        return len(delete) > 0
    
    @staticmethod
    def clear() -> None:
        Logging.objects.all().delete()
    
    @staticmethod
    def info(message: str, trace: dict, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.INFO, message=message, trace=trace, context=context)
        LoggingHandler.handle(logging)
    
    @staticmethod
    def success(message: str, trace: dict, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.SUCCESS, message=message, trace=trace, context=context)
        LoggingHandler.handle(logging)
        
    @staticmethod
    def warning(message: str, trace: dict, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.WARNING, message=message, trace=trace, context=context)
        LoggingHandler.handle(logging)
        
    @staticmethod
    def danger(message: str, trace: dict, context: dict = {}) -> None:
        logging = LoggingCommand(level=LoggingLevel.DANGER, message=message, trace=trace, context=context)
        LoggingHandler.handle(logging)
