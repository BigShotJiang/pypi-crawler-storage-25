from django.apps import AppConfig


class NkunyimIamConfig(AppConfig):
    name = 'nkunyim_iam'
    verbose_name = "Nkunyim IAM"

    def ready(self):
        import nkunyim_iam.signals  # noqa: F401
