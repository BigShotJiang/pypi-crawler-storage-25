from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class UserCommand(BaseModel):
    id: UUID
    username: str
    first_name: str
    last_name: str
    email_address: str
    phone_number: str
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool


class LoggingLevel(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    DANGER = "danger"


LoggingContext = dict[str, str | int | float | bool | None]
LoggingTrace = dict[str, str]

class LoggingCommand(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    level: LoggingLevel = LoggingLevel.INFO
    message: str
    trace: LoggingTrace = Field(default_factory=dict)
    context: LoggingContext = Field(default_factory=dict)

