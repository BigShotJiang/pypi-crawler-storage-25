from uuid import uuid7
from django.db import models
from django.contrib.auth.models import (
    BaseUserManager,
    AbstractBaseUser,
    PermissionsMixin,
)
from django.utils.translation import gettext_lazy as _


class Gender(models.TextChoices):
    MALE = "MALE", _("MALE")
    FEMALE = "FEMALE", _("FEMALE")
    PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY", _("PREFER_NOT_TO_SAY")
    UNKNOWN = "UNKNOWN", _("UNKNOWN")

class MaritalStatus(models.TextChoices):
    SINGLE = "SINGLE", _("SINGLE")
    MARRIED = "MARRIED", _("MARRIED")
    SEPARATED = "SEPARATED", _("SEPARATED")
    DIVORCED = "DIVORCED", _("DIVORCED")
    WIDOW_OR_WIDOWER = "WIDOW_OR_WIDOWER", _("WIDOW_OR_WIDOWER")
    PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY", _("PREFER_NOT_TO_SAY")
    UNKNOWN = "UNKNOWN", _("UNKNOWN")

class EducationLevel(models.TextChoices):
    NONE = "NONE", _("NONE")
    PRIMARY = "PRIMARY", _("PRIMARY")
    JSS_JHS = "JSS_JHS", _("JSS_JHS")
    SSS_SHS = "SSS_SHS", _("SSS_SHS")
    DIPLOMA = "DIPLOMA", _("DIPLOMA")
    UNDERGRADUATE = "UNDERGRADUATE", _("UNDERGRADUATE")
    POSTGRADUATE = "POSTGRADUATE", _("POSTGRADUATE")
    PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY", _("PREFER_NOT_TO_SAY")
    UNKNOWN = "UNKNOWN", _("UNKNOWN")

class EmploymentType(models.TextChoices):
    UNEMPLOYED = "UNEMPLOYED", _("UNEMPLOYED")
    PERMANENT = "PERMANENT", _("PERMANENT")
    FIXED_CONTRACT = "FIXED_CONTRACT", _("FIXED_CONTRACT")
    PART_TIME = "PART_TIME", _("PART_TIME")
    FREELANCE = "FREELANCE", _("FREELANCE")
    SELF_EMPLOYED = "SELF_EMPLOYED", _("SELF_EMPLOYED")
    CIVIL_SERVICE = "CIVIL_SERVICE", _("CIVIL_SERVICE")
    CONTRACT_WORKER = "CONTRACT_WORKER", _("CONTRACT_WORKER")
    PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY", _("PREFER_NOT_TO_SAY")
    UNKNOWN = "UNKNOWN", _("UNKNOWN")

class IdentityType(models.TextChoices):
    NATIONAL = "NATIONAL", _("NATIONAL")
    PASSPORT = "PASSPORT", _("PASSPORT")
    DRIVING_LICENSE = "DRIVING_LICENSE", _("DRIVING_LICENSE")
    OTHER = "OTHER", _("OTHER")

class AppMode(models.TextChoices):
    WEB = "WEB", _("WEB")
    APP = "APP", _("APP")
    API = "API", _("API")
    CLI = "CLI", _("CLI")
    
class HashingAlgo(models.TextChoices):
    S256 = "S256", ("S256")
    S384 = "S384", ("S384")
    S512 = "S512", ("S512")
    
class EncryptionAlgo(models.TextChoices):
    HS256 = "HS256", ("HS256")
    RS256 = "RS256", ("RS256")
    PS256 = "PS256", ("PS256")
    EdDSA = "EdDSA", ("EdDSA")
    ES256 = "ES256", ("ES256")

class Colour(models.TextChoices):
    Behance = "behance", _("Behance")
    Blue = "blue", _("Blue")
    CSS3 = "css3", _("CSS3")
    Dribbble = "dribbble", _("Dribbble")
    DropBox = "dropbox", _("DropBox")
    Facebook = "facebook", _("Facebook")
    FlickR = "flickr", _("FlickR")
    FourSquare = "foursquare", _("FourSquare")
    GitHub = "github", _("GitHub")
    GooglePlus = "google-plus", _("Google+")
    Green = "green", _("Green")
    HTML5 = "html5", _("HTML5")
    Indigo = "indigo", _("Indigo")
    Instagram = "instagram", _("Instagram")
    LinkedIn = "linkedin", _("LinkedIn")
    Nkunyim = "nkunyim", _("Nkunyim")
    OpenID = "openid", _("OpenID")
    Orange = "orange", _("Orange")
    Pink = "pink", _("Pink")
    Pinterest = "pinterest", _("Pinterest")
    Purple = "purple", _("Purple")
    Red = "red", _("Red")
    Reddit = "reddit", _("Reddit")
    Spotify = "spotify", _("Spotify")
    StackOverflow = "stack-overflow", _("StackOverflow")
    Teal = "teal", _("Teal")
    Tumblr = "tumblr", _("Tumblr")
    Twitter = "twitter", _("Twitter")
    Vimeo = "vimeo", _("Vimeo")
    Vine = "vine", _("Vine")
    Vk = "vk", _("Vk")
    Xing = "xing", _("Xing")
    Yahoo = "yahoo", _("Yahoo")
    Yellow = "yellow", _("Yellow")

class ResponseType(models.TextChoices):
    Code = 'code', _('Code')
    Token = 'token', _('Token')

class GrantType(models.TextChoices):
    AuthorizationCode = "authorization_code", _("Authorization Code")
    AccessToken = "access_token", _("Access Token")
    RefreshToken = "refresh_token", _("Refresh Token")
    ClientCredentials = "client_credentials", _("Client Credentials")


class UserManager(BaseUserManager):
    def create_user(self, username, first_name, last_name, phone_number, email_address, password):
        """
        Creates and saves a User with the username, phone_number, email_address.
        """
        if not (username and first_name and last_name and phone_number and email_address and password):
            raise ValueError('Users must have username, phone_number, email_address')

        user = self.model(
            username=username,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            email_address=self.normalize_email(email_address),
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, first_name, last_name, phone_number, email_address, password):
        """
        Creates and saves a superuser with the username, phone_number, email_address.
        """
        user = self.create_user(
            username=username,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            email_address=email_address,
            password=password,
        )
        user.is_superuser = True
        user.is_admin = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    username = models.CharField(
        verbose_name='Username',
        max_length=80,
        blank=False,
        null=False,
        unique=True,
    )
    first_name = models.CharField(
        verbose_name='First Name',
        max_length=32,
        blank=False,
        null=False,
    )
    last_name = models.CharField(
        verbose_name='Last Name',
        max_length=32,
        blank=False,
        null=False,
    )
    email_address = models.EmailField(
        verbose_name='Email Address',
        max_length=128,
        unique=True,
        blank=False,
        null=False,
    )
    phone_number = models.CharField(
        verbose_name='Phone Number',
        max_length=32,
        blank=False,
        null=False,
    )
    is_active = models.BooleanField(default=True, blank=False, null=False)
    is_admin = models.BooleanField(default=False, blank=False, null=False)
    is_verified = models.BooleanField(default=False, blank=False, null=False)
    created_at = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    updated_at = models.DateTimeField(auto_now=True, blank=False, null=False)

    objects = UserManager()

    USERNAME_FIELD = 'username'
    EMAIL_FIELD = 'email_address'
    REQUIRED_FIELDS = [
        'first_name',
        'last_name',
        'email_address',
        'phone_number',
    ]

    class Meta:
        ordering = ["last_name", "first_name", "is_admin", "is_active",]
        verbose_name = "User"
        verbose_name_plural = "Users"

    def __str__(self):
        return self.full_name

    def get_absolute_url(self):
        return "/users/%s/" % self.id

    @property
    def uid(self):
        return self.id

    @property
    def full_name(self):
        return "%s %s" % (self.first_name, self.last_name)

    @property
    def is_staff(self):
        """Is the user a member of staff?"""
        # Simplest possible answer: All admins are staff
        return self.is_admin


class Logging(models.Model):
    class Level(models.TextChoices):
        INFO = "info", _("Info")
        SUCCESS = "success", _("Success")
        WARNING = "warning", _("Warning")
        DANGER = "danger", _("Danger")
    
    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    level = models.CharField(
        verbose_name='Level',
        choices=Level.choices,
        default=Level.INFO,
        max_length=128,
        blank=False,
        null=False,
    )
    message = models.TextField(
        verbose_name='Message',
        blank=False,
        null=False,
    )
    trace = models.JSONField(
        verbose_name='Trace',
        blank=False,
        null=False,
    )
    context = models.JSONField(
        verbose_name='Context',
        blank=True,
        null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True, blank=False, null=False)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Logging"
        verbose_name_plural = "Loggings"

    def __str__(self):
        return f"{self.level}: {self.message[:50]}"

    def get_absolute_url(self):
        return "/loggings/%s/" % self.id
