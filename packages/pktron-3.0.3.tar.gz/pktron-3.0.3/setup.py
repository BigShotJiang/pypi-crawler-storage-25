from setuptools import setup, find_packages

setup(
    name="pktron",
    version="3.0.3",
    description="PKTron - Pakistan's 1st Quantum AI Powered Simulation Framework",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="CETQAP",
    author_email="info@thecetqap.com",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21",
        "scipy>=1.7",
    ],
    extras_require={
        "gpu": ["cupy-cuda12x"],
        "chemistry": ["pyscf>=2.0"],
        "ml": ["torch>=1.12", "tensorflow>=2.10"],
        "full": ["cupy-cuda12x", "pyscf>=2.0", "torch>=1.12", "tensorflow>=2.10"],
    },
)
