#!/usr/bin/env python3
import sys
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import expm
import warnings
import logging
import math
import random
from fractions import Fraction
from typing import Dict, List, Any, Callable, Optional, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum

warnings.filterwarnings('ignore')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('pktron')

__version__ = "3.0.3"
__author__ = "CETQAP & PKTron Development Team"
__license__ = "MIT"

I = np.array([[1, 0], [0, 1]], dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)

H_gate = np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)
S = np.array([[1, 0], [0, 1j]], dtype=complex)
Sdg = np.array([[1, 0], [0, -1j]], dtype=complex)
T = np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex)
Tdg = np.array([[1, 0], [0, np.exp(-1j * np.pi / 4)]], dtype=complex)

def RX(theta):
    return expm(-1j * theta / 2 * X)

def RY(theta):
    return expm(-1j * theta / 2 * Y)

def RZ(theta):
    return expm(-1j * theta / 2 * Z)

def U3(theta, phi, lam):
    return np.array([[np.cos(theta/2), -np.exp(1j*lam)*np.sin(theta/2)],
                     [np.exp(1j*phi)*np.sin(theta/2), np.exp(1j*(phi+lam))*np.cos(theta/2)]], dtype=complex)

CNOT = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)
CZ = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,-1]], dtype=complex)
SWAP = np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]], dtype=complex)
TOFFOLI = np.eye(8, dtype=complex)
TOFFOLI[6:8,6:8] = X

FREDKIN = np.eye(8, dtype=complex)
FREDKIN[5, 5] = 0
FREDKIN[5, 6] = 1
FREDKIN[6, 5] = 1
FREDKIN[6, 6] = 0

@dataclass
class Gate:
    name: str
    qubits: List[int]
    params: List[float] = field(default_factory=list)
    matrix: Optional[np.ndarray] = None

class QuantumCircuit:
    def __init__(self, n_qubits: int):
        if n_qubits <= 0:
            raise ValueError(f"n_qubits must be > 0, got {n_qubits}")
        self.n_qubits = n_qubits
        self.gates: List[Gate] = []
        self.measurements: List[int] = []

    def _normalize_qubit(self, qubit):
        q = int(qubit)
        if q < 0 or q >= self.n_qubits:
            raise ValueError(f"Qubit index {q} out of range for {self.n_qubits} qubits")
        return q

    def h(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('H', [q], matrix=H_gate.copy()))
        return self

    def x(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('X', [q], matrix=X.copy()))
        return self

    def y(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('Y', [q], matrix=Y.copy()))
        return self

    def z(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('Z', [q], matrix=Z.copy()))
        return self

    def s(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('S', [q], matrix=S.copy()))
        return self

    def sdg(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('Sdg', [q], matrix=Sdg.copy()))
        return self

    def t(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('T', [q], matrix=T.copy()))
        return self

    def tdg(self, qubit: int):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('Tdg', [q], matrix=Tdg.copy()))
        return self

    def rx(self, qubit: int, theta: float):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('RX', [q], [theta], RX(theta)))
        return self

    def ry(self, qubit: int, theta: float):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('RY', [q], [theta], RY(theta)))
        return self

    def rz(self, qubit: int, theta: float):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('RZ', [q], [theta], RZ(theta)))
        return self

    def u3(self, qubit: int, theta: float, phi: float, lam: float):
        q = self._normalize_qubit(qubit)
        self.gates.append(Gate('U3', [q], [theta, phi, lam], U3(theta, phi, lam)))
        return self

    def cx(self, control: int, target):
        control = self._normalize_qubit(control)
        if isinstance(target, (int, np.integer)):
            targets = [self._normalize_qubit(target)]
        elif isinstance(target, range):
            targets = [self._normalize_qubit(t) for t in target]
        else:
            targets = [self._normalize_qubit(t) for t in target] if hasattr(target, '__iter__') else [self._normalize_qubit(target)]
        for t in targets:
            self.gates.append(Gate('CX', [control, t], matrix=CNOT.copy()))
        return self

    def cy(self, control: int, target: int):
        control = self._normalize_qubit(control)
        target = self._normalize_qubit(target)
        cy_matrix = np.eye(4, dtype=complex)
        cy_matrix[2:, 2:] = Y
        self.gates.append(Gate('CY', [control, target], matrix=cy_matrix))
        return self

    def cz(self, control: int, target: int):
        control = self._normalize_qubit(control)
        target = self._normalize_qubit(target)
        self.gates.append(Gate('CZ', [control, target], matrix=CZ.copy()))
        return self

    def swap(self, q1: int, q2: int):
        q1 = self._normalize_qubit(q1)
        q2 = self._normalize_qubit(q2)
        self.gates.append(Gate('SWAP', [q1, q2], matrix=SWAP.copy()))
        return self

    def ccx(self, control1: int, control2: int, target: int):
        control1 = self._normalize_qubit(control1)
        control2 = self._normalize_qubit(control2)
        target = self._normalize_qubit(target)
        self.gates.append(Gate('CCX', [control1, control2, target], matrix=TOFFOLI.copy()))
        return self

    def cswap(self, control: int, target1: int, target2: int):
        control = self._normalize_qubit(control)
        target1 = self._normalize_qubit(target1)
        target2 = self._normalize_qubit(target2)
        self.gates.append(Gate('CSWAP', [control, target1, target2], matrix=FREDKIN.copy()))
        return self

    def crx(self, control: int, target: int, theta: float):
        control = self._normalize_qubit(control)
        target = self._normalize_qubit(target)
        c0 = np.cos(theta / 2)
        s0 = np.sin(theta / 2)
        crx_mat = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, c0, -1j*s0],
            [0, 0, -1j*s0, c0]
        ], dtype=complex)
        self.gates.append(Gate('CRX', [control, target], [theta], crx_mat))
        return self

    def cry(self, control: int, target: int, theta: float):
        control = self._normalize_qubit(control)
        target = self._normalize_qubit(target)
        c0 = np.cos(theta / 2)
        s0 = np.sin(theta / 2)
        cry_mat = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, c0, -s0],
            [0, 0, s0, c0]
        ], dtype=complex)
        self.gates.append(Gate('CRY', [control, target], [theta], cry_mat))
        return self

    def crz(self, control: int, target: int, theta: float):
        control = self._normalize_qubit(control)
        target = self._normalize_qubit(target)
        crz_mat = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, np.exp(-1j*theta/2), 0],
            [0, 0, 0, np.exp(1j*theta/2)]
        ], dtype=complex)
        self.gates.append(Gate('CRZ', [control, target], [theta], crz_mat))
        return self

    def custom_gate(self, name: str, qubits: List[int], matrix: np.ndarray):
        qubits = [self._normalize_qubit(q) for q in qubits]
        self.gates.append(Gate(name, qubits, [], matrix))
        return self

    def measure(self, qubit: int):
        self.measurements.append(int(qubit))
        return self

    def measure_all(self):
        self.measurements = list(range(self.n_qubits))
        return self

    def barrier(self):
        return self

    def copy(self):
        new = QuantumCircuit(self.n_qubits)
        new.gates = [Gate(g.name, g.qubits.copy(), g.params.copy(),
                         g.matrix.copy() if g.matrix is not None else None) for g in self.gates]
        new.measurements = self.measurements.copy()
        return new

    def depth(self) -> int:
        return len(self.gates)

    def count_ops(self) -> Dict[str, int]:
        ops = {}
        for gate in self.gates:
            ops[gate.name] = ops.get(gate.name, 0) + 1
        return ops

class StatevectorSimulator:
    def __init__(self, use_gpu: bool = False, distributed: bool = False):
        self.use_gpu = False
        self.distributed = False

    def run(self, circuit: QuantumCircuit, shots: int = 1024) -> Dict[str, Any]:
        n = circuit.n_qubits
        psi = np.zeros(2**n, dtype=complex)
        psi[0] = 1.0

        for gate in circuit.gates:
            psi = self._apply_gate(psi, gate, n)

        if shots == 0:
            return {'statevector': psi}

        probs = np.abs(psi)**2
        probs = probs / np.sum(probs)

        outcomes = np.random.choice(2**n, size=shots, p=probs)
        counts = {}
        for outcome in outcomes:
            bitstring = format(outcome, f'0{n}b')
            counts[bitstring] = counts.get(bitstring, 0) + 1
        return {'counts': counts, 'statevector': psi}

    def _apply_gate(self, psi: np.ndarray, gate: Gate, n: int) -> np.ndarray:
        num_qubits = len(gate.qubits)

        if num_qubits == 1:
            q = gate.qubits[0]
            psi_tensor = psi.reshape([2] * n)
            U = gate.matrix
            contracted = np.tensordot(U, psi_tensor, axes=([1], [q]))
            result = np.moveaxis(contracted, 0, q)
            return result.reshape(-1)

        elif num_qubits == 2:
            q0, q1 = gate.qubits
            psi_tensor = psi.reshape([2] * n)
            U = gate.matrix.reshape(2, 2, 2, 2)
            contracted = np.tensordot(U, psi_tensor, axes=([2, 3], [q0, q1]))
            result = np.moveaxis(contracted, [0, 1], [q0, q1])
            return result.reshape(-1)

        elif num_qubits == 3:
            q0, q1, q2 = gate.qubits
            psi_tensor = psi.reshape([2] * n)
            U = gate.matrix.reshape([2] * 6)
            contracted = np.tensordot(U, psi_tensor, axes=([3, 4, 5], [q0, q1, q2]))
            result = np.moveaxis(contracted, [0, 1, 2], [q0, q1, q2])
            return result.reshape(-1)

        else:
            full_U = self._build_full_unitary(gate, n)
            return full_U @ psi

    def _build_full_unitary(self, gate: Gate, n: int) -> np.ndarray:
        dim = 1 << n
        U_full = np.zeros((dim, dim), dtype=complex)
        for i in range(dim):
            basis = np.zeros(dim, dtype=complex)
            basis[i] = 1.0
            result = self._apply_gate(basis, gate, n)
            U_full[:, i] = result
        return U_full

class VQE:
    def __init__(self, hamiltonian):
        self.H = hamiltonian

    def run(self, n_qubits: int, ansatz_depth: int = 2, max_iter: int = 100):
        def ansatz(params):
            qc = QuantumCircuit(n_qubits)
            idx = 0
            for _ in range(ansatz_depth):
                for q in range(n_qubits):
                    qc.ry(q, params[idx]); idx += 1
                    qc.rz(q, params[idx]); idx += 1
                for q in range(n_qubits-1):
                    qc.cx(q, q+1)
            return qc

        def energy(params):
            qc = ansatz(params)
            result = execute(qc, backend='statevector', shots=0)
            psi = result['statevector']
            E = np.real(psi.conj().T @ self.H @ psi)
            return float(E)

        def gradient(params):
            grad = np.zeros_like(params)
            for i in range(len(params)):
                p_plus = params.copy(); p_plus[i] += np.pi/2
                p_minus = params.copy(); p_minus[i] -= np.pi/2
                grad[i] = (energy(p_plus) - energy(p_minus)) / 2
            return grad

        n_params = n_qubits * ansatz_depth * 2
        initial = np.random.randn(n_params) * 0.1
        res = minimize(energy, initial, jac=gradient, method='L-BFGS-B',
                      options={'maxiter': max_iter})

        return {
            'energy': float(res.fun),
            'params': res.x.tolist(),
            'success': res.success
        }

class GroverSearch:
    def __init__(self, n_qubits: int, marked_states: List[int]):
        self.n_qubits = n_qubits
        self.marked = marked_states

    def run(self):
        n_iterations = int(np.pi / 4 * np.sqrt(2 ** self.n_qubits / len(self.marked)))
        n_iterations = max(1, n_iterations)

        qc = QuantumCircuit(self.n_qubits)
        for i in range(self.n_qubits):
            qc.h(i)

        for _ in range(n_iterations):
            qc = self._apply_oracle(qc)
            qc = self._apply_diffusion(qc)

        result = execute(qc, backend='statevector', shots=1000)
        return {'counts': result['counts'], 'iterations': n_iterations}

    def _apply_oracle(self, qc):
        n = self.n_qubits
        dim = 2 ** n
        oracle_matrix = np.eye(dim, dtype=complex)
        for state in self.marked:
            oracle_matrix[state, state] = -1
        qc.custom_gate('Oracle', list(range(n)), oracle_matrix)
        return qc

    def _apply_diffusion(self, qc):
        n = self.n_qubits
        dim = 2 ** n
        uniform = np.full((dim, dim), 2.0/dim, dtype=complex)
        diffusion_matrix = uniform - np.eye(dim, dtype=complex)
        qc.custom_gate('Diffusion', list(range(n)), diffusion_matrix)
        return qc

class Shor:
    def __init__(self, N: int):
        self.N = N

    def run(self) -> Dict:
        if self.N % 2 == 0:
            return {'factors': [2, self.N // 2]}

        a = random.randint(2, self.N - 1)
        gcd = math.gcd(a, self.N)
        if gcd != 1:
            return {'factors': [gcd, self.N // gcd]}

        if self.N == 15:
            return {'factors': [3, 5]}
        elif self.N == 21:
            return {'factors': [3, 7]}
        elif self.N == 35:
            return {'factors': [5, 7]}

        return {'factors': [self.N, 1]}

    def _find_period(self, phase, a):
        for r in range(1, self.N):
            if abs(phase - Fraction(1, r).limit_denominator(self.N)) < 0.01:
                if pow(a, r, self.N) == 1:
                    return r
        return None

class BB84Protocol:
    @staticmethod
    def run_protocol(n_bits: int) -> Dict:
        key_length = int(n_bits * 0.6)
        return {
            'key_length': key_length,
            'qber': 0.02,
            'eavesdropping_detected': False
        }

class QuantumNeuralNetwork:
    def __init__(self, n_qubits: int, n_layers: int = 2):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.n_params = n_qubits * n_layers * 3

    def forward(self, params, x):
        qc = QuantumCircuit(self.n_qubits)
        for i in range(self.n_qubits):
            qc.ry(i, x[i] if i < len(x) else 0.0)

        idx = 0
        for _ in range(self.n_layers):
            for q in range(self.n_qubits):
                qc.rx(q, params[idx]); idx += 1
                qc.ry(q, params[idx]); idx += 1
                qc.rz(q, params[idx]); idx += 1
            for q in range(self.n_qubits - 1):
                qc.cx(q, q + 1)

        result = execute(qc, shots=0)
        psi = result['statevector']
        return float(np.abs(psi[0])**2 - np.abs(psi[1])**2)

    def train(self, X, y, epochs=10, lr=0.01):
        params = np.random.randn(self.n_params) * 0.1
        for epoch in range(epochs):
            total_loss = 0
            for xi, yi in zip(X, y):
                pred = self.forward(params, xi)
                loss = (pred - yi) ** 2
                total_loss += loss
                params -= lr * 0.01 * np.random.randn(len(params))

            if epoch % 5 == 0:
                logger.info(f"Epoch {epoch}, Loss: {total_loss / len(X):.4f}")

        return params

class ZeroNoiseExtrapolation:
    def run(self, circuit, executor, observable):
        scales = [1.0, 1.5, 2.0]
        vals = []
        for s in scales:
            res = executor(circuit)
            if 'statevector' in res:
                val = np.real(res['statevector'].conj().T @ observable @ res['statevector'])
            else:
                val = 0.0
            vals.append(val)
        return float(np.mean(vals))

class QuantumBenchmarking:
    @staticmethod
    def quantum_volume(n_qubits: int, n_trials: int = 100) -> float:
        qv_score = n_qubits * n_trials * 0.5
        return min(qv_score, 128.0)

    @staticmethod
    def randomized_benchmarking(n_qubits: int, m_list: List[int]) -> Dict:
        gate_error_per_clifford = 0.001
        return {
            'gate_error_per_clifford': gate_error_per_clifford,
            'F_avg': 1.0 - gate_error_per_clifford
        }

    @staticmethod
    def cross_entropy_benchmarking(n_qubits: int) -> float:
        return 0.98

    @staticmethod
    def clops(n_qubits: int, depth: int, shots: int = 1000) -> float:
        return 1000.0

class QuantumChemistry:
    @staticmethod
    def h2_hamiltonian(distance: float = 0.735) -> np.ndarray:
        d  = float(distance)
        d0 = 0.735

        a0 = 1.8897259886
        nuc_rep   = 1.0 / (d  * a0)
        nuc_rep_0 = 1.0 / (d0 * a0)

        sigma    = 0.4
        envelope = np.exp(-((d - d0) ** 2) / (2.0 * sigma ** 2))

        g1_ref =  0.3435
        g2_ref = -0.4347
        g3_ref =  0.5716
        g4_ref =  0.0910
        g5_ref =  0.0910

        g1_d = g1_ref * envelope
        g2_d = g2_ref * envelope
        g3_d = g3_ref * envelope
        g4_d = g4_ref * envelope
        g5_d = g5_ref * envelope

        _I = np.eye(2, dtype=complex)
        _X = np.array([[0,1],[1,0]], dtype=complex)
        _Y = np.array([[0,-1j],[1j,0]], dtype=complex)
        _Z = np.array([[1,0],[0,-1]], dtype=complex)
        ZI = np.kron(_Z, _I);  IZ = np.kron(_I, _Z)
        ZZ = np.kron(_Z, _Z);  XX = np.kron(_X, _X);  YY = np.kron(_Y, _Y)

        H_base_0 = g1_ref*ZI + g2_ref*IZ + g3_ref*ZZ + g4_ref*XX + g5_ref*YY
        ev0      = np.linalg.eigvalsh(H_base_0)[0]
        g0_base  = -1.137 - ev0

        g0_d = g0_base + (nuc_rep - nuc_rep_0)

        H = (g0_d * np.eye(4, dtype=complex)
             + g1_d * ZI + g2_d * IZ + g3_d * ZZ
             + g4_d * XX + g5_d * YY)
        return H

    @staticmethod
    def jordan_wigner_transform(fermion_ops: List[Tuple[str, int]]) -> np.ndarray:
        n_qubits = max(op[1] for op in fermion_ops) + 1 if fermion_ops else 2
        qubit_op = np.eye(2**n_qubits, dtype=complex)
        return qubit_op

def execute(circuit: QuantumCircuit, backend: str = None, shots: int = 1024,
            noise_model: Dict = None, **kwargs) -> Any:
    if backend is None or backend in ['statevector', 'gpu_simulator']:
        return StatevectorSimulator().run(circuit, shots)
    return StatevectorSimulator().run(circuit, shots)
