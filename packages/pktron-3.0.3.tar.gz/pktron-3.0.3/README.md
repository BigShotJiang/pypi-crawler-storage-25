# PKTron v3.0.3

### 🏆 #1 South Asia | #1 Asia | #5 Globally (Based on Features & Modules)
### AI-Powered Quantum Simulation for Every Scientist — From Circuits to Cosmology in One Interactive Lab, Pakistan's 1st Quantum AI Powered Simulation Framework.

**PKTron AI Quantum Lab** is a comprehensive, AI-assisted quantum computing platform
built entirely in Python. Whether you are a student, researcher, or engineer, PKTron
gives you everything you need to build, simulate, analyse, and understand quantum
systems — no real quantum hardware required.

From simple 2-qubit circuits to 100+ qubit fault-tolerant surface codes, quantum finance models,
molecular chemistry simulations, and an AI assistant that explains every step —
PKTron is the one platform that covers it all.

---

## ⭐ What's New in v3.0.3

PKTron v3.0.3 introduces 60+ production-grade capabilities across quantum computing, machine learning, chemistry, and cryptography:

✅ **9 Advanced Simulators** — Statevector (GPU/MPI, 30 qubits), Density Matrix (Lindblad + Kraus), MPS (100+ qubits, canonical form), PEPS (2D lattice), MERA (multi-scale), Clifford (O(n²)), Tensor Network, Quantum Trajectory, Pulse-level (2nd-order Trotter)

✅ **18+ Quantum Algorithms** — VQE (Pauli decomposition), QPE, Grover (multi-target), QFT, Shor (period finding), HHL (Krylov), QSVM, QAOA, Quantum Walks, Counting, Annealing, Simon's, Deutsch-Jozsa

✅ **Production-Grade Quantum Error Correction** — Steane [[7,1,3]], Surface Code (2D lattice), Repetition Codes, Bacon-Shor, Color Codes with full syndrome extraction & correction

✅ **Advanced Error Mitigation (Research-Grade)** — Zero-Noise Extrapolation (ZNE), Probabilistic Error Cancellation (PEC with Pauli quasi-probability), Clifford Data Regression (CDR), Dynamical Decoupling (XY4/XY8/UDD), Readout Error Mitigation

✅ **Full Quantum Chemistry Suite** — H₂, LiH, H₂O, BeH₂ molecules, Jordan-Wigner & Bravyi-Kitaev transformations, Full-CI solver, Excited states calculation, Molecular Hamiltonian construction, UCC ansatz

✅ **Advanced Quantum Machine Learning** — Quantum Reinforcement Learning (QRL), Quantum Generative Adversarial Networks (QGAN), Quantum Boltzmann Machines, QAutoencoders, Quantum Convolutional Neural Networks (QCNN), Quantum Transfer Learning, Quantum Federated Learning (QFL)

✅ **Quantum Cryptography Suite** — BB84 QKD, E91 Protocol, B92 Protocol, Quantum Random Number Generator (QRNG), Post-quantum cryptography

✅ **Hardware & Compilation (Research-Grade)** — Full Compiler (U3 + CX decomposition), SABRE Routing (optimal qubit routing), DRAG Pulses, Cross-Resonance Pulses, Circuit Synthesis (Exact & approximate), Adaptive Circuits with mid-circuit measurement

✅ **Industry-Standard Benchmarking** — Quantum Volume (full HOG protocol), Randomized Benchmarking, Cross-Entropy Benchmarking (XEB), CLOPS (Circuit Layer Operations Per Second)

✅ **Multi-Backend Execution** — PyPI Publishing Support, Multi-backend executor (IBM, Google, IonQ), Automatic backend selection, GPU (CuPy) acceleration, MPI distributed computing

---

## Install
pip install pktron

## Optional Extras
pip install pktron[gpu]        # GPU acceleration via CuPy (CUDA 12.x)
pip install pktron[chemistry]  # Quantum chemistry via PySCF
pip install pktron[ml]         # Quantum ML via PyTorch & TensorFlow
pip install pktron[full]       # Everything

---

## Quick Start

```python
from pktron import QuantumCircuit, StatevectorSimulator, execute

# Create a 2-qubit quantum circuit
qc = QuantumCircuit(2)

# Apply Hadamard gate to qubit 0
qc.h(0)

# Apply CNOT gate with qubit 0 as control and qubit 1 as target
qc.cx(0, 1)

# Run the circuit using execute function
result = execute(qc, backend='statevector', shots=1024)

# Print the measurement counts
print(f"Counts: {result['counts']}")
```

---

## Why PKTron v3.0.3?

| Feature | PKTron |
|---|---|
| AI Quantum Assistant | Yes — explains circuits step by step |
| Simulators | 9 (SV, DM, MPS, PEPS, MERA, Clifford, TN, Trajectory, Pulse) |
| Fault-Tolerant Codes | Steane, Surface, Repetition, Bacon-Shor, Color |
| Quantum Finance | Portfolio, Risk, Fraud, QKD |
| Scientific Domains | Physics, Chemistry, Biology, Cosmology |
| Noise + Mitigation | ZNE, PEC, CDR, DD, REM fully integrated |
| Algorithms | 18+ including Shor, HHL, Grover, VQE |
| Memory Safe | Runs on free Google Colab (12 GB) |
| GPU Support | Optional via CuPy |

---

## Why PKTron is #1 in South Asia

PKTron is the most complete quantum computing framework built in South Asia with 60+ production-grade features implemented at research level.

No other South Asian quantum framework implements even 25% of these features at production level.

---

## Why PKTron is #1 in Asia

Compared to MindQuantum (Huawei), TensorCircuit (Tencent), Yao.jl (Japan), Qulacs:

| Category | PKTron v3.0.3 | MindQuantum | TensorCircuit | Yao.jl | Qulacs |
|---|---|---|---|---|---|
| Simulators | 9 | 2-3 | 2 | 1 | 2 |
| Algorithms | 18+ | 10+ | 8+ | 6+ | 4+ |
| QEC | Steane, Surface, Repetition, Bacon-Shor, Color | None | None | None | Minimal |
| Error Mitigation | ZNE, PEC, CDR, DD, REM | ZNE only | Limited | None | None |
| Chemistry | Full suite (H₂, LiH, H₂O, BeH₂, JW/BK) | Good | Limited | Basic | None |
| Quantum ML | QRL, QGAN, QBM, QCNN, QFL, Transfer | QNN only | Limited | Basic | None |
| Cryptography | BB84, E91, B92, QRNG | None | None | None | None |

---

## Why PKTron is #5 Globally

Ranked alongside Qiskit (IBM), PennyLane (Xanadu), Cirq/Stim (Google), CUDA-Q (NVIDIA):

| Feature | PKTron | Qiskit | PennyLane | Cirq/Stim | CUDA-Q |
|---|---|---|---|---|---|
| Simulators | 9 | 5+ | 3-4 | 2-3 | 1 |
| Algorithms | 18+ | 25+ | 12+ | 10+ | 8+ |
| Chemistry | Full Suite | Full Suite | Excellent | Minimal | Minimal |
| QEC | Steane, Surface, Repetition, Bacon-Shor, Color | Steane, Surface | Theoretical only | Stim codes | None |
| Error Mitigation | ZNE/PEC/CDR/DD/REM | ZNE/PEC/REM | Limited | Limited | GPU-focused |
| Quantum ML | QRL/QGAN/QCNN/QFL | Qiskit ML | Excellent | Minimal | Limited |
| Cryptography | BB84/E91/B92/QRNG | None | None | None | None |

PKTron trails only in ecosystem maturity but matches or exceeds leaders in breadth, integration, and specialized domains.

## The Official Rankings (Pure Features & Modules Only)

## Global Top 5
###Qiskit (IBM)
###PennyLane (Xanadu)
###Cirq + Stim (Google)
###CUDA-Q (NVIDIA)
###PKTron v3.0.3 (Pakistan)

## Asia Top 5
###PKTron v3.0.3 (Pakistan)
###Qulacs / Yao.jl (Japan)
###MindQuantum (Huawei, China)
###TensorCircuit (Tencent, China)

##South Asia
###PKTron v3.0.3 (Pakistan) — Undisputed champion

---

## Core Features

### 🖥️ 9 Advanced Simulators

| Simulator | Qubits | Special Feature | Use Case |
|---|---|---|---|
| Statevector | ~30 | GPU/MPI, BIG-ENDIAN | General circuits, high fidelity |
| Density Matrix | ~12 | Lindblad, noise | Open systems, decoherence |
| MPS | ~200 | Auto-truncation | Long chains, 1D systems |
| PEPS | ~100 | 2D lattice | 2D quantum states |
| MERA | ~200 | Multi-scale | Renormalization group |
| Clifford | ~1000 | O(n²) | Stabilizer circuits |
| Tensor Network | ~100 | Auto-optimization | Entangled states |
| Trajectory | ~20 | Monte Carlo | Open quantum systems |
| Pulse | ~10 | Trotter evolution | Pulse-level control |

### 🔬 18+ Quantum Algorithms

- **Variational:** VQE, QAOA, Quantum Autoencoders, QGAN
- **Search:** Grover (multi-target), Quantum Counting, Amplitude Amplification
- **Factoring:** Shor's algorithm with full period-finding via QPE
- **Linear Systems:** HHL with Krylov subspace method
- **Transforms:** Quantum Fourier Transform, Quantum Walks
- **Classical-Hybrid:** QSVM, Quantum Annealing, Simon's, Deutsch-Jozsa

### ⚠️ Production-Grade QEC

- **Steane [[7,1,3]]** — Logical qubit encoding with 3-distance
- **Surface Code** — 2D topological code with syndrome extraction
- **Repetition Codes** — Bit-flip and phase-flip protection
- **Bacon-Shor Code** — Non-CSS code with hardware efficiency
- **Color Codes** — 2D color structure with fault-tolerance

### 🛡️ Advanced Error Mitigation

- **ZNE** — Polynomial extrapolation to zero noise
- **PEC** — Pauli quasi-probability decomposition
- **CDR** — Machine learning regression with near-Clifford training
- **Dynamical Decoupling** — XY4/XY8/UDD sequences
- **REM** — Matrix inversion with regularization

### 🧪 Full Quantum Chemistry Suite

- **Molecules:** H₂ (0.735 Å), LiH, H₂O, BeH₂
- **Transformations:** Jordan-Wigner, Bravyi-Kitaev
- **Solvers:** Full-CI, Excited states (SSVQE), qEOM

### 🤖 Quantum Machine Learning

- Quantum Reinforcement Learning (QRL)
- QGAN — Quantum generator, classical discriminator
- Quantum Boltzmann Machines
- QAutoencoders
- QCNN — Quantum convolutional filters with pooling
- Quantum Transfer Learning
- Quantum Federated Learning (QFL)

### 🔐 Quantum Cryptography

- BB84 QKD — Sift and privacy amplification
- E91 Protocol — Bell inequality violation detection
- B92 Protocol — Two-basis QKD variant
- Quantum RNG — True random number generation
- Post-Quantum Integration

---

## Performance Benchmarks

| Configuration | Max Qubits | Speed | Memory |
|---|---|---|---|
| CPU (statevector) | 25 | ~1ms/gate | 4 GB |
| GPU (CuPy, statevector) | 30 | ~0.1ms/gate | 8 GB |
| MPS (CPU) | 200+ | ~10ms/gate | 1 GB |
| Clifford | 1000+ | ~0.01ms/gate | 100 MB |
| Density Matrix (CPU) | 12 | ~10ms/gate | 16 GB |

---

## Architecture Highlights

✅ BIG-ENDIAN qubit ordering — Qubit 0 = MSB (Qiskit-compatible)
✅ Scalable statevector simulation — GPU/MPI support with automatic fallback
✅ Multiple simulator backends — Automatic selection based on circuit size
✅ Research-grade algorithms — Rigorous mathematical foundations
✅ Full quantum error correction — Circuit-based codes with syndrome extraction
✅ Comprehensive noise modeling — Physical error models from device characterization
✅ Hardware execution — Multi-backend executor (IBM/Google/IonQ/AWS)
✅ Automated differentiation — Parameter gradients for variational algorithms
✅ Canonical MPS — QR orthogonalization with automatic truncation

---

## Supported Platforms

✅ Linux (Ubuntu 18.04+, CentOS 7+)
✅ macOS (10.13+, Intel & Apple Silicon)
✅ Windows (10+, WSL2)
✅ Cloud (Google Colab, AWS, Azure)
✅ HPC (XSEDE, NERSC, Summit with MPI)

---

## Dependencies

**Core:** NumPy ≥ 1.21, SciPy ≥ 1.7, Matplotlib ≥ 3.4, NetworkX ≥ 2.6

**Optional:**
- GPU: CuPy (CUDA 12.x)
- Chemistry: PySCF ≥ 2.0
- ML: PyTorch ≥ 1.12, TensorFlow ≥ 2.10
- Distributed: mpi4py ≥ 3.0

---

## Documentation & Community

- 🐛 Report Issues: https://github.com/paktronsimulatorpakistan
- 💬 Discussions: https://github.com/paktronsimulatorpakistan/discussions

---

## Citation

If you use PKTron in your research, please cite:
@software{pktron2026,
author = {CETQAP and PKTron Development Team},
title = {PKTron v3.0.3: AI-Powered Quantum Computing Framework},
year = {2026},
url = {https://github.com/thecetqap/pktron},
version = {3.0.3}
}

---

## License

MIT License — free to use, modify, and distribute for academic and commercial purposes.

---

*PKTron v3.0.3 — #1 in South Asia | #1 in Asia | #5 Globally*
*Making quantum computing accessible, production-ready, and research-grade for scientists, engineers, and developers worldwide.*

For inquiries: info@thecetqap.com
