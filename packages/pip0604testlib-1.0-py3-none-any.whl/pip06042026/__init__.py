import cv2
import mediapipe as mp
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def main():
    cap = cv2.VideoCapture(1)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    mp_hands = mp.solutions.hands
    mp_draw = mp.solutions.drawing_utils
    hands = mp_hands.Hands(
        max_num_hands=2,
        min_detection_confidence=0.7,
        min_tracking_confidence=0.5
    )

    window_name = "Video Capture"

    rect1_tl, rect1_br = (200, 100), (600, 600)
    rect2_tl, rect2_br = (680, 100), (1080, 600)

    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break

        frame = cv2.flip(frame, 1)
        h, w, _ = frame.shape

        img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(img_rgb)

        color_rect1 = (255, 0, 0)
        color_rect2 = (255, 0, 0)

        if results.multi_hand_landmarks:
            for idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                hand_label = results.multi_handedness[idx].classification[0].label

                lm = hand_landmarks.landmark
                points = [(int(p.x * w), int(p.y * h)) for p in lm]

                def is_all_inside(pts, tl, br):
                    return all(tl[0] <= p[0] <= br[0] and tl[1] <= p[1] <= br[1] for p in pts)

                fingers_open = []
                for tip, pip in zip([8, 12, 16, 20], [6, 10, 14, 18]):
                    if lm[tip].y < lm[pip].y:
                        fingers_open.append(True)
                    else:
                        fingers_open.append(False)

                is_fist = all(not f for f in fingers_open)
                is_palm = all(f for f in fingers_open)

                if hand_label == 'Left':
                    if is_all_inside(points, rect1_tl, rect1_br):
                        if is_fist:
                            color_rect1 = (0, 255, 255)
                        else:
                            color_rect1 = (0, 255, 0)

                if hand_label == 'Right':
                    if is_all_inside(points, rect2_tl, rect2_br):
                        if is_palm:
                            color_rect2 = (0, 255, 255)
                        else:
                            color_rect2 = (0, 255, 0)

        cv2.rectangle(frame, rect1_tl, rect1_br, color_rect1, 4)
        cv2.rectangle(frame, rect2_tl, rect2_br, color_rect2, 4)

        cv2_im_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil_im = Image.fromarray(cv2_im_rgb)
        draw = ImageDraw.Draw(pil_im)
        try:
            font = ImageFont.truetype("arial.ttf", 40)
        except:
            font = ImageFont.load_default()
        draw.text((20, 20), "Жест", font=font, fill=(255, 0, 0))

        frame = cv2.cvtColor(np.array(pil_im), cv2.COLOR_RGB2BGR)

        cv2.imshow(window_name, frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('E') or key == ord('e'):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()


#5.3 с комментариями
# import cv2
# import mediapipe as mp
# import numpy as np
# from PIL import Image, ImageDraw, ImageFont
#
# def main():
#     # ===== НАСТРОЙКА ВИДЕОЗАХВАТА =====
#     cap = cv2.VideoCapture(1)  # Открываем камеру (1 - обычно внешняя камера, 0 - встроенная)
#     cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)   # Устанавливаем ширину кадра
#     cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)   # Устанавливаем высоту кадра
#
#     # ===== ИНИЦИАЛИЗАЦИЯ MEDIAPIPE ДЛЯ РАСПОЗНАВАНИЯ РУК =====
#     mp_hands = mp.solutions.hands
#     mp_draw = mp.solutions.drawing_utils
#     hands = mp_hands.Hands(
#         max_num_hands=2,              # Максимальное количество рук для отслеживания
#         min_detection_confidence=0.7, # Минимальная уверенность для обнаружения
#         min_tracking_confidence=0.5   # Минимальная уверенность для отслеживания
#     )
#
#     window_name = "Video Capture"
#
#     # ===== ОПРЕДЕЛЕНИЕ ЗОН (КВАДРАТОВ) ДЛЯ ЛЕВОЙ И ПРАВОЙ РУКИ =====
#     # Прямоугольник 1 (левый) - верхний левый и нижний правый углы
#     rect1_tl, rect1_br = (200, 100), (600, 600)
#     # Прямоугольник 2 (правый)
#     rect2_tl, rect2_br = (680, 100), (1080, 600)
#
#     # ===== ОСНОВНОЙ ЦИКЛ ОБРАБОТКИ ВИДЕО =====
#     while cap.isOpened():
#         success, frame = cap.read()  # Читаем кадр
#         if not success:
#             break
#
#         frame = cv2.flip(frame, 1)   # Отзеркаливаем кадр (как в зеркале)
#         h, w, _ = frame.shape        # Получаем высоту и ширину кадра
#
#         # Конвертируем BGR в RGB (MediaPipe требует RGB)
#         img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#         results = hands.process(img_rgb)  # Распознаем руки на кадре
#
#         # Цвета квадратов по умолчанию (синий)
#         color_rect1 = (255, 0, 0)
#         color_rect2 = (255, 0, 0)
#
#         # ===== ОБРАБОТКА РАСПОЗНАННЫХ РУК =====
#         if results.multi_hand_landmarks:
#             for idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
#                 # Рисуем скелет руки (ключевые точки и соединения)
#                 mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
#
#                 # Определяем, левая это рука или правая
#                 hand_label = results.multi_handedness[idx].classification[0].label
#
#                 # Получаем координаты всех 21 ключевых точек руки
#                 lm = hand_landmarks.landmark
#                 points = [(int(p.x * w), int(p.y * h)) for p in lm]
#
#                 # Вспомогательная функция: все ли точки внутри прямоугольника?
#                 def is_all_inside(pts, tl, br):
#                     return all(tl[0] <= p[0] <= br[0] and tl[1] <= p[1] <= br[1] for p in pts)
#
#                 # ===== РАСПОЗНАВАНИЕ ЖЕСТОВ =====
#                 fingers_open = []
#                 # Проверяем 4 пальца (кроме большого): кончик (tip) и средняя фаланга (pip)
#                 for tip, pip in zip([8, 12, 16, 20], [6, 10, 14, 18]):
#                     # Если кончик выше средней фаланги (по y) - палец поднят
#                     if lm[tip].y < lm[pip].y:
#                         fingers_open.append(True)
#                     else:
#                         fingers_open.append(False)
#
#                 # Кулак - все 4 пальца сжаты
#                 is_fist = all(not f for f in fingers_open)
#                 # Раскрытая ладонь - все 4 пальца подняты
#                 is_palm = all(f for f in fingers_open)
#
#                 # ===== ЛОГИКА ИЗМЕНЕНИЯ ЦВЕТА КВАДРАТОВ =====
#                 # Если левая рука полностью внутри левого квадрата
#                 if hand_label == 'Left':
#                     if is_all_inside(points, rect1_tl, rect1_br):
#                         if is_fist:
#                             color_rect1 = (0, 255, 255)  # Желтый (кулак)
#                         else:
#                             color_rect1 = (0, 255, 0)    # Зеленый (не кулак)
#
#                 # Если правая рука полностью внутри правого квадрата
#                 if hand_label == 'Right':
#                     if is_all_inside(points, rect2_tl, rect2_br):
#                         if is_palm:
#                             color_rect2 = (0, 255, 255)  # Желтый (раскрытая ладонь)
#                         else:
#                             color_rect2 = (0, 255, 0)    # Зеленый (не раскрытая ладонь)
#
#         # ===== ОТРИСОВКА КВАДРАТОВ =====
#         cv2.rectangle(frame, rect1_tl, rect1_br, color_rect1, 4)
#         cv2.rectangle(frame, rect2_tl, rect2_br, color_rect2, 4)
#
#         # ===== ДОБАВЛЕНИЕ ТЕКСТА (С ИСПОЛЬЗОВАНИЕМ PIL ДЛЯ РУССКОГО ШРИФТА) =====
#         cv2_im_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR -> RGB
#         pil_im = Image.fromarray(cv2_im_rgb)                 # В PIL Image
#         draw = ImageDraw.Draw(pil_im)
#         try:
#             font = ImageFont.truetype("arial.ttf", 40)       # Попытка загрузить шрифт
#         except:
#             font = ImageFont.load_default()                  # Шрифт по умолчанию (без кириллицы)
#         draw.text((20, 20), "Жест", font=font, fill=(255, 0, 0))  # Рисуем текст
#
#         # Конвертируем обратно в BGR для OpenCV
#         frame = cv2.cvtColor(np.array(pil_im), cv2.COLOR_RGB2BGR)
#
#         # ===== ОТОБРАЖЕНИЕ И УПРАВЛЕНИЕ =====
#         cv2.imshow(window_name, frame)
#
#         key = cv2.waitKey(1) & 0xFF
#         if key == ord('E') or key == ord('e'):  # Выход по клавише E
#             break
#
#     # ===== ОСВОБОЖДЕНИЕ РЕСУРСОВ =====
#     cap.release()
#     cv2.destroyAllWindows()
#
# if __name__ == "__main__":
#     main()






# Задание 2025 интерфейс







# import cv2 as cv
#
# background = cv.imread('background.png')
#
# image_001 = cv.imread("image_001.png")
# image_002 = cv.imread("image_002.png")
#
# filtered_image_001 = cv.imread("image_filter_001.png")
# filtered_image_002 = cv.imread("image_filter_002.png")
#
# image_001_resized = cv.resize(image_001, (260, 195))
# image_002_resized = cv.resize(image_002, (260, 195))
# main_image_001_resized = cv.resize(image_001, (800, 600))
#
# filtered_image_001_resized = cv.resize(filtered_image_001, (60, 60))
# filtered_image_002_resized = cv.resize(filtered_image_002, (60, 60))
# filtered_image_001_resized1 = cv.resize(filtered_image_001, (100, 100))
# filtered_image_002_resized1 = cv.resize(filtered_image_002, (100, 100))
#
# background[20:215, 20:280] = image_001_resized
# background[235:430, 20:280] = image_002_resized
#
# background[640:700, 320:380] = filtered_image_001_resized
# background[640:700, 400:460] = filtered_image_002_resized
#
# background[20:620, 320:1120] = main_image_001_resized
#
# background[20:120, 1160:1260] = filtered_image_001_resized1
# background[140:240, 1160:1260] = filtered_image_002_resized1
#
# cv.imshow('Task #5', background)
# while True:
#     if cv.waitKey(1) & 0xFF == 27:
#         break
#
# cv.destroyAllWindows()







# Задание 2025 с рукой






# import cv2 as cv
# import mediapipe as mp
# import math
#
# mp_hands = mp.solutions.hands
# mp_drawing = mp.solutions.drawing_utils
# hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
#
# background = cv.imread('background.png')
# background_height, background_width = background.shape[:2]
#
# image_001 = cv.imread("image_001.png")
# image_002 = cv.imread("image_002.png")
#
# filtered_image_001 = cv.imread("image_filter_001.png")
# filtered_image_002 = cv.imread("image_filter_002.png")
#
# image_001_resized = cv.resize(image_001, (260, 195))
# image_002_resized = cv.resize(image_002, (260, 195))
# main_image_001_resized = cv.resize(image_001, (800, 600))
# main_image_002_resized = cv.resize(image_002, (800, 600))
#
# filtered_image_001_resized = cv.resize(filtered_image_001, (60, 60))
# filtered_image_002_resized = cv.resize(filtered_image_002, (60, 60))
# filtered_image_001_resized1 = cv.resize(filtered_image_001, (100, 100))
# filtered_image_002_resized1 = cv.resize(filtered_image_002, (100, 100))
#
# background[20:215, 20:280] = image_001_resized
# background[235:430, 20:280] = image_002_resized
#
# background[640:700, 320:380] = filtered_image_001_resized
# background[640:700, 400:460] = filtered_image_002_resized
#
# background[20:620, 320:1120] = main_image_001_resized
#
# background[20:120, 1160:1260] = filtered_image_001_resized1
# background[140:240, 1160:1260] = filtered_image_002_resized1
#
# cursor_radius = 10
# cursor_color = (0, 0, 255)
# active_color = (0, 255, 0)
# last_cursor_pos = (background_height//2, background_width//2)
# selected_idx = -1
#
# GESTURE_TRESHOLD = 20
# cap = cv.VideoCapture(0)
# cap.set(cv.CAP_PROP_FRAME_WIDTH,  1280)
# cap.set(cv.CAP_PROP_FRAME_HEIGHT, 720)
#
# cv.imshow('Task #5', background)
# while True:
#     read_ok, frame = cap.read()
#     if not read_ok:
#         break
#
#     frame = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
#     results = hands.process(frame)
#     frame = cv.cvtColor(frame, cv.COLOR_RGB2BGR)
#
#     gesture_detected = False
#     current_cursor = last_cursor_pos
#
#     if results.multi_hand_landmarks is not None:
#         for hand_landmark, hand_nandedness in zip(results.multi_hand_landmarks, results.multi_handedness):
#             if hand_nandedness.classification[0].label != 'Right':
#                 continue
#
#             thumb = hand_landmark.landmark[mp_hands. HandLandmark.THUMB_TIP]
#             index = hand_landmark.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
#
#             h, w = frame.shape[:2]
#             thumb_x, thumb_y = int(thumb.x*w), int(thumb.y*h)
#             index_x, index_y = int(index.x*w), int(index.y*h)
#
#             distance = int(math.hypot(thumb_x - index_x, thumb_y - index_y))
#             gesture_detected = distance < GESTURE_TRESHOLD
#
#             current_cursor = (index_x, index_y)
#             last_cursor_pos = current_cursor
#
#     x, y = current_cursor
#     x = max(cursor_radius, min(x, background_width - cursor_radius))
#     y = max(cursor_radius, min(y, background_height - cursor_radius))
#     current_cursor = (x, y)
#     print(current_cursor)
#     display_bg = background.copy()
#
#     if gesture_detected:
#         color = active_color
#         if y >= 20 and y <= 215 and x >= 20 and x <= 280:
#             background[20:620, 320:1120] = main_image_001_resized
#         if y >= 235 and y <= 430 and x >= 20 and x <= 280:
#             background[20:620, 320:1120] = main_image_002_resized
#     else:
#         color = cursor_color
#
#     cv.circle(display_bg, current_cursor, cursor_radius, color, -1)
#
#     cv.imshow( "Task #5", display_bg)
#     k = cv.waitKey(30)
#     if k == 27:
#         break
#
# cap.release()
# cv.destroyAllWindows()








# Задание 2023








# """
# Игра "Balloons" - ловля воздушных шариков указательным пальцем
# с использованием компьютерного зрения (MediaPipe + OpenCV)
# ИСПРАВЛЕННАЯ ВЕРСИЯ
# """
#
# import cv2
# import numpy as np
# import random
# import time
# from typing import Optional, Tuple
#
# import mediapipe as mp
#
#
# class HandsDetector:
#     """
#     Класс для распознавания кистей рук на изображении
#     Аналог модуля HandsDetector.py из задания
#     """
#
#     def __init__(self, static_image_mode=False, max_num_hands=2,
#                  min_detection_confidence=0.5, min_tracking_confidence=0.5):
#         self.mp_hands = mp.solutions.hands
#         self.hands = self.mp_hands.Hands(
#             static_image_mode=static_image_mode,
#             max_num_hands=max_num_hands,
#             min_detection_confidence=min_detection_confidence,
#             min_tracking_confidence=min_tracking_confidence
#         )
#         self.mp_draw = mp.solutions.drawing_utils
#         self.results = None
#
#     def find_hands(self, img, draw=True):
#         """Поиск кистей рук на изображении"""
#         img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#         self.results = self.hands.process(img_rgb)
#
#         if draw and self.results.multi_hand_landmarks:
#             for hand_landmarks in self.results.multi_hand_landmarks:
#                 self.mp_draw.draw_landmarks(
#                     img, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)
#         return img
#
#     def find_finger_tip(self, img, hand_type=None):
#         """
#         Находит кончик указательного пальца
#         Возвращает координаты (x, y) и тип руки ('Left' или 'Right')
#         """
#         h, w, _ = img.shape
#         tip_coords = None
#         hand_type_found = None
#
#         if self.results and self.results.multi_hand_landmarks and self.results.multi_handedness:
#             for idx, hand_landmarks in enumerate(self.results.multi_hand_landmarks):
#                 # Определяем тип руки
#                 handedness = self.results.multi_handedness[idx].classification[0].label
#
#                 # Если указан конкретный тип руки и он не совпадает - пропускаем
#                 if hand_type and handedness != hand_type:
#                     continue
#
#                 # Координаты кончика указательного пальца (landmark 8)
#                 tip = hand_landmarks.landmark[8]
#                 tip_x, tip_y = int(tip.x * w), int(tip.y * h)
#                 tip_coords = (tip_x, tip_y)
#                 hand_type_found = handedness
#                 break  # Берем только один палец (первый найденный)
#
#         return tip_coords, hand_type_found
#
#
# class Balloon:
#     """Класс воздушного шарика"""
#
#     def __init__(self, size_type: str, window_width: int, window_height: int):
#         """
#         size_type: 'big', 'medium', 'small'
#         """
#         self.size_type = size_type
#
#         # Параметры размеров в соответствии с заданием
#         sizes = {
#             'big': (115, 150),
#             'medium': (90, 117),
#             'small': (65, 84)
#         }
#
#         self.width, self.height = sizes[size_type]
#         self.window_width = window_width
#         self.window_height = window_height
#
#         # Скорость движения (пикселей в секунду)
#         # В задании указано 10, 15, 20 пикселей в миллисекунду
#         # Это очень быстро для обычного видео (10 px/ms = 10000 px/сек)
#         # Уменьшаем для комфортной игры, сохраняя пропорции
#         speeds_px_per_ms = {
#             'big': 10,
#             'medium': 15,
#             'small': 20
#         }
#         # Переводим в пиксели в секунду (умножаем на 60 для 60 FPS)
#         # Но для реальной игры лучше использовать разумную скорость
#         # Используем px/ms * 60 для ~60 FPS, но ограничиваем
#         self.speed = speeds_px_per_ms[size_type] * 30  # Умеренная скорость
#
#         # Позиция шарика (целые числа)
#         self.x = 0
#         self.y = 0
#         self.reset_position()
#
#         # Создаем изображение шарика с прозрачностью
#         self.image = self._create_balloon_image()
#
#     def _create_balloon_image(self):
#         """Создает изображение шарика с прозрачным фоном"""
#         # Создаем RGBA изображение
#         img = np.zeros((self.height, self.width, 4), dtype=np.uint8)
#
#         # Цвета шариков в зависимости от размера (в BGR)
#         colors = {
#             'big': (0, 0, 255),  # Красный
#             'medium': (0, 255, 255),  # Желтый
#             'small': (255, 0, 255)  # Пурпурный
#         }
#
#         color = colors[self.size_type]
#
#         # Рисуем круг (шарик)
#         center = (self.width // 2, self.height // 2)
#         radius = min(self.width, self.height) // 2 - 5
#
#         # Заливка круга
#         for y in range(self.height):
#             for x in range(self.width):
#                 if (x - center[0]) ** 2 + (y - center[1]) ** 2 <= radius ** 2:
#                     img[y, x] = [color[2], color[1], color[0], 255]  # BGRA
#
#         # Добавляем "хвостик" шарика
#         tail_start = (center[0], center[1] + radius)
#         tail_end = (center[0], center[1] + radius + 15)
#         if tail_end[1] < self.height:
#             cv2.line(img, tail_start, tail_end, (0, 0, 0, 255), 2)
#
#         # Добавляем блик на шарик
#         highlight_center = (center[0] - radius // 3, center[1] - radius // 3)
#         highlight_radius = radius // 4
#         for y in range(self.height):
#             for x in range(self.width):
#                 if (x - highlight_center[0]) ** 2 + (y - highlight_center[1]) ** 2 <= highlight_radius ** 2:
#                     if img[y, x, 3] > 0:
#                         img[y, x] = [255, 255, 255, 200]
#
#         return img
#
#     def reset_position(self):
#         """Устанавливает шарик в верхней части окна со случайной горизонтальной позицией"""
#         max_x = self.window_width - self.width
#         if max_x < 0:
#             max_x = 0
#         self.x = random.randint(0, max(0, max_x))
#         self.y = 0  # Верхняя граница соприкасается с верхней границей окна
#
#     def update(self, delta_time: float):
#         """Обновляет позицию шарика"""
#         self.y += self.speed * delta_time
#
#     def is_off_screen(self) -> bool:
#         """Проверяет, вышел ли шарик за нижнюю границу"""
#         return self.y >= self.window_height
#
#     def check_collision(self, finger_pos: Optional[Tuple[int, int]]) -> bool:
#         """Проверяет, попал ли палец в область шарика"""
#         if not finger_pos:
#             return False
#
#         fx, fy = finger_pos
#
#         # Проверяем целые координаты
#         ix, iy = int(self.x), int(self.y)
#         iwidth, iheight = int(self.width), int(self.height)
#
#         # Проверяем, находится ли палец внутри прямоугольника шарика
#         if ix <= fx <= ix + iwidth and iy <= fy <= iy + iheight:
#             # Дополнительная проверка на прозрачность (попадание именно в шарик)
#             img_x = fx - ix
#             img_y = fy - iy
#             if 0 <= img_x < iwidth and 0 <= img_y < iheight:
#                 # Проверяем альфа-канал (не прозрачный ли пиксель)
#                 alpha = self.image[img_y, img_x, 3]
#                 return alpha > 128
#         return False
#
#     def draw(self, frame):
#         """Рисует шарик на кадре с учетом прозрачности"""
#         # Преобразуем координаты в целые числа
#         x_int = int(self.x)
#         y_int = int(self.y)
#
#         # Проверяем, что шарик полностью или частично в пределах кадра
#         if y_int >= frame.shape[0] or x_int >= frame.shape[1]:
#             return
#
#         # Вычисляем область для наложения
#         y_end = min(y_int + self.height, frame.shape[0])
#         x_end = min(x_int + self.width, frame.shape[1])
#
#         # Вычисляем соответствующие области на изображении шарика
#         img_y_end = y_end - y_int
#         img_x_end = x_end - x_int
#
#         if img_y_end <= 0 or img_x_end <= 0:
#             return
#
#         # Получаем ROI кадра
#         roi = frame[y_int:y_end, x_int:x_end]
#
#         # Получаем соответствующую часть изображения шарика
#         balloon_part = self.image[:img_y_end, :img_x_end]
#
#         # Альфа-маска
#         if balloon_part.shape[2] == 4:
#             alpha = balloon_part[:, :, 3] / 255.0
#             alpha = np.stack([alpha, alpha, alpha], axis=2)
#
#             # Наложение с альфа-каналом
#             if roi.shape == balloon_part[:, :, :3].shape:
#                 roi[:] = roi * (1 - alpha) + balloon_part[:, :, :3] * alpha
#
#
# class Game:
#     """Основной класс игры"""
#
#     def __init__(self):
#         # Размер окна согласно заданию
#         self.window_width = 1280
#         self.window_height = 720
#
#         # Параметры игры
#         self.score = 0
#         self.game_finished = False
#         self.last_time = time.time()
#         self.last_catch_time = 0  # Для защиты от многократного попадания
#
#         # Создаем детектор рук
#         self.detector = HandsDetector()
#
#
#         # Запускаем камеру
#         self.cap = cv2.VideoCapture(1)
#         self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.window_width)
#         self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.window_height)
#
#         # Проверяем, установилось ли разрешение
#         actual_width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
#         actual_height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
#         print(f"Установлено разрешение камеры: {actual_width}x{actual_height}")
#
#         # Текущий шарик
#         self.current_balloon = None
#         self._create_new_balloon()
#
#         # Шрифт для текста
#         self.font = cv2.FONT_HERSHEY_SIMPLEX
#
#     def _create_new_balloon(self):
#         """Создает новый шарик в зависимости от текущего счета"""
#         if self.score < 30:
#             size_type = 'big'
#         elif self.score < 70:
#             size_type = 'medium'
#         else:
#             size_type = 'small'
#
#         self.current_balloon = Balloon(size_type, self.window_width, self.window_height)
#
#     def update_score(self, points: int):
#         """Обновляет счет и управляет сменой шариков"""
#         self.score = points
#
#         # Проверяем завершение игры
#         if self.score >= 100:
#             self.game_finished = True
#             self.score = 100  # Фиксируем максимальный счет
#         else:
#             # Создаем новый шарик (размер может измениться)
#             self._create_new_balloon()
#
#     def check_balloon_catch(self, finger_pos):
#         """Проверяет, поймал ли игрок шарик"""
#         if not self.game_finished and self.current_balloon:
#             current_time = time.time()
#             # Защита от многократного попадания за один шарик
#             if current_time - self.last_catch_time > 0.2:
#                 if self.current_balloon.check_collision(finger_pos):
#                     self.last_catch_time = current_time
#                     self.update_score(self.score + 10)
#                     return True
#         return False
#
#     def update(self):
#         """Обновляет состояние игры"""
#         if self.game_finished:
#             return
#
#         current_time = time.time()
#         delta_time = current_time - self.last_time
#         self.last_time = current_time
#
#         # Ограничиваем delta_time для предотвращения скачков
#         delta_time = min(delta_time, 0.033)
#
#         # Обновляем позицию шарика
#         if self.current_balloon:
#             self.current_balloon.update(delta_time)
#
#             # Если шарик упал (вышел за экран), создаем новый
#             if self.current_balloon.is_off_screen():
#                 self._create_new_balloon()
#
#     def run(self):
#         """Главный игровой цикл"""
#         cv2.namedWindow('Balloons', cv2.WINDOW_NORMAL)
#         cv2.resizeWindow('Balloons', self.window_width, self.window_height)
#
#         print("Игра началась! Ловите шарики указательным пальцем!")
#
#         while True:
#             # Захват кадра
#             ret, frame = self.cap.read()
#             if not ret:
#                 print("Ошибка захвата кадра")
#                 break
#
#             # Изменяем размер кадра, если необходимо
#             if frame.shape[1] != self.window_width or frame.shape[0] != self.window_height:
#                 frame = cv2.resize(frame, (self.window_width, self.window_height))
#
#             # Создаем копию для отрисовки
#             display_frame = frame.copy()
#
#             # Поиск рук и кончика указательного пальца
#             self.detector.find_hands(display_frame, draw=False)
#             finger_pos, hand_type = self.detector.find_finger_tip(display_frame)
#
#             # Рисуем окружность на кончике пальца
#             if finger_pos:
#                 # Залитая окружность радиусом 20 пикселей
#                 # Цвет BGR: (0, 255, 255) - желтый
#                 cv2.circle(display_frame, finger_pos, 20, (0, 255, 255), -1)
#
#                 # Проверяем попадание в шарик
#                 self.check_balloon_catch(finger_pos)
#
#             # Обновляем состояние игры
#             self.update()
#
#             # Рисуем шарик (если игра не завершена)
#             if not self.game_finished and self.current_balloon:
#                 self.current_balloon.draw(display_frame)
#
#             # Отображаем счет
#             score_text = f"Score: {self.score}"
#             # Цвет текста BGR: (29, 230, 181)
#             cv2.putText(display_frame, score_text, (20, 50), self.font,
#                         1.0, (29, 230, 181), 2)
#
#             # Если игра завершена, показываем сообщение
#             if self.game_finished:
#                 # Текст по центру окна
#                 text = "Game Finished"
#                 font_scale = 1.5
#                 text_size = cv2.getTextSize(text, self.font, font_scale, 3)[0]
#                 text_x = (self.window_width - text_size[0]) // 2
#                 text_y = (self.window_height + text_size[1]) // 2
#                 # Цвет BGR: (0, 128, 255)
#                 cv2.putText(display_frame, text, (text_x, text_y), self.font,
#                             font_scale, (0, 128, 255), 3)
#
#                 # Инструкция по выходу
#                 exit_text = "Press any key to exit"
#                 exit_scale = 0.7
#                 exit_size = cv2.getTextSize(exit_text, self.font, exit_scale, 2)[0]
#                 exit_x = (self.window_width - exit_size[0]) // 2
#                 cv2.putText(display_frame, exit_text, (exit_x, text_y + 60), self.font,
#                             exit_scale, (200, 200, 200), 2)
#
#                 # Также показываем финальный счет
#                 final_score_text = f"Final Score: {self.score}"
#                 final_size = cv2.getTextSize(final_score_text, self.font, 0.8, 2)[0]
#                 final_x = (self.window_width - final_size[0]) // 2
#                 cv2.putText(display_frame, final_score_text, (final_x, text_y - 40), self.font,
#                             0.8, (29, 230, 181), 2)
#
#             # Показываем результат
#             cv2.imshow('Balloons', display_frame)
#
#             # Обработка клавиш
#             key = cv2.waitKey(1) & 0xFF
#             if key == 27:  # Escape
#                 print("Выход по клавише ESC")
#                 break
#             if self.game_finished and key != 255:  # Любая клавиша после завершения
#                 print(f"Игра завершена! Финальный счет: {self.score}")
#                 break
#
#         # Освобождаем ресурсы
#         self.cap.release()
#         cv2.destroyAllWindows()
#
#     def __del__(self):
#         if hasattr(self, 'cap') and self.cap.isOpened():
#             self.cap.release()
#
#
# def main():
#     """Точка входа в программу"""
#     print("=" * 50)
#     print("           Игра Balloons")
#     print("=" * 50)
#     print("Правила игры:")
#     print("1. Ловите шарики указательным пальцем")
#     print("2. За каждый шарик дается 10 очков")
#     print("3. Цель - набрать 100 очков")
#     print("4. Шарики ускоряются с набором очков")
#     print("-" * 50)
#     print("Управление:")
#     print("- ESC - выход из игры в любой момент")
#     print("- Любая клавиша - выход после завершения игры")
#     print("=" * 50)
#     input("Нажмите Enter для начала игры...")
#
#     game = Game()
#     game.run()
#
#     print("Спасибо за игру!")
#
#
# if __name__ == "__main__":
#     main()