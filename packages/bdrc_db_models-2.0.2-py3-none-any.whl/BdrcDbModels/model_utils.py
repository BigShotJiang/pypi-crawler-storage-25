"""
Some utilities. These used to be class members of the DrsDbContextBase,
but the ORM classes were refactored into this library, so they could not be
in the BdrcDbLib package (circular reference).

Clients who use this will have to use them in the context of a DrsDbContext session.
"""

import logging
from sqlalchemy import select
from BdrcDbModels.models import Works, Volumes, GbDownload
from BdrcDbLib.SqlAlchemy_get_or_create import get_or_create

def get_some_works(session) -> list:
    """
    Test shell. See https://auth0.com/blog/sqlalchemy-orm-tutorial-for-python-developers/
    for starters
    :return:
    """
    return session.query(Works).filter(Works.WorkName == 'W1FPL2251').all()

def get_work_by_name(session, work_name: str) -> Works:
    """
    Get work by Name
    :param work_name: work to fetch
    :return: MySQL ORM object
    """
    return session.query(Works).filter(Works.WorkName == work_name).first()

def get_or_create_work(session, work_name: str) -> Works:
    """
    Get or create an object managed in this session
    :param work_name: create or get by work name only
    as you need
    :return: object which matches the input filter, or a new object with the
    **kwargs attributes
    """
    defaults = {"HOLLIS": '0'}
    o, newly_made = get_or_create(session, Works, defaults, WorkName=work_name)
    if newly_made:
        logging.debug(f"Newly made {o}")
    return o

def get_or_create_volume(session, work_name: str, volume_name: str):
    vol_work: Works = get_or_create_work(session, work_name)
    o, newly_made = get_or_create(session, Volumes, label=volume_name, work=vol_work)
    if newly_made:
        logging.debug(f"Newly made {o}")
    return o

def get_downloads(session):
    """
    Gets all the downloads
    """
    statement = select(GbDownload).order_by(GbDownload.download_time)
    return session.execute(statement).fetchall()

def remove_volumes(session, labels: list[str]):
    """
    Removes a list of volumes identified by their label
    !! Don't use in productionDon't generally use this!
    :param labels: list of volumes to remove
    :return:
    """
    vols2 = session.query(Volumes).filter(Volumes.label.in_(labels)).all()
    for vv in vols2:
        session.delete(vv)
    session.commit()

def remove_works(session, work_names: list[str]):
    """
    Removes a list of works identified by their WorkName.
    !! Don't use in production
    :param work_names:
    :return:
    """
    works = session.query(Works).filter(Works.WorkName.in_(work_names)).all()
    for w in works:
        session.delete(w)
    session.commit()

