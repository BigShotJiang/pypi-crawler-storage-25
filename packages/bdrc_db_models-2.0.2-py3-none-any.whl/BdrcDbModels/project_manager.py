from sqlalchemy import Column, text, ForeignKey, String, Integer
from sqlalchemy.dialects.mysql import LONGTEXT, TIMESTAMP
from sqlalchemy.orm import relationship
from .base import Base, IdTimestampMixin, TimestampMixin

class ProjectTypes(IdTimestampMixin, Base):
    """Types of projects, e.g. capture, digitization, distribution, analyis, etc."""
    __tablename__ = "pm_project_types"
    project_type_name = Column(String(45), nullable=False)
    project_type_desc = Column(LONGTEXT)
    project = relationship("Projects", back_populates="project_type")

    def __repr__(self):
        return f"<{self.id}: {self.project_type_name}>"


class Projects(IdTimestampMixin, Base):
    """Specific projects, e.g. Google books, DRS"""
    __tablename__ = "pm_projects"
    name = Column(String(45))
    description = Column(LONGTEXT)

    project_type_id = Column(Integer, ForeignKey('pm_project_types.id'))
    project_type = relationship("ProjectTypes", back_populates="project")

    m_type_id = Column(Integer, ForeignKey('pm_member_types.id'))
    m_type = relationship("MemberTypes", back_populates="project")

    member = relationship("ProjectMembers", back_populates="project")

    def __repr__(self):
        return f"<{self.id}: {self.name}-{self.project_type}-{self.m_type}>"


class MemberTypes(IdTimestampMixin, Base):
    """TUsusally, container level (work, volume).)"""
    __tablename__ = "pm_member_types"
    m_type = Column(String(45), nullable=False)
    project = relationship('Projects', back_populates='m_type')
    members = relationship("MemberTypes", back_populates="member_type")

    def __repr__(self):
        return f"<{self.id}: {self.m_type}>"


class MemberStates(IdTimestampMixin, Base):
    """States of project members (See States)"""
    __tablename__ = "pm_member_states"
    m_state_name = Column(String(45), nullable=False)
    m_state_desc = Column(LONGTEXT)

    project_member = relationship('ProjectMembers', back_populates="project_member_state")

    def __repr__(self):
        return f"<{self.id}: {self.m_state_name}>"


class ProjectMembers(TimestampMixin, Base):
    """An instance of a work or volume in a specific project"""
    __tablename__ = "pm_project_members"
    pm_id = Column(Integer, primary_key=True, autoincrement=True)
    pm_type = Column(Integer, ForeignKey('pm_member_types.id'))

    pm_work_id = Column(Integer, ForeignKey('Works.workId'))
    pm_volume_id = Column(Integer, ForeignKey('Volumes.volumeId'))
    
    pm_project = Column(Integer, ForeignKey('pm_projects.id'))
    project = relationship("Projects", back_populates="member")

    pm_project_state_id = Column(Integer, ForeignKey('pm_member_states.id'))

    member_type = relationship("MemberTypes", back_populates="members")
    project_member_state = relationship('MemberStates', back_populates="project_member")

    def __repr__(self):
        return f"<{self.pm_id}: {self.project} {self.member_type}>"

class Steps(IdTimestampMixin, Base):
    """All possible steps."""
    __tablename__ = "pm_steps"
    s_name = Column(String(45), nullable=False)
    s_desc = Column(LONGTEXT)


class ProjectSteps(IdTimestampMixin, Base):
    "A Step instance in a specific project"""
    __tablename__ = "pm_project_steps"
    ps_project = Column(ForeignKey('pm_projects.id'))
    ps_step = Column(ForeignKey('pm_steps.id'))
    project = relationship("Projects", back_populates="member")
    step = relationship("Steps")


class ProjectMemberSteps(TimestampMixin, Base):
    """Lookup table to track steps completed for project members"""
    __tablename__ = "pm_project_member_steps"
    project_member_id = Column(ForeignKey('pm_project_members.pm_id'), primary_key=True)
    project_step_id = Column(ForeignKey("pm_project_steps.id"), primary_key=True)
    project_step_time = Column(TIMESTAMP, nullable=False, server_default=text('CURRENT_TIMESTAMP'))
