import sqlalchemy
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, text
from sqlalchemy.dialects.mysql import TIMESTAMP

Base = declarative_base()

class IdMixin:
    """
    Provides generic id in primary key
    """
    id = Column(Integer, primary_key=True, autoincrement=True)

class TimestampMixin:
    """
    Injects created and update times
    """
    create_time = Column(TIMESTAMP, nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    update_time = Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'))

class IdTimestampMixin(IdMixin, TimestampMixin):
    """
    Provides generic id and create+update time columns
    """
    pass
