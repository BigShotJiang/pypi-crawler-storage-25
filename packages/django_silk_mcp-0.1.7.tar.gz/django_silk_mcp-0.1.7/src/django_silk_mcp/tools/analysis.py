from collections import defaultdict

from mcp.types import ToolAnnotations
from mcp_server.djangomcp import DjangoMCP
from silk.models import SQLQuery as SilkSQLQuery

from django_silk_mcp.helpers import (
    _check_request_id,
    _filter_project_frames,
    _mcp_error,
    _normalize_query,
    _req_db_ms,
    _resolve_request,
    _to_mcp_result,
)
from django_silk_mcp.types import (
    DuplicateQueryGroup,
    QuerySource,
    RequestQueriesResult,
    TimeBreakdownResult,
)

_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, idempotentHint=False)


def register(mcp: DjangoMCP) -> None:
    @mcp.tool(title="Request Time Breakdown (DB vs Python)", annotations=_ANNOTATIONS)
    def get_request_time_breakdown(
        request_path: str = "", request_id: str = ""
    ) -> TimeBreakdownResult:
        """
        Break down the latest request to request_path into DB time vs Python time.
        Determines whether query optimization will have high impact before diving deeper.

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        if err := _check_request_id(request_id):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        total = float(req.time_taken or 0)
        db = _req_db_ms(req)
        python = total - db
        db_pct = round((db / total * 100) if total else 0, 1)
        python_pct = round((python / total * 100) if total else 0, 1)

        return _to_mcp_result(
            {
                "path": req.path,
                "method": req.method,
                "total_ms": round(total, 2),
                "db_ms": round(db, 2),
                "db_pct": db_pct,
                "python_ms": round(python, 2),
                "python_pct": python_pct,
                "num_queries": req.num_sql_queries,
                "verdict": (
                    "DB-bound — query optimization will have high impact"
                    if db_pct >= 60
                    else "Python-bound — query optimization may have limited impact"
                ),
            }
        )

    @mcp.tool(title="Duplicate Queries (N+1 Detection)", annotations=_ANNOTATIONS)
    def get_duplicate_queries(
        request_path: str = "", request_id: str = ""
    ) -> list[DuplicateQueryGroup]:
        """
        Detect N+1 patterns for the latest request to request_path.
        Groups structurally identical queries (same template, different params).

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        if err := _check_request_id(request_id):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        queries = SilkSQLQuery.objects.filter(request=req)
        groups: dict[str, list] = defaultdict(list)
        for q in queries:
            groups[_normalize_query(q.query)].append(
                {"time_ms": round(float(q.time_taken), 2), "sql": q.query}
            )

        duplicates = {k: v for k, v in groups.items() if len(v) > 1}
        if not duplicates:
            return _mcp_error(
                f"No duplicate queries detected for '{request_path}'. No N+1 pattern found."
            )

        result = sorted(
            [
                {
                    "occurrences": len(instances),
                    "total_ms": round(sum(i["time_ms"] for i in instances), 2),
                    "query_template": template,
                    "examples": instances[:3],
                }
                for template, instances in duplicates.items()
            ],
            key=lambda x: -x["occurrences"],
        )
        return _to_mcp_result(result)

    @mcp.tool(title="All SQL Queries for a Request", annotations=_ANNOTATIONS)
    def get_request_queries(
        request_path: str = "", request_id: str = "", summary_only: bool = False
    ) -> RequestQueriesResult:
        """
        Return all SQL queries fired during the latest request to request_path.
        Use summary_only=True to get just timing and a truncated SQL preview per query,
        avoiding large responses when there are many or complex queries.

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        if err := _check_request_id(request_id):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        queries = SilkSQLQuery.objects.filter(request=req).order_by("start_time")
        if summary_only:
            query_list = [
                {
                    "time_ms": round(float(q.time_taken), 2),
                    "sql_preview": q.query[:120] + ("..." if len(q.query) > 120 else ""),
                }
                for q in queries
            ]
        else:
            query_list = [
                {"time_ms": round(float(q.time_taken), 2), "sql": q.query} for q in queries
            ]

        return _to_mcp_result(
            {
                "path": req.path,
                "method": req.method,
                "total_ms": round(float(req.time_taken or 0), 2),
                "db_ms": round(_req_db_ms(req), 2),
                "num_queries": req.num_sql_queries,
                "queries": query_list,
            }
        )

    @mcp.tool(title="Query Source Code Locations", annotations=_ANNOTATIONS)
    def get_query_sources(
        request_path: str = "", request_id: str = "", table_filter: str = ""
    ) -> list[QuerySource]:
        """
        Show which project code lines triggered each SQL query for the latest request.
        Strips Django/library internals — shows only your code's stack frames.
        Use this to know exactly which line to add select_related/prefetch_related.

        Args:
            request_path: The endpoint path to analyze.
            request_id: Pin analysis to a specific request ID
                        (from get_slow_requests/compare_requests)
                        instead of the most recent one matching request_path.
            table_filter: Optional table name substring to filter queries (e.g. "auth_user").
                          When provided, only queries whose SQL contains this string are shown.
        """
        if err := _check_request_id(request_id):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        queries = SilkSQLQuery.objects.filter(request=req).order_by("start_time")
        rows = []
        for q in queries:
            if table_filter and table_filter.lower() not in q.query.lower():
                continue
            frames = _filter_project_frames(q.traceback or "")
            rows.append(
                {
                    "time_ms": round(float(q.time_taken), 2),
                    "sql_preview": q.query[:120] + ("..." if len(q.query) > 120 else ""),
                    "project_frames": frames
                    or ["(no project frames — triggered by Django internals)"],
                }
            )
        return _to_mcp_result(rows)
