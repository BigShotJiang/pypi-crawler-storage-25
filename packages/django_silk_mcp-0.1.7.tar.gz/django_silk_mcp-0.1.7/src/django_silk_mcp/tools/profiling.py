from mcp.types import ToolAnnotations
from mcp_server.djangomcp import DjangoMCP
from silk.models import Profile as SilkProfile

from django_silk_mcp.helpers import (
    _check_limit,
    _check_request_id,
    _mcp_error,
    _resolve_request,
    _to_mcp_result,
)
from django_silk_mcp.types import CProfileHotspotsResult, PythonProfilesResult

_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, idempotentHint=False)


def register(mcp: DjangoMCP) -> None:
    @mcp.tool(title="Python Profile Block Timings", annotations=_ANNOTATIONS)
    def get_python_profiles(request_path: str = "", request_id: str = "") -> PythonProfilesResult:
        """
        Show @silk_profile decorated function timings for the latest request.
        Requires endpoints or functions to be decorated with @silk_profile.
        Each block shows total time, DB time, pure-Python time, and query count —
        making it easy to spot Python-bound bottlenecks that SQL optimization won't fix.

        Pass request_id (from get_slow_requests/compare_requests) to pin analysis to a
        specific request instead of the most recent one matching request_path.
        """
        if err := _check_request_id(request_id):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        profiles = (
            SilkProfile.objects.filter(request=req)
            .prefetch_related("queries")
            .order_by("-time_taken")
        )
        if not profiles:
            return _mcp_error(
                f"No @silk_profile blocks recorded for '{request_path}'. "
                "Add @silk_profile to the functions you want to profile, then re-hit the endpoint."
            )

        rows = []
        for p in profiles:
            sql_time = sum(float(q.time_taken) for q in p.queries.all())
            time_ms = float(p.time_taken or 0)
            rows.append(
                {
                    "name": p.name,
                    "func_name": p.func_name,
                    "file_path": p.file_path,
                    "line_num": p.line_num,
                    "time_ms": round(time_ms, 2),
                    "db_ms": round(sql_time, 2),
                    "python_ms": round(time_ms - sql_time, 2),
                    "num_queries": p.queries.count(),
                    "exception_raised": p.exception_raised,
                }
            )

        return _to_mcp_result(
            {
                "path": req.path,
                "profile_blocks": rows,
                "tip": (
                    "Blocks with high python_ms and low db_ms are pure-Python bottlenecks "
                    "— query optimisation won't help there."
                ),
            }
        )

    @mcp.tool(title="cProfile Function Hotspots", annotations=_ANNOTATIONS)
    def get_cprofile_hotspots(
        request_path: str = "",
        request_id: str = "",
        top_n: int = 20,
        project_only: bool = True,
    ) -> CProfileHotspotsResult:
        """
        Parse cProfile data stored on the latest request and rank Python functions by
        cumulative time (cumtime). Requires SILKY_PYTHON_PROFILER=True in settings.

        Args:
            request_path: The endpoint path to analyze.
            request_id: Pin analysis to a specific request ID
                        (from get_slow_requests/compare_requests)
                        instead of the most recent one matching request_path.
            top_n: Number of top functions to return (default 20).
            project_only: Strip site-packages / stdlib frames and show only project code
                          (default True). Set False to see the full call tree.
        """
        if err := _check_request_id(request_id):
            return err
        if err := _check_limit("top_n", top_n):
            return err
        req = _resolve_request(request_path, request_id)
        if not req:
            return _mcp_error(
                f"No recorded requests matching '{request_path}'. Hit the endpoint first."
            )

        if not req.pyprofile:
            return _mcp_error(
                f"No cProfile data for '{request_path}'. "
                "Set SILKY_PYTHON_PROFILER=True in settings and re-hit the endpoint."
            )

        # cProfile text format: ncalls  tottime  percall  cumtime  percall  filename:lineno(func)
        rows = []
        in_table = False
        for line in req.pyprofile.splitlines():
            line = line.strip()
            if line.startswith("ncalls"):
                in_table = True
                continue
            if not in_table or not line:
                continue
            parts = line.split(None, 5)
            if len(parts) < 6:
                continue
            try:
                location = parts[5].strip()
                if project_only and any(
                    token in location
                    for token in ("site-packages", "/lib/python", "{built-in", "{method")
                ):
                    continue
                rows.append(
                    {
                        "ncalls": parts[0],
                        "tottime_s": round(float(parts[1]), 6),
                        "cumtime_s": round(float(parts[3]), 6),
                        "location": location,
                    }
                )
            except (ValueError, IndexError):
                continue

        rows.sort(key=lambda x: -x["cumtime_s"])
        rows = rows[:top_n]

        if not rows:
            filter_note = (
                " (try project_only=False to include stdlib/packages)" if project_only else ""
            )
            return _mcp_error(
                f"No functions found in cProfile data for '{request_path}'{filter_note}."
            )

        return _to_mcp_result(
            {
                "path": req.path,
                "top_functions_by_cumtime": rows,
                "note": (
                    "cumtime_s = total time in this function including all callees. "
                    "High cumtime with low tottime means the cost is in sub-calls."
                ),
            }
        )
