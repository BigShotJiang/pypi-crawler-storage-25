from django.db.models import Avg, Count, F
from mcp.types import ToolAnnotations
from mcp_server.djangomcp import DjangoMCP
from silk.models import Request as SilkRequest
from silk.models import SQLQuery as SilkSQLQuery

from django_silk_mcp.helpers import (
    _check_limit,
    _check_threshold_ms,
    _db_time_subquery,
    _mcp_error,
    _to_mcp_result,
)
from django_silk_mcp.types import (
    CompareRequestsResult,
    EndpointStats,
    SlowQuery,
    SlowRequest,
)

_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, idempotentHint=False)


def register(mcp: DjangoMCP) -> None:
    @mcp.tool(title="Slowest Endpoints by DB Time", annotations=_ANNOTATIONS)
    def get_most_expensive_endpoints(limit: int = 10) -> list[EndpointStats]:
        """
        Rank all recorded endpoints by average DB time.
        Use this first to decide which endpoint to investigate.
        """
        if err := _check_limit("limit", limit):
            return err
        qs = (
            SilkRequest.objects.annotate(db_time=_db_time_subquery())
            .values("path", "method")
            .annotate(
                avg_total_ms=Avg("time_taken"),
                avg_db_ms=Avg("db_time"),
                avg_queries=Avg("num_sql_queries"),
                request_count=Count("id"),
            )
            .order_by(F("avg_db_ms").desc(nulls_last=True))[:limit]
        )
        if not qs:
            return _mcp_error(
                "No requests recorded yet. Hit some endpoints through the dev server first."
            )

        rows = [
            {
                "path": r["path"],
                "method": r["method"],
                "avg_total_ms": round(r["avg_total_ms"] or 0, 2),
                "avg_db_ms": round(r["avg_db_ms"] or 0, 2),
                "avg_python_ms": round((r["avg_total_ms"] or 0) - (r["avg_db_ms"] or 0), 2),
                "avg_query_count": round(r["avg_queries"] or 0, 1),
                "request_count": r["request_count"],
            }
            for r in qs
        ]
        return _to_mcp_result(rows)

    @mcp.tool(title="Slowest SQL Queries", annotations=_ANNOTATIONS)
    def get_slow_queries(threshold_ms: float = 100.0, limit: int = 20) -> list[SlowQuery]:
        """Return the slowest individual SQL queries across all recorded requests."""
        if err := _check_threshold_ms(threshold_ms):
            return err
        if err := _check_limit("limit", limit):
            return err
        qs = (
            SilkSQLQuery.objects.filter(time_taken__gte=threshold_ms)
            .select_related("request")
            .order_by("-time_taken")[:limit]
        )
        if not qs:
            return _mcp_error(f"No queries slower than {threshold_ms}ms found.")

        rows = [
            {
                "request_id": str(q.request.id) if q.request else None,
                "time_ms": round(float(q.time_taken), 2),
                "request_path": q.request.path if q.request else None,
                "request_method": q.request.method if q.request else None,
                "sql": q.query,
            }
            for q in qs
        ]
        return _to_mcp_result(rows)

    @mcp.tool(title="Slowest HTTP Requests", annotations=_ANNOTATIONS)
    def get_slow_requests(threshold_ms: float = 500.0, limit: int = 20) -> list[SlowRequest]:
        """Return HTTP requests with total time above threshold_ms, worst first."""
        if err := _check_threshold_ms(threshold_ms):
            return err
        if err := _check_limit("limit", limit):
            return err
        qs = (
            SilkRequest.objects.filter(time_taken__gte=threshold_ms)
            .annotate(db_time=_db_time_subquery())
            .order_by("-time_taken")[:limit]
        )
        if not qs:
            return _mcp_error(f"No requests slower than {threshold_ms}ms found.")

        rows = [
            {
                "request_id": str(r.id),
                "path": r.path,
                "method": r.method,
                "total_ms": round(float(r.time_taken or 0)),
                "db_ms": round(float(r.db_time or 0)),
                "python_ms": round(float(r.time_taken or 0) - float(r.db_time or 0)),
                "num_queries": r.num_sql_queries,
                "start_time": str(r.start_time),
            }
            for r in qs
        ]
        return _to_mcp_result(rows)

    @mcp.tool(title="Compare Requests Before/After", annotations=_ANNOTATIONS)
    def compare_requests(request_path: str, limit: int = 5) -> CompareRequestsResult:
        """
        Show the last N *distinct* requests to request_path with timing and query counts.
        Use this after applying an optimization to confirm it actually improved performance.

        Near-simultaneous requests (within 2 seconds of each other) are deduplicated: only
        the slowest one per burst is kept. This filters out cache-warmed follow-up hits
        that fire milliseconds after the real request and would otherwise look like a speedup.
        """
        if err := _check_limit("limit", limit):
            return err
        # Fetch more than `limit` so deduplication still yields enough rows.
        candidates = (
            SilkRequest.objects.filter(path__contains=request_path)
            .annotate(db_time=_db_time_subquery())
            .order_by("-start_time")[: limit * 6]
        )
        if not candidates:
            return _mcp_error(f"No recorded requests matching '{request_path}'.")

        # Deduplicate: walk newest-first and skip any request whose start_time falls
        # within 2 seconds of an already-kept request (keeping the slowest in the burst).
        kept = []
        for r in candidates:
            burst_match = next(
                (k for k in kept if abs((r.start_time - k.start_time).total_seconds()) < 2.0),
                None,
            )
            if burst_match is None:
                kept.append(r)
            elif float(r.time_taken or 0) > float(burst_match.time_taken or 0):
                kept[kept.index(burst_match)] = r
            if len(kept) >= limit:
                break

        kept.sort(key=lambda r: r.start_time, reverse=True)

        rows = [
            {
                "request_id": str(r.id),
                "start_time": str(r.start_time),
                "method": r.method,
                "total_ms": round(float(r.time_taken or 0), 2),
                "db_ms": round(float(r.db_time or 0), 2),
                "python_ms": round(float(r.time_taken or 0) - float(r.db_time or 0), 2),
                "num_queries": r.num_sql_queries,
            }
            for r in kept
        ]
        return _to_mcp_result(
            {
                "path": request_path,
                "requests_newest_first": rows,
                "note": (
                    "Near-simultaneous requests (<2 s apart) are deduplicated — "
                    "only the slowest per burst is shown to avoid mistaking a cache-warmed "
                    "follow-up hit for an optimized request."
                ),
                "tip": "Hit the endpoint again after your fix, then re-run this tool to compare.",
            }
        )
