import os
from setuptools import setup, find_packages

# Safely read the README for the PyPI homepage
long_desc = "Deterministic AST static analysis boundaries for LLM code execution."
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as f:
        long_desc = f.read()

setup(
    name="varek-guardrails",
    version="0.1.0",
    author="VAREK Security Command",
    description="Deterministic AST static analysis boundaries for LLM code execution.",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    url="https://github.com/kwdoug63/varek",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Security",
    ],
    python_requires='>=3.8',
)
