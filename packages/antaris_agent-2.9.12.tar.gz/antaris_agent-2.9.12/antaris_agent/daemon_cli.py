from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from antaris_agent._version import __version__ as VERSION


DEFAULT_CONFIG_ROOT = Path.home() / ".antaris"
REGISTRY_PATH = DEFAULT_CONFIG_ROOT / ".instances.json"


@dataclass(frozen=True)
class AgentTarget:
    agent: str
    config_dir: Path
    pid_file: Path
    log_file: Path
    socket_file: Path


def _load_registry() -> dict[str, str]:
    if not REGISTRY_PATH.exists():
        return {}
    try:
        data = json.loads(REGISTRY_PATH.read_text())
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except Exception:
        pass
    return {}


def _default_config_dir() -> Path:
    env_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()
    return DEFAULT_CONFIG_ROOT


def resolve_agent_target(agent: str | None = None, config_dir: str | Path | None = None) -> AgentTarget:
    if config_dir is not None:
        resolved = Path(config_dir).expanduser().resolve()
        agent_name = agent or resolved.name or "default"
    elif agent and agent != "default":
        registry = _load_registry()
        config_path = registry.get(agent)
        if not config_path:
            raise ValueError(f"Agent '{agent}' not found. Run 'antaris init --name {agent}' first.")
        resolved = Path(config_path).expanduser().resolve()
        agent_name = agent
    else:
        resolved = _default_config_dir()
        agent_name = agent or "default"

    return AgentTarget(
        agent=agent_name,
        config_dir=resolved,
        pid_file=resolved / "bot.pid",
        log_file=resolved / "logs" / "antarisd.log",
        socket_file=resolved / "antarisd.sock",
    )


def _read_pid(pid_file: Path) -> int | None:
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text().strip())
    except Exception:
        return None


def _is_pid_alive(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _status_for_target(target: AgentTarget) -> tuple[str, int | None]:
    pid = _read_pid(target.pid_file)
    if pid and _is_pid_alive(pid):
        return "running", pid
    return "stopped", pid


def _require_antaris_executable() -> str:
    antaris_bin = shutil.which("antaris")
    if antaris_bin:
        return antaris_bin
    return sys.executable


def _run_command_for_target(target: AgentTarget) -> list[str]:
    antaris_bin = _require_antaris_executable()
    if antaris_bin == sys.executable:
        return [sys.executable, "-m", "antaris_agent.cli", "start", "--foreground"]
    return [antaris_bin, "start", "--foreground"]


def _quote_cmd(parts: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def render_systemd_unit(target: AgentTarget, daemon_bin: str) -> str:
    run_cmd = _quote_cmd([daemon_bin, "run", target.agent])
    return f"""[Unit]
Description=Antaris Agent daemon ({target.agent})
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=ANTARIS_CONFIG_DIR={target.config_dir}
ExecStart={run_cmd}
Restart=always
RestartSec=5
StandardOutput=append:{target.log_file}
StandardError=append:{target.log_file}

[Install]
WantedBy=multi-user.target
"""


def render_launchd_plist(target: AgentTarget, daemon_bin: str, label: str) -> str:
    return f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">
<plist version=\"1.0\">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{daemon_bin}</string>
        <string>run</string>
        <string>{target.agent}</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>ANTARIS_CONFIG_DIR</key>
        <string>{target.config_dir}</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{target.log_file}</string>
    <key>StandardErrorPath</key>
    <string>{target.log_file}</string>
</dict>
</plist>
"""


def _service_name_for(target: AgentTarget) -> str:
    return f"antarisd-{target.agent}"


def _service_label_for(target: AgentTarget) -> str:
    return f"ai.antarisanalytics.antarisd.{target.agent}"


def _check_token_lock(target: AgentTarget) -> bool:
    """Check token lock before launch. Returns True if safe to proceed."""
    try:
        from antaris_agent.daemon_lock import acquire_token_lock, release_token_lock
        from antaris_agent.core.config import Config
        config_path = target.config_dir / "config.json"
        cfg = Config.load(str(config_path))
        token = getattr(cfg, "discord_token", None) if cfg else None
        if not token:
            return True  # No token configured — skip lock
        ok, msg = acquire_token_lock(token, target.config_dir, agent_name=target.agent)
        if not ok:
            print(f"🚫 {msg}")
            return False
        import atexit
        atexit.register(release_token_lock, token, target.config_dir)
        return True
    except Exception as e:
        print(f"⚠️  Token lock check failed: {e} — proceeding anyway")
        return True


def _cmd_run(target: AgentTarget) -> int:
    if not _check_token_lock(target):
        return 1
    os.environ["ANTARIS_CONFIG_DIR"] = str(target.config_dir)
    # Signal the child (antaris start --foreground) to skip its own token lock
    # acquisition — we already hold it. Without this, the child sees our lock
    # and exits with "Token collision" against its own parent process.
    os.environ["ANTARIS_DAEMON_LOCK_PID"] = str(os.getpid())
    cmd = _run_command_for_target(target)
    result = subprocess.run(cmd)
    return result.returncode


def _cmd_start(target: AgentTarget) -> int:
    status, pid = _status_for_target(target)
    if status == "running":
        print(f"✅ Agent '{target.agent}' already running (PID {pid})")
        return 0

    # NOTE: Do NOT acquire token lock here — the child process (antarisd run)
    # will acquire it. If we acquire here, the child sees our lock and refuses
    # to start (parent PID still alive during child startup = false collision).

    target.log_file.parent.mkdir(parents=True, exist_ok=True)
    log_handle = open(target.log_file, "a", encoding="utf-8")
    env = os.environ.copy()
    env["ANTARIS_CONFIG_DIR"] = str(target.config_dir)

    daemon_bin = shutil.which("antarisd") or sys.executable
    if daemon_bin == sys.executable:
        cmd = [sys.executable, "-m", "antaris_agent.daemon_cli", "run", target.agent]
    else:
        cmd = [daemon_bin, "run", target.agent]

    try:
        proc = subprocess.Popen(
            cmd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log_handle.close()

    time.sleep(0.2)
    print(f"✅ Starting agent '{target.agent}' (launcher PID {proc.pid})")
    print(f"   Config: {target.config_dir}")
    print(f"   Logs:   {target.log_file}")
    return 0


def _cmd_stop(target: AgentTarget) -> int:
    pid = _read_pid(target.pid_file)
    if not pid:
        print(f"❌ Agent '{target.agent}' is not running.")
        return 1
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        print(f"⚠️  PID {pid} not found for agent '{target.agent}'. Cleaning stale pid file.")
        target.pid_file.unlink(missing_ok=True)
        return 1
    except PermissionError:
        print(f"❌ Permission denied stopping agent '{target.agent}' (PID {pid}).")
        return 1

    print(f"🛑 Stopped agent '{target.agent}' (PID {pid})")
    return 0


def _cmd_status(target: AgentTarget) -> int:
    status, pid = _status_for_target(target)
    print(f"Agent:   {target.agent}")
    print(f"Status:  {status}")
    print(f"PID:     {pid if pid else '-'}")
    print(f"Config:  {target.config_dir}")
    print(f"Logs:    {target.log_file}")
    print(f"Socket:  {target.socket_file}")
    return 0 if status == "running" else 1


def _cmd_restart(target: AgentTarget) -> int:
    _cmd_stop(target)
    # Poll for PID death with timeout instead of a fixed sleep.
    # 200ms was not enough for slow shutdowns — the old process could still
    # hold the lock when _cmd_start ran, causing a false "Token collision".
    for _ in range(50):  # 5 seconds max (50 × 100ms)
        time.sleep(0.1)
        status, _pid = _status_for_target(target)
        if status != "running":
            break
    return _cmd_start(target)


def _cmd_install_service(target: AgentTarget) -> int:
    import platform

    daemon_bin = shutil.which("antarisd") or sys.executable
    system = platform.system()
    service_name = _service_name_for(target)
    service_label = _service_label_for(target)
    target.log_file.parent.mkdir(parents=True, exist_ok=True)

    if system == "Linux":
        unit_path = Path("/etc/systemd/system") / f"{service_name}.service"
        unit_path.write_text(render_systemd_unit(target, daemon_bin))
        subprocess.run(["systemctl", "daemon-reload"], check=True)
        subprocess.run(["systemctl", "enable", service_name], check=True)
        subprocess.run(["systemctl", "start", service_name], check=True)
        print(f"✅ Installed systemd service {service_name} for agent '{target.agent}'")
        return 0

    if system == "Darwin":
        plist_dir = Path.home() / "Library" / "LaunchAgents"
        plist_dir.mkdir(parents=True, exist_ok=True)
        plist_path = plist_dir / f"{service_label}.plist"
        plist_path.write_text(render_launchd_plist(target, daemon_bin, service_label))
        subprocess.run(["launchctl", "load", "-w", str(plist_path)], check=True)
        print(f"✅ Installed launchd service {service_label} for agent '{target.agent}'")
        return 0

    print(f"❌ Unsupported platform for service install: {system}")
    return 1


def _cmd_uninstall_service(target: AgentTarget) -> int:
    import platform

    system = platform.system()
    service_name = _service_name_for(target)
    service_label = _service_label_for(target)

    if system == "Linux":
        unit_path = Path("/etc/systemd/system") / f"{service_name}.service"
        subprocess.run(["systemctl", "stop", service_name], check=False)
        subprocess.run(["systemctl", "disable", service_name], check=False)
        unit_path.unlink(missing_ok=True)
        subprocess.run(["systemctl", "daemon-reload"], check=False)
        print(f"✅ Removed systemd service {service_name} for agent '{target.agent}'")
        return 0

    if system == "Darwin":
        plist_path = Path.home() / "Library" / "LaunchAgents" / f"{service_label}.plist"
        subprocess.run(["launchctl", "unload", "-w", str(plist_path)], check=False)
        plist_path.unlink(missing_ok=True)
        print(f"✅ Removed launchd service {service_label} for agent '{target.agent}'")
        return 0

    print(f"❌ Unsupported platform for service uninstall: {system}")
    return 1


def _cmd_fleet() -> int:
    """Show status of all known agent instances (via token locks + registry)."""
    import json as _json
    from antaris_agent.daemon_lock import fleet_status

    # Gather known config dirs from the instance registry so fleet_status can
    # enrich global registry entries with per-agent metadata.
    _reg_path = Path.home() / ".antaris" / ".instances.json"
    _known_config_dirs: list[Path] = [Path.home() / ".antaris"]  # always include default
    try:
        if _reg_path.exists():
            _reg = _json.loads(_reg_path.read_text())
            _known_config_dirs.extend(Path(p) for p in _reg.values())
    except Exception:
        pass

    instances = fleet_status(config_dirs=_known_config_dirs)

    if not instances:
        print("No agent locks found. Either no agents have been started, or all locks were cleaned up.")
        return 0

    print(f"{'Agent':<20} {'PID':>7} {'Status':<10} {'Host':<20} {'Config'}")
    print("-" * 90)
    for inst in instances:
        status = "🟢 alive" if inst["alive"] else "⚪ dead"
        age = inst["lock_age_seconds"]
        if age > 300 and not inst["alive"]:
            status = "💀 stale"
        print(
            f"{inst['agent']:<20} {inst['pid']:>7} {status:<10} "
            f"{inst['hostname']:<20} {inst['config_dir']}"
        )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="antarisd",
        description="Antaris daemon/service CLI (per-agent lifecycle control)",
    )
    parser.add_argument("--version", action="version", version=f"antarisd {VERSION}")
    parser.add_argument("--config-dir", default=None, metavar="DIR", help="Override config directory for this agent daemon")

    subparsers = parser.add_subparsers(dest="command", required=True)

    for cmd in ("start", "stop", "status", "restart", "run",
                 "install-service", "uninstall-service",
                 "install", "uninstall"):
        sub = subparsers.add_parser(cmd)
        sub.add_argument("agent", nargs="?", default="default", help="Agent/body name (default: default)")

    # Fleet doesn't need an agent argument
    subparsers.add_parser("fleet", help="Show all known agent instances and their status")

    return parser


def main() -> None:
    # ── Name-first syntax: `antarisd <name> <command>` → `antarisd <command> <name>` ──
    _KNOWN_COMMANDS = {
        "start", "stop", "status", "restart", "run",
        "install-service", "uninstall-service", "fleet", "install", "uninstall",
    }
    if len(sys.argv) >= 3:
        _first, _second = sys.argv[1], sys.argv[2]
        if (_first not in _KNOWN_COMMANDS
                and not _first.startswith("-")
                and _second in _KNOWN_COMMANDS):
            sys.argv[1], sys.argv[2] = _second, _first

    parser = build_parser()
    args = parser.parse_args()

    command = args.command

    # Fleet is a global command — no agent target needed
    if command == "fleet":
        sys.exit(_cmd_fleet())

    try:
        target = resolve_agent_target(getattr(args, "agent", None), getattr(args, "config_dir", None))
    except ValueError as exc:
        print(f"❌ {exc}")
        sys.exit(1)

    if command == "run":
        rc = _cmd_run(target)
    elif command == "start":
        rc = _cmd_start(target)
    elif command == "stop":
        rc = _cmd_stop(target)
    elif command == "status":
        rc = _cmd_status(target)
    elif command == "restart":
        rc = _cmd_restart(target)
    elif command in ("install-service", "install"):
        rc = _cmd_install_service(target)
    elif command in ("uninstall-service", "uninstall"):
        rc = _cmd_uninstall_service(target)
    else:
        parser.error(f"Unknown command: {command}")
        return

    sys.exit(rc)


if __name__ == "__main__":
    main()
