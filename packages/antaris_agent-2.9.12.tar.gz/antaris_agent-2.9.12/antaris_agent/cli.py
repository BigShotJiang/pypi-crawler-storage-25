import argparse
import json
import os
import shlex
import signal
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from antaris_agent._version import __version__ as VERSION


def _sigterm_handler(signum, frame):
    """Explicit SIGTERM handler — ensures cleanup runs even if BaseException is caught."""
    _clear_pid()
    # Best-effort: release token lock if we know which token is active.
    _token = os.environ.get("_ANTARIS_ACTIVE_TOKEN")
    _cfg_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if _token and _cfg_dir:
        try:
            from antaris_agent.daemon_lock import release_token_lock
            release_token_lock(_token, _cfg_dir)
        except Exception:
            pass
    sys.exit(0)


def _resolve_config_dir() -> Path:
    """Resolve the config directory, honoring ANTARIS_CONFIG_DIR or ANTARISBOT_CONFIG env vars."""
    env_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()
    # v2.9.7: also honor ANTARISBOT_CONFIG (path to config.json) — use its parent dir
    bot_cfg = os.environ.get("ANTARISBOT_CONFIG")
    if bot_cfg:
        return Path(bot_cfg).expanduser().resolve().parent
    return Path.home() / ".antaris"


PID_FILE = _resolve_config_dir() / "bot.pid"


# ── Instance registry helpers ─────────────────────────────────────────────────

def _load_registry() -> dict:
    """Returns {name: config_dir_path_str} from ~/.antaris/.instances.json."""
    reg_path = Path.home() / ".antaris" / ".instances.json"
    if not reg_path.exists():
        return {}
    try:
        return json.loads(reg_path.read_text())
    except Exception:
        return {}


def _save_registry(reg: dict):
    reg_path = Path.home() / ".antaris" / ".instances.json"
    reg_path.parent.mkdir(parents=True, exist_ok=True)
    reg_path.write_text(json.dumps(reg, indent=2))


def _resolve_named_instance(name: str) -> str | None:
    """Returns config dir path for named instance, or None if not found.
    
    v2.9.11: Also checks ~/.antaris-<name>/ convention before falling back
    to the instances registry. This supports the new agent-home-as-venv layout.
    """
    # Check new convention first: ~/.antaris-<name>/
    new_path = Path.home() / f".antaris-{name}"
    if new_path.exists() and (new_path / "config.json").exists():
        return str(new_path)
    
    # Fall back to registry
    reg = _load_registry()
    return reg.get(name)


def _is_instance_running(config_dir: str) -> tuple[bool, int | None]:
    """Checks if instance at config_dir is running. Returns (running, pid)."""
    pid_file = Path(config_dir) / "bot.pid"
    if not pid_file.exists():
        return False, None
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)
        return True, pid
    except (ValueError, OSError, ProcessLookupError):
        return False, None


def _is_valid_snowflake(value: str) -> bool:
    """Discord snowflake: 17-19 digit integer string."""
    return value.isdigit() and 17 <= len(value) <= 19


_ENRICHMENT_MODEL_OPTIONS = {
    "anthropic": [
        ("claude-haiku-3-5", "$", "cheap, fast, good summaries + tags", "$2 / 1K enrichments"),
        ("claude-sonnet-4-6", "$$", "higher quality, moderate cost", "$15 / 1K enrichments"),
        ("claude-opus-4-6", "$$$", "highest quality, verbose + expensive", "$75 / 1K enrichments"),
    ],
    "openai": [
        ("gpt-5.4-nano", "$", "very cheap, fast, strong default enrichment", "$1.25 / 1K enrichments"),
        ("gpt-5.4", "$$", "higher quality, higher cost", "$10 / 1K enrichments"),
        ("gpt-5.4-pro", "$$$", "premium quality, expensive", "$30 / 1K enrichments"),
    ],
    "openai-codex": [
        ("gpt-5.4-nano", "$", "very cheap, fast, strong default enrichment", "$1.25 / 1K enrichments"),
        ("gpt-5.4", "$$", "higher quality, higher cost", "$10 / 1K enrichments"),
        ("gpt-5.4-pro", "$$$", "premium quality, expensive", "$30 / 1K enrichments"),
    ],
    "google": [
        ("gemini-2.5-flash-lite", "$", "very cheap, fast, good bulk enrichment", "$1 / 1K enrichments"),
        ("gemini-2.5-flash", "$", "cheap, fast, balanced fallback", "$2 / 1K enrichments"),
        ("gemini-3.1-pro-preview", "$$", "higher quality, higher cost", "$10 / 1K enrichments"),
    ],
}


def _provider_label(name: str) -> str:
    return {
        "anthropic": "Anthropic",
        "openai": "OpenAI",
        "openai-codex": "OpenAI Codex",
        "google": "Google",
    }.get(name, name)


def _show_enrichment_status(cfg):
    info = cfg.resolve_enrichment_runtime()
    print("\nCurrent enrichment config")
    print(f"Enrichment enabled: {'yes' if info['enabled'] else 'no'}")
    print(f"Mode: {info['mode']}")
    if info["mode"] == "provider-default":
        for provider in ["anthropic", "openai", "openai-codex", "google"]:
            model = info["provider_defaults"].get(provider, "(unset)")
            print(f"{_provider_label(provider)} → {model}")
    else:
        print(f"Provider: {_provider_label(info['provider'])}")
        print(f"Model: {info['model'] or '(unset)'}")
    if info.get("provider"):
        print(f"Effective runtime: {_provider_label(info['provider'])} / {info.get('model')}")


def _prompt_choice(prompt: str, options: list[tuple[str, str, str, str]]):
    print(f"\n{prompt}")
    for i, (model, cost_band, desc, est) in enumerate(options, start=1):
        print(f"  {i}. {model} — {cost_band} — {desc} — approx {est}")
    while True:
        raw = input("Select option number: ").strip()
        try:
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1][0]
        except ValueError:
            pass
        print("Invalid selection.")


def _run_enrichment_config(cfg):
    available = cfg.available_enrichment_providers()
    if not available:
        print("No configured providers available for enrichment.")
        return
    raw = input("Should enrichment use the same provider as your current auth by default? [Y/n]: ").strip().lower() or "y"
    if raw in {"y", "yes"}:
        cfg.memory_enrich_mode = "provider-default"
        cfg.memory_enrich_provider = ""
        cfg.memory_enrich_model = ""
        defaults = dict(cfg.memory_enrich_provider_defaults or {})
        for provider in available:
            defaults[provider] = _prompt_choice(
                f"Select default enrichment model for {_provider_label(provider)}",
                _ENRICHMENT_MODEL_OPTIONS.get(provider, []),
            )
        cfg.memory_enrich_provider_defaults = defaults
    else:
        print("\nWhich provider should enrichment use?")
        for i, provider in enumerate(available, start=1):
            print(f"  {i}. {_provider_label(provider)}")
        while True:
            raw_provider = input("Select provider number: ").strip()
            try:
                idx = int(raw_provider)
                if 1 <= idx <= len(available):
                    provider = available[idx - 1]
                    break
            except ValueError:
                pass
            print("Invalid selection.")
        cfg.memory_enrich_mode = "fixed"
        cfg.memory_enrich_provider = provider
        cfg.memory_enrich_model = _prompt_choice(
            f"Select enrichment model for {_provider_label(provider)}",
            _ENRICHMENT_MODEL_OPTIONS.get(provider, []),
        )
    cfg.save()
    print("\n✅ Enrichment configuration saved.")
    _show_enrichment_status(cfg)

def _scan_running_antaris_processes() -> list[tuple[int, str]]:
    """Scan for ALL running antaris processes. Returns [(pid, cmdline), ...]."""
    import subprocess
    try:
        result = subprocess.run(
            ["pgrep", "-fl", "antaris.*start"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return []
        processes = []
        for line in result.stdout.strip().splitlines():
            parts = line.split(None, 1)
            if len(parts) == 2:
                try:
                    pid = int(parts[0])
                    cmdline = parts[1]
                    # Skip grep/pgrep itself
                    if "pgrep" not in cmdline and "grep" not in cmdline:
                        processes.append((pid, cmdline))
                except ValueError:
                    continue
        return processes
    except Exception:
        return []




def _auto_register_instance(config_dir: str):
    """Auto-register a config-dir instance in the registry if not already there."""
    resolved = str(Path(config_dir).resolve())
    default_dir = str((Path.home() / ".antaris").resolve())
    if resolved == default_dir:
        return  # Don't register the default instance

    reg = _load_registry()
    # Check if already registered
    for name, path in reg.items():
        if str(Path(path).resolve()) == resolved:
            return  # Already registered

    # Auto-name from directory
    auto_name = Path(config_dir).name.replace(".", "-").replace("~", "")
    if auto_name in reg:
        auto_name = f"{auto_name}-{len(reg)}"
    reg[auto_name] = resolved
    _save_registry(reg)




def _write_pid():
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))


def _read_pid() -> int | None:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def _clear_pid():
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _stop_bot() -> bool:
    """Send SIGTERM to the running bot. Returns True if stopped."""
    pid = _read_pid()
    if not pid:
        print("❌ No running bot found.")
        return False
    try:
        if sys.platform == "win32":
            # Windows: use taskkill for reliable process termination
            import subprocess
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                          capture_output=True, check=True)
        else:
            os.kill(pid, signal.SIGTERM)
        _clear_pid()
        print(f"🛑 Bot stopped (PID {pid})")
        return True
    except (ProcessLookupError, OSError):
        print(f"⚠️  PID {pid} not found — was the bot already stopped?")
        _clear_pid()
        return False
    except subprocess.CalledProcessError:
        print(f"⚠️  PID {pid} could not be stopped.")
        _clear_pid()
        return False
    except PermissionError:
        print(f"❌ Permission denied stopping PID {pid}")
        return False


def _cmd_install_service() -> int:
    """Install Parsica Agent as a system service for 24/7 operation."""
    import platform
    import shutil
    system = platform.system()
    antaris_bin = shutil.which("antaris") or sys.executable.replace("python", "antaris")

    if system == "Linux":
        unit = f"""[Unit]
Description=Parsica Agent
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={antaris_bin} start --foreground
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
"""
        service_path = Path("/etc/systemd/system/parsica-agent.service")
        try:
            service_path.write_text(unit)
        except PermissionError:
            print("❌ Permission denied — run with sudo:")
            print(f"   sudo {' '.join(sys.argv)}")
            return 1
        import subprocess
        subprocess.run(["systemctl", "daemon-reload"], check=True)
        subprocess.run(["systemctl", "enable", "parsica-agent"], check=True)
        subprocess.run(["systemctl", "start", "parsica-agent"], check=True)
        print("✅ Parsica Agent installed as systemd service.")
        print("   Status:  sudo systemctl status parsica-agent")
        print("   Logs:    sudo journalctl -u parsica-agent -f")
        print("   Stop:    sudo systemctl stop parsica-agent")
        print("   Disable: sudo systemctl disable parsica-agent")
        return 0

    elif system == "Darwin":
        plist_label = "ai.antarisanalytics.parsica-agent"
        log_dir = Path.home() / ".antaris" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{plist_label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{antaris_bin}</string>
        <string>start</string>
        <string>--foreground</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/antaris.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/antaris.log</string>
</dict>
</plist>
"""
        plist_dir = Path.home() / "Library" / "LaunchAgents"
        plist_dir.mkdir(parents=True, exist_ok=True)
        plist_path = plist_dir / f"{plist_label}.plist"
        plist_path.write_text(plist)
        import subprocess
        subprocess.run(["launchctl", "load", "-w", str(plist_path)], check=True)
        print("✅ Parsica Agent installed as launchd service.")
        print(f"   Logs:    tail -f {log_dir}/antaris.log")
        print(f"   Stop:    launchctl unload {plist_path}")
        print(f"   Remove:  antaris uninstall-service")
        return 0

    elif system == "Windows":
        print("⚠️  Windows service install is not yet supported.")
        print("   Workaround: add 'antaris start' to Task Scheduler → 'Run at logon'.")
        return 1

    else:
        print(f"❌ Unsupported platform: {system}")
        return 1


def _cmd_uninstall_service() -> int:
    """Remove the Parsica Agent system service."""
    import platform
    import subprocess
    system = platform.system()

    if system == "Linux":
        try:
            subprocess.run(["systemctl", "stop", "parsica-agent"], check=False)
            subprocess.run(["systemctl", "disable", "parsica-agent"], check=False)
            Path("/etc/systemd/system/parsica-agent.service").unlink(missing_ok=True)
            subprocess.run(["systemctl", "daemon-reload"], check=False)
            print("✅ parsica-agent systemd service removed.")
        except PermissionError:
            print("❌ Permission denied — run with sudo")
            return 1
        return 0

    elif system == "Darwin":
        plist_label = "ai.antarisanalytics.parsica-agent"
        plist_path = Path.home() / "Library" / "LaunchAgents" / f"{plist_label}.plist"
        if plist_path.exists():
            subprocess.run(["launchctl", "unload", "-w", str(plist_path)], check=False)
            plist_path.unlink()
            print("✅ parsica-agent launchd service removed.")
        else:
            print("⚠️  No service found to remove.")
        return 0

    else:
        print(f"❌ Unsupported platform: {system}")
        return 1


def _cmd_uninstall(remove_config: bool = False) -> int:
    """Uninstall antaris-agent from the current Python environment."""
    package = "antaris-agent"
    cmd = [sys.executable, "-m", "pip", "uninstall", "-y", package]
    print(f"🧹 Uninstalling {package}…")
    result = subprocess.run(cmd)
    if result.returncode == 0 and remove_config:
        config_dir = _resolve_config_dir()
        if config_dir.exists():
            import shutil
            shutil.rmtree(config_dir)
            print(f"🗑️  Removed config directory: {config_dir}")
    return result.returncode


def _cmd_reinstall() -> int:
    """Force-reinstall antaris-agent from PyPI."""
    package = "antaris-agent"
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--force-reinstall", package]
    print(f"🔄 Reinstalling {package} from PyPI…")
    result = subprocess.run(cmd)
    if result.returncode == 0:
        print("✅ Reinstall complete.")
        print("   Run `antaris init` or `antaris setup` next.")
    return result.returncode


def _cmd_security_status():
    """Print current security configuration."""
    from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris-agent init' first.")
        return
    security_mode = getattr(config, "security_mode", "sandboxed")
    guard_mode = getattr(config, "guard_mode", "monitor")

    mode_descriptions = {
        "open": "Open (0) — no restrictions, full access",
        "standard": "Standard (1) ★ — light safety net, workspace + home scoped (recommended)",
        "sandboxed": "Sandboxed (2) — filesystem restricted, subprocesses blocked",
        "secured": "Secured (3) — network allowlisted, destructive ops need approval",
        "encrypted": "Encrypted (4) — all tools need approval, owner-only memory, full audit",
        "locked": "Encrypted (4) — all tools need approval, owner-only memory, full audit",
    }

    print(f"\n🔐 Antaris Security Status")
    print(f"   Mode:         {mode_descriptions.get(security_mode, security_mode)}")
    print(f"   Guard:        {guard_mode}")
    print(f"   Memory store: {config.memory_store}")
    if security_mode == "locked":
        import os
        audit_path = os.path.expanduser("~/.antaris/audit.log")
        print(f"   Audit log:    {audit_path}")
        print(f"   Encryption:   Owner-only memory + audit enforcement (locked mode)")
    print(f"\n   CLI override: antaris-agent start --security {security_mode}")
    print()


def _cmd_tools(action: str):
    """Tool management commands — lightweight, no full Bot instantiation."""
    from antaris_agent.core.config import Config
    
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris init' first.")
        return
    
    tools_config = getattr(config, '_tools_config', {})
    
    if action == "list":
        print("\n🔧 Configured Tools\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            return
        
        # Show what WOULD be registered based on config (no Bot instantiation)
        tool_specs = {
            'brave_search': ('Web search via Brave Search API', lambda c: c.get('enabled') and c.get('apiKey')),
            'web_fetch': ('Fetch and extract readable content from URLs', lambda c: c.get('enabled', False)),
            'browser': ('Browser automation via Playwright', lambda c: c.get('enabled')),
            'file_ops': ('File read/write/edit operations', lambda c: c.get('enabled')),
            'shell': ('Execute shell commands', lambda c: c.get('enabled')),
            'video': ('Video understanding via ffmpeg/whisper + LLM summaries/Q&A', lambda c: c.get('enabled')),
        }
        
        registered = []
        for tool_name, (desc, check_fn) in tool_specs.items():
            tool_cfg = tools_config.get(tool_name, {})
            if check_fn(tool_cfg):
                registered.append((tool_name, desc))
        
        # Check MCP servers
        mcp_servers = tools_config.get('mcp_servers', [])
        
        if not registered and not mcp_servers:
            print("   No tools enabled")
        else:
            if registered:
                print(f"   Native tools ({len(registered)}):")
                for name, desc in registered:
                    print(f"     • {name} — {desc}")
            if mcp_servers:
                print(f"\n   MCP servers ({len(mcp_servers)}):")
                for server in mcp_servers:
                    transport = server.get('transport', 'stdio')
                    print(f"     • {server['name']} ({transport})")
        
    elif action == "status":
        print("\n🔧 Tool Configuration Status\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            print("\n   Add to config.json:")
            print('   "tools": {')
            print('     "brave_search": {"enabled": true, "apiKey": "your-key"},')
            print('     "web_fetch": {"enabled": true},')
            print('     "browser": {"enabled": false}')
            print('   }')
        else:
            for tool, config_data in tools_config.items():
                if tool == 'mcp_servers':
                    # Handle MCP servers list separately
                    print(f"   MCP servers: {len(config_data)} configured")
                    for server in config_data:
                        print(f"     • {server.get('name', 'unnamed')} ({server.get('transport', 'stdio')})")
                    continue
                enabled = config_data.get('enabled', False)
                status = "✅ enabled" if enabled else "⚪ disabled"
                if tool == 'brave_search':
                    has_key = bool(config_data.get('apiKey'))
                    if enabled and not has_key:
                        status = "❌ enabled but missing apiKey"
                print(f"     • {tool}: {status}")

def _cmd_doctor():
    """Run diagnostic checks and print honest status report."""
    import os
    import sys
    from pathlib import Path

    print("\n🩺 Antaris Agent Doctor\n")
    ok = True

    # --- Config ---
    from antaris_agent.core.config import Config, resolve_config_path
    config_path = resolve_config_path()
    cfg = Config.load(str(config_path))
    if cfg:
        print(f"  Config:           ✅ loaded from {config_path}")
    else:
        print(f"  Config:           ❌ not found — run 'antaris init'")
        ok = False

    # --- Provider ---
    if cfg:
        provider = cfg.provider_name or "unknown"
        model = cfg.model or "unknown"
        print(f"  Provider:         ✅ {provider} ({model})")
    else:
        print(f"  Provider:         ❌ no config loaded")
        ok = False

    # --- Memory store writable ---
    if cfg:
        store = Path(cfg.memory_store)
        if store.exists() and os.access(str(store), os.W_OK):
            print(f"  Memory store:     ✅ writable ({store})")
        elif store.exists():
            print(f"  Memory store:     ❌ not writable ({store})")
            ok = False
        else:
            # Directory doesn't exist yet — check if parent is writable
            parent = store.parent
            if parent.exists() and os.access(str(parent), os.W_OK):
                print(f"  Memory store:     ✅ will be created ({store})")
            else:
                print(f"  Memory store:     ❌ cannot create ({store})")
                ok = False
    else:
        print(f"  Memory store:     ❌ no config loaded")

    # --- Security mode ---
    security_mode = getattr(cfg, 'security_mode', 'sandboxed') if cfg else 'unknown'
    print(f"  Security mode:    {security_mode}")

    # --- Encryption (honest reporting) ---
    print(f"  Encryption:")

    # Key package (cryptography)
    try:
        import cryptography  # noqa: F401
        print(f"    Key package:    ✅ cryptography installed")
        has_crypto = True
    except ImportError:
        print(f"    Key package:    ❌ cryptography not installed")
        has_crypto = False

    # Key loaded (only meaningful in encrypted mode)
    if security_mode == "encrypted":
        if os.environ.get("ANTARISBOT_MEMORY_KEY"):
            print(f"    Key loaded:     ✅ from ANTARISBOT_MEMORY_KEY env var")
        else:
            try:
                import keyring
                stored = keyring.get_password("antaris-agent", "memory-key")
                if stored:
                    print(f"    Key loaded:     ✅ from keyring")
                else:
                    print(f"    Key loaded:     ❌ no key in keyring (run agent to set up)")
            except ImportError:
                print(f"    Key loaded:     ❌ keyring not installed (pip install antaris-agent[secure-store])")
            except Exception as _ke:
                print(f"    Key loaded:     ❌ keyring error: {_ke}")
    else:
        print(f"    Key loaded:     — not in encrypted mode")

    # Data-at-rest encryption — HONEST: not yet implemented
    print(f"    Data-at-rest:   ❌ not yet implemented")

    # --- Audit hook ---
    if hasattr(sys, 'addaudithook'):
        print(f"  Audit hook:       ✅ installable")
    else:
        print(f"  Audit hook:       ❌ sys.addaudithook not available")

    # --- Optional channel dependencies ---
    print(f"  Channels:")

    # Discord
    try:
        import discord  # noqa: F401
        print(f"    Discord:        ✅ discord.py installed")
    except ImportError:
        print(f"    Discord:        ❌ discord.py not installed")

    # Telegram
    try:
        import telegram  # noqa: F401
        print(f"    Telegram:       ✅ python-telegram-bot installed")
    except ImportError:
        print(f"    Telegram:       ❌ python-telegram-bot not installed")

    # Slack
    try:
        import slack_bolt  # noqa: F401
        print(f"    Slack:          ✅ slack-bolt installed")
    except ImportError:
        print(f"    Slack:          ❌ slack-bolt not installed")

    # --- Overall ---
    print()
    if ok:
        print(f"  Overall: ✅ Ready to start")
    else:
        print(f"  Overall: ❌ Issues found — fix the above and retry")
    print()


def main():
    # ── Name-first syntax: `antaris <name> <command>` → `antaris <command> <name>` ──
    _KNOWN_COMMANDS = {
        "init", "start", "stop", "restart", "pulse", "fleet", "chat",
        "status", "config", "memory", "guard", "persona", "migrate",
        "export", "logs", "setup", "update", "uninstall", "reinstall",
        "install-service", "uninstall-service", "security", "doctor",
        "enrichment", "tools",
    }
    if len(sys.argv) >= 3:
        _first, _second = sys.argv[1], sys.argv[2]
        if (_first not in _KNOWN_COMMANDS
                and not _first.startswith("-")
                and _second in _KNOWN_COMMANDS):
            # Swap: `antaris finch start ...` → `antaris start finch ...`
            sys.argv[1], sys.argv[2] = _second, _first

    # Detect invocation name
    prog = os.path.basename(sys.argv[0])
    if prog != "antaris":
        prog = "antaris"

    parser = argparse.ArgumentParser(
        prog=prog,
        description="Parsica Agent — Personal AI assistant powered by Parsica Memory",
        epilog=(
            "Quick start:\n"
            "  antaris init                 First-time setup wizard\n"
            "  antaris init finch           Initialize a named instance\n"
            "  antaris setup                Launch browser setup wizard\n"
            "  antaris start                Launch the default agent\n"
            "  antaris finch start          Launch a named instance\n"
            "  antaris start --terminal     Terminal-only mode (no Discord/Telegram)\n"
            "  antaris start --daemon       Run in background\n\n"
            "Named instances:\n"
            "  antaris <name> <command>     Run any command for a named instance\n"
            "  antaris finch status         Show status of 'finch' instance\n"
            "  antaris finch stop           Stop the 'finch' instance\n"
            "  antaris fleet                List all registered instances\n\n"
            "Daemon control (persistent services):\n"
            "  antarisd finch install       Install 'finch' as a system service\n"
            "  antarisd finch start         Start daemon for 'finch'\n"
            "  antarisd finch stop          Stop daemon for 'finch'\n"
            "  antarisd fleet               List all agent daemons\n\n"
            "Common commands:\n"
            "  antaris status               Show agent status\n"
            "  antaris doctor               Check config + dependencies\n"
            "  antaris logs -f              Stream live logs\n"
            "  antaris memory stats         Memory system health\n"
            "  antaris tools list           Discover enabled tools\n\n"
            "In chat, use !help for the full command guide.\n"
            "\n"
            "Config directory: ~/.antaris (override with --config-dir or ANTARIS_CONFIG_DIR).\n"
            "Named instances: ~/.antaris/instances/<name>/config.json"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"{prog} {VERSION}")
    parser.add_argument(
        "--config-dir",
        default=None,
        metavar="DIR",
        help="Config directory (default: ~/.antaris or $ANTARIS_CONFIG_DIR)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # init
    parser_init = subparsers.add_parser("init", help="Initialize config directory and run first-time setup")
    parser_init.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance (registers in ~/.antaris/.instances.json)")

    # start
    start_parser = subparsers.add_parser("start", help="Launch the agent")
    start_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to start (from registry)")
    start_parser.add_argument("--terminal", action="store_true", help="Terminal mode only")
    start_parser.add_argument("--debug", action="store_true", help="Verbose logging")
    start_parser.add_argument("--daemon", "-d", action="store_true", help="Run in background (daemonize)")
    start_parser.add_argument("--foreground", action="store_true", help="Stay in foreground (default without --daemon)")
    start_parser.add_argument(
        "--security",
        choices=["open", "standard", "sandboxed", "secured", "encrypted"],
        default=None,
        metavar="MODE",
        help="Security mode: open (no restrictions), sandboxed (default, recommended), standard (more capability), secured/encrypted (approval gates + audit logging)",
    )

    # stop
    stop_parser = subparsers.add_parser("stop", help="Stop the running agent")
    stop_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to stop (optional)")

    # pulse
    subparsers.add_parser("pulse", help="Pre-launch health check — verify all components")

    # restart
    restart_parser = subparsers.add_parser("restart", help="Restart the agent")
    restart_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to restart (optional)")
    restart_parser.add_argument("--terminal", action="store_true", help="Restart in terminal mode only")
    restart_parser.add_argument("--debug", action="store_true", help="Restart with verbose logging")
    restart_parser.add_argument("--daemon", "-d", action="store_true", help="Restart in background (daemonize)")
    restart_parser.add_argument(
        "--security",
        choices=["open", "standard", "sandboxed", "secured", "encrypted"],
        default=None,
        metavar="MODE",
        help="Override security mode on restart",
    )

    # fleet
    subparsers.add_parser("fleet", help="List all registered agent instances and their status")

    # chat
    subparsers.add_parser("chat", help="Direct terminal conversation")

    # status
    status_parser = subparsers.add_parser("status", help="Show agent status")
    status_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance (default: current config dir)")

    # config
    config_parser = subparsers.add_parser("config", help="View or edit configuration")
    config_parser.add_argument("action", nargs="?", choices=["show", "set", "add", "telegram-token", "slack-token", "open-channel"])
    config_parser.add_argument("key", nargs="?")
    config_parser.add_argument("value", nargs="?")

    # memory
    mem_parser = subparsers.add_parser(
        "memory",
        help="Inspect and search the memory system",
        description=(
            "Memory inspection and export commands.\n\n"
            "Examples:\n"
            "  antaris memory stats\n"
            "  antaris memory search deployment\n"
            "  antaris memory export"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    mem_parser.add_argument("action", nargs="?", choices=["stats", "search", "export", "import", "prune"], help="stats/search/export/import/prune")
    mem_parser.add_argument("query", nargs="?", help="search query or output path, depending on action")

    # guard
    guard_parser = subparsers.add_parser("guard", help="Guard policy management (coming soon)")
    guard_parser.add_argument("action", nargs="?", choices=["status", "mode", "test"])
    guard_parser.add_argument("value", nargs="?")

    # persona
    persona_parser = subparsers.add_parser("persona", help="Persona management")
    persona_parser.add_argument("action", nargs="?", choices=["show", "edit", "reset"])

    # migrate
    migrate_parser = subparsers.add_parser("migrate", help="Import from another bot framework")
    migrate_parser.add_argument(
        "--from", dest="source",
        choices=["openclaw", "mem0", "langchain", "lancedb", "custom"],
    )
    migrate_parser.add_argument("--path")
    migrate_parser.add_argument("--dry-run", action="store_true")
    migrate_parser.add_argument("--user-id", dest="user_id", default=None,
        help="Discord user ID to assign imported memories to")
    migrate_parser.add_argument("--all", dest="import_all", action="store_true",
        help="Non-interactive: import everything without prompts")

    # export
    export_parser = subparsers.add_parser("export", help="Export bot data to a portable format")
    export_parser.add_argument("--full", action="store_true",
        help="Export everything (identity + config + memories)")
    export_parser.add_argument("--memories-only", action="store_true",
        help="Export memories only as JSONL")
    export_parser.add_argument("--identity-only", action="store_true",
        help="Export identity markdown files only")
    export_parser.add_argument("--output", default=None,
        help="Output path (file for --memories-only, directory otherwise)")

    # logs
    logs_parser = subparsers.add_parser("logs", help="View bot logs")
    logs_parser.add_argument("name", nargs="?", default=None, help="Agent name (e.g. 'antaris logs finch')")
    logs_parser.add_argument("--follow", "-f", action="store_true", help="Stream new log lines (like tail -f)")
    logs_parser.add_argument("--tail", "-n", type=int, default=50, metavar="N", help="Number of lines to show (default: 50)")
    logs_parser.add_argument("--level", "-l", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], metavar="LEVEL", help="Filter to only show lines at or above this level (e.g. ERROR)")

    # setup
    setup_parser = subparsers.add_parser("setup", help="Run the web setup wizard")
    setup_parser.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    setup_parser.add_argument(
        "--wizard",
        choices=["general", "integrations", "automation", "power", "all"],
        default="all",
        help="Open a specific setup wizard for re-entry (default: all)",
    )

    # update
    update_parser = subparsers.add_parser("update", help="Update Parsica Agent to the latest version")
    update_parser.add_argument(
        "--check", action="store_true",
        help="Check for updates without installing"
    )

    # install-service / uninstall-service
    subparsers.add_parser("install-service", help="Install as a system service (systemd/launchd)")
    subparsers.add_parser("uninstall-service", help="Remove the system service")

    # uninstall / reinstall
    uninstall_parser = subparsers.add_parser("uninstall", help="Uninstall Parsica Agent from this environment")
    uninstall_parser.add_argument("--remove-config", action="store_true", help="Also remove the ~/.antaris config directory")
    subparsers.add_parser("reinstall", help="Force-reinstall Parsica Agent from PyPI")

    # security
    parser_security = subparsers.add_parser("security", help="Show security status")
    parser_security.add_argument("action", nargs="?", default="status", choices=["status"])

    # doctor
    doctor_parser = subparsers.add_parser("doctor", help="Check bot configuration and dependencies")
    doctor_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to check")

    # enrichment
    enrichment_parser = subparsers.add_parser("enrichment", help="Inspect or configure memory enrichment")
    enrichment_parser.add_argument("action", nargs="?", default="status",
                                    choices=["status", "config", "batch", "batches"],
                                    help="status | config | batch | batches")
    enrichment_parser.add_argument("--provider", choices=["anthropic", "openai", "google"],
                                    default="anthropic", help="Batch API provider")
    enrichment_parser.add_argument("--model", help="Model for batch enrichment")
    enrichment_parser.add_argument("--limit", type=int, default=500,
                                    help="Max memories to enrich (default: 500)")
    enrichment_parser.add_argument("--dry-run", action="store_true",
                                    help="Prepare batch without submitting")

    # tools
    # ── Telemetry export ──────────────────────────────────────────
    telemetry_parser = subparsers.add_parser(
        "telemetry",
        help="Export and analyze substrate telemetry data",
    )
    telemetry_parser.add_argument("action", nargs="?", default="summary",
                                  choices=["summary", "export", "csv", "json"],
                                  help="Output format (default: summary)")
    telemetry_parser.add_argument("--agent", "-a", help="Filter by agent name")
    telemetry_parser.add_argument("--output", "-o", help="Write to file instead of stdout")

    # ── Session awareness visualization ───────────────────────────
    session_viz_parser = subparsers.add_parser(
        "sessions",
        help="Visualize session awareness across agents",
    )
    session_viz_parser.add_argument("action", nargs="?", default="list",
                                     choices=["list", "awareness"],
                                     help="Action (default: list)")

    tools_parser = subparsers.add_parser(
        "tools",
        help="Discover and inspect enabled tools",
        description=(
            "Inspect Antaris tool availability.\n\n"
            "Examples:\n"
            "  antaris tools list\n"
            "  antaris tools status"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tools_parser.add_argument("action", nargs="?", default="list", 
                             choices=["list", "status"], 
                             help="list = show enabled tools, status = show tool configuration state")

    args = parser.parse_args()

    # Allow reassignment of the module-level PID_FILE throughout this function
    global PID_FILE

    # Apply --config-dir override before any command runs.
    # This sets the env var so that Config, pulse, and PID_FILE all pick it up.
    if getattr(args, "config_dir", None):
        os.environ["ANTARIS_CONFIG_DIR"] = str(Path(args.config_dir).expanduser().resolve())
        # Re-resolve module-level defaults that were computed at import time
        PID_FILE = _resolve_config_dir() / "bot.pid"

    if args.command is None:
        parser.print_help()
        return

    # ── Commands ─────────────────────────────────────────────────────────────

    if args.command == "init":
        from antaris_agent.core.config import run_init_create
        name = getattr(args, "name", None)
        if name:
            # v2.9.11: Agent home = ~/.antaris-<name>/ (venv + config + data in one dir)
            # Old path: ~/.antaris/instances/<name>/ — DEPRECATED
            config_dir = Path.home() / f".antaris-{name}"
            
            # Create as a venv first, then scaffold config inside
            if not (config_dir / "bin" / "python3").exists() and not (config_dir / "bin" / "python").exists():
                import subprocess
                print(f"🔧 Creating isolated venv at {config_dir}...")
                subprocess.run(
                    [sys.executable, "-m", "venv", str(config_dir)],
                    check=True,
                )
                # Install antaris-agent into the new venv
                venv_pip = config_dir / "bin" / "pip"
                print(f"📦 Installing antaris-agent into venv...")
                subprocess.run(
                    [str(venv_pip), "install", "antaris-agent[discord]"],
                    check=True,
                    capture_output=True,
                )
                print(f"✅ Venv ready at {config_dir}")
            
            run_init_create(str(config_dir))
            reg = _load_registry()
            reg[name] = str(config_dir)
            _save_registry(reg)
            print(f"   Instance '{name}' registered at {config_dir}")
            print(f"   Start with: antarisd {name} start")
            print(f"   ⚠️  Do NOT run 'antaris start' — use antarisd only.")
        else:
            run_init_create()

    elif args.command == "setup":
        from antaris_agent.setup.wizard import SetupWizard
        wizard_name = getattr(args, "wizard", "all") or "all"
        no_browser = getattr(args, "no_browser", False)
        wiz = SetupWizard()
        wiz.run(wizard=wizard_name, open_browser=not no_browser)
        print(f"\n   Config: ~/.antaris/config.json")

    elif args.command == "enrichment":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ No config found. Run 'antaris init' or 'antaris setup' first.")
            return
        if args.action == "status":
            _show_enrichment_status(cfg)
        elif args.action == "config":
            _run_enrichment_config(cfg)
        elif args.action == "batch":
            from antaris_agent.tools.batch_enrichment import run_batch_enrichment
            store_path = getattr(cfg, "memory_store", "") or str(Path.home() / ".antaris" / "memory")
            result = run_batch_enrichment(
                store_path=store_path,
                provider=getattr(args, "provider", "anthropic"),
                model=getattr(args, "model", None),
                limit=getattr(args, "limit", 500),
                dry_run=getattr(args, "dry_run", False),
            )
            print(result)
        elif args.action == "batches":
            from antaris_agent.tools.batch_enrichment import list_batches
            store_path = getattr(cfg, "memory_store", "") or str(Path.home() / ".antaris" / "memory")
            print(list_batches(store_path))

    elif args.command == "start":
        import atexit
        # v2.9.11: Check if running inside antarisd daemon context
        # If not inside a daemon and not --foreground, warn the user
        _daemon_pid = os.environ.get("ANTARIS_DAEMON_LOCK_PID", "")
        _is_foreground = getattr(args, "foreground", False)
        if not _daemon_pid and not _is_foreground:
            print("⚠️  'antaris start' should be run through antarisd, not directly.")
            print("   Use: antarisd <name> start")
            print("")
            print("   Running 'antaris start' directly can cause duplicate processes")
            print("   and config resolution issues. Use antarisd for proper daemon management.")
            print("")
            print("   To run in foreground for debugging: antaris start --foreground")
            _force = input("   Continue anyway? (y/N): ").strip().lower()
            if _force != "y":
                sys.exit(0)
        # Resolve named instance before PID check
        _instance_name = getattr(args, "name", None)
        if _instance_name and not getattr(args, "config_dir", None):
            _named_dir = _resolve_named_instance(_instance_name)
            if _named_dir:
                os.environ["ANTARIS_CONFIG_DIR"] = _named_dir
                PID_FILE = Path(_named_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_instance_name}' not found. Run 'antaris init --name {_instance_name}' first.")
                sys.exit(1)
        # Guard: prevent multiple instances — GLOBAL process scan
        _my_config_dir = str(_resolve_config_dir())

        # Check 1: Own PID file
        existing_pid = _read_pid()
        if existing_pid:
            try:
                if sys.platform == "win32":
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(0x1000, False, existing_pid)
                    if handle:
                        kernel32.CloseHandle(handle)
                        _is_alive = True
                    else:
                        _is_alive = False
                else:
                    os.kill(existing_pid, 0)
                    _is_alive = True
                if _is_alive:
                    print(f"⚠️  Bot is already running (PID {existing_pid}).")
                    print(f"   Run 'antaris stop' first, or 'antaris restart'.")
                    sys.exit(1)
                else:
                    _clear_pid()
            except (ProcessLookupError, OSError):
                _clear_pid()

        # Check 2: Token lock — prevents same-token double-launch (local AND cross-host)
        # Skip if the daemon layer (antarisd run) already holds the lock for us.
        # We verify by PID: the env var must contain our parent's PID, preventing
        # spoofing by an unrelated process that simply sets the old boolean flag.
        _daemon_lock_pid_str = os.environ.get("ANTARIS_DAEMON_LOCK_PID")
        _lock_held_by_parent = False
        if _daemon_lock_pid_str:
            try:
                _daemon_lock_pid = int(_daemon_lock_pid_str)
                if _daemon_lock_pid == os.getppid():
                    _lock_held_by_parent = True
                    print(f"ℹ️  Token lock: skipped (held by parent daemon PID {_daemon_lock_pid})")
            except ValueError:
                pass  # Malformed value — treat as not held

        if _lock_held_by_parent:
            pass  # Lock held and verified by parent antarisd process — do not re-acquire
        else:
            from antaris_agent.daemon_lock import acquire_token_lock, release_token_lock, write_pid_file, clear_pid_file
            from antaris_agent.core.config import Config as _LockConfig
            _lock_cfg = _LockConfig.load(str(Path(_my_config_dir) / "config.json"))
            _lock_token = getattr(_lock_cfg, "discord_token", None) if _lock_cfg else None
            if _lock_token:
                _lock_ok, _lock_msg = acquire_token_lock(
                    _lock_token, _my_config_dir,
                    agent_name=Path(_my_config_dir).name or "default",
                )
                if not _lock_ok:
                    print(f"🚫 {_lock_msg}")
                    sys.exit(1)
                import atexit as _lock_atexit
                _lock_atexit.register(release_token_lock, _lock_token, _my_config_dir)
                # N3: Stash token + config_dir in env so _sigterm_handler can clean up.
                os.environ["_ANTARIS_ACTIVE_TOKEN"] = _lock_token

        # Check 3: Legacy process scan (informational only — lock is the real guard)
        running_procs = _scan_running_antaris_processes()
        my_pid = os.getpid()
        other_procs = [(p, c) for p, c in running_procs if p != my_pid]
        if other_procs:
            print(f"⚠️  Found {len(other_procs)} other antaris process(es) already running:")
            for p, c in other_procs:
                print(f"   PID {p}: {c}")
            print(f"   Kill them first, or use 'antaris fleet' to see all instances.")
            print(f"   Continuing anyway — token lock passed.")

        # Auto-register this instance
        _auto_register_instance(_my_config_dir)
        # Only write PID now if NOT daemonizing; daemon path writes after fork
        if not getattr(args, "daemon", False):
            _write_pid()
            atexit.register(_clear_pid)
        from antaris_agent.core.config import Config
        config = Config.load()

        # ── Security mode ─────────────────────────────────────────────
        # v2.5: Security prompt REMOVED from startup. Defaults to Standard (1).
        # Users change security via 'antaris setup' wizard or config.json directly.
        _selected_security = getattr(args, "security", None)
        if not _selected_security:
            _selected_security = getattr(config, "security_mode", "standard") if config else "standard"
        if config:
            config.security_mode = _selected_security

        # ── Daemonize if requested ───────────────────────────────────
        _daemon_mode = getattr(args, "daemon", False)
        if _daemon_mode and not getattr(args, "foreground", False):
            import platform as _plat
            if _plat.system() != "Windows":
                _log_dir = _resolve_config_dir() / "logs"
                _log_dir.mkdir(parents=True, exist_ok=True)
                _log_file = _log_dir / "antaris.log"
                print(f"🛡️  Security: {_selected_security}")
                print(f"🚀 Daemonizing... logs at {_log_file}")
                # First fork
                pid = os.fork()
                if pid > 0:
                    print(f"✅ Bot running in background (PID {pid})")
                    sys.exit(0)
                # Decouple from parent
                os.setsid()
                os.umask(0o077)
                # Second fork
                pid2 = os.fork()
                if pid2 > 0:
                    sys.exit(0)
                # N2: Close inherited file descriptors (beyond stdin/stdout/stderr)
                # to avoid leaking parent's sockets, pipes, and fd handles into the daemon.
                try:
                    _sc_open_max = os.sysconf("SC_OPEN_MAX")
                except (AttributeError, ValueError):
                    _sc_open_max = 1024  # Safe fallback on platforms without sysconf
                try:
                    os.closerange(3, _sc_open_max)
                except OSError:
                    pass
                # Redirect stdio to log
                sys.stdout.flush()
                sys.stderr.flush()
                _lf = open(_log_file, "a")
                os.dup2(_lf.fileno(), sys.stdout.fileno())
                os.dup2(_lf.fileno(), sys.stderr.fileno())
                _devnull = open(os.devnull, "r")
                os.dup2(_devnull.fileno(), sys.stdin.fileno())
                # Write grandchild PID — this is the real daemon process
                _clear_pid()
                _write_pid()
                atexit.register(_clear_pid)
            else:
                print("⚠️  --daemon not supported on Windows. Running in foreground.")

        # N3: Register explicit SIGTERM handler so cleanup runs even if
        # downstream code catches BaseException and suppresses SystemExit.
        signal.signal(signal.SIGTERM, _sigterm_handler)

        from antaris_agent.core.bot import Bot
        bot = Bot()
        if bot.config:
            bot.config.security_mode = _selected_security
        if not _daemon_mode:
            print(f"🛡️  Security: {_selected_security}")
        bot.start(terminal_only=getattr(args, 'terminal', False))

    elif args.command == "stop":
        _stop_name = getattr(args, "name", None)
        if _stop_name:
            _stop_dir = _resolve_named_instance(_stop_name)
            if _stop_dir:
                PID_FILE = Path(_stop_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_stop_name}' not found. Run 'antaris init --name {_stop_name}' first.")
                sys.exit(1)
        _stop_bot()

    elif args.command == "pulse":
        import asyncio as _asyncio
        from antaris_agent.core.pulse import run_pulse
        report = _asyncio.run(run_pulse())
        print(report.summary())
        if not report.passed():
            sys.exit(1)

    elif args.command == "restart":
        _restart_name = getattr(args, "name", None)
        if _restart_name:
            _restart_dir = _resolve_named_instance(_restart_name)
            if _restart_dir:
                PID_FILE = Path(_restart_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_restart_name}' not found. Run 'antaris init --name {_restart_name}' first.")
                sys.exit(1)
        print("🔄 Restarting bot...")
        _stop_bot()
        import time
        time.sleep(1.5)
        _restart_cmd = [sys.argv[0], "start"]
        if _restart_name:
            _restart_cmd += [_restart_name]
        # Forward any CLI flags that were passed to the original invocation
        if getattr(args, "config_dir", None):
            _restart_cmd += ["--config-dir", args.config_dir]
        if getattr(args, "security", None):
            _restart_cmd += ["--security", args.security]
        if getattr(args, "terminal", False):
            _restart_cmd += ["--terminal"]
        if getattr(args, "debug", False):
            _restart_cmd += ["--debug"]
        if getattr(args, "daemon", False):
            _restart_cmd += ["--daemon"]
        subprocess.Popen(_restart_cmd)
        print("✅ Bot restarting.")

    elif args.command == "fleet":
        reg = _load_registry()
        # Default instance always listed first
        instances = {"(default)": str(_resolve_config_dir())}
        instances.update(reg)
        print(f"\n{'NAME':<16} {'STATUS':<10} {'PID':<8} {'CONFIG DIR'}")
        print("-" * 70)
        for _fname, _cdir in instances.items():
            _running, _pid = _is_instance_running(_cdir)
            _status = "running" if _running else "stopped"
            _pid_str = str(_pid) if _pid else "-"
            _short_dir = _cdir.replace(str(Path.home()), "~")
            print(f"{_fname:<16} {_status:<10} {_pid_str:<8} {_short_dir}")
        print()

    elif args.command == "chat":
        from antaris_agent.core.bot import Bot
        Bot().chat()

    elif args.command == "status":
        _status_name = getattr(args, "name", None)
        if _status_name and not getattr(args, "config_dir", None):
            _status_dir = _resolve_named_instance(_status_name)
            if _status_dir:
                os.environ["ANTARIS_CONFIG_DIR"] = _status_dir
                PID_FILE = Path(_status_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_status_name}' not found.")
                sys.exit(1)
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if cfg:
            pid = _read_pid()
            status = f"Running (PID {pid})" if pid else "Stopped"
            print(f"🤖 {cfg.bot_name}")
            print(f"   Status: {status}")
            print(f"   Provider: {cfg.provider_name} / {cfg.model}")
            open_ch = cfg.discord_open_channels
            print(f"   Open channels: {len(open_ch)} configured")
        else:
            print("❌ Not initialized. Run 'antaris init' first.")

    elif args.command == "config":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return
        action = getattr(args, 'action', None) or 'show'
        if action == 'show' or not action:
            import json
            with open(cfg.config_path) as f:
                print(json.dumps(json.load(f), indent=2))
        elif action == 'set':
            key = getattr(args, 'key', None)
            value = getattr(args, 'value', None)
            if not key or not value:
                print("Usage: antaris config set <key> <value>")
                return
            # Simple key=value setter for top-level provider fields
            if key == 'model':
                cfg.model = value
                cfg.save()
                print(f"✅ Model set to {value}")
            elif key == 'open-channel':
                channel_id = value
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ Invalid channel ID '{channel_id}'. Discord channel IDs are 17-19 digit numbers.")
                    sys.exit(1)
                if channel_id not in (cfg.discord_open_channels or []):
                    cfg.discord_open_channels = (cfg.discord_open_channels or []) + [channel_id]
                    cfg.save()
                    print(f"✅ Added {channel_id} as open channel (restart bot to apply)")
                else:
                    print(f"Already an open channel: {channel_id}")
            elif key == 'remove-channel':
                channels = cfg.discord_open_channels or []
                if value in channels:
                    channels.remove(value)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {value} from open channels")
                else:
                    print(f"Not an open channel: {value}")
            else:
                print(f"Unknown config key: {key}")
                print("Available: model, open-channel, remove-channel")
        elif action == 'telegram-token':
            token = getattr(args, 'key', None)
            if not token:
                print("Usage: antaris config telegram-token <token>")
                return
            cfg.telegram_token = token
            cfg.telegram_enabled = True
            cfg.save()
            print(f"✅ Telegram token set and Telegram enabled")

        elif action == 'slack-token':
            bot_token = getattr(args, 'key', None)
            app_token = getattr(args, 'value', None)
            if not bot_token or not app_token:
                print("Usage: antaris config slack-token <bot-token> <app-token>")
                print("  bot-token: xoxb-... (Bot User OAuth Token)")
                print("  app-token: xapp-... (App-Level Token for Socket Mode)")
                return
            cfg.slack_bot_token = bot_token
            cfg.slack_app_token = app_token
            cfg.slack_enabled = True
            cfg.save()
            print(f"✅ Slack tokens set and Slack enabled")

        elif action == 'open-channel':
            sub = getattr(args, 'key', None)
            channel_id = getattr(args, 'value', None)

            if sub == 'list' or not sub:
                channels = cfg.discord_open_channels or []
                if not channels:
                    print("   (no open channels configured)")
                else:
                    print(f"   Open channels ({len(channels)}):")
                    for ch in channels:
                        print(f"   • {ch}")

            elif sub == 'add':
                if not channel_id:
                    print("Usage: antaris config open-channel add <channel_id>")
                    return
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ '{channel_id}' does not look like a Discord snowflake (17-19 digits).")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id in channels:
                    print(f"⚠️  Channel {channel_id} is already in the open-channels list.")
                else:
                    channels.append(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Added {channel_id} to open channels. Restart bot to apply.")

            elif sub == 'remove':
                if not channel_id:
                    print("Usage: antaris config open-channel remove <channel_id>")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id not in channels:
                    print(f"⚠️  Channel {channel_id} not found in open-channels list.")
                else:
                    channels.remove(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {channel_id} from open channels. Restart bot to apply.")

            else:
                print(f"Unknown open-channel sub-command: {sub}")
                print("Usage: antaris config open-channel add|remove|list [channel_id]")

    elif args.command == "persona":
        action = getattr(args, 'action', None) or 'show'
        soul_path = Path.home() / ".antaris" / "SOUL.md"
        if action == 'show':
            if soul_path.exists():
                print(soul_path.read_text())
            else:
                print("No SOUL.md found. Run 'antaris init' first.")
        elif action == 'edit':
            editor = os.environ.get("EDITOR", "nano")
            subprocess.run(shlex.split(editor) + [str(soul_path)], check=False)
        elif action == 'reset':
            print("⚠️  This will erase the current persona and trigger awakening on next start.")
            confirm = input("Are you sure? (y/N): ").strip().lower()
            if confirm in ("y", "yes"):
                soul_path.write_text("AWAKENING_NEEDED\n")
                print("✅ SOUL.md reset. Next bot start will trigger awakening.")
            else:
                print("Cancelled.")

    elif args.command == "memory":
        action = getattr(args, 'action', None) or 'stats'
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return

        from antaris_agent.core.memory import BotMemory
        memory = BotMemory(
            store_path=cfg.memory_store,
            search_limit=cfg.memory_search_limit,
            min_relevance=cfg.memory_min_relevance,
        )

        if action == 'stats' or not action:
            # List all users and their memory counts
            store_path = Path(cfg.memory_store)
            if not store_path.exists() or not any(store_path.iterdir()):
                print("📭 No memories stored yet.")
                return
            total = 0
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    stats = memory.stats(user_dir.name)
                    count = stats.get('entry_count', 0)
                    total += count
                    print(f"   {user_dir.name[:20]}: {count} memories")
            print(f"\n   Total: {total} memories across {len(list(store_path.iterdir()))} user(s)")

        elif action == 'search':
            query = getattr(args, 'query', None)
            if not query:
                print("Usage: antaris memory search <query>")
                return
            # Search across all users
            import asyncio
            store_path = Path(cfg.memory_store)
            found_any = False
            for user_dir in sorted(store_path.iterdir()):
                if not user_dir.is_dir():
                    continue
                results = asyncio.run(memory.recall(user_dir.name, query))
                if results:
                    found_any = True
                    print(f"\n[{user_dir.name[:20]}]")
                    for r in results[:5]:
                        print(f"  • {r[:120]}")
            if not found_any:
                print(f"No memories found for '{query}'")

        elif action == 'export':
            import json, asyncio
            output_file = getattr(args, 'query', None) or 'memory_export.json'
            store_path = Path(cfg.memory_store)
            export = {}
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    results = asyncio.run(memory.recall(user_dir.name, ""))
                    export[user_dir.name] = results
            with open(output_file, 'w') as f:
                json.dump(export, f, indent=2)
            print(f"✅ Exported to {output_file}")

        else:
            print(f"Unknown memory action: {action}")

    elif args.command == "guard":
        print("❌ Guard commands are not yet available.")

    elif args.command == "migrate":
        from pathlib import Path as P
        source = getattr(args, 'source', None)
        source_path = getattr(args, 'path', None)
        dry_run = getattr(args, 'dry_run', False)
        user_id = getattr(args, 'user_id', None) or "migrated-user"
        import_all = getattr(args, 'import_all', False)
        dest_path = str(P.home() / ".antaris")

        from antaris_agent.migration import (
            OpenClawMigration, Mem0Migration, CustomMigration,
            LangChainMigration, LanceDBMigration,
        )

        source_class_map = {
            "openclaw": OpenClawMigration,
            "mem0": Mem0Migration,
            "langchain": LangChainMigration,
            "lancedb": LanceDBMigration,
            "custom": CustomMigration,
        }

        if not source:
            # Interactive mode: scan all known locations
            print("🔍 Scanning for importable data...\n")
            found_sources = []
            scan_targets = [
                ("openclaw", P.home() / ".openclaw" / "workspace"),
                ("mem0", P.home()),
                ("langchain", P.home()),
                ("lancedb", P.home() / ".openclaw" / "memory"),
            ]
            for src_name, default_path in scan_targets:
                cls = source_class_map.get(src_name)
                if cls:
                    try:
                        m = cls(str(default_path), dest_path, dry_run=dry_run, user_id=user_id)
                        if m.detect():
                            found_sources.append((src_name, str(default_path), cls))
                            print(f"  ✅ {src_name} — found at {default_path}")
                    except Exception:
                        pass

            if not found_sources:
                print("No importable data found in default locations.")
                print("Use --from to specify a source: antaris migrate --from openclaw|mem0|langchain|lancedb|custom")
                return

            if not import_all:
                print(f"\nFound {len(found_sources)} source(s). Run with --all to import all, or specify --from <source>.")
                return

            # Import all found sources
            for src_name, src_path, cls in found_sources:
                print(f"\n📦 Migrating from {src_name}...")
                m = cls(src_path, dest_path, dry_run=dry_run, user_id=user_id)
                result = m.migrate()
                print(result.summary())
            if not dry_run:
                print("\n✅ Migration complete. Run 'antaris start' to launch.")
            return

        if not source_path:
            # Default paths per source
            defaults = {
                "openclaw": str(P.home() / ".openclaw" / "workspace"),
                "mem0": str(P.home()),
                "langchain": str(P.home()),
                "lancedb": str(P.home() / ".openclaw" / "memory"),
                "custom": "import.json",
            }
            source_path = defaults.get(source, ".")
            print(f"No --path given, trying default: {source_path}")

        MigrationClass = source_class_map.get(source)
        if not MigrationClass:
            print(f"Unknown source: {source}")
            return

        migrator = MigrationClass(
            source_path=source_path,
            dest_path=dest_path,
            dry_run=dry_run,
            user_id=user_id,
        )

        if not migrator.detect():
            print(f"❌ Could not detect {source} data at: {source_path}")
            print("   Check the path and try again.")
            return

        if dry_run:
            print(f"🔍 Dry run — nothing will be written\n")
        else:
            print(f"📦 Migrating from {source}...\n")

        result = migrator.migrate()
        print(result.summary())

        if result.success and not dry_run:
            print(f"\n✅ Migration complete.")
            print(f"   Run 'antaris start' to launch with your imported data.")
        elif dry_run:
            print(f"\n   Run without --dry-run to apply.")

    elif args.command == "export":
        from pathlib import Path as P
        from antaris_agent.migration.export import ExportManager

        full = getattr(args, 'full', False)
        memories_only = getattr(args, 'memories_only', False)
        identity_only = getattr(args, 'identity_only', False)
        output = getattr(args, 'output', None)

        # Default output paths
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if not output:
            if memories_only:
                output = str(P.home() / f"antaris_memories_{timestamp}.jsonl")
            else:
                output = str(P.home() / f"antaris_export_{timestamp}")

        exporter = ExportManager()

        if memories_only:
            print(f"📤 Exporting memories to {output}...")
            count = exporter.export_memories(output)
            print(f"✅ Exported {count} memory entries to {output}")

        elif identity_only:
            print(f"📤 Exporting identity files to {output}...")
            count = exporter.export_identity(output)
            print(f"✅ Exported {count} identity files to {output}")

        elif full or not (memories_only or identity_only):
            print(f"📤 Exporting full Antaris data to {output}...")
            summary = exporter.export_full(output)
            print(f"✅ Export complete at {output}")
            for key, val in summary.items():
                print(f"   {key}: {val}")
            print(f"\n   To re-import: antaris migrate --from custom --path {output}")

    elif args.command == "logs":
        import subprocess
        # v2.9.11: resolve log path — supports 'antaris logs finch' name-first syntax
        _log_name = getattr(args, "name", None)
        if _log_name:
            _named = _resolve_named_instance(_log_name)
            if _named:
                config_dir = Path(_named)
            else:
                # Try convention path directly
                config_dir = Path.home() / f".antaris-{_log_name}"
                if not config_dir.exists():
                    print(f"❌ No agent '{_log_name}' found.")
                    print(f"   Checked: ~/.antaris-{_log_name}/ and instances registry")
                    return
        else:
            config_dir = _resolve_config_dir()
        # Try antarisd log first (daemon mode), then legacy paths
        log_candidates = [
            config_dir / "logs" / "antarisd.log",       # antarisd daemon log
            config_dir / "logs" / "antaris-agent.log",   # legacy daemon log
            Path.home() / ".antaris" / "logs" / "antaris-agent.log",  # default fallback
        ]
        log_file = None
        for candidate in log_candidates:
            if candidate.exists():
                log_file = candidate
                break
        if log_file is None:
            print(f"No log file found. Checked:")
            for c in log_candidates:
                print(f"  {c}")
            print(f"\nConfig dir: {config_dir}")
            print("Tip: use ANTARIS_CONFIG_DIR to point to a named instance,")
            print("  or run: tail -50 ~/.antarisagent-<name>/logs/antarisd.log")
            return

        follow = getattr(args, 'follow', False)
        tail_n = getattr(args, 'tail', 50)
        level_filter = getattr(args, 'level', None)

        if follow and not level_filter:
            # Pure streaming — delegate to tail -f
            subprocess.run(["tail", "-f", str(log_file)])
        elif follow and level_filter:
            # Stream + filter: tail -f piped through grep
            tail_proc = subprocess.Popen(["tail", "-f", str(log_file)], stdout=subprocess.PIPE)
            grep_proc = subprocess.Popen(
                ["grep", "--line-buffered", f"[{level_filter}]"],
                stdin=tail_proc.stdout,
            )
            try:
                grep_proc.wait()
            except KeyboardInterrupt:
                pass
            finally:
                # Always clean up both processes to prevent zombies
                for proc in (grep_proc, tail_proc):
                    try:
                        proc.terminate()
                        proc.wait(timeout=3)
                    except Exception:
                        proc.kill()
        elif level_filter:
            # Static read — tail N lines then filter
            result = subprocess.run(
                ["tail", "-n", str(tail_n), str(log_file)],
                capture_output=True, text=True,
            )
            for line in result.stdout.splitlines():
                if f"[{level_filter}]" in line:
                    print(line)
        else:
            # Plain tail — configurable number of lines
            subprocess.run(["tail", "-n", str(tail_n), str(log_file)])

    elif args.command == "update":
        from antaris_agent.core.updater import Updater
        updater = Updater()
        check_only = getattr(args, "check", False)

        if check_only:
            available, installed, latest = updater.is_update_available()
            print(f"📦 Installed: v{installed}")
            if latest == installed:
                print("✅ You are up to date.")
            elif available:
                print(f"⬆️  Latest:    v{latest}")
                print(f"   Run `antaris update` to upgrade.")
            else:
                print(f"   Latest:    v{latest}")
                print("✅ You are up to date.")
        else:
            available, installed, latest = updater.is_update_available()
            if not available:
                print(f"✅ Antaris v{installed} is already up to date.")
            else:
                print(f"⬆️  Updating Antaris v{installed} → v{latest}…")
            success = updater.update()
            if success:
                print("✅ Update complete.")
                print("   Run `antaris restart` to apply the update.")
            else:
                print("❌ Update failed. Check the output above for details.")

    elif args.command == "uninstall":
        rc = _cmd_uninstall(remove_config=getattr(args, "remove_config", False))
        sys.exit(rc)

    elif args.command == "reinstall":
        rc = _cmd_reinstall()
        sys.exit(rc)

    elif args.command == "install-service":
        rc = _cmd_install_service()
        sys.exit(rc)

    elif args.command == "uninstall-service":
        rc = _cmd_uninstall_service()
        sys.exit(rc)

    elif args.command == "security":
        _cmd_security_status()

    elif args.command == "doctor":
        _doctor_name = getattr(args, "name", None)
        if _doctor_name and not getattr(args, "config_dir", None):
            _doctor_dir = _resolve_named_instance(_doctor_name)
            if _doctor_dir:
                os.environ["ANTARIS_CONFIG_DIR"] = _doctor_dir
                PID_FILE = Path(_doctor_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_doctor_name}' not found.")
                sys.exit(1)
        _cmd_doctor()

    elif args.command == "tools":
        _cmd_tools(getattr(args, "action", "list"))

    elif args.command == "telemetry":
        from antaris_agent.tools.telemetry_export import run_export
        fmt = getattr(args, "action", "summary")
        if fmt == "export":
            fmt = "csv"  # 'export' is an alias for csv
        result = run_export(
            format=fmt,
            agent=getattr(args, "agent", None),
            output_path=getattr(args, "output", None),
        )
        print(result)

    elif args.command == "sessions":
        action = getattr(args, "action", "list")
        config_dir = _resolve_config_dir()
        if action == "list":
            # Show all known sessions
            sessions_file = config_dir / "sessions.json"
            if sessions_file.exists():
                import json
                try:
                    sessions = json.loads(sessions_file.read_text())
                except (json.JSONDecodeError, OSError) as e:
                    print(f"Error reading sessions file: {e}")
                    return
                if isinstance(sessions, list):
                    print(f"Active sessions: {len(sessions)}")
                    for s in sessions[:20]:
                        sid = s.get("id", s.get("session_id", "?"))
                        channel = s.get("channel", s.get("channel_id", "?"))
                        msgs = s.get("message_count", len(s.get("messages", [])))
                        print(f"  {sid[:20]:20s}  channel={channel}  msgs={msgs}")
                elif isinstance(sessions, dict):
                    print(f"Sessions: {len(sessions)} entries")
                    for k, v in list(sessions.items())[:20]:
                        print(f"  {k}")
            else:
                print(f"No sessions file at {sessions_file}")
        elif action == "awareness":
            # Show which agents share the same memory store
            import json
            registry_file = Path.home() / ".antaris" / ".instances.json"
            if not registry_file.exists():
                print("No instance registry found.")
            else:
                try:
                    registry = json.loads(registry_file.read_text())
                except (json.JSONDecodeError, OSError) as e:
                    print(f"Error reading instance registry: {e}")
                    return
                stores = {}
                for name, path in registry.items():
                    cfg_path = Path(path) / "config.json"
                    if cfg_path.exists():
                        try:
                            cfg = json.loads(cfg_path.read_text())
                        except (json.JSONDecodeError, OSError):
                            continue
                        store = cfg.get("memory", {}).get("store", "default")
                        sa = cfg.get("memory", {}).get("sessionAwareness", "off")
                        ambient = cfg.get("memory", {}).get("ambientAwareness", False)
                        model = cfg.get("model", "?")
                        stores.setdefault(store, []).append({
                            "name": name, "model": model,
                            "session_awareness": sa, "ambient": ambient,
                        })
                
                print("=== Session Awareness Map ===\n")
                for store_path, agents in stores.items():
                    store_name = Path(store_path).name if "/" in store_path else store_path
                    print(f"Store: {store_name}")
                    print(f"  Agents ({len(agents)}):")
                    for a in agents:
                        status = []
                        if a["session_awareness"] != "off":
                            status.append(f"session={a['session_awareness']}")
                        if a["ambient"]:
                            status.append("ambient=✅")
                        flags = " | ".join(status) if status else "isolated"
                        print(f"    {a['name']:15s}  {a['model']:20s}  {flags}")
                    
                    # Show awareness matrix
                    aware_agents = [a for a in agents if a["session_awareness"] != "off"]
                    if len(aware_agents) > 1:
                        print(f"\n  Shared awareness: {' ↔ '.join(a['name'] for a in aware_agents)}")
                    print()

    else:
        print(f"Unknown command: '{args.command}'. Run 'antaris --help' for available commands.")


if __name__ == "__main__":
    main()
