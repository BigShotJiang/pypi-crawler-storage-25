"""
parsica_memory.contracts — Substrate contracts for Parsica 3.4.8+

Single source of truth for:
  - SourceKind        where content came from
  - RecordKind        what the record IS
  - CrossSessionPolicy  eligibility for cross-session recall
  - RECORD_KIND_DEFAULTS  policy encoded in code, not comments
  - IngestEnvelope    single contract object for ALL ingest paths
  - RecordMeta        stable metadata sidecar
  - RetrievalRequest  explicit retrieval contract  (3.4.6rc)
  - SideEffectMode    read/write discipline         (3.4.6rc)
  - RetrievedItem     structured retrieval unit     (3.4.6rc)
  - RetrievalTrace    structured trace              (3.4.6rc)

Version: 3.4.8
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TruthState(str, Enum):
    """Truth-state of a memory record (v2.8.0: Memory Lineage Foundation)."""
    ACCEPTED    = "accepted"    # live, trusted record
    SUPERSEDED  = "superseded"  # replaced by a newer record (de-prioritize in retrieval)
    RETRACTED   = "retracted"   # withdrawn; exclude from default live retrieval


class SourceKind(str, Enum):
    """Where the content originated."""
    CONVERSATION  = "conversation"   # live turn in a chat session
    PIPELINE      = "pipeline"       # agent_turn / automated pipeline
    DOCUMENT      = "document"       # ingested file / URL
    STRUCTURED    = "structured"     # structured data import
    SUBAGENT      = "subagent"       # output from a child subagent
    SYSTEM        = "system"         # system-generated (heartbeat, compaction, etc.)
    MANUAL        = "manual"         # operator-typed inline ingest
    MIGRATION     = "migration"      # data imported from legacy format
    UNKNOWN       = "unknown"


class RecordKind(str, Enum):
    """What the record IS semantically."""
    TURN        = "turn"        # raw conversation turn — episodic, local-only
    FACT        = "fact"        # durable knowledge — cross-session eligible
    MISTAKE     = "mistake"     # durable knowledge — cross-session eligible
    PREFERENCE  = "preference"  # durable knowledge — cross-session eligible
    PROCEDURE   = "procedure"   # durable knowledge — cross-session eligible
    SUMMARY     = "summary"     # selectively eligible — depends on scope
    DOCUMENT    = "document"    # ingested doc chunk — local-only by default
    SYSTEM      = "system"      # system-generated entries
    UNKNOWN     = "unknown"


class CrossSessionPolicy(str, Enum):
    """
    Eligibility for recall across session boundaries.

    local_only     — only the originating session can recall this
    knowledge_only — other sessions can recall only durable-knowledge records
    all            — no cross-session filter applied
    inherit        — defer to the system default (usually knowledge_only)
    """
    LOCAL_ONLY     = "local_only"
    KNOWLEDGE_ONLY = "knowledge_only"
    ALL            = "all"
    INHERIT        = "inherit"


# ---------------------------------------------------------------------------
# Policy table: encoded in code, not comments
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _RecordPolicy:
    cross_session_eligible: bool
    default_cross_session_policy: CrossSessionPolicy
    enrichable: bool            # can be enriched by LLM post-ingest
    description: str


RECORD_KIND_DEFAULTS: Dict[RecordKind, _RecordPolicy] = {
    RecordKind.TURN: _RecordPolicy(
        cross_session_eligible=False,
        default_cross_session_policy=CrossSessionPolicy.LOCAL_ONLY,
        enrichable=True,
        description="Raw conversation turn — episodic, local only",
    ),
    RecordKind.FACT: _RecordPolicy(
        cross_session_eligible=True,
        default_cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
        enrichable=True,
        description="Durable knowledge fact — cross-session eligible",
    ),
    RecordKind.MISTAKE: _RecordPolicy(
        cross_session_eligible=True,
        default_cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
        enrichable=True,
        description="Durable mistake/correction — cross-session eligible",
    ),
    RecordKind.PREFERENCE: _RecordPolicy(
        cross_session_eligible=True,
        default_cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
        enrichable=True,
        description="Durable user preference — cross-session eligible",
    ),
    RecordKind.PROCEDURE: _RecordPolicy(
        cross_session_eligible=True,
        default_cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
        enrichable=True,
        description="Durable procedure/workflow — cross-session eligible",
    ),
    RecordKind.SUMMARY: _RecordPolicy(
        cross_session_eligible=True,
        default_cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
        enrichable=False,
        description="Compressed session/topic summary — selectively cross-session",
    ),
    RecordKind.DOCUMENT: _RecordPolicy(
        cross_session_eligible=False,
        default_cross_session_policy=CrossSessionPolicy.LOCAL_ONLY,
        enrichable=True,
        description="Ingested document chunk — local only by default",
    ),
    RecordKind.SYSTEM: _RecordPolicy(
        cross_session_eligible=False,
        default_cross_session_policy=CrossSessionPolicy.LOCAL_ONLY,
        enrichable=False,
        description="System-generated entry — not eligible",
    ),
    RecordKind.UNKNOWN: _RecordPolicy(
        cross_session_eligible=False,
        default_cross_session_policy=CrossSessionPolicy.LOCAL_ONLY,
        enrichable=True,
        description="Unknown record kind — conservative defaults",
    ),
}


def default_policy(kind: RecordKind) -> _RecordPolicy:
    """Return the default policy for a RecordKind, with safe fallback."""
    return RECORD_KIND_DEFAULTS.get(kind, RECORD_KIND_DEFAULTS[RecordKind.UNKNOWN])


def is_durable_knowledge(kind: RecordKind) -> bool:
    """Return True iff this record kind represents durable knowledge.

    Replaces the broken ``cross_session_recall == "semantic"`` gate:
    instead of checking a pseudo-type, check actual record kind.
    """
    return default_policy(kind).cross_session_eligible


# ---------------------------------------------------------------------------
# IngestEnvelope — single contract for ALL ingest paths
# ---------------------------------------------------------------------------

@dataclass
class IngestEnvelope:
    """
    Single contract object for all ingest paths.

    Every call to parsica_memory ingest MUST build an IngestEnvelope first.
    The envelope encodes:
      - who/where the content came from (provenance)
      - what kind of record this is (RecordKind)
      - what cross-session policy applies
      - the raw content
      - optional derived facts / child envelopes

    Version: 3.4.8
    """

    # --- Identity / provenance -----------------------------------------------
    envelope_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    # Who
    user_id: str = ""
    agent_id: str = ""
    session_id: str = ""
    channel_id: str = ""          # canonical — replaces source_channel at boundary

    # Where the content came from
    source_kind: SourceKind = SourceKind.UNKNOWN
    source_label: str = ""        # human-readable ("discord:1234", "file:/path", …)
    source_url: Optional[str] = None

    # --- Record semantics ----------------------------------------------------
    record_kind: RecordKind = RecordKind.UNKNOWN

    # Declared by caller; inferred_kind set by enricher post-ingest
    declared_kind: Optional[RecordKind] = None
    inferred_kind: Optional[RecordKind] = None
    kind_confidence: float = 0.0  # 0–1 confidence in inferred_kind

    # --- Content -------------------------------------------------------------
    content: str = ""
    content_hash: Optional[str] = None  # set automatically if not provided

    # --- Cross-session policy ------------------------------------------------
    cross_session_policy: CrossSessionPolicy = CrossSessionPolicy.INHERIT
    cross_session_eligible: Optional[bool] = None  # None = derive from policy

    # --- Lineage / parent relationships --------------------------------------
    parent_ids: List[str] = field(default_factory=list)
    envelope_parent_id: Optional[str] = None  # parent envelope if this is a child

    # --- Optional structured metadata ----------------------------------------
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # --- Derived child envelopes (e.g. facts extracted from a turn) ----------
    children: List["IngestEnvelope"] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Auto-derive record_kind from declared_kind if not set
        if self.record_kind == RecordKind.UNKNOWN and self.declared_kind is not None:
            self.record_kind = self.declared_kind

        # Resolve cross_session_eligible from policy if not explicitly set
        if self.cross_session_eligible is None:
            if self.cross_session_policy == CrossSessionPolicy.INHERIT:
                self.cross_session_eligible = default_policy(
                    self.record_kind
                ).cross_session_eligible
            elif self.cross_session_policy == CrossSessionPolicy.LOCAL_ONLY:
                self.cross_session_eligible = False
            elif self.cross_session_policy == CrossSessionPolicy.ALL:
                self.cross_session_eligible = True
            elif self.cross_session_policy == CrossSessionPolicy.KNOWLEDGE_ONLY:
                self.cross_session_eligible = is_durable_knowledge(self.record_kind)

        # Canonicalize: if caller passed channel_id as empty but source_label
        # has a channel component, leave source_label intact — unification
        # happens at the wrapper boundary, not here.

    # --- Convenience constructors --------------------------------------------

    @classmethod
    def for_turn(
        cls,
        content: str,
        session_id: str = "",
        user_id: str = "",
        agent_id: str = "",
        channel_id: str = "",
        source_label: str = "conversation",
    ) -> "IngestEnvelope":
        """Construct an envelope for a raw conversation turn.

        Turns are ALWAYS local-only and episodic.
        They must NOT be split into line fragments.
        """
        return cls(
            content=content,
            source_kind=SourceKind.CONVERSATION,
            source_label=source_label,
            record_kind=RecordKind.TURN,
            declared_kind=RecordKind.TURN,
            cross_session_policy=CrossSessionPolicy.LOCAL_ONLY,
            cross_session_eligible=False,
            session_id=session_id,
            user_id=user_id,
            agent_id=agent_id,
            channel_id=channel_id,
        )

    @classmethod
    def for_fact(
        cls,
        content: str,
        session_id: str = "",
        agent_id: str = "",
        channel_id: str = "",
        source_label: str = "fact",
        parent_envelope_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> "IngestEnvelope":
        """Construct an envelope for a durable knowledge fact."""
        return cls(
            content=content,
            source_kind=SourceKind.PIPELINE,
            source_label=source_label,
            record_kind=RecordKind.FACT,
            declared_kind=RecordKind.FACT,
            cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
            cross_session_eligible=True,
            session_id=session_id,
            agent_id=agent_id,
            channel_id=channel_id,
            envelope_parent_id=parent_envelope_id,
            tags=tags or [],
        )

    @classmethod
    def for_mistake(
        cls,
        content: str,
        session_id: str = "",
        agent_id: str = "",
        channel_id: str = "",
        source_label: str = "mistake",
        parent_envelope_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> "IngestEnvelope":
        """Construct an envelope for a durable mistake/correction."""
        return cls(
            content=content,
            source_kind=SourceKind.PIPELINE,
            source_label=source_label,
            record_kind=RecordKind.MISTAKE,
            declared_kind=RecordKind.MISTAKE,
            cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
            cross_session_eligible=True,
            session_id=session_id,
            agent_id=agent_id,
            channel_id=channel_id,
            envelope_parent_id=parent_envelope_id,
            tags=tags or [],
        )

    @classmethod
    def for_preference(
        cls,
        content: str,
        session_id: str = "",
        agent_id: str = "",
        channel_id: str = "",
        source_label: str = "preference",
        tags: Optional[List[str]] = None,
    ) -> "IngestEnvelope":
        """Construct an envelope for a durable user preference."""
        return cls(
            content=content,
            source_kind=SourceKind.PIPELINE,
            source_label=source_label,
            record_kind=RecordKind.PREFERENCE,
            declared_kind=RecordKind.PREFERENCE,
            cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
            cross_session_eligible=True,
            session_id=session_id,
            agent_id=agent_id,
            channel_id=channel_id,
            tags=tags or [],
        )

    @classmethod
    def for_procedure(
        cls,
        content: str,
        session_id: str = "",
        agent_id: str = "",
        channel_id: str = "",
        source_label: str = "procedure",
        tags: Optional[List[str]] = None,
    ) -> "IngestEnvelope":
        """Construct an envelope for a durable procedure."""
        return cls(
            content=content,
            source_kind=SourceKind.PIPELINE,
            source_label=source_label,
            record_kind=RecordKind.PROCEDURE,
            declared_kind=RecordKind.PROCEDURE,
            cross_session_policy=CrossSessionPolicy.KNOWLEDGE_ONLY,
            cross_session_eligible=True,
            session_id=session_id,
            agent_id=agent_id,
            channel_id=channel_id,
            tags=tags or [],
        )

    # --- Serialization -------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "envelope_id": self.envelope_id,
            "created_at": self.created_at,
            "content": self.content,
            "record_kind": self.record_kind.value,
            "source_kind": self.source_kind.value,
            "source_label": self.source_label,
            "cross_session_policy": self.cross_session_policy.value,
            "cross_session_eligible": self.cross_session_eligible,
        }
        if self.user_id:
            d["user_id"] = self.user_id
        if self.agent_id:
            d["agent_id"] = self.agent_id
        if self.session_id:
            d["session_id"] = self.session_id
        if self.channel_id:
            d["channel_id"] = self.channel_id
        if self.source_url:
            d["source_url"] = self.source_url
        if self.content_hash:
            d["content_hash"] = self.content_hash
        if self.declared_kind is not None:
            d["declared_kind"] = self.declared_kind.value
        if self.inferred_kind is not None:
            d["inferred_kind"] = self.inferred_kind.value
        if self.kind_confidence:
            d["kind_confidence"] = self.kind_confidence
        if self.parent_ids:
            d["parent_ids"] = self.parent_ids
        if self.envelope_parent_id:
            d["envelope_parent_id"] = self.envelope_parent_id
        if self.tags:
            d["tags"] = self.tags
        if self.metadata:
            d["metadata"] = self.metadata
        if self.children:
            d["children"] = [c.to_dict() for c in self.children]
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "IngestEnvelope":
        env = cls(
            envelope_id=d.get("envelope_id", str(uuid.uuid4())),
            created_at=d.get("created_at", datetime.now(timezone.utc).isoformat()),
            content=d.get("content", ""),
            record_kind=RecordKind(d.get("record_kind", RecordKind.UNKNOWN.value)),
            source_kind=SourceKind(d.get("source_kind", SourceKind.UNKNOWN.value)),
            source_label=d.get("source_label", ""),
            cross_session_policy=CrossSessionPolicy(
                d.get("cross_session_policy", CrossSessionPolicy.INHERIT.value)
            ),
            cross_session_eligible=d.get("cross_session_eligible"),
            user_id=d.get("user_id", ""),
            agent_id=d.get("agent_id", ""),
            session_id=d.get("session_id", ""),
            channel_id=d.get("channel_id", ""),
            source_url=d.get("source_url"),
            content_hash=d.get("content_hash"),
            declared_kind=RecordKind(d["declared_kind"]) if d.get("declared_kind") else None,
            inferred_kind=RecordKind(d["inferred_kind"]) if d.get("inferred_kind") else None,
            kind_confidence=d.get("kind_confidence", 0.0),
            parent_ids=d.get("parent_ids", []),
            envelope_parent_id=d.get("envelope_parent_id"),
            tags=d.get("tags", []),
            metadata=d.get("metadata", {}),
        )
        children_data = d.get("children", [])
        env.children = [cls.from_dict(c) for c in children_data]
        return env

    def __repr__(self) -> str:
        return (
            f"<IngestEnvelope id={self.envelope_id[:8]} "
            f"kind={self.record_kind.value} "
            f"xsession={self.cross_session_eligible} "
            f"content={self.content[:40]!r}>"
        )


# ---------------------------------------------------------------------------
# v2.9.1: RetrievalScope, ScopePolicy, TRUTH_STATE_WEIGHTS
# ---------------------------------------------------------------------------

class RetrievalScope(str, Enum):
    BODY_LOCAL       = "body_local"
    IDENTITY_DURABLE = "identity_durable"
    HANDOFF_VISIBLE  = "handoff_visible"


TRUTH_STATE_WEIGHTS: dict = {
    "accepted":   1.0,
    "superseded": 0.5,
    "retracted":  0.0,
}

# v3.0: record lifecycle state weights and sets
RECORD_STATE_WEIGHTS = {
    "active":      1.0,
    "deprecated":  0.25,
    "do_not_use":  0.0,
    "purged":      0.0,
}

EXCLUDED_RECORD_STATES = frozenset({"do_not_use", "purged"})
VALID_RECORD_STATES = frozenset({"active", "deprecated", "do_not_use", "purged"})


@dataclass(frozen=True)
class ScopePolicy:
    allowed_scopes: frozenset = frozenset({"identity_durable", "handoff_visible", "body_local"})
    identity_id: str = ""
    body_id: str = ""
    exclude_truth_states: frozenset = frozenset({"retracted"})
    half_weight_truth_states: frozenset = frozenset({"superseded"})
    prefer_newest_accepted: bool = True


def make_default_scope_policy(
    identity_id: str,
    body_id: str,
    *,
    include_body_local: bool = True,
) -> "ScopePolicy":
    """Required in all real app paths. scope_policy=None is legacy only."""
    allowed = {"identity_durable", "handoff_visible"}
    if include_body_local:
        allowed.add("body_local")
    return ScopePolicy(
        allowed_scopes=frozenset(allowed),
        identity_id=identity_id,
        body_id=body_id,
        exclude_truth_states=frozenset({"retracted"}),
        half_weight_truth_states=frozenset({"superseded"}),
        prefer_newest_accepted=True,
    )


# ---------------------------------------------------------------------------
# Background tasks — journal/runner contract
# ---------------------------------------------------------------------------

@dataclass
class BackgroundTask:
    """Background task record persisted by the task journal."""
    task_id: str
    kind: str
    dedupe_key: str
    payload: Dict[str, Any]
    created_at: str
    updated_at: str
    state: str = "queued"
    worker_id: str = ""
    lease_until: str = ""
    attempt: int = 0
    max_attempts: int = 3
    priority: int = 0
    last_error: str = ""
    result: Dict[str, Any] = field(default_factory=dict)

    _VALID_STATES = frozenset({"queued", "running", "done", "failed", "cancelled", "obsolete", "dead_letter"})

    def __post_init__(self) -> None:
        if not self.task_id:
            raise ValueError("BackgroundTask.task_id must not be empty")
        if not self.kind:
            raise ValueError("BackgroundTask.kind must not be empty")
        if self.state not in self._VALID_STATES:
            raise ValueError(
                f"BackgroundTask.state must be one of {sorted(self._VALID_STATES)}, "
                f"got {self.state!r}"
            )


# ---------------------------------------------------------------------------
# RecordMeta — stable metadata sidecar (sidecar-first, backward-compatible)
# ---------------------------------------------------------------------------

@dataclass
class RecordMeta:
    """
    Stable metadata for a stored record.  Persisted as a sidecar;
    lazily backfilled on load / touch.  Does NOT force a storage rewrite.

    Version: 3.4.8
    """
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content_hash: Optional[str] = None
    origin_id: Optional[str] = None        # envelope_id that created this record
    parent_ids: List[str] = field(default_factory=list)
    record_kind: RecordKind = RecordKind.UNKNOWN
    memory_type: str = "episodic"          # legacy field kept for compat
    provenance: str = "self"
    user_id: str = ""
    agent_id: str = ""
    session_id: str = ""
    channel_id: str = ""
    cross_session_eligible: bool = False
    created_at: Optional[str] = None
    last_seen_at: Optional[str] = None
    state: str = "active"                  # active | deprecated | do_not_use | purged
    family_id: Optional[str] = None        # reserved for 3.6a claim shell

    _VALID_STATES = frozenset({"active", "deprecated", "do_not_use", "purged"})

    def __post_init__(self) -> None:
        if not self.record_id:
            raise ValueError("RecordMeta.record_id must not be empty")
        if self.state not in self._VALID_STATES:
            raise ValueError(
                f"RecordMeta.state must be one of {sorted(self._VALID_STATES)}, "
                f"got {self.state!r}"
            )

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "record_id": self.record_id,
            "record_kind": self.record_kind.value,
            "memory_type": self.memory_type,
            "cross_session_eligible": self.cross_session_eligible,
            "state": self.state,
        }
        for attr in (
            "content_hash", "origin_id", "provenance",
            "user_id", "agent_id", "session_id", "channel_id",
            "created_at", "last_seen_at", "family_id",
        ):
            v = getattr(self, attr)
            if v:
                d[attr] = v
        if self.parent_ids:
            d["parent_ids"] = self.parent_ids
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RecordMeta":
        return cls(
            record_id=d.get("record_id", str(uuid.uuid4())),
            content_hash=d.get("content_hash"),
            origin_id=d.get("origin_id"),
            parent_ids=d.get("parent_ids", []),
            record_kind=RecordKind(d.get("record_kind", RecordKind.UNKNOWN.value)),
            memory_type=d.get("memory_type", "episodic"),
            provenance=d.get("provenance", "self"),
            user_id=d.get("user_id", ""),
            agent_id=d.get("agent_id", ""),
            session_id=d.get("session_id", ""),
            channel_id=d.get("channel_id", ""),
            cross_session_eligible=d.get("cross_session_eligible", False),
            created_at=d.get("created_at"),
            last_seen_at=d.get("last_seen_at"),
            state=d.get("state", "active"),
            family_id=d.get("family_id"),
        )


# ---------------------------------------------------------------------------
# 3.4.6rc stubs — RetrievalRequest, SideEffectMode, RetrievedItem,
#                 RetrievalTrace   (implementations filled in 3.4.6)
# ---------------------------------------------------------------------------

class SideEffectMode(str, Enum):
    """
    Controls what a retrieval call is allowed to mutate.

    pure_read       — zero writes, zero access-count bumps
    retrieved_only  — bump access counts for retrieved items only
    used_only       — bump only items the caller marks as used
    reinforce       — full reinforcement (almost never the default)
    """
    PURE_READ      = "pure_read"
    RETRIEVED_ONLY = "retrieved_only"
    USED_ONLY      = "used_only"
    REINFORCE      = "reinforce"


class RetrievalPurpose(str, Enum):
    """Explicit purpose for a retrieval call."""
    USER_ANSWER   = "user_answer"
    CONTEXT_PACK  = "context_pack"
    HANDOFF       = "handoff"
    ROUTING       = "routing"
    AUDIT         = "audit"
    BACKGROUND    = "background"
    UNKNOWN       = "unknown"


# Default side-effect mode per purpose (encoded in code, not comments)
PURPOSE_SIDE_EFFECT_DEFAULTS: Dict[RetrievalPurpose, SideEffectMode] = {
    RetrievalPurpose.USER_ANSWER:  SideEffectMode.RETRIEVED_ONLY,
    RetrievalPurpose.CONTEXT_PACK: SideEffectMode.PURE_READ,
    RetrievalPurpose.HANDOFF:      SideEffectMode.PURE_READ,
    RetrievalPurpose.ROUTING:      SideEffectMode.PURE_READ,
    RetrievalPurpose.AUDIT:        SideEffectMode.PURE_READ,
    RetrievalPurpose.BACKGROUND:   SideEffectMode.PURE_READ,
    RetrievalPurpose.UNKNOWN:      SideEffectMode.PURE_READ,
}


@dataclass
class RetrievalRequest:
    """
    Explicit contract for all retrieval calls.

    Version: 3.4.6rc
    """
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query: str = ""
    purpose: RetrievalPurpose = RetrievalPurpose.UNKNOWN
    user_id: str = ""
    agent_id: str = ""
    session_id: str = ""
    channel_id: str = ""
    limit: int = 10
    min_confidence: float = 0.0
    cross_session_policy: CrossSessionPolicy = CrossSessionPolicy.INHERIT
    side_effect_mode: Optional[SideEffectMode] = None   # None = derive from purpose
    query_mode: str = "auto"           # "auto|recent|semantic|precision|evidence|deep"
    allow_refinement: bool = True
    max_refinement_steps: int = 2
    max_qte_time_ms: int = 250
    prefer_child_records: bool = False
    prefer_parent_records: bool = False
    persist_trace: bool = False
    persist_diagnostics: bool = False
    tags: List[str] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)
    scope_policy: Optional["ScopePolicy"] = None  # v2.9.1: scope filter policy

    def __post_init__(self) -> None:
        if self.side_effect_mode is None:
            self.side_effect_mode = PURPOSE_SIDE_EFFECT_DEFAULTS.get(
                self.purpose, SideEffectMode.PURE_READ
            )
        _VALID_MODES = {"auto", "recent", "semantic", "precision", "evidence", "deep"}
        if self.query_mode not in _VALID_MODES:
            raise ValueError(
                f"RetrievalRequest.query_mode must be one of {sorted(_VALID_MODES)}, "
                f"got {self.query_mode!r}"
            )
        if self.limit < 1:
            raise ValueError(
                f"RetrievalRequest.limit must be >= 1, got {self.limit}"
            )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "query": self.query,
            "purpose": self.purpose.value,
            "user_id": self.user_id,
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "channel_id": self.channel_id,
            "limit": self.limit,
            "min_confidence": self.min_confidence,
            "cross_session_policy": self.cross_session_policy.value,
            "side_effect_mode": self.side_effect_mode.value if self.side_effect_mode else None,
            "query_mode": self.query_mode,
            "allow_refinement": self.allow_refinement,
            "max_refinement_steps": self.max_refinement_steps,
            "max_qte_time_ms": self.max_qte_time_ms,
            "prefer_child_records": self.prefer_child_records,
            "prefer_parent_records": self.prefer_parent_records,
            "persist_trace": self.persist_trace,
            "persist_diagnostics": self.persist_diagnostics,
            "tags": self.tags,
            "filters": self.filters,
        }


@dataclass
class RetrievedItem:
    """
    Structured retrieval unit. Internal pipeline uses this — legacy
    adapters can flatten to plain content strings at the boundary.

    Version: 3.4.6rc
    """
    record_id: str = ""
    content: str = ""
    memory_type: str = "episodic"
    record_kind: RecordKind = RecordKind.UNKNOWN
    source_label: str = ""
    score: float = 0.0
    matched_terms: List[str] = field(default_factory=list)
    reasoning: str = ""
    trace_path: List[str] = field(default_factory=list)
    cross_session_eligible: bool = False

    def __post_init__(self) -> None:
        if self.score < 0.0:
            raise ValueError(
                f"RetrievedItem.score must be >= 0.0, got {self.score}"
            )
        if not self.record_id:
            raise ValueError("RetrievedItem.record_id must not be empty")

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "record_id": self.record_id,
            "content": self.content,
            "memory_type": self.memory_type,
            "record_kind": self.record_kind.value,
            "score": round(self.score, 4),
            "cross_session_eligible": self.cross_session_eligible,
        }
        if self.source_label:
            d["source_label"] = self.source_label
        if self.matched_terms:
            d["matched_terms"] = self.matched_terms
        if self.reasoning:
            d["reasoning"] = self.reasoning
        if self.trace_path:
            d["trace_path"] = self.trace_path
        return d


@dataclass
class RetrievalTrace:
    """
    Structured execution trace for a retrieval call.
    Persisted as JSONL sidecars.

    Version: 3.4.6rc
    """
    request_id: str = ""
    query: str = ""
    purpose: RetrievalPurpose = RetrievalPurpose.UNKNOWN
    chosen_mode: str = ""
    candidate_budget: int = 0
    rerank_budget: int = 0
    steps: List[Dict[str, Any]] = field(default_factory=list)
    result_ids: List[str] = field(default_factory=list)
    stop_reason: str = ""
    mutations: List[str] = field(default_factory=list)
    qte_mode: str = ""
    qte_fingerprint: dict = field(default_factory=dict)
    qte_features: dict = field(default_factory=dict)
    qte_refinement_steps: list = field(default_factory=list)
    total_time_ms: float = 0.0
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def __post_init__(self) -> None:
        if self.total_time_ms < 0.0:
            raise ValueError(
                f"RetrievalTrace.total_time_ms must be >= 0.0, got {self.total_time_ms}"
            )

    def add_step(self, name: str, count: int = 0, elapsed_ms: float = 0.0,
                 detail: Optional[str] = None) -> None:
        step: Dict[str, Any] = {"name": name, "count": count, "elapsed_ms": elapsed_ms}
        if detail:
            step["detail"] = detail
        self.steps.append(step)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "query": self.query,
            "purpose": self.purpose.value,
            "chosen_mode": self.chosen_mode,
            "candidate_budget": self.candidate_budget,
            "rerank_budget": self.rerank_budget,
            "steps": self.steps,
            "result_ids": self.result_ids,
            "stop_reason": self.stop_reason,
            "mutations": self.mutations,
            "qte_mode": self.qte_mode,
            "qte_fingerprint": self.qte_fingerprint,
            "qte_features": self.qte_features,
            "qte_refinement_steps": self.qte_refinement_steps,
            "total_time_ms": round(self.total_time_ms, 2),
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Shared predicate (v2.9.9 — extracted from active_memory + context_assembler)
# ---------------------------------------------------------------------------

def surfaceable(entry) -> bool:
    """Check if a memory entry should be surfaced (not retracted/deprecated/do_not_use/purged).

    Single source of truth — used by ActiveMemory, ContextAssembler, and any
    future caller that needs to filter out suppressed/removed entries.
    """
    ts = (getattr(entry, "truth_state", "accepted") or "accepted").lower()
    state = (getattr(entry, "state", "active") or "active").lower()
    return ts != "retracted" and state not in ("do_not_use", "purged", "deprecated")
