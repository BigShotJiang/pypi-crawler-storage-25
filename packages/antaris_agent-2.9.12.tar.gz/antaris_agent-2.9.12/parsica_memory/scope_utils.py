"""
parsica_memory.scope_utils — Shared helpers for body scoping and deterministic ordering.
Single source of truth imported by pipeline.py, core_v4.py, and contracts.py.
v2.9.1
"""
import hashlib
import json
from datetime import datetime, timezone
from typing import Any


def compute_body_id(agent_name: str, source_channel: str, channel_id: str, session_id: str) -> str:
    """Canonical body_id — imported by pipeline, ingest, and policy factory. No drift."""
    channel_key = source_channel or channel_id or session_id
    return f"{agent_name}:{channel_key}"


def infer_retrieval_scope(entry) -> str:
    """Infer retrieval_scope from record_kind/memory_type for legacy entries.

    Conservative mapping: unknown/document kinds default to body_local (not identity_durable)
    to prevent accidental cross-body leakage of unclassified entries.
    """
    kind = (getattr(entry, "record_kind", "") or getattr(entry, "memory_type", "") or "").lower()
    if kind in {"turn", "system", "document", "unknown", ""}:
        return "body_local"
    if kind in {"fact", "preference", "procedure", "mistake", "summary"}:
        return "identity_durable"
    if kind in {"handoff", "ambient_event"}:
        return "handoff_visible"
    # Conservative default: unknown kinds stay local
    return "body_local"


def normalize_loaded_entry(entry) -> Any:
    """Normalize a loaded MemoryEntry: backfill blank/invalid scope, stamp __legacy_unknown_body__."""
    scope = str(getattr(entry, "retrieval_scope", "") or "").strip()
    if not scope or scope not in {"body_local", "identity_durable", "handoff_visible"}:
        entry.retrieval_scope = infer_retrieval_scope(entry)
    if entry.retrieval_scope == "body_local" and not getattr(entry, "body_id", ""):
        entry.body_id = "__legacy_unknown_body__"
    return entry


def stable_hit_sort_key(hit) -> tuple:
    """Deterministic sort key for retrieval hits."""
    try:
        ts = getattr(hit, "created", None) or getattr(hit, "created_at", None) or ""
        if not ts and hasattr(hit, "entry"):
            e = hit.entry
            ts = getattr(e, "created", None) or getattr(e, "created_at", None) or ""
        if ts:
            epoch = datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp()
        else:
            epoch = 0.0
    except Exception:
        epoch = 0.0
    score = float(getattr(hit, "score", 0.0))
    rid = str(getattr(hit, "record_id", "") or (hasattr(hit, "entry") and getattr(hit.entry, "record_id", "")) or getattr(hit, "hash", "") or "")
    return (-score, -epoch, rid)


def stable_event_sort_key(ev) -> tuple:
    """Deterministic sort key for ambient events."""
    try:
        ts = getattr(ev, "published_at", "") or ""
        epoch = datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp() if ts else 0.0
    except Exception:
        epoch = 0.0
    return (-epoch, str(getattr(ev, "event_id", "")))


def stable_hash(obj: dict) -> str:
    """SHA256 of normalized JSON — determinism proof for assembly_hash and activation_hash."""
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
