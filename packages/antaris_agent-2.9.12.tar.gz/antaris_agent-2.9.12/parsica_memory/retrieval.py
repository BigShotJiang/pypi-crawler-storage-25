"""
parsica_memory.retrieval — 3.4.6rc: Read/write access policy + retrieval traces

Provides:
  - retrieve()  — structured retrieval via RetrievalRequest
  - trace persistence as JSONL sidecars in <workspace>/_meta/retrieval_traces/
  - pure-read enforcement for context_pack / handoff / routing / audit / background
  - RetrievedItem wrapping of raw search results
  - load_retrieval_traces() — load recent traces across date files

Version: 3.4.6rc
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from .contracts import (
    RetrievalRequest,
    RetrievalPurpose,
    SideEffectMode,
    RetrievedItem,
    RetrievalTrace,
    RecordKind,
    CrossSessionPolicy,
    is_durable_knowledge,
)

if TYPE_CHECKING:
    from .core_v4 import MemorySystem

logger = logging.getLogger("parsica_memory.retrieval")

# Legacy flat JSONL trace sidecar (kept for backward-compat reads)
TRACE_SIDECAR = "retrieval_traces.jsonl"

# 3.4.6: Directory for date-partitioned retrieval trace sidecars
TRACE_DIR = "_meta/retrieval_traces"

# Max entries per date file before rotation (prevents unbounded growth)
TRACE_MAX_ENTRIES_PER_FILE = 1000

# Purposes that MUST be pure reads — enforced here, not by caller convention
_FORCED_PURE_READ_PURPOSES = frozenset({
    RetrievalPurpose.CONTEXT_PACK,
    RetrievalPurpose.HANDOFF,
    RetrievalPurpose.ROUTING,
    RetrievalPurpose.AUDIT,
    RetrievalPurpose.BACKGROUND,
})


def _execute_retrieval(
    mem: "MemorySystem",
    request: RetrievalRequest,
    persist_trace: bool = True,
) -> tuple[List[RetrievedItem], RetrievalTrace]:
    """Base retrieval implementation shared by plain retrieval and QTE."""
    t_start = time.monotonic()
    trace = RetrievalTrace(
        request_id=request.request_id,
        query=request.query,
        purpose=request.purpose,
        candidate_budget=request.limit * 10,
        rerank_budget=request.limit,
    )

    # --- Enforce pure-read for specific purposes regardless of request -------
    effective_mode = request.side_effect_mode
    if request.purpose in _FORCED_PURE_READ_PURPOSES:
        if effective_mode != SideEffectMode.PURE_READ:
            logger.debug(
                "retrieve: forcing pure_read for purpose=%s (was %s)",
                request.purpose.value, effective_mode.value if effective_mode else None,
            )
            effective_mode = SideEffectMode.PURE_READ
    trace.chosen_mode = effective_mode.value if effective_mode else "pure_read"

    # --- Cross-session policy -------------------------------------------------
    _cs_policy = request.cross_session_policy
    if _cs_policy == CrossSessionPolicy.INHERIT:
        cross_session_recall = "knowledge_only"
    elif _cs_policy == CrossSessionPolicy.ALL:
        cross_session_recall = "all"
    elif _cs_policy == CrossSessionPolicy.LOCAL_ONLY:
        cross_session_recall = "none"
    else:
        cross_session_recall = "knowledge_only"

    is_pure = (effective_mode == SideEffectMode.PURE_READ)

    trace.add_step("search_start", detail=f"query={request.query!r} limit={request.limit}")

    try:
        try:
            raw_results = mem.search(
                query=request.query,
                limit=request.limit,
                session_id=request.session_id or "*",
                agent_id=request.agent_id or None,
                min_confidence=request.min_confidence,
                read_only=is_pure,
                cross_session_recall=cross_session_recall,
                memory_type=request.filters.get("memory_type"),
                explain=True,  # v2.9.8: get score-bearing SearchResults
                # v2.9.11: removed apply_lifecycle — search() doesn't accept it,
                # was causing TypeError on EVERY call, forcing the fallback path.
                # Lifecycle weighting is applied once in rank_results_version_aware().
            )
        except TypeError:
            # Safety net only — should not fire after removing apply_lifecycle.
            # Keeps all critical params so BM25 scoring is preserved.
            raw_results = mem.search(
                query=request.query,
                limit=request.limit,
                session_id=request.session_id or "*",
                agent_id=request.agent_id or None,
                min_confidence=request.min_confidence,
                read_only=is_pure,
                cross_session_recall=cross_session_recall,
                memory_type=request.filters.get("memory_type"),
                explain=True,
            )
    except Exception as exc:
        trace.stop_reason = f"error: {exc}"
        trace.total_time_ms = (time.monotonic() - t_start) * 1000
        if persist_trace:
            _persist_trace(mem, trace)
        raise

    trace.add_step("search_done", count=len(raw_results))

    # v2.10.0: Always apply lifecycle-aware ranking (scope_policy can be None)
    scope_policy = getattr(request, "scope_policy", None)
    claim_store = getattr(mem, 'claim_store', None)
    raw_results = rank_results_version_aware(raw_results, scope_policy, claim_store=claim_store)
    if scope_policy is not None:
        trace.add_step("scope_rank", count=len(raw_results),
                       detail=f"scope_policy=body_id:{scope_policy.body_id}")
    else:
        trace.add_step("lifecycle_rank", count=len(raw_results))

    items: List[RetrievedItem] = []
    for r in raw_results:
        if hasattr(r, "entry"):
            entry = r.entry
            # v2.10.0: prefer real search score; fall back to importance only
            # if no search score is available (avoids using importance as rank)
            score = getattr(r, "score", None)
            if score is None or score == 0.0:
                score = getattr(r, "importance", 0.0)
            if score is None:
                score = 0.0
        else:
            entry = r
            # v2.10.0: prefer score attribute if present (some callers pass
            # SearchResult-like objects); fall back to importance
            score = getattr(r, "score", None)
            if score is None or score == 0.0:
                score = getattr(r, "importance", 0.0)
            if score is None:
                score = 0.0

        xsession = getattr(entry, "cross_session_eligible", None)
        if xsession is None:
            rk_str = getattr(entry, "record_kind", "")
            try:
                rk = RecordKind(rk_str) if rk_str else RecordKind.UNKNOWN
            except ValueError:
                rk = RecordKind.UNKNOWN
            xsession = is_durable_knowledge(rk)
            if not xsession:
                legacy_type = (getattr(entry, "memory_type", "") or "").lower()
                xsession = legacy_type in {"fact", "mistake", "preference", "procedure"}

        item = RetrievedItem(
            record_id=getattr(entry, "record_id", "") or getattr(entry, "hash", ""),
            content=getattr(entry, "content", ""),
            memory_type=getattr(entry, "memory_type", "episodic"),
            record_kind=RecordKind(
                getattr(entry, "record_kind", RecordKind.UNKNOWN.value) or RecordKind.UNKNOWN.value
            ) if getattr(entry, "record_kind", "") else RecordKind.UNKNOWN,
            source_label=getattr(entry, "source", ""),
            score=score,
            cross_session_eligible=bool(xsession),
        )
        items.append(item)

    trace.result_ids = [i.record_id for i in items]
    trace.add_step("wrap_done", count=len(items))

    if effective_mode == SideEffectMode.RETRIEVED_ONLY and not is_pure:
        _bump_retrieved(mem, raw_results)
        trace.mutations.append(f"bumped_access_count:{len(raw_results)}")
        trace.add_step("access_bump", count=len(raw_results))

    trace.stop_reason = "ok"
    trace.total_time_ms = (time.monotonic() - t_start) * 1000

    if persist_trace:
        _persist_trace(mem, trace)

    return items, trace


def retrieve(
    mem: "MemorySystem",
    request: RetrievalRequest,
    persist_trace: bool = True,
) -> List[RetrievedItem]:
    """
    Execute a retrieval request against a MemorySystem.

    Enforces side-effect policy:
      - PURE_READ  → read_only=True, no access_count bumps
      - RETRIEVED_ONLY → bump access counts for returned items only
      - USED_ONLY  → no automatic bumps; caller must mark used explicitly
      - REINFORCE  → full reinforcement (almost never the default)

    Emits a RetrievalTrace and optionally persists it as a JSONL sidecar.

    Version: 3.4.6rc
    """
    effective_mode = request.side_effect_mode
    if request.purpose in _FORCED_PURE_READ_PURPOSES and effective_mode != SideEffectMode.PURE_READ:
        effective_mode = SideEffectMode.PURE_READ
        request.side_effect_mode = effective_mode

    if effective_mode == SideEffectMode.PURE_READ:
        request.persist_trace = False
        request.persist_diagnostics = False
    else:
        request.persist_trace = bool(getattr(request, "persist_trace", False) or persist_trace)

    # Route to QTE when query_mode is explicitly set (not None/empty/default)
    query_mode = getattr(request, "query_mode", None)
    if query_mode and query_mode != "auto":
        from .query_time_enrichment import run_qte
        return run_qte(mem, request)

    items, _trace = _execute_retrieval(mem, request, persist_trace=getattr(request, 'persist_trace', persist_trace))
    return items


def _bump_retrieved(mem: "MemorySystem", raw_results: list) -> None:
    """Bump access counts for RETRIEVED_ONLY mode."""
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    for r in raw_results:
        entry = r.entry if hasattr(r, "entry") else r
        try:
            entry.access_count = getattr(entry, "access_count", 0) + 1
            entry.last_accessed = now
        except Exception:
            pass
    mem.search_engine.mark_dirty()


def _persist_trace(mem: "MemorySystem", trace: RetrievalTrace) -> None:
    """Append trace to date-partitioned JSONL sidecar in _meta/retrieval_traces/."""
    try:
        from datetime import date as _date
        trace_dir = Path(mem.workspace) / TRACE_DIR
        trace_dir.mkdir(parents=True, exist_ok=True)
        date_file = trace_dir / f"{_date.today().isoformat()}.jsonl"
        with open(date_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace.to_dict()) + "\n")
        # Also write to legacy flat file for backwards compat
        legacy_path = Path(mem.workspace) / TRACE_SIDECAR
        with open(legacy_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace.to_dict()) + "\n")
    except Exception as exc:
        logger.debug("retrieve: failed to persist trace: %s", exc)


def load_traces(workspace: str, limit: int = 100) -> List[RetrievalTrace]:
    """Load the most recent N traces from date-partitioned JSONL sidecars."""
    trace_dir = Path(workspace) / TRACE_DIR
    lines: list = []
    # Read from date-partitioned files (newest first)
    if trace_dir.exists():
        date_files = sorted(trace_dir.glob("*.jsonl"), reverse=True)
        for df in date_files:
            file_lines = df.read_text(encoding="utf-8").strip().splitlines()
            lines = file_lines + lines
            if len(lines) >= limit:
                break
    # Fallback to legacy flat file if no date files exist
    if not lines:
        legacy_path = Path(workspace) / TRACE_SIDECAR
        if legacy_path.exists():
            lines = legacy_path.read_text(encoding="utf-8").strip().splitlines()
    traces = []
    for line in lines[-limit:]:
        try:
            d = json.loads(line)
            t = RetrievalTrace(
                request_id=d.get("request_id", ""),
                query=d.get("query", ""),
                purpose=RetrievalPurpose(d.get("purpose", "unknown")),
                chosen_mode=d.get("chosen_mode", ""),
                candidate_budget=d.get("candidate_budget", 0),
                rerank_budget=d.get("rerank_budget", 0),
                steps=d.get("steps", []),
                result_ids=d.get("result_ids", []),
                stop_reason=d.get("stop_reason", ""),
                mutations=d.get("mutations", []),
                qte_mode=d.get("qte_mode", ""),
                qte_fingerprint=d.get("qte_fingerprint", {}),
                qte_features=d.get("qte_features", {}),
                qte_refinement_steps=d.get("qte_refinement_steps", []),
                total_time_ms=d.get("total_time_ms", 0.0),
                created_at=d.get("created_at", ""),
            )
            traces.append(t)
        except Exception:
            continue
    return traces


def rank_results_version_aware(
    candidates: list,
    scope_policy,
    *,
    claim_store=None,
    default_exclude: frozenset = frozenset({"retracted"}),
) -> list:
    """Version-aware ranking: scope filter → truth-state filter → state filter → weight → stable sort.

    v2.10.0: Extended to:
    - Apply lifecycle weights exactly once (search() called with apply_lifecycle=False)
    - Filter by record state field (active/deprecated/do_not_use/purged)
    - Combine truth_state weight with record state weight
    """
    from parsica_memory.scope_utils import stable_hit_sort_key
    from parsica_memory.contracts import TRUTH_STATE_WEIGHTS, RECORD_STATE_WEIGHTS, EXCLUDED_RECORD_STATES

    exclude_states = default_exclude
    half_weight_states = frozenset({"superseded"})
    allowed_scopes = None
    scope_body_id = ""

    if scope_policy is not None:
        exclude_states = getattr(scope_policy, "exclude_truth_states", default_exclude)
        half_weight_states = getattr(scope_policy, "half_weight_truth_states", frozenset({"superseded"}))
        allowed_scopes = getattr(scope_policy, "allowed_scopes", None)
        scope_body_id = getattr(scope_policy, "body_id", "")

    filtered = []
    for hit in candidates:
        # Resolve entry (SearchResult vs MemoryEntry)
        entry = getattr(hit, "entry", hit)

        # Truth-state filter
        ts = (getattr(entry, "truth_state", None) or "accepted").lower()
        if ts in exclude_states:
            continue

        # v2.10.0: Record state filter — hard-exclude do_not_use and purged
        state = (getattr(entry, "state", None) or "active").lower()
        if state in EXCLUDED_RECORD_STATES:
            continue

        # Scope filter
        if allowed_scopes is not None:
            entry_scope = getattr(entry, "retrieval_scope", "") or "identity_durable"
            if entry_scope not in allowed_scopes:
                logger.debug("scope_rank: dropped %s (scope=%s not in %s)",
                             getattr(entry, "hash", "?")[:8], entry_scope, allowed_scopes)
                continue
            if entry_scope == "body_local":
                entry_body = getattr(entry, "body_id", "") or ""
                # Exclude legacy sentinel from cross-body results
                if entry_body == "__legacy_unknown_body__" and scope_body_id != "__legacy_unknown_body__":
                    continue
                # Exclude entries from a different body (P0 fix: body match required)
                if entry_body and scope_body_id and entry_body != scope_body_id:
                    continue

        # v2.10.0: Combine truth_state weight with record state weight (applied once here)
        ts_weight = TRUTH_STATE_WEIGHTS.get(ts, 1.0)
        if ts in half_weight_states:
            ts_weight = 0.5
        state_weight = RECORD_STATE_WEIGHTS.get(state, 1.0)
        weight = ts_weight * state_weight

        # Apply claim-family weight if available
        if claim_store is not None:
            record_id = getattr(entry, "record_id", None) or getattr(entry, "hash", "")
            claim_weight = claim_store.get_claim_weight(record_id)
            if claim_weight == 0.0:
                continue  # do_not_use claim family
            weight *= claim_weight

        if hasattr(hit, "score"):
            hit.score = hit.score * weight
        elif hasattr(hit, "relevance"):
            hit.relevance = hit.relevance * weight

        filtered.append(hit)

    filtered.sort(key=stable_hit_sort_key)
    return filtered
