"""
parsica_memory.source_manifest — Lazy provenance index.

Maps (source_type, source_id) → [record_ids].
Built incrementally at ingest time. Used by pack assembly and QTE source routing.

v2.9.2
"""
from __future__ import annotations

import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

MANIFEST_PATH = "_meta/source_manifest.jsonl"


class SourceManifest:
    """Lazy index: (source_type, source_id) → [record_ids].

    Persisted as JSONL at workspace/_meta/source_manifest.jsonl.
    Append-only writes for ingest performance; loaded into memory on first use.
    """

    def __init__(self, workspace: str) -> None:
        self._workspace = workspace
        self._path = str(Path(workspace) / MANIFEST_PATH)
        self._index: Dict[str, List[str]] = defaultdict(list)
        self._loaded = False
        self._dirty_count = 0

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        if not os.path.exists(self._path):
            self._loaded = True
            return
        try:
            with open(self._path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                        key = f"{rec['source_type']}::{rec['source_id']}"
                        self._index[key].append(rec["record_id"])
                    except (json.JSONDecodeError, KeyError):
                        pass
        except OSError:
            pass
        self._loaded = True

    def add(self, source_type: str, source_id: str, record_id: str) -> None:
        """Register a record_id under (source_type, source_id)."""
        key = f"{source_type}::{source_id}"
        self._ensure_loaded()
        if record_id not in self._index[key]:
            self._index[key].append(record_id)
            # Append to JSONL for durability
            try:
                os.makedirs(os.path.dirname(self._path), exist_ok=True)
                with open(self._path, "a", encoding="utf-8") as f:
                    f.write(json.dumps({
                        "source_type": source_type,
                        "source_id": source_id,
                        "record_id": record_id,
                    }, ensure_ascii=False) + "\n")
                self._dirty_count += 1
            except OSError:
                pass

    def lookup(self, source_type: str, source_id: str) -> List[str]:
        """Return record_ids for (source_type, source_id)."""
        self._ensure_loaded()
        return list(self._index.get(f"{source_type}::{source_id}", []))

    def all_sources(self) -> List[tuple]:
        """Return all (source_type, source_id) pairs."""
        self._ensure_loaded()
        result = []
        for key in self._index:
            parts = key.split("::", 1)
            if len(parts) == 2:
                result.append((parts[0], parts[1]))
        return result

    def stats(self) -> dict:
        self._ensure_loaded()
        return {
            "source_count": len(self._index),
            "total_records": sum(len(v) for v in self._index.values()),
        }
