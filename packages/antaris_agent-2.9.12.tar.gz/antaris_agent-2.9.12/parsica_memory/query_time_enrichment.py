from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field, replace as dataclass_replace
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import List

from .contracts import RecordKind, RetrievalTrace, SideEffectMode


class RetrievalMode(str, Enum):
    RECENT = "recent"
    SEMANTIC = "semantic"
    PRECISION = "precision"
    EVIDENCE = "evidence"
    DEEP = "deep"


# Public modes: auto | precision | evidence | deep
# Legacy mapping: recent → precision, semantic → evidence
_LEGACY_MODE_MAP: dict = {
    "recent": "precision",
    "semantic": "evidence",
}


def _map_legacy_mode(mode: str) -> str:
    """Map legacy mode names to their canonical equivalents."""
    return _LEGACY_MODE_MAP.get(mode.lower(), mode.lower())


@dataclass(init=False)
class QueryFingerprint:
    is_recentness_query: bool = False
    is_precision_query: bool = False
    is_evidence_query: bool = False
    is_preference_query: bool = False
    is_procedure_query: bool = False
    is_fact_lookup: bool = False
    mentions_time_window: bool = False
    mentions_correction_or_truth: bool = False
    needs_cross_session: bool = False
    query_length_tokens: int = 0

    def __init__(self, query_or_bool=None, **kwargs):
        """Support both positional string init (for tests) and keyword-only init.

        Usage:
          QueryFingerprint("What is Jake's name?")  — fingerprints the string
          QueryFingerprint(is_recentness_query=True) — keyword fields
          QueryFingerprint()                         — all defaults
        """
        # Set defaults for all declared fields
        self.is_recentness_query = False
        self.is_precision_query = False
        self.is_evidence_query = False
        self.is_preference_query = False
        self.is_procedure_query = False
        self.is_fact_lookup = False
        self.mentions_time_window = False
        self.mentions_correction_or_truth = False
        self.needs_cross_session = False
        self.query_length_tokens = 0

        if isinstance(query_or_bool, str):
            # Called as QueryFingerprint("some query text") — fingerprint the string inline
            query = query_or_bool.strip()
            q = query.lower()
            self.query_length_tokens = len(query.split())
            has_quotes = '"' in query or "'" in query
            has_filename = bool(re.search(r"\b[\w.-]+\.(py|md|json|yaml|yml|toml|ini|cfg|txt)\b", q))
            has_id = bool(re.search(r"\b[a-f0-9]{8,}\b", q)) or bool(re.search(r"\bid[:#-]?\s*[a-z0-9_-]+\b", q))
            has_exact = any(token in q for token in ("exact", "literal", "verbatim"))
            self.is_preference_query = any(token in q for token in _PREFERENCE_PATTERNS)
            self.is_procedure_query = any(token in q for token in _PROCEDURE_PATTERNS)
            self.mentions_correction_or_truth = any(token in q for token in _CORRECTION_PATTERNS)
            self.is_evidence_query = any(token in q for token in _EVIDENCE_PATTERNS)
            self.is_recentness_query = any(token in q for token in _RECENTNESS_PATTERNS)
            self.mentions_time_window = any(token in q for token in _TIME_WINDOW_PATTERNS)
            self.is_fact_lookup = bool(re.search(r"\bwhat is\b|\bwho is\b|\bwhere is\b|\bwhen did\b", q))
            self.needs_cross_session = any(token in q for token in ("last time", "previously", "across sessions", "before"))
            self.is_precision_query = has_quotes or has_filename or has_id or has_exact
        elif query_or_bool is not None:
            # Legacy positional bool (backward compat)
            self.is_recentness_query = bool(query_or_bool)

        # Apply any keyword overrides
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, k, v)


@dataclass
class RetrievalPlan:
    mode: RetrievalMode
    prefer_child_records: bool = False
    prefer_parent_records: bool = False
    prefer_record_kinds: list = field(default_factory=list)
    truth_state_filter: str = "accepted_only"
    allow_refinement: bool = True
    max_refinement_steps: int = 2
    refinement_budget_ms: int = 250
    persist_diagnostics: bool = False
    persist_trace: bool = False


class RetrievalTraceSink:
    """Handles optional trace persistence with rotation."""

    MAX_BYTES = 10 * 1024 * 1024
    RETENTION_DAYS = 7

    def __init__(self, traces_dir):
        self.traces_dir = Path(traces_dir)
        self.traces_dir.mkdir(parents=True, exist_ok=True)

    def _date_prefix(self) -> str:
        return datetime.now(timezone.utc).date().isoformat()

    def _current_path(self) -> Path:
        prefix = f"trace-{self._date_prefix()}"
        existing = sorted(self.traces_dir.glob(f"{prefix}.*.jsonl"))
        if existing:
            candidate = existing[-1]
            if candidate.stat().st_size < self.MAX_BYTES:
                return candidate
        next_index = len(existing) + 1
        return self.traces_dir / f"{prefix}.{next_index:04d}.jsonl"

    def write(self, trace) -> None:
        self.prune()
        path = self._current_path()
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace.to_dict(), ensure_ascii=False) + "\n")

    def prune(self) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=self.RETENTION_DAYS)
        for path in self.traces_dir.glob("trace-*.jsonl"):
            try:
                stamp = path.name.split(".")[0].replace("trace-", "")
                day = datetime.fromisoformat(stamp).replace(tzinfo=timezone.utc)
                if day < cutoff:
                    path.unlink(missing_ok=True)
            except Exception:
                continue


_RECENTNESS_PATTERNS = (
    "recent",
    "just",
    "earlier today",
    "what was i working on",
    "lately",
    "most recently",
    "last thing",
)
_EVIDENCE_PATTERNS = (
    "why",
    "evidence",
    "show me",
    "where did",
    "based on what",
    "proof",
)
_PROCEDURE_PATTERNS = ("how to", "steps to", "to deploy", "procedure")
_PREFERENCE_PATTERNS = ("prefer", "like", "dislike", "favorite", "want")
_CORRECTION_PATTERNS = ("mistake", "wrong", "fix", "correction", "not to do")
_TIME_WINDOW_PATTERNS = ("today", "yesterday", "this week", "last week", "recently", "lately")


def fingerprint_query(request) -> QueryFingerprint:
    query = (getattr(request, "query", "") or "").strip()
    q = query.lower()
    has_quotes = '"' in query or "'" in query
    has_filename = bool(re.search(r"\b[\w.-]+\.(py|md|json|yaml|yml|toml|ini|cfg|txt)\b", q))
    has_id = bool(re.search(r"\b[a-f0-9]{8,}\b", q)) or bool(re.search(r"\bid[:#-]?\s*[a-z0-9_-]+\b", q))
    has_exact = any(token in q for token in ("exact", "literal", "verbatim"))
    preference = any(token in q for token in _PREFERENCE_PATTERNS)
    procedure = any(token in q for token in _PROCEDURE_PATTERNS)
    correction = any(token in q for token in _CORRECTION_PATTERNS)
    evidence = any(token in q for token in _EVIDENCE_PATTERNS)
    recent = any(token in q for token in _RECENTNESS_PATTERNS)
    time_window = any(token in q for token in _TIME_WINDOW_PATTERNS)
    fact_lookup = bool(re.search(r"\bwhat is\b|\bwho is\b|\bwhere is\b|\bwhen did\b", q))
    cross_session = any(token in q for token in ("last time", "previously", "across sessions", "before"))
    return QueryFingerprint(
        is_recentness_query=recent,
        is_precision_query=has_quotes or has_filename or has_id or has_exact,
        is_evidence_query=evidence,
        is_preference_query=preference,
        is_procedure_query=procedure,
        is_fact_lookup=fact_lookup,
        mentions_time_window=time_window,
        mentions_correction_or_truth=correction,
        needs_cross_session=cross_session,
        query_length_tokens=len(query.split()),
    )


def choose_mode(request_or_fp, fp: QueryFingerprint = None) -> RetrievalMode:
    """Choose retrieval mode based on request and fingerprint.

    Supports two call signatures:
      choose_mode(request, fp)          — production path (request object + fingerprint)
      choose_mode(fp)                   — convenience path for tests (fingerprint only)

    Public modes: auto | precision | evidence | deep
    Legacy modes: recent → precision, semantic → evidence
    """
    # Handle single-argument form: choose_mode(fp)
    if fp is None:
        if isinstance(request_or_fp, QueryFingerprint):
            fp = request_or_fp
            request_or_fp = None
        else:
            raise TypeError("choose_mode requires a QueryFingerprint argument")

    request = request_or_fp

    # Explicit mode override (user-requested mode)
    if request is not None:
        requested = (getattr(request, "query_mode", "auto") or "auto").lower()
        if requested != "auto":
            # Apply legacy mapping before constructing enum
            canonical = _map_legacy_mode(requested)
            return RetrievalMode(canonical)

    # --- Heuristic mode routing ---
    # 1. Recentness signals stay as RECENT (legacy; routes to precision internally)
    if fp.is_recentness_query:
        return RetrievalMode.RECENT

    # 2. Short factual queries (who/what/when + entity, ≤6 tokens) → PRECISION
    if fp.query_length_tokens <= 6 and fp.is_fact_lookup:
        return RetrievalMode.PRECISION

    # 3. Complex / multi-faceted / ≥12 tokens → DEEP
    if fp.query_length_tokens >= 12:
        return RetrievalMode.DEEP

    # 4. Evidence signals → EVIDENCE
    if fp.is_evidence_query:
        return RetrievalMode.EVIDENCE

    # 5. Precision signals
    if fp.is_precision_query:
        return RetrievalMode.PRECISION
    if fp.is_procedure_query or fp.is_preference_query or fp.mentions_correction_or_truth:
        return RetrievalMode.PRECISION

    # 6. Default fallback → EVIDENCE
    return RetrievalMode.EVIDENCE


def build_plan(mode: RetrievalMode, request, fp: QueryFingerprint) -> RetrievalPlan:
    effective_mode = getattr(request, "side_effect_mode", None)
    is_pure = effective_mode == SideEffectMode.PURE_READ
    plan = RetrievalPlan(
        mode=mode,
        prefer_child_records=bool(getattr(request, "prefer_child_records", False)),
        prefer_parent_records=bool(getattr(request, "prefer_parent_records", False)),
        allow_refinement=bool(getattr(request, "allow_refinement", True)),
        max_refinement_steps=int(getattr(request, "max_refinement_steps", 2)),
        refinement_budget_ms=int(getattr(request, "max_qte_time_ms", 250)),
        persist_diagnostics=bool(getattr(request, "persist_diagnostics", False)),
        persist_trace=bool(getattr(request, "persist_trace", False)),
    )
    if mode == RetrievalMode.RECENT:
        plan.prefer_parent_records = True
    elif mode == RetrievalMode.EVIDENCE:
        plan.truth_state_filter = "include_superseded"
        plan.prefer_record_kinds = [RecordKind.FACT.value, RecordKind.MISTAKE.value, RecordKind.PROCEDURE.value]
    elif mode == RetrievalMode.PRECISION:
        plan.prefer_child_records = plan.prefer_child_records or fp.is_preference_query or fp.is_procedure_query
        if fp.is_preference_query:
            plan.prefer_record_kinds = [RecordKind.PREFERENCE.value, RecordKind.FACT.value]
        elif fp.is_procedure_query:
            plan.prefer_record_kinds = [RecordKind.PROCEDURE.value, RecordKind.FACT.value]
        elif fp.mentions_correction_or_truth:
            plan.prefer_record_kinds = [RecordKind.MISTAKE.value, RecordKind.FACT.value]
    elif mode == RetrievalMode.DEEP:
        plan.truth_state_filter = "include_all"
        plan.allow_refinement = True
    if is_pure:
        plan.persist_trace = False
        plan.persist_diagnostics = False
    return plan


def _score_item(item, plan: RetrievalPlan):
    score = float(getattr(item, "score", 0.0) or 0.0)
    kind = getattr(getattr(item, "record_kind", None), "value", getattr(item, "record_kind", ""))
    if plan.prefer_record_kinds and kind in plan.prefer_record_kinds:
        score += max(0.25, 0.3 - (0.02 * plan.prefer_record_kinds.index(kind)))
    if plan.prefer_child_records and kind in {
        RecordKind.FACT.value,
        RecordKind.MISTAKE.value,
        RecordKind.PREFERENCE.value,
        RecordKind.PROCEDURE.value,
    }:
        score += 0.2
    if plan.prefer_parent_records and kind == RecordKind.TURN.value:
        score += 0.15
    return score


def _extract_gap_terms(results, query_tokens: set, max_terms: int = 4) -> list:
    """Extract up to max_terms novel content terms from top results not in the original query."""
    stopwords = frozenset({
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "i", "you", "he", "she",
        "it", "we", "they", "what", "which", "who", "when", "where", "how",
        "in", "on", "at", "by", "for", "with", "about", "to", "of", "and",
        "or", "but", "not", "no", "so", "as", "if", "then", "than", "that",
    })
    term_counts: dict = {}
    for item in results:
        content = (getattr(item, "content", "") or "").lower()
        for word in re.findall(r"[a-z]{3,}", content):
            if word not in query_tokens and word not in stopwords:
                term_counts[word] = term_counts.get(word, 0) + 1
    # Sort by frequency, take top N
    sorted_terms = sorted(term_counts, key=lambda w: term_counts[w], reverse=True)
    return sorted_terms[:max_terms]


def run_qte(memory_system, request):
    from .retrieval import _execute_retrieval

    t0 = time.monotonic()
    fp = fingerprint_query(request)
    mode = choose_mode(request, fp)
    plan = build_plan(mode, request, fp)

    limit = max(0, getattr(request, "limit", 10))

    if mode == RetrievalMode.DEEP:
        # Bounded two-pass DEEP retrieval (no unbounded recursion)
        # Pass 1: normal search
        items1, trace = _execute_retrieval(memory_system, request, persist_trace=False)
        top8 = items1[:8]

        # Extract gap terms from top 8 results
        query_tokens = set((getattr(request, "query", "") or "").lower().split())
        gap_terms = _extract_gap_terms(top8, query_tokens, max_terms=4)

        items2 = []
        if gap_terms:
            # Pass 2: expanded query using a cloned request with the expanded query
            expanded_query = (getattr(request, "query", "") or "") + " " + " ".join(gap_terms)
            try:
                # v2.9.9: use dataclasses.replace() instead of dir()-based proxy
                req2 = dataclass_replace(
                    request,
                    query=expanded_query,
                    side_effect_mode=SideEffectMode.PURE_READ,
                )
                items2_raw, _ = _execute_retrieval(memory_system, req2, persist_trace=False)
                items2 = list(items2_raw)
            except Exception:
                # Pass 2 is best-effort; fall back gracefully
                items2 = []

        # Merge pass1 + pass2, dedupe by record_id
        seen = set()
        merged = []
        for item in list(items1) + list(items2):
            rid = getattr(item, "record_id", id(item))
            if rid not in seen:
                seen.add(rid)
                merged.append(item)

        items = merged
    else:
        items, trace = _execute_retrieval(memory_system, request, persist_trace=False)

    ranked = sorted(items, key=lambda item: _score_item(item, plan), reverse=True)
    limited = ranked[:limit]

    trace.qte_mode = mode.value
    trace.qte_fingerprint = asdict(fp)
    trace.qte_features = {
        "prefer_child_records": plan.prefer_child_records,
        "prefer_parent_records": plan.prefer_parent_records,
        "prefer_record_kinds": list(plan.prefer_record_kinds),
        "truth_state_filter": plan.truth_state_filter,
        "allow_refinement": plan.allow_refinement,
        "max_refinement_steps": plan.max_refinement_steps,
        "refinement_budget_ms": plan.refinement_budget_ms,
    }
    trace.qte_refinement_steps = []
    trace.result_ids = [item.record_id for item in limited]
    trace.total_time_ms = (time.monotonic() - t0) * 1000

    effective_mode = getattr(request, "side_effect_mode", None)
    if plan.persist_trace and effective_mode != SideEffectMode.PURE_READ:
        sink = RetrievalTraceSink(Path(memory_system.workspace) / "_meta" / "retrieval_traces")
        sink.write(trace)

    return limited
