"""SegmentStore — the orchestrator for Parsica Memory v3.2.0 segmented storage.

Coordinates manifest, immutable segments, and the hot buffer to provide a
unified storage layer.  ``MemorySystemV4`` delegates all persistence to this
class.  External callers should only depend on ``SegmentStore``; they should
not call :class:`~parsica_memory.storage.manifest.Manifest`,
:class:`~parsica_memory.storage.segments.SegmentWriter`, or
:class:`~parsica_memory.storage.segments.HotBuffer` directly.

Architecture
------------
- ``manifest.json`` is the sole source of truth (atomic JSON, generation
  counter).
- ``hot.jsonl`` is the only mutable file (append-only operation envelopes).
- ``seg_NNNN_<ts>_<count>.jsonl`` are immutable JSONL segments.
- Tombstones live in the manifest (not separate files).
- Flush rotates the hot log by **rename** (not truncate).

Delegation
----------
This module delegates to:

- :mod:`~parsica_memory.storage.manifest` — :class:`Manifest` for all
  manifest I/O, locking, and generation-counter state.
- :mod:`~parsica_memory.storage.segments` — :class:`SegmentWriter`,
  :class:`SegmentReader`, :class:`HotBuffer` for segment and hot-buffer I/O.

Flush lifecycle
---------------
1. Caller calls :meth:`SegmentStore.append_put` or
   :meth:`SegmentStore.append_delete`; op is fsynced to ``hot.jsonl``.
2. :meth:`should_flush` returns ``True`` when a threshold is met (ops count,
   byte size, age, or hot overflow circuit breaker).
3. :meth:`flush` acquires the store-level flush lock, then:

   a. Rotates ``hot.jsonl`` → ``hot.rotating.jsonl`` (atomic rename).
   b. Reads ops from ``hot.rotating.jsonl``.
   c. Computes net state per hash (last-op-wins); collects puts and deletes.
   d. Writes an immutable JSONL segment via ``SegmentWriter``.
   e. Updates manifest atomically (add segment + tombstones + reset hot).
   f. Deletes ``hot.rotating.jsonl``.

Load lifecycle
--------------
:meth:`load` performs crash recovery, segment hydration, and hot replay:

1. Reloads manifest from disk.
2. If ``hot.rotating.jsonl`` exists (crash recovery): performs
   order-preserving repair — rebuilds ``hot.jsonl`` as
   ``rotating_ops + current_hot_ops`` (via temp file + fsync +
   ``os.replace``), then deletes ``hot.rotating.jsonl``.
3. Loads all active segments from disk in manifest order.
4. Applies durable manifest tombstones.
5. Replays ``hot.jsonl`` ops in strict order (later ops override
   earlier ones).
6. Caps result at 75 000 entries.

Compaction lifecycle
--------------------
:meth:`compact` merges segments in the same size tier (Tier 0–2) when ≥ 4
accumulate.  It applies tombstones, deduplicates by hash (highest confidence
wins), optionally applies a decay filter, writes new compacted segments, and
removes the old ones after an atomic manifest update.  Tier 3 (≥ 20 000
entries) is never automatically compacted — manual only.

Hot overflow circuit breaker
-----------------------------
If ``hot.jsonl`` exceeds ``hot_max_emergency_bytes`` (default 50 MB), the
circuit breaker sets ``_hot_overflow = True`` and forces
:meth:`should_flush` to return ``True`` regardless of the ``hot_min_ops``
minimum.  This prevents unbounded log growth when flushes are failing
repeatedly.  Writes are never blocked — only warnings are emitted.

Thread / process safety
-----------------------
- Single-writer per workspace (v3.2 assumption).
- Hot appends serialised via ``HotBuffer``'s internal ``FileLock``.
- Flush / compact / forget serialised via a store-level ``FileLock`` on
  ``segments/segment_store.flush`` (separate from the manifest lock to
  avoid non-reentrant deadlocks).
- Manifest operations use :class:`Manifest`'s own internal lock.

Load limit
----------
A safety cap of 75 000 entries is enforced on :meth:`load`.  Exceeding it
logs a warning and returns only the first 75 000 entries in manifest +
hot-replay order.
"""

from __future__ import annotations

import json
import logging
import os
import time
import warnings
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional, Set

from ..entry import MemoryEntry
from ..locking import FileLock
from .manifest import Manifest
from .segments import HotBuffer, SegmentReader, SegmentWriter

logger = logging.getLogger("parsica_memory")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_LOAD_LIMIT = 75_000
_VERSION = "3.2.0"
_TOMBSTONE_CAP = 5_000
_HOT_MAX_EMERGENCY_BYTES = 50 * 1024 * 1024  # 50 MB


# ===================================================================
# Internal helpers
# ===================================================================

def _segment_filename(sequence: int, entry_count: int) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"seg_{sequence:04d}_{ts}_{entry_count}.jsonl"


def _tier_for_count(count: int) -> int:
    if count < 1_000:
        return 0
    if count < 5_000:
        return 1
    if count < 20_000:
        return 2
    return 3


# ===================================================================
# SegmentStore
# ===================================================================

class SegmentStore:
    """Orchestrator for manifest + immutable segments + hot buffer.

    Delegates to :class:`Manifest`, :class:`SegmentWriter`,
    :class:`SegmentReader`, and :class:`HotBuffer` from sibling modules.

    Parameters
    ----------
    workspace : str
        Root workspace directory.  Segments live in ``{workspace}/segments/``.
    hot_max_ops : int
        Flush when the hot buffer reaches this many operations.
    hot_max_bytes : int
        Flush when the hot buffer file exceeds this size in bytes.
    hot_max_age_seconds : float
        Flush when the oldest un-flushed op is older than this.
    hot_min_ops : int
        Do **not** timer-flush below this many ops (prevents tiny segments).
    """

    def __init__(
        self,
        workspace: str,
        hot_max_ops: int = 1_000,
        hot_max_bytes: int = 4_194_304,
        hot_max_age_seconds: float = 300.0,
        hot_min_ops: int = 50,
        hot_max_emergency_bytes: int = _HOT_MAX_EMERGENCY_BYTES,
    ) -> None:
        self.workspace = workspace
        self.seg_dir = os.path.join(workspace, "segments")
        os.makedirs(self.seg_dir, exist_ok=True)

        # Delegate to Manifest for all manifest state
        self._manifest = Manifest(self.seg_dir)

        # Delegate to HotBuffer for all hot-log I/O
        self._hot_buffer = HotBuffer(self.seg_dir)

        # Convenience paths (for external callers / tests that reference them)
        self.manifest_path = self._manifest.manifest_path
        self.hot_path = self._hot_buffer.hot_path
        self.rotating_path = self._hot_buffer.rotating_path

        # Flush thresholds
        self.hot_max_ops = hot_max_ops
        self.hot_max_bytes = hot_max_bytes
        self.hot_max_age_seconds = hot_max_age_seconds
        self.hot_min_ops = hot_min_ops
        self.hot_max_emergency_bytes = hot_max_emergency_bytes

        # Store-level lock for flush/compact atomicity.
        # Uses a SEPARATE lock path from the manifest's internal lock to
        # avoid non-reentrant deadlocks (both would use manifest.json.lock/).
        self._flush_lock = FileLock(
            os.path.join(self.seg_dir, "segment_store.flush"),
            timeout=60.0,
            stale_threshold=1800,
        )

        # In-memory tracking (not persisted; rebuilt on load)
        self._hot_ops_count = 0
        self._hot_bytes = 0
        self._hot_first_write: Optional[float] = None  # monotonic time

        # Hot buffer circuit breaker (P2 Fix 1): overflow detection
        self._hot_overflow = False

        # Load truncation tracking (P2 Fix 2)
        self._load_truncated = False
        self._load_truncated_count = 0

        # Test-only fault injection hooks for deterministic crash-boundary
        # coverage. Each hook is an optional callable; when set, it is called
        # at the named durability boundary and may raise to simulate a crash.
        #
        # N3 fix: _fault_after_segment_rename was removed because it fired at
        # the exact same code point as _fault_after_segment_write in both
        # flush() and compact().  SegmentWriter.write_segment() performs the
        # atomic write (temp → fsync → rename) internally, so by the time
        # control returns to flush()/compact(), both the write and the rename
        # have already completed.  A separate "after rename" hook at the same
        # call site was redundant and its name was misleading.  Five hooks
        # remain, each at a genuinely distinct durability boundary.
        self._fault_after_hot_fsync: Optional[Callable[[], None]] = None
        self._fault_after_segment_write: Optional[Callable[[], None]] = None
        self._fault_before_manifest_replace: Optional[Callable[[], None]] = None
        self._fault_after_manifest_replace: Optional[Callable[[], None]] = None
        self._fault_before_hot_clear: Optional[Callable[[], None]] = None

    # ---------------------------------------------------------------
    # Load path
    # ---------------------------------------------------------------

    def load(self) -> List[MemoryEntry]:
        """Load all live entries from segments + hot buffer.

        Steps:
        1. Reload manifest from disk.
        2. Crash-recovery: if ``hot.rotating.jsonl`` exists, perform
           order-preserving repair — rebuild ``hot.jsonl`` with rotating
           ops first, then current hot ops; delete rotating file.
        3. Load immutable segments referenced in manifest.
        4. Apply tombstones from manifest.
        5. Replay ``hot.jsonl`` ops in strict order (puts & deletes).
        6. Dedup by hash (hot wins over segment).
        7. Cap at ``_LOAD_LIMIT``.

        Returns the list of live ``MemoryEntry`` objects.
        """
        # Reload manifest from disk to pick up any external changes
        self._manifest.load()

        # -- Crash recovery: rotating file left behind --
        if self._hot_buffer.has_rotating():
            logger.info("Crash recovery: replaying hot.rotating.jsonl")
            rotating_path = self._hot_buffer.rotating_path
            rotating_ops = _read_ops_from_path(rotating_path)
            # [P0 Fix 5] Order-preserving repair.
            #
            # When both hot.rotating.jsonl AND hot.jsonl exist, this means
            # the process crashed between flush rotation and manifest
            # publish, and newer writes may have landed in the fresh
            # hot.jsonl.  The rotating ops are OLDER than the current hot
            # ops and must come FIRST in replay order.
            #
            # The old code (P0 Fix 1) re-appended rotating ops to the END
            # of hot.jsonl.  This reversed op ordering for any hash that
            # appeared in both files — e.g. a delete in rotating followed
            # by a put in hot.jsonl would become put-then-delete after the
            # re-append, incorrectly killing the entry.
            #
            # Fix: read current hot.jsonl, rebuild it as
            # rotating_ops + current_hot_ops in correct order using a temp
            # file, fsync, then atomically replace hot.jsonl.  Finally
            # delete hot.rotating.jsonl.
            current_hot_ops = _read_ops_from_path(self._hot_buffer.hot_path)

            # Rebuild hot.jsonl with correct order: rotating FIRST, then
            # current hot ops.  Write to a temp file, fsync, os.replace.
            import tempfile as _tempfile
            tmp_fd, tmp_path = _tempfile.mkstemp(
                dir=self.seg_dir, suffix=".jsonl.tmp"
            )
            try:
                with os.fdopen(tmp_fd, "w", encoding="utf-8") as tmp_f:
                    for op in rotating_ops:
                        tmp_f.write(json.dumps(op, ensure_ascii=False) + "\n")
                    for op in current_hot_ops:
                        tmp_f.write(json.dumps(op, ensure_ascii=False) + "\n")
                    tmp_f.flush()
                    os.fsync(tmp_f.fileno())
                # Atomically replace hot.jsonl with the rebuilt file
                os.replace(tmp_path, self._hot_buffer.hot_path)
            except BaseException:
                # Clean up temp file on failure; rotating file is still
                # intact so next load() will retry the repair.
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise

            # Now that all ops are safely in hot.jsonl in correct order,
            # delete the rotating file.
            try:
                self._hot_buffer.cleanup_rotating()
            except OSError:
                pass

        # -- Load immutable segments --
        entry_map: OrderedDict[str, MemoryEntry] = OrderedDict()

        for seg_meta in self._manifest.segments:
            if seg_meta.get("state") != "active":
                continue
            fname = seg_meta["filename"]
            seg_path = os.path.join(self.seg_dir, fname)
            if not os.path.exists(seg_path):
                logger.warning("Segment file missing: %s", fname)
                continue
            # v2.8.0: use load_segment_entries() to apply amendment sidecars
            _meta_with_path = dict(seg_meta)
            _meta_with_path["path"] = seg_path
            for entry in SegmentReader.load_segment_entries(_meta_with_path):
                entry_map[entry.hash] = entry

        # -- Apply durable manifest tombstones to segment-loaded entries --
        # Do this BEFORE replaying hot ops so a later put can resurrect an
        # entry that was previously deleted.
        manifest_tombstones = self._manifest.get_tombstone_hashes()
        for h in manifest_tombstones:
            entry_map.pop(h, None)

        # -- Replay hot ops in strict order --
        # After crash recovery repair above, hot.jsonl contains ops in the
        # correct order (rotating ops first, then current ops).  No need
        # to separately track rotating_ops — everything is in hot.jsonl.
        hot_ops = self._hot_buffer.read_ops()

        for op in hot_ops:
            if op.get("op") == "put":
                entry = MemoryEntry.from_dict(op["entry"])
                entry_map[entry.hash] = entry
            elif op.get("op") == "delete":
                h = op.get("hash", "")
                entry_map.pop(h, None)

        # -- Rebuild hot tracking counters --
        self._hot_ops_count = len(hot_ops)
        try:
            self._hot_bytes = os.path.getsize(self.hot_path)
        except OSError:
            self._hot_bytes = 0
        if hot_ops:
            self._hot_first_write = time.monotonic()
        else:
            self._hot_first_write = None

        # -- Respect load limit --
        entries = list(entry_map.values())
        if len(entries) > _LOAD_LIMIT:
            truncated_count = len(entries) - _LOAD_LIMIT
            logger.warning(
                "Load limit reached: %d entries, capping at %d "
                "(%d entries truncated)",
                len(entries), _LOAD_LIMIT, truncated_count,
            )
            warnings.warn(
                f"Parsica Memory load limit reached: {len(entries)} entries "
                f"exceeded the {_LOAD_LIMIT} cap. {truncated_count} entries "
                f"were truncated. Consider compacting or increasing the limit.",
                UserWarning,
                stacklevel=2,
            )
            self._load_truncated = True
            self._load_truncated_count = truncated_count
            entries = entries[:_LOAD_LIMIT]
        else:
            self._load_truncated = False
            self._load_truncated_count = 0

        return entries

    # ---------------------------------------------------------------
    # Write path
    # ---------------------------------------------------------------

    def append_put(self, entry: MemoryEntry) -> None:
        """Append a *put* operation to the hot buffer.

        Delegates to :meth:`HotBuffer.append_put` which handles its own
        locking and fsync.

        .. note:: [P0 Fix 2] Tombstone clearing is NOT done here.  The hot
           put already overrides a manifest tombstone during ``load()``
           because hot replay happens AFTER tombstone application.
           Tombstone clearing happens during ``flush()`` when the
           net-final-state computation determines the last op is a put.
           Clearing eagerly here was unsafe: if the hot append fails after
           the tombstone is removed, the old deleted segment entry
           resurrects on the next load.
        """
        self._hot_buffer.append_put(entry)
        self._hot_ops_count += 1
        try:
            self._hot_bytes = os.path.getsize(self.hot_path)
        except OSError:
            pass
        if self._hot_first_write is None:
            self._hot_first_write = time.monotonic()

        # Hot buffer circuit breaker (P2 Fix 1)
        self._check_hot_overflow()

    def append_delete(self, hash_val: str, reason: str = "") -> None:
        """Append a *delete* operation to the hot buffer **and** record a
        tombstone in the manifest.

        Delegates to :meth:`HotBuffer.append_delete` for the hot log and
        :meth:`Manifest.add_tombstones` for durable tombstone recording.
        """
        self._hot_buffer.append_delete(hash_val, reason)
        self._hot_ops_count += 1
        try:
            self._hot_bytes = os.path.getsize(self.hot_path)
        except OSError:
            pass
        if self._hot_first_write is None:
            self._hot_first_write = time.monotonic()

        # Durable tombstone in manifest (Manifest handles its own locking)
        self._manifest.add_tombstones({
            hash_val: {
                "deleted_at": datetime.now(timezone.utc).isoformat(),
                "reason": reason,
            }
        })

        # Hot buffer circuit breaker (P2 Fix 1)
        self._check_hot_overflow()

    # ---------------------------------------------------------------
    # Hot buffer circuit breaker (P2 Fix 1)
    # ---------------------------------------------------------------

    def _check_hot_overflow(self) -> None:
        """Check if hot.jsonl exceeds the emergency size threshold.

        When hot.jsonl grows beyond ``hot_max_emergency_bytes`` (default 50 MB),
        this sets ``_hot_overflow = True``, logs a critical warning, and forces
        ``should_flush()`` to return True regardless of the minimum ops
        threshold.  Writes are NOT blocked — only loud warnings and forced
        flush attempts.
        """
        if self._hot_bytes >= self.hot_max_emergency_bytes:
            if not self._hot_overflow:
                logger.critical(
                    "HOT BUFFER OVERFLOW: hot.jsonl has reached %d bytes "
                    "(emergency threshold: %d bytes). Flush may be failing "
                    "repeatedly. Forcing flush attempts.",
                    self._hot_bytes,
                    self.hot_max_emergency_bytes,
                )
            self._hot_overflow = True
        else:
            self._hot_overflow = False

    # ---------------------------------------------------------------
    # Flush triggers
    # ---------------------------------------------------------------

    def should_flush(self) -> bool:
        """Return ``True`` if any flush trigger is met.

        Triggers: ops count, byte size, time elapsed, or hot overflow.
        The time trigger is suppressed when below ``hot_min_ops`` to prevent
        tiny segments during quiet periods.  The hot overflow trigger
        (circuit breaker) bypasses the minimum ops threshold.
        """
        if self._hot_ops_count <= 0:
            return False

        # Circuit breaker: hot overflow forces flush regardless of min ops
        if self._hot_overflow:
            return True

        # Hard triggers (always flush)
        if self._hot_ops_count >= self.hot_max_ops:
            return True
        if self._hot_bytes >= self.hot_max_bytes:
            return True

        # Soft trigger (time) — only if above minimum
        if (self._hot_first_write is not None
                and self._hot_ops_count >= self.hot_min_ops):
            elapsed = time.monotonic() - self._hot_first_write
            if elapsed >= self.hot_max_age_seconds:
                return True

        return False

    # ---------------------------------------------------------------
    # Flush  (the critical path)
    # ---------------------------------------------------------------

    def flush(self) -> dict:
        """Rotate the hot buffer into a new immutable segment.

        Safe flush sequence (rename, not truncate):
        1.  Acquire store-level flush lock.
        2.  Check if hot buffer has content.
        3.  Rotate hot buffer (rename → rotating, create new empty).
        4.  Read ops from ``hot.rotating.jsonl``.
        5.  Replay ops into puts and deletes.
        6.  Write immutable segment from put entries via ``SegmentWriter``.
        7.  Verify optimistic concurrency (generation check).
        8.  Update manifest (add segment, tombstones, reset hot,
            increment generation) via ``Manifest`` methods.
        9.  Delete ``hot.rotating.jsonl``.
        10. Release flush lock.

        Returns ``{"segment_sequence": N, "entries_flushed": M}``
        or ``{"segment_sequence": -1, "entries_flushed": 0}`` if no data.
        """
        with self._flush_lock:
            # -- Check if hot buffer has content --
            has_hot = (os.path.exists(self.hot_path)
                       and os.path.getsize(self.hot_path) > 0)
            if not has_hot:
                return {"segment_sequence": -1, "entries_flushed": 0}

            # -- Rotate hot buffer (HotBuffer handles locking + fsync) --
            rotating_path = self._hot_buffer.rotate()
            _invoke_fault(self._fault_after_hot_fsync)

            # Reset in-memory hot tracking
            self._hot_ops_count = 0
            self._hot_bytes = 0
            self._hot_first_write = None
            self._hot_overflow = False

            # -- Read rotating ops --
            ops = _read_ops_from_path(rotating_path)
            if not ops:
                # Edge case: hot file had content but no valid ops
                self._hot_buffer.cleanup_rotating()
                return {"segment_sequence": -1, "entries_flushed": 0}

            # -- Compute net final state per hash in strict op order --
            # Track the LAST operation for each hash.  This correctly handles
            # interleaved put/delete cycles (e.g. delete → re-add → flush).
            #
            # - If the last op for a hash is ``put`` → include in segment,
            #   do NOT tombstone, and REMOVE any pre-existing manifest
            #   tombstone for that hash.
            # - If the last op for a hash is ``delete`` → add tombstone to
            #   manifest, do NOT include in segment.
            last_op_per_hash: OrderedDict[str, dict] = OrderedDict()
            for op in ops:
                h = op.get("hash", "")
                if h:
                    last_op_per_hash[h] = op

            put_entries: list[MemoryEntry] = []
            delete_tombstones: dict[str, dict] = {}
            hashes_to_clear_tombstone: set[str] = set()

            for h, op in last_op_per_hash.items():
                if op.get("op") == "put":
                    entry_data = op.get("entry")
                    if isinstance(entry_data, dict):
                        try:
                            put_entries.append(MemoryEntry.from_dict(entry_data))
                        except Exception as exc:
                            logger.warning(
                                "Skipping invalid hot put entry during flush: %s", exc
                            )
                    # This hash's net state is "alive" — clear any manifest
                    # tombstone that might exist from an earlier delete.
                    hashes_to_clear_tombstone.add(h)
                elif op.get("op") == "delete":
                    delete_tombstones[h] = {
                        "deleted_at": op.get(
                            "ts", datetime.now(timezone.utc).isoformat()
                        ),
                        "reason": op.get("reason", ""),
                    }

            # Re-read manifest from disk before batching updates.
            self._manifest.load()

            # -- Write segment (only if there are puts) --
            seg_meta = None
            next_seq = -1
            if put_entries:
                # Dedup puts — last writer wins
                deduped: OrderedDict[str, MemoryEntry] = OrderedDict()
                for e in put_entries:
                    deduped[e.hash] = e
                put_entries = list(deduped.values())

                next_seq = self._manifest.generation + 1
                fname = _segment_filename(next_seq, len(put_entries))
                seg_path = os.path.join(self.seg_dir, fname)
                write_meta = SegmentWriter.write_segment(
                    seg_path, put_entries
                )
                _invoke_fault(self._fault_after_segment_write)

                now = datetime.now(timezone.utc).isoformat()
                seg_meta = {
                    "sequence": next_seq,
                    "filename": fname,
                    "state": "active",
                    "entry_count": write_meta["entry_count"],
                    "min_created": write_meta.get("min_created", ""),
                    "max_created": write_meta.get("max_created", ""),
                    "size_bytes": write_meta["size_bytes"],
                    "checksum_sha256": write_meta["checksum_sha256"],
                    "categories": write_meta.get("categories", {}),
                    "memory_types": write_meta.get("memory_types", {}),
                    "originals_count": write_meta.get("originals_count", 0),
                    "derived_count": write_meta.get("derived_count", 0),
                    "agent_ids": write_meta.get("agent_ids", []),
                    "session_ids_sample": write_meta.get("session_ids_sample", []),
                    "source_channels": write_meta.get("source_channels", []),
                    "has_lineage_fields": write_meta.get("has_lineage_fields", False),
                    "flushed_at": now,
                }

            # -- Update manifest atomically in a single batch --
            _invoke_fault(self._fault_before_manifest_replace)
            with self._manifest.batch_update() as manifest:
                if seg_meta is not None:
                    manifest._data.setdefault("segments", []).append(seg_meta)

                if delete_tombstones:
                    manifest._data.setdefault("tombstones", {}).update(delete_tombstones)

                if hashes_to_clear_tombstone:
                    existing_tombstones = set(
                        manifest._data.setdefault("tombstones", {}).keys()
                    )
                    to_remove = hashes_to_clear_tombstone & existing_tombstones
                    for h in to_remove:
                        manifest._data["tombstones"].pop(h, None)

                manifest._data["hot"] = {
                    "filename": "hot.jsonl",
                    "put_count": 0,
                    "delete_count": 0,
                    "last_write_at": None,
                }

            _invoke_fault(self._fault_after_manifest_replace)
            _invoke_fault(self._fault_before_hot_clear)

            # -- Cleanup rotating file --
            self._hot_buffer.cleanup_rotating()

            return {
                "segment_sequence": next_seq if seg_meta else -1,
                "entries_flushed": len(put_entries),
            }

    # ---------------------------------------------------------------
    # Compaction
    # ---------------------------------------------------------------

    def compact(
        self,
        decay_fn: Optional[Callable[[MemoryEntry], float]] = None,
    ) -> dict:
        """Merge segments, apply tombstones, dedup, and optionally decay-filter.

        Parameters
        ----------
        decay_fn : callable, optional
            ``decay_fn(entry) -> float``.  Entries with score ≤ 0.0 are dropped
            **unless** they have a non-empty ``enriched_summary``.

        Returns a stats dict.
        """
        with self._flush_lock:
            # Re-read manifest from disk
            self._manifest.load()
            segments = self._manifest.segments
            tombstones = self._manifest.tombstones

            # -- Identify merge candidates (size-tiered) --
            tiers: dict[int, list[dict]] = {}
            for seg in segments:
                if seg.get("state") != "active":
                    continue
                tier = _tier_for_count(seg.get("entry_count", 0))
                tiers.setdefault(tier, []).append(seg)

            merge_groups: list[list[dict]] = []
            for tier_num in sorted(tiers):
                if tier_num >= 3:
                    continue  # Tier 3 = manual only
                tier_segs = tiers[tier_num]
                if len(tier_segs) >= 4:
                    merge_groups.append(tier_segs)

            if not merge_groups:
                return {"merged": 0, "segments_removed": 0,
                        "segments_created": 0, "entries_kept": 0,
                        "entries_dropped": 0, "tombstones_resolved": 0}

            total_removed = 0
            total_created = 0
            total_kept = 0
            total_dropped = 0
            resolved_tombstones: set[str] = set()
            new_segments_meta: list[dict] = []
            old_filenames: list[str] = []
            old_sequences: set[int] = set()

            # [P0 Fix 3] Pre-compute unique sequence numbers for all new
            # segments.  The old code used self._manifest.generation + 1
            # for EVERY merge group without advancing between groups,
            # creating duplicate sequences.  We use a local counter that
            # starts from current generation and increments for each new
            # segment within this compaction run.
            _compact_seq_base = self._manifest.generation

            # [P0 Fix 4] Determine if this is a full-store compaction
            # (all active segments are being compacted).  Only resolve
            # tombstones during full compaction — partial compaction may
            # leave copies of the tombstoned hash in uncompacted segments.
            all_active_sequences = {
                s["sequence"] for s in segments
                if s.get("state") == "active"
            }
            compacted_sequences: set[int] = set()
            for group in merge_groups:
                for seg in group:
                    compacted_sequences.add(seg["sequence"])
            is_full_compaction = compacted_sequences == all_active_sequences

            for group in merge_groups:
                # Load all entries from the group (v2.8.0: apply amendment sidecars)
                all_entries: list[MemoryEntry] = []
                for seg in group:
                    fname = seg["filename"]
                    seg_path = os.path.join(self.seg_dir, fname)
                    if os.path.exists(seg_path):
                        _seg_meta_with_path = dict(seg)
                        _seg_meta_with_path["path"] = seg_path
                        all_entries.extend(
                            SegmentReader.load_segment_entries(_seg_meta_with_path)
                        )
                    old_filenames.append(fname)
                    old_sequences.add(seg["sequence"])
                total_removed += len(group)

                # Apply tombstones — drop tombstoned entries from the
                # merged output, but only mark tombstones as "resolved"
                # (for later removal from manifest) if this is a full-store
                # compaction.  [P0 Fix 4] In partial compaction, the same
                # hash might exist in segments NOT being compacted; removing
                # the tombstone would let those copies resurrect.
                live: list[MemoryEntry] = []
                for e in all_entries:
                    if e.hash in tombstones:
                        if is_full_compaction:
                            resolved_tombstones.add(e.hash)
                        total_dropped += 1
                        continue
                    live.append(e)

                # Dedup by hash — keep highest confidence
                dedup_map: dict[str, MemoryEntry] = {}
                for e in live:
                    existing = dedup_map.get(e.hash)
                    if existing is None or e.confidence > existing.confidence:
                        dedup_map[e.hash] = e
                live = list(dedup_map.values())

                # Decay filter (if provided)
                if decay_fn is not None:
                    filtered: list[MemoryEntry] = []
                    for m in live:
                        score = decay_fn(m)
                        keep = (score > 0.0
                                or bool(getattr(m, "enriched_summary", None)))
                        if keep:
                            filtered.append(m)
                        else:
                            total_dropped += 1
                    live = filtered

                if not live:
                    continue

                # [P0 Fix 3] Use local counter for unique sequences
                _compact_seq_base += 1
                next_seq = _compact_seq_base

                fname = _segment_filename(next_seq, len(live))
                seg_path = os.path.join(self.seg_dir, fname)
                write_meta = SegmentWriter.write_segment(
                    seg_path, live
                )
                _invoke_fault(self._fault_after_segment_write)

                now = datetime.now(timezone.utc).isoformat()
                meta = {
                    "sequence": next_seq,
                    "filename": fname,
                    "state": "active",
                    "entry_count": write_meta["entry_count"],
                    "min_created": write_meta.get("min_created", ""),
                    "max_created": write_meta.get("max_created", ""),
                    "size_bytes": write_meta["size_bytes"],
                    "checksum_sha256": write_meta["checksum_sha256"],
                    "categories": write_meta.get("categories", {}),
                    "memory_types": write_meta.get("memory_types", {}),
                    "originals_count": write_meta.get("originals_count", 0),
                    "derived_count": write_meta.get("derived_count", 0),
                    "agent_ids": write_meta.get("agent_ids", []),
                    "session_ids_sample": write_meta.get("session_ids_sample", []),
                    "source_channels": write_meta.get("source_channels", []),
                    "has_lineage_fields": write_meta.get("has_lineage_fields", False),
                    "flushed_at": now,
                }
                new_segments_meta.append(meta)
                total_created += 1
                total_kept += len(live)

            # -- Update manifest atomically --
            _invoke_fault(self._fault_before_manifest_replace)
            with self._manifest.batch_update() as manifest:
                manifest._data["segments"] = [
                    s for s in manifest._data.get("segments", [])
                    if s.get("sequence") not in old_sequences
                ]
                manifest._data.setdefault("segments", []).extend(new_segments_meta)
                # [P0 Fix 4] Only remove tombstones if this was a full
                # compaction (all active segments were in scope).
                if resolved_tombstones:
                    for h in resolved_tombstones:
                        manifest._data.get("tombstones", {}).pop(h, None)
                # [P0 Fix 3] Set generation to highest sequence used so
                # subsequent flush/compact operations get unique sequences.
                # B3 fix: batch_update() increments generation by 1 on exit.
                # Set generation to max_new_seq - 1 so the +1 lands exactly
                # on max_new_seq, preventing generation inflation.
                if new_segments_meta:
                    max_new_seq = max(s["sequence"] for s in new_segments_meta)
                    if max_new_seq > manifest._data.get("generation", 0):
                        manifest._data["generation"] = max_new_seq - 1

            _invoke_fault(self._fault_after_manifest_replace)

            # -- Best-effort delete old segment files --
            for fname in old_filenames:
                try:
                    os.unlink(os.path.join(self.seg_dir, fname))
                except OSError:
                    pass

        return {
            "merged": sum(len(g) for g in merge_groups),
            "segments_removed": total_removed,
            "segments_created": total_created,
            "entries_kept": total_kept,
            "entries_dropped": total_dropped,
            "tombstones_resolved": len(resolved_tombstones),
        }

    # ---------------------------------------------------------------
    # Forget (delete)
    # ---------------------------------------------------------------

    def forget_hashes(self, hashes: Set[str], reason: str = "") -> None:
        """Mark *hashes* as deleted — append delete ops to hot and tombstones
        to the manifest."""
        for h in hashes:
            self.append_delete(h, reason=reason)

    # ---------------------------------------------------------------
    # Stats
    # ---------------------------------------------------------------

    def stats(self) -> dict:
        """Return a summary dict of the store's state."""
        self._manifest.load()
        segments = self._manifest.segments
        active = [s for s in segments if s.get("state") == "active"]
        total_seg_entries = sum(s.get("entry_count", 0) for s in active)
        tombstone_count = len(self._manifest.tombstones)
        hot_ops = self._hot_ops_count

        # Advisory flags
        advisory: list[str] = []
        if len(active) > 20:
            advisory.append("many_segments")
        if tombstone_count > _TOMBSTONE_CAP:
            advisory.append("tombstone_cap_exceeded")
        small = [s for s in active if s.get("entry_count", 0) < 100]
        if len(small) > len(active) * 0.25 and len(active) > 4:
            advisory.append("many_tiny_segments")

        result = {
            "segment_count": len(active),
            "total_segment_entries": total_seg_entries,
            "tombstone_count": tombstone_count,
            "hot_ops": hot_ops,
            "generation": self._manifest.generation,
            "version": self._manifest.version,
            "advisory": advisory,
            # Hot buffer circuit breaker (P2 Fix 1)
            "hot_overflow": self._hot_overflow,
            # Load truncation tracking (P2 Fix 2)
            "load_truncated": self._load_truncated,
            "load_truncated_count": self._load_truncated_count,
        }
        return result

    # ---------------------------------------------------------------
    # Utility
    # ---------------------------------------------------------------

    # ---------------------------------------------------------------
    # Invariant assertions (PR 1 — storage guardrails)
    # ---------------------------------------------------------------

    def _assert_manifest_is_truth(self) -> None:
        """Verify that the on-disk manifest and segment files are consistent.

        Reloads the manifest from disk first, then checks:

        - Every segment referenced in the manifest exists on disk.
        - No unreferenced segment files are present (orphan detection).

        .. note:: Because this method calls ``self._manifest.load()`` before
           checking, it verifies **disk-state consistency** — not that the
           in-memory state matches disk.  Any in-memory divergence that
           occurred before the reload is masked by the fresh read.

        Raises :class:`AssertionError` with a descriptive message if the
        manifest and disk state diverge.  Intended for debug / CI use —
        not called on the hot path.
        """
        self._manifest.load()
        manifest_filenames: set[str] = set()
        for seg in self._manifest.segments:
            fname = seg.get("filename", "")
            manifest_filenames.add(fname)
            seg_path = os.path.join(self.seg_dir, fname)
            assert os.path.exists(seg_path), (
                f"Manifest references segment {fname!r} but file is missing "
                f"from {self.seg_dir!r}"
            )

        # Check for orphan segment files on disk not in manifest
        for entry in os.listdir(self.seg_dir):
            if entry.startswith("seg_") and entry.endswith(".jsonl"):
                assert entry in manifest_filenames, (
                    f"Orphan segment file {entry!r} exists on disk but is not "
                    f"referenced in the manifest"
                )

    def _assert_no_legacy_writes(self) -> None:
        """Verify that no legacy persistence artefacts contain data while
        the segmented storage backend is active.

        Checks for:
        - ``pending.jsonl`` with non-empty content (legacy WAL entries)
        - Weekly time-shard files (``memories_*-W*.jsonl``)

        Note: The ``.wal/`` directory and empty ``pending.jsonl`` may exist
        because ``WALManager`` is initialised by ``MemorySystemV4.__init__``
        regardless of storage backend.  What matters is that no *entries*
        were written to the WAL.

        Raises :class:`AssertionError` if any legacy write artefact with
        content is found.
        """
        # Legacy pending.jsonl — may exist but must be empty
        pending_path = os.path.join(self.workspace, "pending.jsonl")
        if os.path.exists(pending_path):
            try:
                with open(pending_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                assert not content, (
                    f"Legacy pending.jsonl at {pending_path!r} has content — "
                    f"segmented mode must not write WAL entries"
                )
            except OSError:
                pass

        # Weekly time-shard files
        import glob as _glob
        weekly_shards = _glob.glob(
            os.path.join(self.workspace, "memories_*-W*.jsonl")
        )
        assert not weekly_shards, (
            f"Weekly shard files found ({len(weekly_shards)}) — "
            f"segmented mode must not write time-window shards"
        )

    def has_compaction_candidates(self) -> bool:
        """Return ``True`` when there are cold segments that can/should be merged.

        Trigger conditions (all must hold):
        - Multiple active cold segments exist (≥ 4 in any single size tier).
        - Combined size or count warrants a merge (tier-based thresholds match
          those used by :meth:`compact`).

        This mirrors the tier-based selection logic in :meth:`compact` so that
        the task journal only receives a ``compact_store`` task when
        :meth:`compact` would actually do useful work.
        """
        self._manifest.load()
        segments = self._manifest.segments
        active = [s for s in segments if s.get("state") == "active"]
        # Group by size tier (mirrors compact()'s _tier_for_count logic)
        tiers: dict[int, int] = {}
        for seg in active:
            tier = _tier_for_count(seg.get("entry_count", 0))
            if tier < 3:  # Tier 3 is manual-only — exclude from auto-compaction
                tiers[tier] = tiers.get(tier, 0) + 1
        return any(count >= 4 for count in tiers.values())

    def load_segment_entries(
        self,
        segment_meta: dict,
        *,
        apply_amendments: bool = True,
    ) -> list:
        """Read entries from a cold segment, applying truth-state amendments if present.

        Delegates to :meth:`SegmentReader.load_segment_entries` — this wrapper
        method allows SegmentStore callers to use it without importing
        SegmentReader directly, and ensures the ``path`` key is populated from
        ``seg_dir`` if not already present in the metadata dict.

        Amendment sidecar: ``<segment_id>.amendments.jsonl`` in the same
        directory as the segment file.  This must be used by ALL cold-segment
        readers — search, resolve, lineage, and compaction.

        Parameters
        ----------
        segment_meta : dict
            Segment metadata dict from the manifest.  May or may not include
            a ``path`` key; if absent, the path is derived from ``seg_dir``.
        apply_amendments : bool
            When True (default), apply truth-state amendment sidecars.

        Returns
        -------
        list[MemoryEntry]
            Entries in file order, with amendment overlays applied.
        """
        if "path" not in segment_meta:
            meta = dict(segment_meta)
            fname = meta.get("filename", "")
            meta["path"] = os.path.join(self.seg_dir, fname)
        else:
            meta = segment_meta
        return SegmentReader.load_segment_entries(meta, apply_amendments=apply_amendments)

    def has_manifest(self) -> bool:
        """Return ``True`` if ``segments/manifest.json`` exists on disk."""
        return os.path.exists(self.manifest_path)

    def verify_integrity(self) -> dict:
        """Verify all segments exist and checksums match.

        Returns ``{"ok": True/False, "errors": [...], "checked": N}``.
        """
        self._manifest.load()
        segments = self._manifest.segments
        errors: list[str] = []
        checked = 0

        for seg in segments:
            fname = seg.get("filename", "")
            seg_path = os.path.join(self.seg_dir, fname)
            if not os.path.exists(seg_path):
                errors.append(f"missing:{fname}")
                continue
            checked += 1
            expected = seg.get("checksum_sha256", "")
            if expected:
                actual_ok = SegmentReader.verify_checksum(seg_path, expected)
                if not actual_ok:
                    errors.append(
                        f"checksum_mismatch:{fname} "
                        f"expected={expected[:12]}…"
                    )

        return {
            "ok": len(errors) == 0,
            "errors": errors,
            "checked": checked,
        }


# ===================================================================
# Module-level helper (used by load/flush for reading rotating file)
# ===================================================================

def _read_ops_from_path(path: str) -> list[dict]:
    """Read all operation envelopes from a JSONL file.

    Used for reading the rotating file during flush/crash-recovery.
    """
    ops: list[dict] = []
    if not os.path.exists(path):
        return ops
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                ops.append(json.loads(line))
            except json.JSONDecodeError as exc:
                logger.warning("Bad hot-log line %d in %s: %s",
                               lineno, path, exc)
    return ops


def _invoke_fault(hook: Optional[Callable[[], None]]) -> None:
    """Invoke a test fault hook if one is installed."""
    if hook is not None:
        hook()
