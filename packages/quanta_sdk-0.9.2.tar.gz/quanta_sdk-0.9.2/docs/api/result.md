# Result

::: quanta.result
