# Changelog · `causeway-auth-jwt`

All notable changes to the `causeway-auth-jwt` Python package will be documented in
this file. Managed automatically by [release-please](https://github.com/googleapis/release-please)
from [Conventional Commits](https://www.conventionalcommits.org/).

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1](https://github.com/tamimbinhakim/causeway/compare/causeway-auth-jwt-v0.3.0...causeway-auth-jwt-v0.3.1) (2026-05-19)


### Features

* **causeway:** reshape events/webhooks around subscribers and a typed Event ([#21](https://github.com/tamimbinhakim/causeway/issues/21)) ([646564f](https://github.com/tamimbinhakim/causeway/commit/646564f66973aba67dd13fc4904ceb924b73c694))

## [0.3.0](https://github.com/tamimbinhakim/causeway/compare/causeway-auth-jwt-v0.2.0...causeway-auth-jwt-v0.3.0) (2026-05-18)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway-auth-jwt:** conform to v1.1 AuthProvider contract ([fd253a2](https://github.com/tamimbinhakim/causeway/commit/fd253a27988662b02628e664ddb8387b6de083d3))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [0.2.0](https://github.com/tamimbinhakim/causeway/compare/causeway-auth-jwt-v0.1.0...causeway-auth-jwt-v0.2.0) (2026-05-17)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway-auth-jwt:** conform to v1.1 AuthProvider contract ([fd253a2](https://github.com/tamimbinhakim/causeway/commit/fd253a27988662b02628e664ddb8387b6de083d3))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## 0.1.0 (2026-05-16)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [Unreleased]
