"""
Tests for ``PentesterPortal.update_project_file`` — wraps
``PUT /api/services/app/Project/UpdateProjectFile``. The method
expects a hydrated CyverProjectFile (instance whose ``_guid`` was
populated by ``from_dict`` after a GET) and sends the full editable
state via ``to_dict()`` plus the wrapper-supplied ``projectId``.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverProjectFile,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _project_file_type
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, FAKE_UUID_2, PORTAL,
)


# A third UUID for the additionalGuid scenarios.
OTHER_UUID = "deadbeef-1234-1234-1234-abcdef987654"


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _hydrated_project_file(
    guid: str = FAKE_UUID_2,
    file_name: str = "screenshot.png",
    file_type: int = _project_file_type.evidence,
) -> CyverProjectFile:
    """Build a CyverProjectFile via from_dict so ``_guid`` is populated
    and ``validate_for_put`` will pass.  Server-managed fields are set
    so the caller doesn't have to worry about them — only the
    caller-modifiable fields default to their unset values."""
    return CyverProjectFile.from_dict({
        "guid":            guid,
        "fileName":        file_name,
        "fileSize":        41017,
        "type":            file_type,
        "mimeType":        "image/png",
        "uploadedAt":      "2026-04-23T20:19:54.9078469Z",
        "uploadedBy":      "henrique.soares@thoropass.com",
        "downloadLink":    None,
        "additionalGuid":  "00000000-0000-0000-0000-000000000000",
        "visibleToClient": False,
        "description":     None,
        "caption":         None,
    })


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    """Suppress CyverPortalInstabilityWarning for every test in this file
    *except* the one that explicitly asserts the warning behaviour."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# update_project_file — wire dispatch
# ---------------------------------------------------------------------------

class TestUpdateProjectFileDispatch:

    def test_dispatches_put_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.update_project_file(FAKE_UUID, _hydrated_project_file())

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "PUT"
        assert path == "/api/services/app/Project/UpdateProjectFile"

    def test_no_query_params_sent(self):
        """Body-only request — no ``params`` kwarg on the wire."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.update_project_file(FAKE_UUID, _hydrated_project_file())

        # Either `params` is absent or it's None.
        kwargs = p._send_api_request.call_args.kwargs
        assert kwargs.get("params") is None

    def test_returns_none_even_when_server_result_is_null(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None  # Cyver wraps null as None

        result = p.update_project_file(FAKE_UUID, _hydrated_project_file())

        assert result is None


# ---------------------------------------------------------------------------
# update_project_file — body construction
# ---------------------------------------------------------------------------

class TestUpdateProjectFileBody:

    def test_body_contains_project_id_and_file_id(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        pf = _hydrated_project_file(guid=FAKE_UUID_2)
        p.update_project_file(FAKE_UUID, pf)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["projectId"] == FAKE_UUID
        assert data["fileId"]    == FAKE_UUID_2

    def test_body_contains_type_and_editable_fields(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        pf = _hydrated_project_file(file_type=_project_file_type.evidence)
        p.update_project_file(FAKE_UUID, pf)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["type"]            == _project_file_type.evidence
        assert "caption"          in data
        assert "description"      in data
        assert "visibleToClient"  in data

    def test_body_omits_server_managed_fields(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.update_project_file(FAKE_UUID, _hydrated_project_file())

        data = p._send_api_request.call_args.kwargs["data"]
        for forbidden in ("fileName", "fileSize", "mimeType",
                          "uploadedAt", "uploadedBy", "downloadLink"):
            assert forbidden not in data, f"server-managed field {forbidden!r} leaked into PUT body"

    def test_body_includes_additional_guid_when_set(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        pf = _hydrated_project_file()
        pf.set_additional_guid(OTHER_UUID)
        p.update_project_file(FAKE_UUID, pf)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["additionalGuid"] == OTHER_UUID

    def test_body_omits_additional_guid_when_unset(self):
        """When _additional_guid is None (the default after from_dict
        with the zero-GUID sentinel), to_dict omits the key entirely."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.update_project_file(FAKE_UUID, _hydrated_project_file())

        data = p._send_api_request.call_args.kwargs["data"]
        assert "additionalGuid" not in data

    def test_caller_modifications_round_trip(self):
        """Mutations via the fluent setters surface in the wire body."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        pf = (
            _hydrated_project_file()
            .set_caption("new caption")
            .set_description("payload note")
            .set_visible_to_client(True)
        )
        p.update_project_file(FAKE_UUID, pf)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["caption"]         == "new caption"
        assert data["description"]     == "payload note"
        assert data["visibleToClient"] is True


# ---------------------------------------------------------------------------
# update_project_file — input validation
# ---------------------------------------------------------------------------

class TestUpdateProjectFileValidation:

    def test_invalid_project_id_raises_data_validation_error(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.update_project_file("not-a-uuid", _hydrated_project_file())
        assert exc_info.value.field  == "project_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()

    def test_non_cyverprojectfile_argument_rejected(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.update_project_file(FAKE_UUID, {"fileId": FAKE_UUID_2})
        assert exc_info.value.field  == "project_file"
        assert exc_info.value.reason == "invalid_type"
        p._send_api_request.assert_not_called()

    def test_unhydrated_project_file_rejected(self):
        """A freshly-constructed CyverProjectFile has _guid = None;
        validate_for_put rejects it because PUT requires fileId."""
        p = _authenticated_pentester_portal()
        bare = CyverProjectFile("fresh.png", 100, _project_file_type.evidence)

        with pytest.raises(CyverDataValidationError) as exc_info:
            p.update_project_file(FAKE_UUID, bare)
        assert exc_info.value.field  == "guid"
        assert exc_info.value.reason == "missing_required"
        p._send_api_request.assert_not_called()

    def test_project_id_validated_before_isinstance_check(self):
        """When both arguments are invalid, the first positional one
        fails first — proves left-to-right validation order."""
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.update_project_file("not-a-uuid", {"not": "a CyverProjectFile"})
        assert exc_info.value.field == "project_id"


# ---------------------------------------------------------------------------
# portal_unstable warning — emitted on first invocation
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        # Reset the per-decorator warn-once flag so this test stays
        # independent of suite ordering.
        PentesterPortal.update_project_file._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.update_project_file(FAKE_UUID, _hydrated_project_file())
            p.update_project_file(FAKE_UUID, _hydrated_project_file())  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "update_project_file" in str(portal_warnings[0].message)
