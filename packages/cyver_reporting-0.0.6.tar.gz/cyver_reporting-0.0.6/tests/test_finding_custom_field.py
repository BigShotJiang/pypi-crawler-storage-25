"""
Tests for CyverFindingCustomField.
"""

import pytest

from CyverReporting.DataTypes.CyverFindingCustomField import CyverFindingCustomField
from CyverReporting.Exceptions import CyverDataValidationError


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldConstruction:

    def test_valid_field_name(self):
        cf = CyverFindingCustomField("CVSS Score")
        assert cf.field == "CVSS Score"

    def test_all_optional_fields_none_after_init(self):
        cf = CyverFindingCustomField("My Field")
        assert cf._field_type is None
        assert cf._value is None
        assert cf._code is None

    def test_empty_field_raises_missing_required(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFindingCustomField("")
        assert exc_info.value.field == "field"
        assert exc_info.value.reason == "missing_required"

    def test_non_string_field_raises_invalid_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFindingCustomField(42)
        assert exc_info.value.field == "field"
        assert exc_info.value.reason == "invalid_type"

    def test_none_field_raises(self):
        with pytest.raises(CyverDataValidationError):
            CyverFindingCustomField(None)

    def test_bool_field_raises(self):
        with pytest.raises(CyverDataValidationError):
            CyverFindingCustomField(True)


# ---------------------------------------------------------------------------
# field property
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldProperty:

    def test_field_property_returns_value(self):
        cf = CyverFindingCustomField("Risk Level")
        assert cf.field == "Risk Level"


# ---------------------------------------------------------------------------
# set_field
# ---------------------------------------------------------------------------

class TestSetField:

    def test_update_field(self):
        cf = CyverFindingCustomField("Old Name")
        cf.set_field("New Name")
        assert cf.field == "New Name"

    def test_returns_self(self):
        cf = CyverFindingCustomField("Name")
        assert cf.set_field("Updated") is cf

    def test_empty_string_raises(self):
        cf = CyverFindingCustomField("Name")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field("")
        assert exc_info.value.reason == "missing_required"

    def test_non_string_raises(self):
        cf = CyverFindingCustomField("Name")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field(99)
        assert exc_info.value.reason == "invalid_type"

    def test_none_raises(self):
        cf = CyverFindingCustomField("Name")
        with pytest.raises(CyverDataValidationError):
            cf.set_field(None)


# ---------------------------------------------------------------------------
# set_field_type
# ---------------------------------------------------------------------------

class TestSetFieldType:

    def test_valid_int(self):
        cf = CyverFindingCustomField("F")
        cf.set_field_type(1)
        assert cf._field_type == 1

    def test_zero_accepted(self):
        cf = CyverFindingCustomField("F")
        cf.set_field_type(0)
        assert cf._field_type == 0

    def test_negative_accepted(self):
        cf = CyverFindingCustomField("F")
        cf.set_field_type(-5)
        assert cf._field_type == -5

    def test_large_int_accepted(self):
        cf = CyverFindingCustomField("F")
        cf.set_field_type(99999)
        assert cf._field_type == 99999

    def test_returns_self(self):
        cf = CyverFindingCustomField("F")
        assert cf.set_field_type(2) is cf

    def test_bool_true_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field_type(True)
        assert exc_info.value.field == "fieldType"
        assert exc_info.value.reason == "invalid_type"

    def test_bool_false_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field_type(False)
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field_type("1")
        assert exc_info.value.reason == "invalid_type"

    def test_float_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_field_type(1.0)
        assert exc_info.value.reason == "invalid_type"

    def test_none_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError):
            cf.set_field_type(None)


# ---------------------------------------------------------------------------
# set_value
# ---------------------------------------------------------------------------

class TestSetValue:

    def test_valid_string(self):
        cf = CyverFindingCustomField("F")
        cf.set_value("9.8")
        assert cf._value == "9.8"

    def test_empty_string_accepted(self):
        cf = CyverFindingCustomField("F")
        cf.set_value("")
        assert cf._value == ""

    def test_returns_self(self):
        cf = CyverFindingCustomField("F")
        assert cf.set_value("v") is cf

    def test_int_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_value(9)
        assert exc_info.value.field == "value"
        assert exc_info.value.reason == "invalid_type"

    def test_bool_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_value(True)
        assert exc_info.value.reason == "invalid_type"

    def test_none_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError):
            cf.set_value(None)


# ---------------------------------------------------------------------------
# set_code
# ---------------------------------------------------------------------------

class TestSetCode:

    def test_valid_string(self):
        cf = CyverFindingCustomField("F")
        cf.set_code("CVSS_BASE")
        assert cf._code == "CVSS_BASE"

    def test_empty_string_accepted(self):
        cf = CyverFindingCustomField("F")
        cf.set_code("")
        assert cf._code == ""

    def test_returns_self(self):
        cf = CyverFindingCustomField("F")
        assert cf.set_code("C") is cf

    def test_int_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_code(123)
        assert exc_info.value.field == "code"
        assert exc_info.value.reason == "invalid_type"

    def test_bool_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError) as exc_info:
            cf.set_code(False)
        assert exc_info.value.reason == "invalid_type"

    def test_none_rejected(self):
        cf = CyverFindingCustomField("F")
        with pytest.raises(CyverDataValidationError):
            cf.set_code(None)


# ---------------------------------------------------------------------------
# Fluent chaining
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldFluent:

    def test_full_chain_returns_same_instance(self):
        cf = CyverFindingCustomField("Score")
        result = (
            cf
            .set_field("Updated Score")
            .set_field_type(3)
            .set_value("HIGH")
            .set_code("RISK_SCORE")
        )
        assert result is cf

    def test_chained_values_are_set(self):
        cf = (
            CyverFindingCustomField("Score")
            .set_field_type(2)
            .set_value("7.5")
            .set_code("CVSS_V3")
        )
        assert cf.field == "Score"
        assert cf._field_type == 2
        assert cf._value == "7.5"
        assert cf._code == "CVSS_V3"


# ---------------------------------------------------------------------------
# to_dict
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldToDict:

    def test_field_only(self):
        cf = CyverFindingCustomField("Name Only")
        assert cf.to_dict() == {"field": "Name Only"}

    def test_all_fields(self):
        cf = (
            CyverFindingCustomField("CVSS Score")
            .set_field_type(1)
            .set_value("9.8")
            .set_code("CVSS_BASE")
        )
        d = cf.to_dict()
        assert d == {
            "field": "CVSS Score",
            "fieldType": 1,
            "value": "9.8",
            "code": "CVSS_BASE",
        }

    def test_unset_fields_absent(self):
        cf = CyverFindingCustomField("Partial").set_value("foo")
        d = cf.to_dict()
        assert "fieldType" not in d
        assert "code" not in d
        assert d["value"] == "foo"

    def test_field_type_zero_included(self):
        cf = CyverFindingCustomField("F").set_field_type(0)
        d = cf.to_dict()
        assert "fieldType" in d
        assert d["fieldType"] == 0

    def test_value_empty_string_included(self):
        cf = CyverFindingCustomField("F").set_value("")
        d = cf.to_dict()
        assert "value" in d
        assert d["value"] == ""

    def test_code_empty_string_included(self):
        cf = CyverFindingCustomField("F").set_code("")
        d = cf.to_dict()
        assert "code" in d
        assert d["code"] == ""


# ---------------------------------------------------------------------------
# from_dict
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldFromDict:

    def test_full_from_dict(self):
        data = {
            "field": "CVSS Score",
            "fieldType": 2,
            "value": "8.1",
            "code": "CVSS_V3",
        }
        cf = CyverFindingCustomField.from_dict(data)
        assert cf.field == "CVSS Score"
        assert cf._field_type == 2
        assert cf._value == "8.1"
        assert cf._code == "CVSS_V3"

    def test_minimal_from_dict(self):
        cf = CyverFindingCustomField.from_dict({"field": "Minimal"})
        assert cf.field == "Minimal"
        assert cf._field_type is None
        assert cf._value is None
        assert cf._code is None

    def test_roundtrip_full(self):
        original = (
            CyverFindingCustomField("Risk")
            .set_field_type(4)
            .set_value("Critical")
            .set_code("RISK_LVL")
        )
        restored = CyverFindingCustomField.from_dict(original.to_dict())
        assert restored.field == original.field
        assert restored._field_type == original._field_type
        assert restored._value == original._value
        assert restored._code == original._code

    def test_roundtrip_partial(self):
        original = CyverFindingCustomField("Partial").set_code("X")
        restored = CyverFindingCustomField.from_dict(original.to_dict())
        assert restored.field == "Partial"
        assert restored._code == "X"
        assert restored._field_type is None
        assert restored._value is None


# ---------------------------------------------------------------------------
# __repr__
# ---------------------------------------------------------------------------

class TestCyverFindingCustomFieldRepr:

    def test_repr_field_only(self):
        cf = CyverFindingCustomField("Score")
        r = repr(cf)
        assert "CyverFindingCustomField" in r
        assert "Score" in r

    def test_repr_all_fields(self):
        cf = (
            CyverFindingCustomField("Score")
            .set_field_type(1)
            .set_value("9.8")
            .set_code("CVSS_BASE")
        )
        r = repr(cf)
        assert "fieldType=1" in r
        assert "value='9.8'" in r
        assert "code='CVSS_BASE'" in r

    def test_repr_omits_unset_fields(self):
        cf = CyverFindingCustomField("Score")
        r = repr(cf)
        assert "fieldType" not in r
        assert "value" not in r
        assert "code" not in r
