"""
Tests for ``PentesterPortal.get_project_files`` and its iterator
sibling ``get_all_project_files`` — wraps the undocumented frontend
endpoint ``GET /api/services/app/Project/GetAllProjectFiles``, which
returns every project file regardless of type.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverProjectFile,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _project_file_type
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, FAKE_UUID_2, PORTAL,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _authenticated_pentester_portal() -> PentesterPortal:
    """Mirror the helper used in test_portal.py — bypasses real auth."""
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _file_dict(guid: str, file_name: str = "doc.pdf",
               file_type: int = _project_file_type.report) -> dict:
    """Minimal valid item shape returned by GetAllProjectFiles."""
    return {
        "guid":            guid,
        "fileName":        file_name,
        "fileSize":        12345,
        "type":            file_type,
        "mimeType":        "application/pdf",
        "uploadedAt":      "2026-04-23T20:19:54.9078469Z",
        "uploadedBy":      "henrique.soares@thoropass.com",
        "downloadLink":    None,
        "additionalGuid":  "00000000-0000-0000-0000-000000000000",
        "visibleToClient": False,
        "description":     None,
        "caption":         None,
    }


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    """Suppress CyverPortalInstabilityWarning for every test in this file
    *except* the one that explicitly asserts the warning behaviour."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# get_project_files — wire dispatch / parameter shape
# ---------------------------------------------------------------------------

class TestGetProjectFilesDispatch:

    def test_dispatches_get_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_files(FAKE_UUID)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "GET"
        assert path == "/api/services/app/Project/GetAllProjectFiles"

    def test_query_params_carry_pagination_and_project_id(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_files(FAKE_UUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {
            "projectId":      FAKE_UUID,
            "maxResultCount": 10,
            "skipCount":      0,
        }

    def test_no_filter_param_sent(self):
        """Regression: GetAllProjectFiles does not accept a ``filter``
        query parameter (unlike GetProjectImagesFiles)."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_files(FAKE_UUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert "filter" not in params

    def test_pagination_params_propagate(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_files(FAKE_UUID, count_max=25, count_skip=50)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["maxResultCount"] == 25
        assert params["skipCount"]      == 50


# ---------------------------------------------------------------------------
# get_project_files — hydration across the full type universe
# ---------------------------------------------------------------------------

class TestGetProjectFilesHydration:

    def test_happy_path_returns_dict_with_hydrated_items(self):
        """Mixed-type response: image, scanner import, final report —
        all hydrate cleanly into CyverProjectFile under the widened
        ``_project_file_type._valid`` set."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 3,
            "items": [
                _file_dict(FAKE_UUID,   file_type=_project_file_type.evidence),     # 6
                _file_dict(FAKE_UUID_2, file_type=_project_file_type.import_qualys_scan_report),  # 46
                _file_dict("c0c0c0c0-c0c0-c0c0-c0c0-c0c0c0c0c0c0",
                           file_type=_project_file_type.final_report),              # 50
            ],
        }

        result = p.get_project_files(FAKE_UUID)

        assert result["totalCount"] == 3
        assert len(result["items"])  == 3
        assert all(isinstance(f, CyverProjectFile) for f in result["items"])
        assert [f.file_type for f in result["items"]] == [
            _project_file_type.evidence,
            _project_file_type.import_qualys_scan_report,
            _project_file_type.final_report,
        ]

    def test_scanner_import_type_hydrates_cleanly(self):
        """Regression: ``type=46`` (Qualys Scan Report) was rejected by
        the narrow ``_valid`` set; with the widening it must hydrate."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_file_dict(FAKE_UUID, file_type=46)],
        }

        result = p.get_project_files(FAKE_UUID)

        assert len(result["items"]) == 1
        assert isinstance(result["items"][0], CyverProjectFile)
        assert result["items"][0].file_type == 46

    def test_final_report_type_hydrates_cleanly(self):
        """Regression: ``type=50`` (Final Report) likewise."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_file_dict(FAKE_UUID, file_type=50)],
        }

        result = p.get_project_files(FAKE_UUID)

        assert result["items"][0].file_type == _project_file_type.final_report

    def test_empty_response_returns_empty_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        result = p.get_project_files(FAKE_UUID)

        assert result["items"]      == []
        assert result["totalCount"] == 0

    def test_truly_unknown_type_still_raises(self):
        """Behavioural-contract guard: a ``type`` outside
        ``_project_file_type._valid`` (e.g. a hypothetical future
        code 999) must surface as a CyverDataValidationError so
        schema drift is loud, not silent."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_file_dict(FAKE_UUID, file_type=999)],
        }

        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_project_files(FAKE_UUID)
        assert exc_info.value.field  == "type"
        assert exc_info.value.reason == "invalid_value"


# ---------------------------------------------------------------------------
# get_project_files — input validation
# ---------------------------------------------------------------------------

class TestGetProjectFilesValidation:

    def test_invalid_project_id_raises_data_validation_error(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_project_files("not-a-uuid")
        assert exc_info.value.field  == "project_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()


# ---------------------------------------------------------------------------
# portal_unstable warning — emitted on first invocation
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        # Reset the per-decorator warn-once flag so this test stays
        # independent of suite ordering.
        PentesterPortal.get_project_files._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.get_project_files(FAKE_UUID)
            p.get_project_files(FAKE_UUID)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "get_project_files" in str(portal_warnings[0].message)


# ---------------------------------------------------------------------------
# get_all_project_files — pagination behaviour
# ---------------------------------------------------------------------------

class TestGetAllProjectFiles:

    def test_iterates_pages_and_yields_hydrated_files(self):
        p = _authenticated_pentester_portal()
        # Two pages: 50 + 25 = 75 items, all of various valid types.
        page_1 = {"totalCount": 75,
                  "items": [_file_dict(FAKE_UUID, file_type=_project_file_type.report) for _ in range(50)]}
        page_2 = {"totalCount": 75,
                  "items": [_file_dict(FAKE_UUID_2, file_type=_project_file_type.import_burp) for _ in range(25)]}
        p._send_api_request.side_effect = [page_1, page_2]

        items = list(p.get_all_project_files(FAKE_UUID))

        assert len(items) == 75
        assert all(isinstance(f, CyverProjectFile) for f in items)
        # First 50 are reports, next 25 are Burp imports — preserved order.
        assert items[0].file_type   == _project_file_type.report
        assert items[49].file_type  == _project_file_type.report
        assert items[50].file_type  == _project_file_type.import_burp
        assert items[74].file_type  == _project_file_type.import_burp

    def test_invalid_project_id_raises_before_iteration_starts(self):
        p = _authenticated_pentester_portal()
        gen = p.get_all_project_files("not-a-uuid")
        with pytest.raises(CyverDataValidationError) as exc_info:
            next(gen)
        assert exc_info.value.field == "project_id"
        p._send_api_request.assert_not_called()
