"""
Tests for CyverReporting.Exceptions — hierarchy, attributes, and reason codes.
"""

import pytest

from CyverReporting.Exceptions import (
    CyverError,
    CyverAuthError,
    Cyver2FARequired,
    CyverHTTPError,
    CyverNotFoundError,
    CyverPermissionError,
    CyverRateLimitError,
)


# ---------------------------------------------------------------------------
# Inheritance hierarchy
# ---------------------------------------------------------------------------

class TestHierarchy:

    def test_cyver_error_is_exception(self):
        assert issubclass(CyverError, Exception)

    def test_cyver_error_is_not_runtime_error(self):
        assert not issubclass(CyverError, RuntimeError)

    def test_auth_error_is_cyver_error(self):
        assert issubclass(CyverAuthError, CyverError)

    def test_2fa_required_is_auth_error(self):
        assert issubclass(Cyver2FARequired, CyverAuthError)

    def test_2fa_required_is_cyver_error(self):
        assert issubclass(Cyver2FARequired, CyverError)

    def test_http_error_is_cyver_error(self):
        assert issubclass(CyverHTTPError, CyverError)

    def test_http_error_is_not_runtime_error(self):
        assert not issubclass(CyverHTTPError, RuntimeError)

    def test_not_found_is_http_error(self):
        assert issubclass(CyverNotFoundError, CyverHTTPError)

    def test_permission_is_http_error(self):
        assert issubclass(CyverPermissionError, CyverHTTPError)

    def test_rate_limit_is_http_error(self):
        assert issubclass(CyverRateLimitError, CyverHTTPError)

    def test_all_caught_by_cyver_error(self):
        instances = [
            CyverAuthError("x"),
            Cyver2FARequired("x"),
            CyverHTTPError("x"),
            CyverNotFoundError("x"),
            CyverPermissionError("x"),
            CyverRateLimitError("x"),
        ]
        for exc in instances:
            assert isinstance(exc, CyverError)
            assert isinstance(exc, Exception)

    def test_http_subclasses_caught_by_http_error(self):
        for exc in [CyverNotFoundError("x"), CyverPermissionError("x"), CyverRateLimitError("x")]:
            assert isinstance(exc, CyverHTTPError)


# ---------------------------------------------------------------------------
# CyverError
# ---------------------------------------------------------------------------

class TestCyverError:

    def test_message(self):
        e = CyverError("something went wrong")
        assert str(e) == "something went wrong"

    def test_raise_and_catch(self):
        with pytest.raises(CyverError):
            raise CyverError("test")


# ---------------------------------------------------------------------------
# CyverAuthError
# ---------------------------------------------------------------------------

class TestCyverAuthError:

    def test_message(self):
        e = CyverAuthError("bad credentials")
        assert str(e) == "bad credentials"

    def test_reason_defaults_to_none(self):
        assert CyverAuthError("x").reason is None

    def test_reason_set(self):
        e = CyverAuthError("x", reason="access_token_missing")
        assert e.reason == "access_token_missing"

    @pytest.mark.parametrize("reason", [
        "not_authenticated",
        "2fa_not_configured",
        "access_token_missing",
        "refresh_token_missing",
        "user_id_missing",
    ])
    def test_known_reason_codes(self, reason):
        e = CyverAuthError("x", reason=reason)
        assert e.reason == reason

    def test_caught_by_cyver_error(self):
        with pytest.raises(CyverError):
            raise CyverAuthError("fail")


# ---------------------------------------------------------------------------
# Cyver2FARequired
# ---------------------------------------------------------------------------

class TestCyver2FARequired:

    def test_reason_is_always_2fa_required(self):
        assert Cyver2FARequired("x").reason == "2fa_required"

    def test_user_id_default_is_none(self):
        assert Cyver2FARequired("x").user_id is None

    def test_providers_default_is_empty_list(self):
        assert Cyver2FARequired("x").providers == []

    def test_user_id_set(self):
        e = Cyver2FARequired("x", user_id="abc-123")
        assert e.user_id == "abc-123"

    def test_providers_set(self):
        e = Cyver2FARequired("x", providers=["Email", "SMS"])
        assert e.providers == ["Email", "SMS"]

    def test_caught_by_cyver_auth_error(self):
        with pytest.raises(CyverAuthError):
            raise Cyver2FARequired("fail")

    def test_caught_by_cyver_error(self):
        with pytest.raises(CyverError):
            raise Cyver2FARequired("fail")


# ---------------------------------------------------------------------------
# CyverHTTPError
# ---------------------------------------------------------------------------

class TestCyverHTTPError:

    def test_message(self):
        assert str(CyverHTTPError("failed")) == "failed"

    def test_all_attributes_default_to_none(self):
        e = CyverHTTPError("failed")
        assert e.status_code is None
        assert e.method is None
        assert e.url is None

    def test_all_attributes_set(self):
        e = CyverHTTPError("failed", status_code=503, method="GET", url="https://x.io/api")
        assert e.status_code == 503
        assert e.method == "GET"
        assert e.url == "https://x.io/api"

    def test_caught_by_cyver_error(self):
        with pytest.raises(CyverError):
            raise CyverHTTPError("fail")


# ---------------------------------------------------------------------------
# CyverNotFoundError
# ---------------------------------------------------------------------------

class TestCyverNotFoundError:

    def test_status_code_is_404(self):
        assert CyverNotFoundError("x").status_code == 404

    def test_method_and_url(self):
        e = CyverNotFoundError("x", method="GET", url="https://x.io/api/123")
        assert e.method == "GET"
        assert e.url == "https://x.io/api/123"

    def test_caught_by_http_error(self):
        with pytest.raises(CyverHTTPError):
            raise CyverNotFoundError("not found")


# ---------------------------------------------------------------------------
# CyverPermissionError
# ---------------------------------------------------------------------------

class TestCyverPermissionError:

    def test_default_status_code_is_403(self):
        assert CyverPermissionError("x").status_code == 403

    def test_status_code_401(self):
        assert CyverPermissionError("x", status_code=401).status_code == 401

    def test_status_code_403(self):
        assert CyverPermissionError("x", status_code=403).status_code == 403

    def test_method_and_url(self):
        e = CyverPermissionError("x", status_code=403, method="DELETE", url="https://x.io/api/1")
        assert e.method == "DELETE"
        assert e.url == "https://x.io/api/1"

    def test_caught_by_http_error(self):
        with pytest.raises(CyverHTTPError):
            raise CyverPermissionError("forbidden")


# ---------------------------------------------------------------------------
# CyverRateLimitError
# ---------------------------------------------------------------------------

class TestCyverRateLimitError:

    def test_status_code_is_429(self):
        assert CyverRateLimitError("x").status_code == 429

    def test_method_and_url(self):
        e = CyverRateLimitError("x", method="GET", url="https://x.io/api")
        assert e.method == "GET"
        assert e.url == "https://x.io/api"

    def test_caught_by_http_error(self):
        with pytest.raises(CyverHTTPError):
            raise CyverRateLimitError("rate limited")
