"""
Tests for CyverClientAddress, CyverClientInformation, and CyverClient —
focusing on the from_dict() deserialization path.
"""

import pytest

from CyverReporting import CyverDataValidationError
from CyverReporting.DataTypes import (
    CyverClientAddress,
    CyverClientInformation,
    CyverClient,
)

FAKE_UUID = "12345678-1234-1234-1234-123456789abc"


# ---------------------------------------------------------------------------
# CyverClientAddress.from_dict()
# ---------------------------------------------------------------------------

class TestCyverClientAddressFromDict:

    def test_all_fields_populated(self):
        data = {
            "street": "123 Main St",
            "postalCode": "94105",
            "city": "San Francisco",
            "country": "United States",
            "stateOrProvince": "CA",
        }
        addr = CyverClientAddress.from_dict(data)
        assert addr._street == "123 Main St"
        assert addr._postal_code == "94105"
        assert addr._city == "San Francisco"
        assert addr._country == "United States"
        assert addr._state_or_province == "CA"

    def test_empty_dict_leaves_all_none(self):
        addr = CyverClientAddress.from_dict({})
        assert addr._street is None
        assert addr._postal_code is None
        assert addr._city is None
        assert addr._country is None
        assert addr._state_or_province is None

    def test_partial_fields(self):
        addr = CyverClientAddress.from_dict({"city": "London", "country": "UK"})
        assert addr._city == "London"
        assert addr._country == "UK"
        assert addr._street is None
        assert addr._postal_code is None
        assert addr._state_or_province is None

    def test_returns_cydata_client_address_instance(self):
        addr = CyverClientAddress.from_dict({"city": "Berlin"})
        assert isinstance(addr, CyverClientAddress)

    def test_to_dict_round_trip(self):
        data = {
            "street": "Baker St",
            "postalCode": "NW1 6XE",
            "city": "London",
            "country": "UK",
        }
        addr = CyverClientAddress.from_dict(data)
        result = addr.to_dict()
        assert result["street"] == "Baker St"
        assert result["postalCode"] == "NW1 6XE"
        assert result["city"] == "London"
        assert result["country"] == "UK"
        assert "stateOrProvince" not in result

    @pytest.mark.parametrize("key", ["street", "postalCode", "city", "country", "stateOrProvince"])
    def test_non_string_field_raises(self, key):
        with pytest.raises(CyverDataValidationError):
            CyverClientAddress.from_dict({key: 42})


# ---------------------------------------------------------------------------
# CyverClientInformation.from_dict()
# ---------------------------------------------------------------------------

class TestCyverClientInformationFromDict:

    def test_all_flat_fields_populated(self):
        data = {"companyName": "Acme Corp", "website": "https://acme.example.com"}
        info = CyverClientInformation.from_dict(data)
        assert info._company_name == "Acme Corp"
        assert info._website == "https://acme.example.com"
        assert info._address is None

    def test_empty_dict_leaves_all_none(self):
        info = CyverClientInformation.from_dict({})
        assert info._company_name is None
        assert info._website is None
        assert info._address is None

    def test_nested_address_deserialized(self):
        data = {
            "companyName": "Acme Corp",
            "address": {"city": "New York", "country": "US"},
        }
        info = CyverClientInformation.from_dict(data)
        assert isinstance(info._address, CyverClientAddress)
        assert info._address._city == "New York"
        assert info._address._country == "US"

    def test_absent_address_leaves_none(self):
        info = CyverClientInformation.from_dict({"companyName": "Corp"})
        assert info._address is None

    def test_returns_cydata_client_information_instance(self):
        info = CyverClientInformation.from_dict({})
        assert isinstance(info, CyverClientInformation)

    def test_to_dict_round_trip(self):
        data = {
            "companyName": "Acme",
            "website": "https://acme.io",
            "address": {"city": "Austin", "country": "US"},
        }
        info = CyverClientInformation.from_dict(data)
        result = info.to_dict()
        assert result["companyName"] == "Acme"
        assert result["website"] == "https://acme.io"
        assert result["address"]["city"] == "Austin"
        assert result["address"]["country"] == "US"


# ---------------------------------------------------------------------------
# CyverClient.from_dict() — delegation to nested from_dict() methods
# ---------------------------------------------------------------------------

class TestCyverClientFromDict:

    def test_basic_fields(self):
        data = {"id": FAKE_UUID, "name": "Test Client"}
        client = CyverClient.from_dict(data)
        assert client._id == FAKE_UUID
        assert client._name == "Test Client"

    def test_nested_client_information_delegated(self):
        data = {
            "id": FAKE_UUID,
            "name": "Test Client",
            "clientInformation": {
                "companyName": "Acme Corp",
                "website": "https://acme.io",
            },
        }
        client = CyverClient.from_dict(data)
        assert isinstance(client._client_information, CyverClientInformation)
        assert client._client_information._company_name == "Acme Corp"
        assert client._client_information._website == "https://acme.io"

    def test_nested_address_within_client_information(self):
        data = {
            "id": FAKE_UUID,
            "name": "Test Client",
            "clientInformation": {
                "companyName": "Acme Corp",
                "address": {
                    "street": "123 Main St",
                    "city": "San Francisco",
                    "country": "United States",
                },
            },
        }
        client = CyverClient.from_dict(data)
        addr = client._client_information._address
        assert isinstance(addr, CyverClientAddress)
        assert addr._street == "123 Main St"
        assert addr._city == "San Francisco"
        assert addr._country == "United States"

    def test_absent_client_information_leaves_none(self):
        data = {"id": FAKE_UUID, "name": "No Info Client"}
        client = CyverClient.from_dict(data)
        assert client._client_information is None

    def test_returns_cydata_client_instance(self):
        data = {"name": "Test"}
        assert isinstance(CyverClient.from_dict(data), CyverClient)
