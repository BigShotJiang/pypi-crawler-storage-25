"""
Tests for the cache-disable feature: ``cache_dir`` kwarg,
``CYVER_REPORTING_CACHE_DIR`` environment variable, ``CyverCachingError``,
and the catch-and-degrade contract at every entry point that touches
the credential cache.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from CyverReporting import (
    ClientPortal,
    ClientSession,
    CyverCachingError,
    CyverError,
    CyverSession,
    PentesterPortal,
    PentesterSession,
)
from CyverReporting.Exceptions import CyverDataValidationError
import CyverReporting.Exceptions as ExceptionsPkg
from CyverReporting.Session import (
    _CACHE_DIR_ENV_VAR,
    _CACHE_DIR_UNSET,
    _resolve_cache_dir,
)
from tests.conftest import (
    FAKE_UUID, PASSWORD, PORTAL, USERNAME,
)


# ---------------------------------------------------------------------------
# CyverCachingError — exception class shape
# ---------------------------------------------------------------------------

class TestCyverCachingErrorExceptionClass:

    def test_subclass_of_cyver_error(self):
        assert issubclass(CyverCachingError, CyverError)

    def test_carries_cache_kind_and_reason_fields(self):
        exc = CyverCachingError("boom", cache_kind="oauth", reason="decrypt_failed")
        assert exc.cache_kind == "oauth"
        assert exc.reason     == "decrypt_failed"
        assert str(exc)       == "boom"

    def test_fields_default_to_none(self):
        exc = CyverCachingError("oh no")
        assert exc.cache_kind is None
        assert exc.reason     is None

    def test_importable_from_top_level_and_exceptions_subpackage(self):
        from CyverReporting import CyverCachingError as E1
        from CyverReporting.Exceptions import CyverCachingError as E2
        assert E1 is E2 is CyverCachingError

    def test_listed_in_exceptions_all(self):
        assert "CyverCachingError" in ExceptionsPkg.__all__


# ---------------------------------------------------------------------------
# _resolve_cache_dir — full resolution truth table
# ---------------------------------------------------------------------------

class TestResolveCacheDir:

    def test_kwarg_unset_env_unset_returns_platformdirs_default(self):
        # Empty env mapping forces the platformdirs fallback path.
        result = _resolve_cache_dir(_CACHE_DIR_UNSET, env={})
        assert isinstance(result, Path)
        # The default uses `user_cache_dir("cyver", appauthor=False)`.  We can't
        # pin it to an absolute path (it varies per OS / per user), so we just
        # assert it ends with "cyver" — which platformdirs guarantees on every
        # supported OS.
        assert result.name == "cyver"

    def test_kwarg_unset_env_empty_returns_none(self):
        result = _resolve_cache_dir(_CACHE_DIR_UNSET, env={_CACHE_DIR_ENV_VAR: ""})
        assert result is None

    def test_kwarg_unset_env_path_returns_that_path(self):
        result = _resolve_cache_dir(_CACHE_DIR_UNSET, env={_CACHE_DIR_ENV_VAR: "/tmp/cyver-test"})
        assert result == Path("/tmp/cyver-test")

    def test_kwarg_none_returns_none_regardless_of_env(self):
        # Env var set to a path; kwarg=None should still win.
        result = _resolve_cache_dir(None, env={_CACHE_DIR_ENV_VAR: "/tmp/should-be-ignored"})
        assert result is None

    def test_kwarg_string_returns_that_path_regardless_of_env(self):
        result = _resolve_cache_dir("/explicit", env={_CACHE_DIR_ENV_VAR: ""})
        assert result == Path("/explicit")

    def test_kwarg_path_returns_same_path(self):
        explicit = Path("/explicit")
        result   = _resolve_cache_dir(explicit, env={})
        assert result == explicit

    def test_kwarg_invalid_type_raises_data_validation_error(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _resolve_cache_dir(123, env={})
        assert exc_info.value.field  == "cache_dir"
        assert exc_info.value.reason == "invalid_type"


# ---------------------------------------------------------------------------
# CyverSession constructor — cache_dir kwarg integration
# ---------------------------------------------------------------------------

class TestConstructorCacheDirKwarg:
    """The kwarg flows through every public session class without
    breaking inheritance."""

    def test_pentester_session_disabled_construction(self):
        s = PentesterSession(cache_dir=None)
        assert s._cache_enabled is False
        assert s._cache_dir     is None

    def test_client_session_disabled_construction(self):
        s = ClientSession(cache_dir=None)
        assert s._cache_enabled is False

    def test_pentester_portal_disabled_construction(self):
        p = PentesterPortal(cache_dir=None)
        assert p._cache_enabled is False

    def test_client_portal_disabled_construction(self):
        p = ClientPortal(cache_dir=None)
        assert p._cache_enabled is False

    def test_explicit_path_resolves_to_path(self, tmp_path):
        s = PentesterSession(cache_dir=tmp_path)
        assert s._cache_enabled is True
        assert s._cache_dir     == tmp_path

    def test_default_construction_uses_platformdirs(self):
        # Make sure the env var isn't influencing the default branch.
        with patch.dict("os.environ", {}, clear=False):
            os_environ = __import__("os").environ
            os_environ.pop(_CACHE_DIR_ENV_VAR, None)
            s = PentesterSession()
            assert s._cache_enabled is True
            assert s._cache_dir.name == "cyver"

    def test_invalid_cache_dir_type_raises(self):
        with pytest.raises(CyverDataValidationError):
            PentesterSession(cache_dir=123)

    def test_disabled_construction_logs_info(self, caplog):
        with caplog.at_level(logging.INFO, logger="CyverReporting.Session"):
            PentesterSession(cache_dir=None)
        assert any("disabled" in rec.message.lower() for rec in caplog.records)


# ---------------------------------------------------------------------------
# Cache I/O methods — short-circuit when disabled
# ---------------------------------------------------------------------------

class TestCacheIOShortCircuit:
    """When ``self._cache_enabled is False``, every cache method must
    return its empty-state value without touching the filesystem."""

    def _disabled_session(self):
        s = CyverSession(cache_dir=None)
        s.portal = PORTAL
        return s

    def test_fetch_oauth_returns_template_without_filesystem_access(self):
        s = self._disabled_session()
        with patch("builtins.open") as mock_open:
            result = s._fetch_oauth_cache(USERNAME, PASSWORD)
        assert result == {"accessToken": None, "refreshToken": None,
                          "userId": None, "portal": None}
        mock_open.assert_not_called()

    def test_save_oauth_is_silent_no_op(self):
        s = self._disabled_session()
        s.access_token  = "tok"
        s.refresh_token = "ref"
        s.user_id       = FAKE_UUID
        with patch("os.open") as mock_os_open:
            assert s._save_oauth_cache(USERNAME, PASSWORD) is None
        mock_os_open.assert_not_called()

    def test_delete_oauth_is_silent_no_op(self):
        s = self._disabled_session()
        # We can't assert "Path.unlink wasn't called" without knowing the
        # filename; instead assert the method returns cleanly.
        assert s._delete_oauth_cache(USERNAME, PASSWORD) is None

    def test_fetch_apikey_returns_template_without_filesystem_access(self):
        # API-key sessions normally probe at construction; bypass that
        # by patching the probe to avoid network.
        with patch.object(CyverSession, "_probe_portal"):
            s = CyverSession(portal=PORTAL, api_key="sk-xxx", cache_dir=None)
        with patch("builtins.open") as mock_open:
            result = s._fetch_apikey_cache()
        assert result == {"portal": None}
        mock_open.assert_not_called()

    def test_save_apikey_is_silent_no_op(self):
        with patch.object(CyverSession, "_probe_portal"):
            s = CyverSession(portal=PORTAL, api_key="sk-xxx", cache_dir=None)
        with patch("os.open") as mock_os_open:
            assert s._save_apikey_cache() is None
        mock_os_open.assert_not_called()


# ---------------------------------------------------------------------------
# Cache I/O methods — narrow exception → CyverCachingError mapping
# ---------------------------------------------------------------------------

class TestCacheIOErrorMapping:
    """Real failures inside cache I/O are wrapped into ``CyverCachingError``
    with the right ``reason`` code; cold-start (file missing) is **not**
    an error."""

    def _enabled_session(self, tmp_path):
        s = CyverSession(cache_dir=tmp_path)
        s.portal = PORTAL
        return s

    def test_fetch_oauth_cold_start_returns_template(self, tmp_path):
        # tmp_path exists but contains no cache file — cold start.
        s = self._enabled_session(tmp_path)
        result = s._fetch_oauth_cache(USERNAME, PASSWORD)
        assert result == {"accessToken": None, "refreshToken": None,
                          "userId": None, "portal": None}

    def test_fetch_oauth_corrupted_json_raises_corrupted(self, tmp_path):
        s = self._enabled_session(tmp_path)
        # Write a non-JSON file to the location the fetch will look at.
        from CyverReporting.Session import _calculate_oauth_cache_filename
        secret  = f"{PORTAL}:{USERNAME}:{PASSWORD}"
        target  = _calculate_oauth_cache_filename(secret, tmp_path)
        target.write_text("this is not json {{{")
        with pytest.raises(CyverCachingError) as exc_info:
            s._fetch_oauth_cache(USERNAME, PASSWORD)
        assert exc_info.value.cache_kind == "oauth"
        assert exc_info.value.reason     == "corrupted"

    def test_fetch_oauth_unrecognised_envelope_raises_corrupted(self, tmp_path):
        s = self._enabled_session(tmp_path)
        from CyverReporting.Session import _calculate_oauth_cache_filename
        secret  = f"{PORTAL}:{USERNAME}:{PASSWORD}"
        target  = _calculate_oauth_cache_filename(secret, tmp_path)
        # Valid JSON but missing required envelope keys.
        target.write_text(json.dumps({"version": "ancient"}))
        with pytest.raises(CyverCachingError) as exc_info:
            s._fetch_oauth_cache(USERNAME, PASSWORD)
        assert exc_info.value.reason == "corrupted"

    def test_fetch_oauth_decrypt_failure_raises_decrypt_failed(self, tmp_path):
        s = self._enabled_session(tmp_path)
        from CyverReporting.Session import _calculate_oauth_cache_filename
        secret  = f"{PORTAL}:{USERNAME}:{PASSWORD}"
        target  = _calculate_oauth_cache_filename(secret, tmp_path)
        # Valid envelope but ciphertext that won't decrypt with the derived key.
        target.write_text(json.dumps({
            "v": 1,
            "kdf": "PBKDF2HMAC-SHA256",
            "iterations": 100000,
            "salt_b64": "AAAAAAAAAAAAAAAAAAAAAA==",
            "cipher": "Fernet",
            "ciphertext_b64": "Z0FBQUFBQmltAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        }))
        with pytest.raises(CyverCachingError) as exc_info:
            s._fetch_oauth_cache(USERNAME, PASSWORD)
        assert exc_info.value.reason == "decrypt_failed"

    def test_save_oauth_oserror_raises_write_failed(self, tmp_path):
        s = self._enabled_session(tmp_path)
        s.access_token  = "tok"
        s.refresh_token = "ref"
        s.user_id       = FAKE_UUID
        # Simulate OSError on the file write.
        with patch("os.open", side_effect=OSError("read-only fs")):
            with pytest.raises(CyverCachingError) as exc_info:
                s._save_oauth_cache(USERNAME, PASSWORD)
        assert exc_info.value.cache_kind == "oauth"
        assert exc_info.value.reason     == "write_failed"

    def test_delete_oauth_oserror_raises_delete_failed(self, tmp_path):
        s = self._enabled_session(tmp_path)
        with patch.object(Path, "unlink", side_effect=OSError("readonly")):
            with pytest.raises(CyverCachingError) as exc_info:
                s._delete_oauth_cache(USERNAME, PASSWORD)
        assert exc_info.value.cache_kind == "oauth"
        assert exc_info.value.reason     == "delete_failed"

    def test_fetch_apikey_corrupted_json_raises(self, tmp_path):
        with patch.object(CyverSession, "_probe_portal"):
            s = CyverSession(portal=PORTAL, api_key="sk-xxx", cache_dir=tmp_path)
        from CyverReporting.Session import _calculate_apikey_cache_filename
        target = _calculate_apikey_cache_filename("sk-xxx", tmp_path)
        target.write_text("not json {{{")
        with pytest.raises(CyverCachingError) as exc_info:
            s._fetch_apikey_cache()
        assert exc_info.value.cache_kind == "apikey"
        assert exc_info.value.reason     == "corrupted"


# ---------------------------------------------------------------------------
# authenticate() — degrade gracefully when cache is damaged
# ---------------------------------------------------------------------------

class TestAuthenticateDegradesOnCacheError:
    """A damaged cache must never break authentication.  The library
    catches ``CyverCachingError`` at the boundary and continues with a
    fresh portal probe + re-authentication."""

    def test_authenticate_logs_warning_and_proceeds_when_fetch_fails(self, caplog):
        session = CyverSession()
        with patch.object(session, "_fetch_oauth_cache",
                          side_effect=CyverCachingError("bad", cache_kind="oauth", reason="decrypt_failed")), \
             patch.object(session, "_delete_oauth_cache"), \
             patch.object(session, "_probe_portal"), \
             patch.object(session, "_save_oauth_cache"), \
             patch.object(session, "_send_api_request",
                          return_value={"accessToken": "a", "refreshToken": "r", "userId": FAKE_UUID}), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            with caplog.at_level(logging.WARNING, logger="CyverReporting.Session"):
                ok = session.authenticate(PORTAL, USERNAME, PASSWORD)

        assert ok is True
        assert any("damaged" in rec.message.lower() and "oauth" in rec.message.lower()
                   for rec in caplog.records)

    def test_authenticate_logs_warning_when_save_fails_after_success(self, caplog):
        session = CyverSession()
        empty_cache = {"accessToken": None, "refreshToken": None, "userId": None, "portal": None}
        with patch.object(session, "_fetch_oauth_cache", return_value=empty_cache), \
             patch.object(session, "_probe_portal"), \
             patch.object(session, "_save_oauth_cache",
                          side_effect=CyverCachingError("disk full", cache_kind="oauth", reason="write_failed")), \
             patch.object(session, "_send_api_request",
                          return_value={"accessToken": "a", "refreshToken": "r", "userId": FAKE_UUID}), \
             patch("CyverReporting.Session._validate_jwt_token"), \
             patch("CyverReporting.Session._validate_uuid"):
            with caplog.at_level(logging.WARNING, logger="CyverReporting.Session"):
                ok = session.authenticate(PORTAL, USERNAME, PASSWORD)

        assert ok is True
        assert any("write" in rec.message.lower() for rec in caplog.records)


# ---------------------------------------------------------------------------
# API-key constructor — cache disabled / cache damaged paths
# ---------------------------------------------------------------------------

class TestApiKeyConstructorCacheBehaviour:

    def test_disabled_construction_runs_probe_and_skips_cache(self):
        with patch.object(CyverSession, "_probe_portal") as mock_probe, \
             patch.object(CyverSession, "_fetch_apikey_cache") as mock_fetch, \
             patch.object(CyverSession, "_save_apikey_cache") as mock_save:
            CyverSession(portal=PORTAL, api_key="sk-xxx", cache_dir=None)
        # The "disabled" short-circuit makes _fetch_apikey_cache return a
        # clean template without ever opening a file; the constructor still
        # walks through the probe + save path because the cached portal
        # doesn't match.
        mock_probe.assert_called_once_with(PORTAL)
        # _fetch_apikey_cache and _save_apikey_cache are still invoked, but
        # both are no-ops when caching is disabled.  The contract that
        # matters is: the probe ran.
        assert mock_fetch.called
        assert mock_save.called

    def test_constructor_logs_warning_when_apikey_cache_corrupt(self, caplog):
        with patch.object(CyverSession, "_fetch_apikey_cache",
                          side_effect=CyverCachingError("bad", cache_kind="apikey", reason="corrupted")), \
             patch.object(CyverSession, "_delete_apikey_cache"), \
             patch.object(CyverSession, "_probe_portal"), \
             patch.object(CyverSession, "_save_apikey_cache"):
            with caplog.at_level(logging.WARNING, logger="CyverReporting.Session"):
                CyverSession(portal=PORTAL, api_key="sk-xxx")
        assert any("damaged" in rec.message.lower() and "api-key" in rec.message.lower()
                   for rec in caplog.records)


# ---------------------------------------------------------------------------
# Environment variable — CYVER_REPORTING_CACHE_DIR resolution
# ---------------------------------------------------------------------------

class TestEnvironmentVariableResolution:
    """The env var only matters when the kwarg is left at the sentinel
    (i.e. omitted)."""

    def test_env_empty_disables_cache(self, monkeypatch):
        monkeypatch.setenv(_CACHE_DIR_ENV_VAR, "")
        s = PentesterSession()
        assert s._cache_enabled is False

    def test_env_path_uses_that_path(self, monkeypatch, tmp_path):
        monkeypatch.setenv(_CACHE_DIR_ENV_VAR, str(tmp_path))
        s = PentesterSession()
        assert s._cache_dir == tmp_path

    def test_env_unset_falls_through_to_default(self, monkeypatch):
        monkeypatch.delenv(_CACHE_DIR_ENV_VAR, raising=False)
        s = PentesterSession()
        assert s._cache_enabled is True
        assert s._cache_dir.name == "cyver"

    def test_explicit_kwarg_wins_over_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv(_CACHE_DIR_ENV_VAR, str(tmp_path / "from-env"))
        # Explicit None overrides the env var → disabled.
        s = PentesterSession(cache_dir=None)
        assert s._cache_enabled is False
