"""
Tests for ``PentesterPortal.delete_project_file`` — the second portal
method admitted under R16's endpoint-admission protocol.  Type-agnostic:
deletes any project file (images, scanner imports, reports, evidence,
or any other server-recognised type) given its UUID.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, FAKE_UUID_2, PORTAL,
)


# A third UUID for tests that need three distinct IDs (project + two
# different file_ids representing different file types).
FAKE_UUID_3 = "deadbeef-1234-1234-1234-abcdef987654"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _authenticated_pentester_portal() -> PentesterPortal:
    """Mirror the helper used in test_portal.py — bypasses real auth."""
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    """Suppress CyverPortalInstabilityWarning for every test in this file
    *except* the one that explicitly asserts the warning behaviour."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# delete_project_file — wire dispatch
# ---------------------------------------------------------------------------

class TestDeleteProjectFileDispatch:

    def test_dispatches_delete_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = FAKE_UUID_2

        p.delete_project_file(FAKE_UUID, FAKE_UUID_2)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "DELETE"
        assert path == "/api/services/app/Project/DeleteProjectFile"

    def test_query_params_carry_both_ids(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = FAKE_UUID_2

        p.delete_project_file(FAKE_UUID, FAKE_UUID_2)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {"projectId": FAKE_UUID, "fileId": FAKE_UUID_2}

    def test_no_request_body_sent(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = FAKE_UUID_2

        p.delete_project_file(FAKE_UUID, FAKE_UUID_2)

        # `data` kwarg should be absent from the dispatch — DELETE has no body.
        assert "data" not in p._send_api_request.call_args.kwargs


# ---------------------------------------------------------------------------
# delete_project_file — return value
# ---------------------------------------------------------------------------

class TestDeleteProjectFileReturnValue:

    def test_returns_none_even_when_server_echoes_deleted_guid(self):
        p = _authenticated_pentester_portal()
        # Server echoes the deleted file's GUID in `result`; we discard it.
        p._send_api_request.return_value = FAKE_UUID_2

        result = p.delete_project_file(FAKE_UUID, FAKE_UUID_2)

        assert result is None


# ---------------------------------------------------------------------------
# delete_project_file — type-agnostic behaviour
# ---------------------------------------------------------------------------

class TestDeleteProjectFileTypeAgnostic:
    """The endpoint accepts any file_id the server stores, regardless of
    type. The method must make no type-based assumptions."""

    def test_works_for_any_file_id_regardless_of_type(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        # First call: simulates an image-category file_id (e.g. type 4).
        p.delete_project_file(FAKE_UUID, FAKE_UUID_2)
        # Second call: simulates a non-image file_id (e.g. scanner import,
        # type 46) — same UUID format, different semantic origin server-side.
        p.delete_project_file(FAKE_UUID, FAKE_UUID_3)

        assert p._send_api_request.call_count == 2
        # Both dispatches identical in shape — the method does not branch.
        for call, expected_file_id in zip(
            p._send_api_request.call_args_list, [FAKE_UUID_2, FAKE_UUID_3]
        ):
            assert call.args[0] == "DELETE"
            assert call.kwargs["params"] == {
                "projectId": FAKE_UUID, "fileId": expected_file_id
            }


# ---------------------------------------------------------------------------
# delete_project_file — input validation
# ---------------------------------------------------------------------------

class TestDeleteProjectFileValidation:

    def test_invalid_project_id_raises_and_skips_http(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.delete_project_file("not-a-uuid", FAKE_UUID_2)
        assert exc_info.value.field == "project_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()

    def test_invalid_file_id_raises_and_skips_http(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.delete_project_file(FAKE_UUID, "not-a-uuid")
        assert exc_info.value.field == "file_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()

    def test_project_id_validated_before_file_id(self):
        """When both arguments are invalid, the first positional one fails
        first — proves left-to-right validation order."""
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.delete_project_file("not-a-uuid", "also-not-a-uuid")
        assert exc_info.value.field == "project_id"


# ---------------------------------------------------------------------------
# portal_unstable warning — emitted on first invocation
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        # Reset the per-decorator warn-once flag so this test is
        # independent of suite ordering.
        PentesterPortal.delete_project_file._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.delete_project_file(FAKE_UUID, FAKE_UUID_2)
            p.delete_project_file(FAKE_UUID, FAKE_UUID_2)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "delete_project_file" in str(portal_warnings[0].message)
