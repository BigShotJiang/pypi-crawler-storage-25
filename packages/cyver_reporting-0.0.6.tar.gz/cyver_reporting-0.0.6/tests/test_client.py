"""
Tests for CyverReporting.Client — input validation and pagination.
"""

import pytest

from CyverReporting import CyverProject
from CyverReporting.Utils import _project_status
from CyverReporting.Exceptions import CyverDataValidationError
from tests.conftest import FAKE_UUID, FAKE_UUID_2


# ---------------------------------------------------------------------------
# UUID validation
# ---------------------------------------------------------------------------

class TestUuidValidation:

    INVALID = "not-a-uuid"

    def test_get_project_by_id_invalid_uuid(self, client):
        with pytest.raises(CyverDataValidationError, match="valid UUID"):
            client.get_project_by_id(self.INVALID)

    def test_get_continuous_project_by_id_invalid_uuid(self, client):
        with pytest.raises(CyverDataValidationError, match="valid UUID"):
            client.get_continuous_project_by_id(self.INVALID)


# ---------------------------------------------------------------------------
# Status filter validation
# ---------------------------------------------------------------------------

class TestStatusFilterValidation:

    def test_get_projects_invalid_status_raises(self, client):
        with pytest.raises(CyverDataValidationError, match="status"):
            client.get_projects(status=999)

    def test_get_projects_valid_status_accepted(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        for status in _project_status._valid:
            client.get_projects(status=status)  # must not raise

    def test_get_projects_none_status_accepted(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        client.get_projects(status=None)  # must not raise

    def test_get_continuous_projects_invalid_status_raises(self, client):
        with pytest.raises(CyverDataValidationError, match="status"):
            client.get_continuous_projects(status=999)

    def test_get_continuous_projects_valid_status_accepted(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        for status in _project_status._valid:
            client.get_continuous_projects(status=status)  # must not raise

    def test_get_continuous_projects_none_status_accepted(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        client.get_continuous_projects(status=None)  # must not raise


# ---------------------------------------------------------------------------
# Pagination — get_all_*() generators
# ---------------------------------------------------------------------------

class TestPagination:

    def test_get_all_projects_single_page(self, client):
        items = [{"id": FAKE_UUID, "name": "Project A"}]
        client._send_api_request.return_value = {"items": items, "totalCount": 1}
        result = list(client.get_all_projects())
        assert len(result) == 1
        assert isinstance(result[0], CyverProject)
        assert result[0].id == FAKE_UUID
        assert result[0].name == "Project A"
        assert client._send_api_request.call_count == 1

    def test_get_all_projects_empty_result(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        assert list(client.get_all_projects()) == []
        assert client._send_api_request.call_count == 1

    def test_get_all_projects_multiple_pages(self, client):
        page1 = {"items": [{"name": f"P{i}"} for i in range(50)], "totalCount": 70}
        page2 = {"items": [{"name": f"P{i}"} for i in range(50, 70)], "totalCount": 70}
        client._send_api_request.side_effect = [page1, page2]
        result = list(client.get_all_projects())
        assert len(result) == 70
        assert all(isinstance(p, CyverProject) for p in result)
        assert client._send_api_request.call_count == 2

    def test_get_all_continuous_projects_single_page(self, client):
        items = [{"id": FAKE_UUID, "name": "Continuous A"}]
        client._send_api_request.return_value = {"items": items, "totalCount": 1}
        assert list(client.get_all_continuous_projects()) == items

    def test_get_all_continuous_projects_empty_result(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        assert list(client.get_all_continuous_projects()) == []

    def test_get_all_continuous_projects_multiple_pages(self, client):
        page1 = {"items": [{"id": str(i)} for i in range(50)], "totalCount": 55}
        page2 = {"items": [{"id": str(i)} for i in range(50, 55)], "totalCount": 55}
        client._send_api_request.side_effect = [page1, page2]
        result = list(client.get_all_continuous_projects())
        assert len(result) == 55
        assert client._send_api_request.call_count == 2

    def test_get_all_projects_with_status_filter(self, client):
        items = [{"id": FAKE_UUID, "name": "Testing Project"}]
        client._send_api_request.return_value = {"items": items, "totalCount": 1}
        result = list(client.get_all_projects(status=_project_status.testing))
        assert len(result) == 1
        assert isinstance(result[0], CyverProject)
        assert result[0].name == "Testing Project"


# ---------------------------------------------------------------------------
# API call pass-through
# ---------------------------------------------------------------------------

class TestApiCallPassthrough:

    def test_get_project_by_id_calls_correct_endpoint(self, client):
        client._send_api_request.return_value = {"id": FAKE_UUID, "name": "P"}
        result = client.get_project_by_id(FAKE_UUID)
        args = client._send_api_request.call_args[0]
        assert args[0] == "GET"
        assert FAKE_UUID in args[1]
        assert isinstance(result, CyverProject)
        assert result.id == FAKE_UUID

    def test_get_continuous_project_by_id_calls_correct_endpoint(self, client):
        client._send_api_request.return_value = {"id": FAKE_UUID}
        client.get_continuous_project_by_id(FAKE_UUID)
        args = client._send_api_request.call_args[0]
        assert args[0] == "GET"
        assert FAKE_UUID in args[1]
        assert "continuous-projects" in args[1]

    def test_get_projects_passes_status_param(self, client):
        client._send_api_request.return_value = {"items": [], "totalCount": 0}
        client.get_projects(status=_project_status.testing)
        args = client._send_api_request.call_args[0]
        assert args[2]["Status"] == "TESTING"
