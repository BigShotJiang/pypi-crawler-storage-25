"""
Tests for ``PentesterPortal.create_unique_finding_code`` and its
supporting bits — ``_re_cyver_code``, ``_parse_cyver_code``, and the
``FindingCodeCache`` class.

The method composes ``search_findings`` calls; tests stub the underlying
``_send_api_request`` mock so no real portal traffic is generated.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from CyverReporting import (
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import (
    FindingCodeCache,
    _parse_cyver_code,
    _re_cyver_code,
)
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


def _authenticated_pentester_portal(cache_dir=None) -> PentesterPortal:
    p = PentesterPortal(cache_dir=cache_dir)
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _summary_item(code: str, **overrides) -> dict:
    """Minimal portal-search-summary item shape for a given finding code."""
    base = {
        "guid":                "00000000-0000-0000-0000-000000000001",
        "code":                code,
        "name":                "x",
        "type":                1,
        "status":              1,
        "criticality":         1,
        "clientAssigneeName":  " ",
        "projectName":         "P",
        "projectGuid":         "00000000-0000-0000-0000-000000000002",
        "clientName":          "C",
        "clientGuid":          "00000000-0000-0000-0000-000000000003",
        "reporter":            None,
        "reviewer":            None,
        "pentesterAssignee":   None,
        "labels":              "",
    }
    base.update(overrides)
    return base


def _empty_response() -> dict:
    return {"items": [], "totalCount": 0}


def _response(*codes: str) -> dict:
    items = [_summary_item(code) for code in codes]
    return {"items": items, "totalCount": len(items)}


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# _re_cyver_code regex
# ---------------------------------------------------------------------------

class TestReCyverCode:

    @pytest.mark.parametrize("code,expected_groups", [
        ("F-2026-9876",   ("F",  "2026", "9876")),
        ("F-2026-12345",  ("F",  "2026", "12345")),
        ("TP-2026-9876",  ("TP", "2026", "9876")),
        ("TP-2026-12345", ("TP", "2026", "12345")),
        ("F-2026-0",      ("F",  "2026", "0")),
        ("F-1999-1",      ("F",  "1999", "1")),
        ("TP-2030-987654321", ("TP", "2030", "987654321")),
    ])
    def test_match_valid_codes(self, code, expected_groups):
        match = _re_cyver_code.match(code)
        assert match is not None
        assert match.groups() == expected_groups

    @pytest.mark.parametrize("code", [
        "F-2026-",          # empty number
        "F-26-1234",        # year not 4 digits
        "F-12345-1234",     # year too long
        "F-2026-1234x",     # non-digit suffix
        "f-2026-1234",      # lowercase prefix
        "Tp-2026-1234",     # mixed-case prefix
        "F_2026_1234",      # wrong separator
        "F-2026/1234",      # wrong separator
        "X-2026-1234",      # unknown prefix
        "FF-2026-1234",     # double prefix letter (not "F" or "TP")
        "F-2026 1234",      # space instead of hyphen
        "",
        "not a code at all",
    ])
    def test_reject_malformed_codes(self, code):
        assert _re_cyver_code.match(code) is None


# ---------------------------------------------------------------------------
# _parse_cyver_code helper
# ---------------------------------------------------------------------------

class TestParseCyverCode:

    def test_parses_f_prefix(self):
        assert _parse_cyver_code("F-2026-15514") == ("F", 2026, 15514)

    def test_parses_tp_prefix(self):
        assert _parse_cyver_code("TP-2026-9876") == ("TP", 2026, 9876)

    def test_parses_zero_suffix(self):
        assert _parse_cyver_code("F-2026-0") == ("F", 2026, 0)

    def test_int_conversion_drops_leading_zeros(self):
        assert _parse_cyver_code("F-2026-0123") == ("F", 2026, 123)

    def test_returns_none_for_malformed(self):
        assert _parse_cyver_code("F-2026-") is None
        assert _parse_cyver_code("not a code") is None
        assert _parse_cyver_code("") is None

    @pytest.mark.parametrize("bad", [None, 42, [], {}, b"F-2026-1"])
    def test_returns_none_for_non_string(self, bad):
        assert _parse_cyver_code(bad) is None


# ---------------------------------------------------------------------------
# FindingCodeCache class
# ---------------------------------------------------------------------------

class TestFindingCodeCache:

    def test_disabled_when_cache_dir_is_none(self):
        cache = FindingCodeCache(None)
        assert cache.get_max("F-2026") is None
        cache.update_max("F-2026", 100)   # no-op (no exception)
        assert cache.get_max("F-2026") == 100   # in-memory still works

    def test_round_trip_through_disk(self, tmp_path):
        c1 = FindingCodeCache(tmp_path)
        c1.update_max("F-2026", 15514)
        c1.update_max("TP-2026", 145)

        c2 = FindingCodeCache(tmp_path)
        assert c2.get_max("F-2026") == 15514
        assert c2.get_max("TP-2026") == 145

    def test_update_only_advances_max(self, tmp_path):
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 100)
        cache.update_max("F-2026", 50)    # lower — should not overwrite
        cache.update_max("F-2026", 200)   # higher — should overwrite
        assert cache.get_max("F-2026") == 200

    def test_corrupt_file_falls_back_to_empty(self, tmp_path):
        path = tmp_path / "finding_codes_cache.json"
        path.write_text("not valid json {{{")
        cache = FindingCodeCache(tmp_path)
        assert cache.get_max("F-2026") is None

    def test_non_dict_root_falls_back_to_empty(self, tmp_path):
        path = tmp_path / "finding_codes_cache.json"
        path.write_text(json.dumps([1, 2, 3]))
        cache = FindingCodeCache(tmp_path)
        assert cache.get_max("F-2026") is None

    def test_save_format_is_human_readable(self, tmp_path):
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 15514)
        contents = (tmp_path / "finding_codes_cache.json").read_text()
        loaded = json.loads(contents)
        assert loaded["F-2026"]["max_code"] == 15514
        assert "last_updated" in loaded["F-2026"]


# ---------------------------------------------------------------------------
# create_unique_finding_code — input validation
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeValidation:

    @pytest.mark.parametrize("bad_prefix", [None, "", "X", "f", "tp", "F-", 42, [], "Foo"])
    def test_invalid_prefix_raises(self, bad_prefix):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.create_unique_finding_code(prefix=bad_prefix)
        assert exc.value.field == "prefix"

    @pytest.mark.parametrize("bad_year", [42, 999, 10000, "2026", 2026.0])
    def test_invalid_year_raises(self, bad_year):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.create_unique_finding_code(year=bad_year)
        assert exc.value.field == "year"

    @pytest.mark.parametrize("bad", [None, "false", 0, 1, []])
    def test_invalid_use_cache_raises(self, bad):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.create_unique_finding_code(use_cache=bad)
        assert exc.value.field == "use_cache"

    def test_use_cache_must_be_keyword_only(self):
        """``use_cache`` is keyword-only — passing it positionally raises
        TypeError."""
        p = _authenticated_pentester_portal()
        with pytest.raises(TypeError):
            p.create_unique_finding_code("F", 2026, False)  # type: ignore[misc]


# ---------------------------------------------------------------------------
# create_unique_finding_code — empty year (no codes yet)
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeEmptyYear:

    def test_returns_one_when_no_codes_exist(self):
        p = _authenticated_pentester_portal()
        # Every leading-digit probe returns empty.
        p._send_api_request.return_value = _empty_response()

        result = p.create_unique_finding_code(year=2030)

        assert result == "F-2030-1"


# ---------------------------------------------------------------------------
# create_unique_finding_code — descend-and-stop algorithm against year 2026
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeYear2026:
    """Replays the year-2026 captured behaviour: only leading=1 has
    codes, max value is 15514, with a 4-digit lex-blocker (F-2026-1586)
    sitting above the 5-digit cluster."""

    def _build_responses(self):
        """Return the sequence of mocked responses for year 2026's
        descent path:

          L1:  F-2026-9..F-2026-2  → empty
               F-2026-1            → 100-page sample including the
                                     captured top: 1586, 15514, 15513,
                                     ..., 15484
          L2:  F-2026-19..F-2026-16 → empty
               F-2026-15           → 10-page within F-2026-15
          L3:  F-2026-159..F-2026-156 → empty
               F-2026-155           → 10-page within F-2026-155
          L4+5: F-2026-155 (count=100) → all matching codes
        """
        # L1 sample emulating the 100 lex-top codes from F-2026-1.
        l1_sample = ["F-2026-1586"] + [f"F-2026-{n}" for n in range(15514, 15414, -1)]
        # L2 sample for F-2026-15 (5-digit cluster top).
        l2_sample = [f"F-2026-{n}" for n in range(15514, 15504, -1)]
        # L3 sample for F-2026-155.
        l3_sample = [f"F-2026-{n}" for n in range(15514, 15504, -1)]
        # L4+5 single fetch for F-2026-155 — the 26 actual codes.
        l4_sample = (
            ["F-2026-155"]
            + [f"F-2026-{1550 + i}" for i in range(10)]
            + [f"F-2026-{15500 + i}" for i in range(15)]
        )

        return [
            # L1: 9, 8, 7, 6, 5, 4, 3, 2 empty, then 1 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response(*l1_sample),
            # L2: 19, 18, 17, 16 empty, then 15 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response(*l2_sample),
            # L3: 159, 158, 157, 156 empty, then 155 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response(*l3_sample),
            # L4+5: leaf fetch.
            _response(*l4_sample),
        ]

    def test_returns_max_plus_one(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.side_effect = self._build_responses()

        result = p.create_unique_finding_code(year=2026)

        assert result == "F-2026-15515"

    def test_total_request_count_matches_expectation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.side_effect = self._build_responses()

        p.create_unique_finding_code(year=2026)

        # 9 (L1) + 5 (L2) + 5 (L3) + 1 (L4+5) = 20.
        assert p._send_api_request.call_count == 20

    def test_l1_uses_count_max_100(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.side_effect = self._build_responses()

        p.create_unique_finding_code(year=2026)

        # First 9 calls are L1 probes — each must use count_max=100.
        for i in range(9):
            params = p._send_api_request.call_args_list[i].kwargs["params"]
            assert params["maxResultCount"] == 100, f"L1 call {i} used wrong count_max"

    def test_l2_l3_use_count_max_10(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.side_effect = self._build_responses()

        p.create_unique_finding_code(year=2026)

        # Calls 9-13 are L2 (5 probes) and 14-18 are L3 (5 probes).
        for i in range(9, 19):
            params = p._send_api_request.call_args_list[i].kwargs["params"]
            assert params["maxResultCount"] == 10, f"L2/L3 call {i} used wrong count_max"

    def test_leaf_fetch_uses_count_max_100(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.side_effect = self._build_responses()

        p.create_unique_finding_code(year=2026)

        # Call 19 (zero-indexed) is the L4+5 leaf fetch.
        params = p._send_api_request.call_args_list[19].kwargs["params"]
        assert params["maxResultCount"] == 100


# ---------------------------------------------------------------------------
# create_unique_finding_code — high-leading-digit fast finish
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeHighLeading:
    """When the highest leading digit hits immediately (e.g. F-2030-9)
    the descent terminates after a few requests — adaptive cost."""

    def test_immediate_l1_hit_short_circuits(self):
        p = _authenticated_pentester_portal()
        # L1: F-2030-9 hits immediately with 95000.
        # L2: F-2030-99..F-2030-95 — only 95 hits.
        # L3: F-2030-959..F-2030-950 — only 950 hits.
        # L4+5: leaf fetch on F-2030-950.
        responses = [
            _response("F-2030-95000"),                      # L1: F-2030-9 hit
            _empty_response(), _empty_response(),           # L2: 99, 98 empty
            _empty_response(), _empty_response(),           # L2: 97, 96 empty
            _response("F-2030-95000"),                      # L2: 95 hit
            _empty_response(), _empty_response(),           # L3: 959, 958 empty
            _empty_response(), _empty_response(),           # L3: 957, 956 empty
            _empty_response(),                              # L3: 955, 954, 953, 952, 951 empty
            _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response("F-2030-95000"),                      # L3: 950 hit
            _response("F-2030-95000"),                      # L4+5: leaf
        ]
        p._send_api_request.side_effect = responses

        result = p.create_unique_finding_code(year=2030)

        assert result == "F-2030-95001"
        # 1 (L1) + 5 (L2) + 10 (L3 from 9 down to 0) + 1 (L4+5) = 17
        assert p._send_api_request.call_count == 17


# ---------------------------------------------------------------------------
# create_unique_finding_code — cache fast-path
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeCacheFastPath:

    def test_fast_path_when_cached_max_plus_one_unused(self, tmp_path):
        # Pre-populate the cache.
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 15514)

        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        # Single probe: F-2026-15515 is unused → empty response.
        p._send_api_request.return_value = _empty_response()

        result = p.create_unique_finding_code(year=2026)

        assert result == "F-2026-15515"
        assert p._send_api_request.call_count == 1

    def test_fast_path_falls_back_when_candidate_taken(self, tmp_path):
        # Pre-populate the cache.
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 15514)

        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        # First call: F-2026-15515 — taken (response includes exact match).
        # Then full descent.  We just need responses that yield 15600 as the
        # discovered max so the new code is F-2026-15601.
        responses = [
            _response("F-2026-15515", "F-2026-15600"),  # fast-path probe: 15515 taken
            # L1: descent skips leading 0 (cache bound = 1).
            # L1: probe 9..1 — 9, 8, 7, 6, 5, 4, 3, 2 empty, then 1 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response("F-2026-15600"),
            # L2: 19, 18, 17, 16 empty, 15 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _response("F-2026-15600"),
            # L3: 159, 158, 157 empty, 156 hits.
            _empty_response(), _empty_response(), _empty_response(),
            _response("F-2026-15600"),
            # L4+5: leaf fetch on F-2026-156.
            _response("F-2026-15600"),
        ]
        p._send_api_request.side_effect = responses

        result = p.create_unique_finding_code(year=2026)

        assert result == "F-2026-15601"

    def test_cache_persists_after_run(self, tmp_path):
        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        # Mimic a fresh year that finds 200.
        responses = [
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response("F-2030-200"),
            # L2: 29, 28, 27, 26, 25, 24, 23, 22, 21, 20 — 20 hits at the floor.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _response("F-2030-200"),
            # L3: 209..200 — 200 hits at the floor.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _response("F-2030-200"),
            # L4+5 leaf.
            _response("F-2030-200"),
        ]
        p._send_api_request.side_effect = responses

        p.create_unique_finding_code(year=2030)

        cache = FindingCodeCache(tmp_path)
        assert cache.get_max("F-2030") == 200


# ---------------------------------------------------------------------------
# create_unique_finding_code — malformed codes filtered
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeFiltersMalformed:

    def test_skips_codes_that_dont_match_the_regex(self):
        p = _authenticated_pentester_portal()
        # L1 probe of F-2026-1 returns one well-formed and one garbage.
        responses = [
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response("F-2026-15514", "weird-code-format", "F-2025-99"),
            # L2 etc. just need to land on max=15514.
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response("F-2026-15514"),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response("F-2026-15514"),
            _response("F-2026-15514"),
        ]
        p._send_api_request.side_effect = responses

        result = p.create_unique_finding_code(year=2026)
        # The garbage code and the wrong-year code (F-2025-99) are both
        # filtered; max from the valid F-2026 entries is 15514.
        assert result == "F-2026-15515"


# ---------------------------------------------------------------------------
# create_unique_finding_code — use_cache=False (cache bypass)
# ---------------------------------------------------------------------------

class TestCreateUniqueFindingCodeUseCacheFalse:
    """``use_cache=False`` must skip cache reads (no fast-path, no L1
    lower bound) AND skip cache writes (no update after the descent)."""

    def _year_2026_descent_responses(self):
        """Same 20-response sequence the year-2026 descent expects."""
        l1_sample = ["F-2026-1586"] + [f"F-2026-{n}" for n in range(15514, 15414, -1)]
        l2_sample = [f"F-2026-{n}" for n in range(15514, 15504, -1)]
        l3_sample = [f"F-2026-{n}" for n in range(15514, 15504, -1)]
        l4_sample = (
            ["F-2026-155"]
            + [f"F-2026-{1550 + i}" for i in range(10)]
            + [f"F-2026-{15500 + i}" for i in range(15)]
        )
        return [
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(), _empty_response(),
            _response(*l1_sample),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response(*l2_sample),
            _empty_response(), _empty_response(), _empty_response(),
            _empty_response(),
            _response(*l3_sample),
            _response(*l4_sample),
        ]

    def test_use_cache_false_skips_fast_path(self, tmp_path):
        """Even with a fresh cached entry, ``use_cache=False`` must
        ignore the fast-path probe and run the full descent."""
        # Pre-populate the cache.
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 15514)

        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        # Whole 20-response descent — no fast-path single probe up front.
        p._send_api_request.side_effect = self._year_2026_descent_responses()

        result = p.create_unique_finding_code(year=2026, use_cache=False)

        assert result == "F-2026-15515"
        # 20 requests means the full descent ran with no fast-path
        # short-circuit AND no cache-bound L1 floor (would have stopped
        # earlier had we honoured the cached leading=1).
        assert p._send_api_request.call_count == 20

    def test_use_cache_false_does_not_write_cache(self, tmp_path):
        """A successful run with ``use_cache=False`` must leave the
        on-disk cache untouched."""
        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        p._send_api_request.side_effect = self._year_2026_descent_responses()

        p.create_unique_finding_code(year=2026, use_cache=False)

        # No file should have been created at all.
        cache_file = tmp_path / "finding_codes_cache.json"
        assert not cache_file.exists()

        # And a fresh cache reads back empty.
        assert FindingCodeCache(tmp_path).get_max("F-2026") is None

    def test_use_cache_false_preserves_existing_cache_entry(self, tmp_path):
        """An existing cache entry must NOT be touched by a
        ``use_cache=False`` call — neither updated nor cleared."""
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 99999)   # plant a high sentinel value

        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        p._send_api_request.side_effect = self._year_2026_descent_responses()

        p.create_unique_finding_code(year=2026, use_cache=False)

        # Cache still holds the original entry.
        assert FindingCodeCache(tmp_path).get_max("F-2026") == 99999

    def test_use_cache_default_is_true(self, tmp_path):
        """Sanity check: omitting ``use_cache`` keeps caching active
        (the existing behaviour)."""
        cache = FindingCodeCache(tmp_path)
        cache.update_max("F-2026", 15514)

        p = _authenticated_pentester_portal(cache_dir=tmp_path)
        p._send_api_request.return_value = _empty_response()

        result = p.create_unique_finding_code(year=2026)

        # Hits the fast-path → 1 request, returns cached_max + 1.
        assert result == "F-2026-15515"
        assert p._send_api_request.call_count == 1
