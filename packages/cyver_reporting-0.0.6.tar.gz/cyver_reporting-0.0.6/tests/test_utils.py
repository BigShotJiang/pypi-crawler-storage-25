"""
Tests for format validators (_validate_uuid, _validate_jwt_token) in
CyverReporting.Utils.FormatValidators and field-extraction helpers
(_fd_optional_datetime, _fd_optional_date, _fd_optional_uuid,
_fd_optional_project_status) in CyverReporting.Utils.FieldExtractors.
"""

import time
import pytest
from unittest.mock import patch

from CyverReporting.Utils.FormatValidators import (
    _validate_uuid,
    _validate_jwt_token,
    _validate_project_file_type,
)
from CyverReporting.Utils.MimeTypes import _guess_mime_type
from CyverReporting.Utils.StaticAliases import _project_file_type
from CyverReporting.Utils.FieldExtractors import (
    _sentinels_datetime,
    _sentinels_date,
    _sentinels_uuid,
    _fd_optional_datetime,
    _fd_optional_date,
    _fd_optional_uuid,
    _fd_optional_project_status,
    _fd_uuid_list,
)
from CyverReporting.Exceptions import CyverDataValidationError


# ---------------------------------------------------------------------------
# _validate_uuid
# ---------------------------------------------------------------------------

class TestValidateUuid:

    # --- valid inputs (must not raise) ---

    def test_standard_lowercase(self):
        _validate_uuid("12345678-1234-1234-1234-123456789abc", "id")

    def test_standard_uppercase(self):
        _validate_uuid("12345678-1234-1234-1234-123456789ABC", "id")

    def test_mixed_case(self):
        _validate_uuid("12345678-abcd-ABCD-efEF-123456789abc", "id")

    def test_all_zeros(self):
        _validate_uuid("00000000-0000-0000-0000-000000000000", "id")

    def test_all_fs(self):
        _validate_uuid("ffffffff-ffff-ffff-ffff-ffffffffffff", "id")

    # --- invalid inputs (must raise CyverDataValidationError) ---

    def test_empty_string(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("", "id")

    def test_no_hyphens(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("123456781234123412341234567890ab", "id")

    def test_too_short(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-12345678abc", "id")

    def test_too_long(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789abcd", "id")

    def test_wrong_group_order(self):
        # 4-8-4-4-12 instead of 8-4-4-4-12
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("1234-12345678-1234-1234-123456789abc", "id")

    def test_invalid_hex_characters(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789xyz", "id")

    def test_spaces(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("12345678-1234-1234-1234-123456789ab ", "id")

    def test_plain_string(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _validate_uuid("not-a-uuid-at-all", "id")

    def test_field_name_appears_in_error(self):
        with pytest.raises(CyverDataValidationError, match="clientId"):
            _validate_uuid("bad-uuid", "clientId")

    def test_error_reason_is_invalid_uuid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_uuid("bad", "id")
        assert exc_info.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# _validate_jwt_token
# ---------------------------------------------------------------------------

class TestValidateJwtToken:
    """
    _jwt_decode is patched at the import site
    (CyverReporting.Utils.FormatValidators._jwt_decode) so these tests
    are independent of any installed PyJWT version.
    """

    def test_valid_token(self):
        exp = int(time.time()) + 3600
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            _validate_jwt_token("valid.token.sig", "accessToken")  # must not raise

    def test_expired_token(self):
        exp = int(time.time()) - 1
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("expired.token.sig", "accessToken")

    def test_missing_exp_claim(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"sub": "user"}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("no.exp.token", "accessToken")

    def test_exp_exactly_now(self):
        # Token whose expiry is the current second is treated as expired.
        exp = int(time.time())
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("boundary.token.sig", "accessToken")

    def test_malformed_token_raises_invalid_jwt(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad token")):
            with pytest.raises(CyverDataValidationError, match="not a well-formed JWT"):
                _validate_jwt_token("malformed", "accessToken")

    def test_none_exp_value(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": None}):
            with pytest.raises(CyverDataValidationError, match="expired"):
                _validate_jwt_token("none.exp.token", "accessToken")

    def test_field_name_appears_in_error(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad")):
            with pytest.raises(CyverDataValidationError, match="refreshToken"):
                _validate_jwt_token("bad", "refreshToken")

    def test_error_reason_expired(self):
        exp = int(time.time()) - 1
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", return_value={"exp": exp}):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("expired.token.sig", "accessToken")
        assert exc_info.value.reason == "expired_jwt"

    def test_error_reason_invalid_jwt(self):
        with patch("CyverReporting.Utils.FormatValidators._jwt_decode", side_effect=Exception("bad")):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("bad", "accessToken")
        assert exc_info.value.reason == "invalid_jwt"

    # --- skew_seconds pre-expiry behaviour (R12) ---

    def _decoded(self, exp_offset: int):
        """Produce a patched _jwt_decode returning exp = now + offset."""
        return patch(
            "CyverReporting.Utils.FormatValidators._jwt_decode",
            return_value={"exp": int(time.time()) + exp_offset},
        )

    def test_skew_default_zero_preserves_prior_behaviour_valid(self):
        """Default `skew_seconds=0` + comfortable exp → no raise (regression)."""
        with self._decoded(60):
            _validate_jwt_token("t.sig", "accessToken")

    def test_skew_default_zero_preserves_prior_behaviour_past(self):
        """Default `skew_seconds=0` + past exp → still `expired_jwt`."""
        with self._decoded(-1):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("t.sig", "accessToken")
        assert exc_info.value.reason == "expired_jwt"

    def test_near_expiry_rejected_when_skew_positive(self):
        """Token in-window but within skew → raises with near_expiry reason."""
        with self._decoded(5):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)
        assert exc_info.value.reason == "near_expiry"
        assert exc_info.value.field  == "accessToken"

    def test_comfortably_valid_accepted_when_skew_positive(self):
        """Token well outside skew → no raise."""
        with self._decoded(60):
            _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)

    def test_skew_boundary_inclusive(self):
        """Exactly `skew_seconds` of remaining lifetime → raises (<= semantics)."""
        with self._decoded(30):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)
        assert exc_info.value.reason == "near_expiry"

    def test_just_outside_skew_boundary_accepted(self):
        """One second past the skew threshold → no raise."""
        with self._decoded(31):
            _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)

    def test_past_exp_beats_near_expiry_reason(self):
        """Already-expired tokens keep `expired_jwt` even when skew is set."""
        with self._decoded(-1):
            with pytest.raises(CyverDataValidationError) as exc_info:
                _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)
        assert exc_info.value.reason == "expired_jwt"  # NOT "near_expiry"

    def test_near_expiry_message_mentions_skew_and_remaining(self):
        with self._decoded(5):
            with pytest.raises(CyverDataValidationError,
                               match=r"within 30s of expiry.*5s remaining"):
                _validate_jwt_token("t.sig", "accessToken", skew_seconds=30)


# ---------------------------------------------------------------------------
# _fd_optional_datetime
# ---------------------------------------------------------------------------

class TestFdOptionalDatetime:

    # --- sentinel / absent values → None ---

    def test_key_absent_returns_none(self):
        assert _fd_optional_datetime({}, "startDate") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_datetime({"startDate": None}, "startDate") is None

    @pytest.mark.parametrize("sentinel", sorted(_sentinels_datetime))
    def test_sentinel_returns_none(self, sentinel):
        assert _fd_optional_datetime({"d": sentinel}, "d") is None

    # --- valid values → returned unchanged ---

    def test_valid_datetime_utc(self):
        v = "2024-06-15T10:30:00Z"
        assert _fd_optional_datetime({"d": v}, "d") == v

    def test_valid_datetime_with_fractional(self):
        v = "2024-06-15T10:30:00.123456Z"
        assert _fd_optional_datetime({"d": v}, "d") == v

    # --- wrong type → raises ---

    def test_non_string_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a string"):
            _fd_optional_datetime({"d": 12345}, "d")

    # --- invalid format → raises ---

    def test_invalid_format_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_datetime({"d": "not-a-date"}, "d")


# ---------------------------------------------------------------------------
# _fd_optional_date
# ---------------------------------------------------------------------------

class TestFdOptionalDate:

    # --- sentinel / absent values → None ---

    def test_key_absent_returns_none(self):
        assert _fd_optional_date({}, "startDate") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_date({"startDate": None}, "startDate") is None

    @pytest.mark.parametrize("sentinel", sorted(_sentinels_date))
    def test_sentinel_returns_none(self, sentinel):
        assert _fd_optional_date({"d": sentinel}, "d") is None

    # --- valid value → returned unchanged ---

    def test_valid_date(self):
        v = "2024-06-15"
        assert _fd_optional_date({"d": v}, "d") == v

    # --- wrong type → raises ---

    def test_non_string_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a string"):
            _fd_optional_date({"d": 20240615}, "d")

    # --- invalid format → raises ---

    def test_invalid_format_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_date({"d": "15-06-2024"}, "d")


# ---------------------------------------------------------------------------
# _fd_optional_uuid — empty string treated as absent
# ---------------------------------------------------------------------------

class TestFdOptionalUuid:

    ZERO = "00000000-0000-0000-0000-000000000000"

    def test_sentinel_set_contains_zero_and_empty(self):
        assert self.ZERO in _sentinels_uuid
        assert ""        in _sentinels_uuid

    def test_key_absent_returns_none(self):
        assert _fd_optional_uuid({}, "clientId") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_uuid({"clientId": None}, "clientId") is None

    def test_empty_string_returns_none(self):
        assert _fd_optional_uuid({"clientId": ""}, "clientId") is None

    def test_zero_uuid_returns_none(self):
        """The .NET Guid.Empty sentinel is treated as absent (portal-surface
        convention — GUID and UUID are treated interchangeably here)."""
        assert _fd_optional_uuid({"clientId": self.ZERO}, "clientId") is None

    def test_valid_uuid_returned(self):
        v = "12345678-1234-1234-1234-123456789abc"
        assert _fd_optional_uuid({"clientId": v}, "clientId") == v

    def test_invalid_uuid_raises(self):
        with pytest.raises(CyverDataValidationError, match="not a valid UUID"):
            _fd_optional_uuid({"clientId": "not-a-uuid"}, "clientId")

    def test_non_string_raises(self):
        with pytest.raises(CyverDataValidationError) as exc:
            _fd_optional_uuid({"clientId": 123}, "clientId")
        assert exc.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# _fd_optional_project_status — empty string treated as absent
# ---------------------------------------------------------------------------

class TestFdOptionalProjectStatus:

    def test_key_absent_returns_none(self):
        assert _fd_optional_project_status({}, "status") is None

    def test_none_value_returns_none(self):
        assert _fd_optional_project_status({"status": None}, "status") is None

    def test_empty_string_returns_none(self):
        assert _fd_optional_project_status({"status": ""}, "status") is None

    def test_valid_status_returned(self):
        assert _fd_optional_project_status({"status": "TESTING"}, "status") == "TESTING"

    def test_done_status_accepted(self):
        # DONE is returned by ~10% of real projects on observed portals;
        # used to be missing from _project_status._valid, causing
        # CyverDataValidationError mid-pagination on get_all_projects().
        assert _fd_optional_project_status({"status": "DONE"}, "status") == "DONE"

    def test_invalid_status_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_optional_project_status({"status": "UNKNOWN"}, "status")

    def test_done_alias_resolves_to_done_string(self):
        from CyverReporting.Utils import _project_status
        assert _project_status.done == "DONE"
        assert "DONE" in _project_status._valid


# ---------------------------------------------------------------------------
# _fd_uuid_list — bare UUIDs and {id, ...} object form
# ---------------------------------------------------------------------------

class TestFdUuidList:

    UUID_A = "01234567-89ab-cdef-0123-456789abcdef"
    UUID_B = "fedcba98-7654-3210-fedc-ba9876543210"

    # --- absence / empty ---

    def test_key_absent_returns_empty_list(self):
        assert _fd_uuid_list({}, "labelList") == []

    def test_none_value_returns_empty_list(self):
        assert _fd_uuid_list({"labelList": None}, "labelList") == []

    def test_empty_list_returns_empty_list(self):
        assert _fd_uuid_list({"labelList": []}, "labelList") == []

    # --- bare-string form (back-compatible) ---

    def test_list_of_uuid_strings_passes_through(self):
        assert _fd_uuid_list(
            {"ids": [self.UUID_A, self.UUID_B]}, "ids"
        ) == [self.UUID_A, self.UUID_B]

    # --- object form ({id, text, type}) ---

    def test_list_of_label_objects_normalizes_to_ids(self):
        payload = {
            "labelList": [
                {"id": self.UUID_A, "text": "Black-Box", "type": 2},
                {"id": self.UUID_B, "text": "Grey-Box",  "type": 2},
            ]
        }
        assert _fd_uuid_list(payload, "labelList") == [self.UUID_A, self.UUID_B]

    def test_object_with_extra_unrelated_keys_is_accepted(self):
        payload = {"labelList": [{"id": self.UUID_A, "anything": {"x": 1}}]}
        assert _fd_uuid_list(payload, "labelList") == [self.UUID_A]

    # --- mixed list ---

    def test_mixed_strings_and_objects_normalize_to_ids(self):
        payload = {
            "labelList": [
                self.UUID_A,
                {"id": self.UUID_B, "text": "Grey-Box", "type": 2},
            ]
        }
        assert _fd_uuid_list(payload, "labelList") == [self.UUID_A, self.UUID_B]

    # --- invalid input ---

    def test_non_list_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a list"):
            _fd_uuid_list({"labelList": "not-a-list"}, "labelList")

    def test_invalid_uuid_string_raises(self):
        with pytest.raises(CyverDataValidationError):
            _fd_uuid_list({"ids": ["not-a-uuid"]}, "ids")

    def test_object_with_invalid_uuid_id_raises(self):
        payload = {"labelList": [{"id": "not-a-uuid", "text": "X"}]}
        with pytest.raises(CyverDataValidationError):
            _fd_uuid_list(payload, "labelList")

    def test_object_without_id_raises(self):
        payload = {"labelList": [{"text": "Black-Box", "type": 2}]}
        with pytest.raises(CyverDataValidationError, match="must be a string or"):
            _fd_uuid_list(payload, "labelList")

    def test_object_with_non_string_id_raises(self):
        payload = {"labelList": [{"id": 123, "text": "X"}]}
        with pytest.raises(CyverDataValidationError, match="must be a string or"):
            _fd_uuid_list(payload, "labelList")

    def test_unsupported_item_type_raises(self):
        with pytest.raises(CyverDataValidationError, match="must be a string or"):
            _fd_uuid_list({"ids": [42]}, "ids")


# ---------------------------------------------------------------------------
# Integration — CyverProjectDates.from_dict with all-sentinel payload
# ---------------------------------------------------------------------------

class TestCyverProjectDatesSentinels:

    def test_all_sentinel_datetimes_parsed_as_none(self):
        from CyverReporting.DataTypes.CyverProjectDates import CyverProjectDates

        payload = {
            "startDate":          "0001-01-01T00:00:00",
            "endDate":            "0001-01-01T00:00:00",
            "startTesting":       "0001-01-01T00:00:00",
            "endTesting":         "0001-01-01T00:00:00",
            "creationTime":       "0001-01-01T00:00:00",
            "reportDueDate":      "0001-01-01T00:00:00",
            "reportPublishedAt":  "0001-01-01T00:00:00",
            "planningDates":      [],
        }
        obj = CyverProjectDates.from_dict(payload)

        assert obj._start_date         is None
        assert obj._end_date           is None
        assert obj._start_testing      is None
        assert obj._end_testing        is None
        assert obj._creation_time      is None
        assert obj._report_due_date    is None
        assert obj._report_published_at is None
        assert obj._planning_dates     == []

    def test_mixed_sentinel_and_real_dates(self):
        from CyverReporting.DataTypes.CyverProjectDates import CyverProjectDates

        payload = {
            "startDate":    "2024-01-15T09:00:00Z",
            "endDate":      "0001-01-01T00:00:00",
            "startTesting": "2024-01-20T09:00:00Z",
            "endTesting":   "0001-01-01T00:00:00",
        }
        obj = CyverProjectDates.from_dict(payload)

        assert obj._start_date    == "2024-01-15T09:00:00Z"
        assert obj._end_date      is None
        assert obj._start_testing == "2024-01-20T09:00:00Z"
        assert obj._end_testing   is None


# ---------------------------------------------------------------------------
# Integration — CyverPlanningDate.from_dict with sentinel dates
# ---------------------------------------------------------------------------

class TestCyverPlanningDateSentinels:

    def test_sentinel_dates_parsed_as_none(self):
        from CyverReporting.DataTypes.CyverPlanningDate import CyverPlanningDate

        payload = {"startDate": "0001-01-01", "endDate": "0001-01-01"}
        obj = CyverPlanningDate.from_dict(payload)

        assert obj._start_date is None
        assert obj._end_date   is None


# ---------------------------------------------------------------------------
# _validate_project_file_type
# ---------------------------------------------------------------------------

class TestValidateProjectFileType:

    # --- valid inputs ---

    # Sample of valid codes spanning the low single digits (0–8), the
    # report/quote/invoice cluster (23–25, 29), the scanner-import
    # block (31–44, 46–61), and a few aliased constants.  The full
    # set lives in `_project_file_type._valid` (43 codes total).
    @pytest.mark.parametrize("code", [
        0, 1, 2, 3, 4, 5, 6, 7, 8,
        23, 24, 25, 29,
        31, 33, 38, 44,
        46, 50, 58, 61,
    ])
    def test_accepts_every_known_code(self, code):
        _validate_project_file_type(code, "fileType")  # must not raise

    def test_accepts_named_constant(self):
        # Named aliases evaluate to their integer code.
        _validate_project_file_type(_project_file_type.import_finding, "fileType")
        _validate_project_file_type(_project_file_type.report,         "fileType")

    # --- invalid inputs ---

    # Codes drawn from the gaps in `_valid`: 9–22 (between asset and quote),
    # 26–28 (between indemnity and import_benchmark), 30 and 45 (single
    # gaps), the negative range, and well above the last assigned code.
    @pytest.mark.parametrize("code", [9, 10, 22, 26, 28, 30, 45, 62, 100, -1])
    def test_rejects_unknown_codes(self, code):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_project_file_type(code, "fileType")
        assert exc_info.value.reason == "invalid_value"
        assert exc_info.value.field  == "fileType"

    @pytest.mark.parametrize("value", ["4", "import_finding", 4.0, None, [4], {"v": 4}])
    def test_rejects_non_int(self, value):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_project_file_type(value, "fileType")
        assert exc_info.value.reason == "invalid_type"

    def test_rejects_bool(self):
        # bool subclasses int but must be rejected explicitly.
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_project_file_type(True, "fileType")
        assert exc_info.value.reason == "invalid_type"

    def test_field_name_appears_in_error(self):
        with pytest.raises(CyverDataValidationError, match="custom_field_name"):
            _validate_project_file_type(99, "custom_field_name")


# ---------------------------------------------------------------------------
# _guess_mime_type
# ---------------------------------------------------------------------------

class TestGuessMimeType:

    @pytest.mark.parametrize("filename,expected", [
        ("photo.png",    "image/png"),
        ("doc.pdf",      "application/pdf"),
        ("report.html",  "text/html"),
        ("data.json",    "application/json"),
        ("archive.zip",  "application/zip"),
    ])
    def test_known_extensions(self, filename, expected):
        assert _guess_mime_type(filename) == expected

    def test_unknown_extension_falls_back_to_default(self):
        assert _guess_mime_type("file.cyverblob") == "application/octet-stream"

    def test_no_extension_falls_back_to_default(self):
        assert _guess_mime_type("README") == "application/octet-stream"

    def test_empty_filename_returns_default(self):
        assert _guess_mime_type("") == "application/octet-stream"

    def test_none_returns_default(self):
        assert _guess_mime_type(None) == "application/octet-stream"  # type: ignore[arg-type]

    def test_custom_default_honoured(self):
        assert _guess_mime_type("x.unknownext", default="text/plain") == "text/plain"

    def test_case_insensitive_extension(self):
        assert _guess_mime_type("photo.PNG") == "image/png"
