"""
Tests for ``PentesterPortal.get_project_images_files`` and its iterator
sibling ``get_all_project_images_files`` — the first portal-surface
methods admitted under R16's endpoint-admission protocol.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverProjectFile,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, FAKE_UUID_2, PORTAL,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _authenticated_pentester_portal() -> PentesterPortal:
    """Mirror the helper used in test_portal.py — bypasses real auth."""
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _file_dict(guid: str, file_name: str = "screenshot.png", file_type: int = 6) -> dict:
    """Minimal valid item shape returned by GetProjectImagesFiles."""
    return {
        "guid":            guid,
        "fileName":        file_name,
        "fileSize":        41017,
        "type":            file_type,
        "mimeType":        "image/png",
        "uploadedAt":      "2026-04-23T20:19:54.9078469Z",
        "uploadedBy":      None,
        "downloadLink":    None,
        "additionalGuid":  "00000000-0000-0000-0000-000000000000",
        "visibleToClient": False,
        "description":     None,
        "caption":         None,
    }


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    """Suppress CyverPortalInstabilityWarning for every test in this file
    *except* the one that explicitly asserts the warning behaviour."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# get_project_images_files — happy path and parameter propagation
# ---------------------------------------------------------------------------

class TestGetProjectImagesFilesHappyPath:

    def test_happy_path_returns_dict_with_hydrated_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 2,
            "items": [_file_dict(FAKE_UUID), _file_dict(FAKE_UUID_2)],
        }

        result = p.get_project_images_files(FAKE_UUID)

        assert result["totalCount"] == 2
        assert len(result["items"]) == 2
        assert all(isinstance(f, CyverProjectFile) for f in result["items"])
        assert result["items"][0].guid == FAKE_UUID
        assert result["items"][1].guid == FAKE_UUID_2

    def test_dispatches_get_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_images_files(FAKE_UUID)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "GET"
        assert path == "/api/services/app/Project/GetProjectImagesFiles"

    def test_empty_response_returns_empty_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        result = p.get_project_images_files(FAKE_UUID)

        assert result["items"] == []
        assert result["totalCount"] == 0


# ---------------------------------------------------------------------------
# get_project_images_files — parameter propagation
# ---------------------------------------------------------------------------

class TestGetProjectImagesFilesParams:

    def test_filter_name_propagates_to_query_param(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_images_files(FAKE_UUID, filter_name="cookie")

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"] == "cookie"

    def test_filter_defaults_to_empty_string_when_none(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_images_files(FAKE_UUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert "filter" in params
        assert params["filter"] == ""

    def test_pagination_params_propagate(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_images_files(FAKE_UUID, count_max=25, count_skip=50)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["maxResultCount"] == 25
        assert params["skipCount"] == 50

    def test_project_id_propagates_to_query_param(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_project_images_files(FAKE_UUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["projectId"] == FAKE_UUID


# ---------------------------------------------------------------------------
# get_project_images_files — validation
# ---------------------------------------------------------------------------

class TestGetProjectImagesFilesValidation:

    def test_invalid_project_id_raises_data_validation_error(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_project_images_files("not-a-uuid")
        assert exc_info.value.field == "project_id"
        assert exc_info.value.reason == "invalid_uuid"
        # No HTTP call should have been made.
        p._send_api_request.assert_not_called()


# ---------------------------------------------------------------------------
# portal_unstable warning — emitted on first invocation
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:
    """The autouse fixture is bypassed here via an explicit
    ``catch_warnings`` context that overrides the simplefilter."""

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        # The decorator memoises "already warned" on the wrapper itself —
        # reset so this test stays independent of suite ordering.
        PentesterPortal.get_project_images_files._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.get_project_images_files(FAKE_UUID)
            p.get_project_images_files(FAKE_UUID)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "get_project_images_files" in str(portal_warnings[0].message)


# ---------------------------------------------------------------------------
# get_all_project_images_files — pagination behaviour
# ---------------------------------------------------------------------------

class TestGetAllProjectImagesFiles:

    def test_iterates_pages_and_yields_hydrated_files(self):
        p = _authenticated_pentester_portal()
        # Three pages: 10, 10, 5 — 25 items total.
        page_1 = {"totalCount": 25, "items": [_file_dict(FAKE_UUID) for _ in range(10)]}
        page_2 = {"totalCount": 25, "items": [_file_dict(FAKE_UUID) for _ in range(10)]}
        page_3 = {"totalCount": 25, "items": [_file_dict(FAKE_UUID) for _ in range(5)]}
        p._send_api_request.side_effect = [page_1, page_2, page_3]

        items = list(p.get_all_project_images_files(FAKE_UUID))

        assert len(items) == 25
        assert all(isinstance(f, CyverProjectFile) for f in items)

    def test_propagates_filter_to_inner_calls(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"totalCount": 0, "items": []}

        list(p.get_all_project_images_files(FAKE_UUID, filter_name="cookie"))

        # At least one underlying call; every call carries filter=cookie.
        assert p._send_api_request.call_count >= 1
        for call in p._send_api_request.call_args_list:
            assert call.kwargs["params"]["filter"] == "cookie"

    def test_invalid_project_id_raises_before_iteration_starts(self):
        p = _authenticated_pentester_portal()
        gen = p.get_all_project_images_files("not-a-uuid")
        with pytest.raises(CyverDataValidationError) as exc_info:
            next(gen)
        assert exc_info.value.field == "project_id"
        p._send_api_request.assert_not_called()
