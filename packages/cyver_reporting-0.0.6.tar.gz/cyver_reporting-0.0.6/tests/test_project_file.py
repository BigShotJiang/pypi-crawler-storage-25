"""
Tests for CyverReporting.DataTypes.CyverProjectFile — portal-surface
project-file data builder.
"""

import pytest

from CyverReporting import CyverProjectFile
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import (
    _fd_optional_uuid,
    _project_file_type,
    _sentinels_uuid,
)


# ---------------------------------------------------------------------------
# Shared fixtures / samples drawn from the real captured GetAllProjectFiles
# and GetProjectImagesFiles responses
# ---------------------------------------------------------------------------

FILE_GUID  = "90199ac5-4d60-4e91-9780-49bd1211b127"
OTHER_GUID = "12345678-1234-1234-1234-123456789abc"
ZERO_GUID  = "00000000-0000-0000-0000-000000000000"
UPLOADER   = "henrique.soares@thoropass.com"


def _populated_payload(**overrides):
    """Return a copy of a realistic GetAllProjectFiles item."""
    payload = {
        "guid":            FILE_GUID,
        "fileName":        "cookie_monster.png",
        "mimeType":        "image/png",
        "fileSize":        516545,
        "uploadedAt":      "2026-04-24T13:21:15.3258246Z",
        "uploadedBy":      UPLOADER,
        "downloadLink":    None,
        "type":            4,
        "additionalGuid":  ZERO_GUID,
        "visibleToClient": False,
        "description":     "Test321",
        "caption":         "Test123",
    }
    payload.update(overrides)
    return payload


# ---------------------------------------------------------------------------
# _sentinels_uuid sanity — portal-surface zero-GUID is recognised globally
# ---------------------------------------------------------------------------
#
# The broad behaviour of _fd_optional_uuid (including zero-UUID sentinel
# handling) is covered by tests/test_utils.py::TestFdOptionalUuid.  The
# single assertion below confirms that the portal-surface convention
# (zero GUID = unset) is visible to CyverProjectFile via the shared
# helper — a regression guard in case the helpers are ever split again.

class TestUuidSentinelSharedContract:

    def test_zero_uuid_and_empty_are_sentinels(self):
        assert ZERO_GUID in _sentinels_uuid
        assert ""        in _sentinels_uuid

    def test_fd_optional_uuid_maps_zero_to_none(self):
        assert _fd_optional_uuid({"additionalGuid": ZERO_GUID}, "additionalGuid") is None


# ---------------------------------------------------------------------------
# Constructor — happy path and rejections
# ---------------------------------------------------------------------------

class TestConstructor:

    def test_minimal_construction_succeeds(self):
        f = CyverProjectFile("x.png", 10, _project_file_type.evidence)
        assert f.file_name == "x.png"
        assert f.file_size == 10
        assert f.file_type == _project_file_type.evidence

    def test_named_constant_and_int_are_interchangeable(self):
        f1 = CyverProjectFile("x.png", 10, _project_file_type.evidence)
        f2 = CyverProjectFile("x.png", 10, 6)  # evidence == 6
        assert f1.file_type == f2.file_type == 6

    def test_fresh_instance_has_default_visible_and_empty_text_fields(self):
        f = CyverProjectFile("x.png", 10, 6)
        assert f.visible_to_client is False
        assert f.caption     == ""
        assert f.description == ""
        assert f.additional_guid is None
        assert f.guid is None
        assert f.mime_type is None
        assert f.uploaded_at is None
        assert f.uploaded_by is None
        assert f.download_link is None

    # --- file_name rejections ---

    def test_empty_file_name_rejected(self):
        with pytest.raises(CyverDataValidationError, match="fileName"):
            CyverProjectFile("", 10, 6)

    def test_non_string_file_name_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile(123, 10, 6)
        assert exc.value.reason == "invalid_type"

    # --- file_size rejections ---

    def test_negative_file_size_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile("x.png", -1, 6)
        assert exc.value.reason == "invalid_value"

    def test_bool_file_size_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile("x.png", True, 6)
        assert exc.value.reason == "invalid_type"

    def test_non_int_file_size_rejected(self):
        with pytest.raises(CyverDataValidationError):
            CyverProjectFile("x.png", "10", 6)
        with pytest.raises(CyverDataValidationError):
            CyverProjectFile("x.png", 10.5, 6)

    # --- file_type rejections ---

    def test_unknown_file_type_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile("x.png", 10, 99)
        assert exc.value.reason == "invalid_value"

    def test_bool_file_type_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile("x.png", 10, True)
        assert exc.value.reason == "invalid_type"


# ---------------------------------------------------------------------------
# Setters — caller-modifiable fields
# ---------------------------------------------------------------------------

class TestSetters:

    def _fresh(self):
        return CyverProjectFile("x.png", 10, 6)

    # --- set_caption ---

    def test_set_caption_assigns_and_returns_self(self):
        f = self._fresh()
        assert f.set_caption("Screenshot") is f
        assert f.caption == "Screenshot"

    def test_set_caption_accepts_empty_string(self):
        f = self._fresh().set_caption("x").set_caption("")
        assert f.caption == ""

    def test_set_caption_rejects_non_string(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._fresh().set_caption(123)
        assert exc.value.reason == "invalid_type"

    # --- set_description ---

    def test_set_description_assigns_and_returns_self(self):
        f = self._fresh()
        assert f.set_description("desc") is f
        assert f.description == "desc"

    def test_set_description_accepts_empty_string(self):
        f = self._fresh().set_description("x").set_description("")
        assert f.description == ""

    def test_set_description_rejects_non_string(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._fresh().set_description(None)
        assert exc.value.reason == "invalid_type"

    # --- set_visible_to_client ---

    def test_set_visible_to_client_true(self):
        f = self._fresh().set_visible_to_client(True)
        assert f.visible_to_client is True

    def test_set_visible_to_client_false(self):
        f = self._fresh().set_visible_to_client(False)
        assert f.visible_to_client is False

    def test_set_visible_to_client_rejects_int(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._fresh().set_visible_to_client(1)
        assert exc.value.reason == "invalid_type"

    def test_set_visible_to_client_rejects_none(self):
        with pytest.raises(CyverDataValidationError):
            self._fresh().set_visible_to_client(None)

    def test_set_visible_to_client_rejects_str(self):
        with pytest.raises(CyverDataValidationError):
            self._fresh().set_visible_to_client("true")

    # --- set_additional_guid ---

    def test_set_additional_guid_accepts_real_uuid(self):
        f = self._fresh().set_additional_guid(OTHER_GUID)
        assert f.additional_guid == OTHER_GUID

    def test_set_additional_guid_none_clears(self):
        f = self._fresh().set_additional_guid(OTHER_GUID).set_additional_guid(None)
        assert f.additional_guid is None

    def test_set_additional_guid_zero_sentinel_clears(self):
        f = self._fresh().set_additional_guid(OTHER_GUID).set_additional_guid(ZERO_GUID)
        assert f.additional_guid is None

    def test_set_additional_guid_empty_sentinel_clears(self):
        f = self._fresh().set_additional_guid(OTHER_GUID).set_additional_guid("")
        assert f.additional_guid is None

    def test_set_additional_guid_rejects_malformed(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._fresh().set_additional_guid("not-a-uuid")
        assert exc.value.reason == "invalid_uuid"

    def test_set_additional_guid_rejects_non_string(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._fresh().set_additional_guid(123)
        assert exc.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# to_dict() — update-payload shape
# ---------------------------------------------------------------------------

class TestToDict:

    def test_fresh_instance_emits_type_and_defaults(self):
        d = CyverProjectFile("x.png", 10, 6).to_dict()
        assert d == {
            "type": 6,
            "caption": "",
            "description": "",
            "visibleToClient": False,
        }

    def test_fresh_instance_does_not_emit_fileId_or_additional_guid(self):
        d = CyverProjectFile("x.png", 10, 6).to_dict()
        assert "fileId"         not in d
        assert "additionalGuid" not in d

    def test_does_not_emit_server_managed_fields(self):
        d = CyverProjectFile.from_dict(_populated_payload()).to_dict()
        for forbidden in ("fileName", "fileSize", "mimeType",
                          "uploadedAt", "uploadedBy", "downloadLink",
                          "guid", "projectId"):
            assert forbidden not in d, f"{forbidden!r} should not be in to_dict output"

    def test_hydrated_to_dict_matches_update_body_shape(self):
        """Round-trip sanity vs. the real UpdateProjectFile capture."""
        hyd = CyverProjectFile.from_dict(_populated_payload())
        assert hyd.to_dict() == {
            "type":            4,
            "caption":         "Test123",
            "description":     "Test321",
            "visibleToClient": False,
            "fileId":          FILE_GUID,
        }

    def test_zero_guid_additional_guid_never_emitted(self):
        """Even after hydrate (which sees the zero GUID), to_dict omits it."""
        d = CyverProjectFile.from_dict(
            _populated_payload(additionalGuid=ZERO_GUID)
        ).to_dict()
        assert "additionalGuid" not in d

    def test_real_additional_guid_is_emitted(self):
        f = CyverProjectFile.from_dict(_populated_payload())
        f.set_additional_guid(OTHER_GUID)
        d = f.to_dict()
        assert d["additionalGuid"] == OTHER_GUID

    def test_caller_modifications_reflected(self):
        f = (
            CyverProjectFile.from_dict(_populated_payload())
            .set_caption("new caption")
            .set_description("")
            .set_visible_to_client(True)
        )
        d = f.to_dict()
        assert d["caption"]         == "new caption"
        assert d["description"]     == ""
        assert d["visibleToClient"] is True


# ---------------------------------------------------------------------------
# from_dict() — hydration from real captures
# ---------------------------------------------------------------------------

class TestFromDict:

    def test_populated_payload_hydrates_completely(self):
        f = CyverProjectFile.from_dict(_populated_payload())
        assert f.guid          == FILE_GUID
        assert f.file_name     == "cookie_monster.png"
        assert f.mime_type     == "image/png"
        assert f.file_size     == 516545
        assert f.uploaded_at   == "2026-04-24T13:21:15.3258246Z"
        assert f.uploaded_by   == UPLOADER
        assert f.download_link is None
        assert f.file_type     == 4
        assert f.additional_guid   is None        # zero sentinel mapped to None
        assert f.visible_to_client is False
        assert f.description   == "Test321"
        assert f.caption       == "Test123"

    def test_null_caption_description_become_empty_string(self):
        f = CyverProjectFile.from_dict(_populated_payload(
            caption=None, description=None,
        ))
        assert f.caption     == ""
        assert f.description == ""

    def test_null_visible_to_client_becomes_false(self):
        f = CyverProjectFile.from_dict(_populated_payload(visibleToClient=None))
        assert f.visible_to_client is False

    def test_uploaded_by_can_be_email(self):
        # The GetAllProjectFiles capture returns an email string here.
        f = CyverProjectFile.from_dict(_populated_payload(
            uploadedBy="henrique.soares@thoropass.com",
        ))
        assert f.uploaded_by == "henrique.soares@thoropass.com"

    def test_uploaded_by_can_be_null(self):
        # The GetProjectImagesFiles capture returns null here.
        f = CyverProjectFile.from_dict(_populated_payload(uploadedBy=None))
        assert f.uploaded_by is None

    def test_uploaded_by_not_uuid_validated(self):
        """A non-UUID uploadedBy is accepted — field is opaque."""
        f = CyverProjectFile.from_dict(_populated_payload(
            uploadedBy="plain-string-not-a-uuid",
        ))
        assert f.uploaded_by == "plain-string-not-a-uuid"

    def test_image_capture_sample_hydrates(self):
        """An item from the real GetProjectImagesFiles response."""
        sample = {
            "guid":            "59368b1f-ff08-486c-b0cc-8ed47bdc7eb7",
            "fileName":        "file_type4.png",
            "mimeType":        "image/png",
            "fileSize":        41017,
            "uploadedAt":      "2026-04-23T20:19:54.9078469Z",
            "uploadedBy":      None,
            "downloadLink":    None,
            "type":            4,
            "additionalGuid":  ZERO_GUID,
            "visibleToClient": False,
            "description":     None,
            "caption":         None,
        }
        f = CyverProjectFile.from_dict(sample)
        assert f.guid        == "59368b1f-ff08-486c-b0cc-8ed47bdc7eb7"
        assert f.uploaded_by is None
        assert f.caption     == ""
        assert f.description == ""
        assert f.additional_guid is None

    def test_non_zero_additional_guid_preserved(self):
        f = CyverProjectFile.from_dict(_populated_payload(
            additionalGuid=OTHER_GUID,
        ))
        assert f.additional_guid == OTHER_GUID

    def test_from_dict_raises_on_out_of_range_file_type(self):
        """Type codes outside `_project_file_type._valid` are rejected.

        Code 99 is in a gap above the last assigned code (61) and below
        the typical "way out of range" 100+ space — it survives any
        plausible future widening of the alias set unless the Cyver API
        adopts contiguous numbering.
        """
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile.from_dict(_populated_payload(type=99))
        assert exc.value.reason == "invalid_value"

    def test_from_dict_raises_on_malformed_guid(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverProjectFile.from_dict(_populated_payload(guid="not-a-uuid"))
        assert exc.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# validate_for_post / validate_for_put
# ---------------------------------------------------------------------------

class TestValidation:

    def test_fresh_instance_passes_validate_for_post(self):
        CyverProjectFile("x.png", 10, 6).validate_for_post()

    def test_fresh_instance_fails_validate_for_put(self):
        with pytest.raises(CyverDataValidationError, match="guid"):
            CyverProjectFile("x.png", 10, 6).validate_for_put()

    def test_hydrated_instance_passes_validate_for_put(self):
        CyverProjectFile.from_dict(_populated_payload()).validate_for_put()

    def test_validate_for_post_fails_if_file_name_cleared(self):
        f = CyverProjectFile("x.png", 10, 6)
        f._file_name = ""
        with pytest.raises(CyverDataValidationError):
            f.validate_for_post()


# ---------------------------------------------------------------------------
# __repr__
# ---------------------------------------------------------------------------

class TestRepr:

    def test_fresh_repr_contains_file_name(self):
        r = repr(CyverProjectFile("x.png", 10, 6))
        assert "x.png" in r
        assert "CyverProjectFile" in r

    def test_fresh_repr_omits_default_fields(self):
        r = repr(CyverProjectFile("x.png", 10, 6))
        assert "visibleToClient" not in r
        assert "caption" not in r
        assert "description" not in r

    def test_hydrated_repr_includes_guid_prefix(self):
        r = repr(CyverProjectFile.from_dict(_populated_payload()))
        assert f"guid={FILE_GUID!r}" in r

    def test_repr_lists_modified_fields_only(self):
        f = (
            CyverProjectFile("x.png", 10, 6)
            .set_caption("c")
            .set_visible_to_client(True)
        )
        r = repr(f)
        assert "caption" in r
        assert "visibleToClient" in r
        assert "description" not in r


# ---------------------------------------------------------------------------
# Public-surface discipline — no setters for server-managed fields
# ---------------------------------------------------------------------------

class TestPublicSurfaceDiscipline:

    def test_no_setters_for_server_managed_fields(self):
        forbidden = (
            "set_guid", "set_file_name", "set_file_size", "set_file_type",
            "set_mime_type", "set_uploaded_at", "set_uploaded_by",
            "set_download_link",
        )
        for name in forbidden:
            assert not hasattr(CyverProjectFile, name), (
                f"{name!r} should not exist — these fields are server-managed"
            )

    def test_exposed_read_properties(self):
        f = CyverProjectFile.from_dict(_populated_payload())
        # Confirm every server-managed field is at least readable.
        _ = f.guid, f.file_name, f.file_size, f.file_type
        _ = f.mime_type, f.uploaded_at, f.uploaded_by, f.download_link
