"""
Tests for CyverUser — construction, setters, validation, serialisation,
and the standalone _validate_email / _validate_datetime helpers.
"""

import pytest

from CyverReporting import CyverDataValidationError
from CyverReporting.DataTypes import CyverUser
from CyverReporting.Utils import (
    _user_role,
    _validate_email,
    _validate_datetime,
)

# ---------------------------------------------------------------------------
# Helpers / shared data
# ---------------------------------------------------------------------------

FAKE_UUID   = "12345678-1234-1234-1234-123456789abc"
FAKE_UUID_2 = "abcdef12-abcd-abcd-abcd-abcdef123456"

VALID_NAME         = "Alice"
VALID_SURNAME      = "Smith"
VALID_EMAIL        = "alice@example.com"
VALID_ROLE         = _user_role.pentester_general   # 7 — no client_id required
VALID_CLIENT_ROLE  = _user_role.client_general      # 3 — client_id required

VALID_DATETIME_NO_FRAC   = "2024-05-08T19:33:23Z"
VALID_DATETIME_WITH_FRAC = "2024-05-08T19:33:23.7225068Z"


def make_user(**kwargs) -> CyverUser:
    """Return a minimally valid CyverUser (pentester role), overriding fields."""
    defaults = dict(name=VALID_NAME, surname=VALID_SURNAME,
                    email=VALID_EMAIL, role=VALID_ROLE)
    defaults.update(kwargs)
    return CyverUser(**defaults)


def make_client_user(**kwargs) -> CyverUser:
    """Return a CyverUser with a Client role and client_id already set."""
    defaults = dict(name=VALID_NAME, surname=VALID_SURNAME,
                    email=VALID_EMAIL, role=VALID_CLIENT_ROLE)
    defaults.update(kwargs)
    user = CyverUser(**defaults)
    user.set_client_id(FAKE_UUID_2)
    return user


# ---------------------------------------------------------------------------
# _validate_email — standalone helper
# ---------------------------------------------------------------------------

class TestValidateEmail:

    @pytest.mark.parametrize("addr", [
        "user@example.com",
        "user.name+tag@sub.domain.org",
        "alice@cyver.io",
        "a@b.co",
        "test123@test-domain.net",
        "first.last@company.com",
    ])
    def test_valid_emails_do_not_raise(self, addr):
        _validate_email(addr, "email")  # must not raise

    @pytest.mark.parametrize("addr", [
        "notanemail",
        "@nodomain.com",
        "noatsign",
        "missing@",
        "missing@domain",          # no TLD
        "user @example.com",       # space in local part
        "user@ example.com",       # space in domain
        "",
        "double@@example.com",
    ])
    def test_invalid_emails_raise(self, addr):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_email(addr, "email")
        assert exc_info.value.field == "email"
        assert exc_info.value.reason == "invalid_email"


# ---------------------------------------------------------------------------
# _validate_datetime — standalone helper
# ---------------------------------------------------------------------------

class TestValidateDatetime:

    @pytest.mark.parametrize("dt", [
        "2024-05-08T19:33:23Z",
        "2024-05-08T19:33:23.7225068Z",
        "2024-05-08T19:33:23.0Z",
        "2024-05-08T19:33:23.123456789Z",
        "2000-01-01T00:00:00Z",
        "2099-12-31T23:59:59.999Z",
    ])
    def test_valid_datetimes_do_not_raise(self, dt):
        _validate_datetime(dt, "creationTime")  # must not raise

    @pytest.mark.parametrize("dt", [
        "2024-05-08 19:33:23Z",        # space instead of T
        "2024-05-08T19:33:23",         # missing Z
        "2024-05-08T19:33:23+00:00",   # timezone offset instead of Z
        "05-08-2024T19:33:23Z",        # wrong date order
        "2024-13-08T19:33:23Z",        # invalid month
        "2024-05-32T19:33:23Z",        # invalid day
        "2024-05-08T25:33:23Z",        # invalid hour
        "2024-05-08T19:60:23Z",        # invalid minute
        "2024-05-08T19:33:60Z",        # invalid second
        "not-a-datetime",
        "",
        "2024-05-08T19:33:23.Z",       # dot but no digits
    ])
    def test_invalid_datetimes_raise(self, dt):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_datetime(dt, "creationTime")
        assert exc_info.value.field == "creationTime"
        assert exc_info.value.reason == "invalid_datetime"


# ---------------------------------------------------------------------------
# CyverUser — construction
# ---------------------------------------------------------------------------

class TestConstruction:

    def test_valid_construction(self):
        user = CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, VALID_ROLE)
        assert user.name == VALID_NAME
        assert user.surname == VALID_SURNAME
        assert user.email == VALID_EMAIL
        assert user.role == VALID_ROLE

    def test_optional_fields_default_to_none(self):
        user = make_user()
        assert user.id is None
        assert user.client_id is None
        assert user.phone_number is None
        assert user.is_email_confirmed is None
        assert user.is_active is True      # is_active defaults to True
        assert user.is_two_factor_enabled is None
        assert user.is_lockout_enabled is None
        assert user.creation_time is None

    def test_all_valid_role_codes_accepted(self):
        for code in _user_role._valid:
            CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, code)  # must not raise

    # name -------------------------------------------------------------------

    @pytest.mark.parametrize("bad", [123, None, True, [], {}])
    def test_invalid_name_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(bad, VALID_SURNAME, VALID_EMAIL, VALID_ROLE)
        assert exc_info.value.field == "name"
        assert exc_info.value.reason == "invalid_type"

    def test_empty_name_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser("", VALID_SURNAME, VALID_EMAIL, VALID_ROLE)
        assert exc_info.value.field == "name"
        assert exc_info.value.reason == "missing_required"

    # surname ----------------------------------------------------------------

    @pytest.mark.parametrize("bad", [42, None, False, [], {}])
    def test_invalid_surname_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, bad, VALID_EMAIL, VALID_ROLE)
        assert exc_info.value.field == "surname"
        assert exc_info.value.reason == "invalid_type"

    def test_empty_surname_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, "", VALID_EMAIL, VALID_ROLE)
        assert exc_info.value.field == "surname"
        assert exc_info.value.reason == "missing_required"

    # email ------------------------------------------------------------------

    @pytest.mark.parametrize("bad", [123, None, True, [], {}])
    def test_invalid_email_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, VALID_SURNAME, bad, VALID_ROLE)
        assert exc_info.value.field == "email"
        assert exc_info.value.reason == "invalid_type"

    @pytest.mark.parametrize("bad_email", [
        "notanemail",
        "missing@",
        "@nodomain.com",
        "",
    ])
    def test_invalid_email_format_raises(self, bad_email):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, VALID_SURNAME, bad_email, VALID_ROLE)
        assert exc_info.value.field == "email"
        assert exc_info.value.reason == "invalid_email"

    # role -------------------------------------------------------------------

    @pytest.mark.parametrize("bad", ["pentester", None, True, [], {}])
    def test_invalid_role_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, bad)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_type"

    def test_bool_role_rejected(self):
        # bool is a subclass of int so needs an explicit guard
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, True)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_type"

    def test_out_of_range_role_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, 99)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_value"

    def test_role_code_zero_is_valid(self):
        # 0 is falsy in Python; must not be rejected by mistake
        user = CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, 0)
        assert user.role == 0


# ---------------------------------------------------------------------------
# CyverUser — setters (valid)
# ---------------------------------------------------------------------------

class TestSettersValid:

    def test_set_id_valid_uuid(self):
        user = make_user().set_id(FAKE_UUID)
        assert user.id == FAKE_UUID

    def test_set_client_id_valid_uuid(self):
        user = make_user().set_client_id(FAKE_UUID_2)
        assert user.client_id == FAKE_UUID_2

    def test_set_name(self):
        user = make_user().set_name("Bob")
        assert user.name == "Bob"

    def test_set_surname(self):
        user = make_user().set_surname("Jones")
        assert user.surname == "Jones"

    def test_set_email(self):
        user = make_user().set_email("bob@cyver.io")
        assert user.email == "bob@cyver.io"

    def test_set_role_valid_code(self):
        user = make_user().set_role(_user_role.pentester_owner)
        assert user.role == _user_role.pentester_owner

    def test_set_role_client_code(self):
        user = make_user().set_role(_user_role.client_project_view)
        assert user.role == _user_role.client_project_view

    def test_set_phone_number(self):
        user = make_user().set_phone_number("+1-555-0100")
        assert user.phone_number == "+1-555-0100"

    def test_set_is_email_confirmed_true(self):
        assert make_user().set_is_email_confirmed(True).is_email_confirmed is True

    def test_set_is_email_confirmed_false(self):
        assert make_user().set_is_email_confirmed(False).is_email_confirmed is False

    def test_set_is_active_true(self):
        assert make_user().set_is_active(True).is_active is True

    def test_set_is_active_false(self):
        assert make_user().set_is_active(False).is_active is False

    def test_set_is_two_factor_enabled(self):
        assert make_user().set_is_two_factor_enabled(True).is_two_factor_enabled is True

    def test_set_is_lockout_enabled(self):
        assert make_user().set_is_lockout_enabled(False).is_lockout_enabled is False

    def test_set_creation_time_no_fraction(self):
        user = make_user().set_creation_time(VALID_DATETIME_NO_FRAC)
        assert user.creation_time == VALID_DATETIME_NO_FRAC

    def test_set_creation_time_with_fraction(self):
        user = make_user().set_creation_time(VALID_DATETIME_WITH_FRAC)
        assert user.creation_time == VALID_DATETIME_WITH_FRAC

    def test_setters_return_self_for_chaining(self):
        user = make_user()
        result = user.set_phone_number("+44 20 7946 0958")
        assert result is user


# ---------------------------------------------------------------------------
# CyverUser — setters (invalid)
# ---------------------------------------------------------------------------

class TestSettersInvalid:

    @pytest.mark.parametrize("bad", ["not-a-uuid", "", 42, None])
    def test_set_id_invalid_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_id(bad)
        assert exc_info.value.field == "id"

    @pytest.mark.parametrize("bad", ["not-a-uuid", "", 42, None])
    def test_set_client_id_invalid_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_client_id(bad)
        assert exc_info.value.field == "clientId"

    @pytest.mark.parametrize("bad", [None, 123, True, []])
    def test_set_name_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_name(bad)
        assert exc_info.value.field == "name"

    def test_set_name_empty_raises(self):
        with pytest.raises(CyverDataValidationError):
            make_user().set_name("")

    @pytest.mark.parametrize("bad", [None, 123, True, []])
    def test_set_surname_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_surname(bad)
        assert exc_info.value.field == "surname"

    def test_set_surname_empty_raises(self):
        with pytest.raises(CyverDataValidationError):
            make_user().set_surname("")

    @pytest.mark.parametrize("bad", [None, 42, True, []])
    def test_set_email_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_email(bad)
        assert exc_info.value.field == "email"
        assert exc_info.value.reason == "invalid_type"

    def test_set_email_invalid_format_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_email("not-an-email")
        assert exc_info.value.field == "email"
        assert exc_info.value.reason == "invalid_email"

    @pytest.mark.parametrize("bad", ["pentester", None, True, []])
    def test_set_role_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_role(bad)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_type"

    def test_set_role_bool_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_role(True)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_type"

    def test_set_role_out_of_range_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_role(99)
        assert exc_info.value.field == "role"
        assert exc_info.value.reason == "invalid_value"

    @pytest.mark.parametrize("bad", [123, True, None, []])
    def test_set_phone_number_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_phone_number(bad)
        assert exc_info.value.field == "phoneNumber"
        assert exc_info.value.reason == "invalid_type"

    @pytest.mark.parametrize("bad", ["not-a-datetime", "2024-13-01T00:00:00Z", 123, None])
    def test_set_creation_time_invalid_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_creation_time(bad)
        assert exc_info.value.field == "creationTime"

    @pytest.mark.parametrize("bad", ["yes", 1, None, 0])
    def test_set_is_email_confirmed_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_is_email_confirmed(bad)
        assert exc_info.value.field == "isEmailConfirmed"
        assert exc_info.value.reason == "invalid_type"

    @pytest.mark.parametrize("bad", ["yes", 1, None, 0])
    def test_set_is_active_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_is_active(bad)
        assert exc_info.value.field == "isActive"
        assert exc_info.value.reason == "invalid_type"

    @pytest.mark.parametrize("bad", ["true", 1, None])
    def test_set_is_two_factor_enabled_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_is_two_factor_enabled(bad)
        assert exc_info.value.field == "isTwoFactorEnabled"
        assert exc_info.value.reason == "invalid_type"

    @pytest.mark.parametrize("bad", ["false", 0, None])
    def test_set_is_lockout_enabled_wrong_type_raises(self, bad):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().set_is_lockout_enabled(bad)
        assert exc_info.value.field == "isLockoutEnabled"
        assert exc_info.value.reason == "invalid_type"


# ---------------------------------------------------------------------------
# CyverUser — validate_for_post / validate_for_put
# ---------------------------------------------------------------------------

class TestValidation:

    def test_validate_for_post_passes_for_pentester_role(self):
        make_user().validate_for_post()  # must not raise

    def test_validate_for_post_passes_for_client_role_with_client_id(self):
        make_client_user().validate_for_post()  # must not raise

    @pytest.mark.parametrize("client_role", sorted(_user_role._client_roles))
    def test_validate_for_post_fails_for_client_role_without_client_id(self, client_role):
        user = CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, client_role)
        with pytest.raises(CyverDataValidationError) as exc_info:
            user.validate_for_post()
        assert exc_info.value.field == "client_id"
        assert exc_info.value.reason == "missing_required"

    @pytest.mark.parametrize("pentester_role",
                             sorted(_user_role._valid - _user_role._client_roles))
    def test_validate_for_post_passes_for_all_pentester_roles_without_client_id(
            self, pentester_role):
        user = CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, pentester_role)
        user.validate_for_post()  # must not raise

    def test_validate_for_put_fails_without_id(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            make_user().validate_for_put()
        assert exc_info.value.field == "id"
        assert exc_info.value.reason == "missing_required"

    def test_validate_for_put_passes_when_id_set(self):
        make_user().set_id(FAKE_UUID).validate_for_put()  # must not raise

    def test_validate_for_put_fails_for_client_role_without_client_id(self):
        user = (CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, VALID_CLIENT_ROLE)
                .set_id(FAKE_UUID))
        with pytest.raises(CyverDataValidationError) as exc_info:
            user.validate_for_put()
        assert exc_info.value.field == "client_id"
        assert exc_info.value.reason == "missing_required"

    def test_validate_for_put_passes_for_client_role_with_both_ids(self):
        user = (CyverUser(VALID_NAME, VALID_SURNAME, VALID_EMAIL, VALID_CLIENT_ROLE)
                .set_id(FAKE_UUID)
                .set_client_id(FAKE_UUID_2))
        user.validate_for_put()  # must not raise


# ---------------------------------------------------------------------------
# CyverUser — to_dict
# ---------------------------------------------------------------------------

class TestToDict:

    def test_minimal_dict_contains_required_fields_and_is_active(self):
        d = make_user().to_dict()
        assert d == {
            "name": VALID_NAME,
            "surname": VALID_SURNAME,
            "emailAddress": VALID_EMAIL,
            "role": VALID_ROLE,
            "isActive": True,
        }

    def test_is_active_defaults_to_true_in_payload(self):
        d = make_user().to_dict()
        assert d["isActive"] is True

    def test_is_active_false_overrides_default(self):
        d = make_user().set_is_active(False).to_dict()
        assert d["isActive"] is False

    def test_email_serialised_as_emailAddress(self):
        d = make_user().to_dict()
        assert "emailAddress" in d
        assert "email" not in d
        assert d["emailAddress"] == VALID_EMAIL

    def test_client_id_serialised_as_clientGuid(self):
        d = make_client_user().to_dict()
        assert "clientGuid" in d
        assert "clientId" not in d
        assert d["clientGuid"] == FAKE_UUID_2

    def test_optional_fields_absent_when_not_set(self):
        d = make_user().to_dict()
        for key in ("id", "clientGuid", "phoneNumber", "isEmailConfirmed",
                    "isTwoFactorEnabled", "isLockoutEnabled", "creationTime"):
            assert key not in d
        # isActive is always present because it defaults to True
        assert "isActive" in d

    def test_full_dict_contains_all_set_fields(self):
        user = (
            make_client_user()
            .set_id(FAKE_UUID)
            .set_phone_number("+1-555-0100")
            .set_is_email_confirmed(True)
            .set_is_active(True)
            .set_is_two_factor_enabled(False)
            .set_is_lockout_enabled(True)
            .set_creation_time(VALID_DATETIME_WITH_FRAC)
        )
        d = user.to_dict()
        assert d["id"] == FAKE_UUID
        assert d["clientGuid"] == FAKE_UUID_2
        assert d["name"] == VALID_NAME
        assert d["surname"] == VALID_SURNAME
        assert d["emailAddress"] == VALID_EMAIL
        assert d["phoneNumber"] == "+1-555-0100"
        assert d["isEmailConfirmed"] is True
        assert d["isActive"] is True
        assert d["isTwoFactorEnabled"] is False
        assert d["isLockoutEnabled"] is True
        assert d["role"] == VALID_CLIENT_ROLE
        assert d["creationTime"] == VALID_DATETIME_WITH_FRAC

    def test_boolean_false_is_included_in_dict(self):
        d = make_user().set_is_active(False).to_dict()
        assert "isActive" in d
        assert d["isActive"] is False


# ---------------------------------------------------------------------------
# CyverUser — from_dict (deserialises API responses)
# ---------------------------------------------------------------------------

class TestFromDict:

    def _full_api_response(self) -> dict:
        # The API returns "email" (not "emailAddress") and "clientId" (not
        # "clientGuid") when reading user data back.  The role may be a
        # string name as returned by the server.
        return {
            "id": FAKE_UUID,
            "clientId": FAKE_UUID_2,
            "name": VALID_NAME,
            "surname": VALID_SURNAME,
            "email": VALID_EMAIL,
            "phoneNumber": "+1-555-0100",
            "isEmailConfirmed": True,
            "isActive": True,
            "isTwoFactorEnabled": False,
            "isLockoutEnabled": True,
            "role": "Pentester (General)",   # server returns string role name
            "creationTime": VALID_DATETIME_WITH_FRAC,
        }

    def test_from_full_dict_populates_all_fields(self):
        user = CyverUser.from_dict(self._full_api_response())
        assert user.id == FAKE_UUID
        assert user.client_id == FAKE_UUID_2
        assert user.name == VALID_NAME
        assert user.surname == VALID_SURNAME
        assert user.email == VALID_EMAIL
        assert user.phone_number == "+1-555-0100"
        assert user.is_email_confirmed is True
        assert user.is_active is True
        assert user.is_two_factor_enabled is False
        assert user.is_lockout_enabled is True
        assert user.role == "Pentester (General)"
        assert user.creation_time == VALID_DATETIME_WITH_FRAC

    def test_from_dict_with_int_role_code(self):
        data = self._full_api_response()
        data["role"] = VALID_ROLE   # int code also accepted
        user = CyverUser.from_dict(data)
        assert user.role == VALID_ROLE

    def test_from_minimal_dict_optional_fields_are_none(self):
        user = CyverUser.from_dict({
            "name": VALID_NAME,
            "surname": VALID_SURNAME,
            "email": VALID_EMAIL,
            "role": "Pentester (General)",
        })
        assert user.id is None
        assert user.client_id is None
        assert user.phone_number is None
        assert user.is_email_confirmed is None
        assert user.is_active is True      # defaults to True when absent
        assert user.is_two_factor_enabled is None
        assert user.is_lockout_enabled is None
        assert user.creation_time is None

    @pytest.mark.parametrize("missing_key", ["name", "surname", "email", "role"])
    def test_from_dict_missing_required_key_raises(self, missing_key):
        data = self._full_api_response()
        del data[missing_key]
        with pytest.raises(KeyError):
            CyverUser.from_dict(data)

    def test_from_dict_trusts_server_email_without_revalidating(self):
        # from_dict bypasses setters — server-returned data is not re-validated
        data = self._full_api_response()
        data["email"] = "not-an-email-but-server-sent-it"
        user = CyverUser.from_dict(data)
        assert user.email == "not-an-email-but-server-sent-it"

    def test_from_dict_datetime_no_fraction(self):
        data = self._full_api_response()
        data["creationTime"] = VALID_DATETIME_NO_FRAC
        user = CyverUser.from_dict(data)
        assert user.creation_time == VALID_DATETIME_NO_FRAC

    def test_from_dict_returns_cydata_user_instance(self):
        assert isinstance(CyverUser.from_dict(self._full_api_response()), CyverUser)


# ---------------------------------------------------------------------------
# CyverUser — __repr__
# ---------------------------------------------------------------------------

class TestRepr:

    def test_repr_contains_email(self):
        r = repr(make_user())
        assert VALID_EMAIL in r

    def test_repr_contains_role_name(self):
        r = repr(make_user())
        assert _user_role._names[VALID_ROLE] in r

    def test_repr_contains_id_when_set(self):
        r = repr(make_user().set_id(FAKE_UUID))
        assert FAKE_UUID in r

    def test_repr_does_not_contain_id_when_not_set(self):
        r = repr(make_user())
        assert FAKE_UUID not in r

    def test_repr_contains_client_id_label_when_set(self):
        r = repr(make_user().set_client_id(FAKE_UUID_2))
        assert "clientId" in r

    def test_repr_starts_with_class_name(self):
        assert repr(make_user()).startswith("CyverUser(")
