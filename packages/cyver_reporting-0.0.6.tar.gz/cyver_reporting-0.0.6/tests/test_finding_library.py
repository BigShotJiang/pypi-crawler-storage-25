"""
Tests for CyverReporting.DataTypes.CyverFindingLibrary — portal-surface
finding-library data builder.
"""

import pytest

from CyverReporting import CyverFindingLibrary
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _finding_library


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

LIB_GUID      = "11111111-1111-1111-1111-111111111111"
TEMPLATE_GUID = "22222222-2222-2222-2222-222222222222"


def _populated_payload(**overrides) -> dict:
    """Realistic finding-library GET response shape (camelCase keys,
    enum-name-string status fields), with optional overrides."""
    payload = {
        "guid":                          LIB_GUID,
        "name":                          "Web App Toolkit",
        "description":                   "Reusable findings for web app engagements",
        "status":                        "Published",   # name string, not int
        "findingLibraryTemplateStatus":  "Draft",       # name string, not int
        "findingFieldsTemplateGuid":     TEMPLATE_GUID,
        "findingFieldsTemplateName":     "Default Web App Fields",
    }
    payload.update(overrides)
    return payload


# ---------------------------------------------------------------------------
# Constructor — happy path + mandatory-field validation
# ---------------------------------------------------------------------------

class TestConstruction:

    def test_minimal_construction_succeeds(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        assert lib.name   == "Toolkit"
        assert lib.status == _finding_library.draft
        assert lib.guid   is None

    def test_construction_with_named_alias(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.published)
        assert lib.status == 2

    def test_optional_fields_default_to_none(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        assert lib.description                    is None
        assert lib.finding_library_template_status is None
        assert lib.finding_fields_template_guid    is None
        assert lib.finding_fields_template_name    is None

    def test_empty_name_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary("", _finding_library.draft)
        assert exc.value.field == "name"

    def test_non_string_name_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary(123, _finding_library.draft)
        assert exc.value.field  == "name"
        assert exc.value.reason == "invalid_type"

    def test_invalid_status_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary("Toolkit", 99)
        assert exc.value.field  == "status"
        assert exc.value.reason == "invalid_value"

    def test_bool_status_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary("Toolkit", True)
        assert exc.value.field  == "status"
        assert exc.value.reason == "invalid_type"


# ---------------------------------------------------------------------------
# Setters — happy paths and validation
# ---------------------------------------------------------------------------

class TestSetters:

    def _bare(self) -> CyverFindingLibrary:
        return CyverFindingLibrary("Toolkit", _finding_library.draft)

    def test_setters_return_self_for_fluent_chaining(self):
        lib = self._bare()
        result = (
            lib
            .set_name("Renamed")
            .set_status(_finding_library.published)
            .set_description("note")
            .set_finding_library_template_status(_finding_library.draft)
            .set_finding_fields_template_guid(TEMPLATE_GUID)
        )
        assert result is lib

    def test_set_name_round_trip(self):
        lib = self._bare().set_name("New name")
        assert lib.name == "New name"

    def test_set_name_rejects_empty(self):
        with pytest.raises(CyverDataValidationError):
            self._bare().set_name("")

    def test_set_status_round_trip(self):
        lib = self._bare().set_status(_finding_library.published)
        assert lib.status == _finding_library.published

    def test_set_status_rejects_invalid_code(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._bare().set_status(99)
        assert exc.value.reason == "invalid_value"

    def test_set_description_accepts_empty_string(self):
        lib = self._bare().set_description("")
        assert lib.description == ""

    def test_set_description_rejects_non_string(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._bare().set_description(42)
        assert exc.value.reason == "invalid_type"

    def test_set_finding_library_template_status_round_trip(self):
        lib = self._bare().set_finding_library_template_status(_finding_library.published)
        assert lib.finding_library_template_status == _finding_library.published

    def test_set_finding_library_template_status_rejects_invalid_code(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._bare().set_finding_library_template_status(99)
        assert exc.value.field  == "findingLibraryTemplateStatus"
        assert exc.value.reason == "invalid_value"

    def test_set_finding_fields_template_guid_round_trip(self):
        lib = self._bare().set_finding_fields_template_guid(TEMPLATE_GUID)
        assert lib.finding_fields_template_guid == TEMPLATE_GUID

    def test_set_finding_fields_template_guid_rejects_malformed(self):
        with pytest.raises(CyverDataValidationError) as exc:
            self._bare().set_finding_fields_template_guid("not-a-uuid")
        assert exc.value.field  == "findingFieldsTemplateGuid"
        assert exc.value.reason == "invalid_uuid"

    def test_no_setter_for_finding_fields_template_name(self):
        """The template name is server-derived (looked up from the
        template GUID); it has a read-only property but no public
        setter."""
        assert not hasattr(self._bare(), "set_finding_fields_template_name")


# ---------------------------------------------------------------------------
# validate_for_post / validate_for_put
# ---------------------------------------------------------------------------

class TestValidateForPostAndPut:

    def test_validate_for_post_passes_after_construction(self):
        CyverFindingLibrary("Toolkit", _finding_library.draft).validate_for_post()

    def test_validate_for_put_requires_guid(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        with pytest.raises(CyverDataValidationError) as exc:
            lib.validate_for_put()
        assert exc.value.field  == "guid"
        assert exc.value.reason == "missing_required"

    def test_validate_for_put_passes_after_from_dict(self):
        lib = CyverFindingLibrary.from_dict(_populated_payload())
        lib.validate_for_put()  # must not raise


# ---------------------------------------------------------------------------
# to_dict() — emit shape
# ---------------------------------------------------------------------------

class TestToDict:
    """``to_dict`` emits the PascalCase request shape used by the
    ``CreateOrUpdateFindingLibrary`` endpoint — distinct from the
    camelCase used by GET responses."""

    def test_minimal_emits_only_mandatory_fields(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        assert lib.to_dict() == {
            "Name":   "Toolkit",
            "Status": _finding_library.draft,
        }

    def test_keys_are_pascal_case(self):
        lib = (
            CyverFindingLibrary("Toolkit", _finding_library.draft)
            .set_description("desc")
            .set_finding_library_template_status(_finding_library.draft)
            .set_finding_fields_template_guid(TEMPLATE_GUID)
        )
        data = lib.to_dict()
        for expected in ("Name", "Status", "Description",
                         "FindingLibraryTemplateStatus",
                         "FindingFieldsTemplateGuid"):
            assert expected in data
        # camelCase keys must NOT appear on the wire.
        for forbidden in ("name", "status", "description",
                          "findingLibraryTemplateStatus",
                          "findingFieldsTemplateGuid"):
            assert forbidden not in data

    def test_status_emitted_as_raw_int_not_string(self):
        """User-confirmed: send raw ints even though the captured
        frontend sends string-encoded ints (`"1"`)."""
        lib = CyverFindingLibrary("Toolkit", _finding_library.published)
        data = lib.to_dict()
        assert data["Status"] == 2
        assert isinstance(data["Status"], int)
        assert not isinstance(data["Status"], bool)  # rule out bool subclass surprise

    def test_guid_emitted_as_pascal_when_populated_via_from_dict(self):
        lib = CyverFindingLibrary.from_dict(_populated_payload())
        assert lib.to_dict()["Guid"] == LIB_GUID

    def test_optional_fields_only_emitted_when_set(self):
        lib = (
            CyverFindingLibrary("Toolkit", _finding_library.draft)
            .set_description("desc")
            .set_finding_library_template_status(_finding_library.published)
            .set_finding_fields_template_guid(TEMPLATE_GUID)
        )
        data = lib.to_dict()
        assert data["Description"]                  == "desc"
        assert data["FindingLibraryTemplateStatus"] == _finding_library.published
        assert data["FindingFieldsTemplateGuid"]    == TEMPLATE_GUID

    def test_unset_optional_fields_omitted(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        data = lib.to_dict()
        for absent in ("Description", "FindingLibraryTemplateStatus",
                       "FindingFieldsTemplateGuid", "Guid",
                       # FindingFieldsTemplateName is server-derived;
                       # never emitted regardless of state.
                       "FindingFieldsTemplateName"):
            assert absent not in data

    def test_finding_fields_template_name_never_emitted(self):
        """Even when populated by from_dict, the server-derived
        template name is never sent on writes."""
        lib = CyverFindingLibrary.from_dict(_populated_payload())
        assert lib.finding_fields_template_name == "Default Web App Fields"
        assert "FindingFieldsTemplateName" not in lib.to_dict()
        assert "findingFieldsTemplateName" not in lib.to_dict()

    def test_round_trip_through_from_dict_and_to_dict(self):
        """Read camelCase + name-string status; write PascalCase + int
        status. Bridge the encoding via the round-trip."""
        original = _populated_payload()
        lib      = CyverFindingLibrary.from_dict(original)
        data     = lib.to_dict()
        # Names round-trip identically.
        assert data["Name"]        == original["name"]
        assert data["Description"] == original["description"]
        assert data["Guid"]        == original["guid"]
        assert data["FindingFieldsTemplateGuid"] == original["findingFieldsTemplateGuid"]
        # Status fields are rewritten from name-string to int code.
        assert data["Status"]                       == _finding_library._codes[original["status"]]
        assert data["FindingLibraryTemplateStatus"] == _finding_library._codes[original["findingLibraryTemplateStatus"]]


# ---------------------------------------------------------------------------
# from_dict() — schema-drift + mandatory-field handling
# ---------------------------------------------------------------------------

class TestFromDict:
    """``from_dict`` parses the GET response shape: camelCase keys with
    enum-name strings (``"Draft"`` / ``"Published"``) for status fields.
    Translation to integer codes happens internally."""

    def test_happy_path_populates_every_field(self):
        lib = CyverFindingLibrary.from_dict(_populated_payload())
        assert lib.guid                          == LIB_GUID
        assert lib.name                          == "Web App Toolkit"
        assert lib.description                   == "Reusable findings for web app engagements"
        assert lib.status                        == _finding_library.published
        assert lib.finding_library_template_status == _finding_library.draft
        assert lib.finding_fields_template_guid  == TEMPLATE_GUID
        assert lib.finding_fields_template_name  == "Default Web App Fields"

    def test_status_name_string_parsed_to_int_code(self):
        """The GET response carries `status: "Draft"` (string); the
        data class stores the integer code (1) internally."""
        lib = CyverFindingLibrary.from_dict(_populated_payload(status="Draft"))
        assert lib.status == 1
        assert isinstance(lib.status, int)

    def test_template_status_name_string_parsed_to_int_code(self):
        lib = CyverFindingLibrary.from_dict(
            _populated_payload(findingLibraryTemplateStatus="Published")
        )
        assert lib.finding_library_template_status == 2

    def test_missing_name_raises(self):
        payload = _populated_payload()
        del payload["name"]
        with pytest.raises(KeyError):
            CyverFindingLibrary.from_dict(payload)

    def test_missing_status_raises_validation_error(self):
        """A missing `status` key is caught by the name-string parser
        before the constructor sees it — surfaces as a clean
        CyverDataValidationError, not a KeyError."""
        payload = _populated_payload()
        del payload["status"]
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary.from_dict(payload)
        assert exc.value.field  == "status"
        assert exc.value.reason == "missing_required"

    def test_optional_fields_default_to_none_when_absent(self):
        lib = CyverFindingLibrary.from_dict({
            "name":   "Bare",
            "status": "Draft",
        })
        assert lib.description                     is None
        assert lib.finding_library_template_status is None
        assert lib.finding_fields_template_guid    is None
        assert lib.finding_fields_template_name    is None

    def test_unknown_status_name_rejected(self):
        """Schema-drift guard: a status name not in `_finding_library._codes`
        raises with `reason="invalid_value"`."""
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary.from_dict(_populated_payload(status="Archived"))
        assert exc.value.field  == "status"
        assert exc.value.reason == "invalid_value"

    def test_unknown_template_status_name_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary.from_dict(
                _populated_payload(findingLibraryTemplateStatus="Archived")
            )
        assert exc.value.field == "findingLibraryTemplateStatus"

    def test_non_string_status_rejected(self):
        """If the response carries status as a raw int (schema drift),
        it must surface with `reason="invalid_type"`."""
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary.from_dict(_populated_payload(status=1))
        assert exc.value.field  == "status"
        assert exc.value.reason == "invalid_type"

    def test_malformed_template_guid_in_response_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFindingLibrary.from_dict(
                _populated_payload(findingFieldsTemplateGuid="not-a-uuid")
            )
        assert exc.value.reason == "invalid_uuid"


# ---------------------------------------------------------------------------
# Repr — sanity
# ---------------------------------------------------------------------------

class TestRepr:

    def test_repr_includes_class_name_and_set_fields(self):
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)
        text = repr(lib)
        assert "CyverFindingLibrary" in text
        assert "Toolkit"             in text
        assert "name"                in text
        assert "status"              in text
