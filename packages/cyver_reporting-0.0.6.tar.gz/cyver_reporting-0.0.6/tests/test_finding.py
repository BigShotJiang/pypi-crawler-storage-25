"""
Tests for CyverFinding and the validators it depends on:
  _validate_finding_type, _validate_finding_status, _validate_finding_severity,
  _validate_cvss_score, _validate_cvss40_vector, _validate_cvss31_vector,
  _validate_cvss30_vector, _validate_cvss20_vector, _validate_url
"""

import pytest

from CyverReporting.DataTypes.CyverFinding import CyverFinding
from CyverReporting.DataTypes.CyverFindingEvidence import CyverFindingEvidence
from CyverReporting.DataTypes.CyverFindingCustomField import CyverFindingCustomField
from CyverReporting.Utils.FormatValidators import (
    _validate_finding_type,
    _validate_finding_status,
    _validate_finding_severity,
    _validate_cvss_score,
    _validate_cvss40_vector,
    _validate_cvss31_vector,
    _validate_cvss30_vector,
    _validate_cvss20_vector,
    _validate_url,
)
from CyverReporting.Utils.StaticAliases import (
    _finding_type,
    _finding_status,
    _finding_severity,
    _finding_compliance_status,
)
from CyverReporting.Exceptions import CyverDataValidationError

FAKE_UUID  = "12345678-1234-1234-1234-123456789abc"
FAKE_UUID2 = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

V40 = "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
V31 = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
V30 = "CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
V20 = "AV:N/AC:L/Au:N/C:P/I:P/A:P"


# ===========================================================================
# _validate_finding_type
# ===========================================================================

class TestValidateFindingType:

    # --- individual flags ---
    def test_vulnerability(self):
        _validate_finding_type(_finding_type.vulnerability, "type")

    def test_nonconformity(self):
        _validate_finding_type(_finding_type.nonconformity, "type")

    def test_observation(self):
        _validate_finding_type(_finding_type.observation, "type")

    def test_incident(self):
        _validate_finding_type(_finding_type.incident, "type")

    def test_risk(self):
        _validate_finding_type(_finding_type.risk, "type")

    # --- combined bit-flags ---
    def test_vulnerability_and_observation(self):
        _validate_finding_type(
            _finding_type.vulnerability | _finding_type.observation, "type"
        )  # 1 | 4 = 5

    def test_all_flags_combined(self):
        _validate_finding_type(31, "type")  # 1|2|4|8|16

    # --- invalid ---
    def test_zero_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_type(0, "type")
        assert exc_info.value.reason == "invalid_value"

    def test_out_of_mask_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_type(32, "type")
        assert exc_info.value.reason == "invalid_value"

    def test_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_type(True, "type")
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_type("1", "type")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_finding_status
# ===========================================================================

class TestValidateFindingStatus:

    def test_draft(self):
        _validate_finding_status(_finding_status.draft, "status")

    def test_fixed(self):
        _validate_finding_status(_finding_status.fixed, "status")

    def test_false_positive(self):
        _validate_finding_status(_finding_status.false_positive, "status")

    def test_identified(self):
        _validate_finding_status(_finding_status.identified, "status")

    def test_zero_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_status(0, "status")
        assert exc_info.value.reason == "invalid_value"

    def test_fifteen_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_status(15, "status")
        assert exc_info.value.reason == "invalid_value"

    def test_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_status(True, "status")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_finding_severity
# ===========================================================================

class TestValidateFindingSeverity:

    def test_info(self):
        _validate_finding_severity(_finding_severity.info, "severity")

    def test_critical(self):
        _validate_finding_severity(_finding_severity.critical, "severity")

    def test_five_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_severity(5, "severity")
        assert exc_info.value.reason == "invalid_value"

    def test_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_severity(False, "severity")
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_severity("high", "severity")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_cvss_score
# ===========================================================================

class TestValidateCvssScore:

    def test_zero_int(self):
        _validate_cvss_score(0, "score")

    def test_ten_int(self):
        _validate_cvss_score(10, "score")

    def test_float_9_8(self):
        _validate_cvss_score(9.8, "score")

    def test_float_0_0(self):
        _validate_cvss_score(0.0, "score")

    def test_float_10_0(self):
        _validate_cvss_score(10.0, "score")

    def test_above_ten_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss_score(10.1, "score")
        assert exc_info.value.reason == "invalid_cvss_score"

    def test_negative_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss_score(-0.1, "score")
        assert exc_info.value.reason == "invalid_cvss_score"

    def test_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss_score(True, "score")
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss_score("9.8", "score")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_cvss40_vector
# ===========================================================================

class TestValidateCvss40Vector:

    # --- valid ---
    def test_minimal_valid(self):
        _validate_cvss40_vector(V40, "cvss40Vector")

    def test_with_optional_metric(self):
        _validate_cvss40_vector(V40 + "/E:A", "cvss40Vector")

    def test_all_av_values(self):
        for av in ("N", "A", "L", "P"):
            vec = V40.replace("AV:N", f"AV:{av}")
            _validate_cvss40_vector(vec, "cvss40Vector")

    def test_si_safety_value(self):
        vec = V40.replace("SI:N", "SI:S")
        _validate_cvss40_vector(vec, "cvss40Vector")

    # --- wrong prefix ---
    def test_wrong_version_prefix(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(V31, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"

    def test_no_prefix(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(V20, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"

    # --- missing base metrics ---
    def test_missing_av(self):
        vec = "/".join(p for p in V40.split("/") if not p.startswith("AV:"))
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(vec, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"
        assert "AV" in str(exc_info.value)

    def test_missing_sa(self):
        vec = "/".join(p for p in V40.split("/") if not p.startswith("SA:"))
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(vec, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"

    # --- invalid metric values ---
    def test_invalid_av_value(self):
        vec = V40.replace("AV:N", "AV:X")
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(vec, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"
        assert "AV" in str(exc_info.value)

    def test_invalid_ui_value(self):
        vec = V40.replace("UI:N", "UI:R")  # R is valid in 3.x but not 4.0
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(vec, "cvss40Vector")
        assert exc_info.value.reason == "invalid_cvss40_vector"

    # --- type error ---
    def test_non_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss40_vector(123, "cvss40Vector")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_cvss31_vector
# ===========================================================================

class TestValidateCvss31Vector:

    def test_valid(self):
        _validate_cvss31_vector(V31, "cvss31Vector")

    def test_with_temporal(self):
        _validate_cvss31_vector(V31 + "/E:P/RL:T/RC:R", "cvss31Vector")

    def test_all_scope_values(self):
        for s in ("U", "C"):
            vec = V31.replace("S:U", f"S:{s}")
            _validate_cvss31_vector(vec, "cvss31Vector")

    def test_wrong_version(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss31_vector(V30, "cvss31Vector")
        assert exc_info.value.reason == "invalid_cvss31_vector"

    def test_missing_scope(self):
        vec = "/".join(p for p in V31.split("/") if not p.startswith("S:"))
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss31_vector(vec, "cvss31Vector")
        assert exc_info.value.reason == "invalid_cvss31_vector"

    def test_invalid_ui_value(self):
        vec = V31.replace("UI:N", "UI:A")  # A is valid in 4.0 but not 3.1
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss31_vector(vec, "cvss31Vector")
        assert exc_info.value.reason == "invalid_cvss31_vector"

    def test_non_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss31_vector(None, "cvss31Vector")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_cvss30_vector
# ===========================================================================

class TestValidateCvss30Vector:

    def test_valid(self):
        _validate_cvss30_vector(V30, "cvss30Vector")

    def test_wrong_version(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss30_vector(V31, "cvss30Vector")
        assert exc_info.value.reason == "invalid_cvss30_vector"

    def test_missing_ac(self):
        vec = "/".join(p for p in V30.split("/") if not p.startswith("AC:"))
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss30_vector(vec, "cvss30Vector")
        assert exc_info.value.reason == "invalid_cvss30_vector"

    def test_invalid_pr_value(self):
        vec = V30.replace("PR:N", "PR:X")
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss30_vector(vec, "cvss30Vector")
        assert exc_info.value.reason == "invalid_cvss30_vector"


# ===========================================================================
# _validate_cvss20_vector
# ===========================================================================

class TestValidateCvss20Vector:

    def test_valid_bare(self):
        _validate_cvss20_vector(V20, "cvss20Vector")

    def test_valid_with_parens(self):
        _validate_cvss20_vector(f"({V20})", "cvss20Vector")

    def test_with_temporal(self):
        _validate_cvss20_vector(V20 + "/E:U/RL:OF/RC:C", "cvss20Vector")

    def test_all_av_values(self):
        for av in ("N", "A", "L"):
            vec = V20.replace("AV:N", f"AV:{av}")
            _validate_cvss20_vector(vec, "cvss20Vector")

    def test_all_auth_values(self):
        for au in ("N", "S", "M"):
            vec = V20.replace("Au:N", f"Au:{au}")
            _validate_cvss20_vector(vec, "cvss20Vector")

    def test_cvss3x_prefix_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss20_vector(V31, "cvss20Vector")
        assert exc_info.value.reason == "invalid_cvss20_vector"

    def test_missing_auth_metric(self):
        vec = "/".join(p for p in V20.split("/") if not p.startswith("Au:"))
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss20_vector(vec, "cvss20Vector")
        assert exc_info.value.reason == "invalid_cvss20_vector"
        assert "Au" in str(exc_info.value)

    def test_invalid_av_value(self):
        vec = V20.replace("AV:N", "AV:P")  # P is valid in 3.x/4.0 but not 2.0
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss20_vector(vec, "cvss20Vector")
        assert exc_info.value.reason == "invalid_cvss20_vector"

    def test_invalid_ac_value(self):
        vec = V20.replace("AC:L", "AC:X")
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss20_vector(vec, "cvss20Vector")
        assert exc_info.value.reason == "invalid_cvss20_vector"

    def test_non_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_cvss20_vector(42, "cvss20Vector")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# _validate_url
# ===========================================================================

class TestValidateUrl:

    def test_https_domain(self):
        _validate_url("https://example.com", "link")

    def test_http_domain(self):
        _validate_url("http://example.com", "link")

    def test_with_path(self):
        _validate_url("https://example.com/path/to/resource", "link")

    def test_with_query(self):
        _validate_url("https://example.com/search?q=test&page=1", "link")

    def test_with_port(self):
        _validate_url("http://localhost:8080/api", "link")

    def test_localhost(self):
        _validate_url("http://localhost", "link")

    def test_ipv4(self):
        _validate_url("http://192.168.1.1/api", "link")

    def test_no_scheme_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_url("example.com", "link")
        assert exc_info.value.reason == "invalid_url"

    def test_ftp_scheme_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_url("ftp://example.com", "link")
        assert exc_info.value.reason == "invalid_url"

    def test_empty_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_url("", "link")
        assert exc_info.value.reason == "invalid_url"


# ===========================================================================
# CyverFinding — construction
# ===========================================================================

class TestCyverFindingConstruction:

    def test_valid_name(self):
        f = CyverFinding("SQL Injection")
        assert f.name == "SQL Injection"
        assert f.id is None

    def test_empty_name_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFinding("")
        assert exc_info.value.field == "name"
        assert exc_info.value.reason == "missing_required"

    def test_non_string_name_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFinding(42)
        assert exc_info.value.field == "name"
        assert exc_info.value.reason == "invalid_type"

    def test_none_name_raises(self):
        with pytest.raises(CyverDataValidationError):
            CyverFinding(None)

    def test_all_lists_empty_on_init(self):
        f = CyverFinding("Test")
        assert f._cwe_list == []
        assert f._cve_list == []
        assert f._finding_evidence_list == []
        assert f._custom_fields == []


# ===========================================================================
# CyverFinding — plain string setters
# ===========================================================================

class TestCyverFindingStringSetters:

    def setup_method(self):
        self.f = CyverFinding("Test Finding")

    def test_set_name(self):
        self.f.set_name("New Name")
        assert self.f.name == "New Name"

    def test_set_name_empty_raises(self):
        with pytest.raises(CyverDataValidationError, match="name"):
            self.f.set_name("")

    def test_set_code(self):
        self.f.set_code("FIND-001")
        assert self.f._code == "FIND-001"

    def test_set_code_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_code(1)
        assert exc_info.value.reason == "invalid_type"

    def test_set_description(self):
        self.f.set_description("Detailed description.")
        assert self.f._description == "Detailed description."

    def test_set_compliance_comment(self):
        self.f.set_compliance_comment("Does not comply with PCI DSS.")
        assert self.f._compliance_comment == "Does not comply with PCI DSS."

    def test_set_recommendation(self):
        self.f.set_recommendation("Apply input sanitisation.")
        assert self.f._recommendation == "Apply input sanitisation."

    def test_set_background_information(self):
        self.f.set_background_information("Context here.")
        assert self.f._background_information == "Context here."

    def test_set_impact_description(self):
        self.f.set_impact_description("Sensitive data exposed.")
        assert self.f._impact_description == "Sensitive data exposed."

    def test_set_likelihood_description(self):
        self.f.set_likelihood_description("Easily exploitable.")
        assert self.f._likelihood_description == "Easily exploitable."


# ===========================================================================
# CyverFinding — enum-validated integer setters
# ===========================================================================

class TestCyverFindingEnumSetters:

    def setup_method(self):
        self.f = CyverFinding("Test")

    def test_set_type_valid(self):
        self.f.set_type(_finding_type.vulnerability)
        assert self.f._type == 1

    def test_set_type_combined_flags(self):
        self.f.set_type(_finding_type.vulnerability | _finding_type.observation)
        assert self.f._type == 5

    def test_set_type_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_type(0)
        assert exc_info.value.reason == "invalid_value"

    def test_set_status_valid(self):
        self.f.set_status(_finding_status.draft)
        assert self.f._status == 1

    def test_set_status_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_status(99)
        assert exc_info.value.reason == "invalid_value"

    def test_set_severity_valid(self):
        self.f.set_severity(_finding_severity.critical)
        assert self.f._severity == 4

    def test_set_severity_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_severity(5)
        assert exc_info.value.reason == "invalid_value"

    def test_set_compliance_status_valid(self):
        self.f.set_compliance_status(_finding_compliance_status.fail)
        assert self.f._compliance_status == 1

    def test_set_compliance_status_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_compliance_status(2)
        assert exc_info.value.reason == "invalid_value"


# ===========================================================================
# CyverFinding — plain integer setters
# ===========================================================================

class TestCyverFindingPlainIntSetters:

    def setup_method(self):
        self.f = CyverFinding("Test")

    def test_set_impact(self):
        self.f.set_impact(3)
        assert self.f._impact == 3

    def test_set_impact_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_impact(True)
        assert exc_info.value.reason == "invalid_type"

    def test_set_likelihood(self):
        self.f.set_likelihood(5)
        assert self.f._likelihood == 5

    def test_set_likelihood_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_likelihood("5")
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# CyverFinding — CVSS setters
# ===========================================================================

class TestCyverFindingCvssSetters:

    def setup_method(self):
        self.f = CyverFinding("Test")

    def test_set_cvss40_vector(self):
        self.f.set_cvss40_vector(V40)
        assert self.f._cvss40_vector == V40

    def test_set_cvss40_vector_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_cvss40_vector("CVSS:4.0/AV:N")  # missing required metrics
        assert exc_info.value.reason == "invalid_cvss40_vector"

    def test_set_cvss40_score(self):
        self.f.set_cvss40_score(9.3)
        assert self.f._cvss40_score == 9.3

    def test_set_cvss40_score_out_of_range(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_cvss40_score(11.0)
        assert exc_info.value.reason == "invalid_cvss_score"

    def test_set_cvss31_vector(self):
        self.f.set_cvss31_vector(V31)
        assert self.f._cvss31_vector == V31

    def test_set_cvss31_vector_wrong_version(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_cvss31_vector(V30)
        assert exc_info.value.reason == "invalid_cvss31_vector"

    def test_set_cvss31_score_int(self):
        self.f.set_cvss31_score(10)
        assert self.f._cvss31_score == 10

    def test_set_cvss30_vector(self):
        self.f.set_cvss30_vector(V30)
        assert self.f._cvss30_vector == V30

    def test_set_cvss30_score(self):
        self.f.set_cvss30_score(7.5)
        assert self.f._cvss30_score == 7.5

    def test_set_cvss20_vector_bare(self):
        self.f.set_cvss20_vector(V20)
        assert self.f._cvss20_vector == V20

    def test_set_cvss20_vector_with_parens(self):
        self.f.set_cvss20_vector(f"({V20})")
        assert self.f._cvss20_vector == f"({V20})"

    def test_set_cvss20_vector_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_cvss20_vector(V31)
        assert exc_info.value.reason == "invalid_cvss20_vector"

    def test_set_cvss20_score(self):
        self.f.set_cvss20_score(6.4)
        assert self.f._cvss20_score == 6.4

    def test_returns_self(self):
        result = self.f.set_cvss31_vector(V31).set_cvss31_score(9.8)
        assert result is self.f


# ===========================================================================
# CyverFinding — UUID reference setters
# ===========================================================================

class TestCyverFindingUuidSetters:

    def setup_method(self):
        self.f = CyverFinding("Test")

    def test_set_project_task_id(self):
        self.f.set_project_task_id(FAKE_UUID)
        assert self.f._project_task_id == FAKE_UUID

    def test_set_project_task_id_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_project_task_id("not-a-uuid")
        assert exc_info.value.reason == "invalid_uuid"

    def test_set_reviewer_id(self):
        self.f.set_reviewer_id(FAKE_UUID)
        assert self.f._reviewer_id == FAKE_UUID

    def test_set_reviewer_id_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.set_reviewer_id(123)
        assert exc_info.value.reason == "invalid_type"


# ===========================================================================
# CyverFinding — list setters (representative)
# ===========================================================================

class TestCyverFindingListSetters:

    def setup_method(self):
        self.f = CyverFinding("Test")

    # CWE
    def test_add_cwe(self):
        self.f.add_cwe("CWE-89")
        assert self.f._cwe_list == ["CWE-89"]

    def test_add_cwe_invalid(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_cwe("89")

    def test_set_cwe_list(self):
        self.f.set_cwe_list(["CWE-79", "CWE-89"])
        assert self.f._cwe_list == ["CWE-79", "CWE-89"]

    def test_set_cwe_list_invalid_item(self):
        with pytest.raises(CyverDataValidationError):
            self.f.set_cwe_list(["CWE-79", "BAD"])

    # CVE
    def test_add_cve(self):
        self.f.add_cve("CVE-2024-12345")
        assert "CVE-2024-12345" in self.f._cve_list

    def test_add_cve_invalid(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_cve("CVE-24-123")

    def test_set_cve_list(self):
        self.f.set_cve_list(["CVE-2023-0001", "CVE-2024-99999"])
        assert len(self.f._cve_list) == 2

    # MITRE tactics
    def test_add_mitre_tactic(self):
        self.f.add_mitre_attack_tactic("TA0001")
        assert self.f._mitre_attack_tactics_list == ["TA0001"]

    def test_add_mitre_tactic_invalid(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_mitre_attack_tactic("TA001")

    def test_set_mitre_tactics_list(self):
        self.f.set_mitre_attack_tactics_list(["TA0001", "TA0043"])
        assert len(self.f._mitre_attack_tactics_list) == 2

    # MITRE techniques
    def test_add_mitre_technique(self):
        self.f.add_mitre_attack_technique("T1040")
        assert "T1040" in self.f._mitre_attack_techniques_list

    def test_add_mitre_sub_technique(self):
        self.f.add_mitre_attack_technique("T1003.003")
        assert "T1003.003" in self.f._mitre_attack_techniques_list

    def test_add_mitre_technique_invalid(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_mitre_attack_technique("T104")

    # MITRE mitigations
    def test_add_mitre_mitigation(self):
        self.f.add_mitre_attack_mitigation("M1015")
        assert "M1015" in self.f._mitre_attack_mitigations_list

    def test_add_mitre_mitigation_invalid(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_mitre_attack_mitigation("M101")

    # Vulnerability types
    def test_add_vulnerability_type(self):
        self.f.add_vulnerability_type("Injection")
        assert "Injection" in self.f._vulnerability_type_list

    def test_add_vulnerability_type_wrong_type(self):
        with pytest.raises(CyverDataValidationError):
            self.f.add_vulnerability_type(42)

    def test_set_vulnerability_type_list(self):
        self.f.set_vulnerability_type_list(["Injection", "XSS"])
        assert self.f._vulnerability_type_list == ["Injection", "XSS"]

    # External URLs
    def test_add_external_url(self):
        self.f.add_external_url("OWASP", "https://owasp.org")
        assert self.f._external_url_list == [
            {"title": "OWASP", "link": "https://owasp.org"}
        ]

    def test_add_external_url_invalid_link(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.add_external_url("Bad", "not-a-url")
        assert exc_info.value.reason == "invalid_url"

    def test_add_external_url_invalid_title_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.add_external_url(123, "https://example.com")
        assert exc_info.value.reason == "invalid_type"

    def test_set_external_url_list(self):
        self.f.set_external_url_list([
            {"title": "Ref 1", "link": "https://example.com"},
            {"title": "Ref 2", "link": "http://localhost:8080"},
        ])
        assert len(self.f._external_url_list) == 2

    def test_set_external_url_list_invalid_entry(self):
        with pytest.raises(CyverDataValidationError):
            self.f.set_external_url_list([{"title": "X", "link": "ftp://bad"}])

    # Asset IDs
    def test_add_asset_id(self):
        self.f.add_asset_id(FAKE_UUID)
        assert FAKE_UUID in self.f._asset_id_list

    def test_add_asset_id_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.add_asset_id("bad-uuid")
        assert exc_info.value.reason == "invalid_uuid"

    def test_set_asset_id_list(self):
        self.f.set_asset_id_list([FAKE_UUID, FAKE_UUID2])
        assert len(self.f._asset_id_list) == 2

    # Label IDs
    def test_add_label_id(self):
        self.f.add_label_id(FAKE_UUID)
        assert FAKE_UUID in self.f._label_id_list

    # Project control IDs
    def test_add_project_control_id(self):
        self.f.add_project_control_id(FAKE_UUID)
        assert FAKE_UUID in self.f._project_control_id_list

    # Finding evidence
    def test_add_finding_evidence(self):
        ev = CyverFindingEvidence("Evidence 1")
        self.f.add_finding_evidence(ev)
        assert len(self.f._finding_evidence_list) == 1
        assert self.f._finding_evidence_list[0] is ev

    def test_add_finding_evidence_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.add_finding_evidence({"title": "bad"})
        assert exc_info.value.reason == "invalid_type"

    def test_set_finding_evidence_list(self):
        ev1 = CyverFindingEvidence("E1")
        ev2 = CyverFindingEvidence("E2")
        self.f.set_finding_evidence_list([ev1, ev2])
        assert len(self.f._finding_evidence_list) == 2

    # Custom fields
    def test_add_custom_field(self):
        cf = CyverFindingCustomField("Score")
        self.f.add_custom_field(cf)
        assert len(self.f._custom_fields) == 1

    def test_add_custom_field_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.f.add_custom_field("not-a-custom-field")
        assert exc_info.value.reason == "invalid_type"

    def test_set_custom_fields(self):
        cfs = [CyverFindingCustomField(f"F{i}") for i in range(3)]
        self.f.set_custom_fields(cfs)
        assert len(self.f._custom_fields) == 3


# ===========================================================================
# CyverFinding — fluent chaining
# ===========================================================================

class TestCyverFindingFluent:

    def test_all_setters_return_self(self):
        f = CyverFinding("Chain Test")
        result = (
            f
            .set_code("F-001")
            .set_description("desc")
            .set_type(_finding_type.vulnerability)
            .set_status(_finding_status.draft)
            .set_severity(_finding_severity.high)
            .set_compliance_status(_finding_compliance_status.fail)
            .set_compliance_comment("comment")
            .set_impact(3)
            .set_impact_description("impact desc")
            .set_likelihood(4)
            .set_likelihood_description("likelihood desc")
            .set_recommendation("remediation")
            .set_background_information("context")
            .set_cvss31_vector(V31)
            .set_cvss31_score(9.8)
            .set_cvss20_vector(V20)
            .set_cvss20_score(6.4)
            .set_project_task_id(FAKE_UUID)
            .set_reviewer_id(FAKE_UUID2)
            .add_cwe("CWE-89")
            .add_cve("CVE-2024-12345")
            .add_mitre_attack_tactic("TA0001")
            .add_mitre_attack_technique("T1040")
            .add_mitre_attack_mitigation("M1015")
            .add_vulnerability_type("Injection")
            .add_external_url("OWASP", "https://owasp.org")
            .add_asset_id(FAKE_UUID)
            .add_label_id(FAKE_UUID)
            .add_project_control_id(FAKE_UUID)
            .add_finding_evidence(CyverFindingEvidence("Evidence"))
            .add_custom_field(CyverFindingCustomField("Score"))
        )
        assert result is f


# ===========================================================================
# CyverFinding — to_dict
# ===========================================================================

class TestCyverFindingToDict:

    def test_name_only(self):
        d = CyverFinding("Minimal").to_dict()
        assert d == {"name": "Minimal"}

    def test_unset_fields_absent(self):
        d = CyverFinding("Test").set_severity(_finding_severity.high).to_dict()
        assert "code" not in d
        assert "description" not in d
        assert "cvss" not in d
        assert d["severity"] == 3

    def test_cvss_nested_object_included_when_set(self):
        d = CyverFinding("Test").set_cvss31_vector(V31).set_cvss31_score(9.8).to_dict()
        assert "cvss" in d
        assert d["cvss"]["cvss31Vector"] == V31
        assert d["cvss"]["cvss31Score"] == 9.8

    def test_cvss_absent_when_not_set(self):
        d = CyverFinding("Test").to_dict()
        assert "cvss" not in d

    def test_partial_cvss_included(self):
        d = CyverFinding("Test").set_cvss31_score(7.5).to_dict()
        assert d["cvss"] == {"cvss31Score": 7.5}

    def test_lists_absent_when_empty(self):
        d = CyverFinding("Test").to_dict()
        assert "cweList" not in d
        assert "cveList" not in d
        assert "findingEvidenceList" not in d

    def test_lists_present_when_populated(self):
        f = CyverFinding("Test").add_cwe("CWE-79").add_cve("CVE-2024-12345")
        d = f.to_dict()
        assert d["cweList"] == ["CWE-79"]
        assert d["cveList"] == ["CVE-2024-12345"]

    def test_finding_evidence_serialised(self):
        ev = CyverFindingEvidence("Screenshot").set_ip("10.0.0.1")
        d = CyverFinding("Test").add_finding_evidence(ev).to_dict()
        assert d["findingEvidenceList"][0]["title"] == "Screenshot"
        assert d["findingEvidenceList"][0]["ip"] == "10.0.0.1"

    def test_custom_fields_serialised(self):
        cf = CyverFindingCustomField("Score").set_value("9.8")
        d = CyverFinding("Test").add_custom_field(cf).to_dict()
        assert d["customFields"][0]["field"] == "Score"
        assert d["customFields"][0]["value"] == "9.8"

    def test_external_url_serialised(self):
        d = (
            CyverFinding("Test")
            .add_external_url("OWASP", "https://owasp.org")
            .to_dict()
        )
        assert d["externalUrlList"] == [
            {"title": "OWASP", "link": "https://owasp.org"}
        ]

    def test_combined_type_flag_serialised(self):
        d = (
            CyverFinding("Test")
            .set_type(_finding_type.vulnerability | _finding_type.observation)
            .to_dict()
        )
        assert d["type"] == 5


# ===========================================================================
# CyverFinding — from_dict
# ===========================================================================

class TestCyverFindingFromDict:

    def test_minimal(self):
        f = CyverFinding.from_dict({"name": "Minimal"})
        assert f.name == "Minimal"
        assert f.id is None

    def test_full_flat_fields(self):
        data = {
            "id": FAKE_UUID,
            "name": "Full Finding",
            "code": "F-001",
            "description": "A desc",
            "type": 1,
            "status": 2,
            "severity": 3,
            "complianceStatus": 1,
            "complianceComment": "comment",
            "impact": 4,
            "impactDescription": "impact",
            "likelihood": 3,
            "likelihoodDescription": "likelihood",
            "recommendation": "fix it",
            "backgroundInformation": "context",
            "projectTaskId": FAKE_UUID,
            "reviewerId": FAKE_UUID2,
        }
        f = CyverFinding.from_dict(data)
        assert f.id == FAKE_UUID
        assert f.name == "Full Finding"
        assert f._code == "F-001"
        assert f._type == 1
        assert f._status == 2
        assert f._severity == 3
        assert f._compliance_status == 1
        assert f._impact == 4
        assert f._likelihood == 3
        assert f._project_task_id == FAKE_UUID
        assert f._reviewer_id == FAKE_UUID2

    def test_cvss_sub_object(self):
        data = {
            "name": "CVSS Test",
            "cvss": {
                "cvss31Vector": V31,
                "cvss31Score": 9.8,
                "cvss20Vector": V20,
                "cvss20Score": 6.4,
            },
        }
        f = CyverFinding.from_dict(data)
        assert f._cvss31_vector == V31
        assert f._cvss31_score == 9.8
        assert f._cvss20_vector == V20
        assert f._cvss20_score == 6.4
        assert f._cvss40_vector is None

    def test_string_lists(self):
        data = {
            "name": "Lists",
            "cweList": ["CWE-89"],
            "cveList": ["CVE-2024-12345"],
            "mitreAttackTacticsList": ["TA0001"],
            "mitreAttackTechniquesList": ["T1040"],
            "mitreAttackMitigationsList": ["M1015"],
            "vulnerabilityTypeList": ["Injection"],
        }
        f = CyverFinding.from_dict(data)
        assert f._cwe_list == ["CWE-89"]
        assert f._mitre_attack_tactics_list == ["TA0001"]
        assert f._vulnerability_type_list == ["Injection"]

    def test_uuid_lists(self):
        data = {
            "name": "UUID Lists",
            "assetIdList": [FAKE_UUID],
            "labelIdList": [FAKE_UUID2],
            "projectControlIdList": [FAKE_UUID],
        }
        f = CyverFinding.from_dict(data)
        assert f._asset_id_list == [FAKE_UUID]
        assert f._label_id_list == [FAKE_UUID2]

    def test_nested_evidence_list(self):
        data = {
            "name": "Evidence",
            "findingEvidenceList": [{"title": "Screenshot", "ip": "10.0.0.1"}],
        }
        f = CyverFinding.from_dict(data)
        assert len(f._finding_evidence_list) == 1
        assert isinstance(f._finding_evidence_list[0], CyverFindingEvidence)
        assert f._finding_evidence_list[0].title == "Screenshot"

    def test_nested_custom_fields(self):
        data = {
            "name": "Custom",
            "customFields": [{"field": "Score", "value": "9.8"}],
        }
        f = CyverFinding.from_dict(data)
        assert len(f._custom_fields) == 1
        assert isinstance(f._custom_fields[0], CyverFindingCustomField)
        assert f._custom_fields[0].field == "Score"

    def test_roundtrip(self):
        original = (
            CyverFinding("Round-trip")
            .set_severity(_finding_severity.high)
            .set_status(_finding_status.draft)
            .set_cvss31_vector(V31)
            .set_cvss31_score(9.8)
            .add_cwe("CWE-89")
            .add_external_url("Ref", "https://example.com")
        )
        restored = CyverFinding.from_dict(original.to_dict())
        assert restored.name == original.name
        assert restored._severity == original._severity
        assert restored._cvss31_vector == original._cvss31_vector
        assert restored._cwe_list == original._cwe_list
        assert restored._external_url_list == original._external_url_list


# ===========================================================================
# CyverFinding — validate_for_post / validate_for_put
# ===========================================================================

class TestCyverFindingValidation:

    def test_validate_for_post_passes(self):
        CyverFinding("Valid").validate_for_post()

    def test_validate_for_put_without_id_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFinding("No ID").validate_for_put()
        assert exc_info.value.field == "id"
        assert exc_info.value.reason == "missing_required"

    def test_validate_for_put_with_id_passes(self):
        f = CyverFinding.from_dict({"id": FAKE_UUID, "name": "Has ID"})
        f.validate_for_put()  # should not raise


# ===========================================================================
# CyverFinding — __repr__
# ===========================================================================

class TestCyverFindingRepr:

    def test_repr_minimal(self):
        r = repr(CyverFinding("Test"))
        assert "CyverFinding" in r
        assert "Test" in r

    def test_repr_with_id(self):
        f = CyverFinding.from_dict({"id": FAKE_UUID, "name": "With ID"})
        assert FAKE_UUID in repr(f)

    def test_repr_no_id_prefix_when_absent(self):
        assert "id=" not in repr(CyverFinding("No ID"))

    def test_repr_shows_list_counts(self):
        f = CyverFinding("Lists").add_cwe("CWE-79").add_cve("CVE-2024-12345")
        r = repr(f)
        assert "cweList[1]" in r
        assert "cveList[1]" in r


# ---------------------------------------------------------------------------
# Exploit IDs — added with the get_finding_templates admission round
# ---------------------------------------------------------------------------

EXPLOIT_UUID_1 = "11111111-1111-1111-1111-111111111111"
EXPLOIT_UUID_2 = "22222222-2222-2222-2222-222222222222"


class TestCyverFindingExploitIds:

    def test_default_empty(self):
        f = CyverFinding("F")
        assert f.exploit_id_list == []

    def test_add_exploit_id_round_trip(self):
        f = CyverFinding("F").add_exploit_id(EXPLOIT_UUID_1)
        assert f.exploit_id_list == [EXPLOIT_UUID_1]

    def test_add_exploit_id_returns_self(self):
        f = CyverFinding("F")
        assert f.add_exploit_id(EXPLOIT_UUID_1) is f

    def test_add_exploit_id_rejects_non_uuid(self):
        from CyverReporting.Exceptions import CyverDataValidationError
        with pytest.raises(CyverDataValidationError):
            CyverFinding("F").add_exploit_id("not-a-uuid")

    def test_set_exploit_id_list_replaces(self):
        f = CyverFinding("F").add_exploit_id(EXPLOIT_UUID_1)
        f.set_exploit_id_list([EXPLOIT_UUID_2])
        assert f.exploit_id_list == [EXPLOIT_UUID_2]

    def test_set_exploit_id_list_rejects_non_list(self):
        from CyverReporting.Exceptions import CyverDataValidationError
        with pytest.raises(CyverDataValidationError):
            CyverFinding("F").set_exploit_id_list(EXPLOIT_UUID_1)

    def test_set_exploit_id_list_rejects_non_uuid_element(self):
        from CyverReporting.Exceptions import CyverDataValidationError
        with pytest.raises(CyverDataValidationError):
            CyverFinding("F").set_exploit_id_list([EXPLOIT_UUID_1, "not-a-uuid"])

    def test_to_dict_emits_exploit_ids_when_set(self):
        f = CyverFinding("F").add_exploit_id(EXPLOIT_UUID_1)
        assert f.to_dict()["exploitIds"] == [EXPLOIT_UUID_1]

    def test_to_dict_omits_exploit_ids_when_empty(self):
        f = CyverFinding("F")
        assert "exploitIds" not in f.to_dict()


# ---------------------------------------------------------------------------
# from_dict — template-shape responses (get_finding_templates admission)
# ---------------------------------------------------------------------------

# Captured GetFindingTemplates response item (one element of result.items)
TEMPLATE_ITEM = {
    "guid":                          "2fbcb70d-4a5d-4e10-a5ca-3d967ea0b11e",
    "name":                          "Missing Security Headers",
    "status":                        "Published",
    "externalUrl":                   [{"title": "", "link": ""}],
    "type":                          1,
    "description":                   "...",
    "criticality":                   1,
    "impact":                        0,
    "impactDescription":             "...",
    "likelihood":                    0,
    "likelihoodDescription":         "...",
    "cvsS40Vector":                  "",
    "cvsS40Score":                   None,
    "cvsS31Vector":                  "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:N/A:N",
    "cvsS31Score":                   3.7,
    "cvsS30Vector":                  "",
    "cvsS30Score":                   None,
    "cvsS20Vector":                  "",
    "cvsS20Score":                   None,
    "recommendation":                "...",
    "backgroundInformation":         "...",
    "vulnerabilityTypes":            None,
    "findingCWEs":                   ["CWE-693"],
    "findingCVEs":                   [],
    "findingMitreAttackTactics":     ["TA0001"],
    "findingMitreAttackTechniques":  ["T1071"],
    "findingMitreAttackMitigations": ["M1041"],
    "exploitIds":                    [EXPLOIT_UUID_1],
    "findingLibraryGuid":            "1556a4fe-bee8-440a-9151-c746b27a5c0b",
    "findingLibraryName":            "Web & API Library",
    "controlTemplatesIds":           ["f2f96843-0f45-43c0-b476-059fe860cde6"],
    "mergeTitleRegex1":              "",
    "mergeTitleRegex2":              "",
    "mergeTitleRegex3":              "",
    "mergeTitleRegex4":              "",
    "mergeTitleRegex5":              "",
    "labels":                        "",
    "complianceStatus":              None,
    "complianceComment":             "",
    "customFields":                  [],
}


class TestFromDictTemplateMode:
    """``from_dict(item, as_template=True)`` ignores guid + status from the
    template response and assigns id=None / status=Draft, ready for use as
    the seed for ``create_finding``."""

    def test_as_template_leaves_id_empty(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f.id is None

    def test_as_template_assigns_draft_status(self):
        from CyverReporting.Utils import _finding_status
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._status == _finding_status.draft  # = 1

    def test_default_path_unchanged(self):
        """``as_template=False`` (default) reads id and status as before."""
        proj = {
            "id":     "abcdef12-1234-1234-1234-abcdef123456",
            "name":   "P",
            "status": 5,
        }
        f = CyverFinding.from_dict(proj)
        assert f.id     == "abcdef12-1234-1234-1234-abcdef123456"
        assert f._status == 5

    def test_template_to_dict_round_trip_for_create_finding(self):
        """End-to-end: parse template → serialize for create_finding.
        The output must omit `id` (server assigns) and contain status=1
        (Draft)."""
        from CyverReporting.Utils import _finding_status
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        data = f.to_dict()
        assert "id" not in data
        assert data["status"] == _finding_status.draft
        assert data["name"]   == "Missing Security Headers"

    # --- shape-tolerance: alternative wire keys ---

    def test_external_url_singular_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._external_url_list == [{"title": "", "link": ""}]

    def test_vulnerability_types_singular_key_hydrates(self):
        # captured response sends `vulnerabilityTypes: null`; expect []
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._vulnerability_type_list == []

    def test_finding_cwes_alternate_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._cwe_list == ["CWE-693"]

    def test_finding_cves_alternate_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._cve_list == []

    def test_finding_mitre_tactics_alternate_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._mitre_attack_tactics_list == ["TA0001"]

    def test_finding_mitre_techniques_alternate_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._mitre_attack_techniques_list == ["T1071"]

    def test_finding_mitre_mitigations_alternate_key_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._mitre_attack_mitigations_list == ["M1041"]

    def test_control_templates_ids_folded_into_project_control_id_list(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._project_control_id_list == [
            "f2f96843-0f45-43c0-b476-059fe860cde6",
        ]

    def test_labels_csv_string_parsed_to_list(self):
        item = dict(TEMPLATE_ITEM)
        item["labels"] = "tag-a, tag-b ,, tag-c"
        f = CyverFinding.from_dict(item, as_template=True)
        assert f._label_id_list == ["tag-a", "tag-b", "tag-c"]

    def test_labels_empty_string_yields_empty_list(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._label_id_list == []

    # --- CVSS shape tolerance: flat top-level with `cvsS` typo ---

    def test_cvss_flat_with_cvsS_typo_hydrates(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._cvss31_vector == "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:N/A:N"
        assert f._cvss31_score  == 3.7

    def test_cvss_nested_still_hydrates_in_default_mode(self):
        proj = {
            "name": "P",
            "cvss": {
                "cvss31Vector": "CVSS:3.1/...",
                "cvss31Score":  7.5,
            },
        }
        f = CyverFinding.from_dict(proj)
        assert f._cvss31_vector == "CVSS:3.1/..."
        assert f._cvss31_score  == 7.5

    # --- D11a: criticality folded into severity ---

    def test_criticality_folds_into_severity_when_severity_absent(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f._severity == 1  # from template's `criticality: 1`

    def test_severity_takes_precedence_over_criticality(self):
        item = dict(TEMPLATE_ITEM)
        item["severity"]    = 4   # explicit project-finding severity
        item["criticality"] = 1   # template-shape value
        f = CyverFinding.from_dict(item, as_template=True)
        assert f._severity == 4   # `severity` wins

    # --- D11b/c/d: disregarded keys ---

    def test_disregarded_keys_silently_ignored(self):
        """findingLibraryGuid, findingLibraryName, mergeTitleRegex1..5
        in the response do not blow up from_dict and do not surface as
        new attributes on CyverFinding."""
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        # No attribute exists for any of these — confirm explicitly.
        assert not hasattr(f, "_finding_library_guid")
        assert not hasattr(f, "_finding_library_name")
        assert not hasattr(f, "_merge_title_regex_list")
        assert not hasattr(f, "_merge_title_regex_1")

    # --- D11e: exploitIds ---

    def test_exploit_ids_hydrate_into_list(self):
        f = CyverFinding.from_dict(TEMPLATE_ITEM, as_template=True)
        assert f.exploit_id_list == [EXPLOIT_UUID_1]


# ---------------------------------------------------------------------------
# Search-summary context fields (added with the search_findings admission
# round) — eight new attributes on CyverFinding hydrated from portal
# ``Finding/GetFindings`` responses.  Setters accept ``str | None`` so
# callers can clear a previously-populated value.
# ---------------------------------------------------------------------------

PORTAL_SUMMARY_ITEM = {
    "guid":                "f53de42f-4c7c-44a0-8389-8173f91a8ac2",
    "code":                "F-2026-15251",
    "name":                "OpenSSH Sensitive Information Disclosure Vulnerability",
    "type":                1,
    "status":              5,
    "criticality":         4,
    "clientAssigneeName":  " ",  # whitespace-only → None
    "projectName":         "Acme Mock Web & API Pentest",
    "projectGuid":         "5aa3af05-7739-4034-a8ed-e6df46d3f714",
    "clientName":          "Acme Corp.",
    "clientGuid":          "9cfd3472-f027-4d4d-860e-7cd00d7742a5",
    "reporter":            "Henrique Soares",
    "reviewer":            None,
    "pentesterAssignee":   None,
    "labels":              "",
}

VALID_UUID_A = "11111111-1111-1111-1111-111111111111"
VALID_UUID_B = "22222222-2222-2222-2222-222222222222"


class TestCyverFindingSummaryAttributesDefaults:
    """Freshly constructed instances have every search-summary field
    set to None (these fields are populated only by ``from_dict``)."""

    def test_all_summary_fields_default_to_none(self):
        f = CyverFinding("X")
        assert f.project_id              is None
        assert f.client_id               is None
        assert f.project_name            is None
        assert f.client_name             is None
        assert f.reporter_name           is None
        assert f.reviewer_name           is None
        assert f.pentester_assignee_name is None
        assert f.client_assignee_name    is None


class TestCyverFindingSummaryUuidSetters:

    def test_set_project_id_accepts_valid_uuid(self):
        f = CyverFinding("X").set_project_id(VALID_UUID_A)
        assert f.project_id == VALID_UUID_A

    def test_set_project_id_none_clears(self):
        f = CyverFinding("X").set_project_id(VALID_UUID_A).set_project_id(None)
        assert f.project_id is None

    @pytest.mark.parametrize("bad", ["", "not-a-uuid", "12345"])
    def test_set_project_id_rejects_malformed_uuid(self, bad):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFinding("X").set_project_id(bad)
        assert exc.value.field == "projectId"

    def test_set_project_id_rejects_non_string(self):
        with pytest.raises(CyverDataValidationError) as exc:
            CyverFinding("X").set_project_id(42)  # type: ignore[arg-type]
        assert exc.value.reason == "invalid_type"

    def test_set_client_id_accepts_valid_uuid_and_none_clears(self):
        f = CyverFinding("X").set_client_id(VALID_UUID_A)
        assert f.client_id == VALID_UUID_A
        f.set_client_id(None)
        assert f.client_id is None

    @pytest.mark.parametrize("bad", ["", "x" * 40])
    def test_set_client_id_rejects_malformed_uuid(self, bad):
        with pytest.raises(CyverDataValidationError):
            CyverFinding("X").set_client_id(bad)


class TestCyverFindingSummaryNameSetters:

    @pytest.mark.parametrize("setter,attr,wire", [
        ("set_project_name",            "project_name",            "projectName"),
        ("set_client_name",             "client_name",             "clientName"),
        ("set_reporter_name",           "reporter_name",           "reporter"),
        ("set_reviewer_name",           "reviewer_name",           "reviewer"),
        ("set_pentester_assignee_name", "pentester_assignee_name", "pentesterAssignee"),
        ("set_client_assignee_name",    "client_assignee_name",    "clientAssigneeName"),
    ])
    def test_set_round_trip_and_none_clears(self, setter, attr, wire):
        f = CyverFinding("X")
        getattr(f, setter)("Henrique Soares")
        assert getattr(f, attr) == "Henrique Soares"
        getattr(f, setter)(None)
        assert getattr(f, attr) is None

    @pytest.mark.parametrize("setter,wire", [
        ("set_project_name",            "projectName"),
        ("set_client_name",             "clientName"),
        ("set_reporter_name",           "reporter"),
        ("set_reviewer_name",           "reviewer"),
        ("set_pentester_assignee_name", "pentesterAssignee"),
        ("set_client_assignee_name",    "clientAssigneeName"),
    ])
    def test_empty_string_rejected(self, setter, wire):
        with pytest.raises(CyverDataValidationError) as exc:
            getattr(CyverFinding("X"), setter)("")
        assert exc.value.field == wire

    @pytest.mark.parametrize("setter", [
        "set_project_name", "set_client_name", "set_reporter_name",
        "set_reviewer_name", "set_pentester_assignee_name",
        "set_client_assignee_name",
    ])
    def test_non_string_rejected(self, setter):
        with pytest.raises(CyverDataValidationError) as exc:
            getattr(CyverFinding("X"), setter)(42)  # type: ignore[arg-type]
        assert exc.value.reason == "invalid_type"


class TestCyverFindingSummaryFromDict:

    def test_full_round_trip_from_portal_summary_item(self):
        f = CyverFinding.from_dict(PORTAL_SUMMARY_ITEM)

        assert f.id          == "f53de42f-4c7c-44a0-8389-8173f91a8ac2"
        assert f._code       == "F-2026-15251"
        assert f._severity   == 4   # criticality folded
        assert f.project_id              == "5aa3af05-7739-4034-a8ed-e6df46d3f714"
        assert f.project_name            == "Acme Mock Web & API Pentest"
        assert f.client_id               == "9cfd3472-f027-4d4d-860e-7cd00d7742a5"
        assert f.client_name             == "Acme Corp."
        assert f.reporter_name           == "Henrique Soares"
        assert f.reviewer_name           is None
        assert f.pentester_assignee_name is None
        assert f.client_assignee_name    is None  # " " → None

    def test_id_alias_falls_back_to_guid(self):
        f = CyverFinding.from_dict({"guid": VALID_UUID_A, "name": "X"})
        assert f.id == VALID_UUID_A

    def test_id_takes_precedence_over_guid(self):
        f = CyverFinding.from_dict({"id": VALID_UUID_A, "guid": VALID_UUID_B, "name": "X"})
        assert f.id == VALID_UUID_A

    def test_project_id_alias_falls_back_to_projectGuid(self):
        f = CyverFinding.from_dict({"projectGuid": VALID_UUID_A, "name": "X"})
        assert f.project_id == VALID_UUID_A

    def test_project_id_takes_precedence_over_project_guid(self):
        f = CyverFinding.from_dict({
            "projectId": VALID_UUID_A, "projectGuid": VALID_UUID_B, "name": "X",
        })
        assert f.project_id == VALID_UUID_A

    def test_client_id_alias_falls_back_to_clientGuid(self):
        f = CyverFinding.from_dict({"clientGuid": VALID_UUID_A, "name": "X"})
        assert f.client_id == VALID_UUID_A

    def test_whitespace_only_names_normalised_to_none(self):
        f = CyverFinding.from_dict({
            "name": "X",
            "clientAssigneeName": "   ",
            "reporter": "\t",
        })
        assert f.client_assignee_name is None
        assert f.reporter_name        is None

    def test_summary_fields_default_to_none_when_absent(self):
        """A project-finding response that does not carry the summary
        keys leaves every summary attribute at None — backwards
        compatibility check."""
        f = CyverFinding.from_dict({"id": VALID_UUID_A, "name": "X"})
        assert f.project_id              is None
        assert f.project_name            is None
        assert f.client_id               is None
        assert f.client_name             is None
        assert f.reporter_name           is None
        assert f.reviewer_name           is None
        assert f.pentester_assignee_name is None
        assert f.client_assignee_name    is None
