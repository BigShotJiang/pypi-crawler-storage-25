"""
Tests for ``PentesterPortal.delete_finding_library`` — wraps
``DELETE /api/services/app/FindingLibrary/DeleteFindingLibrary``.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


LIB_GUID = "1064bea3-a3d2-4af0-bf9c-5847f11f3870"


def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# Wire dispatch
# ---------------------------------------------------------------------------

class TestDeleteFindingLibraryDispatch:

    def test_dispatches_delete_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.delete_finding_library(LIB_GUID)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "DELETE"
        assert path == "/api/services/app/FindingLibrary/DeleteFindingLibrary"

    def test_query_param_uses_short_id_key(self):
        """Regression: the wire query parameter is ``id``, not
        ``library_id`` or ``guid`` — per captured Burp request."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.delete_finding_library(LIB_GUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {"id": LIB_GUID}
        assert "library_id" not in params
        assert "guid"       not in params

    def test_no_request_body_sent(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.delete_finding_library(LIB_GUID)

        assert "data" not in p._send_api_request.call_args.kwargs


# ---------------------------------------------------------------------------
# Return value
# ---------------------------------------------------------------------------

class TestDeleteFindingLibraryReturn:

    def test_returns_none_when_server_result_is_null(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        result = p.delete_finding_library(LIB_GUID)

        assert result is None


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

class TestDeleteFindingLibraryValidation:

    def test_invalid_library_id_raises_and_skips_http(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.delete_finding_library("not-a-uuid")
        assert exc_info.value.field  == "library_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()


# ---------------------------------------------------------------------------
# portal_unstable warning
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        PentesterPortal.delete_finding_library._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.delete_finding_library(LIB_GUID)
            p.delete_finding_library(LIB_GUID)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "delete_finding_library" in str(portal_warnings[0].message)
