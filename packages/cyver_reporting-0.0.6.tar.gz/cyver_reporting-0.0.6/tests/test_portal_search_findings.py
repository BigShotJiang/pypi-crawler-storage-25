"""
Tests for ``PentesterPortal.search_findings`` and its iterator
sibling ``search_all_findings`` — wraps the portal's
``GET /api/services/app/Finding/GetFindings`` endpoint.
"""

from __future__ import annotations

import warnings

import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverFinding,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


PROJECT_GUID = "5aa3af05-7739-4034-a8ed-e6df46d3f714"
CLIENT_GUID  = "9cfd3472-f027-4d4d-860e-7cd00d7742a5"


def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _captured_response_items() -> list[dict]:
    """Mirror the six summary items from the user's captured
    ``GET /api/services/app/Finding/GetFindings?filter=OpenSSH&...``
    response.  Real-shape — both alias keys (``guid``,
    ``projectGuid``, ``clientGuid``) plus every display-name field
    the portal returns."""
    common = {
        "type":                1,
        "status":              5,
        "clientAssigneeName":  " ",
        "projectName":         "Acme Mock Web & API Pentest",
        "projectGuid":         PROJECT_GUID,
        "clientName":          "Acme Corp.",
        "clientGuid":          CLIENT_GUID,
        "reporter":            "Henrique Soares",
        "reviewer":            None,
        "pentesterAssignee":   None,
        "labels":              "",
    }
    return [
        {**common, "guid": "f53de42f-4c7c-44a0-8389-8173f91a8ac2",
         "code": "F-2026-15251",
         "name": "OpenSSH Sensitive Information Disclosure Vulnerability",
         "criticality": 4},
        {**common, "guid": "6d03062c-fe8b-4da4-b82b-a2d7468bb1ad",
         "code": "F-2026-15250",
         "name": "OpenSSH ssh Function Vulnerability (CVE-2025-61984)",
         "criticality": 2},
        {**common, "guid": "b0d6aaf6-08cd-44af-8f3e-a1567f90ecc8",
         "code": "F-2026-15249",
         "name": "OpenSSH SSH Protocol Vulnerability (CVE-2023-48795)",
         "criticality": 2},
        {**common, "guid": "58ebbfa9-400c-4644-9dbb-c63d18eab706",
         "code": "F-2026-15248",
         "name": "OpenSSH Expected Behavior Violation Vulnerability (CVE-2025-32728)",
         "criticality": 1},
        {**common, "guid": "6670961a-18f3-48e2-b773-ee0bfe989b2c",
         "code": "F-2026-15247",
         "name": "OpenSSH Authentication Bypass Vulnerability",
         "criticality": 3},
        {**common, "guid": "c2e6b4d1-787a-49e0-88d1-5e2b886b7cfb",
         "code": "F-2026-15246",
         "name": "OpenSSH Remote Code Execution (RCE) Vulnerability in its forwarded ssh-agent",
         "criticality": 2},
    ]


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# Wire dispatch / parameter shape
# ---------------------------------------------------------------------------

class TestSearchFindingsDispatch:

    def test_dispatches_get_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings()

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "GET"
        assert path == "/api/services/app/Finding/GetFindings"

    def test_zero_argument_call_sends_only_filter_and_pagination(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings()

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {
            "filter":         "",
            "maxResultCount": 10,
            "skipCount":      0,
        }

    def test_filter_text_serialised_to_filter(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(filter_text="OpenSSH")

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"] == "OpenSSH"

    def test_project_id_and_client_id_serialised(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(project_id=PROJECT_GUID, client_id=CLIENT_GUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["projectId"] == PROJECT_GUID
        assert params["clientId"]  == CLIENT_GUID

    def test_sorting_passed_through_when_set_otherwise_omitted(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(sorting="Code desc")
        assert p._send_api_request.call_args.kwargs["params"]["sorting"] == "Code desc"

        p._send_api_request.reset_mock()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}
        p.search_findings()
        assert "sorting" not in p._send_api_request.call_args.kwargs["params"]

    def test_pagination_kwargs_serialised(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(count_max=25, count_skip=50)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["maxResultCount"] == 25
        assert params["skipCount"]      == 50


# ---------------------------------------------------------------------------
# Indexed-array list filters
# ---------------------------------------------------------------------------

class TestSearchFindingsIndexedListFilters:
    """The portal expects ABP-style indexed-array query params, e.g.
    ``findingStatusList[0]=1&findingStatusList[1]=2``, not the bare
    repeated-key shape used by V2.2.  Verify each list filter expands
    in the indexed form."""

    def test_status_list_expands_to_indexed_params(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(status_list=[1, 2, 5, 3])

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["findingStatusList[0]"] == 1
        assert params["findingStatusList[1]"] == 2
        assert params["findingStatusList[2]"] == 5
        assert params["findingStatusList[3]"] == 3
        # No bare key — only indexed form.
        assert "findingStatusList" not in params

    def test_severity_list_expands_to_findingCriticalityList_indexed_params(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(severity_list=[1, 2, 3, 4])

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["findingCriticalityList[0]"] == 1
        assert params["findingCriticalityList[1]"] == 2
        assert params["findingCriticalityList[2]"] == 3
        assert params["findingCriticalityList[3]"] == 4

    def test_type_list_expands_to_indexed_params(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(type_list=[1])

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["findingTypeList[0]"] == 1

    def test_empty_list_does_not_emit_any_indexed_params(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.search_findings(status_list=[], severity_list=[], type_list=[])

        params = p._send_api_request.call_args.kwargs["params"]
        assert not any(k.startswith("findingStatusList[")      for k in params)
        assert not any(k.startswith("findingCriticalityList[") for k in params)
        assert not any(k.startswith("findingTypeList[")        for k in params)


# ---------------------------------------------------------------------------
# Validation — fails before dispatch
# ---------------------------------------------------------------------------

class TestSearchFindingsValidation:

    @pytest.mark.parametrize("bad", ["", "not-a-uuid", "12345", "x" * 36])
    def test_project_id_invalid_uuid_raises(self, bad):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.search_findings(project_id=bad)
        assert exc.value.field == "project_id"
        assert exc.value.reason == "invalid_uuid"
        assert p._send_api_request.call_count == 0

    @pytest.mark.parametrize("bad", ["", "not-a-uuid", "12345"])
    def test_client_id_invalid_uuid_raises(self, bad):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.search_findings(client_id=bad)
        assert exc.value.field == "client_id"
        assert exc.value.reason == "invalid_uuid"
        assert p._send_api_request.call_count == 0

    def test_status_list_must_be_a_list(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc:
            p.search_findings(status_list="not-a-list")  # type: ignore[arg-type]
        assert exc.value.field == "status_list"
        assert exc.value.reason == "invalid_type"
        assert p._send_api_request.call_count == 0

    def test_status_list_rejects_invalid_status_codes(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError):
            p.search_findings(status_list=[999])
        assert p._send_api_request.call_count == 0

    def test_severity_list_rejects_invalid_severity_codes(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError):
            p.search_findings(severity_list=[999])
        assert p._send_api_request.call_count == 0

    def test_type_list_rejects_invalid_type_codes(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError):
            p.search_findings(type_list=[999])
        assert p._send_api_request.call_count == 0


# ---------------------------------------------------------------------------
# Response hydration — 6-item captured response
# ---------------------------------------------------------------------------

class TestSearchFindingsResponseHydration:

    def test_returns_dict_with_items_and_totalcount(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "items": _captured_response_items(),
            "totalCount": 6,
        }

        result = p.search_findings(filter_text="OpenSSH", client_id=CLIENT_GUID)

        assert isinstance(result, dict)
        assert result["totalCount"] == 6
        assert len(result["items"]) == 6
        assert all(isinstance(item, CyverFinding) for item in result["items"])

    def test_first_item_carries_full_summary_shape(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "items": _captured_response_items(),
            "totalCount": 6,
        }

        first = p.search_findings()["items"][0]

        # Direct matches.
        assert first.id          == "f53de42f-4c7c-44a0-8389-8173f91a8ac2"
        assert first._code       == "F-2026-15251"
        assert first.name        == "OpenSSH Sensitive Information Disclosure Vulnerability"
        assert first._type       == 1
        assert first._status     == 5
        assert first._severity   == 4   # criticality folded into severity

        # Search-summary context fields.
        assert first.project_id              == PROJECT_GUID
        assert first.project_name            == "Acme Mock Web & API Pentest"
        assert first.client_id               == CLIENT_GUID
        assert first.client_name             == "Acme Corp."
        assert first.reporter_name           == "Henrique Soares"
        assert first.reviewer_name           is None
        assert first.pentester_assignee_name is None
        assert first.client_assignee_name    is None  # whitespace-only normalised

        # Detail fields not present in summary — stay at defaults.
        assert first._description           is None
        assert first._cvss31_vector         is None
        assert first._finding_evidence_list == []
        assert first._cwe_list              == []
        assert first._label_id_list         == []

    def test_id_is_read_from_guid_when_id_absent(self):
        """Portal search responses use ``guid`` rather than ``id`` for
        the finding's UUID; verify the alias-aware extractor picks it up."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "items": [{
                "guid": "f53de42f-4c7c-44a0-8389-8173f91a8ac2",
                "name": "x",
            }],
            "totalCount": 1,
        }

        item = p.search_findings()["items"][0]

        assert item.id == "f53de42f-4c7c-44a0-8389-8173f91a8ac2"

    def test_id_takes_precedence_over_guid_when_both_present(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "items": [{
                "id":   "00000000-0000-0000-0000-000000000001",
                "guid": "00000000-0000-0000-0000-000000000002",
                "name": "x",
            }],
            "totalCount": 1,
        }

        item = p.search_findings()["items"][0]

        assert item.id == "00000000-0000-0000-0000-000000000001"


# ---------------------------------------------------------------------------
# Iterator sibling
# ---------------------------------------------------------------------------

class TestSearchAllFindings:

    def test_paginates_across_pages(self):
        p = _authenticated_pentester_portal()
        page1 = {
            "items": _captured_response_items()[:3],
            "totalCount": 6,
        }
        page2 = {
            "items": _captured_response_items()[3:],
            "totalCount": 6,
        }
        p._send_api_request.side_effect = [page1, page2]

        results = list(p.search_all_findings(filter_text="OpenSSH"))

        assert len(results) == 6
        assert all(isinstance(r, CyverFinding) for r in results)

    def test_forwards_filters_to_each_call(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "items": _captured_response_items()[:3],
            "totalCount": 3,
        }

        list(p.search_all_findings(
            filter_text="OpenSSH",
            client_id=CLIENT_GUID,
            severity_list=[1, 2],
            sorting="Code desc",
        ))

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"]   == "OpenSSH"
        assert params["clientId"] == CLIENT_GUID
        assert params["sorting"]  == "Code desc"
        assert params["findingCriticalityList[0]"] == 1
        assert params["findingCriticalityList[1]"] == 2


# ---------------------------------------------------------------------------
# Portal instability warning
# ---------------------------------------------------------------------------

class TestSearchFindingsPortalUnstable:

    def test_emits_warning_on_first_call(self):
        # Reset the per-decorated-function warn-once gate so this test
        # is order-independent (the decorator stores ``_warned`` on the
        # wrapper itself; see ``Utils/WarningHandlers.py``).
        PentesterPortal.search_findings._warned = False  # type: ignore[attr-defined]

        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.search_findings()

        assert any(
            issubclass(w.category, CyverPortalInstabilityWarning)
            and "search_findings" in str(w.message)
            for w in captured
        )
