"""
Tests for ``PentesterPortal.get_finding_templates`` and its iterator
sibling ``get_all_finding_templates`` — wraps
``GET /api/services/app/FindingLibrary/GetFindingTemplates``.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverFinding,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _finding_library, _finding_status
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


LIBRARY_GUID = "1556a4fe-bee8-440a-9151-c746b27a5c0b"
TEMPLATE_GUID = "2fbcb70d-4a5d-4e10-a5ca-3d967ea0b11e"


def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _template_dict(name: str = "Missing Security Headers",
                   guid: str = TEMPLATE_GUID,
                   status: str = "Published") -> dict:
    """Realistic GetFindingTemplates response item shape."""
    return {
        "guid":                          guid,
        "name":                          name,
        "status":                        status,  # ignored in template mode
        "externalUrl":                   [{"title": "", "link": ""}],
        "type":                          1,
        "description":                   "...",
        "criticality":                   1,
        "impact":                        0,
        "impactDescription":             "...",
        "likelihood":                    0,
        "likelihoodDescription":         "...",
        "cvsS31Vector":                  "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:N/A:N",
        "cvsS31Score":                   3.7,
        "recommendation":                "...",
        "backgroundInformation":         "...",
        "vulnerabilityTypes":            None,
        "findingCWEs":                   ["CWE-693"],
        "findingCVEs":                   [],
        "findingMitreAttackTactics":     [],
        "findingMitreAttackTechniques":  [],
        "findingMitreAttackMitigations": [],
        "exploitIds":                    [],
        "findingLibraryGuid":            LIBRARY_GUID,
        "findingLibraryName":            "Web & API Library",
        "controlTemplatesIds":           [],
        "mergeTitleRegex1":              "", "mergeTitleRegex2": "",
        "mergeTitleRegex3":              "", "mergeTitleRegex4": "",
        "mergeTitleRegex5":              "",
        "labels":                        "",
        "complianceStatus":              None,
        "complianceComment":             "",
        "customFields":                  [],
    }


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# Wire dispatch / parameter shape
# ---------------------------------------------------------------------------

class TestGetFindingTemplatesDispatch:

    def test_dispatches_get_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "GET"
        assert path == "/api/services/app/FindingLibrary/GetFindingTemplates"

    def test_query_params_carry_finding_library_id_and_pagination(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {
            "findingLibraryId": LIBRARY_GUID,
            "filter":           "",
            "status":           "",
            "maxResultCount":   10,
            "skipCount":        0,
        }

    def test_filter_name_propagates_to_query_param(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID, filter_name="Headers")

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"] == "Headers"

    def test_filter_defaults_to_empty_string_when_none(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"] == ""

    def test_filter_status_propagates_as_raw_int_when_set(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID, filter_status=_finding_library.published)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["status"] == 2
        assert isinstance(params["status"], int)

    def test_filter_status_defaults_to_empty_string_when_none(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["status"] == ""

    def test_pagination_params_propagate(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID, count_max=25, count_skip=50)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["maxResultCount"] == 25
        assert params["skipCount"]      == 50


# ---------------------------------------------------------------------------
# Hydration — template-mode CyverFinding
# ---------------------------------------------------------------------------

class TestGetFindingTemplatesHydration:

    def test_happy_path_returns_dict_with_hydrated_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 2,
            "items": [
                _template_dict(name="Missing Security Headers"),
                _template_dict(name="SQL Injection",
                               guid="abcdef12-1234-1234-1234-abcdef123456",
                               status="Draft"),
            ],
        }

        result = p.get_finding_templates(LIBRARY_GUID)

        assert result["totalCount"] == 2
        assert len(result["items"])  == 2
        assert all(isinstance(t, CyverFinding) for t in result["items"])
        assert result["items"][0].name == "Missing Security Headers"
        assert result["items"][1].name == "SQL Injection"

    def test_hydrated_items_have_no_id_template_mode_regression(self):
        """Regression: items hydrated in template mode have id=None so
        create_finding triggers server-side ID assignment."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_template_dict()],
        }

        result = p.get_finding_templates(LIBRARY_GUID)

        assert result["items"][0].id is None

    def test_hydrated_items_have_draft_status_template_mode_regression(self):
        """Regression: items hydrated in template mode get
        status=_finding_status.draft (=1) regardless of the response's
        status field."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_template_dict(status="Published")],
        }

        result = p.get_finding_templates(LIBRARY_GUID)

        assert result["items"][0]._status == _finding_status.draft

    def test_empty_response_returns_empty_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        result = p.get_finding_templates(LIBRARY_GUID)

        assert result["items"]      == []
        assert result["totalCount"] == 0


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

class TestGetFindingTemplatesValidation:

    def test_invalid_finding_library_id_raises(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_finding_templates("not-a-uuid")
        assert exc_info.value.field  == "finding_library_id"
        assert exc_info.value.reason == "invalid_uuid"
        p._send_api_request.assert_not_called()

    def test_invalid_filter_status_raises(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_finding_templates(LIBRARY_GUID, filter_status=99)
        assert exc_info.value.field  == "filter_status"
        assert exc_info.value.reason == "invalid_value"
        p._send_api_request.assert_not_called()

    def test_filter_status_draft_accepted(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID, filter_status=_finding_library.draft)

        # Did not raise — accepted.
        assert p._send_api_request.call_args.kwargs["params"]["status"] == 1

    def test_filter_status_published_accepted(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_templates(LIBRARY_GUID, filter_status=_finding_library.published)

        assert p._send_api_request.call_args.kwargs["params"]["status"] == 2


# ---------------------------------------------------------------------------
# portal_unstable warning
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        PentesterPortal.get_finding_templates._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.get_finding_templates(LIBRARY_GUID)
            p.get_finding_templates(LIBRARY_GUID)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "get_finding_templates" in str(portal_warnings[0].message)


# ---------------------------------------------------------------------------
# Iterator
# ---------------------------------------------------------------------------

class TestGetAllFindingTemplates:

    def test_iterates_pages_and_yields_template_findings(self):
        p = _authenticated_pentester_portal()
        page_1 = {"totalCount": 30,
                  "items": [_template_dict(name=f"T{i}") for i in range(20)]}
        page_2 = {"totalCount": 30,
                  "items": [_template_dict(name=f"T{i}") for i in range(20, 30)]}
        p._send_api_request.side_effect = [page_1, page_2]

        items = list(p.get_all_finding_templates(LIBRARY_GUID))

        assert len(items) == 30
        assert all(isinstance(t, CyverFinding) for t in items)
        # All hydrated in template mode → id=None.
        assert all(t.id is None for t in items)

    def test_invalid_finding_library_id_raises_before_iteration_starts(self):
        p = _authenticated_pentester_portal()
        gen = p.get_all_finding_templates("not-a-uuid")
        with pytest.raises(CyverDataValidationError):
            next(gen)
        p._send_api_request.assert_not_called()

    def test_invalid_filter_status_raises_before_iteration_starts(self):
        p = _authenticated_pentester_portal()
        gen = p.get_all_finding_templates(LIBRARY_GUID, filter_status=99)
        with pytest.raises(CyverDataValidationError):
            next(gen)
        p._send_api_request.assert_not_called()
