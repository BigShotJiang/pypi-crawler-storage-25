"""
Tests for CyverFindingEvidence and the validators it depends on:
  _validate_ip, _validate_port, _validate_finding_compliance_status
"""

import pytest

from CyverReporting.DataTypes.CyverFindingEvidence import CyverFindingEvidence
from CyverReporting.Utils.FormatValidators import (
    _validate_ip,
    _validate_port,
    _validate_finding_compliance_status,
)
from CyverReporting.Utils.StaticAliases import _finding_compliance_status
from CyverReporting.Exceptions import CyverDataValidationError

FAKE_UUID = "12345678-1234-1234-1234-123456789abc"


# ---------------------------------------------------------------------------
# _validate_ip
# ---------------------------------------------------------------------------

class TestValidateIp:

    # --- valid IPv4 ---

    def test_ipv4_typical(self):
        _validate_ip("192.168.1.1", "ip")

    def test_ipv4_loopback(self):
        _validate_ip("127.0.0.1", "ip")

    def test_ipv4_all_zeros(self):
        _validate_ip("0.0.0.0", "ip")

    def test_ipv4_broadcast(self):
        _validate_ip("255.255.255.255", "ip")

    def test_ipv4_single_digit_octets(self):
        _validate_ip("1.2.3.4", "ip")

    # --- valid IPv6 ---

    def test_ipv6_loopback(self):
        _validate_ip("::1", "ip")

    def test_ipv6_all_zeros(self):
        _validate_ip("::", "ip")

    def test_ipv6_full(self):
        _validate_ip("2001:0db8:0000:0000:0000:0000:0000:0001", "ip")

    def test_ipv6_compressed(self):
        _validate_ip("2001:db8::1", "ip")

    def test_ipv6_fe80(self):
        _validate_ip("fe80::1", "ip")

    # --- invalid ---

    def test_empty_string(self):
        with pytest.raises(CyverDataValidationError, match="not a valid IPv4 or IPv6"):
            _validate_ip("", "ip")

    def test_ipv4_leading_zeros(self):
        with pytest.raises(CyverDataValidationError):
            _validate_ip("192.168.001.1", "ip")

    def test_ipv4_out_of_range_octet(self):
        with pytest.raises(CyverDataValidationError):
            _validate_ip("256.0.0.1", "ip")

    def test_ipv4_too_few_octets(self):
        with pytest.raises(CyverDataValidationError):
            _validate_ip("192.168.1", "ip")

    def test_ipv4_too_many_octets(self):
        with pytest.raises(CyverDataValidationError):
            _validate_ip("192.168.1.1.1", "ip")

    def test_random_string(self):
        with pytest.raises(CyverDataValidationError):
            _validate_ip("not-an-ip", "ip")

    def test_error_reason_invalid_ip(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_ip("bad", "ip")
        assert exc_info.value.reason == "invalid_ip"

    def test_field_name_in_error(self):
        with pytest.raises(CyverDataValidationError, match="sourceIp"):
            _validate_ip("bad", "sourceIp")


# ---------------------------------------------------------------------------
# _validate_port
# ---------------------------------------------------------------------------

class TestValidatePort:

    # --- valid ---

    def test_port_zero(self):
        _validate_port(0, "port")

    def test_port_80(self):
        _validate_port(80, "port")

    def test_port_443(self):
        _validate_port(443, "port")

    def test_port_max(self):
        _validate_port(65535, "port")

    def test_port_1024(self):
        _validate_port(1024, "port")

    # --- invalid type ---

    def test_bool_true_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port(True, "port")
        assert exc_info.value.reason == "invalid_type"

    def test_bool_false_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port(False, "port")
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port("80", "port")
        assert exc_info.value.reason == "invalid_type"

    def test_float_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port(80.0, "port")
        assert exc_info.value.reason == "invalid_type"

    # --- out of range ---

    def test_negative(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port(-1, "port")
        assert exc_info.value.reason == "invalid_port"

    def test_above_max(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_port(65536, "port")
        assert exc_info.value.reason == "invalid_port"

    def test_field_name_in_error(self):
        with pytest.raises(CyverDataValidationError, match="dstPort"):
            _validate_port(-1, "dstPort")


# ---------------------------------------------------------------------------
# _validate_finding_compliance_status
# ---------------------------------------------------------------------------

class TestValidateFindingComplianceStatus:

    # --- valid ---

    def test_pass_code(self):
        _validate_finding_compliance_status(_finding_compliance_status.pass_, "evidenceComplianceStatus")

    def test_fail_code(self):
        _validate_finding_compliance_status(_finding_compliance_status.fail, "evidenceComplianceStatus")

    def test_zero_directly(self):
        _validate_finding_compliance_status(0, "evidenceComplianceStatus")

    def test_one_directly(self):
        _validate_finding_compliance_status(1, "evidenceComplianceStatus")

    # --- invalid type ---

    def test_bool_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_compliance_status(True, "evidenceComplianceStatus")
        assert exc_info.value.reason == "invalid_type"

    def test_string_rejected(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_compliance_status("pass", "evidenceComplianceStatus")
        assert exc_info.value.reason == "invalid_type"

    # --- invalid value ---

    def test_negative(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_compliance_status(-1, "evidenceComplianceStatus")
        assert exc_info.value.reason == "invalid_value"

    def test_two(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            _validate_finding_compliance_status(2, "evidenceComplianceStatus")
        assert exc_info.value.reason == "invalid_value"

    def test_field_name_in_error(self):
        with pytest.raises(CyverDataValidationError, match="evidenceComplianceStatus"):
            _validate_finding_compliance_status(99, "evidenceComplianceStatus")


# ---------------------------------------------------------------------------
# CyverFindingEvidence — construction
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceConstruction:

    def test_valid_title(self):
        ev = CyverFindingEvidence("SQL Injection")
        assert ev.title == "SQL Injection"
        assert ev.id is None

    def test_empty_title_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFindingEvidence("")
        assert exc_info.value.field == "title"
        assert exc_info.value.reason == "missing_required"

    def test_non_string_title_raises(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            CyverFindingEvidence(123)
        assert exc_info.value.field == "title"
        assert exc_info.value.reason == "invalid_type"

    def test_none_title_raises(self):
        with pytest.raises(CyverDataValidationError):
            CyverFindingEvidence(None)


# ---------------------------------------------------------------------------
# CyverFindingEvidence — setters
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceSetters:

    def setup_method(self):
        self.ev = CyverFindingEvidence("Test Evidence")

    def test_set_title(self):
        self.ev.set_title("New Title")
        assert self.ev.title == "New Title"

    def test_set_title_empty_raises(self):
        with pytest.raises(CyverDataValidationError, match="title"):
            self.ev.set_title("")

    def test_set_location(self):
        self.ev.set_location("https://example.com/login")
        assert self.ev._location == "https://example.com/login"

    def test_set_location_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="location"):
            self.ev.set_location(123)

    def test_set_version(self):
        self.ev.set_version("1.0.0")
        assert self.ev._version == "1.0.0"

    def test_set_version_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="version"):
            self.ev.set_version(1)

    def test_set_reproduce(self):
        self.ev.set_reproduce("Step 1: ...")
        assert self.ev._reproduce == "Step 1: ..."

    def test_set_reproduce_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="reproduce"):
            self.ev.set_reproduce(None)

    def test_set_results(self):
        self.ev.set_results("Auth bypassed.")
        assert self.ev._results == "Auth bypassed."

    def test_set_results_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="results"):
            self.ev.set_results(42)

    def test_set_issue_details(self):
        self.ev.set_issue_details("Details here.")
        assert self.ev._issue_details == "Details here."

    def test_set_issue_details_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="issueDetails"):
            self.ev.set_issue_details(True)

    def test_set_protocol(self):
        self.ev.set_protocol("HTTPS")
        assert self.ev._protocol == "HTTPS"

    def test_set_protocol_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="protocol"):
            self.ev.set_protocol(443)

    def test_set_is_visible_in_report_true(self):
        self.ev.set_is_visible_in_report(True)
        assert self.ev._is_visible_in_report is True

    def test_set_is_visible_in_report_false(self):
        self.ev.set_is_visible_in_report(False)
        assert self.ev._is_visible_in_report is False

    def test_set_is_visible_in_report_wrong_type(self):
        with pytest.raises(CyverDataValidationError, match="isVisibleInReport"):
            self.ev.set_is_visible_in_report(1)

    def test_set_ip_valid_ipv4(self):
        self.ev.set_ip("10.0.0.1")
        assert self.ev._ip == "10.0.0.1"

    def test_set_ip_valid_ipv6(self):
        self.ev.set_ip("::1")
        assert self.ev._ip == "::1"

    def test_set_ip_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_ip("999.999.999.999")
        assert exc_info.value.reason == "invalid_ip"

    def test_set_ip_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_ip(12345)
        assert exc_info.value.reason == "invalid_type"

    def test_set_port_valid(self):
        self.ev.set_port(443)
        assert self.ev._port == 443

    def test_set_port_zero(self):
        self.ev.set_port(0)
        assert self.ev._port == 0

    def test_set_port_invalid_range(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_port(70000)
        assert exc_info.value.reason == "invalid_port"

    def test_set_port_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_port("443")
        assert exc_info.value.reason == "invalid_type"

    def test_set_evidence_compliance_status_pass(self):
        self.ev.set_evidence_compliance_status(_finding_compliance_status.pass_)
        assert self.ev._evidence_compliance_status == 0

    def test_set_evidence_compliance_status_fail(self):
        self.ev.set_evidence_compliance_status(_finding_compliance_status.fail)
        assert self.ev._evidence_compliance_status == 1

    def test_set_evidence_compliance_status_invalid(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_evidence_compliance_status(99)
        assert exc_info.value.reason == "invalid_value"

    def test_set_evidence_compliance_status_wrong_type(self):
        with pytest.raises(CyverDataValidationError) as exc_info:
            self.ev.set_evidence_compliance_status("pass")
        assert exc_info.value.reason == "invalid_type"


# ---------------------------------------------------------------------------
# CyverFindingEvidence — fluent chaining
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceFluent:

    def test_full_chain_returns_same_instance(self):
        ev = CyverFindingEvidence("Chain Test")
        result = (
            ev
            .set_location("https://example.com")
            .set_version("2.0")
            .set_reproduce("Reproduce steps")
            .set_results("Found XSS")
            .set_issue_details("Extra details")
            .set_is_visible_in_report(True)
            .set_ip("192.168.0.1")
            .set_port(8080)
            .set_protocol("HTTP")
            .set_evidence_compliance_status(_finding_compliance_status.fail)
        )
        assert result is ev


# ---------------------------------------------------------------------------
# CyverFindingEvidence — to_dict
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceToDict:

    def test_title_only(self):
        ev = CyverFindingEvidence("Minimal")
        d = ev.to_dict()
        assert d == {"title": "Minimal"}

    def test_all_fields(self):
        ev = (
            CyverFindingEvidence("Full Evidence")
            .set_location("https://example.com/login")
            .set_version("1.2.3")
            .set_reproduce("Step 1")
            .set_results("Bypassed")
            .set_issue_details("Details")
            .set_is_visible_in_report(True)
            .set_ip("10.10.10.10")
            .set_port(443)
            .set_protocol("HTTPS")
            .set_evidence_compliance_status(1)
        )
        d = ev.to_dict()
        assert d["title"] == "Full Evidence"
        assert d["location"] == "https://example.com/login"
        assert d["version"] == "1.2.3"
        assert d["reproduce"] == "Step 1"
        assert d["results"] == "Bypassed"
        assert d["issueDetails"] == "Details"
        assert d["isVisibleInReport"] is True
        assert d["ip"] == "10.10.10.10"
        assert d["port"] == 443
        assert d["protocol"] == "HTTPS"
        assert d["evidenceComplianceStatus"] == 1

    def test_unset_fields_absent(self):
        ev = CyverFindingEvidence("Partial").set_ip("1.2.3.4")
        d = ev.to_dict()
        assert "location" not in d
        assert "port" not in d
        assert "evidenceComplianceStatus" not in d
        assert d["ip"] == "1.2.3.4"

    def test_is_visible_false_included(self):
        ev = CyverFindingEvidence("Visible False").set_is_visible_in_report(False)
        d = ev.to_dict()
        assert "isVisibleInReport" in d
        assert d["isVisibleInReport"] is False

    def test_port_zero_included(self):
        ev = CyverFindingEvidence("Port Zero").set_port(0)
        d = ev.to_dict()
        assert "port" in d
        assert d["port"] == 0


# ---------------------------------------------------------------------------
# CyverFindingEvidence — from_dict
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceFromDict:

    def test_full_from_dict(self):
        data = {
            "id": FAKE_UUID,
            "title": "Remote Code Execution",
            "location": "/api/execute",
            "version": "3.1",
            "reproduce": "Send payload",
            "results": "Shell obtained",
            "issueDetails": "CVE-2024-12345",
            "isVisibleInReport": True,
            "ip": "192.168.1.100",
            "port": 22,
            "protocol": "SSH",
            "evidenceComplianceStatus": 1,
        }
        ev = CyverFindingEvidence.from_dict(data)
        assert ev.id == FAKE_UUID
        assert ev.title == "Remote Code Execution"
        assert ev._location == "/api/execute"
        assert ev._version == "3.1"
        assert ev._reproduce == "Send payload"
        assert ev._results == "Shell obtained"
        assert ev._issue_details == "CVE-2024-12345"
        assert ev._is_visible_in_report is True
        assert ev._ip == "192.168.1.100"
        assert ev._port == 22
        assert ev._protocol == "SSH"
        assert ev._evidence_compliance_status == 1

    def test_minimal_from_dict(self):
        ev = CyverFindingEvidence.from_dict({"title": "Minimal"})
        assert ev.title == "Minimal"
        assert ev.id is None
        assert ev._ip is None
        assert ev._port is None

    def test_roundtrip(self):
        original = (
            CyverFindingEvidence("Roundtrip Test")
            .set_location("/foo/bar")
            .set_port(8443)
            .set_ip("::1")
            .set_evidence_compliance_status(0)
        )
        ev2 = CyverFindingEvidence.from_dict(original.to_dict())
        assert ev2.title == original.title
        assert ev2._location == original._location
        assert ev2._port == original._port
        assert ev2._ip == original._ip
        assert ev2._evidence_compliance_status == original._evidence_compliance_status


# ---------------------------------------------------------------------------
# CyverFindingEvidence — validate_for_post / validate_for_put
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceValidation:

    def test_validate_for_post_with_title(self):
        ev = CyverFindingEvidence("Valid")
        ev.validate_for_post()  # should not raise

    def test_validate_for_put_with_title(self):
        ev = CyverFindingEvidence("Valid")
        ev.validate_for_put()  # should not raise


# ---------------------------------------------------------------------------
# CyverFindingEvidence — __repr__
# ---------------------------------------------------------------------------

class TestCyverFindingEvidenceRepr:

    def test_repr_minimal(self):
        ev = CyverFindingEvidence("My Evidence")
        r = repr(ev)
        assert "CyverFindingEvidence" in r
        assert "My Evidence" in r

    def test_repr_with_id(self):
        ev = CyverFindingEvidence.from_dict({"id": FAKE_UUID, "title": "With ID"})
        r = repr(ev)
        assert FAKE_UUID in r

    def test_repr_without_id_no_id_prefix(self):
        ev = CyverFindingEvidence("No ID")
        assert "id=" not in repr(ev)
