"""
Tests for ``PentesterPortal.create_finding_library`` — wraps the unified
``POST /api/services/app/FindingLibrary/CreateOrUpdateFindingLibrary``
endpoint via the create-half code path.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverFindingLibrary,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _finding_library
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


LIB_GUID      = "1064bea3-a3d2-4af0-bf9c-5847f11f3870"
TEMPLATE_GUID = "abcdef12-abcd-abcd-abcd-abcdef123456"


def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _hydrated_library(guid: str = LIB_GUID) -> CyverFindingLibrary:
    """Build a CyverFindingLibrary via from_dict so `_guid` is populated."""
    return CyverFindingLibrary.from_dict({
        "guid":                          guid,
        "name":                          "Web App Toolkit",
        "description":                   "Reusable findings",
        "status":                        "Draft",
        "findingLibraryTemplateStatus":  "Draft",
        "findingFieldsTemplateGuid":     None,
        "findingFieldsTemplateName":     None,
    })


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# Wire dispatch
# ---------------------------------------------------------------------------

class TestCreateFindingLibraryDispatch:

    def test_dispatches_post_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)

        p.create_finding_library(lib)

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "POST"
        assert path == "/api/services/app/FindingLibrary/CreateOrUpdateFindingLibrary"

    def test_no_query_params_sent(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)

        p.create_finding_library(lib)

        kwargs = p._send_api_request.call_args.kwargs
        assert kwargs.get("params") is None

    def test_returns_none_when_server_result_is_null(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)

        result = p.create_finding_library(lib)

        assert result is None


# ---------------------------------------------------------------------------
# Body construction — minimal create vs guid-bearing update routing
# ---------------------------------------------------------------------------

class TestCreateFindingLibraryBody:

    def test_minimal_body_pascal_case_with_int_status(self):
        """A freshly-constructed library produces a minimal body:
        Name + Status (raw int)."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)

        p.create_finding_library(lib)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data == {"Name": "Toolkit", "Status": _finding_library.draft}

    def test_full_body_includes_all_set_optional_fields(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = (
            CyverFindingLibrary("Toolkit", _finding_library.draft)
            .set_description("desc")
            .set_finding_library_template_status(_finding_library.published)
            .set_finding_fields_template_guid(TEMPLATE_GUID)
        )

        p.create_finding_library(lib)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["Name"]                         == "Toolkit"
        assert data["Status"]                       == _finding_library.draft
        assert data["Description"]                  == "desc"
        assert data["FindingLibraryTemplateStatus"] == _finding_library.published
        assert data["FindingFieldsTemplateGuid"]    == TEMPLATE_GUID
        assert "Guid" not in data  # fresh construction; no guid

    def test_hydrated_library_routes_to_update_path(self):
        """A library hydrated from from_dict carries `_guid`, so the
        body includes `Guid` — the server then routes to the update
        path of the unified CreateOrUpdate endpoint.  Documented
        behaviour per the wrapper's docstring."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.create_finding_library(_hydrated_library())

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["Guid"] == LIB_GUID
        assert data["Name"] == "Web App Toolkit"

    def test_finding_fields_template_name_never_in_body(self):
        """Server-derived field is never sent on writes, even when
        populated by from_dict."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None

        p.create_finding_library(_hydrated_library())

        data = p._send_api_request.call_args.kwargs["data"]
        assert "FindingFieldsTemplateName" not in data
        assert "findingFieldsTemplateName" not in data

    def test_status_emitted_as_raw_int_not_string(self):
        """Regression for Q1: send raw ints even though the captured
        frontend sends string-encoded ints."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.published)

        p.create_finding_library(lib)

        data = p._send_api_request.call_args.kwargs["data"]
        assert data["Status"] == 2
        assert isinstance(data["Status"], int)
        assert not isinstance(data["Status"], bool)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

class TestCreateFindingLibraryValidation:

    def test_non_cyverfindinglibrary_argument_rejected(self):
        p = _authenticated_pentester_portal()
        with pytest.raises(CyverDataValidationError) as exc_info:
            p.create_finding_library({"Name": "Toolkit", "Status": 1})
        assert exc_info.value.field  == "library"
        assert exc_info.value.reason == "invalid_type"
        p._send_api_request.assert_not_called()


# ---------------------------------------------------------------------------
# portal_unstable warning
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = None
        lib = CyverFindingLibrary("Toolkit", _finding_library.draft)

        PentesterPortal.create_finding_library._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.create_finding_library(lib)
            p.create_finding_library(lib)  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "create_finding_library" in str(portal_warnings[0].message)
