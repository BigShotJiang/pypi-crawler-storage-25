"""
Tests for ``PentesterPortal.get_finding_libraries`` and its iterator
sibling ``get_all_finding_libraries`` — wraps
``GET /api/services/app/FindingLibrary/GetFindingLibraries``.
"""

import warnings
import pytest
from unittest.mock import MagicMock

from CyverReporting import (
    CyverFindingLibrary,
    CyverPortalInstabilityWarning,
    PentesterPortal,
)
from CyverReporting.Exceptions import CyverDataValidationError
from CyverReporting.Utils import _finding_library
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
)


LIB_GUID_1 = "1064bea3-a3d2-4af0-bf9c-5847f11f3870"
LIB_GUID_2 = "abcdef12-abcd-abcd-abcd-abcdef123456"


def _authenticated_pentester_portal() -> PentesterPortal:
    p = PentesterPortal()
    p.portal        = PORTAL
    p.access_token  = FAKE_ACCESS_TOKEN
    p.refresh_token = FAKE_REFRESH_TOKEN
    p.user_id       = FAKE_UUID
    p._send_api_request = MagicMock()
    return p


def _library_dict(guid: str = LIB_GUID_1, name: str = "AATest",
                  status: str = "Draft") -> dict:
    """Realistic GetFindingLibraries response item shape (camelCase
    keys, enum-name strings for status fields)."""
    return {
        "guid":                          guid,
        "name":                          name,
        "description":                   name,
        "status":                        status,
        "findingLibraryTemplateStatus":  status,
        "findingFieldsTemplateGuid":     None,
        "findingFieldsTemplateName":     None,
    }


@pytest.fixture(autouse=True)
def _silence_portal_warnings():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
        yield


# ---------------------------------------------------------------------------
# Wire dispatch / parameter shape
# ---------------------------------------------------------------------------

class TestGetFindingLibrariesDispatch:

    def test_dispatches_get_to_correct_portal_path(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_libraries()

        method, path = p._send_api_request.call_args[0][0], p._send_api_request.call_args[0][1]
        assert method == "GET"
        assert path == "/api/services/app/FindingLibrary/GetFindingLibraries"

    def test_query_params_carry_filter_and_pagination(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_libraries(count_max=10, count_skip=0, filter_name="AATest")

        params = p._send_api_request.call_args.kwargs["params"]
        assert params == {
            "filter":         "AATest",
            "maxResultCount": 10,
            "skipCount":      0,
        }

    def test_filter_defaults_to_empty_string_when_none(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_libraries()

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["filter"] == ""

    def test_pagination_params_propagate(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_libraries(count_max=25, count_skip=50)

        params = p._send_api_request.call_args.kwargs["params"]
        assert params["maxResultCount"] == 25
        assert params["skipCount"]      == 50

    def test_no_project_id_in_query(self):
        """Regression: finding libraries are tenant-scoped, not
        project-scoped, so the wire request must not carry a
        ``projectId`` parameter."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        p.get_finding_libraries()

        params = p._send_api_request.call_args.kwargs["params"]
        assert "projectId" not in params


# ---------------------------------------------------------------------------
# Hydration — name-string status parsed to int codes
# ---------------------------------------------------------------------------

class TestGetFindingLibrariesHydration:

    def test_happy_path_returns_dict_with_hydrated_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 2,
            "items": [
                _library_dict(guid=LIB_GUID_1, name="Web App",   status="Draft"),
                _library_dict(guid=LIB_GUID_2, name="Mobile App", status="Published"),
            ],
        }

        result = p.get_finding_libraries()

        assert result["totalCount"] == 2
        assert len(result["items"])  == 2
        assert all(isinstance(lib, CyverFindingLibrary) for lib in result["items"])
        # Name-string status is parsed to int code internally.
        assert result["items"][0].status == _finding_library.draft
        assert result["items"][1].status == _finding_library.published

    def test_empty_response_returns_empty_items(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        result = p.get_finding_libraries()

        assert result["items"]      == []
        assert result["totalCount"] == 0

    def test_unknown_status_name_in_response_raises(self):
        """Schema drift: a status name not in
        ``_finding_library._codes`` must surface as
        CyverDataValidationError, not silently drop the item."""
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {
            "totalCount": 1,
            "items": [_library_dict(status="Archived")],
        }

        with pytest.raises(CyverDataValidationError) as exc_info:
            p.get_finding_libraries()
        assert exc_info.value.field  == "status"
        assert exc_info.value.reason == "invalid_value"


# ---------------------------------------------------------------------------
# portal_unstable warning
# ---------------------------------------------------------------------------

class TestPortalUnstableWarning:

    def test_warning_emitted_on_first_invocation(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}

        PentesterPortal.get_finding_libraries._warned = False

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always", CyverPortalInstabilityWarning)
            p.get_finding_libraries()
            p.get_finding_libraries()  # silent on second call

        portal_warnings = [
            w for w in captured
            if issubclass(w.category, CyverPortalInstabilityWarning)
        ]
        assert len(portal_warnings) == 1
        assert "get_finding_libraries" in str(portal_warnings[0].message)


# ---------------------------------------------------------------------------
# Iterator
# ---------------------------------------------------------------------------

class TestGetAllFindingLibraries:

    def test_iterates_pages_and_yields_hydrated_libraries(self):
        p = _authenticated_pentester_portal()
        page_1 = {"totalCount": 75,
                  "items": [_library_dict(name=f"Lib {i}") for i in range(50)]}
        page_2 = {"totalCount": 75,
                  "items": [_library_dict(name=f"Lib {i}") for i in range(50, 75)]}
        p._send_api_request.side_effect = [page_1, page_2]

        items = list(p.get_all_finding_libraries())

        assert len(items) == 75
        assert all(isinstance(lib, CyverFindingLibrary) for lib in items)
        assert items[0].name  == "Lib 0"
        assert items[74].name == "Lib 74"

    def test_propagates_filter_to_inner_calls(self):
        p = _authenticated_pentester_portal()
        p._send_api_request.return_value = {"totalCount": 0, "items": []}

        list(p.get_all_finding_libraries(filter_name="web"))

        for call in p._send_api_request.call_args_list:
            assert call.kwargs["params"]["filter"] == "web"
