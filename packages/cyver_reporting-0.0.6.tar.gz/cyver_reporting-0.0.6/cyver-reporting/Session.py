#!/usr/bin/env python3

from .Exceptions import (
    Cyver2FARequired, CyverAuthError, CyverAuthMethodError, CyverCachingError,
    CyverDataValidationError, CyverHTTPError, CyverNotFoundError,
    CyverPermissionError, CyverRateLimitError,
)
from .Utils import JWT_EXPIRY_SKEW_SECONDS, _validate_jwt_token, _validate_uuid

from collections.abc import Callable, Iterator
from base64 import b64decode, b64encode
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from hashlib import md5
from json import dumps, loads, JSONDecodeError
import logging
import os
from os import urandom
from pathlib import Path
from platformdirs import user_cache_dir
from requests import Request, RequestException, Session
from requests.adapters import HTTPAdapter
import threading
from urllib3.util.retry import Retry


CACHE_ITERATIONS = 600000
CACHE_RANDOM_BYTES = 16
REQUESTS_TIMEOUT = 30
REQUESTS_USER_AGENT = "curl/8.7.1"

# Sentinel marking "caller did not supply cache_dir" — distinct from
# explicit ``None`` (which means "disable cache entirely").
_CACHE_DIR_UNSET = object()
_CACHE_DIR_ENV_VAR = "CYVER_REPORTING_CACHE_DIR"


logger = logging.getLogger(__name__)


def _resolve_cache_dir(cache_dir, env=None):
    """Resolve the effective cache directory.

    Resolution precedence:

    1. **Explicit kwarg** — any value (including ``None``) supplied by
       the caller wins.  ``None`` disables caching; any path-like value
       is used directly.
    2. **Environment variable** ``CYVER_REPORTING_CACHE_DIR`` — consulted
       only when the kwarg is left at ``_CACHE_DIR_UNSET``.  Unset →
       fall through; empty string → disabled; any non-empty value → use
       as path.
    3. **Default** — ``platformdirs.user_cache_dir("cyver", appauthor=False)``.

    Args:
        cache_dir: ``_CACHE_DIR_UNSET``, ``None``, ``str``, or ``Path``.
        env: Optional environment mapping (defaults to ``os.environ``).
            Exposed for testability.

    Returns:
        ``Path`` to the effective cache directory, or ``None`` to mean
        caching is disabled.

    Raises:
        CyverDataValidationError: If ``cache_dir`` is supplied but is
            not ``None`` and not a path-like.
    """
    if cache_dir is _CACHE_DIR_UNSET:
        env_value = (env if env is not None else os.environ).get(_CACHE_DIR_ENV_VAR)
        if env_value is None:
            return Path(user_cache_dir("cyver", appauthor=False))
        if env_value == "":
            return None
        return Path(env_value)
    if cache_dir is None:
        return None
    if isinstance(cache_dir, (str, Path)):
        return Path(cache_dir)
    raise CyverDataValidationError(
        f"'cache_dir' must be a path-like, None, or omitted; got {type(cache_dir).__name__}.",
        field="cache_dir", reason="invalid_type",
    )


class CyverSession:
    """
        Base class for managing authenticated sessions with the Cyver
        Pentest Management API. Handles token caching, automatic token
        refresh, 2FA, and the underlying HTTP transport.

        Supports two mutually exclusive authentication modes:

        **Username / password (default)**
            Call ``authenticate(portal, username, password)`` after
            construction. Tokens are cached and refreshed automatically::

                with PentesterSession() as client:
                    client.authenticate(portal, username, password)
                    projects = list(client.get_all_projects())

        **Static API key**
            Pass ``portal`` and ``api_key`` to the constructor. The session
            is immediately ready; ``authenticate()`` must not be called::

                with PentesterSession(portal="app.cyver.io", api_key="sk-...") as client:
                    projects = list(client.get_all_projects())
    """

    def __init__(self, portal: str | None = None, api_key: str | None = None, cache_dir=_CACHE_DIR_UNSET) -> None:
        """
            Initialises token state, a thread-safety lock, and a shared
            HTTP session pre-configured with a User-Agent header and an
            automatic retry policy for transient server errors.

            When ``api_key`` is supplied the session is immediately ready for
            use and ``authenticate()`` must not be called. ``portal`` is
            required in that case.

            Args:
                portal:  Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).
                         Required when ``api_key`` is supplied; optional otherwise
                         (``authenticate()`` will set it).
                api_key: Static API key for keyless authentication. When provided,
                         requests are sent with ``X-API-Key`` instead of a Bearer
                         token. Optional — omit to use the standard login flow.
                cache_dir: Where to store the on-disk credential cache.

                         - **Omitted (default)** — fall through to the
                           ``CYVER_REPORTING_CACHE_DIR`` environment variable;
                           if that is unset, use the OS-native user cache
                           directory via ``platformdirs``.
                         - ``None`` — disable caching entirely.  The
                           portal-probe runs on every authentication, no
                           token state is written to disk, and warm-start
                           optimisations are skipped.
                         - ``str`` / ``Path`` — store the cache under this
                           directory instead of the platformdirs default.

                         The ``CYVER_REPORTING_CACHE_DIR`` env var follows the
                         same conventions: unset → default; empty string →
                         disabled; non-empty → custom path.  The kwarg always
                         takes precedence when supplied.

            Raises:
                CyverDataValidationError: If ``api_key`` is provided without ``portal``, or if
                    either argument is not a non-empty string when supplied; or
                    if ``cache_dir`` is not a path-like, ``None``, or omitted.
                CyverAuthError: If ``api_key`` is supplied and the portal probe
                    reveals the portal is inactive (``reason="portal_inactive"``)
                    or unreachable (``reason="portal_unreachable"``). The probe
                    is skipped when a cache file confirms the same portal was
                    reachable in a previous run; the cache file is deleted if
                    the probe fails or if the cached portal does not match.
                    When caching is disabled, the probe always runs.
        """

        if api_key is not None:
            if not portal or not isinstance(portal, str):
                raise CyverDataValidationError(
                    "portal must be provided as a non-empty string when api_key is supplied.",
                    field="portal",
                    reason="invalid_type",
                )
            if not isinstance(api_key, str) or not api_key.strip():
                raise CyverDataValidationError("api_key must be a non-empty string.", field="api_key", reason="invalid_type")
        elif portal is not None and not isinstance(portal, str):
            raise CyverDataValidationError("portal must be a non-empty string.", field="portal", reason="invalid_type")

        self._api_key      = api_key
        self.portal        = portal
        self.access_token  = None
        self.refresh_token = None
        self.user_id       = None
        self._lock = threading.RLock()
        # Resolve cache configuration.  ``self._cache_dir is None`` is the
        # canonical "disabled" state — every cache I/O method short-circuits
        # on it.  Resolution may raise ``CyverDataValidationError`` for
        # invalid kwarg types; that surfaces back to the caller unchanged.
        self._cache_dir: Path | None = _resolve_cache_dir(cache_dir)
        self._cache_enabled: bool    = self._cache_dir is not None
        if not self._cache_enabled:
            logger.info("Credential cache disabled (cache_dir resolved to None); portal-probe will run on every authentication.")

        # Retry up to 3 times on idempotent requests (GET, PUT) for transient
        # server errors and rate-limiting responses. POST is intentionally
        # excluded to avoid duplicate side-effects (e.g. duplicate auth calls).
        _retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=frozenset(["GET", "PUT"]),
            raise_on_status=False,
        )
        self._session = Session()
        self._session.headers.update({"User-Agent": REQUESTS_USER_AGENT})
        self._session.mount("https://", HTTPAdapter(max_retries=_retry))

        # In API-key mode the portal is known at construction time.  Check the
        # cache first: if a previous successful call already confirmed this
        # portal, skip the probe.  Otherwise validate and update the cache.
        # Cache I/O failures are logged and the constructor degrades to a
        # fresh portal-probe; only a probe failure aborts construction.
        if self._api_key is not None:
            try:
                cache = self._fetch_apikey_cache()
            except CyverCachingError as exc:
                logger.warning(
                    "Ignoring damaged API-key cache (kind=%s, reason=%s, underlying=%s); "
                    "falling back to portal probe.",
                    exc.cache_kind, exc.reason, type(exc.__cause__).__name__,
                )
                cache = {"portal": None}
            if cache.get("portal") == portal:
                # Portal confirmed by a previous successful call — skip probe.
                pass
            else:
                # First time, or the cached portal differs from the one supplied.
                # Delete any stale cache entry before re-validating.
                if cache.get("portal") is not None:
                    try:
                        self._delete_apikey_cache()
                    except CyverCachingError as exc:
                        logger.warning(
                            "Could not delete stale API-key cache (reason=%s); "
                            "proceeding with portal probe anyway.", exc.reason,
                        )
                try:
                    self._probe_portal(portal)
                    try:
                        self._save_apikey_cache()
                    except CyverCachingError as exc:
                        logger.warning(
                            "Portal probe succeeded but API-key cache write "
                            "failed (reason=%s); session is usable but the "
                            "next instantiation will probe again.", exc.reason,
                        )
                except CyverAuthError:
                    try:
                        self._delete_apikey_cache()
                    except CyverCachingError:
                        pass  # already failing — don't mask the auth error
                    raise

    def __repr__(self) -> str:
        """
            Returns a developer-friendly string showing the class name,
            portal hostname, and whether the session is authenticated.
            Works correctly for CyverSession subclasses via type(self).
        """
        authenticated = self.access_token is not None or self._api_key is not None
        return f"{type(self).__name__}(portal={self.portal!r}, authenticated={authenticated})"

    def __enter__(self) -> "CyverSession":
        """
            Supports use as a context manager. Returns self so the caller
            can bind the session to a variable via ``as``::

                with PentesterSession() as client:
                    client.authenticate(...)
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
            Closes the underlying HTTP session when leaving a ``with``
            block, regardless of whether an exception was raised.
        """
        self._session.close()

    def __del__(self) -> None:
        """
            Closes the underlying HTTP session when the object is garbage
            collected, as a fallback for callers that do not use the
            context manager interface.
        """
        if hasattr(self, "_session"):
            self._session.close()

    def authenticate(self, portal: str, username: str, password: str, verification_code: str | None = None) -> bool:
        """
            Authenticates against the Cyver API using username and password.

            On first call (or when the cache is empty) a full login request is
            made. On subsequent calls the cached refresh token is used to obtain
            a new access token without re-entering credentials. Tokens are
            stored encrypted in the OS user-cache directory.

            .. note::
                This method is not available when the session was constructed
                with a static ``api_key``. Calling it in that case raises
                ``CyverAuthError`` immediately.

            Args:
                portal: Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).
                username: Cyver account username or e-mail address.
                password: Cyver account password.
                verification_code: Email-based 2FA code. Pass this on a second
                    call after receiving a Cyver2FARequired on the first.

            Returns:
                True on successful authentication.

            Raises:
                CyverAuthError: If the session was constructed with an API key;
                    if the portal is inactive (``reason="portal_inactive"``); if
                    the portal is unreachable (``reason="portal_unreachable"``);
                    or if authentication fails for any other reason.
                CyverDataValidationError: If portal, username, or password are empty or not strings.
                Cyver2FARequired: If the account requires 2FA and no verification_code
                    was provided. A code is sent to the account e-mail automatically.
                CyverHTTPError: If the underlying HTTP request fails.
        """

        if self._api_key is not None:
            raise CyverAuthError(
                "This session uses a static API key and does not support "
                "username/password authentication. Remove the api_key argument "
                "from the constructor to use the standard login flow.",
                reason="not_authenticated",
            )

        if not portal or not isinstance(portal, str):
            raise CyverDataValidationError("portal must be a non-empty string.", field="portal", reason="invalid_type")
        if not username or not isinstance(username, str):
            raise CyverDataValidationError("username must be a non-empty string.", field="username", reason="invalid_type")
        if not password or not isinstance(password, str):
            raise CyverDataValidationError("password must be a non-empty string.", field="password", reason="invalid_type")

        # Set the portal before fetching the cache so the cache key is correct.
        self.portal = portal
        try:
            auth = self._fetch_oauth_cache(username, password)
        except CyverCachingError as exc:
            logger.warning(
                "Ignoring damaged OAuth cache (kind=%s, reason=%s, underlying=%s); "
                "falling back to fresh authentication.",
                exc.cache_kind, exc.reason, type(exc.__cause__).__name__,
            )
            auth = { "accessToken": None, "refreshToken": None, "userId": None, "portal": None }
            # Best-effort: purge the bad file so a future run doesn't keep tripping over it.
            try:
                self._delete_oauth_cache(username, password)
            except CyverCachingError as delete_exc:
                logger.warning(
                    "Could not purge damaged OAuth cache (reason=%s); proceeding regardless.",
                    delete_exc.reason,
                )

        # "First time" means no usable token exists in the cache, so the full
        # /Authenticate endpoint must be called.  Track this before the probe
        # so the flag is available in the exception handler below.
        is_first_time = not (auth.get("accessToken") or auth.get("refreshToken"))

        # Skip the portal probe only when the cache confirms this portal was
        # previously reachable (portal matches) AND at least one token is still
        # valid — meaning the session was genuinely active recently.  If both
        # tokens are expired the cache offers no evidence of reachability, so
        # probe before sending credentials.
        cached_portal_matches = auth.get("portal") == portal
        has_valid_token = not is_first_time
        if not (cached_portal_matches and has_valid_token):
            self._probe_portal(portal)

        try:
            # If there were valid jwt tokens and user ids in cache ...
            if auth["accessToken"] and auth["refreshToken"] and auth["userId"]:
                # There is no need to do anything else, so move on
                pass

            # If the access token is not valid, but all others are ...
            elif not auth["accessToken"] and auth["refreshToken"] and auth["userId"]:
                # Send a refresh token request for a fresh access jwt token
                creds = { "refreshToken": auth["refreshToken"] }
                creds = self._send_api_request("POST", "/api/TokenAuth/RefreshToken", creds, None)
                if not isinstance(creds, dict) or "accessToken" not in creds:
                    raise CyverAuthError(
                        "Token refresh failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                auth["accessToken"] = creds["accessToken"]

            # If there were no usable tokens in the cache ...
            else:
                # Authenticate against the Cyver API endpoint
                creds = { "userNameOrEmailAddress": username, "password": password }
                if verification_code:
                    creds["twoFactorVerificationCode"] = verification_code
                auth = self._send_api_request("POST", "/api/TokenAuth/Authenticate", None, creds)

            # If the Require Two Factor Verification flag is set ...
            if "requiresTwoFactorVerification" in auth and auth["requiresTwoFactorVerification"]:
                # It means the authentication failed, but Cyver API only supports
                # Email 2FA verification code, so ...
                if "twoFactorAuthProviders" in auth and "Email" in auth["twoFactorAuthProviders"]:
                    # Request a 2FA verification code and raise a 2FA exception
                    token = {"provider": "Email", "userId": auth["userId"] }
                    self._send_api_request("POST", "/api/TokenAuth/SendTwoFactorAuthCode", None, token)
                    raise Cyver2FARequired(
                        "Username/Password requires 2FA validation (2FA Verification Code sent via Email).",
                        user_id=auth.get("userId"),
                        providers=auth.get("twoFactorAuthProviders", []),
                    )
                else:
                    # There is no path forward, so raise an authentication exception
                    raise CyverAuthError(
                        "Username/Password authentication failed (2FA enforced but Email 2FA not enabled).",
                        reason="2fa_not_configured",
                    )

            # Atomically validate and commit the new token state under the lock so
            # concurrent API calls never observe a partially-updated state.
            with self._lock:
                if "accessToken" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                try:
                    _validate_jwt_token(auth["accessToken"], "accessToken")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Access JWT Token was returned).",
                        reason="access_token_missing",
                    )
                self.access_token = auth["accessToken"]

                if "refreshToken" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Refresh JWT Token was returned).",
                        reason="refresh_token_missing",
                    )
                try:
                    _validate_jwt_token(auth["refreshToken"], "refreshToken")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid Refresh JWT Token was returned).",
                        reason="refresh_token_missing",
                    )
                self.refresh_token = auth["refreshToken"]

                if "userId" not in auth:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid User ID UUID was returned).",
                        reason="user_id_missing",
                    )
                try:
                    _validate_uuid(auth["userId"], "userId")
                except CyverDataValidationError:
                    raise CyverAuthError(
                        "Username/Password authentication failed (No valid User ID UUID was returned).",
                        reason="user_id_missing",
                    )
                self.user_id = auth["userId"]

        except Exception:
            # If this was a first-time login (no usable cached tokens) and the
            # backend call failed, delete any stale cache file so the next
            # attempt starts from a clean state.
            if is_first_time:
                try:
                    self._delete_oauth_cache(username, password)
                except CyverCachingError as delete_exc:
                    logger.warning(
                        "Could not delete OAuth cache after failed first-time "
                        "authentication (reason=%s); the original error is being re-raised.",
                        delete_exc.reason,
                    )
            raise

        # Persist tokens to the cache; failure to save is non-fatal.
        try:
            self._save_oauth_cache(username, password)
        except CyverCachingError as exc:
            logger.warning(
                "Authentication succeeded but OAuth cache write failed "
                "(reason=%s, underlying=%s); session is usable but the next "
                "run will need to re-authenticate.",
                exc.reason, type(exc.__cause__).__name__,
            )

        return True

    def _probe_portal(self, portal: str) -> None:
        """
            Performs a lightweight HTTP probe to verify the portal is reachable
            and active before attempting authentication or making API calls.

            A GET request is sent to ``/api/TokenAuth/Authenticate``. If the
            response body contains the word ``"inaccessible"`` (case-insensitive)
            Cyver infrastructure is running but the tenant is not provisioned.
            Any network-level failure (DNS, timeout, connection refused) is
            treated as unreachable.

            Args:
                portal: Hostname of the Cyver portal (e.g. ``"app.cyver.io"``).

            Raises:
                CyverAuthError: With ``reason="portal_inactive"`` if the portal
                    hostname resolves but the tenant is not provisioned; with
                    ``reason="portal_unreachable"`` if the host cannot be reached
                    due to a network error.
        """
        probe_url = f"https://{portal}/api/TokenAuth/Authenticate"
        try:
            response = self._session.get(probe_url, timeout=REQUESTS_TIMEOUT)
            if "inaccessible" in response.text.lower():
                raise CyverAuthError(
                    f"Portal '{portal}' is not active or does not exist.",
                    reason="portal_inactive",
                )
        except CyverAuthError:
            raise
        except RequestException as e:
            raise CyverAuthError(
                f"Portal '{portal}' is unreachable: {e}",
                reason="portal_unreachable",
            ) from e

    def _fetch_oauth_cache(self, username: str, password: str) -> dict:
        """
            Loads previously cached tokens from the configured cache
            directory.

            Returns a template dict with keys ``accessToken``,
            ``refreshToken``, ``userId``, and ``portal``; any value that
            is absent, expired, or undecryptable is returned as ``None``.
            Cold start (the cache file does not yet exist) is **not** an
            error — the empty template is returned silently.

            When caching is disabled (``self._cache_enabled is False``)
            the empty template is returned without touching the
            filesystem.

            Raises:
                CyverCachingError: With ``reason="read_failed"`` on OS
                    errors (permission, I/O); ``"corrupted"`` on JSON
                    parse failure or malformed envelope;
                    ``"decrypt_failed"`` on Fernet decrypt failure or
                    base64 decode failure.
        """
        template = { "accessToken": None, "refreshToken": None, "userId": None, "portal": None }
        if not self._cache_enabled:
            return template

        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret, self._cache_dir)

        try:
            with open(filename, "r") as cachefile:
                raw = cachefile.read()
        except FileNotFoundError:
            return template  # cold start — not an error
        except OSError as exc:
            raise CyverCachingError(
                f"Could not read OAuth cache file '{filename}': {exc}",
                cache_kind="oauth", reason="read_failed",
            ) from exc

        try:
            cache = loads(raw)
        except (JSONDecodeError, ValueError) as exc:
            raise CyverCachingError(
                f"OAuth cache file '{filename}' is not valid JSON: {exc}",
                cache_kind="oauth", reason="corrupted",
            ) from exc

        if "cipher" not in cache or cache["cipher"] != "Fernet" or "ciphertext_b64" not in cache \
                or "iterations" not in cache or "salt_b64" not in cache or \
                "v" not in cache or cache["v"] != 1:
            raise CyverCachingError(
                f"OAuth cache file '{filename}' has an unrecognised envelope.",
                cache_kind="oauth", reason="corrupted",
            )

        try:
            fernet = _derive_fernet(secret, b64decode(cache["salt_b64"]), int(cache["iterations"]))
            payload = loads(fernet.decrypt(b64decode(cache["ciphertext_b64"])).decode("utf-8"))
        except InvalidToken as exc:
            raise CyverCachingError(
                f"OAuth cache file '{filename}' could not be decrypted (wrong key or tampered ciphertext).",
                cache_kind="oauth", reason="decrypt_failed",
            ) from exc
        except (ValueError, JSONDecodeError, UnicodeDecodeError) as exc:
            raise CyverCachingError(
                f"OAuth cache file '{filename}' has corrupted ciphertext or payload: {exc}",
                cache_kind="oauth", reason="decrypt_failed",
            ) from exc

        if "accessToken" in payload:
            try:
                # Pre-check with skew so a near-expiry access token is dropped
                # here and authenticate() refreshes eagerly — avoiding the
                # "first API call → 401 → re-auth" round-trip.  Refresh
                # tokens keep the default skew=0 since they're long-lived and
                # a full login on refresh failure is acceptable.
                _validate_jwt_token(
                    payload["accessToken"], "accessToken",
                    skew_seconds=JWT_EXPIRY_SKEW_SECONDS,
                )
                template["accessToken"] = payload["accessToken"]
            except CyverDataValidationError:
                pass
        if "refreshToken" in payload:
            try:
                _validate_jwt_token(payload["refreshToken"], "refreshToken")
                template["refreshToken"] = payload["refreshToken"]
            except CyverDataValidationError:
                pass
        if "userId" in payload:
            try:
                _validate_uuid(payload["userId"], "userId")
                template["userId"] = payload["userId"]
            except CyverDataValidationError:
                pass
        if "portal" in payload and isinstance(payload["portal"], str) and payload["portal"]:
            template["portal"] = payload["portal"]

        return template

    def _save_oauth_cache(self, username: str, password: str) -> None:
        """
            Encrypts the current access token, refresh token and user ID
            with a PBKDF2-derived Fernet key and writes the result to the
            configured cache directory with owner-only file permissions
            (0o600).

            When caching is disabled this is a silent no-op.

            Raises:
                CyverCachingError: With ``reason="write_failed"`` on
                    encryption failure or any filesystem I/O error.
        """
        if not self._cache_enabled:
            return

        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret, self._cache_dir)

        salt = urandom(CACHE_RANDOM_BYTES)
        fernet = _derive_fernet(secret, salt, CACHE_ITERATIONS)

        with self._lock:
            plaindict = { "accessToken": self.access_token, "refreshToken": self.refresh_token, "userId": self.user_id, "portal": self.portal }

        try:
            plaintext = dumps(plaindict, ensure_ascii=False).encode("utf-8")
            ciphertext = fernet.encrypt(plaintext)
        except (TypeError, ValueError) as exc:
            raise CyverCachingError(
                f"Could not encrypt tokens for OAuth cache: {exc}",
                cache_kind="oauth", reason="write_failed",
            ) from exc

        payload = {
            "v": 1,
            "kdf": "PBKDF2HMAC-SHA256",
            "iterations": CACHE_ITERATIONS,
            "salt_b64": b64encode(salt).decode("ascii"),
            "cipher": "Fernet",
            "ciphertext_b64": b64encode(ciphertext).decode("ascii"),
        }

        try:
            # Open the file with O_CREAT | O_WRONLY | O_TRUNC so it is created
            # atomically with mode 0o600 (owner read/write only) on Unix-like
            # systems. On Windows the mode argument is ignored, but AppData\Local
            # is already user-private so no additional restriction is needed.
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as cachefile:
                cachefile.write(dumps(payload).encode("utf-8"))
        except OSError as exc:
            raise CyverCachingError(
                f"Could not write OAuth cache file '{filename}': {exc}",
                cache_kind="oauth", reason="write_failed",
            ) from exc

    def _delete_oauth_cache(self, username: str, password: str) -> None:
        """
            Removes the encrypted OAuth cache file for the current portal
            and the given username/password combination, if it exists.

            Called automatically when a first-time backend authentication
            attempt fails, ensuring no stale cache file is left behind
            that could interfere with subsequent login attempts.

            When caching is disabled this is a silent no-op.

            Args:
                username: Cyver account username or e-mail address.
                password: Cyver account password.

            Raises:
                CyverCachingError: With ``reason="delete_failed"`` if the
                    file exists but cannot be removed.
        """
        if not self._cache_enabled:
            return

        secret = f"{self.portal}:{username}:{password}"
        filename = _calculate_oauth_cache_filename(secret, self._cache_dir)
        try:
            filename.unlink(missing_ok=True)
            logger.debug(f"Deleted OAuth cache file '{filename}' after failed first-time authentication.")
        except OSError as exc:
            raise CyverCachingError(
                f"Could not delete OAuth cache file '{filename}': {exc}",
                cache_kind="oauth", reason="delete_failed",
            ) from exc

    # ------------------------------------------------------------------
    # API-key cache helpers
    # ------------------------------------------------------------------

    def _fetch_apikey_cache(self) -> dict:
        """
            Loads the API-key validation cache from the configured cache
            directory.

            Returns a template dict with key ``portal``; if the file is
            absent (cold start), ``portal`` is ``None`` and **no exception
            is raised**.  When caching is disabled the same empty
            template is returned without touching the filesystem.

            Raises:
                CyverCachingError: With ``reason="read_failed"`` on OS
                    errors (permission, I/O); ``"corrupted"`` on JSON
                    parse failure or malformed envelope.
        """
        template = {"portal": None}
        if not self._cache_enabled:
            return template

        filename = _calculate_apikey_cache_filename(self._api_key, self._cache_dir)

        try:
            with open(filename, "r") as cachefile:
                raw = cachefile.read()
        except FileNotFoundError:
            return template  # cold start — not an error
        except OSError as exc:
            raise CyverCachingError(
                f"Could not read API-key cache file '{filename}': {exc}",
                cache_kind="apikey", reason="read_failed",
            ) from exc

        try:
            cache = loads(raw)
        except (JSONDecodeError, ValueError) as exc:
            raise CyverCachingError(
                f"API-key cache file '{filename}' is not valid JSON: {exc}",
                cache_kind="apikey", reason="corrupted",
            ) from exc

        if "v" not in cache or cache["v"] != 1 or "portal" not in cache:
            raise CyverCachingError(
                f"API-key cache file '{filename}' has an unrecognised envelope.",
                cache_kind="apikey", reason="corrupted",
            )

        if isinstance(cache["portal"], str) and cache["portal"]:
            template["portal"] = cache["portal"]

        return template

    def _save_apikey_cache(self) -> None:
        """
            Writes the API-key validation record (portal hostname) to the
            configured cache directory with owner-only file permissions
            (0o600).

            When caching is disabled this is a silent no-op.

            Raises:
                CyverCachingError: With ``reason="write_failed"`` on any
                    filesystem I/O error.
        """
        if not self._cache_enabled:
            return

        filename = _calculate_apikey_cache_filename(self._api_key, self._cache_dir)
        payload = {"v": 1, "portal": self.portal}

        try:
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as cachefile:
                cachefile.write(dumps(payload).encode("utf-8"))
        except OSError as exc:
            raise CyverCachingError(
                f"Could not write API-key cache file '{filename}': {exc}",
                cache_kind="apikey", reason="write_failed",
            ) from exc

    def _delete_apikey_cache(self) -> None:
        """
            Removes the API-key validation cache file if it exists.
            Called when the portal probe fails on first use, or when the
            cached portal does not match the one supplied to the
            constructor.

            When caching is disabled this is a silent no-op.

            Raises:
                CyverCachingError: With ``reason="delete_failed"`` if the
                    file exists but cannot be removed.
        """
        if not self._cache_enabled:
            return

        filename = _calculate_apikey_cache_filename(self._api_key, self._cache_dir)
        try:
            filename.unlink(missing_ok=True)
            logger.debug(f"Deleted API-key cache file '{filename}'.")
        except OSError as exc:
            raise CyverCachingError(
                f"Could not delete API-key cache file '{filename}': {exc}",
                cache_kind="apikey", reason="delete_failed",
            ) from exc

    def _require_uuid(self, value: str, field: str) -> None:
        """Raise ``CyverDataValidationError`` if *value* is not a well-formed UUID.

        Args:
            value: The string to validate.
            field: Parameter name used in the error message and ``field``
                attribute of the raised exception.

        Raises:
            CyverDataValidationError: If *value* is not a valid UUID.
        """
        _validate_uuid(value, field)

    def _assert_portal_auth_mode(self) -> None:
        """Raise :class:`CyverAuthMethodError` if the session was constructed
        with a static API key.

        Used by the portal subclasses (``PentesterPortal`` /
        ``ClientPortal``) at construction time: the Cyver web frontend
        API rejects ``X-API-Key`` authentication and accepts only the
        Bearer access token produced by :meth:`authenticate`, so an
        API-key-mode session must fail loudly and immediately rather
        than later at call time.

        Raises:
            CyverAuthMethodError: With ``reason="api_key_not_supported"``
                when ``self._api_key`` is not ``None``.
        """
        if self._api_key is not None:
            raise CyverAuthMethodError(
                "Portal classes require password authentication. "
                "Construct without api_key= and call authenticate(portal, "
                "username, password) instead.",
                reason="api_key_not_supported",
            )

    def _paginate(self, fetcher: Callable[[int, int], dict], page_size: int = 50) -> Iterator:
        """Yield every item from a paginated API endpoint.

        Calls *fetcher* repeatedly, advancing the skip offset until all
        pages have been consumed.

        Args:
            fetcher: Callable with signature ``(count_max: int,
                count_skip: int) -> dict`` that returns a dict containing
                ``items`` (list) and ``totalCount`` (int) keys.
            page_size: Number of records to request per API call.

        Yields:
            Individual items from successive pages.
        """
        skip = 0
        while True:
            page = fetcher(page_size, skip)
            items = page.get("items", [])
            yield from items
            skip += len(items)
            if not items or skip >= page.get("totalCount", 0):
                break

    def _parse_error_detail(self, response) -> str | None:
        """
            Extracts a human-readable error message from a non-2xx response
            body.  Shared by :meth:`_send_api_request` and
            :meth:`_send_multipart_request` so both transports surface the
            same diagnostics.

            Recognises three body shapes, in order:

            - **ABP validation errors** — ``result.errors`` is a mapping of
              ``field → list[str]`` (optionally accompanied by
              ``result.title``).  Used by the Cyver platform for 400-class
              field-validation failures, e.g.::

                  {"result": {"errors": {"fileType": ["The value '8' is
                   invalid."]}, "title": "One or more validation errors
                   occurred.", "status": 400, ...}, ...}

            - **Legacy ABP error** — top-level ``error.message`` or
              ``error.details``.
            - **Generic fallback** — top-level ``message`` or ``detail``.

            Args:
                response: The :class:`requests.Response` carrying the error.

            Returns:
                A single-line summary suitable for interpolation into an
                exception message, or ``None`` when the body carries no
                structured detail.  Non-JSON bodies fall back to the first
                300 characters of ``response.text``.
        """
        try:
            body = response.json()
        except Exception:
            text = response.text
            return text[:300] if text else None

        if not isinstance(body, dict):
            return None

        result = body.get("result")
        if isinstance(result, dict):
            errors = result.get("errors")
            if isinstance(errors, dict) and errors:
                parts = []
                for field, msgs in errors.items():
                    if isinstance(msgs, list):
                        parts.append(f"{field}: {'; '.join(str(m) for m in msgs)}")
                    else:
                        parts.append(f"{field}: {msgs!s}")
                joined = " | ".join(parts)
                title = result.get("title")
                if title:
                    return f"{title} ({joined})"
                return joined
            title = result.get("title")
            if title:
                return str(title)

        error = body.get("error")
        if isinstance(error, dict):
            detail = error.get("message") or error.get("details")
            if detail:
                return str(detail)

        detail = body.get("message") or body.get("detail")
        if detail:
            return str(detail)

        return None

    def _raise_for_error(self, response, method: str, url: str) -> None:
        """
            Maps a non-2xx :class:`requests.Response` to the appropriate
            :class:`~CyverReporting.Exceptions.CyverHTTPError` subclass and
            raises it.  The error message includes the parsed body detail
            (see :meth:`_parse_error_detail`) when one is available.

            Status-code mapping:

            ============ =========================
            HTTP status  Exception
            ============ =========================
            404          ``CyverNotFoundError``
            401 / 403    ``CyverPermissionError``
            429          ``CyverRateLimitError``
            everything   ``CyverHTTPError``
            else
            ============ =========================
        """
        status = response.status_code
        msg = f"{method} {url} failed (HTTP {status})."
        detail = self._parse_error_detail(response)
        if detail:
            msg += f" Server message: {detail}"
        if status == 404:
            raise CyverNotFoundError(msg, method=method, url=url)
        if status in (401, 403):
            raise CyverPermissionError(msg, status_code=status, method=method, url=url)
        if status == 429:
            raise CyverRateLimitError(msg, method=method, url=url)
        raise CyverHTTPError(msg, status_code=status, method=method, url=url)

    def _send_multipart_request(
        self,
        method: str,
        endpoint: str,
        *,
        files: dict,
        data: dict | None = None,
        params: dict | None = None,
    ) -> dict | bool:
        """
            Sends an authenticated ``multipart/form-data`` request to the
            Cyver API.  Shares auth, URL construction, and error-mapping
            plumbing with :meth:`_send_api_request`; the only differences
            are the request body (encoded as multipart rather than JSON) and
            that the ``Content-Type`` header is left to ``requests`` so the
            generated boundary string matches the body exactly.

            Retry policy: inherits the underlying
            :class:`requests.adapters.HTTPAdapter` retry setup.  POST is
            **not** retried automatically to avoid duplicate uploads.

            Args:
                method: HTTP method (typically ``"POST"``).
                endpoint: API path, e.g.
                    ``"/api/latest/pentester/projects/:id/upload-file"``.
                files: Multipart file parts.  Passed verbatim to
                    ``requests.Request(files=...)`` — each value is the
                    standard ``(filename, fileobj, mime_type)`` tuple.
                data: Non-file form fields (plain strings).  Sent alongside
                    *files* in the multipart body.
                params: Optional URL query parameters.

            Returns:
                - The parsed ``result`` value from the JSON response body
                  when the server returns one.
                - ``True`` when the server returns a 2xx with an empty body
                  (the success contract for upload endpoints).
                - ``False`` when the body is non-JSON and non-empty
                  (unexpected but not fatal).

            Raises:
                CyverAuthError: If ``authenticate()`` has not been called.
                CyverNotFoundError: On HTTP 404.
                CyverPermissionError: On HTTP 401 / 403.
                CyverRateLimitError: On HTTP 429.
                CyverHTTPError: On any other non-2xx response, network
                    failure, or a 2xx JSON response with ``success = false``.
        """
        if self.portal is None:
            raise CyverAuthError(
                "Not authenticated. Call authenticate() before making API requests.",
                reason="not_authenticated",
            )

        # Content-Type is intentionally omitted — `requests` generates the
        # boundary and sets the header to match the body.
        headers: dict[str, str] = {}

        if self._api_key:
            headers["X-API-Key"] = self._api_key
        else:
            with self._lock:
                access_token = self.access_token
            if access_token:
                headers["Authorization"] = f"Bearer {access_token}"

        url = f"https://{self.portal}{endpoint}"
        request = Request(method, url, headers=headers, params=params, files=files, data=data)

        try:
            response = self._session.send(
                self._session.prepare_request(request),
                timeout=REQUESTS_TIMEOUT,
            )
        except RequestException as e:
            raise CyverHTTPError(
                f"{method} {url} failed: {e}",
                method=method, url=url,
            ) from e

        if not (200 <= response.status_code < 300):
            self._raise_for_error(response, method, url)

        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                payload = response.json()
            except ValueError as e:
                raise CyverHTTPError(
                    f"{method} {url} returned non-JSON response: {e}",
                    status_code=response.status_code, method=method, url=url,
                ) from e

            if not payload.get("success"):
                raise CyverHTTPError(
                    f"{method} {url} failed (API success flag was false).",
                    status_code=response.status_code, method=method, url=url,
                )

            return payload.get("result")

        try:
            content_length = int(response.headers.get("content-length", -1))
        except ValueError:
            content_length = -1

        if content_length == 0 or not response.content:
            return True

        return False

    def _send_api_request(self, method: str, endpoint: str, params: dict | None = None, data: dict | None = None) -> dict:
        """
            Sends an authenticated HTTP request to the Cyver API and returns
            the parsed ``result`` field from the JSON response body.

            Args:
                method: HTTP method (``"GET"``, ``"POST"``, ``"PUT"``, etc.).
                endpoint: API path, e.g. ``"/api/latest/pentester/projects"``.
                params: Optional URL query parameters.
                data: Optional request body; serialised as JSON.

            Returns:
                The ``result`` value from the API response, True for empty
                200 responses, or False if the response body is unrecognised.

            Raises:
                CyverAuthError: If the session has not been authenticated yet.
                CyverNotFoundError: If the API returns HTTP 404.
                CyverPermissionError: If the API returns HTTP 401 or 403.
                CyverRateLimitError: If the API returns HTTP 429 after all
                    retries are exhausted.
                CyverHTTPError: If the request fails for any other reason,
                    the status code is not 200, the body is not valid JSON,
                    or the success flag is False.
        """
        if self.portal is None:
            raise CyverAuthError(
                "Not authenticated. Call authenticate() before making API requests.",
                reason="not_authenticated",
            )

        headers = {}

        if data:
            headers["Content-Type"] = "application/json; charset=utf-8"

        if self._api_key:
            # Static API-key mode: key is immutable after construction, no lock needed.
            headers["X-API-Key"] = self._api_key
        else:
            # Bearer-token mode: snapshot atomically so the header reflects a
            # consistent state even if authenticate() is called concurrently.
            with self._lock:
                access_token = self.access_token
            if access_token:
                headers["Authorization"] = f"Bearer {access_token}"

        url = f"https://{self.portal}{endpoint}"
        request = Request(method, url, headers=headers, params=params, json=data)

        try:
            response = self._session.send(self._session.prepare_request(request),
                                          timeout=REQUESTS_TIMEOUT)
        except RequestException as e:
            raise CyverHTTPError(
                f"{method} {url} failed: {e}",
                method=method, url=url,
            ) from e

        if not (200 <= response.status_code < 300):
            self._raise_for_error(response, method, url)

        if "content-type" in response.headers and "application/json" in response.headers["content-type"]:
            try:
                payload = response.json()
            except ValueError as e:
                raise CyverHTTPError(
                    f"{method} {url} returned non-JSON response: {e}",
                    status_code=200, method=method, url=url,
                ) from e

            if not payload.get("success"):
                raise CyverHTTPError(
                    f"{method} {url} failed (API success flag was false).",
                    status_code=200, method=method, url=url,
                )

            if "result" not in payload:
                raise CyverHTTPError(
                    f"{method} {url} returned a successful response with no result field.",
                    status_code=200, method=method, url=url,
                )

            return payload["result"]

        try:
            content_length = int(response.headers.get("content-length", -1))
        except ValueError:
            content_length = -1

        if content_length == 0:
            return True

        return False


def _calculate_oauth_cache_filename(secret: str, cache_dir: Path) -> Path:
    """
        Returns the path for the encrypted OAuth token cache file under
        *cache_dir*, creating the parent directory (mode 0o700) if it does
        not yet exist.  The filename is derived from an MD5 digest of the
        secret so that different portals/users each get an isolated cache
        file.

        The caller is responsible for resolving *cache_dir*; this helper
        is never invoked when caching is disabled.

        Raises:
            CyverCachingError: With ``reason="write_failed"`` if the cache
                directory cannot be created (e.g. permission denied,
                read-only filesystem).
    """
    # mode=0o700 restricts the directory to the owner only on Unix-like systems;
    # on Windows, AppData\Local is already user-private so the mode is ignored.
    try:
        cache_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    except OSError as exc:
        raise CyverCachingError(
            f"Could not create cache directory '{cache_dir}': {exc}",
            cache_kind="oauth", reason="write_failed",
        ) from exc

    digest = md5(secret.encode("utf-8")).hexdigest()
    return cache_dir / f"session-{digest}.json"


def _calculate_apikey_cache_filename(api_key: str, cache_dir: Path) -> Path:
    """
        Returns the path for the API-key validation cache file under
        *cache_dir*, creating the parent directory (mode 0o700) if it does
        not yet exist.  The filename is derived from an MD5 digest of the
        API key so that each key gets its own isolated cache file.

        The caller is responsible for resolving *cache_dir*; this helper
        is never invoked when caching is disabled.

        Raises:
            CyverCachingError: With ``reason="write_failed"`` if the cache
                directory cannot be created.
    """
    try:
        cache_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    except OSError as exc:
        raise CyverCachingError(
            f"Could not create cache directory '{cache_dir}': {exc}",
            cache_kind="apikey", reason="write_failed",
        ) from exc

    digest = md5(api_key.encode("utf-8")).hexdigest()
    return cache_dir / f"apikey-{digest}.json"


def _derive_fernet(secret: str, salt: bytes, iterations: int) -> Fernet:
    """
        Derives a Fernet symmetric encryption key from a plaintext secret
        using PBKDF2-HMAC-SHA256 with the given salt and iteration count.
    """
    kdf = PBKDF2HMAC(algorithm=SHA256(), length=32, salt=salt, iterations=iterations)
    key = b64encode(kdf.derive(secret.encode("utf-8")))
    return Fernet(key)
