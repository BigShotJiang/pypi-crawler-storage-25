#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import _validate_uuid
from ..Utils import (
    _fd_optional_str,
    _fd_optional_int,
    _fd_optional_uuid,
    _fd_uuid_list,
    _fd_nested_list,
    _fd_optional_project_status,
    _validate_project_status,
)
from .CyverProjectDates import CyverProjectDates
from .CyverReportTemplate import CyverReportTemplate


class CyverProject:
    """
        Data builder for Cyver project resources.

        Used to construct and validate the request body for
        ``create_project()`` (POST) and ``update_project_by_id()`` (PUT).

        ``name`` is the only constructor argument and is mandatory for both
        operations. ``status``, ``client_id``, and ``project_template_id``
        are also mandatory and must be set before calling
        :meth:`validate_for_post` or :meth:`validate_for_put`.  ``id`` is
        additionally required for PUT.

        Read-only server-populated fields (``clientName``,
        ``projectTemplateTitle``, ``reportTemplateTitle``,
        ``quoteTemplateTitle``, ``projectLeadName``,
        ``projectReviewerName``) are stored when reconstructed via
        :meth:`from_dict` but do not have setters — the server derives them
        from the corresponding UUID fields.

        Typical usage::

            from CyverReporting import (
                PentesterSession,
                CyverProject,
                CyverProjectDates,
                CyverPlanningDate,
            )

            project = (
                CyverProject("Internal Web App Assessment")
                .set_status("TESTING")
                .set_client_id("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")
                .set_project_template_id("yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy")
                .set_report_template_id("zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz")
                .set_project_lead_id("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
                .set_project_dates(
                    CyverProjectDates()
                    .set_start_date("2024-06-01T00:00:00Z")
                    .set_end_date("2024-07-31T00:00:00Z")
                    .add_planning_date(
                        CyverPlanningDate()
                        .set_status("TESTING")
                        .set_start_date("2024-06-15")
                        .set_end_date("2024-07-15")
                    )
                )
            )

            with PentesterSession(portal="app.cyver.io", api_key="sk-...") as p:
                created = p.create_project(project)
                print(created.id)
    """

    def __init__(self, name: str) -> None:
        """
            Initialise a new project builder.

            Args:
                name (str): Project display name. Must be a non-empty string.

            Raises:
                CyverDataValidationError: If ``name`` is not a string
                    (``reason="invalid_type"``) or is empty / whitespace-only
                    (``reason="missing_required"``).
        """
        if not isinstance(name, str) or not name.strip():
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(name, str) else "missing_required",
            )
        # mandatory fields
        self._name: str = name
        self._status: str | None = None
        self._client_id: str | None = None
        self._project_template_id: str | None = None
        # optional / server-assigned
        self._id: str | None = None
        self._code: str | None = None
        self._methodology_markdown: str | None = None
        self._cvss_version: int | None = None
        self._report_template_id: str | None = None
        self._quote_template_id: str | None = None
        self._project_lead_id: str | None = None
        self._project_reviewer_id: str | None = None
        self._project_dates: CyverProjectDates | None = None
        self._label_list: list[str] = []
        self._finding_id_list: list[str] = []
        self._asset_id_list: list[str] = []
        self._checklist_id_list: list[str] = []
        self._compliance_norm_id_list: list[str] = []
        self._user_id_list: list[str] = []
        self._team_id_list: list[str] = []
        self._report_templates: list[CyverReportTemplate] = []
        # read-only server-populated fields (no setters)
        self._client_name: str | None = None
        self._project_template_title: str | None = None
        self._report_template_title: str | None = None
        self._quote_template_title: str | None = None
        self._project_lead_name: str | None = None
        self._project_reviewer_name: str | None = None

    # ------------------------------------------------------------------
    # Properties (read-only server-computed fields)
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """Server-assigned UUID of the project, or ``None`` before creation."""
        return self._id

    @property
    def name(self) -> str:
        """The project's display name."""
        return self._name

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_id(self, value: str) -> "CyverProject":
        """
            Set the project UUID.

            Required for PUT requests. Normally taken from the server response
            after a successful POST.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'id' must be a string, got {type(value).__name__}.",
                field="id",
                reason="invalid_type",
            )
        _validate_uuid(value, "id")
        self._id = value
        return self

    def set_name(self, value: str) -> "CyverProject":
        """
            Update the project display name.

            Args:
                value (str): Non-empty project name string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or is
                    empty / whitespace-only.
        """
        if not isinstance(name := value, str) or not name.strip():
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._name = value
        return self

    def set_status(self, value: str) -> "CyverProject":
        """
            Set the project status.

            Must be an uppercase project-status name from
            :class:`~CyverReporting._project_status`, e.g. ``"TESTING"``,
            ``"COMPLETED"``, ``"ON HOLD"``.

            Args:
                value (str): Uppercase project-status name.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or is not
                    a recognised project-status name
                    (``reason="invalid_value"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'status' must be a string, got {type(value).__name__}.",
                field="status",
                reason="invalid_type",
            )
        _validate_project_status(value, "status")
        self._status = value
        return self

    def set_code(self, value: str) -> "CyverProject":
        """
            Set the project reference code.

            Args:
                value (str): Project code string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'code' must be a string, got {type(value).__name__}.",
                field="code",
                reason="invalid_type",
            )
        self._code = value
        return self

    def set_methodology_markdown(self, value: str) -> "CyverProject":
        """
            Set the project methodology description (Markdown).

            Args:
                value (str): Markdown-formatted methodology text.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'methodologyMarkdown' must be a string, got {type(value).__name__}.",
                field="methodologyMarkdown",
                reason="invalid_type",
            )
        self._methodology_markdown = value
        return self

    def set_cvss_version(self, value: int) -> "CyverProject":
        """
            Set the CVSS scoring version used for this project.

            Args:
                value (int): CVSS version integer (e.g. ``3``).

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``, or is a
                    ``bool``.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'cvssVersion' must be an int, got {type(value).__name__}.",
                field="cvssVersion",
                reason="invalid_type",
            )
        self._cvss_version = value
        return self

    def set_client_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the client this project belongs to.

            Mandatory for both POST and PUT requests.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'clientId' must be a string, got {type(value).__name__}.",
                field="clientId",
                reason="invalid_type",
            )
        _validate_uuid(value, "clientId")
        self._client_id = value
        return self

    def set_project_template_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the project template to apply.

            Mandatory for both POST and PUT requests.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'projectTemplateId' must be a string, got {type(value).__name__}.",
                field="projectTemplateId",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectTemplateId")
        self._project_template_id = value
        return self

    def set_report_template_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the report template to use for this project.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reportTemplateId' must be a string, got {type(value).__name__}.",
                field="reportTemplateId",
                reason="invalid_type",
            )
        _validate_uuid(value, "reportTemplateId")
        self._report_template_id = value
        return self

    def set_quote_template_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the quote template to use for this project.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'quoteTemplateId' must be a string, got {type(value).__name__}.",
                field="quoteTemplateId",
                reason="invalid_type",
            )
        _validate_uuid(value, "quoteTemplateId")
        self._quote_template_id = value
        return self

    def set_project_lead_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the pentester assigned as project lead.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'projectLeadId' must be a string, got {type(value).__name__}.",
                field="projectLeadId",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectLeadId")
        self._project_lead_id = value
        return self

    def set_project_reviewer_id(self, value: str) -> "CyverProject":
        """
            Set the UUID of the pentester assigned as project reviewer.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'projectReviewerId' must be a string, got {type(value).__name__}.",
                field="projectReviewerId",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectReviewerId")
        self._project_reviewer_id = value
        return self

    def set_project_dates(self, value: CyverProjectDates) -> "CyverProject":
        """
            Set the project dates sub-object.

            Args:
                value (CyverProjectDates): A populated
                    :class:`CyverProjectDates` instance.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    ``CyverProjectDates``.
        """
        if not isinstance(value, CyverProjectDates):
            raise CyverDataValidationError(
                f"'projectDates' must be a CyverProjectDates, "
                f"got {type(value).__name__}.",
                field="projectDates",
                reason="invalid_type",
            )
        self._project_dates = value
        return self

    # -- UUID list helpers --------------------------------------------------

    def _add_uuid_to_list(
        self, lst: list, value: str, field: str
    ) -> None:
        """Validate *value* as a UUID and append it to *lst*."""
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each entry in '{field}' must be a string, "
                f"got {type(value).__name__}.",
                field=field,
                reason="invalid_type",
            )
        _validate_uuid(value, field)
        lst.append(value)

    def _set_uuid_list(
        self, value: list[str], field: str
    ) -> list[str]:
        """Validate *value* as a list of UUIDs and return a copy."""
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'{field}' must be a list, got {type(value).__name__}.",
                field=field,
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'{field}[{i}]' must be a string, got {type(item).__name__}.",
                    field=field,
                    reason="invalid_type",
                )
            _validate_uuid(item, f"{field}[{i}]")
        return list(value)

    def add_label_id(self, value: str) -> "CyverProject":
        """
            Append a label UUID to the label list.

            Args:
                value (str): A well-formed UUID string identifying a label.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._label_list, value, "labelList")
        return self

    def set_label_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the label list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._label_list = self._set_uuid_list(value, "labelList")
        return self

    def add_finding_id(self, value: str) -> "CyverProject":
        """
            Append a finding UUID to the finding ID list.

            Args:
                value (str): A well-formed UUID string identifying a finding.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._finding_id_list, value, "findingIdList")
        return self

    def set_finding_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the finding ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._finding_id_list = self._set_uuid_list(value, "findingIdList")
        return self

    def add_asset_id(self, value: str) -> "CyverProject":
        """
            Append an asset UUID to the asset ID list.

            Args:
                value (str): A well-formed UUID string identifying an asset.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._asset_id_list, value, "assetIdList")
        return self

    def set_asset_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the asset ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._asset_id_list = self._set_uuid_list(value, "assetIdList")
        return self

    def add_checklist_id(self, value: str) -> "CyverProject":
        """
            Append a checklist UUID to the checklist ID list.

            Args:
                value (str): A well-formed UUID string identifying a checklist.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._checklist_id_list, value, "checklistIdList")
        return self

    def set_checklist_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the checklist ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._checklist_id_list = self._set_uuid_list(value, "checklistIdList")
        return self

    def add_compliance_norm_id(self, value: str) -> "CyverProject":
        """
            Append a compliance norm UUID to the compliance norm ID list.

            Args:
                value (str): A well-formed UUID string identifying a compliance norm.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._compliance_norm_id_list, value, "complianceNormIdList")
        return self

    def set_compliance_norm_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the compliance norm ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._compliance_norm_id_list = self._set_uuid_list(value, "complianceNormIdList")
        return self

    def add_user_id(self, value: str) -> "CyverProject":
        """
            Append a user UUID to the user ID list.

            Args:
                value (str): A well-formed UUID string identifying a user.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._user_id_list, value, "userIdList")
        return self

    def set_user_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the user ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._user_id_list = self._set_uuid_list(value, "userIdList")
        return self

    def add_team_id(self, value: str) -> "CyverProject":
        """
            Append a team UUID to the team ID list.

            Args:
                value (str): A well-formed UUID string identifying a team.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID.
        """
        self._add_uuid_to_list(self._team_id_list, value, "teamIdList")
        return self

    def set_team_id_list(self, value: list[str]) -> "CyverProject":
        """
            Replace the team ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If any element is not a well-formed UUID.
        """
        self._team_id_list = self._set_uuid_list(value, "teamIdList")
        return self

    def add_report_template(
        self, value: CyverReportTemplate
    ) -> "CyverProject":
        """
            Append a report-template assignment to the report templates list.

            Can be called multiple times to build the list incrementally.
            Use :meth:`set_report_templates` to replace the entire list at
            once.

            Args:
                value (CyverReportTemplate): A populated
                    :class:`CyverReportTemplate` instance.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    ``CyverReportTemplate``.
        """
        if not isinstance(value, CyverReportTemplate):
            raise CyverDataValidationError(
                f"Each entry in 'reportTemplates' must be a "
                f"CyverReportTemplate, got {type(value).__name__}.",
                field="reportTemplates",
                reason="invalid_type",
            )
        self._report_templates.append(value)
        return self

    def set_report_templates(
        self, value: list[CyverReportTemplate]
    ) -> "CyverProject":
        """
            Replace the report templates list.

            Args:
                value (list[CyverReportTemplate]): A list of
                    :class:`CyverReportTemplate` instances.

            Returns:
                CyverProject: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a list, or if any
                    element is not a ``CyverReportTemplate``.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'reportTemplates' must be a list, got {type(value).__name__}.",
                field="reportTemplates",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, CyverReportTemplate):
                raise CyverDataValidationError(
                    f"'reportTemplates[{i}]' must be a CyverReportTemplate, "
                    f"got {type(item).__name__}.",
                    field="reportTemplates",
                    reason="invalid_type",
                )
        self._report_templates = list(value)
        return self

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Assert that all fields required for a POST (create) request are set.

            Mandatory fields: ``name`` (set at construction), ``status``,
            ``clientId``, ``projectTemplateId``.

            Raises:
                CyverDataValidationError: With ``reason="missing_required"`` for
                    the first mandatory field that has not been set.
        """
        if self._status is None:
            raise CyverDataValidationError(
                "'status' is required for POST requests.",
                field="status",
                reason="missing_required",
            )
        if self._client_id is None:
            raise CyverDataValidationError(
                "'clientId' is required for POST requests.",
                field="clientId",
                reason="missing_required",
            )
        if self._project_template_id is None:
            raise CyverDataValidationError(
                "'projectTemplateId' is required for POST requests.",
                field="projectTemplateId",
                reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Assert that all fields required for a PUT (update) request are set.

            Includes all fields checked by :meth:`validate_for_post`, plus
            ``id``.

            Raises:
                CyverDataValidationError: With ``reason="missing_required"`` for
                    the first mandatory field that has not been set.
        """
        if self._id is None:
            raise CyverDataValidationError(
                "'id' is required for PUT requests.",
                field="id",
                reason="missing_required",
            )
        self.validate_for_post()

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the project to a dictionary ready for the Cyver API.

            Always includes: ``name``, ``status``, ``clientId``,
            ``projectTemplateId``.  All other fields are included only when
            they have been explicitly set.  Read-only server-computed name
            fields (``clientName``, ``projectTemplateTitle``, etc.) are
            **not** included — the server derives them from the corresponding
            UUID fields.

            Returns:
                dict: Project payload with camelCase API keys, suitable for
                    use as the ``data`` argument to ``_send_api_request()``.
        """
        result: dict = {
            "name": self._name,
            "status": self._status,
            "clientId": self._client_id,
            "projectTemplateId": self._project_template_id,
        }
        if self._id is not None:
            result["id"] = self._id
        if self._code is not None:
            result["code"] = self._code
        if self._methodology_markdown is not None:
            result["methodologyMarkdown"] = self._methodology_markdown
        if self._cvss_version is not None:
            result["cvssVersion"] = self._cvss_version
        if self._report_template_id is not None:
            result["reportTemplateId"] = self._report_template_id
        if self._quote_template_id is not None:
            result["quoteTemplateId"] = self._quote_template_id
        if self._project_lead_id is not None:
            result["projectLeadId"] = self._project_lead_id
        if self._project_reviewer_id is not None:
            result["projectReviewerId"] = self._project_reviewer_id
        if self._project_dates is not None:
            result["projectDates"] = self._project_dates.to_dict()
        if self._label_list:
            result["labelList"] = self._label_list
        if self._finding_id_list:
            result["findingIdList"] = self._finding_id_list
        if self._asset_id_list:
            result["assetIdList"] = self._asset_id_list
        if self._checklist_id_list:
            result["checklistIdList"] = self._checklist_id_list
        if self._compliance_norm_id_list:
            result["complianceNormIdList"] = self._compliance_norm_id_list
        if self._user_id_list:
            result["userIdList"] = self._user_id_list
        if self._team_id_list:
            result["teamIdList"] = self._team_id_list
        if self._report_templates:
            result["reportTemplates"] = [rt.to_dict() for rt in self._report_templates]
        return result

    def __repr__(self) -> str:
        status_repr = self._status or "NOT SET"
        prefix = f"id={self._id!r}, " if self._id else ""
        set_optional = []
        for flag, key in [
            (self._code, "code"),
            (self._report_template_id, "reportTemplateId"),
            (self._quote_template_id, "quoteTemplateId"),
            (self._project_lead_id, "projectLeadId"),
            (self._project_reviewer_id, "projectReviewerId"),
            (self._project_dates, "projectDates"),
        ]:
            if flag is not None:
                set_optional.append(key)
        for lst, key in [
            (self._label_list, "labelList"),
            (self._finding_id_list, "findingIdList"),
            (self._asset_id_list, "assetIdList"),
            (self._checklist_id_list, "checklistIdList"),
            (self._compliance_norm_id_list, "complianceNormIdList"),
            (self._user_id_list, "userIdList"),
            (self._team_id_list, "teamIdList"),
            (self._report_templates, "reportTemplates"),
        ]:
            if lst:
                set_optional.append(f"{key}[{len(lst)}]")
        return (
            f"CyverProject({prefix}name={self._name!r}, "
            f"status={status_repr!r}, "
            f"clientId={self._client_id!r}, "
            f"projectTemplateId={self._project_template_id!r}"
            + (f", optional={set_optional}" if set_optional else "")
            + ")"
        )

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "CyverProject":
        """
            Construct a ``CyverProject`` from an API response dictionary.

            All fields are assigned directly to private attributes, bypassing
            setters so that server-returned values are not re-validated on
            ingestion.  Read-only server-computed name fields
            (``clientName``, ``projectTemplateTitle``, etc.) are stored and
            accessible via their corresponding properties.

            Args:
                data (dict): A project dict as returned by the Cyver API
                    (e.g. from ``get_project_by_id()``).

            Returns:
                CyverProject: A fully populated instance.

            Raises:
                CyverDataValidationError: If ``name`` is absent or not a
                    non-empty string (``reason="missing_required"``).
        """
        name = data.get("name", "")
        if not isinstance(name, str) or not name.strip():
            raise CyverDataValidationError(
                "'name' is required but was missing or empty in the response data.",
                field="name",
                reason="missing_required",
            )
        obj = cls.__new__(cls)
        # mandatory
        obj._name                   = name
        obj._status                 = _fd_optional_project_status(data, "status")
        obj._client_id              = _fd_optional_uuid(data, "clientId")
        obj._project_template_id    = _fd_optional_uuid(data, "projectTemplateId")
        # optional / server-assigned
        obj._id                     = _fd_optional_uuid(data, "id")
        obj._code                   = _fd_optional_str(data, "code")
        obj._methodology_markdown   = _fd_optional_str(data, "methodologyMarkdown")
        obj._cvss_version           = _fd_optional_int(data, "cvssVersion")
        obj._report_template_id     = _fd_optional_uuid(data, "reportTemplateId")
        obj._quote_template_id      = _fd_optional_uuid(data, "quoteTemplateId")
        obj._project_lead_id        = _fd_optional_uuid(data, "projectLeadId")
        obj._project_reviewer_id    = _fd_optional_uuid(data, "projectReviewerId")
        # nested objects
        raw_dates = data.get("projectDates")
        obj._project_dates = (
            CyverProjectDates.from_dict(raw_dates)
            if isinstance(raw_dates, dict) else None
        )
        # UUID lists
        obj._label_list              = _fd_uuid_list(data, "labelList")
        obj._finding_id_list         = _fd_uuid_list(data, "findingIdList")
        obj._asset_id_list           = _fd_uuid_list(data, "assetIdList")
        obj._checklist_id_list       = _fd_uuid_list(data, "checklistIdList")
        obj._compliance_norm_id_list = _fd_uuid_list(data, "complianceNormIdList")
        obj._user_id_list            = _fd_uuid_list(data, "userIdList")
        obj._team_id_list            = _fd_uuid_list(data, "teamIdList")
        # nested list
        obj._report_templates = _fd_nested_list(
            data, "reportTemplates", CyverReportTemplate
        )
        # read-only server-computed name fields
        obj._client_name              = _fd_optional_str(data, "clientName")
        obj._project_template_title   = _fd_optional_str(data, "projectTemplateTitle")
        obj._report_template_title    = _fd_optional_str(data, "reportTemplateTitle")
        obj._quote_template_title     = _fd_optional_str(data, "quoteTemplateTitle")
        obj._project_lead_name        = _fd_optional_str(data, "projectLeadName")
        obj._project_reviewer_name    = _fd_optional_str(data, "projectReviewerName")
        return obj
