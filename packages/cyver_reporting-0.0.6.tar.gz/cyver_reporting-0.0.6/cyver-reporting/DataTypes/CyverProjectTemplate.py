#!/usr/bin/env python3

from __future__ import annotations

from ..Utils import (
    _fd_require_id,
    _fd_optional_str,
    _fd_optional_int,
    _fd_optional_uuid,
    _fd_uuid_list,
    _fd_nested_list,
)
from .CyverChecklistTemplate import CyverChecklistTemplate
from .CyverComplianceTemplate import CyverComplianceTemplate


class CyverProjectTemplate:
    """
        Read-only representation of a Project Template as returned by the
        Cyver API.

        Instances are constructed exclusively via ``from_dict()``, which
        validates every field's type and enforces the single mandatory field
        (``id``). Nested checklist and compliance template objects are
        parsed recursively using ``CyverChecklistTemplate.from_dict()``
        and ``CyverComplianceTemplate.from_dict()``. No setter methods are
        provided because these objects are never written back to the API.

        Attributes:
            id (str): Server-assigned UUID of the template.
            report_template_id (str | None): UUID of the linked report template.
            finding_fields_template_id (str | None): UUID of the linked finding
                fields template.
            project_workflow_template_id (str | None): UUID of the linked
                project workflow template.
            status (int | None): Numeric status code.
            type (int | None): Numeric project type.
            type_of_findings (int | None): Numeric findings type.
            client_can_report_type_of_findings (int | None): Numeric flag
                controlling client reporting permissions.
            cvss_version (int | None): CVSS scoring version in use.
            title (str | None): Display name of the template.
            checklist_template_list (list[CyverChecklistTemplate]): Checklist
                templates attached to this project template.
            compliance_norm_template_list (list[CyverComplianceTemplate]):
                Compliance norm templates attached to this project template.
            report_templates (list[str]): UUIDs of report templates linked to
                this project template.
    """

    def __init__(
        self,
        id: str,
        report_template_id: str | None,
        finding_fields_template_id: str | None,
        project_workflow_template_id: str | None,
        status: int | None,
        type: int | None,
        type_of_findings: int | None,
        client_can_report_type_of_findings: int | None,
        cvss_version: int | None,
        title: str | None,
        checklist_template_list: list[CyverChecklistTemplate],
        compliance_norm_template_list: list[CyverComplianceTemplate],
        report_templates: list[str],
    ) -> None:
        self._id = id
        self._report_template_id = report_template_id
        self._finding_fields_template_id = finding_fields_template_id
        self._project_workflow_template_id = project_workflow_template_id
        self._status = status
        self._type = type
        self._type_of_findings = type_of_findings
        self._client_can_report_type_of_findings = client_can_report_type_of_findings
        self._cvss_version = cvss_version
        self._title = title
        self._checklist_template_list = checklist_template_list
        self._compliance_norm_template_list = compliance_norm_template_list
        self._report_templates = report_templates

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        """Server-assigned UUID of the template."""
        return self._id

    @property
    def report_template_id(self) -> str | None:
        """UUID of the linked report template."""
        return self._report_template_id

    @property
    def finding_fields_template_id(self) -> str | None:
        """UUID of the linked finding fields template."""
        return self._finding_fields_template_id

    @property
    def project_workflow_template_id(self) -> str | None:
        """UUID of the linked project workflow template."""
        return self._project_workflow_template_id

    @property
    def status(self) -> int | None:
        """Numeric status code."""
        return self._status

    @property
    def type(self) -> int | None:
        """Numeric project type."""
        return self._type

    @property
    def type_of_findings(self) -> int | None:
        """Numeric findings type."""
        return self._type_of_findings

    @property
    def client_can_report_type_of_findings(self) -> int | None:
        """Numeric flag controlling client reporting permissions."""
        return self._client_can_report_type_of_findings

    @property
    def cvss_version(self) -> int | None:
        """CVSS scoring version in use."""
        return self._cvss_version

    @property
    def title(self) -> str | None:
        """Display name of the template."""
        return self._title

    @property
    def checklist_template_list(self) -> list[CyverChecklistTemplate]:
        """Checklist templates attached to this project template."""
        return list(self._checklist_template_list)

    @property
    def compliance_norm_template_list(self) -> list[CyverComplianceTemplate]:
        """Compliance norm templates attached to this project template."""
        return list(self._compliance_norm_template_list)

    @property
    def report_templates(self) -> list[str]:
        """UUIDs of report templates linked to this project template."""
        return list(self._report_templates)

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverProjectTemplate:
        """
            Construct a ``CyverProjectTemplate`` from an API response dict.

            Validates that ``id`` is present and a valid UUID, and that all
            other recognised fields conform to their expected types. Nested
            checklist and compliance template objects are parsed recursively,
            propagating any ``CyverDataValidationError`` raised during their validation.

            Args:
                data (dict): A project-template dict as returned by the
                    Cyver API.

            Returns:
                CyverProjectTemplate: A fully populated, read-only instance.

            Raises:
                CyverDataValidationError: If ``id`` is missing or not a valid UUID, if
                    any scalar field has an unexpected type, if any UUID field
                    is not a well-formed UUID string, or if any nested template
                    object fails its own validation.
        """
        return cls(
            id=_fd_require_id(data),
            report_template_id=_fd_optional_uuid(data, "reportTemplateId"),
            finding_fields_template_id=_fd_optional_uuid(data, "findingFieldsTemplateId"),
            project_workflow_template_id=_fd_optional_uuid(data, "projectWorkflowTemplateId"),
            status=_fd_optional_int(data, "status"),
            type=_fd_optional_int(data, "type"),
            type_of_findings=_fd_optional_int(data, "typeOfFindings"),
            client_can_report_type_of_findings=_fd_optional_int(data, "clientCanReportTypeOfFindings"),
            cvss_version=_fd_optional_int(data, "cvssVersion"),
            title=_fd_optional_str(data, "title"),
            checklist_template_list=_fd_nested_list(data, "checklistTemplateList", CyverChecklistTemplate),
            compliance_norm_template_list=_fd_nested_list(data, "complianceNormTemplateList", CyverComplianceTemplate),
            report_templates=_fd_uuid_list(data, "reportTemplates"),
        )

    def __repr__(self) -> str:
        return (
            f"CyverProjectTemplate(id={self._id!r}, title={self._title!r})"
        )
