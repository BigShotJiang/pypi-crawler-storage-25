#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _validate_project_status,
    _validate_date,
    _fd_optional_project_status,
    _fd_optional_date,
)


class CyverPlanningDate:
    """
        A single phase planning date entry within :class:`CyverProjectDates`.

        Maps a project status phase to expected start and end calendar dates.
        All fields are optional individually, but a useful entry requires at
        least ``status``.

        Typical usage::

            from CyverReporting import CyverPlanningDate

            phase = (
                CyverPlanningDate()
                .set_status("TESTING")
                .set_start_date("2024-05-01")
                .set_end_date("2024-05-31")
            )
    """

    def __init__(self) -> None:
        self._status: str | None = None
        self._start_date: str | None = None
        self._end_date: str | None = None

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_status(self, value: str) -> "CyverPlanningDate":
        """
            Set the project phase this date range applies to.

            Must be an uppercase project-status name from
            :class:`~CyverReporting._project_status`, e.g. ``"TESTING"``,
            ``"REPORTING"``, ``"REMEDIATION"``.

            Args:
                value (str): Uppercase project-status name.

            Returns:
                CyverPlanningDate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or is not
                    a recognised project-status name
                    (``reason="invalid_value"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'status' must be a string, got {type(value).__name__}.",
                field="status",
                reason="invalid_type",
            )
        _validate_project_status(value, "status")
        self._status = value
        return self

    def set_start_date(self, value: str) -> "CyverPlanningDate":
        """
            Set the planned start date for this phase.

            Args:
                value (str): Date string in ``YYYY-MM-DD`` format.

            Returns:
                CyverPlanningDate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match ``YYYY-MM-DD`` (``reason="invalid_date"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'startDate' must be a string, got {type(value).__name__}.",
                field="startDate",
                reason="invalid_type",
            )
        _validate_date(value, "startDate")
        self._start_date = value
        return self

    def set_end_date(self, value: str) -> "CyverPlanningDate":
        """
            Set the planned end date for this phase.

            Args:
                value (str): Date string in ``YYYY-MM-DD`` format.

            Returns:
                CyverPlanningDate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match ``YYYY-MM-DD`` (``reason="invalid_date"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'endDate' must be a string, got {type(value).__name__}.",
                field="endDate",
                reason="invalid_type",
            )
        _validate_date(value, "endDate")
        self._end_date = value
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included.

            Returns:
                dict: Planning date payload with camelCase API keys.
        """
        result: dict = {}
        if self._status is not None:
            result["status"] = self._status
        if self._start_date is not None:
            result["startDate"] = self._start_date
        if self._end_date is not None:
            result["endDate"] = self._end_date
        return result

    def __repr__(self) -> str:
        parts = []
        if self._status is not None:
            parts.append(f"status={self._status!r}")
        if self._start_date is not None:
            parts.append(f"startDate={self._start_date!r}")
        if self._end_date is not None:
            parts.append(f"endDate={self._end_date!r}")
        return f"CyverPlanningDate({', '.join(parts)})"

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "CyverPlanningDate":
        """
            Construct a ``CyverPlanningDate`` from an API response dictionary.

            Args:
                data (dict): A planning date dict as returned by the Cyver API.

            Returns:
                CyverPlanningDate: A populated instance.
        """
        obj = cls()
        obj._status     = _fd_optional_project_status(data, "status")
        obj._start_date = _fd_optional_date(data, "startDate")
        obj._end_date   = _fd_optional_date(data, "endDate")
        return obj
