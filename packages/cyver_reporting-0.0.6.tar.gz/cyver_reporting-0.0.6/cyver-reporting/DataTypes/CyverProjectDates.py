#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _validate_datetime,
    _fd_optional_datetime,
    _fd_nested_list,
)
from .CyverPlanningDate import CyverPlanningDate


class CyverProjectDates:
    """
        Project dates sub-object used within :class:`CyverProject`.

        Encapsulates all temporal information for a project: overall start/end
        datetimes, testing-phase window, report-related datetimes, and a list
        of per-phase :class:`CyverPlanningDate` entries. All fields are
        optional.

        Typical usage::

            from CyverReporting import CyverProjectDates, CyverPlanningDate

            dates = (
                CyverProjectDates()
                .set_start_date("2024-06-01T00:00:00Z")
                .set_end_date("2024-07-31T00:00:00Z")
                .set_start_testing("2024-06-15T00:00:00Z")
                .set_end_testing("2024-07-15T00:00:00Z")
                .set_report_due_date("2024-07-20T00:00:00Z")
                .add_planning_date(
                    CyverPlanningDate()
                    .set_status("TESTING")
                    .set_start_date("2024-06-15")
                    .set_end_date("2024-07-15")
                )
            )
    """

    def __init__(self) -> None:
        self._start_date: str | None = None
        self._end_date: str | None = None
        self._start_testing: str | None = None
        self._end_testing: str | None = None
        self._creation_time: str | None = None
        self._report_due_date: str | None = None
        self._report_published_at: str | None = None
        self._planning_dates: list[CyverPlanningDate] = []

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_start_date(self, value: str) -> "CyverProjectDates":
        """
            Set the project start datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'startDate' must be a string, got {type(value).__name__}.",
                field="startDate",
                reason="invalid_type",
            )
        _validate_datetime(value, "startDate")
        self._start_date = value
        return self

    def set_end_date(self, value: str) -> "CyverProjectDates":
        """
            Set the project end datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'endDate' must be a string, got {type(value).__name__}.",
                field="endDate",
                reason="invalid_type",
            )
        _validate_datetime(value, "endDate")
        self._end_date = value
        return self

    def set_start_testing(self, value: str) -> "CyverProjectDates":
        """
            Set the testing-phase start datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'startTesting' must be a string, got {type(value).__name__}.",
                field="startTesting",
                reason="invalid_type",
            )
        _validate_datetime(value, "startTesting")
        self._start_testing = value
        return self

    def set_end_testing(self, value: str) -> "CyverProjectDates":
        """
            Set the testing-phase end datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'endTesting' must be a string, got {type(value).__name__}.",
                field="endTesting",
                reason="invalid_type",
            )
        _validate_datetime(value, "endTesting")
        self._end_testing = value
        return self

    def set_creation_time(self, value: str) -> "CyverProjectDates":
        """
            Set the project creation datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'creationTime' must be a string, got {type(value).__name__}.",
                field="creationTime",
                reason="invalid_type",
            )
        _validate_datetime(value, "creationTime")
        self._creation_time = value
        return self

    def set_report_due_date(self, value: str) -> "CyverProjectDates":
        """
            Set the report due datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reportDueDate' must be a string, got {type(value).__name__}.",
                field="reportDueDate",
                reason="invalid_type",
            )
        _validate_datetime(value, "reportDueDate")
        self._report_due_date = value
        return self

    def set_report_published_at(self, value: str) -> "CyverProjectDates":
        """
            Set the report publication datetime.

            Args:
                value (str): Datetime string in
                    ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` format.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string, or does
                    not match the expected datetime format
                    (``reason="invalid_datetime"``).
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reportPublishedAt' must be a string, got {type(value).__name__}.",
                field="reportPublishedAt",
                reason="invalid_type",
            )
        _validate_datetime(value, "reportPublishedAt")
        self._report_published_at = value
        return self

    def add_planning_date(self, value: CyverPlanningDate) -> "CyverProjectDates":
        """
            Append a phase planning date entry to the planning dates list.

            Can be called multiple times to build the list incrementally.
            Use :meth:`set_planning_dates` to replace the entire list at once.

            Args:
                value (CyverPlanningDate): A populated
                    :class:`CyverPlanningDate` instance.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    ``CyverPlanningDate``.
        """
        if not isinstance(value, CyverPlanningDate):
            raise CyverDataValidationError(
                f"Each entry in 'planningDates' must be a CyverPlanningDate, "
                f"got {type(value).__name__}.",
                field="planningDates",
                reason="invalid_type",
            )
        self._planning_dates.append(value)
        return self

    def set_planning_dates(
        self, value: list[CyverPlanningDate]
    ) -> "CyverProjectDates":
        """
            Replace the planning dates list with the provided list of entries.

            Args:
                value (list[CyverPlanningDate]): A list of
                    :class:`CyverPlanningDate` instances.

            Returns:
                CyverProjectDates: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a list, or if any
                    element is not a :class:`CyverPlanningDate`.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'planningDates' must be a list, got {type(value).__name__}.",
                field="planningDates",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, CyverPlanningDate):
                raise CyverDataValidationError(
                    f"'planningDates[{i}]' must be a CyverPlanningDate, "
                    f"got {type(item).__name__}.",
                    field="planningDates",
                    reason="invalid_type",
                )
        self._planning_dates = list(value)
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included.

            Returns:
                dict: Project dates payload with camelCase API keys.
        """
        result: dict = {}
        if self._start_date is not None:
            result["startDate"] = self._start_date
        if self._end_date is not None:
            result["endDate"] = self._end_date
        if self._start_testing is not None:
            result["startTesting"] = self._start_testing
        if self._end_testing is not None:
            result["endTesting"] = self._end_testing
        if self._creation_time is not None:
            result["creationTime"] = self._creation_time
        if self._report_due_date is not None:
            result["reportDueDate"] = self._report_due_date
        if self._report_published_at is not None:
            result["reportPublishedAt"] = self._report_published_at
        if self._planning_dates:
            result["planningDates"] = [pd.to_dict() for pd in self._planning_dates]
        return result

    def __repr__(self) -> str:
        set_fields = [
            k for k, v in {
                "startDate": self._start_date,
                "endDate": self._end_date,
                "startTesting": self._start_testing,
                "endTesting": self._end_testing,
                "creationTime": self._creation_time,
                "reportDueDate": self._report_due_date,
                "reportPublishedAt": self._report_published_at,
            }.items()
            if v is not None
        ]
        if self._planning_dates:
            set_fields.append(f"planningDates[{len(self._planning_dates)}]")
        return f"CyverProjectDates(fields={set_fields})"

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "CyverProjectDates":
        """
            Construct a ``CyverProjectDates`` from an API response dictionary.

            Args:
                data (dict): A project dates dict as returned by the Cyver API.

            Returns:
                CyverProjectDates: A populated instance.
        """
        obj = cls()
        obj._start_date          = _fd_optional_datetime(data, "startDate")
        obj._end_date            = _fd_optional_datetime(data, "endDate")
        obj._start_testing       = _fd_optional_datetime(data, "startTesting")
        obj._end_testing         = _fd_optional_datetime(data, "endTesting")
        obj._creation_time       = _fd_optional_datetime(data, "creationTime")
        obj._report_due_date     = _fd_optional_datetime(data, "reportDueDate")
        obj._report_published_at = _fd_optional_datetime(data, "reportPublishedAt")
        obj._planning_dates      = _fd_nested_list(data, "planningDates", CyverPlanningDate)
        return obj
