#!/usr/bin/env python3

from __future__ import annotations

from ..Utils import (
    _fd_require_id,
    _fd_optional_str,
    _fd_optional_int,
    _fd_uuid_list,
)


class CyverChecklistTemplate:
    """
        Read-only representation of a Checklist Template as returned by the
        Cyver API.

        Instances are constructed exclusively via ``from_dict()``, which
        validates every field's type and enforces the single mandatory field
        (``id``). No setter methods are provided because these objects are
        never written back to the API.

        Attributes:
            id (str): Server-assigned UUID of the template.
            status (int | None): Numeric status code of the template.
            name (str | None): Display name of the template.
            external_url (str | None): Optional external reference URL.
            description (str | None): Human-readable description.
            task_group_list (list[str]): List of task-group UUIDs attached to
                the template. Empty list when absent in the API response.
    """

    def __init__(
        self,
        id: str,
        status: int | None,
        name: str | None,
        external_url: str | None,
        description: str | None,
        task_group_list: list[str],
    ) -> None:
        self._id = id
        self._status = status
        self._name = name
        self._external_url = external_url
        self._description = description
        self._task_group_list = task_group_list

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        """Server-assigned UUID of the template."""
        return self._id

    @property
    def status(self) -> int | None:
        """Numeric status code of the template."""
        return self._status

    @property
    def name(self) -> str | None:
        """Display name of the template."""
        return self._name

    @property
    def external_url(self) -> str | None:
        """Optional external reference URL."""
        return self._external_url

    @property
    def description(self) -> str | None:
        """Human-readable description of the template."""
        return self._description

    @property
    def task_group_list(self) -> list[str]:
        """List of task-group UUIDs attached to the template."""
        return list(self._task_group_list)

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverChecklistTemplate:
        """
            Construct a ``CyverChecklistTemplate`` from an API response dict.

            Validates that ``id`` is present and a valid UUID, and that all
            other recognised fields conform to their expected types.

            Args:
                data (dict): A checklist-template dict as returned by the
                    Cyver API.

            Returns:
                CyverChecklistTemplate: A fully populated, read-only instance.

            Raises:
                CyverDataValidationError: If ``id`` is missing or not a valid UUID, or
                    if any other field has an unexpected type.
        """
        return cls(
            id=_fd_require_id(data),
            status=_fd_optional_int(data, "status"),
            name=_fd_optional_str(data, "name"),
            external_url=_fd_optional_str(data, "externalUrl"),
            description=_fd_optional_str(data, "description"),
            task_group_list=_fd_uuid_list(data, "taskGroupList"),
        )

    def __repr__(self) -> str:
        return (
            f"CyverChecklistTemplate(id={self._id!r}, name={self._name!r})"
        )
