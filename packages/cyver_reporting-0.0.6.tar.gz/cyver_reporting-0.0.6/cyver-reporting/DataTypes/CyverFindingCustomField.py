#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError


class CyverFindingCustomField:
    """
        Data-builder for a single finding custom field entry.

        This class is not submitted to an API endpoint on its own; it is
        intended to be embedded in a :class:`CyverFinding` object as part of
        its ``customFields`` list.

        The ``field`` key (the custom field's identifier name) is the only
        universally required value and must be provided at construction time.
        All remaining fields are optional and can be set via their respective
        setters.

        All setter methods return ``self`` so calls can be chained fluently::

            entry = (
                CyverFindingCustomField("CVSS Score")
                .set_field_type(1)
                .set_value("9.8")
                .set_code("CVSS_BASE")
            )

            payload = entry.to_dict()

        Args:
            field (str): The custom field's identifier name. Must be a
                non-empty string.

        Raises:
            CyverDataValidationError: If ``field`` is not a non-empty ``str``.
    """

    def __init__(self, field: str) -> None:
        if not isinstance(field, str) or not field:
            raise CyverDataValidationError(
                "'field' must be a non-empty string.",
                field="field",
                reason="invalid_type" if not isinstance(field, str) else "missing_required",
            )
        self._field: str = field
        self._field_type: int | None = None
        self._value: str | None = None
        self._code: str | None = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def field(self) -> str:
        """The custom field's identifier name."""
        return self._field

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_field(self, value: str) -> CyverFindingCustomField:
        """
            Update the custom field's identifier name.

            Args:
                value (str): New non-empty field identifier name.

            Returns:
                CyverFindingCustomField: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'field' must be a non-empty string.",
                field="field",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._field = value
        return self

    def set_field_type(self, value: int) -> CyverFindingCustomField:
        """
            Set the field type code.

            The value must be a plain ``int``; ``bool`` values are explicitly
            rejected because Python's ``bool`` is a subclass of ``int``.

            Args:
                value (int): Integer field-type code as expected by the API.

            Returns:
                CyverFindingCustomField: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``
                    (or is a ``bool``).
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'fieldType' must be an int, got {type(value).__name__}.",
                field="fieldType",
                reason="invalid_type",
            )
        self._field_type = value
        return self

    def set_value(self, value: str) -> CyverFindingCustomField:
        """
            Set the custom field's value.

            Args:
                value (str): The value to store for this field.

            Returns:
                CyverFindingCustomField: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'value' must be a string, got {type(value).__name__}.",
                field="value",
                reason="invalid_type",
            )
        self._value = value
        return self

    def set_code(self, value: str) -> CyverFindingCustomField:
        """
            Set the custom field's code.

            Args:
                value (str): The code string associated with this field.

            Returns:
                CyverFindingCustomField: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'code' must be a string, got {type(value).__name__}.",
                field="code",
                reason="invalid_type",
            )
        self._code = value
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the custom field entry to a dictionary.

            Only fields that have been explicitly set are included in the
            output.  The ``field`` key is always present as it is required
            at construction time.

            Returns:
                dict: Custom field payload with the API key names, suitable
                    for embedding in a parent finding payload.
        """
        result: dict = {"field": self._field}
        if self._field_type is not None:
            result["fieldType"] = self._field_type
        if self._value is not None:
            result["value"] = self._value
        if self._code is not None:
            result["code"] = self._code
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverFindingCustomField:
        """
            Construct a ``CyverFindingCustomField`` from a dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly (bypassing setters) so that values already
            validated by the server are not re-validated on ingestion.

            Args:
                data (dict): A custom field dict as returned by the Cyver API
                    or embedded in a finding response.

            Returns:
                CyverFindingCustomField: A populated instance.
        """
        obj = cls(data["field"])
        obj._field_type = data.get("fieldType")
        obj._value      = data.get("value")
        obj._code       = data.get("code")
        return obj

    def __repr__(self) -> str:
        parts = [f"field={self._field!r}"]
        if self._field_type is not None:
            parts.append(f"fieldType={self._field_type!r}")
        if self._value is not None:
            parts.append(f"value={self._value!r}")
        if self._code is not None:
            parts.append(f"code={self._code!r}")
        return f"CyverFindingCustomField({', '.join(parts)})"
