#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import _validate_uuid
from ..Utils import (
    _asset_type,
    _asset_env,
    _asset_hosting,
    _asset_hardware,
    _asset_exposure,
)


class CyverAsset:
    """
        Data-builder for the ``/api/v2.2/pentester/clients/:id/assets`` API
        endpoints.

        Encapsulates and validates the request body for both the
        ``POST /api/v2.2/pentester/clients/:id/assets`` (create) and
        ``PUT /api/v2.2/pentester/clients/:id/assets/:id`` (update) operations.

        The ``title`` field is the only universally required field and must be
        provided at construction time. ``type`` is additionally required for
        PUT requests. All remaining fields are optional.

        The ``type``, ``environment``, ``hostingType``, ``publicFacing``, and
        ``typeHardware`` fields accept integer indices that correspond to the
        entries in ``_asset_type``, ``_asset_env``,
        ``_asset_hosting``, ``_asset_exposure``, and
        ``_asset_hardware`` respectively.

        All setter methods return ``self`` so calls can be chained fluently::

            asset = (
                CyverAsset("Main Web Portal")
                .set_type(_asset_type.web)
                .set_environment(_asset_env.prod)
                .set_hosting_type(_asset_hosting.azure)
                .set_url("https://portal.example.com")
                .set_public_facing(_asset_exposure.external)
                .add_label_id("a1b2c3d4-e5f6-7890-abcd-ef1234567890")
            )

            payload = asset.to_dict()

        Args:
            title (str): The asset's display name. Must be a non-empty string.

        Raises:
            CyverDataValidationError: If ``title`` is not a non-empty ``str``.
    """

    def __init__(self, title: str) -> None:
        if not isinstance(title, str) or not title:
            raise CyverDataValidationError(
                "'title' must be a non-empty string.",
                field="title",
                reason="invalid_type" if not isinstance(title, str) else "missing_required",
            )
        self._id: str | None = None
        self._title: str = title
        self._type: int | None = None
        self._description: str | None = None
        self._domain: str | None = None
        self._ip: str | None = None
        self._url: str | None = None
        self._port: int | None = None
        self._ssid: str | None = None
        self._path: str | None = None
        self._protocol: str | None = None
        self._location: str | None = None
        self._operating_system: str | None = None
        self._vendor: str | None = None
        self._product: str | None = None
        self._version: str | None = None
        self._commit: str | None = None
        self._lines_of_code: str | None = None
        self._repository: str | None = None
        self._technology: str | None = None
        self._domain_ad: str | None = None
        self._username: str | None = None
        self._testing_frequency: int | None = None
        self._public_facing: int | None = None
        self._type_hardware: int | None = None
        self._hosting_type: int | None = None
        self._environment: int | None = None
        self._label_id_list: list[str] = []

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_enum(value: int, field: str, valid_values: frozenset[int]) -> None:
        """Validate that *value* is an int present in *valid_values*,
        raising ``CyverDataValidationError`` otherwise."""
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'{field}' must be an int, got {type(value).__name__}.",
                field=field,
                reason="invalid_type",
            )
        if value not in valid_values:
            valid_str = ", ".join(str(v) for v in sorted(valid_values))
            raise CyverDataValidationError(
                f"'{field}' must be one of: {valid_str}. Got {value!r}.",
                field=field,
                reason="invalid_value",
            )

    # ------------------------------------------------------------------
    # Setters — title
    # ------------------------------------------------------------------

    def set_title(self, value: str) -> CyverAsset:
        """
            Update the asset's display name.

            Args:
                value (str): New non-empty display name.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'title' must be a non-empty string.",
                field="title",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._title = value
        return self

    # ------------------------------------------------------------------
    # Setters — enum int fields
    # ------------------------------------------------------------------

    # Maps each _asset_type index to the fields that must be set before a
    # request carrying that type can be dispatched. Used by
    # _validate_type_required_fields(), which is called from both
    # validate_for_post() and validate_for_put().
    _TYPE_REQUIRED_FIELDS: dict[int, list[str]] = {
        2:  ["url"],         # Web Application
        3:  ["path"],        # Mobile Application
        4:  ["url"],         # API
        5:  ["ip"],          # Network
        6:  ["ssid"],        # Wifi Network
        7:  ["domain"],      # Active Directory
        8:  [],              # Physical Asset
        9:  [],              # Hardware Device
        10: ["repository"],  # Smart Contract
        11: ["repository"],  # Source Code
        12: ["username"],    # User
        13: [],              # Other
        14: [],              # Cloud Resource
    }

    def set_type(self, value: int) -> CyverAsset:
        """
            Set the asset type.

            The value must be a valid ``_asset_type`` constant. Required
            for PUT requests.

            Each asset type imposes additional mandatory fields that must be
            set before the request is dispatched. These requirements are
            enforced by ``validate_for_post()`` and ``validate_for_put()``
            via ``_validate_type_required_fields()``. The per-type required
            fields are:

            ============================  ================
            Asset type                    Required field
            ============================  ================
            Web Application (2)           ``url``
            Mobile Application (3)        ``path``
            API (4)                       ``url``
            Network (5)                   ``ip``
            Wifi Network (6)              ``ssid``
            Active Directory (7)          ``domain``
            Smart Contract (10)           ``repository``
            Source Code (11)              ``repository``
            User (12)                     ``username``
            Physical Asset / Hardware /
            Cloud Resource / Other        *(none)*
            ============================  ================

            Args:
                value (int): A ``_asset_type`` constant (e.g.
                    ``_asset_type.web`` or ``2`` for Web Application).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not a
                    valid ``_asset_type`` constant.
        """
        self._validate_enum(value, "type", _asset_type._valid)
        self._type = value
        return self

    def set_environment(self, value: int) -> CyverAsset:
        """
            Set the asset environment.

            The value must be a valid ``_asset_env`` constant.

            Args:
                value (int): A ``_asset_env`` constant (e.g.
                    ``_asset_env.prod`` or ``3`` for Production).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not a
                    valid ``_asset_env`` constant.
        """
        self._validate_enum(value, "environment", _asset_env._valid)
        self._environment = value
        return self

    def set_hosting_type(self, value: int) -> CyverAsset:
        """
            Set the asset hosting type.

            The value must be a valid ``_asset_hosting`` constant.

            Args:
                value (int): A ``_asset_hosting`` constant (e.g.
                    ``_asset_hosting.azure`` or ``1`` for Azure).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not a
                    valid ``_asset_hosting`` constant.
        """
        self._validate_enum(value, "hostingType", _asset_hosting._valid)
        self._hosting_type = value
        return self

    def set_public_facing(self, value: int) -> CyverAsset:
        """
            Set whether the asset is publicly accessible.

            The value must be a valid ``_asset_exposure`` constant.

            Args:
                value (int): A ``_asset_exposure`` constant (e.g.
                    ``_asset_exposure.external`` or ``2`` for External).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not a
                    valid ``_asset_exposure`` constant.
        """
        self._validate_enum(value, "publicFacing", _asset_exposure._valid)
        self._public_facing = value
        return self

    def set_type_hardware(self, value: int) -> CyverAsset:
        """
            Set the hardware device type (applicable when ``type`` is
            ``"Hardware Device"``).

            The value must be a valid ``_asset_hardware`` constant.

            Args:
                value (int): A ``_asset_hardware`` constant (e.g.
                    ``_asset_hardware.workstation`` or ``1`` for Workstation).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not a
                    valid ``_asset_hardware`` constant.
        """
        self._validate_enum(value, "typeHardware", _asset_hardware._valid)
        self._type_hardware = value
        return self

    # ------------------------------------------------------------------
    # Setters — plain int fields
    # ------------------------------------------------------------------

    def set_port(self, value: int) -> CyverAsset:
        """
            Set the network port number.

            Args:
                value (int): Port number.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'port' must be an int, got {type(value).__name__}.",
                field="port",
                reason="invalid_type",
            )
        self._port = value
        return self

    def set_testing_frequency(self, value: int) -> CyverAsset:
        """
            Set the testing frequency.

            Args:
                value (int): Testing frequency value as expected by the API.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'testingFrequency' must be an int, got {type(value).__name__}.",
                field="testingFrequency",
                reason="invalid_type",
            )
        self._testing_frequency = value
        return self

    # ------------------------------------------------------------------
    # Setters — plain string fields
    # ------------------------------------------------------------------

    def set_description(self, value: str) -> CyverAsset:
        """
            Set the asset description.

            Args:
                value (str): Free-text description.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'description' must be a string, got {type(value).__name__}.",
                field="description",
                reason="invalid_type",
            )
        self._description = value
        return self

    def set_domain(self, value: str) -> CyverAsset:
        """
            Set the asset domain name.

            Args:
                value (str): Domain name.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'domain' must be a string, got {type(value).__name__}.",
                field="domain",
                reason="invalid_type",
            )
        self._domain = value
        return self

    def set_ip(self, value: str) -> CyverAsset:
        """
            Set the asset IP address.

            Args:
                value (str): IP address string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'ip' must be a string, got {type(value).__name__}.",
                field="ip",
                reason="invalid_type",
            )
        self._ip = value
        return self

    def set_url(self, value: str) -> CyverAsset:
        """
            Set the asset URL.

            Args:
                value (str): URL string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'url' must be a string, got {type(value).__name__}.",
                field="url",
                reason="invalid_type",
            )
        self._url = value
        return self

    def set_ssid(self, value: str) -> CyverAsset:
        """
            Set the Wi-Fi SSID (applicable to Wifi Network assets).

            Args:
                value (str): SSID string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'ssid' must be a string, got {type(value).__name__}.",
                field="ssid",
                reason="invalid_type",
            )
        self._ssid = value
        return self

    def set_path(self, value: str) -> CyverAsset:
        """
            Set the asset path.

            Args:
                value (str): Path string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'path' must be a string, got {type(value).__name__}.",
                field="path",
                reason="invalid_type",
            )
        self._path = value
        return self

    def set_protocol(self, value: str) -> CyverAsset:
        """
            Set the network protocol.

            Args:
                value (str): Protocol string (e.g. ``"https"``).

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'protocol' must be a string, got {type(value).__name__}.",
                field="protocol",
                reason="invalid_type",
            )
        self._protocol = value
        return self

    def set_location(self, value: str) -> CyverAsset:
        """
            Set the asset physical or logical location.

            Args:
                value (str): Location description.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'location' must be a string, got {type(value).__name__}.",
                field="location",
                reason="invalid_type",
            )
        self._location = value
        return self

    def set_operating_system(self, value: str) -> CyverAsset:
        """
            Set the operating system.

            Args:
                value (str): OS name and version string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'operatingSystem' must be a string, got {type(value).__name__}.",
                field="operatingSystem",
                reason="invalid_type",
            )
        self._operating_system = value
        return self

    def set_vendor(self, value: str) -> CyverAsset:
        """
            Set the asset vendor name.

            Args:
                value (str): Vendor name.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'vendor' must be a string, got {type(value).__name__}.",
                field="vendor",
                reason="invalid_type",
            )
        self._vendor = value
        return self

    def set_product(self, value: str) -> CyverAsset:
        """
            Set the asset product name.

            Args:
                value (str): Product name.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'product' must be a string, got {type(value).__name__}.",
                field="product",
                reason="invalid_type",
            )
        self._product = value
        return self

    def set_version(self, value: str) -> CyverAsset:
        """
            Set the asset version string.

            Args:
                value (str): Version identifier.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'version' must be a string, got {type(value).__name__}.",
                field="version",
                reason="invalid_type",
            )
        self._version = value
        return self

    def set_commit(self, value: str) -> CyverAsset:
        """
            Set the source-code commit reference.

            Args:
                value (str): Commit hash or reference string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'commit' must be a string, got {type(value).__name__}.",
                field="commit",
                reason="invalid_type",
            )
        self._commit = value
        return self

    def set_lines_of_code(self, value: str) -> CyverAsset:
        """
            Set the lines-of-code metric.

            Args:
                value (str): Lines-of-code count as a string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'linesOfCode' must be a string, got {type(value).__name__}.",
                field="linesOfCode",
                reason="invalid_type",
            )
        self._lines_of_code = value
        return self

    def set_repository(self, value: str) -> CyverAsset:
        """
            Set the source-code repository URL or identifier.

            Args:
                value (str): Repository URL or name.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'repository' must be a string, got {type(value).__name__}.",
                field="repository",
                reason="invalid_type",
            )
        self._repository = value
        return self

    def set_technology(self, value: str) -> CyverAsset:
        """
            Set the technology stack description.

            Args:
                value (str): Technology name or stack description.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'technology' must be a string, got {type(value).__name__}.",
                field="technology",
                reason="invalid_type",
            )
        self._technology = value
        return self

    def set_domain_ad(self, value: str) -> CyverAsset:
        """
            Set the Active Directory domain name.

            Args:
                value (str): AD domain name string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'domainAD' must be a string, got {type(value).__name__}.",
                field="domainAD",
                reason="invalid_type",
            )
        self._domain_ad = value
        return self

    def set_username(self, value: str) -> CyverAsset:
        """
            Set the username (required for assets of type ``"User"`` (12)).

            Args:
                value (str): Username string.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'username' must be a string, got {type(value).__name__}.",
                field="username",
                reason="invalid_type",
            )
        self._username = value
        return self

    # ------------------------------------------------------------------
    # Setters — UUID list
    # ------------------------------------------------------------------

    def add_label_id(self, value: str) -> CyverAsset:
        """
            Append a label UUID to the label ID list.

            Can be called multiple times to build up the list incrementally.
            Use ``set_label_id_list()`` to replace the entire list at once.

            Args:
                value (str): A well-formed UUID string identifying a label.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or is not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each entry in 'labelIdList' must be a string, "
                f"got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "labelIdList")
        self._label_id_list.append(value)
        return self

    def set_label_id_list(self, value: list[str]) -> CyverAsset:
        """
            Replace the label ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverAsset: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list``, or if any
                    element is not a well-formed UUID string.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'labelIdList' must be a list, got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'labelIdList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="labelIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"labelIdList[{i}]")
        self._label_id_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def _validate_type_required_fields(self) -> None:
        """Check that all fields required by the current asset type are set.

        Uses the mapping defined in ``_TYPE_REQUIRED_FIELDS`` alongside
        ``set_type()``. Does nothing when ``type`` has not been set yet.

        Raises:
            CyverDataValidationError: If a field required by the current type is absent.
        """
        if self._type is None:
            return
        required = self._TYPE_REQUIRED_FIELDS.get(self._type, [])
        field_attrs: dict[str, str] = {
            "url":        "_url",
            "path":       "_path",
            "ip":         "_ip",
            "ssid":       "_ssid",
            "domain":     "_domain",
            "repository": "_repository",
            "username":   "_username",
        }
        for field in required:
            if getattr(self, field_attrs[field]) is None:
                type_name = _asset_type._names.get(self._type, str(self._type))
                raise CyverDataValidationError(
                    f"'{field}' is required for assets of type "
                    f"'{type_name}' ({self._type}). "
                    f"Call set_{field}() before dispatching.",
                    field=field,
                    reason="missing_required",
                )

    def validate_for_post(self) -> None:
        """
            Validate that all fields required for a POST (create) request
            are present.

            Checks that ``title`` is set, then enforces any additional fields
            required by the current ``type`` value (see ``set_type()`` for the
            per-type requirements).

            Raises:
                CyverDataValidationError: If ``title`` is empty, or if a field required
                    by the current asset type is absent.
        """
        if not self._title:
            raise CyverDataValidationError(
                "'title' is required for POST requests and must not be empty.",
                field="title",
                reason="missing_required",
            )
        self._validate_type_required_fields()

    def validate_for_put(self) -> None:
        """
            Validate that all fields required for a PUT (update) request
            are present.

            In addition to the POST requirements, ``type`` must also be set.
            The type-specific required fields are then checked as well.

            Raises:
                CyverDataValidationError: If ``title`` is empty, ``type`` is not set,
                    or a field required by the asset type is absent.
        """
        if not self._title:
            raise CyverDataValidationError(
                "'title' is required for PUT requests and must not be empty.",
                field="title",
                reason="missing_required",
            )
        if self._type is None:
            raise CyverDataValidationError(
                "'type' is required for PUT requests. "
                "Call set_type() before dispatching.",
                field="type",
                reason="missing_required",
            )
        self._validate_type_required_fields()

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the asset data to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included in the
            output. The ``title`` field is always present as it is required
            at construction time.

            Returns:
                dict: Asset payload with camelCase API keys, suitable for
                    use as the ``data`` argument to ``_send_api_request()``.
        """
        result: dict = {"title": self._title}
        if self._type is not None:
            result["type"] = self._type
        if self._description is not None:
            result["description"] = self._description
        if self._domain is not None:
            result["domain"] = self._domain
        if self._ip is not None:
            result["ip"] = self._ip
        if self._url is not None:
            result["url"] = self._url
        if self._port is not None:
            result["port"] = self._port
        if self._ssid is not None:
            result["ssid"] = self._ssid
        if self._path is not None:
            result["path"] = self._path
        if self._protocol is not None:
            result["protocol"] = self._protocol
        if self._location is not None:
            result["location"] = self._location
        if self._operating_system is not None:
            result["operatingSystem"] = self._operating_system
        if self._vendor is not None:
            result["vendor"] = self._vendor
        if self._product is not None:
            result["product"] = self._product
        if self._version is not None:
            result["version"] = self._version
        if self._commit is not None:
            result["commit"] = self._commit
        if self._lines_of_code is not None:
            result["linesOfCode"] = self._lines_of_code
        if self._repository is not None:
            result["repository"] = self._repository
        if self._technology is not None:
            result["technology"] = self._technology
        if self._domain_ad is not None:
            result["domainAD"] = self._domain_ad
        if self._username is not None:
            result["username"] = self._username
        if self._testing_frequency is not None:
            result["testingFrequency"] = self._testing_frequency
        if self._public_facing is not None:
            result["publicFacing"] = self._public_facing
        if self._type_hardware is not None:
            result["typeHardware"] = self._type_hardware
        if self._hosting_type is not None:
            result["hostingType"] = self._hosting_type
        if self._environment is not None:
            result["environment"] = self._environment
        if self._label_id_list:
            result["labelIdList"] = list(self._label_id_list)
        return result

    # ------------------------------------------------------------------
    # Server-assigned identity
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """The server-assigned UUID of this asset, populated by
        ``from_dict()`` when the object is constructed from an API
        response. ``None`` for objects created locally before dispatch."""
        return self._id

    @property
    def title(self) -> str:
        """The asset's display name."""
        return self._title

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverAsset:
        """
            Construct a ``CyverAsset`` from an API response dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly (bypassing setters) so that values already
            validated by the server are not re-validated on ingestion.

            Args:
                data (dict): An asset dict as returned by the Cyver API
                    (e.g. from ``get_assets_by_client_id()``).

            Returns:
                CyverAsset: A fully populated instance. ``id`` is set to
                    the server-assigned UUID when present in *data*.
        """
        obj = cls(data["title"])
        obj._id = data.get("id")
        obj._type = data.get("type")
        obj._description = data.get("description")
        obj._domain = data.get("domain")
        obj._ip = data.get("ip")
        obj._url = data.get("url")
        obj._port = data.get("port")
        obj._ssid = data.get("ssid")
        obj._path = data.get("path")
        obj._protocol = data.get("protocol")
        obj._location = data.get("location")
        obj._operating_system = data.get("operatingSystem")
        obj._vendor = data.get("vendor")
        obj._product = data.get("product")
        obj._version = data.get("version")
        obj._commit = data.get("commit")
        obj._lines_of_code = data.get("linesOfCode")
        obj._repository = data.get("repository")
        obj._technology = data.get("technology")
        obj._domain_ad = data.get("domainAD")
        obj._username = data.get("username")
        obj._testing_frequency = data.get("testingFrequency")
        obj._public_facing = data.get("publicFacing")
        obj._type_hardware = data.get("typeHardware")
        obj._hosting_type = data.get("hostingType")
        obj._environment = data.get("environment")
        obj._label_id_list = list(data.get("labelIdList") or [])
        return obj

    def __repr__(self) -> str:
        set_fields = ["title"]
        if self._type is not None:
            set_fields.append(f"type={self._type}")
        for attr, key in [
            (self._description, "description"),
            (self._domain, "domain"),
            (self._ip, "ip"),
            (self._url, "url"),
            (self._port, "port"),
            (self._ssid, "ssid"),
            (self._path, "path"),
            (self._protocol, "protocol"),
            (self._location, "location"),
            (self._operating_system, "operatingSystem"),
            (self._vendor, "vendor"),
            (self._product, "product"),
            (self._version, "version"),
            (self._commit, "commit"),
            (self._lines_of_code, "linesOfCode"),
            (self._repository, "repository"),
            (self._technology, "technology"),
            (self._domain_ad, "domainAD"),
            (self._username, "username"),
            (self._testing_frequency, "testingFrequency"),
            (self._public_facing, "publicFacing"),
            (self._type_hardware, "typeHardware"),
            (self._hosting_type, "hostingType"),
            (self._environment, "environment"),
        ]:
            if attr is not None:
                set_fields.append(key)
        if self._label_id_list:
            set_fields.append(f"labelIdList[{len(self._label_id_list)}]")
        prefix = f"id={self._id!r}, " if self._id else ""
        return f"CyverAsset({prefix}title={self._title!r}, fields={set_fields})"
