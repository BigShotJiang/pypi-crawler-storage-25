#!/usr/bin/env python3

from __future__ import annotations

from ..Utils import (
    _fd_require_id,
    _fd_optional_str,
    _fd_optional_int,
    _fd_uuid_list,
)


class CyverComplianceTemplate:
    """
        Read-only representation of a Compliance Template as returned by the
        Cyver API.

        Instances are constructed exclusively via ``from_dict()``, which
        validates every field's type and enforces the single mandatory field
        (``id``). No setter methods are provided because these objects are
        never written back to the API.

        Attributes:
            id (str): Server-assigned UUID of the template.
            status (int | None): Numeric status code of the template.
            code (str | None): Short compliance code (e.g. ``"ISO27001"``).
            name (str | None): Display name of the template.
            description (str | None): Human-readable description.
            control_group_list (list[str]): List of control-group UUIDs
                attached to the template. Empty list when absent in the
                API response.
    """

    def __init__(
        self,
        id: str,
        status: int | None,
        code: str | None,
        name: str | None,
        description: str | None,
        control_group_list: list[str],
    ) -> None:
        self._id = id
        self._status = status
        self._code = code
        self._name = name
        self._description = description
        self._control_group_list = control_group_list

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        """Server-assigned UUID of the template."""
        return self._id

    @property
    def status(self) -> int | None:
        """Numeric status code of the template."""
        return self._status

    @property
    def code(self) -> str | None:
        """Short compliance code (e.g. ``"ISO27001"``)."""
        return self._code

    @property
    def name(self) -> str | None:
        """Display name of the template."""
        return self._name

    @property
    def description(self) -> str | None:
        """Human-readable description of the template."""
        return self._description

    @property
    def control_group_list(self) -> list[str]:
        """List of control-group UUIDs attached to the template."""
        return list(self._control_group_list)

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverComplianceTemplate:
        """
            Construct a ``CyverComplianceTemplate`` from an API response dict.

            Validates that ``id`` is present and a valid UUID, and that all
            other recognised fields conform to their expected types.

            Args:
                data (dict): A compliance-template dict as returned by the
                    Cyver API.

            Returns:
                CyverComplianceTemplate: A fully populated, read-only instance.

            Raises:
                CyverDataValidationError: If ``id`` is missing or not a valid UUID, or
                    if any other field has an unexpected type.
        """
        return cls(
            id=_fd_require_id(data),
            status=_fd_optional_int(data, "status"),
            code=_fd_optional_str(data, "code"),
            name=_fd_optional_str(data, "name"),
            description=_fd_optional_str(data, "description"),
            control_group_list=_fd_uuid_list(data, "controlGroupList"),
        )

    def __repr__(self) -> str:
        return (
            f"CyverComplianceTemplate(id={self._id!r}, code={self._code!r}, "
            f"name={self._name!r})"
        )
