#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _validate_uuid,
    _fd_optional_str,
    _fd_optional_int,
    _fd_optional_uuid,
    _fd_nested_list,
)
from .CyverReportTemplateSection import CyverReportTemplateSection


class CyverReportTemplate:
    """
        Data builder and read-only representation of a Report Template.

        Serves a dual role:

        * **Read path** — returned by ``get_report_templates()`` and
          ``get_all_report_templates()``.  Instances are constructed via
          :meth:`from_dict` from the template-catalogue API response, which
          supplies ``id``, ``title``, ``status``, and
          ``reportTemplateSectionList``.

        * **Write path** — used as an entry in :class:`CyverProject`'s
          ``reportTemplates`` list when building a project request body.
          Construct with no arguments and populate via the fluent setter
          interface.

        **Synced field pairs** — the two pairs ``(id, report_template_id)``
        and ``(name, title)`` always carry the same value.  Setting either
        member of a pair automatically updates the other:

        * :meth:`set_id` and :meth:`set_report_template_id` — both store the
          same UUID in ``_id`` and ``_report_template_id``.
        * :meth:`set_name` and :meth:`set_title` — both store the same
          string in ``_name`` and ``_title``.

        Typical write-path usage::

            from CyverReporting import CyverReportTemplate

            rt = (
                CyverReportTemplate()
                .set_report_template_id("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")
                .set_name("Executive Summary")
                .set_project_id("yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy")
            )
    """

    def __init__(self) -> None:
        self._id: str | None = None               # synced with _report_template_id
        self._report_template_id: str | None = None  # synced with _id
        self._name: str | None = None             # synced with _title
        self._title: str | None = None            # synced with _name
        self._project_id: str | None = None
        self._status: int | None = None
        self._report_template_section_list: list[CyverReportTemplateSection] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """UUID of the report template (synced with :attr:`report_template_id`)."""
        return self._id

    @property
    def report_template_id(self) -> str | None:
        """UUID of the report template (synced with :attr:`id`)."""
        return self._report_template_id

    @property
    def name(self) -> str | None:
        """Display name of the template (synced with :attr:`title`)."""
        return self._name

    @property
    def title(self) -> str | None:
        """Display name of the template (synced with :attr:`name`)."""
        return self._title

    @property
    def project_id(self) -> str | None:
        """UUID of the project this template is linked to."""
        return self._project_id

    @property
    def status(self) -> int | None:
        """Numeric status code."""
        return self._status

    @property
    def report_template_section_list(self) -> list[CyverReportTemplateSection]:
        """Ordered list of sections belonging to this template."""
        return list(self._report_template_section_list)

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_id(self, value: str) -> "CyverReportTemplate":
        """
            Set the report template UUID.

            Also sets :attr:`report_template_id` to the same value.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'id' must be a string, got {type(value).__name__}.",
                field="id",
                reason="invalid_type",
            )
        _validate_uuid(value, "id")
        self._id = value
        self._report_template_id = value
        return self

    def set_report_template_id(self, value: str) -> "CyverReportTemplate":
        """
            Set the report template UUID.

            Also sets :attr:`id` to the same value.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reportTemplateId' must be a string, got {type(value).__name__}.",
                field="reportTemplateId",
                reason="invalid_type",
            )
        _validate_uuid(value, "reportTemplateId")
        self._report_template_id = value
        self._id = value
        return self

    def set_name(self, value: str) -> "CyverReportTemplate":
        """
            Set the display name of the report template.

            Also sets :attr:`title` to the same value.

            Args:
                value (str): Template name string.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'name' must be a string, got {type(value).__name__}.",
                field="name",
                reason="invalid_type",
            )
        self._name = value
        self._title = value
        return self

    def set_title(self, value: str) -> "CyverReportTemplate":
        """
            Set the display name of the report template.

            Also sets :attr:`name` to the same value.

            Args:
                value (str): Template title string.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'title' must be a string, got {type(value).__name__}.",
                field="title",
                reason="invalid_type",
            )
        self._title = value
        self._name = value
        return self

    def set_project_id(self, value: str) -> "CyverReportTemplate":
        """
            Set the UUID of the project this template is linked to.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a string or not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'projectId' must be a string, got {type(value).__name__}.",
                field="projectId",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectId")
        self._project_id = value
        return self

    def set_status(self, value: int) -> "CyverReportTemplate":
        """
            Set the template status code.

            Args:
                value (int): Integer status code.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``, or is a
                    ``bool``.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'status' must be an int, got {type(value).__name__}.",
                field="status",
                reason="invalid_type",
            )
        self._status = value
        return self

    def add_report_template_section(
        self, value: CyverReportTemplateSection
    ) -> "CyverReportTemplate":
        """
            Append a section to the report template section list.

            Args:
                value (CyverReportTemplateSection): A populated section
                    instance.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    ``CyverReportTemplateSection``.
        """
        if not isinstance(value, CyverReportTemplateSection):
            raise CyverDataValidationError(
                f"Each entry in 'reportTemplateSectionList' must be a "
                f"CyverReportTemplateSection, got {type(value).__name__}.",
                field="reportTemplateSectionList",
                reason="invalid_type",
            )
        self._report_template_section_list.append(value)
        return self

    def set_report_template_section_list(
        self, value: list[CyverReportTemplateSection]
    ) -> "CyverReportTemplate":
        """
            Replace the section list with the provided list.

            Args:
                value (list[CyverReportTemplateSection]): A list of section
                    instances.

            Returns:
                CyverReportTemplate: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a list, or if any
                    element is not a ``CyverReportTemplateSection``.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'reportTemplateSectionList' must be a list, got {type(value).__name__}.",
                field="reportTemplateSectionList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, CyverReportTemplateSection):
                raise CyverDataValidationError(
                    f"'reportTemplateSectionList[{i}]' must be a "
                    f"CyverReportTemplateSection, got {type(item).__name__}.",
                    field="reportTemplateSectionList",
                    reason="invalid_type",
                )
        self._report_template_section_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included.  Because
            ``id``/``reportTemplateId`` are always in sync, both keys are
            emitted when the UUID is set.  Likewise, ``name`` is the key
            emitted for the synced name/title value (the project API uses
            ``"name"`` rather than ``"title"``).

            Returns:
                dict: Report-template payload with camelCase API keys.
        """
        result: dict = {}
        if self._id is not None:
            result["id"] = self._id
            result["reportTemplateId"] = self._report_template_id
        if self._name is not None:
            result["name"] = self._name
        if self._project_id is not None:
            result["projectId"] = self._project_id
        if self._status is not None:
            result["status"] = self._status
        if self._report_template_section_list:
            result["reportTemplateSectionList"] = [
                s.to_dict() for s in self._report_template_section_list
            ]
        return result

    def __repr__(self) -> str:
        parts = []
        if self._id is not None:
            parts.append(f"id={self._id!r}")
        if self._name is not None:
            parts.append(f"name={self._name!r}")
        if self._project_id is not None:
            parts.append(f"projectId={self._project_id!r}")
        if self._status is not None:
            parts.append(f"status={self._status!r}")
        if self._report_template_section_list:
            parts.append(f"sections={len(self._report_template_section_list)}")
        return f"CyverReportTemplate({', '.join(parts)})"

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "CyverReportTemplate":
        """
            Construct a ``CyverReportTemplate`` from an API response dict.

            Handles both response shapes:

            * **Template catalogue** (``GET /report-templates``): supplies
              ``id``, ``title``, ``status``, ``reportTemplateSectionList``.
            * **Project** ``reportTemplates`` **list**: supplies ``id``,
              ``name``, ``projectId``, ``reportTemplateId``.

            The synced pairs are resolved as follows:

            * UUID — ``reportTemplateId`` is preferred when present; otherwise
              ``id`` is used.  Both ``_id`` and ``_report_template_id`` are set
              to the resolved value.  Raises if neither key is present.
            * Name — ``title`` is preferred when present; otherwise ``name``
              is used.  Both ``_name`` and ``_title`` are set to the resolved
              value.

            Args:
                data (dict): A report-template dict as returned by the
                    Cyver API.

            Returns:
                CyverReportTemplate: A fully populated instance.

            Raises:
                CyverDataValidationError: If neither ``id`` nor
                    ``reportTemplateId`` is present or valid
                    (``field="id"``, ``reason="missing_required"``), or if any
                    field has an unexpected type.
        """
        obj = cls()
        # UUID sync — prefer reportTemplateId over id
        raw_id    = _fd_optional_uuid(data, "id")
        raw_rt_id = _fd_optional_uuid(data, "reportTemplateId")
        resolved_uuid = raw_rt_id if raw_rt_id is not None else raw_id
        if resolved_uuid is None:
            raise CyverDataValidationError(
                "Neither 'id' nor 'reportTemplateId' was found or valid in "
                "the response data.",
                field="id",
                reason="missing_required",
            )
        obj._id                 = resolved_uuid
        obj._report_template_id = resolved_uuid
        # name/title sync — prefer title over name
        raw_title = _fd_optional_str(data, "title")
        raw_name  = _fd_optional_str(data, "name")
        resolved_name = raw_title if raw_title is not None else raw_name
        obj._title = resolved_name
        obj._name  = resolved_name
        # remaining fields
        obj._project_id = _fd_optional_uuid(data, "projectId")
        obj._status     = _fd_optional_int(data, "status")
        obj._report_template_section_list = _fd_nested_list(
            data, "reportTemplateSectionList", CyverReportTemplateSection
        )
        return obj
