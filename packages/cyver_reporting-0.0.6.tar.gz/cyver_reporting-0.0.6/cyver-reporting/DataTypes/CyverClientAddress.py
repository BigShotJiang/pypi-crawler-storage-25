#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import _fd_optional_str


class CyverClientAddress:
    """
        Address sub-object used within ``CyverClientInformation``.

        All fields are optional. Only fields that have been explicitly set
        are included in the serialised dictionary produced by ``to_dict()``,
        so unset fields are never sent to the API.

        Typical usage::

            address = (
                CyverClientAddress()
                .set_street("123 Main St")
                .set_city("San Francisco")
                .set_country("United States")
                .set_postal_code("94105")
                .set_state_or_province("CA")
            )
    """

    def __init__(self) -> None:
        self._street: str | None = None
        self._postal_code: str | None = None
        self._city: str | None = None
        self._country: str | None = None
        self._state_or_province: str | None = None

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_street(self, value: str) -> CyverClientAddress:
        """
            Set the street line of the address.

            Args:
                value (str): Street name and number.

            Returns:
                CyverClientAddress: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'street' must be a string, got {type(value).__name__}.",
                field="street",
                reason="invalid_type",
            )
        self._street = value
        return self

    def set_postal_code(self, value: str) -> CyverClientAddress:
        """
            Set the postal or ZIP code.

            Args:
                value (str): Postal code.

            Returns:
                CyverClientAddress: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'postalCode' must be a string, got {type(value).__name__}.",
                field="postalCode",
                reason="invalid_type",
            )
        self._postal_code = value
        return self

    def set_city(self, value: str) -> CyverClientAddress:
        """
            Set the city name.

            Args:
                value (str): City name.

            Returns:
                CyverClientAddress: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'city' must be a string, got {type(value).__name__}.",
                field="city",
                reason="invalid_type",
            )
        self._city = value
        return self

    def set_country(self, value: str) -> CyverClientAddress:
        """
            Set the country name.

            Args:
                value (str): Country name.

            Returns:
                CyverClientAddress: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'country' must be a string, got {type(value).__name__}.",
                field="country",
                reason="invalid_type",
            )
        self._country = value
        return self

    def set_state_or_province(self, value: str) -> CyverClientAddress:
        """
            Set the state or province name.

            Args:
                value (str): State or province name.

            Returns:
                CyverClientAddress: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'stateOrProvince' must be a string, got {type(value).__name__}.",
                field="stateOrProvince",
                reason="invalid_type",
            )
        self._state_or_province = value
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the address to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included. An empty
            dictionary is returned if no fields have been set.

            Returns:
                dict: Address payload with camelCase API keys.
        """
        result: dict = {}
        if self._street is not None:
            result["street"] = self._street
        if self._postal_code is not None:
            result["postalCode"] = self._postal_code
        if self._city is not None:
            result["city"] = self._city
        if self._country is not None:
            result["country"] = self._country
        if self._state_or_province is not None:
            result["stateOrProvince"] = self._state_or_province
        return result

    def __repr__(self) -> str:
        set_fields = [
            k for k, v in {
                "street": self._street,
                "postalCode": self._postal_code,
                "city": self._city,
                "country": self._country,
                "stateOrProvince": self._state_or_province,
            }.items()
            if v is not None
        ]
        return f"CyverClientAddress(fields={set_fields})"

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverClientAddress:
        """
            Construct a ``CyverClientAddress`` from an API response dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly, bypassing setters so that server-returned
            values are not re-validated on ingestion.

            Args:
                data (dict): An address dict as returned by the Cyver API.

            Returns:
                CyverClientAddress: A populated instance. Fields absent from
                    *data* are left as ``None``.
        """
        obj = cls()
        obj._street           = _fd_optional_str(data, "street")
        obj._postal_code      = _fd_optional_str(data, "postalCode")
        obj._city             = _fd_optional_str(data, "city")
        obj._country          = _fd_optional_str(data, "country")
        obj._state_or_province = _fd_optional_str(data, "stateOrProvince")
        return obj
