#!/usr/bin/env python3

from __future__ import annotations

from ..Utils import (
    _fd_require_id,
    _fd_optional_str,
    _fd_optional_bool,
    _fd_optional_int,
)


class CyverReportTemplateSection:
    """
        Read-only representation of a Report Template Section as returned
        by the Cyver API.

        Instances are constructed exclusively via ``from_dict()``, which
        validates every field's type and enforces the single mandatory field
        (``id``). No setter methods are provided because these objects are
        never written back to the API.

        Attributes:
            id (str): Server-assigned UUID of the section.
            title (str | None): Display title of the section.
            hide_from_client_portal (bool | None): When ``True``, this
                section is hidden from the client-facing portal view.
            content (str | None): Raw content body of the section.
            is_in_external_download (bool | None): When ``True``, this
                section is included in external report downloads.
            order (int | None): Numeric position of the section within the
                template.
            section_type (int | None): Numeric code identifying the section
                type.
            table_of_contents_depth (int | None): Heading depth included
                when this section is rendered in the table of contents.
            table_of_contents_internal_links (bool | None): When ``True``,
                internal anchor links are generated for this section in the
                table of contents.
            optional (bool | None): When ``True``, this section may be
                omitted from a generated report.
    """

    def __init__(
        self,
        id: str,
        title: str | None,
        hide_from_client_portal: bool | None,
        content: str | None,
        is_in_external_download: bool | None,
        order: int | None,
        section_type: int | None,
        table_of_contents_depth: int | None,
        table_of_contents_internal_links: bool | None,
        optional: bool | None,
    ) -> None:
        self._id = id
        self._title = title
        self._hide_from_client_portal = hide_from_client_portal
        self._content = content
        self._is_in_external_download = is_in_external_download
        self._order = order
        self._section_type = section_type
        self._table_of_contents_depth = table_of_contents_depth
        self._table_of_contents_internal_links = table_of_contents_internal_links
        self._optional = optional

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        """Server-assigned UUID of the section."""
        return self._id

    @property
    def title(self) -> str | None:
        """Display title of the section."""
        return self._title

    @property
    def hide_from_client_portal(self) -> bool | None:
        """When ``True``, this section is hidden from the client portal."""
        return self._hide_from_client_portal

    @property
    def content(self) -> str | None:
        """Raw content body of the section."""
        return self._content

    @property
    def is_in_external_download(self) -> bool | None:
        """When ``True``, included in external report downloads."""
        return self._is_in_external_download

    @property
    def order(self) -> int | None:
        """Numeric position of the section within the template."""
        return self._order

    @property
    def section_type(self) -> int | None:
        """Numeric code identifying the section type."""
        return self._section_type

    @property
    def table_of_contents_depth(self) -> int | None:
        """Heading depth included in the table of contents."""
        return self._table_of_contents_depth

    @property
    def table_of_contents_internal_links(self) -> bool | None:
        """When ``True``, internal anchor links are generated in the ToC."""
        return self._table_of_contents_internal_links

    @property
    def optional(self) -> bool | None:
        """When ``True``, this section may be omitted from a generated report."""
        return self._optional

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set (non-``None``) are
            included.  ``id`` is always present.

            Returns:
                dict: Section payload with camelCase API keys.
        """
        result: dict = {"id": self._id}
        if self._title is not None:
            result["title"] = self._title
        if self._hide_from_client_portal is not None:
            result["hideFromClientPortal"] = self._hide_from_client_portal
        if self._content is not None:
            result["content"] = self._content
        if self._is_in_external_download is not None:
            result["isInExternalDownload"] = self._is_in_external_download
        if self._order is not None:
            result["order"] = self._order
        if self._section_type is not None:
            result["sectionType"] = self._section_type
        if self._table_of_contents_depth is not None:
            result["tableOfContentsDepth"] = self._table_of_contents_depth
        if self._table_of_contents_internal_links is not None:
            result["tableOfContentsInternalLinks"] = self._table_of_contents_internal_links
        if self._optional is not None:
            result["optional"] = self._optional
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverReportTemplateSection:
        """
            Construct a ``CyverReportTemplateSection`` from an API response
            dict.

            Validates that ``id`` is present and a valid UUID, and that all
            other recognised fields conform to their expected types.

            Args:
                data (dict): A report-template-section dict as returned by
                    the Cyver API.

            Returns:
                CyverReportTemplateSection: A fully populated, read-only
                    instance.

            Raises:
                CyverDataValidationError: If ``id`` is missing or not a valid UUID, or
                    if any other field has an unexpected type.
        """
        return cls(
            id=_fd_require_id(data),
            title=_fd_optional_str(data, "title"),
            hide_from_client_portal=_fd_optional_bool(data, "hideFromClientPortal"),
            content=_fd_optional_str(data, "content"),
            is_in_external_download=_fd_optional_bool(data, "isInExternalDownload"),
            order=_fd_optional_int(data, "order"),
            section_type=_fd_optional_int(data, "sectionType"),
            table_of_contents_depth=_fd_optional_int(data, "tableOfContentsDepth"),
            table_of_contents_internal_links=_fd_optional_bool(data, "tableOfContentsInternalLinks"),
            optional=_fd_optional_bool(data, "optional"),
        )

    def __repr__(self) -> str:
        return (
            f"CyverReportTemplateSection(id={self._id!r}, "
            f"title={self._title!r}, order={self._order!r})"
        )
