#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import _fd_optional_str
from .CyverClientAddress import CyverClientAddress


class CyverClientInformation:
    """
        Company information sub-object used within ``CyverClient``.

        All fields are optional. Only fields that have been explicitly set
        are included in the serialised dictionary produced by ``to_dict()``.

        Typical usage::

            info = (
                CyverClientInformation()
                .set_company_name("Acme Corp")
                .set_website("https://acme.example.com")
                .set_address(
                    CyverClientAddress()
                    .set_city("San Francisco")
                    .set_country("United States")
                )
            )
    """

    def __init__(self) -> None:
        self._company_name: str | None = None
        self._website: str | None = None
        self._address: CyverClientAddress | None = None

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_company_name(self, value: str) -> CyverClientInformation:
        """
            Set the company's legal or trading name.

            Args:
                value (str): Company name.

            Returns:
                CyverClientInformation: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'companyName' must be a string, got {type(value).__name__}.",
                field="companyName",
                reason="invalid_type",
            )
        self._company_name = value
        return self

    def set_website(self, value: str) -> CyverClientInformation:
        """
            Set the company's website URL.

            Args:
                value (str): Website URL.

            Returns:
                CyverClientInformation: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'website' must be a string, got {type(value).__name__}.",
                field="website",
                reason="invalid_type",
            )
        self._website = value
        return self

    def set_address(self, value: CyverClientAddress) -> CyverClientInformation:
        """
            Set the company's physical address.

            Args:
                value (CyverClientAddress): A populated ``CyverClientAddress``
                    instance.

            Returns:
                CyverClientInformation: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``CyverClientAddress``
                    instance.
        """
        if not isinstance(value, CyverClientAddress):
            raise CyverDataValidationError(
                f"'address' must be a CyverClientAddress instance, "
                f"got {type(value).__name__}.",
                field="address",
                reason="invalid_type",
            )
        self._address = value
        return self

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the company information to a dictionary for the Cyver API.

            Only fields that have been explicitly set are included.

            Returns:
                dict: Client information payload with camelCase API keys.
        """
        result: dict = {}
        if self._company_name is not None:
            result["companyName"] = self._company_name
        if self._website is not None:
            result["website"] = self._website
        if self._address is not None:
            address_dict = self._address.to_dict()
            if address_dict:
                result["address"] = address_dict
        return result

    def __repr__(self) -> str:
        set_fields = [
            k for k, v in {
                "companyName": self._company_name,
                "website": self._website,
                "address": self._address,
            }.items()
            if v is not None
        ]
        return f"CyverClientInformation(fields={set_fields})"

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverClientInformation:
        """
            Construct a ``CyverClientInformation`` from an API response
            dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly, bypassing setters so that server-returned
            values are not re-validated on ingestion. A nested ``address``
            dict, if present, is deserialised via
            :meth:`CyverClientAddress.from_dict`.

            Args:
                data (dict): A ``clientInformation`` dict as returned by the
                    Cyver API (e.g. from ``get_client_by_id()``).

            Returns:
                CyverClientInformation: A populated instance. Fields absent
                    from *data* are left as ``None``.
        """
        obj = cls()
        obj._company_name = _fd_optional_str(data, "companyName")
        obj._website      = _fd_optional_str(data, "website")
        addr_data = data.get("address")
        if addr_data:
            obj._address = CyverClientAddress.from_dict(addr_data)
        return obj
