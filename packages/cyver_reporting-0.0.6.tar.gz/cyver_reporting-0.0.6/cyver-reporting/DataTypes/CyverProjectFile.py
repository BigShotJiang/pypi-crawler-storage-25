#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _sentinels_uuid,
    _fd_optional_bool,
    _fd_optional_int,
    _fd_optional_str,
    _fd_optional_uuid,
    _fd_optional_datetime,
    _validate_project_file_type,
    _validate_uuid,
)


class CyverProjectFile:
    """
        Data-builder for the portal-surface project-file API endpoints.

        Models the JSON shape returned by ``GET /Project/GetAllProjectFiles`` /
        ``GET /Project/GetProjectImagesFiles`` and accepted by
        ``PUT /Project/UpdateProjectFile``.  ``DELETE /Project/DeleteProjectFile``
        takes the ``guid`` from an instance of this class via its URL query
        parameter.

        The universally mandatory fields — ``fileName``, ``fileSize``, and
        ``type`` — are required at construction.  ``guid`` (serialised as
        ``fileId`` on update requests) is mandatory for PUT and is populated
        from the server response via :meth:`from_dict`; no public setter is
        provided because it is server-assigned at upload time and must not be
        changed afterwards.

        The same immutability rule applies to ``fileName``, ``fileSize``,
        ``mimeType``, ``uploadedAt``, ``uploadedBy``, and ``downloadLink`` —
        all of them are server-managed and exposed only through
        :meth:`from_dict`.  The four caller-modifiable fields
        (``caption``, ``description``, ``visibleToClient``, and
        ``additionalGuid``) have dedicated setters and default to sensible
        "unset-but-present" values (``""``, ``""``, ``False``, ``None``) so
        :meth:`to_dict` always produces a complete update payload.

        ``additionalGuid`` uses the portal-surface convention of the zero
        GUID (``"00000000-0000-0000-0000-000000000000"``) as the "unset"
        sentinel.  The sentinel is handled transparently by
        :func:`_fd_optional_uuid` on the way in and by :meth:`to_dict` on
        the way out — Python code always sees and sets ``None`` for unset.

        ``type`` is validated against :class:`_project_file_type`, which
        covers every file kind the Cyver API recognises — image-category
        attachments (evidence, report, etc.), scanner imports (Burp,
        Nessus, Qualys, etc.), invoices, indemnities, and so on.  Server
        responses carrying a code that is not in
        :attr:`_project_file_type._valid` will raise from
        :meth:`from_dict`.

        All setter methods return ``self`` for fluent chaining::

            file = cyver_project_file                    # hydrated from GET
            updated = (
                file
                .set_caption("Screenshot from step 3")
                .set_description("Payload delivered via POST body")
                .set_visible_to_client(True)
            )
            payload = updated.to_dict()                  # ready for PUT body

        Args:
            file_name (str): The uploaded file's display name.  Must be a
                non-empty string.
            file_size (int): File size in bytes.  Must be a non-negative
                integer (``bool`` is rejected).
            file_type (int): Code from :class:`_project_file_type`.  The
                full set of valid codes lives in
                :attr:`_project_file_type._valid`; named aliases like
                ``_project_file_type.evidence`` or
                ``_project_file_type.import_qualys_scan_report`` evaluate
                to their integer code and can be passed directly.

        Raises:
            CyverDataValidationError: If any of the three mandatory fields
                fails its validation check.
    """

    def __init__(self, file_name: str, file_size: int, file_type: int) -> None:
        if not isinstance(file_name, str) or not file_name:
            raise CyverDataValidationError(
                "'fileName' must be a non-empty string.",
                field="fileName",
                reason="invalid_type" if not isinstance(file_name, str) else "missing_required",
            )
        if isinstance(file_size, bool) or not isinstance(file_size, int):
            raise CyverDataValidationError(
                f"'fileSize' must be an int, got {type(file_size).__name__}.",
                field="fileSize",
                reason="invalid_type",
            )
        if file_size < 0:
            raise CyverDataValidationError(
                f"'fileSize' must be non-negative, got {file_size}.",
                field="fileSize",
                reason="invalid_value",
            )
        _validate_project_file_type(file_type, "type")

        # Universally mandatory — server-managed, no public setter.
        self._file_name: str = file_name
        self._file_size: int = file_size
        self._file_type: int = file_type

        # Mandatory only for PUT — populated by from_dict, no public setter.
        self._guid: str | None = None

        # Optional server-managed fields — no public setter.
        self._mime_type:     str | None = None
        self._uploaded_at:   str | None = None
        self._uploaded_by:   str | None = None
        self._download_link: str | None = None

        # Caller-modifiable fields — default to "unset-but-present" so
        # to_dict() always produces a complete update payload.  Callers
        # mutate them via the setters below.
        self._additional_guid:   str | None = None   # zero-GUID ↔ None at the boundary
        self._visible_to_client: bool       = False
        self._caption:           str        = ""
        self._description:       str        = ""

    # ------------------------------------------------------------------
    # Read-only properties — expose server-managed fields
    # ------------------------------------------------------------------

    @property
    def guid(self) -> str | None:
        return self._guid

    @property
    def file_name(self) -> str:
        return self._file_name

    @property
    def file_size(self) -> int:
        return self._file_size

    @property
    def file_type(self) -> int:
        return self._file_type

    @property
    def mime_type(self) -> str | None:
        return self._mime_type

    @property
    def uploaded_at(self) -> str | None:
        return self._uploaded_at

    @property
    def uploaded_by(self) -> str | None:
        return self._uploaded_by

    @property
    def download_link(self) -> str | None:
        return self._download_link

    @property
    def additional_guid(self) -> str | None:
        return self._additional_guid

    @property
    def visible_to_client(self) -> bool:
        return self._visible_to_client

    @property
    def caption(self) -> str:
        return self._caption

    @property
    def description(self) -> str:
        return self._description

    # ------------------------------------------------------------------
    # Setters — caller-modifiable fields only
    # ------------------------------------------------------------------

    def set_caption(self, value: str) -> CyverProjectFile:
        """
            Set the file's caption.

            Empty strings are accepted explicitly so callers can clear a
            previously-populated caption server-side.

            Args:
                value (str): Caption text (may be empty).

            Returns:
                CyverProjectFile: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'caption' must be a string, got {type(value).__name__}.",
                field="caption",
                reason="invalid_type",
            )
        self._caption = value
        return self

    def set_description(self, value: str) -> CyverProjectFile:
        """
            Set the file's description.

            Empty strings are accepted explicitly so callers can clear a
            previously-populated description server-side.

            Args:
                value (str): Description text (may be empty).

            Returns:
                CyverProjectFile: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'description' must be a string, got {type(value).__name__}.",
                field="description",
                reason="invalid_type",
            )
        self._description = value
        return self

    def set_visible_to_client(self, value: bool) -> CyverProjectFile:
        """
            Set whether the file is visible to client-role users on the
            portal.

            Args:
                value (bool): ``True`` to expose the file to clients,
                    ``False`` to restrict it to pentester-role users.

            Returns:
                CyverProjectFile: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a ``bool``.
                    (``int`` values such as ``0`` / ``1`` are rejected even
                    though ``bool`` is an ``int`` subclass.)
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'visibleToClient' must be a bool, got {type(value).__name__}.",
                field="visibleToClient",
                reason="invalid_type",
            )
        self._visible_to_client = value
        return self

    def set_additional_guid(self, value: str | None) -> CyverProjectFile:
        """
            Set the auxiliary GUID associated with this file.

            The field's meaning varies with ``type`` (and is not fully
            documented) — typically it references another entity the file
            relates to.  Passing ``None`` — or the zero-GUID sentinel
            (``"00000000-0000-0000-0000-000000000000"``) — clears it; any
            other value is UUID-validated and stored verbatim.

            Args:
                value (str | None): A valid UUID string, ``None``, or the
                    zero-GUID sentinel.

            Returns:
                CyverProjectFile: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is a non-empty string
                    that is not a valid UUID.
        """
        if value is None or value in _sentinels_uuid:
            self._additional_guid = None
            return self
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'additionalGuid' must be a valid UUID string, got {type(value).__name__}.",
                field="additionalGuid",
                reason="invalid_uuid",
            )
        _validate_uuid(value, "additionalGuid")
        self._additional_guid = value
        return self

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Confirm every universally-mandatory field is populated.

            Trivially true after a successful construction (the constructor
            rejects missing / malformed values) but kept as a defensive
            check for instances produced via :meth:`from_dict` or direct
            private-attribute manipulation.

            Raises:
                CyverDataValidationError: If ``fileName``, ``fileSize`` or
                    ``type`` is missing.
        """
        if not self._file_name:
            raise CyverDataValidationError(
                "'fileName' is required and must not be empty.",
                field="fileName", reason="missing_required",
            )
        if self._file_size is None:
            raise CyverDataValidationError(
                "'fileSize' is required.",
                field="fileSize", reason="missing_required",
            )
        if self._file_type is None:
            raise CyverDataValidationError(
                "'type' is required.",
                field="type", reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Confirm every field required by the PUT update endpoint is
            populated.

            Runs :meth:`validate_for_post` first, then requires that
            ``guid`` has been populated — which only happens via
            :meth:`from_dict` after a GET, since there is no public
            ``set_guid``.

            Raises:
                CyverDataValidationError: If ``guid`` is missing, or any
                    POST-required field is missing.
        """
        self.validate_for_post()
        if not self._guid:
            raise CyverDataValidationError(
                "'guid' is required for PUT requests. Hydrate the instance "
                "via CyverProjectFile.from_dict(...) from a GET response "
                "before calling the update endpoint.",
                field="guid", reason="missing_required",
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise this instance into the JSON body expected by
            ``PUT /Project/UpdateProjectFile``.

            The emitted dict always contains the four caller-modifiable
            fields (``caption``, ``description``, ``visibleToClient``,
            ``additionalGuid`` when set) plus the mandatory ``type`` and
            ``fileId``.  Server-managed fields — ``fileName``, ``fileSize``,
            ``mimeType``, ``uploadedAt``, ``uploadedBy``, ``downloadLink``
            — are never emitted.  ``projectId`` is also not emitted; the
            wrapping portal method supplies it alongside ``to_dict()`` when
            building the final PUT body.

            ``additionalGuid`` is omitted when :attr:`_additional_guid` is
            ``None`` (the builder's "unset" state); when set, the real UUID
            is emitted — the zero-GUID sentinel never appears in the
            output.

            Returns:
                dict: Update-ready dict with camelCase API keys.
        """
        result: dict = {
            "type":            self._file_type,
            "caption":         self._caption,
            "description":     self._description,
            "visibleToClient": self._visible_to_client,
        }
        if self._guid is not None:
            result["fileId"] = self._guid
        if self._additional_guid is not None:
            result["additionalGuid"] = self._additional_guid
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverProjectFile:
        """
            Construct a ``CyverProjectFile`` from an API response dict.

            The three universally-mandatory keys (``fileName``,
            ``fileSize``, ``type``) run through the constructor's
            validators; remaining keys are extracted via the standard
            ``_fd_optional_*`` helpers.  ``additionalGuid`` uses
            :func:`_fd_optional_uuid` so the zero-GUID sentinel maps
            transparently to ``None``.  ``uploadedBy`` is treated as a
            plain opaque string (the server has been observed returning
            both UUIDs and email addresses, so no UUID validation).

            Any ``type`` code outside :class:`_project_file_type._valid`
            raises ``CyverDataValidationError``.

            Args:
                data (dict): The file dict from a Cyver API response
                    (typically one element of
                    ``result["items"]`` on ``GetAllProjectFiles`` /
                    ``GetProjectImagesFiles``).

            Returns:
                CyverProjectFile: A fully populated instance.
        """
        obj = cls(
            file_name=data["fileName"],
            file_size=data["fileSize"],
            file_type=data["type"],
        )
        obj._guid          = _fd_optional_uuid(data, "guid")
        obj._mime_type     = _fd_optional_str(data, "mimeType")
        obj._uploaded_at   = _fd_optional_datetime(data, "uploadedAt")
        obj._uploaded_by   = _fd_optional_str(data, "uploadedBy")
        obj._download_link = _fd_optional_str(data, "downloadLink")
        obj._additional_guid = _fd_optional_uuid(data, "additionalGuid")

        visible = _fd_optional_bool(data, "visibleToClient")
        obj._visible_to_client = False if visible is None else visible

        caption = _fd_optional_str(data, "caption")
        obj._caption = "" if caption is None else caption

        description = _fd_optional_str(data, "description")
        obj._description = "" if description is None else description

        return obj

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        set_fields = ["fileName", "fileSize", "type"]
        if self._guid is not None:
            set_fields.append("guid")
        if self._mime_type is not None:
            set_fields.append("mimeType")
        if self._uploaded_at is not None:
            set_fields.append("uploadedAt")
        if self._uploaded_by is not None:
            set_fields.append("uploadedBy")
        if self._download_link is not None:
            set_fields.append("downloadLink")
        if self._additional_guid is not None:
            set_fields.append("additionalGuid")
        # visible_to_client / caption / description always have defaults;
        # include them in the repr only when they differ from the default
        # so the debug output stays noise-free on fresh instances.
        if self._visible_to_client:
            set_fields.append("visibleToClient")
        if self._caption:
            set_fields.append("caption")
        if self._description:
            set_fields.append("description")
        prefix = f"guid={self._guid!r}, " if self._guid else ""
        return (
            f"CyverProjectFile({prefix}file_name={self._file_name!r}, "
            f"fields={set(set_fields)})"
        )
