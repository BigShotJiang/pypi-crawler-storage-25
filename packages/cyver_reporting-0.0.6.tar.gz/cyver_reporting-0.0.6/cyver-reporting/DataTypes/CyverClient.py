#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import _validate_uuid
from .CyverClientInformation import CyverClientInformation


class CyverClient:
    """
        Data-builder for the ``/api/v2.2/pentester/clients`` API endpoints.

        Encapsulates and validates the request body for both the
        ``POST /api/v2.2/pentester/clients`` (create) and
        ``PUT /api/v2.2/pentester/clients/:id`` (update) operations.

        The ``name`` field is the only field that is universally required and
        must be provided at construction time. ``status`` defaults to ``0``
        if not explicitly set and is required for both POST and PUT requests;
        call ``validate_for_post()`` or ``validate_for_put()`` before
        dispatching to detect missing fields early. ``clientNumber`` is
        additionally required for PUT requests. All remaining fields are
        optional.

        All setter methods return ``self`` so calls can be chained fluently::

            client_data = (
                CyverClient("Acme Corp")
                .set_status(_client_status.inactive)
                .set_client_number("CLI-0042")
                .set_account_manager_id("550e8400-e29b-41d4-a716-446655440000")
                .add_label_id("a1b2c3d4-e5f6-7890-abcd-ef1234567890")
                .set_client_information(
                    CyverClientInformation()
                    .set_company_name("Acme Corporation")
                    .set_website("https://acme.example.com")
                )
            )

            payload = client_data.to_dict()

        Args:
            name (str): The client's display name. Must be a non-empty string.

        Raises:
            CyverDataValidationError: If ``name`` is not a non-empty ``str``.
    """

    def __init__(self, name: str) -> None:
        if not isinstance(name, str) or not name:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(name, str) else "missing_required",
            )
        self._id: str | None = None
        self._name: str = name
        self._status: int = 0
        self._client_number: str | None = None
        self._account_manager_id: str | None = None
        self._label_id_list: list[str] = []
        self._team_id_list: list[str] = []
        self._client_information: CyverClientInformation | None = None

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_name(self, value: str) -> CyverClient:
        """
            Update the client's display name.

            Args:
                value (str): New non-empty display name.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._name = value
        return self

    def set_status(self, value: int) -> CyverClient:
        """
            Set the client's status code.

            Required for both POST and PUT requests. Defaults to ``0`` if
            never called. Must be a plain integer (``bool`` values are
            rejected because ``bool`` is a subclass of ``int`` in Python).

            Args:
                value (int): Integer status code as defined by the Cyver API.
                    Use :class:`~CyverReporting._client_status` aliases
                    (e.g. ``_client_status.active``) rather than raw integers.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``, or is a
                    ``bool``.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'status' must be an int, got {type(value).__name__}.",
                field="status",
                reason="invalid_type",
            )
        self._status = value
        return self

    def set_client_number(self, value: str) -> CyverClient:
        """
            Set the client's reference number.

            Required for PUT requests.

            Args:
                value (str): Client reference number string.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'clientNumber' must be a string, got {type(value).__name__}.",
                field="clientNumber",
                reason="invalid_type",
            )
        self._client_number = value
        return self

    def set_account_manager_id(self, value: str) -> CyverClient:
        """
            Set the UUID of the account manager responsible for this client.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or is not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'accountManagerId' must be a string, got {type(value).__name__}.",
                field="accountManagerId",
                reason="invalid_type",
            )
        _validate_uuid(value, "accountManagerId")
        self._account_manager_id = value
        return self

    def add_label_id(self, value: str) -> CyverClient:
        """
            Append a label UUID to the label ID list.

            Can be called multiple times to build up the list incrementally.
            Use ``set_label_id_list()`` to replace the entire list at once.

            Args:
                value (str): A well-formed UUID string identifying a label.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or is not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each entry in 'labelIdList' must be a string, "
                f"got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "labelIdList")
        self._label_id_list.append(value)
        return self

    def set_label_id_list(self, value: list[str]) -> CyverClient:
        """
            Replace the label ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list``, or if any
                    element is not a well-formed UUID string.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'labelIdList' must be a list, got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'labelIdList[{i}]' must be a string, got {type(item).__name__}.",
                    field="labelIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"labelIdList[{i}]")
        self._label_id_list = list(value)
        return self

    def add_team_id(self, value: str) -> CyverClient:
        """
            Append a team UUID to the team ID list.

            Can be called multiple times to build up the list incrementally.
            Use ``set_team_id_list()`` to replace the entire list at once.

            Args:
                value (str): A well-formed UUID string identifying a team.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or is not a
                    well-formed UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each entry in 'teamIdList' must be a string, "
                f"got {type(value).__name__}.",
                field="teamIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "teamIdList")
        self._team_id_list.append(value)
        return self

    def set_team_id_list(self, value: list[str]) -> CyverClient:
        """
            Replace the team ID list with the provided list of UUIDs.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list``, or if any
                    element is not a well-formed UUID string.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'teamIdList' must be a list, got {type(value).__name__}.",
                field="teamIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'teamIdList[{i}]' must be a string, got {type(item).__name__}.",
                    field="teamIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"teamIdList[{i}]")
        self._team_id_list = list(value)
        return self

    def set_client_information(self, value: CyverClientInformation) -> CyverClient:
        """
            Set the company information block for this client.

            Args:
                value (CyverClientInformation): A populated
                    ``CyverClientInformation`` instance.

            Returns:
                CyverClient: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``CyverClientInformation``
                    instance.
        """
        if not isinstance(value, CyverClientInformation):
            raise CyverDataValidationError(
                f"'clientInformation' must be a CyverClientInformation instance, "
                f"got {type(value).__name__}.",
                field="clientInformation",
                reason="invalid_type",
            )
        self._client_information = value
        return self

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Validate that all fields required for a POST (create) request
            are present.

            Both ``name`` and ``status`` are required for POST. ``name`` is
            enforced at construction time and ``status`` defaults to ``0``,
            so this method will succeed for any properly constructed instance
            unless ``name`` has somehow been cleared. It is provided as an
            explicit contract checkpoint before dispatching.

            Raises:
                CyverDataValidationError: If ``name`` is empty.
        """
        if not self._name:
            raise CyverDataValidationError(
                "'name' is required for POST requests and must not be empty.",
                field="name",
                reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Validate that all fields required for a PUT (update) request
            are present.

            In addition to the fields required for POST, ``clientNumber``
            must also be set before a PUT request can be dispatched.

            Raises:
                CyverDataValidationError: If ``name`` is empty, or if ``clientNumber``
                    has not been set.
        """
        self.validate_for_post()
        if self._client_number is None:
            raise CyverDataValidationError(
                "'clientNumber' is required for PUT requests. "
                "Call set_client_number() before dispatching.",
                field="clientNumber",
                reason="missing_required",
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the client data to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included in the
            output. The ``name`` field is always present as it is required
            at construction time.

            Returns:
                dict: Client payload with camelCase API keys, suitable for
                    use as the ``data`` argument to ``_send_api_request()``.
        """
        result: dict = {"name": self._name, "status": self._status}
        if self._client_number is not None:
            result["clientNumber"] = self._client_number
        if self._account_manager_id is not None:
            result["accountManagerId"] = self._account_manager_id
        if self._label_id_list:
            result["labelIdList"] = list(self._label_id_list)
        if self._team_id_list:
            result["teamIdList"] = list(self._team_id_list)
        if self._client_information is not None:
            info_dict = self._client_information.to_dict()
            if info_dict:
                result["clientInformation"] = info_dict
        return result

    # ------------------------------------------------------------------
    # Server-assigned identity
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """The server-assigned UUID of this client, populated by
        ``from_dict()`` when the object is constructed from an API
        response. ``None`` for objects created locally before dispatch."""
        return self._id

    @property
    def name(self) -> str:
        """The client's display name."""
        return self._name

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverClient:
        """
            Construct a ``CyverClient`` from an API response dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly (bypassing setters) so that values already
            validated by the server are not re-validated on ingestion.

            Args:
                data (dict): A client dict as returned by the Cyver API
                    (e.g. from ``get_client_by_id()``).

            Returns:
                CyverClient: A fully populated instance. ``id`` is set to
                    the server-assigned UUID when present in *data*.
        """
        obj = cls(data["name"])
        obj._id = data.get("id")
        if data.get("status") is not None:
            obj._status = data["status"]
        obj._client_number = data.get("clientNumber")
        obj._account_manager_id = data.get("accountManagerId")
        obj._label_id_list = list(data.get("labelIdList") or [])
        obj._team_id_list = list(data.get("teamIdList") or [])
        info_data = data.get("clientInformation")
        if info_data:
            obj._client_information = CyverClientInformation.from_dict(info_data)
        return obj

    def __repr__(self) -> str:
        set_fields = ["name", f"status={self._status}"]
        if self._client_number is not None:
            set_fields.append("clientNumber")
        if self._account_manager_id is not None:
            set_fields.append("accountManagerId")
        if self._label_id_list:
            set_fields.append(f"labelIdList[{len(self._label_id_list)}]")
        if self._team_id_list:
            set_fields.append(f"teamIdList[{len(self._team_id_list)}]")
        if self._client_information is not None:
            set_fields.append("clientInformation")
        prefix = f"id={self._id!r}, " if self._id else ""
        return f"CyverClient({prefix}name={self._name!r}, fields={set_fields})"
