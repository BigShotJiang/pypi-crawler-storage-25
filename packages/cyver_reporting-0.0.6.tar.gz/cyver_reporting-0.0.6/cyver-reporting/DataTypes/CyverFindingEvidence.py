#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _validate_uuid,
    _validate_ip,
    _validate_port,
    _validate_finding_compliance_status,
    _finding_compliance_status,
)


class CyverFindingEvidence:
    """
        Data-builder for the finding evidence API endpoints.

        Encapsulates and validates the request body for both the
        POST (create) and PUT (update) operations on finding evidence.

        The ``title`` field is the only universally required field and must be
        provided at construction time.  All remaining fields are optional.

        The ``evidenceComplianceStatus`` field accepts integer codes that
        correspond to the entries in :class:`_finding_compliance_status`:
        ``0`` (Pass) and ``1`` (Fail).

        The ``ip`` field is validated against both IPv4 and IPv6 address formats
        via :func:`_validate_ip`.  The ``port`` field accepts integers in the
        range 0–65535 via :func:`_validate_port`.

        All setter methods return ``self`` so calls can be chained fluently::

            evidence = (
                CyverFindingEvidence("SQL Injection – login form")
                .set_location("https://example.com/login")
                .set_reproduce("1. Enter `' OR 1=1--` in the username field.")
                .set_results("Authentication bypassed; admin panel accessible.")
                .set_ip("10.0.0.1")
                .set_port(443)
                .set_protocol("HTTPS")
                .set_is_visible_in_report(True)
                .set_evidence_compliance_status(
                    _finding_compliance_status.fail
                )
            )

            payload = evidence.to_dict()

        Args:
            title (str): The evidence entry's display title. Must be a
                non-empty string.

        Raises:
            CyverDataValidationError: If ``title`` is not a non-empty ``str``.
    """

    def __init__(self, title: str) -> None:
        if not isinstance(title, str) or not title:
            raise CyverDataValidationError(
                "'title' must be a non-empty string.",
                field="title",
                reason="invalid_type" if not isinstance(title, str) else "missing_required",
            )
        self._id: str | None = None
        self._title: str = title
        self._location: str | None = None
        self._version: str | None = None
        self._reproduce: str | None = None
        self._results: str | None = None
        self._issue_details: str | None = None
        self._is_visible_in_report: bool | None = None
        self._ip: str | None = None
        self._port: int | None = None
        self._protocol: str | None = None
        self._evidence_compliance_status: int | None = None

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """The server-assigned UUID of this evidence entry, populated by
        ``from_dict()`` when the object is constructed from an API response.
        ``None`` for objects created locally before dispatch."""
        return self._id

    @property
    def title(self) -> str:
        """The evidence entry's display title."""
        return self._title

    # ------------------------------------------------------------------
    # Setters — title
    # ------------------------------------------------------------------

    def set_title(self, value: str) -> CyverFindingEvidence:
        """
            Update the evidence entry's display title.

            Args:
                value (str): New non-empty display title.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'title' must be a non-empty string.",
                field="title",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._title = value
        return self

    # ------------------------------------------------------------------
    # Setters — plain string fields
    # ------------------------------------------------------------------

    def set_location(self, value: str) -> CyverFindingEvidence:
        """
            Set the location where the evidence was observed (e.g. a URL or
            file path).

            Args:
                value (str): Location string.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'location' must be a string, got {type(value).__name__}.",
                field="location",
                reason="invalid_type",
            )
        self._location = value
        return self

    def set_version(self, value: str) -> CyverFindingEvidence:
        """
            Set the version identifier associated with this evidence.

            Args:
                value (str): Version string.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'version' must be a string, got {type(value).__name__}.",
                field="version",
                reason="invalid_type",
            )
        self._version = value
        return self

    def set_reproduce(self, value: str) -> CyverFindingEvidence:
        """
            Set the steps-to-reproduce description.

            Args:
                value (str): Free-text reproduction steps.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reproduce' must be a string, got {type(value).__name__}.",
                field="reproduce",
                reason="invalid_type",
            )
        self._reproduce = value
        return self

    def set_results(self, value: str) -> CyverFindingEvidence:
        """
            Set the observed results / impact description.

            Args:
                value (str): Free-text results description.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'results' must be a string, got {type(value).__name__}.",
                field="results",
                reason="invalid_type",
            )
        self._results = value
        return self

    def set_issue_details(self, value: str) -> CyverFindingEvidence:
        """
            Set additional issue details.

            Args:
                value (str): Free-text issue details.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'issueDetails' must be a string, got {type(value).__name__}.",
                field="issueDetails",
                reason="invalid_type",
            )
        self._issue_details = value
        return self

    def set_protocol(self, value: str) -> CyverFindingEvidence:
        """
            Set the network protocol (e.g. ``"HTTPS"``, ``"TCP"``).

            Args:
                value (str): Protocol name string.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'protocol' must be a string, got {type(value).__name__}.",
                field="protocol",
                reason="invalid_type",
            )
        self._protocol = value
        return self

    # ------------------------------------------------------------------
    # Setters — boolean fields
    # ------------------------------------------------------------------

    def set_is_visible_in_report(self, value: bool) -> CyverFindingEvidence:
        """
            Set whether this evidence entry is visible in the generated report.

            Args:
                value (bool): ``True`` to include this entry in the report,
                    ``False`` to hide it.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``bool``.
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'isVisibleInReport' must be a bool, got {type(value).__name__}.",
                field="isVisibleInReport",
                reason="invalid_type",
            )
        self._is_visible_in_report = value
        return self

    # ------------------------------------------------------------------
    # Setters — validated fields
    # ------------------------------------------------------------------

    def set_ip(self, value: str) -> CyverFindingEvidence:
        """
            Set the IP address associated with this evidence.

            Accepts both IPv4 (e.g. ``"192.168.1.1"``) and IPv6 (e.g.
            ``"2001:db8::1"``) addresses.  Validated by :func:`_validate_ip`.

            Args:
                value (str): A valid IPv4 or IPv6 address string.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or is not a
                    valid IPv4 or IPv6 address.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'ip' must be a string, got {type(value).__name__}.",
                field="ip",
                reason="invalid_type",
            )
        _validate_ip(value, "ip")
        self._ip = value
        return self

    def set_port(self, value: int) -> CyverFindingEvidence:
        """
            Set the network port number.

            Valid values are integers in the range 0–65535 (inclusive).
            Validated by :func:`_validate_port`.

            Args:
                value (int): Transport-layer port number.

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``, or is
                    outside the range 0–65535.
        """
        _validate_port(value, "port")
        self._port = value
        return self

    def set_evidence_compliance_status(self, value: int) -> CyverFindingEvidence:
        """
            Set the evidence compliance status.

            The value must be a valid :class:`_finding_compliance_status` code:
            ``0`` (Pass) or ``1`` (Fail).  Validated by
            :func:`_validate_finding_compliance_status`.

            Args:
                value (int): A :class:`_finding_compliance_status` constant
                    (e.g. ``_finding_compliance_status.fail`` or ``1``).

            Returns:
                CyverFindingEvidence: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int`` or is not
                    a valid :class:`_finding_compliance_status` code.
        """
        _validate_finding_compliance_status(value, "evidenceComplianceStatus")
        self._evidence_compliance_status = value
        return self

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Validate that all fields required for a POST (create) request
            are present.

            Currently only checks that ``title`` is set (it is always set
            at construction time, but can be updated via ``set_title()``).

            Raises:
                CyverDataValidationError: If ``title`` is empty.
        """
        if not self._title:
            raise CyverDataValidationError(
                "'title' is required for POST requests and must not be empty.",
                field="title",
                reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Validate that all fields required for a PUT (update) request
            are present.

            Delegates to ``validate_for_post()``.

            Raises:
                CyverDataValidationError: If ``title`` is empty.
        """
        self.validate_for_post()

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the finding evidence data to a dictionary ready for the
            Cyver API.

            Only fields that have been explicitly set are included in the
            output.  The ``title`` field is always present as it is required
            at construction time.

            Returns:
                dict: Evidence payload with camelCase API keys, suitable for
                    use as the ``data`` argument to ``_send_api_request()``.
        """
        result: dict = {"title": self._title}
        if self._location is not None:
            result["location"] = self._location
        if self._version is not None:
            result["version"] = self._version
        if self._reproduce is not None:
            result["reproduce"] = self._reproduce
        if self._results is not None:
            result["results"] = self._results
        if self._issue_details is not None:
            result["issueDetails"] = self._issue_details
        if self._is_visible_in_report is not None:
            result["isVisibleInReport"] = self._is_visible_in_report
        if self._ip is not None:
            result["ip"] = self._ip
        if self._port is not None:
            result["port"] = self._port
        if self._protocol is not None:
            result["protocol"] = self._protocol
        if self._evidence_compliance_status is not None:
            result["evidenceComplianceStatus"] = self._evidence_compliance_status
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverFindingEvidence:
        """
            Construct a ``CyverFindingEvidence`` from an API response dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly (bypassing setters) so that values already
            validated by the server are not re-validated on ingestion.

            Args:
                data (dict): An evidence dict as returned by the Cyver API.

            Returns:
                CyverFindingEvidence: A fully populated instance.  ``id`` is
                    set to the server-assigned UUID when present in *data*.
        """
        obj = cls(data["title"])
        obj._id = data.get("id")
        obj._location = data.get("location")
        obj._version = data.get("version")
        obj._reproduce = data.get("reproduce")
        obj._results = data.get("results")
        obj._issue_details = data.get("issueDetails")
        obj._is_visible_in_report = data.get("isVisibleInReport")
        obj._ip = data.get("ip")
        obj._port = data.get("port")
        obj._protocol = data.get("protocol")
        obj._evidence_compliance_status = data.get("evidenceComplianceStatus")
        return obj

    def __repr__(self) -> str:
        set_fields = ["title"]
        for attr, key in [
            (self._location, "location"),
            (self._version, "version"),
            (self._reproduce, "reproduce"),
            (self._results, "results"),
            (self._issue_details, "issueDetails"),
            (self._is_visible_in_report, "isVisibleInReport"),
            (self._ip, "ip"),
            (self._port, "port"),
            (self._protocol, "protocol"),
            (self._evidence_compliance_status, "evidenceComplianceStatus"),
        ]:
            if attr is not None:
                set_fields.append(key)
        prefix = f"id={self._id!r}, " if self._id else ""
        return f"CyverFindingEvidence({prefix}title={self._title!r}, fields={set_fields})"
