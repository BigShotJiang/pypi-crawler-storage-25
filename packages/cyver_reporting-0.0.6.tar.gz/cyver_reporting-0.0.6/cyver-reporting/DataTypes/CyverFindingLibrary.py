#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _finding_library,
    _fd_optional_str,
    _fd_optional_uuid,
    _validate_finding_library,
    _validate_uuid,
)


def _fd_status_name_to_code(data: dict, key: str, *, required: bool) -> int | None:
    """Translate a ``_finding_library`` enum **name string** from a GET
    response into its integer code.

    The finding-library portal endpoints return ``status`` and
    ``findingLibraryTemplateStatus`` as printable names (e.g.
    ``"Draft"``, ``"Published"``) rather than integer codes.  This
    helper looks the value up in :attr:`_finding_library._codes` and
    raises ``CyverDataValidationError`` if the name is unknown — a
    schema-drift guard.

    Args:
        data: The response item dict.
        key: The camelCase key to read.
        required: When ``True``, raises if the key is missing or its
            value is ``None``; when ``False``, returns ``None`` cleanly
            on missing/null.

    Returns:
        Integer code, or ``None`` when ``required=False`` and the key
        is absent / null.

    Raises:
        CyverDataValidationError: If ``required`` and missing; if the
            value is not a string; or if the string is not in
            :attr:`_finding_library._codes`.
    """
    value = data.get(key)
    if value is None:
        if required:
            raise CyverDataValidationError(
                f"'{key}' is required.", field=key, reason="missing_required",
            )
        return None
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be an enum name string, got {type(value).__name__}.",
            field=key, reason="invalid_type",
        )
    if value not in _finding_library._codes:
        raise CyverDataValidationError(
            f"'{key}' must be one of {sorted(_finding_library._codes)!r}, got {value!r}.",
            field=key, reason="invalid_value",
        )
    return _finding_library._codes[value]


class CyverFindingLibrary:
    """
        Data-builder for the portal-surface finding-library API endpoints.

        Models the JSON shape for finding libraries — collections of
        reusable finding templates that can be in either ``Draft`` or
        ``Published`` state.  The universally mandatory fields —
        ``name`` and ``status`` — are required at construction.  ``guid``
        is mandatory for the PUT endpoint variant only, and is populated
        from the server response via :meth:`from_dict`; no public setter
        is provided because it is server-assigned at creation time.

        ``status`` and ``findingLibraryTemplateStatus`` are both
        validated against :class:`_finding_library` (codes ``1`` =
        Draft, ``2`` = Published).  ``findingFieldsTemplateGuid`` is
        UUID-validated when set.

        All caller-modifiable fields have dedicated setters and return
        ``self`` for fluent chaining::

            library = (
                CyverFindingLibrary(name="Web App Toolkit",
                                    status=_finding_library.draft)
                .set_description("Reusable findings for web app engagements")
                .set_finding_fields_template_guid("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
            )
            payload = library.to_dict()  # ready for POST body

        Args:
            name (str): Display name for the library.  Must be a
                non-empty string.
            status (int): Code from :class:`_finding_library`
                (``1`` = Draft, ``2`` = Published).  Named aliases
                like ``_finding_library.published`` evaluate to their
                integer code and can be passed directly.

        Raises:
            CyverDataValidationError: If either of the two mandatory
                fields fails its validation check.
    """

    def __init__(self, name: str, status: int) -> None:
        if not isinstance(name, str) or not name:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(name, str) else "missing_required",
            )
        _validate_finding_library(status, "status")

        # Universally mandatory.
        self._name:   str = name
        self._status: int = status

        # Mandatory only for PUT — populated by from_dict, no public setter.
        self._guid: str | None = None

        # Optional caller-modifiable fields.  Default to None so to_dict()
        # can omit them cleanly when the caller hasn't set them.
        self._description:                     str | None = None
        self._finding_library_template_status: int | None = None
        self._finding_fields_template_guid:    str | None = None
        self._finding_fields_template_name:    str | None = None

    # ------------------------------------------------------------------
    # Read-only properties
    # ------------------------------------------------------------------

    @property
    def guid(self) -> str | None:
        return self._guid

    @property
    def name(self) -> str:
        return self._name

    @property
    def status(self) -> int:
        return self._status

    @property
    def description(self) -> str | None:
        return self._description

    @property
    def finding_library_template_status(self) -> int | None:
        return self._finding_library_template_status

    @property
    def finding_fields_template_guid(self) -> str | None:
        return self._finding_fields_template_guid

    @property
    def finding_fields_template_name(self) -> str | None:
        return self._finding_fields_template_name

    # ------------------------------------------------------------------
    # Setters — caller-modifiable fields
    # ------------------------------------------------------------------

    def set_name(self, value: str) -> CyverFindingLibrary:
        """
            Set the library's display name.

            Args:
                value (str): Non-empty display name.

            Returns:
                CyverFindingLibrary: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a non-empty
                    ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._name = value
        return self

    def set_status(self, value: int) -> CyverFindingLibrary:
        """
            Set the library's publication status.

            Args:
                value (int): Code from :class:`_finding_library` (``1``
                    = Draft, ``2`` = Published).

            Returns:
                CyverFindingLibrary: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not an ``int``
                    in :attr:`_finding_library._valid`.
        """
        _validate_finding_library(value, "status")
        self._status = value
        return self

    def set_description(self, value: str) -> CyverFindingLibrary:
        """
            Set the library's free-text description.

            Empty strings are accepted explicitly so callers can clear
            a previously-populated description server-side.

            Args:
                value (str): Description text (may be empty).

            Returns:
                CyverFindingLibrary: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'description' must be a string, got {type(value).__name__}.",
                field="description",
                reason="invalid_type",
            )
        self._description = value
        return self

    def set_finding_library_template_status(self, value: int) -> CyverFindingLibrary:
        """
            Set the publication status of the underlying library
            template.

            Args:
                value (int): Code from :class:`_finding_library`.

            Returns:
                CyverFindingLibrary: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not an ``int``
                    in :attr:`_finding_library._valid`.
        """
        _validate_finding_library(value, "findingLibraryTemplateStatus")
        self._finding_library_template_status = value
        return self

    def set_finding_fields_template_guid(self, value: str) -> CyverFindingLibrary:
        """
            Set the UUID of the finding-fields template that backs this
            library.

            Args:
                value (str): A valid UUID string.

            Returns:
                CyverFindingLibrary: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a valid
                    UUID string.
        """
        _validate_uuid(value, "findingFieldsTemplateGuid")
        self._finding_fields_template_guid = value
        return self

    # ``_finding_fields_template_name`` is server-derived (looked up
    # from the template GUID and returned in GET responses); it is
    # **not** sent on writes and therefore has no public setter.
    # Callers that need to read it use the ``finding_fields_template_name``
    # property after a ``from_dict`` hydration.

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Confirm every universally-mandatory field is populated.

            Trivially true after a successful construction (the
            constructor rejects missing / malformed values) but kept as
            a defensive check for instances produced via
            :meth:`from_dict` or direct private-attribute manipulation.

            Raises:
                CyverDataValidationError: If ``name`` or ``status`` is
                    missing.
        """
        if not self._name:
            raise CyverDataValidationError(
                "'name' is required and must not be empty.",
                field="name", reason="missing_required",
            )
        if self._status is None:
            raise CyverDataValidationError(
                "'status' is required.",
                field="status", reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Confirm every field required by the PUT update endpoint is
            populated.

            Runs :meth:`validate_for_post` first, then requires that
            ``guid`` has been populated — which only happens via
            :meth:`from_dict` after a GET, since there is no public
            ``set_guid``.

            Raises:
                CyverDataValidationError: If ``guid`` is missing, or
                    any POST-required field is missing.
        """
        self.validate_for_post()
        if not self._guid:
            raise CyverDataValidationError(
                "'guid' is required for PUT requests. Hydrate the "
                "instance via CyverFindingLibrary.from_dict(...) from "
                "a GET response before calling the update endpoint.",
                field="guid", reason="missing_required",
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise this instance into the JSON body expected by the
            finding-library write endpoint
            (``POST /api/services/app/FindingLibrary/CreateOrUpdateFindingLibrary``).

            **Wire-key casing is PascalCase** on writes — distinct from
            the camelCase used in GET responses.  ``Status`` and
            ``FindingLibraryTemplateStatus`` are emitted as raw integer
            codes.  ``FindingFieldsTemplateName`` is server-derived and
            never emitted.

            The emitted dict always contains ``Name`` and ``Status``
            (the universally-mandatory fields).  ``Guid`` is included
            only when populated (the data class was hydrated from a GET
            response, so the call routes to the server's *update* path
            of the unified ``CreateOrUpdate`` endpoint).  Optional
            fields (``Description``, ``FindingLibraryTemplateStatus``,
            ``FindingFieldsTemplateGuid``) are emitted only when the
            caller has explicitly set them via the corresponding setters
            ("emit when set" semantics — pass-through callers may rely
            on the server applying its own defaults for unset fields).

            Returns:
                dict: Write-ready dict with PascalCase API keys.
        """
        result: dict = {
            "Name":   self._name,
            "Status": self._status,
        }
        if self._guid is not None:
            result["Guid"] = self._guid
        if self._description is not None:
            result["Description"] = self._description
        if self._finding_library_template_status is not None:
            result["FindingLibraryTemplateStatus"] = self._finding_library_template_status
        if self._finding_fields_template_guid is not None:
            result["FindingFieldsTemplateGuid"] = self._finding_fields_template_guid
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> CyverFindingLibrary:
        """
            Construct a ``CyverFindingLibrary`` from an API response
            dict.

            **Wire-key casing is camelCase** on reads (distinct from
            the PascalCase used in writes).  ``status`` and
            ``findingLibraryTemplateStatus`` are received as **enum
            name strings** (e.g. ``"Draft"``, ``"Published"``); this
            method looks them up in :attr:`_finding_library._codes` and
            stores the integer code internally.  Unknown names raise
            ``CyverDataValidationError`` so schema drift is loud rather
            than silent.

            Args:
                data (dict): The library dict from a Cyver API response
                    item (typically one element of ``result["items"]``
                    on ``GetFindingLibraries``).

            Returns:
                CyverFindingLibrary: A fully populated instance.

            Raises:
                CyverDataValidationError: If any mandatory field is
                    missing or has the wrong type, or if a present
                    enum field carries a name not in
                    :attr:`_finding_library._codes`, or if a present
                    UUID field is malformed.
        """
        # Parse the mandatory `status` name string.  We need the int
        # code before we can pass it to the constructor.
        status_code = _fd_status_name_to_code(data, "status", required=True)

        obj = cls(
            name=data["name"],
            status=status_code,
        )
        obj._guid                          = _fd_optional_uuid(data, "guid")
        obj._description                   = _fd_optional_str(data, "description")
        obj._finding_fields_template_guid  = _fd_optional_uuid(data, "findingFieldsTemplateGuid")
        obj._finding_fields_template_name  = _fd_optional_str(data, "findingFieldsTemplateName")

        # Optional template status — same name-string convention.
        obj._finding_library_template_status = _fd_status_name_to_code(
            data, "findingLibraryTemplateStatus", required=False,
        )

        return obj

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        set_fields = ["name", "status"]
        if self._guid is not None:
            set_fields.append("guid")
        if self._description is not None:
            set_fields.append("description")
        if self._finding_library_template_status is not None:
            set_fields.append("findingLibraryTemplateStatus")
        if self._finding_fields_template_guid is not None:
            set_fields.append("findingFieldsTemplateGuid")
        if self._finding_fields_template_name is not None:
            set_fields.append("findingFieldsTemplateName")
        prefix = f"guid={self._guid!r}, " if self._guid else ""
        return (
            f"CyverFindingLibrary({prefix}name={self._name!r}, "
            f"fields={set(set_fields)})"
        )
