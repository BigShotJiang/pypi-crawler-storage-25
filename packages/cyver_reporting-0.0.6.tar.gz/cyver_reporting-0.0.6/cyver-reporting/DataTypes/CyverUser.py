#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _validate_uuid,
    _validate_email,
    _validate_datetime,
    _user_role,
)


class CyverUser:
    """
        Data-builder for the ``/api/v2.2/pentester/users`` API endpoints.

        Encapsulates and validates the request body for both the
        ``POST /api/v2.2/pentester/users`` (create) and
        ``PUT /api/v2.2/pentester/users/:id`` (update) operations.

        The ``name``, ``surname``, ``email`` and ``role`` fields are universally
        required and must be provided at construction time. ``id`` is additionally
        required for PUT requests — call :meth:`set_id` before dispatching and
        use :meth:`validate_for_put` to detect its absence early.

        ``role`` must be an integer code from :class:`_user_role`. When a Client
        role (codes 0–4) is selected, ``client_id`` also becomes mandatory and
        must be set before dispatching — :meth:`validate_for_post` and
        :meth:`validate_for_put` both enforce this.

        ``email`` is validated against a minimal RFC 5321-inspired pattern on
        every assignment. The object attribute is named ``email`` but the API
        key used in the serialised payload is ``emailAddress``. Similarly,
        the object attribute is named ``client_id`` but the API key is
        ``clientGuid``. ``creationTime`` must conform to one of the two ISO
        8601 UTC formats accepted by the Cyver API:
        ``YYYY-MM-DDTHH:MM:SSZ`` or ``YYYY-MM-DDTHH:MM:SS.ffffffZ``.

        All setter methods return ``self`` so calls can be chained fluently::

            user = (
                CyverUser("Alice", "Smith", "alice@example.com", _user_role.pentester_general)
                .set_phone_number("+1-555-0100")
                .set_is_active(True)
                .set_is_two_factor_enabled(False)
            )
            payload = user.to_dict()

            client_user = (
                CyverUser("Bob", "Jones", "bob@example.com", _user_role.client_general)
                .set_client_id("550e8400-e29b-41d4-a716-446655440000")
            )

        Args:
            name (str): The user's first name. Must be a non-empty string.
            surname (str): The user's last name. Must be a non-empty string.
            email (str): The user's e-mail address. Must pass e-mail validation.
            role (int): The user's role code. Must be a value from
                :class:`_user_role` (i.e. present in ``_user_role._valid``).

        Raises:
            CyverDataValidationError: If any required constructor argument fails its type
                or format validation.
    """

    def __init__(self, name: str, surname: str, email: str, role: int) -> None:
        if not isinstance(name, str) or not name:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(name, str) else "missing_required",
            )
        if not isinstance(surname, str) or not surname:
            raise CyverDataValidationError(
                "'surname' must be a non-empty string.",
                field="surname",
                reason="invalid_type" if not isinstance(surname, str) else "missing_required",
            )
        if not isinstance(email, str):
            raise CyverDataValidationError(
                f"'email' must be a string, got {type(email).__name__}.",
                field="email",
                reason="invalid_type",
            )
        _validate_email(email, "email")
        if isinstance(role, bool) or not isinstance(role, int):
            raise CyverDataValidationError(
                f"'role' must be an int, got {type(role).__name__}.",
                field="role",
                reason="invalid_type",
            )
        if role not in _user_role._valid:
            raise CyverDataValidationError(
                f"'role' must be one of {sorted(_user_role._valid)!r}, got {role!r}.",
                field="role",
                reason="invalid_value",
            )

        self._id: str | None = None
        self._client_id: str | None = None
        self._name: str = name
        self._surname: str = surname
        self._email: str = email
        self._phone_number: str | None = None
        self._is_email_confirmed: bool | None = None
        self._is_active: bool = True
        self._is_two_factor_enabled: bool | None = None
        self._is_lockout_enabled: bool | None = None
        self._role: int = role
        self._creation_time: str | None = None

    # ------------------------------------------------------------------
    # Setters — identity & UUID fields
    # ------------------------------------------------------------------

    def set_id(self, value: str) -> "CyverUser":
        """
            Set the user's server-assigned UUID.

            Required for PUT requests. Normally this value is obtained from a
            previous API response and stored here before dispatching an update.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID string.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'id' must be a string, got {type(value).__name__}.",
                field="id",
                reason="invalid_type",
            )
        _validate_uuid(value, "id")
        self._id = value
        return self

    def set_client_id(self, value: str) -> "CyverUser":
        """
            Set the UUID of the client organisation this user belongs to.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a well-formed UUID string.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'clientId' must be a string, got {type(value).__name__}.",
                field="clientId",
                reason="invalid_type",
            )
        _validate_uuid(value, "clientId")
        self._client_id = value
        return self

    # ------------------------------------------------------------------
    # Setters — required string fields
    # ------------------------------------------------------------------

    def set_name(self, value: str) -> "CyverUser":
        """
            Update the user's first name.

            Args:
                value (str): Non-empty first name string.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._name = value
        return self

    def set_surname(self, value: str) -> "CyverUser":
        """
            Update the user's last name.

            Args:
                value (str): Non-empty last name string.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'surname' must be a non-empty string.",
                field="surname",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._surname = value
        return self

    def set_email(self, value: str) -> "CyverUser":
        """
            Update the user's e-mail address.

            The value is validated against :data:`_re_email` on every call.

            Args:
                value (str): A well-formed e-mail address string.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or does not
                    match the e-mail validation pattern.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'email' must be a string, got {type(value).__name__}.",
                field="email",
                reason="invalid_type",
            )
        _validate_email(value, "email")
        self._email = value
        return self

    def set_role(self, value: int) -> "CyverUser":
        """
            Update the user's role code.

            Args:
                value (int): A role code from :class:`_user_role`
                    (i.e. present in ``_user_role._valid``).

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``, is a ``bool``,
                    or is not a recognised role code.
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'role' must be an int, got {type(value).__name__}.",
                field="role",
                reason="invalid_type",
            )
        if value not in _user_role._valid:
            raise CyverDataValidationError(
                f"'role' must be one of {sorted(_user_role._valid)!r}, got {value!r}.",
                field="role",
                reason="invalid_value",
            )
        self._role = value
        return self

    # ------------------------------------------------------------------
    # Setters — optional string fields
    # ------------------------------------------------------------------

    def set_phone_number(self, value: str) -> "CyverUser":
        """
            Set the user's phone number.

            Args:
                value (str): Phone number string (no specific format enforced).

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'phoneNumber' must be a string, got {type(value).__name__}.",
                field="phoneNumber",
                reason="invalid_type",
            )
        self._phone_number = value
        return self

    def set_creation_time(self, value: str) -> "CyverUser":
        """
            Set the account creation timestamp.

            The value must conform to one of the two ISO 8601 UTC formats
            accepted by the Cyver API:

            * ``YYYY-MM-DDTHH:MM:SSZ``
            * ``YYYY-MM-DDTHH:MM:SS.ffffffZ``  (any number of fractional digits)

            Args:
                value (str): Datetime string in one of the accepted formats.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``, or does not
                    match the accepted datetime pattern.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'creationTime' must be a string, got {type(value).__name__}.",
                field="creationTime",
                reason="invalid_type",
            )
        _validate_datetime(value, "creationTime")
        self._creation_time = value
        return self

    # ------------------------------------------------------------------
    # Setters — optional boolean fields
    # ------------------------------------------------------------------

    def set_is_email_confirmed(self, value: bool) -> "CyverUser":
        """
            Set whether the user's e-mail address has been confirmed.

            Args:
                value (bool): ``True`` if confirmed, ``False`` otherwise.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``bool``.
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'isEmailConfirmed' must be a bool, got {type(value).__name__}.",
                field="isEmailConfirmed",
                reason="invalid_type",
            )
        self._is_email_confirmed = value
        return self

    def set_is_active(self, value: bool) -> "CyverUser":
        """
            Set whether the user account is active.

            Args:
                value (bool): ``True`` if active, ``False`` if deactivated.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``bool``.
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'isActive' must be a bool, got {type(value).__name__}.",
                field="isActive",
                reason="invalid_type",
            )
        self._is_active = value
        return self

    def set_is_two_factor_enabled(self, value: bool) -> "CyverUser":
        """
            Set whether two-factor authentication is enabled for this user.

            Args:
                value (bool): ``True`` to enable 2FA, ``False`` to disable.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``bool``.
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'isTwoFactorEnabled' must be a bool, got {type(value).__name__}.",
                field="isTwoFactorEnabled",
                reason="invalid_type",
            )
        self._is_two_factor_enabled = value
        return self

    def set_is_lockout_enabled(self, value: bool) -> "CyverUser":
        """
            Set whether account lockout is enabled for this user.

            Args:
                value (bool): ``True`` to enable lockout, ``False`` to disable.

            Returns:
                CyverUser: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``bool``.
        """
        if not isinstance(value, bool):
            raise CyverDataValidationError(
                f"'isLockoutEnabled' must be a bool, got {type(value).__name__}.",
                field="isLockoutEnabled",
                reason="invalid_type",
            )
        self._is_lockout_enabled = value
        return self

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """The server-assigned UUID of this user, or ``None`` if not yet set."""
        return self._id

    @property
    def client_id(self) -> str | None:
        """UUID of the client organisation this user belongs to, or ``None``."""
        return self._client_id

    @property
    def name(self) -> str:
        """The user's first name."""
        return self._name

    @property
    def surname(self) -> str:
        """The user's last name."""
        return self._surname

    @property
    def email(self) -> str:
        """The user's e-mail address."""
        return self._email

    @property
    def phone_number(self) -> str | None:
        """The user's phone number, or ``None`` if not set."""
        return self._phone_number

    @property
    def is_email_confirmed(self) -> bool | None:
        """``True`` if the e-mail address has been confirmed, else ``None``."""
        return self._is_email_confirmed

    @property
    def is_active(self) -> bool:
        """``True`` if the account is active, ``False`` if deactivated.
        Defaults to ``True`` unless explicitly overridden via :meth:`set_is_active`."""
        return self._is_active

    @property
    def is_two_factor_enabled(self) -> bool | None:
        """``True`` if 2FA is enabled for this user, else ``None``."""
        return self._is_two_factor_enabled

    @property
    def is_lockout_enabled(self) -> bool | None:
        """``True`` if account lockout is enabled for this user, else ``None``."""
        return self._is_lockout_enabled

    @property
    def role(self) -> int:
        """The user's role code (a value from :class:`_user_role`)."""
        return self._role

    @property
    def creation_time(self) -> str | None:
        """Account creation timestamp string, or ``None`` if not set."""
        return self._creation_time

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Validate that all fields required for a POST (create) request
            are present.

            ``name``, ``surname``, ``email`` and ``role`` are enforced at
            construction time, so this method will succeed for any properly
            constructed instance unless a field has been corrupted afterwards.
            Additionally, when the selected role is a Client role (codes 0–4),
            ``client_id`` must also be set.

            Raises:
                CyverDataValidationError: If any universally required field is empty or
                    missing, or if a Client role is selected without a
                    ``client_id`` being set.
        """
        if not self._name:
            raise CyverDataValidationError(
                "'name' is required for POST requests and must not be empty.",
                field="name",
                reason="missing_required",
            )
        if not self._surname:
            raise CyverDataValidationError(
                "'surname' is required for POST requests and must not be empty.",
                field="surname",
                reason="missing_required",
            )
        if not self._email:
            raise CyverDataValidationError(
                "'email' is required for POST requests and must not be empty.",
                field="email",
                reason="missing_required",
            )
        if self._role is None:
            raise CyverDataValidationError(
                "'role' is required for POST requests.",
                field="role",
                reason="missing_required",
            )
        if self._role in _user_role._client_roles and self._client_id is None:
            role_name = _user_role._names.get(self._role, str(self._role))
            raise CyverDataValidationError(
                f"'client_id' is required for Client roles "
                f"(role {self._role}: '{role_name}'). "
                "Call set_client_id() before dispatching.",
                field="client_id",
                reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Validate that all fields required for a PUT (update) request
            are present.

            In addition to the POST requirements (including the ``client_id``
            check for Client roles), ``id`` must also be set before a PUT
            request can be dispatched.

            Raises:
                CyverDataValidationError: If any universally required field is empty,
                    if a Client role is selected without a ``client_id``, or
                    if ``id`` has not been set.
        """
        self.validate_for_post()
        if self._id is None:
            raise CyverDataValidationError(
                "'id' is required for PUT requests. "
                "Call set_id() before dispatching.",
                field="id",
                reason="missing_required",
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the user data to a dictionary ready for the Cyver API.

            The four universally required fields are always present. Note the
            following API key mappings that differ from the object attributes:

            * ``email``     → ``"emailAddress"``
            * ``client_id`` → ``"clientGuid"``

            All other fields are included only when they have been explicitly
            set.

            Returns:
                dict: User payload with camelCase API keys, suitable for use
                    as the ``data`` argument to ``_send_api_request()``.
        """
        result: dict = {
            "name": self._name,
            "surname": self._surname,
            "emailAddress": self._email,
            "role": self._role,
        }
        if self._id is not None:
            result["id"] = self._id
        if self._client_id is not None:
            result["clientGuid"] = self._client_id
        if self._phone_number is not None:
            result["phoneNumber"] = self._phone_number
        if self._is_email_confirmed is not None:
            result["isEmailConfirmed"] = self._is_email_confirmed
        result["isActive"] = self._is_active
        if self._is_two_factor_enabled is not None:
            result["isTwoFactorEnabled"] = self._is_two_factor_enabled
        if self._is_lockout_enabled is not None:
            result["isLockoutEnabled"] = self._is_lockout_enabled
        if self._creation_time is not None:
            result["creationTime"] = self._creation_time
        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "CyverUser":
        """
            Construct a ``CyverUser`` from an API response dictionary.

            All fields are assigned directly to private attributes, bypassing
            the constructor and setters. This mirrors the behaviour of the
            other data-builder classes and trusts that server-returned data
            already conforms to the expected schema. In particular, the API
            may return ``role`` as a string name rather than an integer code,
            so the constructor's int-only role validation is intentionally
            skipped here.

            Note the following API key mappings read from the response:

            * ``"email"``    → stored as ``email``  (not ``"emailAddress"``)
            * ``"clientId"`` → stored as ``client_id`` (not ``"clientGuid"``)

            Args:
                data (dict): A user dict as returned by the Cyver API
                    (e.g. from ``get_user_by_id()``).

            Returns:
                CyverUser: A fully populated instance.

            Raises:
                KeyError: If ``name``, ``surname``, ``email`` or ``role`` is
                    absent from *data*.
        """
        obj = object.__new__(cls)
        obj._id             = data.get("id")
        obj._client_id      = data.get("clientId")
        obj._name           = data["name"]
        obj._surname        = data["surname"]
        obj._email          = data["email"]
        obj._phone_number   = data.get("phoneNumber")
        obj._is_email_confirmed    = data.get("isEmailConfirmed")
        obj._is_active             = data.get("isActive", True)
        obj._is_two_factor_enabled = data.get("isTwoFactorEnabled")
        obj._is_lockout_enabled    = data.get("isLockoutEnabled")
        obj._role           = data["role"]
        obj._creation_time  = data.get("creationTime")
        return obj

    def __repr__(self) -> str:
        role_repr = _user_role._names.get(self._role, repr(self._role)) \
            if isinstance(self._role, int) else repr(self._role)
        set_fields = ["name", "surname", "email", f"role={role_repr}"]
        if self._client_id is not None:
            set_fields.append("clientId")
        if self._phone_number is not None:
            set_fields.append("phoneNumber")
        for flag, key in [
            (self._is_email_confirmed, "isEmailConfirmed"),
            (self._is_active, "isActive"),
            (self._is_two_factor_enabled, "isTwoFactorEnabled"),
            (self._is_lockout_enabled, "isLockoutEnabled"),
        ]:
            if flag is not None:
                set_fields.append(f"{key}={flag}")
        if self._creation_time is not None:
            set_fields.append("creationTime")
        prefix = f"id={self._id!r}, " if self._id else ""
        return f"CyverUser({prefix}email={self._email!r}, fields={set_fields})"
