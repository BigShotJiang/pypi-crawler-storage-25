#!/usr/bin/env python3

from __future__ import annotations

from .Base import CyverError


class CyverAuthError(CyverError):
    """
        Raised when authentication against the Cyver API fails.

        Attributes:
            reason (str | None): A machine-readable code identifying the
                specific failure mode. Known values:

                - ``"not_authenticated"`` — An API method was called before
                  ``authenticate()`` was called on this session.
                - ``"2fa_not_configured"`` — The account requires 2FA but the
                  Email 2FA provider is not enabled.
                - ``"access_token_missing"`` — The API did not return a valid
                  access JWT token.
                - ``"refresh_token_missing"`` — The API did not return a valid
                  refresh JWT token.
                - ``"user_id_missing"`` — The API did not return a valid user
                  ID UUID.

        Example::

            try:
                client.authenticate(portal, username, password)
            except CyverAuthError as e:
                if e.reason == "2fa_not_configured":
                    print("Contact your administrator to enable Email 2FA.")
                else:
                    print(f"Authentication failed: {e}")
    """

    def __init__(self, message: str, reason: str | None = None) -> None:
        super().__init__(message)
        self.reason = reason


class CyverAuthMethodError(CyverAuthError):
    """
        Raised when an operation requires a specific authentication mode
        that the current session does not satisfy.

        Currently used by the portal subclasses (``PentesterPortal`` and
        ``ClientPortal``) at construction time when instantiated with an
        ``api_key=`` argument — the Cyver web frontend API rejects static
        API keys and accepts only access tokens produced by
        :meth:`CyverSession.authenticate`.

        Subclass of :class:`CyverAuthError`, so existing broad
        ``except CyverAuthError:`` handlers keep catching it.

        Attributes:
            reason (str | None): A machine-readable code identifying the
                specific failure mode. Known values:

                - ``"api_key_not_supported"`` — The session was constructed
                  with a static API key, but the target surface requires
                  password-authenticated access tokens.

        Example::

            try:
                portal = PentesterPortal(portal="app.cyver.io", api_key="sk-...")
            except CyverAuthMethodError as e:
                assert e.reason == "api_key_not_supported"
                # Retry with password auth:
                portal = PentesterPortal(portal="app.cyver.io")
                portal.authenticate("app.cyver.io", username, password)
    """


class Cyver2FARequired(CyverAuthError):
    """
        Raised when the Cyver API requires email-based two-factor
        authentication before granting access.

        This is not an error condition — it signals that the authentication
        flow requires a second step. When raised, the API has already
        dispatched a verification code to the account's registered e-mail
        address. Pass that code back via a second call to ``authenticate()``
        using the ``verification_code`` parameter::

            try:
                client.authenticate(portal, username, password)
            except Cyver2FARequired as e:
                print(f"Available 2FA providers: {e.providers}")
                code = input("Enter the 2FA code sent to your email: ")
                client.authenticate(portal, username, password,
                                    verification_code=code)

        Attributes:
            user_id (str | None): The Cyver user ID associated with the
                pending 2FA challenge.
            providers (list[str]): The 2FA providers available for this
                account (e.g. ``["Email"]``).
    """

    def __init__(
        self,
        message: str,
        user_id: str | None = None,
        providers: list[str] | None = None,
    ) -> None:
        super().__init__(message, reason="2fa_required")
        self.user_id = user_id
        self.providers = providers or []
