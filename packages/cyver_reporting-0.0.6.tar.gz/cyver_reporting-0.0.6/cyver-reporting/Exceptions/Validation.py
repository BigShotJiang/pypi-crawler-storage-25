#!/usr/bin/env python3

from __future__ import annotations

from .Base import CyverError


class CyverDataValidationError(CyverError):
    """
        Raised when an argument passed to a library method or data-builder
    fails validation.

        This exception is raised by setter methods on data-builder classes
        (such as ``CyverClient``) when a value's type or format does not
        match the schema expected by the Cyver API, or when a required field
        is missing before a request is dispatched.

        Attributes:
            field (str | None): The name of the field that failed validation,
                using the API's camelCase key name (e.g. ``"accountManagerId"``).
            reason (str | None): A machine-readable code identifying the
                specific failure mode. Known values:

                - ``"invalid_type"`` — The value's Python type does not match
                  the expected type for this field.
                - ``"invalid_uuid"`` — The value is a string but is not a
                  well-formed UUID.
                - ``"invalid_value"`` — The value is the correct type but
                  falls outside the set of accepted values (e.g. an
                  unrecognised status string).
                - ``"missing_required"`` — A field required for the target
                  operation (e.g. PUT) has not been set.

        Example::

            from CyverReporting import CyverClient
            from CyverReporting.Exceptions import CyverDataValidationError

            client_data = CyverClient("Acme Corp")
            try:
                client_data.set_status("active")   # wrong type — expects int
            except CyverDataValidationError as e:
                print(f"Field '{e.field}' error ({e.reason}): {e}")
    """

    def __init__(
        self,
        message: str,
        field: str | None = None,
        reason: str | None = None,
    ) -> None:
        super().__init__(message)
        self.field = field
        self.reason = reason
