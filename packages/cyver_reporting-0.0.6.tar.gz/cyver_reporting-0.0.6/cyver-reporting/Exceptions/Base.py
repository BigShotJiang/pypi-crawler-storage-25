#!/usr/bin/env python3

from __future__ import annotations


class CyverError(Exception):
    """
        Base class for all exceptions raised by the cyver-reporting library.

        Catching this class is sufficient to handle any library-specific error,
        while still allowing unrelated Python exceptions to propagate normally::

            try:
                client.authenticate(portal, username, password)
                results = list(client.get_all_projects())
            except CyverError as e:
                logger.error("Cyver API error: %s", e)
    """


class CyverReferenceError(CyverError):
    """
        Raised when a UUID field in a data-builder object refers to a resource
        that does not exist in the Cyver platform.

        This exception is raised during pre-flight reference validation in write
        methods (e.g. ``create_project()``) before the creation request is ever
        dispatched.  It signals a semantic / referential integrity failure rather
        than an HTTP or type-validation error.

        Attributes:
            field (str | None): The camelCase API field name that holds the
                invalid reference (e.g. ``"clientId"``,
                ``"projectTemplateId"``).
            resource_id (str | None): The UUID that was looked up and not
                found.

        Example::

            from CyverReporting import PentesterSession, CyverProject
            from CyverReporting.Exceptions import CyverReferenceError

            project = (
                CyverProject("Assessment Q3")
                .set_status("TESTING")
                .set_client_id("00000000-0000-0000-0000-000000000000")
                .set_project_template_id("yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy")
            )

            try:
                created = pentester.create_project(project)
            except CyverReferenceError as e:
                print(f"Field '{e.field}' references a non-existent resource: {e.resource_id}")
    """

    def __init__(
        self,
        message: str,
        field: str | None = None,
        resource_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.field = field
        self.resource_id = resource_id


class CyverCachingError(CyverError):
    """
        Raised when the local credential cache cannot be read, written,
        decrypted, or deleted safely.

        Cache failures are wrapped at every library entry point that
        touches the cache (``authenticate()``, the token-refresh path
        inside ``_send_api_request()``, and the API-key constructor
        flow) so that a damaged cache logs a warning and the session
        falls back to a fresh portal probe + re-authentication rather
        than breaking outright.  Callers that wish to handle cache
        damage explicitly may catch :class:`CyverCachingError` directly
        from the private cache I/O methods.

        Cold-start absence of the cache file is **not** an error —
        ``_fetch_*_cache`` returns its "no cache present" sentinel
        without raising.

        Attributes:
            cache_kind (str | None): Which cache flavour the failure
                relates to.  Known values: ``"oauth"``, ``"apikey"``.
            reason (str | None): Machine-readable failure code.  Known
                values: ``"read_failed"``, ``"decrypt_failed"``,
                ``"write_failed"``, ``"delete_failed"``, ``"corrupted"``.

        Example::

            from CyverReporting import PentesterSession
            from CyverReporting.Exceptions import CyverCachingError

            try:
                pentester._fetch_oauth_cache(...)
            except CyverCachingError as e:
                if e.reason == "decrypt_failed":
                    pentester._delete_oauth_cache(...)  # purge and retry
    """

    def __init__(
        self,
        message: str,
        *,
        cache_kind: str | None = None,
        reason: str | None = None,
    ) -> None:
        super().__init__(message)
        self.cache_kind = cache_kind
        self.reason = reason
