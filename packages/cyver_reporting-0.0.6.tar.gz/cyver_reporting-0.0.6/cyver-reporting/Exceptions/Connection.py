#!/usr/bin/env python3

from __future__ import annotations

from .Base import CyverError


class CyverHTTPError(CyverError):
    """
        Raised when an HTTP request to the Cyver API fails or produces an
        unexpected response.

        Covers four distinct failure scenarios:

        - A network-level error or connection timeout (``status_code`` is
          ``None``).
        - A non-200 HTTP status code returned by the API.
        - A 200 response whose body is not valid JSON.
        - A 200 JSON response whose ``success`` flag is ``False``.

        Attributes:
            status_code (int | None): The HTTP status code returned by the
                server, or ``None`` for network-level failures that never
                received a response.
            method (str | None): The HTTP method of the failed request
                (e.g. ``"GET"``, ``"POST"``).
            url (str | None): The full URL of the failed request.

        Example::

            try:
                projects = client.get_projects()
            except CyverHTTPError as e:
                print(f"[{e.method} {e.url}] HTTP {e.status_code}: {e}")
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        method: str | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.method = method
        self.url = url


class CyverNotFoundError(CyverHTTPError):
    """
        Raised when the Cyver API returns HTTP 404, indicating that the
        requested resource does not exist.

        Example::

            try:
                project = client.get_project_by_id(project_id)
            except CyverNotFoundError:
                print(f"Project {project_id} does not exist.")
    """

    def __init__(
        self,
        message: str,
        method: str | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message, status_code=404, method=method, url=url)


class CyverPermissionError(CyverHTTPError):
    """
        Raised when the Cyver API returns HTTP 401 or 403, indicating that
        the authenticated session does not have permission to perform the
        requested operation.

        A 401 typically means the access token has expired or is invalid —
        calling ``authenticate()`` again will refresh it. A 403 means the
        account role does not have access to the resource.

        Example::

            try:
                client.delete_project_by_id(project_id)
            except CyverPermissionError as e:
                if e.status_code == 401:
                    client.authenticate(portal, username, password)
                else:
                    print("Insufficient permissions to delete this project.")
    """

    def __init__(
        self,
        message: str,
        status_code: int = 403,
        method: str | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, method=method, url=url)


class CyverRateLimitError(CyverHTTPError):
    """
        Raised when the Cyver API returns HTTP 429 and all automatic retries
        have been exhausted.

        The library automatically retries GET and PUT requests up to three
        times with exponential back-off before raising this exception. POST
        and DELETE requests are not retried automatically to avoid unintended
        side-effects.

        Example::

            try:
                findings = list(client.get_all_findings())
            except CyverRateLimitError:
                print("Rate limit exceeded. Please wait before retrying.")
    """

    def __init__(
        self,
        message: str,
        method: str | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message, status_code=429, method=method, url=url)
