#!/usr/bin/env python3


from . import CyverSession
from .DataTypes import CyverProject
from .Exceptions import CyverDataValidationError
from .Utils import _project_status

from collections.abc import Iterator


_CLIENT_BASE = "/api/latest/client"


class ClientSession(CyverSession):
    """
        Class for Client users to interact with the Cyver Pentest Management API.

        Inherits all session management, token caching, and HTTP transport
        behaviour from CyverSession. All methods require a successful call to
        :meth:`~CyverReporting.Session.CyverSession.authenticate` first.

        Can be used as a context manager::

            with ClientSession() as client:
                client.authenticate(portal, username, password)
                projects = list(client.get_all_projects())
    """

    # ------------------------------------------------------------------
    # Projects
    # ------------------------------------------------------------------

    def get_projects(
        self,
        status: str | None = None,
        count_skip: int = 0,
        count_max: int = 10,
    ) -> dict:
        """
            Returns a paginated list of projects visible to the authenticated
            client user.

            Args:
                status: Optional filter by project status. Must be a
                    :class:`~cyver_reporting.Utils._project_status` alias or
                    its string value (e.g. ``_project_status.testing`` /
                    ``"TESTING"``).
                count_skip: Number of records to skip (for pagination).
                count_max: Maximum number of records to return.

            Returns:
                A dict with ``items`` (list of ``CyverProject`` objects) and
                ``totalCount`` (int) keys.

            Raises:
                CyverDataValidationError: If *status* is not a recognised project status value.
                CyverHTTPError: If the underlying HTTP request fails.
        """
        if status is not None and status not in _project_status._valid:
            raise CyverDataValidationError(f"'status' must be one of {sorted(_project_status._valid)!r}, got {status!r}.", field="status", reason="invalid_value")

        params: dict = {"SkipCount": count_skip, "MaxResultCount": count_max}
        if status is not None:
            params["Status"] = status

        result = self._send_api_request("GET", f"{_CLIENT_BASE}/projects", params)
        result["items"] = [CyverProject.from_dict(item) for item in result.get("items", [])]
        return result

    def get_all_projects(self, status: str | None = None) -> Iterator[CyverProject]:
        """
            Generator that yields every project visible to the authenticated
            client user, transparently paginating through all result pages.

            Args:
                status: Optional filter by project status.

            Yields:
                One ``CyverProject`` instance per iteration.

            Raises:
                CyverDataValidationError: If *status* is not a recognised project status value.
                CyverHTTPError: If any underlying HTTP request fails.
        """
        yield from self._paginate(
            lambda n, s: self.get_projects(status=status, count_max=n, count_skip=s),
        )

    def get_project_by_id(self, project_id: str) -> CyverProject:
        """
            Returns detailed information for a single project.

            Args:
                project_id: UUID of the project to retrieve.

            Returns:
                A ``CyverProject`` instance populated with the API response.

            Raises:
                CyverDataValidationError: If *project_id* is not a valid UUID.
                CyverHTTPError: If the underlying HTTP request fails.
        """
        self._require_uuid(project_id, "project_id")
        return CyverProject.from_dict(
            self._send_api_request("GET", f"{_CLIENT_BASE}/projects/{project_id}")
        )

    # ------------------------------------------------------------------
    # Continuous Projects
    # ------------------------------------------------------------------

    def get_continuous_projects(
        self,
        status: str | None = None,
        count_skip: int = 0,
        count_max: int = 10,
    ) -> dict:
        """
            Returns a paginated list of continuous projects visible to the
            authenticated client user.

            Args:
                status: Optional filter by project status. Must be a
                    :class:`~cyver_reporting.Utils._project_status` alias or
                    its string value (e.g. ``_project_status.testing`` /
                    ``"TESTING"``).
                count_skip: Number of records to skip (for pagination).
                count_max: Maximum number of records to return.

            Returns:
                A dict containing ``totalCount`` (int) and ``items`` (list).

            Raises:
                CyverDataValidationError: If *status* is not a recognised project status value.
                CyverHTTPError: If the underlying HTTP request fails.
        """
        if status is not None and status not in _project_status._valid:
            raise CyverDataValidationError(f"'status' must be one of {sorted(_project_status._valid)!r}, got {status!r}.", field="status", reason="invalid_value")

        params: dict = {"SkipCount": count_skip, "MaxResultCount": count_max}
        if status is not None:
            params["Status"] = status

        return self._send_api_request("GET", f"{_CLIENT_BASE}/continuous-projects", params)

    def get_all_continuous_projects(self, status: str | None = None) -> Iterator[dict]:
        """
            Generator that yields every continuous project visible to the
            authenticated client user, transparently paginating through all
            result pages.

            Args:
                status: Optional filter by project status.

            Yields:
                Individual continuous project dicts.

            Raises:
                CyverDataValidationError: If *status* is not a recognised project status value.
                CyverHTTPError: If any underlying HTTP request fails.
        """
        yield from self._paginate(
            lambda n, s: self.get_continuous_projects(status=status, count_max=n, count_skip=s),
        )

    def get_continuous_project_by_id(self, continuous_project_id: str) -> dict:
        """
            Returns detailed information for a single continuous project.

            Args:
                continuous_project_id: UUID of the continuous project to retrieve.

            Returns:
                A dict containing the continuous project details.

            Raises:
                CyverDataValidationError: If *continuous_project_id* is not a valid UUID.
                CyverHTTPError: If the underlying HTTP request fails.
        """
        self._require_uuid(continuous_project_id, "continuous_project_id")
        return self._send_api_request("GET", f"{_CLIENT_BASE}/continuous-projects/{continuous_project_id}")
