#!/usr/bin/env python3

"""Client-role session with access to the undocumented frontend API.

:class:`ClientPortal` inherits every method from :class:`ClientSession`
(and transitively from :class:`CyverSession`) so the full documented
V2.2 surface is available unchanged.  Portal-specific methods that
wrap endpoints exercised only by the Cyver web frontend are added
incrementally on this class — each one decorated with
:func:`portal_unstable` to signal that the undocumented surface may
change without notice.

The Cyver frontend API rejects static ``X-API-Key`` authentication,
so the constructor refuses to proceed when ``api_key=`` is supplied:
:class:`CyverAuthMethodError` is raised at construction time rather
than later at call time.  Use password authentication via
:meth:`~CyverSession.authenticate` after construction instead.

See :doc:`docs/portal.md` for the endpoint-admission protocol,
stability disclaimer, and contribution flow.
"""

from __future__ import annotations

from .ClientSession import ClientSession


class ClientPortal(ClientSession):
    """``ClientSession`` + methods for the undocumented frontend API.

    Methods inherited from :class:`ClientSession` behave identically
    to a plain client session.  Portal-specific methods (added
    incrementally from captured HTTP requests) wrap endpoints that the
    Cyver web frontend exercises but the documented V2.2 surface does
    not expose.

    Raises:
        CyverAuthMethodError: When constructed with ``api_key=…`` —
            the portal API accepts only password-authenticated access
            tokens.
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._assert_portal_auth_mode()
