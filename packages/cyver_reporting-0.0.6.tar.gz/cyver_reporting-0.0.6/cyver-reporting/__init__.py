#!/usr/bin/env python3

from .Session import CyverSession
from .ClientSession import ClientSession
from .PentesterSession import PentesterSession
from .ClientPortal import ClientPortal
from .PentesterPortal import PentesterPortal
from .Exceptions import (
    CyverError,
    CyverAuthError,
    CyverAuthMethodError,
    Cyver2FARequired,
    CyverHTTPError,
    CyverNotFoundError,
    CyverPermissionError,
    CyverRateLimitError,
    CyverDataValidationError,
    CyverReferenceError,
    CyverCachingError,
)
from .DataTypes import (
    CyverClientAddress,
    CyverClientInformation,
    CyverClient,
    CyverAsset,
    CyverChecklistTemplate,
    CyverComplianceTemplate,
    CyverProjectTemplate,
    CyverReportTemplateSection,
    CyverReportTemplate,
    CyverUser,
    CyverPlanningDate,
    CyverProjectDates,
    CyverProject,
    CyverFindingEvidence,
    CyverFindingCustomField,
    CyverFinding,
    CyverProjectFile,
    CyverFindingLibrary,
)
from .Utils import (
    _asset_type,
    _asset_env,
    _asset_hosting,
    _asset_hardware,
    _asset_exposure,
    _user_role,
    _client_status,
    _project_status,
    _finding_library,
    CyverPortalInstabilityWarning,
    portal_unstable,
)

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("cyver-reporting")
except PackageNotFoundError:
    # Package is not installed (e.g. running directly from source)
    __version__ = "unknown"

__all__ = [
    # Session classes
    "CyverSession",
    "ClientSession",
    "PentesterSession",
    # Portal session classes (undocumented frontend API)
    "ClientPortal",
    "PentesterPortal",
    # Base exception
    "CyverError",
    # Authentication exceptions
    "CyverAuthError",
    "CyverAuthMethodError",
    "Cyver2FARequired",
    # HTTP exceptions
    "CyverHTTPError",
    "CyverNotFoundError",
    "CyverPermissionError",
    "CyverRateLimitError",
    # Data validation exception
    "CyverDataValidationError",
    # Reference validation exception
    "CyverReferenceError",
    # Caching exception
    "CyverCachingError",
    # Data builder classes
    "CyverClientAddress",
    "CyverClientInformation",
    "CyverClient",
    "CyverAsset",
    "CyverChecklistTemplate",
    "CyverComplianceTemplate",
    "CyverProjectTemplate",
    "CyverReportTemplateSection",
    "CyverReportTemplate",
    "CyverUser",
    "CyverPlanningDate",
    "CyverProjectDates",
    "CyverProject",
    "CyverFindingEvidence",
    "CyverFindingCustomField",
    "CyverFinding",
    "CyverProjectFile",
    "CyverFindingLibrary",
    # Asset field alias classes
    "_asset_type",
    "_asset_env",
    "_asset_hosting",
    "_asset_hardware",
    "_asset_exposure",
    # User field alias classes
    "_user_role",
    # Client / project status alias classes
    "_client_status",
    "_project_status",
    # Finding field alias classes
    "_finding_library",
    # Portal-surface warning and decorator
    "CyverPortalInstabilityWarning",
    "portal_unstable",
    # Package version
    "__version__",
]
