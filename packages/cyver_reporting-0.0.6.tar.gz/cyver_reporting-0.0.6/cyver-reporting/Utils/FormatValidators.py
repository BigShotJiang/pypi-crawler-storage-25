#!/usr/bin/env python3

from __future__ import annotations

from ipaddress import ip_address as _ip_address
from jwt import decode as _jwt_decode
from time import time as _time

from ..Exceptions import CyverDataValidationError
from .RegExPatterns import (
    _re_uuid,
    _re_email,
    _re_datetime,
    _re_date,
    _re_cve,
    _re_cwe,
    _re_mitre_tactic,
    _re_mitre_technique,
    _re_mitre_mitigation,
    _re_cvss40_vector,
    _re_cvss31_vector,
    _re_cvss30_vector,
    _re_cvss20_vector,
    _re_url,
)
from .StaticAliases import (
    _project_status,
    _project_file_type,
    _finding_compliance_status,
    _finding_type,
    _finding_status,
    _finding_severity,
    _finding_library,
)

# ---------------------------------------------------------------------------
# CVSS base-metric value sets (module-level for performance)
# ---------------------------------------------------------------------------

_CVSS40_BASE_METRICS: dict[str, frozenset[str]] = {
    'AV': frozenset({'N', 'A', 'L', 'P'}),
    'AC': frozenset({'L', 'H'}),
    'AT': frozenset({'N', 'P'}),
    'PR': frozenset({'N', 'L', 'H'}),
    'UI': frozenset({'N', 'P', 'A'}),
    'VC': frozenset({'N', 'L', 'H'}),
    'VI': frozenset({'N', 'L', 'H'}),
    'VA': frozenset({'N', 'L', 'H'}),
    'SC': frozenset({'N', 'L', 'H'}),
    'SI': frozenset({'N', 'L', 'H', 'S'}),
    'SA': frozenset({'N', 'L', 'H', 'S'}),
}

# CVSS 3.0 and 3.1 share the same base-metric structure.
_CVSS3X_BASE_METRICS: dict[str, frozenset[str]] = {
    'AV': frozenset({'N', 'A', 'L', 'P'}),
    'AC': frozenset({'L', 'H'}),
    'PR': frozenset({'N', 'L', 'H'}),
    'UI': frozenset({'N', 'R'}),
    'S':  frozenset({'U', 'C'}),
    'C':  frozenset({'N', 'L', 'H'}),
    'I':  frozenset({'N', 'L', 'H'}),
    'A':  frozenset({'N', 'L', 'H'}),
}

_CVSS20_BASE_METRICS: dict[str, frozenset[str]] = {
    'AV': frozenset({'N', 'A', 'L'}),
    'AC': frozenset({'L', 'M', 'H'}),
    'Au': frozenset({'N', 'S', 'M'}),
    'C':  frozenset({'N', 'P', 'C'}),
    'I':  frozenset({'N', 'P', 'C'}),
    'A':  frozenset({'N', 'P', 'C'}),
}

# Bit-flag mask covering all defined _finding_type values (1|2|4|8|16 = 31).
_FINDING_TYPE_MASK: int = 31


def _validate_email(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed e-mail address.

    Uses :data:`_re_email` for matching. Called by :class:`CyverUser`
    setters and the constructor.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_email"`` if *value* does not
            match :data:`_re_email`.
    """
    if not _re_email.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid e-mail address: {value!r}.",
            field=field,
            reason="invalid_email",
        )


def _validate_datetime(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not an accepted datetime string.

    Accepted formats (UTC only, Zulu ``Z`` suffix required):

    * ``YYYY-MM-DDTHH:MM:SSZ``
    * ``YYYY-MM-DDTHH:MM:SS.ffffffZ``  (any number of fractional-second digits)

    Uses :data:`_re_datetime` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_datetime"`` if *value* does not
            match :data:`_re_datetime`.
    """
    if not _re_datetime.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid datetime string: {value!r}. "
            "Expected 'YYYY-MM-DDTHH:MM:SS[.fractional]Z'.",
            field=field,
            reason="invalid_datetime",
        )


def _validate_date(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not an accepted date string.

    Accepted format: ``YYYY-MM-DD``.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_date"`` if *value* does not
            match :data:`_re_date`.
    """
    if not _re_date.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid date string: {value!r}. "
            "Expected 'YYYY-MM-DD'.",
            field=field,
            reason="invalid_date",
        )


def _validate_uuid(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed UUID string.

    Accepted format: ``xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`` (case-insensitive hex groups).

    Uses :data:`_re_uuid` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_uuid"`` if *value* does not
            match :data:`_re_uuid`.
    """
    if not _re_uuid.search(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid UUID: {value!r}.",
            field=field,
            reason="invalid_uuid",
        )


#: Default skew applied by :data:`CyverReporting.Session` when pre-checking a
#: cached access token on warm start.  A token whose ``exp`` falls within this
#: many seconds of the current time is treated as already expired so that
#: ``authenticate()`` refreshes eagerly instead of waiting for the first API
#: call to fail with HTTP 401.
JWT_EXPIRY_SKEW_SECONDS = 30


def _validate_jwt_token(value: str, field: str, *, skew_seconds: int = 0) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed, non-expired JWT token.

    Decodes the token without signature verification to inspect the ``exp`` claim.
    A token is considered invalid if it cannot be decoded, if the ``exp`` claim is
    absent or ``None``, if it is already expired (``exp - now <= 0``), or — when
    *skew_seconds* is greater than zero — if it is within that many seconds of
    expiry (``exp - now <= skew_seconds``).

    Args:
        value: The JWT string to validate.
        field: API field name used in the error message.
        skew_seconds: Keyword-only.  When greater than ``0``, tokens whose
            remaining lifetime is ``<= skew_seconds`` are rejected as
            *near-expiry*.  Defaults to ``0`` so existing call sites keep
            their original semantics (reject only on or after ``exp``).

    Raises:
        CyverDataValidationError: With ``reason="invalid_jwt"`` if the token cannot
            be decoded, ``reason="expired_jwt"`` if the token is already expired
            or missing the ``exp`` claim, or ``reason="near_expiry"`` if the token
            is still in-window but falls inside *skew_seconds* of ``exp``.
    """
    try:
        decoded = _jwt_decode(value, options={"verify_signature": False})
    except Exception:
        raise CyverDataValidationError(
            f"'{field}' is not a well-formed JWT token.",
            field=field,
            reason="invalid_jwt",
        )
    exp = decoded.get("exp")
    if exp is None or exp - int(_time()) <= 0:
        raise CyverDataValidationError(
            f"'{field}' JWT token is expired or missing the expiry claim.",
            field=field,
            reason="expired_jwt",
        )
    if skew_seconds > 0 and exp - int(_time()) <= skew_seconds:
        remaining = exp - int(_time())
        raise CyverDataValidationError(
            f"'{field}' JWT token is within {skew_seconds}s of expiry "
            f"({remaining}s remaining); treat as expired.",
            field=field,
            reason="near_expiry",
        )


def _validate_cve(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed CVE identifier.

    Accepted format: ``CVE-YYYY-NNNNN`` where YYYY is a 4-digit year and
    the sequence number is between 4 and 19 digits (extended syntax per the
    2014 MITRE specification update).

    Uses :data:`_re_cve` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_cve"`` if *value* does not
            match :data:`_re_cve`.
    """
    if not _re_cve.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CVE identifier: {value!r}. "
            "Expected 'CVE-YYYY-NNNN[N...]' (4-digit year, 4–19 digit sequence).",
            field=field,
            reason="invalid_cve",
        )


def _validate_cwe(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed CWE identifier.

    Accepted format: ``CWE-N`` where N is 1–5 digits with no leading zeros.

    Uses :data:`_re_cwe` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_cwe"`` if *value* does not
            match :data:`_re_cwe`.
    """
    if not _re_cwe.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CWE identifier: {value!r}. "
            "Expected 'CWE-N' where N is a positive integer with no leading zeros (e.g. 'CWE-79').",
            field=field,
            reason="invalid_cwe",
        )


def _validate_mitre_tactic(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed MITRE ATT&CK tactic identifier.

    Accepted format: ``TA`` followed by exactly 4 digits (e.g. ``TA0001``).
    Validation is format-only; existence in the current ATT&CK release is
    not checked.

    Uses :data:`_re_mitre_tactic` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_mitre_tactic"`` if *value* does not
            match :data:`_re_mitre_tactic`.
    """
    if not _re_mitre_tactic.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid MITRE ATT&CK tactic identifier: {value!r}. "
            "Expected 'TA' followed by exactly 4 digits (e.g. 'TA0004').",
            field=field,
            reason="invalid_mitre_tactic",
        )


def _validate_mitre_technique(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed MITRE ATT&CK technique identifier.

    Accepted formats:

    * Technique: ``T`` followed by exactly 4 digits (e.g. ``T1040``).
    * Sub-technique: technique ID followed by ``.`` and exactly 3 digits (e.g. ``T1003.003``).

    Validation is format-only; existence in the current ATT&CK release is
    not checked.

    Uses :data:`_re_mitre_technique` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_mitre_technique"`` if *value* does not
            match :data:`_re_mitre_technique`.
    """
    if not _re_mitre_technique.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid MITRE ATT&CK technique identifier: {value!r}. "
            "Expected 'T' followed by 4 digits, optionally with a sub-technique suffix "
            "of '.' and 3 digits (e.g. 'T1040' or 'T1003.003').",
            field=field,
            reason="invalid_mitre_technique",
        )


def _validate_mitre_mitigation(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed MITRE ATT&CK mitigation identifier.

    Accepted format: ``M`` followed by exactly 4 digits (e.g. ``M1015``).
    Validation is format-only; existence in the current ATT&CK release is
    not checked.

    Uses :data:`_re_mitre_mitigation` for matching.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_mitre_mitigation"`` if *value* does not
            match :data:`_re_mitre_mitigation`.
    """
    if not _re_mitre_mitigation.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid MITRE ATT&CK mitigation identifier: {value!r}. "
            "Expected 'M' followed by exactly 4 digits (e.g. 'M1015').",
            field=field,
            reason="invalid_mitre_mitigation",
        )


def _validate_finding_type(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid finding type.

    The ``findingType`` field uses bit-flags; valid values are any non-zero
    combination of the flags defined in :class:`_finding_type`
    (``1`` = Vulnerability, ``2`` = Nonconformity, ``4`` = Observation,
    ``8`` = Incident, ``16`` = Risk).  Any integer from ``1`` to ``31``
    that does not set bits outside the defined mask is accepted.

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not an ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if
            *value* is zero or sets bits outside the valid flag mask.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value <= 0 or (value & ~_FINDING_TYPE_MASK) != 0:
        raise CyverDataValidationError(
            f"'{field}' must be a non-zero combination of valid finding-type flags "
            f"({sorted(_finding_type._valid)}), got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_finding_status(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid finding status code.

    Valid values are the integer codes defined on :class:`_finding_status`
    (``1``–``14``).

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not an
            ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if *value* is
            not in :attr:`_finding_status._valid`.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value not in _finding_status._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_finding_status._valid)}, got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_project_file_type(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid project-file type code.

    Valid values are the integer codes defined on :class:`_project_file_type`
    (``4``, ``5``, ``6``, ``7``, ``23``, ``24``, ``25``, ``29``).

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not an
            ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if *value* is
            not in :attr:`_project_file_type._valid`.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value not in _project_file_type._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_project_file_type._valid)}, got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_finding_severity(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid finding severity code.

    Valid values are the integer codes defined on :class:`_finding_severity`
    (``0`` = Info, ``1`` = Low, ``2`` = Medium, ``3`` = High, ``4`` = Critical).

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not an
            ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if *value* is
            not in :attr:`_finding_severity._valid`.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value not in _finding_severity._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_finding_severity._valid)}, got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_finding_library(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid finding-library status code.

    Valid values are the integer codes defined on :class:`_finding_library`
    (``1`` = Draft, ``2`` = Published).

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not an
            ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if *value* is
            not in :attr:`_finding_library._valid`.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value not in _finding_library._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_finding_library._valid)}, got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_cvss_score(value: object, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid CVSS score.

    Accepts ``int`` or ``float`` values in the range ``0.0``–``10.0``
    (inclusive).  ``bool`` values are explicitly rejected even though
    Python's ``bool`` is a subclass of ``int``.

    Args:
        value: The number to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not numeric (or is a ``bool``), or ``reason="invalid_cvss_score"``
            if *value* is outside the range ``0.0``–``10.0``.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise CyverDataValidationError(
            f"'{field}' must be a numeric CVSS score (int or float), "
            f"got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if not (0.0 <= float(value) <= 10.0):
        raise CyverDataValidationError(
            f"'{field}' CVSS score must be in the range 0.0–10.0, got {value!r}.",
            field=field,
            reason="invalid_cvss_score",
        )


def _validate_cvss40_vector(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid CVSS v4.0 vector string.

    Validation steps:

    1. Structural check — the string must match ``_re_cvss40_vector``
       (``CVSS:4.0/`` prefix, ``/``-separated ``Metric:Value`` pairs).
    2. Base-metric presence — all eleven required base metrics (``AV``,
       ``AC``, ``AT``, ``PR``, ``UI``, ``VC``, ``VI``, ``VA``, ``SC``,
       ``SI``, ``SA``) must be present.
    3. Base-metric value check — each required metric's value must be one
       of its defined valid values (see ``_CVSS40_BASE_METRICS``).

    Optional supplemental and environmental metrics are allowed but not
    validated beyond structural format.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not a ``str``, or ``reason="invalid_cvss40_vector"`` if the string
            fails structural, presence, or value checks.
    """
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{field}' must be a string, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if not _re_cvss40_vector.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CVSS 4.0 vector string: {value!r}. "
            "Expected 'CVSS:4.0/' followed by 'Metric:Value' pairs separated by '/'.",
            field=field,
            reason="invalid_cvss40_vector",
        )
    metrics_str = value[len('CVSS:4.0/'):]
    metrics = dict(pair.split(':', 1) for pair in metrics_str.split('/'))
    for metric, valid_vals in _CVSS40_BASE_METRICS.items():
        if metric not in metrics:
            raise CyverDataValidationError(
                f"'{field}' CVSS 4.0 vector is missing required base metric '{metric}'.",
                field=field,
                reason="invalid_cvss40_vector",
            )
        if metrics[metric] not in valid_vals:
            raise CyverDataValidationError(
                f"'{field}' CVSS 4.0 vector has invalid value for metric '{metric}': "
                f"{metrics[metric]!r}. Expected one of {sorted(valid_vals)}.",
                field=field,
                reason="invalid_cvss40_vector",
            )


def _validate_cvss31_vector(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid CVSS v3.1 vector string.

    Validation steps:

    1. Structural check — the string must match ``_re_cvss31_vector``
       (``CVSS:3.1/`` prefix, ``/``-separated ``Metric:Value`` pairs).
    2. Base-metric presence — all eight required base metrics (``AV``, ``AC``,
       ``PR``, ``UI``, ``S``, ``C``, ``I``, ``A``) must be present.
    3. Base-metric value check — each required metric's value must be one of
       its defined valid values (see ``_CVSS3X_BASE_METRICS``).

    Optional temporal and environmental metrics are allowed but not validated
    beyond structural format.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not a ``str``, or ``reason="invalid_cvss31_vector"`` if the string
            fails structural, presence, or value checks.
    """
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{field}' must be a string, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if not _re_cvss31_vector.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CVSS 3.1 vector string: {value!r}. "
            "Expected 'CVSS:3.1/' followed by 'Metric:Value' pairs separated by '/'.",
            field=field,
            reason="invalid_cvss31_vector",
        )
    metrics_str = value[len('CVSS:3.1/'):]
    metrics = dict(pair.split(':', 1) for pair in metrics_str.split('/'))
    for metric, valid_vals in _CVSS3X_BASE_METRICS.items():
        if metric not in metrics:
            raise CyverDataValidationError(
                f"'{field}' CVSS 3.1 vector is missing required base metric '{metric}'.",
                field=field,
                reason="invalid_cvss31_vector",
            )
        if metrics[metric] not in valid_vals:
            raise CyverDataValidationError(
                f"'{field}' CVSS 3.1 vector has invalid value for metric '{metric}': "
                f"{metrics[metric]!r}. Expected one of {sorted(valid_vals)}.",
                field=field,
                reason="invalid_cvss31_vector",
            )


def _validate_cvss30_vector(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid CVSS v3.0 vector string.

    Identical validation logic to :func:`_validate_cvss31_vector` but requires
    the ``CVSS:3.0/`` prefix instead of ``CVSS:3.1/``.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not a ``str``, or ``reason="invalid_cvss30_vector"`` if the string
            fails structural, presence, or value checks.
    """
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{field}' must be a string, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if not _re_cvss30_vector.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CVSS 3.0 vector string: {value!r}. "
            "Expected 'CVSS:3.0/' followed by 'Metric:Value' pairs separated by '/'.",
            field=field,
            reason="invalid_cvss30_vector",
        )
    metrics_str = value[len('CVSS:3.0/'):]
    metrics = dict(pair.split(':', 1) for pair in metrics_str.split('/'))
    for metric, valid_vals in _CVSS3X_BASE_METRICS.items():
        if metric not in metrics:
            raise CyverDataValidationError(
                f"'{field}' CVSS 3.0 vector is missing required base metric '{metric}'.",
                field=field,
                reason="invalid_cvss30_vector",
            )
        if metrics[metric] not in valid_vals:
            raise CyverDataValidationError(
                f"'{field}' CVSS 3.0 vector has invalid value for metric '{metric}': "
                f"{metrics[metric]!r}. Expected one of {sorted(valid_vals)}.",
                field=field,
                reason="invalid_cvss30_vector",
            )


def _validate_cvss20_vector(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid CVSS v2.0 vector string.

    CVSS 2.0 vector strings carry no version prefix.  Both the bare form
    (``AV:N/AC:L/Au:N/C:P/I:P/A:P``) and the parenthesised form
    (``(AV:N/AC:L/Au:N/C:P/I:P/A:P)``) are accepted; outer parentheses are
    stripped before validation.

    Validation steps:

    1. Outer parentheses stripped if present.
    2. Structural check — the stripped string must match ``_re_cvss20_vector``
       (``Metric:Value`` pairs separated by ``/``, no ``CVSS:`` prefix).
    3. Base-metric presence — all six required base metrics (``AV``, ``AC``,
       ``Au``, ``C``, ``I``, ``A``) must be present.
    4. Base-metric value check — each required metric's value must be one of
       its defined valid values (see ``_CVSS20_BASE_METRICS``).

    Optional temporal and environmental metrics are allowed but not validated
    beyond structural format.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is
            not a ``str``, or ``reason="invalid_cvss20_vector"`` if the string
            fails structural, presence, or value checks.
    """
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{field}' must be a string, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    stripped = value[1:-1] if (value.startswith('(') and value.endswith(')')) else value
    if not _re_cvss20_vector.match(stripped):
        raise CyverDataValidationError(
            f"'{field}' is not a valid CVSS 2.0 vector string: {value!r}. "
            "Expected 'AV:x/AC:x/Au:x/C:x/I:x/A:x' (no version prefix; "
            "optional enclosing parentheses accepted).",
            field=field,
            reason="invalid_cvss20_vector",
        )
    metrics = dict(pair.split(':', 1) for pair in stripped.split('/'))
    for metric, valid_vals in _CVSS20_BASE_METRICS.items():
        if metric not in metrics:
            raise CyverDataValidationError(
                f"'{field}' CVSS 2.0 vector is missing required base metric '{metric}'.",
                field=field,
                reason="invalid_cvss20_vector",
            )
        if metrics[metric] not in valid_vals:
            raise CyverDataValidationError(
                f"'{field}' CVSS 2.0 vector has invalid value for metric '{metric}': "
                f"{metrics[metric]!r}. Expected one of {sorted(valid_vals)}.",
                field=field,
                reason="invalid_cvss20_vector",
            )


def _validate_url(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a well-formed HTTP/HTTPS URL.

    Uses :data:`_re_url` for matching.  Accepts ``http://`` and ``https://``
    schemes with a domain name, ``localhost``, or IPv4 host, an optional port,
    and an optional path / query / fragment.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_url"`` if *value* does not
            match :data:`_re_url`.
    """
    if not _re_url.match(value):
        raise CyverDataValidationError(
            f"'{field}' is not a valid HTTP/HTTPS URL: {value!r}.",
            field=field,
            reason="invalid_url",
        )


def _validate_ip(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid IPv4 or IPv6 address.

    Delegates to :func:`ipaddress.ip_address` from the Python standard library for
    authoritative validation of both IPv4 (dotted-decimal) and IPv6 (including all
    compressed forms such as ``::1`` and ``2001:db8::1``).

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_ip"`` if *value* is not a
            valid IPv4 or IPv6 address string.
    """
    try:
        _ip_address(value)
    except ValueError:
        raise CyverDataValidationError(
            f"'{field}' is not a valid IPv4 or IPv6 address: {value!r}.",
            field=field,
            reason="invalid_ip",
        )


def _validate_port(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid transport-layer port number.

    Valid port numbers are integers in the range 0–65535 (inclusive), covering
    the full IANA port space (well-known, registered, and dynamic/private ports).
    Boolean values are explicitly rejected even though ``bool`` is a subclass of
    ``int`` in Python.

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not
            an ``int`` (or is a ``bool``), or ``reason="invalid_port"`` if *value* is
            outside the range 0–65535.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an integer port number, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if not (0 <= value <= 65535):
        raise CyverDataValidationError(
            f"'{field}' port number must be in the range 0–65535, got {value!r}.",
            field=field,
            reason="invalid_port",
        )


def _validate_finding_compliance_status(value: int, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid finding compliance status code.

    Valid values are the integer codes defined on :class:`_finding_compliance_status`:
    ``0`` (Pass) and ``1`` (Fail).

    Args:
        value: The integer to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_type"`` if *value* is not an
            ``int`` (or is a ``bool``), or ``reason="invalid_value"`` if *value* is
            not in :attr:`_finding_compliance_status._valid`.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{field}' must be an int, got {type(value).__name__}.",
            field=field,
            reason="invalid_type",
        )
    if value not in _finding_compliance_status._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_finding_compliance_status._valid)}, "
            f"got {value!r}.",
            field=field,
            reason="invalid_value",
        )


def _validate_project_status(value: str, field: str) -> None:
    """Raise ``CyverDataValidationError`` if *value* is not a valid project status string.

    Valid values match the string aliases defined on :class:`_project_status`:
    ``"REQUESTED"``, ``"SCHEDULED"``, ``"ONBOARDING"``, ``"TESTING"``,
    ``"REPORTING"``, ``"REMEDIATION"``, ``"ONHOLD"``, ``"COMPLETED"``,
    ``"CANCELLED"``.

    Args:
        value: The string to validate.
        field: API field name used in the error message.

    Raises:
        CyverDataValidationError: With ``reason="invalid_value"`` if *value* is
            not in :attr:`_project_status._valid`.
    """
    if value not in _project_status._valid:
        raise CyverDataValidationError(
            f"'{field}' must be one of {sorted(_project_status._valid)}, "
            f"got {value!r}.",
            field=field,
            reason="invalid_value",
        )
