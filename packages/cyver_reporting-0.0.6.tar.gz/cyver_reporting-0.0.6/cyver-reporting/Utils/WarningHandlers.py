#!/usr/bin/env python3

"""Runtime warnings emitted by the cyver-reporting library.

Kept in a dedicated module so additional warning classes and
decorator-style emitters can land here without churning unrelated
files.  All warnings subclass the stdlib :class:`Warning` hierarchy
and are filterable via the standard :mod:`warnings` module.
"""

from __future__ import annotations

from functools import wraps
from typing import Callable, TypeVar
import warnings


__all__ = [
    "CyverPortalInstabilityWarning",
    "portal_unstable",
]


F = TypeVar("F", bound=Callable[..., object])


class CyverPortalInstabilityWarning(UserWarning):
    """Emitted the first time a portal-surface method is called.

    The Cyver web frontend API consumed by :class:`PentesterPortal` and
    :class:`ClientPortal` is undocumented and may change without notice.
    Methods that wrap it are decorated with :func:`portal_unstable`, which
    raises this warning on their first invocation to remind callers that
    the surface is not covered by the library's stability guarantees.

    Subclass of :class:`UserWarning` so it's visible by default and can
    be silenced via the standard :mod:`warnings` filters::

        import warnings
        from CyverReporting import CyverPortalInstabilityWarning

        warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
    """


def portal_unstable(func: F) -> F:
    """Decorator that flags a method as part of the undocumented portal surface.

    The first call of the decorated function emits exactly one
    :class:`CyverPortalInstabilityWarning`; subsequent calls on the
    *same* decorated function are silent.  Warn-once tracking is
    per-decorated-function, not per-class or per-instance, so two
    independently-decorated methods each warn once.

    Intended for methods on :class:`PentesterPortal` and
    :class:`ClientPortal` that wrap frontend-only API endpoints.  The
    stable V2.2 surface inherited from :class:`PentesterSession` and
    :class:`ClientSession` is **not** decorated.

    Example::

        class PentesterPortal(PentesterSession):
            @portal_unstable
            def some_frontend_only_method(self, ...):
                ...

    Args:
        func: The method to wrap.

    Returns:
        A wrapper that emits the warning on first call, then delegates.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not wrapper._warned:
            wrapper._warned = True
            warnings.warn(
                f"{func.__qualname__} is part of the undocumented portal "
                "surface and may change without notice.",
                CyverPortalInstabilityWarning,
                stacklevel=2,
            )
        return func(*args, **kwargs)

    wrapper._warned = False  # type: ignore[attr-defined]
    return wrapper  # type: ignore[return-value]
