#!/usr/bin/env python3

from __future__ import annotations


# ---------------------------------------------------------------------------
# Static alias classes — asset field constants
# ---------------------------------------------------------------------------

class _asset_type:
    """Alias constants for the asset ``type`` field.

    Usage::

        asset.set_type(_asset_type.web)         # → 2
        asset.set_type(_asset_type.mobile)      # → 3
        asset.set_type(_asset_type.cloud)       # → 14
    """
    web            = 2
    mobile         = 3
    api            = 4
    network        = 5
    wifi           = 6
    ad             = 7
    physical       = 8
    hardware       = 9
    smart_contract = 10
    source_code    = 11
    user           = 12
    other          = 13
    cloud          = 14

    _valid: frozenset[int] = frozenset({2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14})
    _names: dict[int, str] = {
        2:  "Web Application",
        3:  "Mobile Application",
        4:  "API",
        5:  "Network",
        6:  "Wifi Network",
        7:  "Active Directory",
        8:  "Physical Asset",
        9:  "Hardware Device",
        10: "Smart Contract",
        11: "Source Code",
        12: "User",
        13: "Other",
        14: "Cloud Resource",
    }


class _asset_env:
    """Alias constants for the asset ``environment`` field.

    Usage::

        asset.set_environment(_asset_env.prod)  # → 3
        asset.set_environment(_asset_env.dev)   # → 1
    """
    unknown = 0
    dev     = 1
    test    = 2
    prod    = 3

    _valid: frozenset[int] = frozenset({0, 1, 2, 3})
    _names: dict[int, str] = {
        0: "Unknown",
        1: "Development",
        2: "Test",
        3: "Production",
    }


class _asset_hosting:
    """Alias constants for the asset ``hostingType`` field.

    Usage::

        asset.set_hosting_type(_asset_hosting.aws)      # → 2
        asset.set_hosting_type(_asset_hosting.on_prem)  # → 5
    """
    azure         = 1
    aws           = 2
    gcp           = 3
    other_public  = 4
    on_prem       = 5
    private_cloud = 6
    other         = 7

    _valid: frozenset[int] = frozenset({1, 2, 3, 4, 5, 6, 7})
    _names: dict[int, str] = {
        1: "Public Cloud (Azure)",
        2: "Public Cloud (AWS)",
        3: "Public Cloud (Google Cloud)",
        4: "Public Cloud (Other)",
        5: "On-premise Infrastructure",
        6: "Private Cloud",
        7: "Other",
    }


class _asset_hardware:
    """Alias constants for the asset ``typeHardware`` field.

    Usage::

        asset.set_type_hardware(_asset_hardware.laptop)  # → 3
        asset.set_type_hardware(_asset_hardware.iot)     # → 5
    """
    other       = 0
    workstation = 1
    desktop     = 2
    laptop      = 3
    printer     = 4
    iot         = 5
    cloud       = 6

    _valid: frozenset[int] = frozenset({0, 1, 2, 3, 4, 5, 6})
    _names: dict[int, str] = {
        0: "Other",
        1: "Workstation",
        2: "Desktop",
        3: "Laptop",
        4: "Printer",
        5: "IoT Device",
        6: "Cloud",
    }


class _asset_exposure:
    """Alias constants for the asset ``publicFacing`` field.

    Usage::

        asset.set_public_facing(_asset_exposure.external)  # → 2
        asset.set_public_facing(_asset_exposure.internal)  # → 1
    """
    unknown  = 0
    internal = 1
    external = 2

    _valid: frozenset[int] = frozenset({0, 1, 2})
    _names: dict[int, str] = {
        0: "Unknown",
        1: "Internal",
        2: "External",
    }


# ---------------------------------------------------------------------------
# Static alias classes — user & status constants
# ---------------------------------------------------------------------------

class _user_role:
    """Alias constants for the user ``role`` field.

    Usage::

        user.set_role(_user_role.pentester_general)   # → 7
        user.set_role(_user_role.cient_manager)       # → 4

    Roles 0–4 are Client roles. When any of these is selected, ``client_id``
    becomes mandatory and must be set before dispatching a POST or PUT request.
    The set of Client role codes is exposed as :attr:`_client_roles`.
    """
    client_project_view       = 0
    client_finding_only       = 1
    client_project_only       = 2
    client_general            = 3
    cient_manager             = 4   # noqa: intentional spelling from API spec
    pentester_view            = 5
    pentester_project_only    = 6
    pentester_general         = 7
    pentester_project_manager = 8
    pentester_manager         = 9
    pentester_owner           = 10
    team_manager              = 11

    _valid: frozenset[int] = frozenset({0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11})
    _client_roles: frozenset[int] = frozenset({0, 1, 2, 3, 4})
    _names: dict[int, str] = {
        0:  "Client (Project view-only)",
        1:  "Client (Finding only)",
        2:  "Client (Project only)",
        3:  "Client (General)",
        4:  "Client (Manager)",
        5:  "Pentester (View-only)",
        6:  "Pentester (Project only)",
        7:  "Pentester (General)",
        8:  "Pentester (Project Manager)",
        9:  "Pentester (Manager)",
        10: "Pentester (Owner)",
        11: "Pentester (Team Manager)",
    }


class _client_status:
    """Alias constants for the client ``status`` filter field.

    Usage::

        pentester.get_clients(filter_status=_client_status.active)
        pentester.get_clients(filter_status=_client_status.signup)

    Available aliases and their integer codes:

    ============== ====== =================
    Alias          Code   Printable name
    ============== ====== =================
    active         ``0``  ``"Active"``
    inactive       ``1``  ``"Inactive"``
    new            ``2``  ``"New"``
    signup         ``3``  ``"Sign-Up"``
    ============== ====== =================
    """
    active   = 0
    inactive = 1
    new      = 2
    signup   = 3

    _valid: frozenset[int] = frozenset({0, 1, 2, 3})
    _names: dict[int, str] = {
        0: "Active",
        1: "Inactive",
        2: "New",
        3: "Sign-Up",
    }


class _project_status:
    """Alias constants for the project ``status`` field.

    Use the string aliases when filtering projects or updating project status.
    All aliases resolve to uppercase string values that are sent directly to
    the Cyver API.

    Usage::

        pentester.get_projects(filter_status=_project_status.testing)
        pentester.update_project_status_by_id(pid, _project_status.testing)
        project.set_status(_project_status.onboarding)

    Available aliases and their string values:

    ============== ==============
    Alias          String value
    ============== ==============
    requested      ``"REQUESTED"``
    scheduled      ``"SCHEDULED"``
    onboarding     ``"ONBOARDING"``
    testing        ``"TESTING"``
    reporting      ``"REPORTING"``
    remediation    ``"REMEDIATION"``
    on_hold        ``"ONHOLD"``
    done           ``"DONE"``
    completed      ``"COMPLETED"``
    cancelled      ``"CANCELLED"``
    ============== ==============
    """
    requested   = "REQUESTED"
    scheduled   = "SCHEDULED"
    onboarding  = "ONBOARDING"
    testing     = "TESTING"
    reporting   = "REPORTING"
    remediation = "REMEDIATION"
    on_hold     = "ONHOLD"
    done        = "DONE"
    completed   = "COMPLETED"
    cancelled   = "CANCELLED"

    _valid: frozenset[str] = frozenset({
        "REQUESTED", "SCHEDULED", "ONBOARDING", "TESTING",
        "REPORTING", "REMEDIATION", "ONHOLD", "DONE", "COMPLETED", "CANCELLED",
    })


# ---------------------------------------------------------------------------
# Static alias classes — finding field constants
# ---------------------------------------------------------------------------

class _finding_compliance_status:
    """Alias constants for the finding ``complianceStatus`` field.

    Usage::

        finding.set_compliance_status(_finding_compliance_status.pass_)  # → 0
        finding.set_compliance_status(_finding_compliance_status.fail)    # → 1

    Note: the ``pass`` alias is spelled ``pass_`` because ``pass`` is a
    reserved keyword in Python.

    ============== ====== =================
    Alias          Code   Printable name
    ============== ====== =================
    pass_          ``0``  ``"Pass"``
    fail           ``1``  ``"Fail"``
    ============== ====== =================
    """
    pass_ = 0   # noqa: trailing underscore avoids conflict with the `pass` keyword
    fail  = 1

    _valid: frozenset[int] = frozenset({0, 1})
    _names: dict[int, str] = {
        0: "Pass",
        1: "Fail",
    }


class _finding_severity:
    """Alias constants for the finding ``severity`` field.

    Usage::

        finding.set_severity(_finding_severity.high)      # → 3
        finding.set_severity(_finding_severity.critical)  # → 4

    ============== ====== =================
    Alias          Code   Printable name
    ============== ====== =================
    info           ``0``  ``"Info"``
    low            ``1``  ``"Low"``
    medium         ``2``  ``"Medium"``
    high           ``3``  ``"High"``
    critical       ``4``  ``"Critical"``
    ============== ====== =================
    """
    info     = 0
    low      = 1
    medium   = 2
    high     = 3
    critical = 4

    _valid: frozenset[int] = frozenset({0, 1, 2, 3, 4})
    _names: dict[int, str] = {
        0: "Info",
        1: "Low",
        2: "Medium",
        3: "High",
        4: "Critical",
    }


class _finding_status:
    """Alias constants for the finding ``status`` field.

    Usage::

        finding.set_status(_finding_status.draft)           # → 1
        finding.set_status(_finding_status.pending_fix)     # → 2
        finding.set_status(_finding_status.false_positive)  # → 10

    =================== ====== =====================
    Alias               Code   Printable name
    =================== ====== =====================
    draft               ``1``  ``"Draft"``
    pending_fix         ``2``  ``"Pending Fix"``
    fixed               ``3``  ``"Fixed"``
    retest_requested    ``4``  ``"Retest Requested"``
    accepted            ``5``  ``"Accepted"``
    to_review           ``6``  ``"To Review"``
    reviewed            ``7``  ``"Reviewed"``
    mitigated           ``8``  ``"Mitigated"``
    partial_fix         ``9``  ``"Partial Fix"``
    false_positive      ``10`` ``"False Positive"``
    raised              ``11`` ``"Raised"``
    re_open             ``12`` ``"Re-Open"``
    acknowledged        ``13`` ``"Acknowledged"``
    identified          ``14`` ``"Identified"``
    =================== ====== =====================
    """
    draft            = 1
    pending_fix      = 2
    fixed            = 3
    retest_requested = 4
    accepted         = 5
    to_review        = 6
    reviewed         = 7
    mitigated        = 8
    partial_fix      = 9
    false_positive   = 10
    raised           = 11
    re_open          = 12
    acknowledged     = 13
    identified       = 14

    _valid: frozenset[int] = frozenset({1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14})
    _names: dict[int, str] = {
        1:  "Draft",
        2:  "Pending Fix",
        3:  "Fixed",
        4:  "Retest Requested",
        5:  "Accepted",
        6:  "To Review",
        7:  "Reviewed",
        8:  "Mitigated",
        9:  "Partial Fix",
        10: "False Positive",
        11: "Raised",
        12: "Re-Open",
        13: "Acknowledged",
        14: "Identified",
    }


class _finding_type:
    """Alias constants for the finding ``findingType`` field.

    Values are powers of two and may be combined as bitflags.

    Usage::

        finding.set_type(_finding_type.vulnerability)  # → 1
        finding.set_type(_finding_type.observation)    # → 4

    ================ ====== =================
    Alias            Code   Printable name
    ================ ====== =================
    vulnerability    ``1``  ``"Vulnerability"``
    nonconformity    ``2``  ``"Nonconformity"``
    observation      ``4``  ``"Observation"``
    incident         ``8``  ``"Incident"``
    risk             ``16`` ``"Risk"``
    ================ ====== =================
    """
    vulnerability = 1
    nonconformity = 2
    observation   = 4
    incident      = 8
    risk          = 16

    _valid: frozenset[int] = frozenset({1, 2, 4, 8, 16})
    _names: dict[int, str] = {
        1:  "Vulnerability",
        2:  "Nonconformity",
        4:  "Observation",
        8:  "Incident",
        16: "Risk",
    }


class _finding_library:
    """Alias constants for the finding ``library`` field.

    Distinguishes draft entries from published entries within a finding
    library — drafts are visible only to the authoring pentester team;
    published entries become reusable across projects.

    The ``_codes`` mapping is the reverse of ``_names`` and is used to
    parse server responses that carry the printable name (e.g.
    ``"Draft"``) instead of the integer code (e.g. ``1``).  ``GET``
    responses on the finding-library portal endpoints exhibit this
    name-string encoding for ``status`` and
    ``findingLibraryTemplateStatus`` fields.

    Usage::

        finding.set_library(_finding_library.draft)      # → 1
        finding.set_library(_finding_library.published)  # → 2

    ========= ====== ================
    Alias     Code   Printable name
    ========= ====== ================
    draft     ``1``  ``"Draft"``
    published ``2``  ``"Published"``
    ========= ====== ================
    """
    draft     = 1
    published = 2

    _valid: frozenset[int] = frozenset({1, 2})
    _names: dict[int, str] = {
        1: "Draft",
        2: "Published",
    }
    _codes: dict[str, int] = {
        "Draft":     1,
        "Published": 2,
    }


# ---------------------------------------------------------------------------
# Static alias classes — project field constants
# ---------------------------------------------------------------------------

class _project_file_type:
    """Alias constants for the project-file ``type`` field.

    Identifies the kind of file attached to a project (reports, evidence,
    quotes, scanner imports, etc.). Codes are non-contiguous because the
    Cyver API reserves ID ranges for different file-handling subsystems —
    image-category attachments occupy the low single digits and the
    twenties; scanner-import formats occupy the thirties, forties, and
    fifties.

    The aliases ``other`` (``0``) and ``other_image`` (``7``) both map
    to the printable name ``"Other"`` — the Cyver API uses two distinct
    type codes to disambiguate generic attachments from image-category
    "other" files; the aliases are split accordingly so callers can
    select the right one without consulting the printable name.

    Usage::

        _project_file_type.evidence                   # → 6
        _project_file_type.import_qualys_scan_report  # → 46
        _project_file_type.final_report               # → 50

    ====================================== ======= ============================================
    Alias                                  Code    Printable name
    ====================================== ======= ============================================
    other                                  ``0``   ``"Other"``
    finding_evidence                       ``1``   ``"Finding Evidence"``
    finding_comment_upload                 ``2``   ``"Finding Comment Upload"``
    project_proposal                       ``3``   ``"Project Proposal"``
    import_finding                         ``4``   ``"Import (Finding)"``
    report                                 ``5``   ``"Report"``
    evidence                               ``6``   ``"Evidence"``
    other_image                            ``7``   ``"Other"``
    asset                                  ``8``   ``"Asset"``
    quote                                  ``23``  ``"Quote"``
    invoice                                ``24``  ``"Invoice"``
    indemnity                              ``25``  ``"Indemnity"``
    import_benchmark                       ``29``  ``"Import (Benchmark)"``
    import_cyver_xml                       ``31``  ``"Import (Cyver XML)"``
    import_cyver_csv                       ``32``  ``"Import (Cyver CSV)"``
    import_burp                            ``33``  ``"Import (Burp)"``
    import_nessus_csv                      ``34``  ``"Import (Nessus CSV)"``
    import_nmap                            ``35``  ``"Import (Nmap)"``
    import_qualys_asset_report             ``36``  ``"Import (Qualys Asset Report)"``
    import_invicti                         ``37``  ``"Import (Invicti)"``
    import_nexpose                         ``38``  ``"Import (Nexpose)"``
    import_openvas                         ``39``  ``"Import (OpenVas)"``
    import_zap                             ``40``  ``"Import (Zap)"``
    import_acunetix                        ``41``  ``"Import (Acunetix)"``
    import_blindspot                       ``42``  ``"Import (Blindspot)"``
    import_carbon_black                    ``43``  ``"Import (Carbon Black)"``
    import_plextrac                        ``44``  ``"Import (Plextrac)"``
    import_qualys_scan_report              ``46``  ``"Import (Qualys Scan Report)"``
    import_prowler                         ``47``  ``"Import (Prowler)"``
    import_nessus_xml                      ``48``  ``"Import (Nessus XML)"``
    import_scout                           ``49``  ``"Import (Scout)"``
    final_report                           ``50``  ``"Final Report"``
    import_qualys_scan_api_report          ``51``  ``"Import (Qualys Scan API Report)"``
    import_purple_knight                   ``52``  ``"Import (Purple Knight)"``
    import_hcl_appscan                     ``53``  ``"Import (HCL AppScan)"``
    import_snyk                            ``54``  ``"Import (Snyk)"``
    import_checkmarx                       ``55``  ``"Import (Checkmarx)"``
    import_appcheck                        ``56``  ``"Import (AppCheck)"``
    import_nipper                          ``57``  ``"Import (Nipper)"``
    import_evidence                        ``58``  ``"Import Evidence"``
    import_pentest_tools_network_scanner   ``59``  ``"Import (Pentest Tools Network Scanner)"``
    import_pentest_tools_website_scanner   ``60``  ``"Import (Pentest Tools Website Scanner)"``
    import_horizon3_nodezero               ``61``  ``"Import (Horizon3 NodeZero)"``
    ====================================== ======= ============================================
    """
    other                                = 0
    finding_evidence                     = 1
    finding_comment_upload               = 2
    project_proposal                     = 3
    import_finding                       = 4
    report                               = 5
    evidence                             = 6
    other_image                          = 7
    asset                                = 8
    quote                                = 23
    invoice                              = 24
    indemnity                            = 25
    import_benchmark                     = 29
    import_cyver_xml                     = 31
    import_cyver_csv                     = 32
    import_burp                          = 33
    import_nessus_csv                    = 34
    import_nmap                          = 35
    import_qualys_asset_report           = 36
    import_invicti                       = 37
    import_nexpose                       = 38
    import_openvas                       = 39
    import_zap                           = 40
    import_acunetix                      = 41
    import_blindspot                     = 42
    import_carbon_black                  = 43
    import_plextrac                      = 44
    import_qualys_scan_report            = 46
    import_prowler                       = 47
    import_nessus_xml                    = 48
    import_scout                         = 49
    final_report                         = 50
    import_qualys_scan_api_report        = 51
    import_purple_knight                 = 52
    import_hcl_appscan                   = 53
    import_snyk                          = 54
    import_checkmarx                     = 55
    import_appcheck                      = 56
    import_nipper                        = 57
    import_evidence                      = 58
    import_pentest_tools_network_scanner = 59
    import_pentest_tools_website_scanner = 60
    import_horizon3_nodezero             = 61

    _valid: frozenset[int] = frozenset({
        0, 1, 2, 3, 4, 5, 6, 7, 8,
        23, 24, 25, 29,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44,
        46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,
    })
    _names: dict[int, str] = {
        0:  "Other",
        1:  "Finding Evidence",
        2:  "Finding Comment Upload",
        3:  "Project Proposal",
        4:  "Import (Finding)",
        5:  "Report",
        6:  "Evidence",
        7:  "Other",
        8:  "Asset",
        23: "Quote",
        24: "Invoice",
        25: "Indemnity",
        29: "Import (Benchmark)",
        31: "Import (Cyver XML)",
        32: "Import (Cyver CSV)",
        33: "Import (Burp)",
        34: "Import (Nessus CSV)",
        35: "Import (Nmap)",
        36: "Import (Qualys Asset Report)",
        37: "Import (Invicti)",
        38: "Import (Nexpose)",
        39: "Import (OpenVas)",
        40: "Import (Zap)",
        41: "Import (Acunetix)",
        42: "Import (Blindspot)",
        43: "Import (Carbon Black)",
        44: "Import (Plextrac)",
        46: "Import (Qualys Scan Report)",
        47: "Import (Prowler)",
        48: "Import (Nessus XML)",
        49: "Import (Scout)",
        50: "Final Report",
        51: "Import (Qualys Scan API Report)",
        52: "Import (Purple Knight)",
        53: "Import (HCL AppScan)",
        54: "Import (Snyk)",
        55: "Import (Checkmarx)",
        56: "Import (AppCheck)",
        57: "Import (Nipper)",
        58: "Import Evidence",
        59: "Import (Pentest Tools Network Scanner)",
        60: "Import (Pentest Tools Website Scanner)",
        61: "Import (Horizon3 NodeZero)",
    }
