#!/usr/bin/env python3

"""Request-construction helpers shared by the session classes.

Helpers in this module mutate or build the ``params`` / ``data``
arguments that are about to be passed to the HTTP transport layer.
This is the inverse direction of :mod:`Utils.FieldExtractors`, which
parses *responses*.
"""

from __future__ import annotations

from typing import Iterable


def _add_indexed_list(params: dict, key: str, values: Iterable | None) -> None:
    """Expand a list into ABP-style indexed query parameters.

    Mutates *params* in place: each value gets a ``key[N]`` entry.
    No-op when *values* is ``None`` or empty so callers can use the
    same expression for optional filters.

    Mirrors the wire shape captured from the Cyver portal frontend
    (e.g. ``findingStatusList[0]=1&findingStatusList[1]=2``), distinct
    from the bare repeated-key shape (``SeverityList=1&SeverityList=2``)
    that ``requests`` produces by default and that V2.2 endpoints
    accept.

    Args:
        params: The mutable params dict that will be passed to the
            HTTP transport.
        key: The base wire-key name (without the ``[N]`` suffix).
        values: The iterable of values to expand, or ``None``.
    """
    if not values:
        return
    for index, value in enumerate(values):
        params[f"{key}[{index}]"] = value
