#!/usr/bin/env python3

"""On-disk cache of the highest finding code seen per ``(prefix, year)``.

Used by :meth:`PentesterPortal.create_unique_finding_code` to short-cut
the recursive search.  Once a code has been seen, subsequent calls can
either confirm-and-bump (if no new codes were issued in the meantime)
or use the cached value as a lower bound for the recursive descent.

Cache shape (JSON, plain text — no encryption since these are not
credentials):

.. code-block:: json

    {
      "F-2026":  {"max_code": 15514, "last_updated": "2026-04-30T13:27:09Z"},
      "TP-2026": {"max_code":   145, "last_updated": "2026-04-30T13:27:09Z"}
    }

The cache file is stored at ``cache_dir / "finding_codes_cache.json"``;
when ``cache_dir`` is ``None`` (cache opt-out) all operations are no-ops
and ``get_max`` returns ``None``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

_CACHE_FILENAME = "finding_codes_cache.json"

_logger = logging.getLogger("CyverReporting")


class FindingCodeCache:
    """Per-process handle on the on-disk finding-code cache.

    Constructing the instance loads the existing cache (if any).
    Mutations are written to disk immediately so that crashed processes
    do not lose state.  All disk I/O is best-effort: on permission /
    JSON / OS errors the cache silently degrades to in-memory only,
    matching the same robust-degrade contract as the OAuth and API-key
    caches in :class:`CyverSession`.
    """

    def __init__(self, cache_dir: Path | None) -> None:
        self._dir: Path | None = cache_dir
        self._data: dict = self._load()

    def get_max(self, key: str) -> int | None:
        """Return the cached ``max_code`` for *key* (e.g. ``"F-2026"``),
        or ``None`` if the key is unknown or the cache is disabled."""
        entry = self._data.get(key)
        if not isinstance(entry, dict):
            return None
        max_code = entry.get("max_code")
        if not isinstance(max_code, int):
            return None
        return max_code

    def update_max(self, key: str, max_code: int) -> None:
        """Update the cached ``max_code`` for *key* (only when *max_code*
        is greater than what is already cached) and persist."""
        existing = self.get_max(key)
        if existing is not None and existing >= max_code:
            return
        self._data[key] = {
            "max_code":     max_code,
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }
        self._save()

    def _load(self) -> dict:
        if self._dir is None:
            return {}
        path = self._dir / _CACHE_FILENAME
        if not path.is_file():
            return {}
        try:
            text = path.read_text()
            data = json.loads(text)
            if not isinstance(data, dict):
                return {}
            return data
        except (OSError, json.JSONDecodeError) as err:
            _logger.warning(
                "Could not load finding-code cache at %s: %s — starting fresh.",
                path, err,
            )
            return {}

    def _save(self) -> None:
        if self._dir is None:
            return
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            path = self._dir / _CACHE_FILENAME
            path.write_text(json.dumps(self._data, indent=2, sort_keys=True))
        except OSError as err:
            _logger.warning(
                "Could not save finding-code cache to %s: %s.", self._dir, err,
            )
