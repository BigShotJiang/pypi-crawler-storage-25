#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from .FormatValidators import _validate_uuid
from .FormatValidators import _validate_datetime, _validate_date, _validate_project_status
from .RegExPatterns import _re_cyver_code


# ---------------------------------------------------------------------------
# Sentinel values — .NET serialises unset date/datetime fields as MinValue
# instead of null. Treat these as absent (return None) during deserialisation.
# ---------------------------------------------------------------------------

_sentinels_datetime: frozenset[str] = frozenset({
    "",
    "0001-01-01T00:00:00",
    "0001-01-01T00:00:00Z",
    "0001-01-01T00:00:00.0Z",
    "0001-01-01T00:00:00.000000Z",
    "0001-01-01T00:00:00.0000000Z",
})

_sentinels_date: frozenset[str] = frozenset({
    "",
    "0001-01-01",
})

_sentinels_uuid: frozenset[str] = frozenset({
    "",
    "00000000-0000-0000-0000-000000000000",
})


# ---------------------------------------------------------------------------
# Private helpers shared by all read-only from_dict() class methods
# ---------------------------------------------------------------------------

def _fd_require_id(data: dict) -> str:
    """Return the validated ``id`` value from *data*, or raise ``CyverDataValidationError``."""
    if "id" not in data:
        raise CyverDataValidationError(
            "'id' is required but was not found in the response data.",
            field="id",
            reason="missing_required",
        )
    if not isinstance(data["id"], str):
        raise CyverDataValidationError(
            f"'id' must be a valid UUID string, got {data['id']!r}.",
            field="id",
            reason="invalid_uuid",
        )
    _validate_uuid(data["id"], "id")
    return data["id"]


def _fd_optional_str(data: dict, key: str) -> str | None:
    """Return ``data[key]`` as ``str | None``, raising on wrong type."""
    value = data.get(key)
    if value is not None and not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be a string, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    return value


def _fd_optional_int(data: dict, key: str) -> int | None:
    """Return ``data[key]`` as ``int | None``, raising on wrong type or bool."""
    value = data.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise CyverDataValidationError(
            f"'{key}' must be an int, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    return value


def _fd_optional_bool(data: dict, key: str) -> bool | None:
    """Return ``data[key]`` as ``bool | None``, raising on wrong type."""
    value = data.get(key)
    if value is not None and not isinstance(value, bool):
        raise CyverDataValidationError(
            f"'{key}' must be a bool, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    return value


def _fd_optional_uuid(data: dict, key: str) -> str | None:
    """Return ``data[key]`` as a validated UUID string or ``None``.

    Empty strings and the .NET ``Guid.Empty`` sentinel
    (``"00000000-0000-0000-0000-000000000000"`` — see
    :data:`_sentinels_uuid`) are treated as absent and return ``None``.
    The first case covers the V2.2 convention of serialising unset
    UUID fields as ``""``; the second covers the portal-surface
    convention of serialising them as the zero GUID.  GUID and UUID
    are treated interchangeably in this project.
    """
    value = data.get(key)
    if value is None or value in _sentinels_uuid:
        return None
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be a valid UUID string, got {value!r}.",
            field=key,
            reason="invalid_uuid",
        )
    _validate_uuid(value, key)
    return value


def _fd_optional_uuid_alias(data: dict, *keys: str) -> str | None:
    """Return a validated UUID from the first present, non-sentinel key.

    Cyver's portal and V2.2 API surfaces use interchangeable spellings
    for the same identifier — most commonly ``id`` / ``guid``,
    ``clientId`` / ``clientGuid``, ``projectId`` / ``projectGuid``.
    This helper reads through *keys* in order and returns the first
    value that ``_fd_optional_uuid`` resolves to a real UUID; sentinel
    or missing values fall through to the next key.

    Args:
        data: The response dict.
        *keys: One or more candidate keys, tried in order. The first
            key whose value validates as a non-sentinel UUID is
            returned.

    Returns:
        The validated UUID string, or ``None`` if every candidate key
        is missing or holds a sentinel value.

    Raises:
        ValueError: If no keys are supplied.
        CyverDataValidationError: If a key holds a non-string value or
            a malformed UUID string (delegated to ``_fd_optional_uuid``).
    """
    if not keys:
        raise ValueError("at least one key is required")
    for key in keys:
        result = _fd_optional_uuid(data, key)
        if result is not None:
            return result
    return None


def _fd_uuid_list(data: dict, key: str) -> list[str]:
    """Return ``data[key]`` as a validated list of UUID strings.

    Each entry is accepted in either of two forms:

    - A bare UUID string, e.g. ``"01234567-89ab-cdef-0123-456789abcdef"``.
    - An object with a string ``id`` field, e.g.
      ``{"id": "01234567-89ab-...", "text": "Black-Box", "type": 2}``. The
      Cyver API returns ``labelList`` items in this richer form on
      ``GET /projects`` (and other label-bearing endpoints); the ``id`` is
      extracted and the surrounding metadata is discarded.

    Mixed lists are supported. Anything that is neither a string nor an
    object with a string ``id`` field raises ``CyverDataValidationError``,
    as does any UUID that fails format validation.
    """
    raw = data.get(key) or []
    if not isinstance(raw, list):
        raise CyverDataValidationError(
            f"'{key}' must be a list, got {type(raw).__name__}.",
            field=key,
            reason="invalid_type",
        )
    out: list[str] = []
    for i, item in enumerate(raw):
        if isinstance(item, str):
            value = item
        elif isinstance(item, dict) and isinstance(item.get("id"), str):
            value = item["id"]
        else:
            raise CyverDataValidationError(
                f"'{key}[{i}]' must be a string or an object with a string "
                f"'id' field, got {type(item).__name__}.",
                field=key,
                reason="invalid_type",
            )
        _validate_uuid(value, f"{key}[{i}]")
        out.append(value)
    return out


def _fd_nested_list(data: dict, key: str, item_class: type) -> list:
    """Return ``data[key]`` as a list of objects parsed via ``item_class.from_dict()``."""
    raw = data.get(key) or []
    if not isinstance(raw, list):
        raise CyverDataValidationError(
            f"'{key}' must be a list, got {type(raw).__name__}.",
            field=key,
            reason="invalid_type",
        )
    return [item_class.from_dict(item) for item in raw]


def _fd_optional_datetime(data: dict, key: str) -> str | None:
    """Return ``data[key]`` as a validated datetime string or ``None``.

    Empty strings and .NET ``DateTime.MinValue`` sentinel values
    (``_sentinels_datetime``) are treated as absent and return ``None``.
    """
    value = data.get(key)
    if value is None or value in _sentinels_datetime:
        return None
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be a string, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    _validate_datetime(value, key)
    return value


def _fd_optional_date(data: dict, key: str) -> str | None:
    """Return ``data[key]`` as a validated date string (``YYYY-MM-DD``) or ``None``.

    Empty strings and the .NET ``DateOnly.MinValue`` sentinel (``"0001-01-01"``)
    are treated as absent and return ``None``.
    """
    value = data.get(key)
    if value is None or value in _sentinels_date:
        return None
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be a string, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    _validate_date(value, key)
    return value


def _fd_optional_project_status(data: dict, key: str) -> str | None:
    """Return ``data[key]`` as a validated project-status string or ``None``.

    An empty string is treated as absent (returns ``None``) because the
    backend may serialise unset status fields as ``""`` instead of ``null``.
    """
    value = data.get(key)
    if not value:
        return None
    if not isinstance(value, str):
        raise CyverDataValidationError(
            f"'{key}' must be a string, got {type(value).__name__}.",
            field=key,
            reason="invalid_type",
        )
    _validate_project_status(value, key)
    return value


def _parse_cyver_code(code: str) -> tuple[str, int, int] | None:
    """Parse a Cyver finding code into ``(prefix, year, number)``.

    Returns ``None`` when *code* is malformed (does not match
    :data:`_re_cyver_code`), a non-string, or empty — callers can
    silently filter such entries from search responses without
    raising.

    Args:
        code: The finding code string, e.g. ``"F-2026-15514"``.

    Returns:
        A 3-tuple ``(prefix, year, number)`` where:

        - ``prefix`` is ``"F"`` or ``"TP"``,
        - ``year`` is the integer 4-digit year, and
        - ``number`` is the integer numeric suffix (leading zeros are
          accepted on the wire and discarded by the int conversion).

        ``None`` if *code* does not match the canonical format.
    """
    if not isinstance(code, str):
        return None
    match = _re_cyver_code.match(code)
    if match is None:
        return None
    return match.group(1), int(match.group(2)), int(match.group(3))
