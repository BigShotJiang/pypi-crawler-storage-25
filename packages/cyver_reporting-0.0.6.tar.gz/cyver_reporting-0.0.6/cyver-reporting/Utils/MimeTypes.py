#!/usr/bin/env python3

from __future__ import annotations

import mimetypes


_DEFAULT_MIME_TYPE = "application/octet-stream"


def _guess_mime_type(filename: str, default: str = _DEFAULT_MIME_TYPE) -> str:
    """Return the MIME type inferred from *filename*'s extension, or *default*.

    Thin wrapper around :func:`mimetypes.guess_type` that collapses the
    ``(type, encoding)`` tuple to the type only and substitutes
    *default* (``"application/octet-stream"`` by convention) whenever the
    extension is missing or unrecognised.

    Args:
        filename: The filename whose extension drives the lookup.  Empty or
            ``None``-ish values return *default* directly.
        default: Fallback MIME type used when the extension cannot be
            mapped.  Defaults to ``"application/octet-stream"``.

    Returns:
        The guessed MIME type, or *default* when no match is found.
    """
    if not filename:
        return default
    guessed, _ = mimetypes.guess_type(filename)
    return guessed or default
