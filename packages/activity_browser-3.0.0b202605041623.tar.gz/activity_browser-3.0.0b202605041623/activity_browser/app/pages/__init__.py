from .activity_details import ActivityDetailsPage
from .welcome import WelcomePage
from .calculation_setup import CalculationSetupPage
from .impact_category_details import ImpactCategoryDetailsPage
from .lca_results import LCAResultsPage
from .parameters import ParametersPage
from .metadatastore import MetaDataStorePage
from .settings import SettingsPage

base_pages = {
    "Welcome": WelcomePage,
    "Parameters": ParametersPage,
    "Settings": SettingsPage,
}
