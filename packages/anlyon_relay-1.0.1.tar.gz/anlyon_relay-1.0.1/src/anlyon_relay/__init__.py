"""Anlyon Relay Python SDK.

Official Python SDK for the Anlyon Relay API - Type-safe message scheduling and delivery.

Example:
    ```python
    from anlyon_relay import Client, PublishMessageRequest

    # Sync client
    client = Client(api_key="your-api-key")
    result = client.messages.publish(
        PublishMessageRequest(url="https://example.com/webhook")
    )

    # Async client
    from anlyon_relay import AsyncClient

    async with AsyncClient(api_key="your-api-key") as client:
        result = await client.messages.publish(
            PublishMessageRequest(url="https://example.com/webhook")
        )
    ```
"""

from .client import AsyncClient, Client
from .core.errors import (
    AnlyonError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    FeatureNotAvailableError,
    NetworkError,
    NotFoundError,
    ParseError,
    QuotaExceededError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)
from .helpers.builders import PublishMessageBuilder, ScheduleBuilder
from .helpers.pagination import AsyncPaginationIterator, PaginationIterator
from .types.api import (
    AddEndpointRequest,
    BatchPublishResult,
    CreateQueueRequest,
    CreateScheduleRequest,
    CreateUrlGroupRequest,
    CurrentUsage,
    DateRangeParams,
    DlqStats,
    Endpoint,
    EndpointInput,
    ErrorDistribution,
    GroupPublishResult,
    ListDlqParams,
    ListMessagesParams,
    Message,
    MessageAnalytics,
    PublishGroupMessageRequest,
    PublishMessageRequest,
    PublishResult,
    Queue,
    QueueFilters,
    Schedule,
    ScheduleExecution,
    ScheduleStats,
    SimpleMessage,
    TimeSeriesDataPoint,
    TimeSeriesParams,
    TopUrlEntry,
    TopUrlsParams,
    UpdateQueueRequest,
    UpdateScheduleRequest,
    UrlGroup,
    UrlGroupWithEndpoints,
    UsageHistoryEntry,
)
from .types.config import ClientConfig, LoggingConfig, RetryConfig
from .types.enums import (
    ErrorCode,
    HttpMethod,
    LogLevel,
    MessageStatus,
    QueueStatus,
    TimeGranularity,
)
from .types.responses import ApiError, ApiResponse, PaginatedResponse, Pagination
from .webhooks.receiver import (
    Receiver,
    ReceiverConfig,
    SignatureVerificationError,
    WebhookVerificationResult,
    verify_webhook_signature,
)
from .workflows import (
    AsyncWorkflowsResource,
    CallOptions,
    CallResult,
    CreateWorkflowRequest,
    Duration,
    FailureContext,
    ListRunsParams,
    ListWorkflowsParams,
    NotifyEventRequest,
    NotifyResult,
    ServeWorkflowOptions,
    StepExecutionError,
    StepInfo,
    StepPendingError,
    StepResult,
    TriggerResult,
    TriggerWorkflowRequest,
    UpdateWorkflowRequest,
    WaitOptions,
    WorkflowCancelledError,
    WorkflowContext,
    WorkflowDefinition,
    WorkflowRequest,
    WorkflowResponse,
    WorkflowRun,
    WorkflowsResource,
    WorkflowStep,
    create_workflow_handler,
    parse_duration,
)

__version__ = "1.0.1"

__all__ = [
    # Version
    "__version__",
    # Clients
    "AsyncClient",
    "Client",
    # Config
    "ClientConfig",
    "LoggingConfig",
    "RetryConfig",
    # Enums
    "ErrorCode",
    "HttpMethod",
    "LogLevel",
    "MessageStatus",
    "QueueStatus",
    "TimeGranularity",
    # Errors
    "AnlyonError",
    "AuthenticationError",
    "AuthorizationError",
    "ConflictError",
    "FeatureNotAvailableError",
    "NetworkError",
    "NotFoundError",
    "ParseError",
    "QuotaExceededError",
    "RateLimitError",
    "TimeoutError",
    "ValidationError",
    # Responses
    "ApiError",
    "ApiResponse",
    "PaginatedResponse",
    "Pagination",
    # Messages
    "BatchPublishResult",
    "ListMessagesParams",
    "Message",
    "PublishMessageRequest",
    "PublishResult",
    # Schedules
    "CreateScheduleRequest",
    "Schedule",
    "UpdateScheduleRequest",
    # URL Groups
    "AddEndpointRequest",
    "CreateUrlGroupRequest",
    "Endpoint",
    "EndpointInput",
    "GroupPublishResult",
    "PublishGroupMessageRequest",
    "UrlGroup",
    "UrlGroupWithEndpoints",
    # Queues
    "CreateQueueRequest",
    "Queue",
    "QueueFilters",
    "UpdateQueueRequest",
    # DLQ
    "DlqStats",
    "ListDlqParams",
    # Analytics
    "CurrentUsage",
    "DateRangeParams",
    "ErrorDistribution",
    "MessageAnalytics",
    "ScheduleExecution",
    "ScheduleStats",
    "TimeSeriesDataPoint",
    "TimeSeriesParams",
    "TopUrlEntry",
    "TopUrlsParams",
    "UsageHistoryEntry",
    # Common
    "SimpleMessage",
    # Helpers
    "AsyncPaginationIterator",
    "PaginationIterator",
    "PublishMessageBuilder",
    "ScheduleBuilder",
    # Webhooks
    "Receiver",
    "ReceiverConfig",
    "SignatureVerificationError",
    "WebhookVerificationResult",
    "verify_webhook_signature",
    # Workflows — execution engine
    "WorkflowContext",
    "create_workflow_handler",
    "CallOptions",
    "CallResult",
    "Duration",
    "FailureContext",
    "ServeWorkflowOptions",
    "StepExecutionError",
    "StepInfo",
    "StepPendingError",
    "StepResult",
    "WaitOptions",
    "WorkflowCancelledError",
    "WorkflowRequest",
    "WorkflowResponse",
    "parse_duration",
    # Workflows — API client
    "AsyncWorkflowsResource",
    "CreateWorkflowRequest",
    "ListRunsParams",
    "ListWorkflowsParams",
    "NotifyEventRequest",
    "NotifyResult",
    "TriggerResult",
    "TriggerWorkflowRequest",
    "UpdateWorkflowRequest",
    "WorkflowDefinition",
    "WorkflowRun",
    "WorkflowsResource",
    "WorkflowStep",
]
