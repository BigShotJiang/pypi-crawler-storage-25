"""Configuration types for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any, Callable, Protocol

from pydantic import BaseModel, Field

from .enums import LogLevel


class LoggerProtocol(Protocol):
    """Protocol for custom logger implementations."""

    def debug(self, message: str, **kwargs: Any) -> None:
        """Log a debug message."""
        ...

    def info(self, message: str, **kwargs: Any) -> None:
        """Log an info message."""
        ...

    def warn(self, message: str, **kwargs: Any) -> None:
        """Log a warning message."""
        ...

    def error(self, message: str, **kwargs: Any) -> None:
        """Log an error message."""
        ...


class RetryConfig(BaseModel):
    """Configuration for retry behavior."""

    max_attempts: int = Field(default=3, ge=1, le=10, description="Maximum number of retry attempts")
    initial_delay: float = Field(
        default=0.1, ge=0.01, le=60.0, description="Initial delay in seconds"
    )
    max_delay: float = Field(default=10.0, ge=0.1, le=300.0, description="Maximum delay in seconds")
    backoff_multiplier: float = Field(
        default=2.0, ge=1.0, le=10.0, description="Multiplier for exponential backoff"
    )
    jitter: bool = Field(default=True, description="Whether to add jitter to delays")
    retryable_status_codes: list[int] = Field(
        default=[429, 500, 502, 503, 504],
        description="HTTP status codes that should trigger a retry",
    )
    is_retryable: Callable[[Exception], bool] | None = Field(
        default=None, description="Custom function to determine if an error is retryable"
    )

    model_config = {"arbitrary_types_allowed": True}


class LoggingConfig(BaseModel):
    """Configuration for logging behavior."""

    enabled: bool = Field(default=False, description="Whether logging is enabled")
    level: LogLevel = Field(default=LogLevel.INFO, description="Minimum log level")
    logger: LoggerProtocol | None = Field(
        default=None, description="Custom logger implementation"
    )
    redact_sensitive: bool = Field(
        default=True, description="Whether to redact sensitive information in logs"
    )

    model_config = {"arbitrary_types_allowed": True}


class ClientConfig(BaseModel):
    """Configuration for the Anlyon Relay client."""

    api_key: str = Field(..., min_length=1, description="API key for authentication")
    base_url: str = Field(
        default="https://api.anlyon.com",
        description="Base URL for the API",
    )
    timeout: float = Field(
        default=30.0, ge=1.0, le=300.0, description="Request timeout in seconds"
    )
    retry: RetryConfig = Field(default_factory=RetryConfig, description="Retry configuration")
    logging: LoggingConfig = Field(
        default_factory=LoggingConfig, description="Logging configuration"
    )
    default_headers: dict[str, str] = Field(
        default_factory=dict, description="Default headers to include in all requests"
    )

    model_config = {"arbitrary_types_allowed": True}


class RequestOptions(BaseModel):
    """Options for individual requests."""

    params: dict[str, Any] | None = Field(default=None, description="Query parameters")
    headers: dict[str, str] | None = Field(default=None, description="Additional headers")
    timeout: float | None = Field(default=None, description="Request timeout override")

    model_config = {"extra": "forbid"}
