"""API request and response types for the Anlyon Relay SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator

from .enums import HttpMethod, MessageStatus, NotificationCategory, NotificationType, QueueStatus


# =============================================================================
# Messages
# =============================================================================


class PublishMessageRequest(BaseModel):
    """Request to publish a message."""

    url: str = Field(..., min_length=1, description="Destination URL")
    method: HttpMethod = Field(default=HttpMethod.POST, description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")
    queue: str | None = Field(
        default=None,
        pattern=r"^[a-zA-Z0-9_-]+$",
        max_length=100,
        description="Queue name",
    )
    execute_at: int | None = Field(
        default=None, description="Unix timestamp (seconds) for scheduled execution"
    )
    scheduled_for: str | None = Field(
        default=None, description="ISO 8601 timestamp for scheduled execution"
    )
    max_retries: int = Field(default=3, ge=0, le=10, description="Maximum retry attempts")
    content_id: str | None = Field(default=None, description="Idempotency key for deduplication")
    callback_url: str | None = Field(default=None, description="URL for delivery status callback")
    failure_callback_url: str | None = Field(
        default=None, description="URL for failure callback"
    )

    @field_validator("execute_at", "scheduled_for")
    @classmethod
    def validate_mutual_exclusion(cls, v: Any, info: Any) -> Any:
        """Validate that execute_at and scheduled_for are mutually exclusive."""
        return v

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format with camelCase keys."""
        data: dict[str, Any] = {"url": self.url, "method": self.method.value}

        if self.headers:
            data["headers"] = self.headers
        if self.body is not None:
            data["body"] = self.body
        if self.queue:
            data["queue"] = self.queue
        if self.execute_at is not None:
            data["executeAt"] = self.execute_at
        if self.scheduled_for:
            data["scheduledFor"] = self.scheduled_for
        if self.max_retries != 3:
            data["maxRetries"] = self.max_retries
        if self.content_id:
            data["contentId"] = self.content_id
        if self.callback_url:
            data["callbackUrl"] = self.callback_url
        if self.failure_callback_url:
            data["failureCallbackUrl"] = self.failure_callback_url

        return data


class PublishResult(BaseModel):
    """Result of publishing a message."""

    message_id: str = Field(..., alias="messageId", description="Unique message identifier")
    status: str = Field(..., description="Message status (pending or scheduled)")
    scheduled_at: str = Field(..., alias="scheduledAt", description="ISO 8601 timestamp")

    model_config = {"populate_by_name": True}


class BatchPublishResultItem(BaseModel):
    """Individual result in a batch publish operation."""

    message_id: str = Field(..., alias="messageId", description="Message identifier")
    status: str = Field(..., description="Result status (success or error)")

    model_config = {"populate_by_name": True}


class BatchPublishResult(BaseModel):
    """Result of a batch publish operation."""

    total: int = Field(..., description="Total messages in batch")
    successful: int = Field(..., description="Number of successful publishes")
    failed: int = Field(..., description="Number of failed publishes")
    results: list[BatchPublishResultItem] = Field(..., description="Individual results")


class Message(BaseModel):
    """A message in the queue."""

    id: str = Field(..., description="Internal ID")
    message_id: str = Field(..., alias="messageId", description="Public message identifier")
    workspace_id: str = Field(..., alias="workspaceId", description="Workspace identifier")
    url: str = Field(..., description="Destination URL")
    method: str = Field(..., description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")
    status: MessageStatus = Field(..., description="Current status")
    scheduled_at: str | None = Field(default=None, alias="scheduledAt", description="Scheduled time")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    updated_at: str = Field(..., alias="updatedAt", description="Last update timestamp")
    delivered_at: str | None = Field(default=None, alias="deliveredAt", description="Delivery time")
    max_retries: int = Field(..., alias="maxRetries", description="Maximum retries")
    current_retries: int = Field(..., alias="currentRetries", description="Current retry count")
    last_error: str | None = Field(default=None, alias="lastError", description="Last error message")
    http_status: int | None = Field(default=None, alias="httpStatus", description="Last HTTP status")

    model_config = {"populate_by_name": True}


class ListMessagesParams(BaseModel):
    """Parameters for listing messages."""

    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")
    status: MessageStatus | None = Field(default=None, description="Filter by status")
    start_date: str | datetime | None = Field(default=None, description="Filter by start date")
    end_date: str | datetime | None = Field(default=None, description="Filter by end date")
    url: str | None = Field(default=None, description="Filter by URL")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.status:
            params["status"] = self.status.value
        if self.start_date:
            params["startDate"] = (
                self.start_date.isoformat()
                if isinstance(self.start_date, datetime)
                else self.start_date
            )
        if self.end_date:
            params["endDate"] = (
                self.end_date.isoformat()
                if isinstance(self.end_date, datetime)
                else self.end_date
            )
        if self.url:
            params["url"] = self.url
        return params


# =============================================================================
# Schedules
# =============================================================================


class CreateScheduleRequest(BaseModel):
    """Request to create a schedule."""

    name: str = Field(..., min_length=1, max_length=100, description="Schedule name")
    cron_expression: str = Field(..., min_length=1, description="Cron expression")
    timezone: str = Field(default="UTC", description="IANA timezone")
    url: str = Field(..., min_length=1, description="Destination URL")
    method: HttpMethod = Field(default=HttpMethod.POST, description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format with camelCase keys."""
        data: dict[str, Any] = {
            "name": self.name,
            "cronExpression": self.cron_expression,
            "timezone": self.timezone,
            "url": self.url,
            "method": self.method.value,
        }
        if self.headers:
            data["headers"] = self.headers
        if self.body is not None:
            data["body"] = self.body
        return data


class UpdateScheduleRequest(BaseModel):
    """Request to update a schedule."""

    name: str | None = Field(default=None, max_length=100, description="Schedule name")
    cron_expression: str | None = Field(default=None, description="Cron expression")
    timezone: str | None = Field(default=None, description="IANA timezone")
    url: str | None = Field(default=None, description="Destination URL")
    method: HttpMethod | None = Field(default=None, description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")
    is_paused: bool | None = Field(default=None, description="Whether schedule is paused")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format with camelCase keys."""
        data: dict[str, Any] = {}
        if self.name is not None:
            data["name"] = self.name
        if self.cron_expression is not None:
            data["cronExpression"] = self.cron_expression
        if self.timezone is not None:
            data["timezone"] = self.timezone
        if self.url is not None:
            data["url"] = self.url
        if self.method is not None:
            data["method"] = self.method.value
        if self.headers is not None:
            data["headers"] = self.headers
        if self.body is not None:
            data["body"] = self.body
        if self.is_paused is not None:
            data["isPaused"] = self.is_paused
        return data


class Schedule(BaseModel):
    """A scheduled task."""

    id: str = Field(..., description="Schedule identifier")
    workspace_id: str = Field(..., alias="workspaceId", description="Workspace identifier")
    name: str = Field(..., description="Schedule name")
    cron_expression: str = Field(..., alias="cronExpression", description="Cron expression")
    timezone: str = Field(..., description="IANA timezone")
    url: str = Field(..., description="Destination URL")
    method: str = Field(..., description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")
    is_paused: bool = Field(..., alias="isPaused", description="Whether schedule is paused")
    next_run: str | None = Field(default=None, alias="nextRun", description="Next run time")
    last_run: str | None = Field(default=None, alias="lastRun", description="Last run time")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    updated_at: str = Field(..., alias="updatedAt", description="Last update timestamp")

    model_config = {"populate_by_name": True}


# =============================================================================
# URL Groups
# =============================================================================


class EndpointInput(BaseModel):
    """Input for creating an endpoint."""

    url: str = Field(..., min_length=1, description="Endpoint URL")
    name: str | None = Field(default=None, max_length=100, description="Endpoint name")
    retry_count: int = Field(default=3, ge=0, le=10, alias="retryCount", description="Retry count")

    model_config = {"populate_by_name": True}

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {"url": self.url}
        if self.name:
            data["name"] = self.name
        if self.retry_count != 3:
            data["retryCount"] = self.retry_count
        return data


class CreateUrlGroupRequest(BaseModel):
    """Request to create a URL group."""

    name: str = Field(..., min_length=1, max_length=100, description="Group name")
    endpoints: list[EndpointInput] = Field(..., min_length=1, description="Endpoints")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        return {
            "name": self.name,
            "endpoints": [e.model_dump_api() for e in self.endpoints],
        }


class PublishGroupMessageRequest(BaseModel):
    """Request to publish a message to a URL group."""

    method: HttpMethod = Field(default=HttpMethod.POST, description="HTTP method")
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")
    body: Any | None = Field(default=None, description="Request body")
    execute_at: int | None = Field(default=None, description="Unix timestamp for scheduling")
    scheduled_for: str | None = Field(default=None, description="ISO 8601 timestamp for scheduling")
    max_retries: int = Field(default=3, ge=0, le=10, description="Maximum retries")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {"method": self.method.value}
        if self.headers:
            data["headers"] = self.headers
        if self.body is not None:
            data["body"] = self.body
        if self.execute_at is not None:
            data["executeAt"] = self.execute_at
        if self.scheduled_for:
            data["scheduledFor"] = self.scheduled_for
        if self.max_retries != 3:
            data["maxRetries"] = self.max_retries
        return data


class Endpoint(BaseModel):
    """An endpoint in a URL group."""

    id: str = Field(..., description="Endpoint identifier")
    group_id: str = Field(..., alias="groupId", description="Group identifier")
    url: str = Field(..., description="Endpoint URL")
    name: str | None = Field(default=None, description="Endpoint name")
    retry_count: int = Field(..., alias="retryCount", description="Retry count")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")

    model_config = {"populate_by_name": True}


class UrlGroup(BaseModel):
    """A URL group for broadcasting messages."""

    id: str = Field(..., description="Group identifier")
    workspace_id: str = Field(..., alias="workspaceId", description="Workspace identifier")
    name: str = Field(..., description="Group name")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    updated_at: str = Field(..., alias="updatedAt", description="Last update timestamp")

    model_config = {"populate_by_name": True}


class UrlGroupWithEndpoints(UrlGroup):
    """A URL group with its endpoints."""

    endpoints: list[Endpoint] = Field(..., description="Group endpoints")


class GroupPublishResult(BaseModel):
    """Result of publishing to a URL group."""

    message_ids: list[str] = Field(..., alias="messageIds", description="Published message IDs")
    total: int = Field(..., description="Total endpoints published to")

    model_config = {"populate_by_name": True}


class AddEndpointRequest(BaseModel):
    """Request to add an endpoint to a group."""

    url: str = Field(..., min_length=1, description="Endpoint URL")
    name: str | None = Field(default=None, max_length=100, description="Endpoint name")
    retry_count: int = Field(default=3, ge=0, le=10, description="Retry count")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {"url": self.url}
        if self.name:
            data["name"] = self.name
        if self.retry_count != 3:
            data["retryCount"] = self.retry_count
        return data


# =============================================================================
# Queues
# =============================================================================


class CreateQueueRequest(BaseModel):
    """Request to create a queue."""

    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r"^[a-zA-Z0-9_-]+$",
        description="Queue name",
    )
    description: str | None = Field(default=None, max_length=500, description="Queue description")
    parallelism: int = Field(default=1, ge=1, le=100, description="Parallel processing limit")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {"name": self.name, "parallelism": self.parallelism}
        if self.description:
            data["description"] = self.description
        return data


class UpdateQueueRequest(BaseModel):
    """Request to update a queue."""

    name: str | None = Field(default=None, max_length=100, description="Queue name")
    description: str | None = Field(default=None, max_length=500, description="Queue description")
    parallelism: int | None = Field(default=None, ge=1, le=100, description="Parallelism")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {}
        if self.name is not None:
            data["name"] = self.name
        if self.description is not None:
            data["description"] = self.description
        if self.parallelism is not None:
            data["parallelism"] = self.parallelism
        return data


class Queue(BaseModel):
    """A message queue."""

    queue_id: str = Field(..., alias="queueId", description="Queue identifier")
    name: str = Field(..., description="Queue name")
    description: str | None = Field(default=None, description="Queue description")
    parallelism: int = Field(..., description="Parallel processing limit")
    status: QueueStatus = Field(..., description="Queue status")
    is_paused: bool = Field(..., alias="isPaused", description="Whether queue is paused")
    message_count: int = Field(..., alias="messageCount", description="Total message count")
    pending_count: int = Field(..., alias="pendingCount", description="Pending message count")
    lag: int = Field(..., description="Queue lag")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    updated_at: str = Field(..., alias="updatedAt", description="Last update timestamp")

    model_config = {"populate_by_name": True}


class QueueFilters(BaseModel):
    """Filters for listing queues."""

    status: QueueStatus | None = Field(default=None, description="Filter by status")
    search: str | None = Field(default=None, description="Search term")
    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.status:
            params["status"] = self.status.value
        if self.search:
            params["search"] = self.search
        return params


# =============================================================================
# DLQ (Dead Letter Queue)
# =============================================================================


class ListDlqParams(BaseModel):
    """Parameters for listing DLQ messages."""

    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")
    error_type: str | None = Field(default=None, description="Filter by error type")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.error_type:
            params["errorType"] = self.error_type
        return params


class DlqStats(BaseModel):
    """Statistics for the dead letter queue."""

    total: int = Field(..., description="Total failed messages")
    by_error_type: dict[str, int] = Field(
        ..., alias="byErrorType", description="Count by error type"
    )
    oldest_message_at: str | None = Field(
        default=None, alias="oldestMessageAt", description="Oldest message timestamp"
    )
    newest_message_at: str | None = Field(
        default=None, alias="newestMessageAt", description="Newest message timestamp"
    )

    model_config = {"populate_by_name": True}


# =============================================================================
# Analytics
# =============================================================================


class DateRangeParams(BaseModel):
    """Parameters for date range queries."""

    start_date: str | datetime | None = Field(default=None, description="Start date")
    end_date: str | datetime | None = Field(default=None, description="End date")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {}
        if self.start_date:
            params["startDate"] = (
                self.start_date.isoformat()
                if isinstance(self.start_date, datetime)
                else self.start_date
            )
        if self.end_date:
            params["endDate"] = (
                self.end_date.isoformat()
                if isinstance(self.end_date, datetime)
                else self.end_date
            )
        return params


class TimeSeriesParams(DateRangeParams):
    """Parameters for time series queries."""

    granularity: str = Field(default="day", description="Time granularity")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params = super().to_query_params()
        params["granularity"] = self.granularity
        return params


class TopUrlsParams(DateRangeParams):
    """Parameters for top URLs query."""

    limit: int = Field(default=10, ge=1, le=100, description="Number of results")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params = super().to_query_params()
        params["limit"] = self.limit
        return params


class MessageAnalytics(BaseModel):
    """Message analytics data."""

    total: int = Field(..., description="Total messages")
    delivered: int = Field(..., description="Delivered messages")
    failed: int = Field(..., description="Failed messages")
    pending: int = Field(..., description="Pending messages")
    success_rate: float = Field(..., alias="successRate", description="Success rate percentage")
    avg_delivery_time: float | None = Field(
        default=None, alias="avgDeliveryTime", description="Average delivery time (ms)"
    )

    model_config = {"populate_by_name": True}


class TimeSeriesDataPoint(BaseModel):
    """A data point in time series."""

    timestamp: str = Field(..., description="ISO 8601 timestamp")
    total: int = Field(..., description="Total count")
    delivered: int = Field(..., description="Delivered count")
    failed: int = Field(..., description="Failed count")


class TopUrlEntry(BaseModel):
    """Entry in top URLs report."""

    url: str = Field(..., description="URL")
    count: int = Field(..., description="Request count")
    success_rate: float = Field(..., alias="successRate", description="Success rate")
    avg_response_time: float | None = Field(
        default=None, alias="avgResponseTime", description="Avg response time (ms)"
    )

    model_config = {"populate_by_name": True}


class CurrentUsage(BaseModel):
    """Current usage information."""

    messages_sent: int = Field(..., alias="messagesSent", description="Messages sent")
    messages_limit: int | None = Field(
        default=None, alias="messagesLimit", description="Messages limit"
    )
    schedules_active: int = Field(..., alias="schedulesActive", description="Active schedules")
    schedules_limit: int | None = Field(
        default=None, alias="schedulesLimit", description="Schedules limit"
    )
    period_start: str = Field(..., alias="periodStart", description="Period start")
    period_end: str = Field(..., alias="periodEnd", description="Period end")

    model_config = {"populate_by_name": True}


class UsageHistoryEntry(BaseModel):
    """Entry in usage history."""

    date: str = Field(..., description="Date")
    messages_sent: int = Field(..., alias="messagesSent", description="Messages sent")
    messages_delivered: int = Field(..., alias="messagesDelivered", description="Delivered")
    messages_failed: int = Field(..., alias="messagesFailed", description="Failed")

    model_config = {"populate_by_name": True}


class ScheduleStats(BaseModel):
    """Schedule statistics."""

    total: int = Field(..., description="Total schedules")
    active: int = Field(..., description="Active schedules")
    paused: int = Field(..., description="Paused schedules")
    executions_today: int = Field(
        ..., alias="executionsToday", description="Executions today"
    )
    success_rate: float = Field(..., alias="successRate", description="Success rate")

    model_config = {"populate_by_name": True}


class ScheduleExecution(BaseModel):
    """A schedule execution record."""

    schedule_id: str = Field(..., alias="scheduleId", description="Schedule ID")
    schedule_name: str = Field(..., alias="scheduleName", description="Schedule name")
    executed_at: str = Field(..., alias="executedAt", description="Execution time")
    status: str = Field(..., description="Execution status")
    duration_ms: int | None = Field(
        default=None, alias="durationMs", description="Duration in ms"
    )
    error: str | None = Field(default=None, description="Error message if failed")

    model_config = {"populate_by_name": True}


class ErrorDistribution(BaseModel):
    """Error distribution entry."""

    error_type: str = Field(..., alias="errorType", description="Error type")
    count: int = Field(..., description="Error count")
    percentage: float = Field(..., description="Percentage of total errors")

    model_config = {"populate_by_name": True}


# =============================================================================
# Notifications
# =============================================================================


class Notification(BaseModel):
    """A notification."""

    id: str = Field(..., description="Notification ID")
    type: NotificationType = Field(..., description="Notification type")
    category: NotificationCategory = Field(..., description="Notification category")
    title: str = Field(..., description="Notification title")
    message: str = Field(..., description="Notification message")
    is_read: bool = Field(..., alias="isRead", description="Whether read")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    data: dict[str, Any] | None = Field(default=None, description="Additional data")

    model_config = {"populate_by_name": True}


class NotificationListResponse(BaseModel):
    """Response for listing notifications."""

    notifications: list[Notification] = Field(..., description="Notifications")
    unread_count: int = Field(..., alias="unreadCount", description="Unread count")

    model_config = {"populate_by_name": True}


class ListNotificationsParams(BaseModel):
    """Parameters for listing notifications."""

    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")
    category: NotificationCategory | None = Field(default=None, description="Filter by category")
    unread_only: bool = Field(default=False, description="Only unread notifications")

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.category:
            params["category"] = self.category.value
        if self.unread_only:
            params["unreadOnly"] = self.unread_only
        return params


class NotificationPreferences(BaseModel):
    """Notification preferences."""

    email_enabled: bool = Field(..., alias="emailEnabled", description="Email notifications")
    webhook_enabled: bool = Field(..., alias="webhookEnabled", description="Webhook notifications")
    webhook_url: str | None = Field(default=None, alias="webhookUrl", description="Webhook URL")
    categories: dict[str, bool] = Field(..., description="Enabled categories")

    model_config = {"populate_by_name": True}


class UpdateNotificationPreferencesRequest(BaseModel):
    """Request to update notification preferences."""

    email_enabled: bool | None = Field(default=None, description="Email notifications")
    webhook_enabled: bool | None = Field(default=None, description="Webhook notifications")
    webhook_url: str | None = Field(default=None, description="Webhook URL")
    categories: dict[str, bool] | None = Field(default=None, description="Enabled categories")

    def model_dump_api(self) -> dict[str, Any]:
        """Dump to API-compatible format."""
        data: dict[str, Any] = {}
        if self.email_enabled is not None:
            data["emailEnabled"] = self.email_enabled
        if self.webhook_enabled is not None:
            data["webhookEnabled"] = self.webhook_enabled
        if self.webhook_url is not None:
            data["webhookUrl"] = self.webhook_url
        if self.categories is not None:
            data["categories"] = self.categories
        return data


# =============================================================================
# Billing
# =============================================================================


class PlanDetails(BaseModel):
    """Current plan details."""

    id: str = Field(..., description="Plan ID")
    name: str = Field(..., description="Plan name")
    messages_limit: int | None = Field(
        default=None, alias="messagesLimit", description="Monthly message limit"
    )
    schedules_limit: int | None = Field(
        default=None, alias="schedulesLimit", description="Schedule limit"
    )
    price: float = Field(..., description="Monthly price")
    billing_cycle: str = Field(..., alias="billingCycle", description="Billing cycle")
    features: list[str] = Field(..., description="Plan features")

    model_config = {"populate_by_name": True}


class Plan(BaseModel):
    """A billing plan."""

    id: str = Field(..., description="Plan ID")
    name: str = Field(..., description="Plan name")
    description: str = Field(..., description="Plan description")
    messages_limit: int | None = Field(
        default=None, alias="messagesLimit", description="Monthly message limit"
    )
    schedules_limit: int | None = Field(
        default=None, alias="schedulesLimit", description="Schedule limit"
    )
    price: float = Field(..., description="Monthly price")
    features: list[str] = Field(..., description="Plan features")
    is_popular: bool = Field(default=False, alias="isPopular", description="Is popular plan")

    model_config = {"populate_by_name": True}


class BillingUsage(BaseModel):
    """Current billing usage."""

    messages_used: int = Field(..., alias="messagesUsed", description="Messages used")
    messages_limit: int | None = Field(
        default=None, alias="messagesLimit", description="Message limit"
    )
    schedules_used: int = Field(..., alias="schedulesUsed", description="Schedules used")
    schedules_limit: int | None = Field(
        default=None, alias="schedulesLimit", description="Schedule limit"
    )
    current_cost: float = Field(..., alias="currentCost", description="Current period cost")
    projected_cost: float = Field(..., alias="projectedCost", description="Projected cost")
    period_start: str = Field(..., alias="periodStart", description="Period start")
    period_end: str = Field(..., alias="periodEnd", description="Period end")

    model_config = {"populate_by_name": True}


class CostEstimate(BaseModel):
    """Cost estimate."""

    current_usage: float = Field(..., alias="currentUsage", description="Current usage cost")
    projected_total: float = Field(..., alias="projectedTotal", description="Projected total")
    days_remaining: int = Field(..., alias="daysRemaining", description="Days remaining")
    breakdown: dict[str, float] = Field(..., description="Cost breakdown")

    model_config = {"populate_by_name": True}


class Invoice(BaseModel):
    """A billing invoice."""

    id: str = Field(..., description="Invoice ID")
    number: str = Field(..., description="Invoice number")
    amount: float = Field(..., description="Invoice amount")
    status: str = Field(..., description="Invoice status")
    period_start: str = Field(..., alias="periodStart", description="Period start")
    period_end: str = Field(..., alias="periodEnd", description="Period end")
    created_at: str = Field(..., alias="createdAt", description="Creation timestamp")
    paid_at: str | None = Field(default=None, alias="paidAt", description="Payment timestamp")
    pdf_url: str | None = Field(default=None, alias="pdfUrl", description="PDF download URL")

    model_config = {"populate_by_name": True}


# =============================================================================
# Common Response Types
# =============================================================================


class SimpleMessage(BaseModel):
    """A simple message response."""

    message: str = Field(..., description="Response message")
