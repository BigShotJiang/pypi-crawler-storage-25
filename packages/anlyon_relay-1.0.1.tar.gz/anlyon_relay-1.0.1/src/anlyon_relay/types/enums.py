"""Enums for the Anlyon Relay SDK."""

from enum import Enum


class HttpMethod(str, Enum):
    """HTTP methods supported by the API."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class MessageStatus(str, Enum):
    """Status of a message in the queue."""

    PENDING = "pending"
    SCHEDULED = "scheduled"
    PROCESSING = "processing"
    DELIVERED = "delivered"
    FAILED = "failed"
    CANCELLED = "cancelled"


class QueueStatus(str, Enum):
    """Status of a queue."""

    ACTIVE = "active"
    PAUSED = "paused"
    DELETED = "deleted"


class TimeGranularity(str, Enum):
    """Time granularity for analytics."""

    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


class LogLevel(str, Enum):
    """Log levels for the SDK logger."""

    DEBUG = "debug"
    INFO = "info"
    WARN = "warn"
    ERROR = "error"


class ErrorCode(str, Enum):
    """Error codes returned by the API."""

    AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
    AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR"
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    NOT_FOUND = "NOT_FOUND"
    FEATURE_NOT_AVAILABLE = "FEATURE_NOT_AVAILABLE"
    CONFLICT_ERROR = "CONFLICT_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    TIMEOUT_ERROR = "TIMEOUT_ERROR"
    PARSE_ERROR = "PARSE_ERROR"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"


class NotificationType(str, Enum):
    """Types of notifications."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"


class NotificationCategory(str, Enum):
    """Categories of notifications."""

    SYSTEM = "system"
    BILLING = "billing"
    USAGE = "usage"
    SECURITY = "security"
