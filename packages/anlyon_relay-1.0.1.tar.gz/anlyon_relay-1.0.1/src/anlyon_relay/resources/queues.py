"""Queues resource for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    CreateQueueRequest,
    Queue,
    QueueFilters,
    SimpleMessage,
    UpdateQueueRequest,
)
from ..types.responses import ApiResponse, PaginatedResponse, Pagination
from .base import AsyncBaseResource, BaseResource

if TYPE_CHECKING:
    from ..helpers.pagination import AsyncPaginationIterator, PaginationIterator


class QueuesResource(BaseResource):
    """Synchronous queues resource client."""

    _base_path = "/api/v2/queues"

    def list(
        self,
        params: QueueFilters | None = None,
    ) -> PaginatedResponse[Queue]:
        """List queues with optional filters.

        Args:
            params: Filter parameters.

        Returns:
            Paginated response with queues.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get(params=query_params)

        queues = None
        if data.get("data"):
            queues = [Queue.model_validate(q) for q in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=queues,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: QueueFilters | None = None,
    ) -> "PaginationIterator[Queue]":
        """Create a pagination iterator for all queues.

        Args:
            params: Filter parameters (page will be ignored).

        Returns:
            A pagination iterator.
        """
        from ..helpers.pagination import PaginationIterator

        base_params = params.model_copy() if params else QueueFilters()

        def fetcher(page: int, limit: int) -> PaginatedResponse[Queue]:
            base_params.page = page
            base_params.limit = limit
            return self.list(base_params)

        return PaginationIterator(fetcher, page_size=base_params.limit)

    def get(self, queue_id: str) -> ApiResponse[Queue]:
        """Get a specific queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with queue.
        """
        data = self._get(queue_id)
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def create(self, request: CreateQueueRequest) -> ApiResponse[Queue]:
        """Create a new queue.

        Args:
            request: Queue creation request.

        Returns:
            API response with created queue.
        """
        data = self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def update(
        self,
        queue_id: str,
        request: UpdateQueueRequest,
    ) -> ApiResponse[Queue]:
        """Update a queue.

        Args:
            queue_id: Queue identifier.
            request: Update request.

        Returns:
            API response with updated queue.
        """
        data = self._patch(queue_id, body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def delete(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(queue_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def pause(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Pause a queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = self._post(f"{queue_id}/pause")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def resume(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Resume a paused queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = self._post(f"{queue_id}/resume")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncQueuesResource(AsyncBaseResource):
    """Asynchronous queues resource client."""

    _base_path = "/api/v2/queues"

    async def list(
        self,
        params: QueueFilters | None = None,
    ) -> PaginatedResponse[Queue]:
        """List queues with optional filters.

        Args:
            params: Filter parameters.

        Returns:
            Paginated response with queues.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get(params=query_params)

        queues = None
        if data.get("data"):
            queues = [Queue.model_validate(q) for q in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=queues,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: QueueFilters | None = None,
    ) -> "AsyncPaginationIterator[Queue]":
        """Create an async pagination iterator for all queues.

        Args:
            params: Filter parameters (page will be ignored).

        Returns:
            An async pagination iterator.
        """
        from ..helpers.pagination import AsyncPaginationIterator

        base_params = params.model_copy() if params else QueueFilters()

        async def fetcher(page: int, limit: int) -> PaginatedResponse[Queue]:
            base_params.page = page
            base_params.limit = limit
            return await self.list(base_params)

        return AsyncPaginationIterator(fetcher, page_size=base_params.limit)

    async def get(self, queue_id: str) -> ApiResponse[Queue]:
        """Get a specific queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with queue.
        """
        data = await self._get(queue_id)
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def create(self, request: CreateQueueRequest) -> ApiResponse[Queue]:
        """Create a new queue.

        Args:
            request: Queue creation request.

        Returns:
            API response with created queue.
        """
        data = await self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def update(
        self,
        queue_id: str,
        request: UpdateQueueRequest,
    ) -> ApiResponse[Queue]:
        """Update a queue.

        Args:
            queue_id: Queue identifier.
            request: Update request.

        Returns:
            API response with updated queue.
        """
        data = await self._patch(queue_id, body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Queue.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def delete(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(queue_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def pause(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Pause a queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._post(f"{queue_id}/pause")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def resume(self, queue_id: str) -> ApiResponse[SimpleMessage]:
        """Resume a paused queue.

        Args:
            queue_id: Queue identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._post(f"{queue_id}/resume")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
