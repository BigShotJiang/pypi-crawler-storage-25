"""Analytics resource for the Anlyon Relay SDK."""

from __future__ import annotations

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    CurrentUsage,
    DateRangeParams,
    ErrorDistribution,
    MessageAnalytics,
    ScheduleExecution,
    ScheduleStats,
    TimeSeriesDataPoint,
    TimeSeriesParams,
    TopUrlEntry,
    TopUrlsParams,
    UsageHistoryEntry,
)
from ..types.responses import ApiResponse
from .base import AsyncBaseResource, BaseResource


class AnalyticsResource(BaseResource):
    """Synchronous analytics resource client."""

    _base_path = "/api/v2/analytics"

    def get_message_stats(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[MessageAnalytics]:
        """Get message analytics.

        Args:
            params: Date range parameters.

        Returns:
            API response with message analytics.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get("messages", params=query_params)
        result = None
        if data.get("data"):
            result = MessageAnalytics.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_time_series(
        self,
        params: TimeSeriesParams | None = None,
    ) -> ApiResponse[list[TimeSeriesDataPoint]]:
        """Get time series data.

        Args:
            params: Time series parameters.

        Returns:
            API response with time series data points.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get("time-series", params=query_params)
        result = None
        if data.get("data"):
            result = [TimeSeriesDataPoint.model_validate(d) for d in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_top_urls(
        self,
        params: TopUrlsParams | None = None,
    ) -> ApiResponse[list[TopUrlEntry]]:
        """Get top performing URLs.

        Args:
            params: Top URLs parameters.

        Returns:
            API response with top URL entries.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get("top-urls", params=query_params)
        result = None
        if data.get("data"):
            result = [TopUrlEntry.model_validate(u) for u in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_current_usage(self) -> ApiResponse[CurrentUsage]:
        """Get current usage information.

        Returns:
            API response with current usage.
        """
        data = self._get("usage/current")
        result = None
        if data.get("data"):
            result = CurrentUsage.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_usage_history(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[list[UsageHistoryEntry]]:
        """Get usage history.

        Args:
            params: Date range parameters.

        Returns:
            API response with usage history entries.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get("usage/history", params=query_params)
        result = None
        if data.get("data"):
            result = [UsageHistoryEntry.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_schedule_stats(self) -> ApiResponse[ScheduleStats]:
        """Get schedule statistics.

        Returns:
            API response with schedule stats.
        """
        data = self._get("schedules")
        result = None
        if data.get("data"):
            result = ScheduleStats.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_schedule_executions(
        self,
        limit: int = 10,
    ) -> ApiResponse[list[ScheduleExecution]]:
        """Get recent schedule executions.

        Args:
            limit: Maximum number of executions to return.

        Returns:
            API response with schedule executions.
        """
        data = self._get("schedule-executions", params={"limit": limit})
        result = None
        if data.get("data"):
            result = [ScheduleExecution.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_error_distribution(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[list[ErrorDistribution]]:
        """Get error distribution.

        Args:
            params: Date range parameters.

        Returns:
            API response with error distribution.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get("errors", params=query_params)
        result = None
        if data.get("data"):
            result = [ErrorDistribution.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncAnalyticsResource(AsyncBaseResource):
    """Asynchronous analytics resource client."""

    _base_path = "/api/v2/analytics"

    async def get_message_stats(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[MessageAnalytics]:
        """Get message analytics.

        Args:
            params: Date range parameters.

        Returns:
            API response with message analytics.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get("messages", params=query_params)
        result = None
        if data.get("data"):
            result = MessageAnalytics.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_time_series(
        self,
        params: TimeSeriesParams | None = None,
    ) -> ApiResponse[list[TimeSeriesDataPoint]]:
        """Get time series data.

        Args:
            params: Time series parameters.

        Returns:
            API response with time series data points.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get("time-series", params=query_params)
        result = None
        if data.get("data"):
            result = [TimeSeriesDataPoint.model_validate(d) for d in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_top_urls(
        self,
        params: TopUrlsParams | None = None,
    ) -> ApiResponse[list[TopUrlEntry]]:
        """Get top performing URLs.

        Args:
            params: Top URLs parameters.

        Returns:
            API response with top URL entries.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get("top-urls", params=query_params)
        result = None
        if data.get("data"):
            result = [TopUrlEntry.model_validate(u) for u in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_current_usage(self) -> ApiResponse[CurrentUsage]:
        """Get current usage information.

        Returns:
            API response with current usage.
        """
        data = await self._get("usage/current")
        result = None
        if data.get("data"):
            result = CurrentUsage.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_usage_history(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[list[UsageHistoryEntry]]:
        """Get usage history.

        Args:
            params: Date range parameters.

        Returns:
            API response with usage history entries.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get("usage/history", params=query_params)
        result = None
        if data.get("data"):
            result = [UsageHistoryEntry.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_schedule_stats(self) -> ApiResponse[ScheduleStats]:
        """Get schedule statistics.

        Returns:
            API response with schedule stats.
        """
        data = await self._get("schedules")
        result = None
        if data.get("data"):
            result = ScheduleStats.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_schedule_executions(
        self,
        limit: int = 10,
    ) -> ApiResponse[list[ScheduleExecution]]:
        """Get recent schedule executions.

        Args:
            limit: Maximum number of executions to return.

        Returns:
            API response with schedule executions.
        """
        data = await self._get("schedule-executions", params={"limit": limit})
        result = None
        if data.get("data"):
            result = [ScheduleExecution.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_error_distribution(
        self,
        params: DateRangeParams | None = None,
    ) -> ApiResponse[list[ErrorDistribution]]:
        """Get error distribution.

        Args:
            params: Date range parameters.

        Returns:
            API response with error distribution.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get("errors", params=query_params)
        result = None
        if data.get("data"):
            result = [ErrorDistribution.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
