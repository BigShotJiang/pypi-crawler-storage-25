"""URL Groups resource for the Anlyon Relay SDK."""

from __future__ import annotations

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    AddEndpointRequest,
    CreateUrlGroupRequest,
    Endpoint,
    GroupPublishResult,
    PublishGroupMessageRequest,
    SimpleMessage,
    UrlGroup,
    UrlGroupWithEndpoints,
)
from ..types.responses import ApiResponse
from .base import AsyncBaseResource, BaseResource


class UrlGroupsResource(BaseResource):
    """Synchronous URL groups resource client."""

    _base_path = "/api/v2/url-groups"

    def create(self, request: CreateUrlGroupRequest) -> ApiResponse[UrlGroup]:
        """Create a new URL group.

        Args:
            request: Group creation request.

        Returns:
            API response with created group.
        """
        data = self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = UrlGroup.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def list(self) -> ApiResponse[list[UrlGroup]]:
        """List all URL groups.

        Returns:
            API response with list of groups.
        """
        data = self._get()
        groups = None
        if data.get("data"):
            groups = [UrlGroup.model_validate(g) for g in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=groups,
            error=data.get("error"),
        )

    def get(self, group_id: str) -> ApiResponse[UrlGroupWithEndpoints]:
        """Get a specific URL group with its endpoints.

        Args:
            group_id: Group identifier.

        Returns:
            API response with group and endpoints.
        """
        data = self._get(group_id)
        result = None
        if data.get("data"):
            result = UrlGroupWithEndpoints.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def update(self, group_id: str, name: str) -> ApiResponse[UrlGroup]:
        """Update a URL group.

        Args:
            group_id: Group identifier.
            name: New group name.

        Returns:
            API response with updated group.
        """
        data = self._patch(group_id, body={"name": name})
        result = None
        if data.get("data"):
            result = UrlGroup.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def delete(self, group_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a URL group.

        Args:
            group_id: Group identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(group_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def add_endpoint(
        self,
        group_id: str,
        endpoint: AddEndpointRequest,
    ) -> ApiResponse[Endpoint]:
        """Add an endpoint to a URL group.

        Args:
            group_id: Group identifier.
            endpoint: Endpoint details.

        Returns:
            API response with created endpoint.
        """
        data = self._post(f"{group_id}/endpoints", body=endpoint.model_dump_api())
        result = None
        if data.get("data"):
            result = Endpoint.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def remove_endpoint(
        self,
        group_id: str,
        endpoint_id: str,
    ) -> ApiResponse[SimpleMessage]:
        """Remove an endpoint from a URL group.

        Args:
            group_id: Group identifier.
            endpoint_id: Endpoint identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(f"{group_id}/endpoints/{endpoint_id}")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def publish(
        self,
        group_id: str,
        message: PublishGroupMessageRequest,
    ) -> ApiResponse[GroupPublishResult]:
        """Publish a message to all endpoints in a group.

        Args:
            group_id: Group identifier.
            message: Message to publish.

        Returns:
            API response with publish result.
        """
        data = self._post(f"{group_id}/publish", body=message.model_dump_api())
        result = None
        if data.get("data"):
            result = GroupPublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncUrlGroupsResource(AsyncBaseResource):
    """Asynchronous URL groups resource client."""

    _base_path = "/api/v2/url-groups"

    async def create(self, request: CreateUrlGroupRequest) -> ApiResponse[UrlGroup]:
        """Create a new URL group.

        Args:
            request: Group creation request.

        Returns:
            API response with created group.
        """
        data = await self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = UrlGroup.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def list(self) -> ApiResponse[list[UrlGroup]]:
        """List all URL groups.

        Returns:
            API response with list of groups.
        """
        data = await self._get()
        groups = None
        if data.get("data"):
            groups = [UrlGroup.model_validate(g) for g in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=groups,
            error=data.get("error"),
        )

    async def get(self, group_id: str) -> ApiResponse[UrlGroupWithEndpoints]:
        """Get a specific URL group with its endpoints.

        Args:
            group_id: Group identifier.

        Returns:
            API response with group and endpoints.
        """
        data = await self._get(group_id)
        result = None
        if data.get("data"):
            result = UrlGroupWithEndpoints.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def update(self, group_id: str, name: str) -> ApiResponse[UrlGroup]:
        """Update a URL group.

        Args:
            group_id: Group identifier.
            name: New group name.

        Returns:
            API response with updated group.
        """
        data = await self._patch(group_id, body={"name": name})
        result = None
        if data.get("data"):
            result = UrlGroup.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def delete(self, group_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a URL group.

        Args:
            group_id: Group identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(group_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def add_endpoint(
        self,
        group_id: str,
        endpoint: AddEndpointRequest,
    ) -> ApiResponse[Endpoint]:
        """Add an endpoint to a URL group.

        Args:
            group_id: Group identifier.
            endpoint: Endpoint details.

        Returns:
            API response with created endpoint.
        """
        data = await self._post(f"{group_id}/endpoints", body=endpoint.model_dump_api())
        result = None
        if data.get("data"):
            result = Endpoint.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def remove_endpoint(
        self,
        group_id: str,
        endpoint_id: str,
    ) -> ApiResponse[SimpleMessage]:
        """Remove an endpoint from a URL group.

        Args:
            group_id: Group identifier.
            endpoint_id: Endpoint identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(f"{group_id}/endpoints/{endpoint_id}")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def publish(
        self,
        group_id: str,
        message: PublishGroupMessageRequest,
    ) -> ApiResponse[GroupPublishResult]:
        """Publish a message to all endpoints in a group.

        Args:
            group_id: Group identifier.
            message: Message to publish.

        Returns:
            API response with publish result.
        """
        data = await self._post(f"{group_id}/publish", body=message.model_dump_api())
        result = None
        if data.get("data"):
            result = GroupPublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
