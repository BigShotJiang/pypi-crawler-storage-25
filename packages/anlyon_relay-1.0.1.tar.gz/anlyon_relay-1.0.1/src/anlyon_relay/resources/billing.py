"""Billing resource for the Anlyon Relay SDK."""

from __future__ import annotations

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    BillingUsage,
    CostEstimate,
    Invoice,
    Plan,
    PlanDetails,
    UsageHistoryEntry,
)
from ..types.responses import ApiResponse
from .base import AsyncBaseResource, BaseResource


class BillingResource(BaseResource):
    """Synchronous billing resource client."""

    _base_path = "/api/v2/billing"

    def get_current_plan(self) -> ApiResponse[PlanDetails]:
        """Get current plan details.

        Returns:
            API response with plan details.
        """
        data = self._get("plan")
        result = None
        if data.get("data"):
            result = PlanDetails.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_current_usage(self) -> ApiResponse[BillingUsage]:
        """Get current billing period usage.

        Returns:
            API response with usage data.
        """
        data = self._get("usage/current")
        result = None
        if data.get("data"):
            result = BillingUsage.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def list_plans(self) -> ApiResponse[list[Plan]]:
        """List all available plans.

        Returns:
            API response with available plans.
        """
        data = self._get("plans")
        result = None
        if data.get("data"):
            result = [Plan.model_validate(p) for p in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_usage_history(
        self,
        days: int | None = None,
    ) -> ApiResponse[list[UsageHistoryEntry]]:
        """Get usage history.

        Args:
            days: Number of days of history to retrieve.

        Returns:
            API response with usage history.
        """
        params = {"days": days} if days else None
        data = self._get("usage/history", params=params)
        result = None
        if data.get("data"):
            result = [UsageHistoryEntry.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_cost_estimate(self) -> ApiResponse[CostEstimate]:
        """Get cost estimate for current period.

        Returns:
            API response with cost estimate.
        """
        data = self._get("cost-estimate")
        result = None
        if data.get("data"):
            result = CostEstimate.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def list_invoices(
        self,
        limit: int | None = None,
    ) -> ApiResponse[list[Invoice]]:
        """List invoices.

        Args:
            limit: Maximum number of invoices to return.

        Returns:
            API response with invoices.
        """
        params = {"limit": limit} if limit else None
        data = self._get("invoices", params=params)
        result = None
        if data.get("data"):
            result = [Invoice.model_validate(i) for i in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncBillingResource(AsyncBaseResource):
    """Asynchronous billing resource client."""

    _base_path = "/api/v2/billing"

    async def get_current_plan(self) -> ApiResponse[PlanDetails]:
        """Get current plan details.

        Returns:
            API response with plan details.
        """
        data = await self._get("plan")
        result = None
        if data.get("data"):
            result = PlanDetails.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_current_usage(self) -> ApiResponse[BillingUsage]:
        """Get current billing period usage.

        Returns:
            API response with usage data.
        """
        data = await self._get("usage/current")
        result = None
        if data.get("data"):
            result = BillingUsage.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def list_plans(self) -> ApiResponse[list[Plan]]:
        """List all available plans.

        Returns:
            API response with available plans.
        """
        data = await self._get("plans")
        result = None
        if data.get("data"):
            result = [Plan.model_validate(p) for p in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_usage_history(
        self,
        days: int | None = None,
    ) -> ApiResponse[list[UsageHistoryEntry]]:
        """Get usage history.

        Args:
            days: Number of days of history to retrieve.

        Returns:
            API response with usage history.
        """
        params = {"days": days} if days else None
        data = await self._get("usage/history", params=params)
        result = None
        if data.get("data"):
            result = [UsageHistoryEntry.model_validate(e) for e in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_cost_estimate(self) -> ApiResponse[CostEstimate]:
        """Get cost estimate for current period.

        Returns:
            API response with cost estimate.
        """
        data = await self._get("cost-estimate")
        result = None
        if data.get("data"):
            result = CostEstimate.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def list_invoices(
        self,
        limit: int | None = None,
    ) -> ApiResponse[list[Invoice]]:
        """List invoices.

        Args:
            limit: Maximum number of invoices to return.

        Returns:
            API response with invoices.
        """
        params = {"limit": limit} if limit else None
        data = await self._get("invoices", params=params)
        result = None
        if data.get("data"):
            result = [Invoice.model_validate(i) for i in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
