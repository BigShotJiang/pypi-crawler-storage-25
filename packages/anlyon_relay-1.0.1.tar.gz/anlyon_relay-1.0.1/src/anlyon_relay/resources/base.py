"""Base resource class for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any, TypeVar

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.responses import ApiResponse, PaginatedResponse, Pagination

T = TypeVar("T")


class BaseResource:
    """Base class for synchronous resource clients."""

    _base_path: str = ""

    def __init__(self, http: HttpClient) -> None:
        """Initialize the resource.

        Args:
            http: HTTP client instance.
        """
        self._http = http

    def _build_path(self, path: str | None = None) -> str:
        """Build the full API path.

        Args:
            path: Additional path segment.

        Returns:
            Full API path.
        """
        if path:
            return f"{self._base_path}/{path}".replace("//", "/")
        return self._base_path

    def _get(
        self,
        path: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a GET request.

        Args:
            path: Additional path segment.
            params: Query parameters.

        Returns:
            Response data.
        """
        return self._http.get(self._build_path(path), params=params)

    def _post(
        self,
        path: str | None = None,
        body: Any | None = None,
    ) -> dict[str, Any]:
        """Make a POST request.

        Args:
            path: Additional path segment.
            body: Request body.

        Returns:
            Response data.
        """
        return self._http.post(self._build_path(path), body=body)

    def _patch(
        self,
        path: str | None = None,
        body: Any | None = None,
    ) -> dict[str, Any]:
        """Make a PATCH request.

        Args:
            path: Additional path segment.
            body: Request body.

        Returns:
            Response data.
        """
        return self._http.patch(self._build_path(path), body=body)

    def _delete(
        self,
        path: str | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request.

        Args:
            path: Additional path segment.

        Returns:
            Response data.
        """
        return self._http.delete(self._build_path(path))

    def _wrap_response(self, data: dict[str, Any]) -> ApiResponse[Any]:
        """Wrap raw response data in ApiResponse.

        Args:
            data: Raw response data.

        Returns:
            Wrapped ApiResponse.
        """
        return ApiResponse(
            success=data.get("success", True),
            data=data.get("data"),
            error=data.get("error"),
        )

    def _wrap_paginated_response(
        self,
        data: dict[str, Any],
    ) -> PaginatedResponse[Any]:
        """Wrap raw response data in PaginatedResponse.

        Args:
            data: Raw response data.

        Returns:
            Wrapped PaginatedResponse.
        """
        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination(
                page=pagination_data.get("page", 1),
                limit=pagination_data.get("limit", 20),
                total=pagination_data.get("total", 0),
                totalPages=pagination_data.get("totalPages", 0),
                hasNext=pagination_data.get("hasNext", False),
                hasPrevious=pagination_data.get("hasPrevious", False),
            )

        return PaginatedResponse(
            success=data.get("success", True),
            data=data.get("data"),
            pagination=pagination,
            error=data.get("error"),
        )


class AsyncBaseResource:
    """Base class for asynchronous resource clients."""

    _base_path: str = ""

    def __init__(self, http: AsyncHttpClient) -> None:
        """Initialize the resource.

        Args:
            http: Async HTTP client instance.
        """
        self._http = http

    def _build_path(self, path: str | None = None) -> str:
        """Build the full API path.

        Args:
            path: Additional path segment.

        Returns:
            Full API path.
        """
        if path:
            return f"{self._base_path}/{path}".replace("//", "/")
        return self._base_path

    async def _get(
        self,
        path: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a GET request.

        Args:
            path: Additional path segment.
            params: Query parameters.

        Returns:
            Response data.
        """
        return await self._http.get(self._build_path(path), params=params)

    async def _post(
        self,
        path: str | None = None,
        body: Any | None = None,
    ) -> dict[str, Any]:
        """Make a POST request.

        Args:
            path: Additional path segment.
            body: Request body.

        Returns:
            Response data.
        """
        return await self._http.post(self._build_path(path), body=body)

    async def _patch(
        self,
        path: str | None = None,
        body: Any | None = None,
    ) -> dict[str, Any]:
        """Make a PATCH request.

        Args:
            path: Additional path segment.
            body: Request body.

        Returns:
            Response data.
        """
        return await self._http.patch(self._build_path(path), body=body)

    async def _delete(
        self,
        path: str | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request.

        Args:
            path: Additional path segment.

        Returns:
            Response data.
        """
        return await self._http.delete(self._build_path(path))

    def _wrap_response(self, data: dict[str, Any]) -> ApiResponse[Any]:
        """Wrap raw response data in ApiResponse.

        Args:
            data: Raw response data.

        Returns:
            Wrapped ApiResponse.
        """
        return ApiResponse(
            success=data.get("success", True),
            data=data.get("data"),
            error=data.get("error"),
        )

    def _wrap_paginated_response(
        self,
        data: dict[str, Any],
    ) -> PaginatedResponse[Any]:
        """Wrap raw response data in PaginatedResponse.

        Args:
            data: Raw response data.

        Returns:
            Wrapped PaginatedResponse.
        """
        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination(
                page=pagination_data.get("page", 1),
                limit=pagination_data.get("limit", 20),
                total=pagination_data.get("total", 0),
                totalPages=pagination_data.get("totalPages", 0),
                hasNext=pagination_data.get("hasNext", False),
                hasPrevious=pagination_data.get("hasPrevious", False),
            )

        return PaginatedResponse(
            success=data.get("success", True),
            data=data.get("data"),
            pagination=pagination,
            error=data.get("error"),
        )
