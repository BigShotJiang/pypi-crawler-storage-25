"""Dead Letter Queue (DLQ) resource for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    DlqStats,
    ListDlqParams,
    Message,
    SimpleMessage,
)
from ..types.responses import ApiResponse, PaginatedResponse, Pagination
from .base import AsyncBaseResource, BaseResource

if TYPE_CHECKING:
    from ..helpers.pagination import AsyncPaginationIterator, PaginationIterator


class DlqResource(BaseResource):
    """Synchronous DLQ resource client."""

    _base_path = "/api/v2/dlq"

    def list(
        self,
        params: ListDlqParams | None = None,
    ) -> PaginatedResponse[Message]:
        """List failed messages in the DLQ.

        Args:
            params: List parameters.

        Returns:
            Paginated response with failed messages.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get(params=query_params)

        messages = None
        if data.get("data"):
            messages = [Message.model_validate(m) for m in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=messages,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: ListDlqParams | None = None,
    ) -> "PaginationIterator[Message]":
        """Create a pagination iterator for all DLQ messages.

        Args:
            params: List parameters (page will be ignored).

        Returns:
            A pagination iterator.
        """
        from ..helpers.pagination import PaginationIterator

        base_params = params.model_copy() if params else ListDlqParams()

        def fetcher(page: int, limit: int) -> PaginatedResponse[Message]:
            base_params.page = page
            base_params.limit = limit
            return self.list(base_params)

        return PaginationIterator(fetcher, page_size=base_params.limit)

    def get_stats(self) -> ApiResponse[DlqStats]:
        """Get DLQ statistics.

        Returns:
            API response with DLQ stats.
        """
        data = self._get("stats")
        result = None
        if data.get("data"):
            result = DlqStats.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get(self, message_id: str) -> ApiResponse[Message]:
        """Get a specific failed message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with message.
        """
        data = self._get(message_id)
        result = None
        if data.get("data"):
            result = Message.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def retry(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Retry a failed message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = self._post(f"{message_id}/retry")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def retry_all(self) -> ApiResponse[SimpleMessage]:
        """Retry all failed messages.

        Returns:
            API response with confirmation.
        """
        data = self._post("retry-all")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def delete(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a failed message from the DLQ.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(message_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def clear(self) -> ApiResponse[SimpleMessage]:
        """Clear all messages from the DLQ.

        Returns:
            API response with confirmation.
        """
        data = self._delete()
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncDlqResource(AsyncBaseResource):
    """Asynchronous DLQ resource client."""

    _base_path = "/api/v2/dlq"

    async def list(
        self,
        params: ListDlqParams | None = None,
    ) -> PaginatedResponse[Message]:
        """List failed messages in the DLQ.

        Args:
            params: List parameters.

        Returns:
            Paginated response with failed messages.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get(params=query_params)

        messages = None
        if data.get("data"):
            messages = [Message.model_validate(m) for m in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=messages,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: ListDlqParams | None = None,
    ) -> "AsyncPaginationIterator[Message]":
        """Create an async pagination iterator for all DLQ messages.

        Args:
            params: List parameters (page will be ignored).

        Returns:
            An async pagination iterator.
        """
        from ..helpers.pagination import AsyncPaginationIterator

        base_params = params.model_copy() if params else ListDlqParams()

        async def fetcher(page: int, limit: int) -> PaginatedResponse[Message]:
            base_params.page = page
            base_params.limit = limit
            return await self.list(base_params)

        return AsyncPaginationIterator(fetcher, page_size=base_params.limit)

    async def get_stats(self) -> ApiResponse[DlqStats]:
        """Get DLQ statistics.

        Returns:
            API response with DLQ stats.
        """
        data = await self._get("stats")
        result = None
        if data.get("data"):
            result = DlqStats.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get(self, message_id: str) -> ApiResponse[Message]:
        """Get a specific failed message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with message.
        """
        data = await self._get(message_id)
        result = None
        if data.get("data"):
            result = Message.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def retry(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Retry a failed message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._post(f"{message_id}/retry")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def retry_all(self) -> ApiResponse[SimpleMessage]:
        """Retry all failed messages.

        Returns:
            API response with confirmation.
        """
        data = await self._post("retry-all")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def delete(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a failed message from the DLQ.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(message_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def clear(self) -> ApiResponse[SimpleMessage]:
        """Clear all messages from the DLQ.

        Returns:
            API response with confirmation.
        """
        data = await self._delete()
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
