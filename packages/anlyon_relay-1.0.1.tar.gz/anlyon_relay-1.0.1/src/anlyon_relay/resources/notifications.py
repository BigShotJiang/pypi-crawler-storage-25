"""Notifications resource for the Anlyon Relay SDK."""

from __future__ import annotations

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    ListNotificationsParams,
    NotificationListResponse,
    NotificationPreferences,
    SimpleMessage,
    UpdateNotificationPreferencesRequest,
)
from ..types.responses import ApiResponse
from .base import AsyncBaseResource, BaseResource


class NotificationsResource(BaseResource):
    """Synchronous notifications resource client."""

    _base_path = "/api/v2/notifications"

    def list(
        self,
        params: ListNotificationsParams | None = None,
    ) -> ApiResponse[NotificationListResponse]:
        """List notifications.

        Args:
            params: List parameters.

        Returns:
            API response with notifications.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get(params=query_params)
        result = None
        if data.get("data"):
            result = NotificationListResponse.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def mark_as_read(self, notification_id: str) -> ApiResponse[SimpleMessage]:
        """Mark a notification as read.

        Args:
            notification_id: Notification identifier.

        Returns:
            API response with confirmation.
        """
        data = self._patch(f"{notification_id}/read")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def mark_all_as_read(self) -> ApiResponse[SimpleMessage]:
        """Mark all notifications as read.

        Returns:
            API response with confirmation.
        """
        data = self._patch("read-all")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_preferences(self) -> ApiResponse[NotificationPreferences]:
        """Get notification preferences.

        Returns:
            API response with preferences.
        """
        data = self._get("preferences")
        result = None
        if data.get("data"):
            result = NotificationPreferences.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def update_preferences(
        self,
        preferences: UpdateNotificationPreferencesRequest,
    ) -> ApiResponse[NotificationPreferences]:
        """Update notification preferences.

        Args:
            preferences: Preference updates.

        Returns:
            API response with updated preferences.
        """
        data = self._patch("preferences", body=preferences.model_dump_api())
        result = None
        if data.get("data"):
            result = NotificationPreferences.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def get_unread_count(self) -> ApiResponse[dict[str, int]]:
        """Get unread notification count.

        Returns:
            API response with count.
        """
        data = self._get("unread-count")
        return ApiResponse(
            success=data.get("success", True),
            data=data.get("data"),
            error=data.get("error"),
        )

    def test_webhook(self) -> ApiResponse[SimpleMessage]:
        """Test the webhook configuration.

        Returns:
            API response with confirmation.
        """
        data = self._post("preferences/test-webhook")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncNotificationsResource(AsyncBaseResource):
    """Asynchronous notifications resource client."""

    _base_path = "/api/v2/notifications"

    async def list(
        self,
        params: ListNotificationsParams | None = None,
    ) -> ApiResponse[NotificationListResponse]:
        """List notifications.

        Args:
            params: List parameters.

        Returns:
            API response with notifications.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get(params=query_params)
        result = None
        if data.get("data"):
            result = NotificationListResponse.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def mark_as_read(self, notification_id: str) -> ApiResponse[SimpleMessage]:
        """Mark a notification as read.

        Args:
            notification_id: Notification identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._patch(f"{notification_id}/read")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def mark_all_as_read(self) -> ApiResponse[SimpleMessage]:
        """Mark all notifications as read.

        Returns:
            API response with confirmation.
        """
        data = await self._patch("read-all")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_preferences(self) -> ApiResponse[NotificationPreferences]:
        """Get notification preferences.

        Returns:
            API response with preferences.
        """
        data = await self._get("preferences")
        result = None
        if data.get("data"):
            result = NotificationPreferences.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def update_preferences(
        self,
        preferences: UpdateNotificationPreferencesRequest,
    ) -> ApiResponse[NotificationPreferences]:
        """Update notification preferences.

        Args:
            preferences: Preference updates.

        Returns:
            API response with updated preferences.
        """
        data = await self._patch("preferences", body=preferences.model_dump_api())
        result = None
        if data.get("data"):
            result = NotificationPreferences.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def get_unread_count(self) -> ApiResponse[dict[str, int]]:
        """Get unread notification count.

        Returns:
            API response with count.
        """
        data = await self._get("unread-count")
        return ApiResponse(
            success=data.get("success", True),
            data=data.get("data"),
            error=data.get("error"),
        )

    async def test_webhook(self) -> ApiResponse[SimpleMessage]:
        """Test the webhook configuration.

        Returns:
            API response with confirmation.
        """
        data = await self._post("preferences/test-webhook")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
