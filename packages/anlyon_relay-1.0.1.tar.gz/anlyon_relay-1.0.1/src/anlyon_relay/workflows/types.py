"""Workflow types for the Anlyon Relay SDK.

Types for Anlyon Workflows - a durable execution framework.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, TypeVar, Union

from pydantic import BaseModel, Field

T = TypeVar("T")

# ==========================================
# Duration Helpers
# ==========================================

Duration = Union[int, str]


def parse_duration(duration: Duration) -> int:
    """Parse a duration string into seconds.

    Args:
        duration: Duration as seconds (int) or string like "30s", "5m", "1h", "1d", "1w".

    Returns:
        Duration in seconds.

    Raises:
        ValueError: If the duration format is invalid.
    """
    if isinstance(duration, int):
        return duration

    match = re.match(r"^(\d+)(s|m|h|d|w)$", duration)
    if not match:
        raise ValueError(
            f'Invalid duration format: {duration}. '
            'Use format like "30s", "5m", "1h", "1d", "1w"'
        )

    value = int(match.group(1))
    unit = match.group(2)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    return value * multipliers[unit]


# ==========================================
# HTTP Types
# ==========================================


@dataclass
class CallOptions:
    """Options for HTTP call steps."""

    method: str = "POST"
    headers: dict[str, str] | None = None
    body: Any | None = None
    timeout: Duration | None = None
    retries: int = 3


@dataclass
class CallResult(Generic[T]):
    """Result of an HTTP call step."""

    status: int
    headers: dict[str, str]
    body: T


# ==========================================
# Wait Options
# ==========================================


@dataclass
class WaitOptions:
    """Options for wait steps."""

    timeout: Duration | None = None


# ==========================================
# Step Info
# ==========================================


@dataclass
class StepInfo:
    """Information about a completed step, passed to on_step_finish callback."""

    name: str
    type: str  # 'run' | 'sleep' | 'call' | 'invoke' | 'wait_event' | 'notify'
    result: Any = None
    duration_ms: int = 0
    cached: bool = False


# ==========================================
# Failure Context and Serve Options
# ==========================================


@dataclass
class FailureContext(Generic[T]):
    """Context passed to failure handler."""

    run_id: str
    payload: T
    error: Exception
    failed_step: str | None = None
    retries_attempted: int = 0


@dataclass
class ServeWorkflowOptions(Generic[T]):
    """Options for the serve/handler function."""

    signing_secret: str | None = None
    failure_function: Callable[[FailureContext[T]], Any] | None = None
    failure_url: str | None = None
    retries: int = 3
    on_step_finish: Callable[[StepInfo], None] | None = None
    base_url: str | None = None


# ==========================================
# Internal Wire Types (platform protocol)
# ==========================================


class StepResult(BaseModel):
    """Step result sent back to the platform."""

    step_name: str = Field(..., alias="stepName")
    step_type: str = Field(..., alias="stepType")
    status: str  # 'completed' | 'failed'
    output: Any = None
    error: str | None = None
    # Sleep fields
    sleep_until: int | None = Field(None, alias="sleepUntil")
    # Call fields
    call_url: str | None = Field(None, alias="callUrl")
    call_method: str | None = Field(None, alias="callMethod")
    call_headers: dict[str, str] | None = Field(None, alias="callHeaders")
    call_body: Any = Field(None, alias="callBody")
    # Event fields
    event_id: str | None = Field(None, alias="eventId")
    event_timeout: int | None = Field(None, alias="eventTimeout")
    # Invoke fields
    invoke_workflow_id: str | None = Field(None, alias="invokeWorkflowId")
    invoke_payload: Any = Field(None, alias="invokePayload")

    model_config = {"populate_by_name": True}

    def to_dict(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the platform API."""
        return self.model_dump(by_alias=True, exclude_none=True)


class WorkflowRequest(BaseModel):
    """Request payload from the platform to the user's workflow endpoint."""

    run_id: str = Field(..., alias="runId")
    workflow_id: str = Field(..., alias="workflowId")
    payload: Any = None
    step_cache: dict[str, Any] = Field(default_factory=dict, alias="stepCache")
    attempt: int = 1
    is_retry: bool = Field(False, alias="isRetry")

    model_config = {"populate_by_name": True}


class WorkflowResponse(BaseModel):
    """Response from the user's workflow endpoint back to the platform."""

    completed: bool
    result: Any = None
    pending_step: StepResult | None = Field(None, alias="pendingStep")
    error: str | None = None

    model_config = {"populate_by_name": True}

    def to_dict(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the platform API."""
        data: dict[str, Any] = {"completed": self.completed}
        if self.result is not None:
            data["result"] = self.result
        if self.pending_step is not None:
            data["pendingStep"] = self.pending_step.to_dict()
        if self.error is not None:
            data["error"] = self.error
        return data


# ==========================================
# Errors
# ==========================================


class WorkflowCancelledError(Exception):
    """Raised when a workflow is cancelled via context.cancel()."""

    def __init__(self, run_id: str) -> None:
        super().__init__(f"Workflow {run_id} was cancelled")
        self.run_id = run_id


class StepExecutionError(Exception):
    """Raised when a step function raises an exception."""

    def __init__(self, step_name: str, original_error: Exception) -> None:
        super().__init__(f'Step "{step_name}" failed: {original_error}')
        self.step_name = step_name
        self.original_error = original_error


class StepPendingError(Exception):
    """Internal: raised to signal a step needs platform action (sleep, call, wait, etc.).

    This is a control flow mechanism, not a real error. The serve handler catches it
    to build the WorkflowResponse.
    """

    def __init__(self, step_result: StepResult) -> None:
        super().__init__(f'Step "{step_result.step_name}" is pending')
        self.step_result = step_result
