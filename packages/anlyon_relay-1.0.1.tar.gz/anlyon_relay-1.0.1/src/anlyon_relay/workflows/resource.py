"""Workflows API resource for the Anlyon Relay SDK.

Provides CRUD operations on workflow definitions and runs, plus event notification.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from pydantic import BaseModel, Field

from ..core.http_client import AsyncHttpClient, HttpClient
from ..resources.base import AsyncBaseResource, BaseResource
from ..types.responses import PaginatedResponse, Pagination

# ==========================================
# Workflow API Types
# ==========================================


class WorkflowDefinition(BaseModel):
    """A workflow definition registered in the platform."""

    workflow_id: str = Field(..., alias="workflowId")
    name: str
    url: str
    method: str
    retries: int
    failure_url: str | None = Field(None, alias="failureUrl")
    is_active: bool = Field(..., alias="isActive")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str = Field(..., alias="updatedAt")

    model_config = {"populate_by_name": True}


class WorkflowRun(BaseModel):
    """A single execution run of a workflow."""

    run_id: str = Field(..., alias="runId")
    workflow_id: str = Field(..., alias="workflowId")
    workflow_name: str | None = Field(None, alias="workflowName")
    status: str  # 'pending' | 'running' | 'waiting' | 'completed' | 'failed' | 'cancelled'
    current_step_index: int = Field(..., alias="currentStepIndex")
    error_message: str | None = Field(None, alias="errorMessage")
    result: Any = None
    initial_payload: Any = Field(None, alias="initialPayload")
    started_at: str | None = Field(None, alias="startedAt")
    completed_at: str | None = Field(None, alias="completedAt")
    next_step_at: str | None = Field(None, alias="nextStepAt")
    waiting_for_event: str | None = Field(None, alias="waitingForEvent")
    created_at: str = Field(..., alias="createdAt")
    updated_at: str | None = Field(None, alias="updatedAt")

    model_config = {"populate_by_name": True}


class WorkflowStep(BaseModel):
    """A single step within a workflow run."""

    step_id: str = Field(..., alias="stepId")
    step_name: str = Field(..., alias="stepName")
    step_index: int = Field(..., alias="stepIndex")
    step_type: str = Field(..., alias="stepType")
    status: str  # 'pending' | 'running' | 'completed' | 'failed'
    output: Any = None
    error_message: str | None = Field(None, alias="errorMessage")
    attempt_count: int = Field(..., alias="attemptCount")
    duration_ms: int | None = Field(None, alias="durationMs")
    started_at: str | None = Field(None, alias="startedAt")
    completed_at: str | None = Field(None, alias="completedAt")
    created_at: str = Field(..., alias="createdAt")

    model_config = {"populate_by_name": True}


class CreateWorkflowRequest(BaseModel):
    """Request to create a new workflow definition."""

    name: str = Field(..., min_length=1, description="Workflow name")
    url: str = Field(..., min_length=1, description="Endpoint URL the platform calls")
    method: str = Field(default="POST", description="HTTP method")
    retries: int = Field(default=3, ge=0, description="Max retries")
    failure_url: str | None = Field(None, description="URL to POST on failure")

    def model_dump_api(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the API."""
        data: dict[str, Any] = {"name": self.name, "url": self.url, "method": self.method}
        if self.retries != 3:
            data["retries"] = self.retries
        if self.failure_url is not None:
            data["failureUrl"] = self.failure_url
        return data


class UpdateWorkflowRequest(BaseModel):
    """Request to update an existing workflow definition."""

    name: str | None = None
    url: str | None = None
    method: str | None = None
    retries: int | None = None
    failure_url: str | None = None
    is_active: bool | None = None

    def model_dump_api(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the API."""
        data: dict[str, Any] = {}
        if self.name is not None:
            data["name"] = self.name
        if self.url is not None:
            data["url"] = self.url
        if self.method is not None:
            data["method"] = self.method
        if self.retries is not None:
            data["retries"] = self.retries
        if self.failure_url is not None:
            data["failureUrl"] = self.failure_url
        if self.is_active is not None:
            data["isActive"] = self.is_active
        return data


class TriggerWorkflowRequest(BaseModel):
    """Request to trigger a workflow run."""

    payload: Any = None

    def model_dump_api(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the API."""
        data: dict[str, Any] = {}
        if self.payload is not None:
            data["payload"] = self.payload
        return data


class TriggerResult(BaseModel):
    """Result of triggering a workflow run."""

    run_id: str = Field(..., alias="runId")
    workflow_id: str = Field(..., alias="workflowId")
    status: str
    created_at: str = Field(..., alias="createdAt")

    model_config = {"populate_by_name": True}


class ListWorkflowsParams(BaseModel):
    """Parameters for listing workflows."""

    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")
    search: str | None = None
    is_active: bool | None = None

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.search:
            params["search"] = self.search
        if self.is_active is not None:
            params["isActive"] = self.is_active
        return params


class ListRunsParams(BaseModel):
    """Parameters for listing workflow runs."""

    page: int = Field(default=1, ge=1, description="Page number")
    limit: int = Field(default=20, ge=1, le=100, description="Items per page")
    workflow_id: str | None = None
    status: str | None = None
    start_date: str | None = None
    end_date: str | None = None

    def to_query_params(self) -> dict[str, Any]:
        """Convert to query parameters."""
        params: dict[str, Any] = {"page": self.page, "limit": self.limit}
        if self.workflow_id:
            params["workflowId"] = self.workflow_id
        if self.status:
            params["status"] = self.status
        if self.start_date:
            params["startDate"] = self.start_date
        if self.end_date:
            params["endDate"] = self.end_date
        return params


class NotifyEventRequest(BaseModel):
    """Request to notify a waiting workflow of an external event."""

    event_id: str = Field(..., alias="eventId", description="The event identifier")
    data: Any = None

    model_config = {"populate_by_name": True}

    def model_dump_api(self) -> dict[str, Any]:
        """Serialize to camelCase dict for the API."""
        body: dict[str, Any] = {"eventId": self.event_id}
        if self.data is not None:
            body["data"] = self.data
        return body


class NotifyResult(BaseModel):
    """Result of sending an event notification."""

    message: str
    notified_run_id: str | None = Field(None, alias="notifiedRunId")

    model_config = {"populate_by_name": True}


# ==========================================
# Helper: parse paginated response
# ==========================================


def _parse_paginated(data: dict[str, Any]) -> tuple[list[Any], Pagination | None]:
    """Parse raw paginated response data."""
    items = data.get("data") or []
    pagination_data = data.get("pagination")
    pagination = None
    if pagination_data:
        pagination = Pagination(
            page=pagination_data.get("page", 1),
            limit=pagination_data.get("limit", 20),
            total=pagination_data.get("total", 0),
            totalPages=pagination_data.get("totalPages", 0),
            hasNext=pagination_data.get("hasNext", False),
            hasPrevious=pagination_data.get("hasPrevious", False),
        )
    return items, pagination


# ==========================================
# Synchronous Workflows Resource
# ==========================================


class WorkflowsResource(BaseResource):
    """Synchronous client for the Anlyon Workflows API."""

    _base_path = "/api/v2/workflows"

    def create(self, request: CreateWorkflowRequest) -> WorkflowDefinition:
        """Create a new workflow definition.

        Args:
            request: Workflow creation request.

        Returns:
            The created WorkflowDefinition.
        """
        data = self._post(body=request.model_dump_api())
        return WorkflowDefinition.model_validate(data["data"])

    def list(
        self, params: ListWorkflowsParams | None = None
    ) -> PaginatedResponse[WorkflowDefinition]:
        """List all workflow definitions.

        Args:
            params: Optional filter/pagination parameters.

        Returns:
            Paginated list of WorkflowDefinition objects.
        """
        query = (params or ListWorkflowsParams()).to_query_params()
        data = self._get(params=query)
        items, pagination = _parse_paginated(data)
        return PaginatedResponse(
            success=data.get("success", True),
            data=[WorkflowDefinition.model_validate(w) for w in items],
            pagination=pagination,
            error=data.get("error"),
        )

    def get(self, workflow_id: str) -> WorkflowDefinition:
        """Get a workflow definition by ID.

        Args:
            workflow_id: The workflow identifier.

        Returns:
            The WorkflowDefinition.
        """
        data = self._get(workflow_id)
        return WorkflowDefinition.model_validate(data["data"])

    def update(self, workflow_id: str, request: UpdateWorkflowRequest) -> WorkflowDefinition:
        """Update a workflow definition.

        Args:
            workflow_id: The workflow identifier.
            request: Update request.

        Returns:
            The updated WorkflowDefinition.
        """
        data = self._patch(workflow_id, body=request.model_dump_api())
        return WorkflowDefinition.model_validate(data["data"])

    def delete(self, workflow_id: str) -> None:
        """Delete a workflow definition.

        Args:
            workflow_id: The workflow identifier.
        """
        self._delete(workflow_id)

    def trigger(
        self, workflow_id: str, request: TriggerWorkflowRequest | None = None
    ) -> TriggerResult:
        """Trigger a workflow run.

        Args:
            workflow_id: The workflow to trigger.
            request: Optional trigger request with payload.

        Returns:
            The TriggerResult with run ID.
        """
        body = (request or TriggerWorkflowRequest()).model_dump_api()
        data = self._post(f"{workflow_id}/trigger", body=body)
        return TriggerResult.model_validate(data["data"])

    def list_runs(
        self, params: ListRunsParams | None = None
    ) -> PaginatedResponse[WorkflowRun]:
        """List workflow runs.

        Args:
            params: Optional filter/pagination parameters.

        Returns:
            Paginated list of WorkflowRun objects.
        """
        query = (params or ListRunsParams()).to_query_params()
        data = self._get("runs", params=query)
        items, pagination = _parse_paginated(data)
        return PaginatedResponse(
            success=data.get("success", True),
            data=[WorkflowRun.model_validate(r) for r in items],
            pagination=pagination,
            error=data.get("error"),
        )

    def get_run(self, run_id: str) -> WorkflowRun:
        """Get a workflow run by ID.

        Args:
            run_id: The run identifier.

        Returns:
            The WorkflowRun.
        """
        data = self._get(f"runs/{run_id}")
        return WorkflowRun.model_validate(data["data"])

    def get_run_steps(self, run_id: str) -> list[WorkflowStep]:
        """Get all steps for a workflow run.

        Args:
            run_id: The run identifier.

        Returns:
            List of WorkflowStep objects.
        """
        data = self._get(f"runs/{run_id}/steps")
        return [WorkflowStep.model_validate(s) for s in (data.get("data") or [])]

    def cancel_run(self, run_id: str) -> None:
        """Cancel a workflow run.

        Args:
            run_id: The run identifier.
        """
        self._post(f"runs/{run_id}/cancel")

    def notify(self, request: NotifyEventRequest) -> NotifyResult:
        """Send an event notification to wake up waiting workflows.

        Args:
            request: Event notification request with event_id and optional data.

        Returns:
            The NotifyResult.
        """
        data = self._post("events/notify", body=request.model_dump_api())
        return NotifyResult.model_validate(data["data"])

    def wait_for_completion(
        self,
        run_id: str,
        poll_interval: float = 1.0,
        timeout: float = 60.0,
    ) -> WorkflowRun:
        """Poll until a workflow run reaches a terminal state.

        Args:
            run_id: The run identifier.
            poll_interval: Seconds between polls (default: 1.0).
            timeout: Maximum seconds to wait (default: 60.0).

        Returns:
            The completed WorkflowRun.

        Raises:
            TimeoutError: If the run doesn't complete within the timeout.
        """
        terminal = {"completed", "failed", "cancelled"}
        start = time.time()

        while time.time() - start < timeout:
            run = self.get_run(run_id)
            if run.status in terminal:
                return run
            time.sleep(poll_interval)

        raise TimeoutError(f"Timeout waiting for workflow run {run_id} to complete")


# ==========================================
# Asynchronous Workflows Resource
# ==========================================


class AsyncWorkflowsResource(AsyncBaseResource):
    """Asynchronous client for the Anlyon Workflows API."""

    _base_path = "/api/v2/workflows"

    async def create(self, request: CreateWorkflowRequest) -> WorkflowDefinition:
        """Create a new workflow definition.

        Args:
            request: Workflow creation request.

        Returns:
            The created WorkflowDefinition.
        """
        data = await self._post(body=request.model_dump_api())
        return WorkflowDefinition.model_validate(data["data"])

    async def list(
        self, params: ListWorkflowsParams | None = None
    ) -> PaginatedResponse[WorkflowDefinition]:
        """List all workflow definitions.

        Args:
            params: Optional filter/pagination parameters.

        Returns:
            Paginated list of WorkflowDefinition objects.
        """
        query = (params or ListWorkflowsParams()).to_query_params()
        data = await self._get(params=query)
        items, pagination = _parse_paginated(data)
        return PaginatedResponse(
            success=data.get("success", True),
            data=[WorkflowDefinition.model_validate(w) for w in items],
            pagination=pagination,
            error=data.get("error"),
        )

    async def get(self, workflow_id: str) -> WorkflowDefinition:
        """Get a workflow definition by ID.

        Args:
            workflow_id: The workflow identifier.

        Returns:
            The WorkflowDefinition.
        """
        data = await self._get(workflow_id)
        return WorkflowDefinition.model_validate(data["data"])

    async def update(
        self, workflow_id: str, request: UpdateWorkflowRequest
    ) -> WorkflowDefinition:
        """Update a workflow definition.

        Args:
            workflow_id: The workflow identifier.
            request: Update request.

        Returns:
            The updated WorkflowDefinition.
        """
        data = await self._patch(workflow_id, body=request.model_dump_api())
        return WorkflowDefinition.model_validate(data["data"])

    async def delete(self, workflow_id: str) -> None:
        """Delete a workflow definition.

        Args:
            workflow_id: The workflow identifier.
        """
        await self._delete(workflow_id)

    async def trigger(
        self, workflow_id: str, request: TriggerWorkflowRequest | None = None
    ) -> TriggerResult:
        """Trigger a workflow run.

        Args:
            workflow_id: The workflow to trigger.
            request: Optional trigger request with payload.

        Returns:
            The TriggerResult with run ID.
        """
        body = (request or TriggerWorkflowRequest()).model_dump_api()
        data = await self._post(f"{workflow_id}/trigger", body=body)
        return TriggerResult.model_validate(data["data"])

    async def list_runs(
        self, params: ListRunsParams | None = None
    ) -> PaginatedResponse[WorkflowRun]:
        """List workflow runs.

        Args:
            params: Optional filter/pagination parameters.

        Returns:
            Paginated list of WorkflowRun objects.
        """
        query = (params or ListRunsParams()).to_query_params()
        data = await self._get("runs", params=query)
        items, pagination = _parse_paginated(data)
        return PaginatedResponse(
            success=data.get("success", True),
            data=[WorkflowRun.model_validate(r) for r in items],
            pagination=pagination,
            error=data.get("error"),
        )

    async def get_run(self, run_id: str) -> WorkflowRun:
        """Get a workflow run by ID.

        Args:
            run_id: The run identifier.

        Returns:
            The WorkflowRun.
        """
        data = await self._get(f"runs/{run_id}")
        return WorkflowRun.model_validate(data["data"])

    async def get_run_steps(self, run_id: str) -> list[WorkflowStep]:
        """Get all steps for a workflow run.

        Args:
            run_id: The run identifier.

        Returns:
            List of WorkflowStep objects.
        """
        data = await self._get(f"runs/{run_id}/steps")
        return [WorkflowStep.model_validate(s) for s in (data.get("data") or [])]

    async def cancel_run(self, run_id: str) -> None:
        """Cancel a workflow run.

        Args:
            run_id: The run identifier.
        """
        await self._post(f"runs/{run_id}/cancel")

    async def notify(self, request: NotifyEventRequest) -> NotifyResult:
        """Send an event notification to wake up waiting workflows.

        Args:
            request: Event notification request with event_id and optional data.

        Returns:
            The NotifyResult.
        """
        data = await self._post("events/notify", body=request.model_dump_api())
        return NotifyResult.model_validate(data["data"])

    async def wait_for_completion(
        self,
        run_id: str,
        poll_interval: float = 1.0,
        timeout: float = 60.0,
    ) -> WorkflowRun:
        """Poll until a workflow run reaches a terminal state.

        Args:
            run_id: The run identifier.
            poll_interval: Seconds between polls (default: 1.0).
            timeout: Maximum seconds to wait (default: 60.0).

        Returns:
            The completed WorkflowRun.

        Raises:
            TimeoutError: If the run doesn't complete within the timeout.
        """
        terminal = {"completed", "failed", "cancelled"}
        start = time.time()

        while time.time() - start < timeout:
            run = await self.get_run(run_id)
            if run.status in terminal:
                return run
            await asyncio.sleep(poll_interval)

        raise TimeoutError(f"Timeout waiting for workflow run {run_id} to complete")
