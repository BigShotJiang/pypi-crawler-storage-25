"""Anlyon Workflows - Durable execution framework for long-running, multi-step workflows.

Example:
    ```python
    from anlyon_relay.workflows import WorkflowContext, create_workflow_handler

    async def process_order(context: WorkflowContext):
        # Step 1: Validate order (result cached on re-execution)
        order = await context.run('validate', lambda: validate_order(context.payload))

        # Step 2: Wait for payment confirmation event
        payment = await context.wait_for_event('payment-confirm', f"order-{order['id']}")

        # Step 3: Sleep 1 hour before shipping
        await context.sleep('pre-ship-delay', '1h')

        return {'status': 'shipped', 'orderId': order['id']}

    handler = create_workflow_handler(process_order)
    ```
"""

# Context
from .context import WorkflowContext

# Resource (API client)
from .resource import (
    AsyncWorkflowsResource,
    CreateWorkflowRequest,
    ListRunsParams,
    ListWorkflowsParams,
    NotifyEventRequest,
    NotifyResult,
    TriggerResult,
    TriggerWorkflowRequest,
    UpdateWorkflowRequest,
    WorkflowDefinition,
    WorkflowRun,
    WorkflowsResource,
    WorkflowStep,
)

# Serve utilities
from .serve import create_workflow_handler

# Types
from .types import (
    CallOptions,
    CallResult,
    Duration,
    FailureContext,
    ServeWorkflowOptions,
    StepExecutionError,
    StepInfo,
    StepPendingError,
    StepResult,
    WaitOptions,
    WorkflowCancelledError,
    WorkflowRequest,
    WorkflowResponse,
    parse_duration,
)

__all__ = [
    # Context
    "WorkflowContext",
    # Serve
    "create_workflow_handler",
    # Types
    "CallOptions",
    "CallResult",
    "Duration",
    "FailureContext",
    "ServeWorkflowOptions",
    "StepExecutionError",
    "StepInfo",
    "StepPendingError",
    "StepResult",
    "WaitOptions",
    "WorkflowCancelledError",
    "WorkflowRequest",
    "WorkflowResponse",
    "parse_duration",
    # Resource types
    "AsyncWorkflowsResource",
    "CreateWorkflowRequest",
    "ListRunsParams",
    "ListWorkflowsParams",
    "NotifyEventRequest",
    "NotifyResult",
    "TriggerResult",
    "TriggerWorkflowRequest",
    "UpdateWorkflowRequest",
    "WorkflowDefinition",
    "WorkflowRun",
    "WorkflowsResource",
    "WorkflowStep",
]
