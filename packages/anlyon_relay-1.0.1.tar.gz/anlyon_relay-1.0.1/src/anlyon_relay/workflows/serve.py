"""Workflow serve utilities.

Creates framework-agnostic handlers for workflow endpoints that integrate
with the Anlyon platform.
"""

from __future__ import annotations

import inspect
import json
import logging
import os
from typing import Any, Callable

from ..webhooks.receiver import Receiver, ReceiverConfig, SignatureVerificationError
from .context import WorkflowContext
from .types import (
    FailureContext,
    ServeWorkflowOptions,
    StepPendingError,
    WorkflowCancelledError,
    WorkflowRequest,
    WorkflowResponse,
)

logger = logging.getLogger(__name__)


async def _handle_workflow_request(
    request: WorkflowRequest,
    handler: Callable[[WorkflowContext], Any],
    options: ServeWorkflowOptions,  # type: ignore[type-arg]
) -> WorkflowResponse:
    """Internal handler that processes a validated workflow request."""
    context = WorkflowContext(
        request=request,
        on_step_finish=options.on_step_finish,
    )

    try:
        result = handler(context)
        if inspect.isawaitable(result):
            result = await result

        return WorkflowResponse(completed=True, result=result)

    except StepPendingError as e:
        return WorkflowResponse(completed=False, pendingStep=e.step_result)

    except WorkflowCancelledError:
        return WorkflowResponse(completed=False, error="Workflow cancelled")

    except Exception as e:
        error_message = str(e)

        if options.failure_function:
            failure_ctx: FailureContext[Any] = FailureContext(
                run_id=request.run_id,
                payload=request.payload,
                error=e,
                retries_attempted=request.attempt,
            )
            try:
                failure_result = options.failure_function(failure_ctx)
                if inspect.isawaitable(failure_result):
                    await failure_result
            except Exception as fe:
                logger.error("[Anlyon Workflows] Failure function error: %s", fe)

        return WorkflowResponse(completed=False, error=error_message)


def create_workflow_handler(
    handler: Callable[[WorkflowContext], Any],
    options: ServeWorkflowOptions | None = None,  # type: ignore[type-arg]
) -> Callable[[str, str | None], Any]:
    """Create a framework-agnostic async workflow handler.

    The returned handler verifies the platform signature, parses the request,
    executes the workflow function, and returns a WorkflowResponse.

    Args:
        handler: The workflow async function ``async def my_workflow(context: WorkflowContext)``.
        options: Optional serve options (signing_secret, failure_function, etc.).

    Returns:
        An async callable ``(body: str, signature: str | None) -> WorkflowResponse``.

    Raises:
        ValueError: If the signing secret is not configured.

    Example:
        ```python
        from anlyon_relay.workflows import WorkflowContext, create_workflow_handler

        async def process_order(context: WorkflowContext):
            order = await context.run('validate', lambda: validate_order(context.payload))
            await context.sleep('wait', '10m')
            return {'status': 'processed', 'orderId': order['id']}

        handler = create_workflow_handler(process_order)

        # In your web framework:
        # body = await request.text()
        # signature = request.headers.get('x-anlyon-signature')
        # response = await handler(body, signature)
        # return JSONResponse(response.to_dict())
        ```
    """
    opts = options or ServeWorkflowOptions()

    signing_secret = opts.signing_secret or os.environ.get("ANLYON_SIGNING_SECRET")
    if not signing_secret:
        raise ValueError(
            "Signing secret is required. Set ANLYON_SIGNING_SECRET environment variable "
            "or pass signing_secret in ServeWorkflowOptions."
        )

    receiver = Receiver(ReceiverConfig(signing_secret=signing_secret, clock_tolerance=300))

    async def handle(body: str, signature: str | None) -> WorkflowResponse:
        try:
            receiver.verify_or_throw(signature, body)
        except SignatureVerificationError as e:
            raise ValueError("Invalid signature") from e

        try:
            data = json.loads(body)
            request = WorkflowRequest.model_validate(data)
        except Exception as e:
            raise ValueError(f"Invalid request body: {e}") from e

        return await _handle_workflow_request(request, handler, opts)

    return handle
