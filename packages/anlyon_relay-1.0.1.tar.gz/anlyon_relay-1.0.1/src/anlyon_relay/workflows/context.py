"""Workflow context implementation.

Provides the execution context for workflow functions with durable step execution.
"""

from __future__ import annotations

import inspect
import time
from typing import Any, Callable

from .types import (
    CallOptions,
    CallResult,
    Duration,
    StepInfo,
    StepPendingError,
    StepResult,
    WaitOptions,
    WorkflowCancelledError,
    WorkflowRequest,
    parse_duration,
)


class WorkflowContext:
    """Context object passed to workflow handler functions.

    Provides methods for durable step execution. Each method either returns a
    cached result (on re-execution) or raises StepPendingError to signal the
    platform that action is needed.

    Example:
        ```python
        async def my_workflow(context: WorkflowContext):
            # Step 1: Execute once and cache result
            user = await context.run('fetch-user', lambda: db.find_user(context.payload['id']))

            # Step 2: Sleep for 1 hour (no compute consumed)
            await context.sleep('wait', '1h')

            # Step 3: Wait for external event
            shipment = await context.wait_for_event('ship-confirm', f"order-{user['id']}")

            return {'status': 'shipped', 'tracking': shipment['trackingNumber']}
        ```
    """

    def __init__(
        self,
        request: WorkflowRequest,
        on_step_finish: Callable[[StepInfo], None] | None = None,
    ) -> None:
        """Initialize the context from a platform request.

        Args:
            request: The incoming workflow request from the platform.
            on_step_finish: Optional callback invoked after each step completes.
        """
        self.run_id: str = request.run_id
        self.payload: Any = request.payload
        self.attempt: int = request.attempt
        self._step_cache: dict[str, Any] = request.step_cache or {}
        self._executed_steps: set[str] = set()
        self._on_step_finish = on_step_finish

    def _validate_step_name(self, step_name: str) -> None:
        """Ensure step names are unique within a workflow execution."""
        if step_name in self._executed_steps:
            raise ValueError(
                f'Step name "{step_name}" has already been used in this workflow. '
                "Each step must have a unique name."
            )
        self._executed_steps.add(step_name)

    def _notify_step_finish(self, info: StepInfo) -> None:
        """Invoke the on_step_finish callback if configured."""
        if self._on_step_finish:
            try:
                self._on_step_finish(info)
            except Exception:
                pass  # Don't let callback errors affect workflow execution

    async def run(self, step_name: str, fn: Callable[[], Any]) -> Any:
        """Execute a step with automatic result persistence.

        On re-execution, returns the cached result instead of re-running.

        Args:
            step_name: Unique name for this step within the workflow.
            fn: The function to execute. Can be sync or async.

        Returns:
            The result of the function (or cached result).

        Example:
            ```python
            user = await context.run('fetch-user', lambda: db.find_user(user_id))
            ```
        """
        self._validate_step_name(step_name)

        if step_name in self._step_cache:
            cached_result = self._step_cache[step_name]
            self._notify_step_finish(
                StepInfo(name=step_name, type="run", result=cached_result, duration_ms=0, cached=True)
            )
            return cached_result

        start_time = time.monotonic()
        try:
            result = fn()
            if inspect.isawaitable(result):
                result = await result
        except Exception as e:
            raise StepPendingError(
                StepResult(stepName=step_name, stepType="run", status="failed", error=str(e))
            ) from e

        duration_ms = int((time.monotonic() - start_time) * 1000)
        self._notify_step_finish(
            StepInfo(name=step_name, type="run", result=result, duration_ms=duration_ms, cached=False)
        )

        raise StepPendingError(
            StepResult(stepName=step_name, stepType="run", status="completed", output=result)
        )

    async def sleep(self, step_name: str, duration: Duration) -> None:
        """Pause the workflow for a specified duration.

        The workflow resumes after the duration without consuming compute resources.

        Args:
            step_name: Unique name for this step.
            duration: How long to sleep (e.g., "30s", "5m", "1h", 60).

        Example:
            ```python
            await context.sleep('wait-1-hour', '1h')
            ```
        """
        self._validate_step_name(step_name)

        if step_name in self._step_cache:
            self._notify_step_finish(StepInfo(name=step_name, type="sleep", duration_ms=0, cached=True))
            return

        seconds = parse_duration(duration)
        sleep_until = int(time.time()) + seconds

        raise StepPendingError(
            StepResult(stepName=step_name, stepType="sleep", status="completed", sleepUntil=sleep_until)
        )

    async def sleep_until(self, step_name: str, timestamp: Any) -> None:
        """Pause the workflow until a specific timestamp.

        Args:
            step_name: Unique name for this step.
            timestamp: When to wake up. Accepts a datetime object or Unix timestamp (int/float).

        Example:
            ```python
            from datetime import datetime
            await context.sleep_until('wait-until-midnight', datetime(2024, 1, 1, 0, 0, 0))
            ```
        """
        self._validate_step_name(step_name)

        if step_name in self._step_cache:
            self._notify_step_finish(StepInfo(name=step_name, type="sleep", duration_ms=0, cached=True))
            return

        if hasattr(timestamp, "timestamp"):
            sleep_until = int(timestamp.timestamp())
        else:
            sleep_until = int(timestamp)

        raise StepPendingError(
            StepResult(stepName=step_name, stepType="sleep", status="completed", sleepUntil=sleep_until)
        )

    async def call(
        self,
        step_name: str,
        url: str,
        options: CallOptions | None = None,
    ) -> CallResult[Any]:
        """Make an HTTP call managed by the platform.

        Avoids timeout issues by having the platform make the request on your behalf.

        Args:
            step_name: Unique name for this step.
            url: The URL to call.
            options: Request options (method, headers, body, timeout, retries).

        Returns:
            The HTTP response with status, headers, and body.

        Example:
            ```python
            result = await context.call('charge', 'https://api.stripe.com/charge', CallOptions(
                method='POST',
                headers={'Authorization': 'Bearer sk_...'},
                body={'amount': 1000},
            ))
            ```
        """
        self._validate_step_name(step_name)
        opts = options or CallOptions()

        if step_name in self._step_cache:
            cached = self._step_cache[step_name]
            if isinstance(cached, dict):
                result: CallResult[Any] = CallResult(
                    status=cached.get("status", 200),
                    headers=cached.get("headers", {}),
                    body=cached.get("body"),
                )
            else:
                result = cached
            self._notify_step_finish(
                StepInfo(name=step_name, type="call", result=result, duration_ms=0, cached=True)
            )
            return result

        raise StepPendingError(
            StepResult(
                stepName=step_name,
                stepType="call",
                status="completed",
                callUrl=url,
                callMethod=opts.method,
                callHeaders=opts.headers,
                callBody=opts.body,
            )
        )

    async def wait_for_event(
        self,
        step_name: str,
        event_id: str,
        options: WaitOptions | None = None,
    ) -> Any:
        """Wait for an external event notification.

        The workflow pauses until another system calls the notify API.

        Args:
            step_name: Unique name for this step.
            event_id: The event identifier to wait for.
            options: Wait options including timeout.

        Returns:
            The data sent with the notification.

        Example:
            ```python
            shipment = await context.wait_for_event(
                'wait-shipment', f'order-{order_id}', WaitOptions(timeout='24h')
            )
            ```
        """
        self._validate_step_name(step_name)
        opts = options or WaitOptions()

        if step_name in self._step_cache:
            cached = self._step_cache[step_name]

            if isinstance(cached, dict) and cached.get("__waiting"):
                # Still waiting — re-throw to continue waiting
                raise StepPendingError(
                    StepResult(
                        stepName=step_name,
                        stepType="wait_event",
                        status="completed",
                        eventId=event_id,
                        eventTimeout=(
                            int(time.time()) + parse_duration(opts.timeout)
                            if opts.timeout
                            else None
                        ),
                    )
                )

            data = cached.get("data") if isinstance(cached, dict) else cached
            self._notify_step_finish(
                StepInfo(name=step_name, type="wait_event", result=data, duration_ms=0, cached=True)
            )
            return data

        timeout_seconds = (
            parse_duration(opts.timeout) if opts.timeout else 7 * 24 * 60 * 60
        )
        event_timeout = int(time.time()) + timeout_seconds

        raise StepPendingError(
            StepResult(
                stepName=step_name,
                stepType="wait_event",
                status="completed",
                eventId=event_id,
                eventTimeout=event_timeout,
            )
        )

    async def invoke(
        self,
        step_name: str,
        workflow_id: str,
        payload: Any = None,
    ) -> Any:
        """Trigger another workflow and wait for its completion.

        Args:
            step_name: Unique name for this step.
            workflow_id: The ID of the workflow to invoke.
            payload: Optional payload for the invoked workflow.

        Returns:
            The result of the invoked workflow.

        Example:
            ```python
            result = await context.invoke('process-payment', 'wfl_paymentProcessor', {'amount': 100})
            ```
        """
        self._validate_step_name(step_name)

        if step_name in self._step_cache:
            cached_result = self._step_cache[step_name]
            self._notify_step_finish(
                StepInfo(name=step_name, type="invoke", result=cached_result, duration_ms=0, cached=True)
            )
            return cached_result

        raise StepPendingError(
            StepResult(
                stepName=step_name,
                stepType="invoke",
                status="completed",
                invokeWorkflowId=workflow_id,
                invokePayload=payload,
            )
        )

    async def notify(self, step_name: str, event_id: str, data: Any = None) -> None:
        """Send an event notification to wake up waiting workflows.

        Args:
            step_name: Unique name for this step.
            event_id: The event identifier.
            data: Optional data to send with the event.

        Example:
            ```python
            await context.notify('ship-order', f'order-{order_id}', {'trackingNumber': 'ABC123'})
            ```
        """
        self._validate_step_name(step_name)

        if step_name in self._step_cache:
            self._notify_step_finish(StepInfo(name=step_name, type="notify", duration_ms=0, cached=True))
            return

        raise StepPendingError(
            StepResult(
                stepName=step_name,
                stepType="notify",
                status="completed",
                eventId=event_id,
                output=data,
            )
        )

    def cancel(self) -> None:
        """Cancel the current workflow run.

        Raises:
            WorkflowCancelledError: Always.
        """
        raise WorkflowCancelledError(self.run_id)
