"""Main client classes for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any

from .core.http_client import AsyncHttpClient, HttpClient
from .resources.analytics import AnalyticsResource, AsyncAnalyticsResource
from .resources.dlq import AsyncDlqResource, DlqResource
from .resources.messages import AsyncMessagesResource, MessagesResource
from .resources.queues import AsyncQueuesResource, QueuesResource
from .resources.schedules import AsyncSchedulesResource, SchedulesResource
from .resources.url_groups import AsyncUrlGroupsResource, UrlGroupsResource
from .types.config import ClientConfig, LoggingConfig, RetryConfig
from .webhooks.receiver import WebhookVerificationResult, verify_webhook_signature
from .workflows.resource import AsyncWorkflowsResource, WorkflowsResource


class Client:
    """Synchronous client for the Anlyon Relay API.

    Example:
        ```python
        from anlyon_relay import Client

        client = Client(api_key="your-api-key")

        # Publish a message
        result = client.messages.publish(
            PublishMessageRequest(url="https://example.com/webhook")
        )

        # Or use the fluent builder
        result = (
            client.messages.create_message()
            .to("https://example.com/webhook")
            .body({"hello": "world"})
            .send()
        )
        ```
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.anlyon.com",
        timeout: float = 30.0,
        retry: RetryConfig | None = None,
        logging: LoggingConfig | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication.
            base_url: Base URL for the API.
            timeout: Request timeout in seconds.
            retry: Retry configuration.
            logging: Logging configuration.
            default_headers: Default headers for all requests.
        """
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retry=retry or RetryConfig(),
            logging=logging or LoggingConfig(),
            default_headers=default_headers or {},
        )
        self._http = HttpClient(self._config)

        # Lazy-initialized resources
        self._messages: MessagesResource | None = None
        self._schedules: SchedulesResource | None = None
        self._url_groups: UrlGroupsResource | None = None
        self._queues: QueuesResource | None = None
        self._dlq: DlqResource | None = None
        self._analytics: AnalyticsResource | None = None
        self._workflows: WorkflowsResource | None = None

    @property
    def messages(self) -> MessagesResource:
        """Get the messages resource client."""
        if self._messages is None:
            self._messages = MessagesResource(self._http)
        return self._messages

    @property
    def schedules(self) -> SchedulesResource:
        """Get the schedules resource client."""
        if self._schedules is None:
            self._schedules = SchedulesResource(self._http)
        return self._schedules

    @property
    def url_groups(self) -> UrlGroupsResource:
        """Get the URL groups resource client."""
        if self._url_groups is None:
            self._url_groups = UrlGroupsResource(self._http)
        return self._url_groups

    @property
    def queues(self) -> QueuesResource:
        """Get the queues resource client."""
        if self._queues is None:
            self._queues = QueuesResource(self._http)
        return self._queues

    @property
    def dlq(self) -> DlqResource:
        """Get the DLQ (dead letter queue) resource client."""
        if self._dlq is None:
            self._dlq = DlqResource(self._http)
        return self._dlq

    @property
    def analytics(self) -> AnalyticsResource:
        """Get the analytics resource client."""
        if self._analytics is None:
            self._analytics = AnalyticsResource(self._http)
        return self._analytics

    @property
    def workflows(self) -> WorkflowsResource:
        """Get the workflows resource client."""
        if self._workflows is None:
            self._workflows = WorkflowsResource(self._http)
        return self._workflows

    def close(self) -> None:
        """Close the client and release resources."""
        self._http.close()

    def __enter__(self) -> "Client":
        """Enter context manager."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context manager."""
        self.close()

    @staticmethod
    def verify_webhook_signature(
        payload: str,
        signature_header: str,
        secret: str,
        tolerance_seconds: int = 300,
    ) -> WebhookVerificationResult:
        """Verify a webhook signature.

        Args:
            payload: The raw request body.
            signature_header: The signature header value (x-anlyon-signature).
            secret: The signing secret.
            tolerance_seconds: Maximum allowed timestamp difference.

        Returns:
            Verification result with valid status and optional error.
        """
        return verify_webhook_signature(
            payload=payload,
            signature_header=signature_header,
            secret=secret,
            tolerance_seconds=tolerance_seconds,
        )


class AsyncClient:
    """Asynchronous client for the Anlyon Relay API.

    Example:
        ```python
        from anlyon_relay import AsyncClient

        async with AsyncClient(api_key="your-api-key") as client:
            # Publish a message
            result = await client.messages.publish(
                PublishMessageRequest(url="https://example.com/webhook")
            )

            # Or use the fluent builder
            result = await (
                client.messages.create_message()
                .to("https://example.com/webhook")
                .body({"hello": "world"})
                .send_async()
            )
        ```
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.anlyon.com",
        timeout: float = 30.0,
        retry: RetryConfig | None = None,
        logging: LoggingConfig | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        """Initialize the async client.

        Args:
            api_key: API key for authentication.
            base_url: Base URL for the API.
            timeout: Request timeout in seconds.
            retry: Retry configuration.
            logging: Logging configuration.
            default_headers: Default headers for all requests.
        """
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retry=retry or RetryConfig(),
            logging=logging or LoggingConfig(),
            default_headers=default_headers or {},
        )
        self._http = AsyncHttpClient(self._config)

        # Lazy-initialized resources
        self._messages: AsyncMessagesResource | None = None
        self._schedules: AsyncSchedulesResource | None = None
        self._url_groups: AsyncUrlGroupsResource | None = None
        self._queues: AsyncQueuesResource | None = None
        self._dlq: AsyncDlqResource | None = None
        self._analytics: AsyncAnalyticsResource | None = None
        self._workflows: AsyncWorkflowsResource | None = None

    @property
    def messages(self) -> AsyncMessagesResource:
        """Get the messages resource client."""
        if self._messages is None:
            self._messages = AsyncMessagesResource(self._http)
        return self._messages

    @property
    def schedules(self) -> AsyncSchedulesResource:
        """Get the schedules resource client."""
        if self._schedules is None:
            self._schedules = AsyncSchedulesResource(self._http)
        return self._schedules

    @property
    def url_groups(self) -> AsyncUrlGroupsResource:
        """Get the URL groups resource client."""
        if self._url_groups is None:
            self._url_groups = AsyncUrlGroupsResource(self._http)
        return self._url_groups

    @property
    def queues(self) -> AsyncQueuesResource:
        """Get the queues resource client."""
        if self._queues is None:
            self._queues = AsyncQueuesResource(self._http)
        return self._queues

    @property
    def dlq(self) -> AsyncDlqResource:
        """Get the DLQ (dead letter queue) resource client."""
        if self._dlq is None:
            self._dlq = AsyncDlqResource(self._http)
        return self._dlq

    @property
    def analytics(self) -> AsyncAnalyticsResource:
        """Get the analytics resource client."""
        if self._analytics is None:
            self._analytics = AsyncAnalyticsResource(self._http)
        return self._analytics

    @property
    def workflows(self) -> AsyncWorkflowsResource:
        """Get the workflows resource client."""
        if self._workflows is None:
            self._workflows = AsyncWorkflowsResource(self._http)
        return self._workflows

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> "AsyncClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager."""
        await self.close()

    @staticmethod
    def verify_webhook_signature(
        payload: str,
        signature_header: str,
        secret: str,
        tolerance_seconds: int = 300,
    ) -> WebhookVerificationResult:
        """Verify a webhook signature.

        Args:
            payload: The raw request body.
            signature_header: The signature header value (x-anlyon-signature).
            secret: The signing secret.
            tolerance_seconds: Maximum allowed timestamp difference.

        Returns:
            Verification result with valid status and optional error.
        """
        return verify_webhook_signature(
            payload=payload,
            signature_header=signature_header,
            secret=secret,
            tolerance_seconds=tolerance_seconds,
        )
