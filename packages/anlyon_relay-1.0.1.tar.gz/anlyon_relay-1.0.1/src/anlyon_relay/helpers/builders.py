"""Builder classes for fluent API construction."""

from __future__ import annotations

import time
from datetime import datetime
from typing import TYPE_CHECKING, Any, Union

from ..types.api import CreateScheduleRequest, PublishMessageRequest, PublishResult, Schedule
from ..types.enums import HttpMethod
from ..types.responses import ApiResponse

if TYPE_CHECKING:
    from ..resources.messages import AsyncMessagesResource, MessagesResource
    from ..resources.schedules import AsyncSchedulesResource, SchedulesResource


class PublishMessageBuilder:
    """Fluent builder for publishing messages."""

    def __init__(
        self,
        resource: Union["MessagesResource", "AsyncMessagesResource"],
    ) -> None:
        """Initialize the builder.

        Args:
            resource: Messages resource client.
        """
        self._resource = resource
        self._url: str | None = None
        self._method: HttpMethod = HttpMethod.POST
        self._headers: dict[str, str] = {}
        self._body: Any = None
        self._queue: str | None = None
        self._execute_at: int | None = None
        self._scheduled_for: str | None = None
        self._max_retries: int = 3
        self._content_id: str | None = None
        self._callback_url: str | None = None
        self._failure_callback_url: str | None = None

    def to(self, url: str) -> "PublishMessageBuilder":
        """Set the destination URL.

        Args:
            url: Destination URL.

        Returns:
            Self for chaining.
        """
        self._url = url
        return self

    def url(self, url: str) -> "PublishMessageBuilder":
        """Set the destination URL (alias for to()).

        Args:
            url: Destination URL.

        Returns:
            Self for chaining.
        """
        return self.to(url)

    def method(self, method: HttpMethod | str) -> "PublishMessageBuilder":
        """Set the HTTP method.

        Args:
            method: HTTP method.

        Returns:
            Self for chaining.
        """
        if isinstance(method, str):
            method = HttpMethod(method.upper())
        self._method = method
        return self

    def headers(self, headers: dict[str, str]) -> "PublishMessageBuilder":
        """Set all headers.

        Args:
            headers: Headers dictionary.

        Returns:
            Self for chaining.
        """
        self._headers = headers
        return self

    def header(self, key: str, value: str) -> "PublishMessageBuilder":
        """Add a single header.

        Args:
            key: Header name.
            value: Header value.

        Returns:
            Self for chaining.
        """
        self._headers[key] = value
        return self

    def body(self, body: Any) -> "PublishMessageBuilder":
        """Set the request body.

        Args:
            body: Request body.

        Returns:
            Self for chaining.
        """
        self._body = body
        return self

    def payload(self, payload: Any) -> "PublishMessageBuilder":
        """Set the request body (alias for body()).

        Args:
            payload: Request body.

        Returns:
            Self for chaining.
        """
        return self.body(payload)

    def execute_at(self, timestamp: int) -> "PublishMessageBuilder":
        """Schedule execution at a specific Unix timestamp.

        Args:
            timestamp: Unix timestamp in seconds.

        Returns:
            Self for chaining.
        """
        self._execute_at = timestamp
        self._scheduled_for = None
        return self

    def in_seconds(self, seconds: int) -> "PublishMessageBuilder":
        """Schedule execution after a delay.

        Args:
            seconds: Delay in seconds.

        Returns:
            Self for chaining.
        """
        self._execute_at = int(time.time()) + seconds
        self._scheduled_for = None
        return self

    def in_minutes(self, minutes: int) -> "PublishMessageBuilder":
        """Schedule execution after a delay in minutes.

        Args:
            minutes: Delay in minutes.

        Returns:
            Self for chaining.
        """
        return self.in_seconds(minutes * 60)

    def in_hours(self, hours: int) -> "PublishMessageBuilder":
        """Schedule execution after a delay in hours.

        Args:
            hours: Delay in hours.

        Returns:
            Self for chaining.
        """
        return self.in_seconds(hours * 3600)

    def schedule_for(self, date: datetime | str) -> "PublishMessageBuilder":
        """Schedule execution at a specific date/time.

        Args:
            date: Date/time as datetime or ISO 8601 string.

        Returns:
            Self for chaining.
        """
        if isinstance(date, datetime):
            self._scheduled_for = date.isoformat()
        else:
            self._scheduled_for = date
        self._execute_at = None
        return self

    def at(self, date: datetime | str) -> "PublishMessageBuilder":
        """Schedule execution at a specific date/time (alias).

        Args:
            date: Date/time as datetime or ISO 8601 string.

        Returns:
            Self for chaining.
        """
        return self.schedule_for(date)

    def max_retries(self, count: int) -> "PublishMessageBuilder":
        """Set maximum retry count.

        Args:
            count: Maximum retries (0-10).

        Returns:
            Self for chaining.
        """
        self._max_retries = count
        return self

    def no_retries(self) -> "PublishMessageBuilder":
        """Disable retries.

        Returns:
            Self for chaining.
        """
        self._max_retries = 0
        return self

    def content_id(self, id: str) -> "PublishMessageBuilder":
        """Set content ID for deduplication.

        Args:
            id: Content ID.

        Returns:
            Self for chaining.
        """
        self._content_id = id
        return self

    def idempotency_key(self, key: str) -> "PublishMessageBuilder":
        """Set idempotency key (alias for content_id).

        Args:
            key: Idempotency key.

        Returns:
            Self for chaining.
        """
        return self.content_id(key)

    def callback_url(self, url: str) -> "PublishMessageBuilder":
        """Set delivery callback URL.

        Args:
            url: Callback URL.

        Returns:
            Self for chaining.
        """
        self._callback_url = url
        return self

    def on_delivery(self, url: str) -> "PublishMessageBuilder":
        """Set delivery callback URL (alias).

        Args:
            url: Callback URL.

        Returns:
            Self for chaining.
        """
        return self.callback_url(url)

    def failure_callback_url(self, url: str) -> "PublishMessageBuilder":
        """Set failure callback URL.

        Args:
            url: Failure callback URL.

        Returns:
            Self for chaining.
        """
        self._failure_callback_url = url
        return self

    def on_failure(self, url: str) -> "PublishMessageBuilder":
        """Set failure callback URL (alias).

        Args:
            url: Failure callback URL.

        Returns:
            Self for chaining.
        """
        return self.failure_callback_url(url)

    def queue(self, name: str) -> "PublishMessageBuilder":
        """Set the target queue.

        Args:
            name: Queue name.

        Returns:
            Self for chaining.
        """
        self._queue = name
        return self

    def to_queue(self, name: str) -> "PublishMessageBuilder":
        """Set the target queue (alias).

        Args:
            name: Queue name.

        Returns:
            Self for chaining.
        """
        return self.queue(name)

    def build(self) -> PublishMessageRequest:
        """Build the publish message request.

        Returns:
            Configured PublishMessageRequest.

        Raises:
            ValueError: If URL is not set.
        """
        if not self._url:
            raise ValueError("URL is required. Use .to(url) or .url(url) to set it.")

        return PublishMessageRequest(
            url=self._url,
            method=self._method,
            headers=self._headers if self._headers else None,
            body=self._body,
            queue=self._queue,
            execute_at=self._execute_at,
            scheduled_for=self._scheduled_for,
            max_retries=self._max_retries,
            content_id=self._content_id,
            callback_url=self._callback_url,
            failure_callback_url=self._failure_callback_url,
        )

    def send(self) -> ApiResponse[PublishResult]:
        """Build and send the message (sync).

        Returns:
            API response with publish result.
        """
        from ..resources.messages import MessagesResource

        if not isinstance(self._resource, MessagesResource):
            raise TypeError("Use send_async() for async resources")
        return self._resource.publish(self.build())

    async def send_async(self) -> ApiResponse[PublishResult]:
        """Build and send the message (async).

        Returns:
            API response with publish result.
        """
        from ..resources.messages import AsyncMessagesResource

        if not isinstance(self._resource, AsyncMessagesResource):
            raise TypeError("Use send() for sync resources")
        return await self._resource.publish(self.build())


class ScheduleBuilder:
    """Fluent builder for creating schedules."""

    def __init__(
        self,
        resource: Union["SchedulesResource", "AsyncSchedulesResource"],
    ) -> None:
        """Initialize the builder.

        Args:
            resource: Schedules resource client.
        """
        self._resource = resource
        self._name: str | None = None
        self._cron_expression: str | None = None
        self._timezone: str = "UTC"
        self._url: str | None = None
        self._method: HttpMethod = HttpMethod.POST
        self._headers: dict[str, str] = {}
        self._body: Any = None

    def name(self, name: str) -> "ScheduleBuilder":
        """Set the schedule name.

        Args:
            name: Schedule name.

        Returns:
            Self for chaining.
        """
        self._name = name
        return self

    def cron(self, expression: str) -> "ScheduleBuilder":
        """Set the cron expression.

        Args:
            expression: Cron expression.

        Returns:
            Self for chaining.
        """
        self._cron_expression = expression
        return self

    def timezone(self, tz: str) -> "ScheduleBuilder":
        """Set the timezone.

        Args:
            tz: IANA timezone name.

        Returns:
            Self for chaining.
        """
        self._timezone = tz
        return self

    def to(self, url: str) -> "ScheduleBuilder":
        """Set the destination URL.

        Args:
            url: Destination URL.

        Returns:
            Self for chaining.
        """
        self._url = url
        return self

    def url(self, url: str) -> "ScheduleBuilder":
        """Set the destination URL (alias).

        Args:
            url: Destination URL.

        Returns:
            Self for chaining.
        """
        return self.to(url)

    def method(self, method: HttpMethod | str) -> "ScheduleBuilder":
        """Set the HTTP method.

        Args:
            method: HTTP method.

        Returns:
            Self for chaining.
        """
        if isinstance(method, str):
            method = HttpMethod(method.upper())
        self._method = method
        return self

    def headers(self, headers: dict[str, str]) -> "ScheduleBuilder":
        """Set all headers.

        Args:
            headers: Headers dictionary.

        Returns:
            Self for chaining.
        """
        self._headers = headers
        return self

    def header(self, key: str, value: str) -> "ScheduleBuilder":
        """Add a single header.

        Args:
            key: Header name.
            value: Header value.

        Returns:
            Self for chaining.
        """
        self._headers[key] = value
        return self

    def body(self, body: Any) -> "ScheduleBuilder":
        """Set the request body.

        Args:
            body: Request body.

        Returns:
            Self for chaining.
        """
        self._body = body
        return self

    # Preset schedules
    def every_minute(self) -> "ScheduleBuilder":
        """Set to run every minute.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "* * * * *"
        return self

    def every_5_minutes(self) -> "ScheduleBuilder":
        """Set to run every 5 minutes.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "*/5 * * * *"
        return self

    def every_15_minutes(self) -> "ScheduleBuilder":
        """Set to run every 15 minutes.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "*/15 * * * *"
        return self

    def every_30_minutes(self) -> "ScheduleBuilder":
        """Set to run every 30 minutes.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "*/30 * * * *"
        return self

    def hourly(self) -> "ScheduleBuilder":
        """Set to run every hour.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "0 * * * *"
        return self

    def daily(self) -> "ScheduleBuilder":
        """Set to run daily at midnight.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "0 0 * * *"
        return self

    def daily_at(self, hour: int) -> "ScheduleBuilder":
        """Set to run daily at a specific hour.

        Args:
            hour: Hour (0-23).

        Returns:
            Self for chaining.
        """
        self._cron_expression = f"0 {hour} * * *"
        return self

    def weekly(self) -> "ScheduleBuilder":
        """Set to run weekly on Sunday.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "0 0 * * 0"
        return self

    def monthly(self) -> "ScheduleBuilder":
        """Set to run monthly on the 1st.

        Returns:
            Self for chaining.
        """
        self._cron_expression = "0 0 1 * *"
        return self

    def build(self) -> CreateScheduleRequest:
        """Build the create schedule request.

        Returns:
            Configured CreateScheduleRequest.

        Raises:
            ValueError: If required fields are not set.
        """
        if not self._name:
            raise ValueError("Name is required. Use .name(name) to set it.")
        if not self._cron_expression:
            raise ValueError("Cron expression is required. Use .cron(expression) to set it.")
        if not self._url:
            raise ValueError("URL is required. Use .to(url) or .url(url) to set it.")

        return CreateScheduleRequest(
            name=self._name,
            cron_expression=self._cron_expression,
            timezone=self._timezone,
            url=self._url,
            method=self._method,
            headers=self._headers if self._headers else None,
            body=self._body,
        )

    def create(self) -> ApiResponse[Schedule]:
        """Build and create the schedule (sync).

        Returns:
            API response with created schedule.
        """
        from ..resources.schedules import SchedulesResource

        if not isinstance(self._resource, SchedulesResource):
            raise TypeError("Use create_async() for async resources")
        return self._resource.create(self.build())

    async def create_async(self) -> ApiResponse[Schedule]:
        """Build and create the schedule (async).

        Returns:
            API response with created schedule.
        """
        from ..resources.schedules import AsyncSchedulesResource

        if not isinstance(self._resource, AsyncSchedulesResource):
            raise TypeError("Use create() for sync resources")
        return await self._resource.create(self.build())
