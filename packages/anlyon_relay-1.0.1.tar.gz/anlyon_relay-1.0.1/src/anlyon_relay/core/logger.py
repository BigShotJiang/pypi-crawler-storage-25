"""Logger implementation for the Anlyon Relay SDK."""

from __future__ import annotations

import logging
import re
from datetime import datetime
from typing import Any

from ..types.enums import LogLevel

# Keys to redact from logs
SENSITIVE_KEYS = frozenset(
    {
        "apikey",
        "api_key",
        "api-key",
        "authorization",
        "x-api-key",
        "password",
        "secret",
        "token",
        "bearer",
        "credential",
        "credentials",
        "private_key",
        "private-key",
        "access_token",
        "access-token",
        "refresh_token",
        "refresh-token",
    }
)

REDACTED_VALUE = "[REDACTED]"


def _should_redact(key: str) -> bool:
    """Check if a key should be redacted."""
    return key.lower() in SENSITIVE_KEYS


def _redact_value(obj: Any, redact_sensitive: bool = True) -> Any:
    """Recursively redact sensitive values from an object.

    Args:
        obj: The object to redact.
        redact_sensitive: Whether to actually perform redaction.

    Returns:
        A copy of the object with sensitive values redacted.
    """
    if not redact_sensitive:
        return obj

    if isinstance(obj, dict):
        return {
            key: REDACTED_VALUE if _should_redact(key) else _redact_value(value, redact_sensitive)
            for key, value in obj.items()
        }
    elif isinstance(obj, list):
        return [_redact_value(item, redact_sensitive) for item in obj]
    elif isinstance(obj, str):
        # Check for Bearer tokens in strings
        if re.search(r"Bearer\s+\S+", obj, re.IGNORECASE):
            return re.sub(r"(Bearer\s+)\S+", r"\1[REDACTED]", obj, flags=re.IGNORECASE)
        return obj
    else:
        return obj


class Logger:
    """Logger with support for log levels and sensitive data redaction."""

    _LOG_LEVEL_MAP = {
        LogLevel.DEBUG: logging.DEBUG,
        LogLevel.INFO: logging.INFO,
        LogLevel.WARN: logging.WARNING,
        LogLevel.ERROR: logging.ERROR,
    }

    def __init__(
        self,
        name: str = "anlyon_relay",
        level: LogLevel = LogLevel.INFO,
        redact_sensitive: bool = True,
    ) -> None:
        """Initialize the logger.

        Args:
            name: Logger name.
            level: Minimum log level.
            redact_sensitive: Whether to redact sensitive information.
        """
        self._level = level
        self._redact_sensitive = redact_sensitive

        # Set up Python logger
        self._logger = logging.getLogger(name)
        self._logger.setLevel(self._LOG_LEVEL_MAP.get(level, logging.INFO))

        # Add handler if none exists
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                fmt="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
                datefmt="%Y-%m-%dT%H:%M:%S",
            )
            handler.setFormatter(formatter)
            self._logger.addHandler(handler)

    def _should_log(self, level: LogLevel) -> bool:
        """Check if a message at the given level should be logged."""
        level_order = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR]
        return level_order.index(level) >= level_order.index(self._level)

    def _format_meta(self, meta: dict[str, Any] | None) -> str:
        """Format metadata for logging."""
        if not meta:
            return ""
        redacted = _redact_value(meta, self._redact_sensitive)
        return f" {redacted}"

    def debug(self, message: str, **kwargs: Any) -> None:
        """Log a debug message.

        Args:
            message: The message to log.
            **kwargs: Additional metadata to include.
        """
        if self._should_log(LogLevel.DEBUG):
            self._logger.debug(f"{message}{self._format_meta(kwargs)}")

    def info(self, message: str, **kwargs: Any) -> None:
        """Log an info message.

        Args:
            message: The message to log.
            **kwargs: Additional metadata to include.
        """
        if self._should_log(LogLevel.INFO):
            self._logger.info(f"{message}{self._format_meta(kwargs)}")

    def warn(self, message: str, **kwargs: Any) -> None:
        """Log a warning message.

        Args:
            message: The message to log.
            **kwargs: Additional metadata to include.
        """
        if self._should_log(LogLevel.WARN):
            self._logger.warning(f"{message}{self._format_meta(kwargs)}")

    def error(self, message: str, **kwargs: Any) -> None:
        """Log an error message.

        Args:
            message: The message to log.
            **kwargs: Additional metadata to include.
        """
        if self._should_log(LogLevel.ERROR):
            self._logger.error(f"{message}{self._format_meta(kwargs)}")


class NoopLogger:
    """A logger that does nothing."""

    def debug(self, message: str, **kwargs: Any) -> None:
        """No-op debug."""
        pass

    def info(self, message: str, **kwargs: Any) -> None:
        """No-op info."""
        pass

    def warn(self, message: str, **kwargs: Any) -> None:
        """No-op warn."""
        pass

    def error(self, message: str, **kwargs: Any) -> None:
        """No-op error."""
        pass


def create_logger(
    enabled: bool = False,
    level: LogLevel = LogLevel.INFO,
    redact_sensitive: bool = True,
    custom_logger: Any | None = None,
) -> Logger | NoopLogger | Any:
    """Create a logger instance.

    Args:
        enabled: Whether logging is enabled.
        level: Minimum log level.
        redact_sensitive: Whether to redact sensitive information.
        custom_logger: A custom logger implementation to use.

    Returns:
        A logger instance.
    """
    if custom_logger is not None:
        return custom_logger

    if not enabled:
        return NoopLogger()

    return Logger(level=level, redact_sensitive=redact_sensitive)
