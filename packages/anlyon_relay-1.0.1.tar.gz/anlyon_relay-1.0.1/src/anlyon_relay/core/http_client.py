"""HTTP client implementation for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any, TypeVar
from urllib.parse import urlencode, urljoin

import httpx

from ..types.config import ClientConfig, RequestOptions
from .errors import (
    AnlyonError,
    NetworkError,
    ParseError,
    TimeoutError,
    create_error_from_response,
)
from .logger import NoopLogger, create_logger
from .retry import AsyncRetryHandler, RetryHandler

T = TypeVar("T")


class HttpClient:
    """Synchronous HTTP client for the Anlyon Relay SDK."""

    def __init__(self, config: ClientConfig) -> None:
        """Initialize the HTTP client.

        Args:
            config: Client configuration.
        """
        self._config = config
        self._base_url = config.base_url.rstrip("/")
        self._logger = create_logger(
            enabled=config.logging.enabled,
            level=config.logging.level,
            redact_sensitive=config.logging.redact_sensitive,
            custom_logger=config.logging.logger,
        )
        self._retry_handler = RetryHandler(config.retry)
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(timeout=self._config.timeout)
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "HttpClient":
        """Enter context manager."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context manager."""
        self.close()

    def _build_url(self, path: str, params: dict[str, Any] | None = None) -> str:
        """Build a full URL with path and query parameters.

        Args:
            path: The API path.
            params: Query parameters.

        Returns:
            The full URL.
        """
        # Ensure path starts with /
        if not path.startswith("/"):
            path = "/" + path

        url = f"{self._base_url}{path}"

        if params:
            # Filter out None values and convert to strings
            filtered_params = {
                k: str(v) if not isinstance(v, bool) else str(v).lower()
                for k, v in params.items()
                if v is not None
            }
            if filtered_params:
                url = f"{url}?{urlencode(filtered_params)}"

        return url

    def _build_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        """Build request headers.

        Args:
            extra_headers: Additional headers to include.

        Returns:
            Combined headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {self._config.api_key}",
            **self._config.default_headers,
        }

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def _parse_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse the response body.

        Args:
            response: The HTTP response.

        Returns:
            Parsed JSON response.

        Raises:
            ParseError: If the response cannot be parsed.
        """
        if not response.content:
            return {}

        content_type = response.headers.get("content-type", "")

        if "application/json" in content_type:
            try:
                return response.json()
            except Exception as e:
                raise ParseError(
                    message=f"Failed to parse JSON response: {e}",
                    details={"raw_content": response.text[:500]},
                )
        else:
            # Return text response wrapped in a message
            return {"message": response.text}

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle the HTTP response.

        Args:
            response: The HTTP response.

        Returns:
            Parsed response data.

        Raises:
            AnlyonError: If the response indicates an error.
        """
        request_id = response.headers.get("x-request-id")

        # Parse response body
        data = self._parse_response(response)

        # Check for error status
        if response.status_code >= 400:
            retry_after = None
            if response.status_code == 429:
                retry_after_header = response.headers.get("retry-after")
                if retry_after_header:
                    try:
                        retry_after = int(retry_after_header)
                    except ValueError:
                        pass

            raise create_error_from_response(
                status=response.status_code,
                response_data=data,
                request_id=request_id,
                retry_after=retry_after,
            )

        return data

    def request(
        self,
        method: str,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP request.

        Args:
            method: HTTP method.
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        options = options or RequestOptions()
        url = self._build_url(path, options.params)
        headers = self._build_headers(options.headers)
        timeout = options.timeout or self._config.timeout

        self._logger.debug(
            f"Request: {method} {path}",
            method=method,
            url=url,
            body=body,
        )

        def make_request() -> dict[str, Any]:
            try:
                response = self._get_client().request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=body if body is not None else None,
                    timeout=timeout,
                )
                return self._handle_response(response)
            except httpx.TimeoutException as e:
                raise TimeoutError(
                    message=f"Request timed out after {timeout}s",
                    details={"url": url, "timeout": timeout},
                )
            except httpx.ConnectError as e:
                raise NetworkError(
                    message=f"Connection failed: {e}",
                    details={"url": url},
                )
            except httpx.HTTPError as e:
                raise NetworkError(
                    message=f"HTTP error: {e}",
                    details={"url": url},
                )

        result = self._retry_handler.execute(make_request)

        self._logger.debug(
            f"Response: {method} {path}",
            status="success",
            data=result,
        )

        return result

    def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a GET request.

        Args:
            path: API path.
            params: Query parameters.
            options: Request options.

        Returns:
            Parsed response data.
        """
        options = options or RequestOptions()
        if params:
            options = RequestOptions(
                params={**(options.params or {}), **params},
                headers=options.headers,
                timeout=options.timeout,
            )
        return self.request("GET", path, options=options)

    def post(
        self,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a POST request.

        Args:
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return self.request("POST", path, body=body, options=options)

    def patch(
        self,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a PATCH request.

        Args:
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return self.request("PATCH", path, body=body, options=options)

    def delete(
        self,
        path: str,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request.

        Args:
            path: API path.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return self.request("DELETE", path, options=options)


class AsyncHttpClient:
    """Asynchronous HTTP client for the Anlyon Relay SDK."""

    def __init__(self, config: ClientConfig) -> None:
        """Initialize the async HTTP client.

        Args:
            config: Client configuration.
        """
        self._config = config
        self._base_url = config.base_url.rstrip("/")
        self._logger = create_logger(
            enabled=config.logging.enabled,
            level=config.logging.level,
            redact_sensitive=config.logging.redact_sensitive,
            custom_logger=config.logging.logger,
        )
        self._retry_handler = AsyncRetryHandler(config.retry)
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._config.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "AsyncHttpClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager."""
        await self.close()

    def _build_url(self, path: str, params: dict[str, Any] | None = None) -> str:
        """Build a full URL with path and query parameters.

        Args:
            path: The API path.
            params: Query parameters.

        Returns:
            The full URL.
        """
        # Ensure path starts with /
        if not path.startswith("/"):
            path = "/" + path

        url = f"{self._base_url}{path}"

        if params:
            # Filter out None values and convert to strings
            filtered_params = {
                k: str(v) if not isinstance(v, bool) else str(v).lower()
                for k, v in params.items()
                if v is not None
            }
            if filtered_params:
                url = f"{url}?{urlencode(filtered_params)}"

        return url

    def _build_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        """Build request headers.

        Args:
            extra_headers: Additional headers to include.

        Returns:
            Combined headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {self._config.api_key}",
            **self._config.default_headers,
        }

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def _parse_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse the response body.

        Args:
            response: The HTTP response.

        Returns:
            Parsed JSON response.

        Raises:
            ParseError: If the response cannot be parsed.
        """
        if not response.content:
            return {}

        content_type = response.headers.get("content-type", "")

        if "application/json" in content_type:
            try:
                return response.json()
            except Exception as e:
                raise ParseError(
                    message=f"Failed to parse JSON response: {e}",
                    details={"raw_content": response.text[:500]},
                )
        else:
            # Return text response wrapped in a message
            return {"message": response.text}

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle the HTTP response.

        Args:
            response: The HTTP response.

        Returns:
            Parsed response data.

        Raises:
            AnlyonError: If the response indicates an error.
        """
        request_id = response.headers.get("x-request-id")

        # Parse response body
        data = self._parse_response(response)

        # Check for error status
        if response.status_code >= 400:
            retry_after = None
            if response.status_code == 429:
                retry_after_header = response.headers.get("retry-after")
                if retry_after_header:
                    try:
                        retry_after = int(retry_after_header)
                    except ValueError:
                        pass

            raise create_error_from_response(
                status=response.status_code,
                response_data=data,
                request_id=request_id,
                retry_after=retry_after,
            )

        return data

    async def request(
        self,
        method: str,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP request.

        Args:
            method: HTTP method.
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        options = options or RequestOptions()
        url = self._build_url(path, options.params)
        headers = self._build_headers(options.headers)
        timeout = options.timeout or self._config.timeout

        self._logger.debug(
            f"Request: {method} {path}",
            method=method,
            url=url,
            body=body,
        )

        async def make_request() -> dict[str, Any]:
            try:
                client = await self._get_client()
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=body if body is not None else None,
                    timeout=timeout,
                )
                return self._handle_response(response)
            except httpx.TimeoutException as e:
                raise TimeoutError(
                    message=f"Request timed out after {timeout}s",
                    details={"url": url, "timeout": timeout},
                )
            except httpx.ConnectError as e:
                raise NetworkError(
                    message=f"Connection failed: {e}",
                    details={"url": url},
                )
            except httpx.HTTPError as e:
                raise NetworkError(
                    message=f"HTTP error: {e}",
                    details={"url": url},
                )

        result = await self._retry_handler.execute(make_request)

        self._logger.debug(
            f"Response: {method} {path}",
            status="success",
            data=result,
        )

        return result

    async def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a GET request.

        Args:
            path: API path.
            params: Query parameters.
            options: Request options.

        Returns:
            Parsed response data.
        """
        options = options or RequestOptions()
        if params:
            options = RequestOptions(
                params={**(options.params or {}), **params},
                headers=options.headers,
                timeout=options.timeout,
            )
        return await self.request("GET", path, options=options)

    async def post(
        self,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a POST request.

        Args:
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return await self.request("POST", path, body=body, options=options)

    async def patch(
        self,
        path: str,
        body: Any | None = None,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a PATCH request.

        Args:
            path: API path.
            body: Request body.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return await self.request("PATCH", path, body=body, options=options)

    async def delete(
        self,
        path: str,
        options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request.

        Args:
            path: API path.
            options: Request options.

        Returns:
            Parsed response data.
        """
        return await self.request("DELETE", path, options=options)
