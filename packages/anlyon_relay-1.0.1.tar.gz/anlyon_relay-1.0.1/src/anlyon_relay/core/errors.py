"""Error classes for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any

from ..types.enums import ErrorCode


class AnlyonError(Exception):
    """Base exception for all Anlyon SDK errors."""

    def __init__(
        self,
        message: str,
        code: ErrorCode = ErrorCode.UNKNOWN_ERROR,
        status: int | None = None,
        details: Any | None = None,
        request_id: str | None = None,
        retry_after: int | None = None,
    ) -> None:
        """Initialize the error.

        Args:
            message: Human-readable error message.
            code: Error code from the API.
            status: HTTP status code.
            details: Additional error details.
            request_id: Request ID for debugging.
            retry_after: Seconds to wait before retrying (for rate limits).
        """
        super().__init__(message)
        self.message = message
        self.code = code
        self.status = status
        self.details = details
        self.request_id = request_id
        self.retry_after = retry_after

    @property
    def is_retryable(self) -> bool:
        """Whether this error can be retried."""
        return self.code in (
            ErrorCode.RATE_LIMIT_EXCEEDED,
            ErrorCode.NETWORK_ERROR,
            ErrorCode.TIMEOUT_ERROR,
        ) or (self.status is not None and self.status >= 500)

    @property
    def is_auth_error(self) -> bool:
        """Whether this is an authentication error."""
        return self.code in (ErrorCode.AUTHENTICATION_FAILED, ErrorCode.AUTHORIZATION_ERROR)

    @property
    def is_validation_error(self) -> bool:
        """Whether this is a validation error."""
        return self.code == ErrorCode.VALIDATION_ERROR

    @property
    def is_not_found(self) -> bool:
        """Whether the resource was not found."""
        return self.code == ErrorCode.NOT_FOUND

    def to_dict(self) -> dict[str, Any]:
        """Convert error to a dictionary."""
        return {
            "message": self.message,
            "code": self.code.value,
            "status": self.status,
            "details": self.details,
            "request_id": self.request_id,
            "retry_after": self.retry_after,
        }

    def __repr__(self) -> str:
        """Return a string representation of the error."""
        parts = [f"AnlyonError(code={self.code.value!r}, message={self.message!r}"]
        if self.status:
            parts.append(f", status={self.status}")
        if self.request_id:
            parts.append(f", request_id={self.request_id!r}")
        parts.append(")")
        return "".join(parts)


class AuthenticationError(AnlyonError):
    """Raised when authentication fails (401)."""

    def __init__(
        self,
        message: str = "Authentication failed",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.AUTHENTICATION_FAILED,
            status=401,
            details=details,
            request_id=request_id,
        )


class AuthorizationError(AnlyonError):
    """Raised when authorization fails (403)."""

    def __init__(
        self,
        message: str = "Authorization failed",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.AUTHORIZATION_ERROR,
            status=403,
            details=details,
            request_id=request_id,
        )


class RateLimitError(AnlyonError):
    """Raised when rate limit is exceeded (429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: int | None = None,
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.RATE_LIMIT_EXCEEDED,
            status=429,
            details=details,
            request_id=request_id,
            retry_after=retry_after,
        )


class QuotaExceededError(AnlyonError):
    """Raised when quota is exceeded (402)."""

    def __init__(
        self,
        message: str = "Quota exceeded",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.QUOTA_EXCEEDED,
            status=402,
            details=details,
            request_id=request_id,
        )


class ValidationError(AnlyonError):
    """Raised when request validation fails (400)."""

    def __init__(
        self,
        message: str = "Validation failed",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.VALIDATION_ERROR,
            status=400,
            details=details,
            request_id=request_id,
        )


class NotFoundError(AnlyonError):
    """Raised when a resource is not found (404)."""

    def __init__(
        self,
        message: str = "Resource not found",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.NOT_FOUND,
            status=404,
            details=details,
            request_id=request_id,
        )


class FeatureNotAvailableError(AnlyonError):
    """Raised when a feature is not available (402)."""

    def __init__(
        self,
        message: str = "Feature not available on your plan",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.FEATURE_NOT_AVAILABLE,
            status=402,
            details=details,
            request_id=request_id,
        )


class ConflictError(AnlyonError):
    """Raised when there is a conflict (409)."""

    def __init__(
        self,
        message: str = "Conflict error",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.CONFLICT_ERROR,
            status=409,
            details=details,
            request_id=request_id,
        )


class NetworkError(AnlyonError):
    """Raised when there is a network error."""

    def __init__(
        self,
        message: str = "Network error",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.NETWORK_ERROR,
            details=details,
            request_id=request_id,
        )


class TimeoutError(AnlyonError):
    """Raised when a request times out."""

    def __init__(
        self,
        message: str = "Request timed out",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.TIMEOUT_ERROR,
            details=details,
            request_id=request_id,
        )


class ParseError(AnlyonError):
    """Raised when response parsing fails."""

    def __init__(
        self,
        message: str = "Failed to parse response",
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ErrorCode.PARSE_ERROR,
            details=details,
            request_id=request_id,
        )


def create_error_from_response(
    status: int,
    response_data: dict[str, Any] | None = None,
    request_id: str | None = None,
    retry_after: int | None = None,
) -> AnlyonError:
    """Create an appropriate error from an HTTP response.

    Args:
        status: HTTP status code.
        response_data: Parsed response body.
        request_id: Request ID from headers.
        retry_after: Retry-After header value.

    Returns:
        An appropriate AnlyonError subclass instance.
    """
    error_data = response_data.get("error", {}) if response_data else {}
    code_str = error_data.get("code", "")
    message = error_data.get("message", f"Request failed with status {status}")
    details = error_data.get("details")

    # Map error codes to specific error classes
    error_mapping: dict[str, type[AnlyonError]] = {
        ErrorCode.AUTHENTICATION_FAILED.value: AuthenticationError,
        ErrorCode.AUTHORIZATION_ERROR.value: AuthorizationError,
        ErrorCode.RATE_LIMIT_EXCEEDED.value: RateLimitError,
        ErrorCode.QUOTA_EXCEEDED.value: QuotaExceededError,
        ErrorCode.VALIDATION_ERROR.value: ValidationError,
        ErrorCode.NOT_FOUND.value: NotFoundError,
        ErrorCode.FEATURE_NOT_AVAILABLE.value: FeatureNotAvailableError,
        ErrorCode.CONFLICT_ERROR.value: ConflictError,
    }

    # Try to match by error code first
    if code_str in error_mapping:
        error_class = error_mapping[code_str]
        if error_class == RateLimitError:
            return RateLimitError(
                message=message,
                retry_after=retry_after,
                details=details,
                request_id=request_id,
            )
        return error_class(message=message, details=details, request_id=request_id)

    # Fall back to status code mapping
    status_mapping: dict[int, type[AnlyonError]] = {
        400: ValidationError,
        401: AuthenticationError,
        402: QuotaExceededError,
        403: AuthorizationError,
        404: NotFoundError,
        409: ConflictError,
        429: RateLimitError,
    }

    if status in status_mapping:
        error_class = status_mapping[status]
        if error_class == RateLimitError:
            return RateLimitError(
                message=message,
                retry_after=retry_after,
                details=details,
                request_id=request_id,
            )
        return error_class(message=message, details=details, request_id=request_id)

    # Try to parse the error code
    try:
        error_code = ErrorCode(code_str) if code_str else ErrorCode.UNKNOWN_ERROR
    except ValueError:
        error_code = ErrorCode.UNKNOWN_ERROR

    return AnlyonError(
        message=message,
        code=error_code,
        status=status,
        details=details,
        request_id=request_id,
        retry_after=retry_after,
    )
