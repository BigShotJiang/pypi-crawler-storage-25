"""Retry logic for the Anlyon Relay SDK."""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, TypeVar

from ..types.config import RetryConfig
from .errors import AnlyonError, RateLimitError

T = TypeVar("T")


@dataclass
class RetryContext:
    """Context information for a retry attempt."""

    attempt: int
    max_attempts: int
    delay: float
    error: Exception


RetryCallback = Callable[[RetryContext], None]
AsyncRetryCallback = Callable[[RetryContext], Awaitable[None]]


class RetryHandler:
    """Handles retry logic with exponential backoff and jitter."""

    def __init__(self, config: RetryConfig | None = None) -> None:
        """Initialize the retry handler.

        Args:
            config: Retry configuration. Uses defaults if not provided.
        """
        self._config = config or RetryConfig()
        self._on_retry: RetryCallback | None = None

    def set_on_retry(self, callback: RetryCallback) -> None:
        """Set a callback to be called before each retry.

        Args:
            callback: Function to call with retry context.
        """
        self._on_retry = callback

    def _calculate_delay(self, attempt: int, retry_after: int | None = None) -> float:
        """Calculate the delay before the next retry.

        Args:
            attempt: Current attempt number (1-indexed).
            retry_after: Retry-After header value in seconds.

        Returns:
            Delay in seconds.
        """
        # If we have a Retry-After header, use it
        if retry_after is not None and retry_after > 0:
            return float(retry_after)

        # Calculate exponential backoff
        delay = self._config.initial_delay * (self._config.backoff_multiplier ** (attempt - 1))

        # Cap at max delay
        delay = min(delay, self._config.max_delay)

        # Apply full jitter if enabled (random delay between 0 and calculated delay)
        if self._config.jitter:
            delay = random.uniform(0, delay)

        return delay

    def _should_retry(self, error: Exception, attempt: int) -> bool:
        """Determine if the operation should be retried.

        Args:
            error: The error that occurred.
            attempt: Current attempt number.

        Returns:
            True if the operation should be retried.
        """
        if attempt >= self._config.max_attempts:
            return False

        # Check custom retry function
        if self._config.is_retryable is not None:
            return self._config.is_retryable(error)

        # Check if it's an AnlyonError with retryable status
        if isinstance(error, AnlyonError):
            if error.status in self._config.retryable_status_codes:
                return True
            return error.is_retryable

        # For other errors (network errors, etc.), retry
        error_type = type(error).__name__.lower()
        return any(
            keyword in error_type
            for keyword in ("connection", "timeout", "network", "temporary")
        )

    def execute(self, fn: Callable[[], T]) -> T:
        """Execute a function with retry logic (sync).

        Args:
            fn: The function to execute.

        Returns:
            The function's return value.

        Raises:
            The last error if all retries are exhausted.
        """
        last_error: Exception | None = None

        for attempt in range(1, self._config.max_attempts + 1):
            try:
                return fn()
            except Exception as e:
                last_error = e

                if not self._should_retry(e, attempt):
                    raise

                # Get retry_after if available
                retry_after = None
                if isinstance(e, RateLimitError):
                    retry_after = e.retry_after

                delay = self._calculate_delay(attempt, retry_after)

                # Call retry callback if set
                if self._on_retry:
                    context = RetryContext(
                        attempt=attempt,
                        max_attempts=self._config.max_attempts,
                        delay=delay,
                        error=e,
                    )
                    self._on_retry(context)

                time.sleep(delay)

        # This should never be reached, but for type safety
        if last_error:
            raise last_error
        raise RuntimeError("Unexpected state in retry handler")


class AsyncRetryHandler:
    """Handles async retry logic with exponential backoff and jitter."""

    def __init__(self, config: RetryConfig | None = None) -> None:
        """Initialize the async retry handler.

        Args:
            config: Retry configuration. Uses defaults if not provided.
        """
        self._config = config or RetryConfig()
        self._on_retry: AsyncRetryCallback | RetryCallback | None = None

    def set_on_retry(self, callback: AsyncRetryCallback | RetryCallback) -> None:
        """Set a callback to be called before each retry.

        Args:
            callback: Function to call with retry context.
        """
        self._on_retry = callback

    def _calculate_delay(self, attempt: int, retry_after: int | None = None) -> float:
        """Calculate the delay before the next retry.

        Args:
            attempt: Current attempt number (1-indexed).
            retry_after: Retry-After header value in seconds.

        Returns:
            Delay in seconds.
        """
        # If we have a Retry-After header, use it
        if retry_after is not None and retry_after > 0:
            return float(retry_after)

        # Calculate exponential backoff
        delay = self._config.initial_delay * (self._config.backoff_multiplier ** (attempt - 1))

        # Cap at max delay
        delay = min(delay, self._config.max_delay)

        # Apply full jitter if enabled (random delay between 0 and calculated delay)
        if self._config.jitter:
            delay = random.uniform(0, delay)

        return delay

    def _should_retry(self, error: Exception, attempt: int) -> bool:
        """Determine if the operation should be retried.

        Args:
            error: The error that occurred.
            attempt: Current attempt number.

        Returns:
            True if the operation should be retried.
        """
        if attempt >= self._config.max_attempts:
            return False

        # Check custom retry function
        if self._config.is_retryable is not None:
            return self._config.is_retryable(error)

        # Check if it's an AnlyonError with retryable status
        if isinstance(error, AnlyonError):
            if error.status in self._config.retryable_status_codes:
                return True
            return error.is_retryable

        # For other errors (network errors, etc.), retry
        error_type = type(error).__name__.lower()
        return any(
            keyword in error_type
            for keyword in ("connection", "timeout", "network", "temporary")
        )

    async def execute(self, fn: Callable[[], Awaitable[T]]) -> T:
        """Execute an async function with retry logic.

        Args:
            fn: The async function to execute.

        Returns:
            The function's return value.

        Raises:
            The last error if all retries are exhausted.
        """
        last_error: Exception | None = None

        for attempt in range(1, self._config.max_attempts + 1):
            try:
                return await fn()
            except Exception as e:
                last_error = e

                if not self._should_retry(e, attempt):
                    raise

                # Get retry_after if available
                retry_after = None
                if isinstance(e, RateLimitError):
                    retry_after = e.retry_after

                delay = self._calculate_delay(attempt, retry_after)

                # Call retry callback if set
                if self._on_retry:
                    context = RetryContext(
                        attempt=attempt,
                        max_attempts=self._config.max_attempts,
                        delay=delay,
                        error=e,
                    )
                    result = self._on_retry(context)
                    if asyncio.iscoroutine(result):
                        await result

                await asyncio.sleep(delay)

        # This should never be reached, but for type safety
        if last_error:
            raise last_error
        raise RuntimeError("Unexpected state in retry handler")
