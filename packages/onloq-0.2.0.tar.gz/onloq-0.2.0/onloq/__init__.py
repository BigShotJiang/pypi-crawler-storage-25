import os
import functools
import inspect
import time
import tempfile

from . import filelock


NAMESPACE = 'onloq'
DEFAULT_LOCKS_DIR_NAME = NAMESPACE + '_locks'
LOCK_EXTENSION = 'lock'
RELEASE_LUA_SCRIPT = '''
    if redis.call("get",KEYS[1]) == ARGV[1] then
        return redis.call("del",KEYS[1])
    else
        return 0
    end
'''


class Onloq:
	def __init__(self, /, redis=None, locks_dir=None, ttl=25, on_error='raise', logger=None):
		self.redis = redis
		self.locks_dir = locks_dir
		self.ttl = ttl
		self.on_error = on_error
		self.logger = logger

		if self.redis:
			self.redis_release_script = self.redis.register_script(RELEASE_LUA_SCRIPT)
		elif not self.locks_dir:
			self.locks_dir = os.path.join(tempfile.gettempdir(), DEFAULT_LOCKS_DIR_NAME)

	def __call__(self, func=None, *, name=None, ttl=None, on_error=None):
		return self.wrap(func, name=name, ttl=ttl, on_error=on_error)

	def wrap(self, func=None, *, name=None, ttl=None, on_error=None):
		if func is None:
			return lambda f: self.wrap(f, name=name, ttl=ttl, on_error=on_error)
		
		if not callable(func):
			raise TypeError('The first argument must be a callable. All other parameters must be passed as keyword arguments.')

		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			return self.execute(func, args, kwargs, name, ttl, on_error)

		return wrapper

	def execute(self, func, args=None, kwargs=None, name=None, ttl=None, on_error=None):
		args = args or ()
		kwargs = kwargs or {}

		if name is None:
			original = inspect.unwrap(func)
			name = f"{original.__module__}.{original.__qualname__}"
		
		ttl = max(1, self.ttl if ttl is None else ttl)
		on_error = self.on_error if on_error is None else on_error
		lock = self._redis_lock if self.redis else self._file_lock

		return lock(func, args, kwargs, name, ttl, on_error)

	def _redis_lock(self, func, args, kwargs, name, ttl, on_error):
		lock_key = f'{NAMESPACE}:{name}:{LOCK_EXTENSION}'

		if not self.redis.set(lock_key, 'LOCKED', nx=True, ex=ttl):
			return

		try:
			return func(*args, **kwargs)
		except Exception as exc:
			return self._handle_error(exc, on_error, name, args, kwargs)

	def _file_lock(self, func, args, kwargs, name, ttl, on_error):
		os.makedirs(self.locks_dir, exist_ok=True)
		path = os.path.join(self.locks_dir, f'{name}.{LOCK_EXTENSION}')
		
		if ttl and os.path.exists(path):
			try:
				if time.time() - os.path.getmtime(path) < ttl:
					return
			except OSError:
				pass

		lock_file = None
		try:
			lock_file = open(path, 'a')
			filelock.lock(lock_file)
			os.utime(path, None)
		except (filelock.AlreadyLocked, Exception):
			if lock_file:
				lock_file.close()
			return
		
		try:
			return func(*args, **kwargs)
		except Exception as exc:
			return self._handle_error(exc, on_error, name, args, kwargs)
		finally:
			try:
				filelock.unlock(lock_file)
			finally:
				lock_file.close()


	def _handle_error(self, exc, on_error, lock_name, args, kwargs):
		if on_error is None:
			if self.logger:
				self.logger.error("Onloq caught an exception: %s", exc, exc_info=True)
		else:
			if on_error == "raise":
				raise exc

			elif callable(on_error):
				return on_error(lock_name, exc, *args, **kwargs)
	
