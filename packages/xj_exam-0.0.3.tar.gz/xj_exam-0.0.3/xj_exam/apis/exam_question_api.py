# encoding: utf-8
"""
@project: exam_question_api
@author:
@Email:
@synopsis: 考试题目API接口
@created_time: 2024
"""

import sys
from rest_framework.views import APIView

if 'xj_user' in sys.modules:
    from xj_user.services.user_service import UserService

from ..services.exam_question_service import ExamQuestionService
from ..utils.custom_response import util_response
from ..utils.request_params_wrapper import request_params_wrapper
from ..utils.user_wrapper import user_authentication_force_wrapper
from ..utils.x_request_wrapper import x_request_wrapper
from ..utils.j_transform_type import JTransformType


class ExamQuestionItemAPI(APIView):
    """
    考试题目单项操作API：详情、添加、编辑、删除
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取题目详情（包含选项）
        @param pk: 题目ID

        @example
        GET /api/exam/question/123/
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少题目ID。", err=1000)

        # 转换为整数
        try:
            question_id = int(pk)
        except ValueError:
            return util_response(msg="题目ID格式错误。", err=1001)

        # 调用服务层
        data, error_text = ExamQuestionService.item(pk=question_id)
        if not error_text:
            return util_response(data=data)
        return util_response(err=8306, msg=error_text)

    @request_params_wrapper
    def post(self, *args, request_params=None, **kwargs):
        """
        添加题目（包含选项）
        @param subject_id: 所属科目ID（必填）
        @param question: 题目内容（必填）
        @param score: 分值（默认1）
        @param column: 选项展示列数（默认0）
        @param options: 选项列表（必填，至少2个）
        @example
        POST /api/exam/question/
        {
            "subject_id": 1,
            "question": "1+1等于几？",
            "score": 5,
            "analysis": "基础加法运算",
            "column": 2,
            "options": [
                {"option": "A", "content": "1", "is_correct": false},
                {"option": "B", "content": "2", "is_correct": true},
                {"option": "C", "content": "3", "is_correct": false},
                {"option": "D", "content": "4", "is_correct": false}
            ]
        }
        @return
        {
            "err": 0,
            "data": {
                "id": 1,
                "subject_id": 1,
                "subject_name": "数学",
                "question": "1+1等于几？",
                "score": 5,
                "analysis": "基础加法运算",
                "column": 2,
                "create_time": "2024-01-01 10:00:00",
                "options": [
                    {"id": 1, "option": "A", "content": "1", "is_correct": false},
                    {"id": 2, "option": "B", "content": "2", "is_correct": true},
                    {"id": 3, "option": "C", "content": "3", "is_correct": false},
                    {"id": 4, "option": "D", "content": "4", "is_correct": false}
                ]
            }
        }
        """
        # ========== 参数验证 ==========
        if not request_params:
            return util_response(err=8301, msg="请求参数不能为空。")
        # 提取必填字段
        options = request_params.get('options')
        # ========== 提取题目参数（排除 options） ==========
        params = {k: v for k, v in request_params.items() if k != 'options'}
        # ========== 调用服务层 ==========
        data, err_txt = ExamQuestionService.add(params=params, options=options)

        if not err_txt:
            return util_response(data=data)

        return util_response(err=47767, msg=err_txt)

    @request_params_wrapper
    def put(self, *args, request_params=None, **kwargs):
        """
        编辑题目（可选更新选项）

        @param pk: 题目ID
        @param subject_id: 所属科目ID（可选）
        @param question: 题目内容（可选）
        @param score: 分值（可选）
        @param analysis: 答案解析（可选）
        @param column: 选项展示列数（可选）
        @param options: 选项列表（可选，如果提供则完全替换原有选项）

        @example
        PUT /api/exam/question/123/
        {
            "question": "1+1等于多少？",
            "score": 10,
            "options": [
                {"option": "A", "content": "1", "is_correct": false},
                {"option": "B", "content": "2", "is_correct": true},
                {"option": "C", "content": "3", "is_correct": false}
            ]
        }
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少题目ID。", err=1000)

        # 转换为整数
        try:
            question_id = int(pk)
        except ValueError:
            return util_response(msg="题目ID格式错误。", err=1001)

        # 提取选项（如果有）
        options = request_params.pop('options', None)

        # 调用服务层
        data, error_text = ExamQuestionService.edit(pk=question_id, params=request_params, options=options)
        if error_text:
            return util_response(err=1002, msg=error_text)

        return util_response(data=data)

    @user_authentication_force_wrapper
    def delete(self, *args, **kwargs):
        """
        删除题目（级联删除选项）

        @param pk: 题目ID

        @example
        DELETE /api/exam/question/123/
        """
        pk = kwargs.get("pk", None)
        if not pk:
            return util_response(msg="缺少题目ID。", err=1000)

        # 转换为整数
        try:
            question_id = int(pk)
        except ValueError:
            return util_response(msg="题目ID格式错误。", err=1001)

        # 调用服务层
        data, error_text = ExamQuestionService.delete(pk=question_id)
        if not error_text:
            return util_response(msg="删除成功")
        return util_response(err=47767, msg=error_text)


class ExamQuestionListAPI(APIView):
    """
    考试题目列表API：列表查询、批量添加、批量删除

    @description
    [2024.12.10] 参考 exam_subject_api.py 实现
    - 支持多条件查询
    - 支持ID列表查询
    - 支持分页
    - 支持排序
    - 支持批量添加
    - 支持批量删除
    - 可选返回选项信息
    """

    @request_params_wrapper
    def get(self, *args, request_params, **kwargs):
        """
        获取题目列表
        @param page: 页码，默认1
        @param size: 每页数量，默认20（别名：page_size）
        @param sort: 排序字段，默认-create_time（别名：order_by）
        @param search: 搜索关键词（题目内容或答案解析）
        @param id_list: 题目ID列表（逗号分隔或数组）
        @param subject_id: 科目ID
        @param subject_id_list: 科目ID列表（逗号分隔或数组）
        @param paper_id: 试卷ID（✅ 查询指定试卷的题目）
        @param section_id: 专项ID（✅ 新增：查询指定专项的题目）
        @param question: 题目内容（模糊查询）
        @param analysis: 答案解析（模糊查询）
        @param score: 分值（精确查询）
        @param score_min: 最小分值
        @param score_max: 最大分值
        @param column: 选项展示列数
        @param create_time_start: 创建开始时间
        @param create_time_end: 创建结束时间
        @param with_options: 是否包含选项信息，默认true
        @param show_correct: 是否显示正确答案，默认false
        @param filter_fields: 返回字段筛选
        @example
        # 考试场景：显示选项，隐藏答案
        GET /api/exam/question_list/?page=1&size=20
        GET /api/exam/question_list/?subject_id=1&with_options=true&show_correct=false
        # ✅ 查询某个试卷的题目（按题目序号排序）
        GET /api/exam/question_list/?paper_id=1&show_correct=false
        GET /api/exam/question_list/?paper_id=1&sort=number
        # ✅ 查询某个专项的题目（按题目序号排序）
        GET /api/exam/question_list/?section_id=1&show_correct=false
        GET /api/exam/question_list/?section_id=1&sort=number
        # ✅ 查询试卷中某个专项的题目
        GET /api/exam/question_list/?paper_id=1&section_id=2&sort=number
        # ✅ 任何情况下都可以按 number 排序
        GET /api/exam/question_list/?sort=number
        GET /api/exam/question_list/?subject_id=1&sort=number
        # 管理后台：显示选项和答案
        GET /api/exam/question_list/?page=1&size=20&show_correct=true
        GET /api/exam/question_list/?paper_id=1&show_correct=true
        # 不显示选项（性能优化）
        GET /api/exam/question_list/?page=1&size=20&with_options=false
        # 搜索查询
        GET /api/exam/question_list/?search=加法
        # 按ID列表查询
        GET /api/exam/question_list/?id_list=1,2,3&show_correct=true
        # 按分值范围查询
        GET /api/exam/question_list/?score_min=5&score_max=10&sort=-score
        """
        # ========== 参数提取与转换 ==========
        # 分页参数
        page, is_void = JTransformType.to(request_params.get('page', 1), "int", 1)
        # 兼容 page_size 和 size
        size, is_void = JTransformType.to(request_params.get('size') or request_params.get('page_size', 20), "int", 20)
        # 排序参数（兼容 sort 和 order_by）
        sort, is_void = JTransformType.to(request_params.get('sort') or request_params.get('order_by', 'create_time'),
                                          "str", "-create_time")
        # 是否包含选项（默认 true）
        with_options, is_void = JTransformType.to(request_params.get('with_options', True), "bool", True)
        # 是否显示正确答案（默认 false）
        show_correct, is_void = JTransformType.to(request_params.get('show_correct', False), "bool", False)
        # ✅ 试卷ID参数
        paper_id, is_void = JTransformType.to(request_params.get('paper_id', None), "int", None)
        # ✅ 专项ID参数
        section_id, is_void = JTransformType.to(request_params.get('section_id', None), "int", None)

        # ID列表参数
        id_list_param = request_params.get('id_list', None)
        id_list = None
        if id_list_param:
            # 支持逗号分隔的字符串或数组
            if isinstance(id_list_param, str):
                id_list = [int(x.strip()) for x in id_list_param.split(',') if x.strip().isdigit()]
            elif isinstance(id_list_param, list):
                id_list = [int(x) for x in id_list_param if str(x).isdigit()]

        # 科目ID
        subject_id, is_void = JTransformType.to(request_params.get('subject_id', None), "int", None)

        # 科目ID列表参数
        subject_id_list_param = request_params.get('subject_id_list', None)
        subject_id_list = None
        if subject_id_list_param:
            if isinstance(subject_id_list_param, str):
                subject_id_list = [int(x.strip()) for x in subject_id_list_param.split(',') if x.strip().isdigit()]
            elif isinstance(subject_id_list_param, list):
                subject_id_list = [int(x) for x in subject_id_list_param if str(x).isdigit()]

        # ========== 构建查询参数 ==========
        query_params = {}
        # 搜索关键词
        search = request_params.get('search', None)
        if search:
            query_params['search'] = search

        # 其他查询条件
        query_fields = ['id', 'question', 'analysis', 'score', 'score_min', 'score_max', 'column', 'create_time_start',
                        'create_time_end']
        for field in query_fields:
            value = request_params.get(field, None)
            if value:
                query_params[field] = value

        # 科目ID列表
        if subject_id_list:
            query_params['subject_id_list'] = subject_id_list

        # ========== 参数验证 ==========
        if page < 1:
            page = 1
        if size < 1 or size > 200:
            size = 200

        # ✅ 排序字段验证（永远支持 number 排序）
        sort_choices = ["id", "-id", "subject_id", "-subject_id", "score", "-score", "create_time", "-create_time", "number", "-number"]

        if sort not in sort_choices:
            return util_response(err=8302, msg=f"排序字段无效，可选值：{'、'.join(sort_choices)}。")

        # ========== 调用服务层 ==========
        data, error_text = ExamQuestionService.list( id_list=id_list, subject_id=subject_id, paper_id=paper_id, section_id=section_id, query_params=query_params, page=page, size=size, sort=sort, with_options=with_options, show_correct=show_correct,)

        if not error_text:
            return util_response(data=data)
        return util_response(err=8306, msg=error_text)

    @x_request_wrapper
    def post(self, request, request_params, *args, **kwargs):
        """
        批量添加题目

        @param questions: 题目列表，格式：[{"subject_id": 1, "question": "...", "options": [...]}, ...]

        @example
        POST /api/exam/question_list/
        {
            "questions": [
                {
                    "subject_id": 1,
                    "question": "1+1=?",
                    "score": 5,
                    "analysis": "基础加法",
                    "column": 2,
                    "options": [
                        {"option": "A", "content": "1", "is_correct": false},
                        {"option": "B", "content": "2", "is_correct": true},
                        {"option": "C", "content": "3", "is_correct": false},
                        {"option": "D", "content": "4", "is_correct": false}
                    ]
                },
                {
                    "subject_id": 1,
                    "question": "2+2=?",
                    "score": 5,
                    "analysis": "基础加法",
                    "options": [
                        {"option": "A", "content": "3", "is_correct": false},
                        {"option": "B", "content": "4", "is_correct": true},
                        {"option": "C", "content": "5", "is_correct": false}
                    ]
                }
            ]
        }

        @return
        {
            "err": 0,
            "data": {
                "success_count": 2,
                "error_count": 0,
                "success_list": [...],
                "error_list": []
            }
        }
        """

        # ========== 用户令牌验证（可选） ==========
        token = request.META.get('HTTP_AUTHORIZATION', None)
        if token and 'xj_user' in sys.modules:
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)

        # ========== 参数验证 ==========
        questions = request_params.get('questions', [])

        # 类型验证
        if not questions:
            return util_response(err=8301, msg="批量数据(questions)不能为空。")

        if not isinstance(questions, list):
            return util_response(err=8301, msg="批量数据(questions)必须是列表格式。")

        # 数量限制
        if len(questions) > 100:
            return util_response(err=8303, msg="单次批量添加不能超过100条数据。")

        # 数据格式验证
        for index, question_data in enumerate(questions):
            if not isinstance(question_data, dict):
                return util_response(
                    err=8304,
                    msg=f"第 {index + 1} 条数据格式错误，必须是字典格式。"
                )
            if not question_data.get('subject_id'):
                return util_response(
                    err=8305,
                    msg=f"第 {index + 1} 条数据缺少必填字段：subject_id（所属科目）。"
                )
            if not question_data.get('question'):
                return util_response(
                    err=8305,
                    msg=f"第 {index + 1} 条数据缺少必填字段：question（题目内容）。"
                )
            if not question_data.get('analysis'):
                return util_response(
                    err=8305,
                    msg=f"第 {index + 1} 条数据缺少必填字段：analysis（答案解析）。"
                )
            if not question_data.get('options'):
                return util_response(
                    err=8305,
                    msg=f"第 {index + 1} 条数据缺少必填字段：options（选项列表）。"
                )

        # ========== 批量添加 ==========
        success_list = []
        error_list = []

        for index, question_data in enumerate(questions):
            options = question_data.pop('options', [])
            data, err_txt = ExamQuestionService.add(params=question_data, options=options)
            if not err_txt:
                success_list.append(data)
            else:
                # 恢复 options 以便返回完整数据
                question_data['options'] = options
                error_list.append({
                    "index": index + 1,
                    "data": question_data,
                    "error": err_txt
                })

        # ========== 返回结果 ==========
        result = {
            "success_count": len(success_list),
            "error_count": len(error_list),
            "success_list": success_list,
            "error_list": error_list,
        }

        # 如果全部失败，返回错误
        if len(error_list) == len(questions):
            return util_response(err=8307, msg="批量添加失败，所有数据都未成功添加。", data=result)

        # 部分成功或全部成功
        return util_response(data=result)

    @x_request_wrapper
    def delete(self, request, request_params, *args, **kwargs):
        """
        批量删除题目

        @param id_list: 题目ID列表

        @example
        DELETE /api/exam/question_list/
        {
            "id_list": [1, 2, 3, 4, 5]
        }

        @return
        {
            "err": 0,
            "data": {
                "success_count": 3,
                "error_count": 2,
                "success_list": [1, 2, 3],
                "error_list": [
                    {"id": 4, "error": "题目被试卷使用，无法删除"},
                    {"id": 5, "error": "题目不存在"}
                ]
            }
        }
        """

        # ========== 用户令牌验证（可选） ==========
        token = request.META.get('HTTP_AUTHORIZATION', None)
        if token and 'xj_user' in sys.modules:
            token_serv, error_text = UserService.check_token(token)
            if error_text:
                return util_response(err=6045, msg=error_text)

        # ========== 参数验证 ==========
        id_list = request_params.get('id_list', [])

        # 类型验证
        if not id_list:
            return util_response(err=8301, msg="题目ID列表(id_list)不能为空。")

        if not isinstance(id_list, list):
            return util_response(err=8301, msg="题目ID列表(id_list)必须是列表格式。")

        # 数量限制
        if len(id_list) > 100:
            return util_response(err=8303, msg="单次批量删除不能超过100条数据。")

        # ========== 调用服务层 ==========
        data, error_text = ExamQuestionService.batch_delete(id_list=id_list)

        if not error_text:
            # 如果全部失败
            if data['error_count'] == len(id_list):
                return util_response(err=8308, msg="批量删除失败，所有数据都未成功删除。", data=data)
            return util_response(data=data)

        return util_response(err=8306, msg=error_text)