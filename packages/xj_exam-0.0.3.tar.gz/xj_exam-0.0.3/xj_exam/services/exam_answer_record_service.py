# encoding: utf-8
"""
@project: exam_answer_record_service
@author:
@Email:
@synopsis: 答题记录服务层
@created_time: 2026
"""
from django.db import transaction
from ..models import ExamAnswerRecord, ExamRecord, ExamQuestion, ExamQuestionOption, ExamPaperQuestion
from ..utils.j_transform_type import JTransformType
from ..utils.j_parameter import JParameter


class ExamAnswerRecordService:
    """答题记录服务类：提供答题记录的批量添加服务"""

    # 格式化字段
    format_fields = ["question_id|int", "question_option_id|int", "snapshot|dict"]

    @staticmethod
    def add(exam_record_id: int = None, answer_list: list = None, **kwargs):
        """批量添加答题记录"""
        # ========== 参数验证 ==========
        if not exam_record_id:
            return None, "考试记录ID(exam_record_id)必填。"

        exam_record_id, is_void = JTransformType.to(exam_record_id, "int", None)
        if not exam_record_id:
            return None, "考试记录ID格式错误，必须是整数。"

        answer_list, is_void = JTransformType.to(answer_list, "list", [])
        if not answer_list:
            return None, "答题列表(answer_list)不能为空。"

        if not isinstance(answer_list, list):
            return None, "答题列表必须是列表格式。"

        # ========== 数量限制 ==========
        if len(answer_list) > 200:
            return None, "单次批量添加不能超过200条答题记录。"

        # ========== 初始化结果 ==========
        result_list = []

        # ========== 数据库操作（使用事务） ==========
        try:
            with transaction.atomic():
                # ========== 验证考试记录 ==========
                exam_record = ExamRecord.objects.filter(id=exam_record_id).select_related('paper').first()
                if not exam_record:
                    return None, f"考试记录(ID:{exam_record_id})不存在。"

                # ========== 获取该试卷的所有题目ID ==========
                paper_question_ids = set(
                    ExamPaperQuestion.objects.filter(exam_paper_id=exam_record.paper_id).values_list('exam_question_id',
                                                                                                     flat=True)
                )

                if not paper_question_ids:
                    return None, f"试卷(ID:{exam_record.paper_id})没有关联任何题目。"

                # ========== 遍历每个答题记录 ==========
                for index, answer_data in enumerate(answer_list):
                    # ========== 参数格式验证 ==========
                    if not isinstance(answer_data, dict):
                        return None, f"第 {index + 1} 条答案格式错误，必须是字典格式。"

                    query_params = JParameter.format(answer_data, filter_fields=ExamAnswerRecordService.format_fields)

                    # ========== 必填字段验证 ==========
                    question_id = query_params.get("question_id")
                    question_option_id = query_params.get("question_option_id")

                    if not question_id:
                        return None, f"第 {index + 1} 条答案缺少必填字段：question_id（题目ID）。"
                    if not question_option_id:
                        return None, f"第 {index + 1} 条答案缺少必填字段：question_option_id（选项ID）。"

                    # ========== 类型转换 ==========
                    query_params['question_id'], is_void = JTransformType.to(query_params.get('question_id'), "int")
                    query_params['question_option_id'], is_void = JTransformType.to(
                        query_params.get('question_option_id'), "int")

                    if not query_params['question_id'] or not query_params['question_option_id']:
                        return None, f"第 {index + 1} 条答案参数格式错误，ID不能为空。"

                    # ========== 验证题目是否属于该试卷 ==========
                    if query_params['question_id'] not in paper_question_ids:
                        return None, f"第 {index + 1} 条答案：题目(ID:{query_params['question_id']})不属于该试卷(ID:{exam_record.paper_id})。"

                    # ========== 验证题目 ==========
                    question = ExamQuestion.objects.filter(id=query_params['question_id']).first()
                    if not question:
                        return None, f"第 {index + 1} 条答案：题目(ID:{query_params['question_id']})不存在。"

                    # ========== 验证选项 ==========
                    question_option = ExamQuestionOption.objects.filter(
                        id=query_params['question_option_id'],
                        question_id=query_params['question_id']
                    ).first()
                    if not question_option:
                        return None, f"第 {index + 1} 条答案：选项(ID:{query_params['question_option_id']})不存在或不属于该题目。"

                    # ========== 检查重复答题 ==========
                    existing_answer = ExamAnswerRecord.objects.filter(
                        exam_record_id=exam_record_id,
                        question_id=query_params['question_id']
                    ).first()

                    if existing_answer:
                        return None, f"第 {index + 1} 条答案：该题目已经作答，不能重复答题。答题记录ID：{existing_answer.id}"

                    # ========== 判断答案是否正确 ==========
                    is_correct = question_option.is_correct

                    # ========== 获取题目分数（不管对错都记录题目分数） ==========
                    score = float(question.score)

                    # ========== 获取快照 ==========
                    snapshot = query_params.get('snapshot', None)

                    # ========== 创建答题记录 ==========
                    answer_record = ExamAnswerRecord.objects.create(
                        exam_record_id=exam_record_id,
                        question_id=question.id,
                        question_option_id=question_option.id,
                        is_correct=is_correct,
                        score=score,
                        snapshot=snapshot
                    )

                    # ========== 添加到结果列表 ==========
                    result_list.append({
                        "id": answer_record.id,
                        "exam_record_id": answer_record.exam_record_id,
                        "question_id": answer_record.question_id,
                        "question_option_id": answer_record.question_option_id,
                        "is_correct": answer_record.is_correct,
                        "score": answer_record.score,
                        "snapshot": answer_record.snapshot
                    })

                # ========== 返回结果 ==========
                return {
                    "exam_record_id": exam_record_id,
                    "records": result_list
                }, None

        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""

    @staticmethod
    def list(exam_record_id: int = None, is_correct: bool = None, query_params: dict = None, page: int = 1,size: int = 20, sort: str = "-id"):
        """
        获取答题记录列表（不包含题目详情）
        :param exam_record_id: 考试记录ID
        :param is_correct: 是否正确
        :param query_params: 筛选条件字典
        :param page: 页码，默认1
        :param size: 每页数量，默认20
        :param sort: 排序字段，默认 -id
        :return: (列表数据, 错误信息)
        """
        # ========== 参数类型处理 ==========
        query_params, is_void = JTransformType.to(query_params, "dict", {})
        page, is_void = JTransformType.to(page, "int", 1)
        size, is_void = JTransformType.to(size, "int", 20)
        sort_param, is_void = JTransformType.to(sort, "str", "-id")
        # 参数验证
        if page < 1:
            page = 1
        if size < 1 or size > 200:
            size = 20
        # 排序字段验证
        sort_choices = ["id", "-id", "score", "-score", "is_correct", "-is_correct"]
        if sort_param not in sort_choices:
            return None, f"排序字段无效，可选值：{'、'.join(sort_choices)}。"
        try:
            # ========== 构建基础查询 ==========
            from django.core.paginator import Paginator, EmptyPage
            answer_set = ExamAnswerRecord.objects.order_by(sort_param)
            # 如果提供了考试记录ID
            if exam_record_id:
                exam_record_id, is_void = JTransformType.to(exam_record_id, "int", None)
                if exam_record_id:
                    answer_set = answer_set.filter(exam_record_id=exam_record_id)
            # 如果提供了正确性过滤
            if is_correct is not None:
                is_correct, is_void = JTransformType.to(is_correct, "bool", None)
                if is_correct is not None:
                    answer_set = answer_set.filter(is_correct=is_correct)
            # ========== 处理查询条件 ==========
            from ..utils.custom_tool import format_params_handle
            filter_filed_list = ["exam_record_id|int", "question_id|int", "question_option_id|int", "is_correct|bool",
                                 "score_min|float", "score_max|float"]
            condition_alias = {"score_min": "score__gte", "score_max": "score__lte"}
            conditions = format_params_handle(param_dict=query_params, filter_filed_list=filter_filed_list,
                                              alias_dict=condition_alias, is_remove_empty=True)
            if conditions:
                answer_set = answer_set.filter(**conditions)
            # 记录查询SQL
            answer_query = answer_set.query
            # ========== 执行分页查询 ==========
            paginator = Paginator(answer_set, per_page=size)
            total = paginator.count
            # 页号溢出返回空列表
            if page > paginator.num_pages and paginator.num_pages > 0:
                result = {"page": page, "size": size, "total": total, "list": [], "query": str(answer_query)}
                return result, None
            # 获取当前页数据
            paginator_set = paginator.page(page) if total > 0 else []
            # ========== 导出分页结果 ==========
            if total > 0:
                main_set = paginator_set.object_list
                main_list = list(
                    main_set.values('id', 'exam_record_id', 'question_id', 'question_option_id', 'is_correct', 'score',
                                    'snapshot'))
            else:
                main_list = []
            # 返回结果
            result = {"page": int(page), "size": int(size), "total": total, "list": main_list,
                      "query": str(answer_query)}
            return result, None
        except EmptyPage:
            result = {"page": page, "size": size, "total": 0, "list": [], "query": ""}
            return result, None
        except Exception as e:
            return None, f"""{str(e)} in "{str(e.__traceback__.tb_frame.f_globals["__file__"])}" : Line {str(e.__traceback__.tb_lineno)}"""