# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

# threading.Lock is a factory function pre python3.13 so we can't type hint it with the class directly
# without hitting a TypeError at runtime. Importing annotations turns the type hint to a string so that
# the TypeError is circumvented.
from __future__ import annotations

import os
import threading
from typing import Any, overload
from loguru import logger as loguru_logger

from metrana.logger.logger import MetranaLogger
from metrana_protobuf.ingestion.v1.types.aggregation_rules_pb2 import AggregationRule
from metrana.utils.enums import (
    BackpressureStrategy,
    CloseStrategy,
    ErrorStrategy,
    LogLevel,
    ResumeStrategy,
    StandardMetricScale,
)
from metrana.utils.exceptions import (
    MetranaNotInitializedError,
    MetranaProcessForkError,
    NoMetranaApiKeyError,
)
from metrana.utils import env_vars
from metrana.utils import logging as metrana_logging

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

EVALUATION_LABEL = "evaluation"

# ======================================================================================================================
#
# GLOBALS
#
# ======================================================================================================================

_metrana_logger: MetranaLogger | None = None
_metrana_pid: int | None = None
_metrana_lock: threading.Lock = threading.Lock()
_metrana_lock_pid: int = os.getpid()
_metrana_config: dict[str, Any] | None = None

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def _ensure_lock() -> None:
    """Ensure the process-global lock is valid for this process, creating a new one if the process has forked."""

    global _metrana_lock, _metrana_lock_pid

    current_pid = os.getpid()
    if current_pid != _metrana_lock_pid:
        _metrana_lock = threading.Lock()
        _metrana_lock_pid = current_pid


def _build_logger(**kwargs) -> None:
    """Create and store a new MetranaLogger instance and record the current process ID."""

    global _metrana_logger, _metrana_pid

    _metrana_logger = MetranaLogger(**kwargs)
    _metrana_pid = os.getpid()


def _check_logger_initialized() -> None:
    """Raise MetranaNotInitializedError if the logger has not been initialized."""

    if _metrana_logger is None or _metrana_pid is None:
        raise MetranaNotInitializedError(
            "Metrana logger is not initialized. Please ensure that metrana.init(...) has been called "
            "before calling this function."
        )


def _get_or_reinit_logger(kill_timeout: float) -> MetranaLogger:
    """
    Return the active logger, rebuilding it if this process has forked since init().

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    _ensure_lock()

    with _metrana_lock:
        _check_logger_initialized()
        current_pid = os.getpid()

        if _metrana_pid is not None and current_pid != _metrana_pid:
            loguru_logger.debug(
                f"Process fork detected (old pid: {_metrana_pid}, new pid: {current_pid}). "
                f"Rebuilding logger for new process."
            )

            if _metrana_config is None:
                raise MetranaProcessForkError(
                    "Metrana config is not set. Cannot rebuild logger for new process. This should "
                    "be unreachable. Please report this as a bug."
                )

            if _metrana_logger is not None:
                _metrana_logger.kill(timeout=kill_timeout)

            _build_logger(**_metrana_config)

        return _metrana_logger


def init(
    resume_strategy: ResumeStrategy | str | None = None,
    backpressure_strategy: BackpressureStrategy | str | None = None,
    error_strategy: ErrorStrategy | str | None = None,
    close_strategy: CloseStrategy | str | None = None,
    log_level: LogLevel | str | None = None,
    autoconfigure_loguru: bool = True,
    num_dispatch_workers: int = 4,
    event_queue_max_size: int | None = None,
    dispatch_queue_max_size: int | None = None,
    error_queue_max_size: int | None = None,
    batch_fill_initial_wait: float = 0.1,
    batch_fill_wait_decay: float = 0.5,
    batch_fill_max_waits: int = 3,
    request_timeout: float = 30.0,
    api_key: str | None = None,
    aggregation_rules: list[AggregationRule] | None = None,
    config: dict | None = None,
    **kwargs,
) -> None:
    """
    Initialize the Metrana logger. Must be called once before log() or close().

    Args:
        resume_strategy: How to handle existing runs: Never or Allow.
        backpressure_strategy: When the event queue is full: Block, DropNew, or Raise.
        error_strategy: How to handle dispatch errors: Silent, Warn, RaiseOnLog, or RaiseOnClose.
        close_strategy: How to shut down: Immediate, CompletePending, or CompleteAll.
            Can be overridden at close() and defaults to env if unset.
        log_level: Log level for internal loguru configuration when
            autoconfigure_loguru is True.
        autoconfigure_loguru: If True, configure loguru with the given log level.
        num_dispatch_workers: Number of async worker tasks that consume from
            the dispatch queue and send events.
        event_queue_max_size: Max size of the event queue (0 = unbounded).
        dispatch_queue_max_size: Max size of the dispatch queue (0 = unbounded).
        error_queue_max_size: Max size of the error queue (0 = unbounded).
        batch_fill_initial_wait: Initial wait in seconds when filling a batch and the queue
            is temporarily empty (decaying wait).
        batch_fill_wait_decay: Decay factor for each wait (e.g. 0.5 halves the wait each time).
        batch_fill_max_waits: Max number of wait cycles before sending a partial batch.
        request_timeout: Total timeout in seconds for each HTTP request to the ingestion API.
        api_key: API key for the Metrana API.
        aggregation_rules: Optional list of AggregationRule messages declaring how series
            should be aggregated into derived series by the ingestion worker.
        config: Optional dict to log as queryable run attributes. Nested dicts and lists
            are flattened using "/" as the path separator and stored under the "config/"
            prefix. Must contain at most 10 000 leaf fields.
        **kwargs: Passed to MetranaLogger (e.g. workspace_name, project_name, run_name,
            ingestion_url, auth).
    """

    global _metrana_config

    _ensure_lock()

    with _metrana_lock:
        if any(variable is not None for variable in [_metrana_logger, _metrana_pid, _metrana_config]):
            metrana_logging.warn_once(
                "metrana.init() called but logger is already initialized — ignoring.", key="already_initialized"
            )
            return

        api_key = api_key or env_vars.get_api_key()
        if api_key is None:
            raise NoMetranaApiKeyError(
                f"Metrana API key is not set. Please set the API key using the api_key parameter or "
                f"the {env_vars.METRANA_API_KEY} environment variable."
            )

        init_config = dict(
            resume_strategy=resume_strategy,
            backpressure_strategy=backpressure_strategy,
            error_strategy=error_strategy,
            close_strategy=close_strategy,
            log_level=log_level,
            autoconfigure_loguru=autoconfigure_loguru,
            num_dispatch_workers=num_dispatch_workers,
            event_queue_max_size=event_queue_max_size,
            dispatch_queue_max_size=dispatch_queue_max_size,
            error_queue_max_size=error_queue_max_size,
            batch_fill_initial_wait=batch_fill_initial_wait,
            batch_fill_wait_decay=batch_fill_wait_decay,
            batch_fill_max_waits=batch_fill_max_waits,
            request_timeout=request_timeout,
            api_key=api_key,
            aggregation_rules=aggregation_rules,
            config=config,
            **kwargs,
        )

        _build_logger(**init_config)
        _metrana_config = dict(init_config)


@overload
def log(
    metric_name: str,
    value: float | int,
    scale: str | None = ...,
    step: int | None = ...,
    labels: dict[str, str] | None = ...,
    evaluation: bool = ...,
    timestamp: int | None = ...,
    kill_timeout: float = ...,
) -> None: ...


@overload
def log(
    metric_name: dict[str, float | int],
    value: None = ...,
    scale: str | None = ...,
    step: int | None = ...,
    labels: dict[str, str] | None = ...,
    evaluation: bool = ...,
    timestamp: int | None = ...,
    kill_timeout: float = ...,
) -> None: ...


def log(
    metric_name: str | dict[str, float | int],
    value: float | int | None = None,
    scale: str | None = None,
    step: int | None = None,
    labels: dict[str, str] | None = None,
    evaluation: bool = False,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event.

    Accepts two calling conventions::

        metrana.log("loss", 0.5)
        metrana.log({"loss": 0.5, "accuracy": 0.9})

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Either the name of a single metric (str), or a dict mapping metric
            names to numeric values. When a dict is passed, value must be omitted and all
            other arguments apply to every metric in the dict independently.
        value: Numeric value for this point (int or float). Required when metric_name is
            a str; must be omitted when metric_name is a dict.
        scale: Scale descriptor; must be a StandardMetricScale value
            (e.g. "ML_STEP", "EPISODE", "ENVIRONMENT_STEP"). If None, defaults to ML_STEP.
        step: Step index for this point. If None, the logger assigns the next step
            for this (metric_name, scale, labels) series.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        evaluation: If True, injects the label "evaluation": "true" unless the key
            is already present. Evaluation events form a separate series from
            non-evaluation events with otherwise identical identifiers.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    if isinstance(metric_name, dict):
        for name, val in metric_name.items():
            log(
                name,
                val,
                scale=scale,
                step=step,
                labels=labels,
                evaluation=evaluation,
                timestamp=timestamp,
                kill_timeout=kill_timeout,
            )
        return

    if value is None:
        raise TypeError("value is required when metric_name is a str.")

    effective_labels = dict(labels) if labels is not None else {}
    if evaluation and EVALUATION_LABEL not in effective_labels:
        effective_labels[EVALUATION_LABEL] = "true"

    current_pid = os.getpid()
    logger, stored_pid = _metrana_logger, _metrana_pid
    if logger is not None and stored_pid == current_pid:
        logger.log_standard(
            metric_name=metric_name,
            value=value,
            scale=scale,
            step=step,
            labels=effective_labels,
            timestamp=timestamp,
        )
        return

    _get_or_reinit_logger(kill_timeout).log_standard(
        metric_name=metric_name,
        value=value,
        scale=scale,
        step=step,
        labels=effective_labels,
        timestamp=timestamp,
    )


def close(close_strategy: CloseStrategy | str | None = None, close_timeout: float = 15.0) -> None:
    """
    Close the logger and clear internal state.

    After calling close(), init() may be called again to create a new logger instance.

    Args:
        close_strategy: Close strategy to use.
        close_timeout: Timeout in seconds for the logger to stop.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
    """

    global _metrana_logger, _metrana_pid, _metrana_config

    _ensure_lock()

    with _metrana_lock:
        _check_logger_initialized()

        try:
            _metrana_logger.close(strategy=close_strategy, timeout=close_timeout)
        finally:
            # Always clear state even if close() raises (e.g., RaiseOnClose with errors)
            _metrana_logger = None
            _metrana_pid = None
            _metrana_config = None


def log_rl_step(
    metric_name: str,
    value: float | int,
    evaluation: bool = False,
    step: int | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        evaluation: If True, injects the label "evaluation": "true" unless already present.
        step: Step index for this point. If None, the logger assigns the next step
            for this (metric_name, scale, labels) series.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    log(
        metric_name=metric_name,
        value=value,
        scale=StandardMetricScale.ML_STEP,
        evaluation=evaluation,
        step=step,
        labels=labels,
        timestamp=timestamp,
        kill_timeout=kill_timeout,
    )


def log_rl_episode(
    metric_name: str,
    value: float | int,
    rl_step: int,
    evaluation: bool = False,
    episode: int | None = None,
    env_id: str | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event on the EPISODE scale as a compound series point.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        rl_step: RL training step (major step). Must not decrease across calls for a given series.
        evaluation: If True, injects the label "evaluation": "true" unless already present.
        episode: Episode index used as the minor step for this point. If None, the logger
            assigns the next minor step automatically.
        env_id: Environment identifier. Part of the compound series identity.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    effective_labels = dict(labels) if labels is not None else {}
    if evaluation and EVALUATION_LABEL not in effective_labels:
        effective_labels[EVALUATION_LABEL] = "true"

    current_pid = os.getpid()
    logger, stored_pid = _metrana_logger, _metrana_pid
    if logger is not None and stored_pid == current_pid:
        logger.log_rl(
            metric_name=metric_name,
            value=value,
            major_step=rl_step,
            environment_id=env_id,
            episode=None,
            scale=StandardMetricScale.EPISODE,
            minor_step=episode,
            labels=effective_labels,
            timestamp=timestamp,
        )
        return

    _get_or_reinit_logger(kill_timeout).log_rl(
        metric_name=metric_name,
        value=value,
        major_step=rl_step,
        environment_id=env_id,
        episode=None,
        scale=StandardMetricScale.EPISODE,
        minor_step=episode,
        labels=effective_labels,
        timestamp=timestamp,
    )


def log_rl_environment_step(
    metric_name: str,
    value: float | int,
    rl_step: int,
    evaluation: bool = False,
    env_step: int | None = None,
    episode: int | None = None,
    env_id: str | None = None,
    labels: dict[str, str] | None = None,
    timestamp: int | None = None,
    kill_timeout: float = 3.0,
) -> None:
    """
    Log a metric event on the ENVIRONMENT_STEP scale as a compound series point.

    If the process has forked since init(), the logger is rebuilt automatically for the
    current process.

    Args:
        metric_name: Name of the metric (maps to series metric_name in the API).
        value: Numeric value for this point (int or float).
        rl_step: RL training step (major step). Must not decrease across calls for a given series.
        evaluation: If True, injects the label "evaluation": "true" unless already present.
        env_step: Environment step index used as the minor step for this point. If None,
            the logger assigns the next minor step automatically.
        episode: Episode index. Part of the compound series identity.
        env_id: Environment identifier. Part of the compound series identity.
        labels: Optional key-value labels identifying the series. Defaults to {}.
        timestamp: Optional Unix timestamp in nanoseconds. If None, set to current time.
        kill_timeout: Timeout in seconds for the logger to die if the process has forked.

    Raises:
        MetranaNotInitializedError: If init() has not been called.
        MetranaProcessForkError: If config was lost after a fork (unreachable in normal use).
    """

    effective_labels = dict(labels) if labels is not None else {}
    if evaluation and EVALUATION_LABEL not in effective_labels:
        effective_labels[EVALUATION_LABEL] = "true"

    current_pid = os.getpid()
    logger, stored_pid = _metrana_logger, _metrana_pid
    if logger is not None and stored_pid == current_pid:
        logger.log_rl(
            metric_name=metric_name,
            value=value,
            major_step=rl_step,
            environment_id=env_id,
            episode=episode,
            scale=StandardMetricScale.ENVIRONMENT_STEP,
            minor_step=env_step,
            labels=effective_labels,
            timestamp=timestamp,
        )
        return

    _get_or_reinit_logger(kill_timeout).log_rl(
        metric_name=metric_name,
        value=value,
        major_step=rl_step,
        environment_id=env_id,
        episode=episode,
        scale=StandardMetricScale.ENVIRONMENT_STEP,
        minor_step=env_step,
        labels=effective_labels,
        timestamp=timestamp,
    )
