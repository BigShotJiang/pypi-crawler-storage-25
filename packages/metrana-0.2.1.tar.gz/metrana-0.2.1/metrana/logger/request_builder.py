# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from typing import TypeAlias

from metrana_protobuf.ingestion.v1.svc import api_pb2
from metrana_protobuf.ingestion.v1.types import updates_pb2
from google.protobuf.timestamp_pb2 import Timestamp

from metrana.utils.metric_event import MetricEvent, CompoundMetricEvent, AnyMetricEvent
from metrana.utils import logging

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

NANOS_PER_SECOND = 1_000_000_000

SeriesMapKey: TypeAlias = tuple[str, str, tuple[tuple[str, str], ...]]
RLSeriesMapKey: TypeAlias = tuple[str, str, str, int | None, tuple[tuple[str, str], ...]]

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def _split_batch(
    batch: list[AnyMetricEvent],
) -> tuple[list[MetricEvent], list[CompoundMetricEvent]]:
    """
    Partition a mixed batch into regular and RL compound events.

    Args:
        batch: List of MetricEvent or CompoundMetricEvent objects.

    Returns:
        Tuple of (regular_events, compound_events).
    """

    regular: list[MetricEvent] = []
    compound: list[CompoundMetricEvent] = []
    for event in batch:
        if isinstance(event, CompoundMetricEvent):
            compound.append(event)
        else:
            regular.append(event)
    return regular, compound


def _create_regular_series_map(batch: list[MetricEvent]) -> dict[SeriesMapKey, list[MetricEvent]]:
    """
    Group a batch of MetricEvents by their series key (metric_name, scale, labels).

    Args:
        batch: List of MetricEvent objects to group.

    Returns:
        Dict mapping each series key to the list of events belonging to it.
    """

    series_map: dict[SeriesMapKey, list[MetricEvent]] = {}
    for event in batch:
        labels_key = tuple(sorted(event.labels.items()))
        key = (event.metric_name, event.scale, labels_key)

        if key not in series_map:
            series_map[key] = []

        series_map[key].append(event)

    return series_map


def _create_regular_series_updates(series_map: dict[SeriesMapKey, list[MetricEvent]]) -> list[updates_pb2.SeriesUpdate]:
    """
    Convert a grouped series map into a list of SeriesUpdate proto messages.

    Args:
        series_map: Dict produced by _create_regular_series_map.

    Returns:
        List of SeriesUpdate protos, one per distinct series key.
    """

    series_updates = []
    for (metric_name, scale, labels_key), events in series_map.items():
        points = []

        for event in events:
            timestamp = Timestamp()
            timestamp.seconds = event.timestamp // NANOS_PER_SECOND
            timestamp.nanos = event.timestamp % NANOS_PER_SECOND

            point = updates_pb2.Point(
                step=event.step,
                timestamp=timestamp,
                float_value=event.value,
            )
            points.append(point)

        # The step counter guarantees per-series consistency (all auto or all manual),
        # so within a series all events will have the same unordered value.
        ordering = (
            updates_pb2.ORDERING_MODE_ABSOLUTE_UNORDERED
            if any(event.unordered for event in events)
            else updates_pb2.ORDERING_MODE_RELATIVE_ORDERED
        )

        series_update = updates_pb2.SeriesUpdate(
            metric_name=metric_name, scale=scale, labels=dict(labels_key), points=points, ordering=ordering
        )
        series_updates.append(series_update)

    return series_updates


def _create_rl_series_map(batch: list[CompoundMetricEvent]) -> dict[RLSeriesMapKey, list[CompoundMetricEvent]]:
    """
    Group a batch of CompoundMetricEvents by their compound series key
    (metric_name, scale, environment_id, episode, labels).

    Args:
        batch: List of CompoundMetricEvent objects to group.

    Returns:
        Dict mapping each compound series key to the list of events belonging to it.
    """

    series_map: dict[RLSeriesMapKey, list[CompoundMetricEvent]] = {}
    for event in batch:
        labels_key = tuple(sorted(event.labels.items()))
        key = (event.metric_name, event.scale, event.environment_id, event.episode, labels_key)

        if key not in series_map:
            series_map[key] = []

        series_map[key].append(event)

    return series_map


def _create_rl_series_updates(
    rl_series_map: dict[RLSeriesMapKey, list[CompoundMetricEvent]],
) -> list[updates_pb2.RLSeriesUpdate]:
    """
    Convert a grouped RL series map into a list of RLSeriesUpdate proto messages.

    Args:
        series_map: Dict produced by _create_rl_series_map.

    Returns:
        List of RLSeriesUpdate protos, one per distinct compound series key.
    """

    rl_series_updates = []
    for (metric_name, scale, environment_id, episode, labels_key), events in rl_series_map.items():
        points = []

        for event in events:
            timestamp = Timestamp()
            timestamp.seconds = event.timestamp // NANOS_PER_SECOND
            timestamp.nanos = event.timestamp % NANOS_PER_SECOND

            point = updates_pb2.CompoundPoint(
                major_step=event.major_step,
                minor_step=event.minor_step,
                timestamp=timestamp,
                float_value=event.value,
            )
            points.append(point)

        # The step counter guarantees per-series consistency (all auto or all manual),
        # so within a series all events will have the same unordered value.
        ordering = (
            updates_pb2.ORDERING_MODE_ABSOLUTE_UNORDERED
            if any(event.unordered for event in events)
            else updates_pb2.ORDERING_MODE_RELATIVE_ORDERED
        )

        series_update = updates_pb2.RLSeriesUpdate(
            metric_name=metric_name,
            environment_id=environment_id,
            episode=episode,
            scale=scale,
            labels=dict(labels_key),
            points=points,
            ordering=ordering,
        )
        rl_series_updates.append(series_update)

    return rl_series_updates


def build_v1_update_runs_request(
    batch: list[AnyMetricEvent],
    session_id: int,
    workspace_name: str,
    project_name: str,
    run_name: str,
) -> api_pb2.UpdateRunsRequest | None:
    """
    Build a v1 UpdateRunsRequest protobuf from a batch of MetricEvents.

    Groups events by (metric_name, scale, labels) into SeriesUpdate objects,
    then builds a single RunUpdate for the given run.

    Args:
        batch: List of MetricEvent objects to convert.
        session_id: Session ID used by the backend to loosely identify producers. This does not relate to
            authn or authz.
        workspace_name: The name of the workspace for this run.
        project_name: The name of the project for this run.
        run_name: The name of the run.

    Returns:
        UpdateRunsRequest protobuf message.
    """

    regular_batch, rl_batch = _split_batch(batch)
    series_map = _create_regular_series_map(batch=regular_batch)
    rl_series_map = _create_rl_series_map(batch=rl_batch)

    series_updates: list[updates_pb2.SeriesUpdate] | None = None
    rl_series_updates: list[updates_pb2.RLSeriesUpdate] | None = None

    if series_map:
        series_updates = _create_regular_series_updates(series_map=series_map)

    if rl_series_map:
        rl_series_updates = _create_rl_series_updates(rl_series_map=rl_series_map)

    if not series_updates and not rl_series_updates:
        logging.warn_once("Received empty series updates. Silently skipping.", key="empty_series_updates")
        return None

    run_update = api_pb2.UpdateRunsRequest.RunUpdate(
        workspace=workspace_name,
        project=project_name,
        run_name=run_name,
        series=series_updates or [],
        rl_series=rl_series_updates or [],
    )

    return api_pb2.UpdateRunsRequest(
        session_id=session_id,
        run_updates=[run_update],
    )


def build_v1_config_update_request(
    attributes: list[updates_pb2.AttributeUpdate],
    session_id: int,
    workspace_name: str,
    project_name: str,
    run_name: str,
) -> api_pb2.UpdateRunsRequest:
    """
    Build a v1 UpdateRunsRequest carrying only attribute updates (no series).

    Used to send a flattened run config immediately after run creation.

    Args:
        attributes: List of AttributeUpdate protos to include.
        session_id: Session ID for the request.
        workspace_name: The name of the workspace for this run.
        project_name: The name of the project for this run.
        run_name: The name of the run.

    Returns:
        UpdateRunsRequest protobuf message.
    """

    run_update = api_pb2.UpdateRunsRequest.RunUpdate(
        workspace=workspace_name,
        project=project_name,
        run_name=run_name,
        attributes=attributes,
    )

    return api_pb2.UpdateRunsRequest(
        session_id=session_id,
        run_updates=[run_update],
    )
