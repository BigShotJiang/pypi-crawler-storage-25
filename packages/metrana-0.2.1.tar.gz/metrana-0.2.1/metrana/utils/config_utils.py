# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import datetime
import re

from metrana_protobuf.ingestion.v1.types import updates_pb2

from metrana.utils import logging as metrana_logging

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

_CONFIG_PREFIX = "config"
_MAX_CONFIG_FIELDS = 10_000
_VALID_KEY_RE = re.compile(r"^[a-zA-Z0-9._\-:/]+$")

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def flatten_config(config: dict) -> list[updates_pb2.AttributeUpdate]:
    """
    Flatten a nested config dict into a list of AttributeUpdate protos.

    Dict keys and list indices are joined with "/" to form attribute paths, all
    rooted under the "config" prefix (e.g. {"optimizer": {"lr": 0.01}} becomes
    the path "config/optimizer/lr").

    Type mapping:
        bool   → bool_value   (checked before int; bool is a subclass of int)
        int    → int_value
        float  → float_value
        str    → string_value
        dict   → recurse using key as next path component
        list   → recurse using element index as next path component
        None   → skipped silently
        numpy/torch scalars (objects with .item()) → coerced to Python scalar then mapped;
            warns and skips if coercion fails or yields an unsupported type
        datetime.datetime / datetime.date → converted via str(); warns and skips on failure
        anything else → raises TypeError

    Args:
        config: Nested dict to flatten. Keys must match [a-zA-Z0-9._-:/]+ (non-empty).

    Returns:
        List of AttributeUpdate protos, one per leaf value.

    Raises:
        ValueError: If a dict key contains invalid characters, the total number of leaf
            fields exceeds 10 000, or two different key paths produce the same attribute
            path (e.g. key "a/b" conflicts with nested key {"a": {"b": ...}}).
        TypeError: If a leaf value has an unsupported type.
    """

    out: list[updates_pb2.AttributeUpdate] = []
    _flatten_node(config, _CONFIG_PREFIX, out, [0])

    seen: set[str] = set()
    for attr in out:
        if attr.path in seen:
            raise ValueError(
                f"Config produces duplicate attribute path '{attr.path}'. "
                "This can occur when a key contains '/' which conflicts with the path separator "
                "(e.g. key 'a/b' and nested key 'a' -> 'b' both resolve to the same path)."
            )
        seen.add(attr.path)

    return out


def _flatten_node(
    value: object,
    path: str,
    out: list[updates_pb2.AttributeUpdate],
    count: list[int],
) -> None:
    """
    Recursively flatten one node of the config tree into out.

    Args:
        value: The value at this node.
        path: Fully-qualified attribute path built so far (e.g. "config/optimizer/lr").
        out: Accumulator list; leaf AttributeUpdate protos are appended here.
        count: Single-element list used as a mutable integer to track the total
            number of leaf fields appended across the entire traversal.
    """

    if value is None:
        return

    if isinstance(value, bool):
        _append_attribute(updates_pb2.AttributeUpdate(path=path, bool_value=value), out, count, path)

    elif isinstance(value, int):
        _append_attribute(updates_pb2.AttributeUpdate(path=path, int_value=value), out, count, path)

    elif isinstance(value, float):
        _append_attribute(updates_pb2.AttributeUpdate(path=path, float_value=value), out, count, path)

    elif isinstance(value, str):
        _append_attribute(updates_pb2.AttributeUpdate(path=path, string_value=value), out, count, path)

    elif isinstance(value, dict):
        for key, child in value.items():
            if not _VALID_KEY_RE.match(key):
                raise ValueError(
                    f"Config key {key!r} at path '{path}' contains invalid characters. "
                    "Keys must be non-empty and match [a-zA-Z0-9._-:/]+."
                )
            _flatten_node(child, f"{path}/{key}", out, count)

    elif isinstance(value, list):
        for idx, child in enumerate(value):
            _flatten_node(child, f"{path}/{idx}", out, count)

    elif isinstance(value, (datetime.datetime, datetime.date)):
        str_val = _datetime_to_string(value, path)
        if str_val is not None:
            _append_attribute(updates_pb2.AttributeUpdate(path=path, string_value=str_val), out, count, path)

    elif hasattr(value, "item") and callable(value.item):
        coerced = _coerce_array_scalar(value, path)
        if coerced is not None:
            _flatten_node(coerced, path, out, count)

    else:
        raise TypeError(
            f"Config value at path '{path}' has unsupported type {type(value).__name__!r}. "
            "Supported types: bool, int, float, str, dict, list, None, "
            "datetime.date/datetime, and numpy/torch scalars."
        )


def _datetime_to_string(value: datetime.datetime | datetime.date, path: str) -> str | None:
    """
    Convert a datetime or date value to a string.

    Returns the string representation, or None and emits a warn_once if conversion fails.
    """

    try:
        return str(value)
    except Exception:
        metrana_logging.warn_once(
            f"Failed to convert datetime value at config path '{path}' to string. Skipping.",
            key=f"config_datetime_convert_{path}",
        )
        return None


def _coerce_array_scalar(value: object, path: str) -> bool | int | float | str | None:
    """
    Coerce a numpy/torch scalar to a Python scalar via .item().

    Returns the coerced value if it is a supported leaf type (bool, int, float, str),
    or None and emits a warn_once if .item() raises or yields an unsupported type.
    """

    try:
        coerced = value.item()  # type: ignore
    except Exception:
        metrana_logging.warn_once(
            f"Failed to coerce scalar at config path '{path}' via .item(). Skipping.",
            key=f"config_scalar_coerce_{path}",
        )
        return None

    if isinstance(coerced, (bool, int, float, str)):
        return coerced

    metrana_logging.warn_once(
        f"Scalar at config path '{path}' coerced to unsupported type "
        f"{type(coerced).__name__!r} via .item(). Skipping.",
        key=f"config_scalar_type_{path}",
    )
    return None


def _append_attribute(
    attr: updates_pb2.AttributeUpdate,
    out: list[updates_pb2.AttributeUpdate],
    count: list[int],
    path: str,
) -> None:
    """
    Append attr to out after incrementing the field count.

    Raises:
        ValueError: If the count exceeds _MAX_CONFIG_FIELDS.
    """

    count[0] += 1
    if count[0] > _MAX_CONFIG_FIELDS:
        raise ValueError(
            f"Config exceeds the maximum of {_MAX_CONFIG_FIELDS} fields "
            f"(exceeded at path '{path}'). Pass a smaller config or omit config."
        )
    out.append(attr)
