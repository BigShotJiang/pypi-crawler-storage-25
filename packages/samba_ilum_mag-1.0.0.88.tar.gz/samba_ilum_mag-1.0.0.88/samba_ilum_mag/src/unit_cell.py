# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


from pymatgen.io.vasp import Poscar
from pymatgen.core import Structure
from pymatgen.analysis.structure_matcher import StructureMatcher


print ("#################################################")
print ("### Type the name of the POSCAR/CONTCAR file: ###")
print ("#################################################") 
name = input ("name: "); name = str(name)
poscar_file = dir_files + '/' + name
print (" ")

#===============================================================
# Checking the possibility of obtaining a smaller cell size. ===
#===============================================================
structure = Poscar.from_file(poscar_file).structure
matcher = StructureMatcher()
reduced_structure = matcher._get_reduced_structure(structure)
#--------------------------------------------
if matcher.fit(structure, reduced_structure):
    print("The current cell is already a primitive/unit cell. No new file was generated.")
else:
    Poscar(reduced_structure).write_file(dir_files + '/' + 'Unit_Cell.vasp')
    print("A smaller unit cell was found and saved as 'Unit_Cell.vasp'.")

