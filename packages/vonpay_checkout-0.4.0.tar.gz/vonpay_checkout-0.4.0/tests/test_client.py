"""Tests for Von Payments Checkout Python SDK."""

import hashlib
import hmac as hmac_mod
import json
import time

import httpx
import pytest

from vonpay.checkout import VonPayCheckout, VonPayError


class TestConstructor:
    def test_accepts_valid_test_key(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client is not None

    def test_accepts_valid_live_key(self):
        client = VonPayCheckout("vp_sk_live_abc123def456")
        assert client is not None

    def test_accepts_publishable_key(self):
        client = VonPayCheckout("vp_pk_test_abc123def456")
        assert client is not None

    def test_rejects_empty_key(self):
        with pytest.raises(ValueError, match="API key is required"):
            VonPayCheckout("")

    def test_rejects_invalid_prefix(self):
        with pytest.raises(ValueError, match="Invalid API key format"):
            VonPayCheckout("sk_live_bad_prefix")


class TestWebhookVerification:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_verify_valid_signature(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client.webhooks.verify_signature(payload, sig, self.SECRET)

    def test_reject_invalid_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"session.succeeded"}', "bad" * 16, self.SECRET
        )

    def test_reject_tampered_payload(self):
        payload = '{"event":"session.succeeded","amount":1499}'
        sig = self._sign(payload)
        tampered = '{"event":"session.succeeded","amount":9999}'
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(tampered, sig, self.SECRET)

    def test_reject_non_hex_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"test"}', "not-hex-at-all!", self.SECRET
        )

    def test_accepts_bytes_payload(self):
        payload = b'{"event":"session.succeeded"}'
        sig = hmac_mod.new(self.SECRET.encode(), payload, hashlib.sha256).hexdigest()
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client.webhooks.verify_signature(payload, sig, self.SECRET)

    def test_rejects_mixed_case_hex(self):
        payload = '{"event":"session.succeeded"}'
        lower = hmac_mod.new(self.SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        upper = lower.upper()
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(payload, upper, self.SECRET)


class TestConstructEvent:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_parses_valid_event(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data)
        sig = self._sign(payload)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        result = client.webhooks.construct_event(payload, sig, self.SECRET, now)
        assert result.event == "session.succeeded"
        assert result.session_id == "session_abc"
        assert result.amount == 1499
        assert result.transaction_id == "txn_xyz"

    def test_rejects_expired_timestamp(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        old = "2020-01-01T00:00:00Z"

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(payload, sig, self.SECRET, old)
        assert exc_info.value.code == "webhook_invalid_signature"
        assert "timestamp" in str(exc_info.value)

    def test_rejects_bad_signature(self):
        payload = '{"event":"session.succeeded"}'
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(
                payload, "a" * 64, self.SECRET, now
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_accepts_bytes_payload(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data).encode()  # bytes
        sig = hmac_mod.new(self.SECRET.encode(), payload, hashlib.sha256).hexdigest()
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        client = VonPayCheckout("vp_sk_test_abc123def456")
        result = client.webhooks.construct_event(payload, sig, self.SECRET, now)
        assert result.session_id == "session_abc"


class TestErrorCodeCatalog:
    """Coverage for the three new ErrorCode members added in 0.1.1/0.1.2."""

    def test_new_members_importable(self):
        # Import-smoke — if the Literal union is wrong at parse time, this fails.
        from vonpay.checkout.types import ErrorCode  # noqa: F401

    def test_vonpay_error_accepts_new_codes(self):
        for code in (
            "merchant_not_onboarded",
            "provider_attestation_failed",
            "provider_charge_failed",
        ):
            err = VonPayError(
                status=403,
                error="e",
                code=code,  # type: ignore[arg-type]
                fix="f",
                docs="d",
            )
            assert err.code == code


class TestConstructEventV2:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign_v2(self, t: int, payload_bytes: bytes) -> str:
        signed = f"{t}.".encode() + payload_bytes
        return hmac_mod.new(
            self.SECRET.encode(), signed, hashlib.sha256
        ).hexdigest()

    def test_parses_valid_v2_event(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data)
        t = int(time.time())
        header = f"t={t},v2={self._sign_v2(t, payload.encode())}"
        result = VonPayCheckout(
            "vp_sk_test_abc123def456"
        ).webhooks.construct_event_v2(payload, header, self.SECRET)
        assert result.event == "session.succeeded"
        assert result.session_id == "session_abc"
        assert result.amount == 1499

    def test_accepts_bytes_payload(self):
        payload = b'{"event":"session.succeeded","sessionId":"s","merchantId":"m","amount":1,"currency":"USD","status":"succeeded","timestamp":"t"}'
        t = int(time.time())
        header = f"t={t},v2={self._sign_v2(t, payload)}"
        result = VonPayCheckout(
            "vp_sk_test_abc123def456"
        ).webhooks.construct_event_v2(payload, header, self.SECRET)
        assert result.session_id == "s"

    def test_rejects_replayed_timestamp(self):
        payload = '{"event":"session.succeeded","sessionId":"s","merchantId":"m","amount":1,"currency":"USD","status":"succeeded","timestamp":"t"}'
        t = int(time.time())
        # Signer signed at time t, but attacker replays with t_new — server will
        # see (t, sig) where HMAC(secret, t.body) doesn't match because attacker
        # can't recompute without the secret. We simulate by swapping t only.
        good_hex = self._sign_v2(t, payload.encode())
        header_replayed = f"t={t + 1},v2={good_hex}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header_replayed, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_malformed_header(self):
        payload = '{"event":"session.succeeded"}'
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, "not-a-valid-header", self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_stale_timestamp(self):
        payload = '{"event":"session.succeeded"}'
        t_old = int(time.time()) - 3600  # 1 hour ago
        header = f"t={t_old},v2={self._sign_v2(t_old, payload.encode())}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_v1_signature_format(self):
        """A bare v1 64-char hex sig passed as the v2 header must be rejected
        — parity with the Node test at client.test.ts TestConstructEventV2."""
        payload = '{"event":"session.succeeded"}'
        v1_hex = hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, v1_hex, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"


class TestReturnSignature:
    SECRET = "ss_test_session_signing_secret"

    def _sign_return(self, params: dict) -> str:
        data = ".".join([
            params["session"],
            params["status"],
            params["amount"],
            params["currency"],
            params.get("transaction_id", ""),
        ])
        return hmac_mod.new(
            self.SECRET.encode(), data.encode(), hashlib.sha256
        ).hexdigest()

    def test_valid_signature(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
            "transaction_id": "txn_xyz",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_valid_without_transaction_id(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_missing_sig(self):
        params = {"session": "abc", "status": "ok", "amount": "1", "currency": "USD"}
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_wrong_secret(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert not VonPayCheckout.verify_return_signature(params, "wrong_secret")

    def test_rejects_tampered_amount(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        params["amount"] = "9999"
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)


class TestErrorReporter:
    """Phase 2 — error_reporter callback contract."""

    SECRET = "vp_sk_test_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

    def test_fires_on_construct_event_signature_failure(self):
        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        client = VonPayCheckout(self.SECRET, error_reporter=reporter)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with pytest.raises(VonPayError):
            client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)
        assert len(calls) == 1
        err, ctx = calls[0]
        assert isinstance(err, VonPayError)
        assert ctx.method == "webhooks.construct_event"
        assert ctx.code == "webhook_invalid_signature"
        assert ctx.status == 401
        assert ctx.sdk_version

    def test_fires_on_construct_event_v2_stale_timestamp(self):
        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        client = VonPayCheckout(self.SECRET, error_reporter=reporter)
        body = json.dumps({"event": "session.succeeded"})
        old_ts = int(time.time()) - 600
        sig = hmac_mod.new(
            self.SECRET.encode(), f"{old_ts}.{body}".encode(), hashlib.sha256
        ).hexdigest()
        with pytest.raises(VonPayError):
            client.webhooks.construct_event_v2(body, f"t={old_ts},v2={sig}", self.SECRET)
        assert len(calls) == 1
        assert calls[0][1].method == "webhooks.construct_event_v2"

    def test_no_op_when_undefined(self):
        client = VonPayCheckout(self.SECRET)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        # Must still raise normally; absence of reporter must not change behavior.
        with pytest.raises(VonPayError):
            client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

    def test_swallows_reporter_throws(self, caplog):
        def bad_reporter(err, ctx):
            raise RuntimeError("integrator's Sentry is broken")

        client = VonPayCheckout(self.SECRET, error_reporter=bad_reporter)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        # Original VonPayError must propagate; reporter throw must not replace it.
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)
        assert any(
            "error_reporter raised" in record.message for record in caplog.records
        )

    def test_static_verify_signature_works_without_client(self):
        # verify_signature is staticmethod; calling on the class continues to
        # work without a client reference (no error_reporter integration).
        from vonpay.checkout.client import _Webhooks

        ok = _Webhooks.verify_signature("hello", "deadbeef" * 8, "any-secret")
        assert ok is False  # invalid sig, but didn't crash

    def _client_with_transport(self, reporter, *, responses, max_retries=0):
        """Build a VonPayCheckout whose underlying httpx.Client uses a
        MockTransport returning the given responses in order. Each response is
        a (status_code, json_body) tuple.
        """
        iter_responses = iter(responses)

        def handler(request: httpx.Request) -> httpx.Response:
            status, body = next(iter_responses)
            return httpx.Response(
                status_code=status,
                json=body,
                headers={"X-Request-Id": "req_test_123"},
            )

        client = VonPayCheckout(self.SECRET, error_reporter=reporter, max_retries=max_retries)
        # Swap the httpx client out for one with our mock transport. Close
        # the original so we don't leak its connection pool.
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_fires_on_non_retryable_4xx(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            responses=[
                (400, {"error": "Bad", "code": "validation_invalid_amount", "fix": "x", "docs": "y"}),
            ],
        )
        with pytest.raises(VonPayError):
            client.sessions.create(amount=-1, currency="USD")
        assert len(calls) == 1
        err, ctx = calls[0]
        assert isinstance(err, VonPayError)
        assert ctx.method == "sessions.create"
        assert ctx.url == "https://checkout.vonpay.com/v1/sessions"  # query stripped
        assert ctx.status == 400
        assert ctx.code == "validation_invalid_amount"
        assert ctx.request_id == "req_test_123"
        assert ctx.attempt == 0

    def test_fires_once_after_retry_exhaustion(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            # 503 is retryable; with max_retries=1 we expect 2 attempts → fire once
            responses=[
                (503, {"error": "down", "code": "internal_error", "fix": "x", "docs": "y"}),
                (503, {"error": "down", "code": "internal_error", "fix": "x", "docs": "y"}),
            ],
            max_retries=1,
        )
        with pytest.raises(VonPayError):
            client.sessions.get("vp_cs_x")
        assert len(calls) == 1
        assert calls[0][1].method == "sessions.get"
        assert calls[0][1].status == 503
        assert calls[0][1].attempt == 1  # final attempt index

    def test_url_strips_query_string(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            responses=[
                (400, {"error": "Bad", "code": "validation_error", "fix": "x", "docs": "y"}),
            ],
        )
        # validate() appends ?dry_run=true. Reporter ctx must NOT include it.
        with pytest.raises(VonPayError):
            client.sessions.validate(amount=-1, currency="USD")
        assert calls[0][1].method == "sessions.validate"
        assert calls[0][1].url == "https://checkout.vonpay.com/v1/sessions"
        assert "dry_run" not in (calls[0][1].url or "")


class TestErrorSelfHeal:
    """Phase 2.5 — VonPayError self-heal helpers (retryable / next_action / llm_hint)."""

    def test_attaches_helpers_synthesized_from_code(self):
        err = VonPayError(
            status=401,
            error="API key is malformed",
            code="auth_invalid_key",
            fix="Check the key",
            docs="https://docs.vonpay.com",
            request_id="req_abc",
        )
        assert err.retryable is False
        assert err.next_action == "rotate_key"
        assert "malformed" in err.llm_hint

    def test_5xx_retryable_codes(self):
        err = VonPayError(
            status=503,
            error="down",
            code="provider_unavailable",
            fix="x",
            docs="y",
        )
        assert err.retryable is True
        assert err.next_action == "wait_and_retry"

    def test_card_decline_is_ignore(self):
        err = VonPayError(
            status=402,
            error="Card declined",
            code="provider_charge_failed",
            fix="x",
            docs="y",
        )
        assert err.retryable is False
        assert err.next_action == "ignore"

    def test_unknown_code_falls_back_to_contact_support(self):
        err = VonPayError(
            status=500,
            error="future error",
            code="future_unknown_code",  # type: ignore[arg-type]
            fix="x",
            docs="y",
        )
        assert err.next_action == "contact_support"
        assert "future_unknown_code" in err.llm_hint

    def test_help_for_function(self):
        from vonpay.checkout import help_for

        h = help_for("rate_limit_exceeded")
        assert h.retryable is True
        assert h.next_action == "wait_and_retry"


class TestDefaultReporter:
    """Phase 2.5 — default error_reporter behaviour when no callback is configured."""

    SECRET = "vp_sk_test_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

    def test_fires_logging_warning_when_no_callback_and_outside_pytest(self, monkeypatch, caplog):
        # Auto-silenced under pytest by the PYTEST_CURRENT_TEST guard. To
        # exercise the FIRES path, temporarily delete that env var.
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
        monkeypatch.delenv("VONPAY_QUIET", raising=False)

        client = VonPayCheckout(self.SECRET)  # no error_reporter — default path
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        assert any("[vonpay]" in rec.message for rec in caplog.records), (
            "default reporter should emit a [vonpay]-prefixed warning when no callback is configured"
        )
        # Structured payload should include code + retryable + next_action
        log_messages = " ".join(rec.message for rec in caplog.records)
        assert "webhook_invalid_signature" in log_messages
        assert "next_action" in log_messages or "retryable" in log_messages

    def test_silenced_under_pytest_auto(self, caplog):
        # Inside pytest (PYTEST_CURRENT_TEST is set automatically by pytest
        # itself), the default reporter must NOT fire. This is the path that
        # protects test runs from log noise.
        client = VonPayCheckout(self.SECRET)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        # Caplog should be empty (or contain only test-framework warnings,
        # not vonpay default-reporter warnings)
        vonpay_warnings = [
            rec for rec in caplog.records if "[vonpay]" in rec.message
        ]
        assert vonpay_warnings == []

    def test_silenced_when_VONPAY_QUIET_set(self, monkeypatch, caplog):
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
        monkeypatch.setenv("VONPAY_QUIET", "1")

        client = VonPayCheckout(self.SECRET)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        vonpay_warnings = [
            rec for rec in caplog.records if "[vonpay]" in rec.message
        ]
        assert vonpay_warnings == []

    def test_explicit_callback_overrides_default(self, monkeypatch, caplog):
        # When an integrator passes an explicit error_reporter, the default
        # logging.warning must NOT fire — only their callback.
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)

        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        client = VonPayCheckout(self.SECRET, error_reporter=reporter)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        assert len(calls) == 1  # explicit reporter fired
        # Default reporter should NOT have fired
        vonpay_warnings = [
            rec for rec in caplog.records if "[vonpay]" in rec.message and "error_reporter raised" not in rec.message
        ]
        assert vonpay_warnings == []
