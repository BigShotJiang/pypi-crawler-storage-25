"""Error types for Von Payments Checkout SDK."""

from __future__ import annotations

from typing import Optional

from vonpay.checkout.error_help import NextAction, help_for
from vonpay.checkout.types import ErrorCode, RateLimitInfo


class VonPayError(Exception):
    """API error with structured error code, fix suggestion, and docs link.

    In addition to the server-emitted ``error`` / ``code`` / ``fix`` / ``docs``,
    this exception carries three SDK-synthesized self-heal helpers derived from
    ``code`` — useful for AI / LLM agents branching on the error:

    * ``retryable``   — ``True`` when retrying may succeed (network / 429 / 5xx).
    * ``next_action`` — programmatic decision-helper:
      ``"fix_input"`` | ``"rotate_key"`` | ``"wait_and_retry"`` |
      ``"contact_support"`` | ``"ignore"``.
    * ``llm_hint``    — 1-3 sentence LLM-friendly diagnostic specific to ``code``.
    """

    def __init__(
        self,
        status: int,
        error: str,
        code: ErrorCode,
        fix: str,
        docs: str,
        request_id: Optional[str] = None,
        rate_limit: Optional[RateLimitInfo] = None,
    ) -> None:
        super().__init__(error)
        self.status = status
        self.code = code
        self.fix = fix
        self.docs = docs
        self.request_id = request_id
        self.rate_limit = rate_limit
        help_entry = help_for(code)
        self.retryable: bool = help_entry.retryable
        self.next_action: NextAction = help_entry.next_action
        self.llm_hint: str = help_entry.llm_hint
