"""Error-help mapping table — single source of truth for self-heal hints
attached to VonPayError. Mirrors packages/checkout-node/src/error-help.ts.

`llm_hint` is intentionally 1-3 sentences. Structured for an LLM agent
deciding what to do, NOT for a human reading a stack trace. Human-imperative
remediation lives on `fix`.

`next_action` is the agent's branch table:
  - "fix_input"        — request was malformed; agent must change input before retry
  - "rotate_key"       — key is bad; agent must surface to a human or refresh-key flow
  - "wait_and_retry"   — transient; agent should backoff and retry
  - "contact_support"  — server-side merchant config issue; surface to a human
  - "ignore"           — terminal but expected (card decline, session-already-completed, etc.)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Literal


NextAction = Literal[
    "fix_input",
    "rotate_key",
    "wait_and_retry",
    "contact_support",
    "ignore",
]


@dataclass(frozen=True)
class ErrorHelp:
    retryable: bool
    next_action: NextAction
    llm_hint: str


ERROR_HELP: Dict[str, ErrorHelp] = {
    "auth_missing_bearer": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The Authorization header is missing. The SDK adds it automatically when "
            "constructed with a valid key — this error implies the SDK was bypassed. "
            "Check the SDK was constructed and that the integrator isn't manually proxying "
            "requests without forwarding the Authorization header."
        ),
    ),
    "auth_invalid_key": ErrorHelp(
        retryable=False,
        next_action="rotate_key",
        llm_hint=(
            "The API key is malformed or does not exist. Three common causes: "
            "(1) the env var that holds the key is unset or misnamed (check VON_PAY_SECRET_KEY), "
            "(2) the key has rotated past its 24h grace window (regenerate at "
            "/dashboard/developers/api-keys), (3) test/live mode mismatch (test keys cannot "
            "hit live endpoints and vice versa). Do NOT retry the same key; it will fail identically."
        ),
    ),
    "auth_key_expired": ErrorHelp(
        retryable=False,
        next_action="rotate_key",
        llm_hint=(
            "The previous key has rotated past its 24h grace window. Surface a 'rotate your "
            "API key' action to the human; the previous key will not work again. New keys are "
            "generated at app.vonpay.com/dashboard/developers/api-keys. Retrying with the same "
            "key will fail identically."
        ),
    ),
    "auth_key_type_forbidden": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "A publishable key (vp_pk_*) was used on a server-only endpoint, OR a sandbox key "
            "was used against live and vice versa. Switch to the secret key (vp_sk_*) for "
            "server calls. Publishable keys are browser-safe but cannot retrieve session "
            "details or process refunds."
        ),
    ),
    "auth_merchant_inactive": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "The merchant account is disabled or suspended. The integrator must contact "
            "Von Payments support — this is not a code-fix issue. Do not retry; surface a "
            "clear support-contact message to the human."
        ),
    ),
    "auth_service_unavailable": ErrorHelp(
        retryable=True,
        next_action="wait_and_retry",
        llm_hint=(
            "The authentication service is transiently unavailable. The SDK will already "
            "auto-retry on this; if you're seeing this exposed, retry has been exhausted. "
            "Wait 30-60 seconds and retry; if the failure persists for >5 min, escalate."
        ),
    ),
    "session_not_found": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The session ID does not exist. Check that the ID is being passed correctly "
            "(no truncation, no URL-encoding double-trip) and that the key being used is for "
            "the same merchant that created the session. Session IDs are merchant-scoped."
        ),
    ),
    "session_expired": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The session passed its 30-minute TTL. Create a new session with sessions.create() "
            "using the original parameters. Sessions cannot be extended; the merchant must call "
            "sessions.create() afresh."
        ),
    ),
    "session_wrong_state": ErrorHelp(
        retryable=False,
        next_action="ignore",
        llm_hint=(
            "The session is in a state that disallows this operation (e.g., trying to retrieve "
            "a session that's already completed). Treat as terminal; surface the current "
            "session state to the user instead of retrying."
        ),
    ),
    "session_integrity_error": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "Internal session state is inconsistent — a 500-class server bug. Capture the "
            "request_id from the error and report to Von Payments support. Do not retry; the "
            "corrupt state will not self-heal."
        ),
    ),
    "validation_error": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "Request body failed schema validation. The error message will name the failing "
            "field. Fix the field shape (correct type, length, format) before retrying. Common: "
            "amount as string instead of integer; currency lowercase instead of ISO 4217 uppercase."
        ),
    ),
    "validation_missing_field": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "A required field is missing from the request body. The error message will name the "
            "missing field. Add it to the request and retry. Don't include None — omit the key "
            "entirely or supply a real value."
        ),
    ),
    "validation_invalid_amount": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "Amount is not a positive integer or exceeds maximum. Two pitfalls: (1) sending in "
            "major units (e.g., 14.99 for $14.99 — must be 1499 in minor units), (2) sending "
            "negative or zero. The amount must be a positive integer in the smallest currency "
            "unit (cents for USD, pence for GBP, etc.)."
        ),
    ),
    "merchant_not_configured": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "The merchant is missing required configuration (e.g., payment provider credentials "
            "are not bound). The integrator cannot fix this from the API; surface a 'contact "
            "your account manager' action. The fix is on the merchant-app side."
        ),
    ),
    "merchant_not_onboarded": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "The merchant application is pending_approval or denied — live-key creation is "
            "blocked. The merchant must complete KYC + contract review before live keys can be "
            "used. For sandbox/test mode, the merchant should already have access; if seeing "
            "this on a test key, escalate."
        ),
    ),
    "rate_limit_exceeded": ErrorHelp(
        retryable=True,
        next_action="wait_and_retry",
        llm_hint=(
            "Per-IP rate limit exceeded (10 req/60s on POST /v1/sessions). Read the Retry-After "
            "header and back off accordingly. The SDK auto-retries with exponential backoff; if "
            "seeing this exposed, retries are exhausted. Wait the full Retry-After window, do "
            "NOT retry sooner."
        ),
    ),
    "rate_limit_exceeded_per_key": ErrorHelp(
        retryable=True,
        next_action="wait_and_retry",
        llm_hint=(
            "Per-API-key rate limit (30 session-creates/min). For high-throughput integrators, "
            "contact support for a higher ceiling — DO NOT work around by rotating keys (that "
            "creates more problems). Wait the Retry-After window and retry."
        ),
    ),
    "provider_unavailable": ErrorHelp(
        retryable=True,
        next_action="wait_and_retry",
        llm_hint=(
            "The upstream payment provider is not responding. The SDK auto-retries with backoff; "
            "if seeing this exposed, retries are exhausted. Wait 30-60 seconds. If the issue "
            "persists across multiple sessions, the underlying provider may be having an "
            "incident — check the Von Payments status page."
        ),
    ),
    "provider_attestation_failed": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The payment provider rejected the browser-side token (Vora attestation handoff "
            "failed). This usually means the buyer's browser session expired or the token was "
            "tampered with. Have the buyer restart the checkout session; do not retry the "
            "same session."
        ),
    ),
    "provider_charge_failed": ErrorHelp(
        retryable=False,
        next_action="ignore",
        llm_hint=(
            "The card was declined or the charge was rejected by the upstream provider. This "
            "is a buyer-side outcome (insufficient funds, card blocked, etc.), not an "
            "integration bug. Show the decline UI; do not retry the same payment."
        ),
    ),
    "internal_error": ErrorHelp(
        retryable=True,
        next_action="wait_and_retry",
        llm_hint=(
            "Unexpected server error on Von Payments side. Capture the request_id and retry "
            "once with backoff; if persistent, report to support with the request_id."
        ),
    ),
    "webhook_missing_signature": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The webhook request is missing the X-VonPay-Signature header. Real Von Payments "
            "webhooks always carry this header; if you're seeing this, either (1) a non-Vonpay "
            "caller is hitting your webhook URL, OR (2) a proxy/middleware is stripping the "
            "header. Check your reverse proxy config — Cloudflare and AWS API Gateway sometimes "
            "strip x-* headers without a config rule."
        ),
    ),
    "webhook_invalid_signature": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "Webhook HMAC verification failed. Three common causes ranked by frequency: "
            "(1) using the wrong secret — the SDK expects your API key (vp_sk_*) NOT a separate "
            "webhook secret, (2) the body was JSON-parsed before signature verification (must "
            "use the RAW body bytes, not re-stringified JSON), (3) the timestamp is outside "
            "the 5-minute replay window. Check the SDK call passes request.body / request.data "
            "in raw form."
        ),
    ),
    "webhook_not_configured": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "Webhook verification secret is not configured on the server side — a Von Payments "
            "operational issue. Contact support with the request_id. Don't retry; the config "
            "has to be fixed before any webhook will verify."
        ),
    ),
    "origin_forbidden": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "The request origin is not in the merchant's allowed origins list. Add the calling "
            "origin (your app's URL) to the merchant's CORS allowlist at "
            "app.vonpay.com/dashboard/developers/origins. Do not bypass via server-side proxy "
            "as a fix; configure the origin properly."
        ),
    ),
    "transaction_verification_failed": ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            "The transaction could not be verified with the payment provider — usually a "
            "reconciliation failure between Von Payments and the upstream processor. Capture "
            "the request_id and contact support; this is not a retry-can-fix issue."
        ),
    ),
    "unsupported_media_type": ErrorHelp(
        retryable=False,
        next_action="fix_input",
        llm_hint=(
            "Content-Type header is missing or not application/json. The SDK sets this "
            "automatically; if seeing this, an HTTP middleware is rewriting the header. Check "
            "your reverse proxy / API gateway is not stripping or transforming Content-Type."
        ),
    ),
}


def help_for(code: str) -> ErrorHelp:
    """Return the help entry for a given ErrorCode. Returns a fallback for unknown codes."""
    entry = ERROR_HELP.get(code)
    if entry is not None:
        return entry
    return ErrorHelp(
        retryable=False,
        next_action="contact_support",
        llm_hint=(
            f'Unknown error code "{code}". This may indicate a newer server version than '
            f"this SDK supports — upgrade vonpay-checkout to the latest, or capture the full "
            f"error response and contact support."
        ),
    )
