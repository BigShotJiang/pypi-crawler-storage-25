﻿"""CLI module for shibaclaw."""
