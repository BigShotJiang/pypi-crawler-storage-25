# model

::: torchcrop.model
