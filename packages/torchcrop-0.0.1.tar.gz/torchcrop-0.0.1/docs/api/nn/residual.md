# residual

::: torchcrop.nn.residual
