# partitioning

::: torchcrop.processes.partitioning
