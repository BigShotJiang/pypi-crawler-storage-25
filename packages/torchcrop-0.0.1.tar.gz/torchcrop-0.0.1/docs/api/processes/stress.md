# stress

::: torchcrop.processes.stress
