# photosynthesis

::: torchcrop.processes.photosynthesis
