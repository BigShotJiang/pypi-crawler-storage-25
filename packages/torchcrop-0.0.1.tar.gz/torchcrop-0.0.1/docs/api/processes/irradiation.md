# irradiation

::: torchcrop.processes.irradiation
