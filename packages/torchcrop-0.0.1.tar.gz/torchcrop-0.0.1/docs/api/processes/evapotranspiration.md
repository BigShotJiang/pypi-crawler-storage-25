# evapotranspiration

::: torchcrop.processes.evapotranspiration
