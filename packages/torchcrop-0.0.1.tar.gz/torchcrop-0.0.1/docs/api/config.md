# config

::: torchcrop.config
