"""Command `bytinho next` — shows what's closest to unlocking.

Simple client-side heuristic: takes XP missing for next stage,
the next streak milestone, and up to 3 achievements not yet unlocked.
"""
from __future__ import annotations

import typer
from rich.panel import Panel
from rich.text import Text

from .. import client
from ..pet_logic import (
    STAGE_LABEL,
    next_stage,
    next_streak_milestone,
    xp_to_next,
)
from ..render import console


# Espelha CATALOG do server (achievements.py) — versões "achievables" só,
# ordenadas grosseiramente por dificuldade crescente.
_HINTS: dict[str, tuple[str, str]] = {
    "first_commit":     ("🌱", "make your first commit"),
    "early_bird":       ("🌅", "commit between 5h and 7h"),
    "night_owl":        ("🦉", "commit between 0h and 5h"),
    "weekend_warrior":  ("🛡️", "commit on Saturday or Sunday"),
    "doc_lover":        ("📚", "1 commit touching only .md files"),
    "polyglot":         ("💬", "send a message in the global chat"),
    "polyglot_real":    ("🐍", "commits in 3+ different languages"),
    "friday_shipper":   ("🌉", "feat: on a Friday"),
    "streak_3":         ("🔥", "3 days in a row committing"),
    "streak_7":         ("🔥", "7 days in a row"),
    "refactor_king":    ("🧹", "5 commits starting with refactor:"),
    "bug_hunter":       ("🐛", "10 commits starting with fix:"),
    "surgeon":          ("🎯", "10 surgical commits (<10 lines)"),
    "big_bang":         ("💥", "1 commit with 500+ lines"),
    "feature_factory":  ("🏭", "20 commits starting with feat:"),
    "streak_30":        ("🏆", "30 days in a row"),
}


def _next_stage_text(pet: dict) -> str | None:
    stage = pet.get("stage")
    xp = pet.get("xp", 0)
    nxt = next_stage(stage)
    if nxt is None:
        return None
    falta = xp_to_next(xp, stage) or 0
    label = STAGE_LABEL.get(nxt, nxt)
    if falta <= 0:
        return f"✨  about to evolve into [bold]{label}[/bold] (next commit triggers)"
    return f"✨  to evolve into [bold]{label}[/bold]: [bold]{falta} XP[/bold] missing"


def _next_streak_text(streak: dict | None) -> str | None:
    if not streak:
        return None
    days = int(streak.get("days") or 0)
    nxt = next_streak_milestone(days)
    if nxt is None:
        return None
    return f"🔥  [bold]{nxt - days} days[/bold] left for a {nxt}-day streak"


def _next_achievements(unlocked: list[dict]) -> list[str]:
    unlocked_codes = {a.get("code") for a in unlocked}
    rest = [(ic, hint) for code, (ic, hint) in _HINTS.items()
            if code not in unlocked_codes]
    return [f"{ic}  {hint}" for ic, hint in rest[:3]]


def register(app: typer.Typer) -> None:
    @app.command("next")
    def next_cmd():
        """Show what you can unlock today."""
        data = client.sync()
        if not data:
            console.print("[red]✗ The Core offline. try again in a bit.[/red]")
            raise typer.Exit(1)
        pet = data["pet"]
        streak = data["user"].get("streak") or {}
        achs = client.my_achievements()

        lines: list[str] = []
        s = _next_stage_text(pet)
        if s:
            lines.append(s)
        st = _next_streak_text(streak)
        if st:
            lines.append(st)
        lines.extend(_next_achievements(achs))

        if not lines:
            body = Text.from_markup(
                "[dim]nothing on the horizon. you're already a legend.[/dim]"
            )
        else:
            body = Text.from_markup("\n".join(lines))

        console.print(Panel(
            body,
            title="🎯 perto de desbloquear",
            border_style="bright_magenta",
        ))
