"""Shim de compatibilidade — UI agora vive em bytinho.talk_ui."""
from ..talk_ui import render_talk, render_talk_quiet, render_idle_whisper  # noqa: F401
