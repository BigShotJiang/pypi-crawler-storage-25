"""Identity commands: nick, rename, export, import."""
import typer

from .. import client, prefs
from ..render import console, live_for, refresh
from ..session import set_user_id, user_id


def register(app: typer.Typer) -> None:
    @app.command()
    def nick(name: str = typer.Argument(...)):
        """Set your global nick."""
        ok, msg = client.set_nick(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ nick: {name}[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)

    @app.command()
    def rename(name: str = typer.Argument(..., help="New name for your pet.")):
        """Give your Bytinho a custom name."""
        ok, msg = client.rename_pet(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ pet renamed: {name}[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, seconds=2.0, fps=6.0, streak=streak, toasts=toasts)

    @app.command("export")
    def export_cmd():
        """Show your recovery code (use with `import` on another machine)."""
        uid = user_id()
        console.print()
        console.print("[bold magenta]🔑  Bytinho recovery code:[/bold magenta]")
        console.print()
        console.print(f"   [bold cyan]{uid}[/bold cyan]")
        console.print()
        console.print("[dim]Keep this safe. Whoever has this code OWNS your pet.[/dim]")
        console.print("[dim]On another machine run:[/dim]")
        console.print(f"[dim]   bytinho import {uid}[/dim]")
        console.print()

    @app.command("import")
    def import_cmd(code: str = typer.Argument(..., help="Recovery code (UUID).")):
        """Import a pet from another machine using its recovery code."""
        ok, msg = set_user_id(code)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ identity restored: {msg[:8]}…[/green]")
        pet, h, nick_, streak, toasts = refresh()
        live_for(pet, h, nick_, msg="welcome back 💜", seconds=3.0, fps=6.0,
                 streak=streak, toasts=toasts)

    @app.command("persona")
    def persona_cmd(
        name: str = typer.Argument(
            None,
            help="Persona name. Empty = show current and options.",
        ),
        reset: bool = typer.Option(False, "--reset", help="Reset to server persona."),
    ):
        """Choose Bytinho's tone. 100% local override — never sent to server."""
        if reset:
            prefs.reset_persona()
            console.print("[green]✓ persona reset — using server persona[/green]")
            return
        if not name:
            current = prefs.get_persona()
            console.print()
            if current:
                console.print(f"[bold]current persona (local override):[/bold] [cyan]{current}[/cyan]")
            else:
                console.print("[dim]no override — using server persona[/dim]")
            console.print()
            console.print("[bold]available:[/bold]")
            for p in prefs.PERSONAS:
                console.print(f"  · [cyan]{p}[/cyan]")
            console.print()
            console.print("[dim]usage:  bytinho persona minimalist[/dim]")
            return
        ok, msg = prefs.set_persona(name)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ persona: {msg}[/green]")
