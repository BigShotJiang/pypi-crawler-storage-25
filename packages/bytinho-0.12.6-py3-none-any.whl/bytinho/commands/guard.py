"""bytinho commit-guard — pre-commit hook inteligente.

Bloqueia commits com:
  - Secrets prováveis (AWS keys, tokens, JWT, .env, private keys)
  - Debug leftovers (console.log, print(, debugger, pdb.set_trace)
  - TODO/FIXME sem ticket
  - Arquivos perigosos (.env, *.pem, id_rsa)

100% offline. Sem IA. Determinístico.

Uso:
  bytinho commit-guard install     # registra .git/hooks/pre-commit
  bytinho commit-guard run         # roda manualmente nos staged
  bytinho commit-guard run --all   # roda no working tree todo
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

console = Console()

# ── regras ────────────────────────────────────────────────────────────────

@dataclass
class Rule:
    name: str
    pattern: re.Pattern
    severity: str  # "block" | "warn"
    msg: str

RULES: list[Rule] = [
    # ── BLOCK ─────────────────────────────────────────────────────────────
    # AWS Access Key: 20 chars, AKIA prefix, word boundaries para evitar
    # match dentro de hashes longos.
    Rule("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
         "block", "AWS Access Key ID detectada"),
    # AWS Secret: aceita = ou : (JSON/yaml/ini), 40 chars base64-like.
    Rule("aws-secret",     re.compile(r"aws_secret_access_key\s*[:=]\s*[\"']?[A-Za-z0-9/+=]{40}[\"']?", re.I),
         "block", "AWS Secret Key detectada"),
    # GitHub: ghp_/ghs_/gho_/ghu_/ghr_ + 36 chars exatos, word-bounded.
    Rule("github-token",   re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36}\b"),
         "block", "GitHub token detectado"),
    # OpenAI: sk- + 40+ chars (era 20+ → false positive em CSS sk-button etc).
    Rule("openai-key",     re.compile(r"\bsk-[A-Za-z0-9]{40,}\b"),
         "block", "OpenAI/Anthropic-style API key"),
    Rule("private-key",    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
         "block", "Chave privada PEM detectada"),
    Rule("jwt-token",      re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
         "block", "JWT token literal detectado"),
    # Password: filtragem extra de placeholders em _is_obvious_placeholder().
    Rule("password-literal", re.compile(r"""\b(password|passwd|pwd)\s*[:=]\s*["'][^"'\n]{4,}["']""", re.I),
         "block", "Password literal hardcoded"),
    # debugger; sozinho na linha (evita match em strings/comentários casuais).
    Rule("debugger-js",    re.compile(r"^\s*debugger\s*;?\s*$", re.M),
         "block", "debugger; esquecido"),
    # pdb.set_trace() / breakpoint() — exige parênteses fechados.
    Rule("pdb-trace",      re.compile(r"\b(?:pdb\.set_trace|breakpoint)\s*\(\s*\)"),
         "block", "breakpoint() / pdb.set_trace() esquecido"),
    # ── WARN ──────────────────────────────────────────────────────────────
    Rule("console-log",    re.compile(r"\bconsole\.log\s*\("),
         "warn", "console.log esquecido"),
    Rule("python-print",   re.compile(r"^\s*print\s*\(", re.M),
         "warn", "print() em código (use logging?)"),
    Rule("todo-no-ticket", re.compile(r"(?:#|//)\s*(?:TODO|FIXME)\b(?!\s*[:(\-]\s*[A-Z]+-\d+)"),
         "warn", "TODO/FIXME sem ticket (ex: TODO BTN-123)"),
]

# Regras com escopo restrito a tipos de arquivo. Default: aplica a todos.
RULE_SCOPES: dict[str, set[str]] = {
    "console-log": {".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".mjs", ".cjs"},
    "python-print": {".py"},
    "debugger-js": {".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".mjs", ".cjs"},
    "pdb-trace": {".py"},
}

# Caminhos onde print()/console.log são esperados → silencia warns ruidosos.
# Mantém blocks (secrets, debugger). Só silencia warns nesses contextos.
NOISY_PATH_PATTERNS = (
    re.compile(r"(^|/)tests?/"),
    re.compile(r"(^|/)test_[^/]+\.py$"),
    re.compile(r"_test\.(py|ts|js|tsx|jsx)$"),
    re.compile(r"(^|/)scripts?/"),
    re.compile(r"(^|/)examples?/"),
    re.compile(r"(^|/)demo[^/]*\.(py|sh)$"),
    re.compile(r"__main__\.py$"),
    re.compile(r"(^|/)cli/"),  # CLIs usam print/click.echo legitimamente
)
NOISY_RULES = {"console-log", "python-print", "todo-no-ticket"}

# Documentos: skip total. Exemplos em docs não são leaks.
DOC_SUFFIXES = {".md", ".rst", ".txt", ".adoc"}

# Placeholders óbvios em password-literal → ignora.
_PLACEHOLDER_RE = re.compile(
    r"^(?:"
    r"\$\{?[A-Z_]+\}?"           # ${VAR} ou $VAR
    r"|<[^>]+>"                  # <your-password>
    r"|\{\{?[a-z_]+\}?\}?"       # {{var}} ou {var}
    r"|x{3,}"                    # xxxxx
    r"|\*{3,}"                   # *****
    r"|password|passwd|pwd|secret|todo|changeme|placeholder|example|test"
    r"|hunter2|admin|root|none|null|true|false|yourpassword|yourpasswordhere"
    r")$",
    re.I,
)

# Ignore markers — reconhece em qualquer comment style (#, //, /*, <!--, --).
IGNORE_FILE_RE = re.compile(
    r"(?:#|//|/\*|<!--|--)\s*bytinho-guard\s*:\s*ignore-file\b", re.I,
)
IGNORE_LINE_RE = re.compile(
    r"(?:#|//|/\*|<!--|--)\s*bytinho-guard\s*:\s*ignore-line\b", re.I,
)
IGNORE_NEXT_RE = re.compile(
    r"(?:#|//|/\*|<!--|--)\s*bytinho-guard\s*:\s*ignore-next\b", re.I,
)

DANGEROUS_FILES = {".env", ".env.local", "id_rsa", "id_ed25519"}
DANGEROUS_SUFFIXES = {".pem", ".key", ".p12"}

# Não escaneia binários/lockfiles/etc.
SKIP_SUFFIXES = {
    ".lock", ".min.js", ".min.css", ".png", ".jpg", ".jpeg", ".gif",
    ".webp", ".ico", ".pdf", ".zip", ".tar", ".gz", ".woff", ".woff2",
    ".ttf", ".otf", ".pyc", ".so", ".dylib", ".dll", ".class",
}
SKIP_DIRS = {"node_modules", ".git", "dist", "build", ".venv", "venv",
             "__pycache__", ".next", ".turbo", "target"}


@dataclass
class Hit:
    file: str
    line: int
    rule: str
    severity: str
    snippet: str


# ── core ──────────────────────────────────────────────────────────────────

def _staged_files() -> list[Path]:
    out = subprocess.run(
        ["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"],
        capture_output=True, text=True, check=False,
    )
    return [Path(p) for p in out.stdout.splitlines() if p.strip()]


def _all_files() -> list[Path]:
    out = subprocess.run(
        ["git", "ls-files"], capture_output=True, text=True, check=False
    )
    return [Path(p) for p in out.stdout.splitlines() if p.strip()]


def _read_staged_blob(path: Path) -> str | None:
    """Retorna o conteúdo do arquivo EXATAMENTE como será commitado.

    Usa `git show :path` que lê do index (blob staged), não do working tree.
    Crítico: se o dev `git add` algo e depois mudou no disco, queremos
    bloquear o que está no index, não o que está no disco.
    """
    res = subprocess.run(
        ["git", "show", f":{path.as_posix()}"],
        capture_output=True, check=False,  # bytes, não text
    )
    if res.returncode != 0:
        return None
    try:
        return res.stdout.decode("utf-8", errors="replace")
    except (UnicodeDecodeError, AttributeError):
        return None


def _should_skip(p: Path) -> bool:
    if any(part in SKIP_DIRS for part in p.parts):
        return True
    if p.suffix.lower() in SKIP_SUFFIXES:
        return True
    return False


def _is_obvious_placeholder(snippet: str) -> bool:
    """Verifica se o valor entre aspas é placeholder, não senha real."""
    m = re.search(r"""["']([^"'\n]+)["']\s*$""", snippet)
    if not m:
        # tentativa mais frouxa: pega último grupo entre aspas na linha
        m = re.search(r"""["']([^"'\n]+)["']""", snippet)
    if not m:
        return False
    value = m.group(1).strip()
    return bool(_PLACEHOLDER_RE.match(value))


def _is_noisy_path(path: Path) -> bool:
    s = path.as_posix()
    return any(rx.search(s) for rx in NOISY_PATH_PATTERNS)


def _scan_text(text: str, path: Path) -> list[Hit]:
    """Aplica todas as regras a um texto já lido. Pure function.

    Respeita ignore markers:
      - `# bytinho-guard: ignore-file` nas primeiras 5 linhas → skip total
      - `# bytinho-guard: ignore-line` na mesma linha do hit → skip hit
      - `# bytinho-guard: ignore-next` na linha anterior → skip hit
    """
    if len(text) > 1_000_000:  # 1MB cap
        return []
    if path.suffix.lower() in DOC_SUFFIXES:
        return []

    lines = text.splitlines()

    # ignore-file: pode aparecer em qualquer das primeiras 5 linhas (shebang etc)
    for line in lines[:5]:
        if IGNORE_FILE_RE.search(line):
            return []

    # pre-compute linhas com markers para lookup O(1)
    ignore_line_set = {i + 1 for i, ln in enumerate(lines) if IGNORE_LINE_RE.search(ln)}
    ignore_next_from = {i + 2 for i, ln in enumerate(lines) if IGNORE_NEXT_RE.search(ln)}

    suffix = path.suffix.lower()
    noisy = _is_noisy_path(path)

    hits: list[Hit] = []
    for rule in RULES:
        # Scope check: regra restrita a certos suffixes?
        scope = RULE_SCOPES.get(rule.name)
        if scope is not None and suffix not in scope:
            continue
        # Silencia warns ruidosos em paths de teste/script/cli
        if noisy and rule.name in NOISY_RULES:
            continue

        for m in rule.pattern.finditer(text):
            line_no = text[: m.start()].count("\n") + 1
            # ignore markers
            if line_no in ignore_line_set or line_no in ignore_next_from:
                continue
            snippet = lines[line_no - 1] if line_no <= len(lines) else ""
            # password-literal: filtra placeholders óbvios
            if rule.name == "password-literal" and _is_obvious_placeholder(snippet):
                continue
            hits.append(Hit(
                file=str(path), line=line_no, rule=rule.name,
                severity=rule.severity, snippet=snippet.strip()[:80],
            ))
    return hits


def _scan_path(p: Path) -> list[Hit]:
    """Lê do disco e escaneia. Usado em --all (working tree)."""
    if not p.exists() or not p.is_file() or _should_skip(p):
        return []
    try:
        text = p.read_text("utf-8", errors="replace")
    except OSError:
        return []
    return _scan_text(text, p)


def _scan_staged(p: Path) -> list[Hit]:
    """Lê o blob staged (git index) e escaneia. Usado em pre-commit."""
    if _should_skip(p):
        return []
    text = _read_staged_blob(p)
    if text is None:
        return []
    return _scan_text(text, p)


def _scan_dangerous(files: list[Path]) -> list[Hit]:
    hits: list[Hit] = []
    for p in files:
        if p.name in DANGEROUS_FILES or p.suffix in DANGEROUS_SUFFIXES:
            hits.append(Hit(
                file=str(p), line=0, rule="dangerous-file",
                severity="block",
                snippet="arquivo sensível não deve ser comitado",
            ))
    return hits


def scan(files: list[Path], *, staged: bool = False) -> list[Hit]:
    """Escaneia arquivos. Quando staged=True, lê do git index (pre-commit)."""
    hits: list[Hit] = []
    hits.extend(_scan_dangerous(files))
    reader = _scan_staged if staged else _scan_path
    for f in files:
        hits.extend(reader(f))
    return hits


# ── reporting ─────────────────────────────────────────────────────────────

def _report(hits: list[Hit]) -> int:
    blocks = [h for h in hits if h.severity == "block"]
    warns  = [h for h in hits if h.severity == "warn"]

    if not hits:
        console.print("[bold green]✓ commit-guard: limpo[/bold green]")
        return 0

    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("sev", width=6)
    table.add_column("regra")
    table.add_column("local")
    table.add_column("trecho", overflow="fold")
    for h in hits:
        sev = "[red]BLOCK[/red]" if h.severity == "block" else "[yellow]warn[/yellow]"
        loc = f"{h.file}:{h.line}" if h.line else h.file
        table.add_row(sev, h.rule, loc, h.snippet or "—")
    console.print(table)

    if blocks:
        console.print(
            f"\n[bold red]✗ {len(blocks)} bloqueio(s)[/bold red] · "
            f"{len(warns)} aviso(s)"
        )
        console.print(
            "[dim]Para forçar (NÃO recomendado): git commit --no-verify[/dim]"
        )
        return 1
    console.print(f"\n[yellow]⚠ {len(warns)} aviso(s)[/yellow] · sem bloqueios")
    return 0  # warns não bloqueiam


# ── click ─────────────────────────────────────────────────────────────────

guard_app = typer.Typer(no_args_is_help=True, help="Pre-commit hook inteligente (offline).")


@guard_app.command("run")
def run_cmd(
    all_files: bool = typer.Option(
        False, "--all", help="Escaneia todos os arquivos do repo, não só staged."
    ),
) -> None:
    """Roda os checks. Exit 1 se houver block, 0 caso contrário."""
    files = _all_files() if all_files else _staged_files()
    if not files:
        console.print("[dim]nada staged.[/dim]")
        raise typer.Exit(0)
    # staged=True quando rodando como pre-commit hook (lê blob do index,
    # não working tree). --all usa working tree (verificação manual).
    raise typer.Exit(_report(scan(files, staged=not all_files)))


def _resolve_bytinho_invocation() -> str:
    """Retorna a invocação certa pra usar no hook git.

    Prioridade:
      1. Caminho absoluto do binário `bytinho` (resolvido via shutil.which).
      2. `python -m bytinho` usando o sys.executable atual.

    Garantia: o hook funciona mesmo quando o PATH do shell de hooks (GUI git,
    SourceTree, GitHub Desktop, husky) não inclui ~/.local/bin.
    """
    abs_path = shutil.which("bytinho")
    if abs_path:
        return abs_path
    # Fallback: roda via módulo python. Captura o python que instalou o pacote.
    return f"{sys.executable} -m bytinho"


@guard_app.command("install")
def install_cmd(
    force: bool = typer.Option(False, "--force", help="Sobrescreve hook existente."),
) -> None:
    """Instala como .git/hooks/pre-commit no repo atual."""
    git_root = subprocess.run(
        ["git", "rev-parse", "--git-dir"], capture_output=True, text=True, check=False,
    )
    if git_root.returncode != 0:
        console.print("[red]Não é um repositório git.[/red]")
        raise typer.Exit(1)

    hook = Path(git_root.stdout.strip()) / "hooks" / "pre-commit"
    invocation = _resolve_bytinho_invocation()
    new_content = (
        "#!/usr/bin/env bash\n"
        "# Installed by bytinho commit-guard install\n"
        "# https://bytinho.com\n"
        f"exec {invocation} commit-guard run\n"
    )

    if hook.exists():
        existing = hook.read_text("utf-8", errors="replace")
        is_ours = "Installed by bytinho commit-guard" in existing
        if is_ours:
            if existing == new_content:
                console.print(
                    f"[dim]✓ já instalado e atualizado:[/dim] {hook}"
                )
                return
            # mesmo origem, mas conteúdo diferente (ex: novo invocation path)
            hook.write_text(new_content, "utf-8")
            hook.chmod(0o755)
            console.print(f"[green]✓ atualizado:[/green] {hook}")
            return
        if not force:
            console.print(
                f"[yellow]⚠ já existe um hook pre-commit em[/yellow] {hook}\n"
                "[dim]Use --force pra sobrescrever, ou edite manualmente:[/dim]\n"
                f"  exec {invocation} commit-guard run"
            )
            raise typer.Exit(1)
        # backup antes do force
        backup = hook.with_name(hook.name + ".bak")
        backup.write_text(existing, "utf-8")
        console.print(f"[dim]backup:[/dim] {backup}")

    hook.parent.mkdir(parents=True, exist_ok=True)
    hook.write_text(new_content, "utf-8")
    hook.chmod(0o755)
    console.print(f"[green]✓ instalado:[/green] {hook}")
    console.print(f"[dim]invoca:[/dim] {invocation} commit-guard run")


@guard_app.command("uninstall")
def uninstall_cmd() -> None:
    """Remove o hook pre-commit do bytinho (se foi instalado por nós)."""
    git_root = subprocess.run(
        ["git", "rev-parse", "--git-dir"], capture_output=True, text=True, check=False,
    )
    if git_root.returncode != 0:
        console.print("[red]Não é um repositório git.[/red]")
        raise typer.Exit(1)
    hook = Path(git_root.stdout.strip()) / "hooks" / "pre-commit"
    if not hook.exists():
        console.print("[dim]nenhum hook pre-commit encontrado.[/dim]")
        return
    content = hook.read_text("utf-8", errors="replace")
    if "Installed by bytinho commit-guard" not in content:
        console.print(
            "[yellow]⚠ hook existe mas não foi instalado pelo bytinho.[/yellow]\n"
            "[dim]Não vou remover. Edite manualmente se quiser.[/dim]"
        )
        raise typer.Exit(1)
    hook.unlink()
    console.print(f"[green]✓ removido:[/green] {hook}")


@guard_app.command("list-rules")
def list_rules() -> None:
    """Lista todas as regras ativas."""
    table = Table(show_header=True, header_style="bold")
    table.add_column("regra"); table.add_column("severidade"); table.add_column("descrição")
    for r in RULES:
        table.add_row(r.name, r.severity, r.msg)
    console.print(table)


def register(app: typer.Typer) -> None:
    app.add_typer(guard_app, name="commit-guard")
