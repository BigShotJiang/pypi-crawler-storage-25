"""`bytinho stats` — gráfico ASCII de XP/dia + meta pro próximo estágio."""
from __future__ import annotations

import typer

from .. import client
from ..pet_logic import STAGE_LABEL
from ..render import console


# Caracteres ▁▂▃▄▅▆▇█ (Unicode block lower 1/8 → 8/8). Sparkline clássico.
_SPARK = "▁▂▃▄▅▆▇█"


def _sparkline(values: list[int]) -> str:
    if not values:
        return ""
    peak = max(values)
    if peak == 0:
        return "·" * len(values)
    out = []
    for v in values:
        if v == 0:
            out.append("·")
            continue
        idx = int((v / peak) * (len(_SPARK) - 1))
        out.append(_SPARK[idx])
    return "".join(out)


def register(app: typer.Typer) -> None:
    @app.command("stats")
    def stats_cmd():
        """Mostra XP por dia (30d) e quanto falta pro próximo estágio."""
        data = client.stats()
        if data is None:
            console.print("[red]✗ The Core offline.[/red]")
            raise typer.Exit(1)

        pet  = data.get("pet") or {}
        nxt  = data.get("next_stage")
        days = data.get("daily_xp") or []
        week_ach = data.get("achievements_week", 0)

        xp     = pet.get("xp", 0)
        stage  = pet.get("stage", "?")
        label  = STAGE_LABEL.get(stage, stage)

        # cabeçalho
        console.print()
        console.print(f"[bold cyan]📊 stats for @you[/bold cyan]")
        console.print(f"  [dim]xp atual:[/dim] [bold]{xp}[/bold]  ·  "
                      f"[dim]stage:[/dim] [bold]{label}[/bold]")

        # próximo estágio
        if nxt:
            xp_diff = nxt.get("xp_diff", 0)
            n_stage = nxt.get("stage", "?")
            n_label = STAGE_LABEL.get(n_stage, nxt.get("label", n_stage))
            n_emoji = nxt.get("emoji", "")
            console.print(f"  [dim]faltam[/dim] [bold yellow]{xp_diff} XP[/bold yellow] "
                          f"[dim]pra[/dim] {n_emoji} [bold]{n_label}[/bold]")
        else:
            console.print("  [bold magenta]🛸 Living legend.[/bold magenta] no next stage.")

        # sparkline 30d
        xp_per_day = [int(d.get("xp_est", 0)) for d in days]
        commits_total = sum(int(d.get("commits", 0)) for d in days)
        active_days = sum(1 for v in xp_per_day if v > 0)
        if days:
            console.print()
            console.print(f"  [dim]last 30 days:[/dim] {commits_total} commits · "
                          f"{active_days} dias ativos")
            console.print(f"  [cyan]{_sparkline(xp_per_day)}[/cyan]")

        # achievements semana
        console.print()
        if week_ach:
            console.print(f"  [bold]✨ {week_ach}[/bold] [dim]achievement(s) in the last week[/dim]")
        else:
            console.print("  [dim]nenhuma conquista nova essa semana.[/dim]")
        console.print()
