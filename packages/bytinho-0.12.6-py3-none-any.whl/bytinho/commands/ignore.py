"""`bytinho ignore` — opt-out for hook upload (P0-4).

Subcommands:
  bytinho ignore here       create .bytinhoignore in the current repo
  bytinho ignore unhere     remove .bytinhoignore from the current repo
  bytinho ignore add PATH   add path to the global skip-list
  bytinho ignore rm PATH    remove path from the global skip-list
  bytinho ignore list       show current state

No subcommand = `list`.
"""
from __future__ import annotations

import typer

from .. import privacy
from ..render import console


def register(app: typer.Typer) -> None:
    ignore = typer.Typer(
        help="Skip sending commits from selected repo(s).",
        invoke_without_command=True,
        no_args_is_help=False,
    )

    @ignore.callback()
    def _default(ctx: typer.Context):
        if ctx.invoked_subcommand is None:
            _list_impl()

    @ignore.command("here")
    def here():
        """Create .bytinhoignore in the current repo (Bytinho skips forever)."""
        ok, msg = privacy.add_here()
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ skipping this repo:[/green] {msg}")
        console.print(
            "[dim]you can also use [cyan]BYTINHO_SKIP=1 git commit[/cyan] "
            "to skip a single commit.[/dim]"
        )

    @ignore.command("unhere")
    def unhere():
        """Remove .bytinhoignore from the current repo."""
        ok, msg = privacy.rm_here()
        if not ok:
            console.print(f"[yellow]· {msg}[/yellow]")
            return
        console.print(f"[green]✓ re-enabled:[/green] {msg}")

    @ignore.command("add")
    def add(path: str = typer.Argument(..., help="Path of the repo to ignore.")):
        """Add a repo to the global skip-list."""
        ok, msg = privacy.add_global(path)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]✓ in global skip-list:[/green] {msg}")

    @ignore.command("rm")
    def rm(path: str = typer.Argument(..., help="Path to remove from the skip-list.")):
        """Remove a repo from the global skip-list."""
        ok, msg = privacy.rm_global(path)
        if not ok:
            console.print(f"[yellow]· {msg}[/yellow]")
            return
        console.print(f"[green]✓ removed:[/green] {msg}")

    @ignore.command("list")
    def list_cmd():
        """Show current state."""
        _list_impl()

    app.add_typer(ignore, name="ignore")


def _list_impl() -> None:
    items = privacy.list_global()
    skipped, reason = privacy.is_skipped()

    console.print()
    console.print("[bold]Bytinho privacy / opt-out[/bold]")
    if skipped:
        console.print(f"  [yellow]· cwd está sendo pulado: {reason}[/yellow]")
    else:
        console.print("  [dim]· cwd: enviando normalmente.[/dim]")

    console.print()
    if items:
        console.print("[bold]skip-list global:[/bold]")
        for p in items:
            console.print(f"  [dim]·[/dim] {p}")
    else:
        console.print("[dim]skip-list global vazia.[/dim]")

    console.print()
    console.print(
        "[dim italic]opt-outs:[/dim italic]\n"
        "[dim]  · [cyan]BYTINHO_SKIP=1 git commit[/cyan]   "
        "(pular um commit)\n"
        "  · [cyan]bytinho ignore here[/cyan]            "
        "(pular este repo pra sempre)\n"
        "  · [cyan]bytinho ignore add PATH[/cyan]        "
        "(skip-list global)[/dim]"
    )
