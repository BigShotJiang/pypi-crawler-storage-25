"""Interactive commands: talk, live, chat (WebSocket)."""
import asyncio
import json
import time

import typer
from rich.live import Live

from .. import client
from ..render import console, refresh, show_static
from ..session import cache, load_cache
from ..ui import empty_pet, panel


def _fmt(m: dict) -> str:
    return (
        f"[cyan]{m.get('stage_emoji','👾')} {m.get('nick','anon')}[/cyan] "
        f"[dim]lv.{m.get('level',1)}[/dim]: {m.get('text','')}"
    )


async def _chat_loop():
    import websockets
    from rich.panel import Panel as RPanel
    from rich.text import Text as RText

    msgs: list[str] = []
    online = 0
    top_achs: list[dict] = []
    recent_unlocks: list[dict] = []  # feed global "ao vivo"

    def _fmt_unlock(u: dict) -> str:
        return (
            f"[bright_magenta]{u.get('icon','★')}[/bright_magenta] "
            f"[bold]@{u.get('nick','?')}[/bold] unlocked "
            f"[italic]{u.get('title','?')}[/italic]"
        )

    def render():
        body_lines = msgs[-20:]
        body = "\n".join(body_lines) or "[dim]no one has spoken yet... be the first![/dim]"
        # Side feed of recent unlocks (only the 3 most recent)
        if recent_unlocks:
            feed = "\n".join(_fmt_unlock(u) for u in recent_unlocks[:3])
            body = body + "\n\n[dim]── global feed ──[/dim]\n" + feed
        if top_achs:
            top_str = "  ".join(
                f"{a.get('icon','★')} [bold]{a.get('title','?')}[/bold] "
                f"[dim]({a.get('holders',0)})[/dim]"
                for a in top_achs[:3]
            )
            title = f"💬  Global Chat • {online} online  │  🏆 {top_str}"
        else:
            title = f"💬  Global Chat • {online} online"
        if online <= 1:
            subtitle = "[yellow]🌙 just you here — messages stay saved[/yellow] [dim]• Ctrl+C[/dim]"
            border = "yellow"
        else:
            subtitle = "[dim]type and Enter • Ctrl+C to exit[/dim]"
            border = "magenta"
        return RPanel(
            RText.from_markup(body),
            title=title,
            subtitle=subtitle,
            border_style=border, padding=(1, 2),
        )

    # --- reconnect com backoff exponencial -------------------------------
    backoff = 1.0
    BACKOFF_MAX = 30.0
    while True:
        try:
            async with websockets.connect(client.ws_url()) as ws:
                backoff = 1.0  # reset on success
                console.clear(); console.print(render())

                async def reader():
                    nonlocal online
                    async for raw in ws:
                        try: d = json.loads(raw)
                        except ValueError: continue
                        t = d.get("type")
                        if t == "history":
                            for m in d.get("messages", []): msgs.append(_fmt(m))
                        elif t == "msg":     msgs.append(_fmt(d["message"]))
                        elif t == "presence": online = d.get("online", 0)
                        elif t == "stats":
                            top_achs[:] = d.get("top_achievements", []) or []
                            recent_unlocks[:] = d.get("recent_unlocks", []) or []
                        elif t == "unlock_feed":
                            u = d.get("unlock") or {}
                            if u:
                                recent_unlocks.insert(0, u)
                                del recent_unlocks[5:]
                                msgs.append(
                                    f"[bright_magenta]✨ {_fmt_unlock(u)}[/bright_magenta]"
                                )
                        elif t == "system":   msgs.append(f"[yellow]· {d.get('text','')}[/yellow]")
                        elif t == "ping":
                            try: await ws.send(json.dumps({"type": "pong"}))
                            except Exception: return
                            continue
                        elif t == "pong":
                            continue
                        console.clear(); console.print(render())

                task = asyncio.create_task(reader())
                loop = asyncio.get_event_loop()
                try:
                    while True:
                        txt = (await loop.run_in_executor(None, input, "> ")).strip()
                        if not txt: continue
                        if txt in ("/quit", "/sair", "/exit"): return
                        await ws.send(json.dumps({"type": "msg", "text": txt}))
                finally:
                    task.cancel()
        except (KeyboardInterrupt, SystemExit):
            return
        except Exception as ex:
            console.print(
                f"[yellow]· connection dropped ({type(ex).__name__}). "
                f"reconnecting in {backoff:.0f}s... (Ctrl+C to cancel)[/yellow]"
            )
            try:
                await asyncio.sleep(backoff)
            except (KeyboardInterrupt, asyncio.CancelledError):
                return
            backoff = min(backoff * 2, BACKOFF_MAX)


def register(app: typer.Typer) -> None:
    @app.command(
        "talk",
        context_settings={"allow_interspersed_args": False},
    )
    def talk_cmd(
        words: list[str] = typer.Argument(
            None,
            metavar="MESSAGE",
            help="Free message, no quotes needed.",
        ),
        quiet: bool = typer.Option(
            False, "--quiet", "-q",
            help="Plain reply only — no decoration.",
        ),
        full: bool = typer.Option(
            False, "--full", "-f",
            help="Show the full pet card (default is compact one-liner).",
        ),
    ):
        """Chat with Bytinho — quotes are optional.

        Example: bytinho talk hey what's up
        """
        from . import _talk_ui

        # Junta as palavras OU lê do stdin (echo "oi" | bytinho talk)
        if words:
            message = " ".join(words).strip()
        else:
            import sys
            if not sys.stdin.isatty():
                message = sys.stdin.read().strip()
            else:
                message = ""

        if not message:
            console.print(
                "[yellow]·[/yellow] no message. example: "
                "[cyan]bytinho talk hey what's up[/cyan]"
            )
            raise typer.Exit(1)

        res = client.talk(message)
        h = client.health()
        if res is None:
            cached = load_cache() or {}
            show_static(cached.get("pet", empty_pet()), h, cached.get("nick"),
                        msg="The Core offline.")
            return
        pet = res.get("pet") or (load_cache() or {}).get("pet") or empty_pet()
        cached = load_cache() or {}
        nick = cached.get("nick")
        streak = cached.get("streak") or {}
        cache({"pet": pet, "nick": nick, "streak": streak,
               "achievements": cached.get("achievements", [])})

        # Sempre usamos o reply plain como corpo. O server pode mandar
        # `reply_rich` (futuro), mas o layout é client-side pra ficar
        # consistente entre versões de server.
        reply = res.get("reply") or "..."

        if quiet:
            console.print(_talk_ui.render_talk_quiet(pet, reply))
        elif full:
            console.print(_talk_ui.render_talk(pet, reply, nick, streak, tick=0))
        else:
            console.print(f"  [magenta]💬[/magenta] {reply}")

    @app.command(hidden=True)
    def live(fps: float = typer.Option(6.0, help="Frames per second.")):
        """Permanent live mode — Bytinho breathes, blinks, thinks."""
        pet, h, nick_, streak, _toasts = refresh()
        tick = 0
        last_sync = time.time()
        last_whisper = time.time()
        WHISPER_INTERVAL = 60.0
        whisper_msg: str | None = None
        whisper_until: float = 0.0

        try:
            with Live(panel(pet, h, nick_, tick=tick, streak=streak), console=console,
                      refresh_per_second=fps, screen=False) as view:
                while True:
                    time.sleep(1.0 / max(fps, 1.0))
                    tick += 1

                    if time.time() - last_sync > 15:
                        pet, h, nick_, streak, _toasts = refresh()
                        last_sync = time.time()

                    # Whisper de iniciativa após silêncio
                    if time.time() - last_whisper > WHISPER_INTERVAL:
                        soul = (pet.get("soul") or {})
                        persona = soul.get("personality", "fofo")
                        from ..dialogue_client import idle_whisper_for
                        whisper_msg = idle_whisper_for(persona)
                        whisper_until = time.time() + 8.0
                        last_whisper = time.time()

                    # Limpa whisper após 8s
                    if whisper_msg and time.time() > whisper_until:
                        whisper_msg = None

                    view.update(panel(pet, h, nick_, tick=tick, streak=streak,
                                      message=whisper_msg))

        except KeyboardInterrupt:
            console.print("\n[dim]see ya 👋[/dim]")

    @app.command(
        "speak",
        context_settings={"allow_interspersed_args": False},
    )
    def speak_cmd(
        words: list[str] = typer.Argument(
            None,
            metavar="MESSAGE",
            help="Initial message (optional). No quotes needed.",
        ),
    ):
        """Interactive split mode: Bytinho on top, chat below, input always visible.

            bytinho speak
            bytinho speak hey what's up
        """
        from ..speak_tui import SpeakTUI
        initial = " ".join(words).strip() if words else None
        SpeakTUI().run(initial_message=initial)

    @app.command(hidden=True)
    def chat():
        """[soft-launch: hidden] Global Chat — disabled for this release."""
        console.print(
            "[yellow]global chat is disabled in this release.[/yellow]\n"
            "[dim]use `bytinho speak` to talk with your pet or "
            "`bytinho ranking` to see this week's top.[/dim]"
        )
        raise typer.Exit(0)
