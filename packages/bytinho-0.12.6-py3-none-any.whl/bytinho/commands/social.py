"""Comandos sociais: report, share, install-badge, ranking, achievements."""
from pathlib import Path

import typer

from .. import client
from ..render import console
from ..session import load_cache


def _copy_to_clipboard(text: str) -> bool:
    """Tenta xclip, xsel, wl-copy, pbcopy. Retorna True se algum funcionou."""
    import shutil
    import subprocess as sp
    candidates = [
        (["xclip", "-selection", "clipboard"], "xclip"),
        (["wl-copy"],                          "wl-copy"),
        (["xsel", "--clipboard", "--input"],   "xsel"),
        (["pbcopy"],                           "pbcopy"),
    ]
    for cmd, name in candidates:
        if shutil.which(name):
            try:
                p = sp.Popen(cmd, stdin=sp.PIPE)
                p.communicate(text.encode("utf-8"), timeout=2)
                if p.returncode == 0:
                    return True
            except (sp.TimeoutExpired, OSError):
                continue
    return False


def _resolve_nick() -> str | None:
    cached = load_cache() or {}
    nick = cached.get("nick")
    if not nick:
        data = client.sync()
        if data:
            nick = data["user"].get("nick")
    return nick


def register(app: typer.Typer) -> None:
    @app.command(hidden=True)
    def report(
        target_nick: str = typer.Argument(..., help="Nick of the user to report."),
        reason: str = typer.Argument("", help="Reason (optional)."),
    ):
        """Report someone from Global Chat (3 reports = auto-mute)."""
        ok, msg = client.report_user(target_nick, reason)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            return
        console.print(f"[green]✓ report sent against @{target_nick}[/green]")

    @app.command()
    def share(
        no_copy: bool = typer.Option(False, "--no-copy", help="Don't copy to clipboard."),
        to: str = typer.Option(
            "", "--to", "-t",
            help="Direct target: clipboard|twitter|file|card. Empty = ask.",
        ),
        out: Path = typer.Option(
            None, "--out", "-o",
            help="When --to=file or --to=card, output path.",
        ),
    ):
        """Share your profile: clipboard / Twitter / file / PNG card."""
        from ..config import SERVER_URL

        nick = _resolve_nick()
        if not nick:
            console.print(
                "[red]✗ you don't have a nick yet.[/red] "
                "run [bold]bytinho nick <your-nick>[/bold] first."
            )
            raise typer.Exit(1)

        profile_url = f"{SERVER_URL}/u/{nick}"
        badge_url   = f"{SERVER_URL}/u/{nick}.svg"
        badge_md    = f"[![Bytinho]({badge_url})]({profile_url})"

        # always print header
        console.print()
        console.print(f"[bold magenta]🔗 Public profile:[/bold magenta] {profile_url}")
        console.print(f"[dim]🖼  Badge SVG:[/dim]       {badge_url}")
        console.print()
        console.print("[bold]📋 Markdown for README:[/bold]")
        console.print(f"[cyan]{badge_md}[/cyan]")
        console.print()

        # --no-copy keeps legacy behavior: only show, don't ask
        if no_copy and not to:
            return

        choice = (to or "").strip().lower()
        if not choice:
            console.print("[bold]where do you want to share?[/bold]")
            console.print("  [cyan]1[/cyan]  copy markdown to clipboard  [dim](default)[/dim]")
            console.print("  [cyan]2[/cyan]  open Twitter/X with prefilled text")
            console.print("  [cyan]3[/cyan]  save markdown to a file")
            console.print("  [cyan]4[/cyan]  generate PNG card ([dim]uses[/dim] [bold]bytinho card[/bold])")
            console.print("  [cyan]0[/cyan]  cancel")
            try:
                pick = typer.prompt("choice", default="1", show_default=False).strip()
            except (typer.Abort, KeyboardInterrupt, EOFError):
                console.print("[dim](cancelled)[/dim]")
                return
            choice = {
                "1": "clipboard", "c": "clipboard", "clipboard": "clipboard",
                "2": "twitter",   "t": "twitter",   "twitter": "twitter",   "x": "twitter",
                "3": "file",      "f": "file",      "file": "file",
                "4": "card",      "p": "card",      "card": "card",         "png": "card",
                "0": "cancel",
            }.get(pick.lower(), "clipboard")

        if choice == "cancel":
            console.print("[dim](cancelled)[/dim]")
            return

        if choice == "clipboard":
            if _copy_to_clipboard(badge_md):
                console.print("[green]✓ markdown copied to clipboard![/green]")
            else:
                console.print("[dim](no clipboard available — copy it manually)[/dim]")
            return

        if choice == "twitter":
            from urllib.parse import quote
            text = (
                f"my dev pet is alive in the terminal 👾\n"
                f"follow at {profile_url}\n"
                f"#bytinho"
            )
            tweet_url = f"https://twitter.com/intent/tweet?text={quote(text)}"
            console.print(f"[bold cyan]🐦 tweet link:[/bold cyan] {tweet_url}")
            try:
                import webbrowser
                webbrowser.open(tweet_url)
                console.print("[green]✓ opened in browser.[/green]")
            except Exception:
                console.print("[dim](couldn't open browser — copy the link above)[/dim]")
            return

        if choice == "file":
            target = out or Path("bytinho-share.md")
            target = Path(target).expanduser()
            target.parent.mkdir(parents=True, exist_ok=True)
            content = (
                f"# Bytinho — @{nick}\n\n"
                f"{badge_md}\n\n"
                f"perfil: {profile_url}\n"
            )
            target.write_text(content, encoding="utf-8")
            console.print(f"[green]✓ saved to[/green] [cyan]{target}[/cyan]")
            return

        if choice == "card":
            from platformdirs import user_cache_dir
            try:
                from ..card import render_card
            except ImportError:
                console.print(
                    "[red]✗ Pillow not installed.[/red] "
                    "run [bold]pip install Pillow[/bold]."
                )
                return
            profile = client.profile(nick)
            if not profile:
                console.print(f"[red]✗ profile @{nick} not found on server.[/red]")
                return
            target = out or Path(user_cache_dir("bytinho")) / f"card-{nick}.png"
            path = render_card(profile, Path(target))
            console.print(f"[green]✓ card saved to[/green] [cyan]{path}[/cyan]")
            console.print(
                "[dim]drag it into Twitter/Discord to attach as image.[/dim]"
            )
            return

        console.print(f"[red]✗ unknown target: {choice}[/red]")

    @app.command("install-badge", hidden=True)
    def install_badge():
        """Insert the Bytinho badge into the current repo's README.md and git commit."""
        import subprocess as sp

        nick = _resolve_nick()
        if not nick:
            console.print(
                "[red]✗ you don't have a nick yet.[/red] "
                "run [bold]bytinho nick <your-nick>[/bold] first."
            )
            raise typer.Exit(1)

        try:
            r = sp.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True, text=True, timeout=5,
            )
            if r.returncode != 0:
                console.print("[red]✗ current directory is not a git repo.[/red]")
                raise typer.Exit(1)
            git_root = Path(r.stdout.strip())
        except (sp.TimeoutExpired, FileNotFoundError):
            console.print("[red]✗ git not found.[/red]")
            raise typer.Exit(1)

        _BADGE_HOST = "https://bytinho.com"
        badge_md    = f"[![Bytinho]({_BADGE_HOST}/u/{nick}.svg)]({_BADGE_HOST}/u/{nick})"
        marker      = f"{_BADGE_HOST}/u/"

        readme = git_root / "README.md"
        if not readme.exists():
            readme.write_text(f"# {git_root.name}\n\n", encoding="utf-8")

        content = readme.read_text(encoding="utf-8")
        if marker in content:
            console.print(f"[yellow]badge is already in README.md[/yellow]")
            console.print(f"  [dim]{badge_md}[/dim]")
            return

        lines = content.splitlines(keepends=True)
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith("# "):
                insert_at = i + 1
                while insert_at < len(lines) and lines[insert_at].strip() == "":
                    insert_at += 1
                break
        lines.insert(insert_at, badge_md + "\n\n")
        readme.write_text("".join(lines), encoding="utf-8")

        try:
            sp.run(["git", "-C", str(git_root), "add", "README.md"],
                   timeout=5, check=True, capture_output=True)
            sp.run(
                ["git", "-C", str(git_root), "commit", "-m", "chore: add Bytinho badge"],
                timeout=5, check=True, capture_output=True,
            )
            console.print(f"[green]✓ badge added and committed to README.md![/green]")
        except sp.CalledProcessError:
            console.print(f"[yellow]✓ badge added to README.md[/yellow] [dim](please git commit manually)[/dim]")
        console.print(f"  [dim]{badge_md}[/dim]")

    @app.command()
    def ranking(
        top: int = typer.Option(10, "--top", "-n", help="How many to show."),
    ):
        """Weekly top — who's been committing the most."""
        data = client.ranking()
        rows = data.get("top") or []
        you  = data.get("you")
        if not rows:
            console.print("[dim]no commits registered this week yet. be the first 👀[/dim]")
            return
        me = (load_cache() or {}).get("nick")
        medals = ["🥇", "🥈", "🥉"]
        console.print()
        console.print("[bold magenta]🏆  Weekly ranking — commit XP[/bold magenta]")
        console.print()
        my_rank = None
        my_xp = 0
        for i, r in enumerate(rows):
            if me and r["nick"] == me:
                my_rank = i + 1
                my_xp = r["xp_week"]
        for i, r in enumerate(rows[:top]):
            prefix = medals[i] if i < 3 else f" {i+1:>2} "
            nick = r["nick"]
            line = (
                f"  {prefix}  [bold cyan]@{nick}[/bold cyan]"
                f"  [dim]·[/dim]  [bold]{r['xp_week']:>5}[/bold] XP this week"
                f"  [dim]·[/dim]  🔥 {r['streak']}d"
                f"  [dim]·[/dim]  {r['stage']}"
            )
            if me and nick == me:
                line += "  [green]← you[/green]"
            console.print(line)
        outside = my_rank is None or my_rank > top
        if outside and you is not None:
            gap = max(0, (rows[top - 1]["xp_week"] if len(rows) >= top else 0) - you["xp_week"])
            console.print()
            console.print(
                f"  [bold yellow]#{you['rank']}[/bold yellow]"
                f"[dim]/{you['total']}[/dim]  "
                f"[bold cyan]@{you['nick']}[/bold cyan]"
                f"  [dim]·[/dim]  [bold]{you['xp_week']:>5}[/bold] XP this week"
                f"  [dim]·[/dim]  🔥 {you['streak']}d"
                + (f"  [dim]·[/dim]  [yellow]+{gap} XP to reach top {top}[/yellow]"
                   if gap > 0 else "")
            )
        elif outside and me:
            if my_rank is None:
                console.print()
                console.print(
                    "  [dim]you haven't scored this week — "
                    "run `bytinho install-hook` in a repo and commit something 👀[/dim]"
                )
            else:
                last_visible = rows[top - 1]["xp_week"] if len(rows) >= top else 0
                gap = max(0, last_visible - my_xp)
                console.print()
                console.print(
                    f"  [bold yellow]#{my_rank}[/bold yellow]  "
                    f"[bold cyan]@{me}[/bold cyan]"
                    f"  [dim]·[/dim]  [bold]{my_xp:>5}[/bold] XP this week"
                    + (f"  [dim]·[/dim]  [yellow]+{gap} XP to reach top {top}[/yellow]"
                       if gap > 0 else "")
                )
        console.print()

    @app.command()
    def achievements(
        other: str = typer.Option("", "--user", "-u",
                                  help="View achievements of another nick (public)."),
    ):
        """List unlocked achievements."""
        if other:
            rows = client.profile(other)
            if rows is None:
                console.print(f"[red]✗ user @{other} not found.[/red]")
                return
            achs = rows.get("achievements", [])
            title = f"@{other}"
        else:
            data = client.sync()
            if not data:
                console.print("[red]✗ The Core offline.[/red]")
                return
            achs = client.my_achievements()
            title = data["user"].get("nick") or "you"

        console.print()
        console.print(f"[bold magenta]🏅  Achievements — {title}[/bold magenta]")
        console.print()
        if not achs:
            console.print("[dim]none yet. go commit something 👀[/dim]\n")
            return
        for a in achs:
            console.print(
                f"  {a['icon']}  [bold]{a['title']}[/bold]"
                f"   [dim]· {a['desc']}[/dim]"
            )
        console.print()
