"""Comandos meta/utility: version, greet, streak, credits, donate, blob, doctor."""
import time
from datetime import datetime

import typer

from .. import __version__, client
from ..config import GREET_FILE
from ..render import console


def register(app: typer.Typer) -> None:
    @app.command()
    def version():
        """Show installed version."""
        console.print(f"Bytinho {__version__}")

    @app.command()
    def greet():
        """One-line short output (for shell rc).

        Cached in GREET_FILE for 5 min — opening 30 terminals won't hammer the server.
        Shows a warning when streak is about to break (>= 20h without commit).
        """
        import json as _json

        TTL = 5 * 60
        now = time.time()
        payload: dict | None = None

        if GREET_FILE.exists():
            try:
                cached = _json.loads(GREET_FILE.read_text(encoding="utf-8"))
                if now - cached.get("ts", 0) < TTL:
                    payload = cached
            except (ValueError, OSError):
                pass

        if payload is None:
            data = client.sync()
            if not data:
                return
            pet  = data["pet"]
            user = data["user"]
            streak = user.get("streak") or {}
            payload = {
                "ts":        now,
                "pet":       pet,
                "nick":      user.get("nick"),
                "streak":    streak,
                "challenge": user.get("challenge"),
            }
            try:
                GREET_FILE.write_text(_json.dumps(payload), encoding="utf-8")
            except OSError:
                pass

        pet    = payload["pet"]
        nick   = payload.get("nick") or "anon"
        streak = payload.get("streak") or {}
        name   = pet.get("name") or "Bytinho"
        emoji  = pet.get("stage_emoji", "👾")
        lvl    = pet.get("level", 1)
        days   = int(streak.get("days") or 0)
        active_today = bool(streak.get("active_today"))

        parts = [f"{emoji} {name}", f"Lv.{lvl}"]
        if days >= 1:
            parts.append(f"🔥 {days}d")

        hour_local = datetime.now().hour
        if days >= 1 and not active_today and hour_local >= 20:
            hours_left = max(1, 24 - hour_local)
            parts.append(f"[red]⚠ {hours_left}h before losing streak[/red]")
        elif pet.get("hunger", 100) < 30:
            parts.append("[red]hungry[/red]")
        elif pet.get("mood", 100) < 30:
            parts.append("[yellow]sad[/yellow]")
        elif pet.get("asleep"):
            parts.append("💤")

        console.print("  ".join(parts) + f"  [dim]· @{nick}[/dim]")

        ch = payload.get("challenge")
        if ch:
            prog     = int(ch.get("progress", 0))
            target   = int(ch.get("target", 1))
            done     = bool(ch.get("done"))
            days_l   = int(ch.get("days_left", 7))
            label    = ch.get("label", "")
            xp_rew   = int(ch.get("xp_reward", 50))
            show_ch  = done or prog > 0 or days_l <= 2
            if show_ch:
                if done:
                    console.print(f"  [green]✅ challenge complete: {label}  +{xp_rew} XP[/green]")
                else:
                    urgency = f"  [red]{days_l}d left[/red]" if days_l <= 2 else f"  [dim]{days_l}d left[/dim]"
                    console.print(f"  [cyan]⚔[/cyan]  {label}: [bold]{prog}/{target}[/bold]{urgency}")

    @app.command()
    def streak():
        """Show your current streak."""
        data = client.sync()
        if not data:
            console.print("[red]✗ The Core offline.[/red]")
            return
        s = data["user"].get("streak") or {}
        days = s.get("days", 0)
        best = s.get("best", 0)
        today = "✓ counted today" if s.get("active_today") else "[yellow]not counted yet today[/yellow]"
        console.print()
        console.print(f"  🔥  [bold]{days}[/bold] consecutive day(s)")
        console.print(f"  🏅  personal best: [bold]{best}[/bold]")
        console.print(f"      {today}")
        if days < 10:
            bonus = int(min(days / 10.0, 1.0) * 100)
            console.print(f"  [dim]current XP bonus per commit: +{bonus}%  (max +100% at 10d)[/dim]")
        else:
            console.print(f"  [dim]max XP bonus active: +100% 💪[/dim]")
        console.print()

    @app.command()
    def challenge():
        """Show the current weekly challenge and progress."""
        data = client.sync()
        if not data:
            console.print("[red]✗ The Core offline.[/red]")
            return
        ch = (data.get("user") or {}).get("challenge") or {}
        if not ch:
            console.print("[dim]no active challenge right now[/dim]")
            return
        label    = ch.get("label", "?")
        prog     = int(ch.get("progress", 0))
        target   = int(ch.get("target", 1))
        done     = bool(ch.get("done"))
        days_l   = int(ch.get("days_left", 7))
        xp_rew   = int(ch.get("xp_reward", 50))

        console.print()
        console.print(f"[bold cyan]⚔  Weekly Challenge[/bold cyan]")
        console.print(f"   {label}")
        bar_len = 20
        filled  = int(bar_len * min(prog, target) / max(target, 1))
        bar     = "█" * filled + "░" * (bar_len - filled)
        if done:
            console.print(f"   [green]{bar}[/green]  [bold]{prog}/{target}[/bold]")
            console.print(f"   [green]✅ complete · +{xp_rew} XP credited[/green]")
        else:
            color = "red" if days_l <= 2 else "cyan"
            console.print(f"   [{color}]{bar}[/{color}]  [bold]{prog}/{target}[/bold]")
            urgency = "[red]urgent![/red]" if days_l <= 2 else f"[dim]{days_l}d left[/dim]"
            console.print(f"   reward: [bold]+{xp_rew} XP[/bold]  ·  {urgency}")
        console.print()

    @app.command()
    def credits():
        """Who built it, who hosts it, who maintains it."""
        console.print(
            "\n[bold magenta]Bytinho 💜[/bold magenta]\n"
            "  Created by: [bold]Andryus[/bold]\n"
            "  Hosted by: [bold]Qantara[/bold]\n"
            "  Maintained by the community.\n"
        )

    @app.command()
    def donate():
        """Support Bytinho's server."""
        console.print(
            "\n[bold magenta]Support Bytinho[/bold magenta]\n"
            "  PIX:  [cyan]support@bytinho.com[/cyan]\n"
            "\nThanks for keeping the server up 💜\n"
        )

    @app.command(hidden=True)
    def blob(
        preset: str = typer.Argument("default",
                                     help="Preset name (or 'all' to list all)."),
        validate_only: bool = typer.Option(False, "--validate",
                                           help="Just run the catalog validator, don't render."),
    ):
        """Render/validate ASCII blobs (13×8 system)."""
        from .. import blob as blobmod

        if validate_only:
            try:
                cat = blobmod.validate_catalog()
            except blobmod.BlobValidationError as e:
                console.print(f"[red]✗ invalid blob:[/red] {e}")
                raise typer.Exit(1)
            console.print(f"[green]✓ {len(cat)} valid presets[/green] "
                          f"[dim](grid {blobmod.WIDTH}×{blobmod.HEIGHT})[/dim]")
            return

        if preset == "all":
            for name, b in blobmod.validate_catalog().items():
                console.print(f"\n[bold magenta]── {name} ──[/bold magenta]")
                for line in b:
                    console.print(f"  {line}")
            return

        if preset not in blobmod.PRESETS:
            names = ", ".join(blobmod.PRESETS.keys())
            console.print(f"[red]✗ unknown preset:[/red] {preset}")
            console.print(f"[dim]available: {names}, all[/dim]")
            raise typer.Exit(1)

        spec = blobmod.PRESETS[preset]
        blob_lines = blobmod.render(spec)
        console.print(f"\n[bold magenta]{preset}[/bold magenta] "
                      f"[dim]({spec.skin} · {spec.eyes}/{spec.mouth}/{spec.feet})[/dim]\n")
        for line in blob_lines:
            console.print(f"  {line}")
        console.print()

    @app.command()
    def doctor():
        """Diagnostics: check if everything is in place (server, hook, shell)."""
        import os
        import shutil
        import subprocess
        from pathlib import Path

        from ..config import SERVER_URL, USER_FILE
        from ..session import user_id

        ok = "[green]✓[/green]"
        warn = "[yellow]·[/yellow]"
        bad = "[red]✗[/red]"
        problems = 0

        console.print(f"\n[bold]Bytinho doctor[/bold] [dim]v{__version__}[/dim]\n")

        import sys
        pyver = sys.version_info
        if pyver >= (3, 10):
            console.print(f"  {ok} python {pyver.major}.{pyver.minor}")
        else:
            console.print(f"  {bad} python {pyver.major}.{pyver.minor} [red](need ≥ 3.10)[/red]")
            problems += 1

        if USER_FILE.exists():
            uid = user_id()
            console.print(f"  {ok} user uuid: [dim]{uid[:8]}…[/dim]  [dim]({USER_FILE})[/dim]")
        else:
            console.print(f"  {warn} user uuid not created yet [dim](run `bytinho` once)[/dim]")

        h = client.health()
        if h.get("status") == "ok":
            brain = h.get("brain", "?")
            chat = h.get("chat_online", 0)
            console.print(f"  {ok} server [dim]{SERVER_URL}[/dim]  brain={brain}  chat_online={chat}")
        else:
            console.print(f"  {bad} server offline [dim]({SERVER_URL})[/dim]")
            console.print(f"     [dim]check https://{SERVER_URL.split('//')[-1]}/health in your browser[/dim]")
            problems += 1

        git_bin = shutil.which("git")
        if git_bin:
            console.print(f"  {ok} git [dim]({git_bin})[/dim]")
        else:
            console.print(f"  {warn} git not found [dim](hook won't work without git)[/dim]")

        cwd = Path.cwd()
        try:
            gitdir = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=cwd, capture_output=True, text=True, timeout=2,
            )
            if gitdir.returncode == 0:
                hook_path = Path(gitdir.stdout.strip()) / "hooks" / "post-commit"
                if not hook_path.is_absolute():
                    hook_path = cwd / hook_path
                if hook_path.exists() and "bytinho" in hook_path.read_text(errors="ignore"):
                    console.print(f"  {ok} post-commit hook active [dim](current repo)[/dim]")
                else:
                    console.print(f"  {warn} post-commit hook not installed in this repo")
                    console.print(f"     [dim]run `bytinho install-hook` here[/dim]")
            else:
                console.print(f"  {warn} cwd is not a git repo [dim](skipping hook check)[/dim]")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        shell_rc = None
        home = Path.home()
        for rc in (home / ".zshrc", home / ".bashrc"):
            if rc.exists() and "bytinho greet" in rc.read_text(errors="ignore"):
                shell_rc = rc
                break
        if shell_rc:
            console.print(f"  {ok} shell greet in [dim]{shell_rc.name}[/dim]")
        else:
            console.print(f"  {warn} shell greet not installed [dim](`bytinho setup` enables it on terminal open)[/dim]")

        enc = (os.environ.get("LC_ALL") or os.environ.get("LANG") or "").lower()
        if "utf" in enc or os.environ.get("TERM_PROGRAM"):
            console.print(f"  {ok} terminal supports emoji")
        else:
            console.print(f"  {warn} terminal may not support emoji [dim]($LANG without utf)[/dim]")

        # desktop notifications
        try:
            from .. import desktop_notify, prefs
            mode = prefs.get_notify_mode()
            if mode == "off":
                console.print(f"  {warn} notify disabled [dim](`bytinho notify smart` to enable)[/dim]")
            elif desktop_notify.is_supported():
                console.print(f"  {ok} notify [dim]{mode} · {desktop_notify.env_status()}[/dim]")
            else:
                console.print(f"  {warn} notify [dim]{mode} · {desktop_notify.env_status()}[/dim]")
        except Exception:
            pass

        console.print()
        if problems == 0:
            console.print("[green bold]all good. happy committing 👾[/green bold]\n")
        else:
            console.print(f"[red bold]{problems} serious problem(s).[/red bold] fix before continuing.\n")
            raise typer.Exit(1)
