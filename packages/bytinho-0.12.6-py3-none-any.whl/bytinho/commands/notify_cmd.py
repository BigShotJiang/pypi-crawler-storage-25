"""bytinho notify — manage desktop notification preference."""
from __future__ import annotations

import typer
from rich.console import Console

from .. import desktop_notify, prefs

console = Console()


def _show_status() -> None:
    mode = prefs.get_notify_mode()
    env = desktop_notify.env_status()
    supp = desktop_notify.is_supported()
    icon = "✓" if supp else "·"
    console.print(f"[bold]modo atual:[/bold] [cyan]{mode}[/cyan]")
    console.print(f"  {icon} ambiente: [dim]{env}[/dim]")
    console.print()
    console.print("[dim]uso: bytinho notify [off|smart|all][/dim]")
    console.print("[dim]     bytinho notify-test  (dispara toast de teste)[/dim]")


def register(app: typer.Typer) -> None:
    @app.command()
    def notify(
        mode: str = typer.Argument(
            None,
            help="off | smart | all (padrão: smart). Sem argumento, mostra status.",
        ),
    ):
        """Desktop notifications on level up / achievements / streaks."""
        if mode is None:
            _show_status()
            return

        ok, msg = prefs.set_notify_mode(mode)
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)

        descs = {
            "off": "[dim]· toasts desligados.[/dim]",
            "smart": "[green]✓ smart:[/green] [dim]aviso só em level up, conquistas e streaks marcantes.[/dim]",
            "all": "[green]✓ all:[/green] [dim]aviso em todo commit que ganha XP.[/dim]",
        }
        console.print(descs.get(msg, msg))

        if msg != "off" and not desktop_notify.is_supported():
            console.print(
                f"[yellow]⚠ ambiente atual não suporta toasts:[/yellow] "
                f"[dim]{desktop_notify.env_status()}[/dim]"
            )

    @app.command("notify-test", hidden=True)
    def notify_test():
        """Dispara um toast de teste agora."""
        if not desktop_notify.is_supported():
            console.print(
                f"[yellow]· ambiente sem suporte:[/yellow] {desktop_notify.env_status()}"
            )
            raise typer.Exit(1)
        ok = desktop_notify.notify("Bytinho", "🎉 toast de teste — tá funcionando!")
        if ok:
            console.print(
                "[green]✓ enviado.[/green] [dim]se não viu, cheque permissões do sistema.[/dim]"
            )
        else:
            console.print("[yellow]· nada disparado (env não suportado).[/yellow]")
