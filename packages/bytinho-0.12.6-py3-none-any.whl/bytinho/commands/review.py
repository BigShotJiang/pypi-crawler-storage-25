"""`bytinho review` — revisão do diff staged em personagem.

MVP: lê `git diff --cached` (ou `--staged`), monta um prompt estruturado
e usa o endpoint /api/pet/talk existente. Resultado é renderizado com o
mesmo `_talk_ui` (sprite + persona + fala) — fica como se o bicho tivesse
lido seu código antes do push.

Foco do prompt:
    1. TODO/FIXME antigo no diff
    2. nome de variável/função ruim
    3. função adicionada sem teste
    4. possível secret hardcoded (token, password, api_key=)
    5. um elogio honesto se merecer
Tudo em personagem (mesmo persona que o pet do dev tem).
"""
from __future__ import annotations

import subprocess

import typer

from .. import client
from ..render import console, show_static
from ..session import cache, load_cache
from ..ui import empty_pet


# Truncagem — Grok não precisa do diff inteiro. ~6k chars ≈ 1500 tokens.
MAX_DIFF_CHARS = 6000


def _git_diff(scope: str) -> str:
    """Retorna o diff conforme escopo. Vazio se git falhar ou nada mudou."""
    if scope == "staged":
        cmd = ["git", "diff", "--cached", "--no-color"]
    elif scope == "unstaged":
        cmd = ["git", "diff", "--no-color"]
    elif scope == "head":
        cmd = ["git", "diff", "HEAD~1..HEAD", "--no-color"]
    else:
        return ""
    try:
        out = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10, check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    if out.returncode != 0:
        return ""
    return out.stdout or ""


def _truncate(diff: str, limit: int = MAX_DIFF_CHARS) -> tuple[str, bool]:
    if len(diff) <= limit:
        return diff, False
    return diff[:limit] + "\n[... diff truncated ...]\n", True


def _build_prompt(diff: str, truncated: bool) -> str:
    head = (
        "Review this git diff like my PR buddy. "
        "Stay in character, your style, max 5 lines. "
        "Look for: forgotten TODO/FIXME, bad naming, function added without test, "
        "possible hardcoded secret/token. If everything's fine, say so "
        "honestly and call out what's good."
    )
    if truncated:
        head += " (long diff, focus on the start)"
    return f"{head}\n\n```diff\n{diff.strip()}\n```"


def register(app: typer.Typer) -> None:
    @app.command("review")
    def review_cmd(
        scope: str = typer.Option(
            "staged", "--scope", "-s",
            help="staged | unstaged | head (last commit).",
        ),
        quiet: bool = typer.Option(
            False, "--quiet", "-q",
            help="No header/footer — only the reply.",
        ),
    ):
        """Bytinho reviews your diff before push."""
        from . import _talk_ui

        diff = _git_diff(scope)
        if not diff.strip():
            hint = {
                "staged":   "nothing staged. run [cyan]git add[/cyan] first.",
                "unstaged": "nothing modified.",
                "head":     "no previous commit to compare against.",
            }.get(scope, "nothing to review.")
            console.print(f"[yellow]·[/yellow] {hint}")
            raise typer.Exit(0)

        diff, truncated = _truncate(diff)
        prompt = _build_prompt(diff, truncated)

        res = client.talk(prompt)
        if res is None:
            cached = load_cache() or {}
            show_static(cached.get("pet", empty_pet()), client.health(),
                        cached.get("nick"), msg="The Core offline.")
            return

        pet = res.get("pet") or (load_cache() or {}).get("pet") or empty_pet()
        cached = load_cache() or {}
        nick = cached.get("nick")
        streak = cached.get("streak") or {}
        cache({"pet": pet, "nick": nick, "streak": streak,
               "achievements": cached.get("achievements", [])})

        reply = res.get("reply") or "..."
        if quiet:
            console.print(_talk_ui.render_talk_quiet(pet, reply))
        else:
            console.print(_talk_ui.render_talk(pet, reply, nick, streak))

        # Bloco A: registra evento social (idempotente, fire-and-forget)
        unlocked = client.event("review")
        if unlocked:
            tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
            console.print(f"  [bold]✨ desbloqueou:[/bold] {tags}")
