"""Comando `bytinho card` — gera PNG estilo "GitHub stats" do pet."""
from __future__ import annotations

from pathlib import Path

import typer
from platformdirs import user_cache_dir

from .. import client
from ..render import console
from ..session import load_cache


def _resolve_nick() -> str | None:
    cached = load_cache() or {}
    nick = cached.get("nick")
    if not nick:
        data = client.sync()
        if data:
            nick = data["user"].get("nick")
    return nick


def register(app: typer.Typer) -> None:
    @app.command()
    def card(
        nick: str = typer.Option(
            None, "--nick", "-n",
            help="Nick alvo. Default = seu nick.",
        ),
        out: Path = typer.Option(
            None, "--out", "-o",
            help="Arquivo PNG de saída. Default = cache do usuário.",
        ),
    ):
        """Gera um card PNG do perfil (pet + nick + level + top 3 conquistas)."""
        target = (nick or _resolve_nick() or "").strip()
        if not target:
            console.print(
                "[red]✗ você ainda não tem nick.[/red] "
                "rode [bold]bytinho nick <seu-nick>[/bold] primeiro."
            )
            raise typer.Exit(1)

        profile = client.profile(target)
        if not profile:
            console.print(f"[red]✗ perfil @{target} não encontrado.[/red]")
            raise typer.Exit(1)

        if out is None:
            out = Path(user_cache_dir("bytinho")) / f"card-{target}.png"

        # import tardio: PIL é pesado e só é necessário aqui
        try:
            from ..card import render_card
        except ImportError:
            console.print(
                "[red]✗ Pillow não está instalado.[/red] "
                "rode [bold]pip install Pillow[/bold] e tenta de novo."
            )
            raise typer.Exit(1)

        path = render_card(profile, out)
        console.print(f"[green]✓ card salvo em[/green] [cyan]{path}[/cyan]")
        console.print(
            "[dim]dica: arrasta no Twitter/Discord ou usa "
            "[cyan]bytinho share[/cyan] pra obter o link público.[/dim]"
        )

        # Bloco A: registra evento social só se gerou pro próprio nick
        if nick is None or target == _resolve_nick():
            unlocked = client.event("card")
            if unlocked:
                tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
                console.print(f"  [bold]✨ desbloqueou:[/bold] {tags}")
