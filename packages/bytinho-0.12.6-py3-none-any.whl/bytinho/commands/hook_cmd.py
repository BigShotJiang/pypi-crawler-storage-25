"""`bytinho hook ...` — subcomando chamado pelos hooks do git.

Hoje:
    bytinho hook pre-push    # chamado pelo .git/hooks/pre-push

Filosofia: NUNCA bloqueia, NUNCA gera erro pro git. Se algo der errado
(server offline, sem diff, timeout), sai com 0 silenciosamente. O push
sempre passa. Único output é a fala do Bytinho na voz da persona.

Skip: BYTINHO_SKIP=1 git push
"""
from __future__ import annotations

import os
import subprocess

import typer

from .. import client
from ..render import console
from ..session import load_cache
from ..ui import empty_pet


MAX_DIFF_CHARS = 6000


def _diff_to_push() -> str:
    """Diff entre HEAD e o que já tá no remote (origin/<branch atual>).

    Se o branch ainda não existe no remote (primeira push), cai pro
    diff dos últimos 3 commits.
    """
    try:
        # Compara com upstream se existir
        up = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "@{u}"],
            capture_output=True, text=True, timeout=3, check=False,
        )
        if up.returncode == 0 and up.stdout.strip():
            ref = up.stdout.strip()
            r = subprocess.run(
                ["git", "diff", f"{ref}..HEAD", "--no-color"],
                capture_output=True, text=True, timeout=8, check=False,
            )
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout
        # Sem upstream, ou diff vazio: olha últimos 3 commits
        r = subprocess.run(
            ["git", "diff", "HEAD~3..HEAD", "--no-color"],
            capture_output=True, text=True, timeout=8, check=False,
        )
        if r.returncode == 0:
            return r.stdout or ""
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    return ""


def _truncate(diff: str, limit: int = MAX_DIFF_CHARS) -> tuple[str, bool]:
    if len(diff) <= limit:
        return diff, False
    return diff[:limit] + "\n[... diff truncado ...]\n", True


def _build_prompt(diff: str, truncated: bool) -> str:
    head = (
        "Vou dar push agora. Dá uma olhada rápida no que vai subir, "
        "fala em personagem, MÁXIMO 3 linhas curtas. "
        "Se vir TODO esquecido, secret hardcoded (api_key, password, token), "
        "função nova sem teste, ou nome ruim — avisa. "
        "Se tiver tudo limpo, manda um elogio honesto e curto."
    )
    if truncated:
        head += " (diff longo, foca no começo)"
    return f"{head}\n\n```diff\n{diff.strip()}\n```"


def register(app: typer.Typer) -> None:
    hook_app = typer.Typer(help="Subcomandos chamados pelos git hooks.")
    app.add_typer(hook_app, name="hook")

    @hook_app.command("pre-push")
    def pre_push():
        """Chamado pelo .git/hooks/pre-push. Comenta o diff, nunca bloqueia."""
        # Belt-and-suspenders: o hook bash já checa, mas se chamarem direto.
        if os.environ.get("BYTINHO_SKIP") == "1":
            raise typer.Exit(0)

        from . import _talk_ui

        diff = _diff_to_push()
        if not diff.strip():
            # Nada novo pra revisar: silêncio total, não polui o terminal.
            raise typer.Exit(0)

        diff, truncated = _truncate(diff)
        prompt = _build_prompt(diff, truncated)

        res = client.talk(prompt)
        if res is None or not res.get("reply"):
            # Server offline ou sem reply: silêncio. Push passa.
            raise typer.Exit(0)

        pet = res.get("pet") or (load_cache() or {}).get("pet") or empty_pet()
        reply = res["reply"]

        # Modo quiet por default no hook — o dev tá querendo pushar, não
        # quer um header gigante. 2 linhas: fala + assinatura.
        console.print()
        console.print(_talk_ui.render_talk_quiet(pet, reply))
        console.print(
            "[dim italic](pular review: BYTINHO_SKIP=1 git push)[/dim italic]"
        )
        # Bloco A: registra evento social (idempotente, fire-and-forget)
        try:
            client.event("push")
        except Exception:  # nunca bloqueia push
            pass
        raise typer.Exit(0)
