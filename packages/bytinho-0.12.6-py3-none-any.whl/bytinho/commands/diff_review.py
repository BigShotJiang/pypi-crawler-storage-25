"""bytinho diff-review — análise leve do diff atual.

Estatística primeiro (offline, instantâneo).

Saída:
  - Files: N changed (X added, Y modified, Z deleted)
  - +lines / -lines / churn
  - Linguagens tocadas
  - Top 3 arquivos por churn
  - Sinais de risco: arquivo > 400 linhas alteradas, .env modificado,
    package-lock isolado, diff muito amplo.

Não bloqueia nada. É lente, não filtro.

NOTA: a flag --ai existe mas está oculta até v0.10.1
(endpoint /v1/ai/duck ainda não existe no server).
"""
from __future__ import annotations

import subprocess
from collections import Counter
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

LANG_BY_SUFFIX = {
    ".py": "Python", ".js": "JS", ".ts": "TS", ".tsx": "TSX", ".jsx": "JSX",
    ".go": "Go", ".rs": "Rust", ".java": "Java", ".kt": "Kotlin",
    ".rb": "Ruby", ".php": "PHP", ".c": "C", ".cpp": "C++", ".cs": "C#",
    ".swift": "Swift", ".html": "HTML", ".css": "CSS", ".scss": "SCSS",
    ".sql": "SQL", ".sh": "Shell", ".md": "Markdown", ".yml": "YAML",
    ".yaml": "YAML", ".json": "JSON", ".toml": "TOML",
}


def _git(*args: str) -> str:
    r = subprocess.run(["git", *args], capture_output=True, text=True, check=False)
    return r.stdout


def _numstat(rev: str) -> list[tuple[int, int, str]]:
    out = _git("diff", "--numstat", rev)
    rows = []
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        added, removed, path = parts
        if added == "-" or removed == "-":  # binary
            continue
        try:
            rows.append((int(added), int(removed), path))
        except ValueError:
            continue
    return rows


def _name_status(rev: str) -> dict[str, str]:
    out = _git("diff", "--name-status", rev)
    res = {}
    for line in out.splitlines():
        parts = line.split("\t", 1)
        if len(parts) == 2:
            res[parts[1]] = parts[0]
    return res


def _risks(rows: list[tuple[int, int, str]], status: dict[str, str]) -> list[str]:
    risks = []
    big = [(p, a + r) for a, r, p in rows if a + r > 400]
    if big:
        names = ", ".join(p for p, _ in big[:3])
        risks.append(f"arquivos enormes alterados: {names}")
    sensitive = [p for p in status if Path(p).name in {".env", ".env.local", ".env.production"}]
    if sensitive:
        risks.append(f".env modificado: {', '.join(sensitive)}")
    locks = [p for p in status if Path(p).name in {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock"}]
    if locks and len(status) <= len(locks) + 1:
        risks.append("commit só de lockfile sem package.json/pyproject")
    if len(rows) > 30:
        risks.append(f"diff muito amplo ({len(rows)} arquivos) — considere split")
    return risks


def diff_review_cmd(
    rev: str = typer.Option("HEAD", "--rev", help="Revisão base (HEAD, origin/main, etc)."),
    ai: bool = typer.Option(
        False, "--ai",
        help="[em breve] resumo IA do diff.",
        hidden=True,  # endpoint /v1/ai/duck ainda não existe (v0.10.1)
    ),
) -> None:
    """Resumo do diff: stats + risco."""
    rows = _numstat(rev)
    status = _name_status(rev)
    if not rows and not status:
        console.print("[dim]nada pra revisar.[/dim]")
        return

    added = sum(a for a, _, _ in rows)
    removed = sum(r for _, r, _ in rows)
    langs = Counter(LANG_BY_SUFFIX.get(Path(p).suffix.lower(), "outro")
                    for _, _, p in rows)
    by_kind = Counter(status.values())  # A/M/D/R

    body = (
        f"[bold]{len(status)}[/bold] arquivo(s) · "
        f"[green]+{added}[/green] [red]-{removed}[/red]\n"
        f"add={by_kind.get('A',0)} mod={by_kind.get('M',0)} "
        f"del={by_kind.get('D',0)} ren={by_kind.get('R',0)}\n"
        f"langs: {', '.join(f'{k}({v})' for k, v in langs.most_common(5))}"
    )
    console.print(Panel(body, title=f"diff vs {rev}", border_style="cyan"))

    # top churn
    top = sorted(rows, key=lambda x: -(x[0] + x[1]))[:3]
    if top:
        t = Table(show_header=True, header_style="bold", box=None)
        t.add_column("arquivo"); t.add_column("+", justify="right")
        t.add_column("-", justify="right"); t.add_column("total", justify="right")
        for a, r, p in top:
            t.add_row(p, f"[green]{a}[/green]", f"[red]{r}[/red]", str(a + r))
        console.print(t)

    risks = _risks(rows, status)
    if risks:
        console.print("\n[bold yellow]riscos detectados:[/bold yellow]")
        for x in risks:
            console.print(f"  · {x}")
    else:
        console.print("\n[green]sem riscos óbvios.[/green]")

    if ai:
        # Feature em desenvolvimento — endpoint server ainda não disponível.
        # Mantido oculto via hidden=True na flag até v0.10.1.
        console.print(
            "[dim]--ai ainda em desenvolvimento. Vai chegar na v0.10.1.[/dim]"
        )


def register(app: typer.Typer) -> None:
    app.command("diff-review")(diff_review_cmd)


# Mantido para reuso quando o endpoint /v1/ai/duck existir.
def _ai_summary(rev: str, added: int, removed: int,  # noqa: ARG001
                langs: Counter, risks: list[str]) -> None:
    """Stub: será reativado em v0.10.1 quando server tiver /v1/ai/duck."""
    return
