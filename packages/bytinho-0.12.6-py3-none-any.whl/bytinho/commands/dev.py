"""Dev commands: code, sync-history, install-hook, setup, unsetup."""
import os
from pathlib import Path

import typer

from .. import client, telemetry
from ..render import console, live_for
from ..session import cache, load_cache
from ..ui import empty_pet


def _do(action_name: str, prefix: str, **kw) -> None:
    """Helper local: chama action() e renderiza Live com a resposta."""
    res = client.action(action_name, **kw)
    h = client.health()
    if res is None:
        cached = load_cache() or {}
        from ..render import show_static
        show_static(cached.get("pet", empty_pet()), h, cached.get("nick"),
                    msg="The Core offline — action not registered.")
        return
    pet = res["pet"]
    cached = load_cache() or {}
    nick = cached.get("nick")
    cache({"pet": pet, "nick": nick})

    unlocked = res.get("unlocked") or []
    base_msg = f"{prefix} {res.get('message','')}"
    # Trust/repo-age multiplier hint (visible toast for slow farms / new repos).
    mult = float(res.get("trust_mult", 1.0) or 1.0)
    if mult < 1.0:
        reason = res.get("abuse_reason") or "new-repo cooldown"
        base_msg += f"\n[dim yellow]· {mult:.1f}× ({reason})[/dim yellow]"
    if unlocked:
        tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
        base_msg += f"\n[bold magenta]✨ unlocked:[/bold magenta] {tags}"
    live_for(pet, h, nick, msg=base_msg, seconds=3.0 if unlocked else 2.5, fps=8.0)


_HOOK_BODY = r"""#!/usr/bin/env sh
# bytinho post-commit hook — registra commit como XP + reação curta.
# POSIX sh (Linux/macOS/Git-Bash/MSYS). Foreground com timeout: tempo suficiente
# para action(~3s) + react AI(~6s). Se o servidor estiver lento, mata sem
# afetar o commit (que já aconteceu).
#
# Privacy opt-outs (P0-4):
#   - BYTINHO_SKIP=1 git commit ...        # pula um commit
#   - touch .bytinhoignore                  # pula este repo pra sempre
#   - bytinho ignore add /caminho/do/repo   # skip-list global
if [ "${BYTINHO_SKIP:-0}" = "1" ]; then exit 0; fi
_bt_top=$(git rev-parse --show-toplevel 2>/dev/null)
if [ -n "$_bt_top" ] && [ -f "$_bt_top/.bytinhoignore" ]; then exit 0; fi

# P0-2: resolve bytinho de forma portátil (Linux/macOS/Windows-Git-Bash).
_bt_bin=""
if command -v bytinho >/dev/null 2>&1; then
  _bt_bin="bytinho"
elif [ -x "$HOME/.local/bin/bytinho" ]; then
  _bt_bin="$HOME/.local/bin/bytinho"
elif [ -x "$HOME/.local/bin/bytinho.exe" ]; then
  _bt_bin="$HOME/.local/bin/bytinho.exe"
elif [ -n "${APPDATA:-}" ] && [ -x "$APPDATA/Python/Scripts/bytinho.exe" ]; then
  _bt_bin="$APPDATA/Python/Scripts/bytinho.exe"
fi
[ -z "$_bt_bin" ] && exit 0

# timeout pode não existir em Git Bash; fallback chama direto.
if command -v timeout >/dev/null 2>&1; then
  timeout 12s "$_bt_bin" code 1 --from-git --react --quiet 2>/dev/null
else
  "$_bt_bin" code 1 --from-git --react --quiet 2>/dev/null
fi
exit 0
"""

# pre-push: SÓ COMENTA, nunca bloqueia. Se Grok demorar / cair / o que for,
# o push passa silencioso. BYTINHO_SKIP=1 git push pula tudo.
_PREPUSH_BODY = r"""#!/usr/bin/env sh
# bytinho pre-push hook — Bytinho dá uma olhada no diff antes do push.
# POSIX sh portátil (Linux/macOS/Git-Bash). NUNCA BLOQUEIA: falha = push passa.
# Pula com: BYTINHO_SKIP=1 git push
if [ "${BYTINHO_SKIP:-0}" = "1" ]; then exit 0; fi

_bt_bin=""
if command -v bytinho >/dev/null 2>&1; then
  _bt_bin="bytinho"
elif [ -x "$HOME/.local/bin/bytinho" ]; then
  _bt_bin="$HOME/.local/bin/bytinho"
elif [ -x "$HOME/.local/bin/bytinho.exe" ]; then
  _bt_bin="$HOME/.local/bin/bytinho.exe"
elif [ -n "${APPDATA:-}" ] && [ -x "$APPDATA/Python/Scripts/bytinho.exe" ]; then
  _bt_bin="$APPDATA/Python/Scripts/bytinho.exe"
fi
[ -z "$_bt_bin" ] && exit 0

if command -v timeout >/dev/null 2>&1; then
  timeout 8s "$_bt_bin" hook pre-push 2>/dev/null || true
else
  "$_bt_bin" hook pre-push 2>/dev/null || true
fi
exit 0
"""

_GREET_MARK = "# >>> bytinho greet >>>"
_GREET_END  = "# <<< bytinho greet <<<"
_GREET_BLOCK = (
    f"\n{_GREET_MARK}\n"
    "command -v bytinho >/dev/null 2>&1 && bytinho greet 2>/dev/null\n"
    f"{_GREET_END}\n"
)

# P0-1 markers: blocos idempotentes pra encadear no hook de outro framework
# (husky, pre-commit, lefthook, etc.) sem destruir nada.
_HOOK_MARK_START = "# >>> bytinho hook >>>"
_HOOK_MARK_END   = "# <<< bytinho hook <<<"

_HOOK_INNER_POST = (
    f"\n{_HOOK_MARK_START}\n"
    "# bytinho post-commit (managed block — não edite manualmente).\n"
    '# Pular: BYTINHO_SKIP=1 git commit | toque .bytinhoignore na raiz | bytinho ignore add\n'
    'if [ "${BYTINHO_SKIP:-0}" != "1" ]; then\n'
    '  _bt_top=$(git rev-parse --show-toplevel 2>/dev/null)\n'
    '  if [ -z "$_bt_top" ] || [ ! -f "$_bt_top/.bytinhoignore" ]; then\n'
    '    _bt_bin=""\n'
    '    if command -v bytinho >/dev/null 2>&1; then _bt_bin="bytinho";\n'
    '    elif [ -x "$HOME/.local/bin/bytinho" ]; then _bt_bin="$HOME/.local/bin/bytinho";\n'
    '    elif [ -x "$HOME/.local/bin/bytinho.exe" ]; then _bt_bin="$HOME/.local/bin/bytinho.exe";\n'
    '    elif [ -n "${APPDATA:-}" ] && [ -x "$APPDATA/Python/Scripts/bytinho.exe" ]; then _bt_bin="$APPDATA/Python/Scripts/bytinho.exe";\n'
    '    fi\n'
    '    if [ -n "$_bt_bin" ]; then\n'
    '      if command -v timeout >/dev/null 2>&1; then\n'
    '        timeout 12s "$_bt_bin" code 1 --from-git --react --quiet 2>/dev/null\n'
    '      else\n'
    '        "$_bt_bin" code 1 --from-git --react --quiet 2>/dev/null\n'
    '      fi\n'
    '    fi\n'
    '  fi\n'
    'fi\n'
    f"{_HOOK_MARK_END}\n"
)

_HOOK_INNER_PREPUSH = (
    f"\n{_HOOK_MARK_START}\n"
    "# bytinho pre-push (managed block — não edite manualmente).\n"
    'if [ "${BYTINHO_SKIP:-0}" != "1" ]; then\n'
    '  _bt_bin=""\n'
    '  if command -v bytinho >/dev/null 2>&1; then _bt_bin="bytinho";\n'
    '  elif [ -x "$HOME/.local/bin/bytinho" ]; then _bt_bin="$HOME/.local/bin/bytinho";\n'
    '  elif [ -x "$HOME/.local/bin/bytinho.exe" ]; then _bt_bin="$HOME/.local/bin/bytinho.exe";\n'
    '  elif [ -n "${APPDATA:-}" ] && [ -x "$APPDATA/Python/Scripts/bytinho.exe" ]; then _bt_bin="$APPDATA/Python/Scripts/bytinho.exe";\n'
    '  fi\n'
    '  if [ -n "$_bt_bin" ]; then\n'
    '    if command -v timeout >/dev/null 2>&1; then\n'
    '      timeout 8s "$_bt_bin" hook pre-push 2>/dev/null || true\n'
    '    else\n'
    '      "$_bt_bin" hook pre-push 2>/dev/null || true\n'
    '    fi\n'
    '  fi\n'
    'fi\n'
    f"{_HOOK_MARK_END}\n"
)


def _upsert_managed_block(path: Path, inner: str, default_shebang: str = "#!/usr/bin/env sh\n") -> None:
    """Insere ou atualiza o bloco bytinho num hook existente.

    Idempotente: se o bloco já existe, substitui pelo novo conteúdo (mantém
    o resto do arquivo). Se não existe, anexa no fim. Se o arquivo não
    existe, cria com shebang + bloco.
    """
    if not path.exists():
        path.write_text(default_shebang + inner)
        path.chmod(0o755)
        return

    cur = path.read_text(errors="ignore")
    if _HOOK_MARK_START in cur and _HOOK_MARK_END in cur:
        # substitui in-place
        before, _, rest = cur.partition(_HOOK_MARK_START)
        _, _, after = rest.partition(_HOOK_MARK_END)
        new = before.rstrip() + "\n" + inner.lstrip() + after.lstrip()
        path.write_text(new)
    else:
        # backup + append
        try:
            path.with_suffix(path.suffix + ".bak").write_text(cur)
        except OSError:
            pass
        sep = "" if cur.endswith("\n") else "\n"
        path.write_text(cur + sep + inner)
    path.chmod(0o755)


def _remove_managed_block(path: Path) -> bool:
    """Remove o bloco bytinho de um hook. Retorna True se removeu algo."""
    if not path.exists():
        return False
    cur = path.read_text(errors="ignore")
    if _HOOK_MARK_START not in cur or _HOOK_MARK_END not in cur:
        return False
    before, _, rest = cur.partition(_HOOK_MARK_START)
    _, _, after = rest.partition(_HOOK_MARK_END)
    new = before.rstrip() + "\n" + after.lstrip()
    # se restou só shebang/whitespace e o hook foi criado por nós, apaga
    stripped = "\n".join(
        ln for ln in new.splitlines() if ln.strip() and not ln.startswith("#!")
    ).strip()
    if not stripped:
        path.unlink()
    else:
        path.write_text(new)
    return True


def _install_hook_here() -> tuple[bool, str]:
    """Instala o post-commit hook no repo do cwd usando blocos marcados.

    Reutilizado pelo welcome flow (auto-install se cwd for repo git) e pelo
    comando `bytinho install-hook`. Idempotente e non-destructive: se já
    existe um post-commit (próprio ou de terceiros tipo husky), encadeia
    o bloco bytinho no fim sem apagar nada.
    """
    import subprocess
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--git-dir"], stderr=subprocess.DEVNULL,
        ).decode().strip()
    except Exception:
        return False, "not in a git repo"
    hook = Path(out) / "hooks" / "post-commit"
    hook.parent.mkdir(parents=True, exist_ok=True)
    _upsert_managed_block(hook, _HOOK_INNER_POST)
    return True, str(hook)


def _install_global_hooks() -> tuple[bool, str]:
    """Instala hooks GLOBAIS via git config --global core.hooksPath.

    Estratégia P0-1 (non-destructive merge):
      - Se NÃO existe core.hooksPath: cria ~/.bytinho-hooks/ e aponta git pra lá.
      - Se já existe core.hooksPath (husky, pre-commit, lefthook…): NÃO mexe na
        config. Em vez disso, ANEXA blocos bytinho marcados em
        {existing_dir}/post-commit e pre-push. Idempotente: roda 10x sem efeito
        colateral. Desinstalação remove SÓ os blocos marcados.

    Retorna (ok, descrição-pro-user).
    """
    import subprocess

    # 1. Lê config existente
    try:
        cur = subprocess.run(
            ["git", "config", "--global", "core.hooksPath"],
            capture_output=True, text=True, check=False,
        ).stdout.strip()
    except FileNotFoundError:
        return False, "git is not installed"

    # 2. Decide target dir
    if cur:
        target_dir = Path(cur).expanduser()
        chained = True
    else:
        target_dir = Path.home() / ".bytinho-hooks"
        chained = False

    # 3. Garante o dir + escreve / encadeia hooks
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
        post = target_dir / "post-commit"
        pre  = target_dir / "pre-push"
        if chained:
            _upsert_managed_block(post, _HOOK_INNER_POST)
            _upsert_managed_block(pre,  _HOOK_INNER_PREPUSH)
        else:
            # repo dedicado nosso — usa scripts standalone
            post.write_text(_HOOK_BODY)
            post.chmod(0o755)
            pre.write_text(_PREPUSH_BODY)
            pre.chmod(0o755)
    except OSError as e:
        return False, f"could not write to {target_dir} ({e})"

    # 4. Aponta core.hooksPath se ainda não está (só no caso non-chained)
    if not chained:
        try:
            subprocess.check_call(
                ["git", "config", "--global", "core.hooksPath", str(target_dir)],
            )
        except subprocess.CalledProcessError as e:
            return False, f"git config failed: {e}"

    suffix = " (chained into existing setup)" if chained else ""
    return True, str(target_dir) + suffix


def _uninstall_global_hooks() -> tuple[bool, str]:
    """Desinstala hooks globais — remove blocos marcados, preserva o resto."""
    import subprocess

    try:
        cur = subprocess.run(
            ["git", "config", "--global", "core.hooksPath"],
            capture_output=True, text=True, check=False,
        ).stdout.strip()
    except FileNotFoundError:
        return False, "git is not installed"

    own_dir = Path.home() / ".bytinho-hooks"
    if cur and Path(cur).expanduser().resolve() == own_dir.resolve():
        # nosso diretório dedicado — desfaz config e some
        subprocess.run(
            ["git", "config", "--global", "--unset", "core.hooksPath"],
            check=False,
        )
        return True, f"unset (kept {own_dir} in case you want to re-enable)"

    if cur:
        d = Path(cur).expanduser()
        removed = False
        for name in ("post-commit", "pre-push"):
            if _remove_managed_block(d / name):
                removed = True
        if removed:
            return True, f"blocks removed from {d}"
        return True, f"nothing to remove in {d}"

    return True, "core.hooksPath was not set"


def _install_prepush_here() -> tuple[bool, str]:
    """Instala o pre-push hook no repo do cwd com bloco marcado. Idempotente."""
    import subprocess
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--git-dir"], stderr=subprocess.DEVNULL,
        ).decode().strip()
    except Exception:
        return False, "not in a git repo"
    hook = Path(out) / "hooks" / "pre-push"
    hook.parent.mkdir(parents=True, exist_ok=True)
    _upsert_managed_block(hook, _HOOK_INNER_PREPUSH)
    return True, str(hook)


def register(app: typer.Typer) -> None:
    @app.command(hidden=True)
    def code(
        commits: int = typer.Argument(1),
        message: str = typer.Option("", "--message", "-m"),
        hour:    int = typer.Option(-1, "--hour"),
        files:   int = typer.Option(0, "--files"),
        from_git: bool = typer.Option(
            False, "--from-git",
            help="Extract all metadata from the last commit (used by the hook).",
        ),
        react: bool = typer.Option(
            False, "--react",
            help="Print 1 line of brain reaction (used by the hook).",
        ),
        quiet: bool = typer.Option(
            False, "--quiet", "-q",
            help="Minimal output (1 line per commit). Good for the hook.",
        ),
    ):
        """Register commits → XP."""
        from .. import evolution, git_meta, privacy
        from ..render import invalidate_greet_cache

        # P0-4 privacy: short-circuit ANTES de qualquer payload sair daqui.
        # Cobre hooks legados (0.10.x) que não têm o guard em shell.
        if from_git:
            skipped, reason = privacy.is_skipped()
            if skipped:
                if not quiet:
                    console.print(f"[dim]· bytinho skipped ({reason})[/dim]")
                return

        kw: dict = {"commits": commits}
        meta: dict | None = None
        if from_git:
            meta = git_meta.collect()
            if meta is None:
                console.print("[red]✗ not in a git repo.[/red]")
                raise typer.Exit(1)
            kw.update(meta)
            # Bug #5: persiste histórico local pra suggest_persona() ter base.
            # 100% local, fire-and-forget, NUNCA bloqueia o hook.
            try:
                langs = meta.get("languages") or []
                evolution.record_commit(
                    kind=meta.get("kind", "other"),
                    lang=langs[0] if langs else "?",
                    hour=int(meta.get("hour", 0)),
                )
            except Exception:
                pass
        else:
            if message:
                kw["message"] = message
            if hour >= 0:
                kw["hour"] = hour
            if files > 0:
                kw["files"] = files

        if quiet:
            res = client.action("code", **kw)
            if res is None:
                return
            pet = res.get("pet") or {}
            cached = load_cache() or {}
            cache({"pet": pet, "nick": cached.get("nick"),
                   "streak": cached.get("streak")})
            unlocked = res.get("unlocked") or []
            invalidate_greet_cache()
            telemetry.track("first_commit")
            telemetry.track("daily_active")
            # ── P1-3: toast quiet = 1-2 linhas coloridas ────────────────
            # Formato: 👾 +5 XP · 47/100 → spark · 🔥 3d
            # Se reunion: prepend "🌅 voltou depois de Nd · +M XP bônus"
            from ..pet_logic import STAGE_LABEL
            xp_gained   = int(res.get("xp_gained", 0))
            streak_days = int(res.get("streak_days", 0))
            stage_emoji = pet.get("stage_emoji", "👾")
            stage_label = STAGE_LABEL.get(pet.get("stage", ""), pet.get("stage", ""))
            xp_now      = int(pet.get("xp", 0))
            nxt = res.get("next_stage") or {}

            # Fix 3.1: reunion bonus visível no quiet path. O server devolve
            # message "🌅 voltou depois de 7d · +30 XP bônus\n+50 XP por 1...".
            # Pegamos a 1ª linha (a do reunion) pra prepend.
            if res.get("reunion"):
                msg = res.get("message", "")
                first_line = msg.split("\n", 1)[0] if msg else ""
                if first_line:
                    console.print(f"[bold yellow]{first_line}[/bold yellow]")

            # Cor do XP: amarelo se 0 (cap/throttle), magenta caso ganhe.
            if res.get("throttled") or res.get("duplicate"):
                console.print(f"[yellow]· {res.get('message', '')}[/yellow]")
            else:
                xp_color = "yellow" if xp_gained == 0 else "magenta"
                parts = [
                    f"[bold {xp_color}]{stage_emoji} +{xp_gained} XP[/bold {xp_color}]"
                ]
                # Multiplier hint: shows trust/new-repo cooldown to user.
                mult = float(res.get("trust_mult", 1.0) or 1.0)
                if mult < 1.0:
                    reason = res.get("abuse_reason") or "new-repo cooldown"
                    parts.append(f"[yellow]{mult:.1f}× {reason}[/yellow]")
                if nxt:
                    threshold = int(nxt.get("xp_threshold", 0))
                    nxt_label = STAGE_LABEL.get(nxt.get("name", ""),
                                                nxt.get("name", ""))
                    parts.append(
                        f"[cyan]{xp_now}/{threshold}[/cyan] [dim]→[/dim] "
                        f"[bold]{nxt_label}[/bold]"
                    )
                else:
                    # legend: sem next stage
                    parts.append(f"[bold]{stage_label}[/bold] [dim]· lv.{pet.get('level', 1)}[/dim]")
                if streak_days > 0:
                    parts.append(f"[bold red]🔥 {streak_days}d[/bold red]")
                console.print(" [dim]·[/dim] ".join(parts))

            if unlocked:
                tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
                console.print(f"  [bold green]✨ unlocked:[/bold green] {tags}")

            # ── desktop toast (smart mode by default; opts via prefs) ────
            try:
                from .. import desktop_notify, prefs
                pet_prev = (cached or {}).get("pet") or {}
                streak_prev = int(((cached or {}).get("streak") or {}).get("days") or 0)
                desktop_notify.dispatch_commit_event(
                    mode=prefs.get_notify_mode(),
                    xp_gained=xp_gained,
                    unlocked=unlocked,
                    pet_curr=pet,
                    pet_prev=pet_prev or None,
                    streak_days=streak_days,
                    streak_days_prev=streak_prev,
                )
            except Exception:
                pass  # never block the hook on a notification error

            if react and meta:
                reply = client.commit_react(meta)
                if reply:
                    console.print(f"  [italic dim]💬 {reply}[/italic dim]")
            return

        _do("code", "💻", **kw)
        if react and meta:
            reply = client.commit_react(meta)
            if reply:
                console.print(f"[italic dim]💬 {reply}[/italic dim]")

    @app.command("sync-history", hidden=True)
    def sync_history_cmd(
        days: int = typer.Option(30, "--days", "-d", min=1, max=365),
    ):
        """Import commits from the last N days of the current repo (one-shot)."""
        from .. import git_meta
        history = git_meta.collect_history(days=days)
        if history is None:
            console.print("[red]✗ not in a git repo.[/red]")
            raise typer.Exit(1)
        if not history:
            console.print(f"[yellow]no commits in the last {days} days.[/yellow]")
            return

        console.print(f"📦 sending {len(history)} commits from the last {days} days...")
        res = client.sync_history(history)
        if res is None:
            console.print("[red]✗ The Core offline.[/red]")
            raise typer.Exit(1)

        imported = res.get("imported", 0)
        skipped  = res.get("skipped", 0)
        xp       = res.get("xp_gain", 0)
        days_a   = res.get("active_days", 0)
        unlocked = res.get("unlocked") or []
        pet      = res.get("pet") or empty_pet()

        msg = (
            f"📥 +{imported} commits imported ({skipped} already existed)\n"
            f"🔥 {days_a} active days · +{xp} XP"
        )
        if unlocked:
            tags = "  ".join(f"{a['icon']} {a['title']}" for a in unlocked)
            msg += f"\n[bold magenta]✨ unlocked:[/bold magenta] {tags}"

        h = client.health()
        cached = load_cache() or {}
        cache({"pet": pet, "nick": cached.get("nick")})
        live_for(pet, h, cached.get("nick"), msg=msg,
                 seconds=4.0 if unlocked else 3.0, fps=6.0)

    @app.command("install-hook")
    def install_hook(
        global_: bool = typer.Option(
            False, "--global", "-g",
            help="Install GLOBAL hooks (core.hooksPath) — feeds every repo.",
        ),
        uninstall: bool = typer.Option(
            False, "--uninstall",
            help="Remove the bytinho blocks from hooks (preserves the rest).",
        ),
    ):
        """Install git post-commit + pre-push hooks.

        Without --global: install only in the current repo.
        With --global: configures git core.hooksPath → every user repo gets plugged in.
        With --uninstall: removes the marked bytinho blocks, leaving the rest intact.
        """
        if uninstall and global_:
            ok, msg = _uninstall_global_hooks()
            if not ok:
                console.print(f"[red]✗ {msg}[/red]")
                raise typer.Exit(1)
            console.print(f"[green]✓ {msg}[/green]")
            return

        if uninstall:
            import subprocess as _sp
            try:
                git_dir = _sp.check_output(
                    ["git", "rev-parse", "--git-dir"], stderr=_sp.DEVNULL,
                ).decode().strip()
            except Exception:
                console.print("[red]✗ not in a git repo[/red]")
                raise typer.Exit(1)
            removed_any = False
            for name in ("post-commit", "pre-push"):
                if _remove_managed_block(Path(git_dir) / "hooks" / name):
                    console.print(f"[green]✓ {name}:[/green] block removed")
                    removed_any = True
            if not removed_any:
                console.print("[yellow]· nothing to remove.[/yellow]")
            return

        if global_:
            ok, msg = _install_global_hooks()
            if not ok:
                console.print(f"[red]✗ {msg}[/red]")
                raise typer.Exit(1)
            telemetry.track("hook_installed_global")
            console.print(f"[green]✓ global hooks installed at:[/green] {msg}")
            console.print(
                "[dim]from now on, EVERY git repo will feed Bytinho.[/dim]\n"
                "[dim italic]undo: bytinho install-hook --global --uninstall[/dim italic]"
            )
            return

        ok, msg = _install_hook_here()
        if not ok:
            console.print(f"[red]✗ {msg}[/red]")
            raise typer.Exit(1)
        telemetry.track("hook_installed")
        console.print(f"[green]✓ post-commit:[/green] {msg}")
        ok2, msg2 = _install_prepush_here()
        if ok2:
            console.print(f"[green]✓ pre-push:[/green] {msg2}")
        console.print(
            "[dim]now every `git commit` earns XP + 1 line. "
            "every `git push`, Bytinho takes a peek at the diff (won't block).[/dim]\n"
            "[dim italic]skip a single review: BYTINHO_SKIP=1 git push[/dim italic]\n"
            "[dim italic]want to plug ALL your repos at once? run: bytinho install-hook --global[/dim italic]"
        )

    @app.command()
    def setup():
        """Make Bytinho greet you every time you open a terminal."""
        home = Path.home()
        candidates = []
        shell = os.environ.get("SHELL", "")
        if "zsh" in shell:
            candidates.append(home / ".zshrc")
        if "bash" in shell or not candidates:
            candidates.append(home / ".bashrc")
        rc = next((p for p in candidates if p.exists()), candidates[0])
        cur = rc.read_text() if rc.exists() else ""
        if _GREET_MARK in cur:
            console.print(f"[yellow]· greet already installed in {rc}[/yellow]")
            return
        rc.write_text(cur.rstrip() + "\n" + _GREET_BLOCK)
        console.print(f"[green]✓ greet installed in[/green] {rc}")
        console.print("[dim]open a new terminal to see it.[/dim]")

    @app.command(hidden=True)
    def unsetup():
        """Remove the greet from your shell rc."""
        home = Path.home()
        removed = []
        for rc in (home / ".bashrc", home / ".zshrc"):
            if not rc.exists():
                continue
            cur = rc.read_text()
            if _GREET_MARK not in cur:
                continue
            before, _, rest = cur.partition(_GREET_MARK)
            _, _, after = rest.partition(_GREET_END)
            rc.write_text(before.rstrip() + "\n" + after.lstrip())
            removed.append(str(rc))
        if removed:
            console.print(f"[green]✓ removed from:[/green] {', '.join(removed)}")
        else:
            console.print("[yellow]· nothing to remove.[/yellow]")
