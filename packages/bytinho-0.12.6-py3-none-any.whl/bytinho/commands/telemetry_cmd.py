"""Comando `bytinho telemetry` — status + direito ao esquecimento.

Telemetria anônima é sempre ON (zero PII, só eventos agregados).
Única saída: `--forget` apaga tudo do server e desliga local.
"""
import typer

from .. import telemetry
from ..render import console


def register(app: typer.Typer) -> None:
    @app.command("telemetry")
    def telemetry_cmd(
        forget: bool = typer.Option(
            False, "--forget",
            help="Delete ALL your events from the server and disable. Irreversible.",
        ),
    ):
        """Show anonymous telemetry status.

        On by default. Use --forget to wipe everything from the server.
        Zero PII — only aggregated events (install, first_commit, etc).
        """
        if forget:
            if not typer.confirm(
                "delete ALL your events from the server and disable?",
                default=False,
            ):
                return
            ok = telemetry.forget_remote()
            telemetry.set_enabled(False)
            if ok:
                console.print(
                    "[green]✓ wiped from server. telemetry off on this device.[/green]"
                )
            else:
                console.print(
                    "[yellow]⚠ couldn't reach the server, "
                    "but disabled locally.[/yellow]"
                )
            return

        on_now = telemetry.is_enabled()
        if on_now:
            console.print(
                "[green]telemetry: ON[/green] [dim](anonymous, aggregated, zero PII)[/dim]"
            )
            console.print(
                "[dim]events collected: install / first_commit / first_unlock / "
                "stage_up / daily_active[/dim]"
            )
            console.print(
                "[dim]wipe everything from the server?[/dim] "
                "[cyan]bytinho telemetry --forget[/cyan]"
            )
        else:
            console.print("[yellow]telemetry: OFF[/yellow] [dim](you disabled it)[/dim]")
