"""Basic pet commands: status (open TUI), world (active devs counter).

Feed/play/sleep/wake were removed in MVP — the pet mirrors real dev
activity (commits + open editor). No manual care.
"""
import typer

from .. import client
from ..render import console


def register(app: typer.Typer) -> None:
    @app.command()
    def status():
        """Open Bytinho's TUI."""
        from ..speak_tui import SpeakTUI
        SpeakTUI().run()

    @app.command()
    def world():
        """Show how many devs are coding right now."""
        data = client.world()
        if data is None:
            console.print("[red]✗ server offline[/red]")
            raise typer.Exit(1)
        active = int(data.get("active_now", 0))
        chat   = int(data.get("chat_online", 0))
        total  = int(data.get("total_devs", 0))
        dev_w   = "dev" if active == 1 else "devs"
        chat_w  = "dev" if chat == 1 else "devs"
        total_w = "dev" if total == 1 else "devs"
        console.print(
            f"[bold cyan]🌍 {active}[/bold cyan] {dev_w} coding right now · "
            f"[dim]{chat} {chat_w} in The Square · {total} {total_w} total[/dim]"
        )
