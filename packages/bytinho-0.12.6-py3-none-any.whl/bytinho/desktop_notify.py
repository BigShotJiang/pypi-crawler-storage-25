"""Cross-platform desktop notifications (toast).

Best-effort. Failures are silent — never block, never raise.
No new dependencies: uses native CLIs already shipped with each OS.

Modes:
- off      : never notify
- smart    : only level_up, achievements, streak milestones (default)
- all      : every commit's xp gain too

The dispatch helper `dispatch_commit_event()` reads the pref and picks
what (if anything) to surface.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess


def _is_unsupported_env() -> bool:
    """Detect environments where notifications don't work or annoy users."""
    # Explicit user opt-out (overrides pref)
    if os.environ.get("BYTINHO_NO_NOTIFY") == "1":
        return True
    # SSH session — notifying on a remote box makes no sense
    if os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"):
        return True
    # CI / containers
    if os.environ.get("CI") or os.environ.get("GITHUB_ACTIONS"):
        return True

    sys = platform.system()

    # Linux (and WSL) need a display server
    if sys == "Linux":
        if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            return True
        # WSL without WSLg → DISPLAY may exist but daemon doesn't. Check uname.
        try:
            if "microsoft" in platform.uname().release.lower():
                # WSLg sets WAYLAND_DISPLAY=wayland-0 typically
                if not os.environ.get("WAYLAND_DISPLAY"):
                    return True
        except Exception:
            pass
    return False


def is_supported() -> bool:
    """Public: True if current environment can show notifications."""
    if _is_unsupported_env():
        return False
    sys = platform.system()
    if sys == "Linux":
        return shutil.which("notify-send") is not None
    if sys == "Darwin":
        return shutil.which("osascript") is not None
    if sys == "Windows":
        return shutil.which("powershell") is not None or shutil.which("pwsh") is not None
    return False


def env_status() -> str:
    """Short human-readable diagnostic for `bytinho doctor`."""
    if os.environ.get("BYTINHO_NO_NOTIFY") == "1":
        return "disabled (BYTINHO_NO_NOTIFY=1)"
    if os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"):
        return "skipped (SSH session)"
    if os.environ.get("CI"):
        return "skipped (CI environment)"
    sys = platform.system()
    if sys == "Linux":
        if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            return "no display server"
        if not shutil.which("notify-send"):
            return "notify-send missing (apt install libnotify-bin)"
        return f"linux + notify-send"
    if sys == "Darwin":
        return "macOS (osascript)"
    if sys == "Windows":
        return "windows (powershell toast)"
    return f"unsupported OS ({sys})"


# ---------------------------------------------------------------------------
# Dispatchers
# ---------------------------------------------------------------------------

def notify(title: str, body: str = "") -> bool:
    """Show a desktop toast. Returns True if dispatched, False if skipped.

    Always non-blocking: spawns the OS notifier in a detached process and
    returns immediately. Never raises. Safe to call from git hooks.
    """
    if _is_unsupported_env():
        return False

    sys = platform.system()
    try:
        if sys == "Linux":
            return _notify_linux(title, body)
        if sys == "Darwin":
            return _notify_macos(title, body)
        if sys == "Windows":
            return _notify_windows(title, body)
    except Exception:
        return False
    return False


def _notify_linux(title: str, body: str) -> bool:
    if not shutil.which("notify-send"):
        return False
    cmd = ["notify-send", "-a", "Bytinho", "-u", "low", "-t", "5000", title]
    if body:
        cmd.append(body)
    subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return True


def _notify_macos(title: str, body: str) -> bool:
    # osascript is always present on macOS. Quotes escaped defensively.
    safe_title = title.replace('"', "'").replace("\\", "")
    safe_body = body.replace('"', "'").replace("\\", "")
    if safe_body:
        script = f'display notification "{safe_body}" with title "{safe_title}"'
    else:
        script = f'display notification "{safe_title}"'
    subprocess.Popen(
        ["osascript", "-e", script],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return True


def _notify_windows(title: str, body: str) -> bool:
    # Use Windows Runtime via PowerShell. Hidden window, detached process.
    safe_title = title.replace("'", "''")
    safe_body = body.replace("'", "''") or " "
    ps_script = (
        "[Windows.UI.Notifications.ToastNotificationManager,"
        "Windows.UI.Notifications,ContentType=WindowsRuntime] | Out-Null;"
        "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        f"$xml.LoadXml('<toast><visual><binding template=\"ToastText02\">"
        f"<text id=\"1\">{safe_title}</text>"
        f"<text id=\"2\">{safe_body}</text>"
        "</binding></visual></toast>');"
        "$toast = [Windows.UI.Notifications.ToastNotification]::new($xml);"
        "[Windows.UI.Notifications.ToastNotificationManager]::"
        "CreateToastNotifier('Bytinho').Show($toast);"
    )
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(
        subprocess, "DETACHED_PROCESS", 0,
    )
    subprocess.Popen(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_script],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )
    return True


# ---------------------------------------------------------------------------
# Smart dispatcher (called by the post-commit code path)
# ---------------------------------------------------------------------------

# Streak days that trigger a milestone toast.
_STREAK_MILESTONES = {3, 7, 14, 30, 60, 100, 180, 365}


def dispatch_commit_event(
    *,
    mode: str,
    xp_gained: int,
    unlocked: list[dict] | None,
    pet_curr: dict,
    pet_prev: dict | None,
    streak_days: int,
    streak_days_prev: int | None,
) -> None:
    """Decide whether to notify based on current commit result + previous cache.

    Args:
        mode: user pref ("off" | "smart" | "all").
        xp_gained: XP from this commit (0 if throttled / duplicate).
        unlocked: list of fresh achievements ({code,title,icon,desc}).
        pet_curr: pet snapshot returned by server now.
        pet_prev: pet snapshot from local cache before this commit (may be None).
        streak_days: streak days now.
        streak_days_prev: streak days before commit (may be None).

    Always silent; failures don't propagate.
    """
    if mode == "off":
        return
    if not is_supported():
        return

    # 1) Achievements unlocked — highest priority
    if unlocked:
        first = unlocked[0]
        title = f"{first.get('icon', '🏅')} desbloqueou: {first.get('title', '?')}"
        body = first.get("desc", "")
        if len(unlocked) > 1:
            body = (body + f"  (+{len(unlocked) - 1} mais)").strip()
        notify("Bytinho", f"{title}  {body}".strip())
        return  # one toast per commit, max

    # 2) Stage up (junior → pleno, etc.)
    if pet_prev:
        s_prev = (pet_prev or {}).get("stage")
        s_curr = (pet_curr or {}).get("stage")
        if s_prev and s_curr and s_prev != s_curr:
            notify("Bytinho", f"✨ evolved to {s_curr}!")
            return

        # 3) Level up (numeric)
        lvl_prev = int((pet_prev or {}).get("level") or 0)
        lvl_curr = int((pet_curr or {}).get("level") or 0)
        if lvl_curr > lvl_prev > 0:
            notify("Bytinho", f"📈 subiu pro nível {lvl_curr}")
            return

    # 4) Streak milestone
    if (
        streak_days_prev is not None
        and streak_days > streak_days_prev
        and streak_days in _STREAK_MILESTONES
    ):
        notify("Bytinho", f"🔥 {streak_days} dias de streak!")
        return

    # 5) all-mode fallback: every XP-bearing commit
    if mode == "all" and xp_gained > 0:
        emoji = (pet_curr or {}).get("stage_emoji", "👾")
        notify("Bytinho", f"{emoji} +{xp_gained} XP")
