import os
from pathlib import Path

from platformdirs import user_data_dir

SERVER_URL = os.environ.get("BYTINHO_SERVER", "https://bytinho.com").rstrip("/")

# `BYTINHO_DATA` permite isolar dados (perfil/cache/prefs) por sessão.
# Útil pra demos, testes e múltiplos pets na mesma máquina.
_DATA_OVERRIDE = os.environ.get("BYTINHO_DATA")
if _DATA_OVERRIDE:
    DATA_DIR = Path(_DATA_OVERRIDE).expanduser().resolve()
else:
    DATA_DIR = Path(user_data_dir("bytinho", appauthor=False))
DATA_DIR.mkdir(parents=True, exist_ok=True)

STATE_FILE = DATA_DIR / "state.json"
USER_FILE  = DATA_DIR / "user.json"
GREET_FILE = DATA_DIR / "greet.json"  # cache pro shell prompt (TTL curto)
PREFS_FILE = DATA_DIR / "prefs.json"  # preferências locais (skin, etc.)


def supports_emoji() -> bool:
    """Heurística simples: UTF-8 + não ser cmd.exe legacy."""
    if os.environ.get("BYTINHO_NO_EMOJI"):
        return False
    enc = (os.environ.get("LC_ALL") or os.environ.get("LANG") or "").lower()
    if "utf" in enc:
        return True
    # Windows Terminal / VS Code definem WT_SESSION ou TERM_PROGRAM
    if os.environ.get("WT_SESSION") or os.environ.get("TERM_PROGRAM"):
        return True
    return False


EMOJI = supports_emoji()


def e(emoji: str, fallback: str) -> str:
    return emoji if EMOJI else fallback
