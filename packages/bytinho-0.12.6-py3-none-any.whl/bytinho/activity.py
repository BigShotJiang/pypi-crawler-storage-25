"""Passive activity detection.

Detecta editor (VSCode, Cursor, etc.) rodando e dá um mini-ping de XP
ao Bytinho — no máximo 1 vez por hora, anti-cheat.

Sem daemon: roda inline quando user invoca `bytinho` ou abre a TUI.
"""
from __future__ import annotations

import time
from pathlib import Path

from .config import DATA_DIR

_PING_FILE = DATA_DIR / "last_activity_ping"
_MIN_INTERVAL = 3600.0  # 1h entre pings (anti-abuse)

# Processos que indicam "user codando agora"
_EDITOR_PROCS = (
    "code",         # VSCode (CLI/server)
    "code-insiders",
    "cursor",       # Cursor
    "windsurf",     # Windsurf
    "nvim",
    "vim",
    "emacs",
    "subl",         # Sublime
    "zed",
    "helix", "hx",
)


def _editor_running() -> bool:
    """Detecta se algum editor conhecido está rodando agora.

    Cross-platform best effort: usa /proc no Linux, ps no resto.
    Falha silenciosa em qualquer erro (não bloqueia user).
    """
    try:
        # Fast path: /proc (Linux)
        proc = Path("/proc")
        if proc.is_dir():
            for entry in proc.iterdir():
                if not entry.name.isdigit():
                    continue
                try:
                    comm = (entry / "comm").read_text(errors="ignore").strip().lower()
                except OSError:
                    continue
                if comm in _EDITOR_PROCS:
                    return True
            return False
    except Exception:
        pass

    # Fallback: ps (macOS / BSD)
    try:
        import subprocess
        out = subprocess.check_output(
            ["ps", "-A", "-o", "comm="], timeout=2, text=True
        ).lower()
        return any(name in out for name in _EDITOR_PROCS)
    except Exception:
        return False


def _last_ping() -> float:
    try:
        return float(_PING_FILE.read_text().strip())
    except (OSError, ValueError):
        return 0.0


def _save_ping(t: float) -> None:
    try:
        _PING_FILE.write_text(str(t))
    except OSError:
        pass


def maybe_ping() -> bool:
    """Manda mini-XP se: editor rodando + última ping > 1h.

    Retorna True se efetivamente fez ping, False caso contrário.
    Falha silenciosa se servidor offline.
    """
    now = time.time()
    if now - _last_ping() < _MIN_INTERVAL:
        return False
    if not _editor_running():
        return False

    # Só salvamos o timestamp se servidor confirmou (ou não — best effort).
    _save_ping(now)
    try:
        from . import client
        # session_ping = sinal "dev tá vivo" (+3 XP, sem fake commit).
        client.session_ping(lang="py", editor="bytinho")
        return True
    except Exception:
        return False
