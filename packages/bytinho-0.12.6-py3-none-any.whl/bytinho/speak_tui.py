"""Split-screen TUI interativo para conversar com o Bytinho.

Layout (prompt_toolkit HSplit):
┌──────────────────────────────────┐
│  ✦ bytinho · @nick · ✨ spark    │  ← header fixo (1 linha)
│       ▄▄▄▄▄   sprite            │  ← sprite fixo (7 linhas)
├──────────────────────────────────┤
│  você: boa demais esse fix 🔥   │  ← histórico (preenche espaço restante)
│  → aham, três typos 😏          │    mostra os últimos N turns
│  você: e o build?               │
│  → quebrou. claro.               │
├──────────────────────────────────┤
│  spark ██████░░ 420/1000 🔥🔥  │  ← footer fixo (progress + shortcuts)
├──────────────────────────────────┤
│  > _                             │  ← input SEMPRE no rodapé
└──────────────────────────────────┘
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import time
from collections import deque
from io import StringIO

from rich.console import Console as RConsole, Group as RGroup
from rich.padding import Padding
from rich.text import Text as RText

from . import client
from .render import refresh
from .session import load_cache
from .talk_ui import (
    PAD_L,
    _header,
    _persona,
    _profile_url_line,
    _progress,
    _shortcuts,
    _sprite_block,
    help_lines,
)

# ---------------------------------------------------------------- helpers

def _term_w() -> int:
    try:
        return max(40, shutil.get_terminal_size((80, 24)).columns)
    except Exception:
        return 80


def _term_h() -> int:
    try:
        return max(12, shutil.get_terminal_size((80, 24)).lines)
    except Exception:
        return 24


# linhas reservadas para sprite + header info + rule + footer (progress + hint) + input
# valor empírico: ajustado para sprite médio + footer compacto.
_RESERVED_ROWS = 11


def _chat_window() -> int:
    """How many TEXT ROWS (not messages) fit in the chat area.

    Adapts to terminal height. Min 6, max 60.
    """
    return max(6, min(60, _term_h() - _RESERVED_ROWS))


def _full_rule(color: str) -> RText:
    """Rule that spans the full terminal width (aligns with sprite center)."""
    w = max(20, _term_w() - PAD_L * 2)
    return RText("─" * w, style=f"dim {color}")


def _to_ansi(renderable, width: int) -> str:
    """Render Rich renderable → raw ANSI escape string."""
    buf = StringIO()
    c = RConsole(file=buf, force_terminal=True, width=width, highlight=False)
    c.print(renderable)
    return buf.getvalue()


# Regex agressivo: cobre quase todos os blocos Unicode de emoji/pictograma.
_EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"   # Misc symbols, pictographs, emoticons, etc.
    "\U0001F1E6-\U0001F1FF"   # Regional indicators
    "\U00002600-\U000027BF"   # Misc symbols + dingbats
    "\U0001F900-\U0001F9FF"   # Supplemental symbols
    "\U0001FA70-\U0001FAFF"   # Symbols and pictographs ext-A
    "\U0000FE0F"              # Variation selector-16
    "\U0000200D"              # Zero-width joiner
    "]+",
    flags=re.UNICODE,
)


def _clean_reply(text: str) -> str:
    """Remove emojis e colapsa espaços. Pet fica mais limpo/profissional."""
    if not text:
        return text
    cleaned = _EMOJI_RE.sub("", text)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,!?;:])", r"\1", cleaned)
    return cleaned.strip()


# ---------------------------------------------------------------- TUI class

class SpeakTUI:
    """Interactive split-screen bytinho conversation TUI."""

    SYNC_INTERVAL    = 15.0   # seconds between server syncs
    WHISPER_INTERVAL = 60.0   # seconds before idle whisper
    TICK_RATE        = 0.5    # animation frame rate (seconds)

    # mode → (label, shortcut_key). MVP: 4 modos ativos (talk + 3 F-keys).
    SECTIONS: dict[str, tuple[str, str]] = {
        "talk":     ("Chat",            ""),
        "stats":    ("Stats",           "F1"),
        "ranking":  ("Weekly ranking",  "F2"),
        "ach":      ("Achievements",    "F3"),
    }

    def __init__(self) -> None:
        self.pet: dict    = {}
        self.nick: str | None = None
        self.streak: dict = {}
        self.challenge: dict | None = None
        self.tick: int    = 0
        self.history: deque[tuple[str, str]] = deque(maxlen=50)
        self._known_achs: set[str] = set()  # track unlocked achievement codes
        self.thinking: bool  = False
        self.last_sync: float   = 0.0
        self.last_whisper: float = time.time()
        self._app: object | None = None  # prompt_toolkit Application
        # mode: travado em "talk" no MVP (sem seções nem praça)
        self.mode: str = "talk"
        self._section_lines: list[str] = []
        self._section_loading: bool = False
        # state-change toasts: cooldown per alert key
        self._alert_at: dict[str, float] = {}
        # plaza (global chat) state
        self._global_msgs: deque[str] = deque(maxlen=200)
        self._online: int = 0
        self._top_achs: list[dict] = []
        self._ws_task: asyncio.Task | None = None
        self._ws_ref = None  # live websocket for sending
        self._core_online: bool | None = None   # None = not yet checked
        # scroll offset for chat history (0 = stuck at bottom).
        # PageUp/PageDown adjust it; reset on send and on mode switch.
        self._scroll: int = 0

    # ---- greeting on first open (personality-aware) ----------------------

    # One greeting per personality → shown when history is empty
    _GREET: dict[str, str] = {
        "fofo":        "hey, i'm here! 💜 wanna say hi?",
        "sarcástico":  "ah, you showed up. just what i was waiting for. what's up?",
        "motivador":   "LET'S GO! i'm ready! tell me what you're building! 🚀",
        "calmo":       "hi. all good? go ahead, talk.",
        "agitado":     "AAA you opened it!! send a message already lol",
        "tímido":      "...hi. glad you came. go ahead, i'm listening.",
        "dramático":   "FINALLY! i thought you had abandoned me forever!!",
        "estudioso":   "hello! i'm full of curiosity. what are you building?",
        "gamer":       "player 2 entered! ready? tell me what happened today.",
        "filosófico":  "to exist is to commit. what brought you here today?",
        "minimalista": "hi. talk.",
        # BR easter egg — chaotic persona keeps mixing languages on purpose
        "caótico":     "heyyy! salut! こんにちは! o que você precisa??",
    }
    _GREET_DEFAULT = "hey 👾 send me a message, i'm here."

    # ---- Rich → prompt_toolkit renderers --------------------------------

    def _header_text(self):
        from prompt_toolkit.formatted_text import ANSI
        w = _term_w()
        _, color = _persona(self.pet)
        hdr = _header(self.pet, self.nick)
        # offline indicator only — online state is implicit
        if self._core_online is False:
            hdr.append("  ·  ", style="dim")
            hdr.append("offline", style="dim red")
        grp = RGroup(
            RText(""),
            Padding(hdr, (0, 0, 0, PAD_L)),
            RText(""),
            _sprite_block(self.pet, color, tick=self.tick),
            Padding(_profile_url_line(self.nick), (0, 0, 0, PAD_L)),
            RText(""),
        )
        return ANSI(_to_ansi(grp, w))

    def _history_text(self):
        from prompt_toolkit.formatted_text import ANSI
        w = _term_w()
        _, color = _persona(self.pet)
        rule = Padding(_full_rule(color), (0, 0, 0, PAD_L))
        parts: list = [rule]

        if self.mode == "talk":
            # Wrap-aware windowing: pack messages from newest backwards until
            # we fill the available row budget. Each line wraps at content_w.
            row_budget = _chat_window()
            content_w = max(40, w - PAD_L - 8)  # account for prefix "  you: " / "  → "
            full = list(self.history)

            def _rows_for(text: str) -> int:
                if not text:
                    return 1
                rows = 0
                for ln in text.split("\n"):
                    rows += max(1, -(-len(ln) // content_w))  # ceil div
                return rows

            # Build cumulative row counts walking from end to start
            heights = [_rows_for(t) for _, t in full]
            # Find slice that fits within row_budget, honoring scroll offset
            # offset = how many rows of newest content to skip (scroll up)
            scroll_rows = self._scroll * 3  # PgUp scrolls ~3 rows
            total_rows = sum(heights)
            offset = max(0, min(scroll_rows, max(0, total_rows - row_budget)))

            # Walk from end accumulating rows, skipping `offset` rows from the bottom
            shown: list[tuple[str, str]] = []
            seen = 0
            budget = row_budget
            i = len(full) - 1
            # First skip from bottom by offset rows
            skip = offset
            while i >= 0 and skip > 0:
                if heights[i] <= skip:
                    skip -= heights[i]
                    i -= 1
                else:
                    break
            # Now collect upwards within budget
            while i >= 0 and budget > 0:
                shown.insert(0, full[i])
                budget -= heights[i]
                seen += 1
                i -= 1
            history_list = shown
            hidden_above = i + 1
            hidden_below = len(full) - (i + 1 + len(shown))
            if hidden_above > 0:
                parts.append(
                    Padding(RText(f"  ↑ {hidden_above} older  ·  PgUp to see more",
                                  style="dim italic"),
                            (0, 0, 1, 0))
                )
            if not history_list:
                parts.append(
                    Padding(RText("  tell me what's going on...", style="dim italic"),
                            (1, 0, 1, 0))
                )
            else:
                for role, text in history_list:
                    if role == "you":
                        t = RText()
                        t.append("  you: ", style=f"dim {color}")
                        t.append(text)
                    elif role == "bytinho":
                        t = RText()
                        t.append("  → ", style=f"bold {color}")
                        t.append(text)
                    elif role == "unlock":
                        t = RText()
                        t.append("  ✦ ", style="bold bright_yellow")
                        t.append(text, style="bold bright_yellow")
                    else:
                        t = RText(f"  · {text}", style="dim yellow")
                    parts.append(Padding(t, (0, 0, 0, 0)))
            if hidden_below > 0:
                parts.append(
                    Padding(RText(f"  ↓ {hidden_below} newer  ·  PgDn",
                                  style="dim italic"),
                            (0, 0, 0, 0))
                )
            if self.thinking:
                # Animated thinking indicator (visible spinner via dot count).
                import time as _t
                dots = "." * (1 + int(_t.time() * 2) % 3)
                parts.append(
                    Padding(RText(f"  ✦ thinking{dots}", style=f"bold {color}"),
                            (0, 0, 0, 0))
                )

        elif self.mode == "plaza":
            # global live chat — show 10 messages
            hdr = RText()
            hdr.append("  💬 Global Chat", style=f"bold {color}")
            hdr.append(f"  ·  {self._online} online", style="dim")
            parts.append(Padding(hdr, (0, 0, 0, 0)))
            if self._top_achs:
                top_str = "  ".join(
                    f"{a.get('icon','★')} {a.get('title','?')}"
                    for a in self._top_achs[:3]
                )
                parts.append(Padding(RText(f"  🏆 {top_str}", style="dim italic"), (0, 0, 0, 0)))
            parts.append(RText(""))
            if self._section_loading:
                parts.append(Padding(RText("  conectando...", style="dim italic"), (0, 0, 0, 0)))
            else:
                window = 14
                full = list(self._global_msgs)
                offset = max(0, min(self._scroll, max(0, len(full) - window)))
                end = len(full) - offset
                start = max(0, end - window)
                msgs = full[start:end]
                if offset > 0:
                    hidden = len(full) - end
                    parts.append(
                        Padding(RText(f"  ↑ {hidden} mais antigas  ·  PgDn",
                                      style="dim italic"),
                                (0, 0, 1, 0))
                    )
                if not msgs:
                    parts.append(Padding(RText("  no one has spoken yet — be the first!", style="dim italic"), (0, 0, 0, 0)))
                else:
                    for msg in msgs:
                        parts.append(Padding(RText(f"  {msg}"), (0, 0, 0, 0)))

        else:
            # static section view (stats / ranking / ach / next / closet / help)
            label, key = self.SECTIONS.get(self.mode, (self.mode, ""))
            title = RText()
            title.append("  ", style="default")
            title.append(label, style=f"bold {color}")
            if key:
                title.append(f"   {key}", style="dim")
            parts.append(Padding(title, (0, 0, 0, 0)))
            parts.append(RText(""))
            if self._section_loading:
                parts.append(Padding(RText("  loading...", style="dim italic"), (0, 0, 0, 0)))
            elif not self._section_lines:
                parts.append(Padding(RText("  nothing here yet", style="dim italic"), (0, 0, 0, 0)))
            else:
                # apply scroll offset (each line takes 2 rows: content + blank)
                visible_window = max(1, _chat_window())
                # each entry is content+blank → 2 rows per item
                max_visible = max(1, visible_window // 2)
                total = len(self._section_lines)
                offset = max(0, min(self._scroll, max(0, total - max_visible)))
                start = max(0, total - max_visible - offset)
                end = total - offset
                shown = self._section_lines[start:end]
                if offset > 0 or start > 0:
                    parts.append(Padding(RText(f"  ↑ {start} more above (PgUp)", style="dim italic"), (0, 0, 0, 0)))
                for line in shown:
                    parts.append(Padding(RText.from_markup(f"  {line}"), (0, 0, 0, 0)))
                    parts.append(RText(""))
                if offset > 0:
                    parts.append(Padding(RText(f"  ↓ {offset} more below (PgDn)", style="dim italic"), (0, 0, 0, 0)))

        parts.append(rule)
        return ANSI(_to_ansi(RGroup(*parts), w))

    def _footer_text(self):
        from prompt_toolkit.formatted_text import ANSI
        w = _term_w()
        _, color = _persona(self.pet)
        hint = _shortcuts(color)
        grp = RGroup(
            RText(""),
            Padding(_progress(self.pet, color, self.streak), (0, 0, 0, PAD_L)),
            RText(""),
            Padding(hint, (0, 0, 0, PAD_L)),
            RText(""),
        )
        return ANSI(_to_ansi(grp, w))

    # ---- async handlers --------------------------------------------------

    def _handle_shortcut(self, text: str) -> bool:
        """MVP: silencia inputs que começam com `:` ou `/`.

        Não existem modos `:` nem ações `/` no chat. Para stats/ranking
        use as F-keys, ou os subcomandos: `bytinho ranking`, `bytinho status`.
        """
        key = text.strip()
        return key.startswith((":", "/"))

    def _on_enter(self, buffer) -> None:
        text = buffer.text.strip()
        if not text:
            return
        buffer.reset()

        # Modo plaza: tudo que voc\u00ea escreve vai para o chat global.
        if self.mode == "plaza":
            asyncio.ensure_future(self._ws_send(text))
            self._scroll = 0
            if self._app:
                self._app.invalidate()
            return

        # Em qualquer outro overlay (stats / ranking / ach), texto livre volta ao chat
        if self.mode != "talk":
            self._switch_mode("talk")

        # MVP: ignora silenciosamente inputs com `:` ou `/` (sem modos)
        if self._handle_shortcut(text):
            return

        # guard: ignore if already waiting for a response (prevents duplicates)
        if self.thinking:
            return

        self.history.append(("you", text))
        self.thinking = True
        self._scroll = 0  # snap back to bottom on send
        if self._app:
            self._app.invalidate()
        asyncio.ensure_future(self._send(text))

    def _switch_mode(self, mode: str) -> None:
        prev = self.mode
        self.mode = mode
        self._scroll = 0  # reset scroll when switching sections
        # cancel WS if leaving plaza
        if prev == "plaza" and mode != "plaza":
            if self._ws_task and not self._ws_task.done():
                self._ws_task.cancel()
            self._ws_task = None
            self._ws_ref = None
        if mode == "talk":
            self._section_lines = []
            if self._app:
                self._app.invalidate()
            return
        if mode == "plaza":
            self._section_loading = True
            self._global_msgs.clear()
            self._online = 0
            self._ws_task = asyncio.ensure_future(self._ws_connect())
            if self._app:
                self._app.invalidate()
            return
        # static section
        self._section_lines = []
        self._section_loading = True
        if self._app:
            self._app.invalidate()
        asyncio.ensure_future(self._fetch_section(mode))

    async def _fetch_section(self, mode: str) -> None:
        loop = asyncio.get_running_loop()
        lines: list[str] = []
        try:
            if mode == "stats":
                lines = await loop.run_in_executor(None, self._fetch_stats)
            elif mode == "ranking":
                lines = await loop.run_in_executor(None, self._fetch_ranking)
            elif mode == "ach":
                lines = await loop.run_in_executor(None, self._fetch_ach)
            elif mode == "next":
                lines = await loop.run_in_executor(None, self._fetch_next)
            elif mode == "closet":
                lines = await loop.run_in_executor(None, self._fetch_closet)
            elif mode == "missions":
                lines = await loop.run_in_executor(None, self._fetch_missions)
            elif mode == "guard":
                lines = await loop.run_in_executor(None, self._fetch_guard)
            elif mode == "diff":
                lines = await loop.run_in_executor(None, self._fetch_diff)
            elif mode == "standup":
                lines = await loop.run_in_executor(None, self._fetch_standup)
            elif mode == "help":
                lines = help_lines()
        except Exception as exc:
            lines = [f"erro: {exc}"]
        self._section_loading = False
        self._section_lines = lines
        if self._app:
            self._app.invalidate()

    # ---- plaza WebSocket -------------------------------------------------

    @staticmethod
    def _fmt_msg(m: dict) -> str:
        emoji = m.get("stage_emoji", "👾")
        nick  = m.get("nick", "anon")
        lv    = m.get("level", 1)
        text  = m.get("text", "")
        return f"{emoji} @{nick} lv.{lv}: {text}"

    @staticmethod
    def _fmt_unlock(u: dict) -> str:
        icon  = u.get("icon", "★")
        nick  = u.get("nick", "?")
        title = u.get("title", "?")
        return f"✨ @{nick} desbloqueou {icon} {title}"

    async def _ws_connect(self) -> None:
        import json
        try:
            import websockets
        except ImportError:
            self._global_msgs.append("· falta websockets — pip install websockets")
            self._section_loading = False
            if self._app:
                self._app.invalidate()
            return
        backoff = 1.0
        while self.mode == "plaza":
            try:
                async with websockets.connect(client.ws_url()) as ws:
                    self._ws_ref = ws
                    self._section_loading = False
                    backoff = 1.0
                    if self._app:
                        self._app.invalidate()
                    async for raw in ws:
                        if self.mode != "plaza":
                            return
                        try:
                            d = json.loads(raw)
                        except ValueError:
                            continue
                        t = d.get("type")
                        if t == "history":
                            for m in d.get("messages", []):
                                self._global_msgs.append(self._fmt_msg(m))
                        elif t == "msg":
                            self._global_msgs.append(self._fmt_msg(d["message"]))
                        elif t == "presence":
                            self._online = d.get("online", 0)
                        elif t == "stats":
                            self._top_achs[:] = d.get("top_achievements", []) or []
                            for u in d.get("recent_unlocks", []) or []:
                                self._global_msgs.append(self._fmt_unlock(u))
                        elif t == "unlock_feed":
                            u = d.get("unlock") or {}
                            if u:
                                self._global_msgs.append(self._fmt_unlock(u))
                        elif t == "system":
                            self._global_msgs.append(f"· {d.get('text', '')}")
                        elif t == "ping":
                            try:
                                await ws.send(json.dumps({"type": "pong"}))
                            except Exception:
                                break
                        if self._app:
                            self._app.invalidate()
            except asyncio.CancelledError:
                return
            except Exception:
                if self.mode != "plaza":
                    return
                self._ws_ref = None
                self._global_msgs.append(f"· reconectando em {backoff:.0f}s...")
                if self._app:
                    self._app.invalidate()
                try:
                    await asyncio.sleep(backoff)
                except (asyncio.CancelledError, KeyboardInterrupt):
                    return
                backoff = min(backoff * 2, 30.0)
            finally:
                self._ws_ref = None

    async def _ws_send(self, text: str) -> None:
        import json
        if text in ("/quit", "/sair", "/exit"):
            self._switch_mode("talk")
            return
        if self._ws_ref is None:
            self._global_msgs.append("· desconectado, aguarda...")
            if self._app:
                self._app.invalidate()
            return
        try:
            await self._ws_ref.send(json.dumps({"type": "msg", "text": text}))
        except Exception:
            self._global_msgs.append("· falha ao enviar")
            if self._app:
                self._app.invalidate()

    # ---- section fetchers (run in thread executor) ----------------------

    def _fetch_stats(self) -> list[str]:
        from . import pet_logic
        pet = self.pet
        stage  = pet.get("stage", "egg")
        xp     = int(pet.get("xp", 0))
        level  = int(pet.get("level", 1))
        label  = pet_logic.STAGE_LABEL.get(stage, stage)
        nxt    = pet_logic.next_stage(stage)
        emoji  = pet_logic.STAGE_EMOJI.get(stage, "👾")
        streak_days = int((self.streak or {}).get("days") or 0)

        lines = [
            "[bold]IDOL[/bold]",
            f"  {emoji} {label}   [dim]lv {level}[/dim]",
            "",
            "[bold]PROGRESS[/bold]",
            f"  total xp           [bold]{xp}[/bold]",
        ]
        if nxt:
            thr = pet_logic.STAGE_THRESHOLD[nxt]
            nxt_label = pet_logic.STAGE_LABEL.get(nxt, nxt)
            lines.append(f"  next evolution     [dim]{nxt_label}[/dim]  [bold]{thr - xp}[/bold] xp left")
        if streak_days:
            lines.append(f"  streak             [bold yellow]🔥 {streak_days} days[/bold yellow]")
        if pet.get("asleep"):
            lines.append("  state              [dim italic]💤 sleeping (no recent activity)[/dim italic]")

        # Weekly challenge — light social hook
        ch = self.challenge or {}
        if ch:
            label   = ch.get("label", "?")
            prog    = int(ch.get("progress", 0))
            target  = int(ch.get("target", 1))
            done    = bool(ch.get("done"))
            days_l  = int(ch.get("days_left", 7))
            xp_rew  = int(ch.get("xp_reward", 50))
            bar_len = 14
            filled  = int(bar_len * min(prog, target) / max(target, 1))
            bar     = "█" * filled + "░" * (bar_len - filled)
            lines += ["", "[bold]WEEKLY CHALLENGE[/bold]", f"  {label}"]
            if done:
                lines.append(f"  [green]{bar}[/green]  [bold]{prog}/{target}[/bold]  [green]✅ +{xp_rew} XP[/green]")
            else:
                color = "red" if days_l <= 2 else "cyan"
                lines.append(f"  [{color}]{bar}[/{color}]  [bold]{prog}/{target}[/bold]  [dim]· +{xp_rew} XP · {days_l}d left[/dim]")
        return lines

    def _fetch_ranking(self) -> list[str]:
        try:
            data = client.ranking()
            top = data.get("top") or []
            you = data.get("you")  # P1-4
            if not top:
                return ["[dim italic]ranking offline[/dim italic]"]
            lines = []
            me = (load_cache() or {}).get("nick")
            for i, entry in enumerate(top[:10], 1):
                nick   = entry.get("nick") or "?"
                pts    = entry.get("xp_week") or entry.get("xp") or entry.get("points") or 0
                emoji  = entry.get("stage_emoji") or "👾"
                medal  = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, "  ")
                mark   = " [green]←[/green]" if me and nick == me else ""
                lines.append(f"  {medal} [bold]{i:>2}[/bold]  {emoji}  @{nick:<16} [dim]{pts:>6} xp[/dim]{mark}")
            # P1-4: append "you" se está fora do top
            if you is not None:
                lines.append("")
                lines.append(
                    f"  [bold yellow]#{you['rank']}[/bold yellow]"
                    f"[dim]/{you['total']}[/dim]  "
                    f"@{you['nick']:<16} [dim]{you['xp_week']:>6} xp[/dim]"
                )
            return lines
        except Exception:
            return ["[dim italic]ranking offline[/dim italic]"]

    def _fetch_ach(self) -> list[str]:
        try:
            achs = client.my_achievements()
            if not achs:
                return ["[dim italic]no achievements yet — commit something![/dim italic]"]
            lines = []
            for a in achs:
                icon  = a.get("icon") or "★"
                title = a.get("title") or a.get("name") or "?"
                desc  = a.get("desc") or ""
                if desc:
                    lines.append(f"  {icon}  [bold]{title}[/bold]")
                    lines.append(f"     [dim italic]{desc}[/dim italic]")
                else:
                    lines.append(f"  {icon}  [bold]{title}[/bold]")
            return lines
        except Exception:
            return ["[dim italic]achievements offline[/dim italic]"]

    def _fetch_next(self) -> list[str]:
        try:
            data = client.next_achievements()
            if not data:
                return ["[dim italic]no suggestions right now — keep coding![/dim italic]"]
            lines = []
            for a in data[:5]:
                icon  = a.get("icon", "🎯")
                title = a.get("title", "?")
                hint  = a.get("hint", "")
                lines.append(f"  {icon}  [bold]{title}[/bold]")
                if hint:
                    lines.append(f"     [dim italic]{hint}[/dim italic]")
            return lines
        except Exception:
            return ["[dim italic]next offline[/dim italic]"]

    def _fetch_closet(self) -> list[str]:
        try:
            data = client.closet()
            if not data:
                return ["[dim italic]no items in closet[/dim italic]"]
            items = data.get("items") or []
            if not items:
                return ["[dim italic]no items in closet[/dim italic]"]
            equipped = data.get("equipped")
            lines = []
            for item in items:
                code   = item.get("code") or ""
                name   = item.get("name") or "?"
                emoji  = item.get("emoji") or "★"
                owned  = item.get("owned") or item.get("equipped") or False
                is_active = item.get("equipped") or code == equipped
                if is_active:
                    lines.append(f"  {emoji}  [bold green]{name}[/bold green]  [dim](ativo)[/dim]")
                elif owned:
                    lines.append(f"  {emoji}  [bold]{name}[/bold]")
                else:
                    lines.append(f"  {emoji}  [dim]{name}[/dim]  [dim red]🔒[/dim red]")
            return lines
        except Exception:
            return ["[dim italic]closet offline[/dim italic]"]

    def _fetch_missions(self) -> list[str]:
        try:
            data = client.missions()
            if not data:
                return ["[dim italic]missions offline[/dim italic]"]
            lines = []
            for m in data:
                label    = m.get("label", "?")
                progress = m.get("progress", 0)
                target   = m.get("target", 1)
                done     = m.get("done", False)
                xp       = m.get("xp_reward", 0)
                bar_fill = int((progress / target) * 8) if target else 0
                bar = "█" * bar_fill + "░" * (8 - bar_fill)
                if done:
                    lines.append(f"  ✅  [bold green]{label}[/bold green]")
                    lines.append(f"     [green]{bar}[/green]  [dim]done[/dim]  [bold]+{xp} XP[/bold]")
                else:
                    lines.append(f"  🎯  [bold]{label}[/bold]")
                    lines.append(f"     [dim]{bar}[/dim]  [dim]{progress}/{target}[/dim]  [bold]+{xp} XP[/bold]")
            return lines
        except Exception:
            return ["[dim italic]missões offline[/dim italic]"]

    # ── utilidades dev (Bug #7): rodam comandos locais e mostram saída ──

    @staticmethod
    def _run_subcmd(args: list[str], timeout: int = 15) -> tuple[int, list[str]]:
        """Roda um subcomando do bytinho, retorna (exit_code, lines).

        Usa o mesmo executável que está rodando a TUI. Limpa códigos ANSI
        do Rich pra texto puro (vai ser re-estilizado pelo TUI).
        """
        import re as _re
        import subprocess
        import sys as _sys
        try:
            res = subprocess.run(
                [_sys.executable, "-m", "bytinho", *args],
                capture_output=True, text=True, timeout=timeout, check=False,
                env={**os.environ, "NO_COLOR": "1", "TERM": "dumb"},
            )
            raw = (res.stdout or "") + (res.stderr or "")
            # tira ANSI residuais
            ansi = _re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
            lines = [ansi.sub("", ln).rstrip() for ln in raw.splitlines()]
            return res.returncode, [ln for ln in lines if ln]
        except subprocess.TimeoutExpired:
            return 124, [f"[red]timeout (>{timeout}s)[/red]"]
        except Exception as e:
            return 1, [f"[red]erro: {e}[/red]"]

    def _fetch_guard(self) -> list[str]:
        code, out = self._run_subcmd(["commit-guard", "run"], timeout=20)
        head = "[bold]commit-guard (staged)[/bold]"
        hint = "[dim]:g to run again · :t back to talk[/dim]"
        if not out:
            return [head, "", "[dim italic]nothing staged. run `git add` first.[/dim italic]", "", hint]
        status = ("[bold green]✓ clean[/bold green]" if code == 0
                  else "[bold red]✗ blocked[/bold red]")
        return [head, status, "", *out, "", hint]

    def _fetch_diff(self) -> list[str]:
        code, out = self._run_subcmd(["diff-review"], timeout=15)
        head = "[bold]diff-review vs HEAD[/bold]"
        hint = "[dim]:v to run again · :t back to talk[/dim]"
        if not out:
            return [head, "", "[dim italic]no changes since HEAD.[/dim italic]", "", hint]
        return [head, "", *out, "", hint]

    def _fetch_standup(self) -> list[str]:
        code, out = self._run_subcmd(["standup"], timeout=15)
        head = "[bold]today's standup[/bold]"
        hint = "[dim]:u to refresh · :t back to talk[/dim]"
        if not out:
            return [head, "", "[dim italic]no commits today.[/dim italic]", "", hint]
        return [head, "", *out, "", hint]

    async def _send(self, text: str) -> None:
        if self._core_online is False:
            self.thinking = False
            self.history.append(("system", "no connection to The Core 📡  connect and try again"))
            if self._app:
                self._app.invalidate()
            return
        loop = asyncio.get_running_loop()
        try:
            res = await loop.run_in_executor(None, client.talk, text)
        except Exception:
            res = None
        self.thinking = False
        if res:
            reply = _clean_reply(res.get("reply") or "...") or "..."
            self.history.append(("bytinho", reply))
            if res.get("pet"):
                self.pet = res["pet"]
            # detect new achievements (server embeds them in pet.achievements)
            achs = (res.get("pet") or {}).get("achievements") or []
            for ach in achs:
                code = ach.get("code") or ach.get("id") or str(ach)
                if code and code not in self._known_achs:
                    self._known_achs.add(code)
                    icon  = ach.get("icon") or "★"
                    title = ach.get("title") or ach.get("name") or code
                    self.history.append(("unlock", f"{icon} {title} desbloqueado!"))
        else:
            self.history.append(("system", "offline — core fora do ar"))
        if self._app:
            self._app.invalidate()

    # ---- state-change toasts --------------------------------------------

    def _maybe_alert(self) -> None:
        """MVP: sem toasts — a TUI só mostra chat."""
        return

    async def _tick_loop(self) -> None:
        while True:
            await asyncio.sleep(self.TICK_RATE)
            self.tick += 1
            now = time.time()

            # Sync pet state from server
            if now - self.last_sync > self.SYNC_INTERVAL:
                try:
                    loop = asyncio.get_running_loop()
                    pet, _h, nick_, streak, _ = await loop.run_in_executor(None, refresh)
                    self.pet, self.nick, self.streak = pet, nick_, streak
                    cached = load_cache() or {}
                    self.challenge = cached.get("challenge")
                    self._core_online = True
                    self._maybe_alert()
                except Exception:
                    self._core_online = False
                self.last_sync = now

            # Idle whisper desativado no MVP — evita parecer que o pet
            # responde sozinho ou repete o saudo.
            # if now - self.last_whisper > self.WHISPER_INTERVAL:
            #     ...

            if self._app:
                self._app.invalidate()

    # ---- main entry point ------------------------------------------------

    def _load_initial(self) -> None:
        try:
            pet, _h, nick_, streak, _ = refresh()
            self.pet, self.nick, self.streak = pet, nick_, streak
            cached = load_cache() or {}
            self.challenge = cached.get("challenge")
            self._core_online = True
        except Exception:
            cached = load_cache() or {}
            from .ui import empty_pet
            self.pet   = cached.get("pet")    or empty_pet()
            self.nick  = cached.get("nick")
            self.streak = cached.get("streak") or {}
            self.challenge = cached.get("challenge")
            try:
                h = client.health()
                self._core_online = h.get("status") == "ok"
            except Exception:
                self._core_online = False
        self.last_sync = time.time()
        # seed known achievements so we only notify NEW ones
        cached = load_cache() or {}
        for ach in cached.get("achievements") or []:
            if isinstance(ach, dict):
                code = ach.get("code") or ach.get("id")
            else:
                code = str(ach)
            if code:
                self._known_achs.add(code)
        # inject greeting — Bytinho speaks first
        if not self.history:
            personality = (self.pet.get("soul") or {}).get("personality", "")
            greeting = self._GREET.get(personality, self._GREET_DEFAULT)
            self.history.append(("bytinho", greeting))

        # Challenge toast — leve, só quando relevante
        ch = self.challenge or {}
        if ch:
            done   = bool(ch.get("done"))
            days_l = int(ch.get("days_left", 7))
            label  = ch.get("label", "")
            xp_rew = int(ch.get("xp_reward", 50))
            if done:
                self.history.append((
                    "system",
                    f"⚔  desafio completo: {label}  ·  +{xp_rew} XP creditados",
                ))
            elif days_l <= 2 and int(ch.get("progress", 0)) < int(ch.get("target", 1)):
                prog   = int(ch.get("progress", 0))
                target = int(ch.get("target", 1))
                self.history.append((
                    "system",
                    f"⚔  challenge: {label}  [{prog}/{target}]  ·  only {days_l}d left",
                ))

    def run(self, initial_message: str | None = None,
            initial_mode: str = "talk") -> None:
        # Small-terminal warning before launching the TUI.
        if _term_w() < 80 or _term_h() < 14:
            from .render import console
            console.print(
                f"[yellow]⚠ terminal too small ({_term_w()}×{_term_h()}). "
                "Bytinho works best at 80×14 or larger. UI may render broken.[/yellow]"
            )
        try:
            from prompt_toolkit import Application
            from prompt_toolkit.buffer import Buffer
            from prompt_toolkit.key_binding import KeyBindings
            from prompt_toolkit.layout import HSplit, Layout, Window
            from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
        except ImportError:
            from .render import console
            console.print(
                "[red]missing prompt_toolkit.[/red] "
                "[dim]pip install 'prompt_toolkit>=3.0'[/dim]"
            )
            return

        self._load_initial()

        # Passive activity ping (fire-and-forget, rate-limited 1h)
        try:
            import threading
            from . import activity
            threading.Thread(target=activity.maybe_ping, daemon=True).start()
        except Exception:
            pass

        if initial_message:
            self.history.append(("you", initial_message))
            self.thinking = True

        input_buffer = Buffer(
            name="input",
            multiline=False,
            accept_handler=self._on_enter,
        )

        kb = KeyBindings()

        @kb.add("c-c")
        @kb.add("c-d")
        def _quit(event):
            event.app.exit()

        @kb.add("escape")
        def _back(event):
            if self.mode != "talk":
                self._switch_mode("talk")
                event.app.invalidate()

        def _toggle(target: str):
            def _h(event):
                self._switch_mode("talk" if self.mode == target else target)
                event.app.invalidate()
            return _h

        kb.add("f1")(_toggle("stats"))
        kb.add("f2")(_toggle("ranking"))
        kb.add("f3")(_toggle("ach"))
        # F4 livre pós-soft-launch (era plaza/chat).

        @kb.add("pageup")
        def _scroll_up(event):
            self._scroll += 3
            event.app.invalidate()

        @kb.add("pagedown")
        def _scroll_down(event):
            self._scroll = max(0, self._scroll - 3)
            event.app.invalidate()

        layout = Layout(
            HSplit([
                # ── pet header (sprite + info line), altura dinâmica
                Window(
                    content=FormattedTextControl(self._header_text),
                    dont_extend_height=True,
                    always_hide_cursor=True,
                ),
                # ── histórico de conversa, preenche espaço restante
                Window(
                    content=FormattedTextControl(
                        self._history_text, focusable=False
                    ),
                    wrap_lines=True,
                    always_hide_cursor=True,
                ),
                # ── footer (progress + shortcuts), altura dinâmica
                Window(
                    content=FormattedTextControl(self._footer_text),
                    dont_extend_height=True,
                    always_hide_cursor=True,
                ),
                # ── linha de input SEMPRE no rodapé
                Window(
                    content=BufferControl(buffer=input_buffer, focusable=True),
                    height=1,
                    get_line_prefix=lambda lineno, wrap_count: [("bold", "> ")],
                ),
            ])
        )

        self._app = Application(
            layout=layout,
            key_bindings=kb,
            full_screen=True,
            mouse_support=False,
            color_depth=None,  # auto-detect 256/truecolor
        )

        async def main() -> None:
            # Se tiver mensagem inicial, dispara request imediatamente
            if initial_message:
                asyncio.ensure_future(self._send(initial_message))

            # Abre direto numa seção (ex: bytinho status -> stats)
            if initial_mode and initial_mode != "talk":
                self._switch_mode(initial_mode)

            tick_task = asyncio.create_task(self._tick_loop())
            try:
                await self._app.run_async()
            finally:
                tick_task.cancel()
                try:
                    await tick_task
                except asyncio.CancelledError:
                    pass

        asyncio.run(main())
