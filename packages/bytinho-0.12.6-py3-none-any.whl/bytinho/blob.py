"""ASCII Blob System — grade fixa 13×8.

Filosofia: blobs não são desenhos. São componentes renderizados
dentro de uma grade fixa. Tudo passa por um validador estrito.

Estrutura de cada blob (8 linhas):
    L0 → effect_top  (aura, partículas)
    L1 → hat         (acessório do topo)
    L2 → body_top    (topo do corpo, definido pela skin)
    L3 → eyes_line   (olhos, formatado pela skin)
    L4 → mouth_line  (boca, formatado pela skin)
    L5 → body_bottom (base do corpo, definida pela skin)
    L6 → feet        (pés)
    L7 → effect_bottom

Regras invioláveis:
    * len(blob) == 8
    * all(len(line) == 13 for line in blob)
    * acessórios NÃO alteram o corpo — só linhas externas (hat / aura)
    * skins alteram apenas as bordas do corpo (L2, L3, L4, L5)
"""

from __future__ import annotations

from dataclasses import dataclass

WIDTH = 13
HEIGHT = 8


# ---------------------------------------------------------------------------
# componentes (todos com largura intrínseca controlada)
# ---------------------------------------------------------------------------

# olhos: sempre 3 chars
EYES: dict[str, str] = {
    "normal":   "- -",
    "happy":    "^ ^",
    "dead":     "x x",
    "asleep":   "_ _",
    "excited":  "o o",
    "focus":    "O O",
    "sad":      ". .",
}

# bocas: sempre 3 chars
MOUTHS: dict[str, str] = {
    "neutral":  " v ",
    "happy":    "\\_/",
    "sad":      " _ ",
    "surprise": " o ",
    "tired":    " ~ ",
    "smug":     " - ",
}

# pés: sempre 3 chars
FEET: dict[str, str] = {
    "normal":   "o o",
    "asleep":   "- -",
    "running":  "\\ /",
    "tippy":    ". .",
}

# linhas decorativas: sempre 13 chars
EFFECTS: dict[str, str] = {
    "none":   " " * 13,
    "stars":  "   *  *  *   ",
    "sparks": "  *  .  *    ",
    "z":      "    z z z    ",
    "dots":   "     . . .   ",
    "rain":   "  ' ' ' ' '  ",
}

# hats: sempre 13 chars (linha 1)
HATS: dict[str, str] = {
    "none":       " " * 13,
    "graduation": "    [===]    ",
    "wizard":     "     /\\      "[:13],  # garantir 13
    "wizard2":    "    /**\\     "[:13],
    "crown":      "    d|*|b    ",
    "cap":        "    /---\\    ",
    "headphones": "    /===\\    ",
    "antenna":    "      *      ",
    "halo":       "    .vVv.    ",
    "bandana":    "   <[==]>    ",
}

# Garantir que hats têm exatamente 13 chars (após truncate/normalização)
HATS = {k: v.ljust(13)[:13] for k, v in HATS.items()}


# ---------------------------------------------------------------------------
# skins — controlam apenas as bordas do corpo (L2, L3, L4, L5)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Skin:
    """Define o look do corpo. Todos os campos = 13 chars (após format)."""
    body_top:       str   # L2
    eye_line_fmt:   str   # L3, com 1 placeholder {} para eyes (3 chars)
    mouth_line_fmt: str   # L4, com 1 placeholder {} para mouth (3 chars)
    body_bottom:    str   # L5


SKINS: dict[str, Skin] = {
    "classic": Skin(
        body_top       = "    _____    ",
        eye_line_fmt   = "   / {} \\   ",
        mouth_line_fmt = "   | {} |   ",
        body_bottom    = "    \\___/    ",
    ),
    "cyber": Skin(
        body_top       = "    ╔═══╗    ",
        eye_line_fmt   = "   ║ {} ║   ",
        mouth_line_fmt = "   ║ {} ║   ",
        body_bottom    = "    ╚═══╝    ",
    ),
    "bubble": Skin(
        body_top       = "    .---.    ",
        eye_line_fmt   = "   ( {} )   ",
        mouth_line_fmt = "   ( {} )   ",
        body_bottom    = "    '---'    ",
    ),
    "dotted": Skin(
        body_top       = "    .....    ",
        eye_line_fmt   = "   : {} :   ",
        mouth_line_fmt = "   : {} :   ",
        body_bottom    = "    '''''    ",
    ),
}


# ---------------------------------------------------------------------------
# spec + render + validate
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class BlobSpec:
    eyes: str = "normal"
    mouth: str = "neutral"
    feet: str = "normal"
    hat: str = "none"
    skin: str = "classic"
    effect_top: str = "none"
    effect_bottom: str = "none"


class BlobValidationError(ValueError):
    """Raised quando um blob viola a grade 13×8."""


def validate(blob: list[str]) -> None:
    """Rejeita blobs quebrados. Levanta BlobValidationError com diagnóstico."""
    if not isinstance(blob, list):
        raise BlobValidationError(f"blob deve ser list[str], got {type(blob).__name__}")
    if len(blob) != HEIGHT:
        raise BlobValidationError(f"altura: esperado {HEIGHT} linhas, got {len(blob)}")
    for i, line in enumerate(blob):
        if not isinstance(line, str):
            raise BlobValidationError(f"linha {i}: esperado str, got {type(line).__name__}")
        if len(line) != WIDTH:
            raise BlobValidationError(
                f"linha {i}: largura {len(line)} != {WIDTH}\n  conteúdo: {line!r}"
            )


def _feet_line(ft: str) -> str:
    """Gera linha de pés centralizada (13 chars)."""
    if len(ft) != 3:
        raise BlobValidationError(f"feet deve ter 3 chars, got {len(ft)}: {ft!r}")
    return f"     {ft}     "  # 5 + 3 + 5 = 13


def render(spec: BlobSpec) -> list[str]:
    """Renderiza um blob 13×8. Sempre passa pelo validator antes de devolver."""
    if spec.skin not in SKINS:
        raise BlobValidationError(f"skin desconhecida: {spec.skin!r}")
    if spec.eyes not in EYES:
        raise BlobValidationError(f"eyes desconhecidos: {spec.eyes!r}")
    if spec.mouth not in MOUTHS:
        raise BlobValidationError(f"mouth desconhecida: {spec.mouth!r}")
    if spec.feet not in FEET:
        raise BlobValidationError(f"feet desconhecido: {spec.feet!r}")
    if spec.hat not in HATS:
        raise BlobValidationError(f"hat desconhecido: {spec.hat!r}")
    if spec.effect_top not in EFFECTS:
        raise BlobValidationError(f"effect_top desconhecido: {spec.effect_top!r}")
    if spec.effect_bottom not in EFFECTS:
        raise BlobValidationError(f"effect_bottom desconhecido: {spec.effect_bottom!r}")

    skin = SKINS[spec.skin]
    blob = [
        EFFECTS[spec.effect_top],
        HATS[spec.hat],
        skin.body_top,
        skin.eye_line_fmt.format(EYES[spec.eyes]),
        skin.mouth_line_fmt.format(MOUTHS[spec.mouth]),
        skin.body_bottom,
        _feet_line(FEET[spec.feet]),
        EFFECTS[spec.effect_bottom],
    ]
    validate(blob)
    return blob


# ---------------------------------------------------------------------------
# self-check do catálogo (roda no import — falha cedo)
# ---------------------------------------------------------------------------

def _selfcheck() -> None:
    """Confere que TODOS os componentes têm tamanho correto."""
    errors: list[str] = []

    for name, val in EYES.items():
        if len(val) != 3:
            errors.append(f"EYES[{name!r}] tem {len(val)} chars (esperado 3)")
    for name, val in MOUTHS.items():
        if len(val) != 3:
            errors.append(f"MOUTHS[{name!r}] tem {len(val)} chars (esperado 3)")
    for name, val in FEET.items():
        if len(val) != 3:
            errors.append(f"FEET[{name!r}] tem {len(val)} chars (esperado 3)")
    for name, val in HATS.items():
        if len(val) != WIDTH:
            errors.append(f"HATS[{name!r}] tem {len(val)} chars (esperado {WIDTH})")
    for name, val in EFFECTS.items():
        if len(val) != WIDTH:
            errors.append(f"EFFECTS[{name!r}] tem {len(val)} chars (esperado {WIDTH})")

    for name, skin in SKINS.items():
        if len(skin.body_top) != WIDTH:
            errors.append(f"SKINS[{name!r}].body_top: {len(skin.body_top)} chars")
        if len(skin.body_bottom) != WIDTH:
            errors.append(f"SKINS[{name!r}].body_bottom: {len(skin.body_bottom)} chars")
        # testa o format com placeholder de 3 chars
        try:
            eye_test = skin.eye_line_fmt.format("X X")
            if len(eye_test) != WIDTH:
                errors.append(
                    f"SKINS[{name!r}].eye_line_fmt produz {len(eye_test)} chars "
                    f"(esperado {WIDTH}): {eye_test!r}"
                )
        except (IndexError, KeyError) as e:
            errors.append(f"SKINS[{name!r}].eye_line_fmt format falhou: {e}")
        try:
            mouth_test = skin.mouth_line_fmt.format("X X")
            if len(mouth_test) != WIDTH:
                errors.append(
                    f"SKINS[{name!r}].mouth_line_fmt produz {len(mouth_test)} chars "
                    f"(esperado {WIDTH}): {mouth_test!r}"
                )
        except (IndexError, KeyError) as e:
            errors.append(f"SKINS[{name!r}].mouth_line_fmt format falhou: {e}")

    if errors:
        raise BlobValidationError(
            "blob system selfcheck FALHOU:\n  - " + "\n  - ".join(errors)
        )


_selfcheck()


# ---------------------------------------------------------------------------
# catálogo de specs prontos pra uso (presets temáticos)
# ---------------------------------------------------------------------------

PRESETS: dict[str, BlobSpec] = {
    "default":   BlobSpec(),
    "happy":     BlobSpec(eyes="happy", mouth="happy", feet="tippy"),
    "asleep":    BlobSpec(eyes="asleep", mouth="tired", feet="asleep", effect_top="z"),
    "excited":   BlobSpec(eyes="excited", mouth="surprise", effect_top="stars"),
    "scholar":   BlobSpec(eyes="focus", hat="graduation", skin="classic"),
    "wizard":    BlobSpec(eyes="focus", mouth="smug", hat="wizard", skin="bubble", effect_top="sparks"),
    "legend":    BlobSpec(eyes="happy", mouth="happy", hat="crown", effect_top="sparks", effect_bottom="stars"),
    "cyber":     BlobSpec(eyes="excited", mouth="smug", skin="cyber", hat="headphones"),
    "rainy":     BlobSpec(eyes="sad", mouth="sad", feet="asleep", effect_top="rain"),
    "graduate":  BlobSpec(eyes="happy", mouth="happy", hat="graduation", effect_bottom="stars"),
}


def validate_catalog() -> dict[str, list[str]]:
    """Renderiza todos os presets e devolve {name: blob}. Falha rápido."""
    out: dict[str, list[str]] = {}
    for name, spec in PRESETS.items():
        try:
            out[name] = render(spec)
        except BlobValidationError as e:
            raise BlobValidationError(f"preset {name!r}: {e}") from e
    return out


# ---------------------------------------------------------------------------
# CLI util — `python -m bytinho.blob` lista e valida tudo
# ---------------------------------------------------------------------------

def _main() -> int:
    print(f"Bytinho ASCII Blob System  ·  grade {WIDTH}×{HEIGHT}")
    print(f"Componentes: eyes={len(EYES)}  mouths={len(MOUTHS)}  feet={len(FEET)}  "
          f"hats={len(HATS)}  effects={len(EFFECTS)}  skins={len(SKINS)}")
    print(f"Presets: {len(PRESETS)}\n")

    catalog = validate_catalog()
    for name, blob in catalog.items():
        print(f"── {name} ──")
        for line in blob:
            print(f"|{line}|")
        print()
    print(f"✓ {len(catalog)} presets renderizados e validados.")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
