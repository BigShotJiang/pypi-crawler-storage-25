"""
Lore intro — exibida UMA única vez no primeiro `bytinho`.

Estilo Star Wars crawl: linhas aparecem com pausa curta.
SPACE / Enter / q pula imediatamente.
Flag salva em DATA_DIR/lore_shown (toca o arquivo, sem conteúdo).
"""
from __future__ import annotations

import sys
import threading

from .config import DATA_DIR

_FLAG = DATA_DIR / "lore_shown"

# ── skip via keypress ────────────────────────────────────────────────────────

_skipped = threading.Event()


def _watch_key() -> None:
    try:
        import select
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while not _skipped.is_set():
                r, _, _ = select.select([sys.stdin], [], [], 0.1)
                if r:
                    ch = sys.stdin.read(1)
                    if ch in (" ", "\r", "\n", "\x03", "q", "Q"):
                        _skipped.set()
                        break
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except Exception:
        pass  # non-tty (pipe / CI) → ignora silenciosamente


def _pause(secs: float) -> None:
    _skipped.wait(timeout=secs)


# ── conteúdo ─────────────────────────────────────────────────────────────────

_LORE: list[tuple[str, str]] = [
    ("dim white",    "A long time ago, in a terminal far, far away..."),
    ("",             ""),
    ("bold cyan",    "T H E   B Y T I N H O   C O R E"),
    ("",             ""),
    ("white",
     "Every developer's terminal hides a small life.\n"
     "Yours just woke up."),
    ("",             ""),
    ("dim",          "─" * 38),
    ("",             ""),
    ("white",
     "Bytinho lives inside your shell.\n"
     "He grows with each commit you push,\n"
     "every bug you fix, every refactor."),
    ("",             ""),
    ("white",
     "Talk to him. Feed him. Let him sleep.\n"
     "He'll keep you company while you code."),
    ("",             ""),
    ("dim",          "─" * 38),
    ("",             ""),
    ("bold magenta", "He's yours now."),
    ("",             ""),
    ("bold cyan",    "Welcome to the Core."),
]


# ── render ────────────────────────────────────────────────────────────────────

def show_lore() -> None:
    """Exibe o lore e marca como visto. No-op se já foi exibido antes."""
    if _FLAG.exists():
        return

    try:
        import shutil

        term_w = shutil.get_terminal_size((80, 24)).columns
        W = min(term_w, 80)

        # ANSI style map — bypasses Rich width-detection issues
        _ANSI: dict[str, str] = {
            "dim":          "\033[2m",
            "dim white":    "\033[2m",
            "white":        "\033[37m",
            "bold white":   "\033[1;37m",
            "bold cyan":    "\033[1;36m",
            "bold magenta": "\033[1;35m",
            "":             "\033[0m",
        }
        _RST = "\033[0m"

        def _line(text: str, style: str = "") -> None:
            code  = _ANSI.get(style, "")
            padded = text.center(W)
            sys.stdout.write(f"{code}{padded}{_RST}\r\n")
            sys.stdout.flush()

        def _blank() -> None:
            sys.stdout.write("\r\n")
            sys.stdout.flush()

        # inicia watcher de tecla em background
        t = threading.Thread(target=_watch_key, daemon=True)
        t.start()

        # clear screen
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()

        # ── "SPACE to skip" hint shown ONCE at the top, then crawl begins ─
        sys.stdout.write(f"\033[2m  [ SPACE to skip ]\033[0m\r\n")
        sys.stdout.flush()
        _blank()

        for style, text in _LORE:
            if _skipped.is_set():
                break
            if not text:
                _blank()
                _pause(0.15)
                continue
            for subline in text.split("\n"):
                if _skipped.is_set():
                    break
                _line(subline, style)
            _pause(0.6)

        if not _skipped.is_set():
            _pause(1.5)

        _skipped.set()

    except Exception:
        pass  # nunca quebra o fluxo principal

    finally:
        # marca como visto independente de erro ou skip
        try:
            _FLAG.touch()
        except Exception:
            pass
