"""Sprites animados do Bytinho — mascote pixel-art do terminal pet 👾.

Cada estágio é uma pose pixel-art que evolui conforme o XP. Todos os
sprites têm largura uniforme de 11 chars (normalizado por `_pad`) e
animam alternando duas poses (tick % 2).

Caracteres usados (todos single-width em fontes monoespaçadas):
- ` ` espaço     ▄ meio-bloco baixo    ▀ meio-bloco alto    █ bloco cheio
- ◉ olho         ◆ ✦ ✧ ▼ adornos       │ antena
"""


def _pad(lines: list[str]) -> list[str]:
    w = max(len(l) for l in lines)
    return [l.ljust(w) for l in lines]


# Cada variante tem um conjunto único de olhos + deco. Tudo single-width.
# Mantém o pet visualmente reconhecível entre estágios mas distinto entre users.
VARIANT_STYLE = {
    "a": {"eye_hi": "◉", "eye_lo": "▼", "deco": "◆", "egg_deco": "◆"},
    "b": {"eye_hi": "●", "eye_lo": "◆", "deco": "✦", "egg_deco": "▼"},
    "c": {"eye_hi": "◆", "eye_lo": "◇", "deco": "♥", "egg_deco": "✦"},
    "d": {"eye_hi": "✦", "eye_lo": "✧", "deco": "◉", "egg_deco": "♥"},
    "e": {"eye_hi": "◯", "eye_lo": "▽", "deco": "▼", "egg_deco": "◉"},
}


def _vstyle(v: str) -> dict:
    return VARIANT_STYLE.get(v, VARIANT_STYLE["a"])


def _eye(mood: float, asleep: bool, tick: int, v: str = "a") -> str:
    style = _vstyle(v)
    if asleep or tick % 8 == 0:
        return "─"
    if mood >= 50:
        return style["eye_hi"]
    return style["eye_lo"]


# ---------- estágios -------------------------------------------------------
#
# Filosofia: Bytinho é um terminal pet pixel-art 👾. Cada estágio é a mesma
# criatura crescendo / ganhando detalhes. Todos têm largura interna 11 chars.

def _egg(mood, asleep, v, tick):
    # ovo: mascote ainda fechado dentro da casca
    deco = _vstyle(v)["egg_deco"]
    show = deco if (tick // 3) % 2 == 0 else " "
    if asleep:
        show = " "
    return _pad([
        "   ▄▄▄▄▄   ",
        "  █▀▀▀▀▀█  ",
       f"  █  {show}  █  ",
        "  █▄▄▄▄▄█  ",
        "   ▀▀▀▀▀   ",
    ])


def _hatchling(mood, asleep, v, tick):
    # baby: 1 olho central, antenas pequenas
    e = _eye(mood, asleep, tick, v)
    if tick % 2 == 0:
        return _pad([
            "   ▄   ▄   ",
            "  ▄█▄▄▄█▄  ",
           f"  █  {e}  █  ",
            "  ▀█▀▀▀█▀  ",
            "   ▀   ▀   ",
        ])
    return _pad([
        "   ▄   ▄   ",
        "  ▄█▄▄▄█▄  ",
       f"  █  {e}  █  ",
        "   █▀▀▀█   ",
        "  ▀ ▀ ▀ ▀  ",
    ])


def _junior(mood, asleep, v, tick):
    # mascote clássico: 2 olhos, tentáculos
    e = _eye(mood, asleep, tick, v)
    if tick % 2 == 0:
        return _pad([
            "   ▄▄▄▄▄   ",
            "  ▄█▀▀▀█▄  ",
           f"  █ {e} {e} █  ",
            "  ▀█▀▀▀█▀  ",
            "   ▀   ▀   ",
        ])
    return _pad([
        "   ▄▄▄▄▄   ",
        "  ▄█▀▀▀█▄  ",
       f"  █ {e} {e} █  ",
        "  ▀▀█▀█▀▀  ",
        "  ▀  ▀  ▀  ",
    ])


def _pleno(mood, asleep, v, tick):
    # mascote pleno: 4 tentáculos, olhar firme
    e = _eye(mood, asleep, tick, v)
    if tick % 2 == 0:
        return _pad([
            "   ▄▄▄▄▄   ",
            "  █▀▀▀▀▀█  ",
           f"  █ {e}─{e} █  ",
            "  ▀█▀█▀█▀  ",
            "   ▀ ▀ ▀   ",
        ])
    return _pad([
        "   ▄▄▄▄▄   ",
        "  █▀▀▀▀▀█  ",
       f"  █ {e}─{e} █  ",
        "  █▀█▀█▀█  ",
        "  ▀ ▀ ▀ ▀  ",
    ])


def _senior(mood, asleep, v, tick):
    # mascote gigante: braços laterais, mais detalhe
    e = _eye(mood, asleep, tick, v)
    d = _vstyle(v)["deco"]
    if tick % 2 == 0:
        return _pad([
            " ▄ ▄▄▄▄▄ ▄ ",
            "▄█▄█▀▀▀█▄█▄",
           f"█ {d} {e} {e} {d} █",
            "▀█▄▄▄▄▄▄▄█▀",
            "  ▀ ▀ ▀ ▀  ",
        ])
    return _pad([
        " ▄ ▄▄▄▄▄ ▄ ",
        "▄█▄█▀▀▀█▄█▄",
       f"█ {d} {e} {e} {d} █",
        "▀▀█▄▄▄▄▄█▀▀",
        " ▀  ▀ ▀  ▀ ",
    ])


def _staff(mood, asleep, v, tick):
    # mascote mestre: antena de pensamento + corpo robusto
    e = _eye(mood, asleep, tick, v)
    d = _vstyle(v)["deco"]
    spark = d if tick % 2 == 0 else "✦"
    if asleep:
        spark = "z"
    if tick % 2 == 0:
        return _pad([
           f"     {spark}     ",
            "     │     ",
            "  ▄▄▄█▄▄▄  ",
            " ▄█▀▀▀▀▀█▄ ",
           f" █  {e}─{e}  █ ",
            " ▀█▄▄▄▄▄█▀ ",
            "  ▀ ▀ ▀ ▀  ",
        ])
    return _pad([
       f"     {spark}     ",
        "     │     ",
        "  ▄▄▄█▄▄▄  ",
        " ▄█▀▀▀▀▀█▄ ",
       f" █  {e}─{e}  █ ",
        " ▀▀█▄▄▄█▀▀ ",
        " ▀  ▀ ▀  ▀ ",
    ])


def _tenx(mood, asleep, v, tick):
    # mascote 10x: aura de partículas em volta
    e = _eye(mood, asleep, tick, v)
    d = _vstyle(v)["deco"]
    s1, s2 = ("✦", "✧") if tick % 2 == 0 else ("✧", "✦")
    if asleep:
        s1 = s2 = " "
    if tick % 2 == 0:
        return _pad([
           f" {s1} ▄▄▄▄▄ {s2} ",
            "  █▀▀▀▀▀█  ",
           f"  █ {e}{d}{e} █  ",
            "  ▀█▄▄▄█▀  ",
           f" {s2} ▀▀ ▀▀ {s1} ",
        ])
    return _pad([
       f" {s1} ▄▄▄▄▄ {s2} ",
        "  █▀▀▀▀▀█  ",
       f"  █ {e}{d}{e} █  ",
        "  ▀▀█▀█▀▀  ",
       f" {s2} ▀ ▀ ▀ {s1} ",
    ])


def _legend(mood, asleep, v, tick):
    # mascote lendário: coroa de espinhos em cima
    e = _eye(mood, asleep, tick, v)
    d = _vstyle(v)["deco"]
    glow = "▼ ▼ ▼ ▼" if tick % 2 == 0 else "▽ ▽ ▽ ▽"
    if asleep:
        glow = "z z z z"
    if tick % 2 == 0:
        return _pad([
           f"  {glow}  ",
            "  █▄█▄█▄█  ",
            " ▄█▀▀▀▀▀█▄ ",
           f" █  {e}{d}{e}  █ ",
            " ▀█▄▄▄▄▄█▀ ",
            "  ▀ ▀ ▀ ▀  ",
        ])
    return _pad([
       f"  {glow}  ",
        "  █▄█▄█▄█  ",
        " ▄█▀▀▀▀▀█▄ ",
       f" █  {e}{d}{e}  █ ",
        " ▀▀█▄▄▄█▀▀ ",
        " ▀  ▀ ▀  ▀ ",
    ])


_RENDERERS = {
    "egg": _egg, "hatchling": _hatchling, "junior": _junior,
    "pleno": _pleno, "senior": _senior, "staff": _staff,
    "tenx": _tenx, "legend": _legend,
}


# ---------- balõezinhos de pensamento --------------------------------------

THOUGHTS_HAPPY  = ["♪", "♫", "<3", ":)", "*"]
THOUGHTS_HUNGRY = ["pizza?", "pão", "ração?", "cafe", "bolacha"]
THOUGHTS_TIRED  = ["zzz", "soninho", "xau", "..."]
THOUGHTS_BORED  = ["...", "tedio", "cade tu", "alo?"]
THOUGHTS_CODE   = ["git push", "rm -rf?", ":wq", "ship it", "TODO"]


def thought_for(pet: dict, tick: int) -> str | None:
    """Mostra um balão por 3 ticks consecutivos a cada 10 (evita flash de 1 frame)."""
    if tick % 10 not in (5, 6, 7):
        return None
    # Seed estável durante os 3 ticks: usa tick // 10 pro thought não trocar
    # de palavra no meio da exibição.
    seed = tick // 10
    if pet.get("asleep"):
        return THOUGHTS_TIRED[seed % len(THOUGHTS_TIRED)]
    hunger = pet.get("hunger", 100)
    energy = pet.get("energy", 100)
    mood   = pet.get("mood", 100)
    if hunger < 30:
        return THOUGHTS_HUNGRY[seed % len(THOUGHTS_HUNGRY)]
    if energy < 30:
        return THOUGHTS_TIRED[seed % len(THOUGHTS_TIRED)]
    if mood < 30:
        return THOUGHTS_BORED[seed % len(THOUGHTS_BORED)]
    if mood >= 70:
        return THOUGHTS_HAPPY[seed % len(THOUGHTS_HAPPY)]
    return THOUGHTS_CODE[seed % len(THOUGHTS_CODE)]


# ---------- API pública ----------------------------------------------------

def render(stage: str, mood: float, asleep: bool,
           variant: str = "a", tick: int = 0) -> str:
    fn = _RENDERERS.get(stage, _hatchling)
    v = variant if variant in "abcde" else "a"
    return "\n".join(fn(float(mood), bool(asleep), v, int(tick)))


def sway(tick: int, asleep: bool) -> int:
    """Quanto o sprite anda pra esquerda/direita neste frame.

    Range: -2..+2 chars. Quando dorme, fica parado.
    """
    if asleep:
        return 0
    cycle = tick % 8
    return [0, 1, 2, 1, 0, -1, -2, -1][cycle]
