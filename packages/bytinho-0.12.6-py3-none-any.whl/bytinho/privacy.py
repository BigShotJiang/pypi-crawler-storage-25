"""Privacy / opt-out helpers (P0-4).

Bytinho's git hook sends commit metadata to the server: message (200 chars),
file count, language types, line counts, branch, kind. NO source code, NO
file paths. Still, some repos are private/sensitive and the user must be
able to opt out per-repo or globally.

Three levels of opt-out, checked in order:
  1. ``BYTINHO_SKIP=1`` env var — pula um commit/push pontual.
  2. ``.bytinhoignore`` file in repo root — pula esse repo pra sempre.
  3. Global skip list (``DATA_DIR/skip-repos.txt``, um path por linha) —
     pula repos lock-listados sem precisar mexer no checkout.

Tudo é local. A CLI checa antes de mandar qualquer payload.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from .config import DATA_DIR

SKIP_FILE = DATA_DIR / "skip-repos.txt"
IGNORE_FILENAME = ".bytinhoignore"


def _repo_root() -> Path | None:
    """Toplevel do repo git do cwd, ou None se não está num repo."""
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL, timeout=2,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired,
            FileNotFoundError):
        return None
    p = out.decode("utf-8", errors="replace").strip()
    return Path(p).resolve() if p else None


def _load_global_list() -> list[Path]:
    if not SKIP_FILE.exists():
        return []
    out: list[Path] = []
    for line in SKIP_FILE.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            out.append(Path(line).expanduser().resolve())
        except OSError:
            continue
    return out


def _save_global_list(paths: list[Path]) -> None:
    SKIP_FILE.parent.mkdir(parents=True, exist_ok=True)
    body = "\n".join(str(p) for p in paths)
    SKIP_FILE.write_text(body + ("\n" if body else ""))


def is_skipped() -> tuple[bool, str]:
    """Retorna (True, motivo) se o cwd deve pular envio. Motivo legível pro user."""
    if os.environ.get("BYTINHO_SKIP", "").strip() in ("1", "true", "yes"):
        return True, "BYTINHO_SKIP=1"
    root = _repo_root()
    if root is None:
        return False, ""
    if (root / IGNORE_FILENAME).exists():
        return True, f"{IGNORE_FILENAME} no repo"
    for p in _load_global_list():
        if root == p:
            return True, "skip-list global"
    return False, ""


def add_here() -> tuple[bool, str]:
    """Cria .bytinhoignore no repo atual."""
    root = _repo_root()
    if root is None:
        return False, "não tô num repo git"
    f = root / IGNORE_FILENAME
    if f.exists():
        return True, f"já existe: {f}"
    f.write_text(
        "# Bytinho pula este repo. Apague este arquivo pra reativar.\n"
    )
    return True, str(f)


def rm_here() -> tuple[bool, str]:
    """Remove .bytinhoignore do repo atual."""
    root = _repo_root()
    if root is None:
        return False, "não tô num repo git"
    f = root / IGNORE_FILENAME
    if not f.exists():
        return False, f"não existe: {f}"
    f.unlink()
    return True, str(f)


def add_global(path: str) -> tuple[bool, str]:
    """Adiciona path à skip-list global."""
    p = Path(path).expanduser().resolve()
    cur = _load_global_list()
    if p in cur:
        return True, f"já estava na lista: {p}"
    cur.append(p)
    _save_global_list(cur)
    return True, str(p)


def rm_global(path: str) -> tuple[bool, str]:
    """Remove path da skip-list global."""
    p = Path(path).expanduser().resolve()
    cur = _load_global_list()
    if p not in cur:
        return False, f"não estava na lista: {p}"
    cur.remove(p)
    _save_global_list(cur)
    return True, str(p)


def list_global() -> list[Path]:
    return _load_global_list()
