"""Sprites locais dos cosméticos (hats). Single-width chars, largura 11.

Server manda só o `code` equipado em pet["hat"]; cliente desenha com
arte ASCII local. Mantém a mesma filosofia dos sprites: 0 deps externas,
nada de emoji wide dentro do sprite (só na descrição textual).
"""
from __future__ import annotations


# Cada hat tem 1 ou 2 linhas que vão ACIMA do sprite (largura 11 pra alinhar
# com STAGE_W central). Usa só caracteres single-width.
HAT_SPRITES: dict[str, list[str]] = {
    "tophat": [
        "   ▄▄▄▄▄   ",
        "   █████   ",
    ],
    "crown": [
        "  ▄ ▄ ▄ ▄  ",
        "  █▀█▀█▀█  ",
    ],
    "fire": [
        "    ▄ ▄    ",
        "   █▀█▀█   ",
    ],
}


HAT_META: dict[str, dict[str, str]] = {
    "tophat": {"name": "Cartola", "emoji": "🎩"},
    "crown":  {"name": "Coroa",   "emoji": "👑"},
    "fire":   {"name": "Chamas",  "emoji": "🔥"},
}


def render_hat(code: str) -> str | None:
    """Retorna o bloco ASCII do hat (multilinha) ou None se code inválido."""
    art = HAT_SPRITES.get(code)
    if not art:
        return None
    return "\n".join(art)


def hat_meta(code: str) -> dict | None:
    return HAT_META.get(code)
