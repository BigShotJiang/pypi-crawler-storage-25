"""Helpers do lado cliente relacionados ao dialogue (sem deps de server)."""
from __future__ import annotations

import random

IDLE_WHISPERS: dict[str, list[str]] = {
    "fofo":       ["here if you need 💜", "breathe deep, cutie 🫶",
                   "you're doing great, i can see it 🌸"],
    "sarcástico": ["still staring at the stack trace? 🥱",
                   "that bug won't fix itself ☕",
                   "suspicious silence 😏"],
    "motivador":  ["1 commit. just 1. LET'S GO 🔥", "breathe. refocus. ⚡",
                   "almost there. i know you are. 🚀"],
    "calmo":      ["breathe 🍃", "one thing at a time",
                   "the storm is already passing ☁️"],
    "agitado":    ["HEYYYY where are you ⚡", "lol look at this silence 🎉",
                   "helloooo dev 🌀"],
    "caótico":    ["the void* is watching 🐈",
                   "cheese bread solves everything 🍞",
                   "git is just a diary pretending 🌀"],
    "tímido":    ["...hey. here if you need 🌷",
                   "you can talk, i'm listening carefully ✨",
                   "no rush, okay? 🤍"],
    "dramático": ["SUSPICIOUS SILENCE!! are you okay?? 😱",
                   "the terminal went quiet... is this the end? 💫",
                   "COME BACK!! the code needs you!! 🎭"],
    "estudioso":  ["curious: what are you studying today? 🔍",
                   "is this silence reading or debugging? 📚",
                   "got something interesting to share? 💡"],
    "gamer":      ["idle player detected 🎮",
                   "the quest won't complete itself ⚔️",
                   "hey, there's still a save here 🏆"],
    "filosófico": ["the blinking cursor is a koan 🌌",
                   "the silence between commits is also code 💭",
                   "what keeps you here? 🔮"],
    "minimalista": [".", "here.", "talk."],
}


def idle_whisper_for(persona: str) -> str:
    bag = IDLE_WHISPERS.get(persona) or IDLE_WHISPERS["fofo"]
    return random.choice(bag)
