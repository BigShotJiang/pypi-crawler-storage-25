"""Evolução lenta de personalidade segundo o comportamento do dev.

Filosofia: o pet espelha o dev. A cada N commits/dias, sugere (não força)
uma persona que combine com o que ele anda fazendo.

100% local. Sem servidor. Não muda nada sem o dev confirmar (`bytinho persona <x>`).
"""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timedelta, timezone

from .config import DATA_DIR

_HISTORY = DATA_DIR / "commit_history.json"
_HISTORY_MAX = 200  # mantém só os últimos 200 hooks

# Heurísticas de match: kind/lang dominantes → persona sugerida.
_KIND_TO_PERSONA = {
    "fix":      "estudioso",     # caça-bug → curioso
    "refactor": "minimalista",   # limpa código → menos é mais
    "docs":     "calmo",         # escreve docs → paciência
    "test":     "estudioso",
    "feat":     "motivador",
    "chore":    "minimalista",
    "perf":     "estudioso",
}


def record_commit(kind: str, lang: str, hour: int) -> None:
    """Append leve. Chamado pelo hook git."""
    items = _load()
    items.append({
        "ts":   datetime.now(timezone.utc).isoformat(),
        "kind": kind or "other",
        "lang": lang or "?",
        "hour": int(hour),
    })
    items = items[-_HISTORY_MAX:]
    _save(items)


def suggest_persona() -> str | None:
    """Retorna persona sugerida com base nos últimos 14 dias.

    Só sugere se houver sinal claro (≥ 5 commits, kind dominante ≥ 40%).
    """
    items = _recent(days=14)
    if len(items) < 5:
        return None
    kinds = Counter(i["kind"] for i in items)
    top, n = kinds.most_common(1)[0]
    if n / len(items) < 0.40:
        return None
    return _KIND_TO_PERSONA.get(top)


def streak_signal() -> dict:
    """Retorna {'days': int, 'commits': int, 'night_ratio': float}.

    Útil pra hints contextuais ("3 dias seguidos refatorando, hein?").
    """
    items = _recent(days=14)
    if not items:
        return {"days": 0, "commits": 0, "night_ratio": 0.0}
    days = len({i["ts"][:10] for i in items})
    night = sum(1 for i in items if i["hour"] >= 22 or i["hour"] < 6)
    return {
        "days": days,
        "commits": len(items),
        "night_ratio": round(night / len(items), 2),
    }


# ---------- private ----------

def _load() -> list[dict]:
    if not _HISTORY.exists():
        return []
    try:
        return json.loads(_HISTORY.read_text("utf-8"))
    except (ValueError, OSError):
        return []


def _save(items: list[dict]) -> None:
    try:
        _HISTORY.write_text(json.dumps(items), "utf-8")
    except OSError:
        pass


def _recent(days: int) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    out = []
    for i in _load():
        try:
            ts = datetime.fromisoformat(i["ts"])
            if ts >= cutoff:
                out.append(i)
        except (ValueError, KeyError):
            continue
    return out
