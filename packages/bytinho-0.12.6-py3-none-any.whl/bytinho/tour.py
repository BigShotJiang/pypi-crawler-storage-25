"""Tour interativo de 5 telas — onboarding rápido pós-lore.

Roda no primeiro `bytinho` e em qualquer execução até o usuário
marcar como visto. Pode ser pulado com Ctrl+C ou Esc.
"""
from __future__ import annotations

from rich.panel import Panel
from rich.text import Text

from . import prefs
from .render import console


def _press_enter(skip_label: str = "Esc/Ctrl+C to skip") -> bool:
    """Wait for Enter. Returns False if user skips (Ctrl+C / EOF)."""
    try:
        console.print(f"[dim italic]Enter to continue  ·  {skip_label}[/dim italic]")
        input()
        return True
    except (EOFError, KeyboardInterrupt):
        return False


def _screen(num: int, total: int, title: str, body: Text) -> None:
    console.clear()
    console.print()
    console.print(f"[dim]({num}/{total})[/dim]  [bold cyan]{title}[/bold cyan]")
    console.print()
    console.print(Panel(body, border_style="dim cyan", padding=(1, 3), width=72))
    console.print()


def run_tour() -> None:
    """Mostra o tour. Marca como visto ao final OU se user pular."""
    if prefs.has_seen_tour():
        return

    # P1-1: tour exige Enter interativo. Em non-tty/CI marca como visto sem
    # mostrar nada (next call no-ops) — evita travar scripts.
    from .tty import is_interactive
    if not is_interactive():
        prefs.mark_tour_seen()
        return

    total = 5

    # ── 1: what it is
    body = Text.from_markup(
        "[bold]Bytinho[/bold] is a terminal pet that grows with your commits.\n\n"
        "It chats with you (AI), tracks streaks, unlocks achievements\n"
        "and shows your workflow state in a TUI.\n\n"
        "[dim]No login. No password. Just a local UUID.[/dim]"
    )
    _screen(1, total, "what is Bytinho", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 2: chat
    body = Text.from_markup(
        "In the TUI, [bold cyan]type any text[/bold cyan] and hit Enter.\n"
        "Bytinho replies via AI, in his current persona.\n\n"
        "[dim]example:[/dim]\n"
        "  [bold]> hey, just shipped feature X[/bold]\n"
        "  [cyan]→ nice. run the tests before you push.[/cyan]\n\n"
        "[dim]Change his tone:[/dim]  [cyan]bytinho persona minimalist[/cyan]"
    )
    _screen(2, total, "chat", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 3: navigate
    body = Text.from_markup(
        "Use the [bold cyan]F-keys[/bold cyan] to switch panels:\n\n"
        "  [bold cyan]F1[/bold cyan]   stats          [bold cyan]F2[/bold cyan]   ranking\n"
        "  [bold cyan]F3[/bold cyan]   achievements\n\n"
        "  [bold cyan]PgUp/PgDn[/bold cyan]   scroll history\n"
        "  [bold cyan]Esc      [/bold cyan]   back / quit\n\n"
        "[dim]More via CLI:[/dim] [cyan]bytinho ranking[/cyan], [cyan]bytinho status[/cyan], [cyan]bytinho --help[/cyan]"
    )
    _screen(3, total, "navigate", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 4: how the pet grows
    body = Text.from_markup(
        "Bytinho [bold]mirrors your work[/bold] — he evolves on his own\n"
        "as you commit. No tamagotchi feeding mechanics.\n\n"
        "  [bold cyan]commit[/bold cyan]   raises spark (XP) and keeps streak 🔥\n"
        "  [bold cyan]push  [/bold cyan]   confirms your work\n\n"
        "[dim]The bar below the sprite shows current spark + streak.[/dim]"
    )
    _screen(4, total, "how he grows", body)
    if not _press_enter():
        prefs.mark_tour_seen()
        return

    # ── 5: commits = XP
    body = Text.from_markup(
        "Bytinho grows automatically with every [bold]git commit[/bold].\n\n"
        "If you accepted the hook earlier, you're set.\n"
        "Otherwise, inside any git repo run:\n\n"
        "  [bold cyan]bytinho install-hook[/bold cyan]\n\n"
        "[dim]The hook is non-blocking: if the server is down, your commit still goes through.[/dim]\n\n"
        "[bold green]let's go![/bold green]  open the TUI with [bold cyan]bytinho[/bold cyan]\n"
        "[dim]replay this tour:[/dim]  [cyan]bytinho tour[/cyan]"
    )
    _screen(5, total, "commits = XP", body)
    _press_enter("Enter to start")

    prefs.mark_tour_seen()
    console.clear()
