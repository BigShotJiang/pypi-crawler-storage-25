"""UI premium do `bytinho talk` — mascote Bytinho como protagonista.

Princípios:
- O sprite (sprites.render) é o elemento mais prominente, centrado, com
  respiro generoso acima e abaixo. NUNCA editamos sprites.py.
- Header de 1 linha sutil (mood-glyph + nome + persona + ânimo + stage + lv).
- Body (a voz do pet) é o único elemento sem 'dim', indentado, espaçado.
- Footer com barra de XP + streak — informação ambiente.
- Persona define cor das rules + tom italic do header. Sutileza absoluta.
- Funciona em terminais dark e light (evita bright_* exceto caos).
- `--quiet` → só a voz, pipe-friendly.

Usa exclusivamente APIs públicas de sprites.py: render(), sway(), thought_for().
"""
from __future__ import annotations

import shutil

from rich.console import Group
from rich.padding import Padding
from rich.text import Text

from . import pet_logic, sprites

# ---------------------------------------------------------------- paleta

# Tons calibrados pra ser legíveis em dark E light. Caos é a única exceção
# que aceita bright (faz sentido com o tema).
PERSONA_COLOR: dict[str, str] = {
    "fofo":       "magenta",
    "sarcástico": "yellow",
    "motivador":  "red",
    "calmo":      "green",
    "agitado":    "cyan",
    "caótico":    "bright_magenta",
}

# Largura da regra horizontal — calibrada pra parecer "respiração" sem
# atravessar a tela inteira em terminais largos.
RULE_W = 61
# Margem esquerda comum (tudo dentro de uma "coluna" suave).
PAD_L = 2


# ---------------------------------------------------------------- helpers

def _persona(pet: dict) -> tuple[str, str]:
    soul = pet.get("soul") or {}
    name = soul.get("personality", "fofo")
    color = PERSONA_COLOR.get(name) or soul.get("color") or "cyan"
    return name, color


def _mood_glyph(pet: dict) -> str:
    """Glyph subliminar de abertura. Reflete mood vivo sem virar HUD."""
    if pet.get("asleep"):
        return "☾"
    mood = int(pet.get("mood", 50))
    if mood >= 80:
        return "✦"
    if mood >= 40:
        return "◆"
    return "◇"


def _mood_label(pet: dict) -> str:
    if pet.get("asleep"):
        return "dormindo"
    hunger = int(pet.get("hunger", 100))
    energy = int(pet.get("energy", 100))
    mood   = int(pet.get("mood", 50))
    if hunger < 30:
        return "faminto"
    if energy < 30:
        return "cansado"
    if mood >= 80:
        return "animado"
    if mood >= 40:
        return "tranquilo"
    return "tristinho"


def _streak_text(streak: dict | None) -> Text | None:
    days = int((streak or {}).get("days") or 0)
    if days <= 0:
        return None
    t = Text()
    if days >= 30:
        t.append(f"🌟 {days}d", style="bold yellow")
    elif days >= 7:
        t.append(f"🔥🔥🔥 {days}d", style="bold bright_yellow")
    elif days >= 3:
        t.append(f"🔥🔥 {days}d", style="yellow")
    else:
        t.append(f"🔥 {days}d", style="dim yellow")
    return t


def _stage_emoji(stage: str) -> str:
    return pet_logic.STAGE_EMOJI.get(stage, "👾")


def _term_width() -> int:
    try:
        return max(40, shutil.get_terminal_size((80, 24)).columns)
    except Exception:
        return 80


# ---------------------------------------------------------------- zonas

def _header(pet: dict, nick: str | None) -> Text:
    persona, color = _persona(pet)
    stage = pet.get("stage", "egg")
    stage_label = pet_logic.STAGE_LABEL.get(stage, stage).lower()
    level = int(pet.get("level", 1))
    pet_name = (pet.get("name") or "bytinho").strip() or "bytinho"

    t = Text()
    if nick:
        t.append(f"@{nick.lstrip('@')}", style=f"bold {color}")
        t.append("  ·  ", style="dim")
    t.append(pet_name, style="bold")
    t.append("  ·  ", style="dim")
    t.append(stage_label, style="dim")
    t.append("  ·  ", style="dim")
    t.append(f"lv {level}", style="dim")
    return t


def _rule(color: str, width: int) -> Text:
    w = min(RULE_W, max(20, width - PAD_L * 2))
    return Text("─" * w, style=f"dim {color}")


def _sprite_block(pet: dict, color: str, tick: int = 0) -> Padding:
    """Render do mascote Bytinho, alinhado à esquerda (junto com header/barras).

    Usa EXATAMENTE sprites.render() — protocolo intocado.
    """
    soul = pet.get("soul") or {}
    variant = soul.get("variant", "a")
    art = sprites.render(
        pet.get("stage", "egg"),
        float(pet.get("mood", 50)),
        bool(pet.get("asleep", False)),
        variant=variant,
        tick=tick,
    )
    return Padding(Text(art, style=f"bold {color}"), (0, 0, 0, PAD_L))


def _profile_url_line(nick: str | None) -> Text:
    """Linha sutil sob o sprite com a URL pública do perfil."""
    t = Text()
    if nick:
        t.append("🔗 ", style="dim")
        t.append(f"bytinho.com/u/{nick.lstrip('@')}", style="dim cyan underline")
    else:
        t.append("🔗 ", style="dim")
        t.append("bytinho nick <seu-nick>", style="dim italic")
        t.append("  para ter perfil público", style="dim")
    return t


def _progress(pet: dict, color: str, streak: dict | None) -> Text:
    stage = pet.get("stage", "egg")
    xp = int(pet.get("xp", 0))
    nxt = pet_logic.next_stage(stage)
    cur_label = pet_logic.STAGE_LABEL.get(stage, stage).lower()

    line = Text()

    if nxt is None:
        line.append(cur_label, style=f"bold {color}")
        line.append("  ✦ endgame", style="dim italic")
        line.append(f"   {xp} xp", style="dim")
    else:
        nxt_label = pet_logic.STAGE_LABEL.get(nxt, nxt).lower()
        prev_thr = pet_logic.STAGE_THRESHOLD.get(stage, 0)
        nxt_thr = pet_logic.STAGE_THRESHOLD[nxt]
        span = max(1, nxt_thr - prev_thr)
        frac = max(0.0, min(1.0, (xp - prev_thr) / span))

        BAR_W = 21
        filled = round(frac * BAR_W)
        empty = BAR_W - filled

        line.append(cur_label, style="dim")
        line.append("  ", style="default")
        line.append("█" * filled, style=color)
        line.append("░" * empty, style="dim")
        line.append("  ", style="default")
        line.append(nxt_label, style="dim")
        line.append(f"   {xp} / {nxt_thr} xp", style="dim italic")

    streak_t = _streak_text(streak)
    if streak_t is not None:
        line.append("   ", style="default")
        line.append_text(streak_t)
    return line


# ---------------------------------------------------------------- atalhos rápidos

def _shortcuts(color: str = "cyan") -> Text:
    """Single-line minimal footer — only the essentials."""
    t = Text(justify="left")
    t.append("type", style=f"bold {color}")
    t.append(" to chat", style="dim")
    t.append("   ·   ", style="dim")
    t.append("F1", style=f"bold {color}")
    t.append(" stats", style="dim")
    t.append("   ", style="dim")
    t.append("F2", style=f"bold {color}")
    t.append(" ranking", style="dim")
    t.append("   ", style="dim")
    t.append("F3", style=f"bold {color}")
    t.append(" achievements", style="dim")
    t.append("   ·   ", style="dim")
    t.append("Esc", style=f"bold {color}")
    t.append(" quit", style="dim")
    return t


def _slash_hints(color: str = "cyan") -> Text:
    """DEPRECATED — mantido só para compat. Não chamar mais.

    A ajuda completa agora vive na seção `:?` (help modal).
    """
    return _shortcuts(color)


# ---------------------------------------------------------------- status bar (saúde do pet)

def _bar(value: int, total: int = 100, width: int = 6) -> tuple[str, str]:
    """Retorna (texto_da_barra, cor) — verde >60, amarelo 30-60, vermelho <30."""
    pct = max(0.0, min(1.0, value / max(1, total)))
    filled = round(pct * width)
    bar = "█" * filled + "░" * (width - filled)
    if pct >= 0.6:
        color = "green"
    elif pct >= 0.3:
        color = "yellow"
    else:
        color = "red"
    return bar, color


def _status_bar(pet: dict) -> Text:
    """Barra compacta com saúde do pet — fome / energia / humor.

    Usa labels ASCII curtos em vez de emojis pra render consistente
    em qualquer terminal (alguns emojis tem largura instável).
    """
    fome   = int(pet.get("hunger", 0))            # 0=cheio, 100=faminto
    energy = int(pet.get("brain_energy", 100))    # 100=cheio
    mood   = int(pet.get("mood", 50))             # 0-100
    sat = max(0, 100 - fome)

    t = Text()
    t.append("  ", style="default")

    bar, c = _bar(sat)
    t.append("food ", style="dim")
    t.append(bar, style=c)
    t.append(f" {sat:>3}%", style="dim")

    t.append("    ", style="default")
    bar, c = _bar(energy)
    t.append("nrg  ", style="dim")
    t.append(bar, style=c)
    t.append(f" {energy:>3}%", style="dim")

    t.append("    ", style="default")
    bar, c = _bar(mood)
    t.append("mood ", style="dim")
    t.append(bar, style=c)
    t.append(f" {mood:>3}%", style="dim")

    if pet.get("asleep"):
        t.append("    ", style="default")
        t.append("zzz", style="dim italic")

    return t


# ---------------------------------------------------------------- help modal

def help_lines() -> list[str]:
    """Linhas formatadas em rich-markup para a seção de ajuda.

    Formato consistente: [bold]TÍTULO[/bold] depois pares
    `[bold cyan]chave[/bold cyan]  descrição` alinhados em coluna.
    """
    return [
        "[bold]CHAT[/bold]",
        "  type any text + Enter",
        "",
        "[bold]NAVIGATE[/bold]",
        "  [bold cyan]F1[/bold cyan]   stats         [bold cyan]F2[/bold cyan]   ranking",
        "  [bold cyan]F3[/bold cyan]   achievements",
        "",
        "[bold]CONTROLS[/bold]",
        "  [bold cyan]PgUp/PgDn[/bold cyan]   scroll history",
        "  [bold cyan]Esc      [/bold cyan]   back / quit",
    ]


# ---------------------------------------------------------------- API

def render_talk(pet: dict, reply: str,
                nick: str | None = None,
                streak: dict | None = None,
                tick: int = 0) -> Group:
    """Layout completo: header → sprite (centrado) → rule → body → rule → footer."""
    _, color = _persona(pet)
    width = _term_width()

    return Group(
        Text(""),
        Padding(_header(pet, nick), (0, 0, 0, PAD_L)),
        Text(""),
        _sprite_block(pet, color, tick=tick),
        Padding(_profile_url_line(nick), (0, 0, 0, PAD_L)),
        Text(""),
        Padding(_rule(color, width), (0, 0, 0, PAD_L)),
        Padding(Text(reply.strip(), style="default"), (1, 0, 1, PAD_L + 4)),
        Padding(_rule(color, width), (0, 0, 0, PAD_L)),
        Text(""),
        Padding(_progress(pet, color, streak), (0, 0, 0, PAD_L)),
        Text(""),
        Padding(_shortcuts(color), (0, 0, 0, PAD_L)),
        Text(""),
    )


def render_talk_quiet(pet: dict, reply: str) -> Text:
    """`--quiet`: só a voz + assinatura. Pipe-friendly."""
    persona, color = _persona(pet)
    pet_name = (pet.get("name") or "bytinho").strip() or "bytinho"
    t = Text()
    t.append(reply.strip() + "\n", style="default")
    t.append(f"— {pet_name} ({persona})", style=f"italic dim {color}")
    return t


def render_idle_whisper(pet: dict, line: str) -> Group:
    """Iniciativa do pet em live mode: sussurro curto, sprite pequeno."""
    _, color = _persona(pet)
    sprite = _sprite_block(pet, color, tick=0)
    voice = Padding(
        Text(f"💭  {line}", style=f"italic {color}"),
        (1, 0, 0, PAD_L + 4),
    )
    return Group(Text(""), sprite, voice, Text(""))
