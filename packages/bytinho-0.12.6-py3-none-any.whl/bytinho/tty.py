"""TTY / interactivity detection (P1-1).

Bytinho's onboarding (welcome prompts, tour, speak TUI) requires a real
terminal. When invoked from CI, scripts, IDE-run buttons, pipes, or
non-interactive shells, we MUST short-circuit to avoid:
  - blocking on `Prompt.ask` forever (no stdin)
  - dumping ANSI escapes into log files
  - crashing the parent process (e.g. a CI step)

Order of checks (any match = non-interactive):
  1. ``BYTINHO_NONINTERACTIVE=1`` env (explicit user override)
  2. Common CI markers: CI, GITHUB_ACTIONS, GITLAB_CI, BUILDKITE,
     CIRCLECI, JENKINS_URL, TF_BUILD, BUILDER_OUTPUT, TEAMCITY_VERSION
  3. ``stdin`` or ``stdout`` not a tty (piped, redirected)
"""
from __future__ import annotations

import os
import sys

_CI_VARS = (
    "CI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "BUILDKITE",
    "CIRCLECI",
    "JENKINS_URL",
    "TF_BUILD",
    "TEAMCITY_VERSION",
    "BUILDER_OUTPUT",
    "DRONE",
)


def is_ci() -> bool:
    for k in _CI_VARS:
        v = os.environ.get(k, "")
        if v and v.lower() not in ("0", "false", ""):
            return True
    return False


def is_interactive() -> bool:
    """True iff stdin AND stdout são tty E não estamos em CI E sem override."""
    if os.environ.get("BYTINHO_NONINTERACTIVE", "").strip() in ("1", "true", "yes"):
        return False
    if is_ci():
        return False
    try:
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            return False
    except (AttributeError, ValueError):
        # stdin/stdout closed or replaced (e.g. pytest capsys)
        return False
    return True
