from setuptools import setup, find_packages
from setuptools.command.install import install
import sys

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()


class PostInstallCommand(install):
    """Custom post-installation script to show welcome banner."""
    def run(self):
        install.run(self)
        try:
            # Import and show banner after installation
            from rnb.banner import show_banner
            print("\n" + "="*60)
            print("  RednBlue CLI installed successfully!")
            print("="*60)
            show_banner()
            print("\n✅ Installation complete! Run 'rnb' to get started.\n")
        except Exception:
            # Fallback if banner fails
            print("\n✅ RednBlue CLI installed successfully!")
            print("Run 'rnb' to get started.\n")


setup(
    name="rednblue",
    version="2.4.3",
    author="Dr. Mahdi Deramgozin, Dr. Saeid Samizade",
    author_email="contact@rednblue.io",
    description="Adversarial security testing CLI for AI models",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mahdidrm/RednBlue_CLI",
    project_urls={
        "Bug Tracker": "https://github.com/mahdidrm/RednBlue_CLI/issues",
        "Documentation": "https://github.com/mahdidrm/RednBlue_CLI#README",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Security",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "click>=8.1.0",
        "requests>=2.28.0",
        "cryptography>=41.0.0",
        "pillow>=10.0.0",
        "numpy>=1.24.0",
        "torch>=2.0.0",
        "torchvision>=0.15.0",
        "tqdm>=4.65.0",
        "colorama>=0.4.6",
    ],
    extras_require={
        "yolo": ["ultralytics>=8.0.0"],
    },
    entry_points={
        "console_scripts": [
            "rnb=rnb.cli:main",
        ],
    },
    cmdclass={
        'install': PostInstallCommand,
    },
    keywords="adversarial-ml security ai-testing machine-learning deep-learning",
)
