TIER_CONFIGS = {
    "freelancer": {"attacks": ["GNI","SHFP","UAP","FSP","CCM"], "epsilons": [0.005,0.01], "total_tests": 10},
    "enterprise": {"attacks": ["GNI","SHFP","UAP","FSP","CCM","PGD","CW","DEEP"], "epsilons": [0.005,0.01,0.03,0.10], "total_tests": 32}
}
ATTACK_DETAILS = {
    "GNI": {"name": "Gaussian Noise Injection"}, "SHFP": {"name": "High-Frequency Perturbation"},
    "UAP": {"name": "Universal Adversarial Patch", "patch_sizes": [16,32,48,64]},
    "FSP": {"name": "FGSM Surrogate Transfer"}, "CCM": {"name": "Color Channel Manipulation"},
    "PGD": {"name": "Projected Gradient Descent"}, "CW": {"name": "Carlini-Wagner L2"}, "DEEP": {"name": "DeepFool"}
}
GRADING_THRESHOLDS = {"GOLD": 0.90, "SILVER": 0.75, "BRONZE": 0.50}
def get_tier_config(t): return TIER_CONFIGS.get(t.lower())
def calculate_grade(p): return "GOLD" if p >= 0.90 else "SILVER" if p >= 0.75 else "BRONZE"
