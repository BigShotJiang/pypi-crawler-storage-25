"""
RednBlue YOLO Attack Engine
Adversarial attacks targeting object detection models (YOLOv5/v8/v10/v11)

Attack surface differs fundamentally from classification:
  - Success metric : detection evasion (drop in boxes/confidence) or injection (NMS bypass)
  - Gradient target: objectness + classification scores inside the detection head
  - Supports       : ultralytics YOLO (.pt), raw PyTorch YOLO (.pt/.pth), ONNX (via onnx2torch)

Usage (mirrors ImageAttacker interface):
    from rnb.attacks.vision.yolo_attacker import YOLOAttacker

    attacker = YOLOAttacker("best.pt", tier="freelancer", device="cpu")
    results  = attacker.run_attacks("images/frame001.jpg")
"""

import torch
import torch.nn as nn
import numpy as np
from PIL import Image
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import torchvision.transforms as transforms
import os
import platform

# ---------------------------------------------------------------------------
# Tier configuration (YOLO-specific — do NOT mix with classifier tiers)
# ---------------------------------------------------------------------------

YOLO_TIER_CONFIGS: Dict[str, dict] = {
    "freelancer": {
        "attacks"    : ["YGNI", "YFGS", "YPGD", "YGMD"],
        "epsilons"   : [0.005, 0.01],
        "total_tests": 8,
    },
    "enterprise": {
        "attacks"    : ["YGNI", "YFGS", "YPGD", "YDAG", "YTOG", "YNMS", "YNES", "YSQA", "YGMD"],
        "epsilons"   : [0.005, 0.01, 0.03, 0.10],
        "total_tests": 36,
    },
}

YOLO_ATTACK_DETAILS: Dict[str, dict] = {
    "YGNI": {"name": "YOLO Gaussian Noise Injection"},
    "YFGS": {"name": "YOLO FGSM Detection Attack"},
    "YPGD": {"name": "YOLO PGD Detection Evasion"},
    "YDAG": {"name": "Dense Adversary Generation (Xie et al. 2017)"},
    "YTOG": {"name": "Targeted Object Disappearance (Chow et al. 2020)"},
    "YNMS": {"name": "NMS Bypass / False Detection Injection"},
    "YNES": {"name": "Natural Evolution Strategy Black-Box Attack"},
    "YSQA": {"name": "Square Attack (Andriushchenko et al. 2020)"},
    "YGMD": {"name": "Gradient Masking Diagnostic"},
}


# ---------------------------------------------------------------------------
# YOLOAttacker
# ---------------------------------------------------------------------------

class YOLOAttacker:
    """
    Execute adversarial attacks on YOLO object-detection models with tier support.
    Public interface is intentionally identical to ImageAttacker so the same
    run_preview / run_certified_test pipeline works for both model types.

    Args:
        model_path     : Path to .pt / .pth / .onnx model file.
        tier           : 'freelancer' or 'enterprise'.
        device         : 'cpu', 'cuda', or 'mps'.
        conf_threshold : Objectness threshold for counting detections (default 0.25).
        iou_threshold  : IoU threshold for NMS (default 0.45).
        img_size       : Inference resolution (default 640 — standard YOLO input).
    """

    def __init__(
        self,
        model_path    : str,
        tier          : str   = "freelancer",
        device        : str   = "cpu",
        conf_threshold: float = 0.25,
        iou_threshold : float = 0.45,
        img_size      : int   = 640,
    ):
        self.device         = torch.device(device)
        self.tier           = tier.lower()
        self.conf_threshold = conf_threshold
        self.iou_threshold  = iou_threshold
        self.img_size       = img_size

        if self.tier not in YOLO_TIER_CONFIGS:
            raise ValueError(
                f"Unknown tier: '{tier}'. Valid options: 'freelancer', 'enterprise'"
            )

        self.tier_config     = YOLO_TIER_CONFIGS[self.tier]
        self.enabled_attacks = self.tier_config["attacks"]
        self.epsilons        = self.tier_config["epsilons"]

        # Internal model handles — set by _load_model
        self._ultralytics_model = None   # ultralytics.YOLO wrapper (NMS + decode)
        self._torch_model       = None   # raw nn.Module for gradient computation

        self._load_model(model_path)

        self.transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
        ])

        self.device_info = self._get_device_info()

    # ------------------------------------------------------------------ #
    # Model loading
    # ------------------------------------------------------------------ #

    def _load_model(self, model_path: str) -> None:
        """
        Load model with two-stage fallback:
          1. ultralytics.YOLO  — gives structured predictions + internal torch model
          2. torch.load        — for custom / exported raw PyTorch YOLO weights
        """
        path = Path(model_path)
        if not path.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")

        # Stage 1 — ultralytics (YOLOv5 / v8 / v10 / v11)
        try:
            from ultralytics import YOLO as _UltralyticsYOLO  # type: ignore

            ultra = _UltralyticsYOLO(str(model_path))
            ultra.to(self.device)
            self._ultralytics_model = ultra
            # Internal nn.Module — differentiable, no NMS
            self._torch_model = ultra.model.eval()
            return
        except (ImportError, Exception):
            pass  # fall through to raw loader

        # Stage 2 — raw torch.load
        if path.suffix in (".pt", ".pth"):
            obj = torch.load(str(model_path), map_location=self.device, weights_only=False)
            # torch.hub saves might wrap the model in a dict
            if isinstance(obj, dict) and "model" in obj:
                obj = obj["model"]
            if not callable(getattr(obj, "forward", None)):
                raise ValueError(
                    "Loaded object has no forward() method. "
                    "Make sure it is a PyTorch nn.Module."
                )
            self._torch_model = obj.to(self.device).eval()

        elif path.suffix == ".onnx":
            try:
                import onnx                        # type: ignore
                from onnx2torch import convert     # type: ignore

                onnx_model = onnx.load(str(model_path))
                self._torch_model = convert(onnx_model).to(self.device).eval()
            except ImportError:
                raise ImportError(
                    "ONNX support requires: pip install onnx onnx2torch"
                )
        else:
            raise ValueError(
                f"Unsupported model format: '{path.suffix}'. "
                "Use .pt, .pth, or .onnx"
            )

    # ------------------------------------------------------------------ #
    # Device info
    # ------------------------------------------------------------------ #

    def _get_device_info(self) -> dict:
        info = {
            "device_type"    : str(self.device),
            "pytorch_version": torch.__version__,
            "cpu_count"      : os.cpu_count(),
            "model_backend"  : "ultralytics" if self._ultralytics_model else "raw_torch",
            "img_size"       : self.img_size,
        }
        if "cuda" in str(self.device) and torch.cuda.is_available():
            info["device_name"] = torch.cuda.get_device_name(0)
            info["cuda_version"] = torch.version.cuda
            info["gpu_memory"]   = torch.cuda.get_device_properties(0).total_memory
        elif "mps" in str(self.device):
            info["device_name"] = "Apple Metal Performance Shaders"
        else:
            info["device_name"] = platform.processor() or "CPU"
        return info

    # ------------------------------------------------------------------ #
    # Reproducibility
    # ------------------------------------------------------------------ #

    def _set_deterministic(self) -> None:
        torch.manual_seed(42)
        np.random.seed(42)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(42)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark     = False

    # ------------------------------------------------------------------ #
    # Forward pass helpers
    # ------------------------------------------------------------------ #

    def _forward(self, img_tensor: torch.Tensor) -> torch.Tensor:
        """
        Differentiable forward pass — keeps autograd graph intact.

        For ultralytics models we call ultra.model(x) directly, bypassing
        .predict() which runs NMS and other non-differentiable post-processing
        that severs the gradient tape.  We also temporarily switch to train
        mode: in eval mode some YOLO versions apply in-place ops that break
        the autograd graph.
        """
        x = img_tensor.unsqueeze(0) if img_tensor.dim() == 3 else img_tensor
        if self._torch_model is None:
            raise RuntimeError("No differentiable model backend available.")

        was_training = self._torch_model.training
        self._torch_model.train()
        try:
            out = self._torch_model(x)
        finally:
            if not was_training:
                self._torch_model.eval()
        return out

    @staticmethod
    def _normalise_pred(raw) -> Optional[torch.Tensor]:
        """
        Coerce heterogeneous YOLO output formats to a single tensor [B, N, 5+nc].

        YOLO flavour    | raw output type
        --------------- | ---------------
        YOLOv5 (train)  | tuple(tensor[B,N,5+nc], list[feature maps])
        YOLOv8 (export) | tensor[B, 5+nc, N]   (transpose needed)
        YOLOv8 (train)  | tuple(tensor, ...)
        Custom raw      | tensor[B, N, 5+nc]
        """
        if isinstance(raw, (tuple, list)):
            candidates = [
                t for t in raw
                if isinstance(t, torch.Tensor) and t.dim() == 3
            ]
            if not candidates:
                return None
            # Pick the tensor with the most anchors (main prediction head)
            pred = max(candidates, key=lambda t: t.shape[1] * t.shape[2])
        elif isinstance(raw, torch.Tensor):
            pred = raw
        else:
            return None

        # Ensure shape [B, N, features]
        if pred.dim() == 3:
            B, a, b = pred.shape
            if b < a:                          # [B, features, N] → transpose
                pred = pred.permute(0, 2, 1)
        elif pred.dim() == 2:
            pred = pred.unsqueeze(0)

        return pred                            # [B, N, 5+nc]

    def _detection_loss(self, raw) -> torch.Tensor:
        """
        Scalar representing total detection energy in the current prediction.

            L = Σ sigmoid(objectness_i) + Σ max_class_score_i

        To evade detections, the attacker *minimises* L (i.e. adds -sign(∇L)).
        To inject false detections (YNMS), the attacker *maximises* L.
        """
        pred = self._normalise_pred(raw)
        if pred is None:
            # Fallback for exotic architectures
            if isinstance(raw, torch.Tensor):
                return raw.abs().mean()
            return sum(t.abs().mean() for t in raw if isinstance(t, torch.Tensor))

        if pred.shape[-1] >= 5:
            obj        = torch.sigmoid(pred[..., 4])           # [B, N]
            cls_scores = torch.sigmoid(pred[..., 5:])          # [B, N, nc]
            energy     = obj.sum()
            if cls_scores.numel() > 0:
                energy = energy + cls_scores.max(dim=-1).values.sum()
            return energy

        # No separate objectness channel → treat all outputs as proxy
        return torch.sigmoid(pred).sum()

    # ------------------------------------------------------------------ #
    # Detection info (no gradient required)
    # ------------------------------------------------------------------ #

    def _get_detection_info(self, img_tensor: torch.Tensor) -> dict:
        """
        Extract detection statistics from a (possibly adversarial) image tensor.
        Returns a dict compatible with the metadata format used by ImageAttacker.
        """
        EMPTY = {
            "num_detections" : 0,
            "avg_confidence" : 0.0,
            "max_confidence" : 0.0,
            "classes_detected": [],
        }

        with torch.no_grad():
            # Preferred path: ultralytics predict (full NMS + decoding).
            # Must detach first — predict() fails if tensor has requires_grad=True.
            if self._ultralytics_model is not None:
                try:
                    x = img_tensor.detach()
                    x = x.unsqueeze(0) if x.dim() == 3 else x
                    res = self._ultralytics_model.predict(
                        x,
                        conf   = self.conf_threshold,
                        iou    = self.iou_threshold,
                        verbose= False,
                    )
                    boxes = res[0].boxes
                    if boxes is not None and len(boxes):
                        confs   = boxes.conf.cpu().tolist()
                        classes = boxes.cls.cpu().tolist()
                        return {
                            "num_detections" : len(confs),
                            "avg_confidence" : float(np.mean(confs)),
                            "max_confidence" : float(max(confs)),
                            "classes_detected": [int(c) for c in classes],
                        }
                    return EMPTY
                except Exception:
                    pass  # fall through to raw parser

            # Fallback: parse raw tensor output
            raw  = self._forward(img_tensor)
            pred = self._normalise_pred(raw)
            if pred is None:
                return EMPTY

            if pred.shape[-1] >= 5:
                obj    = torch.sigmoid(pred[0, :, 4])        # [N]
                mask   = obj > self.conf_threshold
                detected = obj[mask]
                return {
                    "num_detections" : int(mask.sum().item()),
                    "avg_confidence" : float(detected.mean().item()) if len(detected) else 0.0,
                    "max_confidence" : float(detected.max().item())  if len(detected) else 0.0,
                    "classes_detected": [],                  # class decoding skipped in raw mode
                }

        return EMPTY

    # ------------------------------------------------------------------ #
    # Metadata builder (common to all attacks)
    # ------------------------------------------------------------------ #

    def _build_meta(
        self,
        attack_name    : str,
        epsilon        : float,
        orig           : dict,
        final          : dict,
        noise          : Optional[torch.Tensor] = None,
        grad_mag       : float = 0.0,
        grad_std       : float = 0.0,
        grad_min       : Optional[float] = None,
        grad_max       : Optional[float] = None,
        iterations     : Optional[int]   = None,
        conf_trajectory: Optional[list]  = None,
    ) -> dict:
        """
        Build the standardised metadata dictionary.
        Success = detections dropped OR confidence halved (evasion goal).
        Override 'success' after calling this for injection attacks (YNMS).
        """
        meta: dict = {
            "attack_name"            : attack_name,
            "epsilon"                : epsilon,
            "success"                : (
                final["num_detections"] < orig["num_detections"]
                or final["avg_confidence"] < orig["avg_confidence"] * 0.5
            ),
            "original_num_detections": orig["num_detections"],
            "final_num_detections"   : final["num_detections"],
            "detections_dropped"     : max(0, orig["num_detections"] - final["num_detections"]),
            "initial_confidence"     : orig["avg_confidence"],
            "final_confidence"       : final["avg_confidence"],
            "confidence_drop"        : orig["avg_confidence"] - final["avg_confidence"],
            "gradient_magnitude_avg" : grad_mag,
            "gradient_magnitude_std" : grad_std,
            "original_prediction"    : orig,
            "final_prediction"       : final,
        }

        if noise is not None:
            meta["perturbation_l2"]   = torch.norm(noise, p=2).item()
            meta["perturbation_linf"] = torch.norm(noise, p=float("inf")).item()

        if grad_min is not None:
            meta["gradient_magnitude_min"] = grad_min
        if grad_max is not None:
            meta["gradient_magnitude_max"] = grad_max
        if iterations is not None:
            meta["iterations_taken"] = iterations
        if conf_trajectory is not None:
            meta["confidence_trajectory"] = conf_trajectory

        return meta

    # ------------------------------------------------------------------ #
    # Attack implementations
    # ------------------------------------------------------------------ #

    def attack_YGNI(
        self, img_tensor: torch.Tensor, epsilon: float
    ) -> Tuple[torch.Tensor, dict]:
        """
        YOLO Gaussian Noise Injection.
        Black-box baseline — no gradient required.
        Success criterion: reduction in detected boxes or object confidence.
        """
        self._set_deterministic()
        orig  = self._get_detection_info(img_tensor)

        noise   = torch.randn_like(img_tensor) * epsilon
        adv_img = torch.clamp(img_tensor + noise, 0, 1)
        final   = self._get_detection_info(adv_img)

        return adv_img, self._build_meta(
            "YGNI", epsilon, orig, final, noise=noise
        )

    def attack_YFGS(
        self, img_tensor: torch.Tensor, epsilon: float
    ) -> Tuple[torch.Tensor, dict]:
        """
        YOLO FGSM Detection Attack.
        Single-step white-box attack that minimises total detection energy.
        Gradient flows through objectness + class scores of all anchor positions.

        Gradient masking fallback: if gradients are None or near-zero (known
        symptom in YOLOv10n — see Deramgozin et al. 2025), the attack falls
        back to a uniform sign perturbation and flags the result.
        """
        self._set_deterministic()
        orig = self._get_detection_info(img_tensor)

        gradient_masking = False
        grad_mag = grad_std = 0.0

        x = img_tensor.clone().detach().requires_grad_(True)
        try:
            loss = self._detection_loss(self._forward(x))
            if not loss.requires_grad:
                raise RuntimeError("Loss has no grad_fn — computation graph broken.")
            loss.backward()

            if x.grad is None or x.grad.abs().max().item() < 1e-8:
                # Near-zero gradient: gradient masking detected
                gradient_masking = True
                perturbation = -epsilon * torch.ones_like(img_tensor) * 0.5
            else:
                grad_mag     = x.grad.abs().mean().item()
                grad_std     = x.grad.std().item()
                perturbation = -epsilon * x.grad.sign()

        except Exception:
            gradient_masking = True
            perturbation = -epsilon * torch.ones_like(img_tensor) * 0.5

        adv_img = torch.clamp(img_tensor + perturbation, 0, 1).detach()
        final   = self._get_detection_info(adv_img)

        meta = self._build_meta(
            "YFGS", epsilon, orig, final,
            noise=perturbation, grad_mag=grad_mag, grad_std=grad_std,
        )
        meta["gradient_masking_detected"] = gradient_masking
        return adv_img, meta

    def attack_YPGD(
        self,
        img_tensor: torch.Tensor,
        epsilon   : float,
        iterations: int = 40,
    ) -> Tuple[torch.Tensor, dict]:
        """
        YOLO PGD Detection Evasion.
        Iterative projected gradient descent — strongest evasion attack.
        Step size alpha = epsilon / 10 (standard PGD schedule).

        Gradient masking fallback: if gradients are absent or near-zero on
        the first step, switches to a sign-random walk (gradient-free PGD
        surrogate) and flags the result so the report can surface it.
        """
        self._set_deterministic()
        orig  = self._get_detection_info(img_tensor)
        alpha = epsilon / 10

        adv              = img_tensor.clone()
        grad_mags, conf_history = [], []
        gradient_masking = False

        for i in range(iterations):
            adv = adv.clone().detach().requires_grad_(True)
            try:
                loss = self._detection_loss(self._forward(adv))
                if not loss.requires_grad:
                    raise RuntimeError("Loss has no grad_fn.")
                loss.backward()

                if adv.grad is None or adv.grad.abs().max().item() < 1e-8:
                    raise RuntimeError("Gradient is None or near-zero.")

                grad_mag_i = adv.grad.abs().mean().item()
                grad_mags.append(grad_mag_i)
                step = adv.grad.sign()

            except Exception:
                # Gradient masking — use random sign as surrogate direction
                gradient_masking = True
                grad_mags.append(0.0)
                step = torch.sign(torch.randn_like(adv))

            conf_history.append(
                self._get_detection_info(adv.detach())["avg_confidence"]
            )

            adv   = adv.detach() - alpha * step
            delta = torch.clamp(adv - img_tensor, -epsilon, epsilon)
            adv   = torch.clamp(img_tensor + delta, 0, 1).detach()

        final        = self._get_detection_info(adv)
        perturbation = adv - img_tensor

        meta = self._build_meta(
            "YPGD", epsilon, orig, final,
            noise          = perturbation,
            grad_mag       = float(np.mean(grad_mags)),
            grad_std       = float(np.std(grad_mags)),
            grad_min       = float(min(grad_mags)),
            grad_max       = float(max(grad_mags)),
            iterations     = iterations,
            conf_trajectory= conf_history,
        )
        meta["gradient_masking_detected"] = gradient_masking
        return adv, meta

    def attack_YDAG(
        self,
        img_tensor: torch.Tensor,
        epsilon   : float,
        iterations: int = 50,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Dense Adversary Generation (DAG).
        Adapted from Xie et al. (2017) — attacks ALL anchor positions simultaneously
        instead of using a single loss scalar. Particularly effective against
        models with dense prediction heads (YOLOv8 neck).

        Loss: Σ_scale Σ_anchor sigmoid(objectness) — summed across every feature map scale.
        """
        self._set_deterministic()
        orig  = self._get_detection_info(img_tensor)
        alpha = epsilon / iterations           # constant step — no projection

        adv        = img_tensor.clone()
        grad_mags, conf_history = [], []

        gradient_masking = False
        for _ in range(iterations):
            adv  = adv.clone().detach().requires_grad_(True)
            try:
                raw  = self._forward(adv)

                # Dense loss: aggregate over ALL tensors in the output
                if isinstance(raw, (tuple, list)):
                    tensors = [t for t in raw if isinstance(t, torch.Tensor) and t.dim() >= 3]
                    if tensors:
                        loss = sum(
                            torch.sigmoid(t[..., 4]).sum() if t.shape[-1] >= 5 else t.abs().sum()
                            for t in tensors
                        )
                    else:
                        loss = self._detection_loss(raw)
                else:
                    loss = (
                        torch.sigmoid(raw[..., 4]).sum()
                        if raw.shape[-1] >= 5
                        else raw.abs().sum()
                    )

                if not loss.requires_grad:
                    raise RuntimeError("Loss has no grad_fn.")
                loss.backward()

                if adv.grad is None or adv.grad.abs().max().item() < 1e-8:
                    raise RuntimeError("Gradient is None or near-zero.")

                grad_mags.append(adv.grad.abs().mean().item())
                step = adv.grad.sign()

            except Exception:
                gradient_masking = True
                grad_mags.append(0.0)
                step = torch.sign(torch.randn_like(adv))

            conf_history.append(
                self._get_detection_info(adv.detach())["avg_confidence"]
            )
            adv = torch.clamp(adv.detach() - alpha * step, 0, 1).detach()

        final        = self._get_detection_info(adv)
        perturbation = adv - img_tensor

        meta = self._build_meta(
            "YDAG", epsilon, orig, final,
            noise          = perturbation,
            grad_mag       = float(np.mean(grad_mags)),
            grad_std       = float(np.std(grad_mags)),
            iterations     = iterations,
            conf_trajectory= conf_history,
        )
        meta["gradient_masking_detected"] = gradient_masking
        return adv, meta

    def attack_YTOG(
        self,
        img_tensor  : torch.Tensor,
        epsilon     : float,
        target_class: int = 0,
        iterations  : int = 50,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Targeted Object Disappearance (TOG).
        Adapted from Chow et al. (2020) — forces a specific class to vanish
        by jointly minimising objectness AND the target class score across all anchors.

        Args:
            target_class: YOLO class index to suppress (0 = first class, e.g. 'person').
        """
        self._set_deterministic()
        orig  = self._get_detection_info(img_tensor)
        alpha = epsilon / iterations

        adv        = img_tensor.clone()
        conf_history = []

        for _ in range(iterations):
            adv  = adv.clone().detach().requires_grad_(True)
            raw  = self._forward(adv)
            pred = self._normalise_pred(raw)       # [B, N, 5+nc]

            if pred is not None and pred.shape[-1] >= 6:
                nc      = pred.shape[-1] - 5
                cls_idx = min(target_class, nc - 1) + 5
                loss    = (
                    torch.sigmoid(pred[..., 4]).sum()        # objectness
                    + torch.sigmoid(pred[..., cls_idx]).sum() # target class
                )
            else:
                # Fallback: suppress all detection energy
                loss = self._detection_loss(raw)

            loss.backward()
            conf_history.append(
                self._get_detection_info(adv.detach())["avg_confidence"]
            )

            adv = torch.clamp(adv - alpha * adv.grad.sign(), 0, 1).detach()

        final        = self._get_detection_info(adv)
        perturbation = adv - img_tensor

        meta = self._build_meta(
            "YTOG", epsilon, orig, final,
            noise          = perturbation,
            iterations     = iterations,
            conf_trajectory= conf_history,
        )
        meta["target_class"] = target_class
        return adv, meta

    def attack_YNMS(
        self, img_tensor: torch.Tensor, epsilon: float
    ) -> Tuple[torch.Tensor, dict]:
        """
        NMS Bypass / False Detection Injection.
        Opposite goal to evasion attacks: *maximises* objectness scores so that
        NMS is overwhelmed by ghost boxes, degrading downstream pipeline reliability.

        Success criterion: MORE boxes detected after perturbation than before.
        """
        self._set_deterministic()
        orig = self._get_detection_info(img_tensor)

        x    = img_tensor.clone().detach().requires_grad_(True)
        # Maximise detection energy → add gradient sign (note: -(-loss) = +grad)
        loss = -self._detection_loss(self._forward(x))
        loss.backward()

        grad_mag     = x.grad.abs().mean().item()
        perturbation = epsilon * x.grad.sign()          # add to maximise
        adv_img      = torch.clamp(img_tensor + perturbation, 0, 1).detach()
        final        = self._get_detection_info(adv_img)

        meta = self._build_meta(
            "YNMS", epsilon, orig, final,
            noise=perturbation, grad_mag=grad_mag,
        )
        # Override success: injection attack succeeds when detections INCREASE
        meta["success"]           = final["num_detections"] > orig["num_detections"]
        meta["ghost_detections"]  = max(0, final["num_detections"] - orig["num_detections"])
        return adv_img, meta

    # ------------------------------------------------------------------ #
    # Public interface (mirrors ImageAttacker)
    # ------------------------------------------------------------------ #


    # ================================================================== #
    # Gradient Masking Diagnostic Attacks
    # ================================================================== #

    def attack_YNES(
        self,
        img_tensor: torch.Tensor,
        epsilon   : float,
        n_samples : int = 50,
        sigma     : float = 0.01,
        iterations: int = 20,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Natural Evolution Strategy (NES) Black-Box Attack.

        Estimates the gradient entirely through finite-difference sampling —
        no backpropagation required.  Uses the detection loss as the scoring
        function, querying the model with N Gaussian-perturbed copies per step.

            ĝ ≈ (1 / N·σ) · Σᵢ L(x + σ·vᵢ) · vᵢ   [antithetic sampling]

        If YNES succeeds where YFGS/YPGD fail, gradient masking is confirmed.

        Args:
            n_samples : number of antithetic sample pairs per iteration (total
                        queries = 2 * n_samples * iterations).
            sigma     : NES smoothing radius (separate from epsilon budget).
        """
        self._set_deterministic()
        orig  = self._get_detection_info(img_tensor)
        alpha = epsilon / iterations

        adv              = img_tensor.clone()
        conf_history     = []
        query_count      = 0
        estimated_grad_mags = []

        for _ in range(iterations):
            # Antithetic NES gradient estimate
            grad_estimate = torch.zeros_like(adv)

            for _ in range(n_samples):
                v = torch.randn_like(adv)

                with torch.no_grad():
                    # Positive direction
                    x_pos  = torch.clamp(adv + sigma * v, 0, 1)
                    raw_p  = self._forward(x_pos)
                    loss_p = self._detection_loss(raw_p).item()

                    # Negative direction (antithetic)
                    x_neg  = torch.clamp(adv - sigma * v, 0, 1)
                    raw_n  = self._forward(x_neg)
                    loss_n = self._detection_loss(raw_n).item()

                    query_count += 2

                # Accumulate gradient estimate
                grad_estimate += (loss_p - loss_n) * v

            grad_estimate = grad_estimate / (2 * n_samples * sigma)
            estimated_grad_mags.append(grad_estimate.abs().mean().item())

            # Evasion step: subtract estimated gradient sign
            adv   = adv - alpha * grad_estimate.sign()
            delta = torch.clamp(adv - img_tensor, -epsilon, epsilon)
            adv   = torch.clamp(img_tensor + delta, 0, 1).detach()

            conf_history.append(self._get_detection_info(adv)["avg_confidence"])

        final        = self._get_detection_info(adv)
        perturbation = adv - img_tensor

        meta = self._build_meta(
            "YNES", epsilon, orig, final,
            noise          = perturbation,
            grad_mag       = float(np.mean(estimated_grad_mags)),
            grad_std       = float(np.std(estimated_grad_mags)),
            iterations     = iterations,
            conf_trajectory= conf_history,
        )
        meta["query_count"]           = query_count
        meta["nes_sigma"]             = sigma
        meta["nes_samples_per_step"]  = n_samples
        meta["attack_type"]           = "black_box_gradient_free"
        return adv, meta

    def attack_YSQA(
        self,
        img_tensor: torch.Tensor,
        epsilon   : float,
        max_queries: int = 200,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Square Attack — Score-Based Black-Box Attack.
        Andriushchenko et al. (2020) «Square Attack: a query-efficient
        black-box adversarial attack via random search».

        Operates by randomly adding/removing axis-aligned squares of
        perturbation, accepting changes that reduce detection confidence.
        Requires ZERO gradient information — completely immune to gradient
        masking.

        Square size schedule: starts at ~50% of image width, halves every
        ~25% of query budget (heuristic from original paper).
        """
        self._set_deterministic()
        _, H, W = img_tensor.shape
        orig     = self._get_detection_info(img_tensor)

        # Initialise with random vertical stripes (standard Square Attack init)
        init_delta = torch.zeros_like(img_tensor)
        for c in range(3):
            init_delta[c, :, :] = torch.sign(torch.randn(1, W)) * epsilon
        adv = torch.clamp(img_tensor + init_delta, 0, 1).detach()

        # Score the starting point
        with torch.no_grad():
            curr_loss = self._detection_loss(self._forward(adv)).item()

        conf_history = []
        query_count  = 1
        accepted     = 0

        def _square_size(q: int) -> int:
            """Decrease square size as budget is consumed."""
            frac = q / max_queries
            if   frac < 0.25: return max(int(W * 0.5), 1)
            elif frac < 0.50: return max(int(W * 0.25), 1)
            elif frac < 0.75: return max(int(W * 0.125), 1)
            else:             return max(int(W * 0.0625), 1)

        while query_count < max_queries:
            s = _square_size(query_count)

            # Random square position
            x = np.random.randint(0, max(W - s, 1))
            y = np.random.randint(0, max(H - s, 1))

            # Random sign per channel
            delta = adv.clone()
            for c in range(3):
                sign = np.random.choice([-1, 1])
                delta[c, y:y+s, x:x+s] = sign * epsilon

            candidate = torch.clamp(delta, 0, 1).detach()

            with torch.no_grad():
                new_loss = self._detection_loss(self._forward(candidate)).item()
                query_count += 1

            # Accept if detection energy decreases (evasion goal)
            if new_loss < curr_loss:
                adv       = candidate
                curr_loss = new_loss
                accepted += 1

            conf_history.append(self._get_detection_info(adv)["avg_confidence"])

        final        = self._get_detection_info(adv)
        perturbation = adv - img_tensor

        meta = self._build_meta(
            "YSQA", epsilon, orig, final,
            noise      = perturbation,
            iterations = query_count,
        )
        meta["query_count"]    = query_count
        meta["accepted_steps"] = accepted
        meta["acceptance_rate"] = accepted / max(query_count, 1)
        meta["conf_trajectory"] = conf_history
        meta["attack_type"]     = "black_box_score_based"
        return adv, meta

    def attack_YGMD(
        self,
        img_tensor: torch.Tensor,
        epsilon   : float,
    ) -> Tuple[torch.Tensor, dict]:
        """
        Gradient Masking Diagnostic (YGMD).

        Runs three probes on the same image and computes a masking index:

            masking_index = 1 - (wb_drop / bb_drop)   ∈ [0, 1]

        Where:
            wb_drop = confidence drop achieved by white-box YFGS
            bb_drop = confidence drop achieved by black-box YSQA

        Interpretation:
            0.0  → No masking (white-box as strong as black-box)
            0.5+ → Moderate masking
            0.8+ → Strong masking (consistent with YOLOv10n pattern,
                    Deramgozin et al. 2025)
            1.0  → Complete masking (white-box totally ineffective)

        This is NOT an attack — it is a diagnostic tool.  The 'success'
        field is True when masking_index >= 0.5 (masking confirmed).
        """
        self._set_deterministic()
        orig = self._get_detection_info(img_tensor)

        # ── Probe 1: White-box YFGS ──────────────────────────────────────
        wb_grad_mag  = 0.0
        wb_grad_zero = False
        wb_drop      = 0.0

        x = img_tensor.clone().detach().requires_grad_(True)
        try:
            loss = self._detection_loss(self._forward(x))
            if not loss.requires_grad:
                raise RuntimeError("No grad_fn.")
            loss.backward()

            if x.grad is None or x.grad.abs().max().item() < 1e-8:
                wb_grad_zero = True
            else:
                wb_grad_mag  = x.grad.abs().mean().item()
                perturbation = -epsilon * x.grad.sign()
                adv_wb       = torch.clamp(img_tensor + perturbation, 0, 1).detach()
                wb_result    = self._get_detection_info(adv_wb)
                wb_drop      = orig["avg_confidence"] - wb_result["avg_confidence"]
        except Exception:
            wb_grad_zero = True

        # ── Probe 2: Black-box YNES ──────────────────────────────────────
        _, nes_meta     = self.attack_YNES(img_tensor, epsilon, n_samples=20, iterations=10)
        nes_drop        = nes_meta["confidence_drop"]
        nes_grad_mag    = nes_meta["gradient_magnitude_avg"]

        # ── Probe 3: Black-box YSQA ──────────────────────────────────────
        _, sqa_meta     = self.attack_YSQA(img_tensor, epsilon, max_queries=100)
        sqa_drop        = sqa_meta["confidence_drop"]

        # ── Compute masking index ────────────────────────────────────────
        bb_drop = max(nes_drop, sqa_drop)           # best black-box result
        EPS     = 1e-6

        if bb_drop <= EPS:
            # Neither white-box nor black-box did anything — genuinely robust
            masking_index = 0.0
            verdict       = "GENUINE_ROBUSTNESS"
        elif wb_grad_zero:
            # White-box gradient is literally zero — hard masking
            masking_index = 1.0
            verdict       = "GRADIENT_MASKING_HARD"
        else:
            masking_index = float(np.clip(1.0 - (wb_drop / (bb_drop + EPS)), 0, 1))
            if   masking_index >= 0.8: verdict = "GRADIENT_MASKING_HARD"
            elif masking_index >= 0.5: verdict = "GRADIENT_MASKING_MODERATE"
            elif masking_index >= 0.2: verdict = "GRADIENT_MASKING_WEAK"
            else:                      verdict = "NO_MASKING"

        # YGMD 'success' = masking was detected
        masking_detected = masking_index >= 0.5

        return img_tensor.clone(), {
            "attack_name"             : "YGMD",
            "epsilon"                 : epsilon,
            "success"                 : masking_detected,
            "masking_index"           : masking_index,
            "verdict"                 : verdict,

            # White-box probe
            "wb_gradient_magnitude"   : wb_grad_mag,
            "wb_gradient_zero"        : wb_grad_zero,
            "wb_confidence_drop"      : wb_drop,

            # Black-box probes
            "nes_confidence_drop"     : nes_drop,
            "nes_estimated_grad_mag"  : nes_grad_mag,
            "sqa_confidence_drop"     : sqa_drop,
            "sqa_acceptance_rate"     : sqa_meta.get("acceptance_rate", 0.0),

            # Standard fields expected by report backend
            "original_num_detections" : orig["num_detections"],
            "final_num_detections"    : orig["num_detections"],   # diagnostic, no perturbation applied
            "detections_dropped"      : 0,
            "initial_confidence"      : orig["avg_confidence"],
            "final_confidence"        : orig["avg_confidence"],
            "confidence_drop"         : 0.0,
            "perturbation_l2"         : 0.0,
            "perturbation_linf"       : 0.0,
            "gradient_magnitude_avg"  : wb_grad_mag,
            "gradient_magnitude_std"  : 0.0,
            "original_prediction"     : orig,
            "final_prediction"        : orig,
        }

    def run_single_attack(
        self,
        img_tensor  : torch.Tensor,
        attack_name : str,
        param       : float,
    ) -> dict:
        """Run a single named attack and return its metadata dict."""
        if attack_name not in self.enabled_attacks:
            return {
                "error": (
                    f"Attack '{attack_name}' is not enabled for the "
                    f"'{self.tier}' tier. Available: {self.enabled_attacks}"
                )
            }

        method = getattr(self, f"attack_{attack_name}", None)
        if method is None:
            return {"error": f"Attack method not implemented: attack_{attack_name}"}

        _, metadata = method(img_tensor, param)
        return metadata

    def run_attacks(self, image_path: str, output_dir: Path = None) -> dict:
        """
        Run all tier-configured attacks on a single image.

        Returns the same structure as ImageAttacker.run_attacks() so that the
        encryption / submission pipeline needs zero changes.
        """
        img        = Image.open(image_path).convert("RGB")
        img_tensor = self.transform(img).to(self.device)

        results: dict = {
            "image"     : str(image_path),
            "tier"      : self.tier,
            "model_type": "yolo_detection",
            "device_info": self.device_info,
            "attacks"   : {},
        }

        for attack_name in self.enabled_attacks:
            results["attacks"][attack_name] = []

            # YGMD is a diagnostic — run once at max epsilon, not per epsilon level
            if attack_name == "YGMD":
                try:
                    metadata         = self.run_single_attack(img_tensor, "YGMD", max(self.epsilons))
                    metadata["tier"] = 1
                    results["attacks"][attack_name].append(metadata)
                except Exception as exc:
                    results["attacks"][attack_name].append({
                        "attack_name": "YGMD", "tier": 1,
                        "epsilon": max(self.epsilons), "success": False,
                        "masking_index": 0.0, "verdict": "ERROR",
                        "error": str(exc),
                        "initial_confidence": 0.0, "final_confidence": 0.0,
                        "confidence_drop": 0.0, "gradient_magnitude_avg": 0.0,
                        "perturbation_l2": 0.0, "perturbation_linf": 0.0,
                    })
                continue

            for tier_idx, param in enumerate(self.epsilons, start=1):
                try:
                    metadata           = self.run_single_attack(img_tensor, attack_name, param)
                    metadata["tier"]   = tier_idx

                    if output_dir:
                        attack_dir = Path(output_dir) / attack_name / f"tier{tier_idx}"
                        attack_dir.mkdir(parents=True, exist_ok=True)
                        # Adversarial images can be saved here if needed

                    results["attacks"][attack_name].append(metadata)

                except Exception as exc:
                    # Always preserve epsilon so the report backend can render it.
                    results["attacks"][attack_name].append({
                        "attack_name"            : attack_name,
                        "tier"                   : tier_idx,
                        "epsilon"                : float(param),
                        "success"                : False,
                        "original_num_detections": 0,
                        "final_num_detections"   : 0,
                        "detections_dropped"     : 0,
                        "initial_confidence"     : 0.0,
                        "final_confidence"       : 0.0,
                        "confidence_drop"        : 0.0,
                        "gradient_magnitude_avg" : 0.0,
                        "perturbation_l2"        : 0.0,
                        "perturbation_linf"      : 0.0,
                        "error"                  : str(exc),
                    })

        return results