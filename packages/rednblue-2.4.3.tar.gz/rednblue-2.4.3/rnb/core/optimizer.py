"""Epsilon optimization via binary search"""
from dataclasses import dataclass

@dataclass
class OptimizationConfig:
    min_epsilon: float = 0.001
    max_epsilon: float = 0.1
    target_value: float = 0.5
    max_iterations: int = 15

class EpsilonOptimizer:
    def __init__(self, config): 
        self.config = config
        self.history = []
    
    def optimize(self, attack_fn, metric_extractor=None):
        if not metric_extractor:
            metric_extractor = lambda r: r.get("confidence_drop", 0)
        
        low, high = self.config.min_epsilon, self.config.max_epsilon
        best_epsilon = None
        
        for i in range(self.config.max_iterations):
            epsilon = (low + high) / 2.0
            try:
                results = attack_fn(epsilon)
                value = metric_extractor(results)
                self.history.append({"iteration": i+1, "epsilon": epsilon, "value": value})
                
                if abs(value - self.config.target_value) < 0.05:
                    best_epsilon = epsilon
                    break
                
                if value < self.config.target_value:
                    low = epsilon
                else:
                    high = epsilon
                    best_epsilon = epsilon if not best_epsilon else min(best_epsilon, epsilon)
            except:
                high = epsilon
        
        return {
            "optimal_epsilon": best_epsilon or (low+high)/2,
            "iterations": len(self.history),
            "history": self.history
        }
