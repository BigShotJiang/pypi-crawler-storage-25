"""
RednBlue Attack Engine - Implements 8 adversarial attacks
Supports tier-based configuration (Freelancer/Enterprise)
Comprehensive metadata capture for statistical validation
"""
import torch
import torch.nn as nn
import numpy as np
from PIL import Image
from pathlib import Path
import json
from tqdm import tqdm
from typing import Dict, List, Tuple
import torchvision.transforms as transforms
import os
import platform

from rnb.config.tiers import TIER_CONFIGS, ATTACK_DETAILS, get_tier_config


class ImageAttacker:
    """Execute adversarial attacks on image models with tier support"""
    
    def __init__(self, model_path: str, tier: str = 'freelancer', device: str = 'cpu'):
        """
        Initialize attacker
        
        Args:
            model_path: Path to model file (.pt, .pth, .onnx)
            tier: 'freelancer' or 'enterprise'
            device: 'cpu', 'cuda', or 'mps'
        """
        self.device = torch.device(device)
        self.model = self._load_model(model_path)
        self.model.eval()
        self.tier = tier.lower()
        
        tier_config = get_tier_config(self.tier)
        if not tier_config:
            raise ValueError(f"Unknown tier: {tier}")
        
        self.tier_config = tier_config
        self.enabled_attacks = tier_config['attacks']
        self.epsilons = tier_config['epsilons']
        
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
        ])
        
        # Capture device info
        self.device_info = self._get_device_info()
    
    def _get_device_info(self) -> dict:
        """Capture device context for validation"""
        info = {
            'device_type': str(self.device),
            'pytorch_version': torch.__version__,
            'cpu_count': os.cpu_count()
        }
        
        if 'cuda' in str(self.device):
            if torch.cuda.is_available():
                info['device_name'] = torch.cuda.get_device_name(0)
                info['cuda_version'] = torch.version.cuda
                info['gpu_memory'] = torch.cuda.get_device_properties(0).total_memory
            else:
                info['device_name'] = 'CUDA requested but not available'
        elif 'cpu' in str(self.device):
            info['device_name'] = platform.processor() or 'CPU'
        elif 'mps' in str(self.device):
            info['device_name'] = 'Apple Metal Performance Shaders'
        
        return info
    
    def _load_model(self, model_path: str):
        """Load model from file (.pt, .pth, .onnx)"""

        from pathlib import Path
        from collections import OrderedDict
        import torch
        import torch.nn as nn
        import torchvision.models as models

        path = Path(model_path)

        if not path.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")

        if path.suffix in [".pt", ".pth"]:

            obj = torch.load(model_path, map_location=self.device)

            # Case 1: full saved model
            if isinstance(obj, torch.nn.Module):
                model = obj

            # Case 2: state_dict
            elif isinstance(obj, OrderedDict):

                keys = list(obj.keys())

                # -------------------------
                # Detect architecture
                # -------------------------

                if any(k.startswith("layer1.") for k in keys):
                    # ResNet family
                    model = models.resnet18(weights=None)

                    if "fc.weight" in obj:
                        out_features = obj["fc.weight"].shape[0]
                        model.fc = nn.Linear(model.fc.in_features, out_features)

                elif any(k.startswith("features.") for k in keys):
                    # VGG family
                    model = models.vgg16(weights=None)

                    if "classifier.6.weight" in obj:
                        out_features = obj["classifier.6.weight"].shape[0]
                        model.classifier[6] = nn.Linear(4096, out_features)

                else:
                    raise ValueError("Unknown architecture in state_dict")

                model.load_state_dict(obj)

            else:
                raise ValueError("Unsupported .pth/.pt model format")

        elif path.suffix == ".onnx":
            try:
                import onnx
                from onnx2torch import convert

                onnx_model = onnx.load(model_path)
                model = convert(onnx_model)

            except ImportError:
                raise ImportError("ONNX support requires: pip install onnx onnx2torch")

        else:
            raise ValueError(f"Unsupported model format: {path.suffix}")

        model.eval()
        return model.to(self.device)


    
    def _set_deterministic(self):
        """Set deterministic behavior for reproducibility"""
        torch.manual_seed(42)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(42)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        np.random.seed(42)
    
    def _get_prediction_info(self, img_tensor: torch.Tensor) -> dict:
        """Get prediction details with confidence"""
        with torch.no_grad():
            output = self.model(img_tensor.unsqueeze(0))
            probs = torch.softmax(output, dim=1)[0]
            top5_probs, top5_indices = torch.topk(probs, min(5, len(probs)))
            
            pred_class = output.argmax().item()
            confidence = probs[pred_class].item()
            
            top5 = [
                {'class': idx.item(), 'confidence': prob.item()}
                for idx, prob in zip(top5_indices, top5_probs)
            ]
            
            return {
                'class': pred_class,
                'confidence': confidence,
                'top5': top5
            }
    
    def attack_GNI(self, img_tensor: torch.Tensor, epsilon: float) -> Tuple[torch.Tensor, dict]:
        """Gaussian Noise Injection"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        # Generate noise
        noise = torch.randn_like(img_tensor) * epsilon
        adv_img = torch.clamp(img_tensor + noise, 0, 1)
        
        final_pred = self._get_prediction_info(adv_img)
        
        metadata = {
            'attack_name': 'GNI',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(noise, p=2).item(),
            'perturbation_linf': torch.norm(noise, p=float('inf')).item(),
            'gradient_magnitude_avg': 0.0,  # Non-gradient attack
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_SHFP(self, img_tensor: torch.Tensor, epsilon: float) -> Tuple[torch.Tensor, dict]:
        """High-Frequency Perturbation"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        # Create high-frequency pattern
        freq = 10.0
        _, h, w = img_tensor.shape
        x = torch.linspace(0, 2 * np.pi, w, device=self.device)
        y = torch.linspace(0, 2 * np.pi, h, device=self.device)
        xx, yy = torch.meshgrid(x, y, indexing='ij')
        pattern = torch.sin(freq * xx) * torch.sin(freq * yy)
        pattern = pattern.unsqueeze(0).repeat(3, 1, 1)
        
        perturbation = epsilon * pattern
        adv_img = torch.clamp(img_tensor + perturbation, 0, 1)
        
        final_pred = self._get_prediction_info(adv_img)
        
        metadata = {
            'attack_name': 'SHFP',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(perturbation, p=2).item(),
            'perturbation_linf': torch.norm(perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': 0.0,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_UAP(self, img_tensor: torch.Tensor, patch_size: int) -> Tuple[torch.Tensor, dict]:
        """Universal Adversarial Patch"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        # Generate random patch
        _, h, w = img_tensor.shape
        patch = torch.rand(3, patch_size, patch_size, device=self.device)
        
        # Random placement
        x = np.random.randint(0, max(1, w - patch_size))
        y = np.random.randint(0, max(1, h - patch_size))
        
        adv_img = img_tensor.clone()
        adv_img[:, y:y+patch_size, x:x+patch_size] = patch
        
        final_pred = self._get_prediction_info(adv_img)
        
        perturbation = adv_img - img_tensor
        
        metadata = {
            'attack_name': 'UAP',
            'patch_size': patch_size,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(perturbation, p=2).item(),
            'perturbation_linf': torch.norm(perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': 0.0,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_FSP(self, img_tensor: torch.Tensor, epsilon: float) -> Tuple[torch.Tensor, dict]:
        """FGSM Surrogate Transfer (Fast Sign Perturbation)"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        img_tensor = img_tensor.clone().detach().requires_grad_(True)
        
        output = self.model(img_tensor.unsqueeze(0))
        target = torch.zeros(1, dtype=torch.long, device=self.device)
        loss = nn.CrossEntropyLoss()(output, target)
        loss.backward()
        
        # Capture gradient magnitude
        grad_mag = img_tensor.grad.abs().mean().item()
        
        # FGSM step
        perturbation = epsilon * img_tensor.grad.sign()
        adv_img = torch.clamp(img_tensor + perturbation, 0, 1).detach()
        
        final_pred = self._get_prediction_info(adv_img)
        
        metadata = {
            'attack_name': 'FSP',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(perturbation, p=2).item(),
            'perturbation_linf': torch.norm(perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': grad_mag,
            'gradient_magnitude_std': img_tensor.grad.std().item(),
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_CCM(self, img_tensor: torch.Tensor, epsilon: float) -> Tuple[torch.Tensor, dict]:
        """Color Channel Manipulation"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        # Manipulate each channel differently
        channel_shift = torch.tensor(
            [epsilon, -epsilon, epsilon * 0.5],
            device=self.device
        ).view(3, 1, 1)
        
        adv_img = torch.clamp(img_tensor + channel_shift, 0, 1)
        
        final_pred = self._get_prediction_info(adv_img)
        
        perturbation = adv_img - img_tensor
        
        metadata = {
            'attack_name': 'CCM',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(perturbation, p=2).item(),
            'perturbation_linf': torch.norm(perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': 0.0,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_PGD(self, img_tensor: torch.Tensor, epsilon: float, iterations: int = 40) -> Tuple[torch.Tensor, dict]:
        """Projected Gradient Descent"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        alpha = epsilon / 10
        adv_img = img_tensor.clone()
        
        gradient_magnitudes = []
        confidence_history = []
        loss_history = []
        
        for i in range(iterations):
            adv_img = adv_img.clone().detach().requires_grad_(True)
            
            output = self.model(adv_img.unsqueeze(0))
            target = torch.zeros(1, dtype=torch.long, device=self.device)
            loss = nn.CrossEntropyLoss()(output, target)
            loss.backward()
            
            # Capture metrics
            grad_mag = adv_img.grad.abs().mean().item()
            gradient_magnitudes.append(grad_mag)
            loss_history.append(loss.item())
            
            with torch.no_grad():
                curr_pred = self._get_prediction_info(adv_img)
                confidence_history.append(curr_pred['confidence'])
            
            # PGD step
            adv_img = adv_img + alpha * adv_img.grad.sign()
            perturbation = torch.clamp(adv_img - img_tensor, -epsilon, epsilon)
            adv_img = torch.clamp(img_tensor + perturbation, 0, 1).detach()
        
        final_pred = self._get_prediction_info(adv_img)
        final_perturbation = adv_img - img_tensor
        
        metadata = {
            'attack_name': 'PGD',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(final_perturbation, p=2).item(),
            'perturbation_linf': torch.norm(final_perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': sum(gradient_magnitudes) / len(gradient_magnitudes),
            'gradient_magnitude_std': np.std(gradient_magnitudes),
            'gradient_magnitude_min': min(gradient_magnitudes),
            'gradient_magnitude_max': max(gradient_magnitudes),
            'iterations_taken': iterations,
            'convergence_status': 'completed',
            'confidence_trajectory': confidence_history,
            'loss_trajectory': loss_history,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_CW(self, img_tensor: torch.Tensor, epsilon: float, iterations: int = 50) -> Tuple[torch.Tensor, dict]:
        """Carlini-Wagner L2 Attack (simplified)"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        c = epsilon * 10
        adv_img = img_tensor.clone().requires_grad_(True)
        optimizer = torch.optim.Adam([adv_img], lr=0.01)
        
        gradient_magnitudes = []
        confidence_history = []
        
        for i in range(iterations):
            optimizer.zero_grad()
            
            output = self.model(adv_img.unsqueeze(0))
            
            # CW loss: classification loss + L2 distance
            target_loss = output[0, orig_pred['class']]
            l2_dist = torch.norm(adv_img - img_tensor, p=2)
            loss = target_loss + c * l2_dist
            
            loss.backward()
            
            if adv_img.grad is not None:
                grad_mag = adv_img.grad.abs().mean().item()
                gradient_magnitudes.append(grad_mag)
            
            optimizer.step()
            adv_img.data = torch.clamp(adv_img.data, 0, 1)
            
            with torch.no_grad():
                curr_pred = self._get_prediction_info(adv_img)
                confidence_history.append(curr_pred['confidence'])
        
        adv_img = adv_img.detach()
        final_pred = self._get_prediction_info(adv_img)
        final_perturbation = adv_img - img_tensor
        
        metadata = {
            'attack_name': 'CW',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(final_perturbation, p=2).item(),
            'perturbation_linf': torch.norm(final_perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': sum(gradient_magnitudes) / len(gradient_magnitudes) if gradient_magnitudes else 0.0,
            'gradient_magnitude_std': np.std(gradient_magnitudes) if gradient_magnitudes else 0.0,
            'iterations_taken': iterations,
            'confidence_trajectory': confidence_history,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def attack_DEEP(self, img_tensor: torch.Tensor, epsilon: float, max_iterations: int = 50) -> Tuple[torch.Tensor, dict]:
        """DeepFool Attack (simplified)"""
        self._set_deterministic()
        
        orig_pred = self._get_prediction_info(img_tensor)
        
        adv_img = img_tensor.clone()
        gradient_magnitudes = []
        confidence_history = []
        
        for i in range(max_iterations):
            adv_img = adv_img.clone().detach().requires_grad_(True)
            
            output = self.model(adv_img.unsqueeze(0))
            pred_class = output.argmax().item()
            
            loss = output[0, pred_class]
            loss.backward()
            
            if adv_img.grad is not None:
                grad_mag = adv_img.grad.abs().mean().item()
                gradient_magnitudes.append(grad_mag)
                
                # DeepFool step
                perturbation = epsilon * adv_img.grad.sign()
                adv_img = torch.clamp(adv_img + perturbation, 0, 1).detach()
            
            with torch.no_grad():
                curr_pred = self._get_prediction_info(adv_img)
                confidence_history.append(curr_pred['confidence'])
                
                # Stop if prediction changed
                new_output = self.model(adv_img.unsqueeze(0))
                if new_output.argmax().item() != pred_class:
                    break
        
        final_pred = self._get_prediction_info(adv_img)
        final_perturbation = adv_img - img_tensor
        
        metadata = {
            'attack_name': 'DEEP',
            'epsilon': epsilon,
            'success': (final_pred['class'] != orig_pred['class']),
            'initial_confidence': orig_pred['confidence'],
            'final_confidence': final_pred['confidence'],
            'confidence_drop': orig_pred['confidence'] - final_pred['confidence'],
            'perturbation_l2': torch.norm(final_perturbation, p=2).item(),
            'perturbation_linf': torch.norm(final_perturbation, p=float('inf')).item(),
            'gradient_magnitude_avg': sum(gradient_magnitudes) / len(gradient_magnitudes) if gradient_magnitudes else 0.0,
            'gradient_magnitude_std': np.std(gradient_magnitudes) if gradient_magnitudes else 0.0,
            'iterations_taken': i + 1,
            'convergence_status': 'early_stop' if i < max_iterations - 1 else 'max_iterations',
            'confidence_trajectory': confidence_history,
            'original_prediction': orig_pred,
            'final_prediction': final_pred
        }
        
        return adv_img, metadata
    
    def run_single_attack(self, img_tensor: torch.Tensor, attack_name: str, param: float) -> dict:
        """Run a single attack and return metadata"""
        if attack_name not in self.enabled_attacks:
            return {'error': f'Attack {attack_name} not enabled for {self.tier} tier'}
        
        if attack_name == 'UAP':
            # UAP uses patch sizes, not epsilon
            adv_img, metadata = self.attack_UAP(img_tensor, int(param))
        else:
            # Get attack method
            attack_method = getattr(self, f'attack_{attack_name}')
            adv_img, metadata = attack_method(img_tensor, param)
        
        return metadata
    
    def run_attacks(self, image_path: str, output_dir: Path = None) -> dict:
        """Run all configured attacks on single image"""
        # Load image
        img = Image.open(image_path).convert('RGB')
        img_tensor = self.transform(img).to(self.device)
        
        results = {
            'image': str(image_path),
            'tier': self.tier,
            'device_info': self.device_info,
            'attacks': {}
        }
        
        # Run each enabled attack with configured epsilons
        for attack_name in self.enabled_attacks:
            results['attacks'][attack_name] = []
            
            if attack_name == 'UAP':
                # UAP uses patch sizes
                patch_sizes = ATTACK_DETAILS['UAP']['patch_sizes']
                params = patch_sizes[:len(self.epsilons)]  # Match epsilon count
            else:
                params = self.epsilons
            
            for tier_idx, param in enumerate(params, 1):
                try:
                    metadata = self.run_single_attack(img_tensor, attack_name, param)
                    metadata['tier'] = tier_idx
                    
                    # Save adversarial image if output_dir provided
                    if output_dir:
                        attack_dir = output_dir / attack_name / f'tier{tier_idx}'
                        attack_dir.mkdir(parents=True, exist_ok=True)
                        
                        # Save only if we have the adversarial image
                        # (for preview mode, we might not save)
                    
                    results['attacks'][attack_name].append(metadata)
                    
                except Exception as e:
                    results['attacks'][attack_name].append({
                        'tier': tier_idx,
                        'parameter': param,
                        'error': str(e)
                    })
        
        return results


def run_preview(input_dir: str, model_path: str, device: str = 'cpu'):
    """Run preview mode (free, no token needed)"""
    from colorama import Fore, Style
    
    input_path = Path(input_dir)
    
    # Load attacker (freelancer tier for preview)
    print(f"Loading model from {model_path}...")
    attacker = ImageAttacker(model_path, tier='freelancer', device=device)
    
    # Find images
    image_files = list(input_path.glob('*.jpg')) + list(input_path.glob('*.png'))
    
    if not image_files:
        raise ValueError(f"No images found in {input_dir}")
    
    print(f"Found {len(image_files)} images")
    print(f"Running preview (Freelancer tier: {len(attacker.enabled_attacks)} attacks × {len(attacker.epsilons)} levels = {attacker.tier_config['total_tests']} tests)\n")
    
    # Run attacks on first image (or all if few)
    test_images = image_files[:min(3, len(image_files))]
    all_results = []
    
    for img_file in tqdm(test_images, desc="Testing"):
        result = attacker.run_attacks(str(img_file))
        all_results.append(result)
    
    # Calculate pass rate
    total_tests = 0
    passed_tests = 0
    
    for result in all_results:
        for attack_name, attack_results in result['attacks'].items():
            for test in attack_results:
                if 'success' in test:
                    total_tests += 1
                    if not test['success']:  # Pass = attack failed
                        passed_tests += 1
    
    pass_rate = passed_tests / total_tests if total_tests > 0 else 0
    
    from rnb.config.tiers import calculate_grade
    estimated_grade = calculate_grade(pass_rate)
    
    # Display preview results
    print(f"\n{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
    print(f"{Style.BRIGHT}  RednBlue Security Preview{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}\n")
    print(f"  Model tested: {total_tests} attacks")
    print(f"  Pass Rate: {passed_tests}/{total_tests} ({pass_rate*100:.0f}%)")
    print(f"  Estimated Grade: {Fore.YELLOW if estimated_grade == 'SILVER' else Fore.RED if estimated_grade == 'BRONZE' else Fore.GREEN}{estimated_grade}{Style.RESET_ALL}\n")
    print(f"  {Fore.YELLOW}⚠️  This is a preview only{Style.RESET_ALL}")
    print(f"  To get certified report and certificate:")
    print(f"  → Visit: {Fore.CYAN}https://rednblue.io/checkout{Style.RESET_ALL}")
    print(f"  → Purchase session token")
    print(f"  → Re-run with: {Fore.CYAN}rnb test --session TOKEN{Style.RESET_ALL}\n")
    # Return results for submission
    return {
        "attack_results": all_results,
        "summary": {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "pass_rate": pass_rate,
            "estimated_grade": estimated_grade
        }
    }

def run_certified_test(input_dir: str, model_path: str, session_token: str, device: str = 'cpu'):
    """Run certified test with token"""
    from colorama import Fore, Style
    from rnb.core.hasher import ModelHasher
    from rnb.utils.api import validate_token, fetch_nonce, submit_results
    from rnb.utils.encryption import encrypt_results
    
    print(f"\n{Fore.CYAN}Starting certified test...{Style.RESET_ALL}\n")
    
    # Step 1: Validate token and get tier
    print("1. Validating session token...")
    token_info = validate_token(session_token)
    tier = token_info['tier']
    print(f"   ✓ Token valid ({tier.capitalize()} tier)\n")
    
    # Step 2: Hash model
    print("2. Computing model hash...")
    model_identity = ModelHasher.hash_model(model_path)
    print(f"   ✓ Model hash: {model_identity['model_hash'][:16]}...\n")
    
    # Step 3: Fetch nonce
    print("3. Fetching session nonce...")
    nonce = fetch_nonce(session_token)
    print(f"   ✓ Nonce received\n")
    
    # Step 4: Run attacks
    input_path = Path(input_dir)
    attacker = ImageAttacker(model_path, tier=tier, device=device)
    
    image_files = list(input_path.glob('*.jpg')) + list(input_path.glob('*.png'))
    
    if not image_files:
        raise ValueError(f"No images found in {input_dir}")
    
    tier_config = attacker.tier_config
    print(f"4. Running attacks ({tier.capitalize()} tier: {tier_config['total_tests']} tests)...")
    
    all_results = []
    for img_file in tqdm(image_files, desc="   Processing"):
        result = attacker.run_attacks(str(img_file))
        all_results.append(result)
    
    print(f"   ✓ Attacks completed\n")
    
    # Step 5: Prepare results
    results_payload = {
        'session_token': session_token,
        'model_identity': model_identity,
        'device_info': attacker.device_info,
        'tier': tier,
        'results': all_results,
        'nonce': nonce
    }
    
    # Step 6: Encrypt and submit
    print("5. Encrypting results...")
    encrypted_file = encrypt_results(session_token, model_identity, results_payload, nonce)
    print(f"   ✓ Results encrypted\n")
    
    print("6. Submitting to RednBlue...")
    response = submit_results(session_token, encrypted_file)
    print(f"   ✓ Results submitted\n")
    
    # Display summary
    print(f"{Fore.GREEN}{'='*60}{Style.RESET_ALL}")
    print(f"{Style.BRIGHT}  Test Complete!{Style.RESET_ALL}")
    print(f"{Fore.GREEN}{'='*60}{Style.RESET_ALL}\n")
    print(f"  Status: {response['status']}")
    print(f"  Validation: {response.get('validation_zone', 'pending')}")
    print(f"\n  Your certificate is being generated.")
    print(f"  Check status: {Fore.CYAN}rnb status {session_token}{Style.RESET_ALL}\n")
