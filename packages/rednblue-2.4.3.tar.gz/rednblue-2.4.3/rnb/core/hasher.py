"""
Model identity system with installation-scoped salting
Provides cryptographically secure model hashing with backup/restore capabilities
"""
import hashlib
import secrets
from pathlib import Path
import json
import time


class ModelHasher:
    """Model hashing with installation-scoped salt"""
    
    SALT_FILE = Path.home() / '.rnb' / 'installation_salt'
    
    @classmethod
    def get_or_create_salt(cls) -> str:
        """
        Get existing salt or create new one
        Salt is installation-scoped (one per machine)
        """
        cls.SALT_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        if cls.SALT_FILE.exists():
            return cls.SALT_FILE.read_text().strip()
        else:
            salt = secrets.token_hex(16)
            cls.SALT_FILE.write_text(salt)
            cls.SALT_FILE.chmod(0o600)  # User-only access
            return salt
    
    @classmethod
    def hash_model(cls, model_path: str) -> dict:
        """
        Hash model file with installation salt
        Uses chunked reading for large files
        
        Returns:
            dict: {
                'model_hash': '64-char hex digest',
                'salt': 'installation salt',
                'file_size': size in bytes,
                'timestamp': unix timestamp,
                'file_name': 'model.pt'
            }
        """
        salt = cls.get_or_create_salt()
        hasher = hashlib.sha256()
        hasher.update(salt.encode())
        
        # Chunked reading for large models
        model_file = Path(model_path)
        if not model_file.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")
        
        with open(model_file, 'rb') as f:
            while chunk := f.read(65536):  # 64KB chunks
                hasher.update(chunk)
        
        return {
            'model_hash': hasher.hexdigest(),
            'salt': salt,
            'file_size': model_file.stat().st_size,
            'timestamp': time.time(),
            'file_name': model_file.name
        }
    
    @classmethod
    def backup_salt(cls, output_path: str, password: str):
        """
        Backup installation salt with password encryption
        Uses PBKDF2 for key derivation and Fernet for encryption
        """
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.backends import default_backend
        import base64
        import os
        
        salt_value = cls.get_or_create_salt()
        
        # Derive key from password
        kdf_salt = os.urandom(16)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=kdf_salt,
            iterations=100000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        
        # Encrypt salt
        fernet = Fernet(key)
        encrypted_salt = fernet.encrypt(salt_value.encode())
        
        # Save to file
        backup_data = {
            'kdf_salt': base64.b64encode(kdf_salt).decode(),
            'encrypted_salt': base64.b64encode(encrypted_salt).decode(),
            'version': '2.0.0'
        }
        
        Path(output_path).write_text(json.dumps(backup_data, indent=2))
    
    @classmethod
    def restore_salt(cls, input_path: str, password: str):
        """
        Restore installation salt from backup
        Requires same password used for backup
        """
        from cryptography.fernet import Fernet, InvalidToken
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.backends import default_backend
        import base64
        
        backup_data = json.loads(Path(input_path).read_text())
        
        # Derive key from password
        kdf_salt = base64.b64decode(backup_data['kdf_salt'])
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=kdf_salt,
            iterations=100000,
            backend=default_backend()
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        
        # Decrypt salt
        try:
            fernet = Fernet(key)
            encrypted_salt = base64.b64decode(backup_data['encrypted_salt'])
            salt_value = fernet.decrypt(encrypted_salt).decode()
        except InvalidToken:
            raise ValueError("Invalid password")
        
        # Save restored salt
        cls.SALT_FILE.parent.mkdir(parents=True, exist_ok=True)
        cls.SALT_FILE.write_text(salt_value)
        cls.SALT_FILE.chmod(0o600)
