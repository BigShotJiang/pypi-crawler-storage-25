"""RednBlue CLI v2.4"""
__version__ = "2.4.3"
__author__ = "Dr. Mahdi Deramgozin, Dr. Saeid Samizade"
