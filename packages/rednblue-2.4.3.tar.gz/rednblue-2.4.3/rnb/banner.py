#!/usr/bin/env python3
"""
RednBlue CLI Welcome Banner
Displays after installation or when running `rnb` without arguments
"""

import sys
import os

# Check if terminal supports true color
def supports_truecolor():
    """Check if terminal supports 24-bit true color."""
    colorterm = os.environ.get('COLORTERM', '')
    return colorterm in ('truecolor', '24bit')

# ANSI color codes matching the brand colors from the screenshot
# True color (24-bit) versions
BLUE_TC = "\033[38;2;107;127;215m"    # Purple-blue for R
CYAN_TC = "\033[38;2;93;189;189m"     # Teal for n  
CORAL_TC = "\033[38;2;215;107;107m"   # Coral/salmon for B
GOLD_TC = "\033[38;2;178;134;67m"     # Gold for separator
WHITE_TC = "\033[38;2;229;229;229m"   # Bright white
GRAY_TC = "\033[38;2;150;150;150m"    # Gray for secondary
GREEN_TC = "\033[38;2;114;178;114m"   # Green for commands

# 256-color fallback versions  
BLUE_256 = "\033[38;5;105m"
CYAN_256 = "\033[38;5;73m"
CORAL_256 = "\033[38;5;174m"
GOLD_256 = "\033[38;5;178m"
WHITE_256 = "\033[38;5;255m"
GRAY_256 = "\033[38;5;245m"
GREEN_256 = "\033[38;5;114m"

RESET = "\033[0m"

# Select color scheme based on terminal support
if supports_truecolor():
    BLUE, CYAN, CORAL = BLUE_TC, CYAN_TC, CORAL_TC
    GOLD, WHITE, GRAY, GREEN = GOLD_TC, WHITE_TC, GRAY_TC, GREEN_TC
else:
    BLUE, CYAN, CORAL = BLUE_256, CYAN_256, CORAL_256
    GOLD, WHITE, GRAY, GREEN = GOLD_256, WHITE_256, GRAY_256, GREEN_256

VERSION = "2.4.3"

# Pixel-art ASCII logo matching the screenshot style
# Using Unicode block characters for the chunky pixel look
LOGO = f"""{BLUE}██████╗     {CYAN}        {CORAL}██████╗ {RESET}
{BLUE}██╔══██╗    {CYAN}        {CORAL}██╔══██╗{RESET}
{BLUE}██████╔╝    {CYAN}██████╗ {CORAL}██████╔╝{RESET}
{BLUE}██╔══██╗    {CYAN}██╔═══╝ {CORAL}██╔══██╗{RESET}
{BLUE}██║  ██║    {CYAN}██║     {CORAL}██████╔╝{RESET}
{BLUE}╚═╝  ╚═╝    {CYAN}╚═╝     {CORAL}╚═════╝ {RESET}"""


def get_banner(version: str = VERSION) -> str:
    """Generate the full banner with current version."""
    return f"""
{LOGO}

   {CYAN}Zero-Knowledge Adversarial Security Testing{RESET}
   {GRAY}Version {version}{RESET}

{GOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{RESET}


{WHITE}Quick Start:{RESET}

  {GREEN}rnb attack --help{RESET}         → Run adversarial attacks
  {GREEN}rnb submit --help{RESET}         → Submit encrypted results
  {GREEN}rnb status SESSION_ID{RESET}     → Check assessment status
  {GREEN}rnb download SESSION_ID{RESET}   → Get your certificate

{GRAY}Documentation: https://docs.rednblue.ai{RESET}
"""


def show_banner(version: str = VERSION) -> None:
    """Display the RednBlue CLI welcome banner."""
    print(get_banner(version))


def get_version() -> str:
    """Return the current CLI version."""
    return VERSION


# For integration with Click CLI
def print_version_callback(ctx, param, value):
    """Click callback for --version flag."""
    if not value or ctx.resilient_parsing:
        return
    from click import echo
    echo(f"RednBlue CLI v{VERSION}")
    ctx.exit()


if __name__ == "__main__":
    show_banner()
