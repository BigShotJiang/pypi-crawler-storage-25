"""API utilities - UPDATED for production backend"""
import os, requests
from datetime import datetime, timedelta

class APIClient:
    BASE_URL = os.getenv("REDNBLUE_API_URL", "https://api.rednblue.io")  # Removed /v2
    
    def __init__(self, token=None):
        self.token = token
        self._cache = {}
    
    def validate_subscription(self):
        """Validate token with backend"""
        if self.token[:16] in self._cache:
            return self._cache[self.token[:16]]
        
        # Updated endpoint
        r = requests.post(
            f"{self.BASE_URL}/api/cli/validate-token",
            json={"token_code": self.token},
            timeout=30
        )
        data = r.json()
        self._cache[self.token[:16]] = data
        return data

def validate_token(token):
    """Validate token - returns tier and validity"""
    c = APIClient(token)
    s = c.validate_subscription()
    return {"tier": s.get("tier"), "valid": s.get("valid")}

def fetch_nonce(token, model_hash, model_name=None):
    """Request nonce for new test session"""
    c = APIClient(token)
    r = requests.post(
        f"{c.BASE_URL}/api/cli/request-nonce",
        json={
            "token_code": token,
            "model_hash": model_hash,
            "model_name": model_name or f"Model_{model_hash[:8]}"
        }
    )
    return r.json().get("nonce"), r.json().get("session_id")

def submit_results(token, session_id, nonce, encrypted_data, signature):
    """Submit encrypted test results"""
    c = APIClient(token)
    r = requests.post(
        f"{c.BASE_URL}/api/cli/submit-results",
        json={
            "session_id": session_id,
            "nonce": nonce,
            "encrypted_data": encrypted_data,
            "signature": signature
        }
    )
    return r.json()