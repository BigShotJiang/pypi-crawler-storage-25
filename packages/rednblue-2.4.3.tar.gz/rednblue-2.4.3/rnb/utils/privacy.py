def export_user_data(f): pass
def delete_user_data(): pass