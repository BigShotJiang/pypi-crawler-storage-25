class AuditLogger:
    @classmethod
    def log_event(cls, t, d): pass