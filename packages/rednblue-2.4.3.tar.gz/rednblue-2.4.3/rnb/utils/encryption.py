from cryptography.fernet import Fernet
import json, base64, os
from pathlib import Path
def encrypt_results(token, model_id, results, nonce):
    key = base64.urlsafe_b64encode(os.urandom(32))
    f = Fernet(key)
    encrypted = f.encrypt(json.dumps(results).encode())
    out = Path.home() / ".rnb" / f"enc_{model_id['model_hash'][:8]}.enc"
    out.parent.mkdir(exist_ok=True)
    out.write_bytes(encrypted)
    return str(out)
