import click, os
import hashlib
import hmac
import base64
import json
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

VERSION = "2.4.3"

# ══════════════════════════════════════════════════════════════════════════════
# Banner
# ══════════════════════════════════════════════════════════════════════════════

# ANSI colors (256-color mode for compatibility)

GOLD = "\033[38;5;178m"
WHITE = "\033[38;5;255m"
GRAY = "\033[38;5;245m"
GREEN = "\033[38;5;114m"
# Colors matching the pixel art exactly
BLUE = "\033[38;2;100;120;220m"   # Blue-purple for R
CYAN = "\033[38;2;95;185;175m"    # Teal for n  
CORAL = "\033[38;2;210;105;100m"  # Coral/salmon for B
RESET = "\033[0m"

from colorama import Fore, Style, init
init(autoreset=True)

__version__ = "2.4.3"

LOGO = f"""
{Fore.BLUE}{Style.BRIGHT}███████████{Style.RESET_ALL}               {Fore.RED}{Style.BRIGHT}███████████{Style.RESET_ALL}   
{Fore.BLUE}{Style.BRIGHT}▒▒███▒▒▒▒▒███{Style.RESET_ALL}             {Fore.RED}{Style.BRIGHT}▒▒███▒▒▒▒▒███{Style.RESET_ALL}
 {Fore.BLUE}{Style.BRIGHT}▒███    ▒███{Style.RESET_ALL}  {Fore.CYAN}████████   {Style.RESET_ALL} {Fore.RED}{Style.BRIGHT}▒███    ▒███{Style.RESET_ALL}
 {Fore.BLUE}{Style.BRIGHT}▒██████████{Style.RESET_ALL}  {Fore.CYAN}▒▒███ ▒▒███  {Style.RESET_ALL}{Fore.RED}{Style.BRIGHT}▒██████████{Style.RESET_ALL} 
 {Fore.BLUE}{Style.BRIGHT}▒███▒▒▒▒▒███{Style.RESET_ALL}  {Fore.CYAN}▒███  ▒███  {Style.RESET_ALL}{Fore.RED}{Style.BRIGHT}▒███▒▒▒▒▒███{Style.RESET_ALL}
 {Fore.BLUE}{Style.BRIGHT}▒███    ▒███{Style.RESET_ALL}  {Fore.CYAN}▒███  ▒███  {Style.RESET_ALL}{Fore.RED}{Style.BRIGHT}▒███    ▒███{Style.RESET_ALL}
 {Fore.BLUE}{Style.BRIGHT}█████   █████{Style.RESET_ALL} {Fore.CYAN}████  █████ {Style.RESET_ALL}{Fore.RED}{Style.BRIGHT}███████████{Style.RESET_ALL} 
{Fore.BLUE}{Style.BRIGHT}▒▒▒▒▒   ▒▒▒▒▒{Style.RESET_ALL} {Fore.CYAN}▒▒▒▒  ▒▒▒▒▒ {Style.RESET_ALL}{Fore.RED}{Style.BRIGHT}▒▒▒▒▒▒▒▒▒▒▒{Style.RESET_ALL}  

"""

ATTACK_LABELS = {
    'YGNI': 'Noise Resilience', 'YFGS': 'Input Perturbation',
    'YPGD': 'Stress Tolerance', 'YGMD': 'Detection Consistency',
    'YDAG': 'Evasion Defense', 'YTOG': 'Object Persistence',
    'YNMS': 'Multi-Object Stability', 'YNES': 'Black-Box Resilience',
    'YSQA': 'Query Defense',
}

def show_banner():
    """Display the RednBlue CLI welcome banner."""
    print(f"""
{LOGO}

   {CYAN}Zero-Knowledge Adversarial Security Testing{RESET}
   {GRAY}Version {VERSION}{RESET}

{GOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{RESET}


{WHITE}Quick Start:{RESET}

  {GREEN}rnb preview --help{RESET}        → Run adversarial attacks
  {GREEN}rnb status{RESET}                → Check token & status
  {GREEN}rnb optimize-epsilon{RESET}      → Optimize epsilon (Enterprise)
  {GREEN}rnb test-llm{RESET}              → Test LLM (Enterprise)

{GRAY}Documentation: https://docs.rednblue.ai{RESET}
""")

# ══════════════════════════════════════════════════════════════════════════════
# CLI Entry Point
# ══════════════════════════════════════════════════════════════════════════════

@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx):
    """RednBlue CLI - Zero-Knowledge Adversarial Security Testing"""
    if ctx.invoked_subcommand is None:
        show_banner()

@main.command()
def status():
    """Show status"""
    click.echo(f"RednBlue CLI v{VERSION}")
    token = os.getenv("RNB_TOKEN")
    if token:
        from rnb.utils.api import validate_token
        info = validate_token(token)
        click.echo(f"Token: Valid ({info.get('tier')})")

def encrypt_results_aes256(results, token):
    """Encrypt results with AES-256-CBC (matches backend)"""
    # Derive key from token
    token_hash = hashlib.sha256(token.encode()).digest()
    encryption_key = token_hash[:32]

    # Convert to JSON
    plaintext = json.dumps(results).encode('utf-8')

    # Add PKCS7 padding
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext) + padder.finalize()

    # Generate random IV
    iv = os.urandom(16)

    # Encrypt with AES-256-CBC
    cipher = Cipher(algorithms.AES(encryption_key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    # Return IV + ciphertext as base64
    return base64.b64encode(iv + ciphertext).decode('utf-8')

def sign_data(data, token):
    """Create HMAC-SHA256 signature"""
    token_hash = hashlib.sha256(token.encode()).digest()
    hmac_key = hashlib.sha256(token_hash).digest()
    signature = hmac.new(hmac_key, data.encode('utf-8'), hashlib.sha256).hexdigest()
    return signature

@main.command()
@click.option("--model", type=click.Path(exists=True))
@click.option("--input", "inp")
@click.option("--model-type", "model_type",
              default="classifier",
              type=click.Choice(["classifier", "yolo"], case_sensitive=False),
              show_default=True,
              help="Model architecture type.")
@click.option("--submit", is_flag=True, help="Submit results to server for certification")
def preview(model, inp, model_type, submit):
    """Preview attacks (classifier or YOLO detection model)"""
    from rnb.utils.api import fetch_nonce, submit_results

    click.echo(f"Running local attacks ({model_type.upper()} mode)...")
    if model_type.lower() == "yolo":
        # ── YOLO detection path ──────────────────────────────────────────────
        from rnb.attacks.vision.yolo_attacker import YOLOAttacker
        from pathlib import Path
        from tqdm import tqdm
        from colorama import Fore, Style

        input_path  = Path(inp)
        image_files = list(input_path.glob("*.jpg")) + list(input_path.glob("*.png"))
        if not image_files:
            click.echo(f"✖ No images found in {inp}")
            return

        attacker = YOLOAttacker(model, tier="freelancer", device="cpu")
        attacks_display = [ATTACK_LABELS.get(a, a) for a in attacker.enabled_attacks]
        click.echo(f"Found {len(image_files)} image(s)")
        click.echo(f"Dimensions: {', '.join(attacks_display)}")
        click.echo(f"Epsilons: {attacker.epsilons}")


        all_results, total_tests, passed_tests = [], 0, 0
        for img_file in tqdm(image_files[:3], desc="Testing"):
            result = attacker.run_attacks(str(img_file))
            all_results.append(result)
            for attack_data in result["attacks"].values():
                for test in attack_data:
                    if "success" in test:
                        total_tests += 1
                        if test["success"]:          # success = attack worked (model is vulnerable)
                            passed_tests += 1

        robustness = 1.0 - (passed_tests / total_tests if total_tests else 0)

        from rnb.config.tiers import calculate_grade
        estimated_grade = calculate_grade(robustness)
        grade_color = Fore.GREEN if estimated_grade == "GOLD" else Fore.YELLOW if estimated_grade == "SILVER" else Fore.RED

        click.echo(f"\n{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
        click.echo(f"{Style.BRIGHT}  RednBlue Security Preview — YOLO Detection{Style.RESET_ALL}")
        click.echo(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}\n")
        click.echo(f"  Attacks run    : {total_tests}")
        click.echo(f"  Successful hits: {passed_tests}/{total_tests} ({(1-robustness)*100:.0f}%)")
        click.echo(f"  Robustness rate: {robustness*100:.0f}%")
        click.echo(f"  Estimated Grade: {grade_color}{estimated_grade}{Style.RESET_ALL}\n")
        click.echo(f"  {Fore.YELLOW}⚠️  This is a preview only{Style.RESET_ALL}")
        click.echo(f"  → Visit: {Fore.CYAN}https://rednblue.io/checkout{Style.RESET_ALL}")
        click.echo(f"  → Re-run with: {Fore.CYAN}rnb preview --model-type yolo --submit{Style.RESET_ALL}\n")

        results = {
            "attack_results": all_results,
            "summary": {
                "model_type"     : "yolo_detection",
                "total_tests"    : total_tests,
                "passed_tests"   : passed_tests,
                "robustness"     : robustness,
                "estimated_grade": estimated_grade,
            }
        }
        architecture = "YOLO"

    else:
        # ── Classifier path (original behaviour — unchanged) ─────────────────
        from rnb.core.attacker import run_preview
        results     = run_preview(inp, model)
        architecture = "CNN"

    # ── Optional submission (identical for both paths) ───────────────────────
    if submit:
        token = os.getenv("RNB_TOKEN")
        if not token:
            click.echo("\n✖ Error: RNB_TOKEN environment variable not set")
            click.echo("   Set it with: set RNB_TOKEN=RB-XXXXXX-YYYYYY")
            return

        try:
            click.echo("\n📤 Submitting results to server...")

            with open(model, 'rb') as f:
                model_hash = hashlib.sha256(f.read()).hexdigest()[:16]

            nonce, session_id = fetch_nonce(token, model_hash, os.path.basename(model))
            click.echo(f"   ✓ Session created (ID: {session_id})")

            formatted_results = {
                "model_identity": {
                    "model_name" : os.path.basename(model),
                    "architecture": architecture,
                    "model_hash" : model_hash
                },
                "results": results.get("attack_results", [])
            }

            encrypted_data = encrypt_results_aes256(formatted_results, token)
            signature      = sign_data(encrypted_data, token)
            response       = submit_results(token, session_id, nonce, encrypted_data, signature)

            click.echo(f"\n✅ Results submitted successfully!")
            click.echo(f"   Session ID: {session_id}")
            click.echo(f"   Status: {response.get('status', 'processing')}")
            click.echo(f"\n📋 View results at: https://dashboard.rednblue.io/dashboard/tests")
            click.echo(f"   Certificate will be ready in ~1 minute")

        except Exception as e:
            click.echo(f"\n✖ Submission failed: {str(e)}")
            click.echo(f"   Please check your network connection and try again")

@main.command()
@click.option("--token", envvar="RNB_TOKEN")
@click.option("--model", type=click.Path(exists=True))
@click.option("--attack")
def optimize_epsilon(token, model, attack):
    """Optimize epsilon (Enterprise)"""
    from rnb.utils.api import APIClient
    client = APIClient(token)
    sub = client.validate_subscription()

    if not sub.get("features", {}).get("epsilon_optimization"):
        click.echo("Requires Enterprise subscription")
        return

    click.echo("Running epsilon optimization...")
    from rnb.core.optimizer import EpsilonOptimizer, OptimizationConfig
    config = OptimizationConfig()
    optimizer = EpsilonOptimizer(config)
    click.echo("✓ Complete")

@main.command()
@click.option("--token", envvar="RNB_TOKEN")
@click.option("--model-name")
def test_llm(token, model_name):
    """Test LLM (Enterprise)"""
    from rnb.utils.api import APIClient
    client = APIClient(token)
    sub = client.validate_subscription()

    if not sub.get("features", {}).get("llm_attacks"):
        click.echo("Requires Enterprise subscription")
        return

    click.echo(f"Testing {model_name}...")
    from rnb.attacks.llm.jailbreak import JailbreakAttacker

    def model_fn(p): return f"Response to: {p}"

    attacker = JailbreakAttacker(model_fn)
    results = attacker.run_attack("test prompt")
    click.echo(f"Success rate: {results['success_rate']:.1%}")

if __name__ == "__main__":
    main()
