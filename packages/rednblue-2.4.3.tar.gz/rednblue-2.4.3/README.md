# RednBlue CLI v2.4.3

**Zero-Knowledge Adversarial Security Testing for AI Models**

RednBlue CLI is a command-line tool for testing the adversarial robustness of machine learning models. Run security assessments locally — your model never leaves your infrastructure.

```
███████████               ███████████
▒▒███▒▒▒▒▒███             ▒▒███▒▒▒▒▒███
 ▒███    ▒███  ████████    ▒███    ▒███
 ▒██████████  ▒▒███ ▒▒███  ▒██████████
 ▒███▒▒▒▒▒███  ▒███  ▒███  ▒███▒▒▒▒▒███
 ▒███    ▒███  ▒███  ▒███  ▒███    ▒███
 █████   █████ ████  █████ ███████████
▒▒▒▒▒   ▒▒▒▒▒ ▒▒▒▒  ▒▒▒▒▒ ▒▒▒▒▒▒▒▒▒▒▒

Zero-Knowledge Adversarial Security Testing
```

---

## Features

- **Zero-Knowledge Protocol** — Model weights and data never leave your infrastructure
- **Image Classifiers** — Test ResNet, VGG, EfficientNet, and custom architectures
- **YOLO Detection** — Full support for YOLOv5, YOLOv8, YOLOv10, YOLOv11
- **Tier-Based Testing** — Freelancer (quick scan) and Enterprise (comprehensive)
- **Encrypted Submission** — AES-256 encrypted results with HMAC-SHA256 signing
- **Multi-Jurisdiction Compliance** — EU AI Act, NIST AI RMF, ISO/IEC 42001, UK DSIT, Canada AIDA, Singapore MAIGF

---

## Installation

```bash
# Install from PyPI
pip install rednblue

# Verify installation
rnb
```

### Requirements

- Python 3.8+
- PyTorch 2.0+
- CUDA (optional, for GPU acceleration)

---

## Quick Start

### 1. Set your token

```bash
# Windows
set RNB_TOKEN=RB-XXXXXX-YYYYYY

# Linux/Mac
export RNB_TOKEN=RB-XXXXXX-YYYYYY
```

### 2. Run a security assessment

**Image Classifier:**
```bash
rnb preview --model resnet50.pth --input ./test_images --model-type classifier
```

**YOLO Detection Model:**
```bash
rnb preview --model yolov10n.pt --input ./test_images --model-type yolo
```

### 3. Submit for certification

```bash
rnb preview --model yolov10n.pt --input ./images --model-type yolo --submit
```

---

## Commands

| Command | Description |
|---------|-------------|
| `rnb` | Show welcome banner and quick start |
| `rnb preview --help` | Run adversarial attacks |
| `rnb status` | Check token validity and tier |
| `rnb optimize-epsilon` | Optimize epsilon values (Enterprise) |
| `rnb test-llm` | Test LLM models (Enterprise) |

---

## Assessment Dimensions

### Classifier Models

| Dimension | Description |
|-----------|-------------|
| Noise Resilience | Stability under sensor noise and interference |
| Spatial Consistency | Robustness to spatial feature shifts |
| Universal Pattern Defense | Resistance to universal perturbation patterns |
| Feature Stability | Internal representation integrity |
| Confidence Calibration | Prediction reliability accuracy |
| Iterative Stress Tolerance | Defense against sustained pressure |
| Optimization Attack Defense | Resistance to optimized adversarial inputs |
| Deep Perturbation Resistance | Resilience against deep layer perturbations |

### YOLO Detection Models

| Dimension | Description |
|-----------|-------------|
| Noise Resilience | Stability under sensor noise |
| Input Perturbation Defense | Resistance to subtle input modifications |
| Iterative Stress Tolerance | Defense against multi-step attacks |
| Detection Consistency | Reliable detection under varying conditions |
| Targeted Evasion Defense | Resistance to deliberate misclassification |
| Object Persistence | Maintains detections under perturbations |
| Multi-Object Stability | Accuracy in crowded scenes |
| Black-Box Resilience | Defense without model access |
| Query-Limited Defense | Resistance to low-query probing |

---

## Tier Comparison

| Feature | Freelancer | Enterprise |
|---------|------------|------------|
| Classifier Attacks | 5 | 8 |
| YOLO Attacks | 4 | 9 |
| Epsilon Values | 2 | 4 |
| Total Scenarios | ~10-20 | ~30-70 |
| LLM Testing | ❌ | ✅ |
| Epsilon Optimization | ❌ | ✅ |

---

## Output Example

```
============================================================
  RednBlue Security Preview — YOLO Detection
============================================================
  Attacks run    : 21
  Successful hits: 0/21 (0%)
  Robustness rate: 100%
  Estimated Grade: GOLD

  ⚠️  This is a preview only
  → Visit: https://rednblue.io/checkout
  → Re-run with: rnb preview --model-type yolo --submit
```

---

## Certification Grades

| Grade | Score | Meaning |
|-------|-------|---------|
| 🥇 GOLD | ≥90% | Excellent robustness, deployment ready |
| 🥈 SILVER | ≥75% | Good robustness, minor improvements recommended |
| 🥉 BRONZE | ≥50% | Moderate robustness, improvements needed |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Your Infrastructure                   │
│  ┌─────────┐    ┌─────────┐    ┌─────────────────────┐  │
│  │  Model  │───▶│   CLI   │───▶│  Encrypted Results  │  │
│  └─────────┘    └─────────┘    └──────────┬──────────┘  │
└───────────────────────────────────────────┼─────────────┘
                                            │ AES-256
                                            ▼
                              ┌─────────────────────────┐
                              │   RednBlue Platform     │
                              │  dashboard.rednblue.io  │
                              └─────────────────────────┘
```

---

## Links

- **Platform:** https://dashboard.rednblue.io
- **Documentation:** https://docs.rednblue.ai
- **Website:** https://rednblue.io

---

## Authors

- **Dr. Mahdi Deramgozin** — Chief AI Officer
- **Dr. Saeid Samizade** — Chief Technology Officer

---

## License

Proprietary — RednBlue SAS © 2026

Made in France 🇫🇷
