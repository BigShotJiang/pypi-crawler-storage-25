# Changelog

All notable changes to RednBlue CLI are documented here.

---

## [2.2.0] - 2026-03-08

### Added

- **YOLO Detection Model Support**
  - Full adversarial attack suite for YOLOv5, v8, v10, v11 models
  - New `--model-type yolo` flag in CLI
  - Ultralytics integration for seamless model loading

- **New YOLO-Specific Attacks**
  - `YGNI` — YOLO Gaussian Noise Injection
  - `YFGS` — YOLO FGSM Detection Attack
  - `YPGD` — YOLO PGD Detection Evasion (40 iterations)
  - `YDAG` — Dense Adversary Generation (Xie et al. 2017)
  - `YTOG` — Targeted Object Disappearance (Chow et al. 2020)
  - `YNMS` — NMS Bypass / False Detection Injection

- **Black-Box Attacks for YOLO**
  - `YNES` — Natural Evolution Strategy (gradient-free)
  - `YSQA` — Square Attack (Andriushchenko et al. 2020)

- **Gradient Masking Diagnostic (YGMD)**
  - Detects false robustness in YOLO models
  - Computes masking index (0.0 = genuine, 1.0 = severe masking)
  - Cross-validates white-box vs black-box attack effectiveness

### Fixed

- **Model Loading Issues**
  - Improved architecture detection for ResNet and VGG state_dicts
  - Better handling of `OrderedDict` vs full model saves
  - Fixed device mapping for CPU/CUDA/MPS

- **Gradient Computation**
  - Fixed autograd graph preservation in YOLO forward pass
  - Added gradient masking fallback for models with zero gradients
  - Improved loss computation for detection heads

### Changed

- CLI now uses `--model-type` flag (default: `classifier`)
- Unified submission pipeline for both model types
- Updated API endpoints to match production backend

---

## [2.1.0] - 2026-02-18

### Added

- Initial public release
- Image classifier attack suite (8 attacks)
- Tier-based configuration (Freelancer/Enterprise)
- Encrypted result submission
- Certificate generation

### Attacks

- `GNI` — Gaussian Noise Injection
- `SHFP` — High-Frequency Perturbation
- `UAP` — Universal Adversarial Patch
- `FSP` — FGSM Surrogate Transfer
- `CCM` — Color Channel Manipulation
- `PGD` — Projected Gradient Descent
- `CW` — Carlini-Wagner L2
- `DEEP` — DeepFool

---

## [2.0.0] - 2026-01-15

### Added

- Complete rewrite with modular architecture
- Installation-scoped salt system for model hashing
- AES-256-CBC encryption for result submission
- HMAC-SHA256 signing

### Changed

- Migrated from v1 API to v2 API structure
- New tier system (Freelancer/Enterprise)

---

## [1.0.0] - 2025-11-01

### Added

- Initial internal release
- Basic FGSM and PGD attacks
- Simple CLI interface
