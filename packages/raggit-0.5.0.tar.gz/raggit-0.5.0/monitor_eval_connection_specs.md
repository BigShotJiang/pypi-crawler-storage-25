## Updates for retrieval quality tracking + EvalSuite.from_monitor()

---

### 1. Update raggit/middleware/models.py

Add retrieval quality fields to Event:

```python
class Event(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    cluster_id: str
    query_text: str
    latency_ms: Optional[float] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    cache_hit: bool = False
    # Retrieval quality — optional, user provides if available
    retrieval_rank: Optional[int] = None
    retrieval_score: Optional[float] = None
    retrieved_doc_ids: Optional[List[str]] = None
    user_feedback: Optional[bool] = None  # True=good, False=bad, None=unknown
    extra: Dict[str, Any] = {}
```

---

### 2. Update raggit/middleware/stores/base.py

Update MonitorStore.log() signature:

```python
@abstractmethod
def log(
    self,
    query: str,
    vec: List[float],
    latency_ms: float,
    threshold: float,
    cache_hit: bool = False,
    retrieval_rank: Optional[int] = None,
    retrieval_score: Optional[float] = None,
    retrieved_doc_ids: Optional[List[str]] = None,
    user_feedback: Optional[bool] = None,
    **kwargs
) -> None: ...
```

Add new query methods:

```python
@abstractmethod
def get_events(
    self,
    cluster_id: Optional[str] = None,
    since: Optional[datetime] = None,
    cache_hit: Optional[bool] = None,
    has_feedback: Optional[bool] = None,
) -> List[Event]: ...

@abstractmethod
def get_clusters(
    self,
    top: Optional[int] = None,
    since: Optional[datetime] = None,
    last_seen_before: Optional[datetime] = None,
    min_retrieval_rank: Optional[int] = None,   # clusters where rank > threshold
    max_retrieval_score: Optional[float] = None, # clusters where score < threshold
) -> List[Cluster]: ...
```

Note: Cluster model also needs avg_retrieval_rank and avg_retrieval_score:

```python
class Cluster(BaseModel):
    cluster_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    representative_query: str
    representative_vec: List[float]
    count: int = 0
    created_at: datetime = Field(default_factory=datetime.now)
    last_seen: datetime = Field(default_factory=datetime.now)
    avg_retrieval_rank: Optional[float] = None
    avg_retrieval_score: Optional[float] = None
```

---

### 3. Update raggit/middleware/stores/sqlite.py

Update events table schema:

```sql
CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    cluster_id TEXT NOT NULL,
    query_text TEXT NOT NULL,
    latency_ms REAL,
    timestamp TEXT NOT NULL,
    cache_hit INTEGER DEFAULT 0,
    retrieval_rank INTEGER,
    retrieval_score REAL,
    retrieved_doc_ids TEXT,  -- JSON array of strings
    user_feedback INTEGER,   -- NULL=unknown, 1=good, 0=bad
    extra TEXT DEFAULT '{}',
    FOREIGN KEY (cluster_id) REFERENCES clusters(cluster_id)
);
```

Update clusters table to track aggregated retrieval quality:

```sql
CREATE TABLE IF NOT EXISTS clusters (
    cluster_id TEXT PRIMARY KEY,
    representative_vec TEXT NOT NULL,
    representative_query TEXT NOT NULL,
    count INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    avg_retrieval_rank REAL,    -- updated on each log()
    avg_retrieval_score REAL    -- updated on each log()
);
```

Update log() to compute rolling averages:

```python
def log(self, query, vec, latency_ms, threshold, cache_hit=False,
        retrieval_rank=None, retrieval_score=None,
        retrieved_doc_ids=None, user_feedback=None, **kwargs) -> None:
    """
    Same clustering logic as before plus:
    - INSERT event with new fields
    - If retrieval_rank provided: update cluster avg_retrieval_rank
      new_avg = (old_avg * (count-1) + retrieval_rank) / count
    - If retrieval_score provided: update cluster avg_retrieval_score
      same rolling average formula
    - retrieved_doc_ids stored as json.dumps(list)
    - user_feedback stored as 1/0/NULL
    """
    ...

def get_clusters(self, top=None, since=None, last_seen_before=None,
                 min_retrieval_rank=None, max_retrieval_score=None) -> List[Cluster]:
    """
    Add filters:
    - min_retrieval_rank: WHERE avg_retrieval_rank > min_retrieval_rank
    - max_retrieval_score: WHERE avg_retrieval_score < max_retrieval_score
    """
    ...
```

---

### 4. Update raggit/middleware/monitor/monitor.py

Update log() to pass new fields:

```python
def log(
    self,
    query: str,
    latency_ms: float,
    cache_hit: bool = False,
    retrieval_rank: Optional[int] = None,
    retrieval_score: Optional[float] = None,
    retrieved_doc_ids: Optional[List[str]] = None,
    user_feedback: Optional[bool] = None,
    **kwargs
) -> None:
    vec = self.embedder(query)
    self.store.log(
        query=query,
        vec=vec,
        latency_ms=latency_ms,
        threshold=self.cluster_threshold,
        cache_hit=cache_hit,
        retrieval_rank=retrieval_rank,
        retrieval_score=retrieval_score,
        retrieved_doc_ids=retrieved_doc_ids,
        user_feedback=user_feedback,
        **kwargs
    )

def problematic_clusters(
    self,
    min_rank: int = 5,
    max_score: float = 0.7,
    top: Optional[int] = None,
) -> List[Cluster]:
    """
    Shortcut for clusters with poor retrieval quality.
    Delegates to store.get_clusters(min_retrieval_rank=min_rank, 
                                     max_retrieval_score=max_score)
    """
    return self.store.get_clusters(
        min_retrieval_rank=min_rank,
        max_retrieval_score=max_score,
        top=top,
    )
```

---

### 5. New method: EvalSuite.from_monitor()

Add to raggit/evaluation/suite.py:

```python
@classmethod
def from_monitor(
    cls,
    monitor: "Monitor",
    embedder: Callable[[str], List[float]],
    corpus: List[str],
    top: Optional[int] = 10,
    use_problematic: bool = True,
    min_rank: int = 5,
    max_score: float = 0.7,
    k: int = 3,
    name: str = "from_monitor",
) -> "EvalSuite":
    """
    Generate an EvalSuite from production monitoring data.

    If use_problematic=True: uses monitor.problematic_clusters()
    If use_problematic=False: uses monitor.clusters(top=top)

    For each cluster:
    1. query = cluster.representative_query
    2. query_vec = embedder(query)
    3. corpus_vecs = [embedder(doc) for doc in corpus]
    4. Find expected_doc: most similar doc in corpus to query_vec
       expected_vec = corpus_vecs[argmax(cosine_similarity(query_vec, each corpus_vec))]
    5. Create embedding_eval(query_vec, expected_vec, corpus_vecs, k=k)
    6. suite.add(name=cluster.representative_query, eval_fn=eval)

    Returns configured EvalSuite ready to run.

    Usage:
        suite = EvalSuite.from_monitor(
            monitor=monitor,
            embedder=embedder,
            corpus=my_docs,
            use_problematic=True,
        )
        report = suite.run()
        report.show()
    """
    from raggit.middleware.monitor.monitor import Monitor
    from raggit.fns.embedding import embedding_eval

    suite = cls(name=name)

    if use_problematic:
        clusters = monitor.problematic_clusters(
            min_rank=min_rank,
            max_score=max_score,
            top=top,
        )
    else:
        clusters = monitor.clusters(top=top)

    corpus_vecs = [embedder(doc) for doc in corpus]

    for cluster in clusters:
        query_vec = embedder(cluster.representative_query)
        
        # Infer expected_doc as most similar in corpus
        scores = [
            Metrics.cosine_similarity(query_vec, cv)
            for cv in corpus_vecs
        ]
        best_idx = scores.index(max(scores))
        expected_vec = corpus_vecs[best_idx]

        suite.add(
            name=cluster.representative_query[:50],
            eval_fn=embedding_eval(
                query_vec=query_vec,
                expected_vec=expected_vec,
                corpus_vecs=corpus_vecs,
                k=k,
            )
        )

    return suite
```

---

### Usage example — full loop

```python
from raggit.middleware import Middleware, Monitor, SemanticCache, SQLiteStore
from raggit.evaluation import EvalSuite

store = SQLiteStore(".raggit/middleware.db")
embedder = lambda t: model.encode(t).tolist()

monitor = Monitor(store=store, embedder=embedder)
mw = Middleware(monitor=monitor)

# Production — log with retrieval quality
@mw.track
def answer(query: str) -> str:
    docs, scores, ids = retriever.search_with_scores(query)
    response = llm.generate(query, docs)
    monitor.log(
        query=query,
        latency_ms=0,
        retrieval_rank=1,
        retrieval_score=scores[0],
        retrieved_doc_ids=ids,
    )
    return response

# After collecting production data
# Generate evals from problematic clusters automatically
suite = EvalSuite.from_monitor(
    monitor=monitor,
    embedder=embedder,
    corpus=my_documents,
    use_problematic=True,
    min_rank=5,
)

report = suite.run()
report.show()
```

---

### Notes for Claude Code
- Rolling average formula: new_avg = (old_avg * (count-1) + new_value) / count
- Handle None avg gracefully: if no previous avg, new_avg = new_value
- from_monitor() is a classmethod on EvalSuite — import Monitor lazily to avoid circular imports
- Use Metrics.cosine_similarity for finding expected_doc
- retrieved_doc_ids stored as json.dumps() in SQLite
- user_feedback stored as INTEGER: NULL=None, 1=True, 0=False