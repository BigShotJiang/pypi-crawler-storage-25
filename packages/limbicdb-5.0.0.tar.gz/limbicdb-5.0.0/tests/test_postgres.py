"""
Integration tests for PostgresStore — Python SDK Phase 2.

Requires PG_TEST_URL environment variable to run, gracefully skipped otherwise.
This mirrors the Node.js test in tests/integration/postgres-store.test.ts.

Run::

    PG_TEST_URL=postgres://postgres:test@localhost:5432/postgres pytest tests/test_postgres.py -v

Docker quick-start::

    docker run -d --name pgvector -e POSTGRES_PASSWORD=test -p 5432:5432 pgvector/pgvector:pg16
"""

from __future__ import annotations

import os
import time
import uuid

import pytest

from limbicdb.types import Memory, MemoryKind, MemoryScope, Session, TimelineEvent, TimelineType

PG_TEST_URL = os.environ.get("PG_TEST_URL")
skip_no_pg = pytest.mark.skipif(
    not PG_TEST_URL,
    reason="PG_TEST_URL not set — skipping PostgreSQL integration tests",
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def pg_store():  # type: ignore[return]
    """Create a PostgresStore for the test module, drop schema on teardown."""
    if not PG_TEST_URL:
        pytest.skip("PG_TEST_URL not set")

    from limbicdb.storage.postgres_store import PostgresStore

    test_schema = f"limbic_py_test_{int(time.time())}"
    store = PostgresStore(
        PG_TEST_URL,
        schema=test_schema,
        create_extension=True,
        embedding_dimensions=4,  # tiny dim for tests
    )
    store.init()
    yield store

    # Teardown: drop the test schema
    with store._conn() as conn:
        conn.execute(f'DROP SCHEMA IF EXISTS "{test_schema}" CASCADE')
        conn.commit()
    store.close()


def _mem(**kwargs: object) -> Memory:
    now = int(time.time() * 1000)
    defaults: dict[str, object] = dict(
        id=str(uuid.uuid4()),
        content="Hello from PostgreSQL Python SDK",
        kind=MemoryKind.FACT,
        tags=["test"],
        meta={},
        strength=0.75,
        base_strength=0.75,
        created_at=now,
        accessed_at=now,
        access_count=0,
        scope=MemoryScope.SESSION,
    )
    defaults.update(kwargs)
    return Memory(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@skip_no_pg
class TestPostgresStoreIntegration:
    def test_save_and_get_memory(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        m = _mem(id="pg-py-1", content="Python meets PostgreSQL!")
        store.save_memory(m)

        retrieved = store.get_memory("pg-py-1")
        assert retrieved is not None
        assert retrieved.content == "Python meets PostgreSQL!"
        assert retrieved.strength == 0.75
        assert "test" in retrieved.tags

    def test_keyword_search(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        store.save_memory(_mem(id="pg-py-2", content="LimbicDB Python SDK rocks"))
        results = store.search_memories("Python SDK", limit=5)
        assert any(m.id == "pg-py-2" for m in results)

    def test_upsert_memory(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        now = int(time.time() * 1000)
        m = _mem(id="pg-upsert", content="Original", created_at=now, accessed_at=now)
        store.save_memory(m)
        m.content = "Updated"
        m.strength = 0.9
        store.save_memory(m)

        updated = store.get_memory("pg-upsert")
        assert updated is not None
        assert updated.content == "Updated"
        assert updated.strength == 0.9

    def test_soft_delete(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        m = _mem(id="pg-del")
        store.save_memory(m)
        store.delete_memory("pg-del")
        assert store.get_memory("pg-del") is None

    def test_state_kv(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        store.set_state("sync-cursor", "abc123", int(time.time() * 1000))
        assert store.get_state("sync-cursor") == "abc123"
        assert "sync-cursor" in store.get_all_state_keys()
        store.delete_state("sync-cursor")
        assert store.get_state("sync-cursor") is None

    def test_timeline_events(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        event = TimelineEvent(
            id=str(uuid.uuid4()),
            type=TimelineType.MEMORY,
            action="create",
            timestamp=int(time.time() * 1000),
        )
        store.log_event(event)
        events = store.get_events(limit=10)
        assert len(events) >= 1

    def test_sessions(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        sess = Session(id="sess-py-1", name="Test", created_at=int(time.time() * 1000))
        store.save_session(sess)
        retrieved = store.get_session("sess-py-1")
        assert retrieved is not None
        assert retrieved.name == "Test"

        store.archive_session("sess-py-1", int(time.time() * 1000))
        archived = store.get_session("sess-py-1")
        assert archived is not None
        assert archived.archived_at is not None

    def test_stats(self, pg_store: object) -> None:
        from limbicdb.storage.postgres_store import PostgresStore
        store: PostgresStore = pg_store  # type: ignore[assignment]

        stats = store.get_stats()
        assert "memoryCount" in stats
        assert stats["memoryCount"] >= 0
