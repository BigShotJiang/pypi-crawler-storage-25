"""
Tests for HybridLogicalClock — Phase 2.

Verifies identical behaviour to the TypeScript HLC in src/sync/hlc.ts.
"""

import time

from limbicdb.sync.hlc import HLCTimestamp, HybridLogicalClock


class TestHLCTimestamp:
    def test_str_roundtrip(self) -> None:
        ts = HLCTimestamp(wall_ms=1_700_000_000_000, counter=42, node_id="node-alpha")
        assert str(ts) == "1700000000000-002a-node-alpha"
        parsed = HLCTimestamp.parse(str(ts))
        assert parsed == ts

    def test_ordering_by_wall_ms(self) -> None:
        older = HLCTimestamp(wall_ms=100, counter=0, node_id="n1")
        newer = HLCTimestamp(wall_ms=200, counter=0, node_id="n1")
        assert older < newer
        assert newer > older

    def test_ordering_by_counter_when_same_wall(self) -> None:
        t1 = HLCTimestamp(wall_ms=100, counter=0, node_id="n1")
        t2 = HLCTimestamp(wall_ms=100, counter=1, node_id="n1")
        assert t1 < t2

    def test_equality(self) -> None:
        ts = HLCTimestamp(wall_ms=500, counter=3, node_id="abc")
        assert ts == HLCTimestamp(wall_ms=500, counter=3, node_id="abc")

    def test_parse_invalid_raises(self) -> None:
        import pytest
        with pytest.raises(ValueError):
            HLCTimestamp.parse("not-a-valid-hlc")

    def test_zero(self) -> None:
        z = HLCTimestamp.zero("node-x")
        assert z.wall_ms == 0
        assert z.counter == 0
        assert z.node_id == "node-x"


class TestHybridLogicalClock:
    def test_tick_is_monotonic(self) -> None:
        hlc = HybridLogicalClock("node-a")
        ts1 = hlc.tick()
        ts2 = hlc.tick()
        assert ts2 >= ts1

    def test_tick_encodes_node_id(self) -> None:
        hlc = HybridLogicalClock("agent-alice")
        ts = hlc.tick()
        assert ts.node_id == "agent-alice"

    def test_counter_increments_within_same_ms(self) -> None:
        """Force counter increment by mocking same wall time."""
        hlc = HybridLogicalClock("n1")
        fixed_ms = int(time.time() * 1000)
        # Manually set _last to same wall_ms
        from limbicdb.sync.hlc import HLCTimestamp
        hlc._last = HLCTimestamp(wall_ms=fixed_ms, counter=5, node_id="n1")
        # tick with now == fixed_ms
        # We can't easily mock time here, but we can verify the formula:
        # If wall collides, counter must be > 5
        ts = hlc.tick()
        # Either wall advanced (counter=0) or counter > 5
        assert ts.wall_ms >= fixed_ms
        if ts.wall_ms == fixed_ms:
            assert ts.counter > 5

    def test_recv_advances_past_remote(self) -> None:
        hlc = HybridLogicalClock("local")
        future_ts = HLCTimestamp(wall_ms=int(time.time() * 1000) + 10_000, counter=9, node_id="remote")
        new_ts = hlc.recv(future_ts)
        # Local should advance to at least match remote wall_ms
        assert new_ts.wall_ms >= future_ts.wall_ms

    def test_recv_causal_consistency(self) -> None:
        """After recv(), local tick must produce a timestamp > remote."""
        hlc = HybridLogicalClock("local")
        remote = HLCTimestamp(wall_ms=int(time.time() * 1000) + 5000, counter=0, node_id="remote")
        hlc.recv(remote)
        local = hlc.tick()
        assert local > remote

    def test_serialise_and_parse_roundtrip(self) -> None:
        hlc = HybridLogicalClock("roundtrip-node")
        ts = hlc.tick()
        s = str(ts)
        parsed = HLCTimestamp.parse(s)
        assert parsed.wall_ms == ts.wall_ms
        assert parsed.counter == ts.counter
        assert parsed.node_id == ts.node_id
