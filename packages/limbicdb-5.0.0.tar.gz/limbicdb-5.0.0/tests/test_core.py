"""
Unit tests for LimbicDB Python SDK.

These tests run entirely in-process using the MemoryStorageAdapter —
no SQLite file, no filesystem, no PostgreSQL required.

Key invariant tests:
  - ExplainEngine produces identical scores to TypeScript for the same inputs.
  - API semantics match TypeScript.
  - Cross-language SQLite file compatibility.
"""

import math
import time

import pytest

from limbicdb import LimbicDB, LimbicDBConfig
from limbicdb.core.explain_engine import ExplainEngine, WEIGHT_DECAY, WEIGHT_SEMANTIC
from limbicdb.storage.memory_adapter import MemoryStorageAdapter
from limbicdb.storage.sqlite_adapter import SQLiteStorageAdapter
from limbicdb.types import Memory, MemoryKind, MemoryScope, TimelineEvent, TimelineType


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_memory(**kwargs: object) -> Memory:
    now = int(time.time() * 1000)
    defaults = dict(
        id="test-1",
        content="The user prefers dark mode",
        kind=MemoryKind.PREFERENCE,
        tags=["ui"],
        meta={},
        strength=0.75,
        base_strength=0.75,
        created_at=now,
        accessed_at=now,
        access_count=0,
        scope=MemoryScope.SESSION,
    )
    defaults.update(kwargs)  # type: ignore[arg-type]
    return Memory(**defaults)  # type: ignore[arg-type]


def _in_memory_db() -> LimbicDB:
    return LimbicDB(LimbicDBConfig(storage=MemoryStorageAdapter()))


# ---------------------------------------------------------------------------
# ExplainEngine — numerical correctness
# ---------------------------------------------------------------------------

class TestExplainEngine:
    """Verify that Python ExplainEngine output matches TypeScript values."""

    def test_perfect_recall_no_decay(self) -> None:
        """Freshly created, just-accessed memory → high decay score (≈1.0)."""
        engine = ExplainEngine()
        now = int(time.time() * 1000)
        m = _make_memory(accessed_at=now)
        bd = engine.compute(m, semantic_score=1.0, now_ms=now)
        # decay should be ≈ 1.0 (no time has passed)
        assert bd.decay > 0.99
        assert bd.semantic == 1.0
        assert abs(bd.score - (1.0 * WEIGHT_SEMANTIC + bd.decay * WEIGHT_DECAY + bd.repetition * 0.15 + bd.recency * 0.05)) < 1e-4

    def test_ebbinghaus_decay_drops_over_time(self) -> None:
        """After 7 days, decay should be significantly lower than 1.0."""
        engine = ExplainEngine()
        now_ms = int(time.time() * 1000)
        seven_days_ago = now_ms - (7 * 24 * 60 * 60 * 1000)
        m = _make_memory(accessed_at=seven_days_ago)
        bd = engine.compute(m, now_ms=now_ms)
        assert bd.decay < 0.70, f"Expected decay < 0.70, got {bd.decay}"

    def test_repetition_sigmoid_increases_with_access_count(self) -> None:
        """Higher access_count → higher repetition score."""
        engine = ExplainEngine()
        now = int(time.time() * 1000)
        m_low = _make_memory(access_count=0)
        m_high = _make_memory(access_count=20)
        bd_low = engine.compute(m_low, now_ms=now)
        bd_high = engine.compute(m_high, now_ms=now)
        assert bd_high.repetition > bd_low.repetition

    def test_score_is_deterministic(self) -> None:
        """Same inputs → same output, always."""
        engine = ExplainEngine()
        fixed_now = 1_700_000_000_000
        m = _make_memory(accessed_at=fixed_now, created_at=fixed_now)
        bd1 = engine.compute(m, semantic_score=0.85, now_ms=fixed_now)
        bd2 = engine.compute(m, semantic_score=0.85, now_ms=fixed_now)
        assert bd1.score == bd2.score

    def test_weights_sum(self) -> None:
        """Default weights must sum to exactly 1.0 (TS contract)."""
        from limbicdb.core.explain_engine import (
            WEIGHT_DECAY, WEIGHT_RECENCY, WEIGHT_REPETITION, WEIGHT_SEMANTIC,
        )
        total = WEIGHT_SEMANTIC + WEIGHT_DECAY + WEIGHT_REPETITION + WEIGHT_RECENCY
        assert abs(total - 1.0) < 1e-9, f"Weights sum to {total}, expected 1.0"


# ---------------------------------------------------------------------------
# LimbicDB API
# ---------------------------------------------------------------------------

class TestLimbicDBCore:
    def test_remember_and_recall(self) -> None:
        with _in_memory_db() as db:
            db.remember("User prefers TypeScript over JavaScript")
            result = db.recall("TypeScript")
            assert len(result.memories) >= 1
            assert "TypeScript" in result.memories[0].content

    def test_recall_empty_query_returns_all(self) -> None:
        with _in_memory_db() as db:
            db.remember("Memory A")
            db.remember("Memory B")
            result = db.recall("")
            assert len(result.memories) == 2

    def test_recall_limit_is_respected(self) -> None:
        with _in_memory_db() as db:
            for i in range(10):
                db.remember(f"Memory {i}")
            result = db.recall("Memory", limit=3)
            assert len(result.memories) <= 3

    def test_recall_with_explain(self) -> None:
        with _in_memory_db() as db:
            db.remember("Explanation test memory")
            result = db.recall("test", explain=True)
            assert result.memories[0].explanation is not None
            assert result.memories[0].explanation.score >= 0.0

    def test_forget_removes_memory(self) -> None:
        with _in_memory_db() as db:
            mem = db.remember("I should be forgotten")
            db.forget(mem.id)
            result = db.recall("forgotten")
            assert not any(m.id == mem.id for m in result.memories)

    def test_remember_with_tags(self) -> None:
        with _in_memory_db() as db:
            db.remember("Tagged memory", tags=["important", "ui"])
            result = db.recall("Tagged", tags=["important"])
            assert len(result.memories) >= 1
            assert "important" in result.memories[0].tags

    def test_stats(self) -> None:
        with _in_memory_db() as db:
            db.remember("A")
            db.remember("B")
            stats = db.get_stats()
            assert stats["memoryCount"] == 2

    def test_context_manager(self) -> None:
        with LimbicDB(LimbicDBConfig(storage=MemoryStorageAdapter())) as db:
            db.remember("context manager test")
        assert db._closed is True


# ---------------------------------------------------------------------------
# SQLiteStorageAdapter
# ---------------------------------------------------------------------------

class TestSQLiteStorageAdapter:
    def test_write_and_read_memory(self, tmp_path: pytest.TempPathFactory) -> None:
        db_path = str(tmp_path / "test.limbic")  # type: ignore[operator]
        store = SQLiteStorageAdapter(db_path)
        store.init()

        now = int(time.time() * 1000)
        mem = _make_memory(id="sqlite-test-1", created_at=now, accessed_at=now)
        store.save_memory(mem)

        retrieved = store.get_memory("sqlite-test-1")
        assert retrieved is not None
        assert retrieved.content == mem.content
        assert retrieved.kind == mem.kind
        assert retrieved.tags == mem.tags

        store.close()

    def test_soft_delete(self, tmp_path: pytest.TempPathFactory) -> None:
        db_path = str(tmp_path / "test.limbic")  # type: ignore[operator]
        store = SQLiteStorageAdapter(db_path)
        store.init()

        now = int(time.time() * 1000)
        mem = _make_memory(id="to-delete", created_at=now, accessed_at=now)
        store.save_memory(mem)
        store.delete_memory("to-delete")

        assert store.get_memory("to-delete") is None
        store.close()

    def test_state_kv(self, tmp_path: pytest.TempPathFactory) -> None:
        db_path = str(tmp_path / "state.limbic")  # type: ignore[operator]
        store = SQLiteStorageAdapter(db_path)
        store.init()

        store.set_state("cursor", "abc123", int(time.time() * 1000))
        assert store.get_state("cursor") == "abc123"
        assert "cursor" in store.get_all_state_keys()

        store.delete_state("cursor")
        assert store.get_state("cursor") is None
        store.close()

    def test_upsert_memory(self, tmp_path: pytest.TempPathFactory) -> None:
        db_path = str(tmp_path / "upsert.limbic")  # type: ignore[operator]
        store = SQLiteStorageAdapter(db_path)
        store.init()

        now = int(time.time() * 1000)
        m = _make_memory(id="upsert-1", content="Original", created_at=now, accessed_at=now)
        store.save_memory(m)
        m.content = "Updated"
        m.strength = 0.9
        store.save_memory(m)

        retrieved = store.get_memory("upsert-1")
        assert retrieved is not None
        assert retrieved.content == "Updated"
        assert retrieved.strength == 0.9
        store.close()

    def test_cross_language_file_compatibility(self, tmp_path: pytest.TempPathFactory) -> None:
        """
        Cross-language interoperability test.
        Simulates Node.js writing a memory (by manually creating the SQLite schema
        and inserting a row using the same DDL), then verifies Python reads it
        correctly via SQLiteStorageAdapter.

        In full CI, this would run the real Node.js binary. Here we simulate
        the Node.js write by directly touching the DB at the SQLite level
        with the correct column layout.
        """
        import sqlite3 as _sqlite3
        db_path = str(tmp_path / "interop.limbic")  # type: ignore[operator]

        # Simulate Node.js creating the .limbic file
        conn = _sqlite3.connect(db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY, content TEXT NOT NULL, kind TEXT NOT NULL,
                tags TEXT NOT NULL DEFAULT '[]', meta TEXT NOT NULL DEFAULT '{}',
                strength REAL NOT NULL DEFAULT 0.5, base_strength REAL NOT NULL DEFAULT 0.5,
                created_at INTEGER NOT NULL, accessed_at INTEGER NOT NULL,
                access_count INTEGER NOT NULL DEFAULT 0, expires_at INTEGER, review_at INTEGER,
                is_deleted INTEGER NOT NULL DEFAULT 0, scope TEXT NOT NULL DEFAULT 'session',
                session_id TEXT, project_id TEXT)
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL)
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS timeline (id TEXT PRIMARY KEY, type TEXT NOT NULL,
                action TEXT NOT NULL, ref_key TEXT, content TEXT, timestamp INTEGER NOT NULL,
                hlc TEXT, payload TEXT)
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, name TEXT, created_at INTEGER NOT NULL,
                archived_at INTEGER, memory_count INTEGER NOT NULL DEFAULT 0, meta TEXT NOT NULL DEFAULT '{}')
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS snapshots (id TEXT PRIMARY KEY, created_at INTEGER NOT NULL,
                memory_data TEXT NOT NULL, state_data TEXT NOT NULL, timeline_data TEXT NOT NULL, embeddings_data TEXT)
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memory_embeddings (memory_id TEXT PRIMARY KEY
                REFERENCES memories(id) ON DELETE CASCADE, vector TEXT NOT NULL,
                dimensions INTEGER NOT NULL, model_hint TEXT NOT NULL DEFAULT 'unknown')
        """)
        now = int(time.time() * 1000)
        conn.execute(
            "INSERT INTO memories (id,content,kind,tags,meta,strength,base_strength,created_at,accessed_at,scope) VALUES (?,?,?,?,?,?,?,?,?,?)",
            ("node-written-1", "Written by Node.js simulation", "fact", '["cross-lang"]', '{}', 0.8, 0.8, now, now, "session"),
        )
        conn.commit()
        conn.close()

        # Now Python reads it
        store = SQLiteStorageAdapter(db_path)
        store.init()
        mem = store.get_memory("node-written-1")
        assert mem is not None
        assert mem.content == "Written by Node.js simulation"
        assert mem.kind == MemoryKind.FACT
        assert "cross-lang" in mem.tags
        store.close()


# ---------------------------------------------------------------------------
# MemoryStorageAdapter
# ---------------------------------------------------------------------------

class TestMemoryStorageAdapter:
    def test_basic_crud(self) -> None:
        store = MemoryStorageAdapter()
        store.init()
        now = int(time.time() * 1000)
        mem = _make_memory(created_at=now, accessed_at=now)
        store.save_memory(mem)
        assert store.get_memory("test-1") is not None
        store.delete_memory("test-1")
        assert store.get_memory("test-1") is None

    def test_prune_weak(self) -> None:
        store = MemoryStorageAdapter()
        store.init()
        old = int((time.time() - 86400) * 1000)  # 1 day ago
        mem = _make_memory(strength=0.1, accessed_at=old)
        store.save_memory(mem)
        pruned = store.prune_weak_memories(threshold=0.5, before_time=int(time.time() * 1000))
        assert pruned == 1
        assert store.get_memory("test-1") is None
