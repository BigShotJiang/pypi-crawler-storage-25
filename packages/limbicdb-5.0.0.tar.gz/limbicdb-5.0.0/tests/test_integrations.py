"""
Tests for LangChain and LlamaIndex integrations — Phase 3.

These tests run entirely in-process using MemoryStorageAdapter.
No actual LangChain or LlamaIndex packages required — tests verify the
duck-typing contract that makes LimbicDB adapters compatible.
"""

from __future__ import annotations

import time

from limbicdb import LimbicDB, LimbicDBConfig
from limbicdb.integrations.langchain import LimbicChatMemory, LimbicDocument, LimbicVectorStore
from limbicdb.integrations.llamaindex import (
    LimbicNode,
    LimbicNodeWithScore,
    LimbicQueryEngine,
    LimbicReader,
    LimbicResponse,
)
from limbicdb.storage.memory_adapter import MemoryStorageAdapter
from limbicdb.types import MemoryKind


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fresh_db() -> LimbicDB:
    db = LimbicDB(LimbicDBConfig(storage=MemoryStorageAdapter()))
    return db


# ---------------------------------------------------------------------------
# LimbicChatMemory
# ---------------------------------------------------------------------------

class TestLimbicChatMemory:
    def test_save_and_load_context(self) -> None:
        db = _fresh_db()
        memory = LimbicChatMemory(db=db, session_id="test-session")

        memory.save_context(
            inputs={"input": "What is LimbicDB?"},
            outputs={"text": "LimbicDB is a cognitive memory engine."},
        )

        variables = memory.load_memory_variables()
        history = variables["history"]

        assert "Human:" in history
        assert "What is LimbicDB?" in history
        assert "AI:" in history
        assert "cognitive memory engine" in history

    def test_memory_key_configurable(self) -> None:
        db = _fresh_db()
        memory = LimbicChatMemory(db=db, memory_key="chat_history")
        assert "chat_history" in memory.memory_variables
        variables = memory.load_memory_variables()
        assert "chat_history" in variables

    def test_custom_prefixes(self) -> None:
        db = _fresh_db()
        memory = LimbicChatMemory(db=db, human_prefix="User", ai_prefix="Bot")

        memory.save_context(
            inputs={"input": "Hello"},
            outputs={"text": "Hi!"},
        )
        variables = memory.load_memory_variables()
        history = variables["history"]
        assert "User:" in history
        assert "Bot:" in history

    def test_chronological_order(self) -> None:
        """Older messages should appear before newer ones in history."""
        db = _fresh_db()
        memory = LimbicChatMemory(db=db, session_id="chrono-test")

        memory.save_context({"input": "First message"}, {"text": "First reply"})
        time.sleep(0.01)  # ensure distinct timestamps
        memory.save_context({"input": "Second message"}, {"text": "Second reply"})

        variables = memory.load_memory_variables()
        history = variables["history"]
        first_pos = history.index("First message")
        second_pos = history.index("Second message")
        assert first_pos < second_pos

    def test_clear(self) -> None:
        db = _fresh_db()
        memory = LimbicChatMemory(db=db, session_id="clear-test")
        memory.save_context({"input": "Delete me"}, {"text": "Deleted"})

        # Before clear — should have history
        before = memory.load_memory_variables()["history"]
        assert before.strip() != ""

        memory.clear()

        after = memory.load_memory_variables()["history"]
        assert after.strip() == ""

    def test_context_manager(self) -> None:
        db = _fresh_db()
        with LimbicChatMemory(db=db) as memory:
            memory.save_context({"input": "Test"}, {"text": "Response"})
        # Should not raise after context manager exits


# ---------------------------------------------------------------------------
# LimbicVectorStore
# ---------------------------------------------------------------------------

class TestLimbicVectorStore:
    def test_add_documents_and_search(self) -> None:
        db = _fresh_db()
        store = LimbicVectorStore(db=db)

        # LangChain Document-like objects
        class Doc:
            def __init__(self, text: str, meta: dict | None = None) -> None:
                self.page_content = text
                self.metadata = meta or {}

        ids = store.add_documents([
            Doc("Python is great for AI", {"tags": ["python", "ai"]}),
            Doc("LimbicDB stores agent memories"),
            Doc("TypeScript powers the frontend"),
        ])
        assert len(ids) == 3
        assert all(isinstance(i, str) for i in ids)

        results = store.similarity_search("Python", k=5)
        assert len(results) >= 1
        assert any("Python" in r.page_content for r in results)

    def test_add_texts(self) -> None:
        db = _fresh_db()
        store = LimbicVectorStore(db=db)
        ids = store.add_texts(["Text one", "Text two"])
        assert len(ids) == 2

    def test_similarity_search_with_score(self) -> None:
        db = _fresh_db()
        store = LimbicVectorStore(db=db)
        store.add_texts(["LimbicDB is fast and memory-efficient"])
        results = store.similarity_search_with_score("memory-efficient", k=5)
        assert len(results) >= 1
        doc, score = results[0]
        assert isinstance(doc, LimbicDocument)
        assert isinstance(score, float)
        assert 0.0 <= score <= 1.0

    def test_document_metadata_preserved(self) -> None:
        db = _fresh_db()
        store = LimbicVectorStore(db=db)

        class Doc:
            page_content = "Metadata test"
            metadata = {"author": "alice", "version": "1.0"}

        store.add_documents([Doc()])
        results = store.similarity_search("Metadata", k=1)
        assert len(results) == 1
        assert results[0].metadata.get("author") == "alice"

    def test_as_retriever(self) -> None:
        db = _fresh_db()
        store = LimbicVectorStore(db=db)
        store.add_texts(["Retriever test document"])

        retriever = store.as_retriever(k=3)
        docs = retriever.get_relevant_documents("Retriever test")
        assert isinstance(docs, list)


# ---------------------------------------------------------------------------
# LimbicReader (LlamaIndex)
# ---------------------------------------------------------------------------

class TestLimbicReader:
    def test_load_data_returns_nodes(self) -> None:
        db = _fresh_db()
        db.remember("Memory about cats")
        db.remember("Memory about dogs")

        reader = LimbicReader(db=db)
        nodes = reader.load_data()

        assert len(nodes) == 2
        assert all(isinstance(n, LimbicNode) for n in nodes)
        assert all(n.id_ is not None for n in nodes)
        assert all(n.text is not None for n in nodes)

    def test_node_fields(self) -> None:
        db = _fresh_db()
        db.remember("LimbicDB LlamaIndex node test", tags=["test"])

        reader = LimbicReader(db=db)
        nodes = reader.load_data()
        node = nodes[0]

        assert "LimbicDB" in node.text
        assert isinstance(node.metadata, dict)
        assert "kind" in node.metadata
        assert "strength" in node.metadata

    def test_node_get_content(self) -> None:
        db = _fresh_db()
        db.remember("Content method test")
        reader = LimbicReader(db=db)
        nodes = reader.load_data()
        assert nodes[0].get_content() == "Content method test"

    def test_filter_by_kind(self) -> None:
        db = _fresh_db()
        db.remember("Fact memory", kind=MemoryKind.FACT)
        db.remember("Episode memory", kind=MemoryKind.EPISODE)

        reader = LimbicReader(db=db, filter={"kind": "fact"})
        nodes = reader.load_data()
        assert all(n.metadata["kind"] == "fact" for n in nodes)


# ---------------------------------------------------------------------------
# LimbicQueryEngine (LlamaIndex)
# ---------------------------------------------------------------------------

class TestLimbicQueryEngine:
    def test_query_returns_response(self) -> None:
        db = _fresh_db()
        db.remember("LimbicDB supports Python and TypeScript")
        db.remember("The team loves clean architecture")

        engine = LimbicQueryEngine(db=db, top_k=5)
        response = engine.query("Python support")

        assert isinstance(response, LimbicResponse)
        assert isinstance(response.response, str)
        assert isinstance(response.source_nodes, list)

    def test_source_nodes_have_scores(self) -> None:
        db = _fresh_db()
        db.remember("Score test memory")

        engine = LimbicQueryEngine(db=db, top_k=3)
        response = engine.query("score test")

        if response.source_nodes:
            node_with_score = response.source_nodes[0]
            assert isinstance(node_with_score, LimbicNodeWithScore)
            assert isinstance(node_with_score.score, float)

    def test_synthesise_true(self) -> None:
        db = _fresh_db()
        db.remember("Synthesis A")
        db.remember("Synthesis B")

        engine = LimbicQueryEngine(db=db, synthesise=True)
        response = engine.query("Synthesis")
        assert "1]" in response.response  # numbered list format

    def test_synthesise_false(self) -> None:
        db = _fresh_db()
        db.remember("No synthesis test")

        engine = LimbicQueryEngine(db=db, synthesise=False)
        response = engine.query("synthesis")
        assert response.response == ""

    def test_query_bundle_compat(self) -> None:
        """Accept objects with .query attribute (LlamaIndex QueryBundle)."""
        db = _fresh_db()
        db.remember("QueryBundle compat test")

        engine = LimbicQueryEngine(db=db)

        class QueryBundle:
            query = "QueryBundle"

        response = engine.query(QueryBundle())
        assert isinstance(response, LimbicResponse)

    def test_as_retriever(self) -> None:
        db = _fresh_db()
        db.remember("Retriever test")

        engine = LimbicQueryEngine(db=db)
        retriever = engine.as_retriever()
        nodes = retriever.retrieve("test")
        assert isinstance(nodes, list)
