"""Pytest configuration for LimbicDB Python SDK tests."""

import pytest


# pytest-asyncio global mode is set in pyproject.toml (asyncio_mode = "auto")
# This conftest.py is kept minimal — add shared fixtures here as needed.
