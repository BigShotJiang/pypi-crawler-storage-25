"""
LimbicDB Python SDK
===================

Production-grade AI memory infrastructure.
Provides full feature parity with the TypeScript/Node.js core.

Quick start::

    from limbicdb import open as ldb_open

    db = ldb_open("./agent.limbic")
    db.remember("User prefers dark mode")
    result = db.recall("UI preferences")
    print(result.memories[0].content)
    db.close()

With explanations::

    result = db.recall("UI preferences", explain=True)
    print(result.memories[0].explanation)

PostgreSQL backend::

    from limbicdb.storage.postgres_store import PostgresStore
    from limbicdb import LimbicDB

    store = PostgresStore(connection_string="postgres://...")
    store.init()
    db = LimbicDB(storage=store)
"""

from limbicdb.core.limbicdb import LimbicDB, LimbicDBConfig, RecallResult
from limbicdb.open import open

__all__ = ["LimbicDB", "LimbicDBConfig", "RecallResult", "open"]
__version__ = "4.0.0-beta.2"
