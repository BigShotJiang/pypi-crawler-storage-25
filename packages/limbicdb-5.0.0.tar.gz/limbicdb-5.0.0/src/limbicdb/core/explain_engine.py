"""
ExplainEngine — Deterministic cognitive score calculator.

This is a **byte-for-byte faithful port** of ``src/core/explain-engine.ts``.
Both implementations MUST produce identical scores (to 4 decimal places) for
the same memory/query pair, ensuring cross-language interoperability.

Score formula (Ebbinghaus + Pimsleur/ACT-R + recency):
  score = Σ (component_score × component_weight)

Weights (must match TypeScript DEFAULT_WEIGHTS):
  semantic    : 0.50
  decay       : 0.30
  repetition  : 0.15
  recency     : 0.05
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

from limbicdb.types import CognitiveScoreBreakdown, Memory

# ---------------------------------------------------------------------------
# Weight constants — MUST stay in sync with TypeScript explain-engine.ts
# ---------------------------------------------------------------------------

WEIGHT_SEMANTIC = 0.50
WEIGHT_DECAY = 0.30
WEIGHT_REPETITION = 0.15
WEIGHT_RECENCY = 0.05

# Psychological forgetting curve parameters
EBBINGHAUS_STABILITY = 1.0        # baseline stability (days)
MAX_DECAY_DAYS = 30.0             # after this, decay bottoms out
MIN_DECAY_SCORE = 0.05            # minimum decay score (never forget completely)

# ACT-R / Pimsleur spaced repetition sigmoid
REPETITION_SATURATION = 10        # access count where repetition bonus saturates


@dataclass
class ExplainEngineConfig:
    """Configuration for the cognitive scoring engine."""

    weight_semantic: float = WEIGHT_SEMANTIC
    weight_decay: float = WEIGHT_DECAY
    weight_repetition: float = WEIGHT_REPETITION
    weight_recency: float = WEIGHT_RECENCY
    now_ms: int = field(default_factory=lambda: int(time.time() * 1000))


class ExplainEngine:
    """
    Deterministic, pure-math cognitive score explainer.

    Usage::

        engine = ExplainEngine()
        breakdown = engine.compute(memory, semantic_score=0.85)
        print(breakdown.score)   # e.g. 0.7812
    """

    def __init__(self, config: ExplainEngineConfig | None = None) -> None:
        self.config = config or ExplainEngineConfig()

    def compute(
        self,
        memory: Memory,
        semantic_score: float = 0.0,
        *,
        now_ms: int | None = None,
    ) -> CognitiveScoreBreakdown:
        """Compute the full cognitive score breakdown for a memory.

        Args:
            memory: The memory to score.
            semantic_score: Cosine similarity from the embedding layer (0–1).
                            Pass 0.0 for keyword-only recall.
            now_ms: Override the current time (for testing). Defaults to ``time.time()``.

        Returns:
            A :class:`CognitiveScoreBreakdown` with per-component scores.
        """
        ts_now = now_ms if now_ms is not None else self.config.now_ms

        decay = self._ebbinghaus_decay(memory, ts_now)
        repetition = self._pimsleur_repetition(memory)
        recency = self._recency(memory, ts_now)

        score = (
            semantic_score * self.config.weight_semantic
            + decay * self.config.weight_decay
            + repetition * self.config.weight_repetition
            + recency * self.config.weight_recency
        )

        return CognitiveScoreBreakdown(
            score=round(score, 6),
            semantic=semantic_score,
            semantic_weight=self.config.weight_semantic,
            decay=decay,
            decay_weight=self.config.weight_decay,
            repetition=repetition,
            repetition_weight=self.config.weight_repetition,
            recency=recency,
            recency_weight=self.config.weight_recency,
        )

    # ------------------------------------------------------------------
    # Component functions — keep deterministic and match TypeScript exactly
    # ------------------------------------------------------------------

    @staticmethod
    def _ebbinghaus_decay(memory: Memory, now_ms: int) -> float:
        """Forgetting curve: R = e^(-t/S)

        t = elapsed time in days since last access
        S = stability (proportional to base_strength)
        """
        elapsed_ms = max(0, now_ms - memory.accessed_at)
        elapsed_days = elapsed_ms / (1000 * 60 * 60 * 24)

        stability = EBBINGHAUS_STABILITY * (1.0 + memory.base_strength)
        t_clamped = min(elapsed_days, MAX_DECAY_DAYS)

        decay = math.exp(-t_clamped / stability)
        return max(MIN_DECAY_SCORE, round(decay, 6))

    @staticmethod
    def _pimsleur_repetition(memory: Memory) -> float:
        """Spaced-repetition bonus using a sigmoid over access_count."""
        n = memory.access_count
        # Sigmoid: 1 / (1 + e^(-(n - half_saturation)))
        half = REPETITION_SATURATION / 2
        score = 1.0 / (1.0 + math.exp(-(n - half)))
        return round(score, 6)

    @staticmethod
    def _recency(memory: Memory, now_ms: int) -> float:
        """Recency bonus: more recent creation → higher score."""
        elapsed_ms = max(0, now_ms - memory.created_at)
        elapsed_days = elapsed_ms / (1000 * 60 * 60 * 24)
        # Decay over 7 days (week-scale freshness)
        score = math.exp(-elapsed_days / 7.0)
        return round(max(0.0, score), 6)
