"""Core package init — exposes LimbicDB and config types."""

from limbicdb.core.explain_engine import ExplainEngine, ExplainEngineConfig
from limbicdb.core.limbicdb import LimbicDB, LimbicDBConfig, RecallResult

__all__ = ["ExplainEngine", "ExplainEngineConfig", "LimbicDB", "LimbicDBConfig", "RecallResult"]
