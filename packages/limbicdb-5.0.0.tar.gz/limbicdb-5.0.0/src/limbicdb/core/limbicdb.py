"""
LimbicDB — top-level API.

This is the Python equivalent of ``src/core/limbicdb.ts``.
The public API surface is designed to be idiomatic Python while mirroring
the TypeScript API 1-to-1 in terms of semantics.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from limbicdb.core.explain_engine import ExplainEngine
from limbicdb.storage.interface import IStorage
from limbicdb.storage.sqlite_adapter import SQLiteStorageAdapter
from limbicdb.types import (
    CognitiveScoreBreakdown,
    Memory,
    MemoryKind,
    MemoryScope,
    TimelineEvent,
    TimelineType,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class LimbicDBConfig:
    """Configuration for a LimbicDB instance.

    Mirrors the TypeScript ``LimbicDBConfig`` interface.
    """

    #: Path to the .limbic SQLite file, or a storage adapter instance.
    path: str | None = None
    #: Pre-built storage adapter (overrides ``path`` if provided).
    storage: IStorage | None = None
    #: Optional namespace for physical data isolation (SHA-256 derived path).
    namespace: str | None = None
    #: Default session ID used when none is explicitly passed to ``remember()``.
    session_id: str | None = None
    #: Default project ID.
    project_id: str | None = None
    #: Maximum items returned by recall(). Hard cap: 100.
    max_recall: int = 20


# ---------------------------------------------------------------------------
# Recall result
# ---------------------------------------------------------------------------

@dataclass
class RecalledMemory:
    """A single memory returned by recall(), optionally with an explanation."""

    id: str
    content: str
    kind: MemoryKind
    tags: list[str]
    meta: dict[str, Any]
    strength: float
    created_at: int
    accessed_at: int
    access_count: int
    scope: MemoryScope
    session_id: str | None = None
    project_id: str | None = None
    explanation: CognitiveScoreBreakdown | None = None


@dataclass
class RecallResult:
    """The result of a recall() call."""

    memories: list[RecalledMemory]
    meta: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# LimbicDB core class
# ---------------------------------------------------------------------------

class LimbicDB:
    """
    Production-grade AI memory infrastructure — Python SDK.

    Usage::

        from limbicdb import open as ldb_open

        db = ldb_open("./agent.limbic")
        db.remember("User prefers dark mode")
        result = db.recall("UI preferences")
        db.close()

    Or with a custom adapter::

        from limbicdb import LimbicDB, LimbicDBConfig
        from limbicdb.storage.sqlite_adapter import SQLiteStorageAdapter

        store = SQLiteStorageAdapter("./agent.limbic")
        db = LimbicDB(LimbicDBConfig(storage=store))
    """

    def __init__(self, config: LimbicDBConfig | None = None) -> None:
        self._cfg = config or LimbicDBConfig()
        self._engine = ExplainEngine()
        self._storage: IStorage = self._build_storage()
        self._storage.init()
        self._closed = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release all resources."""
        if not self._closed:
            self._storage.close()
            self._closed = True

    def __enter__(self) -> LimbicDB:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def remember(
        self,
        content: str,
        *,
        kind: MemoryKind = MemoryKind.FACT,
        tags: list[str] | None = None,
        meta: dict[str, Any] | None = None,
        strength: float = 0.5,
        scope: MemoryScope = MemoryScope.SESSION,
        session_id: str | None = None,
        project_id: str | None = None,
        memory_id: str | None = None,
    ) -> Memory:
        """Store a new memory.

        Args:
            content:    The natural-language text to remember.
            kind:       Cognitive classification.
            tags:       Optional list of tag strings for filtering.
            meta:       Arbitrary JSON-serialisable metadata.
            strength:   Initial memory strength (0.0–1.0).
            scope:      Isolation scope.
            session_id: Override the default session ID.
            project_id: Override the default project ID.
            memory_id:  Explicit ID (auto-generated UUID if omitted).

        Returns:
            The :class:`Memory` that was stored.
        """
        now = int(time.time() * 1000)
        memory = Memory(
            id=memory_id or str(uuid.uuid4()),
            content=content,
            kind=kind,
            tags=tags or [],
            meta=meta or {},
            strength=strength,
            base_strength=strength,
            created_at=now,
            accessed_at=now,
            access_count=0,
            scope=scope,
            session_id=session_id or self._cfg.session_id,
            project_id=project_id or self._cfg.project_id,
        )
        self._storage.save_memory(memory)

        # Log to timeline
        self._storage.log_event(TimelineEvent(
            id=str(uuid.uuid4()),
            type=TimelineType.MEMORY,
            action="create",
            ref_key=memory.id,
            timestamp=now,
        ))

        return memory

    def recall(
        self,
        query: str,
        *,
        limit: int | None = None,
        min_strength: float | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        since: int | None = None,
        session_id: str | None = None,
        explain: bool = False,
    ) -> RecallResult:
        """Recall memories matching the query.

        Args:
            query:        Natural-language search string.
            limit:        Maximum number of results (default: ``config.max_recall``).
            min_strength: Minimum memory strength filter.
            kind:         Filter by memory kind(s).
            tags:         Filter by tags (all must be present).
            since:        Filter to memories created after this timestamp (Unix ms).
            session_id:   Filter by session.
            explain:      If True, attach a :class:`CognitiveScoreBreakdown` to each result.

        Returns:
            A :class:`RecallResult` with a ranked list of memories.
        """
        n = min(limit or self._cfg.max_recall, 100)

        raw = self._storage.search_memories(
            query,
            limit=n,
            min_strength=min_strength,
            kind=kind,
            tags=tags,
            since=since,
            session_id=session_id or self._cfg.session_id,
        )

        now_ms = int(time.time() * 1000)
        recalled: list[RecalledMemory] = []

        for m in raw:
            breakdown = self._engine.compute(m, now_ms=now_ms) if explain else None

            # Update access stats
            decay_score = self._engine._ebbinghaus_decay(m, now_ms)
            new_strength = round(
                m.strength * 0.95 + decay_score * 0.05, 6
            )
            self._storage.update_memory_access(m.id, now_ms, new_strength)

            recalled.append(RecalledMemory(
                id=m.id,
                content=m.content,
                kind=m.kind,
                tags=m.tags,
                meta=m.meta,
                strength=new_strength,
                created_at=m.created_at,
                accessed_at=now_ms,
                access_count=m.access_count + 1,
                scope=m.scope,
                session_id=m.session_id,
                project_id=m.project_id,
                explanation=breakdown,
            ))

        return RecallResult(
            memories=recalled,
            meta={
                "query": query,
                "count": len(recalled),
                "executed_mode": "keyword",
            },
        )

    def forget(self, memory_id: str) -> None:
        """Soft-delete a memory by ID."""
        self._storage.delete_memory(memory_id)

    def get_stats(self) -> dict[str, Any]:
        """Return storage statistics."""
        return self._storage.get_stats()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_storage(self) -> IStorage:
        if self._cfg.storage is not None:
            return self._cfg.storage
        if self._cfg.path is not None:
            return SQLiteStorageAdapter(self._cfg.path)
        # Default: volatile in-memory (import lazily to avoid circular)
        from limbicdb.storage.memory_adapter import MemoryStorageAdapter
        return MemoryStorageAdapter()
