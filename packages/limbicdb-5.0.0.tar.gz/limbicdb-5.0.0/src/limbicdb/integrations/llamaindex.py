"""
LimbicDB × LlamaIndex Integration — Python SDK.

Exposes LimbicDB as two canonical LlamaIndex interfaces:

1. **LimbicReader** — BaseReader-compatible adapter.
   Loads LimbicDB memories as LlamaIndex TextNodes.
   Use it to bootstrap a VectorStoreIndex from an agent's persistent memory.

2. **LimbicQueryEngine** — Query engine backed by LimbicDB cognitive recall.
   Wraps LimbicDB recall into the LlamaIndex query-engine contract.

Zero-dependency design:
  ``llama-index-core`` is a PEER dependency — install with::

      pip install "limbicdb[llamaindex]"

  This file uses duck typing — LlamaIndex types are never imported at module
  load time. LimbicDB stays lean.

Usage::

    from limbicdb.integrations.llamaindex import LimbicReader, LimbicQueryEngine

    reader = LimbicReader(path="./agent.limbic")
    nodes = reader.load_data()
    print(nodes[0].text)

    engine = LimbicQueryEngine(path="./agent.limbic")
    response = engine.query("What are the user's UI preferences?")
    print(response.response)
    print(response.source_nodes)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from limbicdb import LimbicDB
from limbicdb.open import open as ldb_open
from limbicdb.types import MemoryKind

# ---------------------------------------------------------------------------
# Duck-typed LlamaIndex-compatible node types
# ---------------------------------------------------------------------------

@dataclass
class LimbicNode:
    """
    A LlamaIndex ``TextNode``-compatible object backed by a LimbicDB Memory.

    Attributes:
        id_:       Node ID (same as the LimbicDB memory ID).
        text:      The memory content (same as ``page_content``).
        metadata:  Structured metadata matching the LimbicDB memory fields.
        score:     Optional recall score (set during retrieval).
        embedding: Optional embedding vector (if stored).
    """

    id_: str
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float | None = None
    embedding: list[float] | None = None

    def get_content(self, metadata_mode: str = "none") -> str:  # noqa: ARG002
        """LlamaIndex BaseNode interface compatibility."""
        return self.text

    def get_embedding(self) -> list[float] | None:
        return self.embedding


@dataclass
class LimbicNodeWithScore:
    """LlamaIndex NodeWithScore-compatible wrapper."""

    node: LimbicNode
    score: float = 0.0


@dataclass
class LimbicResponse:
    """LlamaIndex Response-compatible object."""

    response: str
    source_nodes: list[LimbicNodeWithScore] = field(default_factory=list)

    def __str__(self) -> str:
        return self.response


# ---------------------------------------------------------------------------
# LimbicReader
# ---------------------------------------------------------------------------

class LimbicReader:
    """
    LlamaIndex ``BaseReader``-compatible adapter.

    Loads LimbicDB memories as LlamaIndex ``TextNode``-compatible objects
    so they can be indexed in a LlamaIndex ``VectorStoreIndex``::

        reader = LimbicReader(path="./agent.limbic")
        nodes = reader.load_data()

        # Use with LlamaIndex VectorStoreIndex
        from llama_index.core import VectorStoreIndex
        index = VectorStoreIndex(nodes)

    Args:
        path:       Path to the ``.limbic`` file.
        db:         Pre-built LimbicDB (overrides ``path``).
        filter:     Optional filter dict (``kind``, ``tags``, ``scope``, ``session_id``).
    """

    def __init__(
        self,
        path: str | None = None,
        *,
        db: LimbicDB | None = None,
        filter: dict[str, Any] | None = None,  # noqa: A002
    ) -> None:
        if db is not None:
            self._db: LimbicDB | None = db
        elif path is not None:
            self._db = ldb_open(path)
        else:
            raise ValueError("Either 'path' or 'db' must be provided.")

        self._filter = filter or {}

    def load_data(self, **kwargs: Any) -> list[LimbicNode]:  # noqa: ARG002
        """
        Load all matching memories as LlamaIndex-compatible nodes.

        Returns:
            A list of :class:`LimbicNode` objects ready for indexing.
        """
        if self._db is None:
            return []

        kind_val = self._filter.get("kind")
        kind = MemoryKind(kind_val) if kind_val else None
        tags = self._filter.get("tags")
        session_id = self._filter.get("session_id")

        result = self._db.recall(
            "",
            limit=100,
            kind=kind,
            tags=tags,
            session_id=session_id,
        )

        return [self._to_node(m) for m in result.memories]

    def close(self) -> None:
        if self._db is not None:
            self._db.close()
            self._db = None

    def _to_node(self, memory: Any) -> LimbicNode:
        return LimbicNode(
            id_=memory.id,
            text=memory.content,
            metadata={
                "kind": memory.kind.value,
                "tags": memory.tags,
                "strength": memory.strength,
                "created_at": memory.created_at,
                "accessed_at": memory.accessed_at,
                "scope": memory.scope.value,
                "session_id": memory.session_id,
                **memory.meta,
            },
            score=memory.strength,
        )


# ---------------------------------------------------------------------------
# LimbicQueryEngine
# ---------------------------------------------------------------------------

class LimbicQueryEngine:
    """
    LlamaIndex ``QueryEngine``-compatible adapter.

    Wraps LimbicDB's cognitive recall into a LlamaIndex query-engine::

        engine = LimbicQueryEngine(path="./agent.limbic")
        response = engine.query("UI preferences")
        print(response.response)       # synthesised answer string
        print(response.source_nodes)   # list of LimbicNodeWithScore

    Args:
        path:        Path to the ``.limbic`` file.
        db:          Pre-built LimbicDB (overrides ``path``).
        top_k:       Number of memories to retrieve per query. Default: ``5``.
        synthesise:  If True, concatenate source node texts as the response.
                     Set to False to get ``None`` response and inspect source_nodes
                     directly (useful when feeding into an LLM separately).
    """

    def __init__(
        self,
        path: str | None = None,
        *,
        db: LimbicDB | None = None,
        top_k: int = 5,
        synthesise: bool = True,
    ) -> None:
        if db is not None:
            self._db: LimbicDB | None = db
        elif path is not None:
            self._db = ldb_open(path)
        else:
            raise ValueError("Either 'path' or 'db' must be provided.")

        self._top_k = top_k
        self._synthesise = synthesise

    def query(self, query: str | Any, **kwargs: Any) -> LimbicResponse:
        """
        Query the memory store.

        Accepts either a plain string or a LlamaIndex ``QueryBundle``
        (or any object with a ``.query`` attribute).

        Returns:
            A :class:`LimbicResponse` with ``response`` text and ``source_nodes``.
        """
        if self._db is None:
            return LimbicResponse(response="", source_nodes=[])

        # Support LlamaIndex QueryBundle (duck typing)
        query_str = query if isinstance(query, str) else getattr(query, "query", str(query))

        result = self._db.recall(query_str, limit=self._top_k, explain=True)

        source_nodes = [
            LimbicNodeWithScore(
                node=LimbicNode(
                    id_=m.id,
                    text=m.content,
                    metadata={
                        "kind": m.kind.value,
                        "tags": m.tags,
                        "strength": m.strength,
                        "scope": m.scope.value,
                        **m.meta,
                    },
                    score=m.explanation.score if m.explanation else m.strength,
                ),
                score=m.explanation.score if m.explanation else m.strength,
            )
            for m in result.memories
        ]

        if self._synthesise:
            response_text = "\n\n".join(
                f"[{i+1}] {n.node.text}" for i, n in enumerate(source_nodes)
            )
        else:
            response_text = ""

        return LimbicResponse(response=response_text, source_nodes=source_nodes)

    def as_retriever(self) -> LimbicRetriever:
        """Return a LlamaIndex-compatible retriever."""
        return LimbicRetriever(engine=self)

    def close(self) -> None:
        if self._db is not None:
            self._db.close()
            self._db = None


class LimbicRetriever:
    """A minimal LlamaIndex ``BaseRetriever``-compatible object."""

    def __init__(self, engine: LimbicQueryEngine) -> None:
        self._engine = engine

    def retrieve(self, query: str | Any) -> list[LimbicNodeWithScore]:
        """Retrieve relevant nodes for the query."""
        response = self._engine.query(query)
        return response.source_nodes

    async def aretrieve(self, query: str | Any) -> list[LimbicNodeWithScore]:
        """Async retrieval (delegates to sync)."""
        return self.retrieve(query)
