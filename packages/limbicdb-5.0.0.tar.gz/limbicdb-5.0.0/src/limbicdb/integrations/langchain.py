"""
LimbicDB × LangChain Integration — Python SDK.

Exposes LimbicDB as two canonical LangChain interfaces:

1. **LimbicChatMemory** — BaseMemory-compatible adapter for ConversationChain.
   Stores chat history (Human + AI messages) directly in LimbicDB with
   automatic persistence, Ebbinghaus decay, and cross-session continuity.

2. **LimbicVectorStore** — VectorStore-compatible adapter for RAG chains.
   Delegates retrieval to LimbicDB's cognitive recall engine.
   Bridges LangChain Documents ↔ LimbicDB Memories.

Zero-dependency design:
  ``langchain-core`` is a PEER dependency — install with::

      pip install "limbicdb[langchain]"

  This file uses duck typing — LangChain types are only imported at
  runtime and never at module load time, so LimbicDB itself stays lean.

Usage::

    from limbicdb.integrations.langchain import LimbicChatMemory, LimbicVectorStore
    from langchain.chains import ConversationChain
    from langchain_openai import ChatOpenAI

    memory = LimbicChatMemory(path="./agent.limbic", session_id="user-42")
    chain = ConversationChain(llm=ChatOpenAI(), memory=memory)
    response = chain.invoke({"input": "Hello, my name is Alice"})
"""

from __future__ import annotations

from typing import Any

from limbicdb import LimbicDB, LimbicDBConfig
from limbicdb.open import open as ldb_open
from limbicdb.types import MemoryKind, MemoryScope

# ---------------------------------------------------------------------------
# LimbicChatMemory
# ---------------------------------------------------------------------------

class LimbicChatMemory:
    """
    LangChain ``BaseMemory``-compatible adapter that persists chat history
    in LimbicDB.

    Drop-in replacement for ``ConversationBufferMemory``::

        memory = LimbicChatMemory(path="./chat.limbic", session_id="alice")
        chain = ConversationChain(llm=llm, memory=memory)

    Args:
        path:         Path to the ``.limbic`` file or a :class:`LimbicDBConfig`.
        session_id:   Session ID used to scope memories (recommended).
        memory_key:   LangChain memory key. Defaults to ``"history"``.
        human_prefix: Prefix for human turns. Defaults to ``"Human"``.
        ai_prefix:    Prefix for AI turns. Defaults to ``"AI"``.
        max_history:  Max turns loaded into context. Defaults to ``10``.
    """

    def __init__(
        self,
        path: str | LimbicDBConfig | None = None,
        *,
        db: LimbicDB | None = None,
        session_id: str | None = None,
        memory_key: str = "history",
        human_prefix: str = "Human",
        ai_prefix: str = "AI",
        max_history: int = 10,
    ) -> None:
        if db is not None:
            self._db: LimbicDB | None = db
        elif path is not None:
            if isinstance(path, str):
                self._db = ldb_open(path)
            else:
                self._db = LimbicDB(path)
        else:
            raise ValueError("Either 'path' or 'db' must be provided.")

        self.session_id = session_id
        self.memory_key = memory_key
        self.human_prefix = human_prefix
        self.ai_prefix = ai_prefix
        self.max_history = max_history

    # ── LangChain BaseMemory interface ──────────────────────────────────────

    @property
    def memory_variables(self) -> list[str]:
        """LangChain-required: the list of memory variable keys."""
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Load chat history for the current session.

        Called by LangChain before each chain invocation.

        Returns:
            A dict with ``{memory_key: "<dialog history as text>"}``
        """
        if self._db is None:
            return {self.memory_key: ""}

        result = self._db.recall(
            "",
            limit=self.max_history * 2,  # 2 memories per turn (human + AI)
            kind=MemoryKind.EPISODE,
            session_id=self.session_id,
        )

        # Reconstruct dialog in chronological order (oldest first)
        sorted_memories = sorted(result.memories, key=lambda m: m.created_at)
        history = "\n".join(m.content for m in sorted_memories)
        return {self.memory_key: history}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, Any]) -> None:
        """
        Save a new exchange to LimbicDB.

        Called by LangChain after each chain invocation.
        """
        if self._db is None:
            return

        input_key = next(iter(inputs), "input")
        output_key = next(iter(outputs), "text")
        human_text = str(inputs.get(input_key, ""))
        ai_text = str(
            outputs.get("response")
            or outputs.get("text")
            or outputs.get(output_key)
            or ""
        )

        import time
        now = int(time.time() * 1000)

        if human_text.strip():
            self._db.remember(
                f"{self.human_prefix}: {human_text}",
                kind=MemoryKind.EPISODE,
                scope=MemoryScope.SESSION,
                session_id=self.session_id,
                strength=0.6,
                meta={"role": "human", "turn": str(now)},
            )

        if ai_text.strip():
            self._db.remember(
                f"{self.ai_prefix}: {ai_text}",
                kind=MemoryKind.EPISODE,
                scope=MemoryScope.SESSION,
                session_id=self.session_id,
                strength=0.5,
                meta={"role": "ai", "turn": str(now)},
            )

    def clear(self) -> None:
        """Clear all episode memories for the current session."""
        if self._db is None:
            return
        if self.session_id:
            memories = self._db.recall("", session_id=self.session_id, limit=100)
            for m in memories.memories:
                if m.kind == MemoryKind.EPISODE:
                    self._db.forget(m.id)

    def close(self) -> None:
        """Release the underlying LimbicDB instance."""
        if self._db is not None:
            self._db.close()
            self._db = None

    def __enter__(self) -> LimbicChatMemory:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# LimbicDocument — LangChain-compatible document type
# ---------------------------------------------------------------------------

class LimbicDocument:
    """A LangChain-compatible Document backed by a LimbicDB Memory."""

    def __init__(self, page_content: str, metadata: dict[str, Any] | None = None) -> None:
        self.page_content = page_content
        self.metadata: dict[str, Any] = metadata or {}

    def __repr__(self) -> str:
        preview = self.page_content[:60]
        return f"LimbicDocument(page_content={preview!r}...)"


# ---------------------------------------------------------------------------
# LimbicVectorStore
# ---------------------------------------------------------------------------

class LimbicVectorStore:
    """
    LangChain ``VectorStore``-compatible adapter backed by LimbicDB.

    Can be used as a retriever in any RAG (retrieval-augmented generation) chain::

        store = LimbicVectorStore(path="./memory.limbic")
        store.add_documents([Document(page_content="LimbicDB is fast")])
        retriever = store.as_retriever(k=5)

        # In a chain:
        chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)

    Args:
        path:        Path to the ``.limbic`` file.
        db:          Pre-built LimbicDB instance (overrides ``path``).
        recall_mode: ``"keyword"`` (default), ``"semantic"``, or ``"hybrid"``.
    """

    def __init__(
        self,
        path: str | None = None,
        *,
        db: LimbicDB | None = None,
        recall_mode: str = "keyword",
    ) -> None:
        if db is not None:
            self._db: LimbicDB | None = db
        elif path is not None:
            self._db = ldb_open(path)
        else:
            raise ValueError("Either 'path' or 'db' must be provided.")
        self._recall_mode = recall_mode

    # ── LangChain VectorStore interface ─────────────────────────────────────

    def add_documents(self, documents: list[Any], **kwargs: Any) -> list[str]:
        """
        Add LangChain ``Document`` objects to the vector store.

        Accepts both LangChain ``Document`` instances (with ``.page_content``)
        and plain dicts ``{"page_content": ..., "metadata": ...}``.

        Returns:
            A list of LimbicDB memory IDs for the stored documents.
        """
        if self._db is None:
            return []

        ids: list[str] = []
        for doc in documents:
            if isinstance(doc, dict):
                page_content = doc.get("page_content", "")
                metadata: dict[str, Any] = doc.get("metadata", {})
            else:
                page_content = getattr(doc, "page_content", "")
                metadata = getattr(doc, "metadata", {}) or {}

            memory = self._db.remember(
                page_content,
                kind=MemoryKind.FACT,
                scope=MemoryScope.CORE,
                tags=metadata.get("tags", []),
                meta=metadata,
                strength=float(metadata.get("strength", 0.7)),
            )
            ids.append(memory.id)

        return ids

    def add_texts(self, texts: list[str], metadatas: list[dict[str, Any]] | None = None, **kwargs: Any) -> list[str]:
        """Add plain text strings as documents."""
        metadatas = metadatas or [{} for _ in texts]
        docs = [{"page_content": t, "metadata": m} for t, m in zip(texts, metadatas, strict=False)]
        return self.add_documents(docs)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: dict[str, Any] | None = None,  # noqa: A002
    ) -> list[LimbicDocument]:
        """
        Return the k most relevant documents for the query.

        Args:
            query:  The search query.
            k:      Number of results to return.
            filter: Optional filter dict (supports ``kind``, ``tags`` keys).

        Returns:
            A list of :class:`LimbicDocument` objects.
        """
        if self._db is None:
            return []

        filter = filter or {}
        kind_val = filter.get("kind")
        kind = MemoryKind(kind_val) if kind_val else None
        tags = filter.get("tags")

        result = self._db.recall(query, limit=k, kind=kind, tags=tags)
        return [self._to_document(m) for m in result.memories]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: dict[str, Any] | None = None,  # noqa: A002
    ) -> list[tuple[LimbicDocument, float]]:
        """Return documents with their cognitive scores."""
        if self._db is None:
            return []

        filter = filter or {}
        kind_val = filter.get("kind")
        kind = MemoryKind(kind_val) if kind_val else None
        tags = filter.get("tags")

        result = self._db.recall(query, limit=k, kind=kind, tags=tags, explain=True)
        return [
            (self._to_document(m), m.explanation.score if m.explanation else m.strength)
            for m in result.memories
        ]

    def as_retriever(self, k: int = 4, filter: dict[str, Any] | None = None) -> LimbicRetriever:  # noqa: A002
        """Return a LangChain-compatible retriever object."""
        return LimbicRetriever(store=self, k=k, filter=filter or {})

    def close(self) -> None:
        if self._db is not None:
            self._db.close()
            self._db = None

    def _to_document(self, memory: Any) -> LimbicDocument:
        return LimbicDocument(
            page_content=memory.content,
            metadata={
                "id": memory.id,
                "kind": memory.kind.value,
                "tags": memory.tags,
                "strength": memory.strength,
                "created_at": memory.created_at,
                "scope": memory.scope.value,
                "session_id": memory.session_id,
                **memory.meta,
            },
        )


class LimbicRetriever:
    """A minimal LangChain BaseRetriever-compatible object."""

    def __init__(self, store: LimbicVectorStore, k: int = 4, filter: dict[str, Any] | None = None) -> None:  # noqa: A002
        self._store = store
        self._k = k
        self._filter = filter or {}

    def get_relevant_documents(self, query: str) -> list[LimbicDocument]:
        """Synchronous retrieval — compatible with LangChain chains."""
        return self._store.similarity_search(query, k=self._k, filter=self._filter)

    async def aget_relevant_documents(self, query: str) -> list[LimbicDocument]:
        """Async retrieval — compatible with async LangChain chains."""
        return self.get_relevant_documents(query)
