"""
SQLite Storage Adapter for LimbicDB Python SDK.

Reads and writes the same .limbic SQLite database format as the TypeScript
SQLiteStorageAdapter. Cross-language interoperability is guaranteed by:

  1. Identical table names and column layout
  2. JSON-serialised tags/meta columns (matching TypeScript JSON.stringify)
  3. Identical timestamp representation (Unix milliseconds, BIGINT)
  4. Identical soft-delete convention (is_deleted column)

This adapter uses the stdlib ``sqlite3`` module (synchronous) for zero extra
dependencies. An async wrapper (``AsyncSQLiteAdapter``) using ``aiosqlite``
is available in ``sqlite_adapter_async.py`` for FastAPI / async usage.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from limbicdb.types import Memory, MemoryKind, MemoryScope, Session, TimelineEvent, TimelineType

# ---------------------------------------------------------------------------
# Schema DDL — must match src/storage/sqlite-store.ts exactly
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA busy_timeout=5000;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS memories (
    id           TEXT    PRIMARY KEY,
    content      TEXT    NOT NULL,
    kind         TEXT    NOT NULL,
    tags         TEXT    NOT NULL DEFAULT '[]',
    meta         TEXT    NOT NULL DEFAULT '{}',
    strength     REAL    NOT NULL DEFAULT 0.5,
    base_strength REAL   NOT NULL DEFAULT 0.5,
    created_at   INTEGER NOT NULL,
    accessed_at  INTEGER NOT NULL,
    access_count INTEGER NOT NULL DEFAULT 0,
    expires_at   INTEGER,
    review_at    INTEGER,
    is_deleted   INTEGER NOT NULL DEFAULT 0,
    scope        TEXT    NOT NULL DEFAULT 'session',
    session_id   TEXT,
    project_id   TEXT
);

CREATE TABLE IF NOT EXISTS state (
    key        TEXT    PRIMARY KEY,
    value      TEXT    NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS timeline (
    id        TEXT    PRIMARY KEY,
    type      TEXT    NOT NULL,
    action    TEXT    NOT NULL,
    ref_key   TEXT,
    content   TEXT,
    timestamp INTEGER NOT NULL,
    hlc       TEXT,
    payload   TEXT
);

CREATE TABLE IF NOT EXISTS snapshots (
    id             TEXT    PRIMARY KEY,
    created_at     INTEGER NOT NULL,
    memory_data    TEXT    NOT NULL,
    state_data     TEXT    NOT NULL,
    timeline_data  TEXT    NOT NULL,
    embeddings_data TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
    id           TEXT    PRIMARY KEY,
    name         TEXT,
    created_at   INTEGER NOT NULL,
    archived_at  INTEGER,
    memory_count INTEGER NOT NULL DEFAULT 0,
    meta         TEXT    NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS memory_embeddings (
    memory_id  TEXT PRIMARY KEY REFERENCES memories(id) ON DELETE CASCADE,
    vector     TEXT NOT NULL,
    dimensions INTEGER NOT NULL,
    model_hint TEXT NOT NULL DEFAULT 'unknown'
);

CREATE INDEX IF NOT EXISTS idx_memories_strength  ON memories(strength)    WHERE is_deleted = 0;
CREATE INDEX IF NOT EXISTS idx_memories_accessed  ON memories(accessed_at) WHERE is_deleted = 0;
CREATE INDEX IF NOT EXISTS idx_memories_kind      ON memories(kind)        WHERE is_deleted = 0;
CREATE INDEX IF NOT EXISTS idx_memories_scope     ON memories(scope)       WHERE is_deleted = 0;
CREATE INDEX IF NOT EXISTS idx_memories_session   ON memories(session_id)  WHERE is_deleted = 0;
CREATE INDEX IF NOT EXISTS idx_timeline_timestamp ON timeline(timestamp);
"""


# ---------------------------------------------------------------------------
# Row hydration helpers
# ---------------------------------------------------------------------------

def _row_to_memory(row: sqlite3.Row) -> Memory:
    return Memory(
        id=row["id"],
        content=row["content"],
        kind=MemoryKind(row["kind"]),
        tags=json.loads(row["tags"] or "[]"),
        meta=json.loads(row["meta"] or "{}"),
        strength=float(row["strength"]),
        base_strength=float(row["base_strength"]),
        created_at=int(row["created_at"]),
        accessed_at=int(row["accessed_at"]),
        access_count=int(row["access_count"]),
        scope=MemoryScope(row["scope"] or "session"),
        session_id=row["session_id"],
        project_id=row["project_id"],
        expires_at=row["expires_at"],
        review_at=row["review_at"],
    )


def _row_to_session(row: sqlite3.Row) -> Session:
    return Session(
        id=row["id"],
        name=row["name"],
        created_at=int(row["created_at"]),
        archived_at=int(row["archived_at"]) if row["archived_at"] is not None else None,
        memory_count=int(row["memory_count"]),
        meta=json.loads(row["meta"] or "{}"),
    )


def _row_to_event(row: sqlite3.Row) -> TimelineEvent:
    return TimelineEvent(
        id=row["id"],
        type=TimelineType(row["type"]),
        action=row["action"],
        timestamp=int(row["timestamp"]),
        ref_key=row["ref_key"],
        content=row["content"],
        hlc=row["hlc"],
        payload=row["payload"],
    )


# ---------------------------------------------------------------------------
# SQLiteStorageAdapter
# ---------------------------------------------------------------------------

class SQLiteStorageAdapter:
    """
    SQLite-backed storage adapter.

    Reads and writes ``.limbic`` files in the exact same format as the
    TypeScript ``SQLiteStorageAdapter``, enabling seamless cross-language
    data sharing.

    Usage::

        store = SQLiteStorageAdapter("./agent.limbic")
        store.init()
        store.save_memory(memory)
        store.close()
    """

    def __init__(self, path: str | Path) -> None:
        self._path = str(path)
        self._conn: sqlite3.Connection | None = None

    def init(self) -> None:
        """Open the database and apply the schema DDL."""
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA_SQL)
        self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def vacuum(self) -> None:
        self._db.execute("VACUUM")

    @property
    def _db(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("SQLiteStorageAdapter not initialised — call init() first.")
        return self._conn

    # ------------------------------------------------------------------
    # Memory operations
    # ------------------------------------------------------------------

    def save_memory(self, memory: Memory) -> None:
        self._db.execute(
            """
            INSERT INTO memories
                (id, content, kind, tags, meta, strength, base_strength,
                 created_at, accessed_at, access_count, expires_at, review_at,
                 is_deleted, scope, session_id, project_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                content       = excluded.content,
                kind          = excluded.kind,
                tags          = excluded.tags,
                meta          = excluded.meta,
                strength      = excluded.strength,
                base_strength = excluded.base_strength,
                accessed_at   = excluded.accessed_at,
                access_count  = excluded.access_count,
                expires_at    = excluded.expires_at,
                review_at     = excluded.review_at,
                scope         = excluded.scope,
                session_id    = excluded.session_id,
                project_id    = excluded.project_id
            """,
            (
                memory.id,
                memory.content,
                memory.kind.value,
                json.dumps(memory.tags),
                json.dumps(memory.meta),
                memory.strength,
                memory.base_strength,
                memory.created_at,
                memory.accessed_at,
                memory.access_count,
                memory.expires_at,
                memory.review_at,
                memory.scope.value,
                memory.session_id,
                memory.project_id,
            ),
        )
        self._db.commit()

    def get_memory(self, memory_id: str) -> Memory | None:
        row = self._db.execute(
            "SELECT * FROM memories WHERE id=? AND is_deleted=0", (memory_id,)
        ).fetchone()
        return _row_to_memory(row) if row else None

    def update_memory_access(self, memory_id: str, access_time: int, new_strength: float) -> None:
        self._db.execute(
            """
            UPDATE memories
               SET accessed_at=?, strength=?, access_count=access_count+1
             WHERE id=? AND is_deleted=0
            """,
            (access_time, new_strength, memory_id),
        )
        self._db.commit()

    def delete_memory(self, memory_id: str) -> None:
        self._db.execute("UPDATE memories SET is_deleted=1 WHERE id=?", (memory_id,))
        self._db.commit()

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 20,
        min_strength: float | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        since: int | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]:
        conds = ["is_deleted=0"]
        params: list[Any] = []

        if kind is not None:
            kinds = [kind.value] if isinstance(kind, MemoryKind) else [k.value for k in kind]
            placeholders = ",".join("?" * len(kinds))
            conds.append(f"kind IN ({placeholders})")
            params.extend(kinds)

        if min_strength is not None:
            conds.append("strength>=?")
            params.append(min_strength)

        if since is not None:
            conds.append("created_at>=?")
            params.append(since)

        if session_id is not None:
            conds.append("session_id=?")
            params.append(session_id)

        if project_id is not None:
            conds.append("project_id=?")
            params.append(project_id)

        where = " AND ".join(conds)

        # Tag filtering (JSON contains — simple Python-side post-filter for portability)
        # For high-volume use, consider a generated column or FTS5.

        if not query.strip():
            rows = self._db.execute(
                f"SELECT * FROM memories WHERE {where} ORDER BY strength DESC, accessed_at DESC LIMIT ?",
                params + [limit],
            ).fetchall()
        else:
            conds.append("content LIKE ?")
            params.append(f"%{query}%")
            where = " AND ".join(conds)
            rows = self._db.execute(
                f"SELECT * FROM memories WHERE {where} ORDER BY strength DESC, accessed_at DESC LIMIT ?",
                params + [limit],
            ).fetchall()

        memories = [_row_to_memory(r) for r in rows]

        # Post-filter by tags if requested
        if tags:
            tag_set = set(tags)
            memories = [m for m in memories if tag_set.issubset(set(m.tags))]

        return memories

    def get_memories_by_filter(
        self,
        *,
        ids: list[str] | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        before: int | None = None,
        max_strength: float | None = None,
        scope: str | list[str] | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]:
        conds = ["is_deleted=0"]
        params: list[Any] = []

        if ids:
            placeholders = ",".join("?" * len(ids))
            conds.append(f"id IN ({placeholders})")
            params.extend(ids)

        if kind is not None:
            kinds = [kind.value] if isinstance(kind, MemoryKind) else [k.value for k in kind]
            placeholders = ",".join("?" * len(kinds))
            conds.append(f"kind IN ({placeholders})")
            params.extend(kinds)

        if before is not None:
            conds.append("created_at<?")
            params.append(before)

        if max_strength is not None:
            conds.append("strength<=?")
            params.append(max_strength)

        if scope is not None:
            scopes = [scope] if isinstance(scope, str) else scope
            placeholders = ",".join("?" * len(scopes))
            conds.append(f"scope IN ({placeholders})")
            params.extend(scopes)

        if session_id is not None:
            conds.append("session_id=?")
            params.append(session_id)

        if project_id is not None:
            conds.append("project_id=?")
            params.append(project_id)

        where = " AND ".join(conds)
        rows = self._db.execute(
            f"SELECT * FROM memories WHERE {where} ORDER BY strength DESC",
            params,
        ).fetchall()

        memories = [_row_to_memory(r) for r in rows]

        if tags:
            tag_set = set(tags)
            memories = [m for m in memories if tag_set.issubset(set(m.tags))]

        return memories

    # ------------------------------------------------------------------
    # State KV
    # ------------------------------------------------------------------

    def get_state(self, key: str) -> str | None:
        row = self._db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_state(self, key: str, value: str, timestamp: int) -> None:
        self._db.execute(
            "INSERT INTO state(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, value, timestamp),
        )
        self._db.commit()

    def delete_state(self, key: str) -> None:
        self._db.execute("DELETE FROM state WHERE key=?", (key,))
        self._db.commit()

    def get_all_state_keys(self) -> list[str]:
        rows = self._db.execute("SELECT key FROM state ORDER BY key").fetchall()
        return [r["key"] for r in rows]

    # ------------------------------------------------------------------
    # Timeline
    # ------------------------------------------------------------------

    def log_event(self, event: TimelineEvent) -> None:
        self._db.execute(
            """
            INSERT OR IGNORE INTO timeline
                (id, type, action, ref_key, content, timestamp, hlc, payload)
            VALUES (?,?,?,?,?,?,?,?)
            """,
            (event.id, event.type.value, event.action, event.ref_key,
             event.content, event.timestamp, event.hlc, event.payload),
        )
        self._db.commit()

    def get_events(
        self,
        *,
        since: int | None = None,
        until: int | None = None,
        type: str | list[str] | None = None,
        limit: int = 1000,
    ) -> list[TimelineEvent]:
        conds: list[str] = []
        params: list[Any] = []

        if since is not None:
            conds.append("timestamp>=?")
            params.append(since)
        if until is not None:
            conds.append("timestamp<=?")
            params.append(until)
        if type is not None:
            types = [type] if isinstance(type, str) else type
            placeholders = ",".join("?" * len(types))
            conds.append(f"type IN ({placeholders})")
            params.extend(types)

        where = f"WHERE {' AND '.join(conds)}" if conds else ""
        rows = self._db.execute(
            f"SELECT * FROM timeline {where} ORDER BY timestamp DESC LIMIT ?",
            params + [limit],
        ).fetchall()
        return [_row_to_event(r) for r in rows]

    def prune_events(self, keep_count: int) -> int:
        cur = self._db.execute(
            """
            DELETE FROM timeline WHERE id NOT IN (
                SELECT id FROM timeline ORDER BY timestamp DESC LIMIT ?
            )
            """,
            (keep_count,),
        )
        self._db.commit()
        return cur.rowcount

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def save_session(self, session: Session) -> None:
        self._db.execute(
            """
            INSERT INTO sessions(id,name,created_at,archived_at,memory_count,meta)
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,
                archived_at=excluded.archived_at,
                memory_count=excluded.memory_count,
                meta=excluded.meta
            """,
            (session.id, session.name, session.created_at, session.archived_at,
             session.memory_count, json.dumps(session.meta)),
        )
        self._db.commit()

    def get_session(self, session_id: str) -> Session | None:
        row = self._db.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
        return _row_to_session(row) if row else None

    def list_sessions(self, include_archived: bool = False, limit: int = 50, offset: int = 0) -> list[Session]:
        archive_filter = "" if include_archived else "AND archived_at IS NULL"
        rows = self._db.execute(
            f"SELECT * FROM sessions WHERE 1=1 {archive_filter} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset),
        ).fetchall()
        return [_row_to_session(r) for r in rows]

    def archive_session(self, session_id: str, archive_time: int) -> None:
        self._db.execute("UPDATE sessions SET archived_at=? WHERE id=?", (archive_time, session_id))
        self._db.commit()

    def update_session_memory_count(self, session_id: str, count: int) -> None:
        self._db.execute("UPDATE sessions SET memory_count=? WHERE id=?", (count, session_id))
        self._db.commit()

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def prune_weak_memories(self, threshold: float, before_time: int) -> int:
        cur = self._db.execute(
            "UPDATE memories SET is_deleted=1 WHERE strength<? AND accessed_at<? AND is_deleted=0",
            (threshold, before_time),
        )
        self._db.commit()
        return cur.rowcount

    def get_stats(self) -> dict[str, Any]:
        mem_count = self._db.execute("SELECT COUNT(*) FROM memories WHERE is_deleted=0").fetchone()[0]
        state_count = self._db.execute("SELECT COUNT(*) FROM state").fetchone()[0]
        snap_count = self._db.execute("SELECT COUNT(*) FROM snapshots").fetchone()[0]
        emb_count = self._db.execute("SELECT COUNT(*) FROM memory_embeddings").fetchone()[0]
        return {
            "memoryCount": mem_count,
            "stateKeyCount": state_count,
            "snapshotCount": snap_count,
            "embeddingsCount": emb_count,
            "dbSizeBytes": 0,
        }
