"""
PostgreSQL Storage Adapter for LimbicDB Python SDK.

Cloud/enterprise backend that mirrors the TypeScript PostgresStore exactly.

Features:
  - Connection pooling via psycopg3 (ConnectionPool)
  - pgvector for native cosine-distance vector search
  - JSONB for tags and meta
  - ILIKE keyword search (CJK-compatible)
  - Full P2P sync support (timeline, state)
  - Same schema DDL as the TypeScript PostgresStore

Usage::

    from limbicdb.storage.postgres_store import PostgresStore

    store = PostgresStore(
        conninfo="postgresql://postgres:password@localhost:5432/mydb",
        schema="my_agent",
    )
    store.init()
    store.save_memory(memory)
    store.close()

Optional dependencies::

    pip install "limbicdb[postgres]"   # psycopg[binary] + pgvector
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from limbicdb.types import Memory, MemoryKind, MemoryScope, Session, TimelineEvent, TimelineType

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# DDL — identical column layout to TypeScript postgres-store.ts
# ---------------------------------------------------------------------------

def _build_ddl(schema: str, dim: int) -> str:
    return f"""
CREATE SCHEMA IF NOT EXISTS "{schema}";

CREATE TABLE IF NOT EXISTS "{schema}".memories (
    id            TEXT    PRIMARY KEY,
    content       TEXT    NOT NULL,
    kind          TEXT    NOT NULL CHECK (kind IN ('fact','episode','preference','procedure','goal')),
    tags          JSONB   NOT NULL DEFAULT '[]',
    meta          JSONB   NOT NULL DEFAULT '{{}}',
    strength      REAL    NOT NULL DEFAULT 0.5,
    base_strength REAL    NOT NULL DEFAULT 0.5,
    created_at    BIGINT  NOT NULL,
    accessed_at   BIGINT  NOT NULL,
    access_count  INTEGER NOT NULL DEFAULT 0,
    expires_at    BIGINT,
    review_at     BIGINT,
    is_deleted    SMALLINT NOT NULL DEFAULT 0,
    scope         TEXT    NOT NULL DEFAULT 'session'
                          CHECK (scope IN ('session','project','core','archive')),
    session_id    TEXT,
    project_id    TEXT
);

CREATE TABLE IF NOT EXISTS "{schema}".memory_embeddings (
    memory_id   TEXT    PRIMARY KEY
                        REFERENCES "{schema}".memories(id) ON DELETE CASCADE,
    vector      vector({dim}),
    dimensions  INTEGER NOT NULL,
    model_hint  TEXT    NOT NULL DEFAULT 'unknown'
);

CREATE TABLE IF NOT EXISTS "{schema}".state (
    key         TEXT    PRIMARY KEY,
    value       TEXT    NOT NULL,
    updated_at  BIGINT  NOT NULL
);

CREATE TABLE IF NOT EXISTS "{schema}".timeline (
    id        TEXT    PRIMARY KEY,
    type      TEXT    NOT NULL,
    action    TEXT    NOT NULL,
    ref_key   TEXT,
    content   TEXT,
    timestamp BIGINT  NOT NULL,
    hlc       TEXT,
    payload   TEXT
);

CREATE TABLE IF NOT EXISTS "{schema}".snapshots (
    id              TEXT  PRIMARY KEY,
    created_at      BIGINT NOT NULL,
    memory_data     JSONB  NOT NULL,
    state_data      JSONB  NOT NULL,
    timeline_data   JSONB  NOT NULL,
    embeddings_data JSONB
);

CREATE TABLE IF NOT EXISTS "{schema}".sessions (
    id           TEXT    PRIMARY KEY,
    name         TEXT,
    created_at   BIGINT  NOT NULL,
    archived_at  BIGINT,
    memory_count INTEGER NOT NULL DEFAULT 0,
    meta         JSONB   NOT NULL DEFAULT '{{}}'
);

CREATE INDEX IF NOT EXISTS idx_ldb_py_m_s  ON "{schema}".memories(strength)    WHERE is_deleted=0;
CREATE INDEX IF NOT EXISTS idx_ldb_py_m_a  ON "{schema}".memories(accessed_at) WHERE is_deleted=0;
CREATE INDEX IF NOT EXISTS idx_ldb_py_m_k  ON "{schema}".memories(kind)        WHERE is_deleted=0;
CREATE INDEX IF NOT EXISTS idx_ldb_py_m_si ON "{schema}".memories(session_id)  WHERE is_deleted=0;
CREATE INDEX IF NOT EXISTS idx_ldb_py_tl   ON "{schema}".timeline(timestamp);
"""


# ---------------------------------------------------------------------------
# Row hydration helpers
# ---------------------------------------------------------------------------

def _row_to_memory(row: dict[str, Any]) -> Memory:
    return Memory(
        id=row["id"],
        content=row["content"],
        kind=MemoryKind(row["kind"]),
        tags=row["tags"] if isinstance(row["tags"], list) else json.loads(row["tags"] or "[]"),
        meta=row["meta"] if isinstance(row["meta"], dict) else json.loads(row["meta"] or "{}"),
        strength=float(row["strength"]),
        base_strength=float(row["base_strength"]),
        created_at=int(row["created_at"]),
        accessed_at=int(row["accessed_at"]),
        access_count=int(row["access_count"]),
        scope=MemoryScope(row.get("scope") or "session"),
        session_id=row.get("session_id"),
        project_id=row.get("project_id"),
        expires_at=row.get("expires_at"),
        review_at=row.get("review_at"),
    )


def _row_to_session(row: dict[str, Any]) -> Session:
    return Session(
        id=row["id"],
        name=row.get("name"),
        created_at=int(row["created_at"]),
        archived_at=int(row["archived_at"]) if row.get("archived_at") is not None else None,
        memory_count=int(row["memory_count"]),
        meta=row["meta"] if isinstance(row["meta"], dict) else json.loads(row.get("meta") or "{}"),
    )


def _row_to_event(row: dict[str, Any]) -> TimelineEvent:
    return TimelineEvent(
        id=row["id"],
        type=TimelineType(row["type"]),
        action=row["action"],
        timestamp=int(row["timestamp"]),
        ref_key=row.get("ref_key"),
        content=row.get("content"),
        hlc=row.get("hlc"),
        payload=row.get("payload"),
    )


# ---------------------------------------------------------------------------
# PostgresStore
# ---------------------------------------------------------------------------

class PostgresStore:
    """
    PostgreSQL storage adapter — Python equivalent of TypeScript PostgresStore.

    Requires ``pip install 'limbicdb[postgres]'`` (psycopg[binary]).

    Args:
        conninfo:             PostgreSQL connection string.
        schema:               Schema name (auto-created). Default: ``'public'``.
        min_size:             Pool minimum connections. Default: ``1``.
        max_size:             Pool maximum connections. Default: ``10``.
        create_extension:     Auto-create pgvector extension. Default: ``True``.
        embedding_dimensions: Expected vector dimensions. Default: ``384``.
    """

    def __init__(
        self,
        conninfo: str,
        *,
        schema: str = "public",
        min_size: int = 1,
        max_size: int = 10,
        create_extension: bool = True,
        embedding_dimensions: int = 384,
    ) -> None:
        self._conninfo = conninfo
        self._schema = schema
        self._min_size = min_size
        self._max_size = max_size
        self._create_extension = create_extension
        self._dim = embedding_dimensions
        self._pool: Any = None

    def init(self) -> None:
        """Open the connection pool and apply schema DDL."""
        try:
            from psycopg_pool import ConnectionPool  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "[LimbicDB] PostgresStore requires psycopg[binary] and psycopg-pool.\n"
                "Run: pip install 'limbicdb[postgres]'"
            ) from e

        self._pool = ConnectionPool(
            self._conninfo,
            min_size=self._min_size,
            max_size=self._max_size,
            open=True,
        )

        with self._pool.connection() as conn:
            if self._create_extension:
                try:
                    conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
                except Exception:
                    pass  # non-fatal — pgvector may not be installed
            conn.execute(_build_ddl(self._schema, self._dim))
            conn.commit()

    def close(self) -> None:
        """Close all pool connections."""
        if self._pool is not None:
            self._pool.close()
            self._pool = None

    def vacuum(self) -> None:
        with self._conn() as conn:
            conn.execute(f'VACUUM ANALYZE "{self._schema}".memories')

    def _conn(self) -> Any:
        if self._pool is None:
            raise RuntimeError("PostgresStore not initialised — call init() first.")
        return self._pool.connection()

    def _run(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        """Execute a SELECT query and return rows as dicts."""
        with self._conn() as conn:
            cur = conn.execute(sql, params)
            cols = [d.name for d in cur.description] if cur.description else []
            return [dict(zip(cols, row, strict=False)) for row in cur.fetchall()]

    def _exec(self, sql: str, params: tuple[Any, ...] = ()) -> int:
        """Execute a DML statement and return affected row count."""
        with self._conn() as conn:
            cur = conn.execute(sql, params)
            conn.commit()
            return cur.rowcount or 0

    def _one(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        rows = self._run(sql, params)
        return rows[0] if rows else None

    # ------------------------------------------------------------------
    # Memory
    # ------------------------------------------------------------------

    def save_memory(self, memory: Memory) -> None:
        self._exec(
            f"""
            INSERT INTO "{self._schema}".memories
              (id,content,kind,tags,meta,strength,base_strength,
               created_at,accessed_at,access_count,expires_at,review_at,
               is_deleted,scope,session_id,project_id)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,0,%s,%s,%s)
            ON CONFLICT (id) DO UPDATE SET
              content=EXCLUDED.content, kind=EXCLUDED.kind,
              tags=EXCLUDED.tags, meta=EXCLUDED.meta,
              strength=EXCLUDED.strength, base_strength=EXCLUDED.base_strength,
              accessed_at=EXCLUDED.accessed_at, access_count=EXCLUDED.access_count,
              expires_at=EXCLUDED.expires_at, review_at=EXCLUDED.review_at,
              scope=EXCLUDED.scope, session_id=EXCLUDED.session_id,
              project_id=EXCLUDED.project_id
            """,
            (
                memory.id, memory.content, memory.kind.value,
                json.dumps(memory.tags), json.dumps(memory.meta),
                memory.strength, memory.base_strength,
                memory.created_at, memory.accessed_at, memory.access_count,
                memory.expires_at, memory.review_at,
                memory.scope.value, memory.session_id, memory.project_id,
            ),
        )

    def get_memory(self, memory_id: str) -> Memory | None:
        row = self._one(
            f'SELECT * FROM "{self._schema}".memories WHERE id=%s AND is_deleted=0',
            (memory_id,),
        )
        return _row_to_memory(row) if row else None

    def update_memory_access(self, memory_id: str, access_time: int, new_strength: float) -> None:
        self._exec(
            f'UPDATE "{self._schema}".memories SET accessed_at=%s,strength=%s,access_count=access_count+1 WHERE id=%s AND is_deleted=0',
            (access_time, new_strength, memory_id),
        )

    def delete_memory(self, memory_id: str) -> None:
        self._exec(
            f'UPDATE "{self._schema}".memories SET is_deleted=1 WHERE id=%s',
            (memory_id,),
        )

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 20,
        min_strength: float | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        since: int | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]:
        conds = [f'"{self._schema}".memories.is_deleted=0']
        params: list[Any] = []

        if kind is not None:
            kinds = [kind.value] if isinstance(kind, MemoryKind) else [k.value for k in kind]
            conds.append("kind = ANY(%s::text[])")
            params.append(kinds)
        if min_strength is not None:
            conds.append("strength>=%s")
            params.append(min_strength)
        if since is not None:
            conds.append("created_at>=%s")
            params.append(since)
        if session_id is not None:
            conds.append("session_id=%s")
            params.append(session_id)
        if project_id is not None:
            conds.append("project_id=%s")
            params.append(project_id)
        if tags:
            conds.append("tags @> %s::jsonb")
            params.append(json.dumps(tags))

        where = " AND ".join(conds)

        if not query.strip():
            rows = self._run(
                f'SELECT * FROM "{self._schema}".memories WHERE {where} ORDER BY strength DESC,accessed_at DESC LIMIT %s',
                tuple(params) + (limit,),
            )
        else:
            like = f"%{query}%"
            conds.append("content ILIKE %s")
            params.append(like)
            where = " AND ".join(conds)
            rows = self._run(
                f'SELECT * FROM "{self._schema}".memories WHERE {where} ORDER BY strength DESC,accessed_at DESC LIMIT %s',
                tuple(params) + (limit,),
            )

        return [_row_to_memory(r) for r in rows]

    def get_memories_by_filter(
        self,
        *,
        ids: list[str] | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        before: int | None = None,
        max_strength: float | None = None,
        scope: str | list[str] | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]:
        conds = ["is_deleted=0"]
        params: list[Any] = []

        if ids:
            conds.append("id = ANY(%s::text[])")
            params.append(ids)
        if kind is not None:
            kinds = [kind.value] if isinstance(kind, MemoryKind) else [k.value for k in kind]
            conds.append("kind = ANY(%s::text[])")
            params.append(kinds)
        if before is not None:
            conds.append("created_at<%s")
            params.append(before)
        if max_strength is not None:
            conds.append("strength<=%s")
            params.append(max_strength)
        if scope is not None:
            scopes = [scope] if isinstance(scope, str) else scope
            conds.append("scope = ANY(%s::text[])")
            params.append(scopes)
        if session_id is not None:
            conds.append("session_id=%s")
            params.append(session_id)
        if project_id is not None:
            conds.append("project_id=%s")
            params.append(project_id)
        if tags:
            conds.append("tags @> %s::jsonb")
            params.append(json.dumps(tags))

        where = " AND ".join(conds)
        rows = self._run(
            f'SELECT * FROM "{self._schema}".memories WHERE {where} ORDER BY strength DESC',
            tuple(params),
        )
        return [_row_to_memory(r) for r in rows]

    def search_memories_by_vector(
        self,
        vector: list[float],
        limit: int,
        min_strength: float | None = None,
    ) -> list[tuple[Memory, float]]:
        """pgvector cosine similarity search.

        Returns a list of (Memory, score) tuples sorted by descending score.
        Requires the pgvector extension and embeddings stored via save_embedding().
        """
        conds = [f'"{self._schema}".memories.is_deleted=0']
        params: list[Any] = [json.dumps(vector)]

        if min_strength is not None:
            conds.append(f'"{self._schema}".memories.strength>=%s')
            params.append(min_strength)

        where = " AND ".join(conds)
        rows = self._run(
            f"""
            SELECT "{self._schema}".memories.*,
                   (1 - ("{self._schema}".memory_embeddings.vector <=> %s::vector)) AS cosine_score
            FROM "{self._schema}".memories
            JOIN "{self._schema}".memory_embeddings
              ON "{self._schema}".memory_embeddings.memory_id = "{self._schema}".memories.id
            WHERE {where}
            ORDER BY "{self._schema}".memory_embeddings.vector <=> %s::vector
            LIMIT %s
            """,
            tuple(params) + (json.dumps(vector), limit),
        )
        return [(_row_to_memory(r), float(r["cosine_score"])) for r in rows]

    # ------------------------------------------------------------------
    # Embedding
    # ------------------------------------------------------------------

    def save_embedding(self, memory_id: str, vector: list[float], model_hint: str = "unknown") -> None:
        self._exec(
            f"""
            INSERT INTO "{self._schema}".memory_embeddings (memory_id,vector,dimensions,model_hint)
            VALUES (%s,%s::vector,%s,%s)
            ON CONFLICT (memory_id) DO UPDATE SET
              vector=EXCLUDED.vector,dimensions=EXCLUDED.dimensions,model_hint=EXCLUDED.model_hint
            """,
            (memory_id, json.dumps(vector), len(vector), model_hint),
        )

    def delete_embedding(self, memory_id: str) -> None:
        self._exec(
            f'DELETE FROM "{self._schema}".memory_embeddings WHERE memory_id=%s',
            (memory_id,),
        )

    # ------------------------------------------------------------------
    # State KV
    # ------------------------------------------------------------------

    def get_state(self, key: str) -> str | None:
        row = self._one(f'SELECT value FROM "{self._schema}".state WHERE key=%s', (key,))
        return row["value"] if row else None

    def set_state(self, key: str, value: str, timestamp: int) -> None:
        self._exec(
            f"""
            INSERT INTO "{self._schema}".state (key,value,updated_at) VALUES (%s,%s,%s)
            ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=EXCLUDED.updated_at
            """,
            (key, value, timestamp),
        )

    def delete_state(self, key: str) -> None:
        self._exec(f'DELETE FROM "{self._schema}".state WHERE key=%s', (key,))

    def get_all_state_keys(self) -> list[str]:
        rows = self._run(f'SELECT key FROM "{self._schema}".state ORDER BY key')
        return [r["key"] for r in rows]

    # ------------------------------------------------------------------
    # Timeline
    # ------------------------------------------------------------------

    def log_event(self, event: TimelineEvent) -> None:
        self._exec(
            f"""
            INSERT INTO "{self._schema}".timeline
              (id,type,action,ref_key,content,timestamp,hlc,payload)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (id) DO NOTHING
            """,
            (event.id, event.type.value, event.action, event.ref_key,
             event.content, event.timestamp, event.hlc, event.payload),
        )

    def get_events(
        self,
        *,
        since: int | None = None,
        until: int | None = None,
        type: str | list[str] | None = None,
        limit: int = 1000,
    ) -> list[TimelineEvent]:
        conds: list[str] = []
        params: list[Any] = []

        if since is not None:
            conds.append("timestamp>=%s")
            params.append(since)
        if until is not None:
            conds.append("timestamp<=%s")
            params.append(until)
        if type is not None:
            types = [type] if isinstance(type, str) else type
            conds.append("type = ANY(%s::text[])")
            params.append(types)

        where = f"WHERE {' AND '.join(conds)}" if conds else ""
        rows = self._run(
            f'SELECT * FROM "{self._schema}".timeline {where} ORDER BY timestamp DESC LIMIT %s',
            tuple(params) + (limit,),
        )
        return [_row_to_event(r) for r in rows]

    def prune_events(self, keep_count: int) -> int:
        return self._exec(
            f"""
            DELETE FROM "{self._schema}".timeline
            WHERE id NOT IN (
                SELECT id FROM "{self._schema}".timeline ORDER BY timestamp DESC LIMIT %s
            )
            """,
            (keep_count,),
        )

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def save_session(self, session: Session) -> None:
        self._exec(
            f"""
            INSERT INTO "{self._schema}".sessions (id,name,created_at,archived_at,memory_count,meta)
            VALUES (%s,%s,%s,%s,%s,%s)
            ON CONFLICT (id) DO UPDATE SET
              name=EXCLUDED.name, archived_at=EXCLUDED.archived_at,
              memory_count=EXCLUDED.memory_count, meta=EXCLUDED.meta
            """,
            (session.id, session.name, session.created_at, session.archived_at,
             session.memory_count, json.dumps(session.meta)),
        )

    def get_session(self, session_id: str) -> Session | None:
        row = self._one(f'SELECT * FROM "{self._schema}".sessions WHERE id=%s', (session_id,))
        return _row_to_session(row) if row else None

    def list_sessions(self, include_archived: bool = False, limit: int = 50, offset: int = 0) -> list[Session]:
        archive_filter = "" if include_archived else "AND archived_at IS NULL"
        rows = self._run(
            f'SELECT * FROM "{self._schema}".sessions WHERE 1=1 {archive_filter} ORDER BY created_at DESC LIMIT %s OFFSET %s',
            (limit, offset),
        )
        return [_row_to_session(r) for r in rows]

    def archive_session(self, session_id: str, archive_time: int) -> None:
        self._exec(
            f'UPDATE "{self._schema}".sessions SET archived_at=%s WHERE id=%s',
            (archive_time, session_id),
        )

    def update_session_memory_count(self, session_id: str, count: int) -> None:
        self._exec(
            f'UPDATE "{self._schema}".sessions SET memory_count=%s WHERE id=%s',
            (count, session_id),
        )

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def prune_weak_memories(self, threshold: float, before_time: int) -> int:
        return self._exec(
            f'UPDATE "{self._schema}".memories SET is_deleted=1 WHERE strength<%s AND accessed_at<%s AND is_deleted=0',
            (threshold, before_time),
        )

    def get_stats(self) -> dict[str, Any]:
        a = self._one(f'SELECT COUNT(*) AS n FROM "{self._schema}".memories WHERE is_deleted=0')
        b = self._one(f'SELECT COUNT(*) AS n FROM "{self._schema}".state')
        c = self._one(f'SELECT COUNT(*) AS n FROM "{self._schema}".snapshots')
        d = self._one(f'SELECT COUNT(*) AS n FROM "{self._schema}".memory_embeddings')
        return {
            "memoryCount": int(a["n"]) if a else 0,
            "stateKeyCount": int(b["n"]) if b else 0,
            "snapshotCount": int(c["n"]) if c else 0,
            "embeddingsCount": int(d["n"]) if d else 0,
            "dbSizeBytes": 0,
        }
