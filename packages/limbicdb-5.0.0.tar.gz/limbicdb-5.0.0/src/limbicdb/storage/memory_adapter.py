"""
In-memory storage adapter (for testing and ephemeral sessions).

All data lives in Python dicts — nothing is persisted to disk.
Mirrors the TypeScript MemoryStorageAdapter exactly.
"""

from __future__ import annotations

from typing import Any

from limbicdb.types import Memory, MemoryKind, Session, TimelineEvent


class MemoryStorageAdapter:
    """Volatile in-memory storage — ideal for tests and short-lived agents."""

    def __init__(self) -> None:
        self._memories: dict[str, Memory] = {}
        self._state: dict[str, tuple[str, int]] = {}  # key -> (value, timestamp)
        self._events: list[TimelineEvent] = []
        self._sessions: dict[str, Session] = {}

    def init(self) -> None:
        pass  # no-op

    def close(self) -> None:
        pass  # no-op

    def vacuum(self) -> None:
        pass  # no-op

    # Memory
    def save_memory(self, memory: Memory) -> None:
        self._memories[memory.id] = memory

    def get_memory(self, memory_id: str) -> Memory | None:
        return self._memories.get(memory_id)

    def update_memory_access(self, memory_id: str, access_time: int, new_strength: float) -> None:
        if memory_id in self._memories:
            m = self._memories[memory_id]
            m.accessed_at = access_time
            m.strength = new_strength
            m.access_count += 1

    def delete_memory(self, memory_id: str) -> None:
        self._memories.pop(memory_id, None)

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 20,
        min_strength: float | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        since: int | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]:
        results = list(self._memories.values())

        if query.strip():
            q = query.lower()
            results = [m for m in results if q in m.content.lower()]

        if kind is not None:
            kinds = {kind} if isinstance(kind, MemoryKind) else set(kind)
            results = [m for m in results if m.kind in kinds]

        if min_strength is not None:
            results = [m for m in results if m.strength >= min_strength]

        if since is not None:
            results = [m for m in results if m.created_at >= since]

        if tags:
            tag_set = set(tags)
            results = [m for m in results if tag_set.issubset(set(m.tags))]

        if session_id is not None:
            results = [m for m in results if m.session_id == session_id]

        if project_id is not None:
            results = [m for m in results if m.project_id == project_id]

        results.sort(key=lambda m: (-m.strength, -m.accessed_at))
        return results[:limit]

    def get_memories_by_filter(self, **kwargs: Any) -> list[Memory]:
        return self.search_memories("", **{k: v for k, v in kwargs.items() if v is not None})

    # State
    def get_state(self, key: str) -> str | None:
        entry = self._state.get(key)
        return entry[0] if entry else None

    def set_state(self, key: str, value: str, timestamp: int) -> None:
        self._state[key] = (value, timestamp)

    def delete_state(self, key: str) -> None:
        self._state.pop(key, None)

    def get_all_state_keys(self) -> list[str]:
        return sorted(self._state.keys())

    # Timeline
    def log_event(self, event: TimelineEvent) -> None:
        if not any(e.id == event.id for e in self._events):
            self._events.append(event)

    def get_events(
        self,
        *,
        since: int | None = None,
        until: int | None = None,
        type: str | list[str] | None = None,
        limit: int = 1000,
    ) -> list[TimelineEvent]:
        events = self._events[:]
        if since is not None:
            events = [e for e in events if e.timestamp >= since]
        if until is not None:
            events = [e for e in events if e.timestamp <= until]
        if type is not None:
            types = {type} if isinstance(type, str) else set(type)
            events = [e for e in events if e.type.value in types]
        events.sort(key=lambda e: -e.timestamp)
        return events[:limit]

    def prune_events(self, keep_count: int) -> int:
        if len(self._events) <= keep_count:
            return 0
        sorted_events = sorted(self._events, key=lambda e: -e.timestamp)
        removed = len(self._events) - keep_count
        self._events = sorted_events[:keep_count]
        return removed

    # Sessions
    def save_session(self, session: Session) -> None:
        self._sessions[session.id] = session

    def get_session(self, session_id: str) -> Session | None:
        return self._sessions.get(session_id)

    def list_sessions(self, include_archived: bool = False, limit: int = 50, offset: int = 0) -> list[Session]:
        sessions = list(self._sessions.values())
        if not include_archived:
            sessions = [s for s in sessions if s.archived_at is None]
        sessions.sort(key=lambda s: -s.created_at)
        return sessions[offset:offset + limit]

    def archive_session(self, session_id: str, archive_time: int) -> None:
        if session_id in self._sessions:
            self._sessions[session_id].archived_at = archive_time

    def update_session_memory_count(self, session_id: str, count: int) -> None:
        if session_id in self._sessions:
            self._sessions[session_id].memory_count = count

    # Maintenance
    def prune_weak_memories(self, threshold: float, before_time: int) -> int:
        to_prune = [
            mid for mid, m in self._memories.items()
            if m.strength < threshold and m.accessed_at < before_time
        ]
        for mid in to_prune:
            del self._memories[mid]
        return len(to_prune)

    def get_stats(self) -> dict[str, Any]:
        return {
            "memoryCount": len(self._memories),
            "stateKeyCount": len(self._state),
            "snapshotCount": 0,
            "embeddingsCount": 0,
            "dbSizeBytes": 0,
        }
