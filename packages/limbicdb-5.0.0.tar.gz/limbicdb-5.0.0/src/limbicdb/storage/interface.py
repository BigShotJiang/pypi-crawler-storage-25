"""
Storage adapter interface (IStorage) — Python equivalent of src/storage/interface.ts.

All concrete storage backends (SQLite, PostgreSQL, Memory) must implement this
Protocol. Using a Protocol (structural subtyping) keeps the design duck-typed
and avoids forcing a class hierarchy.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from limbicdb.types import Memory, MemoryKind, Session, TimelineEvent


@runtime_checkable
class IStorage(Protocol):
    """Storage backend protocol.

    Every method signature here must match the TypeScript IStorage interface.
    """

    def init(self) -> None:
        """Initialise the storage (create tables, open connections, etc.)."""
        ...

    def close(self) -> None:
        """Release all resources."""
        ...

    # Memory operations
    def save_memory(self, memory: Memory) -> None: ...
    def get_memory(self, memory_id: str) -> Memory | None: ...
    def update_memory_access(self, memory_id: str, access_time: int, new_strength: float) -> None: ...
    def delete_memory(self, memory_id: str) -> None: ...

    def search_memories(
        self,
        query: str,
        *,
        limit: int = 20,
        min_strength: float | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        since: int | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]: ...

    def get_memories_by_filter(
        self,
        *,
        ids: list[str] | None = None,
        kind: MemoryKind | list[MemoryKind] | None = None,
        tags: list[str] | None = None,
        before: int | None = None,
        max_strength: float | None = None,
        scope: str | list[str] | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
    ) -> list[Memory]: ...

    # State KV
    def get_state(self, key: str) -> str | None: ...
    def set_state(self, key: str, value: str, timestamp: int) -> None: ...
    def delete_state(self, key: str) -> None: ...
    def get_all_state_keys(self) -> list[str]: ...

    # Timeline
    def log_event(self, event: TimelineEvent) -> None: ...
    def get_events(
        self,
        *,
        since: int | None = None,
        until: int | None = None,
        type: str | list[str] | None = None,
        limit: int = 1000,
    ) -> list[TimelineEvent]: ...
    def prune_events(self, keep_count: int) -> int: ...

    # Sessions
    def save_session(self, session: Session) -> None: ...
    def get_session(self, session_id: str) -> Session | None: ...
    def list_sessions(self, include_archived: bool = False, limit: int = 50, offset: int = 0) -> list[Session]: ...
    def archive_session(self, session_id: str, archive_time: int) -> None: ...
    def update_session_memory_count(self, session_id: str, count: int) -> None: ...

    # Maintenance
    def prune_weak_memories(self, threshold: float, before_time: int) -> int: ...
    def get_stats(self) -> dict[str, Any]: ...
    def vacuum(self) -> None: ...
