"""
Hybrid Logical Clock (HLC) for LimbicDB Python SDK.

Faithful port of ``src/sync/hlc.ts``.

HLC provides causally consistent timestamps for distributed P2P sync.
Each tick produces a monotonically increasing timestamp that encodes both
wall-clock time and a logical counter, formatted as:

    "<wall_ms>-<counter_4hex>-<node_id>"

Example: "1700000000000-0001-node-alpha"
"""

from __future__ import annotations

import time
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# HLCTimestamp
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class HLCTimestamp:
    """An immutable HLC timestamp."""

    wall_ms: int    # physical wall-clock milliseconds
    counter: int    # logical counter (0–65535)
    node_id: str    # unique node identifier

    def __str__(self) -> str:
        return f"{self.wall_ms}-{self.counter:04x}-{self.node_id}"

    def __lt__(self, other: HLCTimestamp) -> bool:
        if self.wall_ms != other.wall_ms:
            return self.wall_ms < other.wall_ms
        return self.counter < other.counter

    def __le__(self, other: HLCTimestamp) -> bool:
        return self == other or self < other

    def __gt__(self, other: HLCTimestamp) -> bool:
        return not self <= other

    def __ge__(self, other: HLCTimestamp) -> bool:
        return not self < other

    @classmethod
    def parse(cls, s: str) -> HLCTimestamp:
        """Parse a serialised HLC string back into an HLCTimestamp."""
        parts = s.split("-", 2)
        if len(parts) != 3:
            raise ValueError(f"Invalid HLC timestamp: {s!r}")
        wall_ms, counter_hex, node_id = parts
        return cls(
            wall_ms=int(wall_ms),
            counter=int(counter_hex, 16),
            node_id=node_id,
        )

    @classmethod
    def zero(cls, node_id: str) -> HLCTimestamp:
        """Return the zero-value HLC for a node."""
        return cls(wall_ms=0, counter=0, node_id=node_id)


# ---------------------------------------------------------------------------
# HybridLogicalClock
# ---------------------------------------------------------------------------

class HybridLogicalClock:
    """
    Hybrid Logical Clock implementation.

    Guarantees:
      - Monotonically increasing timestamps.
      - Causally consistent with remote events (via recv()).
      - Node-ID encoded in every timestamp for attribution.

    Usage::

        hlc = HybridLogicalClock(node_id="agent-alice")

        # Tick for a local event
        ts = hlc.tick()
        print(str(ts))  # e.g. "1700000000000-0000-agent-alice"

        # Receive a remote event
        remote_ts = HLCTimestamp.parse(remote_hlc_string)
        hlc.recv(remote_ts)
    """

    def __init__(self, node_id: str) -> None:
        self._node_id = node_id
        self._last = HLCTimestamp.zero(node_id)

    @property
    def node_id(self) -> str:
        return self._node_id

    def tick(self) -> HLCTimestamp:
        """Generate a new HLC timestamp for a local event."""
        now_ms = int(time.time() * 1000)

        if now_ms > self._last.wall_ms:
            new_ts = HLCTimestamp(wall_ms=now_ms, counter=0, node_id=self._node_id)
        elif now_ms == self._last.wall_ms:
            new_ts = HLCTimestamp(wall_ms=now_ms, counter=self._last.counter + 1, node_id=self._node_id)
        else:
            # Clock went backward — stay at last known time, increment counter
            new_ts = HLCTimestamp(
                wall_ms=self._last.wall_ms,
                counter=self._last.counter + 1,
                node_id=self._node_id,
            )

        self._last = new_ts
        return new_ts

    def recv(self, remote: HLCTimestamp) -> HLCTimestamp:
        """
        Merge a received remote HLC timestamp.

        Must be called when processing any inbound sync event.
        Returns the new local HLC after merging.
        """
        now_ms = int(time.time() * 1000)
        max_wall = max(now_ms, self._last.wall_ms, remote.wall_ms)

        if max_wall == now_ms == self._last.wall_ms == remote.wall_ms or max_wall == self._last.wall_ms == remote.wall_ms:
            counter = max(self._last.counter, remote.counter) + 1
        elif max_wall == self._last.wall_ms:
            counter = self._last.counter + 1
        elif max_wall == remote.wall_ms:
            counter = remote.counter + 1
        else:
            counter = 0

        new_ts = HLCTimestamp(wall_ms=max_wall, counter=counter, node_id=self._node_id)
        self._last = new_ts
        return new_ts

    @property
    def last(self) -> HLCTimestamp:
        """The last generated HLC timestamp."""
        return self._last
