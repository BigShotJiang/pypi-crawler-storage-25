"""Sync package init."""

from limbicdb.sync.hlc import HLCTimestamp, HybridLogicalClock

__all__ = ["HLCTimestamp", "HybridLogicalClock"]
