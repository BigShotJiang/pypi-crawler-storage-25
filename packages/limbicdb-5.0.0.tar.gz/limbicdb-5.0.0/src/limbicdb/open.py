"""
Convenience ``open()`` function — Python equivalent of the TypeScript ``open()``.

Usage::

    from limbicdb import open as ldb_open

    db = ldb_open("./agent.limbic")
    db.remember("User prefers dark mode")
    db.close()

    # Or as a context manager:
    with ldb_open("./agent.limbic") as db:
        db.remember("User likes TypeScript")
"""

from __future__ import annotations

from limbicdb.core.limbicdb import LimbicDB, LimbicDBConfig
from limbicdb.storage.sqlite_adapter import SQLiteStorageAdapter


def open(path: str, **kwargs: object) -> LimbicDB:  # noqa: A001
    """Open a LimbicDB database file and return a :class:`LimbicDB` instance.

    Args:
        path:    Path to the ``.limbic`` SQLite file.
        **kwargs: Extra kwargs passed to :class:`LimbicDBConfig`.

    Returns:
        An initialised :class:`LimbicDB` instance ready to use.
    """
    storage = SQLiteStorageAdapter(path)
    cfg = LimbicDBConfig(path=path, storage=storage, **kwargs)  # type: ignore[arg-type]
    return LimbicDB(cfg)
