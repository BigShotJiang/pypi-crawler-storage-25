"""
Core types for LimbicDB Python SDK.

All types are designed to be 100% structurally compatible with the TypeScript
counterparts defined in src/types.ts. Storage-layer JSON serialization must
round-trip cleanly between both language implementations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MemoryKind(str, Enum):
    """The cognitive classification of a memory.

    Must match the TypeScript ``MemoryKind`` union exactly.
    """

    FACT = "fact"
    EPISODE = "episode"
    PREFERENCE = "preference"
    PROCEDURE = "procedure"
    GOAL = "goal"


class MemoryScope(str, Enum):
    """The isolation scope of a memory.

    Must match the TypeScript ``Memory['scope']`` union exactly.
    """

    SESSION = "session"
    PROJECT = "project"
    CORE = "core"
    ARCHIVE = "archive"


class TimelineType(str, Enum):
    """Event type for the append-only timeline.

    Must match the TypeScript ``TimelineType`` union exactly.
    """

    MEMORY = "memory"
    STATE = "state"
    SNAPSHOT = "snapshot"
    SESSION = "session"


@dataclass
class Memory:
    """A single memory unit — the primary data structure.

    Field names deliberately use camelCase (via alias) to match the
    TypeScript type when JSON-serialised. The Python attributes use
    snake_case for idiomatic Python.
    """

    id: str
    content: str
    kind: MemoryKind
    tags: list[str] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    strength: float = 0.5
    base_strength: float = 0.5
    created_at: int = 0          # Unix ms timestamp
    accessed_at: int = 0         # Unix ms timestamp
    access_count: int = 0
    scope: MemoryScope = MemoryScope.SESSION
    session_id: str | None = None
    project_id: str | None = None
    expires_at: int | None = None
    review_at: int | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a dict compatible with the SQLite JSON schema."""
        return {
            "id": self.id,
            "content": self.content,
            "kind": self.kind.value,
            "tags": self.tags,
            "meta": self.meta,
            "strength": self.strength,
            "baseStrength": self.base_strength,
            "createdAt": self.created_at,
            "accessedAt": self.accessed_at,
            "accessCount": self.access_count,
            "scope": self.scope.value,
            "sessionId": self.session_id,
            "projectId": self.project_id,
            "expiresAt": self.expires_at,
            "reviewAt": self.review_at,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Memory:
        """Hydrate a Memory from the SQLite JSON schema."""
        return cls(
            id=d["id"],
            content=d["content"],
            kind=MemoryKind(d["kind"]),
            tags=d.get("tags") or [],
            meta=d.get("meta") or {},
            strength=float(d.get("strength", 0.5)),
            base_strength=float(d.get("baseStrength", d.get("base_strength", 0.5))),
            created_at=int(d.get("createdAt", d.get("created_at", 0))),
            accessed_at=int(d.get("accessedAt", d.get("accessed_at", 0))),
            access_count=int(d.get("accessCount", d.get("access_count", 0))),
            scope=MemoryScope(d.get("scope", "session")),
            session_id=d.get("sessionId") or d.get("session_id"),
            project_id=d.get("projectId") or d.get("project_id"),
            expires_at=d.get("expiresAt") or d.get("expires_at"),
            review_at=d.get("reviewAt") or d.get("review_at"),
        )


@dataclass
class Session:
    """A conversation or task session grouping memories."""

    id: str
    name: str | None = None
    created_at: int = 0
    archived_at: int | None = None
    memory_count: int = 0
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class TimelineEvent:
    """An append-only event in the sync timeline."""

    id: str
    type: TimelineType
    action: str   # 'create' | 'update' | 'delete' | 'access'
    timestamp: int
    ref_key: str | None = None
    content: str | None = None
    hlc: str | None = None
    payload: str | None = None


@dataclass
class CognitiveScoreBreakdown:
    """Explanation payload for a recalled memory score.

    Mirrors the TypeScript ``CognitiveScoreBreakdown`` exactly.
    """

    score: float
    semantic: float
    semantic_weight: float
    decay: float
    decay_weight: float
    repetition: float
    repetition_weight: float
    recency: float
    recency_weight: float
    keyword_match: bool = False
