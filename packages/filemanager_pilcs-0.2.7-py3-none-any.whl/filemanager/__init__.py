"""FileManager - A comprehensive file management module with various utilities."""

__version__ = "0.2.6"
__author__ = "pilcs"
__license__ = "MIT"

from . import FileManager

__all__ = ["FileManager", "__version__", "__author__", "__license__"]