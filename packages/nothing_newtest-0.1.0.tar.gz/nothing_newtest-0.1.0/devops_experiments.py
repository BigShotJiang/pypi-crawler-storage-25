from packages.all_experiments_class import DevOpsExperiments

__all__ = ["DevOpsExperiments"]


def run_experiment(exp_number: int) -> None:
    runner = DevOpsExperiments()
    method_name = f"exp{exp_number}"
    if not hasattr(runner, method_name):
        raise ValueError("Experiment number must be between 2 and 10")
    getattr(runner, method_name)()
