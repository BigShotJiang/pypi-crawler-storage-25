# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Application Code",
        "app.py",
        "def add(a, b):\n"
        "    return a + b\n\n"
        "def greet(name):\n"
        "    return f'Hello {name}'"
    ),
    (
        "Create the Test Code",
        "test_app.py",
        "from app import add, greet\n\n"
        "def test_add():\n"
        "    assert add(2, 3) == 5\n\n"
        "def test_greet():\n"
        "    assert greet('World') == 'Hello World'"
    ),
    (
        "Create the GitHub Actions Directories",
        "Terminal Command",
        "mkdir .github\\workflows"
    ),
    (
        "Create the Tiny Test Pipeline",
        ".github/workflows/python-test.yml",
        "on: push\n"
        "jobs:\n"
        "  b:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - run: |\n"
        "          pip install pytest\n"
        "          pytest test_app.py -v"
    ),
    (
        "Run Local Test (Optional but Recommended)",
        "Terminal Command",
        "pip install pytest\n"
        "pytest test_app.py -v"
    ),
    (
        "Push to GitHub to Trigger",
        "Terminal Commands",
        "git add .\n"
        "git commit -m \"Exp 10: Automated Testing\"\n"
        "git push"
    )
]

print("==================================================")
print("  Exp 10: Python Automated Testing Guide          ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Files ready! Push to see the Green Checkmark.")
print("==================================================")