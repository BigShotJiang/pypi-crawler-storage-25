import time

# List of the exact commands needed for the experiment in order
commands = [
    ("Start Minikube", "minikube start --driver=docker"),
    ("Create Deployment", "kubectl create deployment myapp --image=nginx"),
    ("Expose the App", "kubectl expose deployment myapp --port=80 --type=NodePort"),
    ("Scale the Pods", "kubectl scale deployment myapp --replicas=3"),
    ("Verify Everything", "kubectl get all"),
    ("View Webpage", "minikube service myapp"),
    ("Clean Up (Delete App)", "kubectl delete deployment myapp"),
    ("Clean Up (Delete Network)", "kubectl delete service myapp")
]

print("==================================================")
print("  Kubernetes Imperative Workflow - Lab Reference  ")
print("==================================================\n")

for i in commands:
    print(i[1])