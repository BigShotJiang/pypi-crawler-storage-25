# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Python Application",
        "app.py",
        "print('hello from exp4')"
    ),
    (
        "Create the Dockerfile",
        "Dockerfile",
        "FROM python:3.10-slim\n\n"
        "WORKDIR /app\n\n"
        "COPY . .\n\n"
        "EXPOSE 9000\n\n"
        "CMD [\"python\",\"app.py\"]"
    ),
    (
        "Create the GitHub Actions Directories",
        "Terminal Command",
        "mkdir .github\\workflows"
    ),
    (
        "Create the Tiny CI/CD Pipeline",
        ".github/workflows/cicd.yml",
        "on: push\n"
        "jobs:\n"
        "  b:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - run: |\n"
        "          docker login -u ${{secrets.DOCKER_USERNAME}} -p ${{secrets.DOCKER_PASSWORD}}\n"
        "          docker build -t ${{secrets.DOCKER_USERNAME}}/app:latest .\n"
        "          docker push ${{secrets.DOCKER_USERNAME}}/app:latest"
    ),
    (
        "Build and Run Locally (To Verify)",
        "Terminal Commands",
        "docker build -t <username>/app:latest .\n"
        "docker run <username>/app:latest"
    ),
    (
        "Push to GitHub to Trigger Pipeline",
        "Terminal Commands",
        "git add .\n"
        "git commit -m \"Exp 4: Docker Build and Push\"\n"
        "git push"
    )
]

print("==================================================")
print("  Exp 4: Docker & GitHub Actions Reference        ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Files ready! Run the commands to push to Docker Hub.")
print("==================================================")