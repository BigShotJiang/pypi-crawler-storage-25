# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Flask Application",
        "app.py",
        "from flask import Flask\n\n"
        "app = Flask(__name__)\n\n"
        "@app.route('/')\n"
        "def test():\n"
        "    return '<h1>hello from flask<h1>'\n\n"
        "if __name__ == '__main__':\n"
        "    app.run(host='0.0.0.0', port=9898, debug=True)"
    ),
    (
        "Create the Requirements File",
        "requirements.txt",
        "flask"
    ),
    (
        "Create the Dockerfile",
        "Dockerfile",
        "FROM python:3.10-slim\n"
        "WORKDIR /app\n"
        "COPY requirements.txt .\n"
        "RUN pip install --no-cache-dir -r requirements.txt\n"
        "COPY . .\n"
        "CMD [\"python\", \"app.py\"]"
    ),
    (
        "Build the Docker Image",
        "Terminal Command",
        "docker build -t <username>/exp2:latest ."
    ),
    (
        "Run the Container (Mapping Port 9898 to 9898)",
        "Terminal Command",
        "docker run -p 9898:9898 <username>/exp2:latest"
    ),
    (
        "Push to Docker Hub",
        "Terminal Commands",
        "docker login\n"
        "docker push <username>/exp2:latest"
    ),
    (
        "View the App",
        "Browser URL",
        "http://localhost:9898"
    )
]

print("==================================================")
print("  Exp 2: Flask Containerization & Docker Push     ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Experiment 2 ready! Remember the DOT at the end of build.")
print("==================================================")