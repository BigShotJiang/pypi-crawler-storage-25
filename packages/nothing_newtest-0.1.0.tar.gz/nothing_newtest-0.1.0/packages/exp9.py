# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Step 1: Clone the Repository",
        "Terminal Command",
        "git clone https://github.com/hishamkarunya/devops_lab.git\n"
        "cd devops_lab"
    ),
    (
        "Step 2: Check Status (See what's happening)",
        "Terminal Command",
        "git status"
    ),
    (
        "Step 3: Modify the README file",
        "Terminal Command",
        "echo # Updated Experiment 9 Content >> README.md\n"
        "cat README.md\n"
        "git diff"
    ),
    (
        "Step 4: Stage the changes",
        "Terminal Command",
        "git add README.md"
    ),
    (
        "Step 5: Commit the changes",
        "Terminal Command",
        "git commit -m \"docs: update README with new content\""
    ),
    (
        "Step 6: Push to GitHub",
        "Terminal Command",
        "git push origin main"
    ),
    (
        "Step 7: Verify the History",
        "Terminal Command",
        "git log --oneline -3"
    )
]

print("==================================================")
print("  Exp 9: Git Clone, Modify, and Push Reference    ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"{description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Changes pushed! Check your GitHub repo to see it live.")
print("==================================================")