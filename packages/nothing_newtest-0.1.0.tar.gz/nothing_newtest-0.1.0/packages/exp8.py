# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Flask Application",
        "app3.py",
        "from flask import Flask\n\n"
        "app=Flask(__name__)\n\n"
        "@app.route('/')\n"
        "def test():\n"
        "    return \"<h1>hello from flask app <h1>\"\n\n"
        "app.run(host='0.0.0.0',debug=True,port=9798)"
    ),
    (
        "Create the Requirements File (CRITICAL)",
        "requirements.txt",
        "flask"
    ),
    (
        "Create the Docker Blueprint",
        "Dockerfile",
        "FROM python:3.10-slim\n\n"
        "WORKDIR /app3\n\n"
        "COPY requirements.txt .\n"
        "RUN  pip install --no-cache-dir -r requirements.txt\n\n"
        "COPY . .\n"
        "EXPOSE 9798\n\n"
        "CMD [\"python\",\"app3.py\"]"
    ),
    (
        "Build the Docker Image",
        "Terminal Command",
        "docker build -t <username>/app3:latest ."
    ),
    (
        "Run the Docker Container",
        "Terminal Command",
        "docker run -p 9789:9798 <username>/app3:latest"
    ),
    (
        "View the Application",
        "Browser URL",
        "http://localhost:9789"
    )
]

print("==================================================")
print("  Exp 8: Flask App + Docker Reference Guide       ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Experiment 8 complete! Open the URL to verify.")
print("==================================================")