# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Server (The API)",
        "app.py",
        "from flask import Flask, jsonify, request\n\n"
        "app = Flask(__name__)\n"
        "students = {}\n"
        "int_id = 1\n\n"
        "@app.route('/getstudents', methods=['GET'])\n"
        "def get_students():\n"
        "    return jsonify(list(students.values()))\n\n"
        "@app.route('/students', methods=['POST'])\n"
        "def add_students():\n"
        "    global int_id\n"
        "    data = request.get_json()\n"
        "    students[int_id] = {'id': int_id, 'name': data['name'], 'roll': data['roll']}\n"
        "    int_id += 1\n"
        "    return jsonify(students)\n\n"
        "@app.route('/delete', methods=['POST'])\n"
        "def delete_students():\n"
        "    data = request.get_json()\n"
        "    students.pop(data['id'], None)\n"
        "    return jsonify({'status': 'deleted'})\n\n"
        "if __name__ == '__main__':\n"
        "    app.run(port=5000)"
    ),
    (
        "Create the Client (The Requester)",
        "client.py",
        "import requests\n\n"
        "url = 'http://127.0.0.1:5000'\n\n"
        "def add_student():\n"
        "    name = input('Enter name: ')\n"
        "    roll = input('Enter roll: ')\n"
        "    res = requests.post(f'{url}/students', json={'name': name, 'roll': roll})\n"
        "    print(f'Status: {res.status_code}, Response: {res.text}')\n\n"
        "def get_students():\n"
        "    res = requests.get(f'{url}/getstudents')\n"
        "    print(f'Students List: {res.text}')\n\n"
        "add_student()\n"
        "get_students()"
    ),
    (
        "Install Requirements",
        "Terminal Command",
        "pip install flask requests"
    ),
    (
        "Step 1: Start the Server",
        "Terminal 1",
        "python app.py"
    ),
    (
        "Step 2: Run the Client (While Server is running)",
        "Terminal 2",
        "python client.py"
    )
]

print("==================================================")
print("  Exp 3: Flask Client-Server Interaction Guide    ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Remember: You need TWO terminal windows open!")
print("==================================================")