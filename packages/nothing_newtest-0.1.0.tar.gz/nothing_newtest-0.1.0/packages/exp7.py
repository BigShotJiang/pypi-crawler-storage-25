# List of steps: (Action Description, File/Command Name, Exact Code/Command)
steps = [
    (
        "Create the Python Application",
        "app2.py",
        "print('hello from exp7')"
    ),
    (
        "Create the Docker Blueprint",
        "Dockerfile",
        "FROM python:3.10-slim\n"
        "WORKDIR /app2\n"
        "COPY . .\n"
        "EXPOSE 8900\n"
        "CMD [\"python\",\"app2.py\"]"
    ),
    (
        "Create the GitHub Actions Directories (Windows)",
        "Terminal Command",
        "mkdir .github\\workflows"
    ),
    (
        "Create the CI/CD Pipeline",
        ".github\\workflows\\cicd.yml",
        "on: push\n"
        "jobs:\n"
        "  b:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - run: |\n"
        "          docker login -u ${{secrets.DOCKER_USERNAME}} -p ${{secrets.DOCKER_PASSWORD}}\n"
        "          docker build -t ${{secrets.DOCKER_USERNAME}}/app2:latest .\n"
        "          docker push ${{secrets.DOCKER_USERNAME}}/app2:latest"
    ),
    (
        "Push to GitHub to Trigger the Pipeline",
        "Terminal Commands",
        "git add .\n"
        "git commit -m \"Trigger CI/CD\"\n"
        "git push"
    )
]

print("==================================================")
print("  Exp 7: Docker + GitHub Actions CI/CD Reference  ")
print("==================================================\n")

for i, (description, target, content) in enumerate(steps, start=1):
    print(f"Step {i}: {description}")
    print(f"--- [ {target} ] ---")
    print(content)
    print("-" * 30 + "\n")

print("==================================================")
print("Pipeline triggered! Check your GitHub Actions tab.")
print("==================================================")