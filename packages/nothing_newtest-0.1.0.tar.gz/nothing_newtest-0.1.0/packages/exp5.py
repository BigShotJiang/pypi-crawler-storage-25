# Experiment 5: Jenkins + Docker + GitHub Automation
# This script prints every artifact and command required.

files = {
    "app5.py": """print('Success! Hello from Experiment 5 Automated Pipeline')""",
    
    "Dockerfile": """FROM python:3.10-slim
WORKDIR /app5
COPY . .
EXPOSE 9776
CMD ["python","app5.py"]""",
    
    "Jenkinsfile": """pipeline {
    agent any
    stages {
        stage('Build & Push') {
            steps {
                sh 'docker build -t <username>/app5:latest .'
                sh 'docker push <username>/app5:latest'
            }
        }
    }
}"""
}

commands = [
    ("1. Start Jenkins Container", "docker run -d --name jenkins -p 9890:8080 -v /var/run/docker.sock:/var/run/docker.sock jenkins/jenkins:lts"),
    ("2. Get Admin Password", "docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword"),
    ("3. Install Docker in Jenkins", "docker exec -u root jenkins bash -c 'apt-get update && apt-get install -y docker.io'"),
    ("4. Fix Permissions", "docker exec -u root jenkins chmod 666 /var/run/docker.sock"),
    ("5. Log in to Docker Hub", "docker exec -it jenkins docker login"),
    ("6. Push to GitHub", "git add .\ngit commit -m 'exp5 final'\ngit push origin main")
]

def print_section(title, content):
    print("=" * 60)
    print(f"  {title}")
    print("=" * 60)
    print(content)
    print("\n")

print("EXPERIMENT 5: FULL AUTOMATION WORKFLOW\n")

# Print Files
for filename, content in files.items():
    print_section(f"FILE: {filename}", content)

# Print Commands
cmd_list = ""
for i, (desc, cmd) in enumerate(commands, start=1):
    cmd_list += f"STEP {i}: {desc}\n{cmd}\n{'-'*30}\n"
print_section("TERMINAL COMMANDS (Run in order)", cmd_list)

print_section("JENKINS UI SETUP", 
"1. URL: http://localhost:9890\n"
"2. New Item -> Pipeline -> 'exp5-job'\n"
"3. Definition: Pipeline script from SCM\n"
"4. SCM: Git\n"
"5. Branch Specifier: */main\n"
"6. Click BUILD NOW")