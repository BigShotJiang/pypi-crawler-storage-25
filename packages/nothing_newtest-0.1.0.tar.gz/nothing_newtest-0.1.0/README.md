# DevOps Lab Experiments (Exp2-Exp10)

This package provides a single class, `DevOpsExperiments`, that contains one method per experiment:

- `exp2()`
- `exp3()`
- `exp4()`
- `exp5()`
- `exp6()`
- `exp7()`
- `exp8()`
- `exp9()`
- `exp10()`

## Install

```bash
pip install nothing-newtest
```

## Use

```python
from devops_experiments import DevOpsExperiments

runner = DevOpsExperiments()
runner.exp4()
```

Or run by number:

```python
from devops_experiments import run_experiment

run_experiment(10)
```
