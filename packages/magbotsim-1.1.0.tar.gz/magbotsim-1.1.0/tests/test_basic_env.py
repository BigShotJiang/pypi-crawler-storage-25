##########################################################
# Copyright (c) 2024 Lara Bergmann, Bielefeld University #
##########################################################

import mujoco
import numpy as np
import pytest

from magbotsim import BasicMagBotEnv


@pytest.mark.parametrize(
    'num_movers, mover_params, error_expected, expected_message',
    [
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            False,
            '',
        ),
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': None},
                'mass': 0.639,
                'bumper_mass': 0.0,
            },
            False,
            '',
        ),
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': None},
                'mass': 0.639,
            },
            False,
            '',
        ),
        (
            2,
            {
                'shape': 'mesh',
                'mesh': {
                    'mover_stl_path': ['beckhoff_apm4220_mover', 'beckhoff_apm4220_mover'],
                    'bumper_stl_path': ['beckhoff_apm4220_bumper', 'beckhoff_apm4220_bumper'],
                },
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            False,
            '',
        ),
        (
            2,
            {
                'shape': 'mesh',
                'mesh': {
                    'mover_stl_path': ['beckhoff_apm4220_mover', 'beckhoff_apm4330_mover'],
                    'bumper_stl_path': ['beckhoff_apm4220_bumper', 'beckhoff_apm4330_bumper'],
                },
                'mass': np.array([0.639 - 0.034, 1.264 - 0.05]),
                'bumper_mass': np.array([0.034, 0.05]),
            },
            False,
            '',
        ),
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            True,
            "Mover shape is 'mesh', but no mover mesh file is specified.",
        ),
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': None},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            True,
            'Mover bumper mass is != 0, but no mover bumper mesh file is specified, i.e. no bumper is used.',
        ),
        (
            1,
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': None},
                'mass': 0.639 - 0.034,
                'bumper_mass': -0.034,
            },
            True,
            'Mover bumper mass is != 0, but no mover bumper mesh file is specified, i.e. no bumper is used.',
        ),
        (
            1,
            {
                'shape': 'box',
                'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]),
                'mass': 0.639,
                'bumper_mass': 0.034,
            },
            True,
            'Mover bumper mass is != 0, but no mover bumper mesh file is specified, i.e. no bumper is used.',
        ),
        (
            1,
            {
                'shape': 'box',
                'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]),
                'mass': 0.639,
                'bumper_mass': -0.034,
            },
            True,
            'Mover bumper mass is != 0, but no mover bumper mesh file is specified, i.e. no bumper is used.',
        ),
        (1, {'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.639, 'bumper_mass': 0.0}, False, ''),
        (
            1,
            {
                'shape': 'box',
                'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]),
                'mass': 0.639,
            },
            False,
            '',
        ),
    ],
)
def test_bumper_config(num_movers, mover_params, error_expected, expected_message):
    collision_params = {
        'shape': 'circle',
        'size': 0.8,
        'offset': 0.0,
        'offset_wall': 0.0,
    }
    if error_expected:
        with pytest.raises(AssertionError, match=expected_message):
            env = BasicMagBotEnv(
                layout_tiles=np.ones((4, 4)),
                num_movers=num_movers,
                mover_params=mover_params,
                initial_mover_zpos=0.001,
                collision_params=collision_params,
            )
    else:
        env = BasicMagBotEnv(
            layout_tiles=np.ones((4, 4)),
            num_movers=num_movers,
            mover_params=mover_params,
            initial_mover_zpos=0.001,
            collision_params=collision_params,
        )
        mujoco.mj_step(env.model, env.data, nstep=1)


@pytest.mark.parametrize(
    'mover_params, initial_mover_zpos',
    [
        # shape box
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.001),
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.0025),
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.0032),
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.004),
        # shape cylinder
        # shape cylinder
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.001),
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.0025),
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.0032),
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.004),
        ({'shape': 'cylinder', 'size': np.array([0.155 / 2, 0.1 / 2, 0.01]), 'mass': 1.264}, 0.001),
        ({'shape': 'cylinder', 'size': np.array([0.155 / 2, 0.1 / 2, 0.01]), 'mass': 1.264}, 0.0025),
        ({'shape': 'cylinder', 'size': np.array([0.155 / 2, 0.1 / 2, 0.01]), 'mass': 1.264}, 0.0032),
        ({'shape': 'cylinder', 'size': np.array([0.155 / 2, 0.1 / 2, 0.01]), 'mass': 1.264}, 0.004),
        # mesh files Beckhoff APM4220
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.001,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.0025,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.0032,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.004,
        ),
        # mesh files Beckhoff APM4330
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4330_mover', 'bumper_stl_path': 'beckhoff_apm4330_bumper'},
                'mass': 1.264 - 0.05,
                'bumper_mass': 0.05,
            },
            0.001,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4330_mover', 'bumper_stl_path': 'beckhoff_apm4330_bumper'},
                'mass': 1.264 - 0.05,
                'bumper_mass': 0.05,
            },
            0.0025,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4330_mover', 'bumper_stl_path': 'beckhoff_apm4330_bumper'},
                'mass': 1.264 - 0.05,
                'bumper_mass': 0.05,
            },
            0.0032,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4330_mover', 'bumper_stl_path': 'beckhoff_apm4330_bumper'},
                'mass': 1.264 - 0.05,
                'bumper_mass': 0.05,
            },
            0.004,
        ),
        # mesh files Beckhoff APM4550
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4550_mover', 'bumper_stl_path': 'beckhoff_apm4550_bumper'},
                'mass': 3.414,
                'bumper_mass': 0.01,
            },
            0.001,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4550_mover', 'bumper_stl_path': 'beckhoff_apm4550_bumper'},
                'mass': 3.414,
                'bumper_mass': 0.01,
            },
            0.0025,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4550_mover', 'bumper_stl_path': 'beckhoff_apm4550_bumper'},
                'mass': 3.414,
                'bumper_mass': 0.01,
            },
            0.0032,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4550_mover', 'bumper_stl_path': 'beckhoff_apm4550_bumper'},
                'mass': 3.414,
                'bumper_mass': 0.01,
            },
            0.004,
        ),
        # planar motor M4 XBots
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'planar_motor_M4-11-SD', 'bumper_stl_path': None},
                'mass': 2.0,
            },
            0.001,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'planar_motor_M4-11-SD', 'bumper_stl_path': None},
                'mass': 2.0,
            },
            0.0025,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'planar_motor_M4-11-SD', 'bumper_stl_path': None},
                'mass': 2.0,
            },
            0.0032,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'planar_motor_M4-11-SD', 'bumper_stl_path': None},
                'mass': 2.0,
            },
            0.004,
        ),
    ],
)
def test_initial_mover_zpos(mover_params, initial_mover_zpos):
    collision_params = {
        'shape': 'circle',
        'size': 0.8,
        'offset': 0.0,
        'offset_wall': 0.0,
    }
    env = BasicMagBotEnv(
        layout_tiles=np.ones((4, 4)),
        num_movers=1,
        mover_params=mover_params,
        initial_mover_zpos=initial_mover_zpos,
        collision_params=collision_params,
    )
    mujoco.mj_step(env.model, env.data, nstep=1)

    mover_qpos = env.get_mover_qpos(mover_names=env.mover_names, add_noise=False)
    assert mover_qpos.shape == (env.num_movers, 7)
    assert np.allclose(mover_qpos[:, 2], initial_mover_zpos)


@pytest.mark.parametrize(
    'mover_params, initial_mover_zpos',
    [
        # shape box
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.001),
        ({'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.63}, 0.004),
        # shape cylinder
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.001),
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, 0.004),
        # shape mesh
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.001,
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            0.004,
        ),
    ],
)
def test_initial_mover_zpos_slow_path(mover_params, initial_mover_zpos):
    """get_mover_qpos should apply the z adjustment correctly when called with a subset of mover
    names (slow path), not just when called with the full env.mover_names list (fast path).
    """
    collision_params = {
        'shape': 'circle',
        'size': 0.8,
        'offset': 0.0,
        'offset_wall': 0.0,
    }
    env = BasicMagBotEnv(
        layout_tiles=np.ones((4, 4)),
        num_movers=2,
        mover_params=mover_params,
        initial_mover_zpos=initial_mover_zpos,
        collision_params=collision_params,
    )
    mujoco.mj_step(env.model, env.data, nstep=1)

    # Pass a list (not the identity env.mover_names) to force the slow path for each mover
    for mover_name in env.mover_names:
        mover_qpos = env.get_mover_qpos(mover_names=[mover_name], add_noise=False)
        assert mover_qpos.shape == (1, 7)
        assert np.isclose(mover_qpos[0, 2], initial_mover_zpos), (
            f'z adjustment incorrect for mover {mover_name!r}: expected {initial_mover_zpos}, got {mover_qpos[0, 2]}'
        )


@pytest.mark.parametrize(
    'mover_params, expected_size',
    [
        # shape box
        (
            {'shape': 'box', 'size': np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]), 'mass': 0.639},
            np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]),
        ),
        (
            {'shape': 'box', 'size': np.array([0.155 / 2, 0.155 / 2, 0.012 / 2]), 'mass': 1.264},
            np.array([0.155 / 2, 0.155 / 2, 0.012 / 2]),
        ),
        (
            {'shape': 'box', 'size': np.array([0.235 / 2, 0.235 / 2, 0.012 / 2]), 'mass': 3.414},
            np.array([0.235 / 2, 0.235 / 2, 0.012 / 2]),
        ),
        # shape cylinder
        ({'shape': 'cylinder', 'size': np.array([0.113 / 2, 0.012 / 2, 0.01]), 'mass': 0.639}, np.array([0.113 / 2, 0.012 / 2, 0.01])),
        ({'shape': 'cylinder', 'size': np.array([0.155 / 2, 0.1 / 2, 0.01]), 'mass': 1.264}, np.array([0.155 / 2, 0.1 / 2, 0.01])),
        # shape mesh
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4220_mover', 'bumper_stl_path': 'beckhoff_apm4220_bumper'},
                'mass': 0.639 - 0.034,
                'bumper_mass': 0.034,
            },
            np.array([0.113 / 2, 0.113 / 2, 0.012 / 2]),
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4330_mover', 'bumper_stl_path': 'beckhoff_apm4330_bumper'},
                'mass': 1.264 - 0.05,
                'bumper_mass': 0.05,
            },
            np.array([0.155 / 2, 0.155 / 2, 0.012 / 2]),
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'beckhoff_apm4550_mover', 'bumper_stl_path': 'beckhoff_apm4550_bumper'},
                'mass': 3.414,
                'bumper_mass': 0.01,
            },
            np.array([0.235 / 2, 0.235 / 2, 0.012 / 2]),
        ),
        (
            {
                'shape': 'mesh',
                'mesh': {'mover_stl_path': 'planar_motor_M4-11-SD', 'bumper_stl_path': None},
                'mass': 2.0,
            },
            np.array([0.236 / 2, 0.156 / 2, 0.01235 / 2]),  # CAD file does not correspond to sizes on website, we use "CAD" size here
        ),
    ],
)
def test_mover_size(mover_params, expected_size):
    collision_params = {
        'shape': 'circle',
        'size': 0.8,
        'offset': 0.0,
        'offset_wall': 0.0,
    }
    env = BasicMagBotEnv(
        layout_tiles=np.ones((4, 4)),
        num_movers=1,
        mover_params=mover_params,
        initial_mover_zpos=0.002,
        collision_params=collision_params,
    )
    mujoco.mj_step(env.model, env.data, nstep=1)

    assert np.allclose(expected_size, env.mover_size)


@pytest.mark.parametrize(
    'layout_tiles, qpos, collision_params, add_safety_offset, expected_result, c_size',
    [
        # collsion shape circle, add_safety_offset = False, 0°
        (  # 0
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 1
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 2
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 3
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 4
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 5
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 6
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 7
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 8
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 9
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 10
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 11
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle'},
            False,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape box, add_safety_offset = False, 0°
        (  # 12
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 13
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 14
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 15
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 16
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 17
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 18
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 19
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 20
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 21
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 22
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 23
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape circle, add_safety_offset = True, 0°
        (  # 24
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 25
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 26
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 27
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 28
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 29
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 30
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [1] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 31
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape box, add_safety_offset = True, 0°
        (  # 32
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 33
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 34
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 35
            np.array([[1, 1], [1, 1]]),
            np.array([[0, 0.12, 0.24] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 36
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 37
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 38
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [1] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 39
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.36, 0.48] * 3, [0.24] * 3 + [0.36] * 3 + [0.48] * 3, [0] * 9, [1] * 9, [0] * 9, [0] * 9, [0] * 9]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape circle, add_safety_offset = False, 90°
        (  # 40
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 41
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 42
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 43
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 44
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 45
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 46
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 47
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 48
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 49
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1]),
            None,
        ),
        (  # 50
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 51
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle'},
            False,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape box, add_safety_offset = False
        (  # 52
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 53
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 54
            np.array([[1, 1], [1, 1]]),
            np.array(
                [[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [0.7071068] * 9, [0] * 9, [0] * 9, [0.7071068] * 9]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 55
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 56
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 57
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 58
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 59
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 60
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 61
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0]),
            None,
        ),
        (  # 62
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset_wall': 0.001},
            False,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 63
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08])},
            False,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape circle, add_safety_offset = True, 90°
        (  # 64
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 65
            np.array([[1, 1], [1, 1]]),
            np.array(
                [[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [0.7071068] * 9, [0] * 9, [0] * 9, [0.7071068] * 9]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 66
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.11, 0.111] + [0.12] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 67
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 68
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.11, 0.111],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 69
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 70
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.37, 0.369] + [0.36] * 2,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.37, 0.369],
                    [0] * 13,
                    [0.7071068] * 13,
                    [0] * 13,
                    [0] * 13,
                    [0.7071068] * 13,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 71
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'circle', 'offset': 0.005},
            True,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape box, add_safety_offset = True, 90°
        (  # 72
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 73
            np.array([[1, 1], [1, 1]]),
            np.array(
                [[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [0.7071068] * 9, [0] * 9, [0] * 9, [0.7071068] * 9]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 1, 1, 0, 1, 1]),
            None,
        ),
        (  # 74
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 75
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 1, 0, 1, 1, 0, 0, 0]),
            None,
        ),
        (  # 76
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 77
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 1, 1, 0, 1, 1, 0]),
            None,
        ),
        (  # 78
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4],
                    [0] * 14,
                    [0.7071068] * 14,
                    [0] * 14,
                    [0] * 14,
                    [0.7071068] * 14,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 79
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.7071068] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.7071068] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 1, 0, 1, 1, 0, 0, 0, 0]),
            None,
        ),
        # collsion shape box, add_safety_offset = True, 45°
        (  # 80
            np.array([[1, 1], [1, 0]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08, 0.2],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08, 0.2],
                    [0] * 15,
                    [0.9238795] * 15,
                    [0] * 15,
                    [0] * 15,
                    [0.3826834] * 15,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 81
            np.array([[1, 1], [1, 1]]),
            np.array(
                [[0, 0.12, 0.24] * 3, [0] * 3 + [0.12] * 3 + [0.24] * 3, [0] * 9, [0.9238795] * 9, [0] * 9, [0] * 9, [0.3826834] * 9]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 1]),
            None,
        ),
        (  # 82
            np.array([[1, 1], [0, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3 + [0.08, 0.081] + [0.12] * 2 + [0.08, 0.2],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4, 0.28],
                    [0] * 15,
                    [0.9238795] * 15,
                    [0] * 15,
                    [0] * 15,
                    [0.3826834] * 15,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 83
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0, 0.12, 0.24] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.9238795] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.3826834] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 1, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 84
            np.array([[1, 0], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4, 0.28],
                    [0] * 3 + [0.12] * 3 + [0.24] * 3 + [0.12] * 2 + [0.08, 0.081] + [0.08, 0.2],
                    [0] * 15,
                    [0.9238795] * 15,
                    [0] * 15,
                    [0] * 15,
                    [0.3826834] * 15,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 85
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0] * 3 + [0.12] * 3 + [0.24] * 3,
                    [0] * 9,
                    [0.9238795] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.3826834] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 1, 0, 0]),
            None,
        ),
        (  # 86
            np.array([[0, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3 + [0.4, 0.399] + [0.36] * 2 + [0.4, 0.28],
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3 + [0.36] * 2 + [0.4, 0.399] + [0.4, 0.28],
                    [0] * 15,
                    [0.9238795] * 15,
                    [0] * 15,
                    [0] * 15,
                    [0.3826834] * 15,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 87
            np.array([[1, 1], [1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [0.9238795] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0.3826834] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        # different sizes
        (  # 88
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.24], [0.24, 0.24], [0, 0], [0.9238795] * 2, [0] * 2, [0] * 2, [0.3826834] * 2]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 1]),
            np.array([[0.08, 0.08], [0.02, 0.02]]),
        ),
        (  # 89
            np.array([[1, 1], [1, 1]]),
            np.array([[0.24, 0.24], [0.24, 0.24], [0, 0], [0.9238795] * 2, [0] * 2, [0] * 2, [0.3826834] * 2]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 1]),
            np.array([[0.02, 0.08], [0.08, 0.02]]),
        ),
        (  # 90
            np.array([[1, 1], [1, 1]]),
            np.array([[0.12, 0.12], [0.12, 0.12], [0, 0], [0.9238795] * 2, [0] * 2, [0] * 2, [0.3826834] * 2]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([0, 1]),
            np.array([[0.08, 0.08], [0.02, 0.02]]),
        ),
        (  # 91
            np.array([[1, 1], [1, 1]]),
            np.array([[0.12, 0.12], [0.12, 0.12], [0, 0], [0.9238795] * 2, [0] * 2, [0] * 2, [0.3826834] * 2]).T,
            {'shape': 'box', 'size': np.array([0.08, 0.08]), 'offset': 0.01},
            True,
            np.array([1, 1]),
            np.array([[0.02, 0.08], [0.08, 0.02]]),
        ),
        # mover larger than tile
        (  # 92
            np.array([[1, 0, 1], [1, 1, 1], [1, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 93
            np.array([[1, 1, 1], [1, 1, 1], [1, 0, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 94
            np.array([[1, 1, 1], [0, 1, 1], [1, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 95
            np.array([[1, 1, 1], [1, 1, 0], [1, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 96
            np.array([[0, 1, 1], [1, 1, 1], [1, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 97
            np.array([[1, 1, 0], [1, 1, 1], [1, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 98
            np.array([[1, 1, 1], [1, 1, 1], [0, 1, 1]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
        (  # 99
            np.array([[1, 1, 1], [1, 1, 1], [1, 1, 0]]),
            np.array(
                [
                    [0.24, 0.36, 0.48] * 3,
                    [0.24] * 3 + [0.36] * 3 + [0.48] * 3,
                    [0] * 9,
                    [1] * 9,
                    [0] * 9,
                    [0] * 9,
                    [0] * 9,
                ]
            ).T,
            {'shape': 'box', 'size': np.array([0.3, 0.3]), 'offset': 0.01},
            True,
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]),
            None,
        ),
    ],
)
def test_mover_position_is_valid_check(layout_tiles, qpos, collision_params, add_safety_offset, expected_result, c_size):
    env = BasicMagBotEnv(layout_tiles=layout_tiles, num_movers=1, collision_params=collision_params)

    num_qpos = qpos.shape[0]
    pos_is_valid = env.qpos_is_valid(qpos, c_size=c_size if c_size is not None else env.c_size, add_safety_offset=add_safety_offset)

    # test output shape and result
    assert len(pos_is_valid.shape) == 1
    assert pos_is_valid.shape[0] == num_qpos
    assert (pos_is_valid == expected_result).all()
