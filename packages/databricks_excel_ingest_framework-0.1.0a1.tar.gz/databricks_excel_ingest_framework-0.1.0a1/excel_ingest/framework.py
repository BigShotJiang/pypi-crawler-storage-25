from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from excel_ingest.mapping.adapters.base import LLMAdapter
from excel_ingest.mapping.confidence import CanonicalMapping
from excel_ingest.mapping.engine import map_to_canonical
from excel_ingest.metadata import MetadataExtractionResult, extract_metadata
from excel_ingest.structure import FileProcessingConfig, FileStructureMetadata, analyze_excel_structure
from excel_ingest.validation import FileValidationResult, ValidationStatus, validate_excel_file


@dataclass
class IngestResult:
    """Full pipeline result returned by ExcelIngestFramework.ingest()."""

    file_path: str
    validation: FileValidationResult
    structure: Optional[FileStructureMetadata]
    metadata: Optional[MetadataExtractionResult]
    mappings: List[CanonicalMapping]
    success: bool
    errors: List[str] = field(default_factory=list)

    def mapping_records(self) -> List[Dict[str, Any]]:
        return [m.to_dict() for m in self.mappings]

    def metadata_records(self) -> List[Dict[str, Any]]:
        return self.metadata.to_delta_records() if self.metadata else []

    def file_record(self) -> Optional[Dict[str, Any]]:
        return self.metadata.file_metadata.to_dict() if self.metadata else None


class ExcelIngestFramework:
    """Databricks-native Excel ingestion framework.

    Orchestrates a 4-stage pipeline:
      1. validate()         — file existence, format, password, sheets
      2. detect_structure() — merged cells, multi-row headers, blank/hidden columns
      3. extract_metadata() — hierarchical headers, SHA-256 signature, section IDs
      4. map_to_canonical() — hybrid rule + optional LLM confidence mapping

    The framework works on any Python 3.9+ environment with openpyxl.
    Databricks-specific features (Volume/DBFS path detection, Foundation Models)
    are enabled automatically when running inside a Databricks cluster.

    Args:
        spark:   Optional SparkSession — not used by the framework itself but
                 available to callers who want to write Delta tables from results.
        adapter: Optional LLMAdapter instance (DatabricksAdapter / OpenAIAdapter /
                 AnthropicAdapter). If None, the mapping stage uses rules only.

    Examples::

        from excel_ingest import ExcelIngestFramework

        framework = ExcelIngestFramework(spark=spark)
        result = framework.ingest(
            file_path="/Volumes/catalog/schema/vol/data.xlsx",
            canonical_dict={"employee_id": ["emp id", "staff no"], ...},
        )

        # With a Databricks LLM adapter
        from excel_ingest.mapping.adapters.databricks import DatabricksAdapter
        adapter = DatabricksAdapter(model="databricks-llama-3-70b-instruct")
        framework = ExcelIngestFramework(spark=spark, adapter=adapter)
    """

    def __init__(
        self,
        spark=None,
        adapter: Optional[LLMAdapter] = None,
    ) -> None:
        self.spark = spark
        self.adapter = adapter

    # ------------------------------------------------------------------
    # Stage 1
    # ------------------------------------------------------------------

    def validate(
        self,
        file_path: str,
        password: Optional[str] = None,
    ) -> FileValidationResult:
        """Validate file existence, format, password protection, and sheet list."""
        return validate_excel_file(file_path, password)

    # ------------------------------------------------------------------
    # Stage 2
    # ------------------------------------------------------------------

    def detect_structure(
        self,
        file_path: str,
        config: Optional[FileProcessingConfig] = None,
        password: Optional[str] = None,
    ) -> FileStructureMetadata:
        """Detect header rows, merged cells, blank/hidden columns, and data boundaries."""
        return analyze_excel_structure(file_path, config, password)

    # ------------------------------------------------------------------
    # Stage 3
    # ------------------------------------------------------------------

    def extract_metadata(
        self,
        file_path: str,
        structure: Optional[FileStructureMetadata] = None,
        file_id: Optional[str] = None,
        password: Optional[str] = None,
        config: Optional[FileProcessingConfig] = None,
    ) -> MetadataExtractionResult:
        """Extract hierarchical column metadata and generate a header signature.

        If structure is not supplied, detect_structure() is called automatically.
        """
        if structure is None:
            structure = self.detect_structure(file_path, config, password)
        return extract_metadata(file_path, structure, file_id, password)

    # ------------------------------------------------------------------
    # Stage 4
    # ------------------------------------------------------------------

    def map_to_canonical(
        self,
        metadata: MetadataExtractionResult,
        canonical_dict: Dict[str, List[str]],
        country_code: Optional[str] = None,
        prior_mappings: Optional[Dict[str, str]] = None,
        adapter: Optional[LLMAdapter] = None,
        skip_blank_columns: bool = True,
    ) -> List[CanonicalMapping]:
        """Map column headers to canonical field names.

        Args:
            metadata:        Output of extract_metadata().
            canonical_dict:  {canonical_field: [alias1, alias2, ...]}.
                             Fully caller-supplied — no hardcoded domain.
            country_code:    ISO-2 country hint (e.g. "UK", "US", "DE").
            prior_mappings:  {hierarchical_header: canonical_field} from previous
                             runs — boosts confidence for already-seen headers.
            adapter:         Override the framework-level adapter for this call.
            skip_blank_columns: Skip blank columns (default True).
        """
        effective_adapter = adapter if adapter is not None else self.adapter
        return map_to_canonical(
            metadata_result=metadata,
            canonical_dict=canonical_dict,
            adapter=effective_adapter,
            country_code=country_code,
            prior_mappings=prior_mappings,
            skip_blank_columns=skip_blank_columns,
        )

    # ------------------------------------------------------------------
    # Full pipeline
    # ------------------------------------------------------------------

    def ingest(
        self,
        file_path: str,
        canonical_dict: Dict[str, List[str]],
        config: Optional[FileProcessingConfig] = None,
        password: Optional[str] = None,
        file_id: Optional[str] = None,
        country_code: Optional[str] = None,
        prior_mappings: Optional[Dict[str, str]] = None,
        adapter: Optional[LLMAdapter] = None,
        skip_blank_columns: bool = True,
    ) -> IngestResult:
        """Run all 4 stages in sequence and return a consolidated IngestResult.

        Stops early if validation or structure detection fails.
        """
        errors: List[str] = []

        # Stage 1
        validation = self.validate(file_path, password)
        if validation.status == ValidationStatus.FAILED:
            return IngestResult(
                file_path=file_path,
                validation=validation,
                structure=None,
                metadata=None,
                mappings=[],
                success=False,
                errors=validation.errors,
            )

        # Stage 2
        structure = self.detect_structure(file_path, config, password)
        from excel_ingest.structure import FileStatus
        if structure.status in (FileStatus.EMPTY_FILE, FileStatus.INVALID_STRUCTURE,
                                FileStatus.SHEET_NOT_SPECIFIED):
            errors.append(f"Structure detection failed: {structure.status.value}")
            return IngestResult(
                file_path=file_path,
                validation=validation,
                structure=structure,
                metadata=None,
                mappings=[],
                success=False,
                errors=errors,
            )

        # Stage 3
        metadata = extract_metadata(file_path, structure, file_id, password)

        # Stage 4
        mappings = self.map_to_canonical(
            metadata=metadata,
            canonical_dict=canonical_dict,
            country_code=country_code,
            prior_mappings=prior_mappings,
            adapter=adapter,
            skip_blank_columns=skip_blank_columns,
        )

        return IngestResult(
            file_path=file_path,
            validation=validation,
            structure=structure,
            metadata=metadata,
            mappings=mappings,
            success=True,
            errors=errors,
        )
