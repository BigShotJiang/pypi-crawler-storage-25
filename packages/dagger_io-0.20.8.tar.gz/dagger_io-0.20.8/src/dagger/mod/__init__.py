from typing_extensions import Doc

from dagger.mod._arguments import DefaultAddress
from dagger.mod._arguments import DefaultPath
from dagger.mod._arguments import Deprecated
from dagger.mod._arguments import Ignore
from dagger.mod._arguments import Name
from dagger.mod._module import Module
from dagger.mod._types import Enum


_default_mod = Module()

check = _default_mod.check
enum_type = _default_mod.enum_type
function = _default_mod.function
field = _default_mod.field
generate = _default_mod.generate
interface = _default_mod.interface
object_type = _default_mod.object_type
up = _default_mod.up


def default_module() -> Module:
    """Return the default Module builder instance."""
    return _default_mod


__all__ = [
    "DefaultAddress",
    "DefaultPath",
    "Deprecated",
    "Doc",  # Only re-exported because it's in `typing_extensions`.
    "Enum",
    "Ignore",
    "Name",
    "check",
    "enum_type",
    "field",
    "function",
    "generate",
    "interface",
    "object_type",
    "up",
]
