import configparser
import json
import os
import time
from pathlib import Path
from typing import cast
import httpx
import jwt as pyjwt
from rich.console import Console

from dtxapps.constants import (
    AUTH_REFRESH,
    CREDS_DIR_NAME,
    DEFAULT_API_URL,
    DEFAULT_OUTPUT_FORMAT,
    DEFAULT_PROFILE,
    ENV_API_KEY,
    ENV_API_URL,
    FETCH_ALL_PAGES_LIMIT,
    HTTP_OK,
    HTTP_TIMEOUT,
    PROFILES_FILE,
    RESPONSE_KEY_ITEMS,
    RESPONSE_KEY_NEXT_CURSOR,
    TOKEN_EXPIRY_BUFFER_SECONDS,
)

CREDS_DIR = Path.home() / CREDS_DIR_NAME
TOKENS_FILE = CREDS_DIR / "tokens"  # JWTs — cleared on logout
console = Console(stderr=True)
_DEFAULT_API_URL = DEFAULT_API_URL

_debug: bool = False
_profile: str = DEFAULT_PROFILE
_profile_explicitly_set: bool = False
_output: str = DEFAULT_OUTPUT_FORMAT


def set_debug(val: bool) -> None:
    global _debug
    _debug = val


def is_debug() -> bool:
    return _debug


def set_profile(val: str, explicit: bool = False) -> None:
    global _profile, _profile_explicitly_set
    _profile = val
    if explicit:
        _profile_explicitly_set = True


def get_profile() -> str:
    return _profile


def set_output(val: str) -> None:
    global _output
    _output = val


def get_output() -> str:
    return _output


def _load_cfg(path: Path) -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    if path.exists():
        cfg.read(path)
    return cfg


def _save_cfg(cfg: configparser.ConfigParser, path: Path) -> None:
    CREDS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    CREDS_DIR.chmod(0o700)  # enforce even if dir already existed (mkdir mode is umask-filtered)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        cfg.write(f)


# ── Profile config (URL + api_key — persistent, never auto-cleared) ──────────


def save_profile(*, profile: str, url: str, api_key: str | None = None) -> None:
    """Persist the API URL (and optional api_key) for a profile."""
    cfg = _load_cfg(PROFILES_FILE)
    if not cfg.has_section(profile):
        cfg.add_section(profile)
    cfg[profile]["auth_service_url"] = url.rstrip("/")
    if api_key is not None:
        cfg[profile]["api_key"] = api_key
    elif "api_key" in cfg[profile]:
        del cfg[profile]["api_key"]
    _save_cfg(cfg, PROFILES_FILE)


def load_profile(profile: str = "default") -> dict | None:  # type: ignore[type-arg]
    """Return profile config dict with auth_service_url and api_key, or None if not set."""
    cfg = _load_cfg(PROFILES_FILE)
    if not cfg.has_section(profile):
        return None
    s = cfg[profile]
    return {
        "auth_service_url": s.get("auth_service_url") or None,
        "api_key": s.get("api_key") or None,
    }


def remove_profile(profile: str = "default") -> None:
    """Remove a profile from both PROFILES_FILE and TOKENS_FILE."""
    for path in (PROFILES_FILE, TOKENS_FILE):
        cfg = _load_cfg(path)
        if cfg.has_section(profile):
            cfg.remove_section(profile)
            _save_cfg(cfg, path)


# Backwards-compat shims used by login.py (load_url) and older call sites
def save_url(*, profile: str, url: str) -> None:
    save_profile(profile=profile, url=url)


def load_url(profile: str = "default") -> str | None:
    p = load_profile(profile)
    return p["auth_service_url"] if p else None


# ── User credentials (explicit logins) ───────────────────────────────────────


def save_credentials(
    *,
    profile: str,
    access_token: str,
    refresh_token: str,
    refresh_token_expires_in: int,
) -> None:
    cfg = _load_cfg(TOKENS_FILE)
    _prune_expired_sections(cfg)
    if not cfg.has_section(profile):
        cfg.add_section(profile)
    cfg[profile]["access_token"] = access_token
    cfg[profile]["refresh_token"] = refresh_token
    cfg[profile]["refresh_token_expires_at"] = str(int(time.time()) + refresh_token_expires_in)
    _save_cfg(cfg, TOKENS_FILE)


def load_credentials(profile: str = "default") -> dict | None:  # type: ignore[type-arg]
    prof = load_profile(profile)
    tok_cfg = _load_cfg(TOKENS_FILE)
    if _prune_expired_sections(tok_cfg):
        _save_cfg(tok_cfg, TOKENS_FILE)
    # Return None only if profile is completely unknown
    if prof is None and not tok_cfg.has_section(profile):
        return None
    url = (prof or {}).get("auth_service_url") or DEFAULT_API_URL
    api_key = (prof or {}).get("api_key") or None
    tok = tok_cfg[profile] if tok_cfg.has_section(profile) else {}
    return {
        "auth_service_url": url,
        "api_key": api_key,
        "access_token": tok.get("access_token", ""),  # type: ignore[union-attr]
        "refresh_token": tok.get("refresh_token", ""),  # type: ignore[union-attr]
    }


def clear_credentials(profile: str = "default") -> None:
    """Clear JWT tokens only. Profile config (URL, api_key) is preserved."""
    cfg = _load_cfg(TOKENS_FILE)
    if cfg.has_section(profile):
        cfg.remove_section(profile)
        _save_cfg(cfg, TOKENS_FILE)


# ── App tokens (env API key cache) ───────────────────────────────────────────


def _prune_expired_sections(cfg: configparser.ConfigParser) -> bool:
    """Remove sections whose refresh_token_expires_at is in the past. Returns True if anything was removed."""
    now = int(time.time())
    expired = [s for s in cfg.sections() if cfg[s].get("refresh_token_expires_at") and int(cfg[s]["refresh_token_expires_at"]) < now]
    for s in expired:
        cfg.remove_section(s)
    return bool(expired)


def _token_expired(token):
    try:
        claims = pyjwt.decode(token, options={"verify_signature": False}, algorithms=["RS256"])
        return int(claims.get("exp", 0)) < int(time.time()) + TOKEN_EXPIRY_BUFFER_SECONDS
    except Exception:
        return True


def _env_profile(api_key: str) -> str:
    import hashlib

    return "env-" + hashlib.sha256(api_key.encode()).hexdigest()[:8]


def _exchange_api_key(api_key: str, base_url: str) -> dict | None:
    """Exchange an API key for access+refresh tokens. Returns token dict or None on failure."""
    try:
        resp = httpx.post(
            f"{base_url.rstrip('/')}/auth/token",
            json={"api_key": api_key},
            timeout=HTTP_TIMEOUT,
        )
        if resp.status_code == HTTP_OK:
            return resp.json()  # type: ignore[no-any-return]
        console.print(f"[red]API key authentication failed:[/red] {resp.json().get('detail', resp.text)}")
    except httpx.RequestError as e:
        console.print(f"[red]Could not reach API:[/red] {e}")
    return None


class AuthClient:
    def __init__(
        self,
        base_url: str,
        access_token: str,
        refresh_token: str,
        profile: str = "default",
        api_key: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.profile = profile
        self.api_key = api_key

    def _persist(
        self,
        access_token: str,
        refresh_token: str,
        refresh_token_expires_in: int,
    ) -> None:
        if not self.profile:
            return
        save_credentials(
            profile=self.profile,
            access_token=access_token,
            refresh_token=refresh_token,
            refresh_token_expires_in=refresh_token_expires_in,
        )

    def _req(self, method: str, url: str, **kw) -> httpx.Response:
        if _debug:
            body = kw.get("json")
            console.print(f"[bold cyan]DEBUG →[/bold cyan] {method} {url}", highlight=False)
            if body is not None:
                console.print_json(json.dumps(body, default=str))
        t0 = time.monotonic()
        resp = cast(httpx.Response, getattr(httpx, method.lower())(url, **kw))
        if _debug:
            elapsed = int((time.monotonic() - t0) * 1000)
            color = "green" if resp.is_success else "red"
            console.print(
                f"[bold {color}]DEBUG ←[/bold {color}] {resp.status_code} ({elapsed}ms)",
                highlight=False,
            )
            try:
                console.print_json(json.dumps(resp.json(), default=str))
            except Exception:
                if resp.text:
                    console.print(f"  {resp.text[:500]}")
        return resp

    def _maybe_refresh(self):
        if not _token_expired(self.access_token):
            return
        # Try refresh token first
        resp = self._req(
            "POST",
            f"{self.base_url}{AUTH_REFRESH}",
            json={"refresh_token": self.refresh_token},
            timeout=HTTP_TIMEOUT,
        )
        if resp.status_code == HTTP_OK:
            data = resp.json()
            self.access_token = data["access_token"]
            self.refresh_token = data["refresh_token"]
            self._persist(
                self.access_token,
                self.refresh_token,
                data["refresh_token_expires_in"],
            )
            return
        # Refresh failed — fall back to API key if available
        if self.api_key:
            data = _exchange_api_key(self.api_key, self.base_url)
            if data:
                self.access_token = data["access_token"]
                self.refresh_token = data["refresh_token"]
                self._persist(
                    self.access_token,
                    self.refresh_token,
                    data["refresh_token_expires_in"],
                )
                return
            raise SystemExit(1)
        console.print("[red]Session expired.[/red] Run: dtxapps auth login")
        raise SystemExit(1)

    def _h(self):
        self._maybe_refresh()
        return {"Authorization": f"Bearer {self.access_token}"}

    def current_identity_id(self) -> str | None:
        try:
            claims = pyjwt.decode(
                self.access_token,
                options={"verify_signature": False},
                algorithms=["RS256"],
            )
            return claims.get("sub")
        except Exception:
            return None

    def proactive_refresh(self) -> None:
        """Force a token refresh regardless of expiry and persist the new tokens."""
        resp = self._req(
            "POST",
            f"{self.base_url}{AUTH_REFRESH}",
            json={"refresh_token": self.refresh_token},
            timeout=HTTP_TIMEOUT,
        )
        if resp.status_code == HTTP_OK:
            data = resp.json()
            self.access_token = data["access_token"]
            self.refresh_token = data["refresh_token"]
            self._persist(
                self.access_token,
                self.refresh_token,
                data["refresh_token_expires_in"],
            )

    def get(self, path, no_auth: bool = False, **kw):
        return self._req(
            "GET",
            f"{self.base_url}{path}",
            headers={} if no_auth else self._h(),
            timeout=HTTP_TIMEOUT,
            **kw,
        )

    def fetch_all_pages(self, path: str, *, limit: int = FETCH_ALL_PAGES_LIMIT) -> list:
        """Fetch all pages from a cursor-paginated endpoint and return the combined items list."""
        items: list = []
        cursor: str | None = None
        sep = "&" if "?" in path else "?"
        while True:
            url = f"{path}{sep}limit={limit}"
            if cursor:
                url = f"{url}&cursor={cursor}"
            r = self.get(url)
            if not r.is_success:
                return items
            data = r.json()
            items.extend(data.get(RESPONSE_KEY_ITEMS, []))
            cursor = data.get(RESPONSE_KEY_NEXT_CURSOR)
            if not cursor:
                break
        return items

    def post(self, path, *, no_auth: bool = False, **kw):
        return self._req(
            "POST",
            f"{self.base_url}{path}",
            headers={} if no_auth else self._h(),
            timeout=HTTP_TIMEOUT,
            **kw,
        )

    def patch(self, path, **kw):
        return self._req(
            "PATCH",
            f"{self.base_url}{path}",
            headers=self._h(),
            timeout=HTTP_TIMEOUT,
            **kw,
        )

    def put(self, path, **kw):
        return self._req(
            "PUT",
            f"{self.base_url}{path}",
            headers=self._h(),
            timeout=HTTP_TIMEOUT,
            **kw,
        )

    def delete(self, path, **kw):
        return self._req(
            "DELETE",
            f"{self.base_url}{path}",
            headers=self._h(),
            timeout=HTTP_TIMEOUT,
            **kw,
        )


def _build_env_client(env_api_key: str, env_api_url: str) -> "AuthClient":
    env_profile = _env_profile(env_api_key)
    creds = load_credentials(env_profile)
    if not creds or not creds.get("access_token"):
        data = _exchange_api_key(env_api_key, env_api_url)
        if not data:
            raise SystemExit(1)
        save_credentials(
            profile=env_profile,
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            refresh_token_expires_in=data["refresh_token_expires_in"],
        )
        access_token = data["access_token"]
        refresh_token = data["refresh_token"]
    else:
        access_token = creds["access_token"]
        refresh_token = creds["refresh_token"]
    return AuthClient(
        base_url=env_api_url,
        access_token=access_token,
        refresh_token=refresh_token,
        profile=env_profile,
        api_key=env_api_key,
    )


def _exchange_profile_api_key(creds: dict, profile: str) -> dict:  # type: ignore[type-arg]
    profile_api_key = creds["api_key"]
    base_url = creds["auth_service_url"]
    data = _exchange_api_key(profile_api_key, base_url)
    if not data:
        raise SystemExit(1)
    save_credentials(
        profile=profile,
        access_token=data["access_token"],
        refresh_token=data["refresh_token"],
        refresh_token_expires_in=data["refresh_token_expires_in"],
    )
    return {
        "auth_service_url": base_url,
        "api_key": profile_api_key,
        "access_token": data["access_token"],
        "refresh_token": data["refresh_token"],
    }


def _print_not_authenticated(profile: str) -> None:
    saved_url = load_url(profile)
    console.print("[yellow]Not authenticated.[/yellow] Choose one:\n")
    console.print("  [bold]Interactive login:[/bold]")
    if saved_url:
        console.print(f"    dtxapps auth login        [dim]# URL already configured: {saved_url}[/dim]")
    else:
        console.print(f"    dtxapps config set-profile --url {DEFAULT_API_URL}")
        console.print("    dtxapps auth login")
    console.print("\n  [bold]API key (profile):[/bold]")
    console.print(f"    dtxapps config set-profile --url {DEFAULT_API_URL} --api-key <key>")
    console.print("\n  [bold]API key (env):[/bold]")
    console.print(f"    export {ENV_API_URL}={DEFAULT_API_URL}")
    console.print(f"    export {ENV_API_KEY}=<your-api-key>")


def fetch_api_url_from_website(url: str) -> tuple[str, bool]:
    """Try to resolve the API URL from a website's /config.json endpoint.

    Returns (resolved_url, was_resolved). Falls back silently on any error.
    """
    base = url.rstrip("/")
    try:
        resp = httpx.get(f"{base}/config.json", timeout=3.0)
        if resp.is_success:
            data = resp.json()
            if "authServiceUrl" in data:
                return (data["authServiceUrl"].rstrip("/"), True)
    except (httpx.RequestError, ValueError):
        pass
    return (base, False)


def get_client(profile: str = "") -> "AuthClient":
    if not profile:
        profile = get_profile()
    env_api_key = os.environ.get(ENV_API_KEY)
    env_api_url = os.environ.get(ENV_API_URL, _DEFAULT_API_URL)
    if env_api_key:
        if _profile_explicitly_set:
            console.print(
                f"[red]Error:[/red] {ENV_API_KEY} is set in the environment but --profile '{profile}' was also specified. "
                "Use one or the other, not both."
            )
            raise SystemExit(1)
        resolved_url, _ = fetch_api_url_from_website(env_api_url)
        return _build_env_client(env_api_key, resolved_url)
    creds = load_credentials(profile)
    if creds and creds.get("api_key") and not creds.get("access_token"):
        creds = _exchange_profile_api_key(creds, profile)
    if not creds or not creds.get("access_token"):
        _print_not_authenticated(profile)
        raise SystemExit(1)
    return AuthClient(
        base_url=creds["auth_service_url"],
        access_token=creds["access_token"],
        refresh_token=creds["refresh_token"],
        profile=profile,
        api_key=creds.get("api_key"),
    )


def run_api(
    method: str,
    path: str,
    *,
    action: str,
    no_content: bool = False,
    **kwargs: object,
) -> httpx.Response:
    """Get an authenticated client, make one HTTP call, and assert success.

    Args:
        method:     HTTP method: "get", "post", "put", "patch", "delete".
        path:       URL path relative to the API base.
        action:     Human-readable description for error messages.
        no_content: If True, assert HTTP 204 instead of any 2xx success.
        **kwargs:   Forwarded to the httpx method (json=, params=, etc.).
    """
    from dtxapps.output import check_response, expect_no_content

    c = get_client()
    r: httpx.Response = getattr(c, method.lower())(path, **kwargs)
    if no_content:
        expect_no_content(r, action)
    else:
        check_response(r, action)
    return r
