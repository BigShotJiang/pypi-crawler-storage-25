import json
from collections.abc import Callable
from rich.console import Console
from rich.table import Table
from dtxapps.constants import (
    HTTP_NO_CONTENT,
    RESPONSE_KEY_ITEMS,
    RESPONSE_KEY_NEXT_CURSOR,
)
from dtxapps.context import get_output

console = Console()
err = Console(stderr=True)


def print_json(data):
    console.print_json(json.dumps(data, default=str))


def print_table(rows, columns, title=None):
    if not rows:
        err.print("[dim]No results.[/dim]")
        return
    t = Table(title=title, show_header=True, header_style="bold cyan")
    for col in columns:
        t.add_column(col)
    for row in rows:
        t.add_row(*[str(row.get(c, "")) for c in columns])
    console.print(t)


def print_kv(data, title=None):
    t = Table(title=title, show_header=False, box=None, padding=(0, 2))
    t.add_column("key", style="bold cyan", no_wrap=True)
    t.add_column("value", style="white")
    for k, v in data.items():
        t.add_row(k, str(v) if v is not None else "[dim]—[/dim]")
    console.print(t)


def render_object(data: dict, title: str | None = None) -> None:
    if get_output() == "json":
        print_json(data)
    else:
        print_kv(data, title=title)


def render_success(message: str) -> None:
    if get_output() == "json":
        print_json({"success": True})
    else:
        console.print(message)


def render_paged_response(
    data: dict,
    columns: list[str],
    title: str,
    *,
    transform: Callable[[list], None] | None = None,
) -> None:
    items = data.get(RESPONSE_KEY_ITEMS, [])
    next_cursor = data.get(RESPONSE_KEY_NEXT_CURSOR)
    if get_output() == "json":
        print_json({"items": items, "next_cursor": next_cursor})
    else:
        if transform:
            transform(items)
        print_table(items, columns, title=title)
        if next_cursor:
            console.print(f"\n[dim]Next page: --cursor {next_cursor}[/dim]")


def handle_error(resp, action):
    try:
        detail = resp.json().get("detail", resp.text)
    except Exception:
        detail = resp.text
    err.print(f"[red]Error {action}[/red]: {detail} (HTTP {resp.status_code})")
    raise SystemExit(1)


def check_response(resp, action: str) -> None:
    if not resp.is_success:
        handle_error(resp, action)


def expect_no_content(r, action: str) -> None:
    if r.status_code != HTTP_NO_CONTENT:
        handle_error(r, action)


def refresh_session(client) -> None:
    try:
        client.proactive_refresh()
        console.print("[cyan]↻ Your session has been updated with new claims.[/cyan]")
    except Exception:
        console.print("[yellow]Warning: session refresh failed — re-run 'dtxapps auth login' if you see stale data[/yellow]")
