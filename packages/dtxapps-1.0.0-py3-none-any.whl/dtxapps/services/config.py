import typer
from rich.console import Console
from dtxapps.constants import DEFAULT_PROFILE, PROFILES_FILE
import dtxapps.context as _ctx
from dtxapps.context import _load_cfg, fetch_api_url_from_website, save_profile, load_profile, remove_profile

app = typer.Typer(no_args_is_help=True)
_c = Console()


@app.command("set-profile")
def set_profile(
    name: str = typer.Option(DEFAULT_PROFILE, "--name", "-n", help="Profile name"),
    url: str = typer.Option(
        ...,
        "--url",
        "-u",
        help="Website URL or API URL (e.g. https://admin.yourdomain.com)",
    ),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        help="API key for this profile (optional — enables auto-auth without dtxapps auth login)",
    ),
):
    """Set the DTXApps URL (and optional API key) for a named profile."""
    resolved, was_resolved = fetch_api_url_from_website(url)
    if was_resolved:
        _c.print(f"[dim]Resolved API URL from config.json: {resolved}[/dim]")
    save_profile(profile=name, url=resolved, api_key=api_key)
    _c.print(f"[green]✓ Profile saved.[/green] [bold]{name}[/bold] → [bold]{resolved}[/bold]")
    if api_key:
        masked = "*" * (len(api_key) - 4) + api_key[-4:]
        _c.print(f"  api_key: [dim]{masked}[/dim]")
    _c.print(f"[dim]Stored in {PROFILES_FILE}[/dim]")
    if not api_key:
        _c.print("\nNext step: [bold]dtxapps auth login[/bold]")


@app.command("get-profile")
def get_profile(
    name: str = typer.Option(DEFAULT_PROFILE, "--name", "-n", help="Profile name"),
):
    """Show the configured URL and API key for a named profile."""
    prof = load_profile(name)
    if not prof or not prof.get("auth_service_url"):
        _c.print(f"[yellow]No profile configured for '{name}'.[/yellow]")
        _c.print("Run: [bold]dtxapps config set-profile --url <url>[/bold]")
        raise typer.Exit(1)
    _c.print(f"Profile [bold]{name}[/bold]:")
    _c.print(f"  url:     [bold]{prof['auth_service_url']}[/bold]")
    if prof.get("api_key"):
        key = prof["api_key"]
        masked = "*" * (len(key) - 4) + key[-4:]
        _c.print(f"  api_key: [dim]{masked}[/dim]")
    else:
        _c.print("  api_key: [dim]not configured[/dim]")


@app.command("list-profiles")
def list_profiles() -> None:
    """List all configured profiles."""
    cfg = _load_cfg(PROFILES_FILE)
    sections = cfg.sections()
    active = _ctx.get_profile()
    if not sections:
        _c.print("[yellow]No profiles configured.[/yellow]")
        _c.print("Run: [bold]dtxapps config set-profile --url <url>[/bold]")
        return
    for name in sections:
        marker = "[green]●[/green]" if name == active else " "
        url = cfg[name].get("auth_service_url", "[dim]not set[/dim]")
        key = cfg[name].get("api_key")
        masked_key = "*" * (len(key) - 4) + key[-4:] if key else None
        _c.print(f"{marker} [bold]{name}[/bold]  {url}")
        if masked_key:
            _c.print(f"    api_key: [dim]{masked_key}[/dim]")


@app.command("delete-profile")
def delete_profile(
    name: str = typer.Option(DEFAULT_PROFILE, "--name", "-n", help="Profile name"),
):
    """Delete a named profile (removes URL, API key, and any stored tokens)."""
    remove_profile(name)
    _c.print(f"[green]✓ Profile deleted.[/green] [bold]{name}[/bold]")
    _c.print(f"[dim]Removed from {PROFILES_FILE}[/dim]")
