from typing import Any

import typer
from dtxapps.cli_utils import (
    build_page_params,
    confirm_option,
    require_confirm,
)
from dtxapps.constants import (
    AUTH_IDENTITIES_BASE,
    AUTH_ROLES_BASE,
    DEFAULT_PAGE_SIZE,
)
from dtxapps.context import get_client, run_api
from dtxapps.output import (
    expect_no_content,
    console,
    render_paged_response,
    render_object,
    render_success,
    refresh_session,
)

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_roles(
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size", help="Number of results per page"),
    cursor: str = typer.Option(None, "--cursor", help="Cursor for next page"),
):
    """List all roles."""
    params = build_page_params(page_size, cursor)
    r = run_api("get", AUTH_ROLES_BASE, action="listing roles", params=params)
    render_paged_response(r.json(), ["role_id", "name", "description"], "Roles")


@app.command("create")
def create_role(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    scope: list[str] = typer.Option([], "--scope", "-s", help="Scope to attach (repeatable)"),
):
    """Create a new role."""
    payload: dict[str, Any] = {"name": name, "description": description}
    if scope:
        payload["scopes"] = list(scope)
    r = run_api("post", AUTH_ROLES_BASE, action="creating role", json=payload)
    console.print("[green]✓ Created.[/green]")
    render_object(r.json())


@app.command("set-scopes")
def set_role_scopes(
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
    scope: list[str] = typer.Option(..., "--scope", "-s", help="Scope to set (repeatable; replaces all existing)"),
):
    """Set (replace) all scopes on a role."""
    run_api("patch", f"{AUTH_ROLES_BASE}/{role_id}/scopes", action="updating role scopes", json={"scopes": list(scope)})
    render_success("[green]✓ Scopes updated.[/green]")


@app.command("delete")
def delete_role(
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
    confirm: bool = confirm_option("Delete this role?"),
):
    """Delete a role."""
    require_confirm(confirm)
    run_api("delete", f"{AUTH_ROLES_BASE}/{role_id}", action="deleting role", no_content=True)
    render_success("[green]✓ Deleted.[/green]")


@app.command("assign")
def assign_role(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
    expires_at: str = typer.Option(None, "--expires-at"),
):
    """Assign a role to an identity."""
    payload = {}
    if expires_at:
        payload["expires_at"] = expires_at
    c = get_client()
    r = c.put(f"{AUTH_IDENTITIES_BASE}/{identity_id}/roles/{role_id}", json=payload)
    expect_no_content(r, "assigning role")
    render_success(f"[green]✓ Role {role_id} assigned to {identity_id}.[/green]")
    refresh_session(c)


@app.command("remove")
def remove_role(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
):
    """Remove a role from an identity."""
    c = get_client()
    r = c.delete(f"{AUTH_IDENTITIES_BASE}/{identity_id}/roles/{role_id}")
    expect_no_content(r, "removing role")
    console.print(f"[green]✓ Role {role_id} removed from {identity_id}.[/green]")
    refresh_session(c)


@app.command("list-for-identity")
def list_identity_roles(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
):
    """List directly assigned roles for a specific identity."""
    r = run_api("get", f"{AUTH_IDENTITIES_BASE}/{identity_id}/roles", action="fetching roles")
    render_paged_response(r.json(), ["role_id", "name", "description"], f"Roles — {identity_id}")


@app.command("effective-for-identity")
def list_effective_roles(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size", help="Results per page"),
    cursor: str | None = typer.Option(None, "--cursor", help="Pagination cursor"),
):
    """List effective roles for an identity (direct + group-inherited)."""
    r = run_api(
        "get",
        f"{AUTH_IDENTITIES_BASE}/{identity_id}/effective-roles",
        action="fetching effective roles",
        params=build_page_params(page_size, cursor),
    )
    render_paged_response(
        r.json(),
        ["role_id", "name", "description"],
        f"Effective Roles — {identity_id}",
    )
