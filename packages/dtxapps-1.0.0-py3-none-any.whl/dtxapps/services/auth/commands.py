import typer
from dtxapps.services.auth import (
    login,
    whoami,
    identities,
    roles,
    api_keys,
    groups,
    settings,
    sessions,
)

auth_app = typer.Typer(no_args_is_help=True)
auth_app.command("login")(login.login)
auth_app.command("logout")(login.logout)
auth_app.command("whoami")(whoami.whoami)
auth_app.add_typer(identities.app, name="identities", help="Manage identities")
auth_app.add_typer(roles.app, name="roles", help="Manage roles")
auth_app.add_typer(api_keys.app, name="api-keys", help="Manage API keys")
auth_app.add_typer(groups.app, name="groups", help="Manage groups")
auth_app.add_typer(settings.app, name="settings", help="Manage service configuration")
auth_app.add_typer(sessions.app, name="sessions", help="Manage auth sessions")
