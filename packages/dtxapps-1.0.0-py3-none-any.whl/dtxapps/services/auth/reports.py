import httpx
import typer
from dtxapps.constants import REPORTS_BASE, REPORTS_COMPLIANCE_REPORT
from dtxapps.context import run_api
from dtxapps.output import render_paged_response

app = typer.Typer(no_args_is_help=True)

_REPORT_COLUMNS = ["report_id", "report_type", "status", "created_at", "requested_by"]


@app.command("generate")
def generate_report() -> None:
    """Trigger async compliance report generation."""
    r = run_api("post", REPORTS_COMPLIANCE_REPORT, action="requesting compliance report")
    if r:
        data = r.json()
        typer.echo(f"Report generation started: {data.get('report_id')}")
        typer.echo(f"Status: {data.get('status')}")


@app.command("list")
def list_reports() -> None:
    """List all generated reports."""
    r = run_api("get", REPORTS_BASE, action="listing reports")
    if r is not None:
        render_paged_response(r.json(), _REPORT_COLUMNS, "Reports")


@app.command("download")
def download_report(
    report_id: str = typer.Argument(..., help="Report ID to download"),
    output_file: str = typer.Option("compliance-report.xlsx", "--output", "-o", help="Output file path"),
) -> None:
    """Download a compliance report XLSX by ID."""
    r = run_api("get", f"{REPORTS_BASE}/{report_id}/download", action="getting download URL")
    if r is None:
        raise typer.Exit(1)
    if r.status_code == 409:
        typer.echo("Report is not yet ready. Check status with `dtxapps reports list`.", err=True)
        raise typer.Exit(1)
    if r.status_code == 404:
        typer.echo(f"Report {report_id} not found.", err=True)
        raise typer.Exit(1)
    download_url = r.json()["download_url"]
    try:
        file_resp = httpx.get(download_url, follow_redirects=True, timeout=30)
        file_resp.raise_for_status()
        with open(output_file, "wb") as f:
            f.write(file_resp.content)
        typer.echo(f"Downloaded: {output_file}")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error downloading file: {e.response.status_code}", err=True)
        raise typer.Exit(1)
