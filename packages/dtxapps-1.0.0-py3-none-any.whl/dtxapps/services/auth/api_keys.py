import typer
from typing import Any, Optional
from dtxapps.cli_utils import confirm_option, require_confirm
from dtxapps.constants import (
    AUTH_IDENTITIES_BASE,
)
from dtxapps.context import get_output, run_api
from dtxapps.output import (
    print_kv,
    print_json,
    render_paged_response,
    render_success,
)
from rich.console import Console

app = typer.Typer(no_args_is_help=True)
_c = Console()


@app.command("list")
def list_api_keys(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
):
    """List API keys for an identity."""
    r = run_api("get", f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys", action="listing API keys")
    render_paged_response(
        r.json(),
        [
            "api_key_id",
            "name",
            "key_prefix",
            "status",
            "allowed_role_ids",
            "last_used_at",
            "expires_at",
        ],
        f"API Keys — {identity_id}",
    )


@app.command("create")
def create_api_key(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    name: str = typer.Option(..., "--name", "-n"),
    expires_at: str = typer.Option(None, "--expires-at"),
    allowed_role_ids: Optional[str] = typer.Option(
        None,
        "--allowed-role-ids",
        help="Comma-separated role IDs to restrict this key's permissions",
    ),
):
    """Create an API key. Raw key shown ONCE."""
    payload: dict[str, Any] = {"name": name}
    if expires_at:
        payload["expires_at"] = expires_at
    if allowed_role_ids:
        payload["allowed_role_ids"] = [r.strip() for r in allowed_role_ids.split(",")]
    r = run_api("post", f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys", action="creating API key", json=payload)
    data = r.json()
    if get_output() == "json":
        print_json(data)
    else:
        _c.print("\n[bold green]✓ API key created.[/bold green]")
        _c.print("[bold yellow]Save this key — it will not be shown again:[/bold yellow]")
        _c.print(f"\n  [bold white]{data['raw_key']}[/bold white]\n")
        print_kv({k: v for k, v in data.items() if k != "raw_key"})


@app.command("revoke")
def revoke_api_key(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    api_key_id: str = typer.Option(..., "--api-key-id", help="API key ID"),
    confirm: bool = confirm_option("Revoke this API key?"),
):
    """Revoke an API key."""
    require_confirm(confirm)
    run_api("post", f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys/{api_key_id}/revoke", action="revoking API key", no_content=True)
    render_success("[green]✓ Revoked.[/green]")


@app.command("reauthorize")
def reauthorize_api_key(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    api_key_id: str = typer.Option(..., "--api-key-id", help="API key ID"),
    confirm: bool = confirm_option("Reauthorize this API key?"),
):
    """Reauthorize a previously revoked API key."""
    require_confirm(confirm)
    run_api("post", f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys/{api_key_id}/reauthorize", action="reauthorizing API key", no_content=True)
    render_success("[green]✓ Reauthorized.[/green]")


@app.command("delete")
def delete_api_key(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    api_key_id: str = typer.Option(..., "--api-key-id", help="API key ID"),
    confirm: bool = confirm_option("Permanently delete this API key?"),
):
    """Permanently delete an API key."""
    require_confirm(confirm)
    run_api("delete", f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys/{api_key_id}", action="deleting API key", no_content=True)
    render_success("[green]✓ Deleted.[/green]")


@app.command("update-scopes")
def update_api_key_scopes(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    api_key_id: str = typer.Option(..., "--api-key-id", help="API key ID"),
    allowed_role_ids: Optional[str] = typer.Option(
        None,
        "--allowed-role-ids",
        help="Comma-separated role IDs. Omit to clear all restrictions.",
    ),
):
    """Update the role restrictions on an API key. Omit --allowed-role-ids to clear restrictions."""
    role_ids = [r.strip() for r in allowed_role_ids.split(",")] if allowed_role_ids else None
    run_api(
        "patch",
        f"{AUTH_IDENTITIES_BASE}/{identity_id}/api-keys/{api_key_id}/scopes",
        action="updating API key scopes",
        no_content=True,
        json={"allowed_role_ids": role_ids},
    )
    render_success("[green]✓ Scopes updated.[/green]")
