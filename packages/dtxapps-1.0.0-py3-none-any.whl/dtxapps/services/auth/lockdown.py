import typer
from dtxapps.context import run_api
from dtxapps.output import console, print_json, render_success

app = typer.Typer(no_args_is_help=True)

_DEFAULT_MESSAGE = "Service temporarily unavailable for maintenance. Please try again later."


@app.command("status")
def status() -> None:
    """Show current lockdown status."""
    r = run_api("get", "/auth/lockdown", action="fetching lockdown status")
    data = r.json()
    from dtxapps.context import get_output

    if get_output() == "json":
        print_json(data)
    else:
        active = data.get("active", False)
        state = "[bold red]ACTIVE[/bold red]" if active else "[green]inactive[/green]"
        console.print(f"Lockdown: {state}")
        if active:
            if data.get("message"):
                console.print(f"  Message:      {data['message']}")
            if data.get("activated_at"):
                console.print(f"  Activated at: {data['activated_at']}")
            if data.get("activated_by"):
                console.print(f"  Activated by: {data['activated_by']}")


@app.command("activate")
def activate(
    message: str = typer.Option(
        _DEFAULT_MESSAGE,
        "--message",
        "-m",
        help="Message shown to users during lockdown.",
    ),
) -> None:
    """Activate emergency lockdown. Revokes all non-admin sessions immediately.
    Requires global:admin role.
    """
    r = run_api("post", "/auth/lockdown", action="activating lockdown", json={"message": message})
    data = r.json()
    from dtxapps.context import get_output

    if get_output() == "json":
        print_json(data)
    else:
        revoked = data.get("revoked_sessions", 0)
        console.print(f"[bold red]Lockdown activated.[/bold red] {revoked} session(s) revoked.")
        if data.get("message"):
            console.print(f"  Message: {data['message']}")


@app.command("deactivate")
def deactivate() -> None:
    """Deactivate emergency lockdown. Users must re-authenticate.
    Requires global:admin role.
    """
    run_api("delete", "/auth/lockdown", action="deactivating lockdown")
    render_success("[green]Lockdown deactivated.[/green] Users must re-authenticate.")
