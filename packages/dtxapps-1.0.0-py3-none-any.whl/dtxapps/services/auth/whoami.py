import typer
import jwt as pyjwt
from datetime import datetime, timezone
from dtxapps.constants import (
    AUTH_IDENTITIES_BASE,
    AUTH_IDENTITY_GROUPS_PATH,
)
from dtxapps.context import get_client
from dtxapps.output import console, render_object

_AUTH_ME_PATH = "/auth/me"


def _fetch_all_items(client, path: str) -> list:  # type: ignore[type-arg]
    """Fetch all pages from a paginated endpoint, returning the concatenated items list."""
    items: list = []  # type: ignore[type-arg]
    params: dict = {}  # type: ignore[type-arg]
    while True:
        resp = client.get(path, params=params)
        if not resp.is_success:
            break
        data = resp.json()
        items.extend(data.get("items", []))
        next_cursor = data.get("next_cursor")
        if not next_cursor:
            break
        params = {"cursor": next_cursor}
    return items


def _format_groups(groups: list) -> str:  # type: ignore[type-arg]
    if not groups:
        return "—"
    parts = []
    for g in groups:
        via = g.get("via")
        suffix = f" (via {', '.join(via)})" if via else " (direct)"
        parts.append(g["name"] + suffix)
    return ", ".join(parts)


def whoami():
    """Show current identity, roles, and group memberships."""
    # get_client() handles the not-logged-in / no-URL-configured message and exits
    client = get_client()
    try:
        claims = pyjwt.decode(
            client.access_token,
            options={"verify_signature": False},
        )
    except Exception:
        console.print("[red]Invalid token.[/red]")
        raise typer.Exit(1)
    identity_id = claims["sub"]
    identity_resp = client.get(f"{AUTH_IDENTITIES_BASE}/{identity_id}")
    if not identity_resp.is_success:
        console.print(f"[yellow]Warning: could not fetch identity details ({identity_resp.status_code}).[/yellow]")
    identity = identity_resp.json() if identity_resp.is_success else {}
    groups = _fetch_all_items(client, AUTH_IDENTITY_GROUPS_PATH.format(identity_id=identity_id))
    me_resp = client.get(_AUTH_ME_PATH)
    roles: list[str] = me_resp.json().get("roles", []) if me_resp.is_success else []
    exp = claims.get("exp")
    expires_str = datetime.fromtimestamp(exp, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if exp else "—"
    data = {
        "identity_id": identity.get("identity_id", identity_id),
        "name": identity.get("name", "—"),
        "type": identity.get("type", "—"),
        "status": identity.get("status", "—"),
        "roles": ", ".join(roles) or "—",
        "groups": _format_groups(groups),
        "expires_at": expires_str,
    }
    render_object(data, title="Current Identity")
