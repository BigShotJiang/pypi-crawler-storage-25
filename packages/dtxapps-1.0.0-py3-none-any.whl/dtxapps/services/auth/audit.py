from typing import Optional

import typer
from dtxapps.cli_utils import build_page_params
from dtxapps.constants import (
    ACTOR_ID_DISPLAY_LENGTH,
    AUDIT_EVENTS_BASE,
    DEFAULT_PAGE_SIZE,
    LOG_ID_DISPLAY_LENGTH,
)
from dtxapps.context import run_api
from dtxapps.output import render_object, render_paged_response

app = typer.Typer(no_args_is_help=True)

_AUDIT_COLUMNS = [
    "log_id",
    "created_at",
    "event_type",
    "result",
    "actor",
    "app_slug",
    "environment",
    "resource_type",
    "resource_id",
    "action",
]


def _transform_audit_items(items: list) -> None:
    for item in items:
        lid = item.get("log_id", "")
        if len(lid) > LOG_ID_DISPLAY_LENGTH:
            item["log_id"] = lid[:ACTOR_ID_DISPLAY_LENGTH] + "…"
        name = item.get("actor_name")
        email = item.get("actor_email")
        actor_id = item.get("actor_id", "")
        if name:
            item["actor"] = f"{name} ({email})" if email else name
        elif actor_id:
            item["actor"] = actor_id[:ACTOR_ID_DISPLAY_LENGTH] + "…" if len(actor_id) > LOG_ID_DISPLAY_LENGTH else actor_id
        else:
            item["actor"] = "—"


def _render_audit_events(r_json: dict) -> None:  # type: ignore[type-arg]
    render_paged_response(r_json, _AUDIT_COLUMNS, "Audit Events", transform=_transform_audit_items)


def _build_audit_filter_params(
    limit: int,
    cursor: Optional[str],
    actor_id: Optional[str],
    app_slug: Optional[str],
    resource_type: Optional[str],
    resource_id: Optional[str],
    event_type: Optional[str],
    result: Optional[str],
    start_date: Optional[str],
    end_date: Optional[str],
) -> dict:  # type: ignore[type-arg]
    params = build_page_params(limit, cursor)
    for key, val in [
        ("actor_id", actor_id),
        ("app_slug", app_slug),
        ("resource_type", resource_type),
        ("resource_id", resource_id),
        ("event_type", event_type),
        ("result", result),
        ("start_date", start_date),
        ("end_date", end_date),
    ]:
        if val:
            params[key] = val
    return params


@app.command("list")
def list_events(
    actor_id: Optional[str] = typer.Option(None, "--actor-id", help="Filter by actor identity ID"),
    app_slug: Optional[str] = typer.Option(None, "--app-slug", help="Filter by app slug (e.g. dtxapps-billing)"),
    resource_type: Optional[str] = typer.Option(None, "--resource-type", help="Filter by resource type"),
    resource_id: Optional[str] = typer.Option(None, "--resource-id", help="Filter by resource ID (requires --resource-type)"),
    event_type: Optional[str] = typer.Option(None, "--event-type", help="Filter by event type (e.g. token.issued)"),
    result: Optional[str] = typer.Option(None, "--result", help="Filter by result (success / failure)"),
    start_date: Optional[str] = typer.Option(None, "--start-date", help="ISO 8601 start date (inclusive)"),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="ISO 8601 end date (inclusive)"),
    limit: int = typer.Option(DEFAULT_PAGE_SIZE, "--limit", help="Max results (1–200)"),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor"),
):
    """List audit log events. Admin only."""
    params = _build_audit_filter_params(
        limit,
        cursor,
        actor_id,
        app_slug,
        resource_type,
        resource_id,
        event_type,
        result,
        start_date,
        end_date,
    )
    r = run_api("get", AUDIT_EVENTS_BASE, action="listing audit events", params=params)
    _render_audit_events(r.json())


@app.command("get")
def get_event(
    log_id: str = typer.Option(..., "--log-id", help="Audit log entry ID"),
):
    """Get a single audit log entry by ID. Admin only."""
    r = run_api("get", f"{AUDIT_EVENTS_BASE}/{log_id}", action="fetching audit event")
    item = r.json()
    render_object(item, title=f"Audit Event {log_id[:8]}…")
