import hashlib
import webbrowser
from urllib.parse import urlparse
import httpx
import typer
from rich.console import Console
from dtxapps.constants import (
    DEFAULT_API_URL,
    HTTP_TIMEOUT,
    PKCE_PORT_MIN,
    PKCE_PORT_MAX,
    PKCE_SCOPE,
    PKCE_RESPONSE_TYPE,
    PKCE_CHALLENGE_METHOD,
    PKCE_VERIFIER_BYTES,
)
from dtxapps.context import (
    get_profile,
    save_credentials,
    clear_credentials,
    fetch_api_url_from_website,
    load_url,
    load_credentials,
)
from dtxapps.services.apps.discovery import purge_app_list_cache

_c = Console()

_DEFAULT_URL = DEFAULT_API_URL


def _safe_url(url: str) -> str:
    """Strip embedded credentials (user:pass@) from a URL before display."""
    parsed = urlparse(url)
    return parsed._replace(netloc=parsed.hostname or "").geturl()


def login(
    mock: bool = typer.Option(False, "--mock"),
):
    """Log in via Cognito PKCE, or --mock for local dev.

    For service accounts / automation, set DTXAPPS_API_KEY instead of logging in.
    To set the API URL, run: dtxapps config set-profile --url <url>
    """
    profile = get_profile()
    resolved_url, _ = fetch_api_url_from_website(load_url(profile) or _DEFAULT_URL)
    if mock:
        hostname = urlparse(resolved_url).hostname or ""
        if hostname not in ("localhost", "127.0.0.1"):
            _c.print("[red]--mock is only available for local development.[/red] Target URL must be localhost.")
            raise typer.Exit(1)
        _login_mock(url=resolved_url, profile=profile)
    else:
        _login_cognito(url=resolved_url, profile=profile)


def _save(data, profile):
    save_credentials(
        profile=profile,
        access_token=data["access_token"],
        refresh_token=data["refresh_token"],
        refresh_token_expires_in=data["refresh_token_expires_in"],
    )
    purge_app_list_cache(profile)
    _c.print(f"[green]✓ Logged in.[/green] Profile: [bold]{profile}[/bold]")
    _c.print("[dim]Tokens saved to ~/.dot_dtxapps/tokens (profile config preserved in ~/.dot_dtxapps/profiles)[/dim]")


def _login_mock(*, url, profile):
    # No creds
    mock = httpx.post(
        f"{url}/auth/dev/mock-cognito-token", json={"sub": "mock-user-001", "email": "dev@example.com", "name": "Dev User"}, timeout=HTTP_TIMEOUT
    )
    if not mock.is_success:
        _c.print("[red]Mock endpoint unavailable.[/red] Is the service running locally?")
        raise typer.Exit(1)
    # No Creds
    r = httpx.post("/auth/exchange", json={"cognito_token": mock.json()["token"]}, timeout=HTTP_TIMEOUT)
    if not r.is_success:
        ct = r.headers.get("content-type", "")
        detail = r.json().get("detail", r.text) if "application/json" in ct else r.text
        _c.print(f"[red]Login failed:[/red] {detail}")
        raise typer.Exit(1)
    _save(r.json(), profile)


def _pick_port(start: int, end: int) -> int:
    import socket

    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("localhost", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"No available port in range {start}–{end}.")


def _build_pkce_challenge(verifier: str) -> str:
    """Return the PKCE code_challenge for *verifier* (SHA256 + base64url, no padding)."""
    import base64

    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()


def _build_cognito_auth_url(cfg: dict, redirect_uri: str, verifier: str) -> str:  # type: ignore[type-arg]
    """Build the Cognito /oauth2/authorize URL with PKCE parameters."""
    import urllib.parse

    auth_params: dict = {  # type: ignore[type-arg]
        "response_type": PKCE_RESPONSE_TYPE,
        "client_id": cfg["cognito_client_id"],
        "redirect_uri": redirect_uri,
        "scope": PKCE_SCOPE,
        "code_challenge": _build_pkce_challenge(verifier),
        "code_challenge_method": PKCE_CHALLENGE_METHOD,
    }
    if cfg.get("cognito_identity_provider"):
        auth_params["identity_provider"] = cfg["cognito_identity_provider"]
    params = urllib.parse.urlencode(auth_params)
    return f"https://{cfg['cognito_domain']}/oauth2/authorize?{params}"


def _await_callback_code(port: int) -> str | None:
    """Start a one-shot HTTP server on *port* and return the received OAuth code."""
    import urllib.parse
    from http.server import BaseHTTPRequestHandler, HTTPServer

    holder: dict = {}  # type: ignore[type-arg]

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a: object) -> None:
            pass

        def do_GET(self) -> None:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if "code" in qs:
                holder["code"] = qs["code"][0]
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"<h2>Login successful. Close this tab.</h2>")
            else:
                self.send_response(400)
                self.end_headers()

    HTTPServer(("localhost", port), H).handle_request()
    return holder.get("code")


def _exchange_cognito_code(
    cfg: dict,
    code: str,
    redirect_uri: str,
    verifier: str,  # type: ignore[type-arg]
) -> dict:  # type: ignore[type-arg]
    """POST to Cognito /oauth2/token and return the token response dict."""
    return httpx.post(  # type: ignore[no-any-return]
        f"https://{cfg['cognito_domain']}/oauth2/token",
        data={
            "grant_type": "authorization_code",
            "client_id": cfg["cognito_client_id"],
            "redirect_uri": redirect_uri,
            "code": code,
            "code_verifier": verifier,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=HTTP_TIMEOUT,
    ).json()


def _login_cognito(*, url: str, profile: str) -> None:
    import secrets

    try:
        # No credentials need to use httpx here
        cfg = httpx.get(f"{url}/auth/config", timeout=HTTP_TIMEOUT).json()
    except httpx.ConnectError as e:
        _c.print(f"[red]Cannot connect to API:[/red] {_safe_url(url)}\nIs the service running?  \n[red]Exception:[/red] ${e}")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        _c.print(f"[red]Connection timed out:[/red] {_safe_url(url)}")
        raise typer.Exit(1)
    if not cfg.get("cognito_domain"):
        _c.print("[red]Cognito not configured.[/red] Use --mock for local dev.")
        raise typer.Exit(1)

    try:
        port = _pick_port(PKCE_PORT_MIN, PKCE_PORT_MAX)
    except RuntimeError as e:
        _c.print(f"[red]Could not start local callback server:[/red] {e}")
        raise typer.Exit(1)

    redirect_uri = f"http://localhost:{port}/callback"
    verifier = secrets.token_urlsafe(PKCE_VERIFIER_BYTES)
    auth_url = _build_cognito_auth_url(cfg, redirect_uri, verifier)
    _c.print("[bold]Opening browser...[/bold]")
    webbrowser.open(auth_url)

    code = _await_callback_code(port)
    if not code:
        raise typer.Exit(1)

    tokens = _exchange_cognito_code(cfg, code, redirect_uri, verifier)
    # No credentials yet, cant use client yet
    r = httpx.post(f"{url}/auth/exchange", json={"cognito_token": tokens["id_token"]}, timeout=HTTP_TIMEOUT)
    if not r.is_success:
        ct = r.headers.get("content-type", "")
        detail = r.json().get("detail", r.text) if "application/json" in ct else r.text
        _c.print(f"[red]Login failed:[/red] {detail}")
        raise typer.Exit(1)
    _save(r.json(), profile)


def logout():
    """Clear stored JWT tokens and revoke the server-side session. Profile configuration (URL, API key) is preserved."""
    profile = get_profile()
    creds = load_credentials(profile)
    if creds and creds.get("access_token") and creds.get("auth_service_url"):
        try:
            # Might not be authenticated....
            httpx.post(f"{creds['auth_service_url']}/auth/logout", headers={"Authorization": f"Bearer {creds['access_token']}"}, timeout=HTTP_TIMEOUT)
        except Exception:
            pass  # best-effort — always clear local tokens
    clear_credentials(profile)
    Console().print(f"[green]✓ Logged out.[/green] Profile: [bold]{profile}[/bold]")
    Console(stderr=True).print("[dim]Session revoked. Tokens cleared.[/dim]")
