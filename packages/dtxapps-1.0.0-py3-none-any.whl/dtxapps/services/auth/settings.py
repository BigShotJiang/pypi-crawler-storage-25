import json
import sys
from typing import Optional
import typer
from dtxapps.cli_utils import load_value
from dtxapps.context import run_api
from dtxapps.output import console, err, render_object

app = typer.Typer(no_args_is_help=True)


@app.command("get")
def get_setting(
    key: str = typer.Option(..., "--key", help="Config key to retrieve"),
):
    """Get a service configuration value. Requires auth:admin or global:admin role."""
    r = run_api("get", f"/auth/settings/{key}", action=f"fetching setting '{key}'")
    render_object(r.json(), title=f"Setting: {key}")


@app.command("set")
def set_setting(
    key: str = typer.Option(..., "--key", help="Config key to set"),
    value: str = typer.Option(None, "--value", "-v", help="Value as a string or JSON"),
    file: str = typer.Option(None, "--file", "-f", help="Path to JSON file containing the value"),
):
    """Set a service configuration value. Requires auth:admin or global:admin role.

    The value is parsed as JSON if possible, otherwise stored as a string.
    For complex values (objects, arrays) use --file or pipe JSON via stdin.
    """
    if file:
        try:
            raw_value = json.loads(open(file).read())
        except (FileNotFoundError, PermissionError, json.JSONDecodeError) as e:
            err.print(f"[red]Error: could not read {file}: {e}[/red]")
            raise typer.Exit(1)
    elif value is not None:
        raw_value = load_value(value)
    else:
        raw = sys.stdin.read().strip()
        if not raw:
            err.print("[red]No value provided. Use --value, --file, or pipe JSON via stdin.[/red]")
            raise SystemExit(1)
        raw_value = load_value(raw)

    r = run_api("put", f"/auth/settings/{key}", action=f"setting '{key}'", json={"value": raw_value})
    console.print("[green]✓ Saved.[/green]")
    render_object(r.json(), title=f"Setting: {key}")


@app.command("token-ttls")
def token_ttls(
    access_ttl: Optional[int] = typer.Option(None, "--access-ttl", help="Access token TTL in seconds (60–86400)"),
    refresh_ttl: Optional[int] = typer.Option(None, "--refresh-ttl", help="Refresh token TTL in seconds (300–604800)"),
    max_session_ttl: Optional[int] = typer.Option(
        None,
        "--max-session-ttl",
        help="Absolute max session duration in seconds (300–2592000). Refreshing does not extend this.",
    ),
):
    """Get or set token TTLs. With no options, shows current values."""
    if access_ttl is None and refresh_ttl is None and max_session_ttl is None:
        r = run_api("get", "/auth/settings/token-ttls", action="fetching token TTLs")
        render_object(r.json(), title="Token TTLs")
    else:
        body: dict = {}
        if access_ttl is not None:
            body["access_token_ttl_seconds"] = access_ttl
        if refresh_ttl is not None:
            body["refresh_token_ttl_seconds"] = refresh_ttl
        if max_session_ttl is not None:
            body["max_session_duration_seconds"] = max_session_ttl
        r = run_api("put", "/auth/settings/token-ttls", action="setting token TTLs", json=body)
        console.print("[green]✓ Saved.[/green]")
        render_object(r.json(), title="Token TTLs")
