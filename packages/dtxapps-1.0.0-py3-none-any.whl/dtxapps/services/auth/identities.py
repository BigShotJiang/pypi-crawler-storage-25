from pathlib import Path
from typing import Optional

import typer
from dtxapps.cli_utils import (
    build_page_params,
    confirm_option,
    load_json_payload,
    require_confirm,
)
from dtxapps.constants import (
    AUTH_IDENTITIES_BASE,
    DEFAULT_PAGE_SIZE,
)
from dtxapps.context import run_api
from dtxapps.output import (
    console,
    err,
    render_paged_response,
    render_object,
    render_success,
)

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_identities(
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size", help="Number of results per page"),
    cursor: str = typer.Option(None, "--cursor", help="Cursor for next page"),
):
    """List all identities."""
    params = build_page_params(page_size, cursor)
    r = run_api("get", AUTH_IDENTITIES_BASE, action="listing identities", params=params)
    render_paged_response(
        r.json(),
        ["identity_id", "name", "email", "type", "status", "created_at"],
        "Identities",
    )


@app.command("get")
def get_identity(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
):
    """Get a single identity."""
    r = run_api("get", f"{AUTH_IDENTITIES_BASE}/{identity_id}", action="fetching identity")
    render_object(r.json(), title="Identity")


@app.command("create")
def create_identity(
    name: str = typer.Option(..., "--name", "-n"),
    type: str = typer.Option(..., "--type", "-t", help="user | service_account"),
    owner_id: str = typer.Option(None, "--owner-id"),
):
    """Create a new identity."""
    payload = {"name": name, "type": type}
    if owner_id:
        payload["owner_identity_id"] = owner_id
    r = run_api("post", AUTH_IDENTITIES_BASE, action="creating identity", json=payload)
    console.print("[green]✓ Created.[/green]")
    render_object(r.json())


@app.command("update")
def update_identity(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    name: str = typer.Option(None, "--name", "-n"),
    status: str = typer.Option(None, "--status", "-s"),
    email: str = typer.Option(None, "--email", "-e", help="Email address (service accounts only)"),
):
    """Update name, status, or email (email: service accounts only)."""
    payload = {k: v for k, v in {"name": name, "status": status, "email": email}.items() if v}
    if not payload:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit()
    r = run_api("patch", f"{AUTH_IDENTITIES_BASE}/{identity_id}", action="updating identity", json=payload)
    console.print("[green]✓ Updated.[/green]")
    render_object(r.json())


@app.command("suspend")
def suspend_identity(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
):
    """Suspend an identity (reversible). Sets status to suspended."""
    r = run_api("patch", f"{AUTH_IDENTITIES_BASE}/{identity_id}", action="suspending identity", json={"status": "suspended"})
    console.print("[green]✓ Suspended.[/green]")
    render_object(r.json())


@app.command("delete")
def delete_identity(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    confirm: bool = confirm_option("Permanently delete this identity and all associated data?"),
):
    """Permanently delete an identity and all associated data (API keys, role assignments). Irreversible."""
    require_confirm(confirm)
    run_api("delete", f"{AUTH_IDENTITIES_BASE}/{identity_id}", action="deleting identity", no_content=True)
    render_success("[green]✓ Permanently deleted.[/green]")


@app.command("get-app-preferences")
def get_app_preferences(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
):
    """Get the app category preferences for an identity."""
    r = run_api("get", f"{AUTH_IDENTITIES_BASE}/{identity_id}/app-preferences", action="fetching app preferences")
    render_object(r.json(), title="App Preferences")


@app.command("set-app-preferences")
def set_app_preferences(
    identity_id: str = typer.Option(..., "--identity-id", help="Identity ID"),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Path to JSON preferences file"),
    json_str: Optional[str] = typer.Option(None, "--json", "-j", help="Inline JSON preferences payload"),
):
    """Set the app category preferences for an identity.

    Provide either --file path/to/prefs.json or --json '{...}'.
    If neither is given, JSON is read from stdin.
    """
    payload = load_json_payload(file, json_str, err)
    r = run_api("put", f"{AUTH_IDENTITIES_BASE}/{identity_id}/app-preferences", action="saving app preferences", json=payload)
    console.print("[green]✓ Saved.[/green]")
    render_object(r.json(), title="App Preferences")
