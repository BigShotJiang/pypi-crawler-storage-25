import typer
from dtxapps.cli_utils import (
    build_page_params,
    confirm_option,
    require_confirm,
)
from dtxapps.constants import (
    AUTH_GROUPS_BASE,
    DEFAULT_PAGE_SIZE,
    MEMBER_TYPE_IDENTITY,
)
from dtxapps.context import get_client, run_api
from dtxapps.output import (
    expect_no_content,
    console,
    render_paged_response,
    render_object,
    render_success,
    refresh_session,
)

app = typer.Typer(no_args_is_help=True)
members_app = typer.Typer(no_args_is_help=True)
roles_app = typer.Typer(no_args_is_help=True)
app.add_typer(members_app, name="members", help="Manage group members")
app.add_typer(roles_app, name="roles", help="Manage group roles")


@app.command("list")
def list_groups(
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size", help="Number of results per page"),
    cursor: str = typer.Option(None, "--cursor", help="Cursor for next page"),
):
    """List all groups."""
    params = build_page_params(page_size, cursor)
    r = run_api("get", AUTH_GROUPS_BASE, action="listing groups", params=params)
    render_paged_response(r.json(), ["group_id", "name", "description", "created_at"], "Groups")


@app.command("create")
def create_group(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
):
    """Create a new group."""
    r = run_api("post", AUTH_GROUPS_BASE, action="creating group", json={"name": name, "description": description})
    console.print("[green]✓ Created.[/green]")
    render_object(r.json())


@app.command("delete")
def delete_group(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
    confirm: bool = confirm_option("Delete this group?"),
):
    """Delete a group."""
    require_confirm(confirm)
    run_api("delete", f"{AUTH_GROUPS_BASE}/{group_id}", action="deleting group", no_content=True)
    render_success("[green]✓ Deleted.[/green]")


# ── Members ──────────────────────────────────────────────────────────────────


@members_app.command("list")
def list_members(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
):
    """List members of a group."""
    r = run_api("get", f"{AUTH_GROUPS_BASE}/{group_id}/members", action="listing group members")
    render_paged_response(
        r.json(),
        ["member_id", "member_type", "name", "added_at"],
        f"Members — {group_id}",
    )


@members_app.command("add")
def add_member(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
    member_id: str = typer.Option(..., "--member-id", help="Member ID"),
    member_type: str = typer.Option(MEMBER_TYPE_IDENTITY, "--type", "-t", help="identity or group"),
):
    """Add a member (identity or group) to a group."""
    c = get_client()
    r = c.put(
        f"{AUTH_GROUPS_BASE}/{group_id}/members/{member_id}",
        json={"member_type": member_type},
    )
    expect_no_content(r, "adding group member")
    console.print(f"[green]✓ Added {member_id} to group {group_id}.[/green]")
    refresh_session(c)


@members_app.command("remove")
def remove_member(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
    member_id: str = typer.Option(..., "--member-id", help="Member ID"),
):
    """Remove a member from a group."""
    c = get_client()
    r = c.delete(f"{AUTH_GROUPS_BASE}/{group_id}/members/{member_id}")
    expect_no_content(r, "removing group member")
    console.print(f"[green]✓ Removed {member_id} from group {group_id}.[/green]")
    refresh_session(c)


# ── Roles ─────────────────────────────────────────────────────────────────────


@roles_app.command("list")
def list_group_roles(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
):
    """List roles assigned to a group."""
    r = run_api("get", f"{AUTH_GROUPS_BASE}/{group_id}/roles", action="listing group roles")
    render_paged_response(r.json(), ["role_id", "name", "description"], f"Roles — {group_id}")


@roles_app.command("assign")
def assign_group_role(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
):
    """Assign a role to a group."""
    c = get_client()
    r = c.put(f"{AUTH_GROUPS_BASE}/{group_id}/roles/{role_id}")
    expect_no_content(r, "assigning group role")
    render_success(f"[green]✓ Role {role_id} assigned to group {group_id}.[/green]")
    refresh_session(c)


@roles_app.command("remove")
def remove_group_role(
    group_id: str = typer.Option(..., "--group-id", help="Group ID"),
    role_id: str = typer.Option(..., "--role-id", help="Role ID"),
):
    """Remove a role from a group."""
    c = get_client()
    r = c.delete(f"{AUTH_GROUPS_BASE}/{group_id}/roles/{role_id}")
    expect_no_content(r, "removing group role")
    render_success(f"[green]✓ Role {role_id} removed from group {group_id}.[/green]")
    refresh_session(c)
