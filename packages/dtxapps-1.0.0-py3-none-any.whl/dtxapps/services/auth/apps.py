import json
from pathlib import Path
from typing import Any, Optional

import typer
from dtxapps.cli_utils import (
    build_page_params,
    confirm_option,
    load_json_payload,
    require_confirm,
)
from dtxapps.constants import (
    APPS_BASE,
    APPS_EXCHANGE_CODE,
    DEFAULT_PAGE_SIZE,
    IMAGE_MIME_TYPES,
)
from dtxapps.context import get_client, get_output, run_api
from dtxapps.output import (
    check_response,
    print_table,
    print_kv,
    print_json,
    console,
    err,
    render_object,
    render_paged_response,
)

app = typer.Typer(no_args_is_help=True)


# ── List ──────────────────────────────────────────────────────────────────────


@app.command("list")
def list_apps(
    status: Optional[str] = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status: pending, approved, rejected, disabled, deregistered",
    ),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name (case-insensitive substring)"),
    tags: Optional[str] = typer.Option(None, "--tags", help="Comma-separated tag filter (e.g. 'internal,prod')"),
    has_spec: Optional[bool] = typer.Option(None, "--has-spec", help="Filter by whether app has an active spec"),
    assigned_only: bool = typer.Option(False, "--assigned-only", help="Only show apps you have a role for"),
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size", help="Number of results per page"),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Cursor for next page"),
):
    """List app registrations (managers see all; others see only approved apps they have a role for)."""
    params = build_page_params(page_size, cursor)
    if status:
        params["status"] = status
    if name:
        params["name"] = name
    if tags:
        params["tags"] = tags
    if has_spec is not None:
        params["has_spec"] = has_spec
    if assigned_only:
        params["assigned_only"] = "true"
    r = run_api("get", APPS_BASE, action="listing apps", params=params)
    render_paged_response(
        r.json(),
        ["app_id", "name", "slug", "app_type", "status", "owner_group", "submitted_at"],
        "App Registrations",
    )


# ── Get ───────────────────────────────────────────────────────────────────────


@app.command("get")
def get_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
):
    """Get details of a single app registration."""
    r = run_api("get", f"{APPS_BASE}/{app_id}", action="fetching app")
    if get_output() == "json":
        print_json(r.json())
    else:
        data = r.json()
        # Flatten lists for readability in kv view
        display = {k: v for k, v in data.items() if not isinstance(v, (list, dict)) or v is None}
        display["roles"] = ", ".join(ro["name"] for ro in data.get("roles", [])) or "—"
        display["groups"] = ", ".join(g["name"] for g in data.get("groups", [])) or "—"
        print_kv(display, title=data.get("name", app_id))


# ── Register ──────────────────────────────────────────────────────────────────


def _upload_app_icon(c: Any, app_id: str, icon_file: Path) -> None:
    import mimetypes

    try:
        raw_bytes = icon_file.read_bytes()
    except (FileNotFoundError, PermissionError) as e:
        err.print(f"[yellow]Warning: could not read icon file {icon_file}: {e}[/yellow]")
        return
    suffix = icon_file.suffix.lower()
    content_type = IMAGE_MIME_TYPES.get(suffix) or mimetypes.guess_type(str(icon_file))[0] or "application/octet-stream"
    upload_r = c.post(
        f"{APPS_BASE}/{app_id}/icon",
        files={"file": (icon_file.name, raw_bytes, content_type)},
    )
    if not upload_r.is_success:
        console.print(f"[yellow]Warning: icon upload failed: {upload_r.text}[/yellow]")
    else:
        console.print("[green]✓ Icon uploaded.[/green]")


@app.command("register")
def register_app(
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Path to JSON registration file"),
    json_str: Optional[str] = typer.Option(None, "--json", "-j", help="Inline JSON registration payload"),
    icon_file: Optional[Path] = typer.Option(None, "--icon-file", help="Path to icon image (PNG/JPEG/GIF/WebP, max 512 KB)"),
):
    """Submit a new app registration for review.

    Provide either --file path/to/app.json or --json '{...}'.
    If neither is given, JSON is read from stdin.
    The payload must include: name, slug, description, app_type, metadata,
    environments (list), owner_group. Optionally: scopes, roles, groups,
    icon. To upload a spec at registration time include
    open_api_spec in the relevant environment object.
    """
    payload = load_json_payload(file, json_str, err)
    c = get_client()
    r = c.post(APPS_BASE, json=payload)
    check_response(r, "registering app")
    app_data = r.json()
    console.print("[green]✓ Submitted for review.[/green]")
    render_object(app_data)
    if icon_file:
        _upload_app_icon(c, app_data.get("app_id", ""), icon_file)


# ── Update ────────────────────────────────────────────────────────────────────


@app.command("update")
def update_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Path to JSON update file"),
    json_str: Optional[str] = typer.Option(None, "--json", "-j", help="Inline JSON update payload"),
):
    """Update app fields (applied immediately — no review required).

    Updatable fields: name, description, icon, app_type, metadata, environments,
    scopes, roles, groups, owner_group.
    To upload a new OpenAPI spec version, use: dtxapps registrations specs upload.
    """
    payload = load_json_payload(file, json_str, err)
    r = run_api("patch", f"{APPS_BASE}/{app_id}", action="updating app", json=payload)
    console.print("[green]✓ Updated.[/green]")
    render_object(r.json())


# ── Get spec ──────────────────────────────────────────────────────────────────


@app.command("get-spec")
def get_spec(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    env: str = typer.Option("prod", "--env", "-e", help="Environment name"),
    output_file: Optional[Path] = typer.Option(None, "--output", "-o", help="Write spec JSON to this file instead of stdout"),
):
    """Fetch the latest active OpenAPI spec for an app environment."""
    r = run_api("get", f"{APPS_BASE}/{app_id}/envs/{env}/specs/active", action="fetching spec")
    if output_file:
        output_file.write_text(json.dumps(r.json(), indent=2))
        console.print(f"[green]✓ Spec written to {output_file}[/green]")
    else:
        print_json(r.json())


# ── Approve ───────────────────────────────────────────────────────────────────


@app.command("approve")
def approve_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        prompt="Approve this app? Roles and groups will be provisioned.",
    ),
):
    """Approve a pending registration. Requires global:application_manager or global:admin role."""
    require_confirm(confirm)
    r = run_api("post", f"{APPS_BASE}/{app_id}/approve", action="approving app")
    console.print("[green]✓ Approved.[/green]")
    render_object(r.json())


# ── Reject ────────────────────────────────────────────────────────────────────


@app.command("reject")
def reject_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    confirm: bool = confirm_option("Reject this app?"),
):
    """Reject a pending registration. Requires global:application_manager or global:admin role."""
    require_confirm(confirm)
    r = run_api("post", f"{APPS_BASE}/{app_id}/reject", action="rejecting app")
    console.print("[green]✓ Rejected.[/green]")
    render_object(r.json())


# ── Deregister ────────────────────────────────────────────────────────────────


@app.command("deregister")
def deregister_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        prompt="Deregister this app? It will no longer be accessible.",
    ),
):
    """Deregister an approved app. Requires global:application_manager or global:admin role."""
    require_confirm(confirm)
    run_api("delete", f"{APPS_BASE}/{app_id}", action="deregistering app", no_content=True)
    console.print("[green]✓ Deregistered.[/green]")


# ── Launch ────────────────────────────────────────────────────────────────────


@app.command("launch")
def launch_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    env: Optional[str] = typer.Option(None, "--env", "-e", help="Target environment name"),
):
    """Generate a one-time launch URL for an app. Open in a browser to authenticate."""
    params: dict[str, Any] = {}
    if env:
        params["env"] = env
    r = run_api("post", f"{APPS_BASE}/{app_id}/launch", action="launching app", params=params)
    data = r.json()
    if get_output() == "json":
        print_json(data)
    else:
        console.print(f"[bold cyan]Launch URL:[/bold cyan] {data['launch_url']}")
        console.print("[dim]Open this URL in a browser. The code is single-use and expires in 5 minutes.[/dim]")


# ── Disable / Enable ──────────────────────────────────────────────────────────


@app.command("disable")
def disable_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
):
    """Disable an approved app. Owner group or manager only."""
    r = run_api("post", f"{APPS_BASE}/{app_id}/disable", action="disabling app")
    console.print("[green]✓ App disabled.[/green]")
    render_object(r.json())


@app.command("enable")
def enable_app(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
):
    """Re-enable a disabled app. Owner group or manager only."""
    r = run_api("post", f"{APPS_BASE}/{app_id}/enable", action="enabling app")
    console.print("[green]✓ App enabled.[/green]")
    render_object(r.json())


# ── Per-environment disable / enable ──────────────────────────────────────────


@app.command("env-disable")
def env_disable(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    env_name: str = typer.Option(..., "--env-name", help="Environment name to disable"),
):
    """Disable a single environment on an approved app. Owner group or manager only."""
    r = run_api("post", f"{APPS_BASE}/{app_id}/envs/{env_name}/disable", action="disabling environment")
    if get_output() == "json":
        print_json(r.json())
    else:
        console.print(f"[green]✓ Environment '{env_name}' disabled.[/green]")
        envs = {e["name"]: e["status"] for e in r.json().get("environments", [])}
        print_kv({"app_id": r.json().get("app_id"), **envs})


@app.command("env-enable")
def env_enable(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
    env_name: str = typer.Option(..., "--env-name", help="Environment name to enable"),
):
    """Re-enable a disabled environment on an approved app. Owner group or manager only."""
    r = run_api("post", f"{APPS_BASE}/{app_id}/envs/{env_name}/enable", action="enabling environment")
    if get_output() == "json":
        print_json(r.json())
    else:
        console.print(f"[green]✓ Environment '{env_name}' enabled.[/green]")
        envs = {e["name"]: e["status"] for e in r.json().get("environments", [])}
        print_kv({"app_id": r.json().get("app_id"), **envs})


# ── Exchange code (useful for debugging/scripting) ────────────────────────────


@app.command("exchange-code")
def exchange_code(
    code: str = typer.Option(..., "--code", "-c", help="One-time launch code"),
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID the code was issued for"),
):
    """Exchange a one-time launch code for a scoped JWT. No auth credentials required."""
    r = get_client().post(
        f"{APPS_EXCHANGE_CODE}",
        json={"code": code, "app_id": app_id},
        no_auth=True,
    )
    check_response(r, "exchanging code")
    if get_output() == "json":
        print_json(r.json())
    else:
        data = r.json()
        console.print("[green]✓ Code exchanged.[/green]")
        console.print(f"[bold cyan]access_token:[/bold cyan] {data['access_token']}")
        console.print(f"[bold cyan]refresh_token:[/bold cyan]       {data['refresh_token']}")


# ── Spec management ────────────────────────────────────────────────────────────

specs_app = typer.Typer(no_args_is_help=True, help="Manage OpenAPI spec versions for an app environment.")


@specs_app.command("upload")
def upload_spec(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    env: str = typer.Option(..., "--env", "-e", help="Environment name"),
    file: Path = typer.Option(..., "--file", "-f", help="Path to OpenAPI spec file (JSON or YAML)"),
):
    """Upload a new spec version (YAML or JSON) for an app environment."""
    import mimetypes

    raw = file.read_bytes()
    suffix = file.suffix.lower()
    if suffix in (".yaml", ".yml"):
        content_type = "application/yaml"
    elif suffix == ".json":
        content_type = "application/json"
    else:
        content_type = mimetypes.guess_type(str(file))[0] or "application/octet-stream"
    r = run_api(
        "post",
        f"{APPS_BASE}/{app_id}/envs/{env}/specs",
        action="uploading spec",
        content=raw,
        headers={"Content-Type": content_type},
    )
    console.print("[green]✓ Spec uploaded.[/green]")
    render_object(r.json())


@specs_app.command("list")
def list_specs(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    env: str = typer.Option(..., "--env", "-e", help="Environment name"),
):
    """List all spec versions for an app environment."""
    r = run_api("get", f"{APPS_BASE}/{app_id}/envs/{env}/specs", action="listing specs")
    items = r.json()
    if get_output() == "json":
        print_json(items)
    else:
        cols = ["version_id", "status", "uploaded_at", "content_hash"]
        print_table(items, cols, title=f"Spec versions — {app_id} / {env}")


@specs_app.command("get")
def get_spec_version(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    env: str = typer.Option(..., "--env", "-e", help="Environment name"),
    version_id: Optional[str] = typer.Option(None, "--version-id", "-v", help="Version ID (default: latest active)"),
    output_file: Optional[Path] = typer.Option(None, "--output", "-o", help="Write spec JSON to file instead of stdout"),
):
    """Fetch a spec version. Defaults to the latest active spec."""
    path = f"{APPS_BASE}/{app_id}/envs/{env}/specs/{version_id}" if version_id else f"{APPS_BASE}/{app_id}/envs/{env}/specs/active"
    r = run_api("get", path, action="fetching spec")
    spec = r.json()
    if output_file:
        output_file.write_text(json.dumps(spec, indent=2))
        console.print(f"[green]✓ Spec written to {output_file}[/green]")
    else:
        print_json(spec)


@specs_app.command("set-status")
def set_spec_status(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    env: str = typer.Option(..., "--env", "-e", help="Environment name"),
    version_id: str = typer.Option(..., "--version-id", "-v", help="Version ID"),
    status: str = typer.Option(..., "--status", "-s", help="New status: deprecated or deactivated"),
):
    """Set a spec version to deprecated or deactivated."""
    if status not in ("deprecated", "deactivated"):
        err.print("[red]Status must be 'deprecated' or 'deactivated'.[/red]")
        raise SystemExit(1)
    r = run_api("patch", f"{APPS_BASE}/{app_id}/envs/{env}/specs/{version_id}", action="updating spec status", json={"status": status})
    console.print(f"[green]✓ Spec status set to '{status}'.[/green]")
    render_object(r.json())


@specs_app.command("delete")
def delete_spec(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    env: str = typer.Option(..., "--env", "-e", help="Environment name"),
    version_id: str = typer.Option(..., "--version-id", "-v", help="Version ID"),
    confirm: bool = confirm_option("Permanently delete this spec version?"),
):
    """Hard-delete a spec version from DB and S3."""
    require_confirm(confirm)
    run_api("delete", f"{APPS_BASE}/{app_id}/envs/{env}/specs/{version_id}", action="deleting spec", no_content=True)
    console.print("[green]✓ Spec version deleted.[/green]")


# ── Catalog ───────────────────────────────────────────────────────────────────

catalog_app = typer.Typer(no_args_is_help=True, help="Browse the app catalog (approved and disabled apps).")


@catalog_app.command("list")
def list_catalog(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name (case-insensitive substring)"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status: approved, disabled"),
    team: Optional[str] = typer.Option(None, "--team", help="Filter by owning team"),
    tags: Optional[str] = typer.Option(None, "--tags", help="Comma-separated tag filter"),
    has_spec: Optional[bool] = typer.Option(None, "--has-spec", help="Filter by whether app has an active spec"),
):
    """List all approved and disabled apps in the catalog."""
    params: dict[str, Any] = {}
    if name:
        params["name"] = name
    if status:
        params["status"] = status
    if team:
        params["team"] = team
    if tags:
        params["tags"] = tags
    if has_spec is not None:
        params["has_spec"] = has_spec
    r = run_api("get", f"{APPS_BASE}/catalog", action="fetching catalog", params=params)
    render_paged_response(r.json(), ["app_id", "name", "slug", "status", "owning_team", "app_type"], "App Catalog")


@catalog_app.command("get")
def get_catalog_item(
    app_id: str = typer.Option(..., "--app-id", help="App ID"),
):
    """Get a single catalog entry by app ID."""
    r = run_api("get", f"{APPS_BASE}/catalog/{app_id}", action="fetching catalog item")
    if get_output() == "json":
        print_json(r.json())
    else:
        data = r.json()
        display = {k: v for k, v in data.items() if not isinstance(v, (list, dict))}
        print_kv(display, title=data.get("name", app_id))


# ── Icon management ────────────────────────────────────────────────────────────


@app.command("icon-upload")
def icon_upload(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
    file: Path = typer.Option(
        ...,
        "--file",
        "-f",
        help="Path to image file (PNG, JPEG, GIF, WebP; max 512 KB)",
    ),
):
    """Upload or replace the icon image for an app. Owner group or manager only."""
    import mimetypes

    raw = file.read_bytes()
    suffix = file.suffix.lower()
    content_type = IMAGE_MIME_TYPES.get(suffix) or mimetypes.guess_type(str(file))[0] or "application/octet-stream"
    r = run_api(
        "post",
        f"{APPS_BASE}/{app_id}/icon",
        action="uploading icon",
        files={"file": (file.name, raw, content_type)},
    )
    console.print("[green]✓ Icon uploaded.[/green]")
    render_object(r.json())


@app.command("icon-delete")
def icon_delete(
    app_id: str = typer.Option(..., "--app-id", "-a", help="App ID"),
):
    """Remove the icon image from an app. Owner group or manager only."""
    r = run_api("delete", f"{APPS_BASE}/{app_id}/icon", action="deleting icon")
    console.print("[green]✓ Icon removed.[/green]")
    render_object(r.json())


# ── Register subcommand groups ────────────────────────────────────────────────
app.add_typer(specs_app, name="specs")
app.add_typer(catalog_app, name="catalog")
