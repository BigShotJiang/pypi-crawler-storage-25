from typing import Optional

import typer
from dtxapps.cli_utils import (
    build_page_params,
    confirm_option,
    require_confirm,
)
from dtxapps.constants import (
    AUTH_IDENTITIES_BASE,
    AUTH_SESSIONS_BASE,
    DEFAULT_PAGE_SIZE,
)
from dtxapps.context import get_client
from dtxapps.output import (
    check_response,
    expect_no_content,
    console,
    render_paged_response,
    render_success,
)

app = typer.Typer(no_args_is_help=True)

_SESSION_COLUMNS = [
    "session_id",
    "identity_id",
    "status",
    "created_at",
    "expires_at",
    "ip_address",
    "user_agent",
]


def _transform_sessions(items: list) -> None:
    for item in items:
        ua = item.get("user_agent") or ""
        if len(ua) > 40:
            item["user_agent"] = ua[:37] + "..."


@app.command("list")
def list_sessions(
    all: bool = typer.Option(False, "--all", help="List all sessions (admin only)"),
    identity_id: Optional[str] = typer.Option(None, "--identity-id", help="Filter by identity ID (admin only)"),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor"),
    page_size: int = typer.Option(DEFAULT_PAGE_SIZE, "--page-size"),
):
    """List sessions. Without --all, lists own sessions. --all or --identity-id requires admin."""
    c = get_client()

    if all or identity_id:
        params = build_page_params(page_size, cursor)
        if identity_id:
            params["identity_id"] = identity_id
        r = c.get(AUTH_SESSIONS_BASE, params=params)
        check_response(r, "listing sessions")
    else:
        # Decode the access token (no verification needed — we just need the sub claim)
        import jwt as pyjwt

        try:
            payload = pyjwt.decode(c.access_token, options={"verify_signature": False})
            my_id = payload.get("sub")
        except Exception:
            console.print("[red]Could not determine identity ID. Use --identity-id.[/red]")
            raise typer.Exit(1)
        if not my_id:
            console.print("[red]Could not determine identity ID. Use --identity-id.[/red]")
            raise typer.Exit(1)
        params = build_page_params(page_size, cursor)
        r = c.get(f"{AUTH_IDENTITIES_BASE}/{my_id}/sessions", params=params)
        check_response(r, "listing sessions")

    render_paged_response(r.json(), _SESSION_COLUMNS, "Sessions", transform=_transform_sessions)


@app.command("revoke")
def revoke_session(
    session_id: str = typer.Option(..., "--session-id", help="Session ID to revoke"),
    confirm: bool = confirm_option("Revoke this session?"),
):
    """Revoke a specific session. All refresh tokens in the session will be invalidated."""
    require_confirm(confirm)
    c = get_client()
    r = c.delete(f"{AUTH_SESSIONS_BASE}/{session_id}")
    expect_no_content(r, "revoking session")
    render_success("[green]✓ Session revoked.[/green]")
