"""Dynamic CLI command generation from an OpenAPI 3.x spec.

Builds a Click ``Group`` where each operation in the spec becomes a sub-command.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any

import click
import httpx


# ── Helpers ───────────────────────────────────────────────────────────────────


def _derive_cmd_name(op_id: str | None, tag: str | None, method: str, path: str) -> str:
    """Derive a clean kebab-case CLI command name from an OpenAPI operation.

    Algorithm:
    1. Action word — first ``_``-separated token of ``op_id`` (lowercased).
       Falls back to the HTTP method verb when ``op_id`` is None.
    2. Path segments — non-parameter parts of ``path`` (strip ``{param}`` tokens).
    3. Strip tag — remove segments that match the normalised tag string.
    4. Combine — ``[action] + filtered_segments``, deduplicate consecutive tokens.
    5. Strip action if it equals tag (e.g. ``health`` tag + ``health`` action → empty).
    6. Fallback to HTTP method name when the result would be empty.
    """
    # 1. Action word
    action = op_id.split("_")[0].lower() if op_id else method.lower()

    # 2. Non-parameter path segments
    segments = [p for p in path.strip("/").split("/") if p and not p.startswith("{")]

    # 3. Strip segments that match the tag
    tag_norm = tag.lower() if tag else None
    if tag_norm:
        segments = [s for s in segments if s.lower() != tag_norm]

    # 4. Combine and deduplicate consecutive tokens
    parts: list[str] = []
    for token in [action] + segments:
        if not parts or token != parts[-1]:
            parts.append(token)

    # 5. Strip action when it equals the tag (leaves only path contribution)
    if tag_norm and parts and parts[0] == tag_norm:
        parts = parts[1:]

    # 6. Fallback
    if not parts:
        parts = [method.lower()]

    return "-".join(parts)


def _resolve_ref(spec: dict, ref: str) -> dict | None:  # type: ignore[type-arg]
    """Resolve a local JSON ``$ref`` pointer like ``'#/components/schemas/Foo'``."""
    if not ref.startswith("#/"):
        return None
    node: Any = spec
    for part in ref.lstrip("#/").split("/"):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node if isinstance(node, dict) else None


def _unwrap_nullable(schema: dict) -> dict:  # type: ignore[type-arg]
    """Return the real sub-schema from ``anyOf``/``oneOf`` nullable patterns.

    FastAPI emits ``{"anyOf": [<real>, {"type": "null"}]}`` for optional fields.
    When there is exactly one non-null variant, return it; otherwise return *schema*
    unchanged.
    """
    for key in ("anyOf", "oneOf"):
        variants = schema.get(key)
        if variants:
            non_null: list[dict] = [s for s in variants if s.get("type") != "null"]  # type: ignore[type-arg]
            if len(non_null) == 1:
                return non_null[0]
    return schema


def _success_codes_from_responses(responses: dict) -> frozenset[int]:  # type: ignore[type-arg]
    """Return the set of HTTP status codes the spec lists as success (< 400).

    Handles numeric string keys (``"200"``, ``"404"``) and OpenAPI range patterns
    (``"2XX"``, ``"1XX"``, ``"3XX"``).  The ``"default"`` key is skipped because
    it cannot be classified without seeing the actual response code at runtime.

    Returns an empty frozenset when *responses* is absent or empty — callers
    should fall back to ``resp.is_success`` in that case.
    """
    codes: set[int] = set()
    for key in responses:
        if key == "default":
            continue
        if len(key) == 3 and key[1:].upper() == "XX":
            # Range pattern: "2XX" → 200-299, "1XX" → 100-199, "3XX" → 300-399
            try:
                base = int(key[0]) * 100
            except ValueError:
                continue
            if base < 400:
                codes.update(range(base, base + 100))
        elif key.isdigit():
            code = int(key)
            if code < 400:
                codes.add(code)
    return frozenset(codes)


_ERROR_FIELD_PRIORITY = ["detail", "message", "error", "msg", "description", "errors"]


def _format_error_list(value: list) -> str | None:  # type: ignore[type-arg]
    """Format a list of error items into a comma-separated string."""
    parts: list[str] = []
    for item in value:
        if isinstance(item, dict):
            for sub_field in ("msg", "message", "detail"):
                sub = item.get(sub_field)
                if sub is not None:
                    parts.append(str(sub))
                    break
            else:
                parts.append(str(item))
        else:
            parts.append(str(item))
    return ", ".join(parts) if parts else None


def _error_detail_from_response(
    resp_json: dict,  # type: ignore[type-arg]
    error_schema: dict | None,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> str | None:
    """Extract a human-readable error message from an API error response.

    Strategy:
    1. If *error_schema* is provided, look for known message-field names in its
       ``properties`` to guide extraction.
    2. Fall back to trying the same priority-list fields directly on *resp_json*
       (works for any common API response shape without a schema).
    3. Return ``None`` when nothing useful is found — the caller should fall back
       to raw response text.
    """
    candidate_fields = list(_ERROR_FIELD_PRIORITY)  # copy; may be reordered by schema

    # Schema-guided: move any schema-known field to the front of the priority list
    if error_schema:
        schema = error_schema
        if "$ref" in schema:
            resolved = _resolve_ref(spec, schema["$ref"])
            if resolved:
                schema = resolved
        schema_props = set(schema.get("properties", {}).keys())
        # Reorder: schema-known fields first (preserving their relative priority order)
        schema_known = [f for f in _ERROR_FIELD_PRIORITY if f in schema_props]
        rest = [f for f in _ERROR_FIELD_PRIORITY if f not in schema_props]
        candidate_fields = schema_known + rest

    for field in candidate_fields:
        value = resp_json.get(field)
        if value is None:
            continue
        if isinstance(value, list):
            return _format_error_list(value)
        return str(value)

    return None


def _fields_hint(schema: dict) -> str:  # type: ignore[type-arg]
    """Return a compact field summary for an object schema.

    Example: ``"title: string*, message: string*, level: string"``

    Required fields are marked with ``*``.  Truncates to 5 fields to keep help
    text readable.
    """
    required = set(schema.get("required", []))
    parts: list[str] = []
    for fname, fschema in schema.get("properties", {}).items():
        ftype = fschema.get("type", "any")
        marker = "*" if fname in required else ""
        parts.append(f"{fname}: {ftype}{marker}")
    if len(parts) > 5:
        return ", ".join(parts[:5]) + f", +{len(parts) - 5} more"
    return ", ".join(parts)


def _schema_hint(
    schema: dict,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> str | None:
    """Return a compact human-readable hint for the expected JSON body shape.

    Examples::

        array of $ref       →  "[{title: string*, message: string*}]  (CreateItemRequest)"
        array of string     →  "[string]"
        plain object        →  "{title: string*, message: string*}"
        unrecognised        →  None
    """
    if "$ref" in schema:
        ref = schema["$ref"]
        name = ref.split("/")[-1]
        resolved = _resolve_ref(spec, ref)
        if resolved:
            return _schema_hint(resolved, spec) or name
        return str(name)

    schema = _unwrap_nullable(schema)
    typ = schema.get("type")

    if typ == "array":
        items = schema.get("items", {})
        if "$ref" in items:
            ref_name = items["$ref"].split("/")[-1]
            resolved = _resolve_ref(spec, items["$ref"])
            if resolved and resolved.get("type") == "object" and "properties" in resolved:
                return f"[{{{_fields_hint(resolved)}}}]  ({ref_name})"
            return f"[{ref_name}]"
        inner = _schema_hint(items, spec) if items else "any"
        return f"[{inner}]"

    if typ == "object" and "properties" in schema:
        return "{" + _fields_hint(schema) + "}"

    if typ:
        return str(typ)

    return None


def _make_field_option(
    field_name: str,
    field_schema: dict,  # type: ignore[type-arg]
    required: bool,
) -> click.Option:
    """Build a Click Option for a single JSON Schema object field."""
    default = field_schema.get("default")
    description = field_schema.get("description") or field_schema.get("title", "")
    enum_values: list[str] | None = field_schema.get("enum")
    option_name = f"--{field_name.replace('_', '-')}"

    if enum_values:
        choices = "|".join(enum_values)
        help_text = f"{description} [{choices}]" if description else f"[{choices}]"
        return click.Option(
            [option_name],
            required=required,
            default=default,
            show_default=default is not None,
            help=help_text,
            type=click.Choice(enum_values),
        )

    constraints: list[str] = []
    if "minLength" in field_schema:
        constraints.append(f"min {field_schema['minLength']} chars")
    if "maxLength" in field_schema:
        constraints.append(f"max {field_schema['maxLength']} chars")
    help_text = description
    if constraints:
        suffix = f" ({', '.join(constraints)})"
        help_text = (help_text + suffix).strip()
    return click.Option(
        [option_name],
        required=required,
        default=default,
        show_default=default is not None,
        help=help_text or None,
        type=str,
    )


def _body_params_from_schema(
    schema: dict,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> tuple[list[click.Option], list[str]] | None:
    """Convert a JSON Schema object into per-field Click options.

    Returns ``(options, field_names)`` when *schema* is a plain ``object`` with
    ``properties``, or ``None`` to signal the caller to fall back to
    ``--data`` / ``--file``.

    *field_names* preserves the original JSON field names (underscores) so the
    callback can map Click kwargs (also underscored by Click) back to field names.
    """
    schema = _unwrap_nullable(schema)
    if "$ref" in schema:
        resolved = _resolve_ref(spec, schema["$ref"])
        if resolved is None:
            return None
        schema = resolved

    if schema.get("type") != "object" or "properties" not in schema:
        return None

    required_fields = set(schema.get("required", []))
    options: list[click.Option] = []
    field_names: list[str] = []

    for field_name, raw_field_schema in schema["properties"].items():
        field_schema = _unwrap_nullable(raw_field_schema)
        if "$ref" in field_schema:
            field_schema = _resolve_ref(spec, field_schema["$ref"]) or field_schema
        required = field_name in required_fields
        options.append(_make_field_option(field_name, field_schema, required))
        field_names.append(field_name)

    return options, field_names


def _build_path_param_options(path_params: list) -> list[click.Option]:  # type: ignore[type-arg]
    """Build Click Options for OpenAPI path parameters (all required named flags)."""
    options: list[click.Option] = []
    for pp in path_params:
        name = pp["name"].replace("_", "-")
        description = (pp.get("schema") or {}).get("title") or pp.get("description", "")
        options.append(
            click.Option(
                [f"--{name}"],
                required=True,
                default=None,
                help=description or None,
                type=str,
            )
        )
    return options


def _build_query_param_options(query_params: list) -> list[click.Option]:  # type: ignore[type-arg]
    """Build Click Options for OpenAPI query parameters."""
    options: list[click.Option] = []
    for qp in query_params:
        name = qp["name"].replace("_", "-")
        required = qp.get("required", False)
        options.append(
            click.Option(
                [f"--{name}"],
                required=required,
                default=None,
                help=qp.get("description", ""),
                type=str,
            )
        )
    return options


def _build_response_schemas(
    responses: dict,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> tuple[frozenset[int], dict[int, dict | None]]:  # type: ignore[type-arg]
    """Pre-compute success codes and per-error-code schemas from spec responses."""
    success_codes = _success_codes_from_responses(responses)
    error_schemas: dict[int, dict | None] = {}
    for code_str, resp_obj in responses.items():
        if code_str == "default" or not code_str.isdigit():
            continue
        code = int(code_str)
        if code >= 400:
            raw = resp_obj.get("content", {}).get("application/json", {}).get("schema", {})
            error_schemas[code] = _resolve_ref(spec, raw["$ref"]) if "$ref" in raw else (raw or None)
    return success_codes, error_schemas


def _build_body_options(
    operation: dict,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> tuple[list[click.Option], list[str], bool]:
    """Return (options, field_names, has_body) for the request body."""
    has_body = "requestBody" in operation
    body_field_names: list[str] = []
    options: list[click.Option] = []
    if not has_body:
        return options, body_field_names, has_body

    raw_schema = operation["requestBody"].get("content", {}).get("application/json", {}).get("schema", {})
    field_result = _body_params_from_schema(raw_schema, spec)
    if field_result:
        field_options, body_field_names = field_result
        options.extend(field_options)
    else:
        hint = _schema_hint(raw_schema, spec)
        hint_suffix = f"  Expected: {hint}" if hint else ""
        options.append(
            click.Option(
                ["--data", "-d"],
                default=None,
                help=f"JSON string for the request body.{hint_suffix}",
                type=str,
            )
        )
        options.append(
            click.Option(
                ["--file", "-f"],
                default=None,
                help=f"Path to a JSON file for the request body.{hint_suffix}",
                type=click.Path(exists=True),
            )
        )
    return options, body_field_names, has_body


def _resolve_request_url(path: str, path_params: list, kwargs: dict) -> str:  # type: ignore[type-arg]
    """Substitute path parameters from kwargs into the URL path."""
    url_path = path
    for pp in path_params:
        kwarg_key = pp["name"].replace("-", "_")
        val = kwargs.pop(kwarg_key, None)
        if val is None:
            click.echo(
                f"Error: missing required option '--{pp['name'].replace('_', '-')}'",
                err=True,
            )
            sys.exit(1)
        url_path = url_path.replace("{" + pp["name"] + "}", val)
    return url_path


def _collect_query_params(query_params: list, kwargs: dict) -> dict[str, str]:  # type: ignore[type-arg]
    """Pop query param keys from kwargs and return non-None values."""
    query: dict[str, str] = {}
    for qp in query_params:
        val = kwargs.pop(qp["name"].replace("-", "_"), None)
        if val is not None:
            query[qp["name"]] = val
    return query


def _assemble_body(
    has_body: bool,
    body_field_names: list[str],
    kwargs: dict,  # type: ignore[type-arg]
) -> dict | None:  # type: ignore[type-arg]
    """Build the request body dict from per-field kwargs, --data, or --file."""
    if not has_body:
        return None
    if body_field_names:
        body = {f: kwargs.pop(f, None) for f in body_field_names}
        return {k: v for k, v in body.items() if v is not None} or None
    data_str = kwargs.pop("data", None)
    file_path = kwargs.pop("file", None)
    if file_path:
        try:
            return json.loads(Path(file_path).read_text())  # type: ignore[no-any-return]
        except (FileNotFoundError, PermissionError, json.JSONDecodeError) as e:
            click.echo(f"Error: could not read {file_path}: {e}", err=True)
            sys.exit(1)
    if data_str:
        return json.loads(data_str)  # type: ignore[no-any-return]
    return None


def _emit_debug_request(method: str, url: str, body: dict | None) -> None:  # type: ignore[type-arg]
    """Print request details when debug mode is active."""
    from dtxapps.context import console, is_debug

    if not is_debug():
        return
    console.print(
        f"[bold cyan]DEBUG →[/bold cyan] {method.upper()} {url}",
        highlight=False,
    )
    if body is not None:
        console.print_json(json.dumps(body, default=str))


def _emit_debug_response(resp: httpx.Response, t0: float, is_success: bool) -> None:
    """Print response details when debug mode is active."""
    from dtxapps.context import console, is_debug

    if not is_debug():
        return
    elapsed = int((time.monotonic() - t0) * 1000)
    color = "green" if is_success else "red"
    console.print(
        f"[bold {color}]DEBUG ←[/bold {color}] {resp.status_code} ({elapsed}ms)",
        highlight=False,
    )
    try:
        console.print_json(json.dumps(resp.json(), default=str))
    except Exception:
        if resp.text:
            console.print(f"  {resp.text[:500]}")


def _emit_success(resp: httpx.Response, success_codes: frozenset[int]) -> None:
    """Print the successful response, with a warning for unexpected status codes."""
    if success_codes and resp.is_success and resp.status_code not in success_codes:
        click.echo(
            click.style(
                f"Warning: app spec declares success as {sorted(success_codes)} "
                f"but received {resp.status_code}. The app owner should update their OpenAPI spec.",
                fg="yellow",
            ),
            err=True,
        )
    try:
        click.echo(json.dumps(resp.json(), indent=2))
    except Exception:
        click.echo(resp.text)


def _emit_error(
    resp: httpx.Response,
    error_schemas: dict[int, dict | None],  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> None:
    """Print error details and exit 1."""
    error_schema = error_schemas.get(resp.status_code)
    try:
        resp_json = resp.json()
        detail = _error_detail_from_response(resp_json, error_schema, spec)
        click.echo(f"Error {resp.status_code}: {detail or resp.text}", err=True)
    except Exception:
        click.echo(f"Error {resp.status_code}: {resp.text}", err=True)
    sys.exit(1)


def _execute_operation_request(
    *,
    method: str,
    app_base_url: str | None,
    url_path: str,
    access_token: str,
    query: dict | None,  # type: ignore[type-arg]
    body: dict | None,  # type: ignore[type-arg]
    success_codes: frozenset[int],
    error_schemas: dict[int, dict | None],  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
) -> None:
    if not app_base_url:
        click.echo("Error: no api_url configured for this app environment.", err=True)
        sys.exit(1)
    base_url = app_base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {access_token}"}
    full_url = f"{base_url}{url_path}"
    _emit_debug_request(method, full_url, body)
    t0 = time.monotonic()
    resp = httpx.request(
        method=method.upper(),
        url=full_url,
        headers=headers,
        params=query or None,
        json=body,
        timeout=30,
    )
    is_success = resp.is_success or resp.status_code in success_codes
    _emit_debug_response(resp, t0, is_success)
    if is_success:
        _emit_success(resp, success_codes)
    else:
        _emit_error(resp, error_schemas, spec)


def _make_operation_command(
    slug: str,
    app_id: str,
    env: str,
    cmd_name: str,
    method: str,
    path: str,
    operation: dict,  # type: ignore[type-arg]
    spec: dict,  # type: ignore[type-arg]
    app_base_url: str | None = None,
) -> click.Command:
    """Build a Click command for a single OpenAPI operation."""
    summary = operation.get("summary") or operation.get("description") or f"{method.upper()} {path}"
    all_params = operation.get("parameters", [])
    path_params = [p for p in all_params if p.get("in") == "path"]
    query_params = [p for p in all_params if p.get("in") == "query"]
    params: list[click.Parameter] = [
        *_build_path_param_options(path_params),
        *_build_query_param_options(query_params),
    ]
    success_codes, error_schemas = _build_response_schemas(operation.get("responses", {}), spec)
    body_options, body_field_names, has_body = _build_body_options(operation, spec)
    params.extend(body_options)

    def _callback(**kwargs: Any) -> None:
        from dtxapps.context import get_client as _get_client
        from dtxapps.services.apps.token_manager import get_app_token

        c = _get_client()
        access_token = get_app_token(app_id, slug, c, c.profile, env=env)
        url_path = _resolve_request_url(path, path_params, kwargs)
        query = _collect_query_params(query_params, kwargs)
        body = _assemble_body(has_body, body_field_names, kwargs)
        _execute_operation_request(
            method=method,
            app_base_url=app_base_url,
            url_path=url_path,
            access_token=access_token,
            query=query,
            body=body,
            success_codes=success_codes,
            error_schemas=error_schemas,
            spec=spec,
        )

    _callback.__doc__ = summary
    return click.Command(name=cmd_name, callback=_callback, params=params, help=summary)


# ── Public API ────────────────────────────────────────────────────────────────


class _SlugGroup(click.Group):
    """Per-app group that shows help when invoked with no subcommand."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        from typer.rich_utils import rich_format_help

        rich_format_help(obj=self, ctx=ctx, markup_mode="rich")

    def invoke(self, ctx: click.Context) -> None:
        if not ctx.protected_args and not ctx.args:
            self.format_help(ctx, ctx.make_formatter())
        else:
            super().invoke(ctx)


def _add_ops_to_group(
    target: click.Group,
    ops: list[tuple[str, str, dict]],  # type: ignore[type-arg]
    tag: str | None,
    *,
    slug: str,
    app_id: str,
    env: str,
    spec: dict,  # type: ignore[type-arg]
    app_base_url: str | None,
) -> None:
    seen: set[str] = set()
    for path, method, operation in ops:
        op_id = operation.get("operationId")
        cmd_name = _derive_cmd_name(op_id, tag, method, path)
        base = cmd_name
        suffix = 1
        while cmd_name in seen:
            cmd_name = f"{base}-{suffix}"
            suffix += 1
        seen.add(cmd_name)
        cmd = _make_operation_command(
            slug=slug,
            app_id=app_id,
            env=env,
            cmd_name=cmd_name,
            method=method,
            path=path,
            operation=operation,
            spec=spec,
            app_base_url=app_base_url,
        )
        target.add_command(cmd)


def build_app_group(
    slug: str,
    spec: dict,  # type: ignore[type-arg]
    app_id: str,
    profile: str,  # retained for call-site compatibility; unused internally
    *,
    app_base_url: str | None = None,
    env: str = "prod",
) -> click.Group:
    """Build a Click Group for *slug* from its OpenAPI spec."""
    title = spec.get("info", {}).get("title", slug)
    description = spec.get("info", {}).get("description", f"Commands for {slug}")
    group = _SlugGroup(name=slug, help=f"{title} — {description}", invoke_without_command=True)
    tag_ops: dict[str | None, list[tuple[str, str, dict]]] = {}  # type: ignore[type-arg]
    for path, path_item in spec.get("paths", {}).items():
        for method, operation in path_item.items():
            if method.lower() not in {"get", "post", "put", "patch", "delete"}:
                continue
            if not isinstance(operation, dict):
                continue
            tags = operation.get("tags") or []
            tag: str | None = tags[0] if tags else None
            tag_ops.setdefault(tag, []).append((path, method, operation))
    kw = dict(slug=slug, app_id=app_id, env=env, spec=spec, app_base_url=app_base_url)
    for tag, ops in tag_ops.items():
        if tag is None:
            _add_ops_to_group(group, ops, None, **kw)  # type: ignore[arg-type]
        else:
            tag_group = _SlugGroup(name=tag, help=f"{tag} operations", invoke_without_command=True)
            _add_ops_to_group(tag_group, ops, tag, **kw)  # type: ignore[arg-type]
            group.add_command(tag_group)
    return group
