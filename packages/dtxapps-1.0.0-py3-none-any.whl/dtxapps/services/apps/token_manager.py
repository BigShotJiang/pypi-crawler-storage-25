"""Per-app scoped JWT management.

Tokens are cached in-memory for the session lifetime (the scoped JWT is
valid for 15 minutes — re-launching every call would add ~100ms latency).
Tokens are also persisted in the credentials file under
``[<profile>.apps.<slug>.<env>]`` for re-use across invocations within the TTL.
Each environment gets its own section because the JWT ``aud`` claim differs
per environment.
"""

from __future__ import annotations

import configparser
from typing import Any

from dtxapps.constants import (
    APPS_BASE,
    APPS_EXCHANGE_CODE,
    AUTH_REFRESH,
    HTTP_OK,
)
from dtxapps.constants import APP_TOKENS_FILE
from dtxapps.context import _load_cfg, _save_cfg, _token_expired

# In-memory cache: (profile, slug, env) → access_token
_SESSION_CACHE: dict[tuple[str, str, str], str] = {}


def _section(profile: str, slug: str, env: str) -> str:
    return f"{profile}.apps.{slug}.{env}"


def _get_app_section(profile: str, slug: str, env: str) -> tuple[configparser.ConfigParser, str] | None:
    cfg = _load_cfg(APP_TOKENS_FILE)
    sec = _section(profile, slug, env)
    if not cfg.has_section(sec):
        return None
    return cfg, sec


def _stored_app_token(profile: str, slug: str, env: str) -> str | None:
    result = _get_app_section(profile, slug, env)
    if result is None:
        return None
    cfg, sec = result
    token = cfg[sec].get("access_token", "")
    return token if token and not _token_expired(token) else None


def _store_app_token(
    profile: str,
    slug: str,
    env: str,
    access_token: str,
    refresh_token: str,
    refresh_token_expires_in: int,
) -> None:
    import time

    cfg = _load_cfg(APP_TOKENS_FILE)
    sec = _section(profile, slug, env)
    if not cfg.has_section(sec):
        cfg.add_section(sec)
    cfg[sec]["access_token"] = access_token
    cfg[sec]["refresh_token"] = refresh_token
    cfg[sec]["refresh_token_expires_at"] = str(int(time.time()) + refresh_token_expires_in)
    _save_cfg(cfg, APP_TOKENS_FILE)


def _stored_app_refresh_token(profile: str, slug: str, env: str) -> str | None:
    result = _get_app_section(profile, slug, env)
    if result is None:
        return None
    cfg, sec = result
    return cfg[sec].get("refresh_token") or None


def _try_refresh_app_token(
    profile: str,
    slug: str,
    env: str,
    client: Any,
    cache_key: tuple,  # type: ignore[type-arg]
) -> str | None:
    """Attempt token refresh; return new access token on success, None if no refresh token stored.

    Raises RuntimeError if a refresh token exists but the refresh call fails — that is an
    error condition, not a signal to fall through to a new launch.
    """
    refresh_token = _stored_app_refresh_token(profile, slug, env)
    if not refresh_token:
        return None

    resp = client.post(AUTH_REFRESH, no_auth=True, json={"refresh_token": refresh_token})
    if resp.status_code != HTTP_OK:
        raise RuntimeError(f"Failed to refresh app token for '{slug}' ({env}): {resp.status_code} {resp.text}")
    data = resp.json()
    access_token = str(data["access_token"])
    new_refresh = str(data["refresh_token"])
    _store_app_token(profile, slug, env, access_token, new_refresh, data["refresh_token_expires_in"])
    _SESSION_CACHE[cache_key] = access_token
    return access_token


def _exchange_launch_code(
    app_id: str,
    slug: str,
    env: str,
    client: Any,
    profile: str,
    cache_key: tuple,  # type: ignore[type-arg]
) -> str:
    """Perform the full launch → exchange-code flow and return an access token."""
    import urllib.parse

    launch_resp = client.post(f"{APPS_BASE}/{app_id}/launch?env={env}")
    if not launch_resp.is_success:
        raise RuntimeError(f"Failed to launch app '{slug}': {launch_resp.status_code} {launch_resp.text}")
    launch_url = launch_resp.json()["launch_url"]
    parsed = urllib.parse.urlparse(launch_url)
    qs = urllib.parse.parse_qs(parsed.query)
    code = qs.get("code", [None])[0]
    if not code:
        raise RuntimeError(f"No launch code found in launch_url: {launch_url}")

    exchange_resp = client.post(APPS_EXCHANGE_CODE, no_auth=True, json={"code": code, "app_id": app_id})
    if exchange_resp.status_code != HTTP_OK:
        raise RuntimeError(f"Failed to exchange launch code for '{slug}': {exchange_resp.status_code} {exchange_resp.text}")
    token_data = exchange_resp.json()
    access_token = str(token_data["access_token"])
    new_refresh = str(token_data.get("refresh_token", ""))
    _store_app_token(profile, slug, env, access_token, new_refresh, token_data["refresh_token_expires_in"])
    _SESSION_CACHE[cache_key] = access_token
    return access_token


def get_app_token(app_id: str, slug: str, client: Any, profile: str, *, env: str = "prod") -> str:
    """Return a valid scoped access token for *slug*/*env*, obtaining one if needed.

    Flow:
    1. Check in-memory session cache.
    2. Check stored credentials file.
    3. Try to refresh using stored refresh token.
    4. Full launch → exchange-code flow.
    """
    cache_key = (profile, slug, env)

    cached = _SESSION_CACHE.get(cache_key)
    if cached and not _token_expired(cached):
        return cached

    stored = _stored_app_token(profile, slug, env)
    if stored:
        _SESSION_CACHE[cache_key] = stored
        return stored

    refreshed = _try_refresh_app_token(profile, slug, env, client, cache_key)
    if refreshed:
        return refreshed

    return _exchange_launch_code(app_id, slug, env, client, profile, cache_key)
