"""Top-level ``dtxapps apps`` command group.

Provides:
  dtxapps apps                 — list accessible apps
  dtxapps apps refresh         — re-fetch and cache all specs
  dtxapps apps <slug>          — dynamically generated sub-commands from the app's OpenAPI spec
  dtxapps apps <slug> --help   — shows all operations from the spec
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import click

from dtxapps.context import get_client, get_output
from dtxapps.output import print_table, console
from dtxapps.services.apps.discovery import (
    app_has_spec,
    get_app_list_cached,
    get_spec_cached,
    get_spec_by_slug_cached,
    purge_spec_cache,
)
from dtxapps.services.apps.dyngen import build_app_group

_ALLOWED_ENVS = ["dev", "sandbox", "qa", "stage", "prod"]

# The top-level Click group for ``dtxapps apps``
apps_click_group = click.Group(
    name="apps",
    help="Discover and interact with registered applications.",
    invoke_without_command=True,
)


@apps_click_group.command("list")
def list_apps() -> None:
    """List applications you have access to."""
    c = get_client()
    profile = c.profile
    apps = get_app_list_cached(c, profile)
    approved = [a for a in apps if a.get("status") == "approved"]
    if get_output() == "json":
        import json

        click.echo(json.dumps(approved, indent=2))
    else:
        cols = ["slug", "name", "description", "status"]
        with_spec = [a for a in approved if app_has_spec(a)]
        without_spec = [a for a in approved if not app_has_spec(a)]

        if with_spec:
            print_table(
                with_spec,
                cols,
                title="Applications with CLI commands (dtxapps apps <slug>)",
            )
        if without_spec:
            print_table(
                without_spec,
                cols,
                title="Web-only applications (no OpenAPI spec uploaded)",
            )
        if not approved:
            console.print("[dim]No accessible applications.[/dim]")


@apps_click_group.command("refresh")
def refresh_specs() -> None:
    """Purge the local spec cache and re-fetch all accessible specs."""
    c = get_client()
    profile = c.profile
    purge_spec_cache(profile)
    # force=True bypasses the (just-deleted) cache and rebuilds it
    apps = [a for a in get_app_list_cached(c, profile, force=True) if a.get("status") == "approved"]

    tasks = [(app["app_id"], app["slug"], env["name"]) for app in apps for env in app.get("environments", []) if env.get("latest_spec_version_id")]

    refreshed = 0
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {
            pool.submit(get_spec_cached, app_id, slug, c, profile, True, env_name): (app_id, slug, env_name) for app_id, slug, env_name in tasks
        }
        for future in as_completed(futures):
            if future.result():
                refreshed += 1

    console.print(f"[green]✓ Refreshed {refreshed} spec(s).[/green]")


def _build_dynamic_slug_group(slug: str, env: str = "prod") -> click.Group | None:
    """Fetch spec (from cache or API) and build a dynamic Click group for *slug*/*env*."""
    c = get_client()
    profile = c.profile
    result = get_spec_by_slug_cached(slug, c, profile, env_name=env)
    if not result:
        return None
    app_id, spec = result

    # Resolve the app's API base URL for the selected environment from registration data
    apps = get_app_list_cached(c, profile)
    app = next((a for a in apps if a.get("slug") == slug), None)
    app_base_url: str | None = None
    if app:
        env_data = next((e for e in app.get("environments", []) if e.get("name") == env), None)
        if env_data:
            app_base_url = env_data.get("api_url") or None

    # Fall back to the spec's servers[0].url if the registration has no api_url
    if not app_base_url:
        servers = spec.get("servers", [])
        if servers:
            app_base_url = servers[0].get("url") or None

    return build_app_group(slug, spec, app_id, profile, app_base_url=app_base_url, env=env)


class _EnvSlugGroup(click.Group):
    """Per-app slug group that owns --env and lazily loads operations."""

    def __init__(self, slug: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.slug = slug
        self.params.append(
            click.Option(
                ["--env", "-e"],
                default="prod",
                type=click.Choice(_ALLOWED_ENVS),
                help="Environment to use (default: prod).",
                show_default=True,
            )
        )

    def _load_group(self, env: str) -> click.Group | None:
        return _build_dynamic_slug_group(self.slug, env)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        env = ctx.params.get("env", "prod") or "prod"
        group = self._load_group(env)
        return group.get_command(ctx, cmd_name) if group else None

    def list_commands(self, ctx: click.Context) -> list[str]:
        env = ctx.params.get("env", "prod") or "prod"
        group = self._load_group(env)
        return group.list_commands(ctx) if group else []

    def invoke(self, ctx: click.Context) -> None:
        if not ctx.protected_args and not ctx.args:
            self.format_help(ctx, ctx.make_formatter())
        else:
            super().invoke(ctx)

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        from typer.rich_utils import rich_format_help

        rich_format_help(obj=self, ctx=ctx, markup_mode="rich")


class _AppsGroup(click.Group):
    """Custom Group that adds per-app sub-groups dynamically."""

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        from typer.rich_utils import rich_format_help

        rich_format_help(obj=self, ctx=ctx, markup_mode="rich")

    def invoke(self, ctx: click.Context) -> None:
        # ctx.invoked_subcommand is set *by* super().invoke(), not before it.
        # ctx.protected_args holds the subcommand name after parse_args runs.
        if not ctx.protected_args and not ctx.args:
            self.format_help(ctx, ctx.make_formatter())
        else:
            super().invoke(ctx)

    def get_command(self, ctx: click.Context, cmd_name: str):  # type: ignore[override]
        # Static commands first (list, refresh)
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd
        # Fall through to dynamic app slug commands
        return _EnvSlugGroup(slug=cmd_name, name=cmd_name, invoke_without_command=True)

    def list_commands(self, ctx: click.Context) -> list[str]:
        static = list(super().list_commands(ctx))
        # Append slugs from the cached app list — no live API call on every help render
        try:
            c = get_client()
            profile = c.profile
            slugs = [a["slug"] for a in get_app_list_cached(c, profile) if a.get("status") == "approved" and app_has_spec(a) and a.get("slug")]
            return static + sorted(set(slugs) - set(static))
        except Exception:
            pass
        return static


# Re-create the group using the custom class so dynamic lookup works
apps_click_group_dynamic = _AppsGroup(
    name="apps",
    help=(
        "Discover and interact with registered applications.\n\n"
        "Run [bold]dtxapps apps list[/bold] to see available apps, "
        "then [bold]dtxapps apps [SLUG][/bold] to see and run that app's commands."
    ),
    invoke_without_command=True,
)
# Copy static commands over
for _name, _cmd in apps_click_group.commands.items():
    apps_click_group_dynamic.add_command(_cmd, _name)

# Export the dynamic group
apps_group = apps_click_group_dynamic
