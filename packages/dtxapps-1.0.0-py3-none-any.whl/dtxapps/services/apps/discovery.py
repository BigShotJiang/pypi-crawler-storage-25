"""Spec cache management for per-app OpenAPI discovery.

Cache layout:
  ~/.dot_dtxapps/specs/<profile>/<slug>.json       — spec content
  ~/.dot_dtxapps/specs/<profile>/<slug>.meta.json  — {"fetched_at": <iso8601>}
  ~/.dot_dtxapps/specs/<profile>/_app_list.json    — cached app list (all pages)
  ~/.dot_dtxapps/specs/<profile>/_app_list.meta.json

TTL: 12 hours (override with force=True or ``dtxapps apps refresh``).
"""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from dtxapps.constants import APPS_BASE, CREDS_DIR_NAME

_CACHE_TTL_SECONDS = 43200  # 12 hours


def _specs_dir(profile: str) -> Path:
    return _specs_root() / profile


def _spec_path(profile: str, slug: str, env: str = "prod") -> Path:
    return _specs_dir(profile) / f"{slug}-{env}.json"


def _meta_path(profile: str, slug: str, env: str = "prod") -> Path:
    return _specs_dir(profile) / f"{slug}-{env}.meta.json"


def _is_fresh(profile: str, slug: str, env: str = "prod") -> bool:
    meta = _meta_path(profile, slug, env)
    if not meta.exists():
        return False
    try:
        data = json.loads(meta.read_text())
        fetched = datetime.fromisoformat(data["fetched_at"])
        age = (datetime.now(timezone.utc) - fetched).total_seconds()
        return age < _CACHE_TTL_SECONDS
    except Exception:
        return False


def _find_spec_env(app: dict) -> str | None:  # type: ignore[type-arg]
    """Return the name of the first environment with a spec, preferring 'prod'."""
    envs = app.get("environments", [])
    with_spec = [e for e in envs if e.get("latest_spec_version_id")]
    if not with_spec:
        return None
    prod = next((e for e in with_spec if e.get("name") == "prod"), None)
    return str((prod or with_spec[0])["name"])


def app_has_spec(app: dict) -> bool:  # type: ignore[type-arg]
    """Return True if any environment on this app has an active spec."""
    return any(e.get("latest_spec_version_id") for e in app.get("environments", []))


def get_spec_cached(
    app_id: str,
    slug: str,
    client: Any,
    profile: str,
    force: bool = False,
    env_name: str = "prod",
) -> dict | None:  # type: ignore[type-arg]
    """Return the OpenAPI spec for *slug*/*env_name*, fetching from the DTXApps API if needed.

    Uses GET /apps/{app_id}/envs/{env_name}/specs/active (v2).
    Cache key is per-slug-per-env: ``<slug>-<env>.json``.

    Returns None if the spec cannot be fetched or the env has no active spec.
    """
    specs_dir = _specs_dir(profile)
    spec_file = _spec_path(profile, slug, env_name)
    meta_file = _meta_path(profile, slug, env_name)

    if not force and _is_fresh(profile, slug, env_name) and spec_file.exists():
        try:
            return json.loads(spec_file.read_text())  # type: ignore[return-value,no-any-return]
        except Exception:
            pass

    # Fetch from DTXApps API (v2 per-env endpoint)
    try:
        r = client.get(f"{APPS_BASE}/{app_id}/envs/{env_name}/specs/active")
        if not r.is_success:
            return None
        spec = r.json()
        specs_dir.mkdir(parents=True, exist_ok=True)
        spec_file.write_text(json.dumps(spec, indent=2))
        meta_file.write_text(json.dumps({"fetched_at": datetime.now(timezone.utc).isoformat(), "app_id": app_id}))
        return spec  # type: ignore[return-value,no-any-return]
    except Exception:
        return None


def get_spec_by_slug_cached(
    slug: str,
    client: Any,
    profile: str,
    env_name: str = "prod",
    force: bool = False,
) -> tuple[str, dict] | None:  # type: ignore[type-arg]
    """Return (app_id, spec) for *slug* and *env_name*.

    Looks up the slug in the cached app list to get app_id, then delegates to
    get_spec_cached.  The meta file stores app_id so subsequent cache hits
    require zero API calls.

    Returns None if the slug is not found or the env has no active spec.
    """
    spec_file = _spec_path(profile, slug, env_name)
    meta_file = _meta_path(profile, slug, env_name)

    if not force and _is_fresh(profile, slug, env_name) and spec_file.exists() and meta_file.exists():
        try:
            meta = json.loads(meta_file.read_text())
            cached_app_id = meta.get("app_id")
            if cached_app_id:
                spec = json.loads(spec_file.read_text())
                return cached_app_id, spec  # type: ignore[return-value]
        except Exception:
            pass

    # Resolve slug → app_id via cached app list
    apps = get_app_list_cached(client, profile)
    app = next((a for a in apps if a.get("slug") == slug), None)
    if not app:
        return None
    app_id: str = app["app_id"]

    spec = get_spec_cached(app_id, slug, client, profile, force=force, env_name=env_name)
    if spec is None:
        return None
    return app_id, spec  # type: ignore[return-value]


_STALE_AGE_DAYS = 30


def _specs_root() -> Path:
    return Path.home() / CREDS_DIR_NAME / "specs"


def purge_stale_spec_files(max_age_days: int = _STALE_AGE_DAYS) -> None:
    """Delete stale files across all profile dirs under the specs root.

    Any file not modified within *max_age_days* is removed. Empty profile
    directories are removed afterwards; the specs root itself is never removed.
    """
    root = _specs_root()
    if not root.exists():
        return
    cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
    for profile_dir in list(root.iterdir()):
        if not profile_dir.is_dir():
            continue
        for f in list(profile_dir.iterdir()):
            if f.is_file() and datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc) < cutoff:
                f.unlink()
        if not any(profile_dir.iterdir()):
            profile_dir.rmdir()


def purge_spec_cache(profile: str) -> None:
    """Delete all cached specs and the app list for *profile*."""
    cache_dir = _specs_dir(profile)
    if cache_dir.exists():
        shutil.rmtree(cache_dir)


# ---------------------------------------------------------------------------
# App list cache
# ---------------------------------------------------------------------------


def _app_list_path(profile: str) -> Path:
    return _specs_dir(profile) / "_app_list.json"


def _app_list_meta_path(profile: str) -> Path:
    return _specs_dir(profile) / "_app_list.meta.json"


def purge_app_list_cache(profile: str) -> None:
    """Delete only the cached app list for *profile*, leaving spec files intact."""
    for path in (_app_list_path(profile), _app_list_meta_path(profile)):
        if path.exists():
            path.unlink()


def _is_app_list_fresh(profile: str) -> bool:
    meta = _app_list_meta_path(profile)
    if not meta.exists():
        return False
    try:
        data = json.loads(meta.read_text())
        fetched = datetime.fromisoformat(data["fetched_at"])
        age = (datetime.now(timezone.utc) - fetched).total_seconds()
        return age < _CACHE_TTL_SECONDS
    except Exception:
        return False


def get_app_list_cached(client: Any, profile: str, force: bool = False) -> list[dict]:  # type: ignore[type-arg]
    """Return all accessible apps, using a disk cache with a 1-hour TTL.

    Falls back to an empty list on any error so callers are never blocked.
    Pass ``force=True`` (or run ``dtxapps apps refresh``) to bypass the cache.
    """
    cache_file = _app_list_path(profile)
    meta_file = _app_list_meta_path(profile)

    if not force and _is_app_list_fresh(profile) and cache_file.exists():
        try:
            return json.loads(cache_file.read_text())  # type: ignore[return-value,no-any-return]
        except Exception:
            pass

    try:
        apps = client.fetch_all_pages(f"{APPS_BASE}?assigned_only=true")
    except Exception:
        return []
    specs_dir = _specs_dir(profile)
    specs_dir.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps(apps, indent=2))
    meta_file.write_text(json.dumps({"fetched_at": datetime.now(timezone.utc).isoformat()}))
    purge_stale_spec_files()
    return apps  # type: ignore[return-value,no-any-return]


def discover_apps(client: Any) -> list[dict]:  # type: ignore[type-arg]
    """Return the list of accessible apps from the DTXApps API."""
    r = client.get(APPS_BASE)
    if not r.is_success:
        return []
    from dtxapps.constants import RESPONSE_KEY_ITEMS

    return r.json().get(RESPONSE_KEY_ITEMS, [])  # type: ignore[return-value,no-any-return]
