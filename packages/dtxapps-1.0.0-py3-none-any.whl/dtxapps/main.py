import importlib.metadata
import sys

import typer
import typer.main
from dtxapps import context as _context
from dtxapps.constants import DEFAULT_API_URL, GIT_HASH, ENV_API_URL, ENV_API_KEY, OUTPUT_HELP
from dtxapps.services.auth.commands import auth_app
from dtxapps.services.auth.audit import app as audit_app
from dtxapps.services.auth.reports import app as reports_app
from dtxapps.services.auth.apps import app as registrations_app
from dtxapps.services.auth.lockdown import app as lockdown_app
from dtxapps.services.apps import apps_group
from dtxapps.services.config import app as config_app

_typer_app = typer.Typer(
    name="dtxapps",
    help=(
        "DTXApps CLI\n\n"
        "Getting started — choose one:\n\n"
        "  Interactive login:\n\n"
        f"    dtxapps config set-profile --url {DEFAULT_API_URL}\n"
        "    dtxapps auth login\n\n"
        "  API key via profile (no login needed):\n\n"
        f"    dtxapps config set-profile --url {DEFAULT_API_URL} --api-key <key>\n\n"
        "  API key via env (service accounts / automation):\n\n"
        f"    export {ENV_API_URL}={DEFAULT_API_URL}\n"
        f"    export {ENV_API_KEY}=<your-api-key>"
    ),
    no_args_is_help=True,
    pretty_exceptions_show_locals=False,
)

_typer_app.add_typer(config_app, name="config", help="Configure the CLI (URL, profiles)")
_typer_app.add_typer(auth_app, name="auth", help="Auth service — identities, roles, API keys")
_typer_app.add_typer(
    registrations_app,
    name="registrations",
    help="App registrations — register, approve, reject, manage",
)
_typer_app.add_typer(audit_app, name="audit", help="Audit log — list and inspect audit events")
_typer_app.add_typer(
    lockdown_app,
    name="lockdown",
    help="Emergency lockdown — activate, deactivate, or check status",
)
_typer_app.add_typer(
    reports_app,
    name="reports",
    help="Compliance reports — generate, list, and download",
)


def _version_callback(value: bool) -> None:
    if value:
        ver = importlib.metadata.version("dtxapps")
        typer.echo(f"{ver} (git: {GIT_HASH})")
        raise typer.Exit()


def _pre_parse_globals(argv: list[str]) -> tuple[list[str], str | None, str | None, bool]:
    """Strip --profile/-p, --output/-o, and --debug from anywhere in argv; return (cleaned, profile, output, debug)."""
    result: list[str] = []
    profile: str | None = None
    output: str | None = None
    debug: bool = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--profile", "-p") and i + 1 < len(argv):
            profile = argv[i + 1]
            i += 2
        elif arg.startswith("--profile="):
            profile = arg.split("=", 1)[1]
            i += 1
        elif arg in ("--output", "-o") and i + 1 < len(argv):
            output = argv[i + 1]
            i += 2
        elif arg.startswith("--output="):
            output = arg.split("=", 1)[1]
            i += 1
        elif arg == "--debug":
            debug = True
            i += 1
        else:
            result.append(arg)
            i += 1
    return result, profile, output, debug


@_typer_app.callback()
def _global_options(
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit."),
    debug: bool = typer.Option(False, "--debug", help="Print HTTP request/response details to stderr."),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Credential profile to use."),
    output: str | None = typer.Option(None, "--output", "-o", help=OUTPUT_HELP),
) -> None:
    # pre_parse_globals already handled all three; these are no-ops unless the flag
    # appears at root level before a subcommand and was not stripped (shouldn't happen,
    # but guard here for safety).
    if debug:
        _context.set_debug(debug)
    if profile is not None:
        _context.set_profile(profile, explicit=True)
    if output is not None:
        _context.set_output(output)


def main() -> None:
    cleaned, profile, output, debug = _pre_parse_globals(sys.argv[1:])
    if debug:
        _context.set_debug(True)
    if profile is not None:
        _context.set_profile(profile, explicit=True)
    if output is not None:
        _context.set_output(output)
    sys.argv = [sys.argv[0]] + cleaned
    # Build the Click group from the Typer app, then attach the dynamic apps group.
    click_app = typer.main.get_command(_typer_app)
    click_app.add_command(apps_group, name="apps")  # type: ignore[attr-defined]
    click_app(prog_name="dtxapps")


# Allow ``python -m dtxapps`` and direct entry-point invocation
app = main  # entry point alias used in pyproject.toml

if __name__ == "__main__":
    main()
