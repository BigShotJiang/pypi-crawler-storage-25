import json
import sys
from pathlib import Path
from typing import Any, cast

import typer
from rich.console import Console


def load_json_payload(
    file: Path | None,
    json_str: str | None,
    err_console: Console,
) -> dict[str, Any]:
    """Load a JSON payload from --file, --json, or stdin."""
    if file:
        try:
            return cast(dict[str, Any], json.loads(file.read_text()))
        except (FileNotFoundError, PermissionError, json.JSONDecodeError) as e:
            err_console.print(f"[red]Error: could not read {file}: {e}[/red]")
            raise typer.Exit(1)
    if json_str:
        return cast(dict[str, Any], json.loads(json_str))
    raw = sys.stdin.read().strip()
    if not raw:
        err_console.print("[red]No input provided. Use --file, --json, or pipe JSON via stdin.[/red]")
        raise SystemExit(1)
    return cast(dict[str, Any], json.loads(raw))


def build_page_params(limit: int, cursor: str | None = None) -> dict[str, Any]:
    """Build a pagination params dict for cursor-paginated API calls."""
    params: dict[str, Any] = {"limit": limit}
    if cursor:
        params["cursor"] = cursor
    return params


def confirm_option(prompt: str) -> Any:
    return typer.Option(False, "--confirm", prompt=prompt)


def load_value(raw: str) -> Any:
    """Parse raw as JSON; fall back to returning it as a plain string."""
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw


def pick(data: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    """Return a new dict containing only the specified keys."""
    return {k: v for k, v in data.items() if k in keys}


def require_confirm(confirm: bool) -> None:
    if not confirm:
        raise typer.Abort()
