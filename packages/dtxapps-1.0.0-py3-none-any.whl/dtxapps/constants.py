from pathlib import Path

# Default API URL
DEFAULT_API_URL = "https://dtxapps.dotmatics.com"

# Build info (injected at publish time by cli-publish.sh)
GIT_HASH = "fb48521"

# Image MIME types for icon upload
IMAGE_MIME_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}

# Output option help text
OUTPUT_HELP = "Output format: table or json"

# HTTP client
HTTP_TIMEOUT = 10

# CLI option defaults
DEFAULT_PAGE_SIZE = 50
FETCH_ALL_PAGES_LIMIT = 200
DEFAULT_PROFILE = "default"
DEFAULT_OUTPUT_FORMAT = "table"

# Token handling
TOKEN_EXPIRY_BUFFER_SECONDS = 30

# Environment variables
ENV_API_KEY = "DTXAPPS_API_KEY"
ENV_API_URL = "DTXAPPS_URL"

# JSON response keys
RESPONSE_KEY_ITEMS = "items"
RESPONSE_KEY_NEXT_CURSOR = "next_cursor"

# HTTP status codes
HTTP_OK = 200
HTTP_NO_CONTENT = 204

# Display truncation
LOG_ID_DISPLAY_LENGTH = 20
ACTOR_ID_DISPLAY_LENGTH = 8

# PKCE callback port range
PKCE_PORT_MIN = 9870
PKCE_PORT_MAX = 9877
PKCE_SCOPE = "openid email profile"
PKCE_RESPONSE_TYPE = "code"
PKCE_CHALLENGE_METHOD = "S256"
PKCE_VERIFIER_BYTES = 64

# Group member types
MEMBER_TYPE_IDENTITY = "identity"
MEMBER_TYPE_GROUP = "group"

# Config directory and file paths (used in 2+ files — ADR-014)
CREDS_DIR_NAME = ".dot_dtxapps"
PROFILES_FILE = Path.home() / CREDS_DIR_NAME / "profiles"
APP_TOKENS_FILE = Path.home() / CREDS_DIR_NAME / "app_tokens"

# API path prefixes (used in 2+ files — ADR-019)
APPS_BASE = "/apps"
APPS_EXCHANGE_CODE = "/apps/exchange-code"
AUTH_GROUPS_BASE = "/auth/groups"
AUTH_IDENTITIES_BASE = "/auth/identities"
AUTH_IDENTITY_GROUPS_PATH = AUTH_IDENTITIES_BASE + "/{identity_id}/groups"
AUTH_REFRESH = "/auth/refresh"
AUTH_ROLES_BASE = "/auth/roles"
AUTH_SESSIONS_BASE = "/auth/sessions"
AUDIT_EVENTS_BASE = "/audit/events"
REPORTS_BASE = "/audit/reports"
REPORTS_COMPLIANCE_REPORT = REPORTS_BASE + "/compliance-report"
