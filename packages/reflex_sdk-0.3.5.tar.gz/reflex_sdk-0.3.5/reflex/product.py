"""Dependency-free client for the Convex-backed Reflex product API."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal
from urllib import error, parse, request

from ._version import user_agent

PRODUCT_CLI_USER_AGENT = user_agent("reflex-product-cli")

if TYPE_CHECKING:
    from typing import TypeAlias

    JsonValue: TypeAlias = None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]
    FunctionKind: TypeAlias = Literal["query", "mutation", "action"]
else:
    JsonValue = Any
    FunctionKind = Literal["query", "mutation", "action"]


class ProductError(RuntimeError):
    pass


class AuthError(ProductError):
    pass


def _env(name: str) -> str:
    return os.environ.get(name, "").strip()


def config_path() -> Path:
    explicit = _env("REFLEX_CONFIG_FILE")
    if explicit:
        return Path(explicit).expanduser()
    config_dir = _env("REFLEX_CONFIG_DIR")
    if config_dir:
        return Path(config_dir).expanduser() / "credentials.json"
    xdg = _env("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / "reflex" / "credentials.json"


def load_credentials() -> dict[str, JsonValue]:
    path = config_path()
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProductError(f"Failed to read Reflex credentials at {path}: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ProductError(f"Reflex credentials at {path} must be a JSON object.")
    return parsed


def save_credentials(*, api_key: str, convex_url: str, site_url: str | None = None) -> Path:
    path = config_path()
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload: dict[str, JsonValue] = {
        "apiKey": api_key,
        "convexUrl": convex_url,
    }
    if site_url:
        payload["siteUrl"] = site_url
    tmp = path.with_suffix(path.suffix + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    tmp.replace(path)
    return path


def clear_credentials() -> bool:
    path = config_path()
    if not path.exists():
        return False
    path.unlink()
    return True


def resolve_api_key(value: str | None = None) -> str:
    resolved = value or _env("REFLEX_API_KEY") or _env("RFX_API_KEY")
    if not resolved:
        stored = load_credentials().get("apiKey")
        resolved = stored if isinstance(stored, str) else ""
    resolved = resolved.strip()
    if not resolved:
        raise ProductError("API key is required. Run `reflex login` or set REFLEX_API_KEY.")
    return resolved


def resolve_convex_url(value: str | None = None) -> str:
    resolved = (
        value
        or _env("REFLEX_CONVEX_URL")
        or _env("CONVEX_URL")
        or _env("NEXT_PUBLIC_CONVEX_URL")
    )
    if not resolved:
        stored = load_credentials().get("convexUrl")
        resolved = stored if isinstance(stored, str) else ""
    resolved = resolved.strip().rstrip("/")
    if not resolved:
        raise ProductError("Convex URL is required. Set REFLEX_CONVEX_URL or pass --convex-url.")
    parsed = parse.urlparse(resolved)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ProductError("Convex URL must start with http:// or https://.")
    return resolved


def resolve_site_url(value: str | None = None) -> str:
    resolved = (
        value
        or _env("REFLEX_PLATFORM_URL")
        or _env("NEXT_PUBLIC_SITE_URL")
        or _env("BETTER_AUTH_URL")
        or _env("NEXT_PUBLIC_BETTER_AUTH_URL")
    )
    if not resolved:
        stored = load_credentials().get("siteUrl")
        resolved = stored if isinstance(stored, str) else ""
    resolved = resolved.strip().rstrip("/")
    if not resolved:
        raise ProductError("Platform URL is required for login approval links. Set REFLEX_PLATFORM_URL or pass --site-url.")
    parsed = parse.urlparse(resolved)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ProductError("Platform URL must start with http:// or https://.")
    return resolved


def load_json_arg(raw: str, *, label: str) -> JsonValue:
    try:
        text = Path(raw[1:]).read_text(encoding="utf-8") if raw.startswith("@") else raw
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProductError(f"{label} must be valid JSON.") from exc
    except OSError as exc:
        raise ProductError(f"Failed to read {label}: {exc}") from exc
    return parsed


def expect_object(value: JsonValue, *, label: str) -> dict[str, JsonValue]:
    if not isinstance(value, dict):
        raise ProductError(f"{label} must be a JSON object.")
    return value


class ProductClient:
    def __init__(self, convex_url: str | None = None) -> None:
        self.convex_url = resolve_convex_url(convex_url)

    def call(self, kind: FunctionKind, path: str, args: dict[str, JsonValue] | None = None) -> JsonValue:
        body = json.dumps({"path": path, "args": args or {}, "format": "json"}).encode("utf-8")
        req = request.Request(
            f"{self.convex_url}/api/{kind}",
            data=body,
            method="POST",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": PRODUCT_CLI_USER_AGENT,
            },
        )
        try:
            with request.urlopen(req, timeout=30) as response:
                raw = response.read().decode("utf-8")
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise ProductError(f"Convex HTTP {exc.code}: {detail}".strip()) from exc
        except error.URLError as exc:
            raise ProductError(f"Failed to reach Convex: {exc.reason}") from exc
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError as exc:
            raise ProductError(f"Invalid Convex response: {raw[:200]}") from exc
        if not isinstance(parsed, dict):
            raise ProductError(f"Unexpected Convex response: {parsed!r}")
        if parsed.get("status") == "success":
            value = parsed.get("value")
            return value if _is_json_value(value) else None
        message = parsed.get("errorMessage")
        if not isinstance(message, str):
            message = "Convex function failed"
        raise ProductError(message)

    def query(self, path: str, args: dict[str, JsonValue] | None = None) -> JsonValue:
        return self.call("query", path, args)

    def mutation(self, path: str, args: dict[str, JsonValue] | None = None) -> JsonValue:
        return self.call("mutation", path, args)

    def action(self, path: str, args: dict[str, JsonValue] | None = None) -> JsonValue:
        return self.call("action", path, args)


class AuthClient:
    def __init__(self, site_url: str | None = None) -> None:
        self.site_url = resolve_site_url(site_url)

    def post(self, path: str, body: dict[str, JsonValue]) -> JsonValue:
        route = path if path.startswith("/") else f"/{path}"
        payload = json.dumps(body).encode("utf-8")
        req = request.Request(
            f"{self.site_url}/api/auth{route}",
            data=payload,
            method="POST",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": PRODUCT_CLI_USER_AGENT,
            },
        )
        try:
            with request.urlopen(req, timeout=30) as response:
                raw = response.read().decode("utf-8")
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise AuthError(_better_auth_error(detail) or f"Better Auth HTTP {exc.code}") from exc
        except error.URLError as exc:
            raise AuthError(f"Failed to reach Reflex Platform auth: {exc.reason}") from exc
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError as exc:
            raise AuthError(f"Invalid Better Auth response: {raw[:200]}") from exc
        if not _is_json_value(parsed):
            raise AuthError(f"Unexpected Better Auth response: {parsed!r}")
        if isinstance(parsed, dict) and _better_auth_error(parsed):
            raise AuthError(_better_auth_error(parsed))
        return parsed

    def sign_up_email(
        self,
        *,
        name: str,
        email: str,
        password: str,
        callback_url: str | None = None,
    ) -> JsonValue:
        body: dict[str, JsonValue] = {
            "name": name,
            "email": email,
            "password": password,
        }
        if callback_url:
            body["callbackURL"] = callback_url
        return self.post("/sign-up/email", body)


def _better_auth_error(value: JsonValue | str) -> str:
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return value.strip()
        return _better_auth_error(parsed)
    if not isinstance(value, dict):
        return ""
    error_value = value.get("error")
    if isinstance(error_value, dict):
        message = error_value.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
    if isinstance(error_value, str) and error_value.strip():
        return error_value.strip()
    message = value.get("message")
    if isinstance(message, str) and message.strip():
        return message.strip()
    return ""


def _is_json_value(value: object) -> bool:
    if value is None or isinstance(value, (bool, int, float, str)):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(key, str) and _is_json_value(item) for key, item in value.items())
    return False
