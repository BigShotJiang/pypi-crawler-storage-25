"""The Pirate Bay source: apibay.org JSON API (preferred) + multi-domain
HTML fallback chain."""

import re
import urllib.parse

import requests
from bs4 import BeautifulSoup

from torrent_hound import state
from torrent_hound.ui import colored

from .base import (
    _extract_release_tags,
    _fmt_date,
    _fmt_runtime,
    _format_bytes,
    _https_get,
    _normalise_codec,
    removeAndReplaceSpaces,
)

# `Movie.Title.2024.1080p` or `Movie Title (2024) [...]` — pull the
# rightmost plausible release year. Capped at 2030 so titles whose name
# contains a far-future year (e.g. `Blade Runner 2049`, `2001: A Space
# Odyssey`) don't get the title-year mistaken for a release date.
_YEAR_RE = re.compile(r'\b(19\d{2}|20[0-2]\d|2030)\b')

# Canonical JSON API the TPB front-end SPA uses. Documented nowhere but
# read directly out of `thepiratebay.org/static/main.js`'s `print_trackers`
# / fetch logic. Returns a JSON list of torrent records keyed by name and
# info_hash; magnets are constructed client-side by the SPA.
APIBAY_HOST = 'apibay.org'
APIBAY_URL = f'https://{APIBAY_HOST}'

# Tracker set extracted verbatim from the TPB SPA's `print_trackers()`
# function. Embedded in client-built magnets so newly-added swarms can
# discover peers without DHT bootstrap delay.
TPB_TRACKERS = [
    'udp://tracker.opentrackr.org:1337',
    'udp://open.stealth.si:80/announce',
    'udp://tracker.torrent.eu.org:451/announce',
    'udp://tracker.bittor.pw:1337/announce',
    'udp://public.popcorn-tracker.org:6969/announce',
    'udp://tracker.dler.org:6969/announce',
    'udp://exodus.desync.com:6969',
    'udp://open.demonii.com:1337/announce',
    'udp://glotorrents.pw:6969/announce',
    'udp://tracker.coppersurfer.tk:6969',
    'udp://torrent.gresille.org:80/announce',
    'udp://p4p.arenabg.com:1337',
    'udp://tracker.internetwarriors.net:1337',
]

# HTML-scraped TPB mirrors, tried after apibay if it's unreachable.
# Mirrors churn often; add new ones to the front when they come up, drop
# dead ones from the tail.
TPB_DOMAINS = [
    'thepiratebay.org',
    'thepiratebay.zone',
    'tpb.party',
    'piratebay.party',
    'pirateproxy.live',
]


def _tpb_page_is_empty_results(html) -> bool:
    """True if `html` is a successfully-served TPB results page that just has
    zero matches (the searchResult table is present but contains only the
    header row). Distinguishes from dead/blocked mirrors so the source can
    emit `empty` (genuine no-results, stop probing) vs `mirror_failed`
    (table missing, try the next mirror)."""
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.find("table", {"id": "searchResult"})
    if table is None:
        return False
    return len(table.find_all("tr")) <= 1


# A size cell looks like "6.07 GiB" or "780 MB" — number, optional decimal,
# optional space, then a binary or decimal byte unit. Used by the modern-
# layout parser to identify which td holds the size.
_SIZE_CELL_RE = re.compile(r'^\d+(?:\.\d+)?\s*[KMGT]i?B$', re.IGNORECASE)


def _parse_tpb_html(html, domain='thepiratebay.zone', limit=10):
    """Parse a TPB search-results HTML document. Returns [] if the expected
    results table isn't present (domain is dead / blocked / CAPTCHA).

    Two row layouts in the wild:

    * Legacy: 4 td cells. tds[1] holds <a class="detLink"> + a nested
      magnet <a> with <img alt="Magnet link"> + a <font> carrying size in
      a comma-separated 'Uploaded ..., Size X, ULed by Y' string.
      tds[2]/tds[3] are seeders/leechers.

    * Modern (tpb.party and similar): 8 td cells. The detail link has no
      class. Magnet, size, seeders, leechers, uploader each get their own
      cell. Detected by walking td contents rather than relying on
      positional indices, since the legacy layout would clobber the same
      assumptions if we tried to be too rigid.
    """
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.find("table", {"id": "searchResult"})
    if table is None:
        return []
    trs = table.find_all("tr")[1:]  # drop header row
    parsed = []
    base = f'https://{domain}'
    for tr in trs[:limit]:
        try:
            row = _parse_tpb_row(tr, base)
        except (AttributeError, IndexError, KeyError, TypeError, ValueError):
            continue  # malformed row; skip — don't tank the whole page
        if row is not None:
            parsed.append(row)
    return parsed


def _parse_tpb_row(tr, base):
    """Extract one Result-shaped dict from a TPB search-results row, or
    return None when the row doesn't carry the fields we need (ad rows,
    separator rows, broken markup). Raises only on truly unexpected shapes
    — the caller's per-row try/except handles those."""
    # Detail link: any <a> whose href contains '/torrent/'. Works for both
    # the legacy 'detLink' class and the modern bare-anchor markup.
    name_a = tr.find('a', href=lambda h: h and '/torrent/' in h)
    if name_a is None:
        return None
    name = name_a.get_text(strip=True)
    if not name:
        return None
    href = name_a['href']
    if href.startswith("http"):
        # Force https on absolute URLs — some mirrors emit http:// in the
        # search-row href even though the page itself was served over https.
        link = re.sub(r'^http://', 'https://', href, count=1)
    else:
        link = f"{base}{href}"

    # Magnet: any <a href="magnet:..."> in the row. Legacy nests it inside
    # tds[1]; modern puts it in its own cell. Either way `tr.find` reaches it.
    magnet_a = tr.find('a', href=lambda h: h and h.startswith('magnet:'))
    if magnet_a is None:
        return None
    magnet = magnet_a['href']

    # Seeders / leechers: pair of consecutive numeric-only td cells. Legacy
    # puts them in tds[2]/tds[3]; modern in tds[5]/tds[6] (uploader at [7]).
    tds = tr.find_all('td')
    sl_pair: tuple[int, int] | None = None
    for i in range(len(tds) - 1):
        a = tds[i].get_text(strip=True)
        b = tds[i + 1].get_text(strip=True)
        if a.isdigit() and b.isdigit():
            sl_pair = (int(a), int(b))
            break
    if sl_pair is None:
        return None
    seeders, leechers = sl_pair

    # Size: legacy carries it inside <font> as 'Uploaded ..., Size X, ULed
    # by Y'; modern uses a dedicated td whose text matches the size pattern.
    size = None
    font = tr.find('font')
    if font and font.contents:
        try:
            size = str(font.contents[0]).split(',')[1].split(' ')[2].replace('\xa0', ' ')
        except (IndexError, AttributeError):
            size = None
    if size is None:
        for td in tds:
            text = td.get_text(strip=True).replace('\xa0', ' ')
            if _SIZE_CELL_RE.match(text):
                size = text
                break
    if size is None:
        return None

    try:
        ratio = format(float(seeders) / float(leechers), '.1f')
    except ZeroDivisionError:
        ratio = 'inf'

    metadata: dict = {"name": name}
    metadata.update(_extract_release_tags(name))
    year_matches = _YEAR_RE.findall(name)
    if year_matches:
        metadata["released"] = year_matches[-1]

    return {
        'name': name,
        'link': link,
        'seeders': seeders,
        'leechers': leechers,
        'magnet': magnet,
        'size': size,
        'ratio': ratio,
        'metadata': metadata,
    }


def _build_tpb_magnet(info_hash, name):
    """Construct a TPB magnet URI matching what the SPA's print_trackers()
    builds client-side. info_hash is a 40-char hex string."""
    dn = urllib.parse.quote(name)
    trackers = '&'.join(f'tr={urllib.parse.quote(t, safe="")}' for t in TPB_TRACKERS)
    return f'magnet:?xt=urn:btih:{info_hash}&dn={dn}&{trackers}'


def _tpb_slug(name):
    """Best-effort URL slug for the TPB torrent page. The numeric id alone
    is what TPB's router uses; the slug is decoration. Empty input yields
    'item' so we never produce a URL ending in a stray slash."""
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', name).strip('_').lower()[:80]
    return slug or 'item'


def _parse_apibay_item(item):
    """Convert one apibay JSON record into a Result-shaped dict, or return
    None when the item is the 'no results' sentinel or missing required
    fields. Apibay's empty response is a single record with id='0' and
    info_hash='0' * 40."""
    info_hash = (item.get('info_hash') or '').strip()
    name = (item.get('name') or '').strip()
    item_id = item.get('id') or ''
    if not info_hash or not name or info_hash == '0' * 40 or item_id == '0':
        return None
    try:
        seeders = int(item.get('seeders', 0))
        leechers = int(item.get('leechers', 0))
        size_bytes = int(item.get('size', 0))
    except (ValueError, TypeError):
        return None
    try:
        ratio = format(seeders / leechers, '.1f') if leechers else 'inf'
    except ZeroDivisionError:
        ratio = 'inf'

    metadata: dict = {'name': name}
    metadata.update(_extract_release_tags(name))
    year_matches = _YEAR_RE.findall(name)
    if year_matches:
        metadata['released'] = year_matches[-1]
    if item.get('imdb'):
        metadata['imdb_code'] = item['imdb']
    if item.get('username'):
        metadata['uploader'] = item['username']
    try:
        added = int(item.get('added') or 0)
        if added:
            d = _fmt_date(added)
            if d:
                metadata['uploaded'] = d
    except (ValueError, TypeError):
        pass
    if item.get('num_files'):
        try:
            metadata['files'] = int(item['num_files'])
        except (ValueError, TypeError):
            pass
    # Stash the apibay id so the metadata overlay's lazy worker can fetch
    # `t.php?id=<id>` for the descr field instead of trying to scrape the
    # SPA-rendered detail page (which has no server-side content).
    metadata['_apibay_id'] = item_id

    return {
        'name': name,
        'link': f'https://thepiratebay.org/torrent/{item_id}/{_tpb_slug(name)}',
        'seeders': seeders,
        'leechers': leechers,
        'size': _format_bytes(size_bytes),
        'ratio': ratio,
        'magnet': _build_tpb_magnet(info_hash, name),
        'metadata': metadata,
    }


def _search_apibay(search_string, limit=10, timeout=8, progress=None):
    """Hit apibay.org's q.php JSON endpoint — the canonical data source
    the TPB SPA uses. Returns a Result-shaped list (possibly empty when
    apibay says 'No results returned'), or None when apibay itself is
    unreachable / returns non-JSON / wrong shape so the caller can fall
    back to HTML mirrors."""
    url = f'{APIBAY_URL}/q.php?q={urllib.parse.quote_plus(search_string)}'
    if progress:
        progress({'type': 'mirror_attempt', 'mirror': APIBAY_HOST})
    try:
        r = _https_get(url, timeout=timeout)
        data = r.json()
    except (requests.RequestException, ValueError):
        if progress:
            progress({'type': 'mirror_failed', 'mirror': APIBAY_HOST})
        return None
    if not isinstance(data, list):
        if progress:
            progress({'type': 'mirror_failed', 'mirror': APIBAY_HOST})
        return None

    rows = []
    for item in data:
        parsed = _parse_apibay_item(item)
        if parsed is not None:
            rows.append(parsed)
            if len(rows) >= limit:
                break

    state.tpb_url = url
    if progress:
        if rows:
            progress({'type': 'ok', 'count': len(rows), 'mirror': APIBAY_HOST})
        else:
            progress({'type': 'empty'})
    return rows


def searchPirateBayCondensed(search_string='', quiet_mode=False, limit=10, timeout=8, progress=None):
    """Try the apibay JSON API first — that's the canonical data source the
    TPB front-end SPA fetches from, so it's what 'thepiratebay.org works'
    actually means in practice. Fall back to legacy HTML mirrors when
    apibay is unreachable.

    `progress`, if provided, receives `mirror_attempt`/`mirror_failed`/
    `ok`/`empty`/`failed` events for the TUI's source-trail display.
    """
    api_results = _search_apibay(search_string, limit=limit, timeout=timeout, progress=progress)
    if api_results is not None:
        # apibay responded — definitive (success or genuine empty); don't
        # probe HTML mirrors. Same logic as the per-mirror empty case.
        state.results_tpb_condensed = api_results
        return api_results

    # apibay unreachable — fall through to legacy HTML mirror chain.
    domains_to_try = [state.tpb_working_domain] + [d for d in TPB_DOMAINS if d != state.tpb_working_domain]
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0'}

    for domain in domains_to_try:
        url = f'https://{domain}/s/?q={removeAndReplaceSpaces(search_string)}&page=0&orderby=99'
        if progress:
            progress({"type": "mirror_attempt", "mirror": domain})
        try:
            r = _https_get(url, headers=headers, timeout=timeout)
            parsed = _parse_tpb_html(r.content, domain=domain, limit=limit)
            if parsed:
                state.tpb_working_domain = domain
                state.tpb_url = url
                state.results_tpb_condensed = parsed
                if progress:
                    progress({"type": "ok", "count": len(parsed), "mirror": domain})
                return parsed
            # Empty parse: distinguish "mirror served us a real no-hits page"
            # from "mirror is dead / blocked / CAPTCHA". Probing more mirrors
            # only makes sense for the latter.
            if _tpb_page_is_empty_results(r.content):
                state.tpb_working_domain = domain
                state.results_tpb_condensed = []
                if progress:
                    progress({"type": "empty"})
                return []
            if progress:
                progress({"type": "mirror_failed", "mirror": domain})
        except requests.RequestException:
            if progress:
                progress({"type": "mirror_failed", "mirror": domain})
            continue

    if not quiet_mode:
        print(colored.magenta("[PirateBay] Error : All known mirrors returned no results or were unreachable"))
    state.results_tpb_condensed = []
    if progress:
        progress({"type": "failed"})
    return state.results_tpb_condensed


# ── lazy detail-page fetch ──────────────────────────────────────────────

# Map from `<dt>` label text on the detail page to our metadata field name.
_DT_LABEL_TO_FIELD = {
    'Type:': 'category',
    'Files:': 'files',
    'Uploaded:': 'uploaded',
    'By:': 'uploader',
}

_IMDB_URL_RE = re.compile(r'imdb\.com/title/(tt\d+)')
# Single-line `Label: value` patterns (GalaxyRG-style descriptions).
_GENRE_RE    = re.compile(r'^\s*Genre:\s*(.+)', re.MULTILINE)
_DIRECTOR_RE = re.compile(r'^\s*Directors?:\s*(.+)', re.MULTILINE)
_STARS_RE    = re.compile(r'^\s*Stars?:\s*(.+)', re.MULTILINE)
_PLOT_RE     = re.compile(r'^\s*Plot:\s*(.+?)(?=\n\s*\n|\n\s*[A-Z]+:|\Z)', re.MULTILINE | re.DOTALL)
# Multi-line block format used by IMDB-style scrapes:
#   Directors
#   Name One
#   Name Two
#   <blank>           ← stop on blank
# OR
#   Directors
#   Name One
#   Writers           ← stop on next known heading (no blank line between)
#   ...
_NEXT_HEADING = r'(?:Stars?|Writers?|Cast|Genres?|Plot|Synopsis|Storyline)'
_DIRECTOR_BLOCK_RE = re.compile(
    r'^\s*Directors?\s*$\n'
    r'((?:^\s*[^\s:][^\n:]*$\n?)+?)'
    r'(?=^\s*$|^\s*' + _NEXT_HEADING + r'\s*$|\Z)',
    re.MULTILINE | re.IGNORECASE,
)
_STARS_BLOCK_RE = re.compile(
    r'^\s*Stars?\s*$\n'
    r'((?:^\s*[^\s:][^\n:]*$\n?)+?)'
    r'(?=^\s*$|^\s*' + _NEXT_HEADING + r'\s*$|\Z)',
    re.MULTILINE | re.IGNORECASE,
)
# Slash-separated genre line on its own (no `Genre:` prefix). Conservative —
# require ≥ 3 segments to avoid false positives on "I/O" or "and/or" prose.
_SLASH_GENRE_RE = re.compile(
    r'^\s*([A-Z][a-z]+(?:\s*/\s*[A-Z][a-z]+){2,})\s*$',
    re.MULTILINE,
)
# Multiple duration formats — try each in order:
#   `Duration = HH:MM:SS` (GalaxyRG MEDIAINFO)
#   `Duration : 1 h 32 min` (R8 aligned-row format)
#   `Duration.....: 1h 34mn` (R4 dot-padded label, `mn` minute alias)
#   `Length..............: 1h30mn` (R7 — `Length` label alias, no internal space)
#   `[RUNTIME]:.[ 1Hr 32Min` (R3 bracketed format)
_DURATION_HMS_RE = re.compile(
    r'(?:Duration|Runtime|Length|RUNTIME\b[^\n]*)[\s=:.]+\s*(\d{1,2}):(\d{2}):(\d{2})',
    re.IGNORECASE,
)
_DURATION_HM_RE = re.compile(
    r'(?:Duration|Runtime|Length|\[\s*RUNTIME\s*\][^\n]*?)[\s=:.]+\s*\[?\s*'
    r'(\d+)\s*(?:h|hr|hour)s?\.?\s*(\d+)\s*(?:m|mn|min|minute)s?\.?',
    re.IGNORECASE,
)
# Misc-line patterns (broader). Three shapes the parser recognises:
#   `[LABEL]:....[ value`        — bracketed label + bracketed value (R3, R10)
#   `Label.......: value`        — aligned `Label : value` with optional dot
#                                   padding between label and colon (R4, R7, R8)
#   `LABEL: value`               — uppercase-only label (GalaxyRG)
_MISC_BRACKETED_RE = re.compile(
    r'^\s*\[([A-Z][A-Z0-9 _-]{1,30})\][:.\s]+\[\s*(.+?)\s*\]?\s*$',
    re.MULTILINE,
)
_MISC_ALIGNED_RE = re.compile(
    r'^\s*\.?([A-Z][A-Za-z0-9 _()-]{1,40}?)[.\s]*:\s+(.+?)\s*$',
    re.MULTILINE,
)
_MISC_UPPER_RE = re.compile(
    r'^\s*([A-Z][A-Z0-9 _-]{1,30}):\s*(.+)',
    re.MULTILINE,
)
# Bracketed [GENRE] — extract structured genre when no `Genre:` line exists.
_BRACKETED_GENRE_RE = re.compile(
    r'^\s*\[\s*GENRE\s*\][:.\s]+\[\s*(.+?)\s*\]?\s*$',
    re.MULTILINE,
)
# Video codec — pick the first recognised codec mention anywhere in
# the description. AVC / HEVC are the underlying H.264 / H.265 specs;
# x264 / x265 are encoder names. Both forms appear in the wild.
_VIDEO_CODEC_RE = re.compile(
    r'\b(x265|x264|h\.?265|h\.?264|HEVC|AVC|XviD|DivX|VP9|AV1)\b',
    re.IGNORECASE,
)
# Audio channels — common surround configurations (5.1, 7.1, 2.0).
# Anchored to a digit boundary so dates like 5.12.2024 don't match.
_AUDIO_CHANNELS_RE = re.compile(
    r'\b([1-9](?:\.[0-9])?)\s*(?:channels?|surround|stereo)\b',
    re.IGNORECASE,
)
# Audio codec — first recognised audio format in the description.
# DDP/DD with optional channel layout: `DDP`, `DDP5`, `DDP5.1`, `DDP.5`,
# `DDP.5.1`, `DD7.1` etc. all match.
_AUDIO_CODEC_RE = re.compile(
    r'\b(AAC|FLAC|MP3|Opus|TrueHD|Atmos|DTS(?:-HD)?|E-?AC-?3|AC-?3|'
    r'DDP?(?:[.]?\d(?:\.\d)?)?)\b',
    re.IGNORECASE,
)
# Subtitles — bracketed `[SUBTITLES]:` (R3, R10), aligned `Subtitle(s) : list`
# (R7, R8), or single-line `Subtitles: list`.
_SUBTITLES_RE = re.compile(
    r'(?:^\s*\[\s*SUBTITLES?\s*\][:.\s]+\[\s*|'
    r'^\s*Subtitles?\s*\(?s?\)?[.\s]*:\s+|'
    r'^\s*Included subtitles\s*=\s*)'
    r'(.+?)(?:\s*\(SRT File\))?\s*\]?\s*$',
    re.MULTILINE | re.IGNORECASE,
)
# Labels we already capture as structured fields — exclude from misc.
_KNOWN_LABELS = frozenset({
    "GENRE", "DIRECTOR", "DIRECTORS", "STAR", "STARS", "PLOT",
    "RUNTIME", "DURATION", "IMDB",
})


def _extract_director(desc: str) -> str | None:
    """Try `Director:` single-line first, fall back to `Directors\\n<block>`."""
    if (m := _DIRECTOR_RE.search(desc)):
        return m.group(1).strip()
    if (m := _DIRECTOR_BLOCK_RE.search(desc)):
        names = [ln.strip() for ln in m.group(1).splitlines() if ln.strip()]
        if names:
            return ", ".join(names)
    return None


def _extract_cast(desc: str) -> str | None:
    """Try `Stars:` single-line first, fall back to `Stars\\n<block>`. Cap at 5."""
    if (m := _STARS_RE.search(desc)):
        names = [n.strip() for n in m.group(1).split(",") if n.strip()]
    elif (m := _STARS_BLOCK_RE.search(desc)):
        names = [ln.strip() for ln in m.group(1).splitlines() if ln.strip()]
    else:
        return None
    return ", ".join(names[:5]) if names else None


def _extract_genre(desc: str) -> str | None:
    """Try `Genre:` single-line first, then a bare slash-separated line,
    then bracketed `[GENRE]:....[ value` (R10/YIFY format)."""
    if (m := _GENRE_RE.search(desc)):
        return m.group(1).strip()
    if (m := _SLASH_GENRE_RE.search(desc)):
        return m.group(1).strip()
    if (m := _BRACKETED_GENRE_RE.search(desc)):
        return m.group(1).strip()
    return None


def _extract_video_codec(desc: str) -> str | None:
    """First recognised video codec mention in the description (used by
    the lazy-fetch path; eager extraction from the torrent name lives in
    `_extract_release_tags`). Conventionally cased — `x264` lowercase,
    `AVC` / `HEVC` uppercase, etc."""
    if (m := _VIDEO_CODEC_RE.search(desc)):
        return _normalise_codec(m.group(1))
    return None


def _extract_audio(desc: str) -> str | None:
    """Audio info from the detail-page description. Combines audio codec
    (AAC/DTS/E-AC-3/...) and channel layout (5.1/7.1/2.0/6 channels) when
    both are nearby; falls back to whichever is found alone. A bare integer
    channel count (`6`) gets `' channels'` appended so it doesn't read as
    an isolated number.

    If the codec name already encodes channel info (e.g. `DDP5.1`, `DD7.1`,
    or even `DDP5` from a space-stripped `DDP5 1`), don't append a
    separately-detected channel count — that would produce contradictory
    output like `DDP5 6 channels`."""
    codec = None
    channels = None
    if (m := _AUDIO_CODEC_RE.search(desc)):
        codec = m.group(1)
    if (m := _AUDIO_CHANNELS_RE.search(desc)):
        channels = m.group(1)
        if "." not in channels:
            channels = f"{channels} channels"
    if codec and channels:
        # Codec already carries digit info → channel count would duplicate.
        if re.search(r'\d', codec):
            return codec
        return f"{codec} {channels}"
    return codec or channels


# Multi-line subtitle table (R4-style):
#   Subtitles
#
#   Codec...................... Language
#
#   srt ....................... English
#   srt ....................... Dutch
#   ...
_SRT_LANGUAGE_RE = re.compile(
    r'^\s*srt[\s.]+([A-Z][a-z]+)\s*$',
    re.MULTILINE,
)


def _extract_subtitles(desc: str) -> str | None:
    """Subtitle language list from the detail-page description.
    Handles bracketed `[SUBTITLES]:` (R3/R10), aligned `Subtitle(s) :`
    (R7/R8), `Included subtitles =` (GalaxyRG), and the multi-line
    `srt ....... <Language>` table format (R4).

    Rejects URL values — some uploaders point to subtitle download
    sites (e.g. `Subtitles : https://subscene.com/...`); that's not
    a language list."""
    if (m := _SUBTITLES_RE.search(desc)):
        text = m.group(1).strip().rstrip(",")
        text = re.sub(r'\s*\(SRT File\)\s*$', '', text, flags=re.IGNORECASE).strip()
        # Reject sentinel non-values that uploaders sometimes write:
        # URLs, single dashes, "n/a", "none", "not available".
        if (
            text
            and not text.startswith(("http://", "https://", "www."))
            and text.lower().strip("-.") not in ("", "none", "n/a", "na", "not available", "no")
        ):
            return text
    # Multi-line `srt .... Language` rows (R4 / Subtitles section)
    langs = _SRT_LANGUAGE_RE.findall(desc)
    if langs:
        return ", ".join(langs)
    return None


# Non-plot indicators — keywords whose presence in a paragraph rules it
# out as a movie summary. Covers technical / encoding / playback notes
# (R3's "Compliant with Xbox360/PS3..." paragraph) and torrent-site
# promotional / group-credit content (R5's "Big Shout Out to all who
# support our group, our fellow colleague Encoders / Remuxers..."
# paragraph; R10's "list of upcoming uploads, instant chat, account
# registration..." paragraph).
_NON_PLOT_KEYWORDS_RE = re.compile(
    r'\b('
    r'kHz|kb/?s|Mb/?s|Kbps|Mbps|AAC|AC-?3|MP3|FLAC|x264|x265|HEVC|BluRay|HDR|'
    r'Xbox|PS[345]|VLC|VBR|CBR|playback|audio stream|video format|'
    r'encoders?|remuxers?|remux|mkv|m2ts|nfo|'
    r'yify|yify-torrents|torrents?|uploads?|seeders?|leechers?|'
    r'registration|subtitles?|screenshots?'
    r')\b',
    re.IGNORECASE,
)
# Labeled summary blocks — before the bare-paragraph fallback, look
# for a 'Storyline'/'Synopsis'/'Plot'/'Description' header on its own
# line followed by paragraph content. Reliable when present (R4 uses
# 'Storyline'); falls through to bare-paragraph when missing (R1/R2/R10).
_LABELED_PLOT_BLOCK_RE = re.compile(
    r'^\s*(?:Storyline|Synopsis|Description|About\s+the\s+Movie)\s*$\n+'
    r'\s*(.+?)(?=\n\s*\n|\Z)',
    re.MULTILINE | re.DOTALL | re.IGNORECASE,
)


_HEADER_FIRST_LINE_RE = re.compile(r'^[A-Z][A-Z0-9 ]{3,29}\s*$')
# Mixed-case credit-block headings (Director, Writers, Stars, Cast, Genres,
# Plot, Synopsis, Storyline) — when these stand alone as the first line of
# a paragraph they signal a structured-credit block, not a movie plot.
# Without this filter the credit block can win the longest-paragraph
# tiebreak in `_extract_summary` and get rendered as the summary.
_BLOCK_HEADING_RE = re.compile(
    r'^\s*(?:Directors?|Writers?|Stars?|Cast|Genres?|Plot|Synopsis|Storyline)\s*$',
    re.IGNORECASE,
)


def _extract_summary(desc: str) -> str | None:
    """Try `Plot:` label first; otherwise pick the longest plain-prose
    paragraph in the description that doesn't trip the
    non-plot-keyword filter (technical specs, playback notes, torrent-site
    promo text — none of which are movie plots).

    Also skip paragraphs whose first line is an ALL-CAPS label like
    `RELEASE NOTES`, `INFO`, `WARNING`, `DISCLAIMER` — those are
    uploader announcements, not movie plots."""
    if (m := _PLOT_RE.search(desc)):
        return m.group(1).strip()
    # Labeled-block second: 'Storyline\n\n<text>' / 'Synopsis\n\n<text>'
    if (m := _LABELED_PLOT_BLOCK_RE.search(desc)):
        return m.group(1).strip()
    candidates = []
    for para in re.split(r'\n\s*\n', desc):
        text = para.strip()
        if len(text) < 80:
            continue
        if text.startswith("[") or "~~~" in text or "---" in text:
            continue
        head = text[:100]
        if ":" in head or "=" in head:
            continue
        if _NON_PLOT_KEYWORDS_RE.search(text):
            continue
        # Skip paragraphs that lead with an ALL-CAPS header line
        # (e.g. "RELEASE NOTES\nDisc was fully supported by eac3to...")
        # or a mixed-case credit-block heading (Director / Writers / Stars
        # / Cast / Genres / Plot / Synopsis / Storyline).
        first_line = text.split("\n", 1)[0].strip()
        if _HEADER_FIRST_LINE_RE.fullmatch(first_line) or _BLOCK_HEADING_RE.fullmatch(first_line):
            continue
        # Skip listy paragraphs — tracklists / episode listings often
        # land as a single paragraph (no blank lines between rows). If
        # ≥ 3 lines start with a digit + separator, it's a list, not a plot.
        lines = text.split("\n")
        listy = sum(1 for ln in lines if re.match(r'^\s*\d+[\s\t.)]', ln))
        if listy >= 3:
            continue
        candidates.append(text)
    if not candidates:
        return None
    return max(candidates, key=len)


def _extract_runtime(desc: str) -> str | None:
    """Try HH:MM:SS first, then 'X h Y min' / '[RUNTIME]:.[ XHr YMin'."""
    if (m := _DURATION_HMS_RE.search(desc)):
        h, mn, s = (int(x) for x in m.groups())
        return _fmt_runtime(h * 3600 + mn * 60 + s)
    if (m := _DURATION_HM_RE.search(desc)):
        h, mn = (int(x) for x in m.groups())
        return _fmt_runtime(h * 3600 + mn * 60)
    return None


def _extract_misc(desc: str) -> dict:
    """Collect any `LABEL: value`-shaped lines we didn't structure as a known
    field. Three line shapes are recognised; the first match wins per label
    so a bracketed line doesn't double-count as an aligned line."""
    misc: dict = {}

    def _add(label: str, value: str) -> None:
        label = label.strip()
        if not label or label.upper() in _KNOWN_LABELS:
            return
        # Don't overwrite an earlier capture for the same label.
        if label not in misc:
            misc[label] = value.strip()

    for m in _MISC_BRACKETED_RE.finditer(desc):
        _add(m.group(1), m.group(2))
    for m in _MISC_ALIGNED_RE.finditer(desc):
        _add(m.group(1), m.group(2))
    for m in _MISC_UPPER_RE.finditer(desc):
        _add(m.group(1), m.group(2))
    return misc


def _parse_tpb_detail_html(html_bytes) -> dict:
    """Parse a TPB torrent detail page. Returns a metadata-shaped dict
    with the subset of keys the page actually carried; never raises.

    Three sources of fields:
      1. Structured `<dl class="col1">` / `<dl class="col2">` (Type, Files,
         Uploaded, By) — present on every page.
      2. Description block (`<div class="nfo">` or `<pre>`) — uploader
         convention is `Genre:`, `Director:`, `Stars:`, `Plot:`, plus an
         IMDB URL and a MEDIAINFO Duration line.
      3. Anything else of the form `LABEL: value` in the description
         lands in `misc` so unstructured uploader notes don't disappear.
    """
    if not html_bytes:
        return {}
    try:
        soup = BeautifulSoup(html_bytes, 'html.parser')
    except Exception:
        return {}

    md: dict = {}

    # 1. Structured <dl> blocks
    for dl in soup.select('dl.col1, dl.col2'):
        dts = dl.find_all('dt')
        dds = dl.find_all('dd')
        for dt, dd in zip(dts, dds, strict=False):
            label = dt.get_text(strip=True)
            value = dd.get_text(strip=True)
            field = _DT_LABEL_TO_FIELD.get(label)
            if not field or not value:
                continue
            if field == 'files':
                try:
                    md['files'] = int(value)
                except ValueError:
                    pass
            elif field == 'uploaded':
                d = _fmt_date(value)
                if d:
                    md['uploaded'] = d
            else:
                md[field] = value

    # 2. Description block — .nfo div or top-level <pre>
    desc_node = soup.find('div', class_='nfo') or soup.find('pre')
    desc = desc_node.get_text() if desc_node else ''

    if (m := _IMDB_URL_RE.search(desc)):
        md['imdb_code'] = m.group(1)
    if (val := _extract_genre(desc)):
        md['genre'] = val
    if (val := _extract_director(desc)):
        md['director'] = val
    if (val := _extract_cast(desc)):
        md['cast'] = val
    if (val := _extract_summary(desc)):
        md['summary'] = val
    if (val := _extract_video_codec(desc)):
        md['codec'] = val
    if (val := _extract_audio(desc)):
        md['audio'] = val
    if (val := _extract_subtitles(desc)):
        md['subtitles'] = val
    runtime = _extract_runtime(desc)
    if runtime:
        md['runtime'] = runtime

    # 3. Misc — bracketed/aligned/uppercase `LABEL: value` lines that
    # didn't match a known structured field.
    misc = _extract_misc(desc)
    if misc:
        md['misc'] = misc

    return md


def _fetch_tpb_metadata(detail_url, timeout=8):
    """Lazy fetch + parse for a TPB detail page. Returns the metadata dict
    on success, or `{}` on any HTTP / parse failure (caller surfaces the
    error in the panel footer)."""
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0'}
    try:
        r = _https_get(detail_url, headers=headers, timeout=timeout)
    except requests.RequestException:
        return {}
    if r.status_code != 200:
        return {}
    return _parse_tpb_detail_html(r.content)


def _parse_apibay_descr(descr: str) -> dict:
    """Run the description-text extractors over an apibay `descr` field.
    Same content shape as the legacy `<div class="nfo">` block on TPB
    detail pages — uploader-written prose with Director / Cast / Plot /
    Genre / Runtime / Audio / Subtitles in various formats. Reuses the
    existing extractors so output looks identical regardless of which
    path produced it."""
    md: dict = {}
    if (val := _extract_genre(descr)):
        md['genre'] = val
    if (val := _extract_director(descr)):
        md['director'] = val
    if (val := _extract_cast(descr)):
        md['cast'] = val
    if (val := _extract_summary(descr)):
        md['summary'] = val
    if (val := _extract_video_codec(descr)):
        md['codec'] = val
    if (val := _extract_audio(descr)):
        md['audio'] = val
    if (val := _extract_subtitles(descr)):
        md['subtitles'] = val
    runtime = _extract_runtime(descr)
    if runtime:
        md['runtime'] = runtime
    misc = _extract_misc(descr)
    if misc:
        md['misc'] = misc
    return md


def _fetch_apibay_details(apibay_id, timeout=8) -> dict:
    """Lazy-fetch a single torrent's full record from apibay's `t.php`
    endpoint, returning a metadata-shaped dict with director / cast /
    summary / runtime / audio / subtitles extracted from the `descr` field.

    For apibay-sourced rows the canonical detail page (thepiratebay.org/
    torrent/<id>) is now the SPA shell with no server-rendered content,
    so the legacy HTML detail parser yields nothing. apibay's `t.php`
    returns the same uploader description as a JSON field, which is
    exactly what we need."""
    if not apibay_id:
        return {}
    url = f'{APIBAY_URL}/t.php?id={int(apibay_id)}'
    try:
        r = _https_get(url, timeout=timeout)
        data = r.json()
    except (requests.RequestException, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    descr = data.get('descr') or ''
    if not descr:
        return {}
    return _parse_apibay_descr(descr)
