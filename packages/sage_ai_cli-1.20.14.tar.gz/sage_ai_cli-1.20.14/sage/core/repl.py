"""Async REPL for SAGE with bottom-anchored prompt and background log streaming."""

from __future__ import annotations

import asyncio
import threading
import sys
from typing import Callable, Any, Awaitable

from prompt_toolkit import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.layout.containers import HSplit, Window, FloatContainer, VSplit
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.layout import Layout
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.keys import Keys
from prompt_toolkit.widgets import Frame

class SageREPL:
    def __init__(
        self,
        agent: Any,
        execute_fn: Callable[[str], None],
        prompt_text: str = "you> ",
    ):
        self.agent = agent
        self.execute_fn = execute_fn
        self.prompt_text = prompt_text
        self.input_buffer = Buffer(multiline=False)
        self.is_running_agent = False
        
        # Key bindings
        self.kb = KeyBindings()

        @self.kb.add(Keys.ControlC)
        def _(event):
            event.app.exit()

        @self.kb.add(Keys.Enter)
        def _(event):
            text = self.input_buffer.text.strip()
            self.input_buffer.reset()
            if text:
                if self.is_running_agent:
                    # If agent is already running, treat as a hint
                    if hasattr(self.agent, "hint_queue"):
                        try:
                            self.agent.hint_queue.put_nowait(text)
                        except AttributeError:
                            self.agent.hint_queue.put(text)
                else:
                    # Start new agent task
                    asyncio.create_task(self._run_agent_task(text))

        # UI Layout
        # We use a full-screen application to ensure the prompt is truly anchored.
        # However, we want to see the scrolling logs above it.
        # prompt_toolkit's patch_stdout will print ABOVE the application if full_screen=False.
        # To make it truly anchored and "professional", we'll use a layout that only occupies the bottom rows.
        
        self.layout = Layout(
            HSplit([
                # Spacer to push everything to the bottom
                Window(), 
                # Divider with status info
                Window(height=1, content=FormattedTextControl(self._get_status_bar)),
                # Input area
                Window(
                    height=1,
                    content=FormattedTextControl(HTML(f"<style fg='green'><b>{prompt_text}</b></style> ")),
                ),
                Window(
                    height=1,
                    content=BufferControl(buffer=self.input_buffer),
                ),
            ])
        )

        self.app = Application(
            layout=self.layout,
            key_bindings=self.kb,
            full_screen=False,  # Keep scrolling logs visible
            erase_when_done=False,
        )

    def _get_status_bar(self):
        status = "WORKING" if self.is_running_agent else "IDLE"
        color = "yellow" if self.is_running_agent else "green"
        return HTML(
            f"<style fg='gray'>{'─'*20}</style> "
            f"<style fg='{color}'>[{status}]</style> "
            f"<style fg='gray'>{'─'*60}</style>"
        )

    async def _run_agent_task(self, text: str):
        self.is_running_agent = True
        try:
            # Run in thread to avoid blocking event loop
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self.execute_fn, text)
        finally:
            self.is_running_agent = False

    async def run(self):
        with patch_stdout():
            await self.app.run_async()

def run_repl(agent: Any, execute_fn: Callable[[str], None]):
    """Entry point to start the async REPL."""
    repl = SageREPL(agent, execute_fn)
    asyncio.run(repl.run())
