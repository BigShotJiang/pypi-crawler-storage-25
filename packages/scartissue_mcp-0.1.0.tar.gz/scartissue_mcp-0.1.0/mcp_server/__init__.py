"""ScarTissue MCP server package."""
