"""
Transactional message request objects for the Customer.io App API.

Each class represents a request payload for sending a specific type of transactional message
(email, push, SMS, or inbox message).
"""

import base64
from typing import Any, Dict, Literal, Optional, TypedDict, Union

from async_customerio.constants import IdentifierCIOID, IdentifierEMAIL, IdentifierID
from async_customerio.errors import AsyncCustomerIOError
from async_customerio.utils import to_dict


CustomDevice = TypedDict(
    "CustomDevice",
    {
        "token": str,
        "platform": Literal["ios", "android"],
        "last_used": Optional[int],
        "attributes": dict,
    },
)


class SendEmailRequest:
    """An object with all the options available for triggering a transactional message"""

    def __init__(
        self,
        transactional_message_id: Optional[Union[str, int]] = None,
        to: Optional[str] = None,
        identifiers: Optional[Union[IdentifierID, IdentifierEMAIL, IdentifierCIOID]] = None,
        _from: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        reply_to: Optional[str] = None,
        bcc: Optional[str] = None,
        subject: Optional[str] = None,
        preheader: Optional[str] = None,
        body: Optional[str] = None,
        body_amp: Optional[str] = None,
        body_plain: Optional[str] = None,
        fake_bcc: Optional[bool] = None,
        disable_message_retention: bool = False,
        send_to_unsubscribed: bool = True,
        tracked: bool = True,
        queue_draft: bool = False,
        message_data: Optional[dict] = None,
        attachments: Optional[Dict[str, str]] = None,
        disable_css_preprocessing: bool = False,
        send_at: Optional[int] = None,
        language: Optional[str] = None,
    ):
        self.transactional_message_id = transactional_message_id
        self.to = to
        self.identifiers = identifiers
        self._from = _from
        self.headers = headers
        self.reply_to = reply_to
        self.bcc = bcc
        self.subject = subject
        self.preheader = preheader
        self.body = body
        self.body_plain = body_plain
        self.body_amp = body_amp
        self.fake_bcc = fake_bcc
        self.disable_message_retention = disable_message_retention
        self.send_to_unsubscribed = send_to_unsubscribed
        self.tracked = tracked
        self.queue_draft = queue_draft
        self.message_data = message_data
        self.attachments = attachments
        self.disable_css_preprocessing = disable_css_preprocessing
        self.send_at = send_at
        self.language = language

    def attach(self, name: str, content: str, encode: bool = True) -> None:
        """Helper method to add base64 encode the attachments"""
        if not self.attachments:
            self.attachments = {}

        if name in self.attachments:
            raise AsyncCustomerIOError(f"attachment {name} already exists")

        if encode:
            if isinstance(content, str):
                content = base64.b64encode(content.encode("utf-8")).decode()
            else:
                content = base64.b64encode(content).decode()

        self.attachments[name] = content

    def to_dict(self) -> Dict[str, Any]:
        """Build a request payload from the object"""
        field_map = dict(
            # `from` is reserved keyword hence the object has the field
            # `_from` but in the request payload we map it to `from`
            _from="from",
            # field name is the same as the payload field name
            transactional_message_id="transactional_message_id",
            to="to",
            identifiers="identifiers",
            headers="headers",
            reply_to="reply_to",
            bcc="bcc",
            subject="subject",
            preheader="preheader",
            body="body",
            body_amp="body_amp",
            body_plain="body_plain",
            fake_bcc="fake_bcc",
            disable_message_retention="disable_message_retention",
            send_to_unsubscribed="send_to_unsubscribed",
            tracked="tracked",
            queue_draft="queue_draft",
            message_data="message_data",
            attachments="attachments",
            disable_css_preprocessing="disable_css_preprocessing",
            send_at="send_at",
            language="language",
        )
        return to_dict(field_map=field_map, instance=self)


class SendPushRequest:
    """An object with all the options available for triggering a transactional push message."""

    def __init__(
        self,
        transactional_message_id: Optional[Union[str, int]] = None,
        to: Union[Literal["all", "last_used"], str] = "all",
        identifiers: Optional[Union[IdentifierID, IdentifierEMAIL, IdentifierCIOID]] = None,
        title: Optional[str] = None,
        message: Optional[str] = None,
        disable_message_retention: bool = False,
        send_to_unsubscribed: bool = True,
        queue_draft: bool = False,
        message_data: Optional[dict] = None,
        send_at: Optional[int] = None,
        language: Optional[str] = None,
        image_url: Optional[str] = None,
        link: Optional[str] = None,
        custom_data: Optional[dict] = None,
        custom_device: Optional[CustomDevice] = None,
        custom_payload: Optional[dict] = None,
        sound: str = "default",
    ) -> None:
        self.transactional_message_id = transactional_message_id
        self.to = to
        self.identifiers = identifiers
        self.disable_message_retention = disable_message_retention
        self.send_to_unsubscribed = send_to_unsubscribed
        self.queue_draft = queue_draft
        self.message_data = message_data
        self.send_at = send_at
        self.language = language

        self.title = title
        self.message = message
        self.image_url = image_url
        self.link = link
        self.custom_data = custom_data
        self.custom_device = custom_device
        self.custom_payload = custom_payload
        self.sound = sound

    def to_dict(self) -> Dict[str, Any]:
        """Build a request payload from the object."""
        field_map = dict(
            # field name is the same as the payload field name
            transactional_message_id="transactional_message_id",
            to="to",
            identifiers="identifiers",
            disable_message_retention="disable_message_retention",
            send_to_unsubscribed="send_to_unsubscribed",
            queue_draft="queue_draft",
            message_data="message_data",
            send_at="send_at",
            language="language",
            title="title",
            message="message",
            image_url="image_url",
            link="link",
            custom_data="custom_data",
            custom_payload="custom_payload",
            custom_device="custom_device",
            sound="sound",
        )
        return to_dict(field_map=field_map, instance=self)


class SendSMSRequest:
    """An object with all the options available for triggering a transactional SMS message."""

    def __init__(
        self,
        transactional_message_id: Optional[Union[str, int]] = None,
        to: Optional[str] = None,
        identifiers: Optional[Union[IdentifierID, IdentifierEMAIL, IdentifierCIOID]] = None,
        _from: Optional[str] = None,
        language: Optional[str] = None,
        message_data: Optional[dict] = None,
        send_at: Optional[int] = None,
        disable_message_retention: bool = False,
        send_to_unsubscribed: bool = True,
        queue_draft: bool = False,
    ) -> None:
        """Constructor of the SMS message object that is sent along with the request.

        :param transactional_message_id: The transactional message template that you want to use for your message.
        :param identifiers: Identifies the person represented by your transactional message by one of, and only one of,
            ``IdentifierID``, ``IdentifierEMAIL``, ``IdentifierCIOID``.
        :param _from: The phone number or sender ID that your SMS is from. This must be a verified phone number in your
            Twilio account. This overrides the from address set within the transactional template (referenced by
            ``transactional_message_id``). Phone numbers must be in E.164 format (e.g., +15551234567).
        :param language: Overrides language preferences for the person you want to send your transactional message to.
        :param message_data: A dictionary containing the key-value pairs referenced using **liquid** in your message.
        :param send_at: A unix timestamp (seconds since epoch) determining when the message will be sent.
        :param disable_message_retention: If true, the message body is not retained in delivery history. Default is set
            to ``False``.
        :param send_to_unsubscribed: If false, your message is not sent to unsubscribed recipients. Default is set to
            ``True``.
        :param queue_draft: If true, your transactional message is held as a draft in Customer.io and not sent directly
            to your audience. Default is set to ``False``.
        """

        self.transactional_message_id = transactional_message_id
        self.to = to
        self.identifiers = identifiers
        self._from = _from
        self.language = language
        self.message_data = message_data
        self.send_at = send_at
        self.disable_message_retention = disable_message_retention
        self.send_to_unsubscribed = send_to_unsubscribed
        self.queue_draft = queue_draft

    def to_dict(self) -> Dict[str, Any]:
        """Build a request payload from the object."""
        field_map = dict(
            # `from` is reserved keyword hence the object has the field
            # `_from` but in the request payload we map it to `from`
            _from="from",
            # field name is the same as the payload field name
            transactional_message_id="transactional_message_id",
            to="to",
            identifiers="identifiers",
            disable_message_retention="disable_message_retention",
            send_to_unsubscribed="send_to_unsubscribed",
            queue_draft="queue_draft",
            message_data="message_data",
            send_at="send_at",
            language="language",
        )
        return to_dict(field_map=field_map, instance=self)


class SendInboxMessageRequest:
    """An object with all the options available for triggering a transactional inbox message."""

    def __init__(
        self,
        transactional_message_id: Optional[Union[str, int]] = None,
        identifiers: Optional[Union[IdentifierID, IdentifierEMAIL, IdentifierCIOID]] = None,
        disable_message_retention: bool = False,
        queue_draft: bool = False,
        message_data: Optional[dict] = None,
        send_at: Optional[int] = None,
        language: Optional[str] = None,
    ) -> None:
        """Constructor of the inbox message object that is sent along with the request.

        :param transactional_message_id: The transactional message template that you want to use for your message.
        :param identifiers: Identifies the person represented by your transactional message by one of, and only one of,
            ``IdentifierID``, ``IdentifierEMAIL``, ``IdentifierCIOID``.
        :param disable_message_retention: If true, the message body is not retained in delivery history. Default is set
            to ``False``.
        :param queue_draft: If true, your transactional message is held as a draft in Customer.io and not sent directly
            to your audience. Default is set to ``False``.
        :param message_data: A dictionary containing the key-value pairs referenced using **liquid** in your message.
        :param send_at: A unix timestamp (seconds since epoch) determining when the message will be sent.
        :param language: Overrides language preferences for the person you want to send your transactional message to.
        """
        self.transactional_message_id = transactional_message_id
        self.identifiers = identifiers
        self.disable_message_retention = disable_message_retention
        self.queue_draft = queue_draft
        self.message_data = message_data
        self.send_at = send_at
        self.language = language

    def to_dict(self) -> Dict[str, Any]:
        """Build a request payload from the object."""
        field_map = dict(
            transactional_message_id="transactional_message_id",
            identifiers="identifiers",
            disable_message_retention="disable_message_retention",
            queue_draft="queue_draft",
            message_data="message_data",
            send_at="send_at",
            language="language",
        )
        return to_dict(field_map=field_map, instance=self)
