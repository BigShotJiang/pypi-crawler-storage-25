"""Official ManyWe agent daemon placeholder package reserved on PyPI."""

__all__ = ["PACKAGE_NAME", "__version__", "placeholder_notice"]

PACKAGE_NAME = "manywe-agentd"
__version__ = "0.0.1"

def placeholder_notice() -> str:
    return (
        "manywe-agentd is an official ManyWe placeholder package on PyPI. "
        "The public Python implementation is not available yet."
    )
