"""Prompt composers for scheduled and delegated CLI runtime turns."""

from __future__ import annotations

from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback
from typing import Any

from packages.cron import CronJob


def cron_skill_ids(value: object) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raw_items = value.replace("\n", ",").split(",")
    elif isinstance(value, Mapping):
        raw_items = [str(key) for key, enabled in value.items() if enabled]
    elif isinstance(value, (list, tuple)):
        raw_items = [str(item) for item in value]
    else:
        raw_items = [str(value)]
    return tuple(dict.fromkeys(item.strip() for item in raw_items if item.strip()))


def compose_cron_prompt(runtime: Any, job: CronJob, *, user_prompt: str, session_id: str) -> str:
    skill_sections = _skill_sections(runtime, cron_skill_ids(job.payload.get("skills")), session_id=session_id)
    sections = [
        "[SYSTEM: This turn is running as a scheduled Aegis cron job.]",
        "The scheduler will surface the final response; do not call tool.message.send from this job.",
        "The user may not be present, so avoid interactive clarification and make conservative assumptions.",
        "If there is no useful update, respond exactly [SILENT].",
        "",
        f"Cron job: {job.name} ({job.job_id})",
        f"Schedule: {job.schedule_text}",
    ]
    if skill_sections:
        sections.extend(["", "Scheduled skill instructions:", "\n\n".join(skill_sections)])
    sections.extend(["", f"Scheduled task:\n{user_prompt}"])
    return "\n".join(sections).strip()


def run_sub_agent_task(
    runtime: Any,
    *,
    session_id: str,
    task: str,
    name: str | None = None,
    skills: tuple[str, ...] = (),
) -> Mapping[str, Any]:
    result = run_sub_agent_tasks(
        runtime,
        session_id=session_id,
        tasks=({"task": task, "name": name, "skills": skills},),
        max_concurrency=1,
    )
    results = tuple(result.get("results") or ())
    if not results:
        return {
            "name": name or "sub-agent",
            "summary": "sub-agent did not return a result",
            "skills": list(skills),
            "status": "failed",
        }
    return results[0]


def run_sub_agent_tasks(
    runtime: Any,
    *,
    session_id: str,
    tasks: tuple[Mapping[str, Any], ...],
    max_concurrency: int = 3,
) -> Mapping[str, Any]:
    if runtime.sub_agent_active:
        raise RuntimeError("nested sub-agent delegation is not allowed")
    normalized = tuple(_normalize_sub_agent_task(item) for item in tasks)
    if not normalized:
        raise ValueError("tool.sub_agents requires at least one task")
    workers = max(1, min(int(max_concurrency or 1), len(normalized), 3))
    prepared = tuple(
        _prepare_sub_agent_child(
            runtime,
            parent_session_id=session_id,
            task=item["task"],
            name=item.get("name"),
            skills=tuple(item.get("skills") or ()),
        )
        for item in normalized
    )
    results: list[Mapping[str, Any] | None] = [None] * len(normalized)
    object.__setattr__(runtime, "sub_agent_active", True)
    try:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(
                    _run_prepared_sub_agent_child,
                    runtime,
                    prepared_child=item,
                ): index
                for index, item in enumerate(prepared)
            }
            for future in as_completed(futures):
                index = futures[future]
                results[index] = future.result()
    finally:
        object.__setattr__(runtime, "sub_agent_active", False)
    resolved = tuple(item for item in results if item is not None)
    summary = "\n".join(
        f"{index + 1}. {item.get('name') or 'sub-agent'}: {item.get('summary') or item.get('status') or 'finished'}"
        for index, item in enumerate(resolved)
    )
    return {
        "summary": summary or "sub-agent pool finished",
        "results": list(resolved),
        "max_concurrency": workers,
    }


def _run_one_sub_agent_child(
    runtime: Any,
    *,
    parent_session_id: str,
    task: str,
    name: str | None,
    skills: tuple[str, ...],
) -> Mapping[str, Any]:
    prepared = _prepare_sub_agent_child(
        runtime,
        parent_session_id=parent_session_id,
        task=task,
        name=name,
        skills=skills,
    )
    return _run_prepared_sub_agent_child(runtime, prepared_child=prepared)


def _prepare_sub_agent_child(
    runtime: Any,
    *,
    parent_session_id: str,
    task: str,
    name: str | None,
    skills: tuple[str, ...],
) -> Mapping[str, Any]:
    resume_result = runtime.resume(parent_session_id)
    child_session_id = resume_result.session.session_id
    prompt = _compose_sub_agent_prompt(
        runtime,
        task=task,
        name=name,
        skills=skills,
        session_id=child_session_id,
    )
    return {
        "name": name or "sub-agent",
        "prompt": prompt,
        "session_id": child_session_id,
        "skills": skills,
    }


def _run_prepared_sub_agent_child(
    runtime: Any,
    *,
    prepared_child: Mapping[str, Any],
) -> Mapping[str, Any]:
    child_session_id = str(prepared_child["session_id"])
    name = str(prepared_child.get("name") or "sub-agent")
    skills = tuple(str(item) for item in prepared_child.get("skills") or ())
    prompt = str(prepared_child.get("prompt") or "")
    child_runtime = None
    unsubscribe = None
    try:
        child_runtime = _create_child_runtime(runtime)
        object.__setattr__(child_runtime, "sub_agent_active", True)
        unsubscribe = _relay_child_tool_events(runtime, child_runtime)
        child_runtime.prepare_session_surface(child_session_id)
        outcome = child_runtime.explain_next_step(session_id=child_session_id, prompt=prompt)
        execution = outcome.execution
        status = "completed" if execution.outcome not in {"error", "failed"} else "failed"
        summary = _bounded_child_text(execution.summary)
        execution_id = execution.execution_id
        exit_code = 0 if status == "completed" else 1
    except Exception as error:
        status = "failed"
        summary = _child_result_summary(
            {
                "summary": f"{type(error).__name__}: {error}",
                "status": status,
                "traceback": traceback.format_exc(limit=8),
            },
            output="",
            status=status,
        )
        execution_id = None
        exit_code = 1
    finally:
        if unsubscribe is not None:
            unsubscribe()
        close = getattr(child_runtime, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                pass
    return {
        "name": name,
        "summary": summary,
        "skills": list(skills),
        "session_id": child_session_id,
        "status": status,
        "exit_code": exit_code,
        "execution_id": execution_id,
    }


def _create_child_runtime(runtime: Any) -> Any:
    return runtime.__class__.create(
        state_dir=runtime.paths.state_dir,
        profile_dir=runtime.paths.profile_dir,
    )


def _relay_child_tool_events(parent_runtime: Any, child_runtime: Any):
    emitter = getattr(parent_runtime.tool_runtime, "_emit_event", None)
    subscribe = getattr(child_runtime.tool_runtime, "subscribe", None)
    if not callable(emitter) or not callable(subscribe):
        return None

    def _observer(event: Any) -> None:
        emitter(event)

    return subscribe(_observer)


def _normalize_sub_agent_task(item: Mapping[str, Any]) -> Mapping[str, Any]:
    task = str(item.get("task") or item.get("prompt") or "").strip()
    if not task:
        raise ValueError("sub-agent tasks require 'task'")
    name = item.get("name")
    name_text = None if name is None else str(name).strip() or None
    skills = cron_skill_ids(item.get("skills"))
    return {"task": task, "name": name_text, "skills": skills}


def _child_output_summary(output: str, *, status: str) -> str:
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if not lines:
        return f"sub-agent {status} with no output"
    selected = lines[-8:]
    summary = _bounded_child_text("\n".join(selected).strip())
    if status == "failed":
        return f"sub-agent failed:\n{summary}"
    return summary


def _child_result_summary(payload: Mapping[str, Any], *, output: str, status: str) -> str:
    summary = str(payload.get("summary") or "").strip()
    if not summary and output:
        summary = _child_output_summary(output, status=status)
    if not summary:
        summary = f"sub-agent {status} with no summary"
    summary = _bounded_child_text(summary)
    if status == "failed" and not summary.startswith("sub-agent failed"):
        return f"sub-agent failed:\n{summary}"
    return summary


def _bounded_child_text(value: str, *, limit: int = 12000) -> str:
    text = value.strip()
    if len(text) <= limit:
        return text
    return f"{text[:limit].rstrip()}\n[truncated]"


def _compose_sub_agent_prompt(
    runtime: Any,
    *,
    task: str,
    name: str | None,
    skills: tuple[str, ...],
    session_id: str,
) -> str:
    sections = [
        "[SYSTEM: You are running as a bounded Aegis sub-agent.]",
        "Return a concise final result for the parent agent.",
        "Do not call tool.sub_agents, tool.clarify, or tool.message.send.",
        "Use tools only when they materially advance this delegated task.",
        f"Sub-agent name: {name or 'sub-agent'}",
    ]
    skill_sections = _skill_sections(runtime, skills, session_id=session_id)
    if skill_sections:
        sections.extend(["", "Sub-agent skill instructions:", "\n\n".join(skill_sections)])
    sections.extend(["", f"Delegated task:\n{task}"])
    return "\n".join(sections).strip()


def _skill_sections(runtime: Any, skill_ids: tuple[str, ...], *, session_id: str) -> list[str]:
    sections: list[str] = []
    for skill_id in skill_ids:
        try:
            skill = runtime.inspect_skill(skill_id, session_id=session_id)
        except Exception as error:
            sections.append(f"Skill {skill_id}: unavailable ({error}).")
            continue
        sections.append(
            "\n".join(
                (
                    f"Skill: {skill.display_name} ({skill.skill_id})",
                    f"Summary: {skill.summary}",
                    "Instructions:",
                    skill.instruction_text.strip() or "<empty>",
                )
            )
        )
    return sections
