"""FastAPI web frontend for the iMessage <-> Telegram bridge.

Runs as a separate launchd user agent on the Mac. Reads chat.db via the same
backup-snapshot approach the bridge uses (keeps TCC happy past the 4-min
cliff). Sends iMessages via the same osascript wrappers the bridge uses.
Live updates are streamed via SSE by tailing the bridge's mirror.jsonl file.

Deliberately minimal: htmx swaps fragments into a single HTML page, no JS
framework, no build step. Auth is "you can reach the box" — gate access at
the network layer (Tailscale, LAN-only, CF Access).
"""
from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

import logging

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("chatwire.web")
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Reuse bridge modules
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from chat_db import APPLE_EPOCH_OFFSET, ChatDBReader, CHAT_DB  # noqa: E402
from chat_send import (  # noqa: E402
    send_text_confirm, send_file_confirm,
    send_text_to_chat_confirm, send_file_to_chat_confirm,
)
from contacts import load_lookup as load_contacts, load_image_index, fetch_image  # noqa: E402
from echo_log import register as echo_register  # noqa: E402
from whitelist import (  # noqa: E402
    add as wl_add, add_group as wl_add_group,
    all_handles as wl_all, all_groups as wl_all_groups,
    remove as wl_remove, remove_group as wl_remove_group,
)

# Load config from ~/.chatwire/config.json (or legacy fallbacks).
import config as _bridge_config  # noqa: E402
_bridge_config.apply_to_environ()
from config import STATE_DIR  # noqa: E402

SELF_HANDLES = {h.strip().lower() for h in os.environ.get("SELF_HANDLES", "").split(",") if h.strip()}


def relay_handles() -> set[str]:
    return SELF_HANDLES | wl_all()


MIRROR_FILE = Path(os.environ.get("DEBUG_MIRROR_FILE", str(STATE_DIR / "mirror.jsonl")))

WEB_PORT = int(os.environ.get("WEB_PORT", "8723"))
WEB_SECURE_COOKIE = os.environ.get("WEB_SECURE_COOKIE", "").lower() in ("1", "true", "yes")
HISTORY_LIMIT = 100
CONVO_LIMIT = 50

VAPID_PRIVATE_KEY = os.environ.get("VAPID_PRIVATE_KEY", "")
VAPID_PUBLIC_KEY = os.environ.get("VAPID_PUBLIC_KEY", "")
VAPID_CONTACT = os.environ.get("VAPID_CONTACT", "mailto:admin@example.com")
PUSH_SUBS_FILE = STATE_DIR / "push_subs.json"

CONTACTS = load_contacts()
IMAGE_INDEX = load_image_index()

def _compute_build_id() -> str:
    """Cache-busting identifier for static assets. Changes whenever the
    code does (commit hash if git is available, mtime otherwise)."""
    repo_root = Path(__file__).resolve().parent.parent
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_root), "rev-parse", "--short=8", "HEAD"],
            capture_output=True, text=True, timeout=3,
        )
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip()
    except Exception:
        pass
    return str(int(Path(__file__).stat().st_mtime))


# Two distinct version-shaped values:
#   RELEASE_VERSION — semver, bumped at release ("0.1.0", "0.2.0-rc1", "0.0.0-dev").
#                     Drives the update-check banner.
#   BUILD_ID       — commit hash or mtime, changes every build.
#                     Drives the static-asset cache-buster.
import _version  # noqa: E402
RELEASE_VERSION = _version.__version__
BUILD_ID = _compute_build_id()
APP_VERSION = BUILD_ID  # legacy alias; /healthz et al. expect this name

# Default GitHub repo to check for updates. The web UI's update-check JS
# reads this from a meta tag on the page, so it's per-render configurable
# without a code change. Override via env to point at a fork.
UPDATE_CHECK_REPO = os.environ.get("UPDATE_CHECK_REPO", "allenbina/chatwire")

app = FastAPI()
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")

from web import auth as _auth  # noqa: E402
from web.setup_wizard import register_setup_routes  # noqa: E402
from web.themes import available_themes, selected_theme, themes_for_picker  # noqa: E402

register_setup_routes(app, templates)


def _refresh_auth_state() -> None:
    """Reread `web.auth` from config into app.state. Called at startup and
    whenever the password is set/cleared via settings or wizard. The
    middleware reads from app.state to skip the per-request file load."""
    cfg = _bridge_config.load_config()
    app.state.auth_block = _auth.auth_block(cfg)


_refresh_auth_state()
app.state.login_rate_limiter = _auth.LoginRateLimiter()
# Per-process CSRF secret — rotates on restart (intentional for a home server).
# In-flight forms older than a restart become invalid; that's acceptable.
app.state.csrf_secret = _auth.new_session_secret()


@app.middleware("http")
async def _auth_gate(request: Request, call_next):
    """Cookie-session auth gate. No-op when no password is configured."""
    block = getattr(app.state, "auth_block", None)
    if block is None or _auth.is_public_path(request.url.path):
        return await call_next(request)
    cookie = request.cookies.get(_auth.COOKIE_NAME)
    age = _auth.cookie_age(cookie, block["session_secret"])
    if age is not None:
        response = await call_next(request)
        # Sliding refresh: an active user's cookie keeps rolling forward,
        # while an idle user's still expires at SESSION_TTL_S. Skip the
        # rewrite when the cookie is fresh — set_cookie on every request
        # would ship a Set-Cookie header on every fragment swap. Also
        # skip when the secret rotated mid-request (e.g. /api/auth/password
        # changed the password) — the handler has already set a cookie
        # with the new secret, and reissuing with the pre-rotation secret
        # would shadow it.
        if age >= _auth.SESSION_REFRESH_S:
            cur_block = getattr(app.state, "auth_block", None)
            if cur_block is not None and cur_block["session_secret"] == block["session_secret"]:
                _set_session_cookie(response, block["session_secret"])
        return response
    # htmx fragments can't follow a 302 to a login page — they'd swap the
    # form HTML into the messages list. Surface a 401 with HX-Redirect so
    # the client kicks the whole window over to /login. Plain HTML
    # navigations (full-page) get a normal redirect.
    if request.headers.get("HX-Request") == "true":
        resp = Response(status_code=401)
        resp.headers["HX-Redirect"] = "/login"
        return resp
    target = "/login"
    nxt = request.url.path
    if request.url.query:
        nxt = f"{nxt}?{request.url.query}"
    if nxt and nxt != "/":
        from urllib.parse import quote
        target = f"/login?next={quote(nxt, safe='')}"
    return RedirectResponse(target, status_code=302)


@app.middleware("http")
async def _no_store_html(request: Request, call_next):
    response = await call_next(request)
    ctype = response.headers.get("content-type", "")
    if ctype.startswith("text/html"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/healthz")
async def healthz():
    return {"ok": True, "version": APP_VERSION, "release": RELEASE_VERSION}


@app.get("/version")
async def version():
    return {"release": RELEASE_VERSION, "build": BUILD_ID}


# ------- optional cookie-session auth -------

# Sanity guard for `?next=`: only accept paths that point back into our own
# UI. Anything else falls back to "/" so a crafted login link can't bounce
# the user to a third-party host.
def _safe_next(nxt: str) -> str:
    if not nxt or not nxt.startswith("/") or nxt.startswith("//"):
        return "/"
    return nxt


def _csrf_token() -> str:
    """Fresh signed CSRF token for the current request cycle."""
    return _auth.new_csrf_token(app.state.csrf_secret)


def _set_session_cookie(response: Response, secret: str) -> None:
    response.set_cookie(
        _auth.COOKIE_NAME,
        _auth.issue_cookie(secret),
        max_age=_auth.SESSION_TTL_S,
        httponly=True,
        samesite="lax",
        # `secure` is off by default so LAN-over-http installs work.
        # Set `web.secure_cookie: true` in config.json for deployments
        # behind a TLS-terminating proxy (Tailscale, Caddy, CF Access).
        secure=WEB_SECURE_COOKIE,
    )


@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request, next: str = "/", error: str = ""):
    # If auth isn't configured at all, /login has nothing to do — bounce
    # to the main UI instead of showing a form that can't be submitted.
    if getattr(app.state, "auth_block", None) is None:
        return RedirectResponse("/", status_code=302)
    return templates.TemplateResponse(request, "_login.html", {
        "next": _safe_next(next),
        "error": error,
        "csrf_token": _csrf_token(),
        "release_version": RELEASE_VERSION,
        "version": APP_VERSION,
        "web_theme": selected_theme(_bridge_config.load_config()),
    })


def _client_key(request: Request) -> str:
    """Bucket key for rate limiting. `request.client.host` is the immediate
    peer — for direct LAN access that's the user; behind a reverse proxy
    it's the proxy IP. We deliberately don't trust X-Forwarded-For: in
    the home-deployment context we don't know which proxies are
    trustworthy, and a forged header would let an attacker pick a fresh
    bucket per attempt. See `LoginRateLimiter` docstring for the
    behind-a-proxy tradeoff."""
    return (request.client.host if request.client else "") or "unknown"


@app.post("/login")
async def login_submit(
    request: Request,
    password: str = Form(""),
    next: str = Form("/"),
    csrf_token: str = Form(""),
):
    block = getattr(app.state, "auth_block", None)
    if block is None:
        # Race: password was cleared between form render and submit. Send
        # the user on with no cookie set — auth's disabled now.
        return RedirectResponse(_safe_next(next), status_code=303)
    if not _auth.verify_csrf_token(csrf_token, app.state.csrf_secret):
        from urllib.parse import urlencode
        qs = urlencode({"next": _safe_next(next), "error": "Form expired — please try again."})
        return RedirectResponse(f"/login?{qs}", status_code=303)
    limiter: _auth.LoginRateLimiter = app.state.login_rate_limiter
    key = _client_key(request)
    locked = limiter.locked_for(key)
    if locked:
        from urllib.parse import urlencode
        msg = f"Too many attempts. Try again in {_fmt_lockout(locked)}."
        qs = urlencode({"next": _safe_next(next), "error": msg})
        return RedirectResponse(f"/login?{qs}", status_code=303)
    if not _auth.verify_password(password, block["password_hash"]):
        limiter.record_fail(key)
        # Re-render the form with an error. 303 → GET keeps the URL
        # `?error=` simple and avoids resubmits.
        from urllib.parse import urlencode
        qs = urlencode({"next": _safe_next(next), "error": "Wrong password."})
        return RedirectResponse(f"/login?{qs}", status_code=303)
    limiter.record_success(key)
    resp = RedirectResponse(_safe_next(next), status_code=303)
    _set_session_cookie(resp, block["session_secret"])
    return resp


def _fmt_lockout(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes = (seconds + 59) // 60
    return f"{minutes} minute{'s' if minutes != 1 else ''}"


@app.get("/logout")
async def logout():
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie(_auth.COOKIE_NAME, samesite="lax")
    return resp


def _save_auth_block(password: str | None) -> None:
    """Set or clear the password. Empty/None password clears auth.

    Clearing also drops `web.auth` entirely so the absence-means-disabled
    invariant holds. Setting rotates `session_secret` whenever the
    password changes — that's the natural "log out everywhere" hook
    (existing cookies stop verifying)."""
    cfg = _bridge_config.load_config()
    web = cfg.setdefault("web", {})
    if not password:
        web.pop("auth", None)
        if not web:
            cfg.pop("web", None)
    else:
        web["auth"] = {
            "password_hash": _auth.hash_password(password),
            "session_secret": _auth.new_session_secret(),
        }
    _bridge_config.save_config(cfg)
    _refresh_auth_state()


@app.post("/api/auth/password")
async def api_auth_password(
    request: Request,
    new_password: str = Form(""),
    current_password: str = Form(""),
    clear: str = Form(""),
    csrf_token: str = Form(""),
):
    """Settings-side password set/change/clear.

    - clear=1 with a valid current_password (or no auth currently) drops
      the auth block.
    - new_password sets/changes the password. When auth is already set,
      current_password must match.
    """
    if not _auth.verify_csrf_token(csrf_token, app.state.csrf_secret):
        raise HTTPException(403, "Invalid or expired form token — please reload the page.")
    block = getattr(app.state, "auth_block", None)
    # If auth is currently set, require the current password for any
    # change. This stops a stolen-cookie escalation (cookie alone is
    # enough to read messages but not enough to lock the owner out).
    if block is not None:
        limiter: _auth.LoginRateLimiter = app.state.login_rate_limiter
        # Rate-limit current_password verification on the same bucket as
        # /login: a stolen-cookie attacker grinding for the password to
        # lock the owner out should hit the same wall as one grinding
        # /login itself.
        key = _client_key(request)
        locked = limiter.locked_for(key)
        if locked:
            raise HTTPException(
                429,
                f"Too many attempts. Try again in {_fmt_lockout(locked)}.",
            )
        if not _auth.verify_password(current_password, block["password_hash"]):
            limiter.record_fail(key)
            raise HTTPException(403, "Wrong current password.")
        limiter.record_success(key)

    if clear == "1":
        _save_auth_block(None)
        resp = HTMLResponse(_render_password_card(request))
        resp.delete_cookie(_auth.COOKIE_NAME, samesite="lax")
        return resp

    new_password = new_password.strip()
    if len(new_password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters.")
    _save_auth_block(new_password)
    resp = HTMLResponse(_render_password_card(request))
    new_block = getattr(app.state, "auth_block", None)
    if new_block is not None:
        _set_session_cookie(resp, new_block["session_secret"])
    return resp


def _render_password_card(request: Request, csrf_token: str = "") -> str:
    """Render just the password section of settings (htmx swap target)."""
    has_pw = getattr(app.state, "auth_block", None) is not None
    return templates.get_template("_password_card.html").render({
        "request": request,
        "has_password": has_pw,
        "csrf_token": csrf_token or _csrf_token(),
    })


# ------- chat.db queries (read via backup snapshot, like the bridge) -------

_src_conn: sqlite3.Connection | None = None


_src_lock = __import__("threading").Lock()


def _snapshot() -> sqlite3.Connection:
    global _src_conn
    with _src_lock:
        if _src_conn is None:
            _src_conn = sqlite3.connect(
                f"file:{CHAT_DB}?mode=ro", uri=True, check_same_thread=False
            )
        mem = sqlite3.connect(":memory:")
        mem.row_factory = sqlite3.Row
        _src_conn.backup(mem)
        return mem


# Both of these restrict to chat.style=45 (direct/1:1) so a handle's group
# messages don't leak into the 1:1 sidebar entry or thread view. A person can
# be in both a 1:1 and many groups with us; handle_id alone can't tell them
# apart, only the chat row can.
CONVOS_SQL = """
SELECT
    h.id AS handle,
    MAX(m.date) AS last_dt,
    COUNT(m.ROWID) AS n,
    (SELECT COALESCE(SUBSTR(m2.text,1,80), '')
       FROM message m2
       JOIN chat_message_join cmj2 ON cmj2.message_id = m2.ROWID
       JOIN chat c2 ON c2.ROWID = cmj2.chat_id
       WHERE m2.handle_id = h.ROWID AND c2.style = 45
       ORDER BY m2.date DESC LIMIT 1) AS preview
FROM handle h
JOIN message m ON m.handle_id = h.ROWID
JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
JOIN chat c ON c.ROWID = cmj.chat_id
WHERE c.style = 45
GROUP BY h.id
ORDER BY last_dt DESC
"""

HISTORY_SQL_TEMPLATE = """
SELECT
    m.ROWID AS rowid,
    m.is_from_me AS is_from_me,
    m.date AS date,
    COALESCE(m.text, '') AS text,
    m.cache_has_attachments AS has_attachments,
    h.service AS service,
    m.is_sent AS is_sent,
    m.is_delivered AS is_delivered,
    COALESCE(m.error, 0) AS error
FROM message m
LEFT JOIN handle h ON m.handle_id = h.ROWID
JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
JOIN chat c ON c.ROWID = cmj.chat_id
WHERE h.id IN ({placeholders}) AND c.style = 45
  {cursor_clause}
ORDER BY m.date DESC, m.ROWID DESC
LIMIT ?
"""

ATTACH_SQL = """
SELECT a.filename, a.mime_type, a.transfer_state
FROM message_attachment_join maj
JOIN attachment a ON a.ROWID = maj.attachment_id
WHERE maj.message_id = ?
"""

# Group-chat history: scoped to a single chat GUID. Sender handle comes back
# per row so the UI can label "from Alice" above each bubble (group members
# are only distinguishable by handle_id). Outgoing group rows have handle_id
# NULL, so sender_handle is empty for those — the UI renders them as "me".
HISTORY_GROUP_SQL_TEMPLATE = """
SELECT
    m.ROWID AS rowid,
    m.is_from_me AS is_from_me,
    m.date AS date,
    COALESCE(m.text, '') AS text,
    m.cache_has_attachments AS has_attachments,
    COALESCE(h.id, '') AS sender_handle,
    COALESCE(h.service, '') AS service,
    m.is_sent AS is_sent,
    m.is_delivered AS is_delivered,
    COALESCE(m.error, 0) AS error
FROM message m
LEFT JOIN handle h ON m.handle_id = h.ROWID
JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
JOIN chat c ON c.ROWID = cmj.chat_id
WHERE c.guid = ?
  {cursor_clause}
ORDER BY m.date DESC, m.ROWID DESC
LIMIT ?
"""

ATTACHMENTS_BASE = (Path.home() / "Library" / "Messages" / "Attachments").resolve()

# On-disk thumb cache. Lives outside the Messages.app attachments dir so we
# never risk Messages noticing extra files alongside the originals. Keyed by
# (path, mtime) so renamed/replaced originals invalidate cleanly.
THUMB_CACHE_DIR = (STATE_DIR / "thumb_cache").resolve()
THUMB_MAX_EDGE = 720  # px; covers retina at the chat's ~280–360 displayed size
THUMB_TTL_DAYS = 180


def _thumb_for(orig: Path) -> Path | None:
    """Return a cached JPEG thumbnail for `orig`, generating if needed.

    Returns None if generation fails — caller should fall back to the original.
    Only meaningful for images; videos/audio/files should not call this.
    """
    try:
        st = orig.stat()
    except OSError:
        return None
    import hashlib
    key = hashlib.sha1(f"{orig}:{int(st.st_mtime)}".encode()).hexdigest()[:16]
    THUMB_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cached = THUMB_CACHE_DIR / f"{key}.jpg"
    if cached.exists() and cached.stat().st_mtime >= st.st_mtime:
        return cached
    try:
        subprocess.run(
            ["sips", "-Z", str(THUMB_MAX_EDGE), "-s", "format", "jpeg",
             str(orig), "--out", str(cached)],
            check=True, capture_output=True, timeout=30,
        )
    except Exception:
        return None
    return cached if cached.exists() else None


async def _thumb_cache_evictor():
    """Daily sweep: drop thumbs whose files are older than THUMB_TTL_DAYS.

    Re-viewing an old chat regenerates the thumb on demand; this just bounds
    disk use. Originals in ~/Library/Messages/Attachments are never touched.
    """
    while True:
        try:
            if THUMB_CACHE_DIR.exists():
                cutoff = time.time() - THUMB_TTL_DAYS * 86400
                pruned = 0
                for f in THUMB_CACHE_DIR.iterdir():
                    try:
                        if f.is_file() and f.stat().st_mtime < cutoff:
                            f.unlink()
                            pruned += 1
                    except OSError:
                        continue
                if pruned:
                    log.info("thumb cache: evicted %d files older than %dd",
                             pruned, THUMB_TTL_DAYS)
        except Exception as e:
            log.warning("thumb cache evictor: %s", e)
        await asyncio.sleep(86400)


def _ts(apple_date: int) -> str:
    if not apple_date:
        return ""
    epoch = apple_date / 1_000_000_000 + 978307200  # 2001-01-01
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(epoch))


def _short_ts(apple_date: int) -> str:
    """iMessage-style relative timestamp for the conversation list:
    today → HH:MM, yesterday → 'Yesterday', this week → weekday,
    this year → 'Mon DD', older → 'YYYY-MM-DD'."""
    if not apple_date:
        return ""
    epoch = apple_date / 1_000_000_000 + 978307200
    msg = time.localtime(epoch)
    now = time.localtime()
    if (msg.tm_year, msg.tm_yday) == (now.tm_year, now.tm_yday):
        return time.strftime("%H:%M", msg)
    yest = time.localtime(time.mktime(now) - 86400)
    if (msg.tm_year, msg.tm_yday) == (yest.tm_year, yest.tm_yday):
        return "Yesterday"
    days_ago = (time.mktime(now) - epoch) / 86400
    if 0 < days_ago < 7:
        return time.strftime("%a", msg)
    if msg.tm_year == now.tm_year:
        return time.strftime("%b %d", msg)
    return time.strftime("%Y-%m-%d", msg)


def _name(handle: str) -> str:
    return CONTACTS.get(handle.lower()) or handle


def _handles_for_canonical(canonical: str) -> list[str]:
    """Return all chat.db handles that map to the same person as `canonical`.

    "Same person" = same Contacts display name. Handles without a name match
    are person-of-one (return [canonical]).
    """
    name = CONTACTS.get(canonical.lower())
    if not name:
        return [canonical]
    scope = relay_handles()
    same = [h for h, n in CONTACTS.items() if n == name and h in scope]
    return same or [canonical]


def list_conversations() -> list[dict]:
    conn = _snapshot()
    try:
        rows = conn.execute(CONVOS_SQL).fetchall()
    finally:
        conn.close()

    scope = relay_handles()
    seen: dict[str, dict] = {}
    for r in rows:
        h = r["handle"] or ""
        if h.lower() not in scope:
            continue
        name = CONTACTS.get(h.lower())
        key = name or h
        if key in seen:
            # First row per key wins because CONVOS_SQL orders by last_dt DESC.
            seen[key]["n"] += int(r["n"])
            seen[key]["all_handles"].append(h)
            continue
        seen[key] = {
            "kind": "handle",
            "handle": h,
            "name": name or h,
            "preview": (r["preview"] or "").replace("￼", "📎").strip(),
            "last_dt": int(r["last_dt"] or 0),
            "n": int(r["n"]),
            "all_handles": [h],
        }

    merged = list(seen.values()) + _list_group_convos()
    merged.sort(key=lambda c: c["last_dt"], reverse=True)
    merged = merged[:CONVO_LIMIT]
    for c in merged:
        c["last"] = _short_ts(c["last_dt"])
    return merged


def _list_group_convos() -> list[dict]:
    """Sidebar entry per whitelisted group chat, with latest-message preview.

    Runs in-process (not via ChatDBReader) because the web process has its
    own backup-snapshot source connection; crossing processes would re-open
    chat.db and risk tripping the TCC cliff.
    """
    guids = sorted(wl_all_groups())
    if not guids:
        return []
    placeholders = ",".join("?" * len(guids))
    sql = f"""
        SELECT
            c.guid AS guid,
            COALESCE(c.display_name, '') AS name,
            c.chat_identifier AS chat_identifier,
            MAX(m.date) AS last_dt,
            COUNT(m.ROWID) AS n,
            (SELECT COALESCE(SUBSTR(m2.text,1,80), '')
               FROM message m2
               JOIN chat_message_join cmj2 ON cmj2.message_id = m2.ROWID
               WHERE cmj2.chat_id = c.ROWID
               ORDER BY m2.date DESC LIMIT 1) AS preview
        FROM chat c
        JOIN chat_message_join cmj ON cmj.chat_id = c.ROWID
        JOIN message m ON m.ROWID = cmj.message_id
        WHERE c.style = 43 AND c.guid IN ({placeholders})
        GROUP BY c.ROWID
    """
    conn = _snapshot()
    try:
        rows = conn.execute(sql, list(guids)).fetchall()
    finally:
        conn.close()
    out: list[dict] = []
    for r in rows:
        fallback = (r["chat_identifier"] or "").removeprefix("chat")[-6:]
        name = r["name"] or (f"Group {fallback}" if fallback else "(unnamed group)")
        out.append({
            "kind": "group",
            "guid": r["guid"],
            "name": name,
            "preview": (r["preview"] or "").replace("￼", "📎").strip(),
            "last_dt": int(r["last_dt"] or 0),
            "n": int(r["n"]),
        })
    return out


def _group_info(guid: str) -> dict:
    """Resolve a group GUID to {name, members} via chat.db. Unnamed groups
    get a synthetic short tag from chat_identifier so the header still shows
    something user-identifiable."""
    conn = _snapshot()
    try:
        row = conn.execute(
            """
            SELECT COALESCE(c.display_name, '') AS name,
                   c.chat_identifier AS chat_identifier,
                   (SELECT COUNT(DISTINCT chj.handle_id)
                      FROM chat_handle_join chj
                      WHERE chj.chat_id = c.ROWID) AS members
            FROM chat c
            WHERE c.guid = ? AND c.style = 43
            LIMIT 1
            """,
            (guid,),
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return {"name": "(unknown group)", "members": 0}
    fallback = (row["chat_identifier"] or "").removeprefix("chat")[-6:]
    name = row["name"] or (f"Group {fallback}" if fallback else "(unnamed group)")
    return {"name": name, "members": int(row["members"] or 0)}


def history_for(
    handle: str, before: tuple[int, int] | None = None
) -> tuple[list[dict], bool]:
    """Most-recent HISTORY_LIMIT messages for a 1:1, oldest-first for render.

    `before` is an optional `(date, rowid)` cursor \u2014 return messages strictly
    older than that point. Used by the load-older paging endpoint.

    Fetches `HISTORY_LIMIT + 1` rows so we can tell whether more pages exist
    without an extra round-trip; the extra row is dropped. Returns
    `(msgs, has_more)`.
    """
    handles = _handles_for_canonical(handle)
    placeholders = ",".join("?" * len(handles))
    if before is None:
        sql = HISTORY_SQL_TEMPLATE.format(
            placeholders=placeholders, cursor_clause=""
        )
        params = (*handles, HISTORY_LIMIT + 1)
    else:
        sql = HISTORY_SQL_TEMPLATE.format(
            placeholders=placeholders,
            cursor_clause="AND (m.date, m.ROWID) < (?, ?)",
        )
        params = (*handles, before[0], before[1], HISTORY_LIMIT + 1)
    conn = _snapshot()
    try:
        rows = conn.execute(sql, params).fetchall()
        has_more = len(rows) > HISTORY_LIMIT
        rows = rows[:HISTORY_LIMIT]
        atts_by_msg: dict[int, list[dict]] = defaultdict(list)
        for r in rows:
            if not r["has_attachments"]:
                continue
            for a in conn.execute(ATTACH_SQL, (r["rowid"],)).fetchall():
                fn = a["filename"]
                if not fn:
                    continue
                p = Path(fn).expanduser()
                mt = a["mime_type"] or ""
                kind = "image" if mt.startswith("image/") else \
                       "video" if mt.startswith("video/") else \
                       "audio" if mt.startswith("audio/") else "file"
                atts_by_msg[r["rowid"]].append({
                    "path": str(p),
                    "name": p.name,
                    "mime": mt,
                    "kind": kind,
                    # Trust the filesystem: if the file is there, render it,
                    # regardless of what transfer_state thinks. The flag lags.
                    "ready": p.exists(),
                })
    finally:
        conn.close()
    out = []
    for r in reversed(rows):
        body = (r["text"] or "").replace("\ufffc", "").strip()
        entry = {
            "rowid": r["rowid"],
            "date": int(r["date"] or 0),
            "from_me": bool(r["is_from_me"]),
            "ts": _ts(r["date"]),
            "text": body,
            "attachments": atts_by_msg.get(r["rowid"], []),
        }
        if entry["from_me"]:
            entry.update(_delivery_status(r))
        out.append(entry)
    return out, has_more


def history_for_group(
    guid: str, before: tuple[int, int] | None = None
) -> tuple[list[dict], bool]:
    """Message history for a single group chat, oldest-first for render.

    Adds sender_handle/sender_name to every entry so the UI can label
    incoming bubbles with the group member's name; outgoing rows keep the
    existing delivery fields.

    `before` is an optional `(date, rowid)` cursor — return messages strictly
    older than that point. Used by the load-older paging endpoint. Returns
    `(msgs, has_more)`; one extra row is fetched and dropped to compute the
    has-more flag without an extra round-trip.
    """
    if before is None:
        sql = HISTORY_GROUP_SQL_TEMPLATE.format(cursor_clause="")
        params = (guid, HISTORY_LIMIT + 1)
    else:
        sql = HISTORY_GROUP_SQL_TEMPLATE.format(
            cursor_clause="AND (m.date, m.ROWID) < (?, ?)",
        )
        params = (guid, before[0], before[1], HISTORY_LIMIT + 1)
    conn = _snapshot()
    try:
        rows = conn.execute(sql, params).fetchall()
        has_more = len(rows) > HISTORY_LIMIT
        rows = rows[:HISTORY_LIMIT]
        atts_by_msg: dict[int, list[dict]] = defaultdict(list)
        for r in rows:
            if not r["has_attachments"]:
                continue
            for a in conn.execute(ATTACH_SQL, (r["rowid"],)).fetchall():
                fn = a["filename"]
                if not fn:
                    continue
                p = Path(fn).expanduser()
                mt = a["mime_type"] or ""
                kind = "image" if mt.startswith("image/") else \
                       "video" if mt.startswith("video/") else \
                       "audio" if mt.startswith("audio/") else "file"
                atts_by_msg[r["rowid"]].append({
                    "path": str(p),
                    "name": p.name,
                    "mime": mt,
                    "kind": kind,
                    "ready": p.exists(),
                })
    finally:
        conn.close()
    out: list[dict] = []
    for r in reversed(rows):
        body = (r["text"] or "").replace("￼", "").strip()
        sender = r["sender_handle"] or ""
        entry = {
            "rowid": r["rowid"],
            "date": int(r["date"] or 0),
            "from_me": bool(r["is_from_me"]),
            "ts": _ts(r["date"]),
            "text": body,
            "attachments": atts_by_msg.get(r["rowid"], []),
            "sender_handle": sender,
            "sender_name": _name(sender) if sender else "",
        }
        if entry["from_me"]:
            entry.update(_delivery_status(r))
        out.append(entry)
    return out, has_more


def _cap_class_for(cap: str) -> str:
    """Map a capability label to one of the cap-* CSS classes used by the
    settings table and the contact view. Centralised here so both sites use
    the same colour-coding for the same string."""
    if "deregistered" in cap or "err=" in cap:
        return "cap-warn"
    if "✓" in cap:
        return "cap-good" if cap.startswith("iMessage") else "cap-warn"
    if "untested" in cap or "never contacted" in cap:
        return "cap-unknown"
    return "cap-unknown"


# Per-contact media gallery: most-recent N images/videos exchanged. Capped at
# CONTACT_MEDIA_LIMIT to keep the page light — the gallery is browse-bias, not
# archival. Audio/files are skipped (no useful thumbnail).
CONTACT_MEDIA_LIMIT = 200

CONTACT_MEDIA_HANDLE_SQL = """
SELECT a.filename, a.mime_type, m.date AS date
FROM message m
JOIN handle h ON m.handle_id = h.ROWID
JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
JOIN chat c ON c.ROWID = cmj.chat_id
JOIN message_attachment_join maj ON maj.message_id = m.ROWID
JOIN attachment a ON a.ROWID = maj.attachment_id
WHERE h.id IN ({placeholders}) AND c.style = 45
  AND a.filename IS NOT NULL
  AND (a.mime_type LIKE 'image/%' OR a.mime_type LIKE 'video/%')
ORDER BY m.date DESC
LIMIT ?
"""

CONTACT_MEDIA_GROUP_SQL = """
SELECT a.filename, a.mime_type, m.date AS date
FROM message m
JOIN chat_message_join cmj ON cmj.message_id = m.ROWID
JOIN chat c ON c.ROWID = cmj.chat_id
JOIN message_attachment_join maj ON maj.message_id = m.ROWID
JOIN attachment a ON a.ROWID = maj.attachment_id
WHERE c.guid = ?
  AND a.filename IS NOT NULL
  AND (a.mime_type LIKE 'image/%' OR a.mime_type LIKE 'video/%')
ORDER BY m.date DESC
LIMIT ?
"""


def _media_rows_to_entries(rows) -> list[dict]:
    out: list[dict] = []
    for r in rows:
        fn = r["filename"]
        if not fn:
            continue
        p = Path(fn).expanduser()
        if not p.exists():
            continue
        mt = r["mime_type"] or ""
        out.append({
            "path": str(p),
            "name": p.name,
            "mime": mt,
            "kind": "video" if mt.startswith("video/") else "image",
        })
    return out


def contact_for(handle: str) -> dict:
    """Render data for the contact page of a 1:1. Includes every handle that
    maps to the same person (so an Alice with both phone and email shows both
    rows with their own capability), plus a thumbnail grid of all photos and
    videos exchanged across those handles."""
    handles = _handles_for_canonical(handle)
    name = _name(handle)
    svc = _services_for_handles(handles)
    outcomes = _outcomes_for_handles(handles)
    handle_rows: list[dict] = []
    for h in handles:
        hl = h.lower()
        cap = _capability_label(svc.get(hl, []), outcomes.get(hl))
        handle_rows.append({
            "handle": h,
            "capability": cap,
            "cap_class": _cap_class_for(cap),
        })
    placeholders = ",".join("?" * len(handles))
    sql = CONTACT_MEDIA_HANDLE_SQL.format(placeholders=placeholders)
    conn = _snapshot()
    try:
        rows = conn.execute(sql, (*handles, CONTACT_MEDIA_LIMIT)).fetchall()
    finally:
        conn.close()
    return {
        "kind": "handle",
        "handle": handle,
        "name": name,
        "subtitle": handle if name != handle else "",
        "handles": handle_rows,
        "media": _media_rows_to_entries(rows),
    }


def _group_members(guid: str) -> list[str]:
    """Return the chat-member handles for a group GUID, sorted."""
    conn = _snapshot()
    try:
        rows = conn.execute(
            """
            SELECT h.id AS handle
            FROM chat c
            JOIN chat_handle_join chj ON chj.chat_id = c.ROWID
            JOIN handle h ON h.ROWID = chj.handle_id
            WHERE c.guid = ? AND c.style = 43
            """,
            (guid,),
        ).fetchall()
    finally:
        conn.close()
    return sorted({r["handle"] for r in rows if r["handle"]})


def contact_for_group(guid: str) -> dict:
    """Render data for the contact page of a group chat: name, members with
    per-handle capability, and the photos+videos exchanged in the chat."""
    info = _group_info(guid)
    members = _group_members(guid)
    svc = _services_for_handles(members)
    outcomes = _outcomes_for_handles(members)
    member_rows: list[dict] = []
    for h in members:
        hl = h.lower()
        cap = _capability_label(svc.get(hl, []), outcomes.get(hl))
        member_rows.append({
            "handle": h,
            "name": CONTACTS.get(hl, ""),
            "capability": cap,
            "cap_class": _cap_class_for(cap),
        })
    conn = _snapshot()
    try:
        rows = conn.execute(
            CONTACT_MEDIA_GROUP_SQL, (guid, CONTACT_MEDIA_LIMIT),
        ).fetchall()
    finally:
        conn.close()
    return {
        "kind": "group",
        "chat": guid,
        "name": info["name"],
        "subtitle": f"{info['members']} members" if info["members"] else "group chat",
        "members": member_rows,
        "media": _media_rows_to_entries(rows),
    }


def _delivery_status(r) -> dict:
    """Derive UI-facing delivery status from a message row.

    Returns {status, label, hint, service} where status is one of
    'delivered' | 'sent' | 'pending' | 'failed'. The frontend renders
    a badge only when status != 'delivered' (delivered is the default
    expectation and would be visual noise on every bubble).
    """
    err = int(r["error"] or 0)
    is_sent = bool(r["is_sent"])
    is_delivered = bool(r["is_delivered"])
    service = r["service"] or ""
    if err:
        from chat_send import ERROR_HINTS
        hint = ERROR_HINTS.get(err) or f"iMessage error {err}"
        return {"status": "failed", "label": f"not delivered ({err})",
                "hint": hint, "service": service}
    if is_delivered:
        return {"status": "delivered", "label": "", "hint": "", "service": service}
    if is_sent:
        return {"status": "sent", "label": "sent", "hint": "awaiting delivery receipt",
                "service": service}
    return {"status": "pending", "label": "pending",
            "hint": "Messages.app hasn't confirmed this send yet",
            "service": service}


# ------- routes -------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "index.html", {
        "version": APP_VERSION,
        "release_version": RELEASE_VERSION,
        "update_check_repo": UPDATE_CHECK_REPO,
        "web_theme": selected_theme(_bridge_config.load_config()),
    })


@app.get("/conversations", response_class=HTMLResponse)
async def conversations(request: Request):
    convos = await asyncio.to_thread(list_conversations)
    return templates.TemplateResponse(request, "_conversations.html", {"convos": convos})


def _paging_meta(
    msgs: list[dict], has_more: bool, handle: str, chat: str,
) -> dict:
    """Render `next_url` for the load-older trigger when more pages exist.

    `msgs` is oldest-first as rendered. The cursor for the next page is the
    (date, rowid) of the *oldest* message currently in the page — `msgs[0]`."""
    if not has_more or not msgs:
        return {"has_more": False, "next_url": ""}
    first = msgs[0]
    if chat:
        from urllib.parse import quote
        url = (f"/history?chat={quote(chat, safe='')}"
               f"&before_date={first['date']}&before_rowid={first['rowid']}")
    else:
        from urllib.parse import quote
        url = (f"/history?handle={quote(handle, safe='')}"
               f"&before_date={first['date']}&before_rowid={first['rowid']}")
    return {"has_more": True, "next_url": url}


@app.get("/conversation", response_class=HTMLResponse)
async def conversation(request: Request, handle: str = "", chat: str = ""):
    """Render a conversation. Exactly one of `handle` (1:1) or `chat`
    (group GUID) must be provided. Template branches on `is_group`."""
    if chat:
        if chat not in wl_all_groups():
            raise HTTPException(403, "group not in whitelist")
        msgs, has_more = await asyncio.to_thread(history_for_group, chat)
        info = await asyncio.to_thread(_group_info, chat)
        ctx = {
            "handle": "",
            "chat": chat,
            "name": info["name"],
            "subtitle": f"{info['members']} members" if info["members"] else "group chat",
            "is_group": True,
            "msgs": msgs,
        }
        ctx.update(_paging_meta(msgs, has_more, "", chat))
        return templates.TemplateResponse(request, "_conversation.html", ctx)
    if not handle:
        raise HTTPException(400, "missing handle or chat")
    if handle.lower() not in relay_handles():
        raise HTTPException(403, "handle not in relay scope")
    msgs, has_more = await asyncio.to_thread(history_for, handle)
    ctx = {
        "handle": handle,
        "chat": "",
        "name": _name(handle),
        "subtitle": handle,
        "is_group": False,
        "msgs": msgs,
    }
    ctx.update(_paging_meta(msgs, has_more, handle, ""))
    return templates.TemplateResponse(request, "_conversation.html", ctx)


@app.get("/history", response_class=HTMLResponse)
async def history(
    request: Request,
    handle: str = "",
    chat: str = "",
    before_date: int = 0,
    before_rowid: int = 0,
):
    """Older-message page for an open conversation. Returns the bubble
    fragment (oldest-first) plus a fresh load-older trigger if there are
    more pages still. Same authz as `/conversation`."""
    if before_date <= 0 or before_rowid <= 0:
        raise HTTPException(400, "missing or invalid cursor")
    cursor = (before_date, before_rowid)
    if chat:
        if chat not in wl_all_groups():
            raise HTTPException(403, "group not in whitelist")
        msgs, has_more = await asyncio.to_thread(history_for_group, chat, cursor)
        ctx = {"is_group": True, "msgs": msgs}
        ctx.update(_paging_meta(msgs, has_more, "", chat))
        return templates.TemplateResponse(request, "_history_page.html", ctx)
    if not handle:
        raise HTTPException(400, "missing handle or chat")
    if handle.lower() not in relay_handles():
        raise HTTPException(403, "handle not in relay scope")
    msgs, has_more = await asyncio.to_thread(history_for, handle, cursor)
    ctx = {"is_group": False, "msgs": msgs}
    ctx.update(_paging_meta(msgs, has_more, handle, ""))
    return templates.TemplateResponse(request, "_history_page.html", ctx)


async def _send_via_ctx_or_direct(
    request: Request, kind: str, handle: str, chat: str,
    body: str | None = None, file_path: Path | None = None,
) -> dict:
    """Issue one outbound send. In-process mode (`request.app.state.ctx` is
    set by `WebIntegration.start`) routes through the BridgeContext so the
    in-process echo deque sees the send. Standalone mode (no ctx) falls
    back to the direct `chat_send` path and registers in the cross-process
    `echo_log` file so a separately-running bridge.py still dedups.
    """
    ctx = getattr(request.app.state, "ctx", None)
    if ctx is not None:
        from integrations.base import SendTarget  # local import; ctx mode only
        target = SendTarget(
            kind="chat" if chat else "handle",
            value=chat or handle,
            label="",
        )
        if kind == "text":
            assert body is not None
            o = await ctx.send_text(target, body)
        else:
            assert file_path is not None
            o = await ctx.send_file(target, file_path)
        return {
            "kind": kind, "status": o.status, "hint": o.hint,
            "service": o.service, "error": o.error,
            "fell_back_to_sms": o.fell_back_to_sms,
            "original_error": o.original_error,
        }

    # Standalone fallback: direct AppleScript + cross-process echo log.
    if chat:
        if kind == "text":
            r = await asyncio.to_thread(send_text_to_chat_confirm, chat, body or "")
        else:
            r = await asyncio.to_thread(send_file_to_chat_confirm, chat, file_path)
    else:
        if kind == "text":
            r = await asyncio.to_thread(send_text_confirm, handle, body or "")
            echo_register(handle, "text", body or "")
        else:
            r = await asyncio.to_thread(send_file_confirm, handle, file_path)
            echo_register(handle, "photo")
    return {
        "kind": kind, "status": r.status, "hint": r.hint,
        "service": r.service, "error": r.error,
        "fell_back_to_sms": r.fell_back_to_sms,
        "original_error": r.original_error,
    }


@app.post("/send")
async def send(request: Request,
               handle: str = Form(""),
               chat: str = Form(""),
               body: str = Form(""),
               file: UploadFile | None = File(None)):
    """Outbound text and/or file. Exactly one of `handle` (1:1) or `chat`
    (group GUID) must be provided; group sends skip the SMS fallback path
    because the chat's service is fixed by its GUID."""
    if chat:
        if chat not in wl_all_groups():
            raise HTTPException(403, "group not in whitelist")
    elif handle:
        if handle.lower() not in relay_handles():
            raise HTTPException(403, "handle not in relay scope")
    else:
        raise HTTPException(400, "missing handle or chat")
    body = (body or "").strip()
    has_file = file is not None and file.filename
    if not body and not has_file:
        raise HTTPException(400, "empty send")

    results: list[dict] = []
    tmp_path = None
    try:
        if has_file:
            import tempfile
            suffix = Path(file.filename).suffix or ".bin"
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
                tmp.write(await file.read())
                tmp_path = Path(tmp.name)
            results.append(await _send_via_ctx_or_direct(
                request, "file", handle, chat, file_path=tmp_path,
            ))
        if body:
            results.append(await _send_via_ctx_or_direct(
                request, "text", handle, chat, body=body,
            ))
    finally:
        if tmp_path:
            try:
                tmp_path.unlink()
            except FileNotFoundError:
                pass

    # Worst-case status wins: failed > pending > sent > delivered.
    rank = {"delivered": 0, "sent": 1, "pending": 2, "failed": 3}
    worst = max(results, key=lambda x: rank.get(x["status"], 0)) if results else None
    return {"ok": worst is None or worst["status"] != "failed",
            "status": worst["status"] if worst else "delivered",
            "hint": worst["hint"] if worst else "",
            "fell_back_to_sms": any(r.get("fell_back_to_sms") for r in results),
            "results": results}


@app.get("/contact", response_class=HTMLResponse)
async def contact(request: Request, handle: str = "", chat: str = ""):
    """Render the contact / group-info page. Same routing rule as /conversation:
    exactly one of `handle` (1:1) or `chat` (group GUID)."""
    if chat:
        if chat not in wl_all_groups():
            raise HTTPException(403, "group not in whitelist")
        ctx = await asyncio.to_thread(contact_for_group, chat)
        ctx["back_url"] = f"/conversation?chat={chat}"
        return templates.TemplateResponse(request, "_contact.html", ctx)
    if not handle:
        raise HTTPException(400, "missing handle or chat")
    if handle.lower() not in relay_handles():
        raise HTTPException(403, "handle not in relay scope")
    ctx = await asyncio.to_thread(contact_for, handle)
    ctx["back_url"] = f"/conversation?handle={handle}"
    return templates.TemplateResponse(request, "_contact.html", ctx)


@app.get("/events")
async def events():
    """SSE stream tailing mirror.jsonl. Sends one `data: {json}` per relay event."""
    async def gen():
        if not MIRROR_FILE.exists():
            yield "event: ping\ndata: {}\n\n"
        # Seek to end and tail
        try:
            f = open(MIRROR_FILE, "r", encoding="utf-8")
        except FileNotFoundError:
            return
        f.seek(0, 2)
        last_ping = time.time()
        try:
            while True:
                line = f.readline()
                if line:
                    # Enrich with the resolved contact name so the in-page
                    # Notification can show "iMessage from Alice" instead of
                    # the raw handle. Pass through unchanged on parse errors.
                    out = line.strip()
                    try:
                        evt = json.loads(out)
                        h = evt.get("handle")
                        if h and "name" not in evt:
                            evt["name"] = _name(h)
                            out = json.dumps(evt)
                    except Exception:
                        pass
                    yield f"data: {out}\n\n"
                else:
                    await asyncio.sleep(0.5)
                    if time.time() - last_ping > 25:
                        yield "event: ping\ndata: {}\n\n"
                        last_ping = time.time()
        finally:
            f.close()

    return StreamingResponse(gen(), media_type="text/event-stream")


@app.get("/attachment")
async def attachment(path: str, size: str = ""):
    p = Path(path).expanduser().resolve()
    try:
        p.relative_to(ATTACHMENTS_BASE)
    except ValueError:
        raise HTTPException(403, "outside attachment dir")
    if not p.exists():
        raise HTTPException(404, "missing")
    # Thumbnail mode for inline chat images. Resizes via sips into a separate
    # cache dir; falls through to full-size on any failure so the UI still
    # shows something. Only meaningful for image suffixes — videos/audio
    # should never request size=thumb (the template doesn't).
    if size == "thumb":
        suffix = p.suffix.lower()
        if suffix in (".jpg", ".jpeg", ".png", ".gif", ".heic", ".heif", ".webp"):
            thumb = await asyncio.to_thread(_thumb_for, p)
            if thumb is not None:
                return FileResponse(
                    thumb, media_type="image/jpeg",
                    headers={"Cache-Control": "public, max-age=2592000"},
                )
        # fall through to full-size on unknown ext or sips failure
    # Convert HEIC to JPEG on the fly so browsers can render it.
    if p.suffix.lower() in (".heic", ".heif"):
        cached = p.with_suffix(".jpg")
        if not (cached.exists() and cached.stat().st_mtime >= p.stat().st_mtime):
            try:
                subprocess.run(["sips", "-s", "format", "jpeg", str(p),
                                "--out", str(cached)],
                               check=True, capture_output=True, timeout=30)
            except Exception:
                return FileResponse(p)
        return FileResponse(cached, media_type="image/jpeg")
    # iPhone .mov: relabel as video/mp4 so Chrome/Safari will play inline.
    # Firefox often still rejects (HEVC / QT container), falls back to the
    # download link in the template. See README "Firefox-compatible video
    # playback" for the transcode path if it's ever needed.
    if p.suffix.lower() == ".mov":
        return FileResponse(p, media_type="video/mp4")
    return FileResponse(p)


@app.get("/avatar")
async def avatar(handle: str):
    """Return the contact's avatar JPEG. Looks up by the requested handle, or
    falls back to any handle of the same person if that one has no image."""
    h = handle.lower()
    candidates = [h]
    name = CONTACTS.get(h)
    if name:
        candidates.extend(other for other, n in CONTACTS.items() if n == name and other != h)
    for cand in candidates:
        loc = IMAGE_INDEX.get(cand)
        if not loc:
            continue
        blob = await asyncio.to_thread(fetch_image, loc[0], loc[1], True)
        if blob:
            from fastapi.responses import Response
            return Response(content=blob, media_type="image/jpeg",
                             headers={"Cache-Control": "public, max-age=3600"})
    raise HTTPException(404)


# ------- web push notifications (desktop) -------

_push_lock = __import__("threading").Lock()


def _load_subs() -> list[dict]:
    if not PUSH_SUBS_FILE.exists():
        return []
    try:
        return json.loads(PUSH_SUBS_FILE.read_text())
    except Exception:
        return []


def _save_subs(subs: list[dict]) -> None:
    PUSH_SUBS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = PUSH_SUBS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(subs, indent=2))
    tmp.replace(PUSH_SUBS_FILE)


@app.get("/push/vapid-public-key")
async def push_vapid_key():
    if not VAPID_PUBLIC_KEY:
        raise HTTPException(503, "push not configured")
    return {"key": VAPID_PUBLIC_KEY}


@app.post("/push/subscribe")
async def push_subscribe(request: Request):
    body = await request.json()
    sub = body.get("subscription")
    if not sub or not sub.get("endpoint"):
        raise HTTPException(400, "missing subscription.endpoint")
    with _push_lock:
        subs = _load_subs()
        subs = [s for s in subs if s.get("endpoint") != sub["endpoint"]]
        subs.append(sub)
        _save_subs(subs)
    log.info("push subscribed; total=%d", len(subs))
    return {"ok": True, "count": len(subs)}


async def _push_tailer():
    """Tail mirror.jsonl and fan inbound events out as web-push."""
    if not (VAPID_PRIVATE_KEY and VAPID_PUBLIC_KEY):
        log.info("push disabled (no VAPID keys)")
        return
    from pywebpush import webpush, WebPushException

    while not MIRROR_FILE.exists():
        await asyncio.sleep(2)
    f = open(MIRROR_FILE, "r", encoding="utf-8")
    f.seek(0, 2)
    log.info("push tailer watching %s", MIRROR_FILE)
    try:
        while True:
            line = f.readline()
            if not line:
                await asyncio.sleep(0.5)
                continue
            try:
                evt = json.loads(line)
            except Exception:
                continue
            if evt.get("event") != "inbound" or evt.get("is_from_me"):
                continue
            handle = evt.get("handle", "")
            chat_guid = evt.get("chat_guid", "")
            text = (evt.get("text") or "").replace("\ufffc", "📎").strip() or "(attachment)"
            if chat_guid:
                group = evt.get("chat_name") or "Group"
                sender = _name(handle) if handle else ""
                body_text = (f"{sender}: " if sender else "") + text
                payload = json.dumps({
                    "title": f"iMessage [{group}]",
                    "body": body_text[:140],
                    "chat": chat_guid,
                    "tag": chat_guid,
                })
            else:
                payload = json.dumps({
                    "title": f"iMessage from {_name(handle)}",
                    "body": text[:140],
                    "handle": handle,
                    "tag": handle,
                })
            with _push_lock:
                subs = list(_load_subs())
            dead: list[str] = []
            for sub in subs:
                try:
                    await asyncio.to_thread(
                        webpush,
                        subscription_info=sub,
                        data=payload,
                        vapid_private_key=VAPID_PRIVATE_KEY,
                        vapid_claims={"sub": VAPID_CONTACT},
                    )
                except WebPushException as e:
                    code = getattr(e.response, "status_code", None)
                    if code in (404, 410):
                        dead.append(sub.get("endpoint", ""))
                    else:
                        log.warning("push error (%s): %s", code, e)
                except Exception as e:
                    log.warning("push unexpected: %s", e)
            if dead:
                with _push_lock:
                    subs = [s for s in _load_subs() if s.get("endpoint") not in dead]
                    _save_subs(subs)
                log.info("pruned %d dead push subs", len(dead))
    finally:
        f.close()


@app.on_event("startup")
async def _start_push_tailer():
    asyncio.create_task(_push_tailer())
    asyncio.create_task(_thumb_cache_evictor())


@app.post("/refresh_contacts", response_class=HTMLResponse)
async def refresh_contacts(request: Request):
    global CONTACTS, IMAGE_INDEX
    CONTACTS = await asyncio.to_thread(load_contacts)
    IMAGE_INDEX = await asyncio.to_thread(load_image_index)
    resp = templates.TemplateResponse(request, "_settings.html", {
        "rows": _whitelist_rows(),
        "self_handles": sorted(SELF_HANDLES),
        "contact_names": _contact_names(),
        "has_password": getattr(app.state, "auth_block", None) is not None,
        "csrf_token": _csrf_token(),
        "web_theme": selected_theme(_bridge_config.load_config()),
        "themes": themes_for_picker(),
    })
    resp.headers["HX-Trigger"] = json.dumps({
        "contacts-synced": {"loaded": len(CONTACTS), "with_image": len(IMAGE_INDEX)}
    })
    return resp


# ------- whitelist management -------

# Groups shown in the datalist are prefixed with this so the backend can tell
# a picked group apart from a contact name typed at the same input.
GROUP_LABEL_PREFIX = "[Group] "


def _list_named_groups() -> list[dict]:
    """Return named group chats from chat.db, most-recent first.

    Mirrors chat_db.ChatDBReader.list_groups but uses this process's
    _snapshot() (each process keeps its own persistent source conn to avoid
    TCC re-open issues). Only named groups appear in the web UI; unnamed
    groups can still be added by pasting a GUID.
    """
    conn = _snapshot()
    try:
        rows = conn.execute(
            """
            SELECT c.guid AS guid,
                   c.chat_identifier AS chat_identifier,
                   COALESCE(c.display_name, '') AS name,
                   MAX(cmj.message_id) AS last_rowid,
                   COUNT(DISTINCT chj.handle_id) AS member_count
            FROM chat c
            JOIN chat_message_join cmj ON cmj.chat_id = c.ROWID
            LEFT JOIN chat_handle_join chj ON chj.chat_id = c.ROWID
            WHERE c.style = 43 AND c.display_name != ''
            GROUP BY c.ROWID
            ORDER BY last_rowid DESC
            """
        ).fetchall()
    finally:
        conn.close()
    return [
        {
            "guid": r["guid"],
            "chat_identifier": r["chat_identifier"],
            "name": r["name"],
            "members": int(r["member_count"] or 0),
        }
        for r in rows
    ]


def _looks_like_group_guid(s: str) -> bool:
    s = s.strip()
    return (s.startswith("iMessage;") or s.startswith("SMS;")) and ";+;chat" in s


def _resolve_whitelist_input(s: str) -> tuple[list[str], list[str]]:
    """Name, handle, group name, or group GUID → (handles, group_guids).

    - "[Group] Civi-kids" → look up by display_name in chat.db (most-recent
      match wins if names collide).
    - "iMessage;+;chat…" → take as a literal group GUID.
    - Anything else is a handle/name: if it matches a Contacts display name,
      expand to every known handle for that person; otherwise treat as a
      single literal handle.
    """
    s = (s or "").strip()
    if not s:
        return [], []
    if s.startswith(GROUP_LABEL_PREFIX):
        needle = s[len(GROUP_LABEL_PREFIX):].strip().lower()
        # Pick the most-recent matching group — _list_named_groups is
        # already ordered by last message.
        for g in _list_named_groups():
            if g["name"].lower() == needle:
                return [], [g["guid"]]
        return [], []
    if _looks_like_group_guid(s):
        return [], [s]
    low = s.lower()
    matches = [h for h, name in CONTACTS.items() if name.lower() == low]
    return (matches if matches else [low]), []


def _resolve_handles(s: str) -> list[str]:
    """Back-compat shim. Callers that only want handles (e.g. capability
    lookups) drop any group results."""
    handles, _ = _resolve_whitelist_input(s)
    return handles


def _services_for_handles(handles: list[str]) -> dict[str, list[str]]:
    """{handle_lc: [services...]} — 'iMessage', 'SMS', or empty if unseen.

    Reads `handle.service` from chat.db. A phone number that has both rows
    (one per service) shows both. A handle we've never messaged is absent —
    callers should treat that as "unknown, will be revealed on first send".
    """
    if not handles:
        return {}
    lows = [h.lower() for h in handles]
    placeholders = ",".join("?" * len(lows))
    out: dict[str, list[str]] = {h: [] for h in lows}
    conn = _snapshot()
    try:
        rows = conn.execute(
            f"SELECT LOWER(id) AS id, service FROM handle WHERE LOWER(id) IN ({placeholders})",
            lows,
        ).fetchall()
        for r in rows:
            out.setdefault(r["id"], []).append(r["service"])
    finally:
        conn.close()
    return out


def _outcomes_for_handles(
    handles: list[str], window_days: int = 30
) -> dict[str, dict[str, dict]]:
    """Per-handle-per-service outgoing stats — mirror of ChatDBReader.outcomes_for.

    Uses the web process's _snapshot() instead of the bridge's reader. See
    the bridge-side method for the contract.
    """
    if not handles:
        return {}
    lows = [h.lower() for h in handles]
    placeholders = ",".join("?" * len(lows))
    cutoff_apple_ns = int(
        (time.time() - window_days * 86400 - APPLE_EPOCH_OFFSET) * 1_000_000_000
    )
    out: dict[str, dict[str, dict]] = {h: {} for h in lows}
    conn = _snapshot()
    try:
        agg_sql = f"""
            SELECT LOWER(h.id) AS handle, h.service AS service,
                   COUNT(*) AS total,
                   COALESCE(SUM(m.is_delivered), 0) AS delivered,
                   COALESCE(SUM(CASE WHEN m.error = 22 THEN 1 ELSE 0 END), 0) AS err22
            FROM message m JOIN handle h ON m.handle_id = h.ROWID
            WHERE m.is_from_me = 1
              AND LOWER(h.id) IN ({placeholders})
              AND m.date >= ?
            GROUP BY LOWER(h.id), h.service
        """
        for r in conn.execute(agg_sql, [*lows, cutoff_apple_ns]).fetchall():
            out[r["handle"]][r["service"]] = {
                "total": int(r["total"]),
                "delivered": int(r["delivered"]),
                "err22": int(r["err22"]),
            }
        latest_sql = f"""
            SELECT LOWER(h.id) AS handle, h.service AS service,
                   m.error AS error, m.is_delivered AS is_delivered, m.ROWID AS rowid
            FROM message m JOIN handle h ON m.handle_id = h.ROWID
            WHERE m.is_from_me = 1
              AND LOWER(h.id) IN ({placeholders})
              AND m.ROWID IN (
                  SELECT MAX(m2.ROWID) FROM message m2
                  JOIN handle h2 ON m2.handle_id = h2.ROWID
                  WHERE m2.is_from_me = 1
                    AND LOWER(h2.id) IN ({placeholders})
                  GROUP BY LOWER(h2.id), h2.service
              )
        """
        for r in conn.execute(latest_sql, [*lows, *lows]).fetchall():
            stats = out[r["handle"]].setdefault(
                r["service"], {"total": 0, "delivered": 0, "err22": 0}
            )
            stats["latest_error"] = int(r["error"] or 0)
            stats["latest_delivered"] = bool(r["is_delivered"])
            stats["latest_rowid"] = int(r["rowid"])
    finally:
        conn.close()
    return out


def _capability_label(
    services: list[str], outcomes: dict[str, dict] | None = None
) -> str:
    """Honest capability label for the web UI — see bridge._fmt_capability."""
    outcomes = outcomes or {}
    im = outcomes.get("iMessage") or {}
    sms = outcomes.get("SMS") or {}
    has_im_cfg = "iMessage" in services
    has_sms_cfg = "SMS" in services
    if not services:
        return "never contacted"

    im_total = im.get("total", 0)
    im_delivered = im.get("delivered", 0)
    im_latest_err = im.get("latest_error", 0)
    sms_total = sms.get("total", 0)
    sms_delivered = sms.get("delivered", 0)
    sms_latest_err = sms.get("latest_error", 0)

    # SMS carriers don't return delivery receipts — is_delivered=0 is the norm
    # for SMS even when the message landed. Only err=0 is trustworthy.
    if has_im_cfg:
        if im_latest_err == 22:
            if sms_total > 0 and sms_latest_err == 0:
                return f"iMessage deregistered → SMS ✓ ({sms_total} sent 30d)"
            if sms_total > 0:
                return f"iMessage deregistered → SMS err={sms_latest_err}"
            return "iMessage deregistered (SMS untested)"
        if im_total == 0 and "latest_rowid" not in im:
            if has_sms_cfg and sms_total > 0:
                return f"iMessage configured (untested 30d), SMS {sms_total} sent"
            return "iMessage configured (untested 30d)"
        if im_delivered > 0:
            tail = f", SMS {sms_total} sent" if sms_total > 0 else ""
            return f"iMessage ✓ {im_delivered}/{im_total} 30d{tail}"
        return f"iMessage {im_total} sent / 0 delivered 30d, latest err={im_latest_err}"

    if has_sms_cfg:
        if sms_total == 0:
            return "SMS only (untested 30d)"
        if sms_latest_err == 0:
            return f"SMS ✓ {sms_total} sent 30d"
        return f"SMS err={sms_latest_err} ({sms_total} sent 30d)"

    return "+".join(services) + " (unknown)"


def _whitelist_rows() -> list[dict]:
    """Mixed handle + group rows for the settings UI. Groups carry kind='group'
    and a guid field; the template's remove form branches on that."""
    handles = sorted(wl_all())
    svc = _services_for_handles(handles)
    outcomes = _outcomes_for_handles(handles)
    rows: list[dict] = []
    for h in handles:
        hl = h.lower()
        cap = _capability_label(svc.get(hl, []), outcomes.get(hl))
        rows.append({
            "kind": "handle",
            "handle": h,
            "name": CONTACTS.get(h, ""),
            "capability": cap,
            "cap_class": _cap_class_for(cap),
        })

    # Groups: resolve display names from chat.db for any GUIDs in the whitelist.
    group_guids = sorted(wl_all_groups())
    if group_guids:
        name_by_guid: dict[str, tuple[str, int]] = {}
        for g in _list_named_groups():
            name_by_guid[g["guid"]] = (g["name"], g["members"])
        for guid in group_guids:
            name, members = name_by_guid.get(guid, ("(unnamed group)", 0))
            rows.append({
                "kind": "group",
                "guid": guid,
                "name": name,
                "members": members,
                "capability": f"{members} members" if members else "group chat",
                "cap_class": "cap-unknown",
            })
    return rows


def _contact_names() -> list[str]:
    """Deduped, sorted autocomplete options for the add-input datalist.

    Contacts come as plain names ("Alice Chen"); named groups are prefixed
    with "[Group] " so the backend can disambiguate when the same value
    comes back on form submit (and so the user can see what kind of row
    they're about to add)."""
    contact = sorted({n for n in CONTACTS.values() if n}, key=str.lower)
    groups = [f"{GROUP_LABEL_PREFIX}{g['name']}" for g in _list_named_groups()]
    return contact + groups


@app.get("/settings", response_class=HTMLResponse)
async def settings(request: Request):
    return templates.TemplateResponse(request, "_settings.html", {
        "rows": _whitelist_rows(),
        "self_handles": sorted(SELF_HANDLES),
        "contact_names": _contact_names(),
        "has_password": getattr(app.state, "auth_block", None) is not None,
        "csrf_token": _csrf_token(),
        "web_theme": selected_theme(_bridge_config.load_config()),
        "themes": themes_for_picker(),
    })


@app.post("/api/settings/theme", response_class=HTMLResponse)
async def api_settings_theme(request: Request, theme: str = Form("")):
    """Persist a theme pick to web.theme. Validates against the on-disk
    list so a typo or stale slug can't write a value that'd render with
    a 404'd stylesheet on the next page load."""
    if theme not in available_themes():
        raise HTTPException(400, f"Unknown theme: {theme!r}")
    cfg = _bridge_config.load_config()
    cfg.setdefault("web", {})["theme"] = theme
    _bridge_config.save_config(cfg)
    return templates.TemplateResponse(request, "_appearance_card.html", {
        "web_theme": theme,
        "themes": themes_for_picker(),
    })


@app.get("/whitelist_fragment", response_class=HTMLResponse)
async def whitelist_fragment(request: Request):
    return templates.TemplateResponse(request, "_whitelist_rows.html", {
        "rows": _whitelist_rows(),
    })


@app.post("/whitelist/add", response_class=HTMLResponse)
async def whitelist_add_route(request: Request, input: str = Form("")):
    handles, groups = _resolve_whitelist_input(input)
    for h in handles:
        wl_add(h)
    for g in groups:
        wl_add_group(g)
    return templates.TemplateResponse(request, "_whitelist_rows.html", {
        "rows": _whitelist_rows(),
    })


@app.post("/whitelist/remove", response_class=HTMLResponse)
async def whitelist_remove_route(
    request: Request,
    handle: str = Form(""),
    guid: str = Form(""),
):
    if handle:
        wl_remove(handle)
    if guid:
        wl_remove_group(guid)
    return templates.TemplateResponse(request, "_whitelist_rows.html", {
        "rows": _whitelist_rows(),
    })


def main():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=WEB_PORT, log_level="info")


if __name__ == "__main__":
    main()
