# justifycert

Fast, opinionated TLS certificate checks for developers.

## What it checks

- Expired or expiring certificates
- Weak signature algorithms such as SHA1
- Self-signed certificates
- Missing Subject Alternative Name (SAN)
- Basic chain validation for domain lookups

## Install

```bash
pip install .
```

## Example

```bash
$ justifycert expired.badssl.com

✖ Certificate expired 10 days ago — renew immediately
```

## Use

```bash
justifycert example.com
justifycert --file cert.pem
justifycert example.com --json
```

## Library

```python
from justifycert import analyze_domain, analyze_pem_file

result = analyze_domain("example.com")
print(result["valid"])
print(result["issues"])
```

The library returns a plain Python dictionary with:

```python
{
    "valid": bool,
    "issues": [...],
    "subject": "...",
    "issuer": "...",
    "not_before": "...",
    "not_after": "...",
    "signature_algorithm": "...",
}
```
