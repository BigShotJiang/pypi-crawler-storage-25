# {{ cookiecutter.service_name }}

Platform identity service — manages users and credentials.

## Endpoints

- `POST /api/signup` — create a new user
- `GET /api/users/{user_id}` — get user by ID
- `GET /api/users/{user_id}/roles` — get user roles
- `POST /api/users/{user_id}/roles` — assign a role to user
- `POST /api/verify-credentials` — verify username/password (used by auth-service)
- `GET /health` — liveness probe

## Configuration

| Variable | Default | Description |
|---|---|---|
| `DB_PATH` | `./{{ cookiecutter.__service_name_snake }}.db` | SQLite database path |

## Run

```bash
pip install -r requirements.txt
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```
