from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "{{ cookiecutter.service_name }}"
    port: int = {{ cookiecutter.port }}
    auth_service_url: str = "{{ cookiecutter.auth_service_url }}"


settings = Settings()
