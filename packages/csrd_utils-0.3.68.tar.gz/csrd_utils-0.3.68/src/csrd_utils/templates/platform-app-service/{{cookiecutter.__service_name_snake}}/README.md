# {{ cookiecutter.service_name }}

Platform app service with auth-guarded item endpoints.

## Endpoints

- `GET /health` - liveness probe
- `POST /api/items` - create item (bearer required)
- `GET /api/items` - list items (bearer required)
- `GET /api/items/{entity_id}` - get item (bearer required)
- `PUT /api/items/{entity_id}` - update item (bearer required)
- `PUT /api/items/{entity_id}/upsert` - upsert item (bearer required)
- `DELETE /api/items/{entity_id}` - delete item (bearer required)

## Configuration

| Variable | Default | Description |
|---|---|---|
| `AUTH_SERVICE_URL` | `{{ cookiecutter.auth_service_url }}` | Auth service verify endpoint base URL |

## Run

```bash
pip install -r requirements.txt
uvicorn {{ cookiecutter.__service_name_snake }}:build_app --factory --port {{ cookiecutter.port }}
```
