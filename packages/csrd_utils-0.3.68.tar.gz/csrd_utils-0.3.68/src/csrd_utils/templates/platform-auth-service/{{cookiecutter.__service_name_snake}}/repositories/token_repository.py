from __future__ import annotations

from datetime import UTC, datetime

from csrd.repository import BaseRepository, DBProtocol


class TokenRepository(BaseRepository):
    """Repository backed by a pluggable DBProtocol adapter."""

    def __init__(self, adapter: DBProtocol) -> None:
        super().__init__(adapter)

    async def _init_schema(self) -> None:
        await self.execute(
            """
            CREATE TABLE IF NOT EXISTS issued_tokens (
                token TEXT PRIMARY KEY,
                subject TEXT NOT NULL,
                issued_at TEXT NOT NULL
            )
            """
        )

    async def record_issued_token(self, token: str, subject: str) -> None:
        issued_at = datetime.now(UTC).isoformat()
        await self._init_schema()
        await self.execute(
            "INSERT OR REPLACE INTO issued_tokens (token, subject, issued_at) "
            "VALUES (:token, :subject, :issued_at)",
            {"token": token, "subject": subject, "issued_at": issued_at},
        )
