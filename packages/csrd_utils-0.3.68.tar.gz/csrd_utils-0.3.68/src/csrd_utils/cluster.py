"""Cluster scaffolding helpers for csrd-utils."""

from collections.abc import Iterable
from pathlib import Path
from typing import Any, TypedDict, cast

import yaml  # type: ignore[import-untyped]


class ServiceSpec(TypedDict, total=False):
    name: str
    type: str
    database: str
    delegates: list[str]
    broker: str
    role: str
    port: int
    features: list[str]
    requires: list[str]


class ClusterSpec(TypedDict):
    cluster: dict[str, str]
    services: list[ServiceSpec]


INFRA_NAMES = {"postgres", "mariadb", "redis", "rabbitmq"}
DEFAULT_PORT_START = 8091

PRESETS: dict[str, list[ServiceSpec]] = {
    "none": [],
    "authenticated-cluster": [
        {
            "name": "app-service",
            "type": "platform",
            "role": "app",
            "port": 8080,
            "requires": ["auth-service"],
        },
        {"name": "auth-service", "type": "platform", "role": "auth", "port": 8081, "requires": []},
        {
            "name": "identity-service",
            "type": "platform",
            "role": "identity",
            "port": 8082,
            "requires": ["auth-service"],
        },
    ],
    # "minimal-cluster": [
    #     {"name": "auth-service", "type": "platform", "role": "auth", "port": 8081, "requires": []},
    #     {
    #         "name": "core-db",
    #         "type": "db",
    #         "database": "sqlite",
    #         "port": 8091,
    #         "requires": ["auth-service"],
    #     },
    # ],
    # "event-driven-cluster": [
    #     {"name": "auth-service", "type": "platform", "role": "auth", "port": 8081, "requires": []},
    #     {
    #         "name": "events",
    #         "type": "db",
    #         "database": "postgres",
    #         "port": 8091,
    #         "requires": ["auth-service"],
    #     },
    #     {
    #         "name": "worker-consume",
    #         "type": "worker",
    #         "broker": "redis",
    #         "port": 8093,
    #         "requires": ["events", "redis"],
    #     },
    # ],
}


def _split_csv(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def load_cluster_spec(spec_path: Path) -> ClusterSpec:
    if not spec_path.is_file():
        raise ValueError(f"Cluster spec file not found: {spec_path}")
    payload = yaml.safe_load(spec_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Cluster spec must be a YAML object")
    cluster = payload.get("cluster")
    services = payload.get("services")
    if not isinstance(cluster, dict) or not isinstance(services, list):
        raise ValueError("Cluster spec must include 'cluster' object and 'services' list")

    name = str(cluster.get("name", "")).strip()
    if not name:
        raise ValueError("cluster.name is required")

    preset = str(cluster.get("preset", "none")).strip() or "none"
    parsed_services: list[ServiceSpec] = [
        cast(ServiceSpec, dict(service)) for service in services if isinstance(service, dict)
    ]

    return {
        "cluster": {"name": name, "preset": preset},
        "services": parsed_services,
    }


def normalize_cluster_spec(spec: ClusterSpec) -> ClusterSpec:
    cluster_name = spec["cluster"]["name"].strip()
    preset = spec["cluster"].get("preset", "none").strip() or "none"
    if preset not in PRESETS:
        raise ValueError(f"Unknown preset: {preset}")

    services: list[ServiceSpec] = [cast(ServiceSpec, dict(service)) for service in PRESETS[preset]]
    services.extend(cast(ServiceSpec, dict(service)) for service in spec.get("services", []))

    used_names: set[str] = set()
    used_ports: set[int] = set()
    next_port = DEFAULT_PORT_START
    normalized: list[ServiceSpec] = []

    for service in services:
        name = str(service.get("name", "")).strip()
        if not name:
            raise ValueError("Each service requires a name")
        if name in used_names:
            raise ValueError(f"Duplicate service name: {name}")
        used_names.add(name)

        service_type = str(service.get("type", "")).strip()
        if service_type not in {"db", "delegate", "worker", "platform"}:
            raise ValueError(f"Unsupported service type for {name}: {service_type}")

        normalized_service: ServiceSpec = {
            "name": name,
            "type": service_type,
            "features": list(service.get("features", [])),
            "requires": list(service.get("requires", [])),
        }

        port = service.get("port")
        if port is None:
            while next_port in used_ports:
                next_port += 1
            port = next_port
            next_port += 1
        if int(port) in used_ports:
            raise ValueError(f"Duplicate port detected: {port}")
        normalized_service["port"] = int(port)
        used_ports.add(int(port))

        if service_type == "db":
            database = str(service.get("database", "")).strip()
            if database not in {"sqlite", "maria", "postgres"}:
                raise ValueError(f"DB service '{name}' requires database sqlite/maria/postgres")
            normalized_service["database"] = database

        if service_type == "delegate":
            delegates = service.get("delegates", [])
            if isinstance(delegates, str):
                delegates = _split_csv(delegates)
            normalized_service["delegates"] = list(delegates)

        if service_type == "db" and "delegates" in service:
            delegates = service.get("delegates", [])
            if isinstance(delegates, str):
                delegates = _split_csv(delegates)
            normalized_service["delegates"] = list(delegates)

        if service_type == "worker":
            broker = str(service.get("broker", "")).strip() or "redis"
            if broker not in {"redis", "rabbitmq"}:
                raise ValueError(f"Worker service '{name}' requires broker redis/rabbitmq")
            normalized_service["broker"] = broker

        if service_type == "platform":
            normalized_service["role"] = str(service.get("role", "custom")).strip() or "custom"

        normalized.append(normalized_service)

    _validate_dependencies(normalized)
    _validate_cycles(normalized)

    return {"cluster": {"name": cluster_name, "preset": preset}, "services": normalized}


def _validate_dependencies(services: list[ServiceSpec]) -> None:
    names = {str(service["name"]) for service in services}

    for service in services:
        name = str(service["name"])
        delegates = service.get("delegates", [])
        for target in delegates:
            if target not in names:
                raise ValueError(f"Service '{name}' delegates to unknown service '{target}'")

        requires = service.get("requires", [])
        for required in requires:
            if required not in names and required not in INFRA_NAMES:
                raise ValueError(f"Service '{name}' requires unknown dependency '{required}'")


def _validate_cycles(services: list[ServiceSpec]) -> None:
    names = {str(service["name"]) for service in services}
    graph: dict[str, list[str]] = {}
    for service in services:
        name = str(service["name"])
        graph[name] = [dep for dep in service.get("requires", []) if dep in names]

    visiting: set[str] = set()
    visited: set[str] = set()

    def walk(node: str) -> None:
        if node in visited:
            return
        if node in visiting:
            raise ValueError(f"Circular dependency detected at '{node}'")
        visiting.add(node)
        for nxt in graph.get(node, []):
            walk(nxt)
        visiting.remove(node)
        visited.add(node)

    for node in graph:
        walk(node)


def _infer_infra(services: Iterable[ServiceSpec]) -> set[str]:
    infra: set[str] = set()
    for service in services:
        service_type = service["type"]
        if service_type == "db":
            db = service.get("database")
            if db == "postgres":
                infra.add("postgres")
            if db == "maria":
                infra.add("mariadb")
        if service_type == "worker":
            broker = service.get("broker", "redis")
            infra.add("redis" if broker == "redis" else "rabbitmq")
        if "workers" in service.get("features", []):
            broker = service.get("broker", "redis")
            infra.add("redis" if broker == "redis" else "rabbitmq")
        if "caching" in service.get("features", []):
            infra.add("redis")
        for required in service.get("requires", []):
            if required in INFRA_NAMES:
                infra.add(required)
    return infra


def _service_environment(service: ServiceSpec, services: list[ServiceSpec]) -> dict[str, str]:
    env: dict[str, str] = {"PORT": str(service["port"])}
    name = str(service["name"])

    if service["type"] == "db":
        db = service.get("database")
        if db == "sqlite":
            env["DB_PATH"] = "./service.db"
        elif db == "maria":
            env["DB_HOST"] = "mariadb"
            env["DB_PORT"] = "3306"
            env["DB_USER"] = "${DB_USER:-service_user}"
            env["DB_PASSWORD"] = "${DB_PASSWORD:-change_me}"
            env["DB_NAME"] = "${DB_NAME:-service_db}"
        elif db == "postgres":
            env["DB_HOST"] = "postgres"
            env["DB_PORT"] = "5432"
            env["DB_USER"] = "${DB_USER:-service_user}"
            env["DB_PASSWORD"] = "${DB_PASSWORD:-change_me}"
            env["DB_NAME"] = "${DB_NAME:-service_db}"

    if service["type"] == "worker" or "workers" in service.get("features", []):
        broker = service.get("broker", "redis")
        if broker == "redis":
            env["CELERY_BROKER_URL"] = "redis://redis:6379/0"
            env["CELERY_RESULT_BACKEND"] = "redis://redis:6379/1"
        else:
            env["CELERY_BROKER_URL"] = (
                "amqp://${RABBITMQ_USER:-service_rabbit}:${RABBITMQ_PASSWORD:-change_me}@rabbitmq:5672//"
            )
            env["CELERY_RESULT_BACKEND"] = "rpc://"

    for target in service.get("delegates", []):
        target_service = next((s for s in services if s["name"] == target), None)
        if target_service is not None:
            key = f"{target.upper().replace('-', '_')}_URL"
            env[key] = f"http://{target}:{target_service['port']}"

    auth_service = next((s for s in services if s.get("role") == "auth"), None)
    if auth_service and name != auth_service["name"]:
        env["AUTH_SERVICE_URL"] = f"http://{auth_service['name']}:{auth_service['port']}"

    return env


def render_compose(spec: ClusterSpec) -> dict[str, Any]:
    services = spec["services"]
    infra = _infer_infra(services)
    compose: dict[str, Any] = {"services": {}}

    for service in services:
        name = str(service["name"])
        requires = {
            dep
            for dep in service.get("requires", [])
            if dep in INFRA_NAMES or any(s["name"] == dep for s in services)
        }

        # Auto-wire required infra based on selected DB/broker/features.
        if service["type"] == "db":
            database = service.get("database")
            if database == "postgres":
                requires.add("postgres")
            elif database == "maria":
                requires.add("mariadb")

        if service["type"] == "worker":
            requires.add("redis" if service.get("broker", "redis") == "redis" else "rabbitmq")

        if "workers" in service.get("features", []):
            requires.add("redis" if service.get("broker", "redis") == "redis" else "rabbitmq")

        if "caching" in service.get("features", []):
            requires.add("redis")

        depends_on: dict[str, dict[str, str]] = {}
        for dep in sorted(requires):
            condition = "service_started"
            if dep in {"postgres", "mariadb", "redis", "rabbitmq"}:
                condition = "service_healthy"
            depends_on[dep] = {"condition": condition}

        app_service: dict[str, Any] = {
            "image": f"ghcr.io/csrd-api/{name}:latest",
            "build": {
                "context": ".",
                "dockerfile": f"Dockerfile.{name}",
            },
            "ports": [f"{service['port']}:{service['port']}"],
            "environment": _service_environment(service, services),
        }
        if depends_on:
            app_service["depends_on"] = depends_on
        compose["services"][name] = app_service

    if "postgres" in infra:
        compose["services"]["postgres"] = {
            "image": "postgres:16",
            "environment": {
                "POSTGRES_DB": "${DB_NAME:-service_db}",
                "POSTGRES_USER": "${DB_USER:-service_user}",
                "POSTGRES_PASSWORD": "${DB_PASSWORD:-change_me}",
            },
            "ports": ["5432:5432"],
            "healthcheck": {
                "test": ["CMD-SHELL", "pg_isready -U ${DB_USER:-service_user}"],
                "interval": "10s",
                "timeout": "5s",
                "retries": 5,
            },
        }

    if "mariadb" in infra:
        compose["services"]["mariadb"] = {
            "image": "mariadb:11",
            "environment": {
                "MYSQL_ROOT_PASSWORD": "${MYSQL_ROOT_PASSWORD:-change_me_root}",
                "MYSQL_DATABASE": "${DB_NAME:-service_db}",
                "MYSQL_USER": "${DB_USER:-service_user}",
                "MYSQL_PASSWORD": "${DB_PASSWORD:-change_me}",
            },
            "ports": ["3306:3306"],
            "healthcheck": {
                "test": ["CMD", "mysqladmin", "ping", "-h", "localhost"],
                "interval": "10s",
                "timeout": "5s",
                "retries": 5,
            },
        }

    if "redis" in infra:
        compose["services"]["redis"] = {
            "image": "redis:7",
            "ports": ["6379:6379"],
            "healthcheck": {
                "test": ["CMD", "redis-cli", "ping"],
                "interval": "10s",
                "timeout": "5s",
                "retries": 5,
            },
        }

    if "rabbitmq" in infra:
        compose["services"]["rabbitmq"] = {
            "image": "rabbitmq:3-management",
            "environment": {
                "RABBITMQ_DEFAULT_USER": "${RABBITMQ_USER:-service_rabbit}",
                "RABBITMQ_DEFAULT_PASS": "${RABBITMQ_PASSWORD:-change_me}",
            },
            "ports": ["5672:5672", "15672:15672"],
            "healthcheck": {
                "test": ["CMD", "rabbitmq-diagnostics", "-q", "ping"],
                "interval": "10s",
                "timeout": "5s",
                "retries": 5,
            },
        }

    return compose


def _build_env(spec: ClusterSpec) -> str:
    lines = [
        "# Cluster-level environment",
        f"CLUSTER_NAME={spec['cluster']['name']}",
        "DB_USER=service_user",
        "DB_PASSWORD=change_me",
        "DB_NAME=service_db",
        "MYSQL_ROOT_PASSWORD=change_me_root",
        "RABBITMQ_USER=service_rabbit",
        "RABBITMQ_PASSWORD=change_me",
        "",
        "# Service URLs",
    ]
    for service in spec["services"]:
        key = f"{service['name'].upper().replace('-', '_')}_URL"
        lines.append(f"{key}=http://localhost:{service['port']}")
    return "\n".join(lines).strip() + "\n"


def _build_readme(spec: ClusterSpec) -> str:
    lines = [
        f"# {spec['cluster']['name']}",
        "",
        "Generated cluster scaffold.",
        "",
        "## Services",
    ]
    for service in spec["services"]:
        lines.append(f"- `{service['name']}` ({service['type']}) on port `{service['port']}`")
    lines.extend(
        [
            "",
            "## Tests",
            "",
            "From the workspace root, run all tests:",
            "",
            "```bash",
            "uv run pytest",
            "```",
            "",
            "Run tests for a specific service:",
            "",
            "```bash",
            "uv run pytest tests/unit/{service_name}",
            "uv run pytest tests/acceptance/{service_name}",
            "```",
            "",
            "## Run",
            "",
            "```bash",
            "docker compose up -d",
            "./smoke.sh",
            "```",
        ]
    )
    return "\n".join(lines) + "\n"


def _build_smoke(spec: ClusterSpec) -> str:
    lines = [
        "#!/usr/bin/env bash",
        "set -euo pipefail",
        "",
        'echo "Running cluster smoke checks..."',
    ]
    for service in spec["services"]:
        lines.extend(
            [
                f'echo "- {service["name"]}"',
                f'curl -fsS "http://localhost:{service["port"]}/health" >/dev/null || true',
            ]
        )
    lines.append('echo "Smoke checks complete."')
    return "\n".join(lines) + "\n"


def generate_cluster(spec: ClusterSpec, output_dir: Path, force: bool = False) -> Path:
    """Generate cluster scaffold in workspace mode.

    Always operates at workspace root (no standalone mode).
    """
    normalized = normalize_cluster_spec(spec)
    cluster_root = output_dir.resolve()
    cluster_root.mkdir(parents=True, exist_ok=True)

    # In workspace mode, check if we'd overwrite existing cluster artifacts
    compose_file = cluster_root / "docker-compose.yml"
    if compose_file.exists() and not force:
        raise FileExistsError(
            f"Cluster files already exist in {cluster_root}. Use --force to overwrite."
        )

    compose = render_compose(normalized)
    (cluster_root / "docker-compose.yml").write_text(
        yaml.safe_dump(compose, sort_keys=False), encoding="utf-8"
    )
    (cluster_root / ".env.example").write_text(_build_env(normalized), encoding="utf-8")

    # In workspace mode, preserve existing README (workspace-level, not cluster-specific)
    readme_path = cluster_root / "README.md"
    if not readme_path.exists():
        readme_path.write_text(_build_readme(normalized), encoding="utf-8")

    smoke_path = cluster_root / "smoke.sh"
    smoke_path.write_text(_build_smoke(normalized), encoding="utf-8")
    smoke_path.chmod(0o755)

    return cluster_root
