# Contributing to SENTRA

Thank you for your interest in contributing to SENTRA! This document explains how to get started.

## Getting Started

### Prerequisites

- Python 3.10+
- Git

### Development Setup

```bash
# Clone the repository
git clone https://github.com/maxgerhardson/sentra.git
cd sentra

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate      # Linux/macOS
.venv\Scripts\activate         # Windows

# Install with dev dependencies
pip install -e ".[all]"

# Verify the installation
sentra --help
pytest --ignore=tests/test_server.py --no-cov
```

### Quick Validation

```bash
sentra validate-config          # Check .guard.yaml
pytest --ignore=tests/test_server.py --no-cov  # Run tests
sentra scan                     # Full scan with reports
```

## Architecture Overview

```
src/guard/
  cli.py              # Typer CLI — all commands (both `sentra` and `guard` aliases)
  config.py            # GuardConfig (Pydantic) — YAML + env var loading
  server.py            # FastAPI REST API + management dashboard
  core/
    pipeline.py        # Orchestrates: scan → gate → artifacts
    models.py          # Pydantic models (Finding, Evidence, Severity, etc.)
    licensing.py       # HMAC license key generation and validation
    governance.py      # Governance profiles (strict/standard/permissive)
    reconciler.py      # Work item reconciliation engine
    approvals.py       # Async approval gates (enterprise)
  vault/               # Token vault for secure credential storage
  authz/               # RBAC authorization (roles, permissions, policy engine)
  providers/
    factory.py         # Builds providers from config (devops, standards, scanner, llm)
    *_base.py          # Abstract interfaces (DevOps, Standards, Scanner, LLM)
    *_stub.py          # Local/test implementations
    *_azure.py         # Azure DevOps integrations
    *_github.py        # GitHub integrations
    *_jira.py          # Jira integrations
  reporters/
    factory.py         # Builds reporters (html, junit, sarif, csv)
  rules/
    engine.py          # RulesEngine — evaluates all rule types
    rule_schema.py     # RuleDefinition model
    builtins.py        # Built-in rules
    ast_checks.py      # Python AST semantic analysis
  packs/
    registry.py        # Pack discovery and loading
    fda_iec_62304/     # IEC 62304 standards pack (14 rules)
    owasp_top_10/      # OWASP Top 10 pack (22 rules)
    soc2/              # SOC2 pack (16 rules)
tests/                 # ~1500 tests
docs/                  # Documentation (MkDocs site)
```

### Key Design Patterns

- **Provider factory** — All backends (DevOps, Standards, Scanner, LLM) are swappable via `.guard.yaml` config. Each has a base class, a stub (local/test), and production implementations.
- **Pydantic everywhere** — Configuration, findings, work items, and metadata all use Pydantic `BaseModel` for validation and serialization.
- **Standards packs** — Pre-built regulatory rule sets discovered via `importlib.resources`. Each pack is a Python sub-package with a `pack.yaml`.
- **Rule types** — `regex`, `required_pattern`, `file_policy`, `ast`, `documentation_obligation`.
- **Open-core model** — Free tier has unlimited core features. Enterprise features (parallel scan, vault, approvals, audit, SSO) are license-gated.

### Data Flow

```
CLI command → load config → build providers → run_scan()
  → RulesEngine.evaluate() (rules + packs)
  → Scanner.scan() (external tools)
  → link work items (traceability)
  → evaluate_gate() (pass/fail)
  → write_artifacts() (findings.json, reports, next_actions.md)
```

## Testing

### Running Tests

```bash
# Full test suite (excluding server tests that may hang on full-file runs)
pytest --ignore=tests/test_server.py --no-cov

# With coverage
pytest --ignore=tests/test_server.py

# Specific test file
pytest tests/test_rules_engine.py --no-cov

# Specific test class
pytest tests/test_rules_engine.py::TestRegexEvaluation

# Server tests by class name (avoids hang)
pytest tests/test_server.py -k "TestAuthentication or TestConfigEndpoint" --no-cov
```

### Test Conventions

- Tests live in `tests/` and mirror the source structure.
- Use `tests/helpers.py` for shared factories: `make_finding()`, `write_file()`, `FakeScanner`, `FakeDevOps`, `FakeStandards`.
- Use `conftest.py` fixtures: `finding_factory`, `file_writer`, `guard_config`.
- Test class names: `TestFeatureName` (e.g., `TestRegexEvaluation`, `TestEvaluateGate`).
- Test method names: `test_descriptive_name` (e.g., `test_todo_comment_produces_finding`).
- Use `tmp_path` fixture for file system tests — never write to the real repo.
- Mock external APIs (Azure DevOps, GitHub, Jira) — never make real network calls.

### Coverage

- Coverage threshold is 80% (configured in `pyproject.toml`).
- Coverage report is generated at `out/htmlcov/index.html`.

## Adding Features

### Adding a New Rule Type

1. Add the type name to `RuleDefinition.type` comment in `src/guard/rules/rule_schema.py`.
2. Add a handler branch in `RulesEngine.evaluate()` in `src/guard/rules/engine.py`.
3. Create an `_evaluate_<type>()` function that returns `list[Finding]`.
4. Add tests in `tests/test_rules_engine.py`.

### Adding a New Standards Pack

1. Create `src/guard/packs/<pack_name>/__init__.py`.
2. Create `src/guard/packs/<pack_name>/pack.yaml` with `name`, `description`, and `rules` list.
3. Register the pack in `_BUILTIN_PACKS` dict in `src/guard/packs/registry.py`.
4. Add tests in `tests/test_packs.py`.
5. See the [Pack Authoring Guide](docs/PACK_AUTHORING_GUIDE.md) for details.

### Adding a New CLI Command

1. Add the command function with `@app.command()` in `src/guard/cli.py`.
2. Add a smoke test in `tests/test_smoke.py`.
3. Document the command in `CLAUDE.md`.

### Adding a New Provider

1. Create `src/guard/providers/<name>_<type>.py` implementing the appropriate base class.
2. Add a factory branch in `src/guard/providers/factory.py`.
3. Add the provider name to the valid set in `src/guard/config.py`.
4. Add tests (mock external APIs).

## Code Style

- Python 3.10+ features are welcome (type hints, union types).
- Use `from __future__ import annotations` in all modules.
- Prefer Pydantic `BaseModel` for data classes.
- Keep modules focused — one concern per file.
- Use `logging` instead of `print()` for output.

## Commit Messages

Follow this format:

```
<action> <what was changed>

<optional body explaining why>
```

Examples:
- `Add GitHub provider for work item tracking`
- `Fix regex pattern escaping in standards YAML`
- `Update coverage threshold to 85%`

## License

SENTRA is proprietary software. By contributing, you agree that your contributions will be licensed under the same terms as the project.
