# AI SDLC Guard — Weekly Status Report

**Week of:** [DATE]
**Phase:** [CURRENT PHASE]
**Overall Status:** On Track / At Risk / Blocked

---

## Summary

[1-2 sentence summary of the week's progress and focus.]

---

## Completed This Week

- [Task ID] -- [Brief description of what was done]
- [Task ID] -- [Brief description]

---

## In Progress

- [Task ID] -- [What's being worked on, expected completion]

---

## Blocked / At Risk

- [Task ID] -- [What's blocking progress and what's needed to unblock]

*(If nothing is blocked, write "No blockers this week.")*

---

## Key Metrics

| Metric | Value |
|--------|-------|
| Tasks completed (cumulative) | [X] / 28 |
| Tasks remaining | [X] |
| Current phase progress | [X]% |
| Test suite status | Passing / Failing |
| Test coverage | [X]% (80% threshold) |
| Source LOC | ~4,724 |
| Test LOC | ~8,045 |
| Open blockers | [X] |

---

## Decisions Made

- [Any architectural decisions, priority changes, or scope adjustments made this week.]

*(If none, write "No significant decisions this week.")*

---

## Next Week's Focus

- [Top priority task or goal for the coming week]
- [Secondary goal]

---

## Notes / Reflections

[Optional: anything learned, process improvements to consider, or general observations.]
