# AI SDLC Guard — Demo Guide

**Product:** AI SDLC Guard v1.0.1
**Image:** `ghcr.io/maxgerhardson/ai-sdlc-guard:1.0.1`
**Demo project:** MedFiles — a medical records app (IEC 62304 regulated)
**License:** Enterprise (all features unlocked)
**Azure DevOps org:** `mgerhardson1` / project `MedFiles`

---

## Prerequisites

| Requirement | How to verify |
|---|---|
| Docker Desktop running | `docker info` shows no errors |
| Azure DevOps PAT with Work Items (Read & Write) scope | Generate at https://dev.azure.com/mgerhardson1/_usersSettings/tokens |
| Port 8000 available | `curl http://localhost:8000` should fail before starting |

---

## Setup (one-time, ~2 minutes)

### 1. Pull the image

```bash
docker pull ghcr.io/maxgerhardson/ai-sdlc-guard:1.0.1
```

> If the image is private, log in first:
> ```bash
> echo "YOUR_GITHUB_PAT" | docker login ghcr.io -u maxgerhardson --password-stdin
> ```

### 2. Initialize the demo project

```bash
mkdir -p ~/medfiles && cd ~/medfiles
```

Run the setup wizard:

```bash
docker run --rm -it -v "$(pwd):/app" -w /app \
  ghcr.io/maxgerhardson/ai-sdlc-guard:1.0.1 init
```

Choose:
- **DevOps provider:** Azure DevOps
- **Org:** `mgerhardson1`
- **Project:** `MedFiles`
- **Team:** `MedFiles Team`
- **Iteration:** `MedFiles\Sprint 1`
- **Standards:** IEC 62304 (medical device)
- **Governance:** Standard
- **Reporters:** HTML

> The wizard creates `.guard.yaml` with all settings. The license key is already embedded.

### 3. Start the server

```bash
docker run -d --name guard-api -p 8000:8000 \
  -v "$(pwd):/app" -w /app \
  -e AZURE_DEVOPS_PAT="YOUR_PAT_HERE" \
  ghcr.io/maxgerhardson/ai-sdlc-guard:1.0.1
```

Verify: open **http://localhost:8000/dashboard** in a browser.

---

## Scenario 1: First Scan and Work Item Discovery

**Story:** Show Guard scanning a codebase, finding issues, and connecting to Azure DevOps work items.

### Step 1 — Open the dashboard

Go to **http://localhost:8000/dashboard**. The Overview tab shows "Run guard scan to see metrics."

### Step 2 — Build context (fetch work items)

Click **Run Context**. Guard connects to Azure DevOps and fetches all Sprint 1 work items.

The status bar shows: **DONE — 8 work items** (the sprint requirements: User Authentication, Patient Profile, Blood Pressure Tracking, etc.)

> **What this does:** Generates `agent_context.json` — the file an AI coding agent reads before starting work. It contains active work items, standards rules, and governance policies.

### Step 3 — Run a scan

Click **Run Scan**. Guard evaluates the MedFiles codebase against IEC 62304 and OWASP Top 10 rules.

Result: **116 findings** — the status badge shows **PASSED** (no critical/high findings — only medium and info).

### Step 4 — Explore findings

Click the **Rules** tab. You can search and filter by severity, rule ID, or pack:

| Rule | Count | Severity | What it flags |
|---|---|---|---|
| IEC62304-CODE-001 | 101 | medium | `assert` statements in test files — production code should use explicit error handling |
| IEC62304-5.1.1 | 1 | info | Documentation obligation: Software Development Plan required |
| OWASP-A04-001 | 1 | info | Documentation obligation: Threat model required |

> **Key point:** The 101 medium findings are in test files (`tests/test_*.py`). In a real project you'd scope the scan to exclude tests or add a rule override. The info findings are documentation obligations — they don't fail the gate, they just track compliance gaps.

### Step 5 — Run the gate

Click **Run Gate**. Result: **PASSED** — the gate only fails on `critical` and `high` severities. All 116 findings are medium or info.

> **Key point:** The gate is configurable. In `.guard.yaml`, `gate_fail_on: [critical, high]` controls which severities block merges.

---

## Scenario 2: Work Items and Traceability

**Story:** Show how Guard links scan findings to Azure DevOps work items.

### Step 1 — View work items

Click the **Work Items** tab. You see 17 items from Azure DevOps:

- **Items 27–34:** The 8 Sprint 1 requirements (User Auth, Patient Profile, etc.) — `findings: 0` because these are feature requirements, not rule violations
- **Items 35–43:** Reconcile-created items tied to scan rules — each shows the linked finding count

Click the **Detail** button on item 35 (`[IEC62304-CODE-001] no-assert-in-production`). The modal shows:
- **Rule:** IEC62304-CODE-001
- **DevOps ID:** 35 (the actual Azure DevOps work item ID)
- **Linked findings:** 101
- **Description:** Affected files, remediation guidance
- **Acceptance criteria:** "No IEC62304-CODE-001 findings in guard scan"

### Step 2 — Check reconcile status

Click **Sync to DevOps**. The reconcile preview modal shows:

- **8 update** actions — these items need their descriptions synced with the latest scan data
- **0 create / 0 close** — all rules already have matching work items

> **What's happening:** Guard compares scan findings against Azure DevOps. For each rule with findings, it checks if a work item exists (by matching the `[RULE-ID]` prefix in the title). If the description has drifted, it proposes an update.

### Step 3 — Execute reconcile

Click **Execute Reconcile** in the preview modal.

Result: **0 created, 8 updated, 0 closed**. Click **Done** and the work items refresh.

---

## Scenario 3: Governance and Audit Trail

**Story:** Show the governance engine and audit trail.

### Step 1 — Review governance policies

Click the **Policies** tab. The current profile is **Standard**:

| Policy | Setting | Meaning |
|---|---|---|
| Human review on requirement change | On | Reconcile actions require a PR |
| Human review on critical finding | On | Critical findings require human sign-off |
| Auto-patch | Enabled, max severity: low | Agent can auto-fix low-severity findings |
| Gate fail on | critical, high | Only these severities block merges |
| Auto-close work items | On | When findings are resolved, close the matching WI |

> **Try it:** Switch the profile to **Strict** — all gates tighten. Switch to **Permissive** — maximum agent autonomy. Switch back to **Standard** for the demo.

### Step 2 — Check the audit log

Click the **Audit Log** tab. You see the reconcile entry:

- **Action:** reconcile
- **Result:** success (green badge)

Click the entry to expand it. The **Details** section shows:
- **Summary:** "0 created, 8 updated, 0 closed"
- **Updated items:** Each with ID, rule_id, and title (e.g., `36 — [IEC62304-5.1.1] software-development-plan`)

The **Policy Decision** section shows:
- **Action:** requirement_change
- **Allowed:** true
- **Reason:** "Work items were created/updated. Governance requires a human-reviewed PR before merging. Submit a pull request and assign a reviewer."

> **Key point:** The governance engine doesn't block reconcile — it allows it but flags that a human must review the changes via a PR. This is the audit trail that regulated teams need for compliance.

### Step 3 — Explain the agent workflow

Walk through the intended flow:

1. **Agent reads context** → `guard context` (or "Run Context" button) fetches work items and rules
2. **Agent writes code** → implements features based on work items
3. **Agent runs gate** → `guard gate` checks the code against all rules
4. **If gate fails** → agent reads `findings.json`, fixes issues, re-runs gate
5. **Gate passes** → agent runs `guard reconcile` to sync findings with DevOps
6. **Governance says: submit a PR** → agent creates a pull request for human review
7. **Human reviews and merges** → audit trail records the full chain of decisions

---

## Scenario 4: Standards Packs

**Story:** Show how to add/remove regulatory standards.

### Step 1 — View packs

Click the **Packs** tab. Three packs are shown:

| Pack | Rules | Status |
|---|---|---|
| FDA IEC 62304 | 14 rules | Enabled |
| OWASP Top 10 | 22 rules | Enabled |
| SOC2 | 16 rules | Disabled |

### Step 2 — Enable SOC2

Toggle SOC2 **on**. A toast confirms it's enabled.

### Step 3 — Re-scan

Go back to **Overview** and click **Run Scan**. The finding count increases — SOC2 rules add new documentation obligations and security checks.

### Step 4 — Disable SOC2

Go back to **Packs** and toggle SOC2 **off**. Re-scan to return to the baseline.

> **Key point:** Packs are additive. Teams pick the regulatory frameworks that apply to their product and Guard enforces them all in a single scan.

---

## Scenario 5: Configuration and Settings

**Story:** Show the full configuration.

### Step 1 — View settings

Click the **Settings** tab. The full `.guard.yaml` is displayed as JSON.

### Step 2 — Highlight key fields

- `devops_provider: azure` — connected to Azure DevOps
- `license_key: GUARD-ENTERPRISE-...` — Enterprise tier, all features unlocked
- `governance.profile: standard` — balanced governance
- `standards_packs: [fda-iec-62304, owasp-top-10]` — active regulatory frameworks
- `gate_fail_on: [critical, high]` — what blocks merges

### Step 3 — Show the license

Click the dashboard header or call the API:

```
GET http://localhost:8000/api/license
```

Response: `Enterprise license valid until 2027-12-31` with all 10 features listed.

---

## Scenario 6: DevOps Integration

**Story:** Show the DevOps connection configuration.

### Step 1 — Open the DevOps tab

Click the **DevOps** tab. The connection form shows:

- **Platform:** Azure DevOps
- **Org:** mgerhardson1
- **Project:** MedFiles
- **Team:** MedFiles Team

The header shows a green indicator: **azure connected**.

### Step 2 — Test connection

Click **Test Connection**. The result shows: **Connected — azure** (green checkmark).

### Step 3 — Show env var security model

Point out: the PAT is **not stored in config**. It's passed via the `AZURE_DEVOPS_PAT` environment variable. The DevOps tab shows which env vars are set (true/false) but never displays the actual secrets.

> **Key point:** Secrets stay in the environment (CI variables, Docker env, etc.) and are never written to `.guard.yaml` or any file.

---

## Cleanup

```bash
docker stop guard-api && docker rm guard-api
```

To reset for a fresh demo:

```bash
rm -rf ~/medfiles/out
```

To do a full reset (re-run setup wizard):

```bash
rm ~/medfiles/.guard.yaml
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Dashboard won't load | Check `docker ps` — container should be running and healthy |
| "Internal Server Error" on work items | PAT expired. Generate a new one and restart container with new `-e AZURE_DEVOPS_PAT=...` |
| Scan shows 0 findings | Make sure the medfiles app code is in the mounted volume |
| Gate fails unexpectedly | Check `gate_fail_on` in Settings tab — default is `[critical, high]` |
| Reconcile says "no findings" | Run a scan first — reconcile reads from the last scan output |
| Audit log is empty | Audit logging requires Enterprise license. Check Settings for `license_key` |

---

## API Quick Reference

All endpoints are available at `http://localhost:8000`. No API key is needed for the demo.

| Action | Method | Endpoint |
|---|---|---|
| Health check | GET | `/health` |
| Dashboard | GET | `/dashboard` |
| Run scan | POST | `/api/run-scan` |
| Run gate | POST | `/api/run-gate` |
| Build context | POST | `/api/run-context` |
| Get findings | GET | `/api/findings` |
| Get work items | GET | `/api/work-items` |
| Reconcile (preview) | POST | `/api/reconcile?dry_run=true` |
| Reconcile (execute) | POST | `/api/reconcile?dry_run=false` |
| Governance config | GET | `/api/governance` |
| Audit log | GET | `/api/audit` |
| License status | GET | `/api/license` |
| Packs list | GET | `/api/packs` |
| Full config | GET | `/api/config` |
