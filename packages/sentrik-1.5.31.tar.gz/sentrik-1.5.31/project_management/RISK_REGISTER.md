# AI SDLC Guard — Risk Register

**Last Updated:** 2026-03-01

---

## How to Use This Register

Review risks weekly during your Monday planning session. Update likelihood and impact as conditions change. When a risk materializes, move it to the "Realized Risks" section and document what happened and how it was handled.

**Likelihood:** Low / Medium / High
**Impact:** Low / Medium / High / Critical
**Overall Rating:** Likelihood x Impact (worst case governs)

---

## Active Risks

### R-001: Solo developer bottleneck
**Likelihood:** High | **Impact:** Medium | **Overall:** High

All knowledge, context, and execution capacity sits with one person. The project has grown to ~4,724 source LOC and ~8,045 test LOC — maintaining it solo is increasingly demanding.

**Mitigation:**
- CONTRIBUTING.md already written with architecture overview and extension guides
- Comprehensive test suite (29 modules, 87.51% coverage) means someone else can contribute safely
- Project management docs keep context transferable
- Internal docs and guides enable team members to contribute

---

### R-002: Azure DevOps PAT token expiration
**Likelihood:** Medium | **Impact:** High | **Overall:** High

The `guard sync` command and Azure DevOps providers depend on a Personal Access Token. Expiration breaks CI/CD sync silently.

**Mitigation:**
- Set calendar reminder for PAT renewal (90-day intervals)
- Post-merge sync step in azure-pipelines.yml handles PAT via pipeline secrets
- GitHub provider offers an alternative path if Azure becomes problematic

---

### R-003: Breaking changes in external APIs
**Likelihood:** Medium | **Impact:** Medium | **Overall:** Medium

Azure DevOps, GitHub, and Anthropic APIs could introduce breaking changes. Now with 3 external API integrations, the surface area has grown.

**Mitigation:**
- Pin dependency versions in pyproject.toml
- Provider abstraction keeps swap cost low
- 29 test modules catch breakages early
- External API providers are omitted from coverage (tested via mocks)

---

### R-004: Test coverage regression
**Likelihood:** Medium | **Impact:** Medium | **Overall:** Medium

Coverage dropped from 90.18% to 87.51% as new modules were added. The 80% threshold is enforced but the gap is narrowing.

**Mitigation:**
- Phase 20 includes a task to raise coverage back above 90%
- New modules (server, AST checks, GitHub providers) all have dedicated test files
- Coverage reporting runs in CI on every PR

---

### R-005: REST API security exposure
**Likelihood:** Low | **Impact:** High | **Overall:** Medium

The FastAPI server accepts code for scanning. If deployed without auth, it could be abused for code exfiltration or resource exhaustion.

**Mitigation:**
- API key auth is built in (optional `GUARD_API_KEY` env var)
- Docker deployment (Phase 20) enables network isolation
- Health endpoint is the only unauthenticated route
- Document security best practices in deployment guide

---

### R-006: Standards pack accuracy
**Likelihood:** Medium | **Impact:** Medium | **Overall:** Medium

The FDA IEC 62304 pack contains 14 rules with specific clause references. Regulatory standards evolve, and future packs (OWASP, SOC2) will have the same maintenance challenge.

**Mitigation:**
- Rules tagged with `standard` and `clause` fields for traceability
- Documentation obligations are non-gating (reduces blast radius)
- Pack versioning in metadata
- Phase 21 adds internal documentation with pack maintenance guidance

---

### R-007: LLM scanning inconsistency
**Likelihood:** Medium | **Impact:** Low | **Overall:** Low

The Anthropic LLM provider is non-deterministic. Different runs may produce different findings.

**Mitigation:**
- LLM scanning disabled by default
- Gate decisions rely only on deterministic rules
- LLM findings clearly labeled as AI-suggested

---

### R-008: Docker / deployment complexity
**Likelihood:** Low | **Impact:** Medium | **Overall:** Low

Dockerizing the REST API adds infrastructure complexity. Config files, standards, and pack YAML need to be properly mounted.

**Mitigation:**
- Plan docker-compose.yml with volume mounts for config
- Keep Dockerfile simple (single-stage, pip install)
- Document deployment steps clearly

---

## Retired Risks

| Risk | Reason Retired |
|------|----------------|
| GitHub API rate limiting (was R-005) | GitHub provider shipped in Phase 16 with no rate-limit issues. Authenticated requests provide sufficient headroom. |
| Scope creep in AST rules (was R-004) | AST rules shipped on scope (5 checks) in Phase 17. No scope creep occurred. |
| Test suite becomes slow (was R-006) | 29 test modules run in acceptable time. Not currently a problem. |

---

## Realized Risks

*None yet. When a risk materializes, move it here with a dated entry.*

| Date | Risk ID | What Happened | Response |
|------|---------|---------------|----------|
| -- | -- | -- | -- |
