# AI SDLC Guard — Project Plan

**Owner:** Max Gerhardson
**Version:** 1.0.0
**Last Updated:** 2026-03-02
**Status:** Active Development (Post-Phase 26f)

---

## 1. Project Overview

AI SDLC Guard is a governance runtime that enforces coding standards, architectural constraints, and work-item traceability for teams using AI coding agents. It acts as a quality gate in CI/CD pipelines, providing deterministic-first analysis with auto-remediation capabilities.

The system is built in Python 3.11+ using Typer (CLI), Pydantic (validation), and a pluggable provider architecture supporting Azure DevOps, SARIF scanners, Anthropic LLM integration, and regulatory standards packs.

**Current state:** The platform is v1.0.0 through Phase 26c with ~7,500 lines of source code, 38 test modules (~14,000 LOC), 96%+ test coverage, a REST API (FastAPI) with 20+ endpoints and web dashboard, Docker containerization with OCI labels, GitHub + Azure DevOps + Jira tri-platform support, AST-based rule evaluation, custom rule extensibility, ML severity estimation, parallel scanning, scan metrics, VS Code extension, 3 standards packs (FDA IEC 62304, OWASP Top 10, SOC2), proprietary EULA with tier-based license enforcement, build automation scripts, and a GitHub Actions release workflow. All original work items are closed.

---

## 2. Goals & Success Criteria

### Achieved (Phases 1–19)
- ~~Close remaining active work items~~ — All 4 WIs closed (Phase 15)
- ~~Harden CI/CD pipeline~~ — Azure Pipelines + GitHub Actions both working (Phase 15-16)
- ~~End-to-end workflow: commit → scan → gate → sync~~ — Fully operational (Phase 15)
- ~~Additional DevOps platform~~ — GitHub Issues + Standards providers shipped (Phase 16)
- ~~AST-based rule evaluation~~ — 5 built-in checks shipped (Phase 17)
- ~~REST API server~~ — FastAPI with 5 endpoints + API key auth (Phase 18)
- ~~90%+ test coverage~~ — Peaked at 90.18%, currently 87.51% (Phase 15+)
- ~~PyPI-ready packaging~~ — sdist builds, MIT license, optional extras (Phase 19)

### Achieved (Phase 20–22)
- ~~Dockerize the REST API server for team deployment~~ — Dockerfile + docker-compose (Phase 20)
- ~~Raise test coverage back above 90% and stabilize~~ — 96%+ coverage (Phase 20)
- ~~Add additional standards packs~~ — OWASP Top 10 (22 rules) + SOC2 (16 rules) shipped (Phase 21)
- ~~Create internal documentation~~ — User guide + API reference (Phase 21)
- ~~Support custom rule DSL for organization-specific policies~~ — Declarative extensibility with 5 file policy checks, required_pattern, parameterized AST, composite regex (Phase 22)

### Achieved (Phase 23)
- ~~Jira integration as third DevOps provider~~ — DevOpsJira + StandardsJira + Jira sync (Phase 23)

### Achieved (Phase 24)
- ~~ML-based severity estimation for findings~~ — Feature-based heuristic model with weighted scoring (Phase 24)
- ~~VS Code extension for in-editor scanning~~ — Scan-on-save, diagnostics, commands (Phase 24)
- ~~Pack authoring guide~~ — Comprehensive guide for creating custom standards packs (Phase 24)

### Achieved (Phase 25)
- ~~Performance optimization with parallel scanning~~ — ThreadPoolExecutor-based parallel file evaluation (Phase 25)
- ~~Scan metrics collection~~ — Timing, cache stats, finding counts written to scan_metrics.json (Phase 25)
- ~~Web dashboard~~ — Interactive HTML dashboard at /dashboard with metrics API (Phase 25)
- ~~Performance benchmarks~~ — Synthetic repo benchmarks for parallel vs sequential scanning (Phase 25)

### Achieved (Phase 26c — Proprietary Distribution)
- ~~Proprietary EULA replacing MIT license~~ — LICENSE_PROPRIETARY.txt + LicenseRef-Proprietary in pyproject.toml (Phase 26c)
- ~~License enforcement at runtime~~ — LicenseError, require_license, enforce_license decorator, tier-gated CLI/API/pipeline (Phase 26c)
- ~~`guard install-check` command~~ — Customer onboarding: version, platform, license tier, config, optional deps (Phase 26c)
- ~~`python -m guard` support~~ — `__main__.py` entry point for PyInstaller and Docker (Phase 26c)
- ~~Build automation~~ — build-binary.sh/ps1 scripts, updated guard.spec with __main__ hidden import (Phase 26c)
- ~~GitHub Actions release workflow~~ — Docker + binary (Linux/macOS/Windows) + VSIX release on tag push (Phase 26c)
- ~~Dockerfile hardening~~ — OCI labels (source, licenses), GUARD_LICENSE_KEY env var placeholder (Phase 26c)
- ~~License middleware for API~~ — /api/governance and /api/audit gated behind ENTERPRISE tier (Phase 26c)
- ~~ML license enforcement~~ — ML severity estimation gated behind ORG+ tier in pipeline (Phase 26c)

### Achieved (Phase 26d — GitHub/Jira Write Operations + PR Decoration)
- ~~GitHub Issues write operations~~ — create_work_item, update_work_item, close_work_item via GitHub REST API (Phase 26d)
- ~~Jira Issues write operations~~ — create_work_item, update_work_item, close_work_item with transition support (Phase 26d)
- ~~Widened devops_id type~~ — `int | str` to support Jira string keys (PROJ-42) alongside numeric IDs (Phase 26d)
- ~~PR decoration module~~ — format_findings_comment, GitHubPRDecorator, auto-detect PR number from GitHub Actions (Phase 26d)
- ~~`--decorate-pr` and `--pr-number` CLI flags~~ — gate command posts findings summary as PR comment (Phase 26d)
- ~~GitHub Actions workflow updated~~ — PR gate step includes `--decorate-pr` with GITHUB_TOKEN and repo env vars (Phase 26d)

### Achieved (Phase 26d — Custom Standards Packs)
- ~~`pack_overrides` config field~~ — per-rule overrides (disable, change severity/pattern) without forking packs (Phase 26d)
- ~~Dynamic custom pack discovery~~ — `.guard/packs/` directory scanning for user-defined packs with `pack.yaml` (Phase 26d)
- ~~Pack validation~~ — schema validation for pack YAML (name, rules, types, regex compilation, duplicate IDs) (Phase 26d)
- ~~Pack import/export~~ — CLI commands (`import-pack`, `export-pack`) and API endpoints for portable pack sharing (Phase 26d)
- ~~Pack delete API~~ — `DELETE /api/packs/{pack_id}` removes custom packs, protects built-ins (Phase 26d)
- ~~Factory override wiring~~ — `build_providers()` passes `pack_overrides` through to rule loading (Phase 26d)
- ~~Dashboard Packs UI~~ — rule editor modal with severity/pattern overrides, create-pack wizard, import/export buttons, delete for custom packs (Phase 26d)
- ~~Pack rules API~~ — `GET /api/packs/{pack_id}/rules` returns rules with current overrides applied (Phase 26d)
- ~~37 new tests~~ — TestCustomPackDiscovery, TestPackOverrides, TestPackValidation, TestPackImportExport, TestConfigValidation, TestPackRulesEndpoint, TestPackRulesStructure (Phase 26d)

### Achieved (Phase 26f — Azure PR Decoration, CI Artifacts, PR Status Checks)
- ~~Azure DevOps PR thread decoration~~ — `AzurePRDecorator` class with Basic auth, auto-detect via `SYSTEM_PULLREQUEST_PULLREQUESTID` (Phase 26f)
- ~~CI artifact publishing~~ — SARIF generation + GitHub Code Scanning upload via `codeql-action/upload-sarif@v3` (Phase 26f)
- ~~PR status checks~~ — `GitHubStatusReporter` (Checks API) + `AzureStatusReporter` (Git Status API) with `--status-check` CLI flag (Phase 26f)
- ~~`azure_devops_repo` config field~~ — `GUARD_AZURE_DEVOPS_REPO` env var for Azure PR threads and commit statuses (Phase 26f)
- ~~`--commit-sha` CLI flag~~ — explicit commit SHA override for status checks (Phase 26f)
- ~~Azure Pipelines PR/push split~~ — `--decorate-pr --status-check` on PR builds, plain gate on push (Phase 26f)
- ~~28 new tests~~ — TestAzurePRDecorator, TestDetectAzurePRId, TestDetectAzureRepo, TestDecoratePRAzure, TestGitHubStatusReporter, TestAzureStatusReporter, TestDetectCommitSha, TestReportStatus (Phase 26f)

### Next (Phase 26 — Governance, UX, Distribution & DevOps Integration)
- Configurable governance policies / agent constraint settings via dashboard UI
- Human-in-the-loop gates (e.g., require human-reviewed PR when requirements change)
- Team-level policy profiles (strict, standard, permissive) with per-repo overrides
- Guided setup wizard (`guard init` interactive experience)
- Dashboard management console (settings, policies, audit log, packs)
- ~~Custom standards packs: customize existing packs, build from scratch, import/export as YAML~~ — Phase 26d (backend + dashboard UI complete)
- Dashboard DevOps connection: guided platform setup, work items viewer, reconcile from UI
- ~~PR decoration: findings summary posted as PR comment, reports as CI artifacts~~ — Phase 26d (GitHub), Phase 26f (Azure + status checks + SARIF upload)
- ~~GitHub/Jira write operations: create, update, close work items (currently Azure-only)~~ — Phase 26d
- ~~Proprietary distribution: Docker images + compiled CLI binaries (no source code to end users)~~ — Phase 26c
- ~~License key system for customer activation~~ — Phase 26c

### Mid-Term (Phase 27)
- Multi-language support beyond Python (JavaScript/TypeScript)
- Pack marketplace for custom/community packs

### Long-Term (Phase 28+)
- SaaS / hosted version with multi-tenant architecture
- Advanced ML models with training data
- JetBrains IDE plugin

---

## 3. Scope & Boundaries

### In Scope (Delivered)
- CLI tool with 15 commands for local and CI/CD scanning
- Rules engine with 5 rule types (regex, required_pattern, file-policy, AST, documentation obligation)
- Provider integrations: Azure DevOps, GitHub, Jira, SARIF, Anthropic LLM
- Standards packs framework with 3 built-in packs (FDA IEC 62304, OWASP Top 10, SOC2)
- Report generation (HTML, JUnit, SARIF) with compliance obligation sections
- Auto-patching for low-severity findings
- Work item traceability, state sync, and CI/CD automation (Azure Pipelines + GitHub Actions)
- Pre-commit hook integration
- REST API server (FastAPI) with 7 endpoints + API key auth + web dashboard
- Docker containerization (multi-stage build, docker-compose)
- ML severity estimation for non-deterministic findings
- Parallel scanning with configurable worker threads
- VS Code extension (scan-on-save, diagnostics, commands)
- Custom rule DSL with parameterized checks and composite regex

### In Scope (Next)
- Configurable governance policies (agent constraint settings, human-in-the-loop gates)
- Guided setup wizard (`guard init` interactive experience)
- Dashboard management console (settings, policies, audit log)
- Custom standards packs (customize existing, build from scratch, import/export YAML)
- Dashboard DevOps integration (connection UI, work items viewer, reconcile from dashboard)
- PR decoration and CI artifact publishing (findings → PR comments, reports → pipeline artifacts)
- GitHub & Jira write operations (create/update/close work items — currently Azure-only)
- Proprietary distribution model (Docker image + compiled CLI binary)
- Multi-language scanning support (JavaScript/TypeScript)

### Out of Scope (for now)
- Open-source publication / PyPI (source code is proprietary)
- JetBrains IDE plugin
- SaaS / hosted version
- Mobile or native desktop application

---

## 4. Architecture Summary

```
┌─────────────────────────────────────────────────────────────────────┐
│                     END-USER TOUCHPOINTS                             │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────────────────┐  │
│  │ CLI Binary    │  │ VS Code Ext.    │  │ Dashboard (Web UI)     │  │
│  │ guard init    │  │ scan-on-save    │  │ Settings / Policies /  │  │
│  │ guard scan    │  │ diagnostics     │  │ Audit Log / Packs      │  │
│  │ guard gate    │  │ commands        │  │ Metrics & Charts       │  │
│  └──────┬───────┘  └───────┬─────────┘  └───────────┬────────────┘  │
└─────────┼──────────────────┼────────────────────────┼───────────────┘
          │                  │                        │
          ▼                  ▼                        ▼
┌─────────────────────────────────────────────────────────────────────┐
│  REST API (FastAPI) — 7+ endpoints                                   │
│  /health  /scan  /gate  /report  /rules  /api/metrics  /dashboard   │
│  + API key auth  + governance policy evaluation                      │
└────────────┬────────────────────────────────────────────────────────┘
             │
   ┌─────────┴──────────────────────────────┐
   │                                        │
┌──▼────────────────────────┐  ┌────────────▼──────────────────────┐
│  Pipeline (orchestration)  │  │  Governance Engine (Phase 26)     │
│  Scan → Trace → Patch → Rpt│  │  Policy profiles (strict/std/perm)│
│  → ML Severity → Metrics   │  │  Human-in-the-loop gates          │
└──────────┬─────────────────┘  │  Agent action audit log            │
           │                    └───────────────────────────────────┘
   ┌───────┼──────────┬──────────────┬────────────┐
   │       │          │              │            │
┌──▼──┐ ┌──▼────┐ ┌───▼─────┐ ┌─────▼──────┐ ┌──▼──────┐
│Rules│ │Scanner│ │DevOps   │ │Standards   │ │Stds     │
│Eng. │ │(SARIF,│ │(Azure,  │ │(YAML,Azure,│ │Packs    │
│regex│ │LLM,  │ │GitHub,  │ │GitHub,     │ │(FDA,    │
│AST  │ │comp) │ │Jira)    │ │Jira)       │ │OWASP,   │
│f.pol│ │      │ │         │ │            │ │SOC2)    │
└─────┘ └───────┘ └─────────┘ └────────────┘ └─────────┘
```

**Distribution model:** End users receive Docker images or compiled CLI binaries — no source code. The VS Code extension connects to the REST API over HTTP. Configuration is managed through the dashboard UI or `.guard.yaml` (generated by the setup wizard). Provider factory pattern enables swapping backends via config. Standards packs are discovered via the pack registry and merged with user rules at scan time.

**DevOps integration model:** The dashboard connects to the end user's DevOps platform (Azure DevOps, GitHub, Jira) to pull work items and push findings back as trackable issues. In CI, Guard posts PR comments with findings summaries and publishes reports as pipeline artifacts. The `.guard.yaml` config file lives in the user's repo, so Guard settings travel with the code.

---

## 5. Completed Work (Phases 1–14)

| Phase | Deliverable | Status |
|-------|-------------|--------|
| 1 | Skeleton + end-to-end CLI with stub providers | Done |
| 2 | Diff support (--git-range, --diff flags) | Done |
| 3 | Rules engine (regex + file-policy) | Done |
| 4 | Traceability (work item extraction) | Done |
| 5 | Patch generation (auto-fix) | Done |
| 6 | Provider factory + LLM scanner | Done |
| 7 | Composite scanner + SARIF import | Done |
| 8 | Reporters (HTML, JUnit, SARIF) | Done |
| 9 | Config validation, caching, CLI introspection | Done |
| 10 | Test hardening + shared fixtures | Done |
| 11 | Azure DevOps team deployment | Done |
| 12 | Azure DevOps work item provider | Done |
| 13 | Azure DevOps standards provider | Done |
| 14 | Anthropic LLM provider + guard sync + expanded rules + standards packs framework + FDA IEC 62304 pack | Done |
| 15 | Stabilization & closure — WI-203/204 closed, pytest-cov, CONTRIBUTING.md, 90%+ coverage | Done |
| 16 | Platform Expansion — GitHub DevOps + Standards providers, GitHub Actions workflow | Done |
| 17 | Advanced Rules — AST-based rule evaluation with 5 built-in checks | Done |
| 18 | REST API Server — FastAPI with /scan, /gate, /report, /rules, /health endpoints + API key auth | Done |
| 19 | Packaging & Distribution — PyPI-ready pyproject.toml, README.md, sdist build | Done |
| 20 | Deployment & Hardening — v1.0.0, Dockerfile, docker-compose, 96%+ coverage | Done |
| 21 | Standards Packs & Documentation — OWASP Top 10, SOC2, user guide, API reference | Done |
| 22 | Custom Rules & Extensibility — file policy registry, required_pattern, parameterized AST, composite regex | Done |
| 23 | Jira Integration — DevOpsJira + StandardsJira providers, Jira sync, config validation | Done |
| 24 | IDE Integration & ML — VS Code extension, ML severity estimation, pack authoring guide | Done |
| 25 | Performance & Dashboard — parallel scanning, scan metrics, web dashboard, benchmarks | Done |

### Key Phase 25 Deliverables (Latest)
- **Parallel file scanning** — `ThreadPoolExecutor`-based concurrent file evaluation within each rule, configurable via `parallel_scan` and `max_workers` config fields
- **Thread-safe cache** — `threading.Lock` protects cache reads/writes during parallel evaluation
- **Scan metrics** — `ScanMetrics` dataclass tracking total duration, rules engine time, scanner time, ML estimator time, files scanned, cache hits/misses, cache hit rate, findings by severity/rule, worker count
- **MetricsCollector** — Context-manager-based collector integrated into `run_scan()` pipeline, writes `out/scan_metrics.json`
- **Web dashboard** — Interactive HTML page at `/dashboard` with severity bar chart, top files table, performance stats
- **Metrics API** — `/api/metrics` JSON endpoint for programmatic access to scan metrics
- **Performance benchmarks** — Synthetic repo tests (100-500 files), parallel vs sequential comparison, cache speedup verification
- **Config wiring** — `parallel_scan`, `max_workers` fields with `GUARD_PARALLEL_SCAN` and `GUARD_MAX_WORKERS` env var overrides
- **37 new tests** — ScanMetrics (7), MetricsCollector (10), parallel scanning (8), benchmarks (4), config (3), dashboard (2), metrics API (2), auth (1)
- **970 tests** — up from 933, all passing

### Key Phase 24 Deliverables
- **ML severity estimation** — Feature-based heuristic model (`src/guard/ml/severity_estimator.py`) with weighted scoring across 6 features (base severity, confidence, code context, pattern risk, file risk, density)
- **SeverityEstimator class** — Post-processes non-deterministic findings, configurable weights, optional re-scoring of deterministic findings
- **Pipeline integration** — `ml_severity_enabled` config field + `GUARD_ML_SEVERITY_ENABLED` env var, wired into `run_scan()` pipeline
- **VS Code extension** — `vscode-extension/` with scan-on-save, diagnostics display, 3 commands (scan, gate, clear), severity-mapped colors
- **Pack authoring guide** — `docs/PACK_AUTHORING_GUIDE.md` with YAML format, directory structure, registration, testing, and distribution
- **53 new tests** — Comprehensive ML severity estimator tests (feature extraction, scoring, calibration, estimator class, edge cases)

### Key Phase 23 Deliverables
- **DevOpsJira provider** — fetches work items from Jira Issues via REST API, JQL query support, issue key and query-based fetching
- **StandardsJira provider** — fetches coding standards YAML from a Jira issue description (supports ```yaml code blocks and raw YAML)
- **Jira sync** — `guard sync` now supports Jira (transition issues via REST API)
- **Config wiring** — `jira_base_url`, `jira_project_key`, `jira_jql`, `jira_standards_issue_key` fields with env var overrides
- **Config validation** — Jira-specific field validation (base URL, project key, issue key)
- **Factory registration** — `devops_provider: jira` and `standards_provider: jira` fully supported
- **Authentication** — supports both API token (JIRA_USER + JIRA_TOKEN for Cloud) and PAT (JIRA_PAT for Data Center/Server)
- **64 new tests** — DevOpsJira (28), StandardsJira (16), config validation (10), factory (2), updated existing (8)
- **880 tests** — up from 816, all passing

### Key Phase 22 Deliverables
- **4 new file policy checks** — `max_lines`, `must_contain_pattern`, `must_not_import`, `max_function_count` with configurable `params`
- **File policy registry** — `FILE_POLICY_CHECKS` dict replacing if/else chain, extensible pattern matching AST_CHECKS
- **`required_pattern` rule type** — inverse of regex, flags files lacking a required pattern
- **Parameterized AST checks** — all 6 checks accept optional `params` dict for configurable thresholds (complexity, nesting depth, function length)
- **`max_function_length` AST check** — new built-in check (BUILTIN-AST-005) with configurable line threshold (default 50)
- **Composite regex** — `all_patterns` field on regex rules requiring ALL patterns to match before flagging
- **RuleDefinition schema** — new `params` and `all_patterns` fields
- **Extension guide** — `docs/EXTENSION_GUIDE.md` with YAML examples for all custom rule capabilities
- **48 new tests** — comprehensive coverage across all new features plus backward compatibility
- **816 tests** — up from 768, all passing

### Key Phase 21 Deliverables
- **OWASP Top 10 pack** — 22 rules (16 regex + 6 documentation obligations) covering all 10 OWASP 2021 categories (A01–A10)
- **SOC2 pack** — 16 rules (7 regex + 9 documentation obligations) covering CC6 (Access), CC7 (Operations), CC8 (Change Mgmt), CC9 (Risk), A1 (Availability), C1 (Confidentiality)
- **Pack registry** — 3 built-in packs registered: `fda-iec-62304`, `owasp-top-10`, `soc2`
- **Internal user guide** — `docs/USER_GUIDE.md` covering installation, config, rule types, packs, CLI, CI/CD, Docker, auto-patching, troubleshooting
- **API reference** — `docs/API_REFERENCE.md` covering all 5 endpoints with request/response examples, auth, errors
- **48 pack tests** — comprehensive content validation for all 3 packs (metadata, standards, clauses, tags, remediation, YAML structure)
- **768 tests** — up from 741, all passing

### Key Phase 20 Deliverables
- **Version bump to 1.0.0** — pyproject.toml, `__init__.py`, server.py all updated
- **Dockerfile** — multi-stage build (builder + runtime), Python 3.12-slim, non-root user, health check
- **docker-compose.yml** — volume mounts for config files, env var passthrough for providers and API key
- **.dockerignore** — excludes tests, docs, .git, .env from build context
- **Test coverage raised to 96.23%** — 37 new CLI command tests covering sync (Azure + GitHub), list-packs, add-pack, remove-pack, serve, gate failure, report output, compare edge cases
- **Coverage threshold raised to 90%** — up from 80%
- **741 tests** — up from 704, all passing

### Key Phase 19 Deliverables
- **Package metadata** — authors, license (MIT), classifiers, keywords in pyproject.toml
- **Optional extras** — `[azure]`, `[server]`, `[anthropic]`, `[sync]`, `[all]` dependency groups
- **README.md** — comprehensive installation guide, feature overview, configuration reference, API docs
- **Build verification** — `python -m build --sdist` produces `ai_sdlc_guard-0.1.0.tar.gz`

### Key Phase 18 Deliverables
- **FastAPI REST API** — `guard serve` command starts HTTP server with 5 endpoints
- **POST /scan** — accepts inline files or repo path, returns findings with severity counts
- **POST /gate** — returns pass/fail gate result with per-severity counts
- **POST /report** — generates HTML/JUnit/SARIF reports from scan
- **GET /rules** — lists all configured rules (builtin + user + pack)
- **GET /health** — health check (always accessible, no auth required)
- **API key auth** — optional `GUARD_API_KEY` env var enables X-API-Key header requirement
- **Inline file scanning** — submit file contents directly in POST body for remote scanning
- **23 API tests** — full endpoint coverage with auth and error handling

### Key Phase 17 Deliverables
- **AST rule type** — new `ast` rule type in the rules engine using Python's `ast` module for semantic analysis
- **5 AST check functions** — `no_mutable_defaults`, `no_star_imports`, `high_complexity`, `no_nested_functions`, `no_global_variables`
- **4 built-in AST rules** — BUILTIN-AST-001 through BUILTIN-AST-004 (mutable defaults, star imports, complexity, nested functions)
- **McCabe complexity calculator** — simplified cyclomatic complexity based on control flow statements
- **AST checks module** — `src/guard/rules/ast_checks.py` with `AST_CHECKS` registry
- **50 new tests** — AST check unit tests (37), rules engine integration tests (13)

### Key Phase 16 Deliverables
- **DevOpsGitHub provider** — fetches work items from GitHub Issues via REST API with state mapping, acceptance criteria parsing
- **StandardsGitHub provider** — fetches coding standards YAML from GitHub repositories via Contents API
- **GitHub sync** — `guard sync` now supports GitHub Issues (close/reopen issues based on local work item state)
- **Factory & config wiring** — `devops_provider: github` and `standards_provider: github` fully supported with env var overrides
- **GitHub Actions workflow** — `.github/workflows/guard-gate.yml` for CI/CD with test, gate, and sync steps
- **Config validation** — GitHub-specific field validation (github_owner, github_repo, github_standards_repo)
- **50 new tests** — DevOpsGitHub (24), StandardsGitHub (9), config validation (9), factory wiring (3), updated existing (5)

### Key Phase 15 Deliverables
- **WI-203 and WI-204 closed** — `guard sync` CLI and post-merge CI sync verified and closed
- **Test coverage reporting** — pytest-cov integrated, 90.18% coverage, 80% threshold enforced
- **Contributor onboarding** — `CONTRIBUTING.md` with architecture overview, testing conventions, and extension guides
- **CI pipeline enhanced** — pytest step with coverage + PublishCodeCoverageResults in azure-pipelines.yml
- **HTML reporter test coverage** — obligations rendering fully tested, html.py at 100%

### Key Phase 14 Deliverables
- **Standards packs framework** — pluggable regulatory rule sets with `list-packs`, `add-pack`, `remove-pack` CLI commands
- **FDA IEC 62304 pack** — 14 compliance rules (4 code-enforceable, 8 documentation obligations, 2 ML/AI-specific)
- **Documentation obligation rule type** — non-code compliance items that appear in reports but never fail the gate
- **Anthropic LLM provider** (`LLMAnthropic`) — Claude-powered code scanning via Messages API
- **`guard sync` command** — pushes work item state to Azure DevOps via REST API
- **Post-merge CI step** — automated work item sync on merge to main
- **5 new standards rules** — STD-005 through STD-009 (eval, wildcard imports, bare except, breakpoints, env access)
- **Enhanced rule schema** — `standard`, `clause`, `compliance_category`, `remediation_guidance`, `tags`, `pack_id` fields
- **HTML report enhancements** — separate "Compliance Obligations" section with remediation guidance

---

## 6. Work Items Status

| ID | Title | State |
|----|-------|-------|
| WI-201 | Anthropic LLM provider for code scanning | Closed |
| WI-202 | Sync work item state to Azure DevOps | Closed |
| WI-203 | Integrate sync as guard CLI command | Closed |
| WI-204 | Post-merge CI pipeline for work item sync | Closed |

All work items are now closed. WI-203 (`guard sync` CLI command) and WI-204 (post-merge CI sync step) were verified and closed in Phase 15.

---

## 7. Upcoming Work

### Phase 26 — Governance Policies & Agent Constraints
**Goal:** Add configurable settings that let teams control how tightly AI agents are governed — from permissive to locked-down — via the dashboard UI and `.guard.yaml`.

**Core Deliverable:** A `governance:` section in `.guard.yaml` with policy profiles, human-in-the-loop gates, auto-patch controls, and an agent action audit log. The dashboard expands from a metrics viewer into a management console.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| Design governance policy schema in `.guard.yaml` | High | 1–2 days |
| Implement policy engine (evaluate policies against events) | High | 3–5 days |
| Human-in-the-loop gate: require human-reviewed PR on requirement changes | High | 2–3 days |
| Human-in-the-loop gate: require human approval when gate fails on critical findings | High | 2–3 days |
| Policy profiles (strict, standard, permissive) with per-repo overrides | Medium | 2–3 days |
| Dashboard settings page for policy configuration | Medium | 3–5 days |
| Dashboard policies page (toggle gates, auto-patch scope, merge blocking) | Medium | 3–5 days |
| Dashboard audit log page (timeline of agent actions) | Medium | 2–3 days |
| Agent action audit log engine (write to `out/agent_audit.jsonl`) | Medium | 2–3 days |
| Policy: restrict auto-patch to specific severity levels or rule types | Medium | 1–2 days |
| Policy: require sign-off before work item state transitions | Low | 1–2 days |
| Policy: block merge when documentation obligations are unresolved | Low | 1–2 days |
| Governance context in `guard context` output (policies available to agents) | Medium | 1 day |
| Tests for policy engine and governance rules | High | 2–3 days |

**Governance Policy Config Schema:**
```yaml
governance:
  profile: standard                    # strict | standard | permissive
  human_review_required:
    on_requirement_change: true        # require human PR when work item updated
    on_critical_finding: true          # require human approval when gate fails critical
    on_auto_patch_above: medium        # human review if auto-patch touches medium+ findings
  auto_patch:
    enabled: true
    max_severity: low                  # only auto-patch low severity
  gate:
    fail_on: [critical, high]
    block_merge_on_obligations: false  # strict mode sets this true
  sync:
    auto_close_work_items: true        # auto-close resolved items on merge
    require_sign_off: false            # strict mode sets this true
  audit:
    enabled: true
    log_file: out/agent_audit.jsonl
```

**Profile Defaults:**

| Setting | Strict | Standard | Permissive |
|---------|--------|----------|------------|
| Human PR on requirement change | Yes | Yes | No |
| Human PR on critical finding | Yes | Yes | No |
| Human PR on auto-patch above | Low | Medium | — (disabled) |
| Auto-patch enabled | Yes | Yes | Yes |
| Auto-patch max severity | Low | Low | High |
| Gate fails on | Medium+ | High+ | Critical only |
| Block merge on obligations | Yes | No | No |
| Auto-close work items | No | Yes | Yes |
| Require sync sign-off | Yes | No | No |
| Audit log | Yes | Yes | Yes |

### Phase 26b — Guided Setup & Dashboard UX
**Goal:** Make AI SDLC Guard accessible to users who aren't comfortable editing YAML. The `guard init` command becomes an interactive wizard. The dashboard evolves from a metrics viewer into a complete operational interface where end users can scan, view findings, generate reports, and configure policies — without ever touching the CLI.

**Current Dashboard Gap:** Today the dashboard shows *aggregated metrics* (how many findings by severity, top files, cache stats) but NOT individual findings. To see what was actually found, a user must generate an HTML report from the CLI (`guard report --format html`) or read `findings.json` directly. There's no "Run Scan" button, no findings table, and no "Download Report" action in the dashboard. This means the dashboard is useful for monitoring but not for day-to-day operation.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| **Dashboard Scan Actions** | | |
| "Run Scan" button in dashboard header (calls POST `/scan`, refreshes metrics) | High | 1–2 days |
| Scan progress indicator (spinner + live status while scan runs) | Medium | 1 day |
| "Run Gate" button showing pass/fail result with severity breakdown | Medium | 1 day |
| Repo path selector or auto-detect from config | Medium | 1 day |
| **Dashboard Findings Viewer** | | |
| New "Findings" tab showing detailed finding table (file, line, rule, severity, message) | High | 3–5 days |
| API endpoint: GET `/api/findings` returning findings.json contents | High | 0.5 day |
| Findings table: sortable by severity, filterable by rule/file/severity | High | 2–3 days |
| Finding detail expand/collapse (evidence snippet, suggestion, compliance clause) | Medium | 1–2 days |
| Severity filter chips at top of findings view | Medium | 1 day |
| Compliance obligations section within findings view (grouped by standard) | Medium | 1–2 days |
| **Dashboard Report Generation** | | |
| "Generate Report" button with format selector (HTML / JUnit / SARIF) | High | 2–3 days |
| API endpoint: GET `/api/report?format=html` returning rendered report from last scan | High | 1 day |
| Report preview panel (rendered HTML inline for HTML format) | Medium | 2–3 days |
| Download button for each format (serves file directly, not JSON-wrapped) | Medium | 1–2 days |
| Report history: list of previous scan reports with timestamps and download links | Low | 2–3 days |
| **Dashboard Management Console** | | |
| Settings tab: dropdowns and toggles that write back to `.guard.yaml` via POST `/api/config` | High | 3–5 days |
| Policies tab: profile selector cards + override toggles (interactive, not read-only) | High | 2–3 days |
| Packs tab: enable/disable toggles that call POST `/api/packs/{id}/enable` | Medium | 1–2 days |
| Rules tab: searchable/filterable table (exists in JS, needs polish) | Low | 1 day |
| **Guided Setup** | | |
| Interactive `guard init` wizard (DevOps platform, project type, governance profile) | High | 3–5 days |
| Project type presets auto-suggest packs (web app → OWASP, medical → FDA, etc.) | Medium | 1–2 days |
| Onboarding flow: first-run detection → redirect to setup wizard in dashboard | Medium | 2–3 days |
| CI integration helper: generates ready-to-paste pipeline YAML (Azure/GitHub Actions) | Medium | 1–2 days |
| End-user documentation: "Getting Started" guide written for non-developer audience | Medium | 2–3 days |
| **Tests** | | |
| Tests for scan actions, findings API, report generation, config writes, onboarding | High | 3–5 days |

**End-User Setup Flow:**
1. Install via Docker (`docker pull`) or compiled CLI binary — **no source code access**
2. Run `guard init` → interactive wizard asks: DevOps platform? Project type? Governance profile?
3. Wizard generates `.guard.yaml` with sensible defaults and enables suggested packs
4. Run `guard serve` → dashboard opens at `localhost:8000/dashboard`
5. Dashboard onboarding screen walks through: connect DevOps, review rules, confirm policies
6. Integrate into CI: copy provided pipeline YAML snippet into repo

**Dashboard vs CLI — Same Actions, Two Interfaces:**

| Action | CLI Command | Dashboard Equivalent |
|--------|-------------|---------------------|
| Scan the repo | `guard scan` | "Run Scan" button → calls POST `/scan` |
| Check the gate | `guard gate` | "Run Gate" button → shows pass/fail badge |
| View findings | Read `out/findings.json` | Findings tab with sortable/filterable table |
| Generate HTML report | `guard report --format html` | "Generate Report" → format dropdown → preview + download |
| Change governance profile | Edit `.guard.yaml` | Policies tab → click profile card → save |
| Enable a standards pack | `guard add-pack owasp-top-10` | Packs tab → toggle switch → save |
| View audit trail | Read `out/agent_audit.jsonl` | Audit Log tab with filterable timeline |
| Configure settings | Edit `.guard.yaml` + env vars | Settings tab → form fields → save |

**Dashboard Tab Design (Updated):**

| Tab | Purpose | Key Controls |
|-----|---------|--------------|
| Overview | Scan results, severity charts, top files + scan actions | "Run Scan" button, "Run Gate" button, metrics cards, severity chart |
| Findings | Detailed finding table with individual results | Sortable table, severity filter chips, expand/collapse details, compliance section |
| Reports | Generate and download reports in multiple formats | Format selector, "Generate" button, preview panel, download links, history |
| Policies | Governance controls: profiles, human gates, auto-patch scope | Profile selector cards (Strict/Standard/Permissive) + override toggles |
| Packs | Enable/disable standards packs with descriptions | Cards with toggle + rule count + coverage summary |
| Rules | Browse all active rules with severity and type | Searchable/filterable table |
| Audit Log | Timeline of all agent actions with policy justification | Filterable table: timestamp, action, actor, policy, result |
| Settings | General config: providers, reporters, scanning options | Dropdowns, toggles, text fields → writes to `.guard.yaml` |

### Phase 26c — Proprietary Distribution
**Goal:** Ensure end users never receive source code. Distribute as Docker images and compiled CLI binaries.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| Private Docker registry setup (GitHub Container Registry or AWS ECR) | High | 1–2 days |
| CI pipeline: auto-build + push Docker image on release tag | High | 1–2 days |
| PyInstaller or Nuitka build: compile `guard` CLI to standalone binary | High | 2–3 days |
| Binary builds for Linux (x86_64, arm64) and macOS (arm64) | Medium | 2–3 days |
| License key / activation system (basic — API key validates against license server) | Medium | 3–5 days |
| Remove MIT license, replace with proprietary EULA | High | 0.5 day |
| Strip .py source from Docker image (compile to .pyc only) | Medium | 1 day |
| Customer installation guide (Docker pull + init + serve) | Medium | 1–2 days |
| VS Code extension: package as .vsix, connect to REST API (no local Python required) | Medium | 2–3 days |
| Tests for compiled binary (smoke tests on each platform) | Medium | 1–2 days |

**Distribution Channels:**

| Channel | What the customer gets | Source code exposure |
|---------|----------------------|---------------------|
| Docker image | Pre-built container with compiled .pyc files, REST API + dashboard | None — no .py files in image |
| CLI binary | Standalone executable (PyInstaller/Nuitka) | None — compiled to native |
| VS Code extension | .vsix package that talks to REST API over HTTP | None — TypeScript frontend only |

**Licensing Model:**
- `GUARD_LICENSE_KEY` env var validates against a lightweight license server or offline key file
- License tiers: Team (up to 5 repos), Organization (unlimited repos), Enterprise (custom rules + priority support)
- Grace period: 30-day trial with full features, then gated to read-only scanning (no gate enforcement)

### Phase 26d — Custom Standards Packs
**Goal:** Let end users customize existing packs, build their own packs from scratch, and import/export packs as portable YAML files — all through the dashboard UI, no hand-editing required.

**Current State:** Packs are self-contained YAML files (`pack.yaml` with name, description, and a rules list). Each rule has id, name, type, severity, pattern, and optional compliance fields. The registry is a hardcoded Python dict that maps pack IDs to package paths. The architecture is clean — the only blocker to user-defined packs is the hardcoded registry.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| **Pack Customization (Override Existing)** | | |
| `pack_overrides` section in `.guard.yaml` — per-rule overrides (disable, change severity, tweak pattern) | High | 2–3 days |
| Override merge logic in registry loader — apply overrides after loading base pack rules | High | 1–2 days |
| Dashboard Packs tab: "Edit" button per pack → rule editor (toggle on/off, adjust severity, edit pattern) | High | 3–5 days |
| Override preview: show diff between base pack and customized version | Medium | 1–2 days |
| Reset-to-default button per rule or per pack | Low | 0.5 day |
| **Custom Pack Builder** | | |
| User packs directory: `.guard/packs/` scanned by registry alongside built-in packs | High | 1–2 days |
| Dynamic pack discovery: registry scans filesystem instead of hardcoded dict only | High | 1–2 days |
| Dashboard "Create Pack" wizard: name, description, add rules via form (type, pattern, severity, etc.) | High | 3–5 days |
| Rule builder form: dropdowns for type and severity, text fields for pattern/glob/remediation, tag chips | Medium | 2–3 days |
| Rule validation on save (regex compiles, required fields present, no duplicate IDs) | High | 1–2 days |
| Pack YAML generator: wizard output writes valid `pack.yaml` to user packs directory | Medium | 1–2 days |
| **Pack Import / Export** | | |
| Dashboard "Import Pack" button: file upload accepting `.yaml` files | High | 1–2 days |
| Import schema validation: correct top-level keys, valid rule types, no ID collisions with existing packs | High | 1–2 days |
| Import preview panel: "This pack contains N rules: X regex, Y AST, Z doc obligations" before confirming | Medium | 1 day |
| Dashboard "Export Pack" button: downloads pack as `.yaml` file for sharing | Medium | 1 day |
| API endpoints: POST `/api/packs/import`, GET `/api/packs/{id}/export` | Medium | 1–2 days |
| **Pack Management** | | |
| Dashboard Packs tab redesign: "Built-in" section + "Custom" section + "Import" button | Medium | 1–2 days |
| Delete custom pack (with confirmation — never delete built-in packs) | Low | 0.5 day |
| Pack versioning: track version in pack.yaml metadata, show in dashboard | Low | 1 day |
| **Tests** | | |
| Tests for dynamic discovery, override merge, import validation, export, custom pack CRUD | High | 3–5 days |

**Pack Override Schema (in `.guard.yaml`):**
```yaml
standards_packs:
  - fda-iec-62304
  - owasp-top-10

pack_overrides:
  fda-iec-62304:
    IEC62304-CODE-001:
      enabled: false           # Disable this rule entirely
    IEC62304-CODE-003:
      severity: high           # Override severity from medium to high
    IEC62304-DOC-002:
      remediation_guidance: "Our team uses Confluence for design docs"
  owasp-top-10:
    OWASP-A03-001:
      pattern: "(?i)(execute|run_query)\\s*\\(\\s*f[\"']"  # Tighten the regex
```

**User Pack Directory Structure:**
```
project-repo/
├── .guard.yaml                    # References built-in + custom packs
├── .guard/
│   └── packs/
│       ├── my-company-standards/
│       │   └── pack.yaml          # Custom pack (created via wizard or imported)
│       └── team-security-rules/
│           └── pack.yaml          # Another custom pack
└── src/
```

**Three Tiers of Pack Customization:**

| Tier | User Action | Dashboard UX | Storage |
|------|-------------|-------------|---------|
| Customize existing | Edit rules in a built-in pack (toggle, tweak severity/pattern) | "Edit" button on pack → rule editor | `pack_overrides` in `.guard.yaml` |
| Build from scratch | Create a new pack with custom rules | "Create Pack" wizard → rule builder form | `.guard/packs/{name}/pack.yaml` |
| Import external | Upload a `.yaml` pack file from another team or vendor | "Import Pack" button → validation → preview → confirm | `.guard/packs/{name}/pack.yaml` |

### Phase 26e — Dashboard DevOps Integration
**Goal:** Close the gap between the dashboard and the end user's DevOps repository. Today the dashboard has zero awareness of the connected DevOps platform — users must hand-edit `.guard.yaml` and run CLI commands to link their repo, sync work items, or push findings back. Phase 26e makes the dashboard the primary interface for DevOps connectivity.

**Current Gap:** The DevOps providers (Azure DevOps, GitHub, Jira) are fully functional from the CLI — `guard reconcile` creates/updates/closes work items, `guard sync` pushes state, `guard context` fetches active items. But the dashboard doesn't expose any of this. There's no connection setup UI, no work item viewer, no reconcile button, and no PR decoration.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| **Dashboard DevOps Connection** *(Completed in Phase 26e)* | | |
| ~~"Connect" tab or onboarding step: platform picker (Azure DevOps / GitHub / Jira)~~ | High | Phase 26e |
| ~~Platform-specific form fields (org, project, repo, team, iteration, JQL, etc.)~~ | High | Phase 26e |
| ~~"Test Connection" button — validates credentials + displays result (e.g. "Found 12 open items")~~ | High | Phase 26e |
| ~~API endpoint: POST `/api/devops/test-connection` — validates config + returns platform info~~ | High | Phase 26e |
| ~~API endpoint: GET `/api/devops/status` — returns connected platform, health, last sync time~~ | Medium | Phase 26e |
| ~~Write DevOps config back to `.guard.yaml` on save (tokens stay as env var instructions only)~~ | High | Phase 26e |
| ~~Connection status indicator in dashboard header (platform icon + "Connected" badge)~~ | Medium | Phase 26e |
| ~~Token guidance: UI displays "Set GITHUB_TOKEN as environment variable" — never stores secrets~~ | High | Phase 26e |
| **Dashboard Work Items** *(Completed in Phase 26e)* | | |
| ~~New "Work Items" tab showing remote items pulled from DevOps provider~~ | Medium | Phase 26e |
| ~~API endpoint: GET `/api/work-items` — fetches active work items from configured DevOps~~ | Medium | Phase 26e |
| ~~Work item table: ID, title, state, rule_id, linked findings count~~ | Medium | Phase 26e |
| ~~Work item detail: click to expand with description, acceptance criteria, DevOps link~~ | Low | Phase 26e |
| **Dashboard Reconcile** *(Completed in Phase 26e)* | | |
| ~~"Sync to DevOps" button in dashboard (calls reconcile, shows create/update/close preview)~~ | High | Phase 26e |
| ~~API endpoint: POST `/api/reconcile` with optional `dry_run` query param~~ | High | Phase 26e |
| ~~Reconcile preview panel: shows planned actions before execution (like `--dry-run`)~~ | Medium | Phase 26e |
| ~~Reconcile result summary: created N, updated N, closed N, errors N~~ | Medium | Phase 26e |
| **PR Decoration & CI Reporting** | | |
| ~~PR comment posting: findings summary (severity counts, top issues, pass/fail, report link)~~ | High | Phase 26d |
| ~~GitHub PR comment via GitHub API (POST /repos/{owner}/{repo}/issues/{pr}/comments)~~ | High | Phase 26d |
| Azure DevOps PR thread via Azure API (POST /_apis/git/repositories/{repo}/pullRequests/{pr}/threads) | Medium | 2–3 days |
| CI artifact publishing: attach HTML/SARIF reports to pipeline run | Medium | 1–2 days |
| GitHub Actions: upload-artifact step in workflow template | Medium | 0.5 day |
| Azure Pipelines: PublishBuildArtifacts step in pipeline template | Medium | 0.5 day |
| PR status check: custom check-run showing gate pass/fail (GitHub) / build tag (Azure) | Low | 2–3 days |
| **GitHub/Jira Write Operations** *(Completed in Phase 26d)* | | |
| ~~GitHub Issues: implement create_work_item, update_work_item, close_work_item~~ | High | Phase 26d |
| ~~Jira Issues: implement create_work_item, update_work_item, close_work_item~~ | Medium | Phase 26d |
| **Tests** | | |
| Tests for DevOps connection API, work items API, reconcile API, PR commenting | High | 3–5 days |

**Dashboard ↔ Repo Data Flow:**

```
End User's DevOps Repo
    │
    ├── .guard.yaml (config checked into repo)
    │   └── Dashboard writes devops_provider, org, project, repo fields here
    │
    ├── CI Pipeline (GitHub Actions / Azure Pipelines)
    │   ├── guard gate → pass/fail status check on PR
    │   ├── guard gate → PR comment with findings summary (Phase 26e)
    │   ├── Reports published as CI artifacts (Phase 26e)
    │   └── guard reconcile → creates/updates/closes work items post-merge
    │
    └── Work Items (Issues / User Stories / Bugs)
           ↑↓  guard reconcile (bidirectional)
           ├── New findings → creates work items with rule_id, severity, remediation
           ├── Resolved findings → closes work items (state → Done)
           └── Re-appeared findings → reopens closed work items

Dashboard (localhost:8000/dashboard)
    ├── Connect tab → pick platform, enter org/project/repo, test connection
    ├── Work Items tab → view remote items, see linked findings
    ├── "Sync to DevOps" → dry-run preview → execute reconcile
    ├── Overview → "Run Scan" / "Run Gate" → results flow to Findings tab
    └── Reports → generate + download → same format published to CI artifacts
```

**What Gets Passed Back to the Repo:**

| Artifact | Where It Goes | Trigger |
|----------|---------------|---------|
| Gate pass/fail | PR status check (blocks/allows merge) | CI pipeline runs `guard gate` |
| Findings summary | PR comment thread | CI pipeline posts after gate (Phase 26e) |
| HTML report | CI pipeline artifact (downloadable from PR) | CI pipeline publishes after gate |
| SARIF report | CI pipeline artifact + GitHub Code Scanning (if enabled) | CI pipeline publishes after gate |
| Work items | DevOps Issues/Stories/Bugs | `guard reconcile` (CLI, CI, or dashboard) |
| Audit log | `out/agent_audit.jsonl` in repo | Every scan/gate/reconcile action |

### Phase 27 — Multi-Language & Extensibility
**Goal:** Extend scanning beyond Python and enable community packs.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| JavaScript/TypeScript regex scanning support | High | 3–5 days |
| Language-agnostic rule engine refactoring | High | 3–5 days |
| ~~External pack loading from filesystem paths~~ — moved to Phase 26d | — | — |
| Pack marketplace / registry concept (builds on Phase 26d import/export) | Medium | 3–5 days |

### Phase 28+ — Long-Term
**Goal:** Scale to SaaS offering and advanced AI analysis.

| Task | Priority | Est. Effort |
|------|----------|-------------|
| SaaS / hosted version with multi-tenant architecture | High | TBD |
| Advanced ML models with training data from customer scans | Medium | TBD |
| Windows CLI binary support | Low | 1–2 days |
| JetBrains IDE plugin | Low | 5–7 days |

---

## 8. Current Codebase Metrics

| Metric | Value |
|--------|-------|
| Source LOC | ~7,500 |
| Test LOC | ~14,000 |
| Test coverage | 96%+ (90% threshold enforced) |
| Source modules | 58 Python files |
| Test modules | 38 |
| CLI commands | 17 (init, validate-config, context, scan, gate, apply-patches, list-rules, report, compare, sync, list-packs, add-pack, remove-pack, serve, install-check, license) |
| API endpoints | 20+ (/health, /scan, /gate, /report, /rules, /api/metrics, /api/config, /api/governance, /api/audit, /api/packs, /api/findings, /api/license, /api/run-scan, /api/run-gate, /api/packs/toggle, /api/report/generate, /dashboard) |
| Built-in AST checks | 6 (mutable defaults, star imports, complexity, nested functions, global vars, function length) |
| Standards rules | 9 (STD-001 to STD-009) |
| FDA pack rules | 14 (4 code, 8 doc obligation, 2 ML/AI) |
| OWASP pack rules | 22 (16 code, 6 doc obligation) |
| SOC2 pack rules | 16 (7 code, 9 doc obligation) |
| Work items | 4 (4 closed) |
| Reporters | 3 (HTML, JUnit, SARIF) |
| Providers | Standards (stub, azure, github, jira), DevOps (stub, azure, github, jira), Scanners (stub, sarif, llm, composite), LLM (stub, anthropic), ML (severity estimator) |

---

## 9. Dependencies & External Systems

| Dependency | Purpose | Risk Level |
|------------|---------|------------|
| Azure DevOps (API) | Work items, standards sync | Medium — requires PAT token |
| GitHub API | Work items (Issues), standards sync | Medium — requires GITHUB_TOKEN |
| Anthropic API | LLM-based scanning | Low — optional feature |
| Azure Pipelines | CI/CD execution | Medium — pipeline config coupled |
| GitHub Actions | CI/CD execution (alternative) | Low — built into GitHub |
| Python 3.11+ | Runtime | Low — widely available |

---

## 10. Key Decisions Log

| Date | Decision | Rationale |
|------|----------|-----------|
| Pre-Phase 1 | Python + Typer for CLI | Fast iteration, rich ecosystem, team familiarity |
| Phase 6 | Provider factory pattern | Enables swappable backends without core changes |
| Phase 7 | SARIF as interchange format | Industry standard for static analysis tool interop |
| Phase 11 | Azure DevOps first | Team's current DevOps platform |
| Phase 14 | Anthropic as LLM provider | High-quality code analysis, structured output support |
| Phase 14 | Standards packs framework | Enables pluggable regulatory compliance (FDA first) |
| Phase 14 | Documentation obligations as non-gating | Compliance reporting without blocking development flow |
| Phase 15 | pytest-cov with 80% threshold | Enforces coverage hygiene as codebase grows |
| Phase 15 | Omit external API providers from coverage | Azure/Anthropic modules need live APIs, mock tests cover logic separately |
| Phase 16 | GitHub as second DevOps platform | Broadens adoption beyond Azure DevOps teams |
| Phase 16 | GitHub Actions as alternative CI | Enables GitHub-native teams to use guard without Azure Pipelines |
| Phase 16 | urllib.request for GitHub API | No additional dependency needed — stdlib only |
| Phase 17 | Python ast module for AST rules | Stdlib, no dependencies, Python-native analysis |
| Phase 17 | AST_CHECKS registry pattern | Named checks extensible without modifying engine |
| Phase 17 | McCabe complexity threshold of 10 | Industry standard for maintainable function size |
| Phase 18 | FastAPI for REST server | Modern async, auto-docs (OpenAPI), Pydantic integration |
| Phase 18 | Optional API key auth via header | Simple, stateless, CI/CD friendly |
| Phase 18 | Inline file scanning in POST body | Enables remote scanning without shared filesystem |
| Phase 19 | ~~MIT license~~ (superseded Phase 26c) | Originally permissive; replaced with proprietary EULA |
| Phase 19 | Optional extras for heavy deps | Keeps base install lightweight (typer, pydantic, pyyaml only) |
| Phase 20 | Multi-stage Docker build | Lean runtime image (~120MB), non-root user for security |
| Phase 20 | Internal-only distribution | No PyPI publication — install from source via editable pip install |
| Phase 20 | Coverage threshold raised to 90% | 96% achieved with comprehensive CLI command tests |
| Phase 20 | Version 1.0.0 | Feature-complete platform ready for production use |
| Phase 21 | OWASP Top 10 2021 mapping | Industry-standard vulnerability categories, widely recognized |
| Phase 21 | SOC2 Trust Services Criteria | Covers security, availability, and confidentiality controls |
| Phase 21 | Internal docs in docs/ folder | Separate from README — detailed guides for users and API consumers |
| Phase 22 | FILE_POLICY_CHECKS registry pattern | Mirrors AST_CHECKS — extensible without modifying dispatch logic |
| Phase 22 | `params` dict on RuleDefinition | Enables configurable thresholds without new schema fields per check |
| Phase 22 | `required_pattern` as new rule type | Cleaner semantics than regex negation — explicit inverse-pattern intent |
| Phase 22 | `all_patterns` composite regex | Enables multi-pattern file-level detection without post-processing |
| Phase 23 | Jira as third DevOps platform | Broadens adoption to teams using Jira for project management |
| Phase 23 | urllib.request for Jira API | Consistent with GitHub provider — stdlib only, no additional deps |
| Phase 23 | Dual auth (API token + PAT) | Supports both Jira Cloud (email + API token) and Data Center (PAT) |
| Phase 23 | Standards in Jira issue description | Pragmatic approach — YAML in issue body, supports ```yaml code blocks |
| Phase 24 | Heuristic ML model (no external deps) | Stdlib-only weighted scoring — no sklearn/pytorch dependency needed |
| Phase 24 | Feature-based severity scoring | 6 features (severity, confidence, code context, pattern risk, file risk, density) — interpretable and tunable |
| Phase 24 | ML post-processing in pipeline | Optional post-processing step after all findings collected, gated by config flag |
| Phase 24 | VS Code extension as separate directory | Not a Python package — TypeScript/Node.js with own build system |
| Phase 25 | ThreadPoolExecutor for parallel scanning | GIL-friendly (file I/O releases GIL), no multiprocessing overhead |
| Phase 25 | Per-rule parallelization (not per-rule-set) | Avoids race conditions — files within one rule are independent |
| Phase 25 | Metrics as JSON file alongside artifacts | Simple, no database needed — dashboard reads from filesystem |
| Phase 25 | Inline HTML dashboard (no external assets) | Zero dependencies — works in air-gapped environments |
| Phase 26 | Governance policies as configurable settings | Teams need to dial agent autonomy up or down based on risk tolerance |
| Phase 26 | Human-in-the-loop PR gates | Requirement changes and critical findings need human sign-off — agents shouldn't auto-merge these |
| Phase 26 | Policy profiles (strict/standard/permissive) | Different projects have different risk profiles — one size doesn't fit all |
| Phase 26 | Agent action audit log | Accountability requires knowing what the agent did and which policy allowed it |
| Phase 26b | Interactive `guard init` wizard | Non-technical users need guided setup, not hand-edited YAML |
| Phase 26b | Dashboard as management console | Settings, policies, audit log, packs — YAML is for power users |
| Phase 26b | Dashboard writes back to `.guard.yaml` | Config file stays the source of truth; dashboard is the friendly face |
| Phase 26c | Proprietary distribution (no source code) | End users should never see Python source — protects IP and simplifies support |
| Phase 26c | Docker image + compiled CLI binary | Two distribution channels: containers for servers, binaries for local dev |
| Phase 26c | Replace MIT with proprietary EULA | Source code is not open-source; license key gates production use |
| Phase 26c | .pyc-only Docker image | Strip .py files from container; ship only compiled bytecode |
| Phase 26c | License key system | Tiered licensing (Team/Org/Enterprise) with 30-day trial |
| Phase 26b | Dashboard as operational interface, not just monitoring | End users need to scan, view findings, and download reports without CLI |
| Phase 26b | GET `/api/findings` and GET `/api/report` endpoints | Dashboard needs server-side data; existing `/report` requires POST with scan request |
| Phase 26b | Dashboard-CLI feature parity | Every CLI action should have a dashboard equivalent — same output, two interfaces |
| Phase 26b | Report preview panel in dashboard | HTML reports should render inline; JUnit/SARIF are download-only |
| Phase 26d | `devops_id` widened to `int \| str` | Jira uses string issue keys (PROJ-42) — polymorphic ID avoids provider-specific reconciler logic |
| Phase 26d | GitHub/Jira write ops via urllib.request | Consistent with existing read ops — stdlib only, no additional deps |
| Phase 26d | Jira close via transition search | Jira has no direct "close" — must query available transitions and POST the matching one |
| Phase 26d | PR decorator as standalone module | Decouples formatting + posting from CLI — reusable by API server and CI |
| Phase 26d | Auto-detect PR number from GITHUB_EVENT_PATH | GitHub Actions sets this env var — zero-config PR decoration in CI |
| Phase 26d | Pack overrides via `pack_overrides` in config | Users shouldn't fork a pack to change one rule — layered overrides keep base packs updatable |
| Phase 26d | Dynamic pack discovery from `.guard/packs/` | Hardcoded registry blocks user packs — filesystem scanning makes custom packs drop-in |
| Phase 26d | Three-tier customization (override / build / import) | Different users have different needs — from tweaking one rule to importing a vendor pack |
| Phase 26d | Pack import as YAML upload with schema validation | Packs are already just YAML — uploading is the natural sharing mechanism between teams |
| Phase 26d | User packs directory in `.guard/packs/` (checked into repo) | Custom packs travel with the codebase and are version-controlled alongside config |
| Phase 26e | Dashboard DevOps connection UI | End users shouldn't hand-edit YAML to connect their repo — dashboard provides guided setup |
| Phase 26e | PR decoration (findings summary comment) | Most visible feedback loop — findings appear directly on the PR where developers look |
| Phase 26e | Dashboard reconcile button | Dashboard-only users need to sync findings → work items without CLI |
| Phase 26e | Work Items tab in dashboard | Users need visibility into the Guard-managed work items in their DevOps platform |
| Phase 26e | CI artifact publishing for reports | HTML/SARIF reports attached to pipeline runs so they're accessible from the PR |

---

## 11. End-User Experience Design

### User Personas

| Persona | Role | Primary Interface | Needs |
|---------|------|-------------------|-------|
| Admin | DevOps / Platform Engineer | CLI + Dashboard Settings | Initial setup, CI/CD wiring, policy configuration |
| Developer | Engineer using AI coding agent | VS Code Extension + CLI | Real-time feedback, pre-commit checks, self-service scanning |
| Leader | Engineering Manager / Compliance | Dashboard Overview + Audit Log | Scan trends, policy compliance, audit trail for reviews |

### Setup Flow (Admin Persona)

1. **Install** — `docker pull ghcr.io/ai-sdlc-guard:latest` or download compiled `guard` binary
2. **Initialize** — Run `guard init` in the target repository
   - Wizard asks: DevOps platform? (Azure DevOps / GitHub / Jira)
   - Wizard asks: Project type? (Web app / API / Medical device / Financial / General)
   - Wizard auto-suggests relevant standards packs based on project type
   - Wizard asks: Governance profile? (Strict / Standard / Permissive) with descriptions
   - Wizard asks: VS Code scan-on-save? (Yes / No)
   - Wizard generates `.guard.yaml` with sensible defaults
3. **Connect DevOps** — Wizard prompts for API tokens (stored as env vars, never in config file)
4. **Verify** — `guard scan` runs a first scan; `guard gate` confirms the gate works
5. **Integrate CI** — Wizard outputs a ready-to-paste pipeline snippet (Azure Pipelines or GitHub Actions)
6. **Dashboard** — `guard serve` starts the management console for ongoing configuration

### Development Flow (Developer Persona)

```
Developer starts coding session with AI agent
    │
    ├─→ Agent reads `guard context` → gets governance policies, work items, rules
    │   (Agent now knows its constraints before writing any code)
    │
    ├─→ Developer + agent write code
    │   └─→ VS Code extension runs `guard scan --staged` on save
    │   └─→ Findings appear as editor diagnostics (red/yellow squiggles)
    │   └─→ Agent sees findings → self-corrects in real time
    │
    ├─→ Developer commits
    │   └─→ Pre-commit hook: `guard scan --staged`
    │   └─→ If findings at/above threshold → commit blocked → fix → retry
    │   └─→ If clean → commit succeeds
    │
    ├─→ Developer opens pull request
    │   └─→ CI runs `guard gate --git-range origin/main...HEAD`
    │   └─→ Guard evaluates: code findings + compliance obligations + traceability
    │   └─→ Guard posts PR comment with findings summary
    │   └─→ If governance policy requires human review → labels PR, blocks merge
    │   └─→ If gate passes → PR is mergeable
    │
    └─→ Post-merge
        └─→ `guard sync` updates work items in Azure DevOps / GitHub / Jira
        └─→ `guard reconcile` closes resolved items, opens new ones
        └─→ Audit log records all actions with policy justification
```

### Report Generation Flow (Dashboard vs CLI)

An end user who only has the dashboard should be able to generate the exact same reports that the CLI produces. The workflow:

**From the Dashboard (non-technical user):**
1. Open dashboard → Overview tab → click "Run Scan"
2. Scan runs against configured repo → findings populate the Findings tab
3. Navigate to Reports tab → select format (HTML / JUnit / SARIF) → click "Generate Report"
4. Report renders in a preview panel (for HTML) or as a download link (for JUnit/SARIF)
5. Click "Download" to save the file locally

**From the CLI (developer / CI pipeline):**
1. `guard scan` → writes findings.json + configured reports to `out/`
2. `guard report --format html --output my-report.html` → regenerates from findings
3. Or: `guard gate` → scan + gate decision + reports in a single command

**From the API (automation / custom tooling):**
1. POST `/scan` → returns findings array
2. GET `/api/report?format=html` → returns rendered report from last scan
3. POST `/report` → scan-on-demand with inline files, returns rendered content

All three paths produce identical output — same findings, same report formats, same compliance sections.

### Configuration Interface (Dashboard)

The dashboard at `localhost:8000/dashboard` evolves from a read-only metrics viewer into a full management console with 8 tabs (Overview, Findings, Reports, Policies, Packs, Rules, Audit Log, Settings). Changes made in the dashboard write back to `.guard.yaml` so they stay in version control. The dashboard is the friendly face; the config file is the source of truth.

### Proprietary Distribution Model

End users never receive source code. Three distribution channels:

| Channel | Format | What customer gets | Setup |
|---------|--------|-------------------|-------|
| Docker | Container image from private registry | Pre-built with .pyc-only (no .py source), REST API + dashboard included | `docker pull` → `docker compose up` |
| CLI Binary | Compiled executable (PyInstaller/Nuitka) | Standalone `guard` binary for Linux/macOS | Download → `chmod +x` → run |
| VS Code Extension | .vsix package | TypeScript frontend connecting to REST API over HTTP | Install from marketplace or sideload |

All channels require a `GUARD_LICENSE_KEY` for production use (30-day free trial with full features).

---

## 12. Weekly Workflow

A suggested solo-developer weekly rhythm:

- **Monday:** Review task tracker, prioritize week's work, update status report
- **Wednesday:** Mid-week checkpoint — assess progress, adjust priorities if blocked
- **Friday:** End-of-week review — mark completed tasks, write brief status update, plan next week

---

## 13. References

| Resource | Location |
|----------|----------|
| Source code | `src/guard/` |
| REST API server | `src/guard/server.py` |
| AST checks | `src/guard/rules/ast_checks.py` |
| Tests | `tests/` |
| Config | `.guard.yaml` |
| Standards | `standards.yaml` |
| FDA Pack | `src/guard/packs/fda_iec_62304/pack.yaml` |
| OWASP Pack | `src/guard/packs/owasp_top_10/pack.yaml` |
| SOC2 Pack | `src/guard/packs/soc2/pack.yaml` |
| User Guide | `docs/USER_GUIDE.md` |
| API Reference | `docs/API_REFERENCE.md` |
| Extension Guide | `docs/EXTENSION_GUIDE.md` |
| Pack Authoring Guide | `docs/PACK_AUTHORING_GUIDE.md` |
| ML Severity Estimator | `src/guard/ml/severity_estimator.py` |
| VS Code Extension | `vscode-extension/` |
| Work items | `work_items.json` |
| CI/CD (Azure) | `azure-pipelines.yml` |
| CI/CD (GitHub) | `.github/workflows/guard-gate.yml` |
| Demo | `demo/` |
| Agent instructions | `CLAUDE.md` |
| Contributor guide | `CONTRIBUTING.md` |
| README | `README.md` |
