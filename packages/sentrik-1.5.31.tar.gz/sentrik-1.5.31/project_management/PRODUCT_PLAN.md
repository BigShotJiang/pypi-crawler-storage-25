# AI SDLC Guard — Product Plan

**Version:** 1.0.0
**Date:** March 2026
**Distribution:** Internal Only

---

## Executive Summary

AI SDLC Guard is a governance runtime that enforces coding standards, traces work items, and gates pull requests for enterprise development teams using AI coding agents. It provides deterministic quality control for AI-generated code — a critical gap in the current toolchain.

The product is v1.0.0 with ~5,200 lines of production code, 96%+ test coverage, a REST API, Docker deployment, and three regulatory standards packs (FDA IEC 62304, OWASP Top 10, SOC2). It is ready for internal pilot deployment.

---

## The Problem

AI coding agents (Copilot, Claude Code, Cursor) generate code at unprecedented speed, but they create three problems for enterprise teams:

**No governance layer.** AI agents bypass established code review norms. Secrets, debug code, eval statements, and banned patterns slip into codebases undetected. There's no deterministic check between "AI wrote it" and "it shipped."

**Compliance blind spots.** Regulated industries — healthcare (FDA), financial services (SOC2), and web platforms (OWASP) — need documented evidence that code quality controls are in place. Manual review doesn't scale with AI-speed output.

**Broken traceability.** Work items disconnect from code changes. There's no audit trail linking requirements to implementation, and no automated way to sync status back to project management tools.

---

## The Solution

AI SDLC Guard is a CLI tool and REST API that sits in the development pipeline — between the AI agent and the code repository. Every commit, PR, or scan triggers the guard, which evaluates code against configured rules, links findings to work items, and produces compliance reports.

The core workflow is: **Commit → Scan → Gate → Report → Sync.**

Key capabilities include regex, AST, and file-policy rule evaluation; three pre-built regulatory standards packs; auto-patching for low-severity findings; HTML/JUnit/SARIF report generation; and bidirectional sync with Azure DevOps and GitHub.

---

## Product Capabilities (v1.0.0)

**Rules Engine:** 9 user-configured standards rules (STD-001 through STD-009), 5 built-in AST checks (mutable defaults, star imports, cyclomatic complexity, nested functions, global variables), and 52 rules across 3 regulatory packs. Rules span four types: regex pattern matching, AST semantic analysis, file-policy structural checks, and documentation obligations (non-gating compliance items).

**Standards Packs:** FDA IEC 62304 (14 rules covering medical device software lifecycle), OWASP Top 10 2021 (22 rules covering all 10 vulnerability categories), and SOC2 Trust Services Criteria (16 rules covering security, availability, and confidentiality). Packs are managed via CLI: `guard list-packs`, `guard add-pack`, `guard remove-pack`.

**DevOps Integration:** Full provider support for Azure DevOps (work items, standards sync, state push) and GitHub (Issues, standards, Actions CI). Work items extracted from branch names and commit messages. `guard sync` pushes state back to DevOps platforms.

**REST API:** FastAPI server with 5 endpoints (/health, /scan, /gate, /report, /rules), optional API key authentication, and inline file scanning for remote use. Dockerized with multi-stage build, non-root user, and health checks.

**Reporting:** HTML reports with compliance obligation sections, JUnit XML for CI integration, and SARIF JSON for tool interoperability. Auto-generated patches, next-actions markdown, and scan comparison between runs.

---

## Target Market

Enterprise development teams in regulated industries who are adopting AI coding agents and need provable, auditable evidence that generated code meets their standards.

**Healthcare & Medical Device** — Teams building FDA-regulated software under IEC 62304 / 21 CFR Part 11. They need documented software lifecycle controls, traceability from requirements to code, and audit-ready reports. The FDA IEC 62304 pack provides 14 rules with clause-level traceability.

**Financial Services** — Teams subject to SOC2 audits, change management controls, and access policy enforcement. The SOC2 pack covers Trust Services Criteria across security, availability, and confidentiality. Documentation obligations produce audit evidence without blocking development.

**SaaS & Platform Teams** — Teams building web applications who need OWASP Top 10 security scanning integrated into CI/CD. The OWASP pack covers all 10 2021 categories with 22 rules. CI gating prevents vulnerable code from reaching production.

---

## Competitive Positioning

AI SDLC Guard occupies a unique position — it is purpose-built for governing AI agent output, combining deterministic scanning with regulatory compliance.

**vs. Traditional SAST tools (SonarQube, Semgrep, CodeQL):** These tools scan code but have no AI agent awareness, no work item traceability, and no regulatory compliance packs. Guard complements them — it imports their SARIF output and adds governance on top.

**vs. AI Agent Platforms (Copilot, Cursor, Claude Code):** These platforms generate code but don't govern it. They have no deterministic quality gates, no compliance reporting, and no DevOps sync. Guard is the governance layer that sits alongside them.

**vs. Custom CI scripts:** Many teams write ad-hoc regex checks in CI. Guard replaces these with a structured, tested, extensible framework that includes caching, reporting, auto-patching, and work item integration.

---

## Go-to-Market Strategy

**Internal-first:** Prove value inside the organization before exploring external sales.

**Phase 1 — Internal Pilot (Now → Q2 2026):** Deploy Docker container to one team's CI pipeline. Run `guard gate` on 3 active repos for 2 weeks. Measure findings caught, gate pass rate, and developer friction. Gather feedback on rule accuracy and false positive rate.

**Phase 2 — Org-Wide Rollout (Q3 2026):** Onboard 2-3 additional teams. Deploy custom rule DSL (Phase 22) so each team can add org-specific policies without modifying source. Add Jira integration (Phase 23) for teams not on Azure DevOps or GitHub. Build an internal case study with concrete metrics.

**Phase 3 — External Sales (Q4 2026+):** Package as a licensed product with enterprise pricing (per-team or per-repo). Market around compliance certifications: "AI code that passes your audit." Conference talks and technical blog content to build awareness.

---

## Value Propositions

**For Engineering Leaders:** "Let your team use AI agents without breaking your standards." Guard provides a deterministic gate that blocks bad code before merge, auto-fix patches that reduce manual rework, and a full audit trail of every scan.

**For Compliance & QA:** "Prove your AI-generated code meets regulatory requirements." Pre-built regulatory packs map directly to standard clauses. Documentation obligations are tracked and reported. HTML, JUnit, and SARIF output formats satisfy auditors and CI systems alike.

**For DevOps & Platform Engineering:** "Add governance without slowing down the pipeline." A single CLI command (`guard gate`) integrates into any CI system. Docker deployment takes minutes. Scan caching means only changed files are re-evaluated.

---

## Product Roadmap

**Shipped (Phases 1–21):** Core engine, Azure DevOps + GitHub providers, REST API + Docker, 3 standards packs, internal documentation, 96%+ test coverage. The platform is production-ready.

**Next (Phases 22–23):** Custom rule DSL for organization-specific policies. Jira integration as a third DevOps provider. Performance optimization for large repos (10k+ files). Incremental scanning.

**Future (Phases 24+):** VS Code extension for in-editor scanning. ML-based severity estimation to reduce false positive noise. Web dashboard for scan trends and team-level visibility. Multi-language support beyond Python.

---

## Key Success Metrics

**Adoption** — Number of teams using Guard in their CI pipelines. Target: 3+ teams by end of Q2 2026.

**Coverage** — Percentage of active repos with Guard enabled. Target: 50%+ of team repos by end of Q3 2026.

**Catch Rate** — Critical and high findings caught per scan. Validates the rules are catching real problems.

**Time Saved** — Hours of manual code review avoided per sprint. Measured by comparing pre-Guard and post-Guard review cycles.

---

## Next Steps

1. Deploy Docker container to pilot team's CI pipeline
2. Run `guard gate` on 3 active repos for 2 weeks
3. Review findings report and calibrate rule thresholds
4. Present pilot results to leadership for org-wide rollout decision
