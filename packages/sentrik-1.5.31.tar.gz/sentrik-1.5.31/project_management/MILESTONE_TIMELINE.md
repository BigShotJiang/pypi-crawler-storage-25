# AI SDLC Guard — Milestone Timeline

**Last Updated:** 2026-03-01

---

## Completed Milestones

```
JAN 2026                              MAR 2026
|── Phases 1-14 ──|── Ph15 ─|── Ph16 ─|── Ph17 ─|── Ph18 ─|── Ph19 ─|
  Core Platform     Stabilize  GitHub    AST Rules  REST API  Packaging
                       M1        M2        M3         M4        M5
                       DONE      DONE      DONE       DONE      DONE
```

All five original milestones have been achieved. The project is feature-complete through Phase 19.

| Milestone | Phase | Status | Key Outcome |
|-----------|-------|--------|-------------|
| M1 — Stabilization | 15 | Done | All WIs closed, 90%+ coverage, CONTRIBUTING.md |
| M2 — GitHub Support | 16 | Done | DevOps + Standards GitHub providers, GitHub Actions CI |
| M3 — AST Rules | 17 | Done | 5 built-in AST checks, AST_CHECKS registry |
| M4 — REST API | 18 | Done | FastAPI with 5 endpoints, API key auth, 23 tests |
| M5 — Packaging | 19 | Done | PyPI-ready, MIT license, sdist builds, optional extras |

---

## Upcoming Timeline

```
MAR 2026          APR 2026          MAY 2026          JUN 2026          JUL 2026
|── Phase 20 ──|── Phase 21 ───|── Phase 22 ───|── Phase 23 ───|── Phase 24 ──|
  Docker &        Packs &         Custom Rules    Jira &          IDE &
  Hardening       Internal Docs   & DSL           Performance     ML
     M6              M7              M8              M9              M10
```

---

## Upcoming Milestones

### M6 — Docker Deployment + Coverage Stabilized
**Target:** Mid-March 2026
**Phase:** 20
**Criteria:**

- Dockerfile and docker-compose.yml for REST API server working
- Health check and restart policies configured
- Test coverage back above 90%
- Internal deployment guide written

**Why it matters:** Makes the REST API deployable for the team without requiring everyone to set up a local Python environment. Stabilizes quality baseline.

---

### M7 — Expanded Packs + Internal Documentation
**Target:** Mid-April 2026
**Phase:** 21
**Criteria:**

- At least one new standards pack (OWASP Top 10 or SOC2)
- Internal user guide covering installation, config, rules, and packs
- API reference documentation

**Why it matters:** Regulatory coverage beyond FDA broadens internal applicability. Documentation enables team members to onboard without hand-holding.

---

### M8 — Custom Rule DSL
**Target:** Mid-May 2026
**Phase:** 22
**Criteria:**

- Users can define custom rules in YAML without modifying source
- Custom AST checks configurable via config
- Extension guide with worked examples
- Full test coverage for custom rule loading

**Why it matters:** Removes the need to modify source code to add organization-specific rules — the biggest barrier to team-wide adoption.

---

### M9 — Jira Support + Performance
**Target:** Mid-June 2026
**Phase:** 23
**Criteria:**

- `DevOpsJira` and `StandardsJira` providers working
- Benchmarked on repos with 10k+ files
- Incremental scanning optimizations implemented
- Integration tests for Jira providers

**Why it matters:** Jira is the most widely used project tracking tool. Performance at scale proves readiness for larger repos.

---

### M10 — IDE Extension + ML Severity
**Target:** Mid-July 2026
**Phase:** 24
**Criteria:**

- VS Code extension with scan-on-save
- ML-based severity estimation prototype
- Internal pack authoring guide

**Why it matters:** Meeting developers where they work (in the editor) increases daily usage. ML severity estimation reduces noise from false positives.

---

## Dependencies Between Milestones

M6 is the immediate priority — it unblocks team-wide deployment of the REST API.

M7 depends on M6 being stable (docs reference the deployed service). M8 is independent of M7 and could be worked in parallel.

M9 and M10 are independent of each other but both benefit from M6-M8 being complete (stable, documented, extensible platform).

---

## Checkpoint Schedule

| Date | Checkpoint | Action |
|------|-----------|--------|
| Mar 8 | Phase 20 mid-check | Dockerfile drafted, coverage improvements underway |
| Mar 15 | M6 target | Docker running, coverage above 90% |
| Mar 29 | Phase 21 mid-check | OWASP pack drafted, user guide started |
| Apr 13 | M7 target | New pack shipped, internal docs complete |
| Apr 27 | Phase 22 mid-check | DSL design finalized, loader started |
| May 18 | M8 target | Custom rules working end-to-end |
| Jun 1 | Phase 23 mid-check | Jira provider drafted, benchmarks run |
| Jun 15 | M9 target | Jira support + perf optimizations shipped |
| Jul 6 | Phase 24 mid-check | VS Code extension prototype working |
| Jul 14 | M10 target | Extension working, ML prototype evaluated |
