# sentrik

**Governance runtime for AI-generated code.** Scan, gate, and trace compliance automatically.

[![npm version](https://img.shields.io/npm/v/sentrik)](https://www.npmjs.com/package/sentrik)
[![License](https://img.shields.io/badge/license-Proprietary-blue)](LICENSE)

```bash
npm install -g sentrik
```

## 30-Second Quickstart

```bash
# Open any project and scan — no setup needed
sentrik scan

# Enforce quality gate (exit 1 on failure)
sentrik gate
```

That's it. sentrik auto-detects your project, applies sensible defaults, and shows findings inline. No wizard, no config files needed.

Want to customize? Run `sentrik init` to generate a `.sentrik/config.yaml` with detected settings.

## Why sentrik?

Teams using **Copilot, Cursor, Claude Code**, and AI coding agents generate code fast — but compliance doesn't keep up. sentrik enforces standards **automatically**:

- **IEC 62304** for medical device software (FDA/EU MDR)
- **OWASP Top 10** for web application security
- **SOC2** Trust Services Criteria
- **Custom rule packs** for your own standards

## Key Features

| Feature | Description |
|---------|-------------|
| **Zero Config** | Auto-detects project, applies sensible defaults — just scan |
| **Rules Engine** | Regex, AST, and file-policy rules with auto-fix |
| **Standards Packs** | 14 pre-built packs: IEC 62304, OWASP, SOC2, HIPAA, PCI DSS, ISO 27001, PHP, Kotlin, and more |
| **CI/CD Gate** | Block non-compliant PRs in GitHub Actions, Azure Pipelines, or GitLab CI |
| **PR Decoration** | Compliance summary + findings as PR comments on GitHub and Azure DevOps |
| **Work Item Traceability** | Link findings to Azure DevOps, GitHub Issues, or Jira |
| **Reconciliation** | Auto-create/update/close work items from scan results |
| **Management Dashboard** | Web UI for findings, rules, packs, audit log |
| **REST API** | 75+ endpoints for remote scanning and integration |
| **Reports** | HTML, JUnit XML, SARIF, CSV, compliance reports, trust center |
| **Continuous Monitoring** | `sentrik watch` — file-change detection and periodic scanning |
| **Confidence Scoring** | Variable confidence based on code context; opt-in LLM re-scoring (provider-agnostic: Anthropic, OpenAI, Ollama) |
| **VS Code / Cursor** | Auto-scan on save, inline findings, zero setup |

## Installation

```bash
npm install -g sentrik
```

Downloads a platform-specific binary. No Python, no Docker, no extra dependencies. Works on macOS, Linux, and Windows.

## CI/CD Integration

### GitHub Actions

```yaml
- name: sentrik Gate
  run: |
    npm install -g sentrik
    sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

### Azure Pipelines

```yaml
- script: |
    npm install -g sentrik
    sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
  env:
    AZURE_DEVOPS_PAT: $(AZURE_DEVOPS_PAT)
```

### GitLab CI

```yaml
sentrik-gate:
  stage: compliance
  image: python:3.12-slim
  before_script:
    - pip install sentrik
  script:
    - sentrik gate --git-range "origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME...HEAD"
  artifacts:
    reports:
      junit: out/findings.junit.xml
```

## Management Dashboard

Start the API server and open the dashboard:

```bash
sentrik dashboard
```

The dashboard provides:
- Scan metrics and severity charts
- Searchable/filterable rule browser
- Standards pack management
- Work items with DevOps sync
- Governance policy configuration
- Audit log timeline

## Enterprise Features

Unlock advanced capabilities with a license key from [sentrik.dev](https://sentrik.dev):

```bash
sentrik license    # Check your current license status
```

| Feature | Community (Free) | Team ($29/mo) | Organization ($99/mo) | Enterprise ($299/mo) |
|---------|:----------------:|:-------------:|:---------------------:|:--------------------:|
| Scan, gate, reconcile | Yes | Yes | Yes | Yes |
| Dashboard + API | Yes | Yes | Yes | Yes |
| Standards packs | Yes | Yes | Yes | Yes |
| Priority support | - | Yes | Yes | Yes |
| Parallel scanning | - | - | Yes | Yes |
| Severity rescoring | - | - | Yes | Yes |
| OAuth integration | - | - | Yes | Yes |
| Governance profiles | - | - | - | Yes |
| Audit logging | - | - | - | Yes |
| Async approval gates | - | - | - | Yes |
| Custom standards packs | - | - | - | Yes |

## Configuration

sentrik auto-detects your project and works without config. To customize, create `.sentrik/config.yaml`:

```yaml
output_dir: out
standards_packs:
  - owasp-top-10
gate_fail_on:
  - critical
  - high
reporters:
  - html
  - sarif
devops_provider: github           # stub, azure, github, jira
```

Legacy `.guard.yaml` files are still supported. Migrate with `sentrik migrate`.

Environment variables override config values — see [documentation](https://docs.sentrik.dev) for the full list.

## Standards Packs

```bash
sentrik list-packs                  # See available packs
sentrik add-pack fda-iec-62304      # Enable a pack
sentrik add-pack owasp-top-10       # Enable another
```

| Pack | Rules | Standard |
|------|-------|----------|
| `fda-iec-62304` | 31 | IEC 62304 / 21 CFR Part 11 |
| `owasp-top-10` | 69 | OWASP Top 10 2021 |
| `soc2` | 30 | SOC2 Trust Services Criteria |
| `hipaa` | 25 | HIPAA Security Rule |
| `pci-dss` | 33 | PCI DSS v4.0 |
| `iso-27001` | 32 | ISO 27001:2022 |
| `php-security` | 15 | PHP/Laravel Security |
| `kotlin-security` | 13 | Kotlin/Android/Spring Boot |

## Links

- [Website](https://sentrik.dev)
- [Documentation](https://docs.sentrik.dev)
- [npm](https://www.npmjs.com/package/sentrik)
- [Community](https://github.com/maxgerhardson/sentrik-community)

## License

Proprietary. See [LICENSE](LICENSE) for details.
Free tier available with no limits on core features.
