#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# AI SDLC Guard — Sprint Governance Demo
# Sprint 23: "User Authentication" (WI-101, WI-102)
# ──────────────────────────────────────────────────────────────
set -euo pipefail

# ── Colour helpers ────────────────────────────────────────────
GREEN='\033[1;32m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
BOLD='\033[1m'
RESET='\033[0m'

banner() {
  echo ""
  echo -e "${GREEN}═══════════════════════════════════════════════════════════${RESET}"
  echo -e "${GREEN}  $1${RESET}"
  echo -e "${GREEN}═══════════════════════════════════════════════════════════${RESET}"
  echo ""
}

info()  { echo -e "${CYAN}▸ $1${RESET}"; }
warn()  { echo -e "${YELLOW}▸ $1${RESET}"; }
err()   { echo -e "${RED}▸ $1${RESET}"; }

pause() {
  echo ""
  read -r -p "  Press Enter to continue…"
  echo ""
}

# ── Resolve project root ─────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

CONFIG="demo/.guard.yaml"
BRANCH="feature/WI-101-WI-102-sprint23"

# ── Locate the guard/sentra command ──────────────────────────
if command -v sentra &>/dev/null; then
  GUARD=sentra
elif command -v guard &>/dev/null; then
  GUARD=guard
else
  err "Could not find 'sentra' command. Install with: npm install -g sentra"
  exit 1
fi
info "Using: $GUARD"

# ── Cleanup function (restores original files) ───────────────
cleanup() {
  info "Restoring original demo source files…"
  cp demo/src/auth_fixed.py demo/src/auth_fixed.py.bak 2>/dev/null || true
  cp demo/src/signup_fixed.py demo/src/signup_fixed.py.bak 2>/dev/null || true

  # Restore the "bad" versions so the demo is re-runnable
  cat > demo/src/auth.py << 'PYEOF'
import hashlib

# TODO: Replace with proper JWT library (WI-101)
def login(username, password):
    API_KEY = "sk-secret-key-12345"
    print(f"Login attempt: {username}")
    if username == "admin" and password == "admin123":
        token = hashlib.sha256(f"{username}:{API_KEY}".encode()).hexdigest()
        print(f"Generated token: {token}")
        return {"token": token, "expires_in": 3600}
    return {"error": "Invalid credentials"}
PYEOF

  cat > demo/src/signup.py << 'PYEOF'
import re

# TODO: Add password strength validation (WI-102)
def validate_signup(email, password):
    print(f"Validating signup for {email}")
    errors = []
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        errors.append("Invalid email format")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters")
        print("Password too short")
    return errors
PYEOF

  # Restore fixed files from backup
  mv demo/src/auth_fixed.py.bak demo/src/auth_fixed.py 2>/dev/null || true
  mv demo/src/signup_fixed.py.bak demo/src/signup_fixed.py 2>/dev/null || true

  # Clean output directory
  rm -rf demo/out
  info "Cleanup complete — demo is re-runnable."
}
trap cleanup EXIT

# ══════════════════════════════════════════════════════════════
banner "PHASE 1: Sprint Planning"
# ══════════════════════════════════════════════════════════════

info "Sprint 23 — \"User Authentication\""
info "Work items for this sprint:"
echo ""
cat demo/sprint_backlog.json
echo ""

pause

info "Standards / rules configured for this project:"
echo ""
$GUARD list-rules --config "$CONFIG"
echo ""

pause

info "Generating agent context (work items + rules + commands)…"
$GUARD context --config "$CONFIG"
echo ""
info "Agent context written — an AI coding agent would read this before starting work."

pause

# ══════════════════════════════════════════════════════════════
banner "PHASE 2: Initial Code Scan"
# ══════════════════════════════════════════════════════════════

info "The AI agent has written initial code for WI-101 and WI-102."
info "Let's review what it produced:"
echo ""

echo -e "${BOLD}── demo/src/auth.py ──${RESET}"
cat demo/src/auth.py
echo ""
echo -e "${BOLD}── demo/src/signup.py ──${RESET}"
cat demo/src/signup.py
echo ""

warn "Notice: hardcoded API_KEY, print() calls, TODO comments, missing docstrings."

pause

info "Running guard scan…"
echo ""
$GUARD scan --config "$CONFIG" --branch "$BRANCH"
echo ""

info "Saving initial findings as baseline for later comparison…"
cp demo/out/findings.json demo/out/findings_initial.json

pause

info "Running quality gate…"
echo ""
# Gate will exit 1 on failure — capture it
if $GUARD gate --config "$CONFIG" --branch "$BRANCH"; then
  info "Gate passed (unexpected in this phase)."
else
  err "Gate FAILED — critical findings block the sprint."
fi
echo ""

pause

# ══════════════════════════════════════════════════════════════
banner "PHASE 3: Auto-Fix"
# ══════════════════════════════════════════════════════════════

info "Guard generated patches for auto-fixable findings."
info "Applying patches (removes print statements, comments out TODOs)…"
echo ""
$GUARD apply-patches --config "$CONFIG"
echo ""

info "Code after auto-fix:"
echo ""
echo -e "${BOLD}── demo/src/auth.py (after auto-fix) ──${RESET}"
cat demo/src/auth.py
echo ""
echo -e "${BOLD}── demo/src/signup.py (after auto-fix) ──${RESET}"
cat demo/src/signup.py
echo ""

warn "Auto-fix handled low/medium issues, but the CRITICAL hardcoded secret remains."
warn "That requires a developer to fix manually."

pause

# ══════════════════════════════════════════════════════════════
banner "PHASE 4: Manual Fixes"
# ══════════════════════════════════════════════════════════════

info "Developer reviews the remaining findings and fixes the code:"
info "  - Removes hardcoded API_KEY, reads from environment instead"
info "  - Adds module docstrings"
info "  - Cleans up any remaining issues"
echo ""

cp demo/src/auth_fixed.py demo/src/auth.py
cp demo/src/signup_fixed.py demo/src/signup.py

echo -e "${BOLD}── demo/src/auth.py (manually fixed) ──${RESET}"
cat demo/src/auth.py
echo ""
echo -e "${BOLD}── demo/src/signup.py (manually fixed) ──${RESET}"
cat demo/src/signup.py
echo ""

info "All issues addressed. Let's verify."

pause

# ══════════════════════════════════════════════════════════════
banner "PHASE 5: Rescan & Gate"
# ══════════════════════════════════════════════════════════════

info "Running guard scan on the fixed code…"
echo ""
$GUARD scan --config "$CONFIG" --branch "$BRANCH"
echo ""

pause

info "Comparing against initial findings…"
echo ""
$GUARD compare --config "$CONFIG" --previous demo/out/findings_initial.json
echo ""

pause

info "Running quality gate…"
echo ""
if $GUARD gate --config "$CONFIG" --branch "$BRANCH"; then
  echo ""
  info "Gate PASSED — all critical/high findings resolved!"
else
  echo ""
  err "Gate still failing (unexpected at this point)."
fi
echo ""

pause

# ══════════════════════════════════════════════════════════════
banner "PHASE 6: Sprint Review"
# ══════════════════════════════════════════════════════════════

info "Sprint 23 governance summary:"
echo ""

if [ -f demo/out/comparison.md ]; then
  echo -e "${BOLD}── Comparison Report ──${RESET}"
  cat demo/out/comparison.md
  echo ""
fi

if [ -f demo/out/report.html ]; then
  info "HTML report available at: demo/out/report.html"
fi

if [ -f demo/out/agent_context.json ]; then
  info "Agent context available at: demo/out/agent_context.json"
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════${RESET}"
echo -e "${GREEN}  Demo complete!${RESET}"
echo -e "${GREEN}${RESET}"
echo -e "${GREEN}  Sprint 23 — User Authentication${RESET}"
echo -e "${GREEN}  Work Items: WI-101, WI-102${RESET}"
echo -e "${GREEN}  Initial scan: violations found (gate FAILED)${RESET}"
echo -e "${GREEN}  Auto-fix: print statements + TODOs handled${RESET}"
echo -e "${GREEN}  Manual fix: hardcoded secret removed${RESET}"
echo -e "${GREEN}  Final scan: all issues resolved (gate PASSED)${RESET}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${RESET}"
echo ""
