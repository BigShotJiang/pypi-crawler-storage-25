"""Export to FHIR R4 format.

Requirement: REQ-003 — Export to FHIR format
IEC 62304 Class: B
"""

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


def to_fhir_patient(record: dict[str, Any]) -> dict[str, Any]:
    """Convert an anonymized record to a FHIR R4 Patient resource.

    Args:
        record: Anonymized patient record.

    Returns:
        FHIR R4 Patient resource as a dictionary.
    """
    if not record.get("anon_id"):
        raise ValueError("Record missing anon_id — was it anonymized?")

    resource = {
        "resourceType": "Patient",
        "id": record["anon_id"],
        "identifier": [
            {
                "system": "urn:medfiles:anon",
                "value": record["anon_id"],
            }
        ],
        "active": True,
    }

    # Map optional fields
    if "diagnosis_code" in record:
        resource["extension"] = [
            {
                "url": "urn:medfiles:diagnosis",
                "valueString": record["diagnosis_code"],
            }
        ]

    return resource


def export_bundle(records: list[dict[str, Any]], output_path: str) -> str:
    """Export a list of records as a FHIR Bundle.

    Args:
        records: List of anonymized patient records.
        output_path: Path to write the FHIR JSON file.

    Returns:
        Path to the written file.
    """
    bundle = {
        "resourceType": "Bundle",
        "type": "collection",
        "entry": [
            {"resource": to_fhir_patient(r)} for r in records
        ],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(bundle, f, indent=2)

    logger.info("Exported %d patients to %s", len(records), output_path)
    return output_path
