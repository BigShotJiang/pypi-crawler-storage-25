"""Patient data ingestion module.

Requirement: REQ-001 — Patient data ingestion pipeline
IEC 62304 Class: B
"""

import csv
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def load_patient_csv(filepath: str) -> list[dict[str, Any]]:
    """Load patient records from a CSV file.

    Args:
        filepath: Path to the CSV file.

    Returns:
        List of patient record dictionaries.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Patient file not found: {filepath}")

    records: list[dict[str, Any]] = []
    with open(path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if not _validate_patient_id(row.get("patient_id", "")):
                logger.warning("Invalid patient ID in row: %s", row)
                continue
            records.append(dict(row))

    logger.info("Loaded %d patient records from %s", len(records), filepath)
    return records


def _validate_patient_id(patient_id: str) -> bool:
    """Validate patient ID format (PAT-NNNN)."""
    if not patient_id:
        return False
    if not patient_id.startswith("PAT-"):
        return False
    suffix = patient_id[4:]
    return suffix.isdigit() and len(suffix) == 4
