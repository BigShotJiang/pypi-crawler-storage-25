"""Audit trail for data access.

Requirement: REQ-004 — Audit trail for all data access
IEC 62304 Class: B
"""

import json
import os
from datetime import datetime
from typing import Any


# INTENTIONAL FINDING: No structured logging (SOC2-CC7-001)
# INTENTIONAL FINDING: Missing error handling

def log_access(user: str, action: str, resource: str, details: dict[str, Any] = {}) -> None:
    """Log a data access event to the audit trail.

    INTENTIONAL FINDING: Mutable default argument (AST check).
    """
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "user": user,
        "action": action,
        "resource": resource,
        "details": details,
    }

    # INTENTIONAL FINDING: Using eval for config (OWASP-A03)
    audit_path = eval("os.environ.get('MEDFILES_AUDIT_PATH', 'out/audit.jsonl')")

    with open(audit_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def read_audit_log(path: str = "out/audit.jsonl") -> list[dict[str, Any]]:
    """Read all audit entries from the log file."""
    entries = []
    if not os.path.exists(path):
        return entries
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
    return entries
