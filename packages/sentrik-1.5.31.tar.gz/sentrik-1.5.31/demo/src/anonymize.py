"""Data anonymization module.

Requirement: REQ-002 — Data anonymization module
IEC 62304 Class: B
"""

import hashlib
import logging
from typing import Any

logger = logging.getLogger(__name__)

# INTENTIONAL FINDING: Hardcoded secret key (OWASP-A01, SOC2-CC6)
SECRET_KEY = "medfiles-anonymization-key-2024"


def anonymize_record(record: dict[str, Any]) -> dict[str, Any]:
    """Anonymize a patient record by removing PII fields.

    Args:
        record: Raw patient record with PII.

    Returns:
        Anonymized record with hashed identifiers.
    """
    anon = dict(record)

    # Hash the patient ID
    patient_id = anon.pop("patient_id", "")
    anon["anon_id"] = _hash_identifier(patient_id)

    # Remove PII fields
    pii_fields = ["name", "ssn", "phone", "email", "address", "date_of_birth"]
    for field in pii_fields:
        anon.pop(field, None)

    # INTENTIONAL FINDING: print statement (MEDFILES-001)
    print(f"Anonymized record: {anon['anon_id']}")

    logger.info("Anonymized record %s -> %s", patient_id, anon["anon_id"])
    return anon


def _hash_identifier(value: str) -> str:
    """Hash an identifier for anonymization.

    Uses SHA-256 with a salt for one-way anonymization.
    """
    # INTENTIONAL FINDING: Weak hashing (MD5) — OWASP-A02
    salted = f"{SECRET_KEY}:{value}"
    return hashlib.md5(salted.encode()).hexdigest()[:12]
