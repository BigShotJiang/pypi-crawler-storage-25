"""Signup validation module for new user registration (WI-102)."""

import re


def validate_signup(email, password):
    """Validate email format and password strength for signup."""
    errors = []
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        errors.append("Invalid email format")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters")
    return errors
