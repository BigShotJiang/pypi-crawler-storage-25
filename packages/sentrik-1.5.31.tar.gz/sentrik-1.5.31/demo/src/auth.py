import hashlib

# TODO: Replace with proper JWT library (WI-101)
def login(username, password):
    API_KEY = "sk-secret-key-12345"
    print(f"Login attempt: {username}")
    if username == "admin" and password == "admin123":
        token = hashlib.sha256(f"{username}:{API_KEY}".encode()).hexdigest()
        print(f"Generated token: {token}")
        return {"token": token, "expires_in": 3600}
    return {"error": "Invalid credentials"}
