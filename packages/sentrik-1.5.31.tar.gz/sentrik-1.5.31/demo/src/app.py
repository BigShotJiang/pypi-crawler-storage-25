"""MedFiles main application.

Requirement: REQ-001 — Patient data ingestion pipeline
IEC 62304 Class: B
"""

import sys

from src.ingest import load_patient_csv
from src.anonymize import anonymize_record
from src.export_fhir import export_bundle
from src.audit import log_access


def main():
    """Run the MedFiles pipeline: ingest -> anonymize -> export."""
    if len(sys.argv) < 2:
        print("Usage: python -m src.app <input.csv> [output.json]")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "out/fhir_bundle.json"

    # Ingest
    log_access("system", "ingest", input_path)
    records = load_patient_csv(input_path)

    # Anonymize
    log_access("system", "anonymize", f"{len(records)} records")
    anonymized = [anonymize_record(r) for r in records]

    # Export
    log_access("system", "export", output_path)
    export_bundle(anonymized, output_path)

    print(f"Pipeline complete: {len(anonymized)} records -> {output_path}")


if __name__ == "__main__":
    main()
