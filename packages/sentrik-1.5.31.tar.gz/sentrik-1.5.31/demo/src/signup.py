import re

# TODO: Add password strength validation (WI-102)
def validate_signup(email, password):
    print(f"Validating signup for {email}")
    errors = []
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        errors.append("Invalid email format")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters")
        print("Password too short")
    return errors
