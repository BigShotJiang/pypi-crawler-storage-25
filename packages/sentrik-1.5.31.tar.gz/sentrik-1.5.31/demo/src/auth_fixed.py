"""Authentication module for user login (WI-101)."""

import hashlib
import os


def login(username, password):
    """Authenticate a user and return a JWT-style token."""
    api_key = os.environ.get("API_KEY", "")
    if username == "admin" and password == "admin123":
        token = hashlib.sha256(f"{username}:{api_key}".encode()).hexdigest()
        return {"token": token, "expires_in": 3600}
    return {"error": "Invalid credentials"}
