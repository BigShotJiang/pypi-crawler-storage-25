"""MedFiles — Medical device data processing pipeline.

Requirement: REQ-001 — Patient data ingestion
IEC 62304 Class: B
"""
