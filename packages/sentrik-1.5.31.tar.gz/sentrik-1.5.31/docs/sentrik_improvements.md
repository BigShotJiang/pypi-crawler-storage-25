Sentrik Platform Improvements
Context
These improvements address a critical gap in the AI-assisted development landscape: as agentic coding tools generate more code faster, developers increasingly lose visibility into the design decisions, architectural choices, and quality tradeoffs embedded in that code. Current Sentrik capabilities catch violations (security, compliance, supply chain). These new features catch suboptimal decisions that technically pass all rules — the "deceptively acceptable" code that ships without anyone questioning whether it was the right approach.
Reference: LinkedIn post by Sagnik Nandy (CTO, Docusign) describing the accountability gap in agentic coding.

Feature 1: Design Decision Auditing
Problem
AI agents make hundreds of implicit design decisions — framework choices, data structure selection, auth patterns, state management approaches, API design tradeoffs. These decisions are never surfaced to the developer. When something goes wrong later, nobody knows why the code was structured that way.
What to build
A new sentrik review-design command and corresponding MCP tool that identifies and surfaces significant design decisions made by AI-generated code, presented as questions for the developer rather than pass/fail findings.
CLI interface
bash# Review design decisions in recent changes
sentrik review-design --git-range origin/main...HEAD

# Review a specific file
sentrik review-design --file src/auth/session.py

# Output as structured JSON for dashboard consumption
sentrik review-design --git-range origin/main...HEAD --json
Output format
Each decision should include:

Decision ID — unique identifier (e.g., DD-001)
Category — one of: architecture, data-model, security-pattern, dependency-choice, performance-tradeoff, error-handling, state-management
Summary — one-line description of the decision (e.g., "Auth implemented with custom JWT signing instead of using passport.js")
File and line range — where the decision is expressed in code
Alternatives — 2-3 alternatives that a senior engineer might have considered
Risk assessment — what could go wrong with this choice at scale or over time
Question for developer — a specific question to prompt review (e.g., "Is custom JWT signing intentional here, or would you prefer an established auth library?")

MCP tool
Add a review_design_decisions tool to the MCP server:

Input: file_path (string) or git_range (string)
Returns: Array of design decision objects as described above

Implementation notes

This requires LLM analysis — regex/AST won't work for identifying design decisions. Use the existing GUARD_LLM_PROVIDER configuration.
Analyze the diff, not just individual files. Design decisions often span multiple files.
Use the project's existing code as context — the LLM should compare the new code against established patterns in the repo.
Cache results per commit SHA to avoid re-analysis.
Integrate into the dashboard as a new "Design Review" tab alongside Findings.
Design decisions should NOT block the gate by default. They are informational. Add an optional config to require acknowledgment before merge:

yamlgovernance:
  design_review:
    enabled: true
    require_acknowledgment: true  # Developer must acknowledge decisions before merge
    categories: [architecture, security-pattern, dependency-choice]  # Which categories to surface
Dashboard integration
Add a "Design Decisions" tab to the dashboard showing:

Unacknowledged decisions (filterable by category)
Decision history with developer acknowledgments
Trends: how many decisions are being made by AI vs. explicitly by developers over time


Feature 2: Proactive MCP Design Constraints
Problem
The current MCP flow is reactive: AI generates code, then Sentrik checks it. By the time Sentrik sees the code, the architectural choice is already baked in. The AI agent needs to know the project's design conventions before it starts generating code.
What to build
A new get_design_constraints MCP tool that provides architectural context, established patterns, and tech stack decisions to AI agents before they write code.
MCP tool
Add get_design_constraints to the MCP server:

Input: file_path (string) — the file the AI is about to create or modify, OR intent (string) — a description of what the AI is about to do (e.g., "add user authentication", "create a database migration")
Returns: JSON object with:

established_patterns — patterns already used in the codebase for similar functionality (e.g., "Auth in this project uses passport.js with JWT strategy — see src/auth/passport.ts")
tech_stack_constraints — libraries and frameworks the project uses, so the AI doesn't introduce conflicting ones (e.g., "This project uses React Query for data fetching — do not use SWR or raw fetch")
architectural_rules — from architecture.yaml if present, plus inferred module boundaries
adrs — any Architecture Decision Records found in the repo (look for docs/adr/, docs/decisions/, ADR-*.md patterns)
conventions — coding conventions inferred from existing code (naming patterns, file organization, error handling style)



How it works

On first scan (or when config changes), Sentrik builds a project profile by analyzing the codebase:

Detect frameworks and libraries in use (from manifests + import analysis)
Identify architectural patterns (MVC, repository pattern, service layer, etc.)
Parse any ADRs or CONVENTIONS.md files
Map module boundaries from the existing architecture.yaml or infer from directory structure


The profile is cached in out/project-profile.json and refreshed on each scan.
When the AI agent calls get_design_constraints, the relevant subset of the profile is returned based on the file path or intent.

CLI command
bash# Generate/refresh the project profile
sentrik profile

# View the current profile
sentrik profile --show

# View constraints for a specific area
sentrik profile --for src/auth/
Config
yamldesign_constraints:
  enabled: true
  profile_refresh: on_scan  # or: manual, on_commit
  adr_paths:
    - docs/adr/
    - docs/decisions/
  conventions_file: CONVENTIONS.md  # optional explicit conventions doc
  tech_stack_lock: true  # warn if AI introduces new frameworks not in the existing stack

Feature 3: Expertise-Gap Escalation
Problem
The biggest risk in agentic coding is when AI generates code outside the developer's area of expertise. A backend developer won't notice subtle frontend issues. A Python developer won't catch idiomatic problems in generated Rust. Sentrik currently treats all code equally regardless of who authored it or who's reviewing it.
What to build
A developer profile system that tracks each developer's strengths (from git history or explicit config) and escalates review requirements when AI-generated code falls outside their comfort zone.
Config
yamlexpertise_profiles:
  enabled: true
  source: git_history  # or: manual, both
  lookback_days: 180   # how far back to analyze git history
  escalation:
    mode: warn  # or: require_review, block
    threshold: 0.3  # if developer has < 30% of commits in this language/area, escalate

# Manual override (optional, supplements git analysis)
developers:
  - email: max@sentrik.dev
    strengths: [python, fastapi, postgresql, ci-cd]
    learning: [react, typescript]  # areas where they want extra review but not blocking
How it works

sentrik profile-devs analyzes git history to build per-developer profiles:

Languages they work in (by commit count and line count)
Directories/modules they typically touch
Frameworks they've used (detected from imports in their committed code)


During sentrik gate or sentrik scan --staged, if the current git user is known:

Compare the files being committed against the developer's profile
If the code is in a language or module the developer rarely touches, flag it


Flagged items appear as a new finding type: EXPERTISE-GAP-001 etc.

Severity: info by default (configurable to medium or high)
Message: "This TypeScript React component is outside your usual Python/backend work. Consider requesting review from a frontend team member."
These findings are separate from compliance findings — they appear in a distinct section



Gate integration
bash# Gate with expertise checks
sentrik gate --git-range origin/main...HEAD --check-expertise

# View developer profile
sentrik profile-devs --email max@sentrik.dev
Dashboard integration
Add an "Expertise Coverage" widget to the Overview tab showing:

Percentage of recent AI-generated code that falls within vs. outside developer expertise
Which areas are most frequently outside expertise (helping team leads identify training needs)


Feature 4: Quality Gradient Scoring
Problem
Sentrik's gate is binary: pass or fail. But there's a huge quality difference between code that barely passes and code that's well-engineered. Teams using AI agents need visibility into whether their overall code quality is trending toward "90% as good as it could be" or staying at a high bar.
What to build
A sentrik quality-score command that evaluates code quality on a continuous 0-100 scale across multiple dimensions, with trending over time.
Scoring dimensions
Each dimension is scored 0-100 independently, then weighted into an overall score:
DimensionWeightWhat it measuresCompliance25%Existing Sentrik findings (inverse of finding density)Complexity20%From sentrik metrics — cyclomatic complexity, nesting depth, function lengthTest coverage15%Ratio of test files to source files, test assertions per functionDocumentation10%Docstring/comment coverage, README completeness, API documentationConsistency15%Naming convention adherence, code style uniformity, pattern consistencyDependency health15%From sentrik vulns and sentrik licenses — vuln count, outdated deps, license risk
CLI interface
bash# Overall quality score
sentrik quality-score

# Quality score for specific files/directories
sentrik quality-score --path src/auth/

# Track quality over time (uses scan history)
sentrik quality-trend

# Quality score with breakdown
sentrik quality-score --verbose

# JSON output for automation
sentrik quality-score --json
Output example
Sentrik Quality Score: 78/100

  Compliance:       92/100  ████████████████████░░  (2 medium findings)
  Complexity:       71/100  ██████████████████░░░░  (3 functions over threshold)
  Test coverage:    65/100  █████████████████░░░░░  (12 untested source files)
  Documentation:    80/100  ████████████████████░░  (4 public functions undocumented)
  Consistency:      85/100  █████████████████████░  (minor naming inconsistencies)
  Dependency health: 76/100  ███████████████████░░░  (2 outdated, 1 low-risk vuln)

Trend: +3 from last scan (improving)
Config
yamlquality_scoring:
  enabled: true
  weights:
    compliance: 25
    complexity: 20
    test_coverage: 15
    documentation: 10
    consistency: 15
    dependency_health: 15
  thresholds:
    overall_minimum: 70  # optional: gate fails below this score
    complexity_max_cyclomatic: 15
    complexity_max_nesting: 4
    function_max_lines: 50
Gate integration
Optionally fail the gate on quality score:
bashsentrik gate --git-range origin/main...HEAD --min-quality 70
Dashboard integration

Add a quality score gauge to the Overview tab
Add a "Quality Trend" chart alongside the existing "Finding Trends" chart
Per-file quality breakdown in the Findings tab


Feature 5: Review Attestation Workflow
Problem
As AI generates more code, there's a risk that developers rubber-stamp PRs without engaging with the decisions the AI made. The existing sentrik attest command provides cryptographic proof that a scan happened, but not that a human actually reviewed and understood the AI's decisions.
What to build
Extend the attestation system to include a "design review attestation" where developers must acknowledge specific AI-generated design decisions before merging.
How it works

During sentrik gate, if design_review.require_acknowledgment is enabled:

The gate identifies design decisions (from Feature 1)
The gate outputs a list of decisions requiring acknowledgment
The gate exits with code 2 (new exit code: "pending acknowledgment") instead of 0 or 1


The developer reviews the decisions and acknowledges them:

bash   # List pending acknowledgments
   sentrik review --pending

   # Acknowledge a specific decision
   sentrik review --ack DD-001 --note "Custom JWT is intentional — we need non-standard claims"

   # Acknowledge all decisions (with confirmation prompt)
   sentrik review --ack-all

   # Reject a decision (flags for rework)
   sentrik review --reject DD-003 --note "Switch to passport.js instead"

Acknowledgments are stored in out/attestations/ as signed JSON alongside the compliance attestation.
The gate re-runs and passes once all required decisions are acknowledged.

PR integration
When --decorate-pr is used with the gate:

The PR comment includes a "Design Decisions" section listing each decision
Each decision has a checkbox
Developers check the boxes in the PR comment to acknowledge (Sentrik reads the checkbox state via the GitHub/Azure DevOps API)
The status check stays pending until all checkboxes are checked

Config
yamlgovernance:
  design_review:
    enabled: true
    require_acknowledgment: true
    categories: [architecture, security-pattern, dependency-choice]
    exempt_paths:
      - "test/**"
      - "docs/**"
      - "*.md"
    auto_acknowledge:
      max_severity: low  # auto-ack low-impact decisions
Exit codes
Update the gate exit codes:
CodeMeaning0Gate passed, all decisions acknowledged1Gate failed (compliance findings above threshold)2Gate passed compliance but has pending design acknowledgments
Dashboard integration
Add an "Approvals" section (extend the existing Enterprise Approvals tab) that shows:

Pending design acknowledgments per PR/branch
Acknowledgment history with developer notes
Metrics: average time to acknowledge, rejection rate, most common decision categories


Implementation Priority
Implement in this order based on impact and dependency chain:

Feature 2: Proactive MCP Design Constraints — Foundation for everything else. The project profile it builds is used by Features 1, 3, and 4.
Feature 1: Design Decision Auditing — The highest-impact feature. Requires the project profile from Feature 2 and LLM integration.
Feature 4: Quality Gradient Scoring — Largely independent, builds on existing sentrik metrics and sentrik vulns. Can be developed in parallel with Feature 1.
Feature 3: Expertise-Gap Escalation — Requires git history analysis. Medium complexity.
Feature 5: Review Attestation Workflow — Depends on Feature 1 (design decisions) being complete. Last in sequence but critical for closing the accountability loop.

Technical Dependencies

Features 1, 2, and 3 require LLM integration (already supported via GUARD_LLM_PROVIDER)
Feature 2 requires new static analysis for pattern detection (framework inference, ADR parsing)
Feature 3 requires git log analysis (new capability)
Feature 4 mostly composes existing commands (metrics, vulns, licenses, scan findings)
Feature 5 requires extending the gate exit code system and PR decoration logic