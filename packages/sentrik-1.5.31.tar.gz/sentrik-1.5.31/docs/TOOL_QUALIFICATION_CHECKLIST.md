# sentrik Tool Qualification Checklist

**Reference Document:** sentrik-TQR-001 (TOOL_QUALIFICATION.md)
**Checklist Revision:** 1.0
**Date:** 2026-03-20

---

This checklist supports the qualification of sentrik as a software development tool per IEC 62304:2006+AMD1:2015 Section 8.1 and ISO 26262:2018 Part 8 Section 11. Complete all sections before citing sentrik as a qualified tool in your quality management system.

---

## 1. Project Information

| Field                                    | Value              |
|------------------------------------------|--------------------|
| Project name                             | _________________  |
| Product name                             | _________________  |
| Product class (IEC 62304)                | [ ] A  [ ] B  [ ] C |
| Safety integrity level (ISO 26262)       | [ ] QM  [ ] ASIL A  [ ] ASIL B  [ ] ASIL C  [ ] ASIL D |
| Applicable regulatory framework(s)       | _________________  |
| Quality management system reference      | _________________  |
| Responsible quality engineer             | _________________  |

---

## 2. Tool Configuration Record

| Field                                    | Value              |
|------------------------------------------|--------------------|
| sentrik version                          | _________________  |
| Installation method                      | [ ] pip  [ ] npm  [ ] Docker  [ ] standalone binary |
| Operating system and version             | _________________  |
| Python version                           | _________________  |
| Configuration file location              | [ ] `.sentrik/config.yaml`  [ ] `.guard.yaml`  [ ] Environment variables only |

### 2.1 Standards Packs Enabled

| Pack             | Enabled | Standard Reference            |
|------------------|---------|-------------------------------|
| fda-iec-62304    | [ ]     | IEC 62304 / 21 CFR Part 11    |
| owasp-top-10     | [ ]     | OWASP Top 10 2021             |
| soc2             | [ ]     | SOC 2 Trust Services Criteria |
| hipaa            | [ ]     | HIPAA 45 CFR Part 164         |
| pci-dss          | [ ]     | PCI DSS v4.0                  |
| iso-27001        | [ ]     | ISO/IEC 27001:2022 Annex A    |

### 2.2 Custom Configuration

| Item                                       | Response           |
|--------------------------------------------|--------------------|
| Custom rules added                         | [ ] Yes  [ ] No    |
| If yes, number of custom rules             | _________________  |
| Custom rules documented and reviewed       | [ ] Yes  [ ] N/A   |
| Governance profile                         | [ ] strict  [ ] standard  [ ] permissive  [ ] custom |
| Gate fail-on severities                    | _________________  |
| Files or directories excluded from scan    | _________________  |

### 2.3 Non-Deterministic Features

| Feature                                    | Status             |
|--------------------------------------------|--------------------|
| LLM confidence rescoring enabled           | [ ] Yes  [ ] No    |
| Auto-patching enabled                      | [ ] Yes  [ ] No    |
| SBOM/OSV vulnerability scanning used       | [ ] Yes  [ ] No    |

> **Note:** If any non-deterministic feature is enabled, it is **excluded from the tool qualification scope**. Findings produced or modified by non-deterministic features must not be cited as qualified tool output in regulatory submissions. Document this exclusion in your V&V plan.

---

## 3. Tool Classification Verification

### 3.1 IEC 62304 Classification

- [ ] Tool is used in the development of medical device software (Section 8.1 applies)
- [ ] Tool output is verified by subsequent activities (Confidence Level 2 confirmed)
- [ ] Tool output verification activities are documented in the V&V plan

### 3.2 ISO 26262 Classification

- [ ] Tool Impact assessed: **TI 2** (can fail to detect errors, cannot introduce errors)
- [ ] Tool Error Detection assessed: **TD 2** (medium confidence in malfunction detection)
- [ ] Tool Confidence Level determined: **TCL 2** (per TI/TD matrix, Table 4)
- [ ] Qualification methods selected are sufficient for TCL 2:
  - [ ] Method 1: Increased confidence from use
  - [ ] Method 2: Evaluation of the tool development process
  - [ ] Method 3: Validation of the tool (optional, provides additional confidence)

---

## 4. Qualification Evidence Review

### 4.1 Test Suite Verification

- [ ] sentrik test suite passes (2,100+ tests) for the qualified version
- [ ] Test results reviewed and archived
- [ ] Test coverage meets minimum threshold (80%)

### 4.2 Deterministic Operation

- [ ] Deterministic operation confirmed: same input code and rule set produces identical findings
- [ ] Verification method: _________________
  - (e.g., "ran scan twice on identical codebase, compared output files")

### 4.3 Rule-to-Standard Traceability

- [ ] Rules in enabled standards packs map to specific regulatory clauses
- [ ] Traceability verified by reviewing `standard_ref` field in rule definitions
- [ ] Rule coverage is sufficient for the applicable regulatory requirements

### 4.4 Fail-Safe Behavior

- [ ] Confirmed: scan errors produce exit code 1 (gate blocks on failure)
- [ ] Confirmed: CI/CD pipeline treats non-zero exit code as step failure
- [ ] Confirmed: missing or invalid configuration causes gate failure (not silent pass)

### 4.5 Known Limitations

- [ ] Known limitations documented in sentrik-TQR-001 Section 4.3 reviewed
- [ ] Limitations accepted and compensating controls identified:

| Limitation                                        | Compensating Control                |
|---------------------------------------------------|-------------------------------------|
| Regex false positives in comments/strings         | ___________________________________ |
| No data flow analysis                             | ___________________________________ |
| Python-only AST analysis                          | ___________________________________ |
| No binary/compiled code analysis                  | ___________________________________ |
| External database dependency (SBOM scanning)      | ___________________________________ |

---

## 5. Residual Risk Assessment

- [ ] False positive risk assessed and accepted (impact: developer effort, no safety impact)
- [ ] False negative risk assessed and mitigated by other V&V activities
- [ ] Tool failure risk assessed (fail-safe design confirmed)
- [ ] Configuration error risk assessed (validation command available, config under version control)
- [ ] Residual risks documented in project risk management file

---

## 6. Integration into Quality Management System

- [ ] sentrik is listed as a qualified tool in the project's software development plan
- [ ] Tool version is recorded in the project's tool inventory / configuration management plan
- [ ] sentrik scan results are included as V&V evidence in the verification report
- [ ] Compliance reports are archived per document retention policy
- [ ] Audit trail output is preserved for regulatory review
- [ ] Re-qualification triggers are documented (see sentrik-TQR-001 Section 8.1)

---

## 7. Deployment Verification

- [ ] sentrik is deployed in the intended operating environment (see Section 2)
- [ ] Operating environment matches or is equivalent to the validation environment
- [ ] Deployment mode documented: [ ] CLI  [ ] CI/CD  [ ] Pre-commit  [ ] Docker  [ ] REST API  [ ] VS Code Extension
- [ ] CI/CD pipeline configuration reviewed and tested

---

## 8. Approval

| Role                        | Name            | Signature       | Date            |
|-----------------------------|-----------------|-----------------|-----------------|
| Quality Engineer            | _______________ | _______________ | _______________ |
| Software Development Lead   | _______________ | _______________ | _______________ |
| Regulatory Affairs (if applicable) | _______________ | _______________ | _______________ |

---

## 9. Qualification Maintenance

| Field                                    | Value              |
|------------------------------------------|--------------------|
| Qualification date                       | _________________  |
| Qualified sentrik version                | _________________  |
| Next scheduled review date               | _________________  |
| Re-qualification criteria                | Per sentrik-TQR-001 Section 8.1 |

### Qualification Review Log

| Date       | Reviewer        | sentrik Version | Action Taken                  |
|------------|-----------------|-----------------|-------------------------------|
| __________ | _______________ | _______________ | _____________________________ |
| __________ | _______________ | _______________ | _____________________________ |
| __________ | _______________ | _______________ | _____________________________ |

---

*End of Checklist*
