# Sentrik Manual Test Plan

Comprehensive manual test plan for release readiness. Tests are organized by area and priority. Execute on the demo project (`sentrik-demo-medapi`) unless noted otherwise.

**Priority levels:**
- **P0** — Must pass for release. Blocking.
- **P1** — Should pass. Important functionality.
- **P2** — Nice to have. Edge cases and polish.

---

## 1. Installation & Setup (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 1.1 | pip install | `pip install sentrik` in a fresh venv | Installs without errors, `sentrik` command available |
| 1.2 | npm install | `npm install -g sentrik` | Installs, `sentrik` command available |
| 1.3 | Version | `sentrik version` | Prints version number |
| 1.4 | Install check | `sentrik install-check` | Reports all dependencies OK |
| 1.5 | Auto-detect | `cd <project> && sentrik scan` (no config) | Auto-detects languages, creates out/ with findings |
| 1.6 | Init wizard | `sentrik init --no-interactive --mode developer` | Creates `.sentrik/config.yaml` with developer preset |
| 1.7 | Init compliance | `sentrik init --no-interactive --mode compliance` | Creates config with strict governance |
| 1.8 | Init CI | `sentrik init --no-interactive --mode ci` | Creates config optimized for CI |
| 1.9 | Validate config | `sentrik validate-config` | Reports valid or lists warnings |
| 1.10 | Migrate | Create `.guard.yaml`, run `sentrik migrate` | Creates `.sentrik/config.yaml` from legacy |

## 2. Core Scanning (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 2.1 | Full scan | `sentrik scan` | Findings written to `out/findings.json`, exit 0 |
| 2.2 | Scan staged | Stage a file, `sentrik scan --staged` | Only scans staged files |
| 2.3 | Scan git range | `sentrik scan --git-range HEAD~3..HEAD` | Only scans files in range |
| 2.4 | Actionable only | `sentrik scan --actionable-only` | Only shows findings with remediation |
| 2.5 | Output files | Check `out/` after scan | `findings.json`, `findings.html`, `scan_metrics.json` exist |
| 2.6 | Scan metrics | Read `out/scan_metrics.json` | Contains duration, rules count, cache stats |
| 2.7 | Gate pass | Run on clean code | Exit 0, "GATE PASSED" |
| 2.8 | Gate fail | Run on code with critical findings | Exit 1, "GATE FAILED", severity counts shown |
| 2.9 | Gate PR decoration | `sentrik gate --decorate-pr --git-range origin/main...HEAD` | PR comment posted (needs GitHub token) |
| 2.10 | Gate status check | `sentrik gate --status-check --commit-sha <sha>` | Status check created on GitHub |
| 2.11 | Remediation in CLI | Run scan, check top findings table | "Fix:" line shown under each finding with standard/clause |

## 3. Standards Packs (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 3.1 | List packs | `sentrik list-packs` | Shows 22 packs with tier and rule counts |
| 3.2 | Add pack | `sentrik add-pack gdpr` | Pack enabled, config updated |
| 3.3 | Remove pack | `sentrik remove-pack gdpr` | Pack disabled, config updated |
| 3.4 | Scan with OWASP | Enable owasp-top-10, scan | OWASP findings with clause references |
| 3.5 | Scan with HIPAA | Enable hipaa, scan | HIPAA findings (PHI in logs, etc.) |
| 3.6 | Scan with EU AI Act | Enable eu-ai-act, scan on ML project | AI-specific rules fire |
| 3.7 | Scan with GDPR | Enable gdpr, scan | PII rules fire (logs, encryption) |
| 3.8 | Scan with NIST 800-53 | Enable nist-800-53, scan | Federal security rules fire |
| 3.9 | Scan with CMMC | Enable cmmc, scan | Defense contractor rules fire |
| 3.10 | Multiple packs | Enable 5+ packs simultaneously, scan | All pack findings appear, no conflicts |
| 3.11 | Import spec | `sentrik import-spec openapi.yaml --enable` | Rules generated from API spec |
| 3.12 | Export pack | `sentrik export-pack owasp-top-10` | YAML file written |
| 3.13 | Diff packs | `sentrik diff-packs owasp-top-10 old.yaml` | Shows added/removed/changed rules |
| 3.14 | Gap analysis | `sentrik gap-analysis owasp-top-10 old.yaml` | Gap report with new obligations |

## 4. Supply Chain Security (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 4.1 | SBOM | `sentrik sbom` | CycloneDX SBOM in `out/sbom.json` |
| 4.2 | SBOM SPDX | `sentrik sbom --format spdx` | SPDX format output |
| 4.3 | Vuln scan | `sentrik vulns` | CVEs listed with severity |
| 4.4 | Vuln fix preview | `sentrik vulns --fix-preview` | Shows what would change |
| 4.5 | License scan | `sentrik licenses` | License types listed, copyleft flagged |
| 4.6 | Secrets scan | `sentrik secrets` | Hardcoded secrets detected |
| 4.7 | Secrets staged | `sentrik secrets --staged` | Only scans staged files |

## 5. Code Intelligence (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 5.1 | Quality score | `sentrik quality-score --verbose` | Score 0-100, all 6 dimensions shown |
| 5.2 | Quality threshold | `sentrik quality-score --min-quality 90` | Exit 1 if below threshold |
| 5.3 | Quality trend | Run quality-score twice, then `sentrik quality-trend` | Shows 2+ entries with trend direction |
| 5.4 | Quality JSON | `sentrik quality-score --verbose --json` | Valid JSON with dimensions |
| 5.5 | Profile build | `sentrik profile` | Detects languages, frameworks, patterns |
| 5.6 | Profile show | `sentrik profile --show` | Cached profile displayed |
| 5.7 | Profile constraints | `sentrik profile --for src/api/routes/patients.py` | File-specific constraints returned |
| 5.8 | Design review | `sentrik review-design --file src/api/routes/patients.py` | Decisions identified with categories (needs LLM) |
| 5.9 | Design pending | `sentrik review-design --pending` | Lists unacknowledged decisions |
| 5.10 | Design acknowledge | `sentrik review-design --ack DD-XXXXX --note "OK"` | Decision marked as acknowledged |
| 5.11 | Expertise profile | `sentrik check-expertise --profile` | Developer stats from git history |
| 5.12 | Expertise gaps | `sentrik check-expertise --git-range HEAD~5..HEAD` | Flags gaps or reports clean |
| 5.13 | Expertise threshold | `sentrik check-expertise --threshold 0.01` | More sensitive, flags more |
| 5.14 | Metrics | `sentrik metrics` | Per-file LOC, nesting, function counts |
| 5.15 | Compare | `sentrik compare` | Delta: new/resolved/unchanged counts |

## 6. Threat Modeling (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 6.1 | Threat model file | `sentrik threat-model --file src/api/routes/patients.py` | STRIDE threats identified (needs LLM) |
| 6.2 | Threat model range | `sentrik threat-model --git-range HEAD~3..HEAD` | Threats for recent changes |
| 6.3 | Threat pending | `sentrik threat-model --pending` | Lists unmitigated threats |
| 6.4 | Threat mitigate | `sentrik threat-model --mitigate TM-XXXXX --note "Fixed"` | Threat marked as mitigated |
| 6.5 | Threat filter | `sentrik threat-model --stride tampering` | Only tampering threats shown |
| 6.6 | Threat JSON | `sentrik threat-model --pending --json` | Valid JSON array |
| 6.7 | No LLM error | Unset API key, run `sentrik threat-model --file x.py` | Clear error: "requires LLM" |

## 7. Compliance & Reporting (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 7.1 | Report list | `sentrik compliance-report --list` | Frameworks from last scan listed |
| 7.2 | Single framework | `sentrik compliance-report -f "HIPAA"` | HTML report with clause-by-clause table |
| 7.3 | All frameworks | `sentrik compliance-report` | Combined report |
| 7.4 | History list | `sentrik history-report --list` | Past runs listed with IDs |
| 7.5 | History report | `sentrik history-report --run-id <ID>` | Report from historical data |
| 7.6 | Trust center | `sentrik trust-center --org "Test Corp"` | Public-safe HTML page |
| 7.7 | Trust center JSON | `sentrik trust-center --json` | JSON with scores, no code paths |
| 7.8 | Attestation | `sentrik attest` | Signed JSON with HMAC-SHA256 |
| 7.9 | Attestation verify | `sentrik attest --verify out/attestation.json` | "Signature is valid" |
| 7.10 | Evidence export | `sentrik evidence-export -f "SOC2"` | Evidence package generated |
| 7.11 | Risk summary | `sentrik risk-summary --org "Test Corp"` | HTML executive summary |
| 7.12 | Compliance trend | `sentrik compliance-trend` | Historical compliance scores |
| 7.13 | Next action | `sentrik next-action -n 5` | Top 5 fixable findings |
| 7.14 | Drift scan | `sentrik drift-scan` | Requirement drift analysis |

## 8. Dashboard — Core Tabs (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 8.1 | Start dashboard | `sentrik dashboard --port 8770` | Server starts, dashboard loads |
| 8.2 | Overview | Navigate to Overview tab | Compliance score, severity chart, gate status |
| 8.3 | Findings list | Navigate to Findings tab | Findings table with severity filters |
| 8.4 | Findings filter | Click severity pill (e.g., Critical) | Table filters to selected severity |
| 8.5 | Findings search | Type in search box | Results filter by search term |
| 8.6 | Finding detail | Click a finding row | Detail expands: file, line, code, remediation |
| 8.7 | Finding "Fix with AI" | Click "Fix with AI" on a finding | Chat panel opens with finding context |
| 8.8 | AI chat send | Type message in chat, click Send | AI responds with fix suggestion (needs LLM) |
| 8.9 | AI chat apply fix | Click "Apply Fix" on code block | Code applied to file |
| 8.10 | Vulnerabilities | Navigate to Vulns tab | CVE list with severity |
| 8.11 | History | Navigate to History tab | Past scan runs listed |
| 8.12 | History view report | Click "View Report" on a history entry | Historical report renders |

## 9. Dashboard — Compliance Tabs (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 9.1 | Rules browser | Navigate to Rules tab | Searchable rule list |
| 9.2 | Rules filter | Filter by severity/type/standard | Results update |
| 9.3 | Packs | Navigate to Packs tab | All 22 packs shown with toggle |
| 9.4 | Pack enable | Toggle a pack on | Pack enables, scan re-runs |
| 9.5 | Pack disable | Toggle a pack off | Pack disables |
| 9.6 | Reports | Navigate to Reports tab | Framework selection, generate button |
| 9.7 | Licenses | Navigate to Licenses tab | Dependency license list |

## 10. Dashboard — Intelligence Tabs (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 10.1 | Quality Score tab | Navigate to Quality Score | Ring chart with score, 6 dimension bars, history |
| 10.2 | Quality dimensions | Check all 6 dimensions | Compliance, complexity, test_coverage, documentation, consistency, dep_health |
| 10.3 | Profile tab | Navigate to Project Profile | Languages, frameworks, architecture, conventions, module map |
| 10.4 | Design tab | Navigate to Design Decisions | Decision cards with category badges |
| 10.5 | Design acknowledge | Click "Acknowledge" on a decision | Prompt for note, decision updates |
| 10.6 | Design badge | Check sidebar badge | Shows count of pending decisions |
| 10.7 | Expertise tab | Navigate to Expertise | Developer profiles with language/module bars |
| 10.8 | Threat tab | Navigate to Threat Model | Threat cards with STRIDE badges |
| 10.9 | Threat severity filter | Click Critical pill | Only critical threats shown, count label updates |
| 10.10 | Threat STRIDE filter | Select "Tampering" from dropdown | Only tampering threats shown |
| 10.11 | Threat status filter | Select "Unmitigated" | Only unmitigated threats shown |
| 10.12 | Threat search | Type in search box | Threats filter by description/component |
| 10.13 | Threat "Fix with AI" | Click "Fix with AI" on a threat | Chat panel opens with threat context |
| 10.14 | Threat mitigate | Click "Mark Mitigated" | Prompt for note, threat updates to mitigated |
| 10.15 | Threat badge | Check sidebar badge | Shows unmitigated count |
| 10.16 | Attestation tab | Navigate to Attestation | Gate status, metrics, signature shown |

## 11. Dashboard — Governance Tabs (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 11.1 | Policies | Navigate to Policies tab | Governance profile selector |
| 11.2 | Approvals | Navigate to Approvals tab | Approval list (may be empty) |
| 11.3 | Audit log | Navigate to Audit Log tab | Action timeline entries |
| 11.4 | Audit filter | Filter by action type | Results update |
| 11.5 | Audit export | Click "Export Audit Bundle" | ZIP download triggers |

## 12. Dashboard — Integration & Settings (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 12.1 | Work Items | Navigate to Work Items tab | Work item list from DevOps |
| 12.2 | Integration | Navigate to Integration tab | Provider selection (Azure/GitHub/Jira) |
| 12.3 | Test connection | Fill provider details, click "Test" | Connection success/failure message |
| 12.4 | Settings | Navigate to Settings tab | Full config displayed |
| 12.5 | AI config | Configure LLM provider in Settings | Provider saved, test connection works |

## 13. Dashboard — General (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 13.1 | Tab switching | Click each sidebar tab | Tab content loads correctly |
| 13.2 | Keyboard shortcuts | Press 1-9, 0 | Tabs switch |
| 13.3 | Dark/Light toggle | Click theme toggle | Theme switches, persists on reload |
| 13.4 | Mobile responsive | Resize to 768px | Sidebar collapses, content adapts |
| 13.5 | Onboarding | First visit (no prior scan) | Onboarding panel shows |
| 13.6 | Scan from dashboard | Click "Run Scan" button | Scan executes, findings refresh |
| 13.7 | Gate from dashboard | Click "Run Gate" button | Gate result shown |

## 14. REST API (P1)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 14.1 | Health check | `GET /health` | `{"status": "ok"}` |
| 14.2 | Metrics | `GET /api/metrics` | Scan metrics JSON |
| 14.3 | Findings | `GET /api/findings` | Findings array |
| 14.4 | Packs list | `GET /api/packs` | Packs with total count |
| 14.5 | Config | `GET /api/config` | Current config |
| 14.6 | Quality score | `GET /api/quality-score` | Score history array |
| 14.7 | Threat model | `GET /api/threat-model` | Threats array |
| 14.8 | Design decisions | `GET /api/design-decisions` | Decisions array |
| 14.9 | Attestation | `GET /api/attestation` | Attestation object |
| 14.10 | API key auth | Set `GUARD_API_KEY`, call without header | 401 Unauthorized |
| 14.11 | API key valid | Call with `X-API-Key` header | 200 OK |
| 14.12 | Rate limiting | Send 61 requests in 1 minute | 429 Too Many Requests |
| 14.13 | CORS headers | Check response headers | CORS headers present |

## 15. CI/CD Integration (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 15.1 | GitHub Actions | Push to repo with workflow | Gate runs, findings posted |
| 15.2 | Pre-commit hook | Stage file with violation, commit | Hook catches finding, blocks commit |
| 15.3 | SARIF output | `sentrik scan`, check `out/findings.sarif` | Valid SARIF file |
| 15.4 | JUnit output | Check `out/findings.junit.xml` | Valid JUnit XML |

## 16. Governance Features (P2)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 16.1 | Reconcile dry run | `sentrik reconcile --dry-run` | Shows what would happen, no API calls |
| 16.2 | Work item sync | `sentrik reconcile` (with DevOps configured) | Work items created/updated |
| 16.3 | Generate reqs | `sentrik generate-reqs --dry-run` | Requirements YAML generated |
| 16.4 | Verify reqs | `sentrik verify-reqs` | Coverage status per requirement |
| 16.5 | Pull reqs | `sentrik pull-reqs` (with DevOps configured) | Requirements pulled from provider |
| 16.6 | Impact analysis | `sentrik impact --staged` | Affected controls listed |
| 16.7 | Async approval | `sentrik gate --require-approval` | Approval request created on failure |
| 16.8 | Approve | `sentrik approve <id> --action approved` | Approval resolved |
| 16.9 | Watch mode | `sentrik watch --interval 10` | Rescans every 10 seconds |
| 16.10 | Auditor create | `sentrik auditor create --name "Test" --email test@test.com` | Token generated, portal URL printed |
| 16.11 | Auditor portal | Open portal URL in browser | Read-only compliance view |
| 16.12 | GRC push | `sentrik grc-push --test` | Test payload sent to webhook |
| 16.13 | Org dashboard | `sentrik org-dashboard` | Multi-repo summary |

## 17. Analysis Features (P2)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 17.1 | Architecture check | `sentrik check-arch` | Architecture rules evaluated |
| 17.2 | Policy check | `sentrik check-policies` | Policy rules evaluated |
| 17.3 | C/C++ analysis | `sentrik analyze-cpp` (on C project) | clang-tidy/cppcheck findings |
| 17.4 | Inline check | `sentrik check-inline --context src/main.py` | Compliance context JSON |
| 17.5 | MCP audit | `sentrik audit-mcp` | MCP config security report |

## 18. Website (P0)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 18.1 | Page loads | Open sentrik.dev | Page renders, no console errors |
| 18.2 | Hero | Check hero section | "Stop auditing AI code by hand", Early Access badge |
| 18.3 | Problem stats | Scroll to problem section | 4 stat cards, 36% stat has citation link |
| 18.4 | How It Works | Check 3-step section | Scan, Gate, Ship with CLI commands + YAML snippet |
| 18.5 | Terminal demo | Click each of 9 tabs | All load correctly (asciinema player) |
| 18.6 | Mid-page CTA | Check CTA button | Scrolls to #early-access form |
| 18.7 | Dashboard section | Scroll to dashboard showcase | 7 showcase blocks with screenshots |
| 18.8 | Threat model screenshot | Check STRIDE showcase block | Screenshot with AI chat visible |
| 18.9 | Code Intelligence | Check quality/profile blocks | Screenshots with descriptions |
| 18.10 | Feature cards | Check 6 value prop cards | All render with icons |
| 18.11 | Integrations grid | Check 6-column grid | CI, DevOps, AI, Editors, GRC, Output |
| 18.12 | Regulated section | Check 4 cards | Air-gapped, auditor, governance, attestations |
| 18.13 | Standards grid | Check framework cards | 12 cards including EU AI Act, GDPR, NIST, CMMC |
| 18.14 | Form submit | Fill email, click "Request Access" | Netlify form submits |
| 18.15 | Lightbox open | Click expandable screenshot | Full-screen lightbox opens |
| 18.16 | Lightbox close | Press Escape or click backdrop | Lightbox closes |
| 18.17 | Nav CTA | Click "Get Early Access" in header | Scrolls to form |
| 18.18 | Mobile responsive | Resize to 600px | Layout adapts, form stacks vertically |
| 18.19 | robots.txt | Check sentrik.dev/robots.txt | AI crawlers blocked, Google allowed |
| 18.20 | OG tags | Share URL on Slack/LinkedIn | Preview image and description show |

## 19. Edge Cases & Error Handling (P2)

| # | Test | Steps | Expected |
|---|------|-------|----------|
| 19.1 | No config | Run scan in empty directory | Auto-detect, sensible defaults |
| 19.2 | Invalid config | Corrupt `.guard.yaml`, run scan | Clear error message |
| 19.3 | No findings | Scan clean code | "No findings detected", exit 0 |
| 19.4 | Large project | Scan 1000+ file project | Completes in reasonable time |
| 19.5 | Binary files | Scan directory with images/binaries | Skipped gracefully |
| 19.6 | No git | Run in non-git directory | Works without git |
| 19.7 | Expired license | Use expired key | Clear message, falls back to evaluation |
| 19.8 | Invalid license | Use garbage key | Clear error, suggests removing key |
| 19.9 | No LLM key | Run review-design without API key | Clear error: "requires LLM" |
| 19.10 | Concurrent scans | Run two scans simultaneously | No corruption, both complete |

---

## Execution Summary

| Area | P0 | P1 | P2 | Total |
|------|-----|-----|-----|-------|
| Installation & Setup | 10 | — | — | 10 |
| Core Scanning | 11 | — | — | 11 |
| Standards Packs | 14 | — | — | 14 |
| Supply Chain | 7 | — | — | 7 |
| Code Intelligence | — | 15 | — | 15 |
| Threat Modeling | — | 7 | — | 7 |
| Compliance & Reporting | — | 14 | — | 14 |
| Dashboard Core | 12 | — | — | 12 |
| Dashboard Compliance | — | 7 | — | 7 |
| Dashboard Intelligence | — | 16 | — | 16 |
| Dashboard Governance | — | 5 | — | 5 |
| Dashboard Integration | — | 5 | — | 5 |
| Dashboard General | 7 | — | — | 7 |
| REST API | — | 13 | — | 13 |
| CI/CD | 4 | — | — | 4 |
| Governance | — | — | 13 | 13 |
| Analysis | — | — | 5 | 5 |
| Website | 20 | — | — | 20 |
| Edge Cases | — | — | 10 | 10 |
| **Total** | **85** | **82** | **28** | **195** |

**P0 tests (85):** Must all pass before release.
**P1 tests (82):** Should pass. Known issues must be documented.
**P2 tests (28):** Best effort. Failures are acceptable if documented.
