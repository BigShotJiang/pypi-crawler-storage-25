# Sentrik — One-Year Product Outlook

**Date:** 2026-03-11
**Baseline:** Current state as of Sprint 4 (zero-config onboarding complete, 1719 tests, full CLI/dashboard/VS Code/OAuth/RBAC/licensing stack)

---

## Current Foundation

In a matter of weeks, the following has been built from scratch:

- Full CLI with 30+ commands (scan, gate, trace, reconcile, verify-reqs, generate-reqs, apply-patches, approve, etc.)
- REST API server with 33+ protected endpoints
- Web dashboard with metrics, policies, packs, rules, audit log, approvals, governance banner
- VS Code extension with zero-config auto-init, scan-on-save, inline diagnostics
- 6 standards packs (IEC 62304, OWASP Top 10, SOC2, HIPAA, PCI-DSS, ISO 27001)
- OAuth 2.0 for Azure DevOps, GitHub, and Jira
- Async approval gates with audit trails
- Language-aware auto-patching with governance controls
- Requirement traceability, drift detection, and auto-generation
- Heuristic severity rescoring and parallel scanning
- RBAC with fine-grained permissions
- Tiered licensing (Free/Trial/Team/Org/Enterprise)
- npm package, Docker image, PyPI distribution
- Marketing website (Astro + Netlify), MkDocs documentation site, community repo
- Demo project (C++ DICOM viewer) with full walkthrough script

---

## Q2 2026 — Product-Market Fit

### Monetization & Distribution
- Stripe billing goes live — Checkout sessions, webhook handlers, license provisioning
- Online license server (`portal.sentrik.dev`) ships on Fly.io/Railway
- npm package publishes with real platform binaries (macOS x64/arm64, Linux x64, Windows x64)
- First paying customers from the medical device / IEC 62304 niche — sharpest wedge because nobody else does automated IEC 62304 traceability with drift detection

### Stickiness Features (from Vision Doc items 9, 10)
- **Watch mode / continuous scanning:** Filesystem watcher + debounced incremental scan. `sentrik watch` runs in the background, findings appear in real-time. Configurable triggers (file save, git commit, branch switch). Teams that install Sentrik stop uninstalling it.
- **Compliance score trending + alerts:** Line charts over time, finding velocity (new vs. resolved per day), "compliance debt" metric. Alert rules for score drops, stale approvals, drift detection. Data already exists in `out/history/` — just needs charting and threshold checks.

### Sales Motion
- The demo script becomes the sales call — 25 minutes, zero-to-governance walkthrough
- Target: regulated-industry engineering leads (medical devices, fintech) where the pain is acute and the budget exists
- Free tier on personal projects and startups feeds the pipeline

---

## Q3 2026 — Platform Expansion

### Signature Feature: Compliance-as-Code Contracts (Vision item 5)
- Each requirement gets a machine-readable contract (YAML) that Sentrik verifies continuously
- Contract types: `pattern_required`, `pattern_forbidden`, `function_exists`, `test_coverage`
- `sentrik verify-contracts` produces pass/fail per requirement
- Contract violations become findings with direct requirement linkage
- Contracts versioned alongside code — requirement changes require contract updates
- This is the feature that makes regulated teams say "we can't go back"

### AI Autonomy Levels (Vision item 3)
- Tiered autonomy: Level 0 (full auto) → Level 3 (full block)
- Config-driven severity routing based on file patterns, finding severity, change type
- Auto-merge with notification for low-risk changes, synchronous block for safety-critical paths
- Lets teams dial in exactly how much the AI can do unsupervised — the conversation every engineering leader is having right now

### Standards Pack Expansion (6 → 12+)
- **Automotive:** ISO 26262 / ASPICE
- **Aerospace:** DO-178C
- **Fintech:** MAS TRM, EBA guidelines
- **Government:** FedRAMP, NIST 800-53
- Each pack opens a new vertical market
- Community-authored packs start appearing (pack authoring guide already exists)

### Scheduled Review Cadences (Vision item 2)
- Configurable daily/weekly review digests via Slack/Teams/email
- Auto-escalation for stale approvals (e.g., pending > 48h → escalate to director)
- Weekly PDF compliance reports suitable for QA meetings or regulatory review

---

## Q4 2026 — The AI Governance Layer

### LLM-Powered Remediation (Vision item 4)
- Safety loop: LLM generates fix → Sentrik scans fix → validates no new findings → proposes as PR
- Maximum 3 retry attempts per finding
- Critical-path files never get LLM fixes without human review
- All LLM fixes attributed in git history ("Co-authored-by: Sentrik AI")
- Key insight: Sentrik already has scan-and-gate infrastructure — the LLM is just another actor subject to the same rules

### Predictive Compliance (Vision item 8)
- `sentrik predict --requirement REQ-009 --files src/new_feature.cpp`
- Before an AI agent writes code, Sentrik predicts which rules will fire based on the requirement and target files
- Outputs recommended patterns and anti-patterns
- Flips the feedback loop: instead of "write → scan → fix," agents write compliant code on the first attempt
- Scan-fix-rescan cycle drops from 3-4 iterations to 1

### Regulatory Submission Automation (Vision item 7)
- `sentrik export-submission --standard iec-62304 --class C`
- One command generates a submission-ready ZIP: Software Development Plan, Software Requirements Specification, Software Architecture Document, Traceability Matrix, Risk Analysis, Test Summary Report, Compliance Statement
- Ships for IEC 62304 first, then PCI-DSS and SOC2
- A medical device company that spent 6 weeks compiling FDA paperwork does it in 6 minutes
- This becomes the enterprise sales closer

### Branch-and-Continue Workflow (Vision item 1)
- When the gate blocks main, Sentrik creates a remediation branch so development continues
- Finding-level claiming (developers "own" specific findings to prevent duplicate work)
- Merge-back validation: re-run gate when fix branch merges to confirm resolution

---

## Q1 2027 — The Coordination Platform

### Multi-Agent Orchestration (Vision item 6)
- Sentrik evolves from "a tool that scans code" to "the coordination layer for AI-assisted development"
- When 3+ agents work on different parts of a codebase, Sentrik manages:
  - **File locking:** Agent A claims `patient_db.cpp` — Agent B can't modify it until release
  - **Finding assignment:** Findings routed to the most relevant agent based on active file set
  - **Merge ordering:** Optimal merge sequence to minimize conflicts
  - **Composite gating:** All agent branches must pass individually AND the merged result must pass
  - **Conflict detection:** Flag when two agents modify the same function before merge
- This is where the "governance runtime" positioning fully materializes

### Three Product Surfaces
1. **CLI + CI** — the developer/agent interface (where it started)
2. **Dashboard + API** — the team lead / QA / compliance officer interface
3. **Portal (portal.sentrik.dev)** — the org-level management plane (billing, seat management, cross-project compliance posture, audit exports for regulators)

---

## Business Projections

### Revenue
- ~50-100 paying teams by Q1 2027, concentrated in medical devices and fintech
- ARR in the low hundreds of thousands — mostly Org ($99/mo) and Enterprise ($299/mo) tiers
- Free tier drives awareness and pipeline from startups and personal projects

### Market Position
- 2-3 published case studies ("How [Company] cut FDA submission prep from 6 weeks to 2 days")
- Partnership conversations with AI coding agent companies (Cursor, Windsurf, Codium) who want "built-in compliance" — Sentrik becomes the governance backend they integrate
- Conference presence at medical device and fintech regulatory events

### Competitive Moat
The thing that's hard to replicate isn't any single feature — it's the end-to-end loop:

```
Requirement in Azure DevOps
  → Code traced to requirement
    → Code scanned against IEC 62304 + OWASP + MISRA
      → Gate blocks merge
        → Approval workflow with audit trail
          → Audit export for FDA submission
```

A competitor can build a linter. They can build a dashboard. But rebuilding the full loop is a year of work.

Standards packs are the second moat. Each pack is domain expertise encoded as rules. Writing the HIPAA pack required understanding 45 CFR Part 164. Writing the IEC 62304 pack required reading the actual standard. That knowledge compounds — every new pack makes the platform more valuable and harder to replicate.

### Key Risk
Distribution, not capability. The product is already deeper than most competitors. The challenge isn't "can we build it" — it's "can we get it in front of the 50 regulated-industry engineering leads who would pay $299/month today if they knew it existed." The demo script is the best sales tool. The website, docs, and community repo are the top-of-funnel.

---

## Guiding Principles (unchanged from Vision Doc)

1. **More automation, same guardrails.** Every new automation feature passes through the same governance framework.
2. **Never block development entirely.** The gate redirects, not dead-ends.
3. **Audit everything.** Every automated decision gets an audit trail entry.
4. **Progressive trust.** Start strict, earn autonomy. Agents that produce clean code get promoted.
5. **Developer experience first.** If compliance tooling is annoying, developers bypass it.

---

## Implementation Priority (simplest → hardest)

| Order | Feature | Target | Effort | Risk |
|-------|---------|--------|--------|------|
| 1 | Compliance score trending + alerts | Q2 2026 | Low | Low |
| 2 | Watch mode / continuous scanning | Q2 2026 | Low-Med | Low |
| 3 | Scheduled review cadences | Q3 2026 | Medium | Low |
| 4 | Compliance-as-code contracts | Q3 2026 | Medium | Low |
| 5 | AI autonomy levels | Q3 2026 | Medium | Medium |
| 6 | Branch-and-continue workflow | Q4 2026 | Med-High | Medium |
| 7 | Predictive compliance | Q4 2026 | Med-High | Medium |
| 8 | LLM-powered remediation | Q4 2026 | High | High |
| 9 | Regulatory submission automation | Q4 2026 | High | Medium |
| 10 | Multi-agent orchestration | Q1 2027 | Very High | High |
