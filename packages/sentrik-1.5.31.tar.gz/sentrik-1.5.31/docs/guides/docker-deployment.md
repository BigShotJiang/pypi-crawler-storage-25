# Docker Deployment

Run the SENTRA API server and dashboard in a container.

## Quick start

```bash
# Start server
docker run -d --name sentra -p 8000:8000 -v "$(pwd):/app" -w /app sentrik/sentrik dashboard
```

Open [http://localhost:8000/dashboard](http://localhost:8000/dashboard).

## Docker Compose

```yaml
# docker-compose.yml
services:
  sentra:
    image: sentrik/sentrik:latest
    ports:
      - "8000:8000"
    volumes:
      - .:/app
    working_dir: /app
    command: serve
    environment:
      - GUARD_API_KEY=${GUARD_API_KEY:-}
      - AZURE_DEVOPS_PAT=${AZURE_DEVOPS_PAT:-}
      - GITHUB_TOKEN=${GITHUB_TOKEN:-}
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
```

```bash
docker compose up -d
docker compose down
```

## Volume mounts

Mount your project files into `/app`:

| Host file | Container path | Purpose |
|-----------|---------------|---------|
| `.guard.yaml` | `/app/.guard.yaml` | Configuration |
| `standards.yaml` | `/app/standards.yaml` | Custom rules |
| `work_items.json` | `/app/work_items.json` | Work items |
| Source code | `/app/src/` | Code to scan |

## Environment variables

Pass secrets via environment variables (never mount credential files):

```bash
docker run -d --name sentra \
  -p 8000:8000 \
  -v "$(pwd):/app" \
  -w /app \
  -e GUARD_API_KEY=your-api-key \
  -e AZURE_DEVOPS_PAT=your-pat \
  -e GUARD_LICENSE_KEY=your-key \
  sentrik/sentrik dashboard
```

## Scanning from Docker

```bash
# Full scan
docker run --rm -v "$(pwd):/app" -w /app sentrik/sentrik scan

# Gate check
docker run --rm -v "$(pwd):/app" -w /app sentrik/sentrik gate

# Generate reports
docker run --rm -v "$(pwd):/app" -w /app sentrik/sentrik report --format html
```

## Image registry

| Registry | Image |
|----------|-------|
| Docker Hub | `docker.io/sentrik/sentrik` |

Tags follow semver: `:1.0.0`, `:1.0`, `:1`.
