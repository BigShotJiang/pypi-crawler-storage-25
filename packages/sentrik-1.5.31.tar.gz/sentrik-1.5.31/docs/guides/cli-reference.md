# CLI Reference

The CLI command is `sentrik`.

## Core commands

| Command | Description |
|---------|-------------|
| `sentrik init` | Create `.sentrik/config.yaml` (supports `--mode developer\|compliance\|ci` presets) |
| `sentrik scan` | Run a scan and write findings/reports to `out/` (supports `--actionable-only`) |
| `sentrik gate` | Run scan and enforce quality gate (exit 0 pass / exit 1 fail) |
| `sentrik next-action` | Show top fixable findings from latest scan |
| `sentrik context` | Generate `agent_context.json` for AI agents |
| `sentrik validate-config` | Validate configuration |
| `sentrik migrate` | Migrate `.guard.yaml` to `.sentrik/config.yaml` |
| `sentrik guide` | Interactive command guide with workflow examples |

![Gate Failure](../assets/images/docs-cli-gate-fail.png)

## Supply chain commands

| Command | Description |
|---------|-------------|
| `sentrik sbom` | Generate a Software Bill of Materials (CycloneDX or SPDX) |
| `sentrik vulns` | Scan dependencies for known vulnerabilities (CVEs) via OSV.dev |
| `sentrik licenses` | Scan dependency licenses and flag copyleft risk |
| `sentrik secrets` | Scan for hardcoded secrets: AWS keys, GitHub PATs, Stripe keys, private keys, etc. |

## Analysis commands

| Command | Description |
|---------|-------------|
| `sentrik analyze-cpp` | Run semantic C/C++ analysis with clang-tidy and/or cppcheck |
| `sentrik check-arch` | Check architecture rules — detect forbidden module dependencies |
| `sentrik check-policies` | Evaluate Policy-as-Code rules against the repository |
| `sentrik check-inline` | Check code compliance inline (for AI agents) |
| `sentrik metrics` | Per-file code metrics: lines, nesting depth, function count (20+ languages) |
| `sentrik quality-score` | Code quality score (0-100) across 6 dimensions |
| `sentrik quality-trend` | Quality score trend over time |
| `sentrik profile` | Build/refresh project profile (languages, frameworks, patterns) |
| `sentrik review-design` | LLM-powered design decision review and acknowledgement |
| `sentrik check-expertise` | Check if changes are outside developer's expertise |
| `sentrik compare` | Delta analysis — new/resolved findings vs previous run |
| `sentrik threat-model` | STRIDE-based threat modeling with LLM analysis |

## Governance commands

| Command | Description |
|---------|-------------|
| `sentrik reconcile` | Sync findings with DevOps work items (create/update/close) |
| `sentrik sync` | Sync work item states to DevOps provider |
| `sentrik apply-patches` | Apply auto-generated patches from last scan |
| `sentrik generate-reqs` | Auto-generate requirements from untracked code |
| `sentrik verify-reqs` | Verify requirements match actual code (drift detection) |
| `sentrik pull-reqs` | Pull requirements from a DevOps provider into requirements.yaml |
| `sentrik trace` | Show traceability matrix (requirements → code) |
| `sentrik impact` | Analyse which compliance controls and requirements are affected by changed files |
| `sentrik compliance-report` | Generate per-framework compliance reports |
| `sentrik history-report` | Generate a report from a historical scan run |
| `sentrik trust-center` | Generate a public-safe trust center page |
| `sentrik attest` | Generate or verify a signed compliance attestation |
| `sentrik gap-analysis` | Generate regulatory gap report between pack versions |
| `sentrik compliance-trend` | Show compliance score trend from historical scans |
| `sentrik risk-summary` | Generate one-page executive risk summary (HTML) |
| `sentrik evidence-export` | Generate audit evidence packages mapped to compliance framework controls |
| `sentrik grc-push` | Push compliance evidence to a GRC platform (Drata, Vanta, Secureframe, or webhook) |
| `sentrik org-dashboard` | Aggregate compliance data across multiple repositories |
| `sentrik watch` | Continuous monitoring — watch for file changes or scan periodically |
| `sentrik export-audit` | Export audit bundle (ZIP) for regulatory submission |
| `sentrik drift-scan` | Context-aware requirement drift analysis (behavioral, structural, cross-file, acceptance criteria) |
| `sentrik approve <id>` | Approve or reject an async gate approval request |
| `sentrik auditor create` | Create an auditor portal access token |
| `sentrik auditor list` | List active auditor portal tokens |
| `sentrik auditor revoke` | Revoke an auditor portal token by prefix match |
| `sentrik mcp-server` | Start the MCP server for AI agent integration |
| `sentrik lsp-server` | Start LSP server for real-time as-you-type compliance scanning |
| `sentrik audit-mcp` | Audit MCP server configurations for security risks |

## Standards pack commands

| Command | Description |
|---------|-------------|
| `sentrik list-packs` | List available standards packs |
| `sentrik add-pack <id>` | Enable a standards pack |
| `sentrik remove-pack <id>` | Disable a standards pack |
| `sentrik import-pack <file>` | Import a pack from YAML |
| `sentrik export-pack <id>` | Export a pack to YAML |
| `sentrik import-spec <file>` | Generate security rules from an API spec (OpenAPI, AsyncAPI, protobuf) |
| `sentrik diff-packs <id> <old>` | Diff current pack against an older version YAML |

## Admin commands

| Command | Description |
|---------|-------------|
| `sentrik dashboard` | Start the REST API server + dashboard |
| `sentrik list-rules` | List all configured rules |
| `sentrik report` | Generate a report from existing findings |
| `sentrik compare` | Delta analysis — new/resolved/unchanged findings vs previous run (auto-detects history) |
| `sentrik license` | Show license status and features |
| `sentrik install-check` | Verify installation and dependencies |
| `sentrik test-connection` | Test DevOps provider connectivity |


### `sentrik compliance-report`

Generate per-framework compliance reports mapping findings to regulatory clauses.

```bash
sentrik compliance-report --list                        # List frameworks from last scan
sentrik compliance-report --framework "IEC 62304"       # Single-framework report
sentrik compliance-report                               # All frameworks combined
sentrik compliance-report -f "OWASP Top 10" -o report.html  # Custom output path
```

| Option | Default | Description |
|--------|---------|-------------|
| `--framework, -f` | all | Standard name (e.g. `"IEC 62304"`, `"SOC2"`) |
| `--output, -o` | `out/compliance-report.html` | Output file path |
| `--list, -l` | false | List available frameworks and exit |
| `--config, -c` | auto | Config file path |

The report includes:

- **Compliance score card** — percentage, rules passed/failed, clauses checked
- **Clause-by-clause table** — PASS/FAIL status per regulatory clause
- **Findings detail** — each finding mapped to its clause with remediation guidance
- **Documentation obligations** — non-code items required by the standard
- Dark mode support, print-friendly CSS

Also available via REST API: `GET /api/compliance-report?framework=IEC+62304`

### `sentrik history-report`

Generate a compliance report from a historical scan run.

```bash
sentrik history-report --list                          # List available historical runs
sentrik history-report --run-id <RUN_ID>               # Generate report for a past run
sentrik history-report --run-id <RUN_ID> -f "IEC 62304"  # With framework filter
```

| Option | Default | Description |
|--------|---------|-------------|
| `--run-id, -r` | — | Run ID to generate report for |
| `--list, -l` | false | List available historical runs and exit |
| `--framework, -f` | all | Framework filter for compliance report |
| `--output, -o` | `out/report-<id>.html` | Output file path |
| `--config, -c` | auto | Config file path |

Historical runs are automatically archived in `out/history/` after each scan or gate run.

### `sentrik trust-center`

Generate a public-safe trust center page showing compliance posture. The page contains no source code, file paths, or finding details — safe to share with customers, auditors, or embed on a website.

```bash
sentrik trust-center                              # HTML page to out/trust-center.html
sentrik trust-center --org "Acme Corp"            # With organization name in header
sentrik trust-center --json                       # JSON output to out/trust-center.json
sentrik trust-center -o public/compliance.html    # Custom output path
```

| Option | Default | Description |
|--------|---------|-------------|
| `--org` | — | Organization name for the page header |
| `--json, -j` | false | Output JSON instead of HTML |
| `--output, -o` | `out/trust-center.html` | Output file path |
| `--config, -c` | auto | Config file path |

The page includes:

- **Overall compliance score** — Healthy / Needs Attention / At Risk status
- **Severity distribution** — counts per severity level
- **Per-framework cards** — score, progress bar, and rule pass rate for each standard
- Dark/light theme, responsive design, print-friendly

Also available via REST API: `GET /api/trust-center?format=html&org_name=Acme+Corp`

### `sentrik watch`

Continuous compliance monitoring — watch for file changes and re-scan automatically.

```bash
sentrik watch                              # Watch for file changes, scan on save
sentrik watch --interval 300               # Periodic scan every 5 minutes
sentrik watch --interval 60 --quiet        # Cron mode, minimal output
sentrik watch --vulns                      # Also scan deps for new CVEs (hourly)
sentrik watch --vulns --fix --create-pr    # Auto-fix + auto-PR on new CVEs
```

| Option | Default | Description |
|--------|---------|-------------|
| `--interval, -i` | — | Periodic scan interval in seconds (optional, adds scheduled scans) |
| `--quiet, -q` | false | Minimal output (cron-friendly) |
| `--config, -c` | auto | Config file path |
| `--vulns` | false | Enable periodic dependency vulnerability scanning |
| `--vuln-interval` | 3600 | Seconds between vulnerability scans |
| `--fix` | false | Auto-patch vulnerable dependencies (requires `--vulns`) |
| `--create-pr` | false | Create PR with fixes (requires `--fix` + DevOps provider) |

## Supply chain command details

### `sentrik sbom`

Generate a Software Bill of Materials (SBOM) from dependency manifests.

```bash
sentrik sbom                                    # CycloneDX SBOM to out/sbom.json
sentrik sbom --format spdx                      # SPDX format
sentrik sbom --list                             # List detected manifests and exit
sentrik sbom -o build/sbom.json                 # Custom output path
```

| Option | Default | Description |
|--------|---------|-------------|
| `--format, -f` | `cyclonedx` | SBOM format: `cyclonedx` or `spdx` |
| `--output, -o` | `out/sbom.json` | Output file path |
| `--list, -l` | false | List detected manifests and exit |
| `--config, -c` | auto | Config file path |

Supports `requirements.txt`, `package.json`, `Cargo.toml`, and other common manifest formats. Components are deduplicated across manifests.

### `sentrik vulns`

Scan project dependencies for known vulnerabilities (CVEs) via OSV.dev.

```bash
sentrik vulns                                   # Scan and show results
sentrik vulns --json                            # Output JSON
sentrik vulns --fix-preview                     # Preview available fixes
sentrik vulns --fix                             # Auto-patch manifests with fixed versions
sentrik vulns --fix --create-pr                 # Apply fixes and create a PR
```

| Option | Default | Description |
|--------|---------|-------------|
| `--json, -j` | false | Output JSON instead of Rich table |
| `--output, -o` | `out/vulnerabilities.json` | Output file path |
| `--fix` | false | Auto-patch manifest files with fixed versions |
| `--fix-preview` | false | Show what `--fix` would change without modifying files |
| `--create-pr` | false | Create a branch and PR with the fixes (requires `--fix` and a DevOps provider) |
| `--config, -c` | auto | Config file path |

Results are recorded to the local metrics database for trend tracking. The `--create-pr` flag requires a configured DevOps provider (Azure DevOps or GitHub).

![Vulnerability Scan](../assets/images/docs-cli-vulns.png)

### `sentrik licenses`

Scan project dependencies for license types and flag copyleft risk.

```bash
sentrik licenses                                # Scan and show all licenses
sentrik licenses --copyleft-only                # Show only copyleft-licensed packages
sentrik licenses --json                         # Output JSON
sentrik licenses -o build/licenses.json         # Custom output path
```

| Option | Default | Description |
|--------|---------|-------------|
| `--json, -j` | false | Output JSON instead of Rich table |
| `--copyleft-only` | false | Show only copyleft-licensed packages |
| `--output, -o` | `out/licenses.json` | Output file path |
| `--config, -c` | auto | Config file path |

Each dependency is classified by license risk level (high, medium, low, none) and flagged if it uses a copyleft license (GPL, AGPL, etc.).

## Analysis command details

### `sentrik analyze-cpp`

Run semantic C/C++ analysis with clang-tidy and/or cppcheck.

```bash
sentrik analyze-cpp                             # Auto-detect available tools
sentrik analyze-cpp --tool clang-tidy           # Use clang-tidy only
sentrik analyze-cpp --tool cppcheck             # Use cppcheck only
sentrik analyze-cpp --tool both                 # Use both tools
sentrik analyze-cpp --checks "cert-*,misra-*"   # Specific clang-tidy checks
sentrik analyze-cpp --files src/main.cpp        # Analyse specific files
sentrik analyze-cpp --json -o results.json      # JSON output to file
```

| Option | Default | Description |
|--------|---------|-------------|
| `--tool, -t` | `auto` | Tool to use: `clang-tidy`, `cppcheck`, `both`, or `auto` |
| `--checks` | — | Clang-tidy checks (comma-separated, e.g. `"cert-*,misra-*"`) |
| `--files, -f` | all | Specific files to analyze |
| `--json, -j` | false | Output JSON instead of Rich table |
| `--output, -o` | `out/cpp_findings.json` | Output file path |
| `--config, -c` | auto | Config file path |

In `auto` mode, the command detects which tools are installed and uses whatever is available. Findings are converted to standard sentrik findings format for integration with the gate and dashboard.

### `sentrik check-arch`

Check architecture rules — detect forbidden module dependencies.

```bash
sentrik check-arch                              # Check against architecture.yaml
sentrik check-arch --init                       # Generate a template architecture.yaml
sentrik check-arch --config rules/arch.yaml     # Custom rules file
sentrik check-arch --json                       # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--config, -c` | `architecture.yaml` | Path to architecture rules YAML file |
| `--json, -j` | false | Output results as JSON |
| `--init` | false | Generate a template `architecture.yaml` file |

Architecture rules define allowed and forbidden import relationships between modules. Violations are reported with the source file, line number, and imported module. Exit code 1 when violations are found.

### `sentrik check-policies`

Evaluate Policy-as-Code rules against the repository.

```bash
sentrik check-policies                          # Evaluate policies.yaml
sentrik check-policies --init                   # Generate a template policies.yaml
sentrik check-policies --config rules/pol.yaml  # Custom policies file
sentrik check-policies --json                   # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--config` | `policies.yaml` | Path to policies YAML file |
| `--json` | false | Output results as JSON |
| `--init` | false | Generate a template `policies.yaml` file |

Policies define repository-level constraints (e.g., required files, naming conventions, structural rules). Each policy violation includes the policy name, file, line, message, and severity.

### `sentrik check-inline`

Check code compliance inline — designed for AI coding agents to validate code snippets before writing them.

```bash
sentrik check-inline --file src/main.cpp --code "strcpy(dest, src);"
sentrik check-inline --file src/main.cpp --stdin
sentrik check-inline --context src/main.cpp
sentrik check-inline --file app.py --code "eval(data)" --frameworks "OWASP Top 10"
```

| Option | Default | Description |
|--------|---------|-------------|
| `--file, -f` | — | Filename for language detection and rule matching |
| `--code, -c` | — | Code string to check |
| `--stdin` | false | Read code from stdin |
| `--context` | — | Print compliance context for the given filename as JSON |
| `--frameworks` | all | Comma-separated framework names to filter rules |

In context mode (`--context`), prints the applicable rules and frameworks for a file as JSON — useful for AI agents to understand constraints before generating code. Exit code 1 when findings are detected.

## Governance command details

### `sentrik pull-reqs`

Pull requirements from a DevOps provider into `requirements.yaml`.

```bash
sentrik pull-reqs --provider azure              # Pull from Azure DevOps
sentrik pull-reqs --provider github             # Pull from GitHub Issues
sentrik pull-reqs --provider jira               # Pull from Jira
sentrik pull-reqs --merge                       # Merge with existing requirements
sentrik pull-reqs --map-files                   # Auto-map source files by title matching
sentrik pull-reqs -o reqs/requirements.yaml     # Custom output path
```

| Option | Default | Description |
|--------|---------|-------------|
| `--provider, -p` | config value | Override DevOps provider (`azure`, `github`, `jira`) |
| `--output, -o` | `requirements.yaml` | Output YAML file path |
| `--merge` | false | Merge with existing `requirements.yaml` instead of overwriting |
| `--map-files` | false | Auto-map `source_files` by matching work item titles to filenames |
| `--config, -c` | auto | Config file path |

Work items are converted to requirement entries with ID, title, description, and acceptance criteria. The `--map-files` flag uses title-to-filename matching to populate the `source_files` field for traceability.

### `sentrik impact`

Analyse which compliance controls and requirements are affected by changed files.

```bash
sentrik impact                                  # Analyse staged files (default)
sentrik impact --staged                         # Explicitly scope to staged files
sentrik impact --git-range origin/main...HEAD   # Scope to a git range
sentrik impact --files src/auth.py src/db.py    # Specific files
sentrik impact --json                           # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--git-range` | — | Git range for scoping (e.g. `origin/main...HEAD`) |
| `--files, -f` | — | Specific files to analyse |
| `--staged` | false | Analyse staged files |
| `--json` | false | Output as JSON |
| `--config, -c` | auto | Config file path |

The report shows per-file risk level (high/medium/low), affected rules, affected requirements, and impacted frameworks. When critical or high-severity rules are affected, the report flags that revalidation is required.

### `sentrik evidence-export`

Generate audit evidence packages mapped to compliance framework controls.

```bash
sentrik evidence-export --list                           # List available frameworks
sentrik evidence-export --framework "SOC2"               # Export for a single framework
sentrik evidence-export --all                            # Export for all frameworks
sentrik evidence-export --framework "IEC 62304" --json   # JSON output
sentrik evidence-export -f "SOC2" -o evidence/           # Custom output directory
```

| Option | Default | Description |
|--------|---------|-------------|
| `--framework, -f` | — | Framework to export evidence for (e.g. `"SOC2"`, `"IEC 62304"`) |
| `--all, -a` | false | Export evidence for all available frameworks |
| `--list, -l` | false | List available frameworks and exit |
| `--json, -j` | false | Output JSON instead of HTML |
| `--output, -o` | `out/evidence-<framework>.html` | Output directory or file path |
| `--config, -c` | auto | Config file path |

Evidence packages map scan findings, compliance scores, and audit log entries to specific framework controls. Output is an HTML report by default, or JSON for programmatic consumption. Requires either `--framework` or `--all`.

### `sentrik grc-push`

Push compliance evidence to a GRC platform (Drata, Vanta, Secureframe, or generic webhook).

```bash
sentrik grc-push                                # Push scan_complete event (default)
sentrik grc-push --event gate_passed            # Push gate result
sentrik grc-push --event vuln_scan              # Push vulnerability scan results
sentrik grc-push --test                         # Send a test payload to verify connectivity
```

| Option | Default | Description |
|--------|---------|-------------|
| `--event, -e` | `scan_complete` | Event type: `scan_complete`, `gate_passed`, `gate_failed`, `vuln_scan` |
| `--test` | false | Send a test payload to verify webhook connectivity |
| `--config, -c` | auto | Config file path |

Requires `grc_webhook_url` in config or `GUARD_GRC_WEBHOOK_URL` env var. Payloads include project name, findings summary, compliance scores, and timestamps. Run `sentrik scan` or `sentrik gate` before pushing scan/gate events.

### `sentrik org-dashboard`

Aggregate compliance data across multiple repositories into a single view.

```bash
sentrik org-dashboard                           # Scan subdirectories of current dir
sentrik org-dashboard --root ~/projects         # Custom organization root
sentrik org-dashboard --json                    # JSON output
sentrik org-dashboard -o report.html            # Generate HTML report
```

| Option | Default | Description |
|--------|---------|-------------|
| `--root, -r` | `.` | Organization root directory containing sub-projects |
| `--json, -j` | false | Output JSON instead of Rich table |
| `--output, -o` | — | Write HTML report to this file path |

Discovers projects by looking for `.sentrik/config.yaml` or `.guard.yaml` in subdirectories. The summary shows per-project compliance score, findings by severity, gate status, and framework coverage. Use `--output` to generate an HTML dashboard report.

### `sentrik auditor create`

Create an auditor portal access token for external auditors.

```bash
sentrik auditor create --name "Jane Doe" --email jane@auditor.com
sentrik auditor create --name "Auditor" --email a@co.com --hours 24
sentrik auditor create --name "Auditor" --email a@co.com --scope findings,compliance
```

| Option | Default | Description |
|--------|---------|-------------|
| `--name, -n` | (required) | Auditor's name |
| `--email, -e` | (required) | Auditor's email address |
| `--hours, -H` | 72 | Token lifetime in hours |
| `--port, -p` | 8000 | Server port for the portal URL |
| `--scope, -s` | all | Comma-separated scopes: `findings`, `compliance`, `audit_log`, `evidence`, `trends` |

Generates a time-limited token and prints the portal URL. Share the URL with the auditor. The server must be running (`sentrik dashboard`) for the auditor to access the portal.

### `sentrik auditor list`

List all active auditor portal tokens.

```bash
sentrik auditor list
```

Shows the auditor name, email, expiry time, and token prefix for each active token.

### `sentrik auditor revoke`

Revoke an auditor portal token by prefix match.

```bash
sentrik auditor revoke abc123def456             # Full or partial token prefix
```

| Argument | Description |
|----------|-------------|
| `TOKEN_PREFIX` | Token or prefix of the token to revoke |

Revokes all tokens matching the given prefix. Use `sentrik auditor list` to find token prefixes.

### `sentrik mcp-server`

Start the MCP (Model Context Protocol) server for AI agent integration. AI coding tools like Claude Code, Cursor, and VS Code connect to this server to access Sentrik's compliance tools during code generation and review.

```bash
sentrik mcp-server
```

The server communicates over stdio (stdin/stdout) — the standard MCP transport. You don't run this directly; configure it in your AI tool's MCP settings:

**Claude Code** (`.claude/claude_desktop_config.json` or project `.mcp.json`):
```json
{
  "mcpServers": {
    "sentrik": {
      "command": "sentrik",
      "args": ["mcp-server"]
    }
  }
}
```

**Cursor** (Settings > MCP Servers):
```json
{
  "mcpServers": {
    "sentrik": {
      "command": "sentrik",
      "args": ["mcp-server"]
    }
  }
}
```

The MCP server exposes 10 tools:

| Tool | Description |
|------|-------------|
| `scan_file` | Scan a single file for compliance issues |
| `get_compliance_context` | Get applicable rules and constraints for a file |
| `check_code_snippet` | Check inline code without a file on disk |
| `get_scan_summary` | Get current project compliance status |
| `explain_rule` | Explain a specific compliance rule in detail |
| `get_vulnerabilities` | Get dependency vulnerability scan results |
| `run_scan` | Run a full project scan |
| `get_agent_status` | Get per-agent compliance metrics from the latest scan |
| `get_design_constraints` | Get project design constraints and established patterns for a file |
| `review_design_decisions` | LLM-powered design decision review for code changes |

For detailed setup instructions, see the [MCP Integration Guide](mcp-integration.md).

## Confidence Scoring

Regex findings are assigned a confidence score based on where the match occurs:

| Confidence | Context | Deterministic |
|------------|---------|---------------|
| 1.0 | Executable code | Yes |
| 0.7 | Test file (`test_` prefix, `_test.py` suffix, `/tests/` dir) | No |
| 0.5 | Inside a comment (`#` for Python/Ruby/YAML/Shell, `//` for JS/TS/C/C++/Go/Rust/Java/Swift/Kotlin/Scala/Dart) | No |
| 0.4 | Inside a string literal or docstring | No |

AST, file_policy, and required_pattern checks always report confidence 1.0 (structurally verified). SARIF imports default to 0.9, LLM findings use the LLM-provided value, and requirement drift findings use 0.7.

Confidence feeds into the severity rescorer when `severity_rescoring_enabled: true` — lower-confidence findings are less likely to be escalated.

## Pre-commit commands

| Command | Description |
|---------|-------------|
| `sentrik pre-commit-scan` | Scan staged files with recovery hints |
| `sentrik fix-hook` | Auto-fix findings from last pre-commit scan |

## Approval commands (Enterprise)

| Command | Description |
|---------|-------------|
| `sentrik approve <id>` | Approve a pending approval request |
| `sentrik approval-status <id>` | Check status of an approval request |

## Common options

| Option | Description |
|--------|-------------|
| `--config, -c PATH` | Use a specific config file |
| `--staged` | Scope to git-staged files only |
| `--git-range RANGE` | Scope to a git range (e.g., `origin/main...HEAD`) |
| `--diff TEXT` | Scope to files from a diff string |
| `--branch TEXT` | Set branch for work item traceability |
| `--dry-run` | Preview without side effects |

`--staged`, `--git-range`, and `--diff` are mutually exclusive.

## Scan command options

```bash
sentrik scan [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--config, -c PATH` | Config file path |
| `--staged` | Scan only git-staged files |
| `--git-range RANGE` | Scan files in git range |
| `--diff TEXT` | Scan files from diff |
| `--branch TEXT` | Branch name for traceability |

## Gate command options

```bash
sentrik gate [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--config, -c PATH` | Config file path |
| `--staged` | Gate only staged files |
| `--git-range RANGE` | Gate files in git range |
| `--decorate-pr` | Post compliance summary + findings as PR comments |
| `--status-check` | Report status via GitHub Checks / Azure commit status |
| `--commit-sha TEXT` | Commit SHA for status reporting |
| `--require-approval` | Create approval request on gate failure (Enterprise) |
| `--approval-timeout INT` | Approval timeout in seconds |

## Serve command options

```bash
sentrik dashboard [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--host TEXT` | Host to bind to (default: `127.0.0.1`; use `0.0.0.0` for network access) |
| `--port INT` | Port number (default: `8000`) |
| `--reload` | Enable auto-reload for development |

## Reconcile command options

```bash
sentrik reconcile [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--config, -c PATH` | Config file path |
| `--staged` | Scope to staged files |
| `--dry-run` | Preview actions without executing |
| `--work-items PATH` | Override work items file path |


### `sentrik import-spec`

Generate security rules from an API specification file. Auto-detects format from file extension and content.

```bash
sentrik import-spec openapi.yaml --enable          # OpenAPI → rules, enable in config
sentrik import-spec events.yaml -f asyncapi        # Explicit format
sentrik import-spec service.proto --id my-api      # Custom pack ID
```

| Option | Description |
|--------|-------------|
| `--format, -f` | Spec format: `openapi`, `asyncapi`, `protobuf` (auto-detected if omitted) |
| `--id` | Pack ID (defaults to spec title/package name) |
| `--overwrite` | Overwrite existing pack |
| `--enable` | Enable pack in config after import |
| `--config, -c` | Config file path |

Rules generated per format:

- **OpenAPI**: auth enforcement, unbounded string inputs, sensitive response fields, HTTP servers, unconstrained path params
- **AsyncAPI**: channel auth, sensitive payloads, unbounded fields, insecure broker protocols
- **Protobuf**: sensitive fields, unbounded strings, RPC auth obligations


### `sentrik attest`

Generate or verify a cryptographically signed compliance attestation.

```bash
sentrik attest                              # Generate attestation from latest scan
sentrik attest -o proof.json                # Custom output path
sentrik attest --verify out/attestation.json  # Verify existing attestation
```

| Option | Description |
|--------|-------------|
| `--output, -o` | Output file path (default: `out/attestation.json`) |
| `--verify` | Verify an existing attestation file |
| `--config, -c` | Config file path |

The attestation document includes: findings digest (SHA-256), severity counts, gate status, packs enabled, git SHA, tool version, and an HMAC-SHA256 signature.


### `sentrik diff-packs`

Diff the current version of a standards pack against an older version.

```bash
sentrik diff-packs owasp-top-10 old-owasp.yaml       # Human-readable diff
sentrik diff-packs supply-chain-security old.yaml -j  # JSON output
```

| Option | Description |
|--------|-------------|
| `--json, -j` | Output as JSON |
| `--config, -c` | Config file path |


### `sentrik gap-analysis`

Generate a regulatory gap analysis between pack versions. Identifies new obligations, strengthened rules, relaxed rules, and removed controls.

```bash
sentrik gap-analysis owasp-top-10 old-owasp.yaml        # Human-readable report
sentrik gap-analysis soc2 old-soc2.yaml --json           # JSON for automation
sentrik gap-analysis hipaa old.yaml -o gap-report.json -j  # Save to file
```

| Option | Description |
|--------|-------------|
| `--output, -o` | Output file path (default: stdout) |
| `--json, -j` | Output as JSON |


### `sentrik drift-scan`

Context-aware requirement drift analysis. Detects four types of drift:

1. **Behavioral** — LLM compares requirement description against actual code behavior
2. **Structural** — detects removed/weakened security patterns (auth bypass, TLS disabled, weak crypto)
3. **Cross-file** — finds missing source files and suggests where code may have moved
4. **Acceptance criteria** — LLM validates each acceptance criterion against the implementation

```bash
sentrik drift-scan                              # Analyze all requirements
sentrik drift-scan -r custom-reqs.yaml          # Custom requirements file
sentrik drift-scan --staged                     # Scope to staged files only
sentrik drift-scan --json -o drift-report.json  # JSON output
```

| Option | Description |
|--------|-------------|
| `--config, -c` | Config file path |
| `--requirements, -r` | Path to requirements.yaml |
| `--staged` | Scope to staged files only |
| `--output, -o` | Output file path |
| `--json, -j` | Output as JSON |

Structural and cross-file checks work without LLM. For behavioral drift and acceptance criteria validation, set `ANTHROPIC_API_KEY` (or configure another LLM provider).

## Intelligence command details

### `sentrik quality-score`

Calculate a code quality score (0-100) across six weighted dimensions.

```bash
sentrik quality-score                      # Show overall score
sentrik quality-score --verbose            # Show per-dimension breakdown
sentrik quality-score --verbose --json     # JSON output with all dimensions
sentrik quality-score --min-quality 70     # Fail (exit 1) if score is below threshold
```

| Option | Default | Description |
|--------|---------|-------------|
| `--verbose, -v` | false | Show per-dimension scores |
| `--json, -j` | false | Output JSON |
| `--min-quality` | — | Minimum quality threshold (exit 1 if below) |
| `--config, -c` | auto | Config file path |

**Dimensions and weights:**

| Dimension | Weight | What it measures |
|-----------|--------|-----------------|
| Compliance | 25% | Inverse of finding density from the latest scan |
| Complexity | 20% | Cyclomatic complexity, nesting depth, function length |
| Test Coverage | 15% | Ratio of test files to source files |
| Documentation | 10% | Docstring and comment coverage |
| Consistency | 15% | Naming conventions, pattern uniformity |
| Dependency Health | 15% | Vulnerability count, outdated deps, license risk |

Each run is appended to `out/quality_history.json` for trend tracking.

### `sentrik quality-trend`

Show quality score trend from historical measurements.

```bash
sentrik quality-trend                      # Show trend table
sentrik quality-trend --last 20            # Last 20 measurements
sentrik quality-trend --json               # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--last, -n` | 10 | Number of historical entries to show |
| `--json, -j` | false | Output JSON |

### `sentrik profile`

Build or view a project profile — auto-detected languages, frameworks, architecture patterns, conventions, and module map.

```bash
sentrik profile                            # Build/refresh profile
sentrik profile --show                     # View cached profile
sentrik profile --for src/api/routes/      # View constraints for a specific area
sentrik profile --json                     # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--show` | false | View cached profile without refreshing |
| `--for PATH` | — | Show design constraints for a specific file or directory |
| `--json, -j` | false | Output JSON |
| `--config, -c` | auto | Config file path |

The profile is cached in `out/project-profile.json`. AI agents query it via the `get_design_constraints` MCP tool to understand established patterns before generating code.

**Profile fields:**

- **Languages** — detected programming languages
- **Frameworks** — detected frameworks with source (e.g., `FastAPI` from `pyproject.toml`)
- **Architecture** — detected patterns (Service Layer, MVC, Repository Pattern, etc.)
- **ADRs** — Architecture Decision Records found in the repo
- **Conventions** — type hints usage, docstring style, naming conventions
- **Module map** — directory structure with purpose and file counts
- **Tech stack** — consolidated technology list

### `sentrik review-design`

LLM-powered design decision review. Analyses code changes and surfaces architecture, security, and data model decisions that need human attention.

```bash
sentrik review-design --file src/auth.py                # Review a specific file
sentrik review-design --git-range HEAD~3..HEAD          # Review recent changes
sentrik review-design --pending                         # Show unacknowledged decisions
sentrik review-design --ack DD-ABC123 --note "Reviewed" # Acknowledge a decision
sentrik review-design --json                            # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--file, -f` | — | Specific file to review |
| `--git-range` | — | Git range for scoping (e.g. `HEAD~3..HEAD`) |
| `--pending` | false | Show only unacknowledged decisions |
| `--ack` | — | Acknowledge a decision by ID (e.g. `DD-ABC123`) |
| `--note` | — | Note to attach to acknowledgement |
| `--json, -j` | false | Output JSON |
| `--config, -c` | auto | Config file path |

Requires an LLM provider (`ANTHROPIC_API_KEY` or `OPENAI_API_KEY`). Each decision includes:

- **Decision ID** — unique identifier (e.g. `DD-14580B`)
- **Category** — `architecture`, `security-pattern`, `data-model`, `error-handling`, `performance-tradeoff`, `dependency-choice`, `state-management`
- **Summary** — one-line description of the decision
- **File and line range** — where in the code
- **Alternatives** — what else could have been done
- **Risk** — what could go wrong at scale
- **Question** — review prompt for the developer

Decisions are stored in `out/design_decisions.json`. When `governance.design_review.require_acknowledgment` is set in config, `sentrik gate` returns exit code 2 if decisions are pending (compliance passes but design review is incomplete).

### `sentrik check-expertise`

Check if code changes fall outside the developer's expertise based on git commit history.

```bash
sentrik check-expertise --profile                    # Show developer profile
sentrik check-expertise                              # Check staged changes
sentrik check-expertise --git-range HEAD~5..HEAD     # Check specific range
sentrik check-expertise --threshold 0.1              # More sensitive (flag more)
```

| Option | Default | Description |
|--------|---------|-------------|
| `--profile` | false | Show developer expertise profile |
| `--git-range` | — | Git range for scoping |
| `--staged` | false | Check staged files |
| `--threshold, -t` | 0.2 | Expertise threshold (0.0-1.0) — lower means more sensitive |
| `--json, -j` | false | Output JSON |
| `--config, -c` | auto | Config file path |

The developer profile is built from git commit history (180-day lookback). It tracks:

- **Languages** — commit count per language (Python, JavaScript, Go, etc.)
- **Modules** — commit count per top-level directory
- **Total commits** — aggregate count

When changes touch a language or module where the developer has fewer than `threshold` proportion of commits, it flags an expertise gap with severity `warning` or `info`. Profiles are cached in `out/developer_profiles.json`.

### `sentrik compare`

Delta analysis — show new, resolved, and unchanged findings compared to a previous scan.

```bash
sentrik compare                             # Compare against most recent history
sentrik compare --run-id <RUN_ID>           # Compare against a specific run
sentrik compare --json                      # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--run-id, -r` | latest | Run ID to compare against (auto-detects latest from `out/history/`) |
| `--json, -j` | false | Output JSON |
| `--config, -c` | auto | Config file path |

Shows three categories: **new** findings (introduced since last run), **resolved** findings (fixed), and **unchanged** findings. Useful for PR reviews to see exactly what changed.

### `sentrik threat-model`

STRIDE-based threat modeling using LLM analysis. Identifies spoofing, tampering, repudiation, information disclosure, denial of service, and elevation of privilege threats in your code.

```bash
sentrik threat-model --file src/api/routes/patients.py   # Analyze a specific file
sentrik threat-model --git-range HEAD~3..HEAD            # Analyze recent changes
sentrik threat-model --stride tampering                  # Filter by STRIDE category
sentrik threat-model --pending                           # Show unmitigated threats
sentrik threat-model --mitigate TM-ABC123 --note "Fixed" # Mark threat as mitigated
sentrik threat-model --json                              # JSON output
```

| Option | Default | Description |
|--------|---------|-------------|
| `--file, -f` | — | Specific file to analyze |
| `--git-range` | — | Git range for scoping (e.g. `HEAD~3..HEAD`) |
| `--stride` | — | Filter by STRIDE category (e.g. `spoofing`, `tampering`) |
| `--pending` | false | Show only unmitigated threats |
| `--mitigate` | — | Mark a threat as mitigated by ID (e.g. `TM-ABC123`) |
| `--note` | — | Note for mitigation |
| `--json, -j` | false | Output JSON |
| `--config, -c` | auto | Config file path |

Requires an LLM provider (`ANTHROPIC_API_KEY` or `OPENAI_API_KEY`). Each threat includes:

- **Threat ID** — unique identifier (e.g. `TM-14580B`)
- **STRIDE category** — spoofing, tampering, repudiation, information_disclosure, denial_of_service, elevation_of_privilege
- **Component** — affected file or module
- **Description** — what the threat is
- **Attack vector** — how an attacker would exploit it
- **Impact** — what happens if exploited
- **Likelihood** — high, medium, or low
- **Severity** — critical, high, medium, or low
- **Mitigation** — recommended fix

Threats are stored in `out/threat_model.json`. The dashboard Threat Model tab shows threats with filters by severity, STRIDE category, and status. Each threat has a "Fix with AI" button that opens the AI chat panel with full threat context.

Also available via REST API: `GET /api/threat-model`
