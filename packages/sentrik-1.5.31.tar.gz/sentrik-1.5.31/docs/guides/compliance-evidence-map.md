# Compliance Evidence Map

The Compliance Evidence Map shows where your code **satisfies** compliance requirements — not just violations, but proof of compliance. This is essential for audits, regulatory submissions, and continuous compliance monitoring.

## Overview

Traditional scanners only tell you what's wrong. Sentrik's Evidence Map also shows what's right:

- **Met** — code evidence found that satisfies the requirement
- **Violated** — violations found by the scanner
- **Manual Review** — documentation obligation with no matching docs found
- **Not Applicable** — no files match the rule's scope

The coverage percentage tells you how many applicable requirements have verified implementations.

## Quick Start

### CLI

```bash
# Generate evidence map (HTML report)
sentrik compliance-map

# Filter by framework
sentrik compliance-map --framework "HIPAA"

# JSON output for automation
sentrik compliance-map --json

# Custom output path
sentrik compliance-map -o audit-evidence.html
```

### Dashboard

Click the **Evidence Map** tab in the sidebar (under Compliance). The dashboard shows:

- Coverage percentage and summary cards
- Framework filter dropdown
- Table grouped by standard showing each rule's status and evidence locations

### API

```bash
# Get compliance map
GET /api/compliance-map

# Filter by framework
GET /api/compliance-map?framework=HIPAA

# Force rebuild (bypasses cache)
GET /api/compliance-map?refresh=true
```

## How Evidence Is Collected

Sentrik collects evidence differently depending on the rule type:

### Required Pattern Rules

These rules define patterns that **should** exist in your code. When found, Sentrik reports the exact file and line as evidence.

**Example:** HIPAA requires audit logging. The `required_pattern` rule looks for `import logging` or similar patterns. When found:

```
HIPAA-164.312-b (required_pattern): MET
  → auth/session.py:14 — Implements audit-logging-required: import logging
  → api/patients.py:3 — Implements audit-logging-required: import logging
```

### Regex Rules (Violation Rules)

These rules flag violations. Evidence = no violations found across all scanned files.

**Example:** OWASP A01 forbids wildcard CORS. When no violations exist:

```
OWASP-A01-001 (regex): MET
  → (project-wide) — No violations of no-permissive-cors across 43 file(s)
```

### Documentation Obligations

These rules require documentation (e.g., risk management plans, security policies). Sentrik searches `.md`, `.adoc`, `.rst`, and `.txt` files for relevant keywords.

**Example:** HIPAA requires a risk analysis document. Sentrik finds it:

```
HIPAA-164.308-a1 (documentation_obligation): MET
  → docs/risk-analysis.adoc:14 — Documentation found matching: risk, analysis, vulnerabilities
```

Supported documentation formats:

- Markdown (`.md`)
- AsciiDoc (`.adoc`)
- reStructuredText (`.rst`)
- Plain text (`.txt`)

### File Policy Rules

Evidence = files that pass the policy check (e.g., docstrings present, line limits respected).

### AST Rules

Evidence = Python files that pass structural checks (e.g., no mutable defaults, acceptable complexity).

## Using Evidence Maps for Audits

### Export for Auditors

```bash
# Generate HTML report for auditors
sentrik compliance-map -o compliance-evidence.html

# Generate JSON for GRC platforms
sentrik compliance-map --json -o compliance-evidence.json
```

### Auditor Portal

Share the evidence map through the Auditor Portal:

```bash
# Create auditor access token
sentrik auditor create --name "Jane Smith" --email "jane@auditor.com"

# Start dashboard (auditor accesses via token URL)
sentrik dashboard
```

### CI/CD Integration

Add evidence map generation to your pipeline:

```yaml
# GitHub Actions
- name: Generate compliance evidence
  run: sentrik compliance-map --json -o compliance-evidence.json

- name: Upload evidence
  uses: actions/upload-artifact@v4
  with:
    name: compliance-evidence
    path: compliance-evidence.json
```

## Coverage Calculation

Coverage is calculated as:

```
coverage = met / (met + violated) * 100
```

Rules marked as "not applicable" or "manual review" are excluded from the calculation.

## Caching

The evidence map is cached at `out/compliance-map.json` after the first build. The dashboard serves from cache for fast loading. Use `?refresh=true` on the API or re-run `sentrik compliance-map` to rebuild.

## Configuration

The evidence map uses the same scan configuration as `sentrik scan`:

- **Standards packs** determine which rules are evaluated
- **scan_exclude** patterns are respected
- **Suppressions** are not applied (evidence map shows raw state)

```yaml
# .sentrik/config.yaml
standards_packs:
  - owasp-top-10
  - hipaa
  - soc2
  - fda-iec-62304

scan_exclude:
  - tests/
  - node_modules/
  - docs/
```
