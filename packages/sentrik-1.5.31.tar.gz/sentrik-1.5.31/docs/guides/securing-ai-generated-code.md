# Securing AI-Generated Code

AI coding agents ship code fast. But speed without governance creates risk — and recent supply chain compromises show that even the security tools themselves can be attack vectors.

This guide explains the threat landscape for AI-generated code and how to enforce compliance automatically with Sentrik.

## Why AI-generated code needs governance

AI coding agents (Claude Code, Copilot, Cursor, Codex) generate syntactically correct code that passes tests. But they routinely introduce patterns that violate security policies:

- **Hardcoded secrets** — AI agents copy credential patterns from training data or context windows
- **Unpinned dependencies** — generated `pip install` and `npm install` commands rarely pin versions
- **Missing input validation** — AI-generated endpoints often skip schema validation and length constraints
- **Insecure defaults** — `verify=False`, `--no-check-certificate`, and `privileged: true` appear frequently in generated CI configs

These are not hypothetical risks. They are the exact patterns that enable supply chain attacks.

## Recent incidents: your tools are targets too

Two incidents from March 2026 illustrate why governance must cover your entire toolchain, not just application code:

### CVE-2026-33634 — Aquasecurity Trivy

A supply chain compromise in Trivy — one of the most popular container security scanners — allowed attackers to inject malicious code through the tool's own dependency tree. Organizations running Trivy in CI/CD pipelines were exposed to arbitrary code execution in their build environments.

**Lesson:** Security scanning tools are high-value targets. A compromised scanner can silently approve malicious code or exfiltrate secrets from the build environment.

### CVE-2026-33017 — Langflow

A code injection vulnerability in Langflow, an AI workflow orchestration platform, allowed unauthenticated remote code execution. Attackers could execute arbitrary Python through crafted workflow definitions.

**Lesson:** AI development tools themselves are attack surfaces. The tools you use to build and orchestrate AI agents can be weaponized.

### What these incidents have in common

Both attacks targeted the **development toolchain** — the infrastructure developers trust implicitly. They succeeded because:

1. No integrity verification on tool updates (mutable tags, unpinned versions)
2. No audit trail of what ran in the build environment
3. No policy enforcement on CI/CD configuration changes

## How Sentrik addresses these threats

Sentrik provides defense-in-depth for AI-generated code across four layers:

### Layer 1: Code scanning

Every file touched by an AI agent is scanned against your active standards packs. Sentrik ships with 22 built-in packs covering major frameworks:

```bash
# Scan everything
sentrik scan

# Scope to what the AI agent just changed
sentrik scan --staged

# Enforce as a gate (exit 1 on failure)
sentrik gate --git-range "origin/main...HEAD"
```

Findings include severity, remediation guidance, and the specific standard clause violated — giving AI agents the context they need to self-correct.

### Layer 2: Supply chain security

The new **Supply Chain Security** pack (20 rules) catches the exact patterns that enabled the Trivy and Langflow compromises:

```bash
sentrik add-pack supply-chain-security
sentrik scan
```

What it catches:

| Rule | What it detects | Severity |
|------|----------------|----------|
| `SCS-CI-001` | `curl \| bash` — piping remote scripts into shell | Critical |
| `SCS-CI-003` | GitHub Actions pinned to mutable tags (`@v3`) | High |
| `SCS-CI-005` | Hardcoded secrets in CI configuration | Critical |
| `SCS-DEP-001` | Unpinned `pip install` in build scripts | Medium |
| `SCS-DEP-005` | Docker images without digest pinning | High |
| `SCS-BUILD-001` | Disabled TLS/certificate verification | High |
| `SCS-SEC-001` | Private keys committed to source control | Critical |

The full pack covers CI/CD pipeline hardening, dependency integrity, build provenance, credential hygiene, and four documentation obligations aligned to SLSA and NIST SSDF.

### Layer 3: Spec-driven compliance

If your project has an API specification, Sentrik can generate rules directly from it:

```bash
# Generate security rules from your OpenAPI spec
sentrik import-spec openapi.yaml --enable

# Works with AsyncAPI and protobuf too
sentrik import-spec events.yaml --enable
sentrik import-spec service.proto --enable
```

This catches:

- Endpoints missing authentication declarations
- Response fields exposing sensitive data (passwords, SSNs, tokens)
- Unbounded string inputs without validation constraints
- HTTP server URLs (should be HTTPS)
- Path parameters without format/pattern constraints

The generated rules are saved as a custom pack and enforced on every scan — so code that violates the API contract is flagged before it ships.

### Layer 4: Continuous monitoring

For ongoing protection against new CVEs in your dependencies:

```bash
# One-time vulnerability scan
sentrik vulns

# Auto-fix vulnerable dependencies
sentrik vulns --fix

# Watch mode: periodic scanning + auto-PR on new CVEs
sentrik watch --vulns --fix --create-pr
```

## Integrating with AI coding agents

Sentrik integrates directly into AI agent workflows through three mechanisms:

### MCP server (Claude Code, Cursor, VS Code)

The MCP server gives AI agents real-time compliance context as they write code:

```json
{
  "mcpServers": {
    "sentrik": {
      "command": "sentrik",
      "args": ["mcp-server"]
    }
  }
}
```

The agent can call `scan_file`, `check_code_snippet`, and `get_compliance_context` to validate code before committing. See the [MCP Integration guide](mcp-integration.md) for setup details.

### Pre-commit hook

Catch violations before they enter version control:

```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: sentrik
        name: sentrik scan
        entry: sentrik scan --staged
        language: system
        pass_filenames: false
```

### CI/CD gate

Enforce compliance as a merge requirement:

```yaml
# .github/workflows/sentrik-gate.yml
- name: Sentrik Gate
  run: sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
```

## Recommended configuration for AI-heavy teams

For teams where most code is AI-generated, enable these packs and settings:

```yaml
# .sentrik/config.yaml
standards_packs:
  - owasp-top-10
  - supply-chain-security

governance:
  profile: standard
  human_review_required:
    on_critical_finding: true
    on_auto_patch_above: medium
  gate:
    fail_on: [critical, high]

severity_rescoring_enabled: true
parallel_scan: true
agent_scan: true
```

This configuration:

- Scans for OWASP web vulnerabilities and supply chain risks
- Requires human review for critical findings and non-trivial auto-patches
- Blocks merges on critical and high severity issues
- Uses heuristic severity rescoring to reduce false positives
- Enables parallel scanning for faster feedback loops
- Runs each pack as an independent compliance agent in parallel

## Key takeaways

1. **AI-generated code is not inherently secure.** Agents optimize for correctness and speed, not compliance. Governance must be automated and continuous.

2. **Your toolchain is an attack surface.** The Trivy and Langflow incidents prove that dev tools are high-value targets. Pin your dependencies, verify your tools, audit your CI/CD configs.

3. **Governance should be invisible to developers.** When compliance checks run automatically in pre-commit hooks, CI/CD gates, and MCP integrations, teams get security without friction.

4. **Specs are contracts — enforce them.** If you have an OpenAPI or AsyncAPI spec, use `sentrik import-spec` to turn it into enforceable rules. The spec already defines what your API should do — make sure your code agrees.
