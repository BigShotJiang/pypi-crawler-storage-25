# CI/CD Integration

sentrik integrates with GitHub Actions, Azure Pipelines, and GitLab CI/CD to enforce quality gates on every pull request.

## GitHub Actions

### Basic gate

```yaml
name: sentrik Gate
on: [pull_request]

jobs:
  gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm install -g sentrik
      - run: sentrik gate --git-range "origin/main...HEAD"
```

### With PR decoration and status checks

Posts a compliance summary comment on the PR showing per-framework findings breakdown, blocking count, and top findings.

```yaml
      - run: sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          GUARD_GITHUB_OWNER: ${{ github.repository_owner }}
          GUARD_GITHUB_REPO: ${{ github.event.repository.name }}
```

### With SARIF upload (GitHub Code Scanning)

```yaml
      - run: sentrik scan --git-range "origin/main...HEAD"
      - uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: out/report.sarif.json
```

## Azure Pipelines

### Basic gate

```yaml
trigger:
  - main

pool:
  vmImage: ubuntu-latest

steps:
  - script: npm install -g sentrik
  - script: sentrik gate --git-range "origin/main...HEAD"
```

### With PR decoration

```yaml
  - script: |
      sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
    env:
      AZURE_DEVOPS_PAT: $(AZURE_DEVOPS_PAT)
      GUARD_AZURE_DEVOPS_ORG: $(System.TeamFoundationCollectionUri)
      GUARD_AZURE_DEVOPS_PROJECT: $(System.TeamProject)
      GUARD_AZURE_DEVOPS_REPO: $(Build.Repository.Name)
```

## GitLab CI/CD

### Basic gate

```yaml
sentrik-gate:
  stage: compliance
  image: python:3.12-slim
  before_script:
    - pip install sentrik
  script:
    - |
      if [ "$CI_PIPELINE_SOURCE" = "merge_request_event" ]; then
        sentrik gate --git-range "origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME...HEAD"
      else
        sentrik gate
      fi
  artifacts:
    when: always
    paths:
      - out/
    reports:
      junit: out/findings.junit.xml
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
```

### With SARIF for GitLab SAST

```yaml
sentrik-sast:
  stage: compliance
  image: python:3.12-slim
  before_script:
    - pip install sentrik
  script:
    - sentrik scan
  artifacts:
    reports:
      sast: out/findings.sarif
  allow_failure: true
```

A complete template is available in the repository at `templates/gitlab-ci-sentrik.yml`.

## Pre-commit hook

sentrik can scan staged files before every commit:

```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: sentrik-scan
        name: sentrik scan
        entry: sentrik pre-commit-scan
        language: system
        pass_filenames: false
        stages: [pre-commit]
```

Install the hook:

```bash
pre-commit install
```

If the pre-commit scan finds fixable issues:

```bash
sentrik fix-hook    # Auto-fix and re-stage
```

## DevOps project mismatch warning

When a DevOps provider is configured (Azure DevOps, GitHub, or Jira), sentrik checks whether the configured project name matches the local git repository name. If they differ, a warning is shown during `Test Connection` and `reconcile` to prevent accidentally syncing findings or work items to the wrong project.

## Environment variables for CI

| Variable | Purpose |
|----------|---------|
| `GUARD_LICENSE_KEY` | Enterprise license key |
| `GUARD_STANDARDS_PACKS` | Comma-separated pack list |
| `GUARD_GATE_FAIL_ON` | Override gate severities |
| `GUARD_GOVERNANCE_PROFILE` | Override governance profile |
| `AZURE_DEVOPS_PAT` | Azure DevOps authentication |
| `GITHUB_TOKEN` | GitHub authentication |
| `JIRA_TOKEN` | Jira authentication |
| `GUARD_CONFIDENCE_SCORING_ENABLED` | Enable LLM-powered confidence re-scoring (`true`) |
| `GUARD_CONFIDENCE_SCORING_MAX_FINDINGS` | Max findings to re-score per scan (default: `50`) |
| `GUARD_LLM_PROVIDER` | LLM provider for confidence scoring (`anthropic`, `openai`, `ollama`) |
| `GUARD_LLM_MODEL` | LLM model name |
| `GUARD_LLM_BASE_URL` | Base URL for LLM API (required for `ollama`) |

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | Gate passed |
| `1` | Gate failed (findings above threshold) |
