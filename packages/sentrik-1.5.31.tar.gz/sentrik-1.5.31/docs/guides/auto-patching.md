# Auto-Patching

sentrik can automatically generate and apply fixes for certain findings. When a rule has an autofix strategy defined, `sentrik scan` produces unified diff patches that you can review and apply in one command.

## How it works

1. **Scan** — `sentrik scan` evaluates your code against all enabled rules. For rules that define an autofix strategy, sentrik generates a unified diff patch for each affected file.
2. **Patch files** — Patches are written to `out/patches/` as numbered `.patch` files (e.g., `0001.patch`, `0002.patch`).
3. **Apply** — Run `sentrik apply-patches` to apply all generated patches to your source files.

```bash
# Step 1: Scan and generate patches
sentrik scan

# Step 2: Review patches (optional)
cat out/patches/0001.patch

# Step 3: Apply all patches
sentrik apply-patches
```

## Autofix strategies

Each rule can define one of three autofix strategies:

### `remove_line`

Deletes the offending line entirely. Used for code that should not exist at all, such as debug statements or wildcard imports.

**Before:**
```python
from utils import *  # flagged by no-star-imports
```

**After:** *(line removed)*

### `comment_out`

Comments out the offending line, preserving indentation. Useful when you want to keep the code visible for review but prevent it from executing.

**Before:**
```python
    eval(user_input)  # flagged by no-eval
```

**After:**
```python
    # eval(user_input)  # flagged by no-eval
```

### `replace_match`

Replaces the matched code snippet with a specified replacement string. Used when there is a known safe alternative for the flagged pattern.

**Before:**
```python
password = "hardcoded_secret"
```

**After:**
```python
password = os.environ.get("PASSWORD", "")
```

## Configuration

Auto-patching is controlled via the `governance` section in your config:

```yaml
governance:
  auto_patch:
    enabled: true
    max_severity: low  # Only auto-patch findings up to this severity
```

The `max_severity` setting prevents auto-patching of high-impact findings that should be reviewed manually. Options: `low`, `medium`, `high`, `critical`.

### Governance profiles

The built-in governance profiles set different auto-patch defaults:

| Profile | `auto_patch.enabled` | `max_severity` |
|---------|---------------------|----------------|
| **strict** | `false` | — |
| **standard** | `true` | `low` |
| **permissive** | `true` | `medium` |

## Using in CI/CD

You can integrate auto-patching into your CI pipeline to automatically fix low-severity issues:

```yaml
# GitHub Actions example
- name: Scan
  run: sentrik scan

- name: Apply auto-fixes
  run: sentrik apply-patches

- name: Commit fixes
  run: |
    git diff --quiet || (
      git add -A &&
      git commit -m "fix: apply sentrik auto-patches" &&
      git push
    )
```

!!! warning
    Auto-committing patches in CI should only be used for low-severity findings with well-understood fixes. Always review patches for critical or high-severity findings manually.

## How rules define autofix

Rules in standards packs or custom rules can specify an autofix strategy:

```yaml
rules:
  - id: SEC-001
    name: no-eval
    type: regex
    severity: critical
    pattern: "\\beval\\("
    autofix: comment_out

  - id: SEC-002
    name: no-hardcoded-secrets
    type: regex
    severity: high
    pattern: "(password|secret|api_key)\\s*=\\s*[\"'][^\"']+[\"']"
    autofix: replace_match
    autofix_replacement: 'os.environ.get("SECRET", "")'
```

The `autofix` field maps to a strategy, and `autofix_replacement` provides the replacement text for the `replace_match` strategy.

## Reviewing patches

Patches are standard unified diffs. You can inspect them with any diff viewer:

```bash
# View all patches
ls out/patches/

# Read a specific patch
cat out/patches/0001.patch

# Use git apply for a dry run
git apply --check out/patches/0001.patch
```

!!! tip
    Always review patches before applying, especially for `replace_match` fixes where the replacement may need context-specific adjustments.
