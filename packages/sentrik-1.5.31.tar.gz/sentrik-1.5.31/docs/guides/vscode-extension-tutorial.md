# SENTRA VS Code Extension Tutorial

This tutorial walks you through installing, configuring, and using the SENTRA VS Code extension to get real-time governance feedback directly in your editor.

## Prerequisites

- **VS Code** v1.85.0 or later
- **SENTRA CLI** installed via one of:
  - `pip install sentra` (Python 3.11+)
  - `npm install -g sentra` (Node.js)
  - Standalone binary on your PATH

Verify the CLI is available:

```bash
sentra --version
```

## Installation

### From the VS Code Marketplace

1. Open VS Code
2. Go to the Extensions view (`Ctrl+Shift+X` / `Cmd+Shift+X`)
3. Search for **"SENTRA"**
4. Click **Install**

### From a .vsix File

If you have a `.vsix` package (e.g., from a GitHub Release):

1. Open VS Code
2. Open the Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`)
3. Run **Extensions: Install from VSIX...**
4. Select the `.vsix` file

## First Launch — Zero-Config Setup

When you open a project folder in VS Code with the SENTRA extension installed, it automatically:

1. **Detects your project** — identifies language, framework, and CI platform
2. **Initializes config** — creates `.sentra/config.yaml` if one doesn't exist (runs `sentra init --no-interactive` behind the scenes)
3. **Runs an initial scan** — analyzes your code and displays findings immediately

You don't need to create any config files or run any commands manually. Just open your project and SENTRA starts working.

> **Note:** Auto-init and auto-scan can be disabled in settings if you prefer manual control (see [Configuration](#configuration) below).

## Understanding the Interface

### Inline Diagnostics

SENTRA findings appear as native VS Code diagnostics — the same squiggly underlines you see for TypeScript errors or ESLint warnings:

| Severity | Appearance | VS Code Level |
|----------|-----------|---------------|
| **Critical** | Red underline | Error |
| **High** | Red underline | Error |
| **Medium** | Yellow underline | Warning |
| **Low** | Blue underline | Information |
| **Info** | Dots | Hint |

Each diagnostic includes:

- The rule ID (e.g., `SEC-001`)
- A description of the issue
- Remediation guidance explaining how to fix it

You can see all findings in the **Problems** panel (`Ctrl+Shift+M` / `Cmd+Shift+M`), grouped by file.

### Status Bar

The SENTRA status bar item sits in the bottom-left of your editor and shows the current state:

| Status | Display | Meaning |
|--------|---------|---------|
| Idle | `SENTRA` (shield icon) | Extension active, no recent scan |
| Scanning | `SENTRA: scanning...` (spinner) | Scan in progress |
| Clean | `SENTRA: clean` (checkmark, green) | No findings detected |
| Issues found | `SENTRA: N issues` (shield, yellow) | N findings in your project |
| Error | `SENTRA: error` (warning, red) | Scan failed — check Output panel |

**Click the status bar item** to manually trigger a scan at any time.

### Output Channel

For detailed logs, open the **Output** panel (`Ctrl+Shift+U`) and select **SENTRA** from the dropdown. This shows:

- Scan start/finish timestamps
- CLI command being executed
- Error messages and stack traces (if something goes wrong)
- Config initialization output

## Commands

Open the Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) and type "SENTRA" to see all available commands:

### SENTRA: Run Scan

Runs a full `sentra scan` on your workspace and displays findings as inline diagnostics.

- Keyboard shortcut: Click the status bar item
- Equivalent CLI: `sentra scan`

### SENTRA: Run Gate

Runs a governance gate check against your project. This is the same gate that runs in CI/CD pipelines.

- If the gate **passes**, you'll see a success notification
- If the gate **fails**, you'll see a failure notification with the counts of findings by severity

Use this to check whether your code would pass the CI gate before pushing.

### SENTRA: Clear Diagnostics

Removes all SENTRA diagnostics from the editor. Useful if you want a clean slate before running a fresh scan, or if you're temporarily working on something where the findings are distracting.

## Automatic Scan on Save

By default, SENTRA scans your project every time you save a file. The scan is **debounced** (500ms delay) so rapid saves don't trigger multiple scans.

The scan runs in the background — you can keep editing while it processes. When complete, diagnostics update automatically.

To disable auto-scan:

1. Open Settings (`Ctrl+,` / `Cmd+,`)
2. Search for `sentra.autoScan`
3. Uncheck the box

With auto-scan disabled, use the **SENTRA: Run Scan** command or click the status bar to scan manually.

## Configuration

### Extension Settings

Open VS Code Settings and search for "sentra" to see all options:

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `sentra.autoInit` | boolean | `true` | Auto-create `.sentra/config.yaml` when opening a project without one |
| `sentra.autoScan` | boolean | `true` | Automatically scan on every file save |
| `sentra.binaryPath` | string | `""` (auto) | Path to the `sentra` CLI binary. Leave empty to auto-detect from PATH |
| `sentra.severityFilter` | array | `["critical", "high", "medium"]` | Which severity levels to show as diagnostics |

#### Severity Filter

By default, **low** and **info** severity findings are hidden to reduce noise. To see all findings:

```json
{
  "sentra.severityFilter": ["critical", "high", "medium", "low", "info"]
}
```

Or to only see critical and high severity issues:

```json
{
  "sentra.severityFilter": ["critical", "high"]
}
```

#### Custom Binary Path

If the `sentra` CLI isn't on your PATH, point the extension to it explicitly:

```json
{
  "sentra.binaryPath": "/usr/local/bin/sentra"
}
```

On Windows:

```json
{
  "sentra.binaryPath": "C:\\Users\\you\\AppData\\Local\\Programs\\sentra\\sentra.exe"
}
```

### Project Configuration

The extension uses the same `.sentra/config.yaml` (or legacy `.guard.yaml`) that the CLI uses. Common settings you might configure:

```yaml
# .sentra/config.yaml

# Standards packs to enforce
standards_packs:
  - owasp-top-10
  - soc2

# Gate thresholds — which severities block the gate
gate_fail_on:
  - critical
  - high

# Output directory for reports
output_dir: out

# Enable parallel scanning for faster results
parallel_scan: true
max_workers: 4
```

See the [Configuration Guide](configuration.md) for the full reference.

## Typical Workflows

### Workflow 1: Catch Issues While Coding

1. Open your project in VS Code
2. SENTRA auto-initializes and runs an initial scan
3. As you edit and save files, findings appear as inline diagnostics
4. Hover over a squiggly underline to see the rule and remediation guidance
5. Fix the issue and save — the diagnostic disappears on the next scan

### Workflow 2: Pre-Push Gate Check

Before pushing a branch:

1. Open the Command Palette
2. Run **SENTRA: Run Gate**
3. If it passes — push with confidence
4. If it fails — review the findings in the Problems panel and fix them

This mirrors exactly what your CI pipeline does, so there are no surprises.

### Workflow 3: Focused Review

When reviewing a specific area of the codebase:

1. Run **SENTRA: Clear Diagnostics** to start clean
2. Open the files you want to review
3. Run **SENTRA: Run Scan**
4. Review findings in the Problems panel, grouped by file

### Workflow 4: Compliance Audit Prep

For regulated environments (medical devices, fintech):

1. Configure appropriate standards packs in `.sentra/config.yaml`:
   ```yaml
   standards_packs:
     - fda-iec-62304
     - hipaa
   ```
2. Save the config — SENTRA rescans with the new rules
3. Review all findings in the Problems panel
4. Address each finding or document justification for suppression

## Troubleshooting

### "SENTRA: error" in status bar

Open the Output panel and select SENTRA to see the error details. Common causes:

- **CLI not found:** Install the `sentra` package or set `sentra.binaryPath`
- **Config error:** Run `sentra validate-config` in your terminal to check for YAML issues
- **Timeout:** Scans timeout after 120 seconds. For very large projects, consider using `parallel_scan: true` or scanning specific directories

### No diagnostics appearing

1. Check that `sentra.autoScan` is enabled
2. Check that your `sentra.severityFilter` includes the severity levels you expect
3. Verify the CLI works: run `sentra scan` in your terminal from the project root
4. Check that `out/findings.json` is generated after a scan

### Diagnostics on wrong lines

This can happen when the file has been modified since the last scan. Save the file to trigger a rescan, and the diagnostics will update to the correct positions.

### Extension not activating

The extension activates when VS Code detects any files in your workspace. If it's not activating:

1. Make sure the extension is installed and enabled
2. Check the Extensions view for any error badges on the SENTRA extension
3. Try reloading VS Code (`Ctrl+Shift+P` > **Developer: Reload Window**)

## Legacy Settings

If you were using the older "AI SDLC Guard" extension, your settings still work. The extension checks legacy settings as a fallback:

| Legacy Setting | New Setting |
|---------------|-------------|
| `ai-sdlc-guard.scanOnSave` | `sentra.autoScan` |
| `ai-sdlc-guard.guardPath` | `sentra.binaryPath` |

Legacy command IDs (`ai-sdlc-guard.scan`, `ai-sdlc-guard.gate`, `ai-sdlc-guard.clearDiagnostics`) also continue to work.

## Next Steps

- [CLI Reference](cli-reference.md) — Full list of SENTRA CLI commands
- [CI/CD Integration](ci-cd-integration.md) — Set up SENTRA in your CI pipeline
- [Dashboard Guide](dashboard.md) — Use the web dashboard for deeper analysis
- [Standards Packs Overview](../standards-packs/overview.md) — Browse available compliance packs
- [Custom Packs](../standards-packs/authoring-custom-packs.md) — Create your own rules
