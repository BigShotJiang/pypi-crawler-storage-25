# SENTRIK CLI Demo — MedFiles Infusion Pump Firmware

> **Duration:** ~35 minutes (Steps 1-18 core demo; Steps 19-22 advanced features)
> **Audience:** Developers, DevOps engineers, CI/CD pipeline architects, compliance officers
> **Story:** Clone a C++ medical device firmware project, compile it with zero warnings, then scan it with SENTRIK to reveal 38 regulatory compliance violations invisible to the compiler. Watch findings appear as Azure DevOps work items, fix them in a branch, push a PR with a passing gate, and see resolved items close automatically. Then watch an AI agent add a feature that compiles perfectly but violates three regulatory standards — and SENTRIK blocks it.

---

## Demo Tips

- **Steps 1-12** are the core story (~18 min). Everything after is bonus depth.
- **Step 7** (First Scan) is the first "wow" — pause and let the audience absorb the finding count.
- **Step 8** (Reconcile) is where the DevOps integration clicks — switch to Azure DevOps Boards live.
- **Step 21** (AI Feature) is the climax — narrate the setup, then let the scan results speak.
- Pre-prepare the fix branch (Step 10) so you can `git checkout` instead of live-editing C++.
- Keep the dashboard (`sentrik dashboard`) running in a second terminal throughout.

---

## Prerequisites

- A C++ compiler (Visual Studio with C++ workload, g++, or clang++)
- Node.js installed (for npm)
- An Azure DevOps account with a project (SENTRIK also supports GitHub and Jira)
- A terminal with a monospace font (Rich progress bars render best in modern terminals)

---

## Step 1 — Clone the Example Project

Clone the example repo:

```bash
git clone https://github.com/your-org/sentrik-example-medfiles.git
cd sentrik-example-medfiles
```

The project is an infusion pump firmware written in C++ with **intentional compliance violations** — not the kind of bugs a compiler or linter would catch, but the kind of issues that cause FDA 483 observations, failed SOC2 audits, and HIPAA breach notifications.

---

## Step 2 — Compile the Code (Zero Warnings)

Let's prove this is valid, well-formed C++ that any compiler accepts without complaint:

```bash
cmake -B build
cmake --build build
```

**Expected output:**
```
-- Configuring done
-- Generating done
-- Build files have been written to: .../build
[1/5] Building CXX object ...alarm_handler.cpp.obj
[2/5] Building CXX object ...main.cpp.obj
[3/5] Building CXX object ...network_client.cpp.obj
[4/5] Building CXX object ...patient_data.cpp.obj
[5/5] Building CXX object ...pump_controller.cpp.obj
[6/6] Linking CXX executable medfiles_pump
```

**Zero errors. Zero warnings.** The compiler is satisfied — this is syntactically valid, type-safe C++ that links cleanly into a binary.

But this code has **38 regulatory compliance violations** across three international standards. The compiler doesn't know that `printf(patient_id)` is a HIPAA violation, that `rand()` for a session token is an OWASP cryptographic failure, or that a `TODO: validate sensor range` comment is an IEC 62304 audit finding. It doesn't know because **compilers check syntax, not regulatory compliance.**

Let's bring in a tool that does.

---

## Step 3 — Install SENTRIK

```bash
npm install -g sentrik
```

Verify the installation:

```bash
sentrik --version
```

---

## Step 4 — Explore Available Packs

```bash
sentrik list-packs
```

**Expected output:**
```
PACK ID                   SOURCE     STATUS     TIER     RULES    NAME
------------------------------------------------------------------------------------------
fda-iec-62304             builtin    ENABLED    Free     31       FDA IEC 62304
owasp-top-10              builtin    ENABLED    Free     69       OWASP Top 10
soc2                      builtin    available  Free     30       SOC2 Trust Services
hipaa                     builtin    ENABLED    Free     25       HIPAA Security Rule
pci-dss                   builtin    available  Free     33       PCI DSS v4.0
iso-27001                 builtin    available  Free     32       ISO 27001:2022
iec-81001-5-1             builtin    available  Org      20       IEC 81001-5-1
fda-21cfr11               builtin    available  Org      16       21 CFR Part 11
misra-c                   builtin    available  Org      21       MISRA C/C++
iso-14971                 builtin    available  Org      16       ISO 14971
do-178c                   builtin    available  Org      22       DO-178C
iso-26262                 builtin    available  Org      23       ISO 26262

Total: 12 pack(s), 3 enabled
```

SENTRIK ships with 22 standards packs — 5 free, 11 team, and 6 at the Organization tier — covering medical devices, web security, compliance, healthcare, payments, supply chain security, PHP/Laravel, Kotlin/Android, automotive, avionics, and information security. This project already has 3 packs enabled from its config.

---

## Step 5 — Initialize with DevOps Integration

Initialize the project and select Azure DevOps as the provider:

```bash
sentrik init
```

When prompted, select:
- **Industry:** Medical device (IEC 62304)
- **Governance profile:** Strict
- **DevOps provider:** azure
- **Azure DevOps org:** `your-org`
- **Azure DevOps project:** `sentrik-example-medfiles`
- **Install a pre-commit hook?** No (say no — it would block commits during the demo since there are intentional findings)

**Expected output:**
```
✔ Created .sentrik/config.yaml
✔ Enabled pack: fda-iec-62304
✔ Governance profile: strict
✔ DevOps provider: azure
✔ Output directory: out/

Project initialized. Run 'sentrik scan' to check compliance.
```

> **What just happened?**
> `sentrik init` created a `.sentrik/config.yaml` with IEC 62304 medical device governance settings **and** Azure DevOps integration. SENTRIK will now create work items for findings and post PR status checks. The strict profile means the gate will fail on Critical, High, and Medium severity findings.

> **Presenter tip — OAuth connection:**
> If you have `sentrik dashboard` running in a second terminal, open **http://localhost:8000/dashboard**, go to the **Integration** tab, and click **"Connect to Azure DevOps"**. Sign in with your Microsoft account — no PAT or secrets needed. SENTRIK stores the OAuth token locally and auto-refreshes it. If SENTRIK detects that the configured DevOps project name doesn't match your local git repo, it shows a warning — preventing accidental syncs to the wrong project.

---

## Step 6 — Enable Additional Packs

Since this is a connected medical device handling patient data over a network, let's add HIPAA and OWASP:

```bash
sentrik add-pack hipaa
sentrik add-pack owasp-top-10
```

Verify:

```bash
sentrik list-packs
```

Now `fda-iec-62304`, `hipaa`, and `owasp-top-10` are enabled — 125 rules covering medical device safety (Class C software), healthcare data protection, and network security.

---

## Step 7 — First Scan

```bash
sentrik scan
```

**Expected output:**
```
Scan Complete
  Severity    Count
  critical        6
  high           25
  medium          7
  info           24

  Compliance Score: 85.6%  (107 of 125 rules passed)

  File                       Findings
  src/patient_data.cpp             11
  src/network_client.cpp            9
  src/pump_controller.cpp           9
  src/alarm_handler.cpp             7

Output: out/findings.json
```

62 total findings — 38 code violations plus 24 documentation obligations (non-code compliance items like "create a threat model" that auditors expect to see tracked). The findings include:

**Cross-standard violations (the same line of code violates multiple frameworks):**
- **Hardcoded API key** in `patient_data.cpp` — flagged by IEC 62304, OWASP A02, and HIPAA §164.312(d) simultaneously (3 findings from one line). Enable SOC2 and PCI packs and it hits 5 standards.
- **`http://` URL** in `network_client.cpp` — flagged by OWASP A05 and HIPAA §164.312(e) (2 findings from one line)

**Domain-specific violations (invisible to compilers and linters):**
- **`rand()`/`srand()`** for session token generation — compiles perfectly, but OWASP A02 requires a CSPRNG (3 findings)
- **`TODO: validate sensor input range`** — not a code bug, but IEC 62304 treats this as evidence of an unimplemented safety control
- **Patient ID in `printf()` output** — compiles fine, but HIPAA §164.312 prohibits PHI in stdout (3 findings)
- **Patient data written to unencrypted `ofstream`** — compiles fine, but HIPAA requires encryption at rest
- **`FIXME: add certificate pinning`** — IEC 62304 treats this as an acknowledged but unresolved safety gap

**Safety-critical violations (IEC 62304 Class C):**
- **`malloc()` dynamic memory** in dosage calculation path — heap fragmentation risk in safety-critical firmware
- **`signal()` handler** — non-deterministic behavior in safety-critical context
- **`goto`** for error recovery — violates structured programming requirements for Class C software
- **`system()` call** — shell injection risk in firmware

> **What just happened?**
> `sentrik scan` analyzed all C++ source files against 125 rules from three enabled packs. Unlike a compiler or linter, SENTRIK maps each finding to the specific regulatory clause it violates — so you know this isn't just "bad practice" but a specific compliance gap. The cross-standard findings show that one line of code can create liability under multiple regulatory frameworks simultaneously.

---

## Step 8 — Reconcile Findings to Work Items

This is where SENTRIK connects to your DevOps workflow. Run reconcile to push findings to Azure DevOps:

```bash
sentrik reconcile
```

**Expected output:**
```
Reconcile complete: 10 created, 0 updated, 0 closed

10 work item(s) synced.
```

**Now check your Azure DevOps Boards.** You'll see new work items like:

| # | Title | Type | Severity | Standards Hit |
|---|-------|------|----------|---------------|
| 1 | [OWASP-A02-003] no-hardcoded-secrets | Issue | Critical | OWASP + HIPAA + IEC 62304 |
| 2 | [OWASP-A03-006-CPP] no-scanf-unbounded-cpp | Issue | High | OWASP A03 |
| 3 | [OWASP-A03-007-CPP] no-format-string-vuln | Issue | Critical | OWASP A03 |
| 4 | [IEC62304-5.5.5-CPP] no-unsafe-memory-ops-cpp | Issue | High | IEC 62304 §5.5.5 |
| 5 | [OWASP-A02-001-CPP] no-md5-openssl-cpp | Issue | High | OWASP A02 |
| 6 | [HIPAA-164.312-a2-CPP] no-phi-in-stdout | Issue | High | HIPAA §164.312 |
| 7 | [HIPAA-164.312-a2-CPP2] no-unencrypted-phi-file-io | Issue | High | HIPAA §164.312 |
| 8 | [OWASP-A02-004-CPP] no-unsafe-random-cpp | Issue | Medium | OWASP A02 |
| 9 | [IEC62304-CODE-005] no-todo-in-medical | Issue | Medium | IEC 62304 |
| ... | ... | ... | ... | ... |

Each work item includes rich HTML-formatted descriptions (not raw markdown) with:
- **Rule ID and standard clause** (e.g., IEC 62304 §5.5.5, OWASP A02:2021, HIPAA §164.312(a)(2))
- **Severity** and finding count
- **Affected files** with line numbers in `<code>` tags
- **Remediation guidance** — domain-specific fix instructions (e.g., "Use `std::random_device` or platform CSPRNG instead of `rand()` for any security-relevant value generation")
- **Acceptance criteria** — structured `<ul>` checklist for verifying the fix

> **What separates this from a generic SAST tool?**
>
> Notice that the hardcoded API key (Work Item #1) cites **three regulatory standards** — OWASP, HIPAA, and IEC 62304. Enable SOC2 and PCI packs and it hits five. A generic SAST tool would create one "hardcoded secret" finding. SENTRIK tells you *which regulations you're violating* and *which auditors will flag it*. When you fix it, all standards are satisfied by one code change — and all corresponding compliance clauses show as resolved in your compliance report.
>
> Also notice Work Item #9 — a `TODO` comment. No compiler or linter treats this as a compliance issue. But IEC 62304 §5.5.3 requires that all safety-relevant code is verified. A `TODO: validate sensor range` comment is evidence that a safety control was designed but never implemented. An FDA auditor would flag this as a Class C software deficiency.

> **What just happened?**
> `sentrik reconcile` compared scan findings against existing Azure DevOps work items. For each finding group (by rule), it created a new work item with full context, regulatory citations, and acceptance criteria. On subsequent runs, it updates existing items or closes them when findings are resolved — keeping your backlog perfectly in sync with your compliance state.

---

## Step 9 — Gate Check (Expect FAIL)

```bash
sentrik gate
echo "Exit code: $?"
```

**Expected output:**
```
Compliance Score: 85.6%  (107 of 125 rules passed)

GATE FAILED
critical=6  high=25  medium=7

Exit code: 1
```

The gate returns **exit code 1** (failure). In a CI pipeline, this would block the merge.

---

## Step 10 — Fix the Findings in a Branch

> **Presenter tip:** Pre-prepare a branch with these fixes before the demo. During the live demo, just `git checkout fix/compliance-findings` instead of editing files. The audience cares about the *before/after*, not watching you type C++.

Create a feature branch for the fixes:

```bash
git checkout -b fix/compliance-findings
```

Edit the source files to resolve the critical and high issues:

**`src/pump_controller.cpp`** — Replace unsafe memory and string operations:

```cpp
// Before: strcpy(rate_label, input);
strncpy(rate_label, input, sizeof(rate_label) - 1);
rate_label[sizeof(rate_label) - 1] = '\0';

// Before: char* buf = (char*)malloc(BUF_SIZE);
static char buf[BUF_SIZE];  // static allocation — no heap fragmentation in safety path

// Before: srand(time(0)); int token = rand();
// After: use platform CSPRNG for session tokens
#include <random>
std::random_device rd;
std::mt19937 gen(rd());

// Before: // TODO: validate sensor input range
// After: implement the actual validation
if (sensor_reading < 0.0 || sensor_reading > MAX_FLOW_RATE) {
    raise_alarm(ALARM_SENSOR_OUT_OF_RANGE);
    return SAFE_DEFAULT_RATE;
}
```

**`src/patient_data.cpp`** — Remove hardcoded secret, fix all PHI exposure:

```cpp
// Before: const char* API_KEY = "sk-mdf-4a7b2c9e1f...";
const char* api_key = std::getenv("MEDFILES_API_KEY");  // resolves OWASP + HIPAA + SOC2 + PCI

// Before: printf("Processing patient: %s\n", patient_id);
spdlog::info("Processing patient record");  // no PHI in output

// Before: ofstream out("patient_export.csv"); out << patient_id << ...;
// After: use encrypted file I/O
auto out = create_encrypted_stream("patient_export.csv.enc", encryption_key);

// Before: throw std::runtime_error("Invalid record for patient " + patient_id);
throw std::runtime_error("Invalid record format");  // no PHI in exception messages
```

**`src/alarm_handler.cpp`** — Replace gets(), fix empty catch, remove goto/signal:

```cpp
// Before: gets(alarm_code);
fgets(alarm_code, sizeof(alarm_code), stdin);

// Before: catch (...) { }
catch (const std::exception& e) {
    spdlog::error("Alarm handler error: {}", e.what());
    enter_safe_state();
}

// Before: goto cleanup;
// After: use RAII or structured control flow for cleanup

// Before: signal(SIGINT, handler);
// After: use platform-specific safe shutdown mechanism
```

**`src/network_client.cpp`** — Fix TLS, replace MD5, resolve FIXME:

```cpp
// Before: http://telemetry.medfiles.io/api/v1/upload
// After:
const char* TELEMETRY_URL = "https://telemetry.medfiles.io/api/v1/upload";

// Before: MD5_Init(&ctx);
SHA256_Init(&ctx);  // OWASP A02 + ISO 27001 A.8.24

// Before: // FIXME: add certificate pinning
// After: implement certificate pinning
curl_easy_setopt(curl, CURLOPT_PINNEDPUBLICKEY, "sha256//YhKJG7...");
```

**`src/main.cpp`** — Remove debug mode, fix injection vectors:

```cpp
// Before: #define DEBUG true
// After: remove or guard behind build flag
#ifdef NDEBUG
  #define DEBUG false
#else
  #define DEBUG true
#endif

// Before: system(command_buffer);
// After: use exec() family with explicit arguments (no shell interpretation)
execvp(args[0], args);

// Before: printf(user_msg);  // format string vulnerability
printf("%s", user_msg);
```

Commit the fixes:

```bash
git add -A
git commit -m "fix: resolve critical/high compliance findings across 4 standards

- Replace rand()/srand() with std::random_device (OWASP-A02-004)
- Replace malloc with static allocation in safety path (IEC62304-5.5.5)
- Implement sensor input validation that was TODO (IEC62304-CODE-005)
- Remove hardcoded API key, use env var (OWASP+HIPAA+SOC2+PCI)
- Redact patient ID from printf, exceptions, file I/O (HIPAA-164.312)
- Encrypt patient data file output (HIPAA-164.312-a2)
- Replace gets() with fgets() (OWASP-A03-004)
- Add error handling to empty catch block (SOC2-CC7-001)
- Remove goto and signal() (IEC62304-CODE-007, IEC62304-CODE-006)
- Upgrade http:// to https:// (OWASP+HIPAA+PCI cross-standard)
- Replace MD5 with SHA-256 (OWASP-A02-001 + ISO27001-A8.24)
- Implement certificate pinning (resolved FIXME)
- Remove DEBUG=true (OWASP+HIPAA+PCI cross-standard)
- Fix format string vulnerability (OWASP-A03-007)
- Replace system() with execvp() (OWASP-A03-003)"
```

---

## Step 11 — Re-Scan, Gate, and Push

```bash
sentrik scan
sentrik gate
echo "Exit code: $?"
```

**Expected output:**
```
Gate: PASS

0 critical findings (threshold: 0)
0 high findings (threshold: 0)
0 medium findings (threshold: 0)

Exit code: 0
```

The gate passes. Now push and open a PR:

```bash
git push -u origin fix/compliance-findings

sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
```

**Check your Azure DevOps PR:**
- The PR has a **SENTRIK status check** (green ✓ pass)
- The PR has a **comment from SENTRIK** showing the scan summary — 0 critical, 0 high, gate passed
- This is the same check that would run automatically in CI (see the Azure Pipelines section)

---

## Step 12 — Reconcile Again — Watch Work Items Close

```bash
sentrik reconcile
```

**Expected output:**
```
Reconcile complete: 0 created, 0 updated, 7 closed

7 work item(s) synced.
```

**Check Azure DevOps Boards again.** The work items for resolved findings are now **Closed** — including the cross-standard ones:

- ~~#1 [OWASP-A02-003] no-hardcoded-secrets~~ — **Closed** (resolved across OWASP, HIPAA, IEC 62304 simultaneously)
- ~~#2 [OWASP-A03-006-CPP] no-scanf-unbounded-cpp~~ — **Closed**
- ~~#3 [OWASP-A03-007-CPP] no-format-string-vuln~~ — **Closed**
- ~~#4 [IEC62304-5.5.5-CPP] no-unsafe-memory-ops-cpp~~ — **Closed**
- ~~#5 [OWASP-A02-001-CPP] no-md5-openssl-cpp~~ — **Closed**
- ~~#6 [HIPAA-164.312-a2-CPP] no-phi-in-stdout~~ — **Closed**
- ~~#7 [HIPAA-164.312-a2-CPP2] no-unencrypted-phi-file-io~~ — **Closed**
- ...and more

Work items for remaining Low/Info findings stay open — they're tracked but don't block the gate.

> **Key concept: Gate-blocking vs. tracked findings**
>
> The gate only blocks on **Critical**, **High**, and **Medium** findings (configurable via `gate_fail_on`). But your scan may still produce Low and Info findings that represent real work:
>
> - **Low findings** — code quality issues (`signal()` handlers, missing header guards) that should be addressed but don't block a release
> - **Info findings** — **documentation obligations** like "create a threat model" or "document risk assessment." These are non-code compliance items required by IEC 62304, HIPAA, and SOC2. They'll never fail the gate, but auditors expect them to be tracked as work items.
>
> `sentrik reconcile` creates, updates, and closes work items automatically — so nothing falls through the cracks and your backlog always reflects the current compliance state.

---

## Step 13 — Async Approval Gate (Enterprise)

In regulated environments, even a passing gate may require human sign-off before code reaches production. Let's simulate a realistic scenario: the `network_client.cpp` telemetry uplink still uses `http://localhost:9090` for a local Prometheus metrics scrape. The OWASP `no-http-urls` rule flags it as Medium — but the security lead knows localhost traffic never leaves the device.

First, add the flagged line to `src/network_client.cpp`:

```cpp
static const char* METRICS_ENDPOINT = "http://localhost:9090/metrics";  // local Prometheus scrape
```

Re-scan and run the gate with `--require-approval`:

```bash
sentrik scan
sentrik gate --require-approval
echo "Exit code: $?"
```

**Expected output:**
```
Gate: FAIL

0 critical findings (threshold: 0)
0 high findings (threshold: 0)
1 medium findings (threshold: 0)

  APPROVAL REQUIRED: a1b2c3d4-...
  Resolve via: sentrik approve <id> --action approved
  Check status: sentrik approval-status <id>

Exit code: 1
```

The gate fails because of the medium `http://` URL — but this is a localhost-only metrics endpoint on the device itself, not a security risk. The security lead reviews and approves:

```bash
sentrik approve <approval-id> --action approved \
  --comment "Accepted risk: localhost metrics endpoint on device loopback interface. No TLS required per OWASP A05 exception for loopback traffic. Documented in risk assessment RA-2026-041." \
  --user "jane.chen@medfiles.com"
```

**Expected output:**
```
Approval a1b2c3d4-...: approved
  Comment: Accepted risk: localhost metrics endpoint on device loopback interface...
```

> **Why this matters for auditors:**
>
> The approval is recorded in the audit log with the reviewer's identity, timestamp, and justification. When an FDA auditor asks "why did you ship firmware with an HTTP URL?", the answer is traceable: Jane Chen approved it today, citing the OWASP A05 loopback exception and referencing risk assessment RA-2026-041. The audit entry export includes the full policy decision chain.
>
> In the dashboard, the Approvals tab shows all pending and resolved requests. Approvals can also create Azure DevOps work items to track the accepted risk going forward.

Now revert the test line and re-scan to continue with a clean state:

```bash
# Remove the test line from src/network_client.cpp, then:
sentrik scan
sentrik gate
```

---

## Step 14 — Generate Reports

```bash
# HTML report — interactive, stakeholder-ready
sentrik report --format html

# SARIF report — for code scanning integration
sentrik report --format sarif

# Compliance report — per-framework regulatory mapping
sentrik compliance-report -f "IEC 62304"

# Trust center — public-safe compliance page (no code/paths exposed)
sentrik trust-center --org "MedFiles Inc"
```

Open `out/report.html` in a browser to see:
- **Donut chart** — Severity breakdown
- **Filter buttons** — Toggle severities on/off
- **Sortable table** — Click column headers
- **Expandable rows** — Click for finding details
- **Dark mode support** — Matches system preference
- **Print-ready** — Ctrl+P produces a clean PDF

Open `out/compliance-report-iec-62304.html` for a clause-by-clause IEC 62304 compliance report with pass/fail status per clause and remediation guidance.

Open `out/trust-center.html` for a shareable compliance posture page with overall score, severity distribution, and per-framework breakdown — safe to share with customers or auditors.

---

## Step 15 — SBOM & Dependency Vulnerability Scan

> **Presenter tip:** This step shows supply chain security — a hot topic after Log4j, SolarWinds, and the EU Cyber Resilience Act. FDA also now requires SBOMs for medical device submissions.

Generate a Software Bill of Materials, then scan dependencies for known vulnerabilities:

```bash
# Generate SBOM (CycloneDX format — also supports SPDX)
sentrik sbom
```

**Expected output:**
```
SBOM generated: 12 component(s) from 1 manifest(s)
Output: out/sbom.json
```

Now scan those dependencies against the OSV.dev vulnerability database:

```bash
sentrik vulns
```

**Expected output (if vulnerabilities exist):**
```
Vulnerability Scan
  Total dependencies: 12
  Vulnerable:          2

  SEVERITY  PACKAGE              VERSION   CVE              FIX       FRAMEWORKS
  high      openssl              1.1.1k    CVE-2023-0286    1.1.1t    PCI DSS 6.3, SOC2 CC7.1, OWASP A06
  medium    curl                 7.79.1    CVE-2023-27534   7.88.0    PCI DSS 6.3, SOC2 CC7.1

Output: out/vulnerabilities.json
```

Each vulnerability is mapped to the compliance frameworks that require you to address it. The `FIX` column shows the earliest version with a patch — so your developer knows exactly what to upgrade to.

> **Why this matters:**
>
> The FDA's 2023 cybersecurity guidance requires a Software Bill of Materials for every medical device submission. The EU Cyber Resilience Act mandates SBOM disclosure for all connected products. PCI DSS 6.3 requires known vulnerability remediation. SENTRIK generates the SBOM and checks it for vulnerabilities in one step — mapped to the frameworks your auditor cares about.

---

## Step 16 — Evidence Export for Auditors

When it's audit time, compliance teams spend weeks gathering evidence: scan results, gate passes, approval records, remediation proof. SENTRIK packages all of this automatically:

```bash
# Export audit evidence mapped to IEC 62304 controls
sentrik evidence-export -f "IEC 62304"

# Export for SOC2
sentrik evidence-export -f "SOC2"

# See all available frameworks
sentrik evidence-export --list
```

**Expected output:**
```
Evidence package generated: IEC 62304
  Controls evaluated: 3
  Controls passing:   3
  Evidence items:     14

Output: out/evidence-iec-62304.html
```

Open `out/evidence-iec-62304.html` — it's a standalone HTML report organized by regulatory control:

- **§5.1 Software Development Planning** — Pass. Evidence: scan configuration, enabled packs, governance profile.
- **§5.5 Software Detailed Design and Unit Implementation** — Pass. Evidence: 0 implementation findings, gate passed, work items closed.
- **§5.7 Software Verification** — Pass. Evidence: 125 rules evaluated, compliance score 100%, scan timestamp.

Each control shows the evidence items with timestamps, so the auditor can trace exactly when each check was performed and what the result was.

> **The time saved:**
>
> Without SENTRIK, preparing evidence for an IEC 62304 audit means manually collecting screenshots, exporting Jira queries, cross-referencing git history, and writing a narrative for each control. With SENTRIK, it's one command. The evidence is generated from the same data used by the scan and gate — so it's always consistent and up to date.

---

## Step 17 — Compare Scan Runs

> **Presenter tip:** This step is optional if time is short. It's a quick visual payoff showing the before/after delta.

```bash
sentrik compare
```

**Expected output:**
```
Scan Comparison:
  Previous: 38 findings
  Current:   0 findings

  ✔ Fixed:  38
  ● New:     0

Delta: -38 findings (100% reduction)
```

---

## Step 18 — Start the Dashboard

> **Presenter tip:** Have this running in a second terminal from the start. Switch to the browser after key CLI steps (scan, reconcile, gate) to show results updating in real time. The governance banner on the Overview tab changes color based on gate status — red when blocked, green when passing.

```bash
sentrik dashboard --port 8000
```

Open **http://localhost:8000/dashboard** in your browser.

Everything done via the CLI — including Azure DevOps-synced work items — is reflected in the dashboard:
- **Overview** — Scan metrics, compliance score, severity charts, governance status
- **Findings** — Severity filter pills with a filter-active indicator banner, bulk selection via header checkbox, interactive filtering by rule, file, and framework
- **Rules** — Filtering by severity, type, and standard, plus grouping and sortable columns
- **Work Items** — Azure DevOps items synced by reconcile, with open/closed status
- **Packs** — All 6 standards packs visible, 3 enabled, with rule browser
- **Trend Chart** — Findings trend lines are toggleable — click legend items to show/hide individual severity lines
- **Integration** — Work item types are dynamically fetched from Azure DevOps after Test Connection, with available/unavailable visual distinction (unavailable types greyed out with tooltip)
- **Audit Log** — Timeline of every scan, gate, reconcile, and approval action. Each entry can be exported as a standalone HTML report. "Export Audit Bundle" downloads a zip of all scan artifacts for auditors.
- **Settings** — Governance profile, gate thresholds, notification config

---

## Step 19 — Continuous Monitoring

Instead of running `sentrik scan` manually after every edit, let SENTRIK watch for file changes and re-scan automatically:

```bash
sentrik watch
```

**Expected behavior:**

SENTRIK monitors your source files for changes. When you save a file, it detects the modification and triggers a new scan within a few seconds. The terminal shows a live stream of scan results as you edit.

For scheduled periodic scanning (useful in CI or long-running dev sessions), add an interval:

```bash
# Re-scan every 5 minutes regardless of file changes
sentrik watch --interval 300
```

Press **Ctrl+C** to stop watching. The watcher respects `scan_exclude` patterns from your config, only monitors source files matching your enabled packs, and debounces rapid saves to avoid redundant scans.

> **When to use this:**
>
> During active development — especially when an AI agent is making changes across multiple files — `sentrik watch` gives you instant feedback on every save. You don't have to remember to run `sentrik scan` after each change. Combined with the dashboard (`sentrik dashboard`), you get a live compliance view that updates as code changes land.

---

## Step 20 — Confidence Scoring

Not all findings are created equal. A hardcoded secret in production code is a definite violation; the same pattern inside a string literal or test file is less certain. SENTRIK assigns variable **confidence scores** to each finding based on where the match occurs.

Run a scan and inspect the findings:

```bash
sentrik scan
```

Open `out/findings.json` and look at the `confidence` field on each finding. You'll see values like:

| Confidence | Meaning | Example |
|------------|---------|---------|
| **1.0** | Match in executable code — definite violation | `strcpy(buf, input)` in `pump_controller.cpp` |
| **0.7** | Match in a test file — likely intentional for testing | `strcpy()` in `tests/test_utils.cpp` |
| **0.5** | Match inside a comment — informational only | `// old code: strcpy(buf, input)` |
| **0.4** | Match inside a string literal — documentation, not code | `"strcpy is unsafe"` in a help message |

Heuristic confidence scoring is **always on** — no configuration needed. When confidence is below 1.0, the finding is marked `deterministic=false`, which means severity rescoring (if enabled) can further adjust its priority.

### Optional: LLM-powered confidence scoring

For teams that want AI-assisted triage, SENTRIK can send ambiguous findings to an LLM for deeper analysis. This is entirely optional — SENTRIK works fully without any LLM.

```bash
# Enable LLM confidence scoring (optional — works with any provider)
export GUARD_CONFIDENCE_SCORING_ENABLED=true
export GUARD_LLM_PROVIDER=openai  # or anthropic, ollama
export OPENAI_API_KEY=sk-...
sentrik scan
```

The LLM evaluates each finding's surrounding code context and returns a refined confidence value. This is useful for large codebases where manual triage of hundreds of findings is impractical.

> **Key point:** SENTRIK is a fully local, deterministic tool by default. Heuristic confidence scoring runs without any external API calls. LLM scoring is opt-in and additive — it refines confidence but never changes the rules or the gate logic.

---

## Step 21 — AI Adds a Feature (Live Governance)

> **Presenter tip:** This is the climax of the demo. Slow down here. Let the audience read the finding table. The punchline is that the code *compiles, runs, and fulfills the requirement* — but it cannot ship. That gap between "works" and "compliant" is SENTRIK's entire value proposition.

This is the key demo moment: **an AI coding agent builds a new feature, and SENTRIK catches what the AI missed.**

### The scenario

A product manager requests a new **Dose History Log** — the pump should record every dosage change with a timestamp and display it in the simulator. The team asks an AI agent (Copilot, Claude, Cursor, etc.) to implement it.

### Narrate, then stage the file

Tell the audience: *"Let's say we prompted an AI agent to add dose history logging. It generated this file — it compiles cleanly and fulfills the requirement. Let's see what SENTRIK thinks."*

Copy the pre-written AI-generated file into `src/` and stage it:

```bash
cp demo/dose_history.cpp src/
git add src/dose_history.cpp
```

You can open `src/dose_history.cpp` briefly to show the audience — it's clean, well-structured code that looks like any competent developer (or AI) would write: structs, a history buffer, CSV logging, console output. Nothing obviously wrong.

### Run SENTRIK on the staged changes

```bash
sentrik scan --staged
```

**9 findings from one file — across 3 regulatory standards:**

| # | Finding | Rule | Standard | Why the AI missed it |
|---|---------|------|----------|---------------------|
| 1-3 | `strcpy()` x3 for patient_id, nurse_id, event_type | IEC62304-5.5.5-CPP | IEC 62304 S5.5.5 | AI knows strcpy works; doesn't know it's banned in Class C medical software |
| 4-5 | Patient ID in `printf()` output x2 | HIPAA-164.312-a2-CPP | HIPAA S164.312 | AI adds logging as good practice; doesn't know PHI can't go to stdout |
| 6 | Unencrypted `ofstream` writing PHI to CSV | HIPAA-164.312-a2-CPP2 | HIPAA S164.312 | AI fulfills the requirement literally; doesn't know PHI requires encryption at rest |
| 7-9 | `strcpy()` x3 (also flagged by OWASP) | OWASP-A03-005-CPP | OWASP A03:2021 | Same strcpy, different standard — cross-standard correlation |

### The gate blocks the merge

```bash
sentrik gate --staged
# Exit code: 1 — FAIL
```

The AI's code compiles, runs correctly, and fulfills the product requirement — but it **cannot ship** because it violates three regulatory standards. The developer now has clear, actionable findings telling them exactly what to fix and which clauses require it.

### Fix and re-gate

The developer (or the AI, with SENTRIK's findings as context) fixes the issues:
- Replace `strcpy` -> `strncpy` with bounds
- Encrypt the CSV output or use a secure audit log
- Redact patient IDs from `printf()` output

```bash
sentrik scan --staged
sentrik gate --staged
# Exit code: 0 — PASS
```

> **The takeaway for the audience:**
>
> AI coding agents are fast but compliance-blind. They generate code that compiles, passes tests, and fulfills requirements — but they don't understand HIPAA, IEC 62304, or OWASP. SENTRIK acts as the **governance guardrail** that catches what the AI misses, before non-compliant code reaches production. The developer still moves fast — they just can't ship code that violates regulatory standards.
>
> This is the core value proposition: **AI writes the code, SENTRIK enforces the rules, humans approve the exceptions.**

---

## Step 22 — Requirement Drift Detection

> **Presenter tip:** This step completes the governance trifecta. Step 7 showed SENTRIK catching *code-level violations*. Steps 8/12 showed *work item drift* — findings syncing to DevOps as code changes. This step shows *requirement drift* — when code diverges from what the spec says should exist. These are three distinct failure modes, and SENTRIK covers all of them.

### Why this matters

In regulated environments (FDA, ISO, SOC2), auditors don't just ask "does the code have bugs?" They ask:

1. **"Does every requirement have implementing code?"** — If your spec says "the system shall encrypt patient data at rest" but no code does that, you have a gap.
2. **"Does every source file trace back to a requirement?"** — If code exists that nobody asked for, it's untested scope creep.
3. **"Has the code drifted from the spec since your last audit?"** — If a developer (or AI) deleted, renamed, or rewrote a file, the requirement mapping may be broken.

Compilers don't check this. Linters don't check this. Most SAST tools don't either. SENTRIK does.

### Set up the scenario

This project includes a `requirements.yaml` that maps each requirement to its implementing source files:

```bash
cat requirements.yaml
```

**Key excerpt:**
```yaml
requirements:
  - req_id: REQ-001
    title: Infusion rate control
    description: The pump shall allow setting infusion rate between 0.1 and 999.9 mL/hr...
    source_files:
      - src/pump_controller.cpp

  - req_id: REQ-006
    title: Dose history logging
    description: The system shall log all dosage changes with timestamps to an encrypted audit trail...
    source_files:
      - src/dose_history.cpp
```

In Step 21, an AI agent created `src/dose_history.cpp` to implement REQ-006. But what if someone deletes that file, or the AI never created it? Let's simulate that:

```bash
# Temporarily remove the AI-generated file to simulate drift
mv src/dose_history.cpp src/dose_history.cpp.bak
```

### Detect the drift

```bash
sentrik verify-reqs
```

**Expected output:**
```
Verifying 6 requirement(s) against source code...

  [MEDIUM] [REQ-006] Source file 'src/dose_history.cpp' referenced in requirement no longer exists
    File: src/dose_history.cpp
    Fix: Remove 'src/dose_history.cpp' from the requirement's source_files, or restore the file

1 drift finding(s) detected.
```

SENTRIK found that REQ-006 ("Dose history logging") references a file that doesn't exist. In an FDA audit, this is a gap — the requirements spec promises functionality that isn't in the codebase.

Now restore the file:

```bash
mv src/dose_history.cpp.bak src/dose_history.cpp
sentrik verify-reqs
```

```
Verifying 6 requirement(s) against source code...

0 drift finding(s) detected.
```

The drift is resolved — the file exists and the requirement mapping is intact.

### Check traceability

There's a second layer: even when the file exists, does it *reference* the requirement? In IEC 62304, every safety-critical source file must contain a traceability comment linking it back to a requirement ID.

```bash
sentrik trace
```

**Expected output:**
```
Traceability Matrix
  File                         Requirement References
  src/pump_controller.cpp      REQ-001
  src/patient_data.cpp         REQ-002, REQ-003
  src/network_client.cpp       REQ-004
  src/alarm_handler.cpp        REQ-005
  src/dose_history.cpp         (none)          ← no REQ-xxx reference found
  src/main.cpp                 (none)

  Files with traceability: 4/6
  Files missing references: 2
```

Notice `src/dose_history.cpp` — the AI created this file in Step 21, and it compiles, runs, and (after our fixes) passes all compliance checks. But the AI used its own invented ID (`DOSE-HIST-001` in a comment) instead of `REQ-006` from the requirements spec. An auditor would flag this: the code exists, but it's not traceable to the documented requirement.

The fix is simple — add `// REQ-006` to the file header — but the point is that SENTRIK caught the gap automatically.

### The three layers of governance

This completes the picture of what SENTRIK tracks:

| Layer | Command | What it catches | Example |
|-------|---------|-----------------|---------|
| **Code violations** | `sentrik scan` | Patterns that violate regulatory rules | `strcpy()` banned in Class C software |
| **Work item drift** | `sentrik reconcile` | Findings that need DevOps tracking | New finding → create work item; fixed finding → close it |
| **Requirement drift** | `sentrik verify-reqs` | Code that doesn't match the spec | REQ-006 references a file that doesn't exist |
| **Traceability gaps** | `sentrik trace` | Source files with no requirement link | AI-generated code with no `REQ-xxx` reference |

> **The takeaway:**
>
> AI agents implement features fast, but they don't maintain requirement traceability. They invent their own reference IDs, skip traceability comments, or implement features that don't match the spec. In IEC 62304, every line of safety-critical code must trace back to a documented requirement.
>
> `sentrik scan` catches what compilers miss. `sentrik reconcile` keeps your backlog in sync. `sentrik verify-reqs` and `sentrik trace` ensure your requirements spec and your codebase tell the same story. Together, they give you full traceability: **requirements → code → findings → work items → audit trail.**

---

## Summary of CLI Commands Demonstrated

| # | Command | What it does | Key flags |
|---|---------|--------------|-----------|
| 1 | `sentrik init` | Initialize project + DevOps config | Interactive prompts |
| 2 | `sentrik list-packs` | Show available standards packs | — |
| 3 | `sentrik add-pack` | Enable a standards pack | Pack ID as argument |
| 4 | `sentrik scan` | Scan files against all rules | `--staged`, `--git-range` |
| 5 | `sentrik gate` | Enforce pass/fail policy | `--require-approval`, `--decorate-pr` |
| 6 | `sentrik reconcile` | Sync findings to DevOps work items | `--dry-run` |
| 7 | `sentrik approve` | Approve/reject async gate request | `--action`, `--comment`, `--user` |
| 8 | `sentrik report` | Generate formatted report | `--format html/sarif/junit` |
| 9 | `sentrik compliance-report` | Per-framework compliance report | `--framework`, `--list` |
| 10 | `sentrik trust-center` | Public-safe compliance page | `--org`, `--json` |
| 11 | `sentrik evidence-export` | Audit evidence mapped to controls | `--framework`, `--all`, `--json` |
| 12 | `sentrik sbom` | Generate Software Bill of Materials | `--format cyclonedx/spdx` |
| 13 | `sentrik vulns` | Scan dependencies for known CVEs | `--json` |
| 14 | `sentrik compare` | Show finding delta between runs | `--previous` |
| 15 | `sentrik dashboard` | Start dashboard + API server | `--port`, `--host` |
| 16 | `sentrik watch` | Continuous monitoring — auto-rescan on save | `--interval`, `--quiet` |
| 17 | `sentrik verify-reqs` | Detect requirement drift | — |
| 18 | `sentrik trace` | Show traceability matrix | — |

**Built-in capabilities (no separate command needed):**
- **Confidence scoring** — every finding has a confidence value (1.0 = code, 0.7 = test, 0.5 = comment, 0.4 = string). Opt-in LLM re-scoring available via `GUARD_CONFIDENCE_SCORING_ENABLED=true`.
- **Project mismatch detection** — warns if your DevOps project name doesn't match the local git repo on Test Connection and reconcile.
- **HTML work items** — Azure DevOps work items render with formatted HTML descriptions, not raw markdown.

---

## CI Pipeline Integration

Add this to your repo and every PR gets scanned, gated, and decorated automatically:

### Azure Pipelines

```yaml
trigger:
  - main

pool:
  vmImage: 'ubuntu-latest'

steps:
  - task: NodeTool@0
    inputs:
      versionSpec: '20.x'
  - script: npm install -g sentrik
  - script: sentrik scan
  - script: sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
    env:
      AZURE_DEVOPS_PAT: $(AZURE_DEVOPS_PAT)
  - script: sentrik reconcile
    env:
      AZURE_DEVOPS_PAT: $(AZURE_DEVOPS_PAT)
  - script: sentrik report --format sarif
  - publish: out/report.sarif
    artifact: sentrik-sarif
```

This pipeline:
1. **Scans** all files against enabled packs
2. **Gates** the PR — fails the check if critical/high/medium findings exist
3. **Decorates** the PR with a comment showing the scan summary
4. **Reconciles** findings to Azure DevOps work items — new findings create items, resolved findings close them
5. **Publishes** SARIF report as a build artifact

### GitHub Actions

```yaml
name: SENTRIK Gate
on: [pull_request]

jobs:
  compliance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm install -g sentrik
      - run: sentrik scan
      - run: sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check --commit-sha ${{ github.sha }}
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      - run: sentrik reconcile
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      - run: sentrik report --format sarif
      - uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: out/report.sarif
```

---

## The Full Loop

Here's what happened in this demo, end to end:

```
Clone C++ firmware repo
        │
        ▼
  cmake --build ──── compiles cleanly, zero warnings
        │
        ▼
  sentrik init ──── connects to DevOps, enables IEC 62304
        │
        ▼
  sentrik scan ──── 38 code findings (6 critical, 25 high)
        │             strcpy, gets, hardcoded secret, MD5, patient PHI in logs
        ▼
  sentrik reconcile ──── Azure DevOps work items created
        │                  with severity, guidance, acceptance criteria
        ▼
  sentrik gate ──── FAIL (exit 1) — blocks merge
        │
        ▼
  Fix C++ code in branch
        │  strncpy, fgets, env var, SHA-256, redacted logs
        ▼
  sentrik gate ──── PASS ✓
        │
        ▼
  sentrik reconcile ──── work items closed
        │
        ▼
  sentrik sbom + vulns ──── SBOM generated, deps scanned for CVEs
        │                    mapped to PCI DSS, SOC2, OWASP frameworks
        ▼
  sentrik evidence-export ──── audit evidence packages per framework
        │                       control-by-control pass/fail with timestamps
        ▼
  sentrik watch ──── continuous monitoring
        │              auto-rescans on file save, --interval for periodic
        ▼
  AI agent adds Dose History feature
        │  compiles cleanly, fulfills requirements
        ▼
  sentrik scan --staged ──── 9 new findings across 3 standards!
        │  strcpy (IEC 62304 + OWASP), unencrypted PHI (HIPAA), patient ID in logs
        │  each finding scored: confidence 1.0 (code) / 0.5 (comment) / 0.4 (string)
        ▼
  sentrik gate ──── FAIL — AI code is compliance-blind
        │
        ▼
  Fix AI-generated code with SENTRIK guidance
        │  strncpy, encrypted output, redacted logs
        ▼
  sentrik gate ──── PASS ✓ — compliant feature ships
        │
        ▼
  sentrik verify-reqs ──── requirement drift check
        │  catches missing files, orphaned reqs, spec divergence
        ▼
  sentrik trace ──── traceability matrix
                     every source file must link to a requirement
```

Every action is auditable. Every finding is tracked as a work item. Every approval has a justification.

**AI writes the code. SENTRIK enforces the rules. Humans approve the exceptions.**

---

## What We Demonstrated

In 30 minutes, we showed a complete governance workflow that would take weeks to build manually:

| Capability | What you saw |
|------------|-------------|
| **Multi-standard scanning** | One scan checked 125 rules across IEC 62304, HIPAA, and OWASP simultaneously |
| **Cross-standard correlation** | A single hardcoded API key flagged across 3 standards — one fix resolved all 3 |
| **DevOps integration** | Findings became Azure DevOps work items with HTML-formatted descriptions, and closed automatically when fixed |
| **CI/CD gating** | Exit code 1 blocks PRs; exit code 0 lets them through — works in any pipeline |
| **Async approval** | Human sign-off with full audit trail for accepted risks |
| **AI governance** | AI-generated code that compiles perfectly was blocked for 9 regulatory violations |
| **Requirement traceability** | Drift detection caught when code didn't match the requirements spec |
| **SBOM generation** | CycloneDX/SPDX bill of materials from dependency manifests — required by FDA and EU CRA |
| **Vulnerability scanning** | Dependencies checked against OSV.dev for known CVEs, mapped to PCI/SOC2/OWASP |
| **Evidence export** | One-command audit evidence packages mapped to framework controls (IEC 62304 §5.x, SOC2 CC6.x) |
| **Continuous monitoring** | `sentrik watch` auto-rescans on every save |
| **Confidence scoring** | Each finding scored by context (code vs. comment vs. string) — optionally refined by LLM |
| **Dashboard** | Real-time visibility into compliance state, findings trends, and audit history |

SENTRIK is not a linter, not a SAST tool, and not a documentation generator. It's a **governance runtime** — it sits between your code and your compliance requirements, and it never lets non-compliant code ship.

---

## Cleanup

```bash
# Stop the server (Ctrl+C)
cd ..
rm -rf sentrik-example-medfiles/
```
