# Sentrik Launch Submissions

> Master doc with copy-paste text for every submission. Work through top to bottom.

---

## 1. Product Hunt

**URL:** https://producthunt.com/posts/new

**Best time:** Tuesday or Wednesday, 12:01 AM PST

**Tagline (60 chars max):**
> Prove where your AI code meets compliance — not just violations

**Description:**
> Sentrik is a governance runtime for AI-generated code. While every security tool tells you what's wrong, Sentrik also proves what's right.
>
> The Compliance Evidence Map shows exactly where your code satisfies each regulatory requirement — with file, line number, and matched pattern. When an auditor asks "show me where you implement encryption at rest," you open the Evidence Map.
>
> 526 rules across 22 frameworks: OWASP, SOC 2, HIPAA, PCI-DSS, IEC 62304, EU AI Act, GDPR, NIST, and more.
>
> **Free tier:** 5 packs, 158 rules, forever. No credit card.
>
> **How it works:**
> 1. `npm install -g sentrik`
> 2. `sentrik scan` — 526 rules in 30 seconds
> 3. `sentrik compliance-map` — proof of compliance
>
> **Key features:**
> - Compliance Evidence Map (no competitor has this)
> - AI-powered fix suggestions in the dashboard
> - One-line CI gate for GitHub Actions
> - Risk scoring on every finding (exploitability, blast radius)
> - MCP server for Claude Code, Cursor, Cline
> - VS Code extension with inline diagnostics
> - Cryptographically signed attestations
> - Auditor portal with token-based access

**Maker Comment:**
> Hey PH! I built Sentrik because I was tired of the compliance gap in AI-assisted development.
>
> 84% of developers now use AI coding tools. But when the auditor shows up, nobody can prove the AI-generated code meets regulations. Teams spend 6+ weeks assembling evidence in spreadsheets.
>
> The Evidence Map is what makes Sentrik different. Every other security tool finds violations. Sentrik also finds proof — where your code satisfies HIPAA §164.312, SOC 2 CC6.1, or IEC 62304 §5.5.3.
>
> The free tier includes 5 packs — OWASP, SOC 2, Python Security, Go Security, and Supply Chain (158 rules). Install it, scan your project, and see what it finds.
>
> I'm here all day — ask me anything about compliance as code, AI governance, or regulated software.

**Topics:** Developer Tools, Compliance, Security, AI

**Screenshots needed:** Evidence Map dashboard, findings view, CLI scan output

---

## 2. Hacker News — Show HN

**URL:** https://news.ycombinator.com/submit

**Best time:** Weekday, 9-11 AM EST

**Title:**
> Show HN: Sentrik – compliance evidence maps for AI-generated code (free tier)

**Text:**
> I built Sentrik because every security scanner tells you what's wrong, but none prove what's right.
>
> When an auditor asks "show me where you implement audit logging," there's no tool that can answer that. You dig through git blame and update a spreadsheet.
>
> Sentrik's Compliance Evidence Map inverts the scanner model. For each regulatory requirement (HIPAA, SOC 2, OWASP, IEC 62304), it shows:
> - **MET** — code evidence at file:line (e.g., "audit logging found in middleware/audit.py:14")
> - **VIOLATED** — violations from the scanner
> - **N/A** — rule doesn't apply to your project
>
> It also searches .md/.adoc documentation files to satisfy documentation obligations (risk management plans, security policies).
>
> 526 rules across 22 frameworks. Free tier includes 5 packs with 158 rules (forever, no credit card).
>
> npm install -g sentrik && sentrik scan
>
> GitHub Action: uses: maxgerhardson/sentrik-community@v1
>
> https://sentrik.dev
> Docs: https://docs.sentrik.dev
> Community: https://github.com/maxgerhardson/sentrik-community

---

## 3. Dev.to — Blog Republish

**URL:** https://dev.to/new

**IMPORTANT:** Set the canonical URL to `https://sentrik.dev/blog/prove-compliance-ai-generated-code` so Google knows the original source.

**Title:**
> How to Prove Compliance in AI-Generated Code

**Tags:** `security`, `compliance`, `ai`, `devops`

**Body:** Copy the full blog post from `sentrik.dev/blog/prove-compliance-ai-generated-code`. At the bottom add:

> ---
> *Originally published at [sentrik.dev](https://sentrik.dev/blog/prove-compliance-ai-generated-code)*
>
> Sentrik is free to try: `npm install -g sentrik && sentrik scan`

---

## 4. Reddit Posts

### r/devops

**Title:** We built a compliance evidence map that shows where your code satisfies HIPAA/SOC 2/OWASP — not just violations

**Body:**
> 84% of devs use AI coding tools now. The code ships fast, but when the auditor asks "show me where you implement encryption at rest," nobody has a good answer.
>
> We built Sentrik to fix this. It scans your code against 526 rules from 22 regulatory frameworks and generates a Compliance Evidence Map — showing where each requirement is satisfied, with the exact file and line number.
>
> Free tier includes 5 packs with 158 rules, forever: `npm install -g sentrik`
>
> One-line CI gate: `uses: maxgerhardson/sentrik-community@v1`
>
> https://sentrik.dev | https://docs.sentrik.dev

### r/compliance

**Title:** Automated compliance evidence for SOC 2, HIPAA, IEC 62304 — maps code to regulatory clauses

**Body:**
> Compliance engineer here. Tired of manually collecting evidence for SOC 2 and HIPAA audits, I built a tool that scans code and generates an evidence map showing where each control is satisfied.
>
> For example: HIPAA §164.312(b) audit logging → found in middleware/audit.py:14. SOC 2 CC6.1 access controls → verified across 43 files. IEC 62304 §7.1 risk management → documentation found in docs/risk-analysis.adoc.
>
> 526 rules, 22 frameworks, cryptographically signed attestations. Auditor portal with read-only token access.
>
> Free to try: npm install -g sentrik
>
> https://sentrik.dev

### r/programming

**Title:** Show r/programming: Compliance Evidence Maps — proving where code satisfies regulations, not just finding violations

**Body:**
> Most security scanners find violations. We built one that also finds proof of compliance.
>
> `sentrik compliance-map` generates an evidence map showing where your code satisfies each regulatory requirement — HIPAA, SOC 2, OWASP, IEC 62304 — with file, line number, and matched pattern.
>
> It also searches your .md and .adoc files to find documentation that satisfies process requirements (risk management plans, security policies).
>
> 526 rules, 22 frameworks, free tier forever.
>
> `npm install -g sentrik && sentrik scan`
>
> Blog post: https://sentrik.dev/blog/prove-compliance-ai-generated-code

### r/medicaldevices

**Title:** IEC 62304 compliance automation — 31 rules mapped to software lifecycle clauses, evidence generated on every commit

**Body:**
> I work on medical device software. The IEC 62304 compliance evidence process was eating weeks of engineering time every release cycle.
>
> Built Sentrik to automate it. 31 rules mapped to IEC 62304 clauses (§5.1–§8). It scans your code, verifies coding standards, checks for risk management documentation, generates SBOM for configuration management, and produces a compliance evidence map showing exactly where each clause is satisfied.
>
> Also covers HIPAA (25 rules), IEC 81001-5-1 (20 rules), ISO 14971 (16 rules), and 21 CFR Part 11 (16 rules).
>
> Signed attestations (HMAC-SHA256) and an auditor portal with token-based read-only access.
>
> https://sentrik.dev/compliance/iec-62304

---

## 5. G2 / Capterra Profile

**URL:** https://www.g2.com/products/new | https://www.capterra.com/vendors/sign-up

**Product Name:** Sentrik

**Category:** Static Application Security Testing (SAST), Compliance Management, Application Security Posture Management (ASPM)

**Description (short):**
> Governance runtime for AI-generated code. Scan, gate, and prove compliance automatically.

**Description (long):**
> Sentrik scans AI-generated code against 526 rules from 22 regulatory frameworks — OWASP, SOC 2, HIPAA, PCI-DSS, IEC 62304, EU AI Act, GDPR, NIST, and more — and generates audit-ready compliance evidence automatically.
>
> Unlike traditional SAST tools that only find violations, Sentrik's Compliance Evidence Map shows where your code satisfies each regulatory requirement. When an auditor asks "show me where you implement encryption at rest," you open the Evidence Map.
>
> Key capabilities: compliance evidence mapping, risk scoring, AI-powered remediation, CI/CD gate (GitHub Actions), MCP server for AI coding agents, VS Code extension, SBOM generation, CVE scanning, cryptographically signed attestations, and auditor portal.
>
> Free tier: 5 packs (OWASP, SOC 2, Python Security, Go Security, Supply Chain), 158 rules, forever. Team: $29/mo. Organization: $99/mo.

**Website:** https://sentrik.dev
**Pricing:** Free, $29/mo, $99/mo

---

## 6. AlternativeTo

**URL:** https://alternativeto.net/manage/add/

**Product Name:** Sentrik
**URL:** https://sentrik.dev
**Description:** Governance runtime for AI-generated code. 526 rules across 22 regulatory frameworks with compliance evidence mapping. Free tier available.
**Tags:** compliance, security, SAST, code-quality, governance
**Alternatives to:** SonarQube, Snyk, Semgrep, Vanta, Drata

---

## 7. DevHunt

**URL:** https://devhunt.org (look for Submit button)

**Product Name:** Sentrik
**Tagline:** Prove where your AI code meets compliance — not just violations
**URL:** https://sentrik.dev
**GitHub:** https://github.com/maxgerhardson/sentrik-community
**Description:** 526 rules, 22 regulatory frameworks, compliance evidence maps. Free tier forever.

---

## 8. Hashnode — Blog Republish

**URL:** https://hashnode.com (create blog, write post)

Same content as Dev.to republish. Set canonical URL to sentrik.dev blog post.

---

## 9. Medium — Blog Republish

**URL:** https://medium.com/new-story

Same content as Dev.to republish. Add canonical link in settings.

---

## Submission Checklist

| # | Platform | Type | Status |
|---|----------|------|--------|
| 1 | Product Hunt | Launch | Pending — schedule for Tuesday |
| 2 | Hacker News | Show HN | Pending — post weekday morning |
| 3 | Dev.to | Blog | Pending — need account |
| 4 | Reddit r/devops | Post | Pending |
| 5 | Reddit r/compliance | Post | Pending |
| 6 | Reddit r/programming | Post | Pending |
| 7 | Reddit r/medicaldevices | Post | Pending |
| 8 | G2 | Profile | Pending |
| 9 | Capterra | Profile | Pending |
| 10 | AlternativeTo | Listing | Pending |
| 11 | DevHunt | Launch | Pending |
| 12 | Hashnode | Blog | Pending |
| 13 | Medium | Blog | Pending |
| 14 | LinkedIn page | Company page | Backlog |
| 15 | LinkedIn article | Post | Backlog (needs company page) |
| 16 | Claude Desktop form | MCP listing | Backlog |
| 17 | PulseMCP | MCP listing | Backlog |
| 18 | Vanta partnership | Form | Backlog |
