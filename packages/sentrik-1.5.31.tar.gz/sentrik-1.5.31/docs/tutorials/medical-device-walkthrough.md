# Medical Device Walkthrough

This end-to-end tutorial demonstrates using sentrik to enforce IEC 62304 compliance on a medical device software project.

## Scenario

You're building **MedFiles** — a medical device data processor that handles patient records. Your team uses AI coding agents (Copilot, Claude Code) for development and needs to demonstrate IEC 62304 compliance for FDA 510(k) submission.

## 1. Install and initialize

```bash
npm install -g sentrik
cd medfiles
sentrik init
```

In the setup wizard, select:
- **DevOps Platform**: Azure DevOps (or GitHub)
- **Project Type**: Medical device (IEC 62304)
- **Governance Profile**: Strict
- **Output Directory**: out
- **Pre-commit Hook**: Yes

## 2. Verify standards pack

```bash
sentrik list-packs
```

The `fda-iec-62304` pack should be enabled with 14 rules.

## 3. Run your first scan

```bash
sentrik scan
```

Review the output:
- `out/findings.json` — All findings with severity, rule ID, file, line number
- `out/report.md` — Human-readable summary
- `out/scan_metrics.json` — Performance data

## 4. Understand findings

IEC 62304 findings fall into two categories:

**Code-enforceable** (fail the gate):
- Missing traceability headers
- Unsafe type casts
- Missing input validation
- Missing error handling

**Documentation obligations** (appear in reports, never fail gate):
- Software development plan (clause 5.1)
- Requirements specification (clause 5.2)
- Architecture design (clause 5.3)
- etc.

## 5. Fix code findings

Add traceability headers to source files:

```python
"""Patient data processor.

Requirement: REQ-001 — Patient data ingestion
IEC 62304 Class: B
"""
```

Add input validation:

```python
def process_patient_record(record: dict) -> dict:
    if not isinstance(record, dict):
        raise ValueError("Invalid record format")
    if "patient_id" not in record:
        raise ValueError("Missing patient_id")
    # ... processing logic
```

## 6. Enforce the gate

```bash
sentrik gate
```

The gate passes when no `critical` or `high` severity code findings remain.

## 7. Set up CI/CD

### GitHub Actions

```yaml
name: IEC 62304 Gate
on: [pull_request]

jobs:
  compliance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm install -g sentrik
      - run: sentrik gate --git-range "origin/main...HEAD" --decorate-pr
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

## 8. Work item traceability

Connect to your DevOps platform and reconcile findings with work items:

```bash
sentrik reconcile --dry-run    # Preview actions
sentrik reconcile              # Execute
```

This creates work items for unresolved findings and closes items for fixed ones.

## 9. Generate compliance reports

```bash
sentrik report --format html
sentrik report --format sarif

# Per-framework compliance report with clause-by-clause mapping
sentrik compliance-report -f "IEC 62304"

# Public-safe trust center page for customers/auditors
sentrik trust-center --org "MedFiles Inc"
```

HTML reports include:
- Donut chart showing severity distribution
- Sortable findings table with code context
- Documentation obligation checklist
- Filter by severity, rule, or file

The compliance report maps each finding to its IEC 62304 clause with pass/fail status. The trust center page shows compliance posture without exposing any source code — suitable for sharing with regulatory bodies or embedding on your company website.

These reports serve as **audit evidence** for FDA submission.

## 10. Dashboard

Start the management console:

```bash
sentrik dashboard
```

Open [http://localhost:8000/dashboard](http://localhost:8000/dashboard) to:
- View real-time scan results
- Manage governance policies
- Track documentation obligations
- Monitor compliance trends over time

## Audit trail

With governance audit enabled, every scan, gate, and reconcile action is logged to `out/agent_audit.jsonl` with timestamps, user/agent identity, and results. This provides the **traceability evidence** required by IEC 62304 clause 5.1.
