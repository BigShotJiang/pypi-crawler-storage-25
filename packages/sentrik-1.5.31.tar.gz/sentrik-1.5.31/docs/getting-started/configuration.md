# Configuration

sentrik works without any configuration file — it auto-detects your project and applies sensible defaults. When you need to customize, configuration lives in `.sentrik/config.yaml`. Environment variables override file values (useful for CI).

## Config resolution order

sentrik checks for configuration in this order:

1. **Explicit path** — `--config path/to/config.yaml`
2. **`.sentrik/config.yaml`** — new convention (recommended)
3. **`.guard.yaml`** — legacy format (fully supported)
4. **Auto-detect** — in-memory defaults based on project detection

## The `.sentrik/` directory

```
.sentrik/
  config.yaml     # Main config (commit to git)
  rules/          # Custom rules (optional, commit to git)
  .gitignore      # Ignores local/
  local/          # Machine-local state (not committed)
```

Create it with:

```bash
sentrik init --no-interactive    # Auto-detected defaults
sentrik init                     # Interactive wizard
```

### Migrating from `.guard.yaml`

```bash
sentrik migrate
```

Copies `.guard.yaml` to `.sentrik/config.yaml`. Both formats remain fully supported — `.sentrik/config.yaml` takes precedence when both exist.

## Core settings

| Setting | Default | Env Var | Description |
|---------|---------|---------|-------------|
| `output_dir` | `out` | `GUARD_OUTPUT_DIR` | Output directory for artifacts |
| `standards_file` | `examples/sample_standards.yaml` | `GUARD_STANDARDS_FILE` | Path to rules YAML |
| `work_items_file` | `examples/sample_work_items.json` | `GUARD_WORK_ITEMS_FILE` | Path to work items |
| `provider` | `stub` | `GUARD_PROVIDER` | Scanner provider (`stub`, `sarif`, `composite`) |
| `gate_fail_on` | `[critical, high]` | `GUARD_GATE_FAIL_ON` | Severities that fail the gate |
| `reporters` | `[]` | — | Report formats (`html`, `junit`, `sarif`, `csv`) |
| `standards_packs` | `[]` | `GUARD_STANDARDS_PACKS` | Enabled standards packs |
| `parallel_scan` | `false` | `GUARD_PARALLEL_SCAN` | Enable parallel file scanning |
| `max_workers` | `4` | `GUARD_MAX_WORKERS` | Number of parallel worker threads |
| `agent_scan` | `false` | `GUARD_AGENT_SCAN` | Enable multi-agent scanning (one agent per pack, evaluated in parallel) |
| `agent_max_concurrency` | `0` | `GUARD_AGENT_MAX_CONCURRENCY` | Max concurrent compliance agents (`0` = one per pack) |
| `ml_severity_enabled` | `false` | `GUARD_ML_SEVERITY_ENABLED` | Enable heuristic severity rescoring (local, no AI) |
| `confidence_scoring_enabled` | `false` | `GUARD_CONFIDENCE_SCORING_ENABLED` | Enable LLM-powered confidence re-scoring |
| `confidence_scoring_max_findings` | `50` | `GUARD_CONFIDENCE_SCORING_MAX_FINDINGS` | Max findings to re-score per scan |
| `scan_exclude` | `[]` | — | File/directory patterns to exclude from scanning (e.g. `["tests/", "demo/"]`) |

## C/C++ analysis settings

| Setting | Default | Env Var | Description |
|---------|---------|---------|-------------|
| `cpp_analysis_enabled` | `false` | `GUARD_CPP_ANALYSIS_ENABLED` | Enable C/C++ semantic analysis |
| `cpp_analysis_tool` | `clang-tidy` | `GUARD_CPP_ANALYSIS_TOOL` | Tool to use: `clang-tidy`, `cppcheck`, or `both` |
| `cpp_analysis_checks` | `""` | `GUARD_CPP_ANALYSIS_CHECKS` | Clang-tidy check patterns (empty = use defaults) |

## GRC integration settings

| Setting | Default | Env Var | Description |
|---------|---------|---------|-------------|
| `grc_webhook_url` | `""` | `GUARD_GRC_WEBHOOK_URL` | GRC platform webhook URL |
| `grc_platform` | `generic` | `GUARD_GRC_PLATFORM` | GRC platform type: `generic`, `drata`, `vanta`, `secureframe` |
| `grc_events` | `[]` | `GUARD_GRC_EVENTS` | Events to push: `scan_complete`, `gate_passed`, `gate_failed` |

Note: `GUARD_GRC_API_KEY` can be set as an environment variable for GRC platform authentication.

## Requirement coverage settings

| Setting | Default | Env Var | Description |
|---------|---------|---------|-------------|
| `requirement_coverage_enabled` | `false` | — | Enable requirement coverage tracking |
| `requirement_coverage_exclude` | *(see below)* | — | File patterns to exclude from coverage analysis |

Default `requirement_coverage_exclude` patterns: `tests/*`, `test_*`, `*.md`, `*.txt`, `*.yaml`, `*.yml`, `*.json`, `*.toml`, `*.cfg`, `*.ini`, `*.lock`, `__init__.py`, `__pycache__/*`, `*.pyc`, `*.pyo`, `*.db`, `*.sqlite*`, `out/*`, `dist/*`, `build/*`, `*.egg-info/*`, `*.patch`, `*.html`, `*.css`, `*.min.*`.

## LLM settings

| Setting | Default | Env Var | Description |
|---------|---------|---------|-------------|
| `llm_provider` | — | `GUARD_LLM_PROVIDER` | LLM provider (`anthropic`, `openai`, `ollama`) |
| `llm_model` | — | `GUARD_LLM_MODEL` | Model name (e.g. `claude-sonnet-4-20250514`, `gpt-4o`, `llama3`) |
| `llm_base_url` | — | `GUARD_LLM_BASE_URL` | Base URL for the LLM API (required for `ollama`, optional for others) |

These settings are used by LLM-powered features such as confidence scoring and requirement generation. All LLM features are opt-in — the core scanning pipeline is fully deterministic and never calls an LLM.

## DevOps provider settings

| Setting | Env Var | Description |
|---------|---------|-------------|
| `devops_provider` | `GUARD_DEVOPS_PROVIDER` | `stub`, `azure`, `github`, or `jira` |
| `azure_devops_org` | `GUARD_AZURE_DEVOPS_ORG` | Azure DevOps organization |
| `azure_devops_project` | `GUARD_AZURE_DEVOPS_PROJECT` | Azure DevOps project |
| `azure_devops_team` | `GUARD_AZURE_DEVOPS_TEAM` | Azure DevOps team (optional) |
| `azure_devops_repo` | `GUARD_AZURE_DEVOPS_REPO` | Azure DevOps repository name |
| `github_owner` | `GUARD_GITHUB_OWNER` | GitHub repository owner |
| `github_repo` | `GUARD_GITHUB_REPO` | GitHub repository name |
| `github_label` | `GUARD_GITHUB_LABEL` | Filter issues by label |
| `github_milestone` | `GUARD_GITHUB_MILESTONE` | Filter issues by milestone |
| `jira_base_url` | `GUARD_JIRA_BASE_URL` | Jira instance base URL |
| `jira_project_key` | `GUARD_JIRA_PROJECT_KEY` | Jira project key |
| `jira_jql` | `GUARD_JIRA_JQL` | Custom JQL query |

## Secrets (set in environment, never in config)

| Variable | Description |
|----------|-------------|
| `AZURE_DEVOPS_PAT` | Azure DevOps Personal Access Token |
| `GITHUB_TOKEN` | GitHub Personal Access Token |
| `JIRA_USER` | Jira username/email (Cloud) |
| `JIRA_TOKEN` | Jira API token (Cloud) |
| `JIRA_PAT` | Jira Personal Access Token (Data Center/Server) |
| `GUARD_API_KEY` | REST API authentication key (constant-time validated) |
| `GUARD_LICENSE_KEY` | License key for paid features |
| `GUARD_AUDIT_HMAC_KEY` | HMAC key for audit log integrity signatures |
| `GUARD_SESSION_SECRET` | Session secret for OIDC (generate ephemeral if unset) |
| `GUARD_RATE_LIMIT_RPM` | API rate limit per IP per minute (default: 60) |

## Governance settings

```yaml
governance:
  profile: standard  # strict | standard | permissive
  human_review_required:
    on_requirement_change: true
    on_critical_finding: true
    on_auto_patch_above: medium
  auto_patch:
    enabled: true
    max_severity: low
  gate:
    fail_on: [critical, high]
    block_merge_on_obligations: false
  sync:
    auto_close_work_items: true
    require_sign_off: false
  audit:
    enabled: true
    log_file: out/agent_audit.jsonl
```

Profiles provide sensible defaults:

- **strict** — Human review for everything, tightest gates
- **standard** — Balanced (default)
- **permissive** — Maximum agent autonomy

## Notification settings

| Setting | Env Var | Description |
|---------|---------|-------------|
| `notifications.slack_webhook_url` | `GUARD_SLACK_WEBHOOK_URL` | Slack incoming webhook URL |
| `notifications.teams_webhook_url` | `GUARD_TEAMS_WEBHOOK_URL` | Microsoft Teams webhook URL |
| `notifications.notify_on` | — | Events to notify on (default: `["gate_failed"]`) |

## Enterprise settings

| Setting | Env Var | Description |
|---------|---------|-------------|
| `license_key` | `GUARD_LICENSE_KEY` | License key (provided on purchase) |
| `async_approval.enabled` | `GUARD_APPROVAL_ENABLED` | Enable async approval gates |
| `async_approval.timeout` | `GUARD_APPROVAL_TIMEOUT` | Approval timeout in seconds |
| `online_license_check` | `GUARD_ONLINE_LICENSE_CHECK` | Enable online license validation (default: `true`) |
| `portal_url` | `GUARD_PORTAL_URL` | License portal URL (default: `https://portal.sentrik.dev`) |

## Example configuration

```yaml
# .sentrik/config.yaml
output_dir: out
standards_file: standards.yaml
work_items_file: work_items.json
provider: stub
gate_fail_on:
  - critical
  - high
reporters:
  - html
  - sarif
standards_packs:
  - owasp-top-10
devops_provider: github
github_owner: myorg
github_repo: myapp
governance:
  profile: standard
parallel_scan: true
max_workers: 8
agent_scan: true            # one compliance agent per pack, evaluated in parallel
agent_max_concurrency: 0    # 0 = auto (one thread per pack)
```

## Validate configuration

```bash
sentrik validate-config
```

Reports errors and warnings for invalid settings.
