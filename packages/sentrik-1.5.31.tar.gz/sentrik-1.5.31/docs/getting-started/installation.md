# Installation

## Install via pip (recommended)

```bash
pip install sentrik
```

For tree-sitter AST analysis across C/C++, Go, Rust, Java, TypeScript, and more:

```bash
pip install "sentrik[treesitter]"
```

For the dashboard and REST API server:

```bash
pip install "sentrik[server]"
```

For everything:

```bash
pip install "sentrik[all]"
```

Requires Python 3.11 or later.

## Install via npm

```bash
npm install -g sentrik
```

Downloads a platform-specific binary. No Python or runtime dependencies needed. Works on macOS (x64/arm64), Linux (x64), and Windows (x64).

> **Note:** The npm binary does not include tree-sitter grammar support or the dashboard server. Use the pip install for those features.

## Verify installation

```bash
sentrik --version
sentrik --help
```

## VS Code Extension

Install the **Sentrik** extension from the VS Code Marketplace for in-editor scanning, inline diagnostics, and Copilot integration. The extension auto-detects the pip-installed `sentrik` binary.

## License

Check your current license status:

```bash
sentrik license
```

Visit [sentrik.dev](https://sentrik.dev) to upgrade to Team, Organization, or Enterprise tiers.
