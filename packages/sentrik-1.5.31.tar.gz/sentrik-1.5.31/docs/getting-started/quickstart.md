# Quickstart

Get scanning in under a minute. No config files needed.

## 1. Install

```bash
npm install -g sentrik
```

No Python or runtime dependencies needed.

## 2. Scan your code

```bash
cd your-project
sentrik scan
```

sentrik auto-detects your project — languages, CI platform, and applicable standards packs. No wizard, no prompts. Findings are written to `out/`:

- `findings.json` — machine-readable findings
- `report.md` — human-readable summary
- `next_actions.md` — prioritized action items
- `scan_metrics.json` — performance metrics

## 3. Enforce the gate

```bash
sentrik gate
```

Exits with code 0 (pass) or 1 (fail). By default, `critical` and `high` severity findings fail the gate.

## 4. Scope to changed files

For faster CI/CD runs, scope to only changed files:

```bash
# Staged files (pre-commit)
sentrik scan --staged

# PR diff
sentrik gate --git-range "origin/main...HEAD"
```

## 5. Customize (optional)

Lock in your settings with a config file:

```bash
sentrik init --no-interactive    # Auto-detected defaults → .sentrik/config.yaml
sentrik init                     # Interactive wizard → .sentrik/config.yaml
```

The `.sentrik/` directory structure:

```
.sentrik/
  config.yaml     # Main config (commit to git)
  rules/          # Custom rules (optional)
  .gitignore      # Ignores local/
  local/          # Machine-local state (not committed)
```

!!! tip "Migrating from .guard.yaml"
    If you have an existing `.guard.yaml`, run `sentrik migrate` to copy it to `.sentrik/config.yaml`. Both formats are fully supported.

## 6. Enable standards packs

OWASP Top 10 is always enabled by default. Add more:

```bash
sentrik add-pack fda-iec-62304    # Medical device (IEC 62304)
sentrik add-pack soc2             # SOC2 compliance
```

List available packs:

```bash
sentrik list-packs
```

## 7. Start the dashboard

```bash
sentrik dashboard
```

Open [http://localhost:8000/dashboard](http://localhost:8000/dashboard) for the management console.

## 8. Generate compliance artifacts

```bash
# Per-framework compliance report for auditors
sentrik compliance-report -f "OWASP Top 10"

# Public-safe trust center page (no code or file paths)
sentrik trust-center --org "Your Company"
```

The trust center page at `out/trust-center.html` shows your compliance posture without exposing any source code — safe to share with customers or embed on your website.

## Next steps

- [Configuration reference](configuration.md) — full `.sentrik/config.yaml` options
- [CI/CD integration](../guides/ci-cd-integration.md) — GitHub Actions, Azure Pipelines, and GitLab CI
- [Dashboard guide](../guides/dashboard.md) — full dashboard walkthrough
- [Standards packs](../standards-packs/overview.md) — IEC 62304, OWASP, SOC2 details
