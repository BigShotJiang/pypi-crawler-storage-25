# Authentication

sentrik supports API key authentication and JWT token authentication.

## API key authentication

Set the `GUARD_API_KEY` environment variable to enable API key auth:

```bash
export GUARD_API_KEY="your-secret-key"
sentrik dashboard
```

All endpoints (except `/health`) require the `X-API-Key` header:

```bash
curl -H "X-API-Key: your-secret-key" http://localhost:8000/api/metrics
```

If `GUARD_API_KEY` is not set, all endpoints are open (no auth required).

API key validation uses constant-time comparison (`hmac.compare_digest`) to prevent timing side-channel attacks.

### Error response (401)

```json
{"detail": "Invalid or missing API key"}
```

## JWT authentication

For production deployments, sentrik supports JWT-based authentication with role-based access control.

### Configuration

```yaml
# .guard.yaml
auth:
  enabled: true
  jwt_secret: "your-jwt-secret"     # Or set GUARD_JWT_SECRET env var
  jwt_algorithm: "HS256"
  token_expiry_hours: 24
```

### Token format

Include the JWT in the `Authorization` header:

```bash
curl -H "Authorization: Bearer <token>" http://localhost:8000/api/metrics
```

### Token claims

| Claim | Type | Description |
|-------|------|-------------|
| `sub` | string | User ID |
| `role` | string | User role (`admin`, `security-lead`, `developer`, `viewer`, `agent`) |
| `repo_access` | string[] | Repository access list (for `agent` role) |
| `exp` | int | Token expiration timestamp |

## OIDC integration (Enterprise)

Enterprise tier supports OIDC/SSO integration with identity providers like Auth0, Okta, and Azure AD.

## Authentication priority

When multiple auth methods are configured:

1. JWT token (if present in `Authorization` header)
2. API key (if present in `X-API-Key` header)
3. No auth (if neither header is present and auth is disabled)
