# Role-Based Access Control (RBAC)

sentrik implements fine-grained authorization with 5 built-in roles and 10+ permissions.

## Roles

| Role | Description |
|------|-------------|
| **admin** | Full access to all features |
| **security-lead** | Scan, gate, reconcile, findings, audit, pack management |
| **developer** | Scan, gate, read findings, read packs |
| **viewer** | Read-only access to findings, audit, packs |
| **agent** | Scan and gate with repo-scoped access |

## Permissions

| Permission | admin | security-lead | developer | viewer | agent |
|-----------|-------|---------------|-----------|--------|-------|
| `scan` | Yes | Yes | Yes | - | Yes |
| `gate` | Yes | Yes | Yes | - | Yes |
| `reconcile` | Yes | Yes | - | - | - |
| `config:read` | Yes | Yes | Yes | - | - |
| `config:edit` | Yes | - | - | - | - |
| `findings:read` | Yes | Yes | Yes | Yes | Yes |
| `findings:write` | Yes | Yes | - | - | - |
| `audit:read` | Yes | Yes | - | Yes | - |
| `packs:read` | Yes | Yes | Yes | Yes | - |
| `packs:manage` | Yes | Yes | - | - | - |
| `approval:request` | Yes | Yes | Yes | - | Yes |
| `approval:review` | Yes | Yes | - | - | - |
| `vault:read` | Yes | Yes | - | - | - |

## Agent role

The `agent` role is designed for AI coding agents operating within CI/CD pipelines. It supports **repo-scoped access** — an agent token can be limited to specific repositories:

```json
{
  "sub": "ci-agent-1",
  "role": "agent",
  "repo_access": ["myorg/myapp", "myorg/shared-lib"]
}
```

## Backward compatibility

- **No auth configured**: All requests pass authorization checks (anonymous = admin)
- **API key only**: API key users get admin role
- **JWT enabled**: Role determined by token claims

## Protected endpoints

All 33+ API endpoints are protected by permission checks. Each endpoint requires a specific permission — unauthorized requests receive a `403 Forbidden` response:

```json
{"detail": "Permission denied: scan required"}
```
