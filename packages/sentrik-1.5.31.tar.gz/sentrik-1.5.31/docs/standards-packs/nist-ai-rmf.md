# NIST AI RMF

The `nist-ai-rmf` pack enforces rules based on the **NIST AI 600-1 Risk Management Framework** for governing AI systems, covering organizational governance, risk assessment, bias testing, security, transparency, and data protection.

## Enable

```bash
sentrik add-pack nist-ai-rmf
```

## Rules

The pack includes 15 rules across code enforcement and documentation obligations:

### Code rules (7)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| AIRM-SEC-001 | MANAGE 2.4 | critical | API keys and credentials for AI model services must not be hardcoded |
| AIRM-SEC-002 | MAP 2.3 | high | User input passed directly to AI models without sanitization enables prompt injection |
| AIRM-SEC-003 | MANAGE 2.4 | critical | AI model output must not be passed to eval() or exec() without validation |
| AIRM-DATA-001 | MANAGE 3.2 | high | Training data containing PII must not be logged or printed in plaintext |
| AIRM-DATA-002 | MANAGE 2.4 | high | AI models serialized with pickle are vulnerable to arbitrary code execution on deserialization |
| AIRM-DATA-003 | MEASURE 2.1 | low | Fixed random seeds in production can cause reproducibility issues masking model failures |
| AIRM-FAIR-001 | MEASURE 2.6 | medium | Protected demographic attributes should not be used as direct model features without justification |

### Documentation obligations (8)

| ID | Clause | Description |
|----|--------|-------------|
| AIRM-MAP-001 | MAP 1.1 | AI systems must be inventoried with documented purpose, capabilities, and limitations |
| AIRM-MAP-002 | MAP 3.1 | AI risk assessments must be performed and documented before deployment |
| AIRM-MEAS-001 | MEASURE 2.1 | AI models must have documented performance metrics and acceptance thresholds |
| AIRM-MEAS-002 | MEASURE 2.6 | AI systems must be tested for bias across protected demographic groups |
| AIRM-MAN-001 | MANAGE 1.3 | Deployed AI models must have continuous monitoring for performance degradation and drift |
| AIRM-MAN-002 | MANAGE 4.1 | An AI incident response plan must exist for model failures, bias incidents, and security breaches |
| AIRM-GOV-001 | GOVERN 1.1 | An organizational AI governance policy must define roles, responsibilities, and oversight for AI systems |
| AIRM-GOV-002 | GOVERN 4.2 | AI system decisions must be explainable and documented for affected stakeholders |

## Use case

Teams building or deploying AI/ML systems, including LLM-powered applications, predictive models, and data pipelines. The pack provides:

1. **AI security enforcement** -- Catches hardcoded AI service credentials, prompt injection vectors, unsafe execution of model output, and insecure model serialization
2. **Fairness and bias detection** -- Flags protected demographic attributes used as direct model features and requires documented bias testing
3. **Governance documentation** -- Documentation obligations for AI system inventory, risk assessment, performance metrics, monitoring, incident response, governance policy, and transparency appear in reports for auditors
