# HIPAA Security Rule

The `hipaa` pack enforces rules based on the **HIPAA Security Rule (45 CFR Part 164)** for protecting electronic Protected Health Information (ePHI). It covers technical safeguards, administrative safeguards, and organizational requirements.

## Enable

```bash
sentrik add-pack hipaa
```

## Rules

The pack includes 25 rules across code enforcement and documentation obligations:

### Code rules (16)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| HIPAA-164.312-a1 | 164.312(a)(1) | critical | PHI identifiers must not be stored as plaintext literals in source code |
| HIPAA-164.312-a2 | 164.312(a)(2) | high | PHI must not be written to application logs (Python) |
| HIPAA-164.312-a2-JS | 164.312(a)(2) | high | PHI must not be written to console logs in JavaScript/TypeScript |
| HIPAA-164.312-a2-JAVA | 164.312(a)(2) | high | PHI must not be written to System.out in Java |
| HIPAA-164.312-a2-CPP | 164.312(a)(2) | high | PHI must not be written to stdout via printf or cout in C/C++ |
| HIPAA-164.312-a2-CPP2 | 164.312(a)(2) | high | File I/O operations referencing PHI data must use encryption in C/C++ |
| HIPAA-164.312-e1 | 164.312(e)(1) | high | Data must be transmitted over encrypted channels (HTTPS, not HTTP) |
| HIPAA-164.312-d | 164.312(d) | critical | Credentials must not be embedded in source code |
| HIPAA-164.312-b | 164.312(b) | medium | Modules handling PHI must import a logging framework for audit trail purposes |
| HIPAA-164.308-a5-code | 164.308(a)(5) | high | Debug mode must not be enabled in production configurations |
| HIPAA-164.312-a3-JS | 164.312(a)(1) | critical | PHI must not be stored in localStorage |
| HIPAA-164.312-e2-JS | 164.312(e)(1) | high | Cookies must be set with the Secure flag |
| HIPAA-164.312-a2-JAVA-LOG | 164.312(a)(2) | high | PHI must not be written to application logs via Java logging frameworks |
| HIPAA-164.312-a2-CS | 164.312(a)(2) | high | PHI must not be written to console output in C# |
| HIPAA-164.312-a2-CS-FILE | 164.312(a)(2) | critical | PHI must not be written to unencrypted file storage in C# |
| HIPAA-164.312-a2-GO | 164.312(a)(2) | high | PHI must not be written to stdout or application logs in Go |

### Documentation obligations (9)

| ID | Clause | Description |
|----|--------|-------------|
| HIPAA-164.308-a1 | 164.308(a)(1) | Risk analysis identifying threats and vulnerabilities to ePHI |
| HIPAA-164.308-a3 | 164.308(a)(3) | Workforce security policies for appropriate ePHI access |
| HIPAA-164.308-a4 | 164.308(a)(4) | Information access management based on role and minimum necessary standard |
| HIPAA-164.308-a5 | 164.308(a)(5) | Security awareness and training program for all workforce members |
| HIPAA-164.308-a6 | 164.308(a)(6) | Security incident identification, response, and mitigation procedures |
| HIPAA-164.308-a7 | 164.308(a)(7) | Contingency plan for data backup, disaster recovery, and emergency operations |
| HIPAA-164.310-a1 | 164.310(a)(1) | Facility access controls limiting physical access to information systems |
| HIPAA-164.314-a1 | 164.314(a)(1) | Business Associate Agreements with all entities handling ePHI |
| HIPAA-164.316-b1 | 164.316(b)(1) | Documentation retention policy (minimum six years) |

## Use case

Healthcare organizations, health-tech startups, and any company handling ePHI. The pack provides:

1. **PHI leak detection** -- Catches plaintext PHI in source code, logs, localStorage, and unencrypted file I/O across Python, JavaScript, Java, C#, C/C++, and Go
2. **Encryption enforcement** -- Flags unencrypted HTTP transmission and missing Secure cookie flags
3. **Audit trail support** -- Documentation obligations appear in HTML/SARIF reports, providing auditors with traceable compliance status against HIPAA Security Rule requirements
