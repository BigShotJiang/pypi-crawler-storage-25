# EU AI Act

The `eu-ai-act` pack enforces rules based on the **EU Artificial Intelligence Act** for high-risk AI systems. It covers risk management, transparency, human oversight, data governance, prohibited practices, and cybersecurity requirements (Articles 5, 9-15, 43, 49, 50, 72).

## Enable

```bash
sentrik add-pack eu-ai-act
```

## Rules

The pack includes 22 rules across code enforcement and documentation obligations:

### Code rules (12)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| EUAI-ART15-002 | Article 15(4) | critical | AI service credentials must not be hardcoded |
| EUAI-ART15-003 | Article 15(3) | critical | AI model output must not be executed via eval/exec without validation |
| EUAI-ART50-001 | Article 50(1) | high | AI chatbots and agents must disclose to users that they are interacting with an AI system |
| EUAI-ART52-001 | Article 5(1)(c) | critical | Social scoring systems that evaluate or classify persons based on social behavior are prohibited |
| EUAI-ART52-002 | Article 5(1)(h) | critical | Real-time remote biometric identification in publicly accessible spaces is prohibited except for narrowly defined exceptions |
| EUAI-ART15-004 | Article 15(3) | high | User input passed directly to AI models without validation enables prompt injection and undermines robustness |
| EUAI-ART12-002 | Article 12(1) | high | AI system decisions must be logged to ensure traceability |
| EUAI-ART14-002 | Article 14(1) | high | AI systems must not make high-impact decisions without human oversight mechanisms |
| EUAI-ART15-005 | Article 15(3) | high | Raw unsanitized user input concatenated into model prompts enables adversarial attacks |
| EUAI-ART13-002 | Article 13(3)(b)(ii) | medium | AI system outputs should include confidence scores to support transparency |
| EUAI-ART14-003 | Article 14(4) | high | High-risk AI systems must include a mechanism for human override or shutdown |
| EUAI-ART10-002 | Article 10(2)(f) | medium | Training data must have documented lineage and provenance |

### Documentation obligations (10)

| ID | Clause | Description |
|----|--------|-------------|
| EUAI-ART9-001 | Article 9 | Risk management system continuously iterated throughout the AI system lifecycle |
| EUAI-ART10-001 | Article 10 | Data governance and management practices for training, validation, and testing datasets |
| EUAI-ART11-001 | Article 11 | Technical documentation drawn up before market placement and kept up to date |
| EUAI-ART12-001 | Article 12 | Automatic logging capabilities to ensure traceability of system functioning |
| EUAI-ART13-001 | Article 13 | Transparency for users to interpret and use AI system output appropriately |
| EUAI-ART14-001 | Article 14 | Human oversight procedures allowing effective oversight during the period of use |
| EUAI-ART15-001 | Article 15 | Accuracy, robustness, and cybersecurity testing throughout the system lifecycle |
| EUAI-ART43-001 | Article 43 | Conformity assessment procedure before market placement |
| EUAI-ART49-001 | Article 49 | Registration in the EU database before market placement |
| EUAI-ART72-001 | Article 72 | Post-market monitoring system proportionate to the nature of the AI system |

## Use case

Organizations developing or deploying high-risk AI systems within the EU, including AI-powered healthcare, hiring, credit scoring, law enforcement, and critical infrastructure applications. The pack provides:

1. **Prohibited practice detection** -- Catches social scoring and real-time biometric surveillance patterns in code
2. **Robustness enforcement** -- Flags hardcoded AI credentials, unvalidated model execution, prompt injection risks, and missing input validation
3. **Transparency and oversight** -- Requires AI disclosure notices, confidence scores, decision logging, and human override mechanisms
4. **Audit trail support** -- Documentation obligations appear in HTML/SARIF reports, providing auditors with traceable compliance status against EU AI Act requirements
