# CMMC 2.0

The `cmmc` pack enforces controls from **CMMC 2.0 Level 2**, mapped to NIST SP 800-171 Rev 2, for US defense contractors handling Controlled Unclassified Information (CUI). It covers access control, audit and accountability, identification and authentication, system and communications protection, and system and information integrity.

## Enable

```bash
sentrik add-pack cmmc
```

## Rules

The pack includes 19 rules across code enforcement and documentation obligations:

### Code rules (13)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| CMMC-AC-001 | AC.L2-3.1.1 | high | System access must be limited to authorized users performing authorized transactions (Python) |
| CMMC-AC-002 | AC.L2-3.1.2 | high | Express/Node.js route handlers must include authentication middleware |
| CMMC-AU-001 | AU.L2-3.3.1 | medium | System components must create audit records for security-relevant events |
| CMMC-AU-002 | AU.L2-3.3.2 | medium | Audit records must contain who, what, when, where, and outcome information |
| CMMC-IA-001 | IA.L2-3.5.3 | high | Systems processing CUI must implement multi-factor authentication for network access |
| CMMC-IA-002 | IA.L2-3.5.7 | critical | Passwords must meet minimum complexity requirements — no plaintext storage or weak hashing |
| CMMC-SC-001 | SC.L2-3.13.1 | high | Communications at system boundaries must use encrypted channels — no plaintext HTTP for external traffic |
| CMMC-SC-002 | SC.L2-3.13.8 | critical | Controlled Unclassified Information (CUI) must not appear as plaintext literals in source code |
| CMMC-SC-003 | SC.L2-3.13.11 | high | Only FIPS-validated cryptography may be used to protect CUI — MD5, SHA1, DES, RC4 are prohibited |
| CMMC-SC-004 | SC.L2-3.13.11 | critical | Cryptographic keys must be managed through approved key management processes, not embedded in code |
| CMMC-SI-001 | SI.L2-3.14.1 | medium | Known vulnerable dependencies and outdated packages must be identified and remediated |
| CMMC-SI-002 | SI.L2-3.14.2 | critical | Dynamic code execution on user input enables malicious code injection |
| CMMC-SI-003 | SI.L2-3.14.6 | high | Systems must monitor for unauthorized access attempts — debug mode and verbose errors must be disabled in production |

### Documentation obligations (6)

| ID | Clause | Description |
|----|--------|-------------|
| CMMC-DOC-001 | CA.L2-3.12.4 | System Security Plan (SSP) describing system boundaries, environments, security requirements, and implementation details |
| CMMC-DOC-002 | CA.L2-3.12.2 | Plan of Action and Milestones (POA&M) tracking remediation of security deficiencies |
| CMMC-DOC-003 | IR.L2-3.6.1 | Incident response plan defining procedures for detecting, reporting, and responding to cybersecurity incidents |
| CMMC-DOC-004 | AC.L2-3.1.1 | Access control policies and procedures defining authorized users, processes, and devices |
| CMMC-DOC-005 | CM.L2-3.4.1 | Configuration management policies establishing baselines and controlling changes to organizational systems |
| CMMC-DOC-006 | RA.L2-3.11.1 | Periodic risk assessments identifying and evaluating risks to organizational operations and CUI |

## Use case

Defense contractors, subcontractors, and any organization in the Defense Industrial Base (DIB) handling CUI. The pack provides:

1. **CUI protection** -- Catches plaintext CUI in source code, hardcoded cryptographic keys, and disabled MFA configurations across Python, JavaScript, Java, C#, Go, and Rust
2. **FIPS cryptographic compliance** -- Flags prohibited algorithms (MD5, SHA1, DES, RC4, Blowfish) and ensures FIPS 140-2 validated cryptography is used for CUI
3. **Access control enforcement** -- Detects unprotected route handlers in Python and Node.js/Express applications
4. **Audit trail support** -- Documentation obligations appear in HTML/SARIF reports, providing assessors with traceable compliance status against CMMC Level 2 practices mapped to NIST SP 800-171
