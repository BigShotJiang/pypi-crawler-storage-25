# 21 CFR Part 11

The `fda-21cfr11` pack enforces rules based on **FDA 21 CFR Part 11 -- Electronic Records; Electronic Signatures**. It covers audit trail requirements, access controls, data integrity, electronic signatures, system validation, and record retention for regulated industries.

!!! note "Organization tier required"
    This pack requires an **Organization** or **Enterprise** license key. See [sentrik.dev](https://sentrik.dev) for details.

## Enable

```bash
sentrik add-pack fda-21cfr11
```

## Rules

The pack includes 16 rules across code enforcement and documentation obligations:

### Code rules (14)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| CFR11-001 | 11.10(e) | high | Database writes without audit logging violate audit trail requirements |
| CFR11-002 | 11.10(e) | medium | Data records without timestamps violate audit trail requirements |
| CFR11-003 | 11.10(d) | high | API endpoints without authentication checks violate access control requirements |
| CFR11-004 | 11.10(d) | critical | Hardcoded credentials in source code violate access control requirements |
| CFR11-005 | 11.10(e) | high | Direct record mutation without versioning violates electronic record integrity |
| CFR11-006 | 11.10(c) | critical | Unsafe deserialization can corrupt regulated electronic records |
| CFR11-007 | 11.100 | high | Regulated actions without signature verification violate electronic signature requirements |
| CFR11-008 | 11.100 | high | Weak hash algorithms for digital signatures compromise signature integrity |
| CFR11-009 | 11.10(a) | critical | Dynamic code execution (eval/exec) is prohibited in validated systems |
| CFR11-010 | 11.10(a) | medium | Missing input validation violates system validation requirements |
| CFR11-011 | 11.10(c) | medium | Storing regulated records in temporary/memory storage violates retention requirements |
| CFR11-012 | 11.10(g) | medium | Operations on regulated data without role/permission checks violate authority requirements |
| CFR11-013 | 11.200(a) | medium | Sessions without timeout configuration violate device check requirements |
| CFR11-014 | 11.10(d) | high | Logging passwords, signatures, or regulated PII violates record protection |

### Documentation obligations (2)

| ID | Clause | Description |
|----|--------|-------------|
| CFR11-DOC-001 | 11.10(a) | System validation documentation (IQ/OQ/PQ protocols, traceability matrix) |
| CFR11-DOC-002 | 11.10(e) | Audit trail review and management procedures |

## Use case

Pharmaceutical companies, biotech firms, CROs, and any FDA-regulated organization maintaining electronic records or using electronic signatures. The pack provides:

1. **Audit trail enforcement** -- Catches database writes without logging, missing timestamps, and record mutations without versioning
2. **Electronic signature integrity** -- Flags regulated actions lacking signature verification and weak hash algorithms
3. **Validated system compliance** -- Detects eval/exec usage, missing input validation, and volatile storage of regulated records
4. **FDA inspection readiness** -- Documentation obligations map to 21 CFR Part 11 sections for pre-audit assessment
