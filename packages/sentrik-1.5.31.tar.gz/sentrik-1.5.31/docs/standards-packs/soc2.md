# SOC2

The `soc2` pack enforces rules for **SOC2 Trust Services Criteria** — Security, Availability, and Confidentiality.

## Enable

```bash
sentrik add-pack soc2
```

## Rules

The pack includes **30 rules** across code enforcement and documentation obligations. Code rules cover **Python, JavaScript/TypeScript, Java, C#, C/C++, and Go**.

### Code rules (21)

| ID | Category | Severity | Description |
|----|----------|----------|-------------|
| SOC2-CC6-001 | Access Control (CC6.1) | critical | Credentials must not be embedded in source code |
| SOC2-CC6-002 | Access Control (CC6.1) | high | Authentication must not be disabled or bypassed in code |
| SOC2-CC7-001 | System Operations (CC7.2) | high | Bare except clauses hide errors and undermine monitoring (Python) |
| SOC2-CC7-001-JS | System Operations (CC7.2) | high | Empty catch blocks hide errors (JS/TS) |
| SOC2-CC7-001-JAVA | System Operations (CC7.2) | high | Empty catch blocks hide errors (Java) |
| SOC2-CC7-001-CPP | System Operations (CC7.2) | high | Empty catch blocks hide errors (C/C++) |
| SOC2-CC7-002 | System Operations (CC7.2) | medium | Caught exceptions must not be silently ignored (Python) |
| SOC2-CC7-005-JS | System Operations (CC7.2) | medium | process.exit() causes abrupt shutdown without cleanup (JS/TS) |
| SOC2-CC7-006-JS | System Operations (CC7.2) | high | Empty .catch() handlers silently swallow errors (JS/TS) |
| SOC2-CC7-007-JAVA | System Operations (CC7.2) | medium | System.exit() causes abrupt shutdown without cleanup (Java) |
| SOC2-CC7-008-CS | System Operations (CC7.2) | high | Empty catch blocks hide errors (C#) |
| SOC2-CC7-009-GO | System Operations (CC7.2) | high | Empty error handling blocks silently discard errors (Go) |
| SOC2-CC8-002 | Change Management (CC8.1) | low | TODO comments indicate incomplete work |
| SOC2-CC8-003 | Change Management (CC8.1) | medium | FIXME comments indicate known issues |
| SOC2-CC8-004 | Change Management (CC8.1) | medium | HACK comments indicate fragile workarounds |
| SOC2-CC8-005-JS | Change Management (CC8.1) | low | Disabling ESLint rules bypasses code quality controls (JS/TS) |
| SOC2-C1-001 | Confidentiality (C1.1) | high | Sensitive data must not be logged in plaintext (Python) |
| SOC2-C1-001-JS | Confidentiality (C1.1) | high | Sensitive data must not be logged via console.log (JS/TS) |
| SOC2-C1-001-CPP | Confidentiality (C1.1) | high | Sensitive data must not be logged via printf/cout (C/C++) |
| SOC2-C1-004-JS | Confidentiality (C1.1) | medium | console.warn/error/debug/trace may leak sensitive data (JS/TS) |
| SOC2-C1-005-GO | Confidentiality (C1.1) | high | Sensitive data must not be printed to stdout (Go) |

### Documentation obligations (9)

| ID | TSC Criteria | Description |
|----|-------------|-------------|
| SOC2-CC6-003 | CC6.1 | Access control policy defining roles, permissions, and provisioning |
| SOC2-CC6-004 | CC6.3 | Periodic access reviews to verify appropriate permissions |
| SOC2-CC7-003 | CC7.2 | System monitoring and alerting for security events |
| SOC2-CC7-004 | CC7.3 | Incident response plan documented and tested |
| SOC2-CC8-001 | CC8.1 | Change management policy governing all production changes |
| SOC2-CC9-001 | CC9.1 | Regular risk assessments for operational and security risks |
| SOC2-A1-001 | A1.2 | Business continuity and disaster recovery plan |
| SOC2-C1-002 | C1.1 | Data classification policy with sensitivity levels |
| SOC2-C1-003 | C1.2 | Encryption standards for data at rest and in transit |

## Use case

SaaS companies and fintech organizations undergoing SOC2 audits. The pack provides:

1. **Automated code checks** — Catches common SOC2 control gaps (hardcoded credentials, missing logging, unhandled exceptions)
2. **Audit evidence** — Documentation obligations appear in HTML/SARIF reports, providing auditors with traceable compliance status
3. **Continuous compliance** — Run in CI/CD to catch regressions before they reach production
