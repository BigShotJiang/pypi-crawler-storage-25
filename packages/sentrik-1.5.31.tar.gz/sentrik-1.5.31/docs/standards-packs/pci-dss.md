# PCI DSS v4.0

The `pci-dss` pack enforces rules based on the **Payment Card Industry Data Security Standard v4.0** for protecting cardholder data. It covers secure coding, data protection, encryption in transit, access controls, and audit logging.

## Enable

```bash
sentrik add-pack pci-dss
```

## Rules

The pack includes 33 rules across code enforcement and documentation obligations:

### Code rules (25)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| PCI-REQ6.2-001 | 6.2 | critical | SQL queries must use parameterized statements, not string interpolation (Python) |
| PCI-REQ6.2-001-MULTI | 6.2 | critical | SQL queries built with string concatenation are vulnerable to injection |
| PCI-REQ6.2-002 | 6.2 | high | Template output must not bypass auto-escaping (Python) |
| PCI-REQ6.2-002-JS | 6.2 | high | Using innerHTML with dynamic content enables XSS |
| PCI-REQ6.2-003 | 6.2 | critical | Dynamic code execution via eval() or exec() is prohibited |
| PCI-REQ3.4-001 | 3.4 | critical | Primary Account Numbers (PANs) must not be stored as plaintext literals |
| PCI-REQ3.5-001 | 3.5 | critical | Cryptographic keys and credentials must not be embedded in source code |
| PCI-REQ4.2-001 | 4.2 | high | Data must be transmitted over encrypted channels (HTTPS, not HTTP) |
| PCI-REQ2.2-001 | 2.2 | high | Debug mode must not be enabled in production configurations |
| PCI-REQ10.2-001 | 10.2 | medium | Use structured logging instead of print statements (Python) |
| PCI-REQ10.2-001-JS | 10.2 | medium | Use structured logging instead of console.log |
| PCI-REQ10.2-001-JAVA | 10.2 | medium | Use structured logging instead of System.out.println |
| PCI-REQ10.2-001-CS | 10.2 | medium | Use structured logging instead of Console.Write |
| PCI-REQ6.2-004-CPP | 6.2 | high | rand()/srand() are not cryptographically secure for payment processing |
| PCI-REQ3.4-001-CPP | 3.4 | critical | Card data must not be output to stdout via printf or cout in C/C++ |
| PCI-REQ3.4-002-JS | 3.4 | critical | Card data must not be stored in localStorage/sessionStorage |
| PCI-REQ6.2-004-JS | 6.2 | high | crypto.createCipher() is deprecated and uses weak key derivation |
| PCI-REQ6.2-005-JS | 6.2 | critical | DES and RC4 cipher algorithms are broken and must not be used |
| PCI-REQ6.2-006-JAVA | 6.2 | medium | java.util.Random is not cryptographically secure for payment systems |
| PCI-REQ6.2-007-JAVA | 6.2 | high | Using Statement instead of PreparedStatement enables SQL injection |
| PCI-REQ3.4-002-JAVA | 3.4 | critical | Cardholder data must not be written to System.out |
| PCI-REQ6.2-006-CS | 6.2 | medium | System.Random is not cryptographically secure for payment systems |
| PCI-REQ6.2-007-CS | 6.2 | critical | SQL commands built with string concatenation in C# enable injection |
| PCI-REQ6.2-006-GO | 6.2 | medium | math/rand is not cryptographically secure for payment systems |
| PCI-REQ3.4-002-GO | 3.4 | critical | Cardholder data must not be written to stdout or logs in Go |

### Documentation obligations (8)

| ID | Clause | Description |
|----|--------|-------------|
| PCI-REQ1.1-001 | 1.1 | Network security policy defining firewall rules, segmentation, and access controls |
| PCI-REQ3.1-001 | 3.1 | Data retention policy defining storage limitations and disposal procedures |
| PCI-REQ5.1-001 | 5.1 | Anti-malware solutions deployed and maintained on all systems |
| PCI-REQ7.1-001 | 7.1 | Access to cardholder data restricted by business need-to-know |
| PCI-REQ9.1-001 | 9.1 | Physical access to cardholder data restricted and monitored |
| PCI-REQ10.1-001 | 10.1 | Audit logging to track access to cardholder data |
| PCI-REQ11.1-001 | 11.1 | Regular vulnerability scans and penetration tests |
| PCI-REQ12.1-001 | 12.1 | Comprehensive information security policy |

## Use case

Payment processors, e-commerce platforms, fintech companies, and any organization handling cardholder data. The pack provides:

1. **Cardholder data protection** -- Catches plaintext PANs, card data in logs, and insecure browser storage across Python, JavaScript, Java, C#, C/C++, and Go
2. **Injection prevention** -- Flags SQL injection vectors, XSS via innerHTML, and dynamic code execution
3. **Cryptography enforcement** -- Detects deprecated ciphers (DES, RC4), weak random number generators, and unencrypted HTTP transmission
4. **Audit readiness** -- Documentation obligations map to PCI DSS requirements for QSA assessments
