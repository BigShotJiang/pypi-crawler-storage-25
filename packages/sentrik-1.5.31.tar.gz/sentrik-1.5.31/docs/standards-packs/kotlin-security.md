# Kotlin Security

The `kotlin-security` pack enforces security rules for **Kotlin applications** across Android, Spring Boot, and server-side Kotlin, covering injection, cryptographic failures, Android-specific risks, and insecure patterns.

## Enable

```bash
sentrik add-pack kotlin-security
```

Auto-suggested when Sentrik detects `build.gradle.kts` or `*.kt` files in your project.

## Rules

The pack includes 13 rules across code enforcement and Android manifest checks:

### Code rules (10)

| ID | Category | Severity | Description |
|----|----------|----------|-------------|
| KT-SQL-001 | SQL Injection | critical | String interpolation/concatenation in `rawQuery`/`execSQL`/`compileStatement` |
| KT-SQL-002 | SQL Injection | critical | String templates in Spring `@Query` native queries |
| KT-CRYPTO-001 | Cryptography | high | Weak hash algorithms (MD5, SHA-1) via `MessageDigest.getInstance()` |
| KT-CRYPTO-002 | Cryptography | high | ECB encryption mode leaks data patterns |
| KT-CRYPTO-003 | Credentials | high | Hardcoded API keys, passwords, or tokens |
| KT-DESER-001 | Deserialization | high | Java `ObjectInputStream` deserialization of untrusted data |
| KT-ANDROID-001 | Android WebView | high | JavaScript enabled in WebView without controls |
| KT-LOG-001 | Information Exposure | high | Sensitive data (passwords, tokens) in log statements |
| KT-INJ-001 | Command Injection | critical | `Runtime.exec()` with string interpolation |
| KT-SPRING-001 | Access Control | high | Wildcard CORS origins in Spring configuration |

### Android manifest rules (3)

| ID | Category | Severity | Description |
|----|----------|----------|-------------|
| KT-ANDROID-002 | Component Security | medium | Exported components without permission restrictions |
| KT-ANDROID-003 | Transport Security | high | Cleartext HTTP traffic allowed |
