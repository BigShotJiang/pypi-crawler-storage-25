# MISRA C/C++

The `misra-c` pack enforces rules based on **MISRA C:2023 / MISRA C++:2023** coding guidelines for safety-critical C and C++ software. It covers control flow, memory management, banned standard library functions, and type safety.

!!! success "Free tier"
    This pack is available on all tiers, including the free tier.

## Enable

```bash
sentrik add-pack misra-c
```

## Rules

The pack includes 21 code rules:

### Code rules (21)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| MISRA-001 | Rule 15.1 | critical | goto statements are banned in safety-critical code |
| MISRA-002 | Rule 17.2 | high | Recursive function calls are prohibited due to unbounded stack usage |
| MISRA-003 | Rule 16.4 | medium | Every switch statement must have a default clause |
| MISRA-004 | Rule 15.6 | medium | All if/else statements must use braces |
| MISRA-005 | Rule 15.6 | medium | All for loops must use braces |
| MISRA-006 | Rule 15.6 | medium | All while loops must use braces |
| MISRA-007 | Rule 21.3 | critical | malloc() is banned -- dynamic memory allocation is prohibited |
| MISRA-008 | Rule 21.3 | critical | calloc() is banned -- dynamic memory allocation is prohibited |
| MISRA-009 | Rule 21.3 | critical | realloc() is banned -- dynamic memory reallocation is prohibited |
| MISRA-010 | Rule 21.3 | critical | free() is banned -- manual memory deallocation is prohibited |
| MISRA-011 | Rule 21.14 | critical | Unsafe string functions (gets, strcpy, strcat, sprintf) are banned |
| MISRA-012 | Rule 21.8 | high | abort(), exit(), and system() are banned |
| MISRA-013 | Rule 21.7 | high | atoi() and atof() are banned due to undefined behavior on invalid input |
| MISRA-014 | Rule 21.4 | critical | setjmp/longjmp are banned -- they bypass structured control flow |
| MISRA-015 | Rule 21.5 | high | signal() and raise() are banned -- asynchronous signal handling is unsafe |
| MISRA-016 | Rule 21.6 | medium | printf, scanf, and other stdio functions are banned in production |
| MISRA-017 | Rule 17.1 | high | Variable argument lists (va_list, va_start, va_arg) are banned |
| MISRA-018 | Rule 19.2 | medium | Unions must not be used for type punning |
| MISRA-019 | Rule 18.4 | medium | Pointer arithmetic is restricted due to out-of-bounds risks |
| MISRA-020 | Rule 7.1 | low | Octal constants are banned due to readability confusion |
| MISRA-021 | Rule 4.2 | low | Trigraph sequences are banned |

## Use case

Automotive, aerospace, industrial, and embedded systems teams writing safety-critical C/C++ software. The pack provides:

1. **Memory safety** -- Bans dynamic memory allocation (malloc, calloc, realloc, free) and unsafe string functions that cause buffer overflows
2. **Control flow discipline** -- Prohibits goto, recursion, setjmp/longjmp, and enforces braces on all control structures
3. **Banned function enforcement** -- Flags abort, exit, system, atoi, signal, and stdio functions that are prohibited in safety-critical environments
4. **MISRA compliance evidence** -- Rules map to specific MISRA C:2023 rule numbers for compliance documentation and tool qualification
