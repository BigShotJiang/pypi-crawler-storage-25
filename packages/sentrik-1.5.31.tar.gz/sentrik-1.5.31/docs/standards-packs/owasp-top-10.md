# OWASP Top 10

The `owasp-top-10` pack enforces rules for the **OWASP Top 10 2021** web application security risks.

## Enable

```bash
sentrik add-pack owasp-top-10
```

## Rules

The pack includes **69 rules** covering all 10 OWASP categories across **8 languages**: Python, JavaScript/TypeScript, Java, C#, Go, C/C++, Ruby, and Rust (via multi-language glob patterns).

### Code rules (64)

#### A01: Broken Access Control (7 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A01-001 | no-permissive-cors | high | All | Wildcard CORS origin allows any site to make cross-origin requests |
| OWASP-A01-002 | no-debug-true-in-config | high | All | Debug mode enabled in production exposes sensitive information |
| OWASP-A01-003-JS | no-open-redirect | high | JS/TS | Redirecting to user-controlled URLs enables phishing |
| OWASP-A01-004-JS | no-path-traversal | critical | JS/TS | User input in file system paths enables path traversal |
| OWASP-A01-005-JAVA | no-path-traversal-java | high | Java | Constructing File objects from user input enables path traversal |
| OWASP-A01-005-CS | no-path-traversal-csharp | high | C# | Opening files from user input enables path traversal |
| OWASP-A01-005-GO | no-path-traversal-go | high | Go | Opening files from user-controlled URL paths enables path traversal |

#### A02: Cryptographic Failures (15 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A02-001 | no-md5-hashing | high | All | MD5 is cryptographically broken |
| OWASP-A02-001-JS | no-md5-require-js | high | JS/TS | Importing MD5 libraries indicates broken cryptography |
| OWASP-A02-001-JAVA | no-md5-java | high | Java | MessageDigest.getInstance("MD5") uses broken cryptography |
| OWASP-A02-001-CS | no-md5-csharp | high | C# | MD5.Create() uses broken cryptography |
| OWASP-A02-001-CPP | no-md5-openssl-cpp | high | C/C++ | OpenSSL MD5 functions use broken cryptography |
| OWASP-A02-002 | no-sha1-hashing | medium | All | SHA-1 is deprecated and vulnerable to collisions |
| OWASP-A02-002-JS | no-sha1-js | medium | JS/TS | Creating SHA-1 hashes uses a deprecated algorithm |
| OWASP-A02-002-JAVA | no-sha1-java | medium | Java | MessageDigest.getInstance("SHA-1") is deprecated |
| OWASP-A02-002-CPP | no-sha1-openssl-cpp | medium | C/C++ | OpenSSL SHA-1 functions are deprecated |
| OWASP-A02-003 | no-hardcoded-secrets | critical | All | Secrets hardcoded in source code are easily extracted |
| OWASP-A02-004-CPP | no-unsafe-random-cpp | medium | C/C++ | rand()/srand() are not cryptographically secure |
| OWASP-A02-005-JS | no-jwt-decode-without-verify | high | JS/TS | jwt.decode() does not verify the token signature |
| OWASP-A02-006-JS | no-math-random-for-security | medium | JS/TS | Math.random() is not cryptographically secure |
| OWASP-A02-007-JAVA | no-weak-random-java | medium | Java | java.util.Random is not cryptographically secure |
| OWASP-A02-007-CS | no-weak-random-csharp | medium | C# | System.Random is not cryptographically secure |

#### A03: Injection (27 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A03-001 | no-sql-string-formatting | critical | Python | SQL queries with string formatting enable SQL injection |
| OWASP-A03-001-MULTI | no-sql-string-concat | critical | JS/TS, Java, C#, Go, C/C++ | SQL queries with string concatenation enable SQL injection |
| OWASP-A03-002 | no-sql-f-strings | critical | Python | SQL queries with f-strings enable SQL injection |
| OWASP-A03-002-JS | no-sql-template-literals | critical | JS/TS | SQL queries with template literals enable SQL injection |
| OWASP-A03-003 | no-os-system-calls | high | Python | os.system() is vulnerable to command injection |
| OWASP-A03-003-JAVA | no-runtime-exec-java | high | Java | Runtime.exec() with string argument enables command injection |
| OWASP-A03-003-JS | no-child-process-exec-js | high | JS/TS | child_process.exec() is vulnerable to command injection |
| OWASP-A03-003-CPP | no-system-call-cpp | high | C/C++ | system() calls are vulnerable to command injection |
| OWASP-A03-004-CPP | no-gets-cpp | critical | C/C++ | gets() has no bounds checking (removed in C11) |
| OWASP-A03-005-CPP | no-strcpy-cpp | high | C/C++ | strcpy() has no bounds checking |
| OWASP-A03-006-CPP | no-scanf-unbounded-cpp | high | C/C++ | scanf with %s has no width limit |
| OWASP-A03-007-CPP | no-format-string-vuln-cpp | critical | C/C++ | printf(variable) enables format string attacks |
| OWASP-A03-008-CPP | no-malloc-without-review-cpp | medium | C/C++ | Manual malloc() is error-prone (leaks, use-after-free) |
| OWASP-A03-004 | no-shell-true | high | Python | subprocess with shell=True enables shell injection |
| OWASP-A03-005 | no-eval | critical | All | eval() executes arbitrary code |
| OWASP-A03-006 | no-exec | critical | Python, JS/TS | exec() executes arbitrary code |
| OWASP-A03-009-JS | no-dangerously-set-innerhtml | high | JS/TS | dangerouslySetInnerHTML bypasses XSS protection |
| OWASP-A03-010-JS | no-document-write | high | JS/TS | document.write() can introduce XSS vulnerabilities |
| OWASP-A03-011-JS | no-prototype-pollution | high | JS/TS | Object.assign with unsanitized request data |
| OWASP-A03-012-JS | no-nosql-injection | critical | JS/TS | Unsanitized request data in MongoDB queries |
| OWASP-A03-013-JAVA | no-xss-getparameter-output-java | high | Java | Writing getParameter() directly to response enables XSS |
| OWASP-A03-014-JAVA | no-ldap-injection-java | high | Java | User input in LDAP queries enables LDAP injection |
| OWASP-A03-015-JAVA | no-sql-statement-java | high | Java | Statement with string concat enables SQL injection |
| OWASP-A03-016-CS | no-sql-injection-csharp | critical | C# | SqlCommand with string concatenation enables SQL injection |
| OWASP-A03-017-CS | no-xss-response-write-csharp | high | C# | Writing user input to Response enables XSS |
| OWASP-A03-018-GO | no-sql-injection-go | critical | Go | SQL queries with fmt.Sprintf enable SQL injection |
| OWASP-A03-019-GO | no-command-injection-go | high | Go | Shell commands with string concatenation enable injection |

#### A05: Security Misconfiguration (5 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A05-001 | no-http-urls | medium | All | HTTP URLs transmit data in cleartext |
| OWASP-A05-002 | no-verify-false | high | Python | Disabling SSL verification exposes connections to MITM |
| OWASP-A05-002-JS | no-tls-reject-unauthorized-false | high | JS/TS | Disabling TLS validation in Node.js |
| OWASP-A05-002-GO | no-tls-insecure-skip-verify | high | Go | Disabling TLS verification in Go |
| OWASP-A05-003-JAVA | no-hardcoded-ip-url-java | medium | Java | Hardcoded IP addresses in URLs |

#### A07: Identification and Authentication Failures (1 rule)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A07-001 | no-plaintext-passwords | critical | All | Passwords must not be stored or compared in plaintext |

#### A08: Software and Data Integrity Failures (6 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A08-001 | no-pickle-loads | critical | Python | pickle.loads() enables remote code execution |
| OWASP-A08-002 | no-yaml-unsafe-load | high | Python | yaml.load() without SafeLoader executes arbitrary objects |
| OWASP-A08-002-JS | no-unsafe-deserialization-js | high | JS/TS | node-serialize enables arbitrary code execution |
| OWASP-A08-002-JAVA | no-unsafe-deserialization-java | critical | Java | ObjectInputStream.readObject() enables RCE |
| OWASP-A08-003-JAVA | no-xxe-java | high | Java | XML parsers without disabled external entities |
| OWASP-A08-003-CS | no-unsafe-deserialization-csharp | critical | C# | BinaryFormatter enables remote code execution |

#### A10: Server-Side Request Forgery (3 rules)

| ID | Name | Severity | Languages | Description |
|----|------|----------|-----------|-------------|
| OWASP-A10-001 | no-unvalidated-redirects | high | Python | User-controlled URLs in requests enable SSRF |
| OWASP-A10-002-JS | no-ssrf-user-input | high | JS/TS | HTTP requests with user-controlled URLs enable SSRF |
| OWASP-A10-003-JAVA | no-unsafe-redirect-java | high | Java | Redirecting to user-supplied URLs enables open redirects |

### Documentation obligations (5)

| ID | Category | Description |
|----|----------|-------------|
| OWASP-A04-001 | A04: Insecure Design | A threat model must be created and maintained |
| OWASP-A04-002 | A04: Insecure Design | Security design reviews for significant changes |
| OWASP-A06-001 | A06: Vulnerable Components | Dependencies must be tracked and updated for security patches |
| OWASP-A09-001 | A09: Logging Failures | Security-relevant events must be logged with sufficient detail |
| OWASP-A09-002 | A09: Logging Failures | An incident response plan must be established and tested |

## Multi-language coverage

Rules use `file_glob` patterns with brace expansion to match multiple languages in a single rule. For example, `**/*.{py,js,ts,jsx,tsx,java,cs,go,rs,cpp,c,h,hpp}` covers all supported languages. Language-specific rules (e.g., `OWASP-A03-001` for Python SQL injection vs. `OWASP-A03-001-MULTI` for other languages) provide targeted detection with lower false-positive rates.

## Use case

Any team building web applications — especially those using AI coding agents that may introduce OWASP vulnerabilities without awareness. The pack catches the most common security issues across your entire polyglot stack before they reach production.
