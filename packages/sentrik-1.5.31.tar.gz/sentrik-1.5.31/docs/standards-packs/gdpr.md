# GDPR

The `gdpr` pack enforces rules based on the **EU General Data Protection Regulation (GDPR)** for protecting personal data. It covers data protection by design, consent handling, PII security, right to erasure, breach notification, and cross-border transfer controls.

## Enable

```bash
sentrik add-pack gdpr
```

## Rules

The pack includes 25 rules across code enforcement and documentation obligations:

### Code rules (17)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| GDPR-ART25-001 | Article 25 | critical | Personal data must not appear in Python log statements |
| GDPR-ART25-002 | Article 25 | critical | Personal data must not appear in JavaScript/TypeScript console output |
| GDPR-ART25-003 | Article 25 | critical | Personal data must not appear in Java log or System.out statements |
| GDPR-ART32-001 | Article 32 | critical | Personal data fields must not be stored as plaintext string literals in source code |
| GDPR-ART25-004 | Article 25 | high | Hardcoded personal data (email addresses, phone numbers) must not appear in source code |
| GDPR-ART32-002 | Article 32 | critical | Passwords must not be stored or compared in plaintext |
| GDPR-ART5-001 | Article 5(1)(c) | high | SELECT * retrieves all columns including unnecessary personal data -- violates data minimization |
| GDPR-ART5-002 | Article 5(1)(b) | high | Direct personal identifiers must not appear in analytics or tracking code |
| GDPR-ART7-001 | Article 7 | high | Data processing modules must include consent verification logic |
| GDPR-ART7-002 | Article 7 | high | Analytics and tracking scripts must not load without consent checks |
| GDPR-ART7-003 | Article 7 | high | Setting cookies must be preceded by consent verification |
| GDPR-ART17-001 | Article 17 | high | API applications must provide a data deletion endpoint to support the right to erasure |
| GDPR-ART17-002 | Article 17 | high | Soft-delete patterns that retain personal data violate right to erasure |
| GDPR-ART32-003 | Article 32 | high | Personal data must be transmitted over encrypted channels (HTTPS, not HTTP) |
| GDPR-ART32-004 | Article 32 | high | Database connections handling personal data should use SSL/TLS encryption |
| GDPR-ART32-005 | Article 32 | medium | Modules handling personal data must include audit logging capabilities |
| GDPR-ART44-001 | Articles 44-49 | high | API calls transmitting personal data to external services must include transfer safeguard references |

### Documentation obligations (8)

| ID | Clause | Description |
|----|--------|-------------|
| GDPR-ART13-001 | Articles 13/14 | Privacy notice detailing processing purposes, legal basis, retention periods, and data subject rights |
| GDPR-ART30-001 | Article 30 | Records of processing activities documenting all personal data processing operations |
| GDPR-ART35-001 | Article 35 | Data Protection Impact Assessment for high-risk processing |
| GDPR-ART33-001 | Articles 33/34 | Data breach notification procedure for reporting to supervisory authorities within 72 hours |
| GDPR-ART28-001 | Article 28 | Data Processing Agreements with all processors handling personal data |
| GDPR-ART7-004 | Article 7 | Consent collection, storage, and withdrawal mechanisms documentation |
| GDPR-ART44-002 | Articles 44-49 | Documentation for all transfers of personal data to third countries |
| GDPR-ART5-003 | Article 5(1)(e) | Data retention policy defining storage periods for each category of personal data |

## Use case

Any organization processing personal data of EU residents, including SaaS platforms, e-commerce sites, and data-driven applications. The pack provides:

1. **PII leak detection** -- Catches personal data in log statements, console output, plaintext storage, hardcoded values, and analytics events across Python, JavaScript, Java, and other languages
2. **Consent enforcement** -- Flags tracking scripts, cookies, and data processing without consent verification
3. **Data subject rights** -- Requires deletion endpoints and flags soft-delete patterns that violate the right to erasure
4. **Security of processing** -- Enforces HTTPS transmission, encrypted database connections, password hashing, and audit logging
5. **Audit trail support** -- Documentation obligations appear in HTML/SARIF reports, providing auditors with traceable compliance status against GDPR requirements
