# PHP Security

The `php-security` pack enforces security rules for **PHP and Laravel applications**, covering code injection, SQL injection, XSS, file inclusion, cryptographic failures, and framework-specific vulnerabilities.

## Enable

```bash
sentrik add-pack php-security
```

Auto-suggested when Sentrik detects `composer.json` or `artisan` in your project.

## Rules

The pack includes 15 rules, all code enforcement:

| ID | Category | Severity | Description |
|----|----------|----------|-------------|
| PHP-INJ-001 | Code Injection | critical | `eval()` executes arbitrary PHP code |
| PHP-INJ-002 | Code Injection | critical | Shell execution functions (`system`, `exec`, `passthru`, `shell_exec`, `popen`, `proc_open`) |
| PHP-INJ-003 | Code Injection | critical | Backtick operator executes shell commands with variable interpolation |
| PHP-INJ-004 | Code Injection | critical | `/e` modifier in `preg_replace` evaluates replacement as PHP code |
| PHP-SQL-001 | SQL Injection | critical | String interpolation in `mysql_query`/`mysqli_query`/`pg_query` |
| PHP-SQL-002 | SQL Injection | high | `DB::raw()`/`whereRaw()` with variable interpolation bypasses Laravel query builder |
| PHP-XSS-001 | XSS | high | Blade `{!! !!}` outputs raw HTML without escaping |
| PHP-XSS-002 | XSS | critical | `echo` with unsanitized superglobals (`$_GET`, `$_POST`, etc.) |
| PHP-FILE-001 | File Inclusion | critical | Dynamic `include`/`require` with variable paths |
| PHP-CRYPTO-001 | Cryptography | critical | MD5/SHA1 used for password hashing |
| PHP-CRYPTO-002 | Credentials | high | Hardcoded API keys, passwords, or secrets |
| PHP-DESER-001 | Deserialization | critical | `unserialize()` on user-controlled input |
| PHP-CSRF-001 | CSRF | medium | Routes excluded from Laravel CSRF protection |
| PHP-SESSION-001 | Session | medium | Missing session ID regeneration after authentication |
| PHP-LARAVEL-001 | Mass Assignment | high | `$guarded = []` with no `$fillable` whitelist |

## CISA Context

This pack was created in response to CISA KEV additions:

- **CVE-2025-54068** — Laravel Livewire remote code execution via code injection
- **CVE-2025-32432** — Craft CMS code injection vulnerability

Both highlight the continued emphasis on code injection prevention in PHP applications.
