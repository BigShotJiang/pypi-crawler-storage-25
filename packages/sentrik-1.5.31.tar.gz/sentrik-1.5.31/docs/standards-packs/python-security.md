# Python Security

The `python-security` pack enforces security rules for **Python applications** covering code execution, deserialization, command injection, cryptography, web frameworks (Django, Flask, FastAPI), file/path security, and network security.

## Enable

```bash
sentrik add-pack python-security
```

## Rules

The pack includes 18 code rules:

### Code rules (18)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| PY-SEC-001 | CWE-95 | critical | eval() executes arbitrary code and is a critical injection vector |
| PY-SEC-002 | CWE-95 | critical | exec() executes arbitrary code strings and enables code injection |
| PY-SEC-003 | CWE-95 | high | compile() + exec() is equivalent to eval/exec and enables code injection |
| PY-SEC-004 | CWE-502 | critical | pickle.load() deserializes arbitrary Python objects and enables remote code execution |
| PY-SEC-005 | CWE-502 | high | yaml.load() without SafeLoader can execute arbitrary Python code via YAML tags |
| PY-SEC-006 | CWE-502 | high | shelve uses pickle internally and inherits its arbitrary code execution risks |
| PY-SEC-007 | CWE-78 | critical | os.system() passes commands through the shell and enables command injection |
| PY-SEC-008 | CWE-78 | high | subprocess with shell=True enables command injection through shell metacharacters |
| PY-SEC-009 | CWE-328 | high | MD5 and SHA1 are cryptographically broken and must not be used for security |
| PY-SEC-010 | CWE-338 | medium | The random module is not cryptographically secure and must not be used for tokens or keys |
| PY-SEC-011 | CWE-215 | high | Django DEBUG=True in production exposes sensitive information including settings and stack traces |
| PY-SEC-012 | CWE-215 | critical | Flask debug mode enables the interactive debugger which allows arbitrary code execution |
| PY-SEC-013 | CWE-798 | critical | Hardcoded SECRET_KEY allows session forgery and CSRF bypass |
| PY-SEC-014 | CWE-89 | critical | SQL queries built with f-strings or .format() are vulnerable to injection |
| PY-SEC-015 | CWE-377 | medium | tempfile.mktemp() has a race condition that enables symlink attacks |
| PY-SEC-016 | CWE-732 | high | Setting world-writable permissions creates a privilege escalation risk |
| PY-SEC-017 | CWE-295 | high | Disabling SSL verification allows man-in-the-middle attacks |
| PY-SEC-018 | CWE-668 | medium | Binding to 0.0.0.0 exposes the service to all network interfaces including external |

## Use case

Python web applications, APIs, data pipelines, and automation scripts. The pack provides:

1. **Code execution prevention** -- Catches eval(), exec(), compile(), and unsafe deserialization via pickle, shelve, and yaml.load()
2. **Injection detection** -- Flags command injection via os.system() and subprocess shell=True, and SQL injection via f-strings and .format()
3. **Web framework hardening** -- Detects Django/Flask debug mode in production, hardcoded SECRET_KEY values, disabled SSL verification, and overly permissive network bindings
