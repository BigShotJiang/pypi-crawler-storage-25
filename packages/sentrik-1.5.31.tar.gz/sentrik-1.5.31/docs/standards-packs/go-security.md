# Go Security

The `go-security` pack enforces security rules for **Go applications** covering injection, cryptography, unsafe operations, concurrency, web framework vulnerabilities, and error handling.

## Enable

```bash
sentrik add-pack go-security
```

## Rules

The pack includes 15 code rules:

### Code rules (15)

| ID | Clause | Severity | Description |
|----|--------|----------|-------------|
| GO-SEC-001 | CWE-89 | critical | SQL queries built with string concatenation or fmt.Sprintf are vulnerable to injection |
| GO-SEC-002 | CWE-78 | critical | os/exec with string interpolation enables command injection |
| GO-SEC-003 | CWE-79 | high | Using text/template instead of html/template for web output disables HTML escaping |
| GO-SEC-004 | CWE-328 | high | MD5 and SHA1 are cryptographically broken and must not be used for security purposes |
| GO-SEC-005 | CWE-326 | high | TLS versions below 1.2 are vulnerable to known attacks |
| GO-SEC-006 | CWE-295 | critical | Disabling TLS certificate verification allows man-in-the-middle attacks |
| GO-SEC-007 | CWE-321 | critical | Cryptographic keys hardcoded in source code can be extracted by anyone with repo access |
| GO-SEC-008 | CWE-787 | medium | Package unsafe bypasses Go's type safety and memory safety guarantees |
| GO-SEC-009 | CWE-120 | medium | CGO introduces C memory management risks (buffer overflows, use-after-free) into Go programs |
| GO-SEC-010 | CWE-942 | high | Allowing all CORS origins exposes the API to cross-origin attacks |
| GO-SEC-011 | CWE-22 | high | Serving files from user-controlled paths without sanitization enables path traversal |
| GO-SEC-012 | CWE-400 | low | Goroutines without context cancellation can leak and exhaust resources |
| GO-SEC-013 | CWE-833 | medium | Unbuffered channels in HTTP handlers can cause goroutine deadlocks under load |
| GO-SEC-014 | CWE-252 | medium | Ignoring error returns can mask security failures and data corruption |
| GO-SEC-015 | CWE-248 | medium | Unrecovered panics in HTTP handlers crash the entire server |

## Use case

Go backend services, microservices, and CLI tools. The pack provides:

1. **Injection prevention** -- Catches SQL injection via string concatenation, command injection via os/exec, XSS via text/template, and path traversal in file serving
2. **Cryptography enforcement** -- Flags weak hashes (MD5, SHA1), weak TLS versions, disabled certificate verification, and hardcoded crypto keys
3. **Concurrency safety** -- Detects goroutine leaks without context, unbuffered channels in HTTP handlers, and unrecovered panics
