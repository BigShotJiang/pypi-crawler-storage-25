# SENTRA Dashboard Demo — MedFiles Example Project

> **Duration:** ~20 minutes
> **Audience:** Engineering leads, compliance officers, security teams
> **Story:** A medical device team has a data processing pipeline (MedFiles) with security and compliance issues. Walk through the dashboard to scan, triage, govern, and report.

---

## Prerequisites

- Node.js installed (for npm)
- A terminal and a web browser
- No DevOps credentials needed (uses stub provider)

---

## Step 1 — Install and Clone

```bash
# Install SENTRA
npm install -g sentrik

# Clone the example project
git clone https://github.com/maxgerhardson/sentrik-example-medfiles.git
cd sentrik-example-medfiles
```

The MedFiles project is a medical device data processing pipeline with **intentional compliance findings**:

| File | Purpose | Intentional Findings |
|------|---------|---------------------|
| `src/ingest.py` | Patient CSV ingestion | Clean (compliant) |
| `src/anonymize.py` | PII anonymization | Hardcoded secret, print statement, weak hashing (MD5) |
| `src/export_fhir.py` | FHIR R4 export | Clean (compliant) |
| `src/audit.py` | Audit trail logging | eval(), mutable default argument |
| `src/app.py` | Main pipeline | print statements |

---

## Step 2 — Initialize and Start the Dashboard

```bash
# Initialize with medical device governance
sentrik init
```

When prompted, select:
- **Industry:** Medical device (IEC 62304)
- **Governance profile:** Strict
- **DevOps provider:** stub (for demo purposes)
- Accept defaults for everything else

```bash
# Start the SENTRA server
sentrik dashboard --port 8000
```

Open your browser to **http://localhost:8000/dashboard**

> **What just happened?**
> `sentrik init` created a `.sentrik/config.yaml` config file with the `fda-iec-62304` pack enabled and strict governance settings. `sentrik dashboard` starts a FastAPI server hosting the REST API and the dashboard.

---

## Step 3 — Onboarding Wizard

When you first open the dashboard, the **Onboarding Wizard** appears with 4 guided steps:

1. **Configure DevOps** — Shows the Integration tab; for this demo, keep "stub" selected and click **Next**
2. **Enable Packs** — Shows available standards packs; verify `fda-iec-62304` is enabled, click **Next**
3. **Run Scan** — Prompts you to run your first scan; click **Run Scan Now** (we'll do this in Step 5)
4. **Review Findings** — Guides you to the Findings tab

Click **Skip** on step 3 for now — we'll add more packs first.

---

## Step 4 — Integration Tab: Configure DevOps

Click the **Integration** tab (or press `8` on the keyboard).

1. The **Platform** dropdown shows: stub, azure, github, jira
2. Keep **stub** selected for this demo
3. Click **Test Connection** — you'll see a green success toast
4. The header shows a small indicator: **stub connected**

---

## Step 5 — Packs Tab: Enable Standards Packs

Click the **Packs** tab (or press `6`).

You'll see pack cards for all available standards:

| Pack | Description | Rules | Status |
|------|-------------|-------|--------|
| `fda-iec-62304` | Medical device software lifecycle (IEC 62304) | 14 | Enabled |
| `owasp-top-10` | OWASP Top 10 2021 web security rules | 22 | Disabled |
| `soc2` | SOC2 Trust Services Criteria | 16 | Disabled |
| `hipaa` | HIPAA Security Rule for ePHI protection | 15 | Disabled |
| `pci-dss` | PCI DSS v4.0 for cardholder data | 16 | Disabled |
| `iso-27001` | ISO/IEC 27001:2022 information security | 14 | Disabled |

1. Click **Enable** on `owasp-top-10` — a green toast confirms
2. Click **Enable** on `hipaa` — since this project handles patient data, HIPAA rules apply
3. Click on a pack card to expand it and browse the rules inside

> **What just happened?**
> SENTRIK ships with 22 standards packs (526 rules total) across 5 free, 11 team, and 6 Organization-tier packs. Each pack contains rules mapped to specific regulatory clauses. With `fda-iec-62304`, `owasp-top-10`, and `hipaa` enabled, your scan will check against 125 rules covering medical device compliance, web security, and healthcare data protection.

---

## Step 6 — Overview Tab: Run Scan

Click the **Overview** tab (or press `1`).

1. Click the **Run Scan** button
2. Watch the **SSE progress bar** fill in real-time as files are scanned
3. When complete, the Overview shows:
   - **Health cards** — Total findings, Critical count, Files scanned, Rules checked
   - **Severity donut chart** — Visual breakdown by Critical / High / Medium / Low
   - **Scan trends** — Line chart showing findings over time (first data point appears)

You should see approximately:
- **20+ findings** across 5 Python files
- **2 Critical** findings (hardcoded secret in `anonymize.py`, eval() in `audit.py`)
- **1+ High** findings (MD5 hashing in `anonymize.py`)
- **Several Medium/Low** findings (print statements, mutable default argument)

---

## Step 7 — Findings Tab: Filter and Explore

Click the **Findings** tab (or press `2`).

### Filter by severity

1. Click the **Critical** filter button at the top
2. The table narrows to only Critical findings — you should see:
   - Hardcoded secret in `anonymize.py` — `SECRET_KEY = "medfiles-anonymization-key-2024"`
   - eval() in `audit.py` — `eval("os.environ.get(...)")`

### Expand a finding

3. Click on the **hardcoded secret** finding to expand it
4. You'll see:
   - **Rule ID** and matched standards (OWASP-A02, HIPAA-164.312-d, SOC2-CC6-001)
   - **File:** `anonymize.py` with the line number
   - **Code context:** The offending line highlighted
   - **Remediation guidance:** Move to environment variables or a secrets manager

### Sort findings

5. Click the **File** column header to sort — see all issues per file grouped together
6. Click the **Severity** header to sort by severity descending

---

## Step 8 — Suppress a Known-Safe Finding

Still on the **Findings** tab:

1. Find a low-severity finding that is acceptable for this project
2. Click the **Suppress** button on that finding row
3. In the suppression dialog, enter:
   - **Reason:** "Accepted risk — tracked in backlog"
   - **Expiry:** 90 days (optional)
4. Click **Confirm**
5. The finding dims and shows a "Suppressed" badge

---

## Step 9 — Policies Tab: Governance Profile

Click the **Policies** tab (or press `4`).

1. You'll see three governance profiles:
   - **Permissive** — Gate fails on Critical only
   - **Standard** — Gate fails on Critical + High
   - **Strict** — Gate fails on Critical + High + Medium (currently selected)
2. Below the profiles, toggle switches for:
   - **Human Review Gate** — Require manual approval before deployment
   - **Auto-Patch** — Automatically generate fix patches

---

## Step 10 — Work Items Tab: Coverage and Reconciliation

Click the **Work Items** tab (or press `7`).

### Check coverage

1. Click **Check Coverage** — a modal shows which findings are tracked by work items and which are untracked
2. Since this is a fresh scan, all findings are **untracked**

### Generate requirements

3. Click **Generate Requirements** in the coverage modal
4. A dry-run preview shows auto-generated requirement drafts:
   - Each requirement maps to a group of related findings
   - Titles like "Fix hardcoded secret in anonymize.py"
5. Click **Execute** to write them to `requirements.yaml`

### Reconcile with DevOps

6. Click **Sync to DevOps** — this triggers a dry-run reconciliation
7. A preview modal shows planned actions with **Create** / **Update** / **Close** badges
8. Click **Execute** to push (to the stub provider — no real tickets created)

---

## Step 11 — Reports Tab: Generate HTML Report

Click the **Reports** tab (or press `3`).

1. Select **HTML** from the format dropdown
2. Click **Generate Report**
3. A styled HTML report appears with:
   - **Donut chart** — Severity breakdown
   - **Filter buttons** — Toggle Critical / High / Medium / Low
   - **Sortable table** — Click column headers to sort
   - **Expandable rows** — Click a finding for full details
   - **Dark mode** — Respects the dashboard theme
   - **Print-ready** — Ctrl+P generates a clean PDF
4. Click **Download** to save the report

---

## Step 12 — Bonus: Keyboard Shortcuts and Theme

### Global search

1. Press **Ctrl+K** — a search overlay appears
2. Type "MD5" — results show the weak hashing finding in `anonymize.py`
3. Click a result to jump to it

### Tab switching

4. Press number keys **1** through **0** to jump between tabs

### Theme toggle

5. Click the **theme toggle** button (sun/moon icon) in the header
6. The dashboard switches between light and dark mode

---

## Summary of Features Demonstrated

| # | Feature | Tab/Location |
|---|---------|-------------|
| 1 | Project initialization | Terminal (setup) |
| 2 | Onboarding wizard | Overlay (first visit) |
| 3 | DevOps integration | Integration tab |
| 4 | Standards pack management (6 packs) | Packs tab |
| 5 | Real-time scan with SSE progress | Overview tab |
| 6 | Severity donut chart and trends | Overview tab |
| 7 | Finding filter / sort / expand | Findings tab |
| 8 | Finding suppression with audit trail | Findings tab |
| 9 | Governance profiles (Strict/Standard/Permissive) | Policies tab |
| 10 | Coverage check | Work Items tab |
| 11 | Auto-generate requirements | Work Items tab |
| 12 | Dry-run reconciliation | Work Items tab |
| 13 | HTML report (donut, filters, sort, expand, print) | Reports tab |
| 14 | Global search (Ctrl+K) | Overlay |
| 15 | Keyboard shortcuts | All tabs |
| 16 | Theme toggle (light/dark) | Header |

---

## Cleanup

```bash
# Stop the server (Ctrl+C in the terminal running sentrik dashboard)
cd ..
rm -rf sentrik-example-medfiles/
```
