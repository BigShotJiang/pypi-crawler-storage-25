# Sentrik — Distribution & Infrastructure

## Distribution Channels

| Channel | URL / Install | Account | Status |
|---------|--------------|---------|--------|
| **npm** | `npm install -g sentrik` / [npmjs.com/package/sentrik](https://www.npmjs.com/package/sentrik) | npmjs.com (maxgerhardson) | Live (v1.2.0) |
| **PyPI** | `pip install sentrik` / [pypi.org/project/sentrik](https://pypi.org/project/sentrik) | pypi.org (maxgerhardson) | Live (v1.1.0) — binary wrapper planned for v1.2.0 |
| **GitHub Releases** | [github.com/maxgerhardson/sentrik/releases](https://github.com/maxgerhardson/sentrik/releases) | GitHub (maxgerhardson) | Live (v1.1.0) — Linux, macOS, Windows binaries |
| **Docker Hub** | `docker run maxgerhardson/sentrik` | hub.docker.com (maxgerhardson) | Live |
| **GHCR** | `ghcr.io/maxgerhardson/ai_sdlc_guard` | GitHub Packages | Live |
| **VS Code Marketplace** | Search "Sentrik" / [marketplace.visualstudio.com](https://marketplace.visualstudio.com) | Publisher: `sentrik` | Live (v0.2.1) |
| **GitHub Actions Marketplace** | `maxgerhardson/sentrik-community@v1` | GitHub (maxgerhardson) | Live (v1.0.0) |
| **MCP Registry (Official)** | [registry.modelcontextprotocol.io](https://registry.modelcontextprotocol.io) | GitHub OAuth | Live (v1.2.0) |
| **mcp.so** | [mcp.so](https://mcp.so) | GitHub issue submission | Submitted, pending review |
| **Cline MCP Marketplace** | [cline/mcp-marketplace#1305](https://github.com/cline/mcp-marketplace/issues/1305) | GitHub issue submission | Submitted, pending review |
| **Claude Desktop / Anthropic** | [Google Form](https://forms.gle/tyiAZvch1kDADKoP9) | N/A | Not yet submitted |
| **PulseMCP** | [pulsemcp.com/use-cases/submit](https://www.pulsemcp.com/use-cases/submit) | N/A | Not yet submitted |

## GitHub Repositories

| Repo | URL | Visibility | Purpose |
|------|-----|------------|---------|
| **sentrik** (main) | [github.com/maxgerhardson/sentrik](https://github.com/maxgerhardson/sentrik) | Private | Source code, CI/CD, releases |
| **sentrik-community** | [github.com/maxgerhardson/sentrik-community](https://github.com/maxgerhardson/sentrik-community) | Public | Community hub, issues, discussions, GitHub Action |
| **sentra-website** | [github.com/maxgerhardson/sentra-website](https://github.com/maxgerhardson/sentra-website) | Private | Website source (Astro) |
| **sentrik-docs** | [github.com/maxgerhardson/sentrik-docs](https://github.com/maxgerhardson/sentrik-docs) | Public | Documentation (MkDocs Material) |
| **sentrik-demo-medapi** | [github.com/maxgerhardson/sentrik-demo-medapi](https://github.com/maxgerhardson/sentrik-demo-medapi) | Public | Demo project for healthcare use case |

## Infrastructure & Hosting

| Service | URL | Provider | Purpose | Billing |
|---------|-----|----------|---------|---------|
| **Website** | [sentrik.dev](https://sentrik.dev) | Netlify | Marketing site ("coming soon" page) | Free tier |
| **Documentation** | [docs.sentrik.dev](https://docs.sentrik.dev) | GitHub Pages | MkDocs Material docs | Free |
| **License Server** | [sentrik-portal.fly.dev](https://sentrik-portal.fly.dev) | Fly.io | FastAPI license validation API | Paid (credit card added) |
| **Domain** | sentrik.dev | GoDaddy | Primary domain + subdomains | Paid |

## DNS Records (GoDaddy)

| Type | Name | Value | Purpose |
|------|------|-------|---------|
| A/CNAME | `@` (sentrik.dev) | Netlify | Website |
| CNAME | `docs` | maxgerhardson.github.io | Documentation |
| CNAME | `portal` | sentrik-portal.fly.dev | License server (if configured) |

## Third-Party Accounts

| Service | Account | Purpose |
|---------|---------|---------|
| **GitHub** | maxgerhardson | Source code, releases, Actions, Pages |
| **npm** | maxgerhardson | npm package publishing |
| **PyPI** | maxgerhardson | PyPI package publishing |
| **Docker Hub** | maxgerhardson | Docker image publishing |
| **Netlify** | (linked to GitHub) | Website hosting |
| **Fly.io** | (email login) | License server hosting |
| **GoDaddy** | (email login) | Domain registrar |
| **Stripe** | (email login) | Payment processing (test mode) |
| **VS Code Marketplace** | Publisher: `sentrik` | Extension publishing |
| **MCP Registry** | GitHub OAuth | MCP server listing |

## Stripe Integration

| Item | Detail |
|------|--------|
| **Mode** | Test (keys start with `sk_test_`, `whsec_`) |
| **Products** | Team ($29/mo), Organization ($99/mo) |
| **To go live** | Create live-mode products + payment links, swap URLs in pricing.astro, update Fly.io secrets |

## CI/CD Pipelines

| Workflow | File | Triggers | What it does |
|----------|------|----------|--------------|
| **Sentrik Gate** | `.github/workflows/guard-gate.yml` | Push to main, PRs | Tests, scan, gate, SARIF upload |
| **Release** | `.github/workflows/release.yml` | `v*` tags | Build binaries (4 platforms), publish to PyPI/npm/Docker, create GitHub Release, package VSIX |
