# Tech Stack & Architecture

This document describes the technologies, components, and high-level architecture of the SENTRA platform.

## Tech Stack Summary

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Core Language** | Python 3.11–3.13 | All backend logic |
| **CLI Framework** | Typer + Rich | Command-line interface with formatted output |
| **Data Validation** | Pydantic 2.0+ | Config models, request/response validation |
| **Config Format** | PyYAML 6.0+ | YAML config parsing |
| **Web API** | FastAPI + Uvicorn | REST server and dashboard host |
| **Authentication** | authlib, python-jose | JWT validation, OAuth 2.0 / OIDC |
| **DevOps SDKs** | azure-devops, requests | Azure DevOps, GitHub, Jira integrations |
| **LLM Integration** | requests (Anthropic API) | AI-powered scanning and requirement generation |
| **Dashboard** | Vanilla HTML/CSS/JS | Web UI (embedded in server, no framework) |
| **VS Code Extension** | TypeScript, VS Code API | Editor integration |
| **npm Distribution** | Node.js | Cross-platform binary installer |
| **Testing** | pytest, pytest-cov | 1500+ tests, 90%+ coverage |
| **Documentation** | MkDocs Material | Static documentation site |
| **CI/CD** | GitHub Actions | Build, test, release automation |
| **Containers** | Docker | Server deployment |
| **Binary Packaging** | PyInstaller | Standalone executables (Linux, macOS, Windows) |

## High-Level Architecture

```
+------------------------------------------------------------------+
|                        USER INTERFACES                           |
|                                                                  |
|  +----------+   +-------------+   +----------+   +----------+   |
|  |   CLI    |   |  VS Code    |   | Dashboard|   | REST API |   |
|  | (Typer)  |   | Extension   |   | (Web UI) |   | (HTTP)   |   |
|  +----+-----+   +------+------+   +----+-----+   +----+-----+   |
|       |                |               |               |         |
+-------|----------------|---------------|---------------|----------+
        |                |               |               |
        v                v               v               v
+------------------------------------------------------------------+
|                      FASTAPI SERVER                              |
|                                                                  |
|  Authentication (JWT / API Key / OIDC)                           |
|  Authorization  (RBAC: admin, security-lead, developer, viewer)  |
|  License Gating (HMAC-based tier enforcement)                    |
|                                                                  |
+-----------------------------+------------------------------------+
                              |
                              v
+------------------------------------------------------------------+
|                    CORE PIPELINE ENGINE                           |
|                                                                  |
|  1. Rules Engine ──> Evaluate rules against source files         |
|  2. External Scanner ──> SARIF / LLM / Composite                |
|  3. ML Severity ──> Optional re-scoring of findings              |
|  4. Traceability ──> Link findings to work items                 |
|  5. Governance ──> Policy checks, approval gates                 |
|  6. Reporters ──> HTML, SARIF, JUnit, CSV output                 |
|                                                                  |
+----------+------------------+------------------+-----------------+
           |                  |                  |
           v                  v                  v
+----------------+  +------------------+  +-------------------+
|  RULES & PACKS |  |    PROVIDERS     |  |    REPORTERS      |
|                |  |                  |  |                   |
| Built-in rules |  | DevOps:          |  | HTML (interactive)|
| AST checks     |  |  Azure DevOps    |  | SARIF 2.1.0       |
| Regex patterns  |  |  GitHub Issues   |  | JUnit XML         |
| File policies  |  |  Jira            |  | CSV               |
|                |  |  Stub (local)    |  |                   |
| Standards Packs|  |                  |  +-------------------+
|  IEC 62304     |  | Scanners:        |
|  OWASP Top 10  |  |  SARIF parser    |
|  SOC2          |  |  LLM (Claude)    |
|  HIPAA         |  |  Composite       |
|  PCI DSS       |  |                  |
|  ISO 27001     |  | LLM:             |
|                |  |  Anthropic       |
| Custom rules   |  |  Stub            |
| (.sentra/rules)|  |                  |
+----------------+  +------------------+
                            |
                            v
              +----------------------------+
              |    EXTERNAL SERVICES       |
              |                            |
              |  Azure DevOps API          |
              |  GitHub API                |
              |  Jira API                  |
              |  Anthropic Claude API      |
              |  HashiCorp Vault (Enterprise)|
              |  License Portal (optional) |
              +----------------------------+
```

## Component Details

### CLI (`cli.py`)

The primary user interface. Built with **Typer** for command parsing and **Rich** for formatted terminal output (tables, panels, progress bars).

Key commands: `scan`, `gate`, `init`, `reconcile`, `generate-reqs`, `serve`, `trial`

The CLI loads config, builds providers via the factory, and delegates to the pipeline engine. Exit code 0 means pass, 1 means gate failure.

### FastAPI Server (`server.py`)

Hosts the REST API and the web dashboard. Serves as the backend for the VS Code extension (future), CI/CD integrations, and the browser-based dashboard.

- **Authentication:** Dual-mode — JWT tokens (via OIDC) or API key (`X-API-Key` header). Anonymous access allowed when auth is disabled.
- **Authorization:** RBAC with 5 roles (admin, security-lead, developer, viewer, agent) and 16 granular permissions. Enforced on all protected endpoints via FastAPI `Depends()`.
- **License gating:** Enterprise features (approvals, vault, custom packs) are gated by license tier. The server checks the HMAC license key on startup.

### Dashboard (embedded in `server.py`)

A single-page web application served at `/dashboard`. Built with vanilla HTML, CSS, and JavaScript — no framework or build step.

Tabs: Overview, Policies, Packs, Rules, DevOps, Work Items, Audit Log, Settings

Communicates with the REST API via `fetch()` calls. Supports light/dark themes via CSS variables.

### Rules Engine (`rules/engine.py`)

Evaluates rules against source files. Supports four rule types:

| Type | Description |
|------|-------------|
| `regex` | Pattern matching (single or composite `all_patterns`) |
| `required_pattern` | Flags files that *lack* a required pattern |
| `file_policy` | Structural checks (docstrings, line count, import restrictions) |
| `ast` | Python AST semantic analysis (complexity, mutable defaults, etc.) |

Features: parallel evaluation via `ThreadPoolExecutor`, content-hash caching for incremental scans, thread-safe cache locking.

### Standards Packs (`packs/`)

Pre-built rule sets for specific compliance frameworks. Each pack is a directory containing a `rules.yaml` file with rule definitions.

| Pack | Rules | Domain |
|------|-------|--------|
| `fda-iec-62304` | 14 | Medical device software |
| `owasp-top-10` | 22 | Web application security |
| `soc2` | 16 | Trust services criteria |
| `hipaa` | 15 | Healthcare data protection |
| `pci-dss` | 16 | Payment card security |
| `iso-27001` | 14 | Information security management |

Custom packs can be authored, imported, and exported via CLI or dashboard.

### Providers (`providers/`)

Pluggable integrations using the **Strategy** pattern. The factory (`providers/factory.py`) builds the right provider based on config:

- **DevOps providers** — Create, update, and close work items; fetch existing items; comment on PRs; set commit status. Implementations: Azure DevOps, GitHub Issues, Jira, Stub (local JSON file).
- **Scanner providers** — External code analysis. Implementations: SARIF file parser, LLM-based scanner (Claude), Composite (combine multiple).
- **Standards providers** — Fetch rule definitions from external sources. Implementations: Azure repo, GitHub repo, Jira issue, Stub (local YAML).
- **LLM providers** — AI-powered analysis. Implementations: Anthropic Claude, Stub.

### Pipeline (`core/pipeline.py`)

Orchestrates the full scan-and-gate workflow:

```
Load Config
    |
    v
Build Providers (factory)
    |
    v
Rules Engine Evaluation ──> List[Finding]
    |
    v
External Scanner ──> Merge additional findings
    |
    v
ML Severity Estimation (optional) ──> Re-score severities
    |
    v
Traceability Linking ──> Map findings to work items
    |
    v
Governance Checks ──> Gate pass/fail decision
    |
    v
Report Generation ──> HTML, SARIF, JUnit, CSV
    |
    v
Output Writing ──> out/ directory
    |
    v
PR Decoration + Status Checks (CI only)
    |
    v
Metrics Archival ──> Trends data
```

### Authentication & Authorization

**Auth modules** (`auth/`): JWT token validation, OIDC discovery and session management, OAuth 2.0 Device Flow for CLI login.

**RBAC modules** (`authz/`): `LocalPolicyEngine` performs pure-Python set lookups against a role-permission matrix. No external authorization service required (OpenFGA client exists as a stub for future integration).

### License System (`core/licensing.py`)

Offline-first HMAC-based licensing. License keys encode the tier and expiry date, signed with a shared secret. No network call needed for validation.

Tiers: **Trial** (30-day, all features), **Team**, **Org** (adds parallel, ML, vault), **Enterprise** (adds governance, approvals, custom packs).

Optional online check against a license portal for revocation enforcement.

### Token Vault (`vault/`)

Manages DevOps credentials (PATs, tokens). Default provider reads from environment variables. HashiCorp Vault provider available for Enterprise (address, mount, namespace, token auth).

### Async Approvals (`core/approvals.py`)

Enterprise feature. When a gate fails, an approval request can be created instead of immediately failing. A security lead reviews and approves/rejects the request. The gate result is held pending until reviewed or timed out.

## Data Flow: CI/CD Gate Check

A typical CI/CD integration runs `sentra gate` on every PR:

```
PR Opened / Push
    |
    v
CI Runner: sentra gate --git-range origin/main...HEAD
    |
    v
Config loaded from .sentra/config.yaml
    |
    v
Changed files extracted from git range
    |
    v
Rules + packs evaluated on changed files only
    |
    v
Findings counted by severity
    |
    v
Gate decision: pass (exit 0) or fail (exit 1)
    |
    +──> PR Comment posted (GitHub/Azure)
    +──> Commit status set (GitHub Checks / Azure)
    +──> SARIF uploaded to GitHub Code Scanning
    +──> Reports saved as CI artifacts
```

## Storage

SENTRA uses a **file-based architecture** with no traditional database:

| Data | Format | Location |
|------|--------|----------|
| Configuration | YAML | `.sentra/config.yaml` or `.guard.yaml` |
| Scan findings | JSON | `out/findings.json` |
| Reports | HTML, SARIF, JUnit, CSV | `out/` directory |
| Gate results | JSON | `out/gate_result.json` |
| Scan metrics | JSON | `out/scan_metrics.json` |
| Work items (local) | JSON | `work_items.json` |
| Audit log | JSONL | `out/agent_audit.jsonl` |
| Scan cache | File hashes | `.guard_cache/` |
| Custom rules | YAML | `.sentra/rules/` |

## Distribution Channels

| Channel | Package | Command |
|---------|---------|---------|
| **PyPI** | `sentra` | `pip install sentra` |
| **npm** | `sentra` | `npm install -g sentra` |
| **Docker Hub** | `maxgerhardson/sentra` | `docker pull maxgerhardson/sentra` |
| **GitHub Releases** | Standalone binaries | Download for Linux/macOS/Windows |
| **VS Code Marketplace** | SENTRA extension | Install from Extensions view |

## Project Structure

```
ai_sdlc_guard/
├── src/guard/                # Main Python package
│   ├── cli.py               # Typer CLI (50+ commands)
│   ├── config.py            # Pydantic config model
│   ├── server.py            # FastAPI server + dashboard
│   ├── core/                # Pipeline, models, governance, licensing
│   ├── rules/               # Rules engine + AST checks
│   ├── packs/               # Standards packs (IEC 62304, OWASP, etc.)
│   ├── providers/           # DevOps, scanner, LLM, standards plugins
│   ├── reporters/           # Output format renderers
│   ├── auth/                # JWT, OIDC, device flow
│   ├── authz/               # RBAC policy engine
│   ├── vault/               # Secret management
│   └── ml/                  # Heuristic severity rescorer (no actual ML)
├── tests/                    # 49 modules, 1500+ tests
├── docs/                     # MkDocs documentation
├── vscode-extension/         # TypeScript VS Code extension
├── npm-package/              # npm binary installer
├── .github/workflows/        # CI/CD (release, gate, docs)
├── Dockerfile                # Production container
├── docker-compose.yml        # Local deployment
├── pyproject.toml            # Package metadata + dependencies
└── mkdocs.yml                # Documentation site config
```
