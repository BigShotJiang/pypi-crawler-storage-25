# Medical Device Software (IEC 62304)

sentrik enforces IEC 62304 and 21 CFR Part 11 compliance for teams building medical device software with AI coding tools.

## The Challenge

Medical device software teams face a difficult intersection:

- **AI coding agents** (Copilot, Cursor, Claude Code) accelerate development but introduce untraced, unreviewed code
- **IEC 62304** requires full traceability from requirements → design → code → tests → verification
- **FDA 21 CFR Part 11** demands audit trails, electronic signatures, and data integrity controls
- **Manual compliance** slows teams to a crawl — reviewing every AI suggestion against regulatory requirements

sentrik automates this enforcement in your CI/CD pipeline, so your team moves fast without breaking compliance.

## How sentrik Helps

### 1. Requirements Traceability

Every code change must trace back to a documented requirement. sentrik scans your codebase and cross-references against your work item tracker (Azure DevOps, GitHub Issues, Jira).

```bash
# Scan and check traceability
sentrik scan

# Reconcile findings with work items
sentrik reconcile --dry-run
```

Untraced code is flagged automatically. The reconciler creates work items for gaps and closes items when requirements are met.

### 2. IEC 62304 Standards Pack

Enable the built-in `fda-iec-62304` pack to enforce 14 regulatory rules:

```yaml
# .guard.yaml
standards_packs:
  - fda-iec-62304
```

| Rule | What It Checks |
|------|---------------|
| `iec62304-req-trace` | Every module traces to a requirement |
| `iec62304-unit-test` | Test coverage exists for each module |
| `iec62304-risk-class` | Risk classification is documented |
| `iec62304-change-control` | Changes follow change control process |
| `iec62304-soup-list` | Third-party software (SOUP) is documented |
| `iec62304-module-docstring` | All modules have docstrings |
| `iec62304-no-hardcoded-secrets` | No credentials in source |
| `iec62304-input-validation` | User inputs are validated |
| `iec62304-error-handling` | Exceptions are properly handled |
| `iec62304-no-deprecated-api` | Deprecated APIs are flagged |
| `iec62304-max-complexity` | Cyclomatic complexity limits |
| `iec62304-no-dynamic-exec` | No `eval()` or `exec()` calls |
| `iec62304-data-integrity` | Data processing follows integrity rules |
| `iec62304-audit-logging` | Security events are logged |

### 3. Governance Gates in CI/CD

Block non-compliant PRs from merging:

```yaml
# .github/workflows/sentrik-gate.yml
- name: sentrik Gate
  run: sentrik gate --git-range "origin/main...HEAD" --decorate-pr --status-check
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

The gate fails with exit code 1 if critical or high findings exist. PR comments show exactly what failed and why.

### 4. Audit Trail

Every scan, gate decision, and remediation is logged:

```bash
sentrik scan    # → out/agent_audit.jsonl
```

The audit log captures:
- Who triggered the scan (human or AI agent)
- What was scanned and when
- Which rules fired and why
- Gate pass/fail decisions with justification

This log maps directly to FDA 21 CFR Part 11 audit trail requirements.

## Example Workflow

```
1. Product owner creates requirement REQ-042 in Azure DevOps
   "Implement patient data anonymization per HIPAA Safe Harbor"

2. Developer (or AI agent) writes src/anonymize.py

3. CI runs: sentrik gate --decorate-pr --status-check
   → FAIL: iec62304-no-hardcoded-secrets (hardcoded key in line 15)
   → FAIL: iec62304-input-validation (no input validation on patient_id)
   → PASS: iec62304-req-trace (REQ-042 linked via work_items.json)

4. Developer fixes findings, pushes again
   → PASS: All 14 IEC 62304 rules pass
   → PR merges

5. Weekly: sentrik reconcile
   → Updates Azure DevOps work items with coverage status
   → Closes REQ-042 as verified
```

## Governance Profiles

Choose the right level of strictness for your software safety class:

| Profile | Best For | Gate Behavior |
|---------|----------|---------------|
| **Strict** | Class C (life-sustaining) | Human review required for all changes, no auto-patch |
| **Standard** | Class B (non-life-sustaining) | Human review for critical/high, auto-patch for low |
| **Permissive** | Class A (no injury risk) | Maximum automation, human review for critical only |

```yaml
governance:
  profile: strict
  human_review_required:
    on_requirement_change: true
    on_critical_finding: true
```

## Getting Started

```bash
# Install
pip install sentrik

# Initialize with medical device preset
sentrik init
# Select: Medical device (IEC 62304)
# Select: Strict governance

# Run your first scan
sentrik scan

# View the dashboard
sentrik dashboard
# Open http://localhost:8000/dashboard
```

See the [Medical Device Walkthrough](../tutorials/medical-device-walkthrough.md) for a complete end-to-end tutorial.
