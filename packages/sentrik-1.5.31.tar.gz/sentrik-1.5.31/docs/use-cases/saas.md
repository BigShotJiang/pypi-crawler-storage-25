# SaaS Teams Using AI Coding Agents

sentrik governs AI-generated code in CI/CD pipelines, ensuring quality and security standards are met before code ships.

## The Challenge

SaaS engineering teams are adopting AI coding tools rapidly:

- **GitHub Copilot, Cursor, Claude Code** generate 30-60% of new code in many teams
- **Code review bottlenecks** increase as AI-generated PRs flood the queue
- **Quality variance** — AI output ranges from excellent to subtly broken
- **No traceability** — generated code isn't linked to requirements or tickets
- **Security blind spots** — AI agents don't know your security policies

sentrik acts as an automated reviewer that enforces your standards on every commit, whether written by a human or an AI agent.

## How sentrik Helps

### 1. Automated Code Governance

sentrik sits in your CI/CD pipeline and checks every PR:

```
Developer / AI Agent → git push → CI Pipeline → sentrik Gate → Merge
                                                    ↓
                                              Pass or Block
```

No manual review needed for standard checks. Your team reviews architecture and logic; sentrik handles compliance and quality.

### 2. Custom Rules for Your Codebase

Define rules that match your team's conventions:

```yaml
# standards.yaml
rules:
  - id: no-print-statements
    description: "Use logging module instead of print()"
    type: regex
    pattern: "\\bprint\\s*\\("
    severity: medium
    exclude_patterns: ["tests/", "scripts/"]

  - id: require-type-hints
    description: "All public functions must have type hints"
    type: file_policy
    check: must_contain_pattern
    params:
      pattern: "def \\w+\\(.*:.*\\).*->"
    severity: low

  - id: max-function-complexity
    description: "Functions must not exceed complexity 10"
    type: ast
    check: high_complexity
    params:
      max_complexity: 10
    severity: high
```

### 3. Standards Packs

Start with pre-built rule sets and customize from there:

```yaml
# .guard.yaml
standards_packs:
  - owasp-top-10       # 22 security rules

# Override specific rules
pack_overrides:
  owasp-top-10:
    owasp-a03-sql-injection:
      severity: critical    # Upgrade from high
    owasp-a05-debug-mode:
      enabled: false        # Not relevant for API-only service
```

### 4. Work Item Traceability

Link code to tickets automatically. sentrik integrates with:

- **GitHub Issues** — link findings to issues, auto-create issues for gaps
- **Azure DevOps** — work item sync, iteration-scoped queries
- **Jira** — JQL-based work item fetching, bi-directional sync

```bash
# Reconcile findings with your tracker
sentra reconcile --dry-run    # Preview what would change
sentra reconcile              # Create/update/close work items
```

### 5. Dashboard for Visibility

The built-in management console gives your team real-time visibility:

```bash
sentra serve
# Open http://localhost:8000/dashboard
```

Dashboard features:
- **Overview** — scan metrics, severity distribution, top files by findings
- **Rules** — searchable rule browser with pack membership
- **Work Items** — traceability status, sync controls
- **Audit Log** — who scanned what, when, and what happened
- **Trends** — findings over time, showing improvement

### 6. Pre-commit Hook

Catch issues before they reach CI:

```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: sentra-scan
        name: sentrik Scan
        entry: sentra scan --staged
        language: system
        pass_filenames: false
```

Developers get instant feedback on AI-generated code before pushing.

## CI/CD Integration Examples

### GitHub Actions

```yaml
name: sentrik Gate
on: [pull_request]
jobs:
  gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - run: npm install -g sentra
      - run: sentra gate --git-range "origin/main...HEAD" --decorate-pr --status-check
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      - uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: out/report.sarif
        if: always()
```

### Azure Pipelines

```yaml
trigger:
  branches:
    include: [main]
pr:
  branches:
    include: [main]

steps:
  - script: npm install -g sentra
  - script: >
      sentra gate
      --git-range "origin/main...HEAD"
      --decorate-pr
      --status-check
    env:
      AZURE_DEVOPS_PAT: $(AZURE_DEVOPS_PAT)
```

## Parallel Scanning for Large Codebases

For repositories with hundreds of files, enable parallel scanning:

```yaml
# .guard.yaml
parallel_scan: true
max_workers: 8
```

sentrik distributes file evaluation across threads, with thread-safe caching. Scan metrics (`out/scan_metrics.json`) report cache hit rates and per-phase timing.

## Enterprise Features

Unlock advanced capabilities with a license key:

| Feature | Team | Org | Enterprise |
|---------|------|-----|-----------|
| Parallel scanning | Yes | Yes | Yes |
| Severity rescoring | Yes | Yes | Yes |
| Token vault | — | Yes | Yes |
| Governance profiles | — | Yes | Yes |
| Async approval gates | — | — | Yes |
| Audit logging | — | — | Yes |
| SSO/OIDC | — | — | Yes |

```bash
# Try enterprise features free for 30 days
sentra trial
```

## Getting Started

```bash
# Install
npm install -g sentra

# Initialize (interactive wizard)
sentra init

# Scan your codebase
sentra scan

# Add to CI/CD
sentra gate --git-range "origin/main...HEAD"

# View dashboard
sentra serve
```

See the [Quickstart Guide](../getting-started/quickstart.md) for a 5-minute tutorial.
