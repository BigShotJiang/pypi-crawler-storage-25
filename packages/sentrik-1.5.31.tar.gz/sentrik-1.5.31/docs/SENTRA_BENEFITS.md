# SENTRIK — Governance for AI-Generated Code

**The runtime that enforces coding standards, traces work items, and gates pull requests for teams using AI coding agents.**

Deterministic-first analysis with automatic remediation — purpose-built for medical device software, fintech, and security-critical systems.

---

## The Problem

AI coding agents are transforming software development. Teams ship faster than ever — but speed without guardrails creates risk:

- **Compliance gaps** — AI-generated code bypasses the review practices that satisfy FDA, OWASP, and SOC2 auditors
- **Untraceable changes** — Code appears in pull requests with no link to approved requirements or work items
- **Inconsistent quality** — What one reviewer catches, another misses. Manual review doesn't scale to AI-agent velocity
- **Credential exposure** — AI agents need DevOps tokens to operate, but storing them safely across tools is an afterthought
- **No approval workflow** — Critical findings slip through because there's no structured way to escalate, review, and approve

## The Solution

SENTRIK scans every commit, enforces quality gates, and traces code back to business requirements — automatically. It runs in your CI/CD pipeline, in Docker, or as a local CLI, giving your team deterministic, repeatable governance without slowing down delivery.

---

## What You Get in Phase 3

Phase 3 delivers the complete enterprise platform. Everything below is production-ready.

### Deterministic Scanning — Every Commit, Every Time

Five rule types cover structural, semantic, and compliance checks:

| Rule Type | What It Catches |
|-----------|----------------|
| **Regex** | Pattern violations in file contents (hardcoded secrets, banned imports, unsafe calls) |
| **Required Pattern** | Missing patterns files *must* contain (license headers, copyright notices) |
| **File Policy** | Structural issues (missing docstrings, excessive file length, import violations, function count) |
| **AST** | Python semantic analysis (cyclomatic complexity, mutable defaults, nested functions, global variables) |
| **Documentation Obligation** | Non-code compliance items surfaced in reports (never fail the gate) |

Results are deterministic — same code, same rules, same findings. No flaky results. No AI hallucinations in the scan itself.

### Built-In Compliance Packs

Three standards packs ship out of the box:

- **FDA IEC 62304** — Medical device software lifecycle rules (14 rules mapping to IEC 62304 / 21 CFR Part 11 clauses)
- **OWASP Top 10** — Web application security (22 rules covering the 2021 OWASP Top 10)
- **SOC2** — Trust Services Criteria for security, availability, and confidentiality (16 rules)

Each pack is customizable per-rule — override severity or patterns without forking the pack definition. Build your own packs from scratch or import/export as YAML.

### Quality Gates That Block Bad Merges

The gate command returns a deterministic pass/fail (exit code 0 or 1) based on configurable severity thresholds. Wire it into any CI/CD pipeline:

```yaml
# GitHub Actions
- run: sentrik gate --decorate-pr --status-check

# Azure Pipelines
- script: sentrik gate --decorate-pr --status-check --commit-sha $(Build.SourceVersion)
```

Gate results post directly to your pull request as a comment (findings table, severity summary, pass/fail badge) and as a commit status check that blocks the merge button.

### Full DevOps Traceability

SENTRIK connects to **Azure DevOps**, **GitHub**, and **Jira** — all as first-class integrations:

- **Work item extraction** — Automatically links findings to work items by parsing branch names (`feature/WI-101-add-auth` maps to `WI-101`)
- **Reconciliation** — Syncs findings back as work items: creates new issues for untracked findings, updates existing ones, closes resolved ones
- **Dry-run preview** — See exactly what will be created, updated, or closed before committing changes
- **PR decoration** — Findings summary posted as a PR comment on GitHub and Azure DevOps
- **Status checks** — GitHub Check Runs and Azure commit statuses gate the merge

### Auto-Remediation

Rules can specify fix strategies (remove line, comment out, replace). SENTRIK generates patches during scan — never auto-applies them:

1. `sentrik scan` produces patches in `out/patches/`
2. Developer reviews patches
3. `sentrik apply-patches` applies approved fixes

### Auto-Generated Requirements

Identify source files not covered by any requirement, then generate structured requirements automatically:

- LLM-powered analysis produces title, description, and acceptance criteria
- Stub fallback works without an LLM connection
- Merge-aware YAML writer preserves approved/rejected entries
- Push generated requirements directly to Azure DevOps, GitHub, or Jira as work items
- Available via CLI (`sentrik generate-reqs`), API, and dashboard

---

## Enterprise Capabilities (Phase 3)

### Role-Based Access Control

Five roles enforce least-privilege access across all 33 protected API endpoints:

| Role | Access |
|------|--------|
| **Admin** | Full system access |
| **Security Lead** | Scan, gate, reconcile, findings, audit, packs, approval review |
| **Developer** | Scan, gate, read findings and packs |
| **Viewer** | Read-only access to findings, audit logs, packs |
| **Agent** | Scan and gate with repo-scoped access (for CI/CD service accounts) |

The `agent` role supports repo-scoped access — restrict a service account to scan only specific repositories. Authorization is enforced by a pure-Python policy engine with no external dependencies.

### Token Vault

Securely manage DevOps credentials without storing them in configuration files:

- **Environment variable provider** (default) — Maps provider names to standard env vars (`AZURE_DEVOPS_PAT`, `GITHUB_TOKEN`, `JIRA_TOKEN`)
- **HashiCorp Vault provider** — Retrieve secrets from Vault with configurable address, mount, namespace, and token TTL
- **Pluggable architecture** — Implement the `SecretProvider` protocol to integrate any secrets backend

Tokens are never written to `.guard.yaml`. The vault is opt-in and available on Org and Enterprise tiers.

### Async Approval Gates

When a gate fails on critical findings, SENTRIK can require explicit approval before proceeding:

1. Gate fails and creates an **approval request** with findings summary
2. Request appears in the dashboard Approvals tab and via API
3. Security lead **approves** or **rejects** with an optional comment
4. Request expires after a configurable TTL (default: 1 hour)

Available via:
- **CLI:** `sentrik gate --require-approval` / `sentrik approve <id>` / `sentrik approval-status <id>`
- **API:** Full CRUD on `/api/approvals`
- **Dashboard:** Approve/reject with one click

Async approval is an Enterprise-tier feature, disabled by default.

### Governance Profiles

Three built-in profiles control the balance between oversight and velocity:

| Profile | Behavior |
|---------|----------|
| **Strict** | Human review for all changes, tightest gates |
| **Standard** | Human review for critical findings (default) |
| **Permissive** | Maximum agent autonomy, minimal friction |

Toggle individual gates: human review on requirement change, human review on critical finding, auto-patch, block merge on unresolved obligations, require sync sign-off.

### Audit Trail

Every action is logged: scans, gate results, configuration changes, reconciliation, approvals. The audit log captures:

- Timestamp, user, action type, result (passed/blocked/updated)
- Governance profile in effect
- Gate pass/fail details with critical finding counts
- Auto-patch and remediation status

Filter by action type or result in the dashboard Audit tab.

---

## Performance at Scale

### Parallel Scanning

Multi-threaded file evaluation using a configurable worker pool (default 4, up to 16 workers). Thread-safe caching prevents redundant rule evaluation. Delivers 2-4x speedup on repositories with 100+ files.

### ML Severity Estimation

Re-scores findings from non-deterministic sources (LLM scanners) using contextual features: base severity, confidence, code context, pattern risk, file risk, and finding density. Deterministic rules (regex, AST, file policy) are never re-scored — their severity is authoritative.

### Scan Metrics

Every scan outputs `scan_metrics.json` with duration, files scanned, cache hit rate, worker count, and findings breakdown. The dashboard trends tab charts these metrics over time.

---

## Management Dashboard

A full-featured web console with 11 tabs, keyboard navigation, dark/light theme, and mobile-responsive layout.

| Tab | Purpose |
|-----|---------|
| Overview | Health cards, severity chart, trends, action buttons |
| Findings | Search, filter, sort, expand details, suppress, export CSV |
| Reports | Generate and download HTML/JUnit/SARIF reports |
| Policies | Governance profile, human review gates, auto-patch controls |
| Packs | Enable/disable packs, create custom, import/export |
| Rules | Browse and search all active rules |
| Work Items | View items, check coverage, generate requirements, reconcile |
| Integration | Configure Azure/GitHub/Jira, test connection |
| Audit | Action timeline with filtering |
| Approvals | View/approve/reject pending gates (Enterprise) |
| Settings | Config viewer, validation |

Global search (`Ctrl+K`), keyboard shortcuts (`1`-`0` for tabs, `S` to scan, `G` to gate), and a help overlay (`?`) are available on every screen.

> See the [Dashboard User Guide](DASHBOARD_GUIDE.md) for detailed documentation of every tab, modal, and feature.

---

## Integration Points

### CI/CD Pipelines
GitHub Actions, Azure Pipelines, or any CI system via the CLI or REST API. Gate commands return exit codes for pass/fail. SARIF output integrates with GitHub Code Scanning.

### DevOps Platforms
Azure DevOps, GitHub Issues, and Jira — read/write work items, post PR comments, create status checks, sync findings as issues.

### Secret Management
Environment variables (zero setup) or HashiCorp Vault (enterprise). Pluggable `SecretProvider` protocol for custom backends.

### IDE
VS Code extension with scan-on-save, in-editor diagnostics, and command palette integration. Pre-commit hooks for git-staged file scanning.

### REST API
75+ endpoints covering scan, gate, findings, rules, packs, config, work items, reconciliation, approvals, trends, suppressions, and requirements generation. OpenAPI-compatible with an API docs landing page at `/api`.

---

## Who Benefits

### Compliance Officers
Deterministic scanning eliminates guesswork. Built-in FDA, OWASP, and SOC2 packs map directly to regulatory clauses. Audit trails log every governance decision. Work item traceability proves code-to-requirement linkage. Per-framework compliance reports map findings to specific clauses, and the trust center page provides a public-safe compliance posture summary for customers and auditors.

### Engineering Managers
Automated quality gates protect `main` without bottlenecking developers. Dashboard metrics show trend lines. Custom packs codify team-specific standards. Governance profiles let you dial oversight up or down.

### DevOps Engineers
Five-minute setup (Docker + `.guard.yaml`). Multi-platform DevOps support. PR decoration and status checks work out of the box. SARIF export for security dashboards. Pre-commit hooks catch issues before push.

### AI Agent Operators
`sentrik context` generates a structured JSON file that AI agents read to understand project standards, active rules, and open work items. Auto-patching closes the feedback loop — the agent writes code, SENTRIK scans it, patches fix low-severity issues automatically.

---

## Why SENTRIK Over Alternatives

### vs. Manual Code Review

| | Manual Review | SENTRIK |
|-|---------------|--------|
| Speed | Hours per PR | Seconds per commit |
| Consistency | Varies by reviewer | Deterministic — same rules, same results |
| Coverage | Spot checks | Every file, every time |
| Audit proof | Email threads | Structured audit log |
| Scale | Bottleneck at 20+ devs | Unlimited (add CI workers) |

### vs. Generic Linters

| | Linters (ESLint, Pylint) | SENTRIK |
|-|--------------------------|--------|
| Compliance mapping | Style rules only | FDA, OWASP, SOC2 clause references |
| Work item traceability | No | Code to requirement to work item |
| Auto-remediation | Limited | Configurable strategies with review workflow |
| Governance | No | RBAC, approval gates, audit trails |
| DevOps sync | No | Azure, GitHub, Jira reconciliation |

### vs. Commercial Scan Tools

| | Commercial (Snyk, SonarQube) | SENTRIK |
|-|------------------------------|--------|
| AI-code focus | Retrofitted | Purpose-built (severity rescoring, agent context) |
| Setup time | Weeks to months | Minutes (Docker + YAML) |
| On-premise | Expensive add-on | Docker Compose (standard) |
| Multi-platform DevOps | Partial | Azure + GitHub + Jira, all first-class |
| Custom rules | Limited DSL | Full YAML rule builder with 5 rule types |

---

## License Tiers

| Tier | Features | Best For |
|------|----------|----------|
| **Trial** | Scan, gate, reconcile, dashboard, packs, API | Evaluation (30 days) |
| **Team** | Same as Trial | Small teams, basic compliance |
| **Org** | + Parallel scanning, severity rescoring | Mid-size teams, performance-sensitive workloads |
| **Enterprise** | + Governance profiles, audit logging, async approvals | Regulated industries, Fortune 500 |

---

## Getting Started

```bash
# Install
npm install -g sentrik

# Initialize project
sentrik init

# Run your first scan
sentrik scan

# Enforce the gate
sentrik gate

# Start the dashboard
sentrik dashboard
# Open http://localhost:8000/dashboard
```

---

*SENTRIK is built by engineers who ship AI-generated code into regulated environments. Every feature exists because we needed it ourselves.*
