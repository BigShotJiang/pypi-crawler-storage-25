# Sentrik

**Governance runtime for AI-generated code.** Scan, gate, and trace compliance automatically in CI/CD.

## What is Sentrik?

Teams using **Copilot, Cursor, Claude Code**, and AI coding agents generate code fast — but compliance doesn't keep up. Sentrik enforces standards **automatically** across 22 regulatory frameworks:

- **IEC 62304** for medical device software (FDA/EU MDR)
- **OWASP Top 10** for web application security
- **SOC2, HIPAA, PCI DSS** for healthcare and fintech
- **DO-178C, ISO 26262, MISRA C** for aviation, automotive, and embedded
- **Custom rule packs** for your own standards

## Install

=== "pip (PyPI)"

    ```bash
    pip install sentrik
    ```

=== "npm"

    ```bash
    npm install -g sentrik
    ```

## 30-second quickstart

```bash
# Scan — no config needed, auto-detects your project
sentrik scan

# Block non-compliant code in CI
sentrik gate

# Generate signed compliance attestation
sentrik attest
```

No config files, no wizard. Sentrik auto-detects your project and applies sensible defaults.

## Key features

| Feature | Description |
|---------|-------------|
| **Zero Config** | Auto-detects project, applies sensible defaults — just scan |
| **Rules Engine** | 526 rules — regex, AST, and file-policy with auto-fix |
| **Standards Packs** | 22 pre-built packs across medical, finance, healthcare, aviation, automotive, defense, AI governance, data privacy |
| **CI/CD Gate** | Block non-compliant PRs in GitHub Actions, Azure Pipelines, or GitLab CI |
| **PR Decoration** | Compliance summary + findings as PR comments on GitHub and Azure DevOps |
| **Work Item Traceability** | Link findings to Azure DevOps, GitHub Issues, or Jira |
| **Requirement Drift** | Detect when code diverges from requirements, auto-create work items |
| **AI Agent Integration** | MCP server for Claude Code, Cursor, VS Code — compliance during code generation |
| **Design Decision Review** | LLM-powered architecture review with acknowledgement workflow |
| **Code Intelligence** | Quality scoring, project profiling, developer expertise tracking |
| **Supply Chain** | SBOM, CVE scanning, license compliance, secrets detection |
| **Management Dashboard** | 21-tab web UI with AI-powered fix suggestions and compliance evidence map |
| **REST API** | 45+ endpoints for remote scanning and integration |
| **Signed Attestations** | HMAC-SHA256 cryptographic compliance attestations |
| **Reports** | HTML, JUnit XML, SARIF, CSV, CycloneDX SBOM |

## Next steps

- [Installation](getting-started/installation.md)
- [Quickstart tutorial](getting-started/quickstart.md) — under 5 minutes
- [Configuration](getting-started/configuration.md) — `.sentrik/config.yaml` reference
- [CLI Reference](guides/cli-reference.md) — 50+ commands
- [Standards Packs](standards-packs/overview.md) — 22 frameworks
- [MCP Integration](guides/mcp-integration.md) — AI agent setup
