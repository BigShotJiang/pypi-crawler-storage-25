# Sentrik — VS Code Extension

Governance runtime for AI-generated code — scans on save, inline findings, zero config.

## Features

- **Zero config** — auto-detects your project, creates `.sentrik/` on first open, scans immediately
- **Scan on save** — automatically runs `sentrik scan` when any file is saved
- **Findings sidebar** — tree view of all findings grouped by severity, click to navigate
- **Inline diagnostics** — findings appear in the editor with severity-appropriate colors
- **Quick fixes** — suppress findings, view docs, or see fix suggestions from the lightbulb menu
- **Quality score** — compliance score (0-100) shown in the status bar after each scan
- **All languages** — works with Python, JavaScript, TypeScript, Go, PHP, Kotlin, C/C++, and more
- **C/C++ analysis** — enable semantic analysis with clang-tidy or cppcheck, plus MISRA C compliance
- **Standards packs sidebar** — view, enable, and disable standards packs from the sidebar
- **Custom packs** — create your own rule packs with YAML templates directly from VS Code
- **Status bar** — shows scan state and finding count inline

## Install Sentrik CLI

The extension requires the Sentrik CLI. **Install the CLI and restart VS Code before installing the extension.**

```bash
# Option 1: npm (downloads platform binary)
npm install -g sentrik

# Option 2: pip (Python source — use this if npm binary is blocked by Smart App Control or antivirus)
pip install sentrik
```

After the install completes, **restart VS Code**, then install the Sentrik extension from the marketplace.

**If using pip**, you may need to set the binary path in VS Code settings so the extension finds the CLI:

1. Open Settings (`Ctrl+,`) → search `sentrik.binaryPath`
2. Set it to your Python Scripts path, e.g.:
   ```
   C:\Users\YourName\AppData\Local\Programs\Python\Python312\Scripts\sentrik.exe
   ```
   To find the exact path, run `pip show sentrik` and replace `Lib\site-packages` with `Scripts\sentrik.exe` in the Location.

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `sentrik.autoInit` | `true` | Auto-initialize `.sentrik/` config on project open |
| `sentrik.autoScan` | `true` | Auto-scan on file save |
| `sentrik.binaryPath` | `""` | Path to sentrik CLI (auto-detected if empty) |
| `sentrik.severityFilter` | `["critical", "high", "medium"]` | Severities shown as diagnostics |
| `sentrik.enableCppAnalysis` | `false` | Enable C/C++ semantic analysis (requires clang-tidy or cppcheck) |
| `sentrik.customPacksPath` | `""` | Custom pack YAML directory (defaults to `.sentrik/rules/`) |

## Commands

| Command | Description |
|---------|-------------|
| `SENTRIK: Run Scan` | Run a full scan and display findings |
| `SENTRIK: Run Gate` | Run gate check with pass/fail notification |
| `SENTRIK: Open Dashboard` | Launch the full compliance dashboard in a standalone window |
| `SENTRIK: Quality Score` | View detailed quality score breakdown |
| `SENTRIK: Manage Packs` | Refresh the standards packs list |
| `SENTRIK: Enable Pack` | Enable a standards pack |
| `SENTRIK: Disable Pack` | Disable a standards pack |
| `SENTRIK: Create Custom Pack` | Scaffold a new custom rule pack YAML |
| `SENTRIK: Clear Diagnostics` | Remove all diagnostics |

## Quick Fixes

Hover over a finding and click the lightbulb (or press `Ctrl+.`) to see:
- **Suppress** — adds a `sentrik-ignore` comment above the line
- **View docs** — opens the rule documentation on docs.sentrik.dev
- **How to fix** — shows the remediation guidance in a detail panel

## Custom Packs

Create your own standards packs to enforce team-specific rules:

1. Run `SENTRIK: Create Custom Pack` from the command palette
2. Enter a name (e.g., `my-team-rules`)
3. Edit the generated YAML template in `.sentrik/rules/`
4. Save — rules are applied on the next scan

Custom packs support regex rules, required patterns, file policies, and C/C++ specific checks. See the generated template for examples.

## C/C++ Support

Enable `sentrik.enableCppAnalysis` in settings for deep C/C++ analysis with clang-tidy or cppcheck. The `misra-c`, `do-178c`, and `iso-26262` standards packs are all included in the free tier.

## Free Tier

The extension works with Sentrik's free tier — 8 standards packs with 224 rules, no license key required:
- OWASP Top 10
- SOC 2
- Python Security
- Go Security
- Supply Chain Security
- MISRA C/C++
- DO-178C (Airborne Systems)
- ISO 26262 (Automotive Safety)

Upgrade to Team or Organization for 22 packs and 526 rules. Visit [sentrik.dev](https://sentrik.dev) for more information.

## Links

- [Documentation](https://docs.sentrik.dev)
- [Community](https://github.com/maxgerhardson/sentrik-community)
- [Report Issues](https://github.com/maxgerhardson/sentrik-community/issues)
