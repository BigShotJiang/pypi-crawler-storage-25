#!/usr/bin/env node
"use strict";

/**
 * postinstall script — downloads the platform-specific Sentrik binary
 * from GitHub Releases.
 */

const fs = require("fs");
const path = require("path");
const https = require("https");
const { execFileSync } = require("child_process");

const pkg = require("./package.json");
// Release tag matches major.minor.0
const parts = pkg.version.split(".");
const RELEASE_VERSION = `${parts[0]}.${parts[1]}.0`;

const PLATFORM_MAP = {
  "linux-x64": { asset: "sentrik-linux-x64", bin: "sentrik" },
  "linux-arm64": { asset: "sentrik-linux-x64", bin: "sentrik" },
  "darwin-x64": { asset: "sentrik-darwin-x64", bin: "sentrik" },
  "darwin-arm64": { asset: "sentrik-darwin-arm64", bin: "sentrik" },
  "win32-x64": { asset: "sentrik-win32-x64.exe", bin: "sentrik.exe" },
};

const key = `${process.platform}-${process.arch}`;
const entry = PLATFORM_MAP[key];

if (!entry) {
  console.error(
    `\n  sentrik: unsupported platform ${process.platform}-${process.arch}\n` +
      `  Supported: ${Object.keys(PLATFORM_MAP).join(", ")}\n`
  );
  process.exit(0);
}

const binDir = path.join(__dirname, "bin");
const binPath = path.join(binDir, entry.bin);
const url = `https://github.com/maxgerhardson/sentrik-community/releases/download/v${RELEASE_VERSION}/${entry.asset}`;

// Skip if binary already exists
if (fs.existsSync(binPath) && fs.statSync(binPath).size > 1000) {
  console.log(`\n  sentrik already installed.\n`);
  process.exit(0);
}

console.log(`\n  sentrik: downloading binary for ${process.platform}-${process.arch}...`);
console.log(`  ${url}\n`);

if (!fs.existsSync(binDir)) {
  fs.mkdirSync(binDir, { recursive: true });
}

// Try curl first (fast, handles redirects), fall back to Node https
let downloaded = false;

try {
  execFileSync("curl", ["-fsSL", "--retry", "3", "-o", binPath, url], {
    stdio: "inherit",
    timeout: 120000,
  });
  downloaded = true;
} catch {
  // curl not available or failed — try Node https
}

if (!downloaded) {
  try {
    if (process.platform === "win32") {
      execFileSync("powershell", [
        "-Command",
        `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ` +
          `Invoke-WebRequest -Uri '${url}' -OutFile '${binPath}' -UseBasicParsing`,
      ], { stdio: "inherit", timeout: 120000 });
      downloaded = true;
    }
  } catch {
    // PowerShell failed too
  }
}

if (!downloaded) {
  // Last resort: Node https with redirect following
  try {
    downloadSync(url, binPath);
    downloaded = true;
  } catch (err) {
    console.error(`\n  sentrik: all download methods failed: ${err.message}`);
  }
}

if (downloaded && fs.existsSync(binPath) && fs.statSync(binPath).size > 1000) {
  if (process.platform !== "win32") {
    fs.chmodSync(binPath, 0o755);
  }
  console.log("  sentrik installed! Get started:");
  console.log("    sentrik scan        Run your first scan");
  console.log("    sentrik init        Set up project config");
  console.log("    Docs: https://docs.sentrik.dev");
  console.log("");
} else {
  // Clean up partial download
  try { fs.unlinkSync(binPath); } catch {}
  console.error(
    `\n  sentrik: download failed.\n\n` +
      `  Download manually from:\n` +
      `  https://github.com/maxgerhardson/sentrik-community/releases/tag/v${RELEASE_VERSION}\n` +
      `  Place the binary in: ${binDir}\n`
  );
}

/**
 * Synchronous download using Node https — follows redirects.
 * Blocks the event loop intentionally so npm waits.
 */
function downloadSync(downloadUrl, dest) {
  const { execSync } = require("child_process");
  // Use a small Node script executed as a child process
  const script = `
    const https = require("https");
    const http = require("http");
    const fs = require("fs");
    function get(url, redirects) {
      if (redirects > 5) { process.exit(1); }
      const mod = url.startsWith("https") ? https : http;
      mod.get(url, { headers: { "User-Agent": "sentrik-npm" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          get(res.headers.location, redirects + 1);
          return;
        }
        if (res.statusCode !== 200) {
          console.error("HTTP " + res.statusCode);
          process.exit(1);
        }
        const file = fs.createWriteStream("${dest.replace(/\\/g, "\\\\")}");
        res.pipe(file);
        file.on("finish", () => { file.close(); process.exit(0); });
      }).on("error", (e) => { console.error(e.message); process.exit(1); });
    }
    get("${downloadUrl}", 0);
  `;
  execSync(`node -e '${script.replace(/'/g, "\\'")}'`, {
    stdio: "inherit",
    timeout: 120000,
  });
}
