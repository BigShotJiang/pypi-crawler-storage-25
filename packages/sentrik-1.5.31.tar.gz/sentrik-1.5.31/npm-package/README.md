# SENTRIK

**Governance runtime for AI-generated code.** Scan, gate, and trace compliance automatically in CI/CD.

```bash
npm install -g sentrik
```

Then open any project and run:

```bash
sentrik scan    # Scan code against standards
sentrik gate    # Enforce quality gate (exit 1 on failure)
```

No configuration needed — SENTRIK auto-detects your project and applies sensible defaults.

## Documentation

- [Website](https://sentrik.dev)
- [Docs](https://docs.sentrik.dev)
- [GitHub](https://github.com/maxgerhardson/sentrik-community)
