#!/usr/bin/env node
"use strict";

/**
 * Thin wrapper that delegates to the platform-specific SENTRIK binary.
 */

const { spawnSync } = require("child_process");
const path = require("path");
const fs = require("fs");

const ext = process.platform === "win32" ? ".exe" : "";
const binPath = path.join(__dirname, "bin", `sentrik${ext}`);

if (!fs.existsSync(binPath)) {
  console.error(
    "SENTRIK: Binary not found. Try reinstalling:\n" +
      "  npm install -g sentrik\n\n" +
      "Or use pip:\n" +
      "  pip install sentrik"
  );
  process.exit(1);
}

const result = spawnSync(binPath, process.argv.slice(2), {
  stdio: "inherit",
  windowsHide: true,
});

process.exit(result.status || 0);
