#!/bin/bash
# ============================================================
# Sentrik Automation Pipeline — Setup Script
# ============================================================
# Run this once to install all dependencies for the pipeline.
# Execute from the repo root: bash automation/scripts/setup.sh
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
AUTOMATION_DIR="$REPO_ROOT/automation"

echo "========================================="
echo "Sentrik Automation Pipeline Setup"
echo "========================================="
echo "Repo root: $REPO_ROOT"
echo ""

# 1. Python dependencies for Telegram bot
echo "[1/5] Installing Telegram bot dependencies..."
pip install python-telegram-bot --break-system-packages 2>/dev/null || \
pip install python-telegram-bot

# 2. Playwright for E2E tests
echo "[2/5] Setting up Playwright E2E tests..."
cd "$AUTOMATION_DIR/e2e"
npm install
npx playwright install chromium
cd "$REPO_ROOT"

# 3. GitHub CLI labels
echo "[3/5] Creating GitHub labels for auto-merge..."
gh label create "auto-merge" --color "0E8A16" --description "Automated PR — merge when checks pass" 2>/dev/null || true
gh label create "feature" --color "1D76DB" --description "New feature" 2>/dev/null || true
gh label create "bug" --color "D73A4A" --description "Bug fix" 2>/dev/null || true
gh label create "security" --color "B60205" --description "Security fix" 2>/dev/null || true
gh label create "docs" --color "0075CA" --description "Documentation" 2>/dev/null || true
gh label create "content" --color "7057FF" --description "Content update" 2>/dev/null || true

# 4. GitHub secrets reminder
echo "[4/5] GitHub secrets check..."
echo ""
echo "  Make sure these secrets are set in your repo settings:"
echo "  • SENTRIK_BOT_TOKEN  — your Telegram bot token"
echo "  • SENTRIK_CHAT_ID    — your Telegram chat ID (8561149678)"
echo ""
echo "  Set them at:"
echo "  https://github.com/maxgerhardson/sentrik/settings/secrets/actions"
echo ""

# 5. Create directories
echo "[5/5] Creating directories..."
mkdir -p "$AUTOMATION_DIR/logs"
mkdir -p "$AUTOMATION_DIR/e2e/screenshots"

echo ""
echo "========================================="
echo "Setup complete!"
echo ""
echo "To start the approval handler:"
echo "  export SENTRIK_BOT_TOKEN='your-bot-token'"
echo "  python automation/telegram/approval_handler.py"
echo ""
echo "To run E2E tests manually:"
echo "  cd automation/e2e && npx playwright test"
echo "========================================="
