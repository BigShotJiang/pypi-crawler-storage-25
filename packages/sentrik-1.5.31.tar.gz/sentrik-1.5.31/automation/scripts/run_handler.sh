#!/bin/bash
# ============================================================
# Start the Sentrik Telegram Approval Handler
# ============================================================
# Runs the approval handler as a persistent process.
# Use with systemd, screen, tmux, or WSL2 background task.
#
# Usage:
#   bash automation/scripts/run_handler.sh
#
# Environment variables (set before running or in .env):
#   SENTRIK_BOT_TOKEN   — Telegram bot token (required)
#   SENTRIK_CHAT_ID     — Telegram chat ID (default: 8561149678)
#   SENTRIK_REPO_PATH   — Repo path (default: C:\Users\mgerh\ai_sdlc_guard)
#   CLAUDE_BIN          — Claude Code binary (default: claude)
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Load .env file if present
ENV_FILE="$REPO_ROOT/automation/.env"
if [ -f "$ENV_FILE" ]; then
    echo "Loading environment from $ENV_FILE"
    set -a
    source "$ENV_FILE"
    set +a
fi

# Validate
if [ -z "${SENTRIK_BOT_TOKEN:-}" ]; then
    echo "ERROR: SENTRIK_BOT_TOKEN is not set."
    echo "Set it in automation/.env or export it before running."
    exit 1
fi

# Set defaults
export SENTRIK_CHAT_ID="${SENTRIK_CHAT_ID:-8561149678}"
export SENTRIK_REPO_PATH="${SENTRIK_REPO_PATH:-$REPO_ROOT}"
export SENTRIK_LOG_DIR="${SENTRIK_LOG_DIR:-$REPO_ROOT/automation/logs}"
export CLAUDE_BIN="${CLAUDE_BIN:-claude}"

echo "Starting Sentrik Approval Handler..."
echo "  Chat ID:  $SENTRIK_CHAT_ID"
echo "  Repo:     $SENTRIK_REPO_PATH"
echo "  Claude:   $CLAUDE_BIN"
echo "  Logs:     $SENTRIK_LOG_DIR"
echo ""

cd "$REPO_ROOT"
exec python automation/telegram/approval_handler.py
