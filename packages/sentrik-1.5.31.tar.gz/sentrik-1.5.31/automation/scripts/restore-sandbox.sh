#!/bin/bash
# ============================================================
# Sentrik NemoClaw Sandbox — Full Restore Script
# ============================================================
# Run this INSIDE the sandbox after nemoclaw onboard completes:
#   nemoclaw sentrik-agent connect
#   bash ~/sentrik-repo/automation/scripts/restore-sandbox.sh
#
# If the repo isn't cloned yet, first run:
#   git clone https://github.com/maxgerhardson/sentrik.git ~/sentrik-repo
# ============================================================

set -euo pipefail

REPO="${HOME}/sentrik-repo"
SKILLS_SRC="${REPO}/automation/nemoclaw-skill"
SKILLS_DST="/sandbox/.openclaw-data/skills"
MEMORY_DST="${HOME}/.openclaw/agents/main/agent/memory"

echo "========================================="
echo "Sentrik Sandbox Restore"
echo "========================================="

# 1. Install all 10 skills
echo "[1/5] Installing skills..."
SKILLS=(
  bug-triage
  customer-support
  docs-manager
  market-research
  sales-business
  security-maintenance
  sentrik-coordinator
  socials-content
  approval-executor
  release-manager
)

for skill in "${SKILLS[@]}"; do
  if [ -f "${SKILLS_SRC}/${skill}/SKILL.md" ]; then
    mkdir -p "${SKILLS_DST}/${skill}"
    cp "${SKILLS_SRC}/${skill}/SKILL.md" "${SKILLS_DST}/${skill}/SKILL.md"
    echo "  ✓ ${skill}"
  else
    echo "  ✗ ${skill} — source not found, skipping"
  fi
done

# 2. Restore memory file
echo "[2/5] Restoring agent memory..."
mkdir -p "${MEMORY_DST}"
cp "${SKILLS_SRC}/memory.md" "${MEMORY_DST}/sentrik.md"
echo "  ✓ Memory restored"

# 3. Reindex memory
echo "[3/5] Reindexing memory..."
openclaw memory index --force 2>/dev/null || echo "  ⚠ Memory reindex skipped (openclaw not ready yet)"

# 4. Create convenience aliases
echo "[4/5] Setting up environment..."
echo 'alias python=python3' >> ~/.bashrc 2>/dev/null || true
echo 'alias jq="python3 -c \"import sys,json; data=json.load(sys.stdin); print(json.dumps(data,indent=2))\""' >> ~/.bashrc 2>/dev/null || true
ln -sf /usr/bin/python3 /sandbox/.local/bin/python 2>/dev/null || true

# 5. Set up directories
echo "[5/5] Creating directories..."
mkdir -p ~/sentrik-intel
mkdir -p ~/sentrik-content

echo ""
echo "========================================="
echo "Restore complete!"
echo ""
echo "Skills installed: ${#SKILLS[@]}"
echo "Memory: restored"
echo ""
echo "Next steps:"
echo "  1. Verify: openclaw skills list"
echo "  2. Set up cron jobs (see below)"
echo "  3. Test on Telegram: send 'approve' to a report"
echo ""
echo "Cron jobs to re-add:"
echo "  - market-research:      daily at 06:00"
echo "  - sentrik-coordinator:  daily at 07:30"
echo "  - bug-triage:           weekly Monday 06:00"
echo "  - security-maintenance: weekly Monday 06:00"
echo "  - socials-content:      weekly Tuesday 09:00"
echo "  - docs-manager:         weekly Wednesday 07:00"
echo "  - sales-business:       weekly Thursday 08:00"
echo "  - customer-support:     every 4 hours (08:00-20:00)"
echo "========================================="
