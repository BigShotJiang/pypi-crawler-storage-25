#!/bin/bash
# ============================================================
# Install the Sentrik Approval Handler as a systemd user service
# ============================================================
# Run this from your WSL2 shell (not inside NemoClaw sandbox):
#   bash /mnt/c/Users/mgerh/ai_sdlc_guard/automation/scripts/install-service.sh
# ============================================================

set -euo pipefail

REPO="/mnt/c/Users/mgerh/ai_sdlc_guard"
SERVICE_NAME="sentrik-approval"
SERVICE_FILE="$REPO/automation/scripts/${SERVICE_NAME}.service"
ENV_FILE="$REPO/automation/.env"

echo "========================================="
echo "Installing Sentrik Approval Handler"
echo "========================================="

# 1. Check prerequisites
echo "[1/6] Checking prerequisites..."
command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 not found"; exit 1; }
command -v claude >/dev/null 2>&1 || { echo "WARNING: claude CLI not on PATH — make sure it's accessible"; }
python3 -c "import telegram" 2>/dev/null || {
    echo "Installing python-telegram-bot..."
    pip3 install python-telegram-bot --break-system-packages 2>/dev/null || pip3 install python-telegram-bot
}

# 2. Set up .env if not present
echo "[2/6] Checking environment config..."
if [ ! -f "$ENV_FILE" ]; then
    cp "$REPO/automation/.env.example" "$ENV_FILE"
    echo ""
    echo "  Created $ENV_FILE from template."
    echo "  EDIT IT NOW with your bot token before continuing:"
    echo "    nano $ENV_FILE"
    echo ""
    read -p "  Press Enter after editing .env, or Ctrl+C to abort..."
fi

# Validate bot token is set
source "$ENV_FILE"
if [ "${SENTRIK_BOT_TOKEN:-}" = "your-bot-token-here" ] || [ -z "${SENTRIK_BOT_TOKEN:-}" ]; then
    echo "ERROR: SENTRIK_BOT_TOKEN is not configured in $ENV_FILE"
    echo "Edit it and re-run this script."
    exit 1
fi

# 3. Create log directory
echo "[3/6] Creating directories..."
mkdir -p "$REPO/automation/logs"
mkdir -p "$REPO/automation/e2e/screenshots"

# 4. Install Playwright (for visual testing)
echo "[4/6] Installing Playwright..."
cd "$REPO/automation/e2e"
if [ ! -d "node_modules" ]; then
    npm install 2>/dev/null || echo "  npm install skipped (install Node.js if you want E2E tests)"
    npx playwright install chromium 2>/dev/null || echo "  Playwright install skipped"
fi
cd "$REPO"

# 5. Install systemd user service
echo "[5/6] Installing systemd service..."
mkdir -p ~/.config/systemd/user/
cp "$SERVICE_FILE" ~/.config/systemd/user/${SERVICE_NAME}.service

# Enable lingering so service runs even when not logged in
sudo loginctl enable-linger "$(whoami)" 2>/dev/null || true

systemctl --user daemon-reload
systemctl --user enable "$SERVICE_NAME"
systemctl --user start "$SERVICE_NAME"

# 6. Verify
echo "[6/6] Verifying..."
sleep 2
if systemctl --user is-active --quiet "$SERVICE_NAME"; then
    echo ""
    echo "========================================="
    echo "Sentrik Approval Handler is RUNNING"
    echo "========================================="
    echo ""
    echo "Commands:"
    echo "  Status:   systemctl --user status sentrik-approval"
    echo "  Logs:     journalctl --user -u sentrik-approval -f"
    echo "  Stop:     systemctl --user stop sentrik-approval"
    echo "  Restart:  systemctl --user restart sentrik-approval"
    echo ""
    echo "The handler is now listening for your Telegram replies."
    echo "Reply to any NemoClaw report with 'approve' to trigger Claude Code."
    echo ""
else
    echo ""
    echo "WARNING: Service failed to start. Check logs:"
    echo "  journalctl --user -u sentrik-approval --no-pager -n 20"
    echo ""
    systemctl --user status "$SERVICE_NAME" --no-pager || true
fi
