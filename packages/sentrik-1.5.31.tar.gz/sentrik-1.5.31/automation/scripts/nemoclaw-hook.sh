#!/bin/bash
# ============================================================
# NemoClaw Post-Connect Hook for Sentrik
# ============================================================
# This script ensures the approval handler is running whenever
# you connect to the sentrik-agent sandbox.
#
# Install by adding to your NemoClaw sandbox config:
#   nemoclaw sentrik-agent config set post_connect_hook \
#     "/mnt/c/Users/mgerh/ai_sdlc_guard/automation/scripts/nemoclaw-hook.sh"
#
# Or add to your shell profile (~/.bashrc or ~/.zshrc):
#   alias sentrik-connect='nemoclaw sentrik-agent connect && bash /mnt/c/Users/mgerh/ai_sdlc_guard/automation/scripts/nemoclaw-hook.sh'
# ============================================================

REPO="/mnt/c/Users/mgerh/ai_sdlc_guard"
SERVICE_NAME="sentrik-approval"

# Check if systemd service is running
if systemctl --user is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "[sentrik] Approval handler already running"
else
    echo "[sentrik] Starting approval handler..."
    systemctl --user start "$SERVICE_NAME" 2>/dev/null || {
        # Fallback: run directly if systemd isn't available (e.g., inside Docker)
        echo "[sentrik] systemd not available, starting handler directly..."
        cd "$REPO"
        nohup bash automation/scripts/run_handler.sh > automation/logs/handler.log 2>&1 &
        echo "[sentrik] Handler started (PID: $!)"
    }
fi

# Quick status check
echo "[sentrik] Telegram approval handler: $(systemctl --user is-active $SERVICE_NAME 2>/dev/null || echo 'running (direct)')"
echo "[sentrik] Reply to NemoClaw reports with 'approve' to trigger Claude Code"
