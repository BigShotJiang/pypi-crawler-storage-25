---
name: customer-support
description: Monitors Sentrik's GitHub Discussions and question-labelled issues, drafts replies for unanswered items older than 4 hours, and queues them for Max approval via Telegram. Use when asked to handle support, draft replies to user questions, or summarise support themes.
---

# Customer Support Skill

## Trigger
Heartbeat: every 4 hours during business hours (08:00-20:00)

## Instructions
1. Check for unanswered GitHub Discussions:
   ```bash
   cd ~/sentrik-repo
   gh api repos/maxgerhardson/sentrik/discussions --jq '.[] | select(.comments == 0 and .answer == null)'
   ```

2. Check for question-labelled issues without a response:
   ```bash
   gh issue list -R maxgerhardson/sentrik --label "question" --state open --json number,title,comments,createdAt
   ```

3. For each unanswered item older than 4 hours:
   - Read the question carefully
   - Research the answer using Sentrik's docs, code, and CLAUDE.md
   - Draft a helpful, accurate reply
   - Include code examples where relevant
   - Link to relevant documentation pages

4. Queue all draft replies for Max approval via Telegram:
   - Show the original question summary
   - Show the drafted reply
   - Ask for approval, edits, or rejection

5. Track support themes:
   - Common questions → potential docs improvements
   - Feature requests → potential issues to open
   - Bugs reported via support → triage

6. Send support summary to Telegram:
   - Items needing response
   - Draft replies ready for review
   - Common themes this week

## Rules
- NEVER post a reply without Max's explicit approval
- Draft replies must be technically accurate — verify against code
- Be friendly, professional, and helpful in tone
- Include links to docs when relevant
- If unsure about an answer, flag it for Max rather than guessing
- Track all support items even if already answered by others
