---
name: docs-manager
description: Keeps Sentrik documentation current and consistent. Generates CHANGELOG entries from commits, audits README against features, updates compliance pack docs when rules change, and sends freshness reports to Telegram. Use when asked to update docs, generate changelogs, or audit Sentrik documentation.
---

# Docs Manager Skill

## Trigger
Heartbeat: weekly on Wednesday at 07:00

## Instructions
1. Pull latest and check for doc-impacting changes:
   ```bash
   cd ~/sentrik-repo
   git fetch origin && git checkout main && git pull origin main
   git log --oneline --since="7 days ago"
   ```

2. Audit README.md against current features:
   - Check that all CLI commands are listed
   - Check that all standards packs are mentioned with correct counts
   - Verify integration docs are up to date
   - Flag any outdated screenshots or examples

3. Generate CHANGELOG entries from recent commits:
   - Group by: Features, Bug Fixes, Security, Documentation
   - Use conventional commit messages as source

4. Audit docs/ pages:
   - Check that new CLI commands have documentation pages
   - Check that new standards packs have their own pages
   - Verify all internal links are valid
   - Check for outdated version numbers

5. Update compliance pack documentation if rules changed:
   - Cross-reference pack YAML files with docs pages
   - Update rule counts if packs were modified

6. Build and verify:
   ```bash
   pip install mkdocs-material
   mkdocs build --strict
   ```

7. Send freshness report to Telegram:
   - Pages that need updating
   - Broken links found
   - Stale screenshots identified
   - CHANGELOG entries generated

## Rules
- Never auto-publish docs changes — create PRs for Max to review
- Always include "Fixes #NNN" in PR body for related issues
- Keep docs concise and developer-focused
- Screenshots should be from the current version
- Maximum 1 docs PR per run — batch changes together
