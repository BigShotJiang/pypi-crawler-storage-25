---
name: sales-business
description: Tracks inbound interest in Sentrik, identifies warm leads from GitHub activity, drafts outreach messages, and maintains a leads log. Use when asked to track leads, draft outreach, or summarise Sentrik's sales pipeline.
---

# Sales & Business Development Skill

## Trigger
Heartbeat: weekly on Thursday at 08:00

## Instructions
1. Monitor GitHub for inbound interest signals:
   ```bash
   cd ~/sentrik-repo
   gh api repos/maxgerhardson/sentrik/stargazers --jq '.[].login' | head -20
   gh issue list -R maxgerhardson/sentrik --label "question" --state open
   ```

2. Check for new stars, forks, and watchers in the past week

3. Identify warm leads:
   - Users who starred AND opened an issue or discussion
   - Users from companies in regulated industries (medical, finance, automotive)
   - Users who asked about enterprise features or pricing

4. For each warm lead:
   - Research their GitHub profile and company
   - Draft a personalized outreach message
   - Add to leads log at ~/sentrik-intel/leads-log.md

5. Review GitHub Discussions for buying signals:
   - Questions about compliance features
   - Enterprise deployment questions
   - Integration requests that suggest production use

6. Send weekly summary to Telegram:
   - New stars/forks count
   - Warm leads identified
   - Outreach drafts ready for review
   - Pipeline summary

## Rules
- All outreach drafts go to Telegram for Max approval before sending
- Never contact anyone directly — always queue for Max
- Keep leads log organized by date and priority
- Focus on regulated industries: medical, finance, automotive, defense
- Do not share any non-public repo information in outreach
