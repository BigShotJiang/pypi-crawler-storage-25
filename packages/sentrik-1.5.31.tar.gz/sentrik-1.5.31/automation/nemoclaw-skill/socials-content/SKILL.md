---
name: socials-content
description: Drafts social media content for Sentrik across LinkedIn, Twitter/X, and blog posts. Creates content calendar, writes posts based on product updates and market trends, and queues all drafts for Max approval via Telegram. Use when asked to create social content, draft posts, or manage Sentrik's content calendar.
---

# Social Media Content Skill

## Trigger
Heartbeat: weekly on Tuesday at 09:00

## Instructions
1. Review recent product updates for content opportunities:
   ```bash
   cd ~/sentrik-repo
   git log --oneline --since="7 days ago"
   ```

2. Review latest market research briefs:
   ```bash
   ls -la ~/sentrik-intel/
   cat ~/sentrik-intel/$(ls -t ~/sentrik-intel/ | head -1)
   ```

3. Draft content for the week:
   - **LinkedIn post** (1-2): Professional, thought-leadership tone. Focus on compliance, AI governance, or industry trends. 1300-1800 characters.
   - **Twitter/X post** (2-3): Concise, engaging. Product updates, tips, or industry commentary. Under 280 characters.
   - **Blog post outline** (0-1): If there's a major feature or trend worth a deep dive.

4. Save drafts to `~/sentrik-content/`:
   - `YYYY-MM-DD-linkedin.md`
   - `YYYY-MM-DD-twitter.md`
   - `YYYY-MM-DD-blog-outline.md` (if applicable)

5. Queue all drafts for Max approval via Telegram:
   - Show each draft
   - Note suggested posting date/time
   - Ask for approval, edits, or rejection

## Rules
- NEVER post anything without Max's explicit approval
- All drafts go to ~/sentrik-content/ and Telegram for review
- Keep tone professional but approachable
- No claims about competitors that can't be verified
- Include relevant hashtags for discoverability
- Focus on value (compliance, security, governance) not hype
- Content should educate, not hard-sell
