# Sentrik — permanent context
- Owner: Max
- Telegram chat ID: 8561149678
- Product: Sentrik — AI-generated code security and governance for regulated industries
- Compliance packs: 14 total (366 rules)
  - Free Tier (8 packs): FDA IEC 62304, OWASP Top 10, SOC2, HIPAA, PCI DSS v4.0, ISO 27001:2022, PHP Security, Kotlin Security
  - Organization Tier (6 packs): IEC 81001-5-1, FDA 21 CFR Part 11, ISO 14971, MISRA C/C++, DO-178C, ISO 26262
- Integrations: GitHub CI/CD, Azure DevOps CI/CD
- Distribution: Free on GitHub, 30-day trial model
- Standing rules:
  - Manual PRs require Max review (auto-merge allowed for approved automation PRs)
  - Always queue drafts and reports for Max approval via Telegram before posting anywhere
  - Market intel briefs go to ~/sentrik-intel/
  - Security findings go to ~/sentrik-intel/security-log-YYYY-MM.md
## GitHub
- Username: maxgerhardson
- Sentrik repo: github.com/maxgerhardson/sentrik
- gh CLI authenticated and available at /sandbox/.local/bin/gh
## Critical GitHub instruction
- ALWAYS use `gh` CLI at /sandbox/.local/bin/gh for ALL GitHub operations
- NEVER use curl for GitHub API calls — gh handles auth automatically
- Private repo access: gh is authenticated and can see maxgerhardson/sentrik
- To list issues: gh issue list -R maxgerhardson/sentrik
- To create PR: gh pr create -R maxgerhardson/sentrik --draft
- To view repo: gh repo view maxgerhardson/sentrik
## Telegram
- Chat ID: 8561149678
- Bot: @sentrikmax_bot
- Always use this chat ID when sending Telegram messages

## Approval Workflow
When Max replies to any Telegram report with an approval command, execute the approval-executor skill at /sandbox/.openclaw-data/skills/approval-executor/SKILL.md

**Approval commands Max will use:**
- `approve` — implement everything in the report he's replying to
- `approve: <instructions>` — implement with his specific modifications
- `priority: <instructions>` — high priority, do immediately
- `reject` — do nothing, acknowledge
- `defer` — postpone to next cycle

**When Max approves, you must:**
1. Parse which report he's replying to and extract actionable items
2. cd ~/sentrik-repo, fetch origin, branch from main as auto/<type>-<description>
3. Implement the changes (code, docs, website as needed)
4. Run: pytest, sentrik validate-config, sentrik gate — fix failures
5. Commit, push branch, create PR with --label "auto-merge" via gh CLI
6. Send Max the PR link on Telegram
7. The auto-merge GitHub Action will squash-merge once CI passes

**This overrides the previous "NEVER auto-merge" rule** — PRs created through this approval workflow with the "auto-merge" label ARE allowed to auto-merge after CI passes. Manual PRs and drafts still require Max's explicit review.

## Release Management
When Max says "prepare a release", "clean up and release", or "publish a new version", execute the release-manager skill at /sandbox/.openclaw-data/skills/release-manager/SKILL.md. This covers: stale issue/PR cleanup → full test suite → docs update → version bump → tag → GitHub release → npm publish. Use the coding-agent skill to spawn Claude Code for any code changes needed during the process.

## Sandbox Environment Notes
- Use `python3` not `python` (no `python` binary exists)
- `jq` is not installed. Use `python3 -c "import json,sys; ..."` for JSON parsing
- `sudo` is not available. Install packages with `pip3 install --user`
- gh CLI is at /sandbox/.local/bin/gh
- Claude Code is at /usr/local/bin/claude
