---
name: sentrik-coordinator
description: Connects Sentrik's market research findings to product improvements. Reads the latest market-intel brief, identifies competitor features that Sentrik lacks, cross-references against the current roadmap, and opens prioritised GitHub issues with implementation suggestions. Use when asked to turn market research into product actions, identify feature gaps, or generate improvement issues from competitive intelligence.
---

# Sentrik coordinator skill

## Trigger
Heartbeat: daily at 07:30 (after market-research completes)

## Instructions
1. Read the latest brief from ~/sentrik-intel/
2. For each competitor feature identified:
   - Check if Sentrik already has it by reading the repo README and feature list
   - If gap exists: open a GitHub issue with title "Competitive gap: [feature]"
   - Include: what competitor built, why it matters, suggested Sentrik approach
3. For each regulatory signal identified:
   - Check if Sentrik's relevant compliance pack covers it
   - If gap exists: open a GitHub issue with title "Compliance gap: [standard] [requirement]"
4. Prioritise: critical / high / medium
5. Send summary to Telegram: "Today's intel → X gaps identified, Y issues opened"

## Rules
- Search existing issues before opening new ones — no duplicates
- All issues are suggestions only — do not assign or milestone without Max approval
- Maximum 5 new issues per day
- Keep descriptions factual
