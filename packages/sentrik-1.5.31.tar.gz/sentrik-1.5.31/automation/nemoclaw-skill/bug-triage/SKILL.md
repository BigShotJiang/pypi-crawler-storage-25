---
name: bug-triage
description: Automated bug triage and security scanning for the Sentrik GitHub repo. Scans the codebase using claude CLI, classifies findings by severity, and opens detailed GitHub issues with full context for developer fix. Use when asked to triage issues, scan the codebase, or manage the Sentrik issue queue.
---

# Bug Triage Skill

## Trigger
Heartbeat: weekly on Monday at 06:00

## Instructions
1. Pull latest from main:
   ```bash
   cd ~/sentrik-repo
   git fetch origin && git checkout main && git pull origin main
   ```

2. Run Sentrik self-scan:
   ```bash
   source .venv/bin/activate
   sentrik scan
   sentrik vulns
   ```

3. Review findings in `out/findings.json`:
   - Classify by severity: critical, high, medium, low
   - Check for new CVEs in dependencies
   - Identify any regressions from recent commits

4. For each critical or high finding:
   - Check if a GitHub issue already exists (search first — no duplicates)
   - If new: open a GitHub issue with:
     - Title: clear description of the bug/vulnerability
     - Body: file, line number, code context, suggested fix, severity
     - Labels: appropriate severity and type labels

5. Run the test suite and report any failures:
   ```bash
   python -m pytest --tb=short -q
   ```

6. Send triage report to Telegram:
   - Number of findings by severity
   - New issues opened
   - Test suite status
   - Any critical items needing immediate attention

## Rules
- Search existing issues before opening new ones — no duplicates
- Include full context in issue descriptions (file, line, code snippet)
- Critical and high findings get individual issues
- Medium and low can be batched into a single issue
- Always include reproduction steps where possible
- Maximum 10 new issues per triage run
