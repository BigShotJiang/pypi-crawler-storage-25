---
name: release-manager
description: Manages Sentrik releases end-to-end. Audits and closes stale GitHub issues/PRs, runs the full test suite, updates documentation and website, determines the appropriate version bump (patch/minor/major) based on commit history, tags the release, and publishes to npm. Use when Max says "prepare a release", "clean up and release", "publish a new version", or approves a release-related report.
---

# Release Manager Skill

## Trigger
On-demand: activated when Max requests a release, or approves a report that includes release actions.

## Instructions

### Phase 1: Issue & PR Cleanup

1. **Audit open issues:**
   ```bash
   cd ~/sentrik-repo
   gh issue list -R maxgerhardson/sentrik --state open --limit 50 --json number,title,labels,updatedAt,body
   ```

2. **Identify stale/resolved issues:**
   - Issues that reference bugs already fixed in merged commits
   - Issues older than 60 days with no recent activity
   - Issues that duplicate existing ones
   - Cross-reference issue numbers mentioned in commit messages (e.g., `#85-95`, `#98`, `#105`, `#114`)

3. **Close resolved issues** with a comment explaining which commit/PR resolved them:
   ```bash
   gh issue close <number> -R maxgerhardson/sentrik -c "Resolved in <commit hash> — <commit message>"
   ```

4. **Audit open PRs:**
   ```bash
   gh pr list -R maxgerhardson/sentrik --state open --json number,title,labels,updatedAt,headRefName
   ```

5. **Close stale PRs** that are superseded or abandoned:
   ```bash
   gh pr close <number> -R maxgerhardson/sentrik -c "Closing — superseded by <reason>"
   ```

6. **Send summary to Telegram:** "Cleaned up X issues and Y PRs. Ready for testing."

### Phase 2: Test Suite

1. **Sync to latest main:**
   ```bash
   cd ~/sentrik-repo
   git fetch origin && git checkout main && git pull origin main
   ```

2. **Run full test suite:**
   ```bash
   source .venv/bin/activate || python3 -m venv .venv && source .venv/bin/activate
   pip install -e ".[dev]"
   python -m pytest --tb=short -q
   ```

3. **Run Sentrik self-checks:**
   ```bash
   sentrik validate-config
   sentrik gate
   sentrik scan
   ```

4. **If any tests fail:**
   - Use the coding-agent skill to spawn Claude Code to fix failures
   - Re-run tests until green
   - Do NOT proceed to release with failing tests

5. **Send summary to Telegram:** "All X tests passing. Gate clean. Ready for docs."

### Phase 3: Documentation & Website

1. **Generate changelog from commits since last tag:**
   ```bash
   LAST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
   if [ -n "$LAST_TAG" ]; then
     git log ${LAST_TAG}..HEAD --oneline --pretty=format:"- %s"
   else
     git log --oneline -30 --pretty=format:"- %s"
   fi
   ```

2. **Update docs:**
   - Check that all new CLI commands are documented in `docs/`
   - Check README.md reflects current feature set
   - Verify all standards packs are listed in docs
   - Update any version references

3. **Build and verify docs:**
   ```bash
   pip install mkdocs-material
   mkdocs build --strict
   ```

4. **If docs fail to build:**
   - Fix the issues
   - Rebuild until clean

5. **Send summary to Telegram:** "Docs updated and building clean."

### Phase 4: Version Bump & Release

1. **Determine version bump** based on commits since last tag:
   - **Major (X.0.0):** Breaking API changes, removed features, major architecture changes
   - **Minor (X.Y.0):** New features, new standards packs, new CLI commands, new dashboard tabs
   - **Patch (X.Y.Z):** Bug fixes, security patches, dependency updates, doc fixes only

2. **Update version in all files:**
   - `pyproject.toml` → `version = "X.Y.Z"`
   - `npm-package/package.json` → `"version": "X.Y.Z"`
   - Any other version references in docs or code

3. **Commit the version bump:**
   ```bash
   git add -A
   git commit -m "release: v<version>

   <changelog summary — top 5-10 items>

   Co-Authored-By: Sentrik Agent <agent@sentrik.dev>"
   git push origin main
   ```

4. **Tag the release:**
   ```bash
   git tag v<version>
   git push origin v<version>
   ```

5. **Create GitHub release:**
   ```bash
   gh release create v<version> \
     -R maxgerhardson/sentrik \
     --title "Sentrik v<version>" \
     --notes "## What's New

   <formatted changelog grouped by: Features, Bug Fixes, Security, Documentation>

   ## Standards Packs
   <total pack count and any new packs>

   ## Full Changelog
   https://github.com/maxgerhardson/sentrik/compare/<previous-tag>...v<version>"
   ```

6. **Publish npm package:**
   ```bash
   cd npm-package
   npm publish
   ```
   Note: npm auth must be configured. If not, report to Max.

7. **Send final summary to Telegram:**
   ```
   🚀 Sentrik v<version> released!

   Cleanup: X issues closed, Y PRs closed
   Tests: all passing
   Docs: updated and deployed
   GitHub: release tagged, changelog published
   npm: published to registry

   Release URL: <github release url>
   ```

### Phase 5: Post-Release

1. **Verify the GitHub Actions release workflow triggers** (builds PyPI wheel, Docker images, binaries, VSIX)
2. **Verify docs deploy** (the Deploy Docs workflow should fire on the push to main)
3. Report any post-release failures to Max

## Rules
- NEVER release with failing tests
- NEVER close issues without a comment explaining why
- ALWAYS tag the release before publishing to npm
- Version numbers must be consistent across pyproject.toml and npm-package/package.json
- If unsure about closing an issue, skip it and flag it for Max
- If npm publish fails (auth issue), report to Max — don't retry
- Maximum 1 release per execution — don't chain releases
- The GitHub Actions release.yml workflow handles PyPI, Docker, binaries, and VSIX — do NOT manually publish those
