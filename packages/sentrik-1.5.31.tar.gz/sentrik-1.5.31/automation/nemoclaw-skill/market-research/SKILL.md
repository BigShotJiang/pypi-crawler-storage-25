---
name: market-research
description: Daily competitive intelligence for Sentrik. Monitors GitHub for competing ai-sdlc and ai-code-security repos, tracks HackerNews for LLM vulnerability discussions, fetches release notes from Snyk and Semgrep, checks CISA advisories and IEC 62304 updates, and writes a dated brief to ~/sentrik-intel/. Use when asked for competitor analysis, market research, or regulatory updates.
---

# Market Research Skill

## Trigger
Heartbeat: daily at 06:00

## Instructions
1. Monitor competing GitHub repos for new releases and features:
   - Snyk CLI and related tools
   - Semgrep (semgrep/semgrep)
   - SineWave AI and other MCP security scanners
   - Any new ai-sdlc or ai-code-security repos gaining traction

2. Track HackerNews and relevant forums for:
   - LLM vulnerability discussions
   - AI code security topics
   - Regulatory compliance for AI-generated code

3. Check regulatory sources:
   - CISA Known Exploited Vulnerabilities catalog
   - IEC 62304 updates
   - EU AI Act implementation news
   - NIST AI RMF updates

4. Fetch latest release notes from key competitors:
   - Snyk (latest CLI version)
   - Semgrep (latest release)
   - Any new entrants

5. Write a dated brief to `~/sentrik-intel/YYYY-MM-DD-competitive-intelligence.md`:
   - Key findings summary
   - Major competitive threats
   - Strategic opportunities
   - Regulatory signals
   - Recommendations

6. Send summary to Telegram with top findings and actionable recommendations

## Rules
- Briefs go to ~/sentrik-intel/ — never post externally without Max approval
- Focus on actionable intelligence, not noise
- Flag direct competitive threats as high priority
- Include links to sources
- Keep briefs factual and concise
