---
name: approval-executor
description: Handles approval replies from Max on Telegram and executes approved work. When Max replies "approve" (or "approve: <instructions>", "priority: <instructions>") to any report from another skill, this skill takes over to implement the approved changes. It branches the repo, implements code changes, updates documentation, updates the website, runs tests with screenshots, creates a PR with auto-merge label, and reports the PR link back to Telegram. Use when Max replies with approval keywords to any previous report.
---

# Approval Executor Skill

## Trigger
On-demand: activated when Max replies to a Telegram report with an approval command.

## Approval Commands
- `approve` — implement everything in the referenced report as-is
- `approve: <instructions>` — implement with Max's specific instructions taking priority
- `priority: <instructions>` — same as approve but treat as high priority, do immediately
- `reject` — acknowledge and do nothing
- `defer` — acknowledge, note for next cycle, do nothing now

## Instructions

When Max sends an approval reply:

### 1. Parse the Approval
- Identify which report Max is replying to (the message being replied to)
- Extract the actionable items from that original report
- Note any additional instructions Max included after "approve:"
- If Max said "reject" or "defer", acknowledge on Telegram and stop

### 2. Branch and Sync
```bash
cd ~/sentrik-repo
git fetch origin
git checkout main && git pull origin main
git checkout -b auto/<type>-<short-description>
```
Where `<type>` is: `fix`, `feat`, `security`, `docs`, or `content` based on the source report.

### 3. Implement the Changes
Based on the source report type:

**Bug triage reports:**
- Write a failing test that reproduces the bug FIRST
- Fix the bug with minimal changes
- Verify the test passes

**Market research / feature reports:**
- Identify the feature gap or improvement
- Implement the code changes in `src/guard/`
- Add tests in `tests/`
- Keep changes focused and minimal

**Security reports:**
- For dependency CVEs: update the vulnerable package in pyproject.toml
- For code issues: apply the fix, add a regression test
- Update `agent-reports/market-intel/security-log-*.md`

**Content / social reports:**
- Update website content in `docs/`
- Update marketing copy as needed

### 4. Update Documentation
After code changes:
- Update relevant docs in `docs/` (CLI help, config options, guides)
- Update `README.md` if public-facing features changed
- Build and verify: `mkdocs build --strict`

### 5. Update the Website
If feature or content changes affect the public site:
- Edit the relevant pages in `docs/`
- Rebuild: `mkdocs build --strict`
- The Deploy Docs GitHub Action will handle deployment on merge to main

### 6. Run Tests
Execute ALL of these and fix any failures before proceeding:
```bash
# Unit tests
python -m pytest --tb=short -q

# Config validation
python -m guard.cli validate-config

# Sentrik gate scan
python -m guard.cli gate
```

If tests fail, fix the issue and re-run. Do not proceed with failures.

### 7. Visual Testing
If E2E tests are set up:
```bash
cd /sandbox/.openclaw-data/workspace/sentrik-repo/automation/e2e
npx playwright test --project=chromium 2>/dev/null || echo "E2E skipped — Playwright not installed in sandbox"
```

### 8. Commit and Create PR
```bash
git add -A
git commit -m "<type>: <concise description>

Implemented from <source-skill> report.
Approved by Max via Telegram.

Co-Authored-By: Sentrik Agent <agent@sentrik.dev>"

git push origin auto/<branch-name>

gh pr create \
  --title "<type>: <concise description>" \
  --body "## Auto-implemented from $(source-skill) report

### Summary
<what changed and why>

### Linked Issues
Fixes #<issue-number> (include ALL related issue numbers — GitHub will auto-close them on merge)

### Testing
- [x] Unit tests pass
- [x] Config validation pass
- [x] Sentrik gate pass
- [x] Docs build clean

### Approval
Approved by Max via Telegram reply.

---
🤖 Sentrik Autonomous Agent" \
  --label "auto-merge"
```

### 9. Report Back
Send a Telegram message to Max:
```
✅ PR created: <pr-url>
Type: <type>
Title: <title>
Tests: all passing
Auto-merge: enabled — will merge when CI checks pass
```

If anything failed, send:
```
❌ Implementation failed at step <N>
Error: <brief description>
I've pushed what I have to branch auto/<name> for review.
```

## Rules
- NEVER push directly to main — always create a PR
- ALWAYS run tests before creating the PR
- If tests fail after 2 fix attempts, push what you have and report the failure to Max
- Do not modify files outside the scope of the approved report
- Max's inline instructions (after "approve:") override the report's suggestions
- Maximum 1 PR per approval — don't split into multiple PRs
- If the change is too large or risky, tell Max and ask for guidance instead of proceeding
- Always include the auto-merge label so the GitHub Action can squash-merge when CI passes
- ALWAYS include "Fixes #NNN" in PR body for every related GitHub issue — this auto-closes issues on merge
- After a PR merges, verify the linked issues were closed. If not, close them manually with gh issue close
