---
name: security-maintenance
description: Keeps Sentrik's own dependencies and security posture current. Runs npm audit, checks Dependabot alerts, searches NVD for CVEs, drafts dependency bump PRs, and runs Sentrik's scanner against itself. Use when asked to check dependencies, scan for vulnerabilities, or review Sentrik's security posture.
---

# Security Maintenance Skill

## Trigger
Heartbeat: weekly on Monday at 06:00

## Instructions
1. Pull latest and activate environment:
   ```bash
   cd ~/sentrik-repo
   git fetch origin && git checkout main && git pull origin main
   source .venv/bin/activate
   ```

2. Check Python dependencies for known CVEs:
   ```bash
   pip install pip-audit safety
   pip-audit
   safety check
   ```

3. Check npm dependencies:
   ```bash
   cd npm-package && npm audit
   cd ../frontend && npm audit
   cd ../vscode-extension && npm audit
   ```

4. Check Dependabot alerts:
   ```bash
   gh api repos/maxgerhardson/sentrik/dependabot/alerts --jq '.[] | select(.state=="open")'
   ```

5. Run Sentrik's own scanner against itself:
   ```bash
   sentrik scan
   sentrik vulns
   ```

6. For each vulnerability found:
   - Assess severity and exploitability
   - Draft a fix (dependency bump or code change)
   - Create a PR if fix is straightforward

7. Update security log:
   ```bash
   # Append to ~/sentrik-intel/security-log-YYYY-MM.md
   ```

8. Send security report to Telegram:
   - Vulnerabilities found (by severity)
   - Dependencies that need updating
   - Self-scan results
   - Any PRs created

## Rules
- Critical CVEs get immediate attention and Telegram alert
- Always test after dependency bumps: pytest + sentrik gate
- Security PRs should include "Fixes #NNN" for related issues
- Log all findings to security-log even if no action needed
- Never downgrade a dependency to fix a vulnerability
