# Sentrik Agent — Telegram Commands

## Approvals (reply to any report)
| Command | What happens |
|---------|-------------|
| `approve` | Implement everything as suggested |
| `approve: <notes>` | Implement with your modifications |
| `priority: <notes>` | Urgent — do it now |
| `reject` | Skip it |
| `defer` | Next cycle |

## Releases
| Command | What happens |
|---------|-------------|
| `prepare a release` | Full pipeline: cleanup → test → docs → tag → publish |
| `publish to npm` | npm publish only |

## Status
| Command | What happens |
|---------|-------------|
| `/status` | Queue and recent tasks |
| `/logs <task-id>` | Pull logs for a task |

## Examples
- "approve" → implements the report as-is
- "approve: only fix the critical CVEs, skip the low ones" → selective
- "priority: the html.py syntax error is blocking us" → urgent
- "prepare a release" → v1.x.0 end-to-end
