import { test, expect } from '@playwright/test';
import { execSync } from 'child_process';

/**
 * Sentrik Regression Tests
 *
 * Deeper checks that run CLI commands, verify output files,
 * and compare dashboard state after operations.
 */

test.describe('CLI Regression Tests', () => {

  test('sentrik validate-config succeeds', async () => {
    const result = execSync('python -m guard.cli validate-config', {
      cwd: '../../',
      encoding: 'utf-8',
      timeout: 30000,
    });
    expect(result).not.toContain('ERROR');
  });

  test('sentrik scan produces output', async () => {
    try {
      execSync('python -m guard.cli scan', {
        cwd: '../../',
        encoding: 'utf-8',
        timeout: 60000,
      });
    } catch (e: any) {
      // Scan may exit non-zero if findings exist — that's fine
      expect(e.stdout || e.stderr).toBeDefined();
    }
  });

  test('sentrik gate runs without crash', async () => {
    try {
      execSync('python -m guard.cli gate', {
        cwd: '../../',
        encoding: 'utf-8',
        timeout: 60000,
      });
    } catch (e: any) {
      // Gate may exit 1 on findings — that's expected
      // Just verify it ran (produced output)
      const output = (e.stdout || '') + (e.stderr || '');
      expect(output.length).toBeGreaterThan(0);
    }
  });

  test('mkdocs builds without errors', async () => {
    const result = execSync('mkdocs build --strict 2>&1 || true', {
      cwd: '../../',
      encoding: 'utf-8',
      timeout: 60000,
    });
    // Strict mode: warnings are errors
    expect(result).not.toContain('ERROR');
  });
});


test.describe('Dashboard Regression', () => {

  test('dashboard reflects latest scan data', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Take a full-page screenshot for visual comparison
    await page.screenshot({
      path: 'screenshots/regression-dashboard-full.png',
      fullPage: true,
    });

    // Verify key dashboard elements exist
    const body = await page.textContent('body');
    expect(body).toBeTruthy();
    expect(body!.length).toBeGreaterThan(100); // Not a blank page
  });

  test('dashboard navigation works', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Try clicking through main nav items and screenshot each
    const navLinks = page.locator('nav a, .nav-link, [role="tab"]');
    const count = await navLinks.count();

    for (let i = 0; i < Math.min(count, 5); i++) {
      const link = navLinks.nth(i);
      const text = await link.textContent();
      if (text && await link.isVisible()) {
        await link.click();
        await page.waitForLoadState('networkidle');
        const safeName = text.trim().toLowerCase().replace(/\W+/g, '-').slice(0, 30);
        await page.screenshot({
          path: `screenshots/nav-${safeName}.png`,
          fullPage: true,
        });
      }
    }
  });
});


test.describe('Frontend Build Regression', () => {

  test('frontend builds without errors', async () => {
    const result = execSync('npm run build 2>&1', {
      cwd: '../../frontend',
      encoding: 'utf-8',
      timeout: 60000,
    });
    expect(result).not.toContain('ERROR');
  });
});
