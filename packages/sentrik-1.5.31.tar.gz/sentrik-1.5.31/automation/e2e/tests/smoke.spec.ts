import { test, expect } from '@playwright/test';

/**
 * Sentrik Smoke Tests
 *
 * Quick checks that key pages load and core functionality works.
 * Screenshots are captured for every test for visual regression tracking.
 */

test.describe('Dashboard Smoke Tests', () => {

  test('dashboard loads and shows overview', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Check page title
    await expect(page).toHaveTitle(/Sentrik|Guard|Dashboard/i);

    // Screenshot the full dashboard
    await page.screenshot({
      path: 'screenshots/dashboard-overview.png',
      fullPage: true,
    });
  });

  test('findings panel renders', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Look for findings-related content
    const findingsSection = page.locator('[data-testid="findings"], .findings, #findings').first();
    if (await findingsSection.isVisible()) {
      await findingsSection.screenshot({
        path: 'screenshots/findings-panel.png',
      });
    } else {
      // Full page fallback
      await page.screenshot({
        path: 'screenshots/findings-panel-fullpage.png',
        fullPage: true,
      });
    }
  });

  test('compliance section renders', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const compliance = page.locator('[data-testid="compliance"], .compliance, #compliance').first();
    if (await compliance.isVisible()) {
      await compliance.screenshot({
        path: 'screenshots/compliance-section.png',
      });
    }
  });

  test('no console errors on dashboard', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        errors.push(msg.text());
      }
    });

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Filter out known benign errors (e.g., favicon 404)
    const realErrors = errors.filter(
      (e) => !e.includes('favicon') && !e.includes('404')
    );
    expect(realErrors).toHaveLength(0);
  });
});


test.describe('API Smoke Tests', () => {

  test('health endpoint responds', async ({ request }) => {
    const response = await request.get('/health');
    expect(response.ok()).toBeTruthy();
    const body = await response.json();
    expect(body).toHaveProperty('status');
  });

  test('scan results endpoint responds', async ({ request }) => {
    const response = await request.get('/api/v1/findings');
    // May be 200 or 404 depending on whether a scan has run
    expect([200, 404]).toContain(response.status());
  });
});


test.describe('Docs Site Smoke Tests', () => {

  test('docs site loads', async ({ page }) => {
    // Check if mkdocs site is accessible
    await page.goto('http://localhost:8001', { timeout: 5000 }).catch(() => {
      test.skip(true, 'Docs server not running');
    });

    await page.waitForLoadState('networkidle');
    await page.screenshot({
      path: 'screenshots/docs-homepage.png',
      fullPage: true,
    });
  });
});
