import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  outputDir: './test-results',
  fullyParallel: false,
  retries: 1,
  workers: 1,
  reporter: [
    ['html', { outputFolder: './report' }],
    ['json', { outputFile: './test-results/results.json' }],
    ['list'],
  ],
  use: {
    baseURL: 'http://localhost:8000',
    screenshot: 'on',
    trace: 'on-first-retry',
    video: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  /* Start the Sentrik dashboard server before running tests */
  webServer: {
    command: 'python -m guard.cli serve --port 8000',
    port: 8000,
    timeout: 30000,
    reuseExistingServer: true,
    cwd: '../../',
  },
});
