#!/usr/bin/env python3
"""
Sentrik Telegram Approval Handler
==================================
Listens for replies to NemoClaw agent reports in Telegram.
When Max replies with an approval, triggers Claude Code to implement the work.

Architecture:
  NemoClaw cron → sends report to Telegram → Max replies "approve" →
  this handler catches reply → parses task context → spawns Claude Code →
  Claude Code: implement → test → screenshot → PR → auto-merge

Setup:
  1. Set environment variables (or .env file)
  2. Run: python approval_handler.py
  3. Reply to any NemoClaw report message with approval commands

Approval Commands:
  "approve"                    - Approve as-is, implement everything in the report
  "approve: <instructions>"   - Approve with specific instructions
  "priority: <instructions>"  - High priority, skip queue
  "reject"                    - Reject the suggestion
  "defer"                     - Defer to next cycle
"""

import os
import re
import json
import asyncio
import logging
import subprocess
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional

from telegram import Update, Message
from telegram.ext import (
    Application,
    MessageHandler,
    CommandHandler,
    ContextTypes,
    filters,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BOT_TOKEN = os.environ.get("SENTRIK_BOT_TOKEN", "")
AUTHORIZED_CHAT_ID = int(os.environ.get("SENTRIK_CHAT_ID", "8561149678"))
REPO_PATH = os.environ.get("SENTRIK_REPO_PATH", r"C:\Users\mgerh\ai_sdlc_guard")
CLAUDE_BIN = os.environ.get("CLAUDE_BIN", "claude")  # Claude Code CLI binary
LOG_DIR = os.environ.get("SENTRIK_LOG_DIR", "automation/logs")
MAX_CONCURRENT_TASKS = int(os.environ.get("MAX_CONCURRENT_TASKS", "1"))

# WSL2 path translation (Windows → WSL)
WSL_REPO_PATH = os.environ.get(
    "WSL_REPO_PATH",
    "/mnt/c/Users/mgerh/ai_sdlc_guard",
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("sentrik.approval")


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

class TaskStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskType(str, Enum):
    FEATURE = "feature"
    BUG_FIX = "bug_fix"
    SECURITY = "security"
    DOCS = "docs"
    MARKET_RESEARCH = "market_research"
    CONTENT = "content"


@dataclass
class ApprovalTask:
    task_id: str
    task_type: TaskType
    title: str
    description: str
    instructions: str
    source_message_id: int
    approval_message_id: int
    status: TaskStatus = TaskStatus.QUEUED
    priority: bool = False
    pr_url: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: Optional[str] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Report Parser — extracts structured task info from NemoClaw reports
# ---------------------------------------------------------------------------

def classify_report(text: str) -> TaskType:
    """Classify a NemoClaw report into a task type."""
    text_lower = text.lower()
    if any(k in text_lower for k in ["vulnerability", "cve", "security", "exploit"]):
        return TaskType.SECURITY
    if any(k in text_lower for k in ["bug", "error", "crash", "fix", "regression"]):
        return TaskType.BUG_FIX
    if any(k in text_lower for k in ["market", "competitor", "trend", "research"]):
        return TaskType.MARKET_RESEARCH
    if any(k in text_lower for k in ["content", "blog", "social", "linkedin", "twitter"]):
        return TaskType.CONTENT
    if any(k in text_lower for k in ["docs", "documentation", "readme", "guide"]):
        return TaskType.DOCS
    return TaskType.FEATURE


def extract_title(text: str) -> str:
    """Pull the first heading or first sentence as a title."""
    for line in text.strip().splitlines():
        line = line.strip()
        if line.startswith("#"):
            return line.lstrip("# ").strip()
        if line and len(line) > 10:
            return line[:120]
    return "Untitled task"


def generate_task_id(text: str) -> str:
    """Deterministic short ID from report content."""
    h = hashlib.sha256(text.encode()).hexdigest()[:8]
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M")
    return f"task-{ts}-{h}"


# ---------------------------------------------------------------------------
# Approval Command Parser
# ---------------------------------------------------------------------------

APPROVE_PATTERN = re.compile(
    r"^(approve|yes|go|ship it|lgtm|do it)(?:\s*[:\-]\s*(.+))?$",
    re.IGNORECASE | re.DOTALL,
)
PRIORITY_PATTERN = re.compile(
    r"^(priority|urgent|asap)(?:\s*[:\-]\s*(.+))?$",
    re.IGNORECASE | re.DOTALL,
)
REJECT_PATTERN = re.compile(r"^(reject|no|skip|pass)\b", re.IGNORECASE)
DEFER_PATTERN = re.compile(r"^(defer|later|next cycle|postpone)\b", re.IGNORECASE)


def parse_approval(text: str):
    """Parse user reply into an approval action.

    Returns: (action, extra_instructions)
      action: "approve" | "priority" | "reject" | "defer" | None
    """
    text = text.strip()
    m = PRIORITY_PATTERN.match(text)
    if m:
        return "priority", (m.group(2) or "").strip()
    m = APPROVE_PATTERN.match(text)
    if m:
        return "approve", (m.group(2) or "").strip()
    if REJECT_PATTERN.match(text):
        return "reject", ""
    if DEFER_PATTERN.match(text):
        return "defer", ""
    return None, ""


# ---------------------------------------------------------------------------
# Claude Code Task Runner
# ---------------------------------------------------------------------------

class ClaudeTaskRunner:
    """Manages spawning and tracking Claude Code sessions."""

    def __init__(self, repo_path: str, claude_bin: str, log_dir: str):
        self.repo_path = repo_path
        self.claude_bin = claude_bin
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._active_tasks: dict[str, asyncio.subprocess.Process] = {}

    def build_prompt(self, task: ApprovalTask) -> str:
        """Build the Claude Code prompt for a given task."""
        prompt_template_path = (
            Path(__file__).parent.parent / "prompts" / f"{task.task_type.value}.md"
        )
        if prompt_template_path.exists():
            template = prompt_template_path.read_text()
        else:
            template = (Path(__file__).parent.parent / "prompts" / "default.md").read_text()

        prompt = template.replace("{{TASK_ID}}", task.task_id)
        prompt = prompt.replace("{{TITLE}}", task.title)
        prompt = prompt.replace("{{DESCRIPTION}}", task.description)
        prompt = prompt.replace("{{INSTRUCTIONS}}", task.instructions or "Implement as described in the report.")
        prompt = prompt.replace("{{TASK_TYPE}}", task.task_type.value)
        prompt = prompt.replace("{{PRIORITY}}", "HIGH" if task.priority else "NORMAL")
        return prompt

    async def run_task(self, task: ApprovalTask) -> ApprovalTask:
        """Execute a task via Claude Code CLI."""
        prompt = self.build_prompt(task)
        log_file = self.log_dir / f"{task.task_id}.log"
        prompt_file = self.log_dir / f"{task.task_id}.prompt.md"

        # Save prompt for debugging
        prompt_file.write_text(prompt)

        task.status = TaskStatus.RUNNING
        logger.info(f"Starting task {task.task_id}: {task.title}")

        try:
            proc = await asyncio.create_subprocess_exec(
                self.claude_bin,
                "--print",
                "--dangerously-skip-permissions",
                "-p", prompt,
                cwd=self.repo_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            self._active_tasks[task.task_id] = proc
            stdout, stderr = await proc.communicate()

            output = stdout.decode("utf-8", errors="replace")
            log_file.write_text(output)

            if proc.returncode == 0:
                task.status = TaskStatus.COMPLETED
                # Try to extract PR URL from output
                pr_match = re.search(r"https://github\.com/[^\s]+/pull/\d+", output)
                if pr_match:
                    task.pr_url = pr_match.group(0)
                logger.info(f"Task {task.task_id} completed. PR: {task.pr_url}")
            else:
                task.status = TaskStatus.FAILED
                task.error = stderr.decode("utf-8", errors="replace")[:500]
                logger.error(f"Task {task.task_id} failed: {task.error}")

        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            logger.exception(f"Task {task.task_id} exception")
        finally:
            self._active_tasks.pop(task.task_id, None)
            task.completed_at = datetime.now(timezone.utc).isoformat()

        return task


# ---------------------------------------------------------------------------
# Telegram Bot Handlers
# ---------------------------------------------------------------------------

runner = ClaudeTaskRunner(
    repo_path=REPO_PATH,
    claude_bin=CLAUDE_BIN,
    log_dir=LOG_DIR,
)

# Track report message IDs → report text, so we can resolve replies
report_cache: dict[int, str] = {}
task_history: list[ApprovalTask] = []
task_queue: asyncio.Queue = asyncio.Queue()


async def handle_report_tracking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Track outbound report messages so we can match replies.

    NemoClaw sends reports via the same bot. This handler captures them
    so reply-based approvals can reference the original report text.
    """
    msg = update.effective_message
    if not msg or msg.chat_id != AUTHORIZED_CHAT_ID:
        return
    # If the message is from the bot itself (outbound report), cache it
    if msg.from_user and msg.from_user.is_bot:
        report_cache[msg.message_id] = msg.text or ""
        logger.debug(f"Cached report message {msg.message_id}")


async def handle_approval_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process a user reply to a NemoClaw report message."""
    msg = update.effective_message
    if not msg or msg.chat_id != AUTHORIZED_CHAT_ID:
        return

    # Must be a reply to a previous message
    if not msg.reply_to_message:
        return

    replied_id = msg.reply_to_message.message_id
    reply_text = msg.text or ""

    # Get the original report text
    original_report = report_cache.get(replied_id, "")
    if not original_report:
        # Fallback: use the replied-to message text directly
        original_report = msg.reply_to_message.text or ""

    if not original_report:
        await msg.reply_text("Couldn't find the original report. Try forwarding it to me with your instructions.")
        return

    # Parse the approval command
    action, extra_instructions = parse_approval(reply_text)

    if action is None:
        await msg.reply_text(
            "I didn't understand that. Reply with:\n"
            "• `approve` — implement as suggested\n"
            "• `approve: <instructions>` — implement with changes\n"
            "• `priority: <instructions>` — urgent task\n"
            "• `reject` — skip this\n"
            "• `defer` — next cycle",
            parse_mode="Markdown",
        )
        return

    if action == "reject":
        await msg.reply_text("Rejected. Moving on.")
        return

    if action == "defer":
        await msg.reply_text("Deferred to next cycle.")
        return

    # Build the task
    task = ApprovalTask(
        task_id=generate_task_id(original_report),
        task_type=classify_report(original_report),
        title=extract_title(original_report),
        description=original_report,
        instructions=extra_instructions,
        source_message_id=replied_id,
        approval_message_id=msg.message_id,
        priority=(action == "priority"),
    )

    task_history.append(task)
    await task_queue.put(task)

    emoji = "🔴" if task.priority else "🟢"
    await msg.reply_text(
        f"{emoji} *Task queued*\n"
        f"ID: `{task.task_id}`\n"
        f"Type: {task.task_type.value}\n"
        f"Title: {task.title[:80]}\n"
        f"Priority: {'HIGH' if task.priority else 'normal'}\n\n"
        f"Claude Code will pick this up shortly.",
        parse_mode="Markdown",
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show queue and recent task status."""
    msg = update.effective_message
    if not msg or msg.chat_id != AUTHORIZED_CHAT_ID:
        return

    lines = ["*Task Status*\n"]

    active = [t for t in task_history if t.status == TaskStatus.RUNNING]
    queued = [t for t in task_history if t.status == TaskStatus.QUEUED]

    if active:
        for t in active:
            lines.append(f"🔄 Running: `{t.task_id}` — {t.title[:60]}")
    if queued:
        for t in queued:
            lines.append(f"⏳ Queued: `{t.task_id}` — {t.title[:60]}")

    recent = [t for t in task_history if t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)][-5:]
    if recent:
        lines.append("\n*Recent:*")
        for t in reversed(recent):
            icon = "✅" if t.status == TaskStatus.COMPLETED else "❌"
            pr = f" → [PR]({t.pr_url})" if t.pr_url else ""
            lines.append(f"{icon} `{t.task_id}` — {t.title[:50]}{pr}")

    if len(lines) == 1:
        lines.append("No tasks yet. Reply to a report to get started.")

    await msg.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send the log for a given task ID."""
    msg = update.effective_message
    if not msg or msg.chat_id != AUTHORIZED_CHAT_ID:
        return
    args = context.args
    if not args:
        await msg.reply_text("Usage: /logs <task_id>")
        return
    task_id = args[0]
    log_file = Path(LOG_DIR) / f"{task_id}.log"
    if log_file.exists():
        content = log_file.read_text()[-3000:]  # Last 3K chars
        await msg.reply_text(f"```\n{content}\n```", parse_mode="Markdown")
    else:
        await msg.reply_text(f"No log found for `{task_id}`.")


# ---------------------------------------------------------------------------
# Task Queue Worker
# ---------------------------------------------------------------------------

async def task_worker(app: Application):
    """Background worker that processes approved tasks sequentially."""
    logger.info("Task worker started")
    while True:
        task: ApprovalTask = await task_queue.get()
        logger.info(f"Worker picked up task {task.task_id}")

        # Notify Telegram that work is starting
        try:
            await app.bot.send_message(
                chat_id=AUTHORIZED_CHAT_ID,
                text=f"🚀 *Starting work on `{task.task_id}`*\n{task.title[:80]}",
                parse_mode="Markdown",
            )
        except Exception:
            pass

        # Run the task
        task = await runner.run_task(task)

        # Report result back to Telegram
        try:
            if task.status == TaskStatus.COMPLETED:
                pr_line = f"\n🔗 [View PR]({task.pr_url})" if task.pr_url else ""
                await app.bot.send_message(
                    chat_id=AUTHORIZED_CHAT_ID,
                    text=(
                        f"✅ *Task completed*\n"
                        f"ID: `{task.task_id}`\n"
                        f"Title: {task.title[:80]}{pr_line}\n\n"
                        f"Tests ran, screenshots captured, PR created with auto-merge."
                    ),
                    parse_mode="Markdown",
                )
            else:
                await app.bot.send_message(
                    chat_id=AUTHORIZED_CHAT_ID,
                    text=(
                        f"❌ *Task failed*\n"
                        f"ID: `{task.task_id}`\n"
                        f"Error: {task.error[:200] if task.error else 'Unknown'}\n\n"
                        f"Use /logs {task.task_id} for details."
                    ),
                    parse_mode="Markdown",
                )
        except Exception:
            logger.exception("Failed to send result to Telegram")

        task_queue.task_done()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if not BOT_TOKEN:
        raise RuntimeError(
            "Set SENTRIK_BOT_TOKEN environment variable. "
            "Get it from @BotFather on Telegram."
        )

    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("logs", cmd_logs))

    # Reply-based approval handler (only for replies)
    app.add_handler(
        MessageHandler(
            filters.REPLY & filters.TEXT & filters.Chat(AUTHORIZED_CHAT_ID),
            handle_approval_reply,
        )
    )

    # Track all bot messages for report caching
    app.add_handler(
        MessageHandler(filters.ALL, handle_report_tracking),
        group=1,
    )

    # Start the background task worker
    loop = asyncio.get_event_loop()
    loop.create_task(task_worker(app))

    logger.info("Sentrik Approval Handler started. Listening for replies...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
