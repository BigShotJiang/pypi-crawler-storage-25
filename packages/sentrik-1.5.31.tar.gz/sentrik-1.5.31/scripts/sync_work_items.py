"""Sync local work_items.json state to Azure DevOps epics via REST API.

Usage:
    AZURE_DEVOPS_PAT=<pat> python scripts/sync_work_items.py

Reads org/project from .guard.yaml and work items from work_items.json,
then updates Azure DevOps work item states to match.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import requests
import yaml

# Map local state names to Azure DevOps state names
STATE_MAP: dict[str, str] = {
    "active": "Doing",
    "closed": "Done",
    "new": "To Do",
}


def load_config(config_path: str = ".guard.yaml") -> tuple[str, str]:
    """Read .guard.yaml and return (org, project)."""
    path = Path(config_path)
    with path.open() as f:
        data = yaml.safe_load(f)
    org = data["azure_devops_org"]
    project = data["azure_devops_project"]
    return org, project


def load_work_items(path: str = "work_items.json") -> list[dict]:
    """Read work_items.json and return list of work item dicts."""
    with Path(path).open() as f:
        return json.load(f)


def find_work_item_by_title(
    title: str, org: str, project: str, pat: str
) -> tuple[int, str] | None:
    """Query Azure DevOps via WIQL for a work item matching *title*.

    Returns ``(id, current_state)`` or ``None`` if not found.
    Prints a warning and returns ``None`` when multiple matches exist.
    """
    url = f"https://dev.azure.com/{org}/{project}/_apis/wit/wiql?api-version=7.1"
    wiql = {
        "query": (
            "SELECT [System.Id], [System.State] FROM WorkItems "
            f"WHERE [System.Title] = '{title}'"
        )
    }
    resp = requests.post(url, json=wiql, auth=("", pat), timeout=30)
    if resp.status_code != 200:
        print(f"  WIQL query failed ({resp.status_code}): {resp.text}")
        return None

    work_items = resp.json().get("workItems", [])
    if len(work_items) == 0:
        print(f"  No DevOps work item found for title: {title}")
        return None
    if len(work_items) > 1:
        print(f"  Multiple matches ({len(work_items)}) for title: {title} — skipping")
        return None

    wi_id = work_items[0]["id"]

    # Fetch full work item to get current state
    detail_url = (
        f"https://dev.azure.com/{org}/{project}/_apis/wit/workitems/{wi_id}"
        f"?api-version=7.1"
    )
    detail_resp = requests.get(detail_url, auth=("", pat), timeout=30)
    if detail_resp.status_code != 200:
        print(f"  Failed to fetch work item {wi_id} ({detail_resp.status_code})")
        return None

    state = detail_resp.json()["fields"]["System.State"]
    return wi_id, state


def update_work_item_state(
    work_item_id: int, new_state: str, org: str, project: str, pat: str
) -> bool:
    """PATCH a DevOps work item to set its state. Returns True on success."""
    url = (
        f"https://dev.azure.com/{org}/{project}/_apis/wit/workitems/{work_item_id}"
        f"?api-version=7.1"
    )
    payload = [
        {
            "op": "replace",
            "path": "/fields/System.State",
            "value": new_state,
        }
    ]
    resp = requests.patch(
        url,
        json=payload,
        auth=("", pat),
        headers={"Content-Type": "application/json-patch+json"},
        timeout=30,
    )
    if resp.status_code != 200:
        print(f"  PATCH failed ({resp.status_code}): {resp.text}")
        return False
    return True


def main() -> None:
    """Orchestrate the sync: read config, iterate work items, update DevOps."""
    pat = os.environ.get("AZURE_DEVOPS_PAT")
    if not pat:
        print("Error: AZURE_DEVOPS_PAT environment variable is not set.")
        sys.exit(1)

    org, project = load_config()
    items = load_work_items()

    updated = 0
    skipped = 0
    failed = 0

    for item in items:
        title = item["title"]
        local_state = item["state"]
        desired = STATE_MAP.get(local_state)
        if desired is None:
            print(f"[SKIP] Unknown local state '{local_state}' for: {title}")
            skipped += 1
            continue

        print(f"[SYNC] {title}")
        result = find_work_item_by_title(title, org, project, pat)
        if result is None:
            skipped += 1
            continue

        wi_id, current_state = result
        if current_state == desired:
            print(f"  Already '{desired}' — no change needed")
            skipped += 1
            continue

        print(f"  Updating {wi_id}: '{current_state}' -> '{desired}'")
        if update_work_item_state(wi_id, desired, org, project, pat):
            updated += 1
        else:
            failed += 1

    print(f"\nDone: {updated} updated, {skipped} skipped, {failed} failed")


if __name__ == "__main__":
    main()
