# Sentrik Test Sandbox
# Creates an isolated environment with a temp directory and fresh venv.
# Everything is destroyed when you type 'exit' or close the window.
#
# Usage: .\scripts\test-sandbox.ps1
# Optional: .\scripts\test-sandbox.ps1 -WithDemo  (clones demo project)

param(
    [switch]$WithDemo
)

$sandbox = Join-Path $env:TEMP "sentrik-sandbox-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Write-Host ""
Write-Host "  ========================================" -ForegroundColor Cyan
Write-Host "  Sentrik Test Sandbox" -ForegroundColor Cyan
Write-Host "  ========================================" -ForegroundColor Cyan
Write-Host "  Directory: $sandbox" -ForegroundColor Gray
Write-Host "  Type 'exit' to destroy sandbox" -ForegroundColor Gray
Write-Host ""

# Create sandbox
New-Item -ItemType Directory -Path $sandbox -Force | Out-Null
Set-Location $sandbox

# Create venv
Write-Host "  Creating virtual environment..." -ForegroundColor Yellow
python -m venv .venv
& .\.venv\Scripts\Activate.ps1

# Install sentrik from npm (binary)
Write-Host "  Installing sentrik via npm..." -ForegroundColor Yellow
npm install -g sentrik 2>$null

# Verify
Write-Host ""
sentrik version
Write-Host ""

# Clone demo project if requested
if ($WithDemo) {
    Write-Host "  Cloning demo project..." -ForegroundColor Yellow
    git clone https://github.com/maxgerhardson/sentrik-demo-medapi.git demo
    Set-Location demo
    Write-Host "  Demo project ready at: $sandbox\demo" -ForegroundColor Green
}

Write-Host ""
Write-Host "  Sandbox ready. You're in a clean environment." -ForegroundColor Green
Write-Host "  - sentrik is installed globally via npm" -ForegroundColor Gray
Write-Host "  - Python venv is active (.venv)" -ForegroundColor Gray
Write-Host "  - Type 'exit' when done — everything is deleted" -ForegroundColor Gray
Write-Host ""

# Register cleanup on exit
Register-EngineEvent PowerShell.Exiting -Action {
    deactivate 2>$null
    Set-Location $env:USERPROFILE
    Remove-Item -Recurse -Force $using:sandbox -ErrorAction SilentlyContinue
    Write-Host "  Sandbox destroyed: $using:sandbox" -ForegroundColor Red
} | Out-Null
