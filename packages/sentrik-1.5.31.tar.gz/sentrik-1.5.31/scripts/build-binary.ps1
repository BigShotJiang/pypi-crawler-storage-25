# Build a standalone guard binary using PyInstaller (Windows).
# Usage: .\scripts\build-binary.ps1

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "==> Building AI SDLC Guard standalone binary"
Write-Host "    Project root: $ProjectRoot"

Set-Location $ProjectRoot

# Ensure PyInstaller is installed
try {
    python -m PyInstaller --version | Out-Null
} catch {
    Write-Host "==> Installing PyInstaller..."
    pip install pyinstaller
}

# Clean previous builds
Write-Host "==> Cleaning dist/ and build/ directories..."
if (Test-Path dist) { Remove-Item -Recurse -Force dist }
if (Test-Path build) { Remove-Item -Recurse -Force build }

# Run PyInstaller
Write-Host "==> Running PyInstaller..."
python -m PyInstaller guard.spec

# Smoke test
$Binary = "dist\guard.exe"
if (Test-Path $Binary) {
    Write-Host "==> Smoke test: $Binary --help"
    try {
        & $Binary --help | Out-Null
        Write-Host "    PASSED"
    } catch {
        Write-Host "    FAILED"
    }
    Write-Host "==> Binary built successfully: $Binary"
} else {
    Write-Host "ERROR: Binary not found at $Binary"
    exit 1
}
