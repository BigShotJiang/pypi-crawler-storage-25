$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $RepoRoot

Write-Host "==> Creating virtual environment..."
python -m venv .venv
& .venv\Scripts\Activate.ps1

Write-Host "==> Installing package with dev dependencies..."
pip install --upgrade pip
pip install -e ".[dev]"

Write-Host "==> Installing pre-commit hooks..."
pre-commit install

Write-Host "==> Validating guard config..."
guard validate-config

Write-Host "==> Running smoke test (guard scan)..."
guard scan

Write-Host ""
Write-Host "Setup complete! Activate the venv with:"
Write-Host "  .venv\Scripts\Activate.ps1"
