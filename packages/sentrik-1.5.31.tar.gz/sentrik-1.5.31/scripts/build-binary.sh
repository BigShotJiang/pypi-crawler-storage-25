#!/usr/bin/env bash
set -euo pipefail

# Build a standalone guard binary using PyInstaller.
# Usage: bash scripts/build-binary.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "==> Building AI SDLC Guard standalone binary"
echo "    Project root: $PROJECT_ROOT"

cd "$PROJECT_ROOT"

# Ensure PyInstaller is installed
if ! python -m PyInstaller --version &>/dev/null; then
    echo "==> Installing PyInstaller..."
    pip install pyinstaller
fi

# Clean previous builds
echo "==> Cleaning dist/ and build/ directories..."
rm -rf dist/ build/

# Run PyInstaller
echo "==> Running PyInstaller..."
python -m PyInstaller guard.spec

# Smoke test
BINARY="dist/guard"
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" || "$OSTYPE" == "win32" ]]; then
    BINARY="dist/guard.exe"
fi

if [[ -f "$BINARY" ]]; then
    echo "==> Smoke test: $BINARY --help"
    "$BINARY" --help >/dev/null 2>&1 && echo "    PASSED" || echo "    FAILED"
    echo "==> Binary built successfully: $BINARY"
else
    echo "ERROR: Binary not found at $BINARY"
    exit 1
fi
