#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

PYTHON="${PYTHON:-$(command -v python3 2>/dev/null || command -v python 2>/dev/null)}"
if [ -z "$PYTHON" ]; then
    echo "Error: python3 or python not found on PATH" >&2
    exit 1
fi

echo "==> Creating virtual environment (using $PYTHON)..."
"$PYTHON" -m venv .venv

# Activate: support both Unix and Git-Bash-on-Windows layouts
if [ -f .venv/bin/activate ]; then
    source .venv/bin/activate
elif [ -f .venv/Scripts/activate ]; then
    source .venv/Scripts/activate
else
    echo "Error: could not find venv activate script" >&2
    exit 1
fi

echo "==> Installing package with dev dependencies..."
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"

echo "==> Installing pre-commit hooks..."
pre-commit install

echo "==> Validating guard config..."
guard validate-config

echo "==> Running smoke test (guard scan)..."
guard scan

echo ""
echo "Setup complete! Activate the venv with:"
echo "  source .venv/bin/activate"
