"""Automated manual test suite for Sentrik release readiness."""

import subprocess
import sys
import os
import time
import urllib.request
import urllib.error
import json

os.chdir(os.environ.get("TEST_DIR", os.getcwd()))

results = []
passed = 0
failed = 0


def run(test_id, desc, cmd, check_fn=None, timeout=60):
    global passed, failed
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        output = r.stdout + r.stderr
        if check_fn:
            ok = check_fn(r, output)
        else:
            ok = r.returncode == 0
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        results.append((test_id, desc, status))
        print(f"  {status} {test_id}: {desc}")
        if not ok:
            print(f"       exit={r.returncode}, out={output[:200]}")
    except subprocess.TimeoutExpired:
        results.append((test_id, desc, "TIMEOUT"))
        print(f"  TIMEOUT {test_id}: {desc}")
    except Exception as e:
        failed += 1
        results.append((test_id, desc, "ERROR"))
        print(f"  ERROR {test_id}: {desc} -- {e}")


def api_check(path, port=8770, expect=200):
    try:
        r = urllib.request.urlopen(f"http://localhost:{port}{path}", timeout=10)
        return r.status == expect
    except urllib.error.HTTPError as e:
        return e.code == expect
    except Exception:
        return False


# ===== PHASE 1: CLI Commands =====
print("=== Phase 1: CLI Commands ===")

print("--- Setup ---")
run("1.3", "Version", "sentrik version")
run("1.9", "Validate config", "sentrik validate-config")

print("--- Core Scanning ---")
run("2.1", "Full scan", "sentrik scan")
run("2.7", "Gate", "sentrik gate", lambda r, o: True)

print("--- Standards Packs ---")
run("3.1", "List packs", "sentrik list-packs", lambda r, o: "Total:" in o)
run("3.12", "Export pack", "sentrik export-pack owasp-top-10")

print("--- Supply Chain ---")
run("4.1", "SBOM", "sentrik sbom")
run("4.3", "Vulns", "sentrik vulns", lambda r, o: True)
run("4.5", "Licenses", "sentrik licenses", lambda r, o: True)
run("4.6", "Secrets", "sentrik secrets", lambda r, o: True)

print("--- Code Intelligence ---")
run("5.1", "Quality score", "sentrik quality-score --verbose")
run("5.4", "Quality JSON", "sentrik quality-score --verbose --json", lambda r, o: "overall" in o)
run("5.5", "Profile", "sentrik profile")
run("5.6", "Profile show", "sentrik profile --show")
run("5.11", "Expertise profile", "sentrik check-expertise --profile", lambda r, o: True)
run("5.14", "Metrics", "sentrik metrics")
run("5.15", "Compare", "sentrik compare", lambda r, o: True)

print("--- Compliance & Reporting ---")
run("7.1", "Report list", "sentrik compliance-report --list")
run("7.3", "All reports", "sentrik compliance-report")
run("7.6", "Trust center", 'sentrik trust-center --org "MedAPI Inc"')
run("7.7", "Trust center JSON", "sentrik trust-center --json")
run("7.8", "Attestation", "sentrik attest")
run("7.11", "Risk summary", 'sentrik risk-summary --org "MedAPI Inc"')
run("7.12", "Compliance trend", "sentrik compliance-trend", lambda r, o: True)
run("7.13", "Next action", "sentrik next-action -n 5", lambda r, o: True)
run("7.14", "Drift scan", "sentrik drift-scan", lambda r, o: True)

print("--- Evidence Map ---")
run("NEW.1", "Compliance map", "sentrik compliance-map")
run("NEW.2", "Compliance map JSON", "sentrik compliance-map --json", lambda r, o: "coverage_percent" in o)

print("--- License ---")
run("L.1", "License status", "sentrik license")

print("--- CI Outputs ---")
run("15.3", "SARIF valid", 'python -c "import json; json.load(open(\'out/report.sarif.json\'))"')
run("15.4", "JUnit valid", 'python -c "import xml.etree.ElementTree as ET; ET.parse(\'out/report.xml\')"')

print("--- Governance ---")
run("16.1", "Reconcile dry-run", "sentrik reconcile --dry-run", lambda r, o: True)
run("16.3", "Generate reqs", "sentrik generate-reqs --dry-run", lambda r, o: True)
run("16.4", "Verify reqs", "sentrik verify-reqs", lambda r, o: True)
run("16.10", "Auditor create", 'sentrik auditor create --name "Test" --email test@test.com', lambda r, o: True)
run("16.13", "Org dashboard", "sentrik org-dashboard", lambda r, o: True)

print("--- Analysis ---")
run("17.2", "Policy check", "sentrik check-policies", lambda r, o: True)
run("17.4", "Inline check", "sentrik check-inline --context server/app.py", lambda r, o: True)
run("17.5", "MCP audit", "sentrik audit-mcp", lambda r, o: True)


# ===== PHASE 2: REST API =====
print("\n=== Phase 2: REST API ===")

PORT = 8770
srv = subprocess.Popen(
    ["python", "-m", "uvicorn", "guard.server:app", "--host", "127.0.0.1", "--port", str(PORT)],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
)
time.sleep(5)

api_tests = [
    ("14.1", "Health check", "/health"),
    ("14.2", "Metrics", "/api/metrics"),
    ("14.3", "Findings", "/api/findings"),
    ("14.4", "Packs list", "/api/packs"),
    ("14.5", "Config", "/api/config"),
    ("14.6", "Quality score", "/api/quality-score"),
    ("14.7", "Threat model", "/api/threat-model"),
    ("14.8", "Design decisions", "/api/design-decisions"),
    ("14.9", "Attestation", "/api/attestation"),
    ("API.1", "Compliance map", "/api/compliance-map"),
    ("API.2", "Posture", "/api/posture"),
    ("API.3", "Governance", "/api/governance"),
    ("API.4", "Audit log", "/api/audit"),
    ("API.5", "License", "/api/license"),
    ("API.6", "Compliance report", "/api/compliance-report"),
    ("API.7", "Developer profiles", "/api/developer-profiles"),
    ("API.8", "Project profile", "/api/project-profile"),
]

for tid, desc, path in api_tests:
    ok = api_check(path, PORT)
    status = "PASS" if ok else "FAIL"
    if ok:
        passed += 1
    else:
        failed += 1
    results.append((tid, desc, status))
    print(f"  {status} {tid}: {desc}")

srv.terminate()
srv.wait()


# ===== PHASE 3: Integration =====
print("\n=== Phase 3: Integration ===")
run("15.3b", "SARIF has findings", 'python -c "import json; d=json.load(open(\'out/report.sarif.json\')); print(len(d.get(\'runs\',[])))"')
run("19.1", "No config dir scan", "sentrik scan", lambda r, o: True)
run("V.1", "Attestation verify", "sentrik attest --verify out/attestation.json", lambda r, o: True)


# ===== SUMMARY =====
print(f"\n{'='*50}")
print(f"TOTAL: {passed} passed, {failed} failed, {len(results)} total")
print(f"{'='*50}")

fails = [r for r in results if r[2] != "PASS"]
if fails:
    print("\nFailed tests:")
    for tid, desc, status in fails:
        print(f"  {status}: {tid} -- {desc}")
else:
    print("\nAll tests passed!")
