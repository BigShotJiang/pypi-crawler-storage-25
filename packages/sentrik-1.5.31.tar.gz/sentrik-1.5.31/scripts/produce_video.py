"""Produce a narrated Sentrik demo video.

Uses edge-tts for voice, Playwright for dashboard captures,
Pillow for title cards, and ffmpeg for stitching.
"""

import asyncio
import json
import os
import subprocess
import sys
import time
from pathlib import Path

# Config
OUTPUT_DIR = Path("C:/Users/mgerh/sentrik-demo-medapi/recordings/video")
DASHBOARD_URL = "http://localhost:8800/dashboard"
FFMPEG = None
WIDTH, HEIGHT = 1920, 1080
FPS = 30
VOICE = "en-US-GuyNeural"  # Professional male voice

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def get_ffmpeg():
    global FFMPEG
    if FFMPEG is None:
        import imageio_ffmpeg
        FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
    return FFMPEG


# ── Sections: (id, title_text, narration, visual_type, visual_data) ──

SECTIONS = [
    {
        "id": "01-intro",
        "title": "Sentrik",
        "subtitle": "Governance Runtime for AI-Generated Code",
        "narration": (
            "Today I'm going to show you Sentrik, a tool that solves a problem "
            "every engineering team using AI is about to face. "
            "AI coding agents like Claude Code and Cursor are writing more code than ever. "
            "But that code still needs to comply with regulations. HIPAA, SOC 2, OWASP, "
            "IEC 62304, PCI DSS, depending on your industry. "
            "Right now, teams are catching compliance issues weeks or months after the code ships, "
            "usually when an auditor finds it. "
            "Sentrik catches it before the code merges. And it doesn't just find what's wrong. "
            "It proves what's right. Let me show you."
        ),
        "visual": "title",
    },
    {
        "id": "02-scan",
        "title": "First Scan",
        "subtitle": "526 rules across 22 regulatory frameworks",
        "narration": (
            "I'm using a real project, VitalSync Medical API. It's a FastAPI service "
            "for patient vitals from wearable devices. Heart rate, blood pressure, oxygen saturation. "
            "All protected health information under HIPAA. "
            "This project needs to comply with four regulations simultaneously: "
            "IEC 62304 for medical devices, HIPAA for patient data, OWASP for web security, "
            "and SOC 2 for trust services. "
            "Sentrik scans every file against 526 rules in about 30 seconds. "
            "Every finding maps to a specific regulatory clause. "
            "Not just you have a bug. It's you're violating HIPAA section 164 point 312."
        ),
        "visual": "dashboard",
        "tab": "overview",
    },
    {
        "id": "03-findings",
        "title": "Findings",
        "subtitle": "Every finding maps to a regulatory clause",
        "narration": (
            "Here's the findings view. Each finding shows the file, line number, "
            "regulatory clause, and code snippet. I can filter by severity, "
            "click Critical to see just the blockers. "
            "Every finding includes a risk score with exploitability, blast radius, "
            "and data sensitivity. So you prioritize by actual risk, not just severity labels. "
            "And watch this. I click Fix with AI, and an AI chat panel opens "
            "about this specific finding. It explains the vulnerability, "
            "suggests a fix, and can apply it directly. "
            "Compliance officers can triage findings without opening an IDE."
        ),
        "visual": "dashboard",
        "tab": "findings",
    },
    {
        "id": "04-evidence",
        "title": "Compliance Evidence Map",
        "subtitle": "The feature no competitor has",
        "narration": (
            "Now the feature that no other tool has. The Compliance Evidence Map. "
            "Every other security tool tells you what's wrong. "
            "Sentrik also tells you what's right. "
            "Look at the summary. Coverage percentage, requirements met, violated, "
            "manual review, not applicable. "
            "Each row is a regulatory requirement. The green MET badges show where "
            "your code satisfies the requirement, with the exact file and line number. "
            "For example, this HIPAA requirement for audit logging. "
            "Sentrik found that audit logging is implemented in the audit middleware, line 14. "
            "That's not a finding. That's proof of compliance. "
            "When an auditor asks show me where you implement encryption at rest, "
            "you open this page. This is audit evidence generated automatically on every scan."
        ),
        "visual": "dashboard",
        "tab": "evidence",
    },
    {
        "id": "05-quality",
        "title": "Quality Score",
        "subtitle": "0-100 across 6 dimensions",
        "narration": (
            "Sentrik doesn't just check compliance. It understands your code. "
            "The quality score rates your project zero to one hundred across six dimensions. "
            "Compliance, complexity, test coverage, documentation, consistency, "
            "and dependency health. You can set a minimum threshold in the gate "
            "so quality doesn't degrade over time."
        ),
        "visual": "dashboard",
        "tab": "quality",
    },
    {
        "id": "06-threats",
        "title": "Threat Modeling",
        "subtitle": "STRIDE analysis powered by AI",
        "narration": (
            "STRIDE threat modeling. Sentrik analyzes your code for spoofing, "
            "tampering, repudiation, information disclosure, denial of service, "
            "and elevation of privilege threats. "
            "Each threat can be discussed with AI and tracked to resolution."
        ),
        "visual": "dashboard",
        "tab": "threats",
    },
    {
        "id": "07-cicd",
        "title": "CI/CD Integration",
        "subtitle": "One line in your workflow",
        "narration": (
            "Getting Sentrik into your CI pipeline is one line. "
            "The Sentrik GitHub Action installs the tool, runs the gate, "
            "uploads SARIF results to GitHub Code Scanning, "
            "and attaches findings as artifacts. No configuration needed. "
            "We also have a VS Code extension on the Marketplace. "
            "It scans on every save, shows findings inline, "
            "and has a button to open this dashboard directly from your IDE. "
            "And for AI coding agents, Claude Code, Cursor, and Cline, "
            "Sentrik runs as an MCP server. The AI checks compliance rules "
            "before writing code, so generated code passes the gate on the first try."
        ),
        "visual": "title",
    },
    {
        "id": "08-pricing",
        "title": "Start Free. No Credit Card.",
        "subtitle": "5 packs, 158 rules, forever free",
        "narration": (
            "Sentrik replaces 8 to 12 tools with one CLI command. "
            "22 regulatory frameworks. 526 rules. "
            "Gates every PR. Generates audit evidence automatically. "
            "And with the Evidence Map, proves where your code satisfies "
            "each requirement. Not just where it fails. "
            "The free tier includes five standards packs with 158 rules. "
            "No credit card, no time limit. "
            "Install it, scan your project, and see what it finds. "
            "N P M install dash G sentrik. Sentrik scan. That's it."
        ),
        "visual": "title",
    },
]


# ── Step 1: Generate voice-over audio ──

async def generate_audio():
    """Generate TTS audio for each section."""
    import edge_tts

    for section in SECTIONS:
        audio_path = OUTPUT_DIR / f"{section['id']}.mp3"
        if audio_path.exists():
            print(f"  Audio exists: {section['id']}")
            continue

        print(f"  Generating audio: {section['id']}...")
        communicate = edge_tts.Communicate(section["narration"], VOICE, rate="-5%")
        await communicate.save(str(audio_path))
    print("Audio generation complete.")


# ── Step 2: Capture dashboard screenshots ──

def capture_dashboard():
    """Capture dashboard tab screenshots using Playwright."""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": WIDTH, "height": HEIGHT})

        for section in SECTIONS:
            if section.get("visual") != "dashboard":
                continue

            img_path = OUTPUT_DIR / f"{section['id']}.png"
            if img_path.exists():
                print(f"  Screenshot exists: {section['id']}")
                continue

            tab = section.get("tab", "overview")
            print(f"  Capturing: {section['id']} (tab: {tab})...")

            page.goto(DASHBOARD_URL)
            time.sleep(3)

            # Click the tab
            page.click(f'[data-tab="{tab}"]')
            time.sleep(4)

            page.screenshot(path=str(img_path))

        browser.close()
    print("Dashboard capture complete.")


# ── Step 3: Create title cards ──

def create_title_cards():
    """Create title card images using Pillow."""
    from PIL import Image, ImageDraw, ImageFont

    for section in SECTIONS:
        if section.get("visual") != "title":
            continue

        img_path = OUTPUT_DIR / f"{section['id']}.png"
        if img_path.exists():
            print(f"  Title card exists: {section['id']}")
            continue

        print(f"  Creating title card: {section['id']}...")

        img = Image.new("RGB", (WIDTH, HEIGHT), color=(13, 17, 23))
        draw = ImageDraw.Draw(img)

        # Try to load a nice font, fall back to default
        try:
            title_font = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 72)
            sub_font = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 36)
        except (IOError, OSError):
            title_font = ImageFont.load_default()
            sub_font = ImageFont.load_default()

        title = section["title"]
        subtitle = section.get("subtitle", "")

        # Center title
        bbox = draw.textbbox((0, 0), title, font=title_font)
        tw = bbox[2] - bbox[0]
        tx = (WIDTH - tw) // 2
        ty = HEIGHT // 2 - 80
        draw.text((tx, ty), title, fill=(230, 237, 243), font=title_font)

        # Center subtitle
        if subtitle:
            bbox2 = draw.textbbox((0, 0), subtitle, font=sub_font)
            sw = bbox2[2] - bbox2[0]
            sx = (WIDTH - sw) // 2
            sy = ty + 100
            draw.text((sx, sy), subtitle, fill=(139, 148, 158), font=sub_font)

        # Purple accent line
        line_y = ty + 85
        draw.rectangle([(WIDTH // 2 - 60, line_y), (WIDTH // 2 + 60, line_y + 4)], fill=(99, 102, 241))

        img.save(str(img_path))

    print("Title cards complete.")


# ── Step 4: Get audio durations ──

def get_duration(audio_path):
    """Get audio duration in seconds using ffprobe."""
    ffmpeg = get_ffmpeg()
    ffprobe = ffmpeg.replace("ffmpeg", "ffprobe")
    if not Path(ffprobe).exists():
        # Fallback: use ffmpeg to probe
        result = subprocess.run(
            [ffmpeg, "-i", str(audio_path), "-f", "null", "-"],
            capture_output=True, text=True,
        )
        # Parse duration from stderr
        for line in result.stderr.split("\n"):
            if "Duration:" in line:
                parts = line.split("Duration:")[1].split(",")[0].strip()
                h, m, s = parts.split(":")
                return float(h) * 3600 + float(m) * 60 + float(s)
    else:
        result = subprocess.run(
            [ffprobe, "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(audio_path)],
            capture_output=True, text=True,
        )
        return float(result.stdout.strip())
    return 10.0  # fallback


# ── Step 5: Stitch into final video ──

def stitch_video():
    """Combine images + audio into final video using ffmpeg."""
    ffmpeg = get_ffmpeg()

    # Build concat file and combine audio
    segments = []
    audio_files = []

    for section in SECTIONS:
        img_path = OUTPUT_DIR / f"{section['id']}.png"
        audio_path = OUTPUT_DIR / f"{section['id']}.mp3"

        if not img_path.exists() or not audio_path.exists():
            print(f"  SKIP: {section['id']} (missing files)")
            continue

        duration = get_duration(audio_path)
        # Add 1.5 seconds padding
        duration += 1.5

        # Create video segment from still image + audio
        segment_path = OUTPUT_DIR / f"{section['id']}_segment.mp4"
        print(f"  Segment: {section['id']} ({duration:.1f}s)")

        subprocess.run([
            ffmpeg, "-y",
            "-loop", "1", "-i", str(img_path),
            "-i", str(audio_path),
            "-c:v", "libx264", "-tune", "stillimage",
            "-c:a", "aac", "-b:a", "192k",
            "-pix_fmt", "yuv420p",
            "-t", str(duration),
            "-shortest",
            str(segment_path),
        ], capture_output=True)

        segments.append(segment_path)

    if not segments:
        print("ERROR: No segments to combine")
        return

    # Write concat file
    concat_file = OUTPUT_DIR / "concat.txt"
    with open(concat_file, "w") as f:
        for seg in segments:
            f.write(f"file '{seg.name}'\n")

    # Combine all segments
    final_path = OUTPUT_DIR / "sentrik-demo.mp4"
    print(f"\n  Stitching {len(segments)} segments into final video...")

    subprocess.run([
        ffmpeg, "-y",
        "-f", "concat", "-safe", "0",
        "-i", str(concat_file),
        "-c:v", "libx264", "-crf", "23",
        "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart",
        str(final_path),
    ], capture_output=True, cwd=str(OUTPUT_DIR))

    if final_path.exists():
        size_mb = final_path.stat().st_size / 1024 / 1024
        print(f"\n  DONE: {final_path}")
        print(f"  Size: {size_mb:.1f} MB")
    else:
        print("\n  ERROR: Final video not created")


# ── Main ──

def main():
    print("=" * 50)
    print("Sentrik Demo Video Producer")
    print("=" * 50)

    print("\nStep 1: Generating voice-over audio...")
    asyncio.run(generate_audio())

    print("\nStep 2: Capturing dashboard screenshots...")
    capture_dashboard()

    print("\nStep 3: Creating title cards...")
    create_title_cards()

    print("\nStep 4: Stitching video...")
    stitch_video()

    print("\n" + "=" * 50)
    print("Video production complete!")
    print("=" * 50)


if __name__ == "__main__":
    main()
