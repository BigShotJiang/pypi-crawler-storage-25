"""Thin wrapper that downloads and delegates to the SENTRIK binary.

This package does not contain source code. On first run it downloads the
platform-specific compiled binary from GitHub Releases.
"""

from __future__ import annotations

import os
import platform
import stat
import subprocess
import sys
import urllib.request
from pathlib import Path

__version__ = "1.2.0"

# GitHub release URL pattern
_GITHUB_RELEASE = "https://github.com/maxgerhardson/sentrik/releases/download/v{version}"

_PLATFORM_MAP = {
    ("Linux", "x86_64"): "sentrik-linux-x64",
    ("Linux", "aarch64"): "sentrik-linux-arm64",
    ("Darwin", "x86_64"): "sentrik-darwin-x64",
    ("Darwin", "arm64"): "sentrik-darwin-arm64",
    ("Windows", "AMD64"): "sentrik-win32-x64.exe",
}


def _bin_dir() -> Path:
    """Return the directory where the binary is stored."""
    return Path(__file__).parent / "bin"


def _binary_path() -> Path:
    """Return the expected path to the sentrik binary."""
    ext = ".exe" if sys.platform == "win32" else ""
    return _bin_dir() / f"sentrik{ext}"


def _asset_name() -> str:
    """Determine the correct release asset name for this platform."""
    system = platform.system()
    machine = platform.machine()
    key = (system, machine)
    asset = _PLATFORM_MAP.get(key)
    if not asset:
        print(
            f"sentrik: unsupported platform {system}-{machine}\n"
            f"Supported: {', '.join(f'{s}-{m}' for s, m in sorted(_PLATFORM_MAP))}",
            file=sys.stderr,
        )
        sys.exit(1)
    return asset


def _download_binary() -> Path:
    """Download the binary from GitHub Releases."""
    bin_path = _binary_path()
    if bin_path.exists():
        return bin_path

    asset = _asset_name()
    url = f"{_GITHUB_RELEASE.format(version=__version__)}/{asset}"

    print(f"sentrik: downloading binary for {platform.system()}-{platform.machine()}...")
    print(f"  {url}")

    bin_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        urllib.request.urlretrieve(url, bin_path)
    except Exception as exc:
        print(f"sentrik: failed to download binary: {exc}", file=sys.stderr)
        print(
            "\nAlternatives:\n"
            "  1. Download manually from https://github.com/maxgerhardson/sentrik/releases\n"
            "  2. Use npm: npm install -g sentrik\n"
            "  3. Use Docker: docker run maxgerhardson/sentrik",
            file=sys.stderr,
        )
        sys.exit(1)

    # Make executable on Unix
    if sys.platform != "win32":
        bin_path.chmod(bin_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    print("sentrik: binary installed successfully\n")
    return bin_path


def main():
    """Entry point: download binary if needed, then delegate."""
    binary = _download_binary()
    result = subprocess.run(
        [str(binary), *sys.argv[1:]],
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
