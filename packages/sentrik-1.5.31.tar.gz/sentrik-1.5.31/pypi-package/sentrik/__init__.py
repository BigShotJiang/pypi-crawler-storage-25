"""SENTRIK - governance runtime for AI-generated code."""

__version__ = "1.2.0"
