# Sentrik

**Governance runtime for AI-generated code.** Scan, gate, and trace compliance automatically.

## Install

```bash
pip install sentrik
```

On first run, Sentrik downloads the platform-specific binary (~45 MB). Supported platforms:
- Linux x86_64 / ARM64
- macOS x86_64 / Apple Silicon
- Windows x86_64

## Quick Start

```bash
# Initialize project config
sentrik init

# Scan your code
sentrik scan

# Enforce the gate (exit 1 on failure)
sentrik gate
```

## Free Tier

Sentrik includes 5 standards packs for free, forever:
- **OWASP Top 10** (69 rules) - Web application security
- **SOC 2** (30 rules) - Trust services compliance
- **Python Security** (18 rules) - Python-specific vulnerabilities
- **Go Security** (15 rules) - Go-specific vulnerabilities
- **Supply Chain Security** (26 rules) - SLSA, SBOM, dependency integrity

## Upgrade

Unlock 11 more compliance packs (HIPAA, PCI-DSS, ISO 27001, FDA IEC 62304, GDPR, and more) with a Team license.

Visit [sentrik.dev](https://sentrik.dev) for more information.

## Documentation

- [Getting Started](https://docs.sentrik.dev)
- [CLI Reference](https://docs.sentrik.dev/cli/)
- [Standards Packs](https://docs.sentrik.dev/packs/)

## Alternative Install Methods

```bash
# npm
npm install -g sentrik

# Docker
docker run maxgerhardson/sentrik scan

# Direct binary
# Download from https://github.com/maxgerhardson/sentrik/releases
```

## License

Proprietary. Free tier available. See [sentrik.dev](https://sentrik.dev).
