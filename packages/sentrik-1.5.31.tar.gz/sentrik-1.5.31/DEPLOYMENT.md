# SENTRA Deployment Checklist

Step-by-step guide to deploy all SENTRA services and publish the package.

## Repositories

| Repo | URL | Visibility |
|------|-----|-----------|
| **sentra** (main) | github.com/maxgerhardson/sentra | Private |
| **sentra-website** | github.com/maxgerhardson/sentra-website | Public |
| **sentra-portal** | github.com/maxgerhardson/sentra-portal | Private |
| **sentra-example-medfiles** | github.com/maxgerhardson/sentra-example-medfiles | Public |
| **homebrew-sentra** | github.com/maxgerhardson/homebrew-sentra | Public |

---

## 1. PyPI — `pip install sentra`

### Setup (one-time)
1. Create account at [pypi.org](https://pypi.org/account/register/)
2. Create project `sentra`: upload first build manually or via trusted publisher
3. Configure Trusted Publisher at pypi.org/manage/project/sentra/settings/publishing/:
   - Repository: `maxgerhardson/sentra`
   - Workflow: `release.yml`
   - Environment: `pypi`

### Verify
```bash
pip install sentra
sentra --help
sentra scan
```

---

## 2. Docker Hub — `docker pull maxgerhardson/sentra`

### Setup (one-time)
1. Create account at [hub.docker.com](https://hub.docker.com/)
2. Create repository `maxgerhardson/sentra` (public)
3. Add GitHub repo secrets:
   - `DOCKERHUB_USERNAME` = `maxgerhardson`
   - `DOCKERHUB_TOKEN` = Docker Hub access token (hub.docker.com/settings/security)

### Also: Make GHCR image public
1. Go to github.com/maxgerhardson/sentra/packages
2. Click the package → Package settings → Change visibility → Public

### Verify
```bash
docker pull maxgerhardson/sentra:latest
docker run --rm maxgerhardson/sentra --help
```

---

## 3. Website — sentra.dev (Netlify)

### Setup (one-time)
1. Go to [app.netlify.com](https://app.netlify.com/) → New site from Git
2. Connect `maxgerhardson/sentra-website`
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Set custom domain: `sentra.dev`
6. Enable HTTPS (automatic with Netlify)

### DNS
Add to your domain registrar:
```
CNAME  sentra.dev  → <your-netlify-site>.netlify.app
```

### Verify
- https://sentra.dev loads
- All pages render correctly
- Mobile responsive

---

## 4. Documentation — docs.sentra.dev (GitHub Pages)

### Setup (one-time)
1. Go to github.com/maxgerhardson/sentra → Settings → Pages
2. Source: GitHub Actions
3. The `docs.yml` workflow deploys automatically on push to main

### DNS
```
CNAME  docs.sentra.dev  → maxgerhardson.github.io
```

### Verify
- https://docs.sentra.dev loads
- Navigation works, search works
- All 14+ pages render

---

## 5. License Portal — portal.sentra.dev (Railway)

### Setup (one-time)
1. Go to [railway.app](https://railway.app/) → New Project → Deploy from GitHub
2. Connect `maxgerhardson/sentra-portal`
3. Set environment variables:
   - `STRIPE_SECRET_KEY` — from Stripe dashboard
   - `STRIPE_WEBHOOK_SECRET` — from Stripe webhook settings
   - `STRIPE_PRICE_TEAM` — Stripe price ID for Team tier
   - `STRIPE_PRICE_ORG` — Stripe price ID for Org tier
   - `STRIPE_PRICE_ENTERPRISE` — Stripe price ID for Enterprise tier
   - `GUARD_LICENSE_SECRET` — production HMAC secret (must match main SENTRA)
   - `SENDGRID_API_KEY` — from SendGrid dashboard
   - `SENDGRID_FROM_EMAIL` — `hello@sentra.dev`
   - `PORTAL_URL` — `https://portal.sentra.dev`
4. Set custom domain: `portal.sentra.dev`

### Stripe Products
1. Go to [dashboard.stripe.com/products](https://dashboard.stripe.com/products)
2. Create 3 products:
   - **SENTRA Team** — $29/mo recurring
   - **SENTRA Org** — $99/mo recurring
   - **SENTRA Enterprise** — $299/mo recurring
3. Copy each price ID (starts with `price_`) into Railway env vars
4. Set up webhook:
   - Endpoint: `https://portal.sentra.dev/webhook/stripe`
   - Events: `checkout.session.completed`

### DNS
```
CNAME  portal.sentra.dev  → <your-railway-app>.up.railway.app
```

### Verify
- https://portal.sentra.dev loads
- https://portal.sentra.dev/health returns `{"status": "ok"}`
- Stripe test checkout works end-to-end

---

## 6. Demo — demo.sentra.dev (Fly.io)

### Setup (one-time)
```bash
cd ai_sdlc_guard
fly launch --dockerfile Dockerfile.demo --name sentra-demo --region iad
fly secrets set GUARD_API_KEY=demo-readonly-key
fly deploy
```

### DNS
```
CNAME  demo.sentra.dev  → sentra-demo.fly.dev
```

### Verify
- https://demo.sentra.dev/dashboard loads
- Pre-loaded MedFiles findings visible
- Write endpoints disabled

---

## 7. Analytics — Plausible

### Setup (one-time)
1. Go to [plausible.io](https://plausible.io/) → Sign up ($9/mo)
2. Add site: `sentra.dev`
3. Script tag already added to website layout

### Verify
- Visit sentra.dev → check plausible.io dashboard for pageview

---

## 8. Homebrew — `brew install sentra`

### Setup (per release)
1. Build macOS binary in release workflow
2. Compute SHA: `shasum -a 256 guard-macos-amd64`
3. Update `homebrew-sentra/Formula/sentra.rb`:
   - `url` → release download URL
   - `sha256` → computed hash
   - `version` → release version

### Verify
```bash
brew tap maxgerhardson/sentra
brew install sentra
sentra --help
```

---

## 9. GitHub Repo Settings

### Enable GitHub Discussions
1. Go to github.com/maxgerhardson/sentra → Settings → Features
2. Check "Discussions"
3. Discussion templates are already in `.github/DISCUSSION_TEMPLATE/`

### Issue Templates
Already configured in `.github/ISSUE_TEMPLATE/`

---

## 10. First Release — Tag v1.0.0

After all services are configured:

```bash
cd ai_sdlc_guard
git tag v1.0.0
git push origin v1.0.0
```

This triggers `.github/workflows/release.yml` which:
- Builds and publishes to PyPI
- Builds and pushes Docker images to GHCR + Docker Hub
- Creates GitHub Release with binaries

---

## Monthly Costs

| Service | Cost |
|---------|------|
| Fly.io (demo) | ~$7/mo |
| Railway (portal) | ~$5/mo |
| Plausible (analytics) | $9/mo |
| Domain (sentra.dev) | ~$1/mo (~$12/yr) |
| Stripe | 2.9% + $0.30/transaction |
| **Total** | **~$22/mo** |
