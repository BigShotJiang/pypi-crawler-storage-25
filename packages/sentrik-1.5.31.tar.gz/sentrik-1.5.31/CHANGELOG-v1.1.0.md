# Sentrik v1.1.0 Release Notes

## 🎯 Major Features

### 🔒 Security Enhancements
- **Fixed 11 critical security issues** including XSS, SSRF, race conditions, and authentication bypasses
- **Thread-safe operations** for approval store, license cache, and metrics handling
- **Input validation** for WIQL queries, JQL queries, and webhook URLs
- **Enhanced authentication** for OAuth endpoints and API routes

### 🧠 AI & Compliance Intelligence  
- **Real-time LSP server** for as-you-type compliance scanning in VS Code
- **AI supply chain rules** with CISA KEV vulnerability tagging
- **Threat modeling** with STRIDE-based analysis and mitigation recommendations
- **Design decision auditing** with expertise gap detection and escalation
- **Quality scoring** with project profiling and MCP design constraints

### 📊 Dashboard & API Expansion
- **Vue 3 + Vite dashboard** with 5 new tabs (Threat Model, Design Review, Quality, Expertise, Project Profile)
- **86 new tests** bringing coverage above 70%
- **Enhanced audit logging** with scan, gate, fix, and suppression events
- **Multi-agent architecture** for compliance scanning orchestration

### 📚 Standards Packs Expansion
- **15 total standards packs** (up from 6) with 386 rules (up from 97)
- **New packs**: EU AI Act (47 rules), GDPR (47 rules), NIST 800-53 (28 rules), CMMC (12 rules), Python Security (18 rules), NIST AI RMF (16 rules), Go Security (15 rules), Supply Chain Security (20 rules)
- **Pack versioning** with `sentrik diff-packs` command for change tracking
- **Conditional obligations** with `applies_when` rules

### ⚙️ Workflow Optimizations
- **Smart triage** with `--actionable-only` and `--ai-mode` filtering
- **Progressive disclosure** via `sentrik next-action` command  
- **Compliance trending** with `sentrik compliance-trend` and `sentrik risk-summary`
- **Context-aware scanning** based on development phase and file types
- **Requirement drift analysis** with `sentrik drift-scan`

## 🔧 CLI Enhancements

### New Commands
- `sentrik review-design` - Design decision auditing with expertise tracking
- `sentrik threat-model` - STRIDE-based threat modeling and mitigation
- `sentrik gap-analysis` - Regulatory gap analysis across frameworks
- `sentrik attest` - Signed compliance attestation generation
- `sentrik drift-scan` - Context-aware requirement drift detection
- `sentrik diff-packs` - Compare standards pack versions
- `sentrik import-spec` - Generate rules from API specifications
- `sentrik next-action` - Progressive disclosure of actionable items
- `sentrik compliance-trend` - Track compliance scores over time
- `sentrik risk-summary` - High-level risk assessment dashboard

### Enhanced Commands
- **Enhanced `sentrik scan`** with AI-mode filtering and smart triage
- **Improved `sentrik gate`** with auto-fix suggestions and suppression recommendations
- **Extended `sentrik dashboard`** with 5 new tabs and AI chat integration

## 🏗️ Architecture Improvements

### Performance & Reliability
- **Multi-agent scanning** with parallel processing capabilities
- **Enhanced caching** with thread-safe operations and race condition fixes
- **Rate limiting controls** with runtime configuration
- **Robust error handling** with detailed logging and recovery mechanisms

### Integration & Extensibility  
- **MCP server support** for AI coding assistant integration
- **LSP server** for real-time IDE compliance feedback
- **Enhanced DevOps providers** with Azure DevOps and Jira improvements
- **API expansion** with 25+ new endpoints for dashboard integration

## 📖 Documentation Updates

### New Documentation
- **195-test manual test plan** for comprehensive release validation
- **EU AI Act and GDPR pack guides** with compliance mapping
- **4 new standards pack pages** with detailed rule documentation
- **Enhanced dashboard guide** with new tab walkthroughs
- **AI-generated code security guide** with best practices

### Improved Documentation  
- **Updated CLI reference** with 15+ new commands
- **Corrected pack counts** and rule numbers throughout documentation
- **Enhanced architecture documentation** with multi-agent patterns
- **Comprehensive API documentation** with authentication details

## 🐛 Bug Fixes

### Critical Security Fixes
- **XSS prevention** in OAuth callback URL handling
- **SSRF protection** for webhook POST requests  
- **Authentication enforcement** on previously unprotected endpoints
- **Race condition resolution** in license cache and approval store
- **Input validation** for WIQL and JQL injection prevention

### Stability Improvements
- **Fixed 16 pre-existing CI failures** with comprehensive test suite updates
- **Unicode handling** improvements in scan pipeline
- **CORS headers** addition for proper API access
- **Configuration error handling** with better user feedback
- **File globbing fixes** for accurate file discovery

## 📊 Statistics

- **Total Rules**: 386 (up from 97)  
- **Standards Packs**: 15 (up from 6)
- **Test Coverage**: >70% (up from ~20%)
- **New Tests**: 86 additional test cases
- **Security Fixes**: 11 critical vulnerabilities resolved
- **New Commands**: 10+ CLI commands added
- **Dashboard Components**: 5 new Vue.js components
- **API Endpoints**: 25+ new REST endpoints

## 🚀 Getting Started

```bash
# Install latest version
npm install -g sentrik@1.1.0

# Verify installation
sentrik --version

# Start with auto-detection
sentrik scan

# Open enhanced dashboard
sentrik dashboard
```

## 🔄 Migration Notes

### Breaking Changes
- **None** - Full backward compatibility maintained
- **Legacy `.guard.yaml`** files still supported alongside new `.sentrik/config.yaml`
- **All existing CLI commands** continue to work unchanged

### Recommended Actions
1. **Update standards packs**: Run `sentrik list-packs` to see new options
2. **Try new commands**: Explore `sentrik next-action` and `sentrik threat-model`  
3. **Enable real-time scanning**: Install VS Code extension for LSP integration
4. **Review dashboard**: Explore new Threat Model and Quality tabs

## 💝 Acknowledgments

Special thanks to the security research community for responsible vulnerability disclosure and to early adopters providing feedback on the AI compliance workflows.

---

**Full changelog**: All commits since project inception  
**Security advisories**: All 11 security issues resolved in this release  
**Documentation**: Available at [docs.sentrik.dev](https://docs.sentrik.dev)