<script setup lang="ts">
import { onMounted, ref, computed, markRaw, type Component } from 'vue'
import { useDashboardStore } from './stores/dashboard'
import { useTheme } from './composables/useTheme'
import { useKeyboard } from './composables/useKeyboard'

import AppHeader from './components/AppHeader.vue'
import AppSidebar from './components/AppSidebar.vue'
import SearchOverlay from './components/SearchOverlay.vue'
import HelpOverlay from './components/HelpOverlay.vue'
import ToastNotification from './components/ToastNotification.vue'

import OverviewPage from './pages/OverviewPage.vue'
import FindingsPage from './pages/FindingsPage.vue'
import VulnsPage from './pages/VulnsPage.vue'
import HistoryPage from './pages/HistoryPage.vue'
import RulesPage from './pages/RulesPage.vue'
import PacksPage from './pages/PacksPage.vue'
import ReportsPage from './pages/ReportsPage.vue'
import LicensesPage from './pages/LicensesPage.vue'
import WorkItemsPage from './pages/WorkItemsPage.vue'
import DevOpsPage from './pages/DevOpsPage.vue'
import PoliciesPage from './pages/PoliciesPage.vue'
import ApprovalsPage from './pages/ApprovalsPage.vue'
import AuditPage from './pages/AuditPage.vue'
import SettingsPage from './pages/SettingsPage.vue'

const store = useDashboardStore()
const { isDark, toggle: toggleTheme } = useTheme()

const searchOpen = ref(false)
const helpOpen = ref(false)
const sidebarCollapsed = ref(false)

useKeyboard({
  onSearch: () => { searchOpen.value = true },
  onHelp: () => { helpOpen.value = true },
  onEscape: () => { searchOpen.value = false; helpOpen.value = false },
})

const pageMap: Record<string, Component> = {
  overview: markRaw(OverviewPage),
  findings: markRaw(FindingsPage),
  vulns: markRaw(VulnsPage),
  history: markRaw(HistoryPage),
  rules: markRaw(RulesPage),
  packs: markRaw(PacksPage),
  reports: markRaw(ReportsPage),
  licenses: markRaw(LicensesPage),
  workitems: markRaw(WorkItemsPage),
  devops: markRaw(DevOpsPage),
  policies: markRaw(PoliciesPage),
  approvals: markRaw(ApprovalsPage),
  audit: markRaw(AuditPage),
  settings: markRaw(SettingsPage),
}

const activePage = computed(() => pageMap[store.activeTab] || OverviewPage)

const sidebarSections = [
  {
    label: 'Monitoring',
    items: [
      { tab: 'overview', label: 'Overview', icon: '\u25FE' },
      { tab: 'findings', label: 'Findings', icon: '\u26A0' },
      { tab: 'vulns', label: 'Vulnerabilities', icon: '\u26A1' },
      { tab: 'history', label: 'History', icon: '\u25F7' },
    ],
  },
  {
    label: 'Compliance',
    items: [
      { tab: 'rules', label: 'Rules', icon: '\u269C' },
      { tab: 'packs', label: 'Packs', icon: '\u2630' },
      { tab: 'reports', label: 'Reports', icon: '\u263E' },
      { tab: 'licenses', label: 'Licenses', icon: '\u2696' },
    ],
  },
  {
    label: 'Integrations',
    items: [
      { tab: 'workitems', label: 'Work Items', icon: '\u2611' },
      { tab: 'devops', label: 'Integration', icon: '\u25EF' },
    ],
  },
  {
    label: 'Governance',
    items: [
      { tab: 'policies', label: 'Policies', icon: '\u2696' },
      { tab: 'approvals', label: 'Approvals', icon: '\u2713' },
      { tab: 'audit', label: 'Audit Log', icon: '\u25E8' },
      { tab: 'settings', label: 'Settings', icon: '\u2699' },
    ],
  },
]

function selectTab(tab: string) {
  store.activeTab = tab
}

onMounted(() => {
  store.init()
})
</script>

<template>
  <div class="app-root">
    <AppHeader :dark-mode="isDark" @logout="toggleTheme" />

    <div class="dashboard-layout">
      <nav class="sidebar" :class="{ collapsed: sidebarCollapsed }">
        <div class="sidebar-toggle" @click="sidebarCollapsed = !sidebarCollapsed">
          <span v-if="sidebarCollapsed">&raquo;</span>
          <span v-else>&laquo;</span>
        </div>

        <template v-for="section in sidebarSections" :key="section.label">
          <div v-if="!sidebarCollapsed" class="sidebar-section-label">{{ section.label }}</div>
          <div
            v-for="item in section.items"
            :key="item.tab"
            class="sidebar-item"
            :class="{ active: store.activeTab === item.tab }"
            :title="item.label"
            @click="selectTab(item.tab)"
          >
            <span class="sidebar-icon">{{ item.icon }}</span>
            <span v-if="!sidebarCollapsed" class="sidebar-label">{{ item.label }}</span>
          </div>
        </template>
      </nav>

      <main class="content-area">
        <component :is="activePage" />
      </main>
    </div>

    <SearchOverlay :open="searchOpen" @close="searchOpen = false" @navigate="(t: string) => { selectTab(t); searchOpen = false }" />
    <HelpOverlay :open="helpOpen" @close="helpOpen = false" />
    <ToastNotification />
  </div>
</template>

<style scoped>
.app-root {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.dashboard-layout {
  display: flex;
  flex: 1;
  overflow: hidden;
}

.sidebar {
  width: 220px;
  min-width: 220px;
  background: var(--bg-secondary);
  border-right: 1px solid var(--border-light);
  padding: 8px 0;
  overflow-y: auto;
  transition: width 0.2s, min-width 0.2s;
}

.sidebar.collapsed {
  width: 48px;
  min-width: 48px;
}

.sidebar-toggle {
  text-align: center;
  padding: 4px;
  cursor: pointer;
  color: var(--text-muted);
  font-size: 12px;
  border-bottom: 1px solid var(--border-light);
  margin-bottom: 4px;
}

.sidebar-toggle:hover {
  color: var(--accent);
}

.sidebar-section-label {
  font-size: 0.65rem;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: var(--text-dimmed);
  padding: 12px 16px 4px;
  font-weight: 600;
}

.sidebar-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 16px;
  cursor: pointer;
  color: var(--text-muted);
  font-size: 0.85rem;
  border-left: 3px solid transparent;
  transition: background 0.15s, color 0.15s, border-color 0.15s;
}

.sidebar.collapsed .sidebar-item {
  justify-content: center;
  padding: 10px 0;
  gap: 0;
}

.sidebar-item:hover {
  background: var(--bg-tertiary);
  color: var(--text-primary);
}

.sidebar-item.active {
  border-left-color: var(--accent);
  color: var(--accent);
  background: var(--highlight-bg);
  font-weight: 600;
}

.sidebar-icon {
  font-size: 14px;
  width: 18px;
  text-align: center;
  flex-shrink: 0;
}

.sidebar-label {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.content-area {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  min-width: 0;
}

@media (max-width: 768px) {
  .sidebar {
    position: fixed;
    left: 0;
    top: 48px;
    bottom: 0;
    z-index: 100;
    transform: translateX(-100%);
    transition: transform 0.2s;
  }
  .sidebar.open {
    transform: translateX(0);
  }
  .content-area {
    padding: 16px;
  }
}
</style>
