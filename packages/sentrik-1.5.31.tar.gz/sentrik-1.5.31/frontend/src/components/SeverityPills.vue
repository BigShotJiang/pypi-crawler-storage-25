<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  counts: Record<string, number>
  active: Set<string>
}>()

const emit = defineEmits<{
  (e: 'toggle', severity: string): void
}>()

const severities = ['critical', 'high', 'medium', 'low', 'info'] as const

const allActive = computed(() => props.active.size === 0 || props.active.size === severities.length)

function toggleAll() {
  // Emit a special 'all' toggle that the parent can interpret
  emit('toggle', 'all')
}
</script>

<template>
  <div class="severity-pills">
    <button
      class="pill pill-all"
      :class="{ active: allActive }"
      @click="toggleAll"
    >
      All
    </button>
    <button
      v-for="sev in severities"
      :key="sev"
      class="pill"
      :class="[sev, { active: active.has(sev) }]"
      @click="emit('toggle', sev)"
    >
      {{ sev.charAt(0).toUpperCase() + sev.slice(1) }}
      <span class="pill-count">{{ counts[sev] ?? 0 }}</span>
    </button>
  </div>
</template>

<style scoped>
.severity-pills {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 12px;
  border-radius: 16px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.15s, color 0.15s, border-color 0.15s;
  border: 1.5px solid transparent;
  background: transparent;
  color: var(--text-primary);
}

.pill-count {
  font-weight: 400;
  opacity: 0.8;
}

/* Outlined (inactive) states */
.pill.critical {
  border-color: var(--sev-critical);
  color: var(--sev-critical);
}
.pill.high {
  border-color: var(--sev-high);
  color: var(--sev-high);
}
.pill.medium {
  border-color: var(--sev-medium);
  color: var(--sev-medium);
}
.pill.low {
  border-color: var(--sev-low);
  color: var(--sev-low);
}
.pill.info {
  border-color: var(--sev-info);
  color: var(--sev-info);
}

.pill-all {
  border-color: var(--border-light);
}

/* Filled (active) states */
.pill.critical.active {
  background: var(--sev-critical);
  color: #fff;
}
.pill.high.active {
  background: var(--sev-high);
  color: #fff;
}
.pill.medium.active {
  background: var(--sev-medium);
  color: #fff;
}
.pill.low.active {
  background: var(--sev-low);
  color: #fff;
}
.pill.info.active {
  background: var(--sev-info);
  color: #fff;
}
.pill-all.active {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}

.pill:hover {
  opacity: 0.85;
}
</style>
