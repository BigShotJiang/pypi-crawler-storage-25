<script setup lang="ts">
import { ref, computed, watch, nextTick } from 'vue'

const props = defineProps<{
  open: boolean
}>()

const emit = defineEmits<{
  (e: 'close'): void
  (e: 'navigate', tab: string): void
}>()

const query = ref('')
const inputRef = ref<HTMLInputElement | null>(null)

interface SearchItem {
  id: string
  label: string
  section: string
  icon: string
}

const allItems: SearchItem[] = [
  { id: 'overview', label: 'Overview', section: 'Monitoring', icon: '◾' },
  { id: 'findings', label: 'Findings', section: 'Monitoring', icon: '⚠' },
  { id: 'vulnerabilities', label: 'Vulnerabilities', section: 'Monitoring', icon: '⚡' },
  { id: 'history', label: 'History', section: 'Monitoring', icon: '◷' },
  { id: 'rules', label: 'Rules', section: 'Compliance', icon: '⚜' },
  { id: 'packs', label: 'Packs', section: 'Compliance', icon: '☰' },
  { id: 'reports', label: 'Reports', section: 'Compliance', icon: '☾' },
  { id: 'licenses', label: 'Licenses', section: 'Compliance', icon: '⚸' },
  { id: 'workitems', label: 'Work Items', section: 'Integrations', icon: '☑' },
  { id: 'integration', label: 'Integration', section: 'Integrations', icon: '◯' },
  { id: 'policies', label: 'Policies', section: 'Governance', icon: '⚸' },
  { id: 'approvals', label: 'Approvals', section: 'Governance', icon: '✓' },
  { id: 'auditlog', label: 'Audit Log', section: 'Governance', icon: '◨' },
  { id: 'settings', label: 'Settings', section: 'Settings', icon: '⚡' },
]

const selectedIndex = ref(0)

const filtered = computed(() => {
  const q = query.value.toLowerCase().trim()
  if (!q) return allItems
  return allItems.filter(
    (item) =>
      item.label.toLowerCase().includes(q) ||
      item.section.toLowerCase().includes(q) ||
      item.id.toLowerCase().includes(q)
  )
})

watch(
  () => props.open,
  (isOpen) => {
    if (isOpen) {
      query.value = ''
      selectedIndex.value = 0
      nextTick(() => inputRef.value?.focus())
    }
  }
)

watch(filtered, () => {
  selectedIndex.value = 0
})

function onKeydown(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    emit('close')
    return
  }
  if (event.key === 'ArrowDown') {
    event.preventDefault()
    selectedIndex.value = Math.min(selectedIndex.value + 1, filtered.value.length - 1)
  } else if (event.key === 'ArrowUp') {
    event.preventDefault()
    selectedIndex.value = Math.max(selectedIndex.value - 1, 0)
  } else if (event.key === 'Enter') {
    event.preventDefault()
    const item = filtered.value[selectedIndex.value]
    if (item) {
      emit('navigate', item.id)
      emit('close')
    }
  }
}

function onBackdropClick(event: MouseEvent) {
  if ((event.target as HTMLElement).classList.contains('search-overlay')) {
    emit('close')
  }
}

function selectItem(item: SearchItem) {
  emit('navigate', item.id)
  emit('close')
}
</script>

<template>
  <Teleport to="body">
    <Transition name="search">
      <div
        v-if="open"
        class="search-overlay"
        @click="onBackdropClick"
        @keydown="onKeydown"
      >
        <div class="search-card">
          <div class="search-input-row">
            <span class="search-icon">⌕</span>
            <input
              ref="inputRef"
              v-model="query"
              class="search-input"
              type="text"
              placeholder="Jump to page..."
              autocomplete="off"
            />
            <kbd class="esc-hint">Esc</kbd>
          </div>

          <div class="search-results" v-if="filtered.length > 0">
            <button
              v-for="(item, idx) in filtered"
              :key="item.id"
              class="search-result"
              :class="{ selected: idx === selectedIndex }"
              @click="selectItem(item)"
              @mouseenter="selectedIndex = idx"
            >
              <span class="result-icon">{{ item.icon }}</span>
              <span class="result-label">{{ item.label }}</span>
              <span class="result-section">{{ item.section }}</span>
            </button>
          </div>

          <div v-else class="search-empty">
            No matching pages
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.search-overlay {
  position: fixed;
  inset: 0;
  z-index: 1100;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding-top: 15vh;
  background: rgba(0, 0, 0, 0.4);
  backdrop-filter: blur(2px);
}

.search-card {
  background: var(--bg-primary);
  border: 1px solid var(--border-light);
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.25);
  width: 90vw;
  max-width: 480px;
  overflow: hidden;
}

.search-input-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-light);
}

.search-icon {
  font-size: 18px;
  color: var(--text-primary);
  opacity: 0.5;
}

.search-input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 15px;
  background: transparent;
  color: var(--text-primary);
}

.search-input::placeholder {
  color: var(--text-primary);
  opacity: 0.4;
}

.esc-hint {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  border: 1px solid var(--border-light);
  color: var(--text-primary);
  opacity: 0.5;
  font-family: inherit;
}

.search-results {
  max-height: 320px;
  overflow-y: auto;
  padding: 6px 0;
}

.search-result {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 8px 16px;
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-primary);
  font-size: 14px;
  text-align: left;
  transition: background 0.1s;
}

.search-result.selected {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.05));
}

.result-icon {
  width: 20px;
  text-align: center;
  flex-shrink: 0;
}

.result-label {
  flex: 1;
  font-weight: 500;
}

.result-section {
  font-size: 12px;
  opacity: 0.5;
}

.search-empty {
  padding: 24px 16px;
  text-align: center;
  color: var(--text-primary);
  opacity: 0.5;
  font-size: 14px;
}

/* Transition */
.search-enter-active,
.search-leave-active {
  transition: opacity 0.15s ease;
}

.search-enter-from,
.search-leave-to {
  opacity: 0;
}
</style>
