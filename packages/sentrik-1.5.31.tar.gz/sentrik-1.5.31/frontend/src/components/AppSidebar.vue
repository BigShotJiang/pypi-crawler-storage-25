<script setup lang="ts">
export interface NavItem {
  id: string
  label: string
  icon: string
  section: string
}

const props = defineProps<{
  activeTab: string
  collapsed: boolean
  badges?: Record<string, number>
}>()

defineEmits<{
  (e: 'navigate', tab: string): void
  (e: 'toggle-collapse'): void
}>()

interface NavSection {
  label: string
  items: NavItem[]
}

const sections: NavSection[] = [
  {
    label: 'Monitoring',
    items: [
      { id: 'overview', label: 'Overview', icon: '◾', section: 'Monitoring' },
      { id: 'findings', label: 'Findings', icon: '⚠', section: 'Monitoring' },
      { id: 'vulnerabilities', label: 'Vulnerabilities', icon: '⚡', section: 'Monitoring' },
      { id: 'history', label: 'History', icon: '◷', section: 'Monitoring' },
    ],
  },
  {
    label: 'Compliance',
    items: [
      { id: 'rules', label: 'Rules', icon: '⚜', section: 'Compliance' },
      { id: 'packs', label: 'Packs', icon: '☰', section: 'Compliance' },
      { id: 'reports', label: 'Reports', icon: '☾', section: 'Compliance' },
      { id: 'licenses', label: 'Licenses', icon: '⚸', section: 'Compliance' },
    ],
  },
  {
    label: 'Integrations',
    items: [
      { id: 'workitems', label: 'Work Items', icon: '☑', section: 'Integrations' },
      { id: 'integration', label: 'Integration', icon: '◯', section: 'Integrations' },
    ],
  },
  {
    label: 'Governance',
    items: [
      { id: 'policies', label: 'Policies', icon: '⚸', section: 'Governance' },
      { id: 'approvals', label: 'Approvals', icon: '✓', section: 'Governance' },
      { id: 'auditlog', label: 'Audit Log', icon: '◨', section: 'Governance' },
    ],
  },
  {
    label: 'Settings',
    items: [
      { id: 'settings', label: 'Settings', icon: '⚡', section: 'Settings' },
    ],
  },
]

function badgeCount(id: string): number | undefined {
  return props.badges?.[id]
}
</script>

<template>
  <aside class="app-sidebar" :class="{ collapsed }">
    <button class="collapse-btn" @click="$emit('toggle-collapse')">
      <span v-if="collapsed">▶</span>
      <span v-else>◀</span>
    </button>

    <nav class="sidebar-nav">
      <div v-for="section in sections" :key="section.label" class="nav-section">
        <div v-if="!collapsed" class="section-label">{{ section.label }}</div>

        <button
          v-for="item in section.items"
          :key="item.id"
          class="nav-item"
          :class="{ active: activeTab === item.id }"
          :title="collapsed ? item.label : undefined"
          @click="$emit('navigate', item.id)"
        >
          <span class="nav-icon">{{ item.icon }}</span>
          <span v-if="!collapsed" class="nav-label">{{ item.label }}</span>
          <span
            v-if="badgeCount(item.id) && !collapsed"
            class="nav-badge"
          >
            {{ badgeCount(item.id) }}
          </span>
        </button>
      </div>
    </nav>
  </aside>
</template>

<style scoped>
.app-sidebar {
  width: 220px;
  min-width: 220px;
  background: var(--bg-primary);
  border-right: 1px solid var(--border-light);
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  transition: width 0.2s, min-width 0.2s;
}

.app-sidebar.collapsed {
  width: 48px;
  min-width: 48px;
}

.collapse-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: none;
  border-bottom: 1px solid var(--border-light);
  padding: 8px;
  cursor: pointer;
  color: var(--text-primary);
  font-size: 12px;
  opacity: 0.6;
  transition: opacity 0.15s;
}

.collapse-btn:hover {
  opacity: 1;
}

.sidebar-nav {
  padding: 8px 0;
}

.nav-section {
  margin-bottom: 4px;
}

.section-label {
  padding: 8px 16px 4px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--text-primary);
  opacity: 0.5;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 6px 16px;
  background: none;
  border: none;
  border-left: 3px solid transparent;
  cursor: pointer;
  color: var(--text-primary);
  font-size: 13px;
  text-align: left;
  transition: background 0.15s, border-color 0.15s;
}

.collapsed .nav-item {
  justify-content: center;
  padding: 8px 0;
  gap: 0;
}

.nav-item:hover {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.04));
}

.nav-item.active {
  border-left-color: var(--accent);
  background: var(--bg-secondary, rgba(0, 0, 0, 0.06));
  font-weight: 600;
}

.nav-icon {
  font-size: 14px;
  width: 18px;
  text-align: center;
  flex-shrink: 0;
}

.nav-label {
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nav-badge {
  background: var(--accent);
  color: #fff;
  font-size: 11px;
  font-weight: 600;
  padding: 1px 6px;
  border-radius: 10px;
  min-width: 18px;
  text-align: center;
}
</style>
