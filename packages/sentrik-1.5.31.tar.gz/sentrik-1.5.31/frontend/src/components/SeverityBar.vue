<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  counts: Record<string, number>
}>()

const severities = ['critical', 'high', 'medium', 'low', 'info'] as const

const total = computed(() =>
  severities.reduce((sum, s) => sum + (props.counts[s] ?? 0), 0)
)

const segments = computed(() =>
  severities
    .filter((s) => (props.counts[s] ?? 0) > 0)
    .map((s) => ({
      severity: s,
      pct: ((props.counts[s] ?? 0) / total.value) * 100,
    }))
)
</script>

<template>
  <div class="severity-bar" role="img" aria-label="Severity distribution">
    <div
      v-for="seg in segments"
      :key="seg.severity"
      class="segment"
      :class="seg.severity"
      :style="{ width: seg.pct + '%' }"
      :title="`${seg.severity}: ${counts[seg.severity]}`"
    />
  </div>
</template>

<style scoped>
.severity-bar {
  display: flex;
  height: 8px;
  border-radius: 4px;
  overflow: hidden;
  background: var(--border-light, #e0e0e0);
  width: 100%;
}

.segment {
  height: 100%;
  transition: width 0.3s ease;
}

.segment.critical {
  background: var(--sev-critical);
}
.segment.high {
  background: var(--sev-high);
}
.segment.medium {
  background: var(--sev-medium);
}
.segment.low {
  background: var(--sev-low);
}
.segment.info {
  background: var(--sev-info);
}
</style>
