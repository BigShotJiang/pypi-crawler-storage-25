<script setup lang="ts">
export interface TableColumn {
  key: string
  label: string
  sortable?: boolean
}

defineProps<{
  columns: TableColumn[]
  rows: any[]
  sortKey: string
  sortAsc: boolean
}>()

const emit = defineEmits<{
  (e: 'sort', key: string): void
  (e: 'row-click', row: any): void
}>()

function handleHeaderClick(col: TableColumn) {
  if (col.sortable !== false) {
    emit('sort', col.key)
  }
}
</script>

<template>
  <div class="data-table-wrapper">
    <table class="data-table">
      <thead>
        <tr>
          <th
            v-for="col in columns"
            :key="col.key"
            :class="{ sortable: col.sortable !== false, active: sortKey === col.key }"
            @click="handleHeaderClick(col)"
          >
            <span class="th-content">
              {{ col.label }}
              <span v-if="col.sortable !== false" class="sort-indicator">
                <template v-if="sortKey === col.key">
                  {{ sortAsc ? '▲' : '▼' }}
                </template>
                <template v-else>
                  <span class="sort-inactive">▲</span>
                </template>
              </span>
            </span>
          </th>
        </tr>
      </thead>
      <tbody>
        <template v-if="rows.length > 0">
          <tr
            v-for="(row, idx) in rows"
            :key="idx"
            class="data-row"
            @click="emit('row-click', row)"
          >
            <td v-for="col in columns" :key="col.key">
              <slot :name="`cell-${col.key}`" :column="col" :row="row">
                {{ row[col.key] }}
              </slot>
            </td>
          </tr>
        </template>
        <template v-else>
          <tr>
            <td :colspan="columns.length" class="empty-cell">
              <slot name="empty">
                <div class="empty-state">No data available</div>
              </slot>
            </td>
          </tr>
        </template>
      </tbody>
    </table>
  </div>
</template>

<style scoped>
.data-table-wrapper {
  overflow-x: auto;
  border: 1px solid var(--border-light);
  border-radius: 8px;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

thead {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.03));
}

th {
  padding: 10px 14px;
  text-align: left;
  font-weight: 600;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  color: var(--text-primary);
  opacity: 0.7;
  border-bottom: 1px solid var(--border-light);
  white-space: nowrap;
  user-select: none;
}

th.sortable {
  cursor: pointer;
}

th.sortable:hover {
  opacity: 1;
}

th.active {
  opacity: 1;
  color: var(--accent);
}

.th-content {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.sort-indicator {
  font-size: 10px;
}

.sort-inactive {
  opacity: 0.3;
}

td {
  padding: 10px 14px;
  border-bottom: 1px solid var(--border-light);
  color: var(--text-primary);
}

.data-row {
  cursor: pointer;
  transition: background 0.1s;
}

.data-row:hover {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.02));
}

.data-row:last-child td {
  border-bottom: none;
}

.empty-cell {
  text-align: center;
  padding: 32px 14px;
}

.empty-state {
  color: var(--text-primary);
  opacity: 0.5;
  font-size: 14px;
}
</style>
