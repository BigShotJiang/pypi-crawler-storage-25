<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    lines?: number
    type?: 'text' | 'card' | 'table'
  }>(),
  {
    lines: 3,
    type: 'text',
  }
)

const lineWidths = computed(() => {
  const widths: string[] = []
  for (let i = 0; i < props.lines; i++) {
    // Vary widths for a natural look
    const w = i === props.lines - 1 ? 60 : 80 + Math.round((i * 17) % 20)
    widths.push(w + '%')
  }
  return widths
})
</script>

<template>
  <div class="skeleton" :class="type">
    <!-- Text mode -->
    <template v-if="type === 'text'">
      <div
        v-for="(w, i) in lineWidths"
        :key="i"
        class="skeleton-line"
        :style="{ width: w }"
      />
    </template>

    <!-- Card mode -->
    <template v-else-if="type === 'card'">
      <div
        v-for="i in lines"
        :key="i"
        class="skeleton-card"
      >
        <div class="skeleton-line" style="width: 40%; height: 14px" />
        <div class="skeleton-line" style="width: 80%" />
        <div class="skeleton-line" style="width: 60%" />
      </div>
    </template>

    <!-- Table mode -->
    <template v-else-if="type === 'table'">
      <div class="skeleton-table-header">
        <div class="skeleton-cell" v-for="i in 4" :key="'h' + i" />
      </div>
      <div
        v-for="i in lines"
        :key="'r' + i"
        class="skeleton-table-row"
      >
        <div class="skeleton-cell" v-for="j in 4" :key="'c' + j" />
      </div>
    </template>
  </div>
</template>

<style scoped>
@keyframes pulse {
  0%, 100% {
    opacity: 0.4;
  }
  50% {
    opacity: 0.15;
  }
}

.skeleton-line {
  height: 12px;
  border-radius: 4px;
  background: var(--text-primary, #888);
  opacity: 0.15;
  animation: pulse 1.5s ease-in-out infinite;
  margin-bottom: 10px;
}

/* Text */
.skeleton.text {
  padding: 4px 0;
}

/* Card */
.skeleton-card {
  border: 1px solid var(--border-light, #e0e0e0);
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 10px;
}

.skeleton-card .skeleton-line {
  margin-bottom: 8px;
}

.skeleton-card .skeleton-line:last-child {
  margin-bottom: 0;
}

/* Table */
.skeleton-table-header,
.skeleton-table-row {
  display: flex;
  gap: 12px;
  padding: 10px 0;
  border-bottom: 1px solid var(--border-light, #e0e0e0);
}

.skeleton-table-header {
  opacity: 0.7;
}

.skeleton-cell {
  flex: 1;
  height: 12px;
  border-radius: 4px;
  background: var(--text-primary, #888);
  opacity: 0.15;
  animation: pulse 1.5s ease-in-out infinite;
}
</style>
