<script setup lang="ts">
defineEmits<{
  (e: 'logout'): void
}>()

defineProps<{
  darkMode?: boolean
}>()
</script>

<template>
  <header class="app-header">
    <div class="header-left">
      <svg class="logo-icon" viewBox="0 0 58 58" width="32" height="32">
        <rect x="8" y="6" width="42" height="10" rx="2.5" fill="var(--bg-tertiary)" />
        <rect x="8" y="6" width="24" height="10" rx="2.5" fill="var(--accent)" />
        <rect x="8" y="24" width="42" height="10" rx="2.5" fill="var(--bg-tertiary)" />
        <rect x="26" y="24" width="24" height="10" rx="2.5" fill="var(--accent)" />
        <rect x="8" y="42" width="42" height="10" rx="2.5" fill="var(--bg-tertiary)" />
        <rect x="8" y="42" width="24" height="10" rx="2.5" fill="var(--accent)" />
      </svg>
      <span class="logo-text">sentrik</span>
    </div>

    <div class="header-right">
      <button
        class="icon-btn theme-toggle"
        :title="darkMode ? 'Switch to light mode' : 'Switch to dark mode'"
        @click="$emit('logout')"
      >
        <span v-if="darkMode" class="icon">☀</span>
        <span v-else class="icon">☽</span>
      </button>

      <a
        class="docs-link"
        href="https://docs.sentrik.dev"
        target="_blank"
        rel="noopener"
      >
        Docs
      </a>

      <button class="icon-btn logout-btn" title="Sign out" @click="$emit('logout')">
        Sign out
      </button>
    </div>
  </header>
</template>

<style scoped>
.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 24px;
  border-top: 3px solid var(--accent);
  border-bottom: 1px solid var(--border-light);
  background: var(--bg-primary);
  height: 48px;
  box-sizing: border-box;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.logo-text {
  font-size: 22px;
  font-weight: 700;
  color: var(--text-primary);
  letter-spacing: -0.5px;
}

.logo-icon {
  flex-shrink: 0;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.icon-btn {
  background: none;
  border: 1px solid var(--border-light);
  border-radius: 6px;
  padding: 4px 10px;
  cursor: pointer;
  color: var(--text-primary);
  font-size: 14px;
  transition: background 0.15s, border-color 0.15s;
}

.icon-btn:hover {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.05));
  border-color: var(--accent);
}

.theme-toggle .icon {
  font-size: 16px;
}

.docs-link {
  color: var(--text-primary);
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 6px;
  transition: background 0.15s;
}

.docs-link:hover {
  background: var(--bg-secondary, rgba(0, 0, 0, 0.05));
}

.logout-btn {
  font-size: 13px;
  font-weight: 500;
}
</style>
