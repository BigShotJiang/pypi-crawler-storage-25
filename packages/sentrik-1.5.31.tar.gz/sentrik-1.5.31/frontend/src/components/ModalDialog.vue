<script setup lang="ts">
defineProps<{
  open: boolean
  title: string
  width?: string
}>()

const emit = defineEmits<{
  (e: 'close'): void
}>()

function onBackdropClick(event: MouseEvent) {
  if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
    emit('close')
  }
}

function onKeydown(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    emit('close')
  }
}
</script>

<template>
  <Teleport to="body">
    <Transition name="modal">
      <div
        v-if="open"
        class="modal-overlay"
        @click="onBackdropClick"
        @keydown="onKeydown"
        tabindex="-1"
      >
        <div class="modal-card" :style="{ maxWidth: width ?? '520px' }">
          <div class="modal-header">
            <h2 class="modal-title">{{ title }}</h2>
            <button class="close-btn" @click="emit('close')" aria-label="Close">
              ✕
            </button>
          </div>

          <div class="modal-body">
            <slot />
          </div>

          <div v-if="$slots.footer" class="modal-footer">
            <slot name="footer" />
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(2px);
}

.modal-card {
  background: var(--bg-primary);
  border-radius: 12px;
  border: 1px solid var(--border-light);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
  width: 90vw;
  max-height: 85vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-light);
}

.modal-title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
}

.close-btn {
  background: none;
  border: none;
  font-size: 16px;
  cursor: pointer;
  color: var(--text-primary);
  opacity: 0.5;
  padding: 4px 8px;
  border-radius: 4px;
  transition: opacity 0.15s, background 0.15s;
}

.close-btn:hover {
  opacity: 1;
  background: var(--bg-secondary, rgba(0, 0, 0, 0.05));
}

.modal-body {
  padding: 20px;
  overflow-y: auto;
  flex: 1;
}

.modal-footer {
  padding: 12px 20px;
  border-top: 1px solid var(--border-light);
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

/* Transition */
.modal-enter-active,
.modal-leave-active {
  transition: opacity 0.2s ease;
}

.modal-enter-active .modal-card,
.modal-leave-active .modal-card {
  transition: transform 0.2s ease;
}

.modal-enter-from,
.modal-leave-to {
  opacity: 0;
}

.modal-enter-from .modal-card {
  transform: scale(0.95) translateY(10px);
}

.modal-leave-to .modal-card {
  transform: scale(0.95) translateY(10px);
}
</style>
