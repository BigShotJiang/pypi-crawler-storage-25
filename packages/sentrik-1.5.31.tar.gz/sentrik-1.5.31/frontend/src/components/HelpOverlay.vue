<script setup lang="ts">
defineProps<{
  open: boolean
}>()

const emit = defineEmits<{
  (e: 'close'): void
}>()

interface Shortcut {
  keys: string
  description: string
}

const shortcuts: Shortcut[] = [
  { keys: '1 – 9', description: 'Switch between tabs' },
  { keys: '/', description: 'Open search' },
  { keys: '?', description: 'Show this help' },
  { keys: 'S', description: 'Run scan' },
  { keys: 'G', description: 'Run gate check' },
  { keys: 'Esc', description: 'Close overlay / modal' },
]

function onBackdropClick(event: MouseEvent) {
  if ((event.target as HTMLElement).classList.contains('help-overlay')) {
    emit('close')
  }
}

function onKeydown(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    emit('close')
  }
}
</script>

<template>
  <Teleport to="body">
    <Transition name="help">
      <div
        v-if="open"
        class="help-overlay"
        @click="onBackdropClick"
        @keydown="onKeydown"
        tabindex="-1"
      >
        <div class="help-card">
          <div class="help-header">
            <h2 class="help-title">Keyboard Shortcuts</h2>
            <button class="close-btn" @click="emit('close')" aria-label="Close">
              ✕
            </button>
          </div>

          <div class="shortcuts-grid">
            <div
              v-for="sc in shortcuts"
              :key="sc.keys"
              class="shortcut-row"
            >
              <kbd class="shortcut-key">{{ sc.keys }}</kbd>
              <span class="shortcut-desc">{{ sc.description }}</span>
            </div>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.help-overlay {
  position: fixed;
  inset: 0;
  z-index: 1100;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.4);
  backdrop-filter: blur(2px);
}

.help-card {
  background: var(--bg-primary);
  border: 1px solid var(--border-light);
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
  width: 90vw;
  max-width: 400px;
  overflow: hidden;
}

.help-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-light);
}

.help-title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
}

.close-btn {
  background: none;
  border: none;
  font-size: 16px;
  cursor: pointer;
  color: var(--text-primary);
  opacity: 0.5;
  padding: 4px 8px;
  border-radius: 4px;
  transition: opacity 0.15s;
}

.close-btn:hover {
  opacity: 1;
}

.shortcuts-grid {
  padding: 16px 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.shortcut-row {
  display: flex;
  align-items: center;
  gap: 16px;
}

.shortcut-key {
  display: inline-block;
  min-width: 56px;
  padding: 4px 10px;
  border: 1px solid var(--border-light);
  border-radius: 6px;
  background: var(--bg-secondary, rgba(0, 0, 0, 0.04));
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
  color: var(--text-primary);
}

.shortcut-desc {
  font-size: 14px;
  color: var(--text-primary);
  opacity: 0.8;
}

/* Transition */
.help-enter-active,
.help-leave-active {
  transition: opacity 0.15s ease;
}

.help-enter-from,
.help-leave-to {
  opacity: 0;
}
</style>
