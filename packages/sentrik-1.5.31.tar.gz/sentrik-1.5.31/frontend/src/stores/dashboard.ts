import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { useApi, ApiError } from '../composables/useApi'

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export interface Finding {
  id: string
  rule_id: string
  rule_name: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  message: string
  file: string
  line: number
  confidence: number
  deterministic: boolean
  standard?: string
  suggestion?: string
}

export interface Rule {
  id: string
  name: string
  description: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  type: 'regex' | 'required_pattern' | 'file_policy' | 'ast' | 'documentation_obligation'
  standard?: string
  enabled: boolean
  source?: 'builtin' | 'custom' | 'pack'
  pack?: string
}

export interface ScanMetrics {
  total_duration?: number
  files_scanned?: number
  findings_count?: number
  cache_hit_rate?: number
  severity_counts?: Record<string, number>
  by_rule?: Record<string, number>
  parallel_workers?: number
  scan_time?: string
  false_positive_rate?: number
}

export interface GovernanceConfig {
  profile?: string
  human_review_required?: Record<string, boolean>
  auto_patch?: { enabled?: boolean; max_severity?: string }
  gate?: { fail_on?: string[]; block_merge_on_obligations?: boolean }
}

export interface PackInfo {
  id: string
  name: string
  description: string
  rule_count: number
  enabled: boolean
  tier?: string
}

export interface DashboardConfig {
  standards_file?: string
  output_dir?: string
  gate_fail_on?: string[]
  devops_provider?: string
  standards_packs?: string[]
  parallel_scan?: boolean
  max_workers?: number
  severity_rescoring_enabled?: boolean
  governance?: GovernanceConfig
  [key: string]: unknown
}

export type ToastType = 'success' | 'error' | 'info'

export interface Toast {
  id: number
  message: string
  type: ToastType
}

/* ------------------------------------------------------------------ */
/*  Store                                                              */
/* ------------------------------------------------------------------ */

export const useDashboardStore = defineStore('dashboard', () => {
  /* --- State --- */
  const activeTab = ref<string>('overview')
  const findings = ref<Finding[]>([])
  const rules = ref<Rule[]>([])
  const metrics = ref<ScanMetrics | null>(null)
  const config = ref<DashboardConfig | null>(null)
  const packs = ref<PackInfo[]>([])
  const licenseFeatures = ref<Set<string>>(new Set())
  const governance = ref<GovernanceConfig | null>(null)

  const scanning = ref(false)
  const gating = ref(false)

  const toasts = ref<Toast[]>([])
  let nextToastId = 0

  /* --- Computed --- */
  const findingsBySeverity = computed(() => {
    const counts: Record<string, number> = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      info: 0,
    }
    for (const f of findings.value) {
      counts[f.severity] = (counts[f.severity] || 0) + 1
    }
    return counts
  })

  const totalFindings = computed(() => findings.value.length)

  /* --- Toast helper --- */
  function showToast(message: string, type: ToastType = 'success', duration = 3500) {
    const id = nextToastId++
    toasts.value.push({ id, message, type })
    setTimeout(() => {
      toasts.value = toasts.value.filter((t) => t.id !== id)
    }, duration)
  }

  /* --- API helpers (shared instance) --- */
  const api = useApi()

  /* --- Actions --- */
  async function loadMetrics(): Promise<void> {
    try {
      metrics.value = await api.get<ScanMetrics>('/api/metrics')
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) {
        metrics.value = null
      } else {
        console.error('Failed to load metrics:', err)
      }
    }
  }

  async function loadFindings(): Promise<void> {
    try {
      const data = await api.get<{ findings: Finding[] } | Finding[]>('/api/findings')
      findings.value = Array.isArray(data) ? data : data.findings
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) {
        findings.value = []
      } else {
        console.error('Failed to load findings:', err)
      }
    }
  }

  async function loadRules(): Promise<void> {
    try {
      const data = await api.get<{ rules: Rule[] } | Rule[]>('/rules')
      rules.value = Array.isArray(data) ? data : data.rules
    } catch (err) {
      console.error('Failed to load rules:', err)
    }
  }

  async function loadConfig(): Promise<void> {
    try {
      config.value = await api.get<DashboardConfig>('/api/config')
    } catch (err) {
      console.error('Failed to load config:', err)
    }
  }

  async function loadPacks(): Promise<void> {
    try {
      const data = await api.get<{ packs: PackInfo[] } | PackInfo[]>('/api/packs')
      packs.value = Array.isArray(data) ? data : data.packs
    } catch (err) {
      console.error('Failed to load packs:', err)
    }
  }

  async function loadGovernance(): Promise<void> {
    try {
      governance.value = await api.get<GovernanceConfig>('/api/governance')
    } catch (err) {
      console.error('Failed to load governance:', err)
    }
  }

  async function runScan(): Promise<void> {
    if (scanning.value) return
    scanning.value = true
    showToast('Scan started...', 'info')
    try {
      await api.post('/api/run-scan')
      showToast('Scan completed successfully')
      // Refresh data after scan
      await Promise.all([loadMetrics(), loadFindings()])
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : 'Scan failed',
        'error',
      )
    } finally {
      scanning.value = false
    }
  }

  async function runGate(): Promise<void> {
    if (gating.value) return
    gating.value = true
    showToast('Gate check started...', 'info')
    try {
      const result = await api.post<{ status: string; message?: string }>('/api/run-gate')
      if (result.status === 'passed') {
        showToast('Gate passed')
      } else {
        showToast(result.message || 'Gate failed', 'error')
      }
      await Promise.all([loadMetrics(), loadFindings()])
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : 'Gate check failed',
        'error',
      )
    } finally {
      gating.value = false
    }
  }

  async function updateConfig(updates: Partial<DashboardConfig>): Promise<void> {
    try {
      await api.post('/api/config', updates)
      showToast('Configuration updated')
      await loadConfig()
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : 'Failed to update config',
        'error',
      )
    }
  }

  async function togglePack(packId: string, enable: boolean): Promise<void> {
    try {
      await api.post('/api/packs/toggle', { pack_id: packId, enable })
      showToast(`Pack ${enable ? 'enabled' : 'disabled'}`)
      await loadPacks()
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : 'Failed to toggle pack',
        'error',
      )
    }
  }

  /** Load all dashboard data in parallel. */
  async function init(): Promise<void> {
    await Promise.allSettled([
      loadMetrics(),
      loadFindings(),
      loadRules(),
      loadConfig(),
      loadPacks(),
      loadGovernance(),
    ])
  }

  return {
    // State
    activeTab,
    findings,
    rules,
    metrics,
    config,
    packs,
    licenseFeatures,
    governance,
    scanning,
    gating,
    toasts,

    // Computed
    findingsBySeverity,
    totalFindings,

    // Actions
    loadMetrics,
    loadFindings,
    loadRules,
    loadConfig,
    loadPacks,
    loadGovernance,
    runScan,
    runGate,
    updateConfig,
    togglePack,
    showToast,
    init,
  }
})
