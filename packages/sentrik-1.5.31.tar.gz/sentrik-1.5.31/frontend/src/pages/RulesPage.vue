<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

interface Rule {
  id: string
  name: string
  type: string
  severity: string
  standard: string
  pack: string
  description: string
  pattern: string
  remediation: string
  file_glob: string
  tags: string[]
}

const rules = ref<Rule[]>([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const severityFilter = ref<string[]>([])
const standardFilter = ref('')
const groupBy = ref<'none' | 'severity' | 'standard' | 'type'>('none')
const expandedId = ref<string | null>(null)

const severities = ['critical', 'high', 'medium', 'low', 'info']

onMounted(async () => {
  try {
    const res = await fetch('/api/rules')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    rules.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const standards = computed(() => [...new Set(rules.value.map(r => r.standard).filter(Boolean))].sort())

const filtered = computed(() => {
  let list = rules.value
  if (search.value) {
    const q = search.value.toLowerCase()
    list = list.filter(r => r.id.toLowerCase().includes(q) || r.name.toLowerCase().includes(q) || r.description?.toLowerCase().includes(q))
  }
  if (severityFilter.value.length) list = list.filter(r => severityFilter.value.includes(r.severity))
  if (standardFilter.value) list = list.filter(r => r.standard === standardFilter.value)
  return list
})

const grouped = computed(() => {
  if (groupBy.value === 'none') return null
  const map = new Map<string, Rule[]>()
  for (const r of filtered.value) {
    const key = groupBy.value === 'severity' ? r.severity : groupBy.value === 'standard' ? (r.standard || 'None') : r.type
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(r)
  }
  return map
})

function toggleSev(s: string) {
  const idx = severityFilter.value.indexOf(s)
  if (idx >= 0) severityFilter.value.splice(idx, 1)
  else severityFilter.value.push(s)
}

function toggleExpand(id: string) { expandedId.value = expandedId.value === id ? null : id }
</script>

<template>
  <div class="rules-page">
    <h1>Rules</h1>
    <div class="toolbar">
      <input v-model="search" class="search-input" placeholder="Search rules..." />
      <div class="pills">
        <button v-for="s in severities" :key="s" class="pill" :class="{ active: severityFilter.includes(s), [s]: true }" @click="toggleSev(s)">{{ s }}</button>
      </div>
      <select v-model="standardFilter" class="filter-select">
        <option value="">All standards</option>
        <option v-for="st in standards" :key="st" :value="st">{{ st }}</option>
      </select>
      <select v-model="groupBy" class="filter-select">
        <option value="none">No grouping</option>
        <option value="severity">Group by severity</option>
        <option value="standard">Group by standard</option>
        <option value="type">Group by type</option>
      </select>
    </div>

    <div v-if="loading" class="loading">Loading rules...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else-if="groupBy === 'none'">
      <table class="data-table">
        <thead><tr><th>ID</th><th>Name</th><th>Type</th><th>Severity</th><th>Standard</th><th>Pack</th></tr></thead>
        <tbody>
          <template v-for="r in filtered" :key="r.id">
            <tr @click="toggleExpand(r.id)" class="clickable">
              <td class="mono">{{ r.id }}</td>
              <td>{{ r.name }}</td>
              <td><span class="type-badge">{{ r.type }}</span></td>
              <td><span class="sev-badge" :class="r.severity">{{ r.severity }}</span></td>
              <td>{{ r.standard || '-' }}</td>
              <td>{{ r.pack || '-' }}</td>
            </tr>
            <tr v-if="expandedId === r.id" class="detail-row">
              <td colspan="6">
                <div class="detail">
                  <p v-if="r.description"><strong>Description:</strong> {{ r.description }}</p>
                  <p v-if="r.pattern"><strong>Pattern:</strong> <code>{{ r.pattern }}</code></p>
                  <p v-if="r.remediation"><strong>Remediation:</strong> {{ r.remediation }}</p>
                  <p v-if="r.file_glob"><strong>File glob:</strong> <code>{{ r.file_glob }}</code></p>
                  <p v-if="r.tags?.length"><strong>Tags:</strong> <span v-for="t in r.tags" :key="t" class="tag">{{ t }}</span></p>
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
      <p class="count">{{ filtered.length }} rules</p>
    </template>

    <template v-else-if="grouped">
      <div v-for="[key, items] in grouped" :key="key" class="group">
        <h3>{{ key }} <span class="group-count">({{ items.length }})</span></h3>
        <div v-for="r in items" :key="r.id" class="group-item" @click="toggleExpand(r.id)">
          <span class="sev-badge" :class="r.severity">{{ r.severity }}</span>
          <span class="mono">{{ r.id }}</span>
          <span>{{ r.name }}</span>
          <div v-if="expandedId === r.id" class="detail">
            <p v-if="r.description">{{ r.description }}</p>
            <p v-if="r.pattern"><strong>Pattern:</strong> <code>{{ r.pattern }}</code></p>
            <p v-if="r.remediation"><strong>Remediation:</strong> {{ r.remediation }}</p>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.rules-page { padding: 1.5rem; }
h1 { margin: 0 0 1rem; color: var(--text-primary); }
.toolbar { display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; margin-bottom: 1rem; }
.search-input { padding: 0.5rem 0.75rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg-secondary); color: var(--text-primary); flex: 1; min-width: 200px; }
.pills { display: flex; gap: 0.35rem; }
.pill { padding: 0.3rem 0.7rem; border-radius: 12px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-secondary); cursor: pointer; font-size: 0.8rem; text-transform: capitalize; }
.pill.active.critical { background: var(--sev-critical); color: #fff; border-color: var(--sev-critical); }
.pill.active.high { background: var(--sev-high); color: #fff; border-color: var(--sev-high); }
.pill.active.medium { background: var(--sev-medium); color: #fff; border-color: var(--sev-medium); }
.pill.active.low { background: var(--sev-low); color: #fff; border-color: var(--sev-low); }
.pill.active.info { background: var(--sev-info); color: #fff; border-color: var(--sev-info); }
.filter-select { padding: 0.4rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.clickable { cursor: pointer; }
.clickable:hover { background: var(--bg-tertiary); }
.mono { font-family: monospace; font-size: 0.85rem; }
.sev-badge { padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.75rem; color: #fff; text-transform: uppercase; font-weight: 600; }
.sev-badge.critical { background: var(--sev-critical); }
.sev-badge.high { background: var(--sev-high); }
.sev-badge.medium { background: var(--sev-medium); }
.sev-badge.low { background: var(--sev-low); }
.sev-badge.info { background: var(--sev-info); }
.type-badge { padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.75rem; background: var(--bg-tertiary); color: var(--text-secondary); }
.detail-row td { background: var(--bg-tertiary); }
.detail { padding: 0.5rem; color: var(--text-primary); }
.detail p { margin: 0.3rem 0; }
.detail code { background: var(--bg-primary); padding: 0.15rem 0.4rem; border-radius: 4px; font-size: 0.85rem; }
.tag { display: inline-block; padding: 0.1rem 0.4rem; border-radius: 4px; background: var(--accent); color: #fff; font-size: 0.75rem; margin-right: 0.3rem; }
.count { color: var(--text-secondary); font-size: 0.9rem; margin-top: 0.75rem; }
.group { margin-bottom: 1.5rem; }
.group h3 { color: var(--text-primary); margin: 0 0 0.5rem; }
.group-count { color: var(--text-secondary); font-weight: 400; }
.group-item { padding: 0.5rem 0.75rem; border-bottom: 1px solid var(--border); display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; cursor: pointer; color: var(--text-primary); }
.group-item:hover { background: var(--bg-tertiary); }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
