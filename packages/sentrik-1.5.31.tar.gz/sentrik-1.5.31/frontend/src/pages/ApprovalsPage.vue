<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

interface Approval {
  id: string
  action: string
  state: 'pending' | 'approved' | 'rejected'
  created_at: string
  resolved_at: string | null
}

const approvals = ref<Approval[]>([])
const loading = ref(true)
const error = ref('')

onMounted(async () => {
  try {
    const res = await fetch('/api/approvals')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    approvals.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const pending = computed(() => approvals.value.filter(a => a.state === 'pending'))
const resolved = computed(() => approvals.value.filter(a => a.state !== 'pending'))

async function decide(approval: Approval, decision: 'approved' | 'rejected') {
  try {
    const res = await fetch(`/api/approvals/${approval.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    approval.state = decision
    approval.resolved_at = new Date().toISOString()
  } catch (e: any) {
    error.value = e.message
  }
}

function formatTime(ts: string | null) {
  if (!ts) return '-'
  try { return new Date(ts).toLocaleString() } catch { return ts }
}

const stateColor = (s: string) => {
  if (s === 'approved') return 'var(--sev-info)'
  if (s === 'rejected') return 'var(--sev-critical)'
  return 'var(--sev-medium)'
}
</script>

<template>
  <div class="approvals-page">
    <h1>Approval Gates</h1>

    <div v-if="loading" class="loading">Loading approvals...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else>
      <section class="section">
        <h2>Pending Approvals <span class="count-badge" v-if="pending.length">{{ pending.length }}</span></h2>
        <div v-if="pending.length" class="approval-list">
          <div v-for="a in pending" :key="a.id" class="approval-card pending">
            <div class="approval-info">
              <span class="approval-action">{{ a.action }}</span>
              <span class="approval-time">Created: {{ formatTime(a.created_at) }}</span>
            </div>
            <div class="approval-actions">
              <button class="btn btn-approve" @click="decide(a, 'approved')">Approve</button>
              <button class="btn btn-reject" @click="decide(a, 'rejected')">Reject</button>
            </div>
          </div>
        </div>
        <p v-else class="empty">No pending approvals.</p>
      </section>

      <section class="section">
        <h2>Resolved</h2>
        <table v-if="resolved.length" class="data-table">
          <thead><tr><th>Action</th><th>State</th><th>Created</th><th>Resolved</th></tr></thead>
          <tbody>
            <tr v-for="a in resolved" :key="a.id">
              <td>{{ a.action }}</td>
              <td><span class="state-badge" :style="{ color: stateColor(a.state) }">{{ a.state }}</span></td>
              <td>{{ formatTime(a.created_at) }}</td>
              <td>{{ formatTime(a.resolved_at) }}</td>
            </tr>
          </tbody>
        </table>
        <p v-else class="empty">No resolved approvals.</p>
      </section>
    </template>
  </div>
</template>

<style scoped>
.approvals-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; }
.section { margin-bottom: 2rem; }
.count-badge { background: var(--sev-medium); color: #fff; padding: 0.1rem 0.5rem; border-radius: 10px; font-size: 0.8rem; margin-left: 0.5rem; }
.approval-list { display: flex; flex-direction: column; gap: 0.5rem; }
.approval-card { background: var(--bg-secondary); border-radius: 8px; padding: 1rem; display: flex; justify-content: space-between; align-items: center; border: 1px solid var(--border); flex-wrap: wrap; gap: 0.5rem; }
.approval-card.pending { border-left: 3px solid var(--sev-medium); }
.approval-info { display: flex; flex-direction: column; gap: 0.25rem; }
.approval-action { color: var(--text-primary); font-weight: 600; }
.approval-time { color: var(--text-secondary); font-size: 0.85rem; }
.approval-actions { display: flex; gap: 0.5rem; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn-approve { background: var(--sev-info); color: #fff; border-color: var(--sev-info); }
.btn-reject { background: var(--sev-critical); color: #fff; border-color: var(--sev-critical); }
.state-badge { font-weight: 600; text-transform: capitalize; }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); }
.empty { color: var(--text-secondary); font-style: italic; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
