<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'

interface Setting {
  key: string
  value: any
  type: 'boolean' | 'string' | 'array' | 'number'
  description: string
  group: string
}

const config = ref<Record<string, any>>({})
const loading = ref(true)
const error = ref('')
const validating = ref(false)
const validationResult = ref<{ valid: boolean; errors: string[] } | null>(null)
const expandedKey = ref<string | null>(null)
const editValues = ref<Record<string, any>>({})
const dirty = ref<Set<string>>(new Set())

const groups = ['Core', 'Scanning', 'Integration', 'Governance', 'Server']

const groupMap: Record<string, string> = {
  output_dir: 'Core', standards_file: 'Core', work_items_file: 'Core', provider: 'Core',
  gate_fail_on: 'Core', standards_packs: 'Core',
  parallel_scan: 'Scanning', max_workers: 'Scanning', severity_rescoring_enabled: 'Scanning',
  agent_scan: 'Scanning', agent_max_concurrency: 'Scanning', confidence_scoring_enabled: 'Scanning',
  devops_provider: 'Integration', azure_devops_org: 'Integration', azure_devops_project: 'Integration',
  github_owner: 'Integration', github_repo: 'Integration', jira_base_url: 'Integration',
  governance_profile: 'Governance', human_review_required: 'Governance', auto_patch: 'Governance',
  api_key: 'Server', rate_limit_enabled: 'Server', rate_limit_rpm: 'Server',
}

onMounted(async () => {
  try {
    const res = await fetch('/api/config')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    config.value = await res.json()
    for (const [k, v] of Object.entries(config.value)) editValues.value[k] = v
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const settings = computed((): Setting[] =>
  Object.entries(config.value).map(([key, value]) => ({
    key,
    value,
    type: typeof value === 'boolean' ? 'boolean' : Array.isArray(value) ? 'array' : typeof value === 'number' ? 'number' : 'string',
    description: '',
    group: groupMap[key] || 'Core',
  }))
)

const groupedSettings = computed(() => {
  const map: Record<string, Setting[]> = {}
  for (const g of groups) map[g] = []
  for (const s of settings.value) {
    const g = s.group
    if (!map[g]) map[g] = []
    map[g].push(s)
  }
  return map
})

function updateValue(key: string, val: any) {
  editValues.value[key] = val
  dirty.value.add(key)
}

async function saveChanges() {
  const updates: Record<string, any> = {}
  for (const k of dirty.value) updates[k] = editValues.value[k]
  if (!Object.keys(updates).length) return
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updates }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    Object.assign(config.value, updates)
    dirty.value.clear()
  } catch (e: any) {
    error.value = e.message
  }
}

async function validate() {
  validating.value = true
  validationResult.value = null
  try {
    const res = await fetch('/api/config/validate', { method: 'POST' })
    validationResult.value = await res.json()
  } catch (e: any) {
    validationResult.value = { valid: false, errors: [e.message] }
  } finally {
    validating.value = false
  }
}
</script>

<template>
  <div class="settings-page">
    <div class="header">
      <h1>Settings</h1>
      <div class="header-actions">
        <button class="btn" @click="validate" :disabled="validating">{{ validating ? 'Validating...' : 'Validate' }}</button>
        <button class="btn btn-primary" @click="saveChanges" :disabled="!dirty.size">Save Changes ({{ dirty.size }})</button>
      </div>
    </div>

    <div v-if="validationResult" class="validation-banner" :class="{ valid: validationResult.valid }">
      <span v-if="validationResult.valid">Configuration is valid</span>
      <template v-else>
        <span>Validation errors:</span>
        <ul><li v-for="(e, i) in validationResult.errors" :key="i">{{ e }}</li></ul>
      </template>
    </div>

    <div v-if="loading" class="loading">Loading configuration...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else>
      <section v-for="group in groups" :key="group" class="settings-group">
        <h2>{{ group }}</h2>
        <div v-if="!groupedSettings[group]?.length" class="empty">No settings in this group</div>
        <div v-for="s in groupedSettings[group]" :key="s.key" class="setting-row">
          <div class="setting-header" @click="expandedKey = expandedKey === s.key ? null : s.key">
            <span class="setting-label">{{ s.key }}</span>
            <div class="setting-control" @click.stop>
              <template v-if="s.type === 'boolean'">
                <label class="toggle-switch">
                  <input type="checkbox" :checked="editValues[s.key]" @change="updateValue(s.key, ($event.target as HTMLInputElement).checked)" />
                  <span class="slider"></span>
                </label>
              </template>
              <template v-else-if="s.type === 'number'">
                <input type="number" :value="editValues[s.key]" @input="updateValue(s.key, Number(($event.target as HTMLInputElement).value))" class="text-input num-input" />
              </template>
              <template v-else-if="s.type === 'array'">
                <input type="text" :value="(editValues[s.key] || []).join(', ')"
                  @input="updateValue(s.key, ($event.target as HTMLInputElement).value.split(',').map((x: string) => x.trim()).filter(Boolean))"
                  class="text-input" placeholder="comma-separated" />
              </template>
              <template v-else>
                <input type="text" :value="editValues[s.key]" @input="updateValue(s.key, ($event.target as HTMLInputElement).value)" class="text-input" />
              </template>
            </div>
            <span v-if="dirty.has(s.key)" class="dirty-dot"></span>
          </div>
          <div v-if="expandedKey === s.key" class="setting-detail">
            <p class="setting-desc">Current value: <code>{{ JSON.stringify(s.value) }}</code></p>
          </div>
        </div>
      </section>
    </template>
  </div>
</template>

<style scoped>
.settings-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem; }
h1 { margin: 0; color: var(--text-primary); }
.header-actions { display: flex; gap: 0.5rem; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.validation-banner { padding: 0.75rem 1rem; border-radius: 6px; margin-bottom: 1rem; background: var(--sev-critical); color: #fff; }
.validation-banner.valid { background: var(--sev-info); }
.validation-banner ul { margin: 0.3rem 0 0 1.25rem; padding: 0; }
.settings-group { margin-bottom: 2rem; }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border); }
.setting-row { border-bottom: 1px solid var(--border); }
.setting-header { display: flex; align-items: center; gap: 1rem; padding: 0.65rem 0; cursor: pointer; }
.setting-label { color: var(--text-primary); font-family: monospace; font-size: 0.9rem; min-width: 200px; }
.setting-control { flex: 1; display: flex; justify-content: flex-end; }
.text-input { padding: 0.3rem 0.5rem; border: 1px solid var(--border); border-radius: 4px; background: var(--bg-secondary); color: var(--text-primary); width: 250px; }
.num-input { width: 100px; }
.dirty-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); flex-shrink: 0; }
.setting-detail { padding: 0.25rem 0 0.75rem 0; }
.setting-desc { color: var(--text-secondary); font-size: 0.85rem; margin: 0; }
.setting-desc code { background: var(--bg-tertiary); padding: 0.1rem 0.3rem; border-radius: 3px; }
.toggle-switch { position: relative; width: 40px; height: 22px; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; inset: 0; background: var(--bg-tertiary); border-radius: 22px; transition: 0.3s; }
.slider::before { content: ''; position: absolute; height: 16px; width: 16px; left: 3px; bottom: 3px; background: var(--text-secondary); border-radius: 50%; transition: 0.3s; }
.toggle-switch input:checked + .slider { background: var(--accent); }
.toggle-switch input:checked + .slider::before { transform: translateX(18px); background: #fff; }
.empty { color: var(--text-secondary); font-style: italic; padding: 0.5rem 0; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
