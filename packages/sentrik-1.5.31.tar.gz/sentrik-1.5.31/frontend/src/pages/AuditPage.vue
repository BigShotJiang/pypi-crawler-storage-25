<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

interface AuditEntry {
  timestamp: string
  action: string
  user: string
  decision: string
  details: string
  _integrity: string
}

const entries = ref<AuditEntry[]>([])
const loading = ref(true)
const error = ref('')
const actionFilter = ref('')
const expandedIdx = ref<number | null>(null)

onMounted(async () => {
  try {
    const res = await fetch('/api/audit')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    entries.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const actions = computed(() => [...new Set(entries.value.map(e => e.action))].sort())

const filtered = computed(() => {
  if (!actionFilter.value) return entries.value
  return entries.value.filter(e => e.action === actionFilter.value)
})

function formatTime(ts: string) {
  try { return new Date(ts).toLocaleString() } catch { return ts }
}

function toggleExpand(idx: number) {
  expandedIdx.value = expandedIdx.value === idx ? null : idx
}

function exportAudit() {
  const a = document.createElement('a')
  a.href = '/api/audit/export'
  a.download = 'audit-bundle.json'
  a.click()
}

const decisionColor = (d: string) => {
  if (d === 'approved' || d === 'pass') return 'var(--sev-info)'
  if (d === 'rejected' || d === 'fail') return 'var(--sev-critical)'
  return 'var(--text-secondary)'
}
</script>

<template>
  <div class="audit-page">
    <div class="header">
      <h1>Audit Log</h1>
      <div class="header-actions">
        <select v-model="actionFilter" class="filter-select">
          <option value="">All actions</option>
          <option v-for="a in actions" :key="a" :value="a">{{ a }}</option>
        </select>
        <button class="btn" @click="exportAudit">Export Bundle</button>
      </div>
    </div>

    <div v-if="loading" class="loading">Loading audit log...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <div v-else-if="filtered.length" class="entries">
      <div v-for="(entry, idx) in filtered" :key="idx" class="entry" @click="toggleExpand(idx)">
        <div class="entry-header">
          <span class="entry-time">{{ formatTime(entry.timestamp) }}</span>
          <span class="entry-action">{{ entry.action }}</span>
          <span class="entry-decision" :style="{ color: decisionColor(entry.decision) }">{{ entry.decision }}</span>
          <span class="entry-user">{{ entry.user }}</span>
          <span class="toggle-icon">{{ expandedIdx === idx ? '\u25BC' : '\u25B6' }}</span>
        </div>
        <div v-if="expandedIdx === idx" class="entry-detail">
          <p><strong>Details:</strong> {{ entry.details }}</p>
          <p class="integrity"><strong>Integrity:</strong> <code>{{ entry._integrity }}</code></p>
        </div>
      </div>
    </div>
    <p v-else class="empty">No audit entries found.</p>

    <p class="count" v-if="!loading">{{ filtered.length }} entries</p>
  </div>
</template>

<style scoped>
.audit-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.5rem; }
h1 { margin: 0; color: var(--text-primary); }
.header-actions { display: flex; gap: 0.5rem; }
.filter-select { padding: 0.4rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); }
.entries { display: flex; flex-direction: column; gap: 0.25rem; }
.entry { background: var(--bg-secondary); border-radius: 8px; padding: 0.75rem 1rem; cursor: pointer; border: 1px solid var(--border); transition: border-color 0.2s; }
.entry:hover { border-color: var(--accent); }
.entry-header { display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; }
.entry-time { color: var(--text-secondary); font-size: 0.85rem; min-width: 160px; }
.entry-action { background: var(--bg-tertiary); padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.8rem; color: var(--text-primary); }
.entry-decision { font-weight: 600; font-size: 0.85rem; text-transform: capitalize; }
.entry-user { color: var(--text-secondary); font-size: 0.85rem; margin-left: auto; }
.toggle-icon { font-size: 0.7rem; color: var(--text-secondary); }
.entry-detail { margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid var(--border); }
.entry-detail p { margin: 0.3rem 0; color: var(--text-primary); font-size: 0.9rem; }
.integrity code { font-size: 0.75rem; background: var(--bg-tertiary); padding: 0.1rem 0.3rem; border-radius: 3px; word-break: break-all; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.count { color: var(--text-secondary); font-size: 0.85rem; margin-top: 1rem; }
.empty { color: var(--text-secondary); font-style: italic; text-align: center; padding: 2rem; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
