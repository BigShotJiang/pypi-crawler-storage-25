<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue'

interface Run {
  timestamp: string
  total_findings: number
  archived_at: string
  findings_by_severity?: Record<string, number>
}

const runs = ref<Run[]>([])
const loading = ref(true)
const error = ref('')
const svgRef = ref<SVGSVGElement | null>(null)

const chartW = 700
const chartH = 220
const padX = 50
const padY = 30

onMounted(async () => {
  try {
    const res = await fetch('/api/metrics/history')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    runs.value = data.runs || []
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const maxFindings = computed(() => Math.max(1, ...runs.value.map(r => r.total_findings)))

const points = computed(() => {
  if (!runs.value.length) return ''
  const n = runs.value.length
  return runs.value.map((r, i) => {
    const x = padX + (i / Math.max(1, n - 1)) * (chartW - 2 * padX)
    const y = padY + (1 - r.total_findings / maxFindings.value) * (chartH - 2 * padY)
    return `${x},${y}`
  }).join(' ')
})

const dataPoints = computed(() => {
  if (!runs.value.length) return []
  const n = runs.value.length
  return runs.value.map((r, i) => ({
    x: padX + (i / Math.max(1, n - 1)) * (chartW - 2 * padX),
    y: padY + (1 - r.total_findings / maxFindings.value) * (chartH - 2 * padY),
    run: r,
  }))
})

const yTicks = computed(() => {
  const max = maxFindings.value
  const step = Math.max(1, Math.ceil(max / 5))
  const ticks = []
  for (let v = 0; v <= max; v += step) {
    ticks.push({ value: v, y: padY + (1 - v / max) * (chartH - 2 * padY) })
  }
  return ticks
})

function formatDate(ts: string) {
  try { return new Date(ts).toLocaleDateString() } catch { return ts }
}

function viewReport(run: Run) {
  window.open(`/api/metrics/history/${run.archived_at || run.timestamp}/report`, '_blank')
}
</script>

<template>
  <div class="history-page">
    <h1>Compliance History</h1>

    <div v-if="loading" class="loading">Loading history...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else>
      <section class="chart-section">
        <h2>Findings Over Time</h2>
        <svg v-if="runs.length > 1" ref="svgRef" :viewBox="`0 0 ${chartW} ${chartH}`" class="line-chart" preserveAspectRatio="xMidYMid meet">
          <!-- Y axis ticks -->
          <template v-for="t in yTicks" :key="t.value">
            <line :x1="padX" :y1="t.y" :x2="chartW - padX" :y2="t.y" class="grid-line" />
            <text :x="padX - 8" :y="t.y + 4" class="axis-label" text-anchor="end">{{ t.value }}</text>
          </template>
          <!-- Line -->
          <polyline :points="points" class="data-line" fill="none" />
          <!-- Data dots -->
          <circle v-for="(p, i) in dataPoints" :key="i" :cx="p.x" :cy="p.y" r="4" class="data-dot">
            <title>{{ formatDate(p.run.timestamp) }}: {{ p.run.total_findings }} findings</title>
          </circle>
          <!-- X axis labels (first, middle, last) -->
          <text v-if="runs.length" :x="padX" :y="chartH - 4" class="axis-label">{{ formatDate(runs[0].timestamp) }}</text>
          <text v-if="runs.length" :x="chartW - padX" :y="chartH - 4" class="axis-label" text-anchor="end">{{ formatDate(runs[runs.length - 1].timestamp) }}</text>
        </svg>
        <p v-else class="empty">Not enough data for chart (need at least 2 runs).</p>
      </section>

      <section class="runs-section">
        <h2>Historical Runs</h2>
        <table v-if="runs.length" class="data-table">
          <thead><tr><th>Date</th><th>Total Findings</th><th>Actions</th></tr></thead>
          <tbody>
            <tr v-for="r in runs" :key="r.timestamp">
              <td>{{ formatDate(r.timestamp) }}</td>
              <td>{{ r.total_findings }}</td>
              <td><button class="btn btn-sm" @click="viewReport(r)">View Report</button></td>
            </tr>
          </tbody>
        </table>
        <p v-else class="empty">No historical runs available.</p>
      </section>
    </template>
  </div>
</template>

<style scoped>
.history-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; }
.chart-section { margin-bottom: 2rem; }
.line-chart { width: 100%; max-width: 750px; height: auto; background: var(--bg-secondary); border-radius: 8px; padding: 0.5rem; }
.grid-line { stroke: var(--border); stroke-width: 0.5; stroke-dasharray: 4,4; }
.axis-label { fill: var(--text-secondary); font-size: 11px; }
.data-line { stroke: var(--accent); stroke-width: 2.5; stroke-linejoin: round; }
.data-dot { fill: var(--accent); cursor: pointer; }
.data-dot:hover { r: 6; }
.runs-section { margin-bottom: 2rem; }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn-sm { padding: 0.25rem 0.5rem; font-size: 0.8rem; }
.empty { color: var(--text-secondary); font-style: italic; padding: 1rem 0; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
