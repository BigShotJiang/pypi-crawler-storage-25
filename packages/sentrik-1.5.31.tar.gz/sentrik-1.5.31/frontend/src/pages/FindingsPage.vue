<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'

interface Finding {
  finding_id: string
  rule_id: string
  severity: string
  message: string
  evidence: { file: string; lines: number[]; snippet: string }
  suggestion: string
  confidence: number
  is_obligation: boolean
  risk_score: number
  _selected?: boolean
}

const emit = defineEmits<{ (e: 'suppress', ids: string[]): void; (e: 'export', ids: string[]): void }>()

const findings = ref<Finding[]>([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const severityFilter = ref<string[]>([])
const groupBy = ref<'none' | 'file' | 'rule' | 'severity'>('none')
const sortCol = ref<keyof Finding>('severity')
const sortAsc = ref(true)
const page = ref(1)
const pageSize = 50
const expandedId = ref<string | null>(null)
const selectAll = ref(false)

const severities = ['critical', 'high', 'medium', 'low', 'info']
const sevOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3, info: 4 }

onMounted(async () => {
  try {
    const res = await fetch('/api/findings')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    findings.value = (await res.json()).map((f: Finding) => ({ ...f, _selected: false }))
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const filtered = computed(() => {
  let list = findings.value
  if (search.value) {
    const q = search.value.toLowerCase()
    list = list.filter(f => f.message.toLowerCase().includes(q) || f.rule_id.toLowerCase().includes(q) || f.evidence.file.toLowerCase().includes(q))
  }
  if (severityFilter.value.length) list = list.filter(f => severityFilter.value.includes(f.severity))
  list = [...list].sort((a, b) => {
    const col = sortCol.value
    let av = col === 'severity' ? sevOrder[a.severity] : (a as any)[col]
    let bv = col === 'severity' ? sevOrder[b.severity] : (b as any)[col]
    if (av < bv) return sortAsc.value ? -1 : 1
    if (av > bv) return sortAsc.value ? 1 : -1
    return 0
  })
  return list
})

const totalPages = computed(() => Math.max(1, Math.ceil(filtered.value.length / pageSize)))
const paged = computed(() => filtered.value.slice((page.value - 1) * pageSize, page.value * pageSize))

const grouped = computed(() => {
  if (groupBy.value === 'none') return null
  const map = new Map<string, Finding[]>()
  for (const f of filtered.value) {
    const key = groupBy.value === 'file' ? f.evidence.file : groupBy.value === 'rule' ? f.rule_id : f.severity
    if (!map.has(key)) map.set(key, [])
    map.get(key)!.push(f)
  }
  return map
})

watch(search, () => { page.value = 1 })
watch(severityFilter, () => { page.value = 1 }, { deep: true })

function toggleSev(s: string) {
  const idx = severityFilter.value.indexOf(s)
  if (idx >= 0) severityFilter.value.splice(idx, 1)
  else severityFilter.value.push(s)
}

function toggleSort(col: keyof Finding) {
  if (sortCol.value === col) sortAsc.value = !sortAsc.value
  else { sortCol.value = col; sortAsc.value = true }
}

function toggleExpand(id: string) { expandedId.value = expandedId.value === id ? null : id }

function toggleSelectAll() {
  selectAll.value = !selectAll.value
  paged.value.forEach(f => f._selected = selectAll.value)
}

const selectedIds = computed(() => findings.value.filter(f => f._selected).map(f => f.finding_id))

function bulkSuppress() { emit('suppress', selectedIds.value) }
function bulkExport() { emit('export', selectedIds.value) }
</script>

<template>
  <div class="findings-page">
    <h1>Findings</h1>
    <div class="toolbar">
      <input v-model="search" class="search-input" placeholder="Search findings..." />
      <div class="pills">
        <button v-for="s in severities" :key="s" class="pill" :class="{ active: severityFilter.includes(s), [s]: true }" @click="toggleSev(s)">{{ s }}</button>
      </div>
      <select v-model="groupBy" class="group-select">
        <option value="none">No grouping</option>
        <option value="file">Group by file</option>
        <option value="rule">Group by rule</option>
        <option value="severity">Group by severity</option>
      </select>
    </div>

    <div v-if="selectedIds.length" class="bulk-bar">
      <span>{{ selectedIds.length }} selected</span>
      <button class="btn btn-warn" @click="bulkSuppress">Suppress</button>
      <button class="btn" @click="bulkExport">Export</button>
    </div>

    <div v-if="loading" class="loading">Loading findings...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <template v-else-if="groupBy === 'none'">
      <table class="data-table">
        <thead>
          <tr>
            <th><input type="checkbox" :checked="selectAll" @change="toggleSelectAll" /></th>
            <th @click="toggleSort('severity')" class="sortable">Severity</th>
            <th @click="toggleSort('rule_id')" class="sortable">Rule</th>
            <th>File</th>
            <th @click="toggleSort('message')" class="sortable">Message</th>
          </tr>
        </thead>
        <tbody>
          <template v-for="f in paged" :key="f.finding_id">
            <tr @click="toggleExpand(f.finding_id)" class="clickable">
              <td @click.stop><input type="checkbox" v-model="f._selected" /></td>
              <td><span class="sev-badge" :class="f.severity">{{ f.severity }}</span></td>
              <td class="mono">{{ f.rule_id }}</td>
              <td class="mono file-path">{{ f.evidence.file }}</td>
              <td>{{ f.message }}</td>
            </tr>
            <tr v-if="expandedId === f.finding_id" class="detail-row">
              <td colspan="5">
                <div class="detail">
                  <pre class="snippet">{{ f.evidence.snippet }}</pre>
                  <p v-if="f.suggestion"><strong>Suggestion:</strong> {{ f.suggestion }}</p>
                  <p><strong>Risk score:</strong> {{ f.risk_score }} | <strong>Confidence:</strong> {{ f.confidence }} | <strong>Lines:</strong> {{ f.evidence.lines.join(', ') }}</p>
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
      <div class="pagination">
        <button class="btn" :disabled="page <= 1" @click="page--">Prev</button>
        <span>Page {{ page }} / {{ totalPages }}</span>
        <button class="btn" :disabled="page >= totalPages" @click="page++">Next</button>
      </div>
    </template>
    <template v-else-if="grouped">
      <div v-for="[key, items] in grouped" :key="key" class="group">
        <h3>{{ key }} <span class="group-count">({{ items.length }})</span></h3>
        <div v-for="f in items" :key="f.finding_id" class="group-item" @click="toggleExpand(f.finding_id)">
          <span class="sev-badge" :class="f.severity">{{ f.severity }}</span>
          <span class="mono">{{ f.rule_id }}</span>
          <span>{{ f.message }}</span>
          <div v-if="expandedId === f.finding_id" class="detail">
            <pre class="snippet">{{ f.evidence.snippet }}</pre>
            <p v-if="f.suggestion"><strong>Suggestion:</strong> {{ f.suggestion }}</p>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.findings-page { padding: 1.5rem; }
h1 { margin: 0 0 1rem; color: var(--text-primary); }
.toolbar { display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; margin-bottom: 1rem; }
.search-input { padding: 0.5rem 0.75rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg-secondary); color: var(--text-primary); flex: 1; min-width: 200px; }
.pills { display: flex; gap: 0.35rem; }
.pill { padding: 0.3rem 0.7rem; border-radius: 12px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-secondary); cursor: pointer; font-size: 0.8rem; text-transform: capitalize; }
.pill.active.critical { background: var(--sev-critical); color: #fff; border-color: var(--sev-critical); }
.pill.active.high { background: var(--sev-high); color: #fff; border-color: var(--sev-high); }
.pill.active.medium { background: var(--sev-medium); color: #fff; border-color: var(--sev-medium); }
.pill.active.low { background: var(--sev-low); color: #fff; border-color: var(--sev-low); }
.pill.active.info { background: var(--sev-info); color: #fff; border-color: var(--sev-info); }
.group-select { padding: 0.4rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); }
.bulk-bar { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 1rem; background: var(--bg-tertiary); border-radius: 6px; margin-bottom: 0.75rem; color: var(--text-primary); }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.sortable { cursor: pointer; user-select: none; }
.clickable { cursor: pointer; }
.clickable:hover { background: var(--bg-tertiary); }
.mono { font-family: monospace; font-size: 0.85rem; }
.file-path { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sev-badge { padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.75rem; color: #fff; text-transform: uppercase; font-weight: 600; }
.sev-badge.critical { background: var(--sev-critical); }
.sev-badge.high { background: var(--sev-high); }
.sev-badge.medium { background: var(--sev-medium); }
.sev-badge.low { background: var(--sev-low); }
.sev-badge.info { background: var(--sev-info); }
.detail-row td { background: var(--bg-tertiary); }
.detail { padding: 0.5rem; }
.snippet { background: var(--bg-primary); padding: 0.75rem; border-radius: 6px; overflow-x: auto; font-size: 0.85rem; color: var(--text-primary); }
.pagination { display: flex; align-items: center; justify-content: center; gap: 1rem; margin-top: 1rem; color: var(--text-secondary); }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-warn { background: var(--sev-high); color: #fff; border-color: var(--sev-high); }
.group { margin-bottom: 1.5rem; }
.group h3 { color: var(--text-primary); margin: 0 0 0.5rem; }
.group-count { color: var(--text-secondary); font-weight: 400; }
.group-item { padding: 0.5rem 0.75rem; border-bottom: 1px solid var(--border); display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; cursor: pointer; color: var(--text-primary); }
.group-item:hover { background: var(--bg-tertiary); }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
