<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

interface Vuln {
  cve_id: string
  package: string
  severity: string
  fix_version: string
  description: string
}

const vulns = ref<Vuln[]>([])
const loading = ref(true)
const scanning = ref(false)
const error = ref('')

const sevOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3, info: 4 }

onMounted(async () => {
  await loadVulns()
})

async function loadVulns() {
  loading.value = true
  error.value = ''
  try {
    const res = await fetch('/api/vulns')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    vulns.value = (await res.json()).sort((a: Vuln, b: Vuln) => (sevOrder[a.severity] ?? 5) - (sevOrder[b.severity] ?? 5))
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

async function rescan() {
  scanning.value = true
  error.value = ''
  try {
    const res = await fetch('/api/vulns?refresh=true', { method: 'POST' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    vulns.value = (await res.json()).sort((a: Vuln, b: Vuln) => (sevOrder[a.severity] ?? 5) - (sevOrder[b.severity] ?? 5))
  } catch (e: any) {
    error.value = e.message
  } finally {
    scanning.value = false
  }
}

const bySeverity = computed(() => {
  const counts: Record<string, number> = {}
  for (const v of vulns.value) counts[v.severity] = (counts[v.severity] || 0) + 1
  return counts
})

const severities = ['critical', 'high', 'medium', 'low', 'info']
</script>

<template>
  <div class="vulns-page">
    <div class="header">
      <h1>Vulnerabilities</h1>
      <button class="btn btn-primary" @click="rescan" :disabled="scanning">{{ scanning ? 'Scanning...' : 'Scan Now' }}</button>
    </div>

    <div v-if="error" class="error">{{ error }}</div>

    <div class="cards">
      <div class="card">
        <span class="card-label">Total</span>
        <span class="card-value">{{ vulns.length }}</span>
      </div>
      <div v-for="s in severities" :key="s" class="card" :class="{ 'has-count': bySeverity[s] }">
        <span class="card-label">{{ s }}</span>
        <span class="card-value" :class="'sev-' + s">{{ bySeverity[s] || 0 }}</span>
      </div>
    </div>

    <div v-if="loading" class="loading">Loading vulnerabilities...</div>
    <template v-else>
      <table v-if="vulns.length" class="data-table">
        <thead>
          <tr><th>CVE ID</th><th>Package</th><th>Severity</th><th>Fix Version</th><th>Description</th></tr>
        </thead>
        <tbody>
          <tr v-for="v in vulns" :key="v.cve_id">
            <td class="mono">{{ v.cve_id }}</td>
            <td class="mono">{{ v.package }}</td>
            <td><span class="sev-badge" :class="v.severity">{{ v.severity }}</span></td>
            <td class="mono">{{ v.fix_version || '-' }}</td>
            <td>{{ v.description }}</td>
          </tr>
        </tbody>
      </table>
      <p v-else class="empty">No vulnerabilities found.</p>
    </template>
  </div>
</template>

<style scoped>
.vulns-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
h1 { margin: 0; color: var(--text-primary); }
.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 0.75rem; margin-bottom: 1.5rem; }
.card { background: var(--bg-secondary); border-radius: 8px; padding: 1rem; text-align: center; }
.card-label { display: block; font-size: 0.8rem; color: var(--text-secondary); text-transform: capitalize; margin-bottom: 0.25rem; }
.card-value { font-size: 1.75rem; font-weight: 700; color: var(--text-primary); }
.sev-critical { color: var(--sev-critical); }
.sev-high { color: var(--sev-high); }
.sev-medium { color: var(--sev-medium); }
.sev-low { color: var(--sev-low); }
.sev-info { color: var(--sev-info); }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); font-size: 0.9rem; }
.mono { font-family: monospace; font-size: 0.85rem; }
.sev-badge { padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.75rem; color: #fff; text-transform: uppercase; font-weight: 600; }
.sev-badge.critical { background: var(--sev-critical); }
.sev-badge.high { background: var(--sev-high); }
.sev-badge.medium { background: var(--sev-medium); }
.sev-badge.low { background: var(--sev-low); }
.sev-badge.info { background: var(--sev-info); }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.empty { color: var(--text-secondary); font-style: italic; text-align: center; padding: 2rem; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
