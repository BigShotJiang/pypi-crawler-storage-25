<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

interface License {
  package: string
  license: string
  risk: string
}

const licenses = ref<License[]>([])
const loading = ref(true)
const scanning = ref(false)
const error = ref('')
const riskFilter = ref<string[]>([])

const riskLevels = ['high', 'medium', 'low']
const riskColors: Record<string, string> = {
  high: 'var(--sev-critical)',
  medium: 'var(--sev-medium)',
  low: 'var(--sev-info)',
}

onMounted(async () => {
  await loadLicenses()
})

async function loadLicenses() {
  loading.value = true
  error.value = ''
  try {
    const res = await fetch('/api/licenses')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    licenses.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

async function rescan() {
  scanning.value = true
  error.value = ''
  try {
    const res = await fetch('/api/licenses?refresh=true', { method: 'POST' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    licenses.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    scanning.value = false
  }
}

function toggleRisk(r: string) {
  const idx = riskFilter.value.indexOf(r)
  if (idx >= 0) riskFilter.value.splice(idx, 1)
  else riskFilter.value.push(r)
}

const filtered = computed(() => {
  if (!riskFilter.value.length) return licenses.value
  return licenses.value.filter(l => riskFilter.value.includes(l.risk))
})
</script>

<template>
  <div class="licenses-page">
    <div class="header">
      <h1>License Compliance</h1>
      <button class="btn btn-primary" @click="rescan" :disabled="scanning">{{ scanning ? 'Scanning...' : 'Scan Now' }}</button>
    </div>

    <div v-if="error" class="error">{{ error }}</div>

    <div class="toolbar">
      <div class="pills">
        <button v-for="r in riskLevels" :key="r" class="pill" :class="{ active: riskFilter.includes(r) }" @click="toggleRisk(r)">
          <span class="risk-dot" :style="{ backgroundColor: riskColors[r] }"></span> {{ r }}
        </button>
      </div>
    </div>

    <div v-if="loading" class="loading">Loading licenses...</div>
    <template v-else>
      <table v-if="filtered.length" class="data-table">
        <thead><tr><th>Package</th><th>License</th><th>Risk Level</th></tr></thead>
        <tbody>
          <tr v-for="l in filtered" :key="l.package">
            <td class="mono">{{ l.package }}</td>
            <td>{{ l.license }}</td>
            <td><span class="risk-badge" :style="{ color: riskColors[l.risk] || 'var(--text-secondary)' }">{{ l.risk }}</span></td>
          </tr>
        </tbody>
      </table>
      <p v-else class="empty">No license data available.</p>
      <p class="count">{{ filtered.length }} packages</p>
    </template>
  </div>
</template>

<style scoped>
.licenses-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
h1 { margin: 0; color: var(--text-primary); }
.toolbar { margin-bottom: 1rem; }
.pills { display: flex; gap: 0.35rem; }
.pill { padding: 0.35rem 0.75rem; border-radius: 12px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-secondary); cursor: pointer; font-size: 0.85rem; display: flex; align-items: center; gap: 0.35rem; text-transform: capitalize; }
.pill.active { background: var(--bg-tertiary); border-color: var(--accent); color: var(--text-primary); }
.risk-dot { width: 8px; height: 8px; border-radius: 50%; }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); font-size: 0.9rem; }
.mono { font-family: monospace; font-size: 0.85rem; }
.risk-badge { font-weight: 600; text-transform: capitalize; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.count { color: var(--text-secondary); font-size: 0.85rem; margin-top: 0.75rem; }
.empty { color: var(--text-secondary); font-style: italic; text-align: center; padding: 2rem; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
