<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'

interface Metrics {
  scan_metrics: {
    total_duration_ms: number
    rules_engine_ms: number
    files_scanned: number
    cache_hits: number
    cache_misses: number
    findings_by_severity: Record<string, number>
    agent_metrics?: Record<string, { duration_ms: number; findings: number }>
  }
  findings_count: number
  compliance_score: { score: number; rules_passed: number; rules_total: number }
  findings_by_file: Record<string, number>
}

const metrics = ref<Metrics | null>(null)
const loading = ref(true)
const error = ref('')
const agentExpanded = ref(false)

onMounted(async () => {
  try {
    const res = await fetch('/api/metrics')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    metrics.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const scoreColor = computed(() => {
  if (!metrics.value) return 'var(--text-secondary)'
  const s = metrics.value.compliance_score.score
  if (s >= 90) return 'var(--sev-info)'
  if (s >= 70) return 'var(--sev-medium)'
  return 'var(--sev-critical)'
})

const criticalCount = computed(() => metrics.value?.scan_metrics.findings_by_severity.critical ?? 0)

const severities = ['critical', 'high', 'medium', 'low', 'info'] as const
const sevColors: Record<string, string> = {
  critical: 'var(--sev-critical)',
  high: 'var(--sev-high)',
  medium: 'var(--sev-medium)',
  low: 'var(--sev-low)',
  info: 'var(--sev-info)',
}

const totalSevFindings = computed(() => {
  if (!metrics.value) return 0
  return Object.values(metrics.value.scan_metrics.findings_by_severity).reduce((a, b) => a + b, 0)
})

const topFiles = computed(() => {
  if (!metrics.value) return []
  return Object.entries(metrics.value.findings_by_file)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
})
</script>

<template>
  <div class="overview-page">
    <h1>Overview</h1>
    <div v-if="loading" class="loading">Loading metrics...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <template v-else-if="metrics">
      <div class="cards">
        <div class="card score-card">
          <span class="card-label">Compliance Score</span>
          <span class="card-value" :style="{ color: scoreColor }">{{ metrics.compliance_score.score }}%</span>
          <span class="card-sub">{{ metrics.compliance_score.rules_passed }}/{{ metrics.compliance_score.rules_total }} rules</span>
        </div>
        <div class="card">
          <span class="card-label">Total Findings</span>
          <span class="card-value">{{ metrics.findings_count }}</span>
          <div class="sparkline">
            <span v-for="sev in severities" :key="sev" class="spark-segment"
              :style="{ flex: metrics.scan_metrics.findings_by_severity[sev] || 0, backgroundColor: sevColors[sev] }"
              :title="`${sev}: ${metrics.scan_metrics.findings_by_severity[sev] || 0}`" />
          </div>
        </div>
        <div class="card" :class="{ 'card-danger': criticalCount > 0 }">
          <span class="card-label">Critical Findings</span>
          <span class="card-value">{{ criticalCount }}</span>
        </div>
        <div class="card">
          <span class="card-label">Duration</span>
          <span class="card-value">{{ metrics.scan_metrics.total_duration_ms }} ms</span>
        </div>
        <div class="card">
          <span class="card-label">Files Scanned</span>
          <span class="card-value">{{ metrics.scan_metrics.files_scanned }}</span>
        </div>
      </div>

      <section class="severity-bar-section">
        <h2>Severity Distribution</h2>
        <div class="severity-bar" v-if="totalSevFindings > 0">
          <div v-for="sev in severities" :key="sev" class="sev-segment"
            :style="{ width: ((metrics.scan_metrics.findings_by_severity[sev] || 0) / totalSevFindings * 100) + '%', backgroundColor: sevColors[sev] }">
            <span v-if="(metrics.scan_metrics.findings_by_severity[sev] || 0) > 0" class="sev-label">
              {{ sev }} ({{ metrics.scan_metrics.findings_by_severity[sev] }})
            </span>
          </div>
        </div>
        <p v-else class="empty">No findings</p>
      </section>

      <section v-if="metrics.scan_metrics.agent_metrics" class="agent-section">
        <h2 @click="agentExpanded = !agentExpanded" class="collapsible">
          Agent Metrics <span class="toggle">{{ agentExpanded ? '\u25BC' : '\u25B6' }}</span>
        </h2>
        <table v-if="agentExpanded" class="data-table">
          <thead><tr><th>Pack</th><th>Duration (ms)</th><th>Findings</th></tr></thead>
          <tbody>
            <tr v-for="(m, pack) in metrics.scan_metrics.agent_metrics" :key="pack">
              <td>{{ pack }}</td><td>{{ m.duration_ms }}</td><td>{{ m.findings }}</td>
            </tr>
          </tbody>
        </table>
      </section>

      <section class="top-files-section">
        <h2>Top Files by Findings</h2>
        <table class="data-table">
          <thead><tr><th>File</th><th>Findings</th></tr></thead>
          <tbody>
            <tr v-for="[file, count] in topFiles" :key="file">
              <td class="file-path">{{ file }}</td><td>{{ count }}</td>
            </tr>
          </tbody>
        </table>
      </section>
    </template>
  </div>
</template>

<style scoped>
.overview-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
.loading, .error { padding: 2rem; text-align: center; color: var(--text-secondary); }
.error { color: var(--sev-critical); }
.cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.card { background: var(--bg-secondary); border-radius: 8px; padding: 1.25rem; display: flex; flex-direction: column; gap: 0.25rem; }
.card-label { font-size: 0.8rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.05em; }
.card-value { font-size: 2rem; font-weight: 700; color: var(--text-primary); }
.card-sub { font-size: 0.85rem; color: var(--text-secondary); }
.card-danger { border: 2px solid var(--sev-critical); }
.card-danger .card-value { color: var(--sev-critical); }
.sparkline { display: flex; height: 6px; border-radius: 3px; overflow: hidden; margin-top: 0.5rem; }
.spark-segment { min-width: 2px; }
.severity-bar-section, .agent-section, .top-files-section { margin-bottom: 2rem; }
h2 { color: var(--text-primary); margin: 0 0 0.75rem; font-size: 1.1rem; }
.collapsible { cursor: pointer; user-select: none; }
.toggle { font-size: 0.75rem; margin-left: 0.5rem; }
.severity-bar { display: flex; height: 28px; border-radius: 6px; overflow: hidden; }
.sev-segment { display: flex; align-items: center; justify-content: center; min-width: 2px; transition: width 0.3s; }
.sev-label { font-size: 0.7rem; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 0 4px; }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 1rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); font-size: 0.9rem; }
.file-path { font-family: monospace; font-size: 0.85rem; }
.empty { color: var(--text-secondary); font-style: italic; }
</style>
