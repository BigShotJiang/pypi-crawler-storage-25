<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'

const provider = ref('none')
const config = ref({
  org: '',
  project: '',
  team: '',
  owner: '',
  repo: '',
  base_url: '',
  project_key: '',
})
const loading = ref(true)
const error = ref('')
const testing = ref(false)
const testResult = ref<{ ok: boolean; message: string } | null>(null)
const oauthStatus = ref<Record<string, boolean>>({})

const providers = [
  { value: 'none', label: 'None' },
  { value: 'azure', label: 'Azure DevOps' },
  { value: 'github', label: 'GitHub' },
  { value: 'jira', label: 'Jira' },
]

onMounted(async () => {
  try {
    const [configRes, oauthRes] = await Promise.all([
      fetch('/api/config'),
      fetch('/api/oauth/status'),
    ])
    if (configRes.ok) {
      const data = await configRes.json()
      provider.value = data.devops_provider || 'none'
      config.value.org = data.azure_devops_org || ''
      config.value.project = data.azure_devops_project || ''
      config.value.team = data.azure_devops_team || ''
      config.value.owner = data.github_owner || ''
      config.value.repo = data.github_repo || ''
      config.value.base_url = data.jira_base_url || ''
      config.value.project_key = data.jira_project_key || ''
    }
    if (oauthRes.ok) oauthStatus.value = await oauthRes.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

const isConnected = computed(() => oauthStatus.value[provider.value] || false)

async function saveConfig() {
  const updates: Record<string, string> = { devops_provider: provider.value }
  if (provider.value === 'azure') {
    updates.azure_devops_org = config.value.org
    updates.azure_devops_project = config.value.project
    updates.azure_devops_team = config.value.team
  } else if (provider.value === 'github') {
    updates.github_owner = config.value.owner
    updates.github_repo = config.value.repo
  } else if (provider.value === 'jira') {
    updates.jira_base_url = config.value.base_url
    updates.jira_project_key = config.value.project_key
  }
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updates }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
  } catch (e: any) {
    error.value = e.message
  }
}

function oauthConnect() {
  window.location.href = `/oauth/${provider.value}/login`
}

async function oauthDisconnect() {
  try {
    const res = await fetch(`/oauth/${provider.value}/disconnect`, { method: 'POST' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    oauthStatus.value[provider.value] = false
  } catch (e: any) {
    error.value = e.message
  }
}

async function testConnection() {
  testing.value = true
  testResult.value = null
  try {
    const res = await fetch('/api/devops/test', { method: 'POST' })
    testResult.value = await res.json()
  } catch (e: any) {
    testResult.value = { ok: false, message: e.message }
  } finally {
    testing.value = false
  }
}
</script>

<template>
  <div class="devops-page">
    <h1>DevOps Integration</h1>

    <div v-if="loading" class="loading">Loading configuration...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else>
      <section class="section">
        <h2>Provider</h2>
        <div class="provider-cards">
          <div v-for="p in providers" :key="p.value" class="provider-card" :class="{ active: provider === p.value }" @click="provider = p.value">
            <span class="provider-name">{{ p.label }}</span>
            <span v-if="oauthStatus[p.value]" class="connected-badge">Connected</span>
          </div>
        </div>
      </section>

      <section v-if="provider === 'azure'" class="section">
        <h2>Azure DevOps Configuration</h2>
        <div class="form-group"><label>Organization</label><input v-model="config.org" class="text-input" placeholder="mycompany" /></div>
        <div class="form-group"><label>Project</label><input v-model="config.project" class="text-input" placeholder="MyProject" /></div>
        <div class="form-group"><label>Team (optional)</label><input v-model="config.team" class="text-input" placeholder="MyTeam" /></div>
      </section>

      <section v-if="provider === 'github'" class="section">
        <h2>GitHub Configuration</h2>
        <div class="form-group"><label>Owner</label><input v-model="config.owner" class="text-input" placeholder="org-or-user" /></div>
        <div class="form-group"><label>Repository</label><input v-model="config.repo" class="text-input" placeholder="my-repo" /></div>
      </section>

      <section v-if="provider === 'jira'" class="section">
        <h2>Jira Configuration</h2>
        <div class="form-group"><label>Base URL</label><input v-model="config.base_url" class="text-input" placeholder="https://jira.example.com" /></div>
        <div class="form-group"><label>Project Key</label><input v-model="config.project_key" class="text-input" placeholder="PROJ" /></div>
      </section>

      <section v-if="provider !== 'none'" class="section actions-section">
        <div class="action-row">
          <button class="btn btn-primary" @click="saveConfig">Save Configuration</button>
          <button v-if="!isConnected" class="btn btn-oauth" @click="oauthConnect">Connect via OAuth</button>
          <button v-else class="btn btn-disconnect" @click="oauthDisconnect">Disconnect</button>
          <button class="btn" @click="testConnection" :disabled="testing">{{ testing ? 'Testing...' : 'Test Connection' }}</button>
        </div>
        <div v-if="testResult" class="test-result" :class="{ ok: testResult.ok }">
          {{ testResult.message }}
        </div>
      </section>
    </template>
  </div>
</template>

<style scoped>
.devops-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; }
.section { margin-bottom: 2rem; }
.provider-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 0.75rem; }
.provider-card { background: var(--bg-secondary); border: 2px solid var(--border); border-radius: 8px; padding: 1rem; cursor: pointer; text-align: center; transition: border-color 0.2s; }
.provider-card:hover { border-color: var(--accent); }
.provider-card.active { border-color: var(--accent); background: var(--bg-tertiary); }
.provider-name { display: block; font-weight: 600; color: var(--text-primary); }
.connected-badge { display: inline-block; margin-top: 0.25rem; font-size: 0.75rem; color: var(--sev-info); }
.form-group { margin-bottom: 0.75rem; }
.form-group label { display: block; color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 0.25rem; }
.text-input { width: 100%; max-width: 400px; padding: 0.5rem 0.75rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg-secondary); color: var(--text-primary); }
.actions-section { padding-top: 0.5rem; }
.action-row { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.btn-oauth { background: var(--sev-info); color: #fff; border-color: var(--sev-info); }
.btn-disconnect { background: var(--sev-high); color: #fff; border-color: var(--sev-high); }
.test-result { margin-top: 0.75rem; padding: 0.5rem 0.75rem; border-radius: 6px; background: var(--sev-critical); color: #fff; }
.test-result.ok { background: var(--sev-info); }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
