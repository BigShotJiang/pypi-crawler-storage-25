<script setup lang="ts">
import { ref, onMounted } from 'vue'

interface WorkItem {
  id: string
  title: string
  state: string
  description: string
}

const items = ref<WorkItem[]>([])
const loading = ref(true)
const error = ref('')
const reconciling = ref(false)
const checking = ref(false)
const reconcilePreview = ref<any[] | null>(null)
const coverageResult = ref<any | null>(null)

onMounted(async () => {
  try {
    const res = await fetch('/api/work-items')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    items.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

async function reconcile(dryRun: boolean) {
  reconciling.value = true
  reconcilePreview.value = null
  try {
    const url = dryRun ? '/api/work-items/reconcile?dry_run=true' : '/api/work-items/reconcile'
    const res = await fetch(url, { method: 'POST' })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    if (dryRun) {
      reconcilePreview.value = data.actions || []
    } else {
      reconcilePreview.value = null
      const reload = await fetch('/api/work-items')
      if (reload.ok) items.value = await reload.json()
    }
  } catch (e: any) {
    error.value = e.message
  } finally {
    reconciling.value = false
  }
}

async function checkCoverage() {
  checking.value = true
  coverageResult.value = null
  try {
    const res = await fetch('/api/work-items/coverage')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    coverageResult.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    checking.value = false
  }
}

const stateColor = (s: string) => {
  const sl = s.toLowerCase()
  if (sl === 'done' || sl === 'closed') return 'var(--sev-info)'
  if (sl === 'active' || sl === 'in progress') return 'var(--sev-medium)'
  return 'var(--text-secondary)'
}
</script>

<template>
  <div class="work-items-page">
    <div class="header">
      <h1>Work Items</h1>
      <div class="header-actions">
        <button class="btn" @click="reconcile(true)" :disabled="reconciling">Preview Reconcile</button>
        <button class="btn btn-primary" @click="reconcile(false)" :disabled="reconciling">Reconcile</button>
        <button class="btn" @click="checkCoverage" :disabled="checking">Check Coverage</button>
      </div>
    </div>

    <div v-if="error" class="error">{{ error }}</div>

    <div v-if="reconcilePreview" class="preview-panel">
      <h3>Reconcile Preview</h3>
      <div v-if="reconcilePreview.length">
        <div v-for="(a, i) in reconcilePreview" :key="i" class="preview-action">{{ JSON.stringify(a) }}</div>
      </div>
      <p v-else>No actions needed.</p>
      <button class="btn btn-sm" @click="reconcilePreview = null">Dismiss</button>
    </div>

    <div v-if="coverageResult" class="coverage-panel">
      <h3>Coverage Check</h3>
      <pre class="coverage-output">{{ JSON.stringify(coverageResult, null, 2) }}</pre>
      <button class="btn btn-sm" @click="coverageResult = null">Dismiss</button>
    </div>

    <div v-if="loading" class="loading">Loading work items...</div>
    <template v-else>
      <table v-if="items.length" class="data-table">
        <thead><tr><th>ID</th><th>Title</th><th>State</th><th>Description</th></tr></thead>
        <tbody>
          <tr v-for="item in items" :key="item.id">
            <td class="mono">{{ item.id }}</td>
            <td>{{ item.title }}</td>
            <td><span class="state-badge" :style="{ color: stateColor(item.state) }">{{ item.state }}</span></td>
            <td class="desc-cell">{{ item.description }}</td>
          </tr>
        </tbody>
      </table>
      <p v-else class="empty">No work items found. Connect a DevOps provider first.</p>
    </template>
  </div>
</template>

<style scoped>
.work-items-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.5rem; }
h1 { margin: 0; color: var(--text-primary); }
.header-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.preview-panel, .coverage-panel { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 8px; padding: 1rem; margin-bottom: 1rem; }
.preview-panel h3, .coverage-panel h3 { margin: 0 0 0.5rem; color: var(--text-primary); font-size: 1rem; }
.preview-action { padding: 0.4rem 0; border-bottom: 1px solid var(--border); color: var(--text-primary); font-family: monospace; font-size: 0.85rem; }
.coverage-output { background: var(--bg-primary); padding: 0.75rem; border-radius: 6px; overflow-x: auto; font-size: 0.85rem; color: var(--text-primary); }
.data-table { width: 100%; border-collapse: collapse; background: var(--bg-secondary); border-radius: 8px; overflow: hidden; }
.data-table th, .data-table td { padding: 0.6rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
.data-table th { background: var(--bg-tertiary); color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; }
.data-table td { color: var(--text-primary); font-size: 0.9rem; }
.mono { font-family: monospace; font-size: 0.85rem; }
.state-badge { font-weight: 600; text-transform: capitalize; }
.desc-cell { max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.btn-sm { padding: 0.25rem 0.5rem; font-size: 0.8rem; margin-top: 0.5rem; }
.empty { color: var(--text-secondary); font-style: italic; text-align: center; padding: 2rem; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
