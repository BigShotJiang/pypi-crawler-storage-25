<script setup lang="ts">
import { ref, onMounted } from 'vue'

interface Pack {
  pack_id: string
  name: string
  description: string
  rule_count: number
  source: string
  version: string
  enabled: boolean
}

const packs = ref<Pack[]>([])
const loading = ref(true)
const error = ref('')
const editPack = ref<Pack | null>(null)
const showImport = ref(false)
const importYaml = ref('')

onMounted(async () => {
  try {
    const res = await fetch('/api/packs')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    packs.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

async function togglePack(pack: Pack) {
  const prev = pack.enabled
  pack.enabled = !pack.enabled
  try {
    const res = await fetch('/api/packs/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pack_id: pack.pack_id, enabled: pack.enabled }),
    })
    if (!res.ok) { pack.enabled = prev; throw new Error(`HTTP ${res.status}`) }
  } catch (e: any) {
    pack.enabled = prev
    error.value = e.message
  }
}

function exportPack(pack: Pack) {
  const a = document.createElement('a')
  a.href = `/api/packs/${pack.pack_id}/export`
  a.download = `${pack.pack_id}.yaml`
  a.click()
}

async function importPack() {
  try {
    const res = await fetch('/api/packs/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-yaml' },
      body: importYaml.value,
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const newPack = await res.json()
    packs.value.push(newPack)
    showImport.value = false
    importYaml.value = ''
  } catch (e: any) {
    error.value = e.message
  }
}
</script>

<template>
  <div class="packs-page">
    <div class="header">
      <h1>Standards Packs</h1>
      <button class="btn btn-primary" @click="showImport = true">Import Pack</button>
    </div>

    <div v-if="loading" class="loading">Loading packs...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <div v-else class="pack-grid">
      <div v-for="p in packs" :key="p.pack_id" class="pack-card" :class="{ disabled: !p.enabled }">
        <div class="pack-header">
          <h3>{{ p.name }}</h3>
          <label class="toggle-switch">
            <input type="checkbox" :checked="p.enabled" @change="togglePack(p)" />
            <span class="slider"></span>
          </label>
        </div>
        <p class="pack-desc">{{ p.description }}</p>
        <div class="pack-meta">
          <span>{{ p.rule_count }} rules</span>
          <span>v{{ p.version }}</span>
          <span class="pack-source">{{ p.source }}</span>
        </div>
        <div class="pack-actions">
          <button class="btn btn-sm" @click="editPack = p">Edit</button>
          <button class="btn btn-sm" @click="exportPack(p)">Export</button>
        </div>
      </div>
    </div>

    <!-- Import Modal -->
    <div v-if="showImport" class="modal-overlay" @click.self="showImport = false">
      <div class="modal">
        <h2>Import Standards Pack</h2>
        <p class="modal-hint">Paste YAML content below:</p>
        <textarea v-model="importYaml" class="yaml-input" rows="15" placeholder="# Pack YAML content..."></textarea>
        <div class="modal-actions">
          <button class="btn" @click="showImport = false">Cancel</button>
          <button class="btn btn-primary" @click="importPack" :disabled="!importYaml.trim()">Import</button>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div v-if="editPack" class="modal-overlay" @click.self="editPack = null">
      <div class="modal">
        <h2>{{ editPack.name }}</h2>
        <p class="modal-hint">{{ editPack.description }}</p>
        <p>{{ editPack.rule_count }} rules | v{{ editPack.version }} | {{ editPack.source }}</p>
        <div class="modal-actions">
          <button class="btn" @click="editPack = null">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.packs-page { padding: 1.5rem; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
h1 { margin: 0; color: var(--text-primary); }
.pack-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; }
.pack-card { background: var(--bg-secondary); border-radius: 8px; padding: 1.25rem; border: 1px solid var(--border); transition: border-color 0.2s; }
.pack-card:hover { border-color: var(--accent); }
.pack-card.disabled { opacity: 0.6; }
.pack-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }
.pack-header h3 { margin: 0; color: var(--text-primary); font-size: 1rem; }
.pack-desc { color: var(--text-secondary); font-size: 0.9rem; margin: 0 0 0.75rem; line-height: 1.4; }
.pack-meta { display: flex; gap: 0.75rem; font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 0.75rem; }
.pack-source { background: var(--bg-tertiary); padding: 0.1rem 0.4rem; border-radius: 4px; }
.pack-actions { display: flex; gap: 0.5rem; }
.toggle-switch { position: relative; width: 40px; height: 22px; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; inset: 0; background: var(--bg-tertiary); border-radius: 22px; transition: 0.3s; }
.slider::before { content: ''; position: absolute; height: 16px; width: 16px; left: 3px; bottom: 3px; background: var(--text-secondary); border-radius: 50%; transition: 0.3s; }
.toggle-switch input:checked + .slider { background: var(--accent); }
.toggle-switch input:checked + .slider::before { transform: translateX(18px); background: #fff; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn-sm { padding: 0.25rem 0.5rem; font-size: 0.8rem; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 100; }
.modal { background: var(--bg-primary); border-radius: 12px; padding: 1.5rem; width: 90%; max-width: 600px; max-height: 80vh; overflow-y: auto; }
.modal h2 { margin: 0 0 0.75rem; color: var(--text-primary); }
.modal-hint { color: var(--text-secondary); font-size: 0.9rem; margin: 0 0 0.75rem; }
.yaml-input { width: 100%; border: 1px solid var(--border); border-radius: 6px; background: var(--bg-secondary); color: var(--text-primary); padding: 0.75rem; font-family: monospace; resize: vertical; }
.modal-actions { display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 1rem; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
