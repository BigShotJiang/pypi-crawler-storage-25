<script setup lang="ts">
import { ref, onMounted } from 'vue'

interface Governance {
  profile: string
  defaults: Record<string, any>
  violations: any[]
}

const governance = ref<Governance | null>(null)
const loading = ref(true)
const error = ref('')
const saving = ref(false)

const profiles = ['strict', 'standard', 'permissive']

onMounted(async () => {
  try {
    const res = await fetch('/api/governance')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    governance.value = await res.json()
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

async function saveProfile(profile: string) {
  if (!governance.value) return
  saving.value = true
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updates: { governance_profile: profile } }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    governance.value.profile = profile
  } catch (e: any) {
    error.value = e.message
  } finally {
    saving.value = false
  }
}

async function toggleSetting(key: string, value: boolean) {
  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updates: { [key]: value } }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    if (governance.value) governance.value.defaults[key] = value
  } catch (e: any) {
    error.value = e.message
  }
}

const reviewKeys = [
  { key: 'human_review_on_requirement_change', label: 'Require human review on requirement changes' },
  { key: 'human_review_on_critical_finding', label: 'Require human review on critical findings' },
]

const patchKeys = [
  { key: 'auto_patch_enabled', label: 'Enable auto-patch' },
  { key: 'auto_close_work_items', label: 'Auto-close resolved work items' },
]
</script>

<template>
  <div class="policies-page">
    <h1>Governance Policies</h1>

    <div v-if="loading" class="loading">Loading governance...</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <template v-else-if="governance">
      <section class="section">
        <h2>Profile</h2>
        <div class="profile-cards">
          <div v-for="p in profiles" :key="p" class="profile-card" :class="{ active: governance.profile === p }" @click="saveProfile(p)">
            <span class="profile-name">{{ p }}</span>
            <span class="profile-desc" v-if="p === 'strict'">Maximum oversight, human review for everything</span>
            <span class="profile-desc" v-else-if="p === 'standard'">Balanced governance with reasonable defaults</span>
            <span class="profile-desc" v-else>Maximum agent autonomy, minimal gates</span>
          </div>
        </div>
      </section>

      <section class="section">
        <h2>Human Review</h2>
        <div v-for="r in reviewKeys" :key="r.key" class="setting-row">
          <span class="setting-label">{{ r.label }}</span>
          <label class="toggle-switch">
            <input type="checkbox" :checked="governance.defaults[r.key]" @change="toggleSetting(r.key, ($event.target as HTMLInputElement).checked)" />
            <span class="slider"></span>
          </label>
        </div>
      </section>

      <section class="section">
        <h2>Auto-Patch Controls</h2>
        <div v-for="r in patchKeys" :key="r.key" class="setting-row">
          <span class="setting-label">{{ r.label }}</span>
          <label class="toggle-switch">
            <input type="checkbox" :checked="governance.defaults[r.key]" @change="toggleSetting(r.key, ($event.target as HTMLInputElement).checked)" />
            <span class="slider"></span>
          </label>
        </div>
      </section>

      <section v-if="governance.violations.length" class="section">
        <h2>Violations</h2>
        <div v-for="(v, i) in governance.violations" :key="i" class="violation">{{ JSON.stringify(v) }}</div>
      </section>
    </template>
  </div>
</template>

<style scoped>
.policies-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; }
.section { margin-bottom: 2rem; }
.profile-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 0.75rem; }
.profile-card { background: var(--bg-secondary); border: 2px solid var(--border); border-radius: 8px; padding: 1rem; cursor: pointer; transition: border-color 0.2s; }
.profile-card:hover { border-color: var(--accent); }
.profile-card.active { border-color: var(--accent); background: var(--bg-tertiary); }
.profile-name { display: block; font-weight: 700; text-transform: capitalize; color: var(--text-primary); margin-bottom: 0.25rem; }
.profile-desc { font-size: 0.85rem; color: var(--text-secondary); }
.setting-row { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid var(--border); }
.setting-label { color: var(--text-primary); font-size: 0.95rem; }
.toggle-switch { position: relative; width: 40px; height: 22px; flex-shrink: 0; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.slider { position: absolute; cursor: pointer; inset: 0; background: var(--bg-tertiary); border-radius: 22px; transition: 0.3s; }
.slider::before { content: ''; position: absolute; height: 16px; width: 16px; left: 3px; bottom: 3px; background: var(--text-secondary); border-radius: 50%; transition: 0.3s; }
.toggle-switch input:checked + .slider { background: var(--accent); }
.toggle-switch input:checked + .slider::before { transform: translateX(18px); background: #fff; }
.violation { background: var(--bg-secondary); padding: 0.5rem 0.75rem; border-left: 3px solid var(--sev-critical); margin-bottom: 0.5rem; color: var(--text-primary); font-size: 0.9rem; border-radius: 0 6px 6px 0; }
.loading, .error { padding: 2rem; text-align: center; }
.error { color: var(--sev-critical); }
</style>
