<script setup lang="ts">
import { ref, onMounted } from 'vue'

const formats = [
  { value: 'html', label: 'HTML Report' },
  { value: 'pdf', label: 'PDF Report' },
  { value: 'sarif', label: 'SARIF (Static Analysis)' },
  { value: 'csv', label: 'CSV Export' },
  { value: 'junit', label: 'JUnit XML' },
]

const selectedFormat = ref('html')
const selectedFramework = ref('')
const frameworks = ref<string[]>([])
const loading = ref(true)
const generating = ref(false)
const error = ref('')

onMounted(async () => {
  try {
    const res = await fetch('/api/compliance-report?list=true')
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    frameworks.value = data.frameworks || []
  } catch (e: any) {
    error.value = e.message
  } finally {
    loading.value = false
  }
})

async function generate() {
  generating.value = true
  error.value = ''
  try {
    const params = new URLSearchParams({ format: selectedFormat.value })
    if (selectedFramework.value) params.set('framework', selectedFramework.value)
    const res = await fetch(`/api/compliance-report?${params}`)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    const ext = selectedFormat.value === 'junit' ? 'xml' : selectedFormat.value
    a.download = `compliance-report.${ext}`
    a.click()
    URL.revokeObjectURL(url)
  } catch (e: any) {
    error.value = e.message
  } finally {
    generating.value = false
  }
}
</script>

<template>
  <div class="reports-page">
    <h1>Reports</h1>

    <div v-if="error" class="error">{{ error }}</div>

    <section class="section">
      <h2>Format</h2>
      <div class="format-cards">
        <div v-for="f in formats" :key="f.value" class="format-card" :class="{ active: selectedFormat === f.value }" @click="selectedFormat = f.value">
          <span class="format-name">{{ f.label }}</span>
        </div>
      </div>
    </section>

    <section class="section">
      <h2>Framework Filter</h2>
      <div v-if="loading" class="loading-inline">Loading frameworks...</div>
      <div v-else class="framework-pills">
        <button class="pill" :class="{ active: !selectedFramework }" @click="selectedFramework = ''">All Frameworks</button>
        <button v-for="fw in frameworks" :key="fw" class="pill" :class="{ active: selectedFramework === fw }" @click="selectedFramework = fw">{{ fw }}</button>
      </div>
    </section>

    <section class="section">
      <div class="generate-actions">
        <button class="btn btn-primary btn-lg" @click="generate" :disabled="generating">
          {{ generating ? 'Generating...' : 'Generate & Download' }}
        </button>
      </div>
    </section>
  </div>
</template>

<style scoped>
.reports-page { padding: 1.5rem; }
h1 { margin: 0 0 1.5rem; color: var(--text-primary); }
h2 { color: var(--text-primary); font-size: 1.1rem; margin: 0 0 0.75rem; }
.section { margin-bottom: 2rem; }
.format-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 0.75rem; }
.format-card { background: var(--bg-secondary); border: 2px solid var(--border); border-radius: 8px; padding: 1rem; cursor: pointer; text-align: center; transition: border-color 0.2s; }
.format-card:hover { border-color: var(--accent); }
.format-card.active { border-color: var(--accent); background: var(--bg-tertiary); }
.format-name { font-weight: 600; color: var(--text-primary); }
.framework-pills { display: flex; flex-wrap: wrap; gap: 0.35rem; }
.pill { padding: 0.35rem 0.75rem; border-radius: 12px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-secondary); cursor: pointer; font-size: 0.85rem; }
.pill.active { background: var(--accent); color: #fff; border-color: var(--accent); }
.generate-actions { display: flex; gap: 0.5rem; }
.btn { padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-secondary); color: var(--text-primary); cursor: pointer; }
.btn:disabled { opacity: 0.4; cursor: default; }
.btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
.btn-lg { padding: 0.6rem 1.5rem; font-size: 1rem; }
.loading-inline { color: var(--text-secondary); font-size: 0.9rem; }
.error { color: var(--sev-critical); padding: 0.5rem 0; }
</style>
