import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import { useTheme } from './composables/useTheme'
import './styles/variables.css'

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)

// Apply stored theme before first render to avoid flash
const { init: initTheme } = useTheme()
initTheme()

app.mount('#app')
