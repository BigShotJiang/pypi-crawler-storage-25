import { ref } from 'vue'

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public body?: unknown,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const resp = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  })

  if (!resp.ok) {
    let body: unknown
    try {
      body = await resp.json()
    } catch {
      body = await resp.text().catch(() => null)
    }
    const msg =
      body && typeof body === 'object' && 'detail' in body
        ? String((body as Record<string, unknown>).detail)
        : `HTTP ${resp.status}: ${resp.statusText}`
    throw new ApiError(msg, resp.status, body)
  }

  // Handle 204 No Content
  if (resp.status === 204) {
    return undefined as T
  }

  return resp.json() as Promise<T>
}

export function useApi() {
  const loading = ref(false)
  const error = ref<string | null>(null)

  async function get<T>(url: string): Promise<T> {
    loading.value = true
    error.value = null
    try {
      return await request<T>(url)
    } catch (err) {
      error.value = err instanceof Error ? err.message : String(err)
      throw err
    } finally {
      loading.value = false
    }
  }

  async function post<T>(url: string, body?: unknown): Promise<T> {
    loading.value = true
    error.value = null
    try {
      return await request<T>(url, {
        method: 'POST',
        body: body !== undefined ? JSON.stringify(body) : undefined,
      })
    } catch (err) {
      error.value = err instanceof Error ? err.message : String(err)
      throw err
    } finally {
      loading.value = false
    }
  }

  return { get, post, loading, error }
}
