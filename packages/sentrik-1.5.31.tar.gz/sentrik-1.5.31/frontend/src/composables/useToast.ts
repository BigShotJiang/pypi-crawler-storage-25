import { reactive } from 'vue'

export type ToastType = 'success' | 'error' | 'info'

export interface Toast {
  id: number
  message: string
  type: ToastType
}

let nextId = 0

const toasts = reactive<Toast[]>([])

export function useToast() {
  function show(message: string, type: ToastType = 'info') {
    const id = nextId++
    toasts.push({ id, message, type })

    setTimeout(() => {
      const idx = toasts.findIndex((t) => t.id === id)
      if (idx !== -1) toasts.splice(idx, 1)
    }, 3000)
  }

  function dismiss(id: number) {
    const idx = toasts.findIndex((t) => t.id === id)
    if (idx !== -1) toasts.splice(idx, 1)
  }

  return { toasts, show, dismiss }
}
