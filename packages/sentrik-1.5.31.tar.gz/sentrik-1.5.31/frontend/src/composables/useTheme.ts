import { ref, watch } from 'vue'

const STORAGE_KEY = 'guard-theme'

function readStoredTheme(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) !== 'light'
  } catch {
    return true // default to dark
  }
}

const isDark = ref(readStoredTheme())

function applyTheme(dark: boolean): void {
  const html = document.documentElement
  if (dark) {
    html.removeAttribute('data-theme')
  } else {
    html.setAttribute('data-theme', 'light')
  }
}

// Keep DOM in sync whenever the ref changes
watch(isDark, (dark) => {
  applyTheme(dark)
  try {
    localStorage.setItem(STORAGE_KEY, dark ? 'dark' : 'light')
  } catch {
    // storage unavailable — ignore
  }
})

export function useTheme() {
  function toggle(): void {
    isDark.value = !isDark.value
  }

  /** Call once at app startup to apply the stored theme to <html>. */
  function init(): void {
    applyTheme(isDark.value)
  }

  return { isDark, toggle, init }
}
