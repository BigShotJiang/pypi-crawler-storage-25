import { onMounted, onUnmounted, ref } from 'vue'
import { useDashboardStore } from '../stores/dashboard'

export interface KeyboardOptions {
  onSearch?: () => void
  onHelp?: () => void
  onEscape?: () => void
}

/** Tab names in sidebar order, mapped to number keys 1-9. */
const TAB_ORDER: string[] = [
  'overview',
  'findings',
  'vulns',
  'history',
  'rules',
  'packs',
  'reports',
  'licenses',
  'workitems',
]

export function useKeyboard(options: KeyboardOptions = {}) {
  const searchOpen = ref(false)
  const helpOpen = ref(false)

  function handleKeyDown(e: KeyboardEvent): void {
    // Ignore when typing in an input / textarea / select
    const tag = (e.target as HTMLElement)?.tagName
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') {
      if (e.key === 'Escape') {
        ;(e.target as HTMLElement).blur()
      }
      return
    }

    const store = useDashboardStore()

    // Number keys 1-9 → switch tab
    if (e.key >= '1' && e.key <= '9') {
      const idx = Number(e.key) - 1
      if (idx < TAB_ORDER.length) {
        e.preventDefault()
        store.activeTab = TAB_ORDER[idx]
      }
      return
    }

    switch (e.key) {
      case '/':
        e.preventDefault()
        searchOpen.value = true
        options.onSearch?.()
        break

      case '?':
        e.preventDefault()
        helpOpen.value = true
        options.onHelp?.()
        break

      case 'S':
        if (!e.ctrlKey && !e.metaKey) {
          e.preventDefault()
          store.runScan()
        }
        break

      case 'G':
        if (!e.ctrlKey && !e.metaKey) {
          e.preventDefault()
          store.runGate()
        }
        break

      case 'Escape':
        searchOpen.value = false
        helpOpen.value = false
        options.onEscape?.()
        break

      case 'ArrowUp': {
        e.preventDefault()
        const curIdx = TAB_ORDER.indexOf(store.activeTab)
        if (curIdx > 0) {
          store.activeTab = TAB_ORDER[curIdx - 1]
        }
        break
      }

      case 'ArrowDown': {
        e.preventDefault()
        const curIdx = TAB_ORDER.indexOf(store.activeTab)
        if (curIdx >= 0 && curIdx < TAB_ORDER.length - 1) {
          store.activeTab = TAB_ORDER[curIdx + 1]
        }
        break
      }
    }
  }

  onMounted(() => {
    document.addEventListener('keydown', handleKeyDown)
  })

  onUnmounted(() => {
    document.removeEventListener('keydown', handleKeyDown)
  })

  return { searchOpen, helpOpen }
}
