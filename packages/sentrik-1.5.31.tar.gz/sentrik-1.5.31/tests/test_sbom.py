"""Tests for the SBOM generator."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from guard.core.sbom import (
    Component,
    SBOMMetadata,
    detect_manifests,
    generate_cyclonedx,
    generate_spdx,
    parse_dependencies,
)


# ---------------------------------------------------------------------------
# detect_manifests
# ---------------------------------------------------------------------------


class TestDetectManifests:
    def test_detect_manifests_package_json(self, tmp_path: Path):
        (tmp_path / "package.json").write_text("{}", encoding="utf-8")
        result = detect_manifests(tmp_path)
        assert len(result) == 1
        assert result[0].name == "package.json"

    def test_detect_manifests_requirements_txt(self, tmp_path: Path):
        (tmp_path / "requirements.txt").write_text("flask==3.0.0", encoding="utf-8")
        result = detect_manifests(tmp_path)
        assert len(result) == 1
        assert result[0].name == "requirements.txt"

    def test_detect_manifests_multiple(self, tmp_path: Path):
        (tmp_path / "package.json").write_text("{}", encoding="utf-8")
        (tmp_path / "requirements.txt").write_text("", encoding="utf-8")
        (tmp_path / "go.mod").write_text("", encoding="utf-8")
        result = detect_manifests(tmp_path)
        assert len(result) == 3
        names = {p.name for p in result}
        assert names == {"package.json", "requirements.txt", "go.mod"}

    def test_detect_manifests_none(self, tmp_path: Path):
        result = detect_manifests(tmp_path)
        assert result == []

    def test_detect_manifests_ignores_non_manifest(self, tmp_path: Path):
        (tmp_path / "README.md").write_text("# Hello", encoding="utf-8")
        (tmp_path / "main.py").write_text("print(1)", encoding="utf-8")
        result = detect_manifests(tmp_path)
        assert result == []


# ---------------------------------------------------------------------------
# parse_dependencies — package.json
# ---------------------------------------------------------------------------


class TestParsePackageJson:
    def test_parse_package_json(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text(json.dumps({
            "dependencies": {
                "express": "^4.18.2",
                "lodash": "~4.17.21",
            },
            "devDependencies": {
                "jest": "29.7.0",
            },
        }), encoding="utf-8")

        components = parse_dependencies(pkg)
        assert len(components) == 3
        names = {c.name for c in components}
        assert names == {"express", "lodash", "jest"}

        express = next(c for c in components if c.name == "express")
        assert express.version == "4.18.2"
        assert express.ecosystem == "npm"
        assert express.scope == "required"

        jest = next(c for c in components if c.name == "jest")
        assert jest.scope == "dev"

    def test_parse_package_json_empty(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text("{}", encoding="utf-8")
        assert parse_dependencies(pkg) == []

    def test_parse_package_json_invalid(self, tmp_path: Path):
        pkg = tmp_path / "package.json"
        pkg.write_text("not json!", encoding="utf-8")
        assert parse_dependencies(pkg) == []


# ---------------------------------------------------------------------------
# parse_dependencies — requirements.txt
# ---------------------------------------------------------------------------


class TestParseRequirementsTxt:
    def test_parse_requirements_txt(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text(
            "requests==2.31.0\nflask>=3.0.0\nnumpy~=1.26.0\n# comment\n\n-r other.txt\n",
            encoding="utf-8",
        )
        components = parse_dependencies(req)
        assert len(components) == 3
        names = {c.name: c.version for c in components}
        assert names["requests"] == "2.31.0"
        assert names["flask"] == "3.0.0"
        assert names["numpy"] == "1.26.0"
        assert all(c.ecosystem == "pypi" for c in components)

    def test_parse_requirements_txt_name_only(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("click\n", encoding="utf-8")
        components = parse_dependencies(req)
        assert len(components) == 1
        assert components[0].name == "click"
        assert components[0].version == "0.0.0"


# ---------------------------------------------------------------------------
# parse_dependencies — pyproject.toml
# ---------------------------------------------------------------------------


class TestParsePyprojectToml:
    def test_parse_pyproject_toml(self, tmp_path: Path):
        toml = tmp_path / "pyproject.toml"
        toml.write_text(
            '[project]\nname = "myapp"\ndependencies = [\n'
            '    "requests>=2.31.0",\n'
            '    "click~=8.1",\n'
            '    "pydantic",\n'
            "]\n",
            encoding="utf-8",
        )
        components = parse_dependencies(toml)
        assert len(components) == 3
        names = {c.name: c.version for c in components}
        assert names["requests"] == "2.31.0"
        assert names["click"] == "8.1"
        assert names["pydantic"] == "0.0.0"

    def test_parse_pyproject_toml_no_project_section(self, tmp_path: Path):
        toml = tmp_path / "pyproject.toml"
        toml.write_text('[build-system]\nrequires = ["setuptools"]\n', encoding="utf-8")
        assert parse_dependencies(toml) == []

    def test_parse_pyproject_toml_with_extras(self, tmp_path: Path):
        toml = tmp_path / "pyproject.toml"
        toml.write_text(
            '[project]\ndependencies = [\n    "uvicorn[standard]>=0.20.0",\n]\n',
            encoding="utf-8",
        )
        components = parse_dependencies(toml)
        assert len(components) == 1
        assert components[0].name == "uvicorn"
        assert components[0].version == "0.20.0"


# ---------------------------------------------------------------------------
# parse_dependencies — Cargo.toml
# ---------------------------------------------------------------------------


class TestParseCargoToml:
    def test_parse_cargo_toml(self, tmp_path: Path):
        cargo = tmp_path / "Cargo.toml"
        cargo.write_text(
            '[package]\nname = "myapp"\nversion = "0.1.0"\n\n'
            "[dependencies]\n"
            'serde = "1.0"\n'
            'tokio = { version = "1.35", features = ["full"] }\n',
            encoding="utf-8",
        )
        components = parse_dependencies(cargo)
        assert len(components) == 2
        names = {c.name: c.version for c in components}
        assert names["serde"] == "1.0"
        assert names["tokio"] == "1.35"
        assert all(c.ecosystem == "cargo" for c in components)


# ---------------------------------------------------------------------------
# parse_dependencies — go.mod
# ---------------------------------------------------------------------------


class TestParseGoMod:
    def test_parse_go_mod(self, tmp_path: Path):
        gomod = tmp_path / "go.mod"
        gomod.write_text(
            "module github.com/example/myapp\n\ngo 1.21\n\n"
            "require (\n"
            "\tgithub.com/gin-gonic/gin v1.9.1\n"
            "\tgolang.org/x/crypto v0.17.0 // indirect\n"
            ")\n",
            encoding="utf-8",
        )
        components = parse_dependencies(gomod)
        assert len(components) == 2
        names = {c.name: c.version for c in components}
        assert names["github.com/gin-gonic/gin"] == "v1.9.1"
        assert names["golang.org/x/crypto"] == "v0.17.0"
        assert all(c.ecosystem == "golang" for c in components)

    def test_parse_go_mod_single_line_require(self, tmp_path: Path):
        gomod = tmp_path / "go.mod"
        gomod.write_text(
            "module example.com/app\n\ngo 1.21\n\n"
            "require github.com/pkg/errors v0.9.1\n",
            encoding="utf-8",
        )
        components = parse_dependencies(gomod)
        assert len(components) == 1
        assert components[0].name == "github.com/pkg/errors"


# ---------------------------------------------------------------------------
# parse_dependencies — unsupported format
# ---------------------------------------------------------------------------


class TestParseUnsupported:
    def test_parse_unsupported_returns_empty(self, tmp_path: Path):
        pom = tmp_path / "pom.xml"
        pom.write_text("<project></project>", encoding="utf-8")
        assert parse_dependencies(pom) == []


# ---------------------------------------------------------------------------
# generate_cyclonedx
# ---------------------------------------------------------------------------


class TestGenerateCycloneDX:
    def test_generate_cyclonedx_structure(self):
        components = [
            Component(name="express", version="4.18.2", ecosystem="npm"),
            Component(name="requests", version="2.31.0", ecosystem="pypi"),
        ]
        meta = SBOMMetadata(name="my-project", version="1.0.0")
        doc = generate_cyclonedx(components, meta)

        assert doc["bomFormat"] == "CycloneDX"
        assert doc["specVersion"] == "1.5"
        assert doc["version"] == 1
        assert doc["serialNumber"].startswith("urn:uuid:")
        assert doc["metadata"]["component"]["name"] == "my-project"
        assert doc["metadata"]["component"]["version"] == "1.0.0"
        assert doc["metadata"]["component"]["type"] == "application"
        assert len(doc["components"]) == 2

    def test_generate_cyclonedx_purls(self):
        components = [
            Component(name="express", version="4.18.2", ecosystem="npm"),
            Component(name="requests", version="2.31.0", ecosystem="pypi"),
            Component(name="serde", version="1.0.0", ecosystem="cargo"),
            Component(name="github.com/gin-gonic/gin", version="v1.9.1", ecosystem="golang"),
        ]
        doc = generate_cyclonedx(components)

        purls = [c["purl"] for c in doc["components"]]
        assert "pkg:npm/express@4.18.2" in purls
        assert "pkg:pypi/requests@2.31.0" in purls
        assert "pkg:cargo/serde@1.0.0" in purls
        assert "pkg:golang/github.com/gin-gonic/gin@v1.9.1" in purls

    def test_generate_cyclonedx_empty(self):
        doc = generate_cyclonedx([])
        assert doc["components"] == []
        assert doc["bomFormat"] == "CycloneDX"

    def test_generate_cyclonedx_dev_scope(self):
        components = [Component(name="jest", version="29.7.0", ecosystem="npm", scope="dev")]
        doc = generate_cyclonedx(components)
        assert doc["components"][0]["scope"] == "optional"

    def test_generate_cyclonedx_json_serializable(self):
        components = [Component(name="flask", version="3.0.0", ecosystem="pypi")]
        doc = generate_cyclonedx(components, SBOMMetadata(name="test"))
        # Must not raise
        result = json.dumps(doc)
        assert "CycloneDX" in result


# ---------------------------------------------------------------------------
# generate_spdx
# ---------------------------------------------------------------------------


class TestGenerateSPDX:
    def test_generate_spdx_structure(self):
        components = [
            Component(name="express", version="4.18.2", ecosystem="npm"),
        ]
        meta = SBOMMetadata(name="my-project", version="1.0.0")
        doc = generate_spdx(components, meta)

        assert doc["spdxVersion"] == "SPDX-2.3"
        assert doc["dataLicense"] == "CC0-1.0"
        assert doc["SPDXID"] == "SPDXRef-DOCUMENT"
        assert doc["name"] == "my-project"
        assert "spdx.org" in doc["documentNamespace"]
        assert doc["creationInfo"]["creators"] == ["Tool: sentrik"]

        # Root package + 1 dependency
        assert len(doc["packages"]) == 2
        root = doc["packages"][0]
        assert root["SPDXID"] == "SPDXRef-RootPackage"
        assert root["name"] == "my-project"
        assert root["versionInfo"] == "1.0.0"

        dep = doc["packages"][1]
        assert dep["SPDXID"] == "SPDXRef-Package-1"
        assert dep["name"] == "express"
        assert dep["versionInfo"] == "4.18.2"
        assert dep["downloadLocation"] == "NOASSERTION"
        assert dep["externalRefs"][0]["referenceLocator"] == "pkg:npm/express@4.18.2"

    def test_generate_spdx_empty(self):
        doc = generate_spdx([])
        assert doc["spdxVersion"] == "SPDX-2.3"
        # Only root package
        assert len(doc["packages"]) == 1

    def test_generate_spdx_json_serializable(self):
        components = [Component(name="flask", version="3.0.0", ecosystem="pypi")]
        doc = generate_spdx(components, SBOMMetadata(name="test"))
        result = json.dumps(doc)
        assert "SPDX-2.3" in result


# ---------------------------------------------------------------------------
# CLI integration tests (using CliRunner)
# ---------------------------------------------------------------------------


class TestCLI:
    def test_cli_sbom_default(self, tmp_path: Path, monkeypatch):
        """CLI produces an output file in CycloneDX format by default."""
        # Create a minimal project
        (tmp_path / "package.json").write_text(json.dumps({
            "dependencies": {"express": "^4.18.2"},
        }), encoding="utf-8")
        # Minimal config
        (tmp_path / ".guard.yaml").write_text("output_dir: out\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["sbom", "--config", str(tmp_path / ".guard.yaml")])
        assert result.exit_code == 0, result.output
        assert "SBOM" in result.output or "sbom" in result.output.lower()

        out_file = tmp_path / "out" / "sbom.json"
        assert out_file.exists()
        doc = json.loads(out_file.read_text(encoding="utf-8"))
        assert doc["bomFormat"] == "CycloneDX"
        assert len(doc["components"]) == 1

    def test_cli_sbom_list(self, tmp_path: Path, monkeypatch):
        """--list flag shows manifests without generating SBOM."""
        (tmp_path / "requirements.txt").write_text("flask==3.0.0\n", encoding="utf-8")
        (tmp_path / ".guard.yaml").write_text("output_dir: out\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["sbom", "--list", "--config", str(tmp_path / ".guard.yaml")])
        assert result.exit_code == 0, result.output
        assert "requirements.txt" in result.output
        # Should NOT create an output file
        assert not (tmp_path / "out" / "sbom.json").exists()

    def test_cli_sbom_spdx_format(self, tmp_path: Path, monkeypatch):
        """--format spdx produces SPDX output."""
        (tmp_path / "requirements.txt").write_text("requests==2.31.0\n", encoding="utf-8")
        (tmp_path / ".guard.yaml").write_text("output_dir: out\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["sbom", "--format", "spdx", "--config", str(tmp_path / ".guard.yaml")])
        assert result.exit_code == 0, result.output

        out_file = tmp_path / "out" / "sbom.json"
        assert out_file.exists()
        doc = json.loads(out_file.read_text(encoding="utf-8"))
        assert doc["spdxVersion"] == "SPDX-2.3"

    def test_cli_sbom_custom_output(self, tmp_path: Path, monkeypatch):
        """--output flag writes to custom path."""
        (tmp_path / "requirements.txt").write_text("click==8.1.0\n", encoding="utf-8")
        (tmp_path / ".guard.yaml").write_text("output_dir: out\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner
        from guard.cli import app

        custom_out = tmp_path / "custom" / "my-sbom.json"
        runner = CliRunner()
        result = runner.invoke(app, ["sbom", "--output", str(custom_out), "--config", str(tmp_path / ".guard.yaml")])
        assert result.exit_code == 0, result.output
        assert custom_out.exists()

    def test_cli_sbom_no_manifests(self, tmp_path: Path, monkeypatch):
        """No manifests produces a warning, not a crash."""
        (tmp_path / ".guard.yaml").write_text("output_dir: out\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)

        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["sbom", "--config", str(tmp_path / ".guard.yaml")])
        assert result.exit_code == 0, result.output
        assert "no dependency manifests" in result.output.lower() or "No dependency" in result.output


# ---------------------------------------------------------------------------
# Component purl
# ---------------------------------------------------------------------------


class TestComponentPurl:
    def test_npm_purl(self):
        c = Component(name="express", version="4.18.2", ecosystem="npm")
        assert c.purl == "pkg:npm/express@4.18.2"

    def test_pypi_purl(self):
        c = Component(name="requests", version="2.31.0", ecosystem="pypi")
        assert c.purl == "pkg:pypi/requests@2.31.0"

    def test_golang_purl(self):
        c = Component(name="github.com/gin-gonic/gin", version="v1.9.1", ecosystem="golang")
        assert c.purl == "pkg:golang/github.com/gin-gonic/gin@v1.9.1"

    def test_cargo_purl(self):
        c = Component(name="serde", version="1.0.0", ecosystem="cargo")
        assert c.purl == "pkg:cargo/serde@1.0.0"


# ---------------------------------------------------------------------------
# parse_dependencies — CMakeLists.txt
# ---------------------------------------------------------------------------


class TestParseCMake:
    def test_detect_manifests_cmake(self, tmp_path: Path):
        (tmp_path / "CMakeLists.txt").write_text(
            "cmake_minimum_required(VERSION 3.14)\nproject(myapp)\n",
            encoding="utf-8",
        )
        result = detect_manifests(tmp_path)
        assert len(result) == 1
        assert result[0].name == "CMakeLists.txt"

    def test_parse_cmake_find_package(self, tmp_path: Path):
        cmake = tmp_path / "CMakeLists.txt"
        cmake.write_text(
            "cmake_minimum_required(VERSION 3.14)\n"
            "project(myapp)\n"
            "find_package(OpenSSL REQUIRED)\n"
            "find_package(ZLIB REQUIRED)\n",
            encoding="utf-8",
        )
        components = parse_dependencies(cmake)
        assert len(components) == 2
        names = {c.name for c in components}
        assert names == {"OpenSSL", "ZLIB"}
        assert all(c.ecosystem == "cmake" for c in components)
        assert all(c.version == "" for c in components)

    def test_parse_cmake_find_package_with_version(self, tmp_path: Path):
        cmake = tmp_path / "CMakeLists.txt"
        cmake.write_text(
            "cmake_minimum_required(VERSION 3.14)\n"
            "project(myapp)\n"
            "find_package(Boost 1.75 REQUIRED)\n"
            "find_package(Qt5 5.15.2 COMPONENTS Widgets REQUIRED)\n",
            encoding="utf-8",
        )
        components = parse_dependencies(cmake)
        assert len(components) == 2
        names = {c.name: c.version for c in components}
        assert names["Boost"] == "1.75"
        assert names["Qt5"] == "5.15.2"

    def test_parse_cmake_fetchcontent(self, tmp_path: Path):
        cmake = tmp_path / "CMakeLists.txt"
        cmake.write_text(
            "include(FetchContent)\n"
            "FetchContent_Declare(\n"
            "  googletest\n"
            "  URL https://github.com/google/googletest/archive/refs/tags/v1.14.0.tar.gz\n"
            ")\n"
            "FetchContent_MakeAvailable(googletest)\n",
            encoding="utf-8",
        )
        components = parse_dependencies(cmake)
        assert len(components) == 1
        assert components[0].name == "googletest"
        assert components[0].version == "1.14.0"
        assert components[0].ecosystem == "cmake"

    def test_parse_cmake_fetchcontent_git_tag(self, tmp_path: Path):
        cmake = tmp_path / "CMakeLists.txt"
        cmake.write_text(
            "include(FetchContent)\n"
            "FetchContent_Declare(\n"
            "  fmt\n"
            "  GIT_REPOSITORY https://github.com/fmtlib/fmt.git\n"
            "  GIT_TAG 10.1.1\n"
            ")\n"
            "FetchContent_MakeAvailable(fmt)\n",
            encoding="utf-8",
        )
        components = parse_dependencies(cmake)
        assert len(components) == 1
        assert components[0].name == "fmt"
        assert components[0].version == "10.1.1"
        assert components[0].ecosystem == "cmake"

    def test_parse_cmake_empty(self, tmp_path: Path):
        cmake = tmp_path / "CMakeLists.txt"
        cmake.write_text(
            "cmake_minimum_required(VERSION 3.14)\n"
            "project(myapp)\n"
            "add_executable(myapp main.cpp)\n",
            encoding="utf-8",
        )
        components = parse_dependencies(cmake)
        assert components == []


# ---------------------------------------------------------------------------
# Lockfile detection
# ---------------------------------------------------------------------------


class TestDetectManifestsLockfiles:
    def test_detect_manifests_lockfiles(self, tmp_path: Path):
        """detect_manifests finds lockfiles alongside manifests."""
        (tmp_path / "package.json").write_text("{}", encoding="utf-8")
        (tmp_path / "package-lock.json").write_text("{}", encoding="utf-8")
        (tmp_path / "Cargo.toml").write_text("", encoding="utf-8")
        (tmp_path / "Cargo.lock").write_text("", encoding="utf-8")
        (tmp_path / "pyproject.toml").write_text("", encoding="utf-8")
        (tmp_path / "poetry.lock").write_text("", encoding="utf-8")

        result = detect_manifests(tmp_path)
        names = {p.name for p in result}
        assert "package-lock.json" in names
        assert "Cargo.lock" in names
        assert "poetry.lock" in names
        # Also includes the manifests themselves
        assert "package.json" in names
        assert "Cargo.toml" in names
        assert "pyproject.toml" in names


# ---------------------------------------------------------------------------
# parse_dependencies — package-lock.json
# ---------------------------------------------------------------------------


class TestParsePackageLockJson:
    def test_parse_package_lock_json_v7(self, tmp_path: Path):
        """Parse npm v7+ lockfile with packages field."""
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text(json.dumps({
            "name": "my-app",
            "version": "1.0.0",
            "lockfileVersion": 3,
            "packages": {
                "": {"name": "my-app", "version": "1.0.0"},
                "node_modules/express": {"version": "4.18.2"},
                "node_modules/accepts": {"version": "1.3.8"},
                "node_modules/body-parser": {"version": "1.20.1"},
                "node_modules/@types/node": {"version": "20.10.0", "dev": True},
            },
        }), encoding="utf-8")

        components = parse_dependencies(lockfile)
        assert len(components) == 4
        names = {c.name: c for c in components}
        assert "express" in names
        assert "accepts" in names
        assert "body-parser" in names
        assert "@types/node" in names
        assert names["express"].version == "4.18.2"
        assert names["express"].ecosystem == "npm"
        assert names["@types/node"].scope == "dev"
        assert names["express"].scope == "required"

    def test_parse_package_lock_json_v6(self, tmp_path: Path):
        """Parse npm v6 lockfile with dependencies field."""
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text(json.dumps({
            "name": "my-app",
            "version": "1.0.0",
            "lockfileVersion": 1,
            "dependencies": {
                "express": {
                    "version": "4.18.2",
                    "dependencies": {
                        "accepts": {"version": "1.3.8"},
                    },
                },
                "lodash": {"version": "4.17.21"},
            },
        }), encoding="utf-8")

        components = parse_dependencies(lockfile)
        assert len(components) == 3
        names = {c.name for c in components}
        assert names == {"express", "accepts", "lodash"}

    def test_parse_package_lock_json_scoped(self, tmp_path: Path):
        """Scoped packages (@scope/name) are parsed correctly."""
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text(json.dumps({
            "lockfileVersion": 3,
            "packages": {
                "": {},
                "node_modules/@babel/core": {"version": "7.23.5"},
                "node_modules/@babel/core/node_modules/semver": {"version": "6.3.1"},
            },
        }), encoding="utf-8")

        components = parse_dependencies(lockfile)
        assert len(components) == 2
        names = {c.name for c in components}
        assert "@babel/core" in names
        assert "semver" in names

    def test_parse_package_lock_json_invalid(self, tmp_path: Path):
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text("not json!", encoding="utf-8")
        assert parse_dependencies(lockfile) == []

    def test_parse_package_lock_json_empty(self, tmp_path: Path):
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text("{}", encoding="utf-8")
        assert parse_dependencies(lockfile) == []


# ---------------------------------------------------------------------------
# parse_dependencies — poetry.lock
# ---------------------------------------------------------------------------


class TestParsePoetryLock:
    def test_parse_poetry_lock(self, tmp_path: Path):
        lockfile = tmp_path / "poetry.lock"
        lockfile.write_text(
            '[[package]]\n'
            'name = "requests"\n'
            'version = "2.31.0"\n'
            'description = "Python HTTP library"\n'
            '\n'
            '[[package]]\n'
            'name = "urllib3"\n'
            'version = "2.1.0"\n'
            'description = "HTTP library"\n'
            '\n'
            '[[package]]\n'
            'name = "certifi"\n'
            'version = "2023.11.17"\n'
            'description = "CA bundle"\n',
            encoding="utf-8",
        )

        components = parse_dependencies(lockfile)
        assert len(components) == 3
        names = {c.name: c.version for c in components}
        assert names["requests"] == "2.31.0"
        assert names["urllib3"] == "2.1.0"
        assert names["certifi"] == "2023.11.17"
        assert all(c.ecosystem == "pypi" for c in components)

    def test_parse_poetry_lock_empty(self, tmp_path: Path):
        lockfile = tmp_path / "poetry.lock"
        lockfile.write_text("", encoding="utf-8")
        assert parse_dependencies(lockfile) == []


# ---------------------------------------------------------------------------
# parse_dependencies — Cargo.lock
# ---------------------------------------------------------------------------


class TestParseCargoLock:
    def test_parse_cargo_lock(self, tmp_path: Path):
        lockfile = tmp_path / "Cargo.lock"
        lockfile.write_text(
            '# This file is automatically generated by Cargo.\n'
            '[[package]]\n'
            'name = "my-app"\n'
            'version = "0.1.0"\n'
            '\n'
            '[[package]]\n'
            'name = "serde"\n'
            'version = "1.0.193"\n'
            'source = "registry+https://github.com/rust-lang/crates.io-index"\n'
            '\n'
            '[[package]]\n'
            'name = "serde_derive"\n'
            'version = "1.0.193"\n'
            'source = "registry+https://github.com/rust-lang/crates.io-index"\n'
            '\n'
            '[[package]]\n'
            'name = "tokio"\n'
            'version = "1.35.0"\n'
            'source = "registry+https://github.com/rust-lang/crates.io-index"\n',
            encoding="utf-8",
        )

        components = parse_dependencies(lockfile)
        # Root package "my-app" has no source, so it's skipped
        assert len(components) == 3
        names = {c.name: c.version for c in components}
        assert names["serde"] == "1.0.193"
        assert names["serde_derive"] == "1.0.193"
        assert names["tokio"] == "1.35.0"
        assert all(c.ecosystem == "cargo" for c in components)

    def test_parse_cargo_lock_empty(self, tmp_path: Path):
        lockfile = tmp_path / "Cargo.lock"
        lockfile.write_text("", encoding="utf-8")
        assert parse_dependencies(lockfile) == []


# ---------------------------------------------------------------------------
# Lockfile has more deps than manifest
# ---------------------------------------------------------------------------


class TestLockfileHasMoreDepsThanManifest:
    def test_lockfile_has_more_deps_than_manifest(self, tmp_path: Path):
        """Lockfile returns transitive deps not present in the manifest."""
        # Manifest: only 1 direct dep
        manifest = tmp_path / "package.json"
        manifest.write_text(json.dumps({
            "dependencies": {"express": "^4.18.2"},
        }), encoding="utf-8")

        # Lockfile: express + its transitive deps
        lockfile = tmp_path / "package-lock.json"
        lockfile.write_text(json.dumps({
            "lockfileVersion": 3,
            "packages": {
                "": {"name": "my-app", "version": "1.0.0"},
                "node_modules/express": {"version": "4.18.2"},
                "node_modules/accepts": {"version": "1.3.8"},
                "node_modules/body-parser": {"version": "1.20.1"},
                "node_modules/content-type": {"version": "1.0.5"},
                "node_modules/cookie": {"version": "0.5.0"},
            },
        }), encoding="utf-8")

        manifest_deps = parse_dependencies(manifest)
        lockfile_deps = parse_dependencies(lockfile)

        # Manifest has only 1 direct dep
        assert len(manifest_deps) == 1
        assert manifest_deps[0].name == "express"

        # Lockfile has 5 (express + 4 transitive)
        assert len(lockfile_deps) == 5
        lockfile_names = {c.name for c in lockfile_deps}
        assert "express" in lockfile_names
        assert "accepts" in lockfile_names
        assert "body-parser" in lockfile_names
        assert "content-type" in lockfile_names
        assert "cookie" in lockfile_names
