"""Tests for conditional documentation obligations (applies_when)."""

from pathlib import Path

from guard.rules.engine import _obligation_applies
from guard.rules.rule_schema import RuleDefinition


def _make_rule(**kwargs) -> RuleDefinition:
    return RuleDefinition(
        id="TEST-001", name="test-rule", type="documentation_obligation",
        severity="info", **kwargs,
    )


class TestObligationAppliesNoConditions:
    def test_no_applies_when_always_fires(self, tmp_path):
        rule = _make_rule()
        assert _obligation_applies(rule, tmp_path, []) is True

    def test_empty_applies_when_always_fires(self, tmp_path):
        rule = _make_rule(applies_when={})
        assert _obligation_applies(rule, tmp_path, []) is True


class TestLanguageCondition:
    def test_matches_language(self, tmp_path):
        rule = _make_rule(applies_when={"languages": ["python", "java"]})
        assert _obligation_applies(rule, tmp_path, ["python"]) is True

    def test_no_match_skips(self, tmp_path):
        rule = _make_rule(applies_when={"languages": ["python"]})
        assert _obligation_applies(rule, tmp_path, ["java", "go"]) is False

    def test_no_languages_detected_skips(self, tmp_path):
        rule = _make_rule(applies_when={"languages": ["python"]})
        assert _obligation_applies(rule, tmp_path, None) is False

    def test_empty_languages_detected_skips(self, tmp_path):
        rule = _make_rule(applies_when={"languages": ["python"]})
        assert _obligation_applies(rule, tmp_path, []) is False


class TestHasFilesCondition:
    def test_file_exists_matches(self, tmp_path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.12")
        rule = _make_rule(applies_when={"has_files": ["**/Dockerfile"]})
        assert _obligation_applies(rule, tmp_path, []) is True

    def test_no_file_skips(self, tmp_path):
        rule = _make_rule(applies_when={"has_files": ["**/Dockerfile"]})
        assert _obligation_applies(rule, tmp_path, []) is False

    def test_multiple_patterns_any_matches(self, tmp_path):
        (tmp_path / "fly.toml").write_text("[app]")
        rule = _make_rule(applies_when={"has_files": ["**/Dockerfile", "**/fly.toml"]})
        assert _obligation_applies(rule, tmp_path, []) is True


class TestHasImportsCondition:
    def test_import_found(self, tmp_path):
        (tmp_path / "train.py").write_text("import torch\nmodel = torch.nn.Linear(10, 5)")
        rule = _make_rule(applies_when={"has_imports": ["torch", "tensorflow"]})
        assert _obligation_applies(rule, tmp_path, []) is True

    def test_from_import_found(self, tmp_path):
        (tmp_path / "ml.py").write_text("from sklearn.ensemble import RandomForestClassifier")
        rule = _make_rule(applies_when={"has_imports": ["sklearn"]})
        assert _obligation_applies(rule, tmp_path, []) is True

    def test_no_import_skips(self, tmp_path):
        (tmp_path / "app.py").write_text("import os\nimport json")
        rule = _make_rule(applies_when={"has_imports": ["torch"]})
        assert _obligation_applies(rule, tmp_path, []) is False

    def test_no_python_files_skips(self, tmp_path):
        rule = _make_rule(applies_when={"has_imports": ["torch"]})
        assert _obligation_applies(rule, tmp_path, []) is False


class TestCombinedConditions:
    def test_all_conditions_must_pass(self, tmp_path):
        """When multiple conditions are set, ALL must be satisfied."""
        (tmp_path / "train.py").write_text("import torch")
        rule = _make_rule(applies_when={
            "languages": ["python"],
            "has_imports": ["torch"],
        })
        # Both match
        assert _obligation_applies(rule, tmp_path, ["python"]) is True

    def test_one_fails_skips(self, tmp_path):
        """If one condition fails, the obligation is skipped."""
        (tmp_path / "train.py").write_text("import torch")
        rule = _make_rule(applies_when={
            "languages": ["java"],  # Not in project
            "has_imports": ["torch"],  # Present
        })
        assert _obligation_applies(rule, tmp_path, ["python"]) is False


class TestEngineIntegration:
    def test_conditional_obligation_skipped(self, tmp_path):
        """Obligation with unmet condition doesn't produce findings."""
        from guard.rules.engine import RulesEngine

        rules = [{
            "id": "ML-001", "name": "ml-docs", "type": "documentation_obligation",
            "severity": "info", "applies_when": {"has_imports": ["torch"]},
        }]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path), project_languages=["python"])
        assert len(findings) == 0

    def test_conditional_obligation_fires_when_met(self, tmp_path):
        """Obligation with met condition produces a finding."""
        from guard.rules.engine import RulesEngine

        (tmp_path / "model.py").write_text("import torch")
        rules = [{
            "id": "ML-001", "name": "ml-docs", "type": "documentation_obligation",
            "severity": "info", "applies_when": {"has_imports": ["torch"]},
        }]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path), project_languages=["python"])
        assert len(findings) == 1
        assert findings[0].rule_id == "ML-001"

    def test_unconditional_obligation_always_fires(self, tmp_path):
        """Obligation without applies_when always fires (backward compat)."""
        from guard.rules.engine import RulesEngine

        rules = [{
            "id": "DOC-001", "name": "some-doc", "type": "documentation_obligation",
            "severity": "info",
        }]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path), project_languages=[])
        assert len(findings) == 1
