"""Tests for GRC platform integration."""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from guard.core.grc_integration import (
    GRCConfig,
    GRCPayload,
    build_grc_config_from_guard_config,
    build_gate_payload,
    build_scan_payload,
    build_vuln_payload,
    maybe_push_grc_event,
    push_event,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _config(url="https://example.com/webhook", api_key="", platform="generic", events=None):
    return GRCConfig(
        webhook_url=url,
        api_key=api_key,
        platform=platform,
        events=events or [],
    )


def _payload(event="scan_complete"):
    return GRCPayload(
        event=event,
        timestamp="2026-03-20T00:00:00+00:00",
        project_name="test-project",
        data={"compliance_score": 95.0, "findings_summary": {"critical": 0, "high": 1}},
    )


class _FakeResponse:
    def __init__(self, status):
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


# ---------------------------------------------------------------------------
# push_event tests
# ---------------------------------------------------------------------------

class TestPushEvent:

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_success(self, mock_urlopen):
        """200 response returns True."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config()
        payload = _payload()
        assert push_event(config, payload) is True

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_success_201(self, mock_urlopen):
        """201 response returns True."""
        mock_urlopen.return_value = _FakeResponse(201)
        assert push_event(_config(), _payload()) is True

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_failure(self, mock_urlopen):
        """500 response returns False."""
        import urllib.error
        mock_urlopen.side_effect = urllib.error.HTTPError(
            "https://example.com/webhook", 500, "Server Error", {}, None
        )
        assert push_event(_config(), _payload()) is False

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_network_error(self, mock_urlopen):
        """Connection error returns False."""
        mock_urlopen.side_effect = ConnectionError("Connection refused")
        assert push_event(_config(), _payload()) is False

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_with_api_key(self, mock_urlopen):
        """Includes Authorization header when api_key is set."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config(api_key="my-secret-key")
        push_event(config, _payload())

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer my-secret-key"

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_headers(self, mock_urlopen):
        """Includes X-Sentrik-Event and X-Sentrik-Version headers."""
        mock_urlopen.return_value = _FakeResponse(200)
        payload = _payload(event="gate_failed")
        push_event(_config(), payload)

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("X-sentrik-event") == "gate_failed"
        assert req.get_header("X-sentrik-version")  # non-empty version string
        assert req.get_header("Content-type") == "application/json"

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_push_event_no_api_key(self, mock_urlopen):
        """Omits Authorization header when api_key is empty."""
        mock_urlopen.return_value = _FakeResponse(200)
        push_event(_config(api_key=""), _payload())

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") is None

    def test_push_event_no_url(self):
        """Returns False when webhook_url is empty."""
        config = _config(url="")
        assert push_event(config, _payload()) is False


# ---------------------------------------------------------------------------
# Payload builder tests
# ---------------------------------------------------------------------------

class TestBuildPayloads:

    def test_build_scan_payload(self):
        """Scan payload has correct structure."""
        payload = build_scan_payload(
            findings_summary={"critical": 1, "high": 2, "medium": 3},
            compliance_score=87.5,
            project_name="my-app",
        )
        assert payload.event == "scan_complete"
        assert payload.project_name == "my-app"
        assert payload.data["compliance_score"] == 87.5
        assert payload.data["findings_summary"]["critical"] == 1
        assert payload.data["total_findings"] == 6
        assert payload.timestamp  # non-empty

    def test_build_scan_payload_with_dict_score(self):
        """Scan payload extracts score from compliance dict."""
        payload = build_scan_payload(
            findings_summary={},
            compliance_score={"score": 92.0, "rules_total": 10},
            project_name="proj",
        )
        assert payload.data["compliance_score"] == 92.0

    def test_build_gate_payload_passed(self):
        """Gate payload for passed gate."""
        gate = SimpleNamespace(
            passed=True, total_findings=5,
            critical=0, high=0, medium=3, low=1, info=1,
        )
        payload = build_gate_payload(gate, "my-app")
        assert payload.event == "gate_passed"
        assert payload.data["gate_passed"] is True
        assert payload.data["gate_result"]["critical"] == 0

    def test_build_gate_payload_failed(self):
        """Gate payload for failed gate."""
        gate = SimpleNamespace(
            passed=False, total_findings=10,
            critical=2, high=3, medium=3, low=1, info=1,
        )
        payload = build_gate_payload(gate, "my-app")
        assert payload.event == "gate_failed"
        assert payload.data["gate_passed"] is False
        assert payload.data["gate_result"]["critical"] == 2

    def test_build_vuln_payload(self):
        """Vulnerability payload has correct structure."""
        vuln_data = {
            "vulnerabilities": [{"id": "CVE-2024-1234", "severity": "high"}],
            "total": 1,
            "critical": 0,
            "high": 1,
            "medium": 0,
            "low": 0,
        }
        payload = build_vuln_payload(vuln_data, "my-app")
        assert payload.event == "vuln_scan"
        assert payload.data["total_vulnerabilities"] == 1
        assert len(payload.data["vulnerabilities"]) == 1


# ---------------------------------------------------------------------------
# Event filter & disabled tests
# ---------------------------------------------------------------------------

class TestEventFiltering:

    def test_disabled_when_no_url(self):
        """No push when webhook_url is empty."""
        config = SimpleNamespace(grc_webhook_url="", grc_platform="generic", grc_events=[])
        result = maybe_push_grc_event(config, "scan_complete", _payload())
        assert result is None

    @patch("guard.core.grc_integration.push_event", return_value=True)
    def test_event_filter_blocks(self, mock_push):
        """Only pushes configured events — blocks unlisted events."""
        config = SimpleNamespace(
            grc_webhook_url="https://example.com/hook",
            grc_platform="generic",
            grc_events=["gate_failed"],
        )
        result = maybe_push_grc_event(config, "scan_complete", _payload())
        assert result is None
        mock_push.assert_not_called()

    @patch("guard.core.grc_integration.push_event", return_value=True)
    def test_event_filter_allows(self, mock_push):
        """Pushes when event is in the configured events list."""
        config = SimpleNamespace(
            grc_webhook_url="https://example.com/hook",
            grc_platform="generic",
            grc_events=["scan_complete", "gate_failed"],
        )
        result = maybe_push_grc_event(config, "scan_complete", _payload())
        assert result is True
        mock_push.assert_called_once()

    @patch("guard.core.grc_integration.push_event", return_value=True)
    def test_empty_events_list_allows_all(self, mock_push):
        """Empty events list means all events are enabled."""
        config = SimpleNamespace(
            grc_webhook_url="https://example.com/hook",
            grc_platform="generic",
            grc_events=[],
        )
        result = maybe_push_grc_event(config, "scan_complete", _payload())
        assert result is True


# ---------------------------------------------------------------------------
# Platform-specific transforms
# ---------------------------------------------------------------------------

class TestPlatformTransforms:

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_drata_transform(self, mock_urlopen):
        """Drata payload uses evidenceType/source/result schema."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config(platform="drata")
        payload = _payload()
        push_event(config, payload)

        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode("utf-8"))
        assert body["evidenceType"] == "AUTOMATED"
        assert body["source"] == "sentrik"
        assert "result" in body
        assert body["sourceEvent"] == "scan_complete"

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_vanta_transform(self, mock_urlopen):
        """Vanta payload uses integration/type/outcome schema."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config(platform="vanta")
        push_event(config, _payload())

        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode("utf-8"))
        assert body["integration"] == "sentrik"
        assert body["type"] == "scan_complete"
        assert "outcome" in body
        assert body["resource"]["type"] == "repository"

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_secureframe_transform(self, mock_urlopen):
        """Secureframe payload uses source/event_type/status schema."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config(platform="secureframe")
        push_event(config, _payload())

        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode("utf-8"))
        assert body["source"] == "sentrik"
        assert body["event_type"] == "scan_complete"
        assert "status" in body
        assert body["asset"]["asset_type"] == "code_repository"

    @patch("guard.core.grc_integration.urllib.request.urlopen")
    def test_generic_passthrough(self, mock_urlopen):
        """Generic platform sends raw Sentrik format."""
        mock_urlopen.return_value = _FakeResponse(200)
        config = _config(platform="generic")
        payload = _payload()
        push_event(config, payload)

        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data.decode("utf-8"))
        assert body["event"] == "scan_complete"
        assert body["project_name"] == "test-project"
        assert "data" in body


# ---------------------------------------------------------------------------
# Config builder from GuardConfig
# ---------------------------------------------------------------------------

class TestBuildGRCConfigFromGuardConfig:

    def test_from_guard_config_attrs(self):
        """Reads grc_* attributes from config object."""
        config = SimpleNamespace(
            grc_webhook_url="https://hook.example.com",
            grc_platform="drata",
            grc_events=["scan_complete"],
            grc_api_key="",
        )
        with patch.dict("os.environ", {}, clear=True):
            grc = build_grc_config_from_guard_config(config)
        assert grc.webhook_url == "https://hook.example.com"
        assert grc.platform == "drata"
        assert grc.events == ["scan_complete"]

    def test_from_env_vars(self):
        """Falls back to GUARD_GRC_* env vars."""
        config = SimpleNamespace(
            grc_webhook_url="",
            grc_platform="",
            grc_events=[],
        )
        env = {
            "GUARD_GRC_WEBHOOK_URL": "https://env-hook.example.com",
            "GUARD_GRC_API_KEY": "env-key",
            "GUARD_GRC_PLATFORM": "vanta",
            "GUARD_GRC_EVENTS": "gate_failed,scan_complete",
        }
        with patch.dict("os.environ", env, clear=True):
            grc = build_grc_config_from_guard_config(config)
        assert grc.webhook_url == "https://env-hook.example.com"
        assert grc.api_key == "env-key"
        assert grc.platform == "vanta"
        assert grc.events == ["gate_failed", "scan_complete"]
