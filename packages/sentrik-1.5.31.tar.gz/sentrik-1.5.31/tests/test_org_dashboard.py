"""Tests for the multi-repo organization dashboard."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

import pytest

from guard.core.org_dashboard import (
    OrgProject,
    aggregate_org_data,
    collect_project_data,
    discover_projects,
    generate_org_html_report,
    org_data_to_json,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_project(
    name: str = "proj-a",
    total_findings: int = 5,
    score: float = 85.0,
    gate: str = "passed",
    frameworks: list[str] | None = None,
    sev: dict[str, int] | None = None,
) -> OrgProject:
    return OrgProject(
        name=name,
        path=f"/org/{name}",
        last_scan=datetime(2026, 3, 16, tzinfo=timezone.utc),
        compliance_score=score,
        findings_by_severity=sev or {"critical": 0, "high": 1, "medium": 2, "low": 1, "info": 1},
        total_findings=total_findings,
        frameworks=frameworks or ["fda-iec-62304"],
        gate_status=gate,
    )


def _setup_project(base: Path, name: str, *, use_sentrik: bool = True,
                    findings: list[dict] | None = None,
                    metrics: dict | None = None,
                    packs: list[str] | None = None) -> Path:
    """Create a minimal project directory structure under *base*."""
    proj = base / name
    if use_sentrik:
        cfg_dir = proj / ".sentrik"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        cfg_content = "standards_packs:\n"
        for p in (packs or []):
            cfg_content += f"  - {p}\n"
        (cfg_dir / "config.yaml").write_text(cfg_content, encoding="utf-8")
    else:
        proj.mkdir(parents=True, exist_ok=True)
        cfg_content = "standards_packs:\n"
        for p in (packs or []):
            cfg_content += f"  - {p}\n"
        (proj / ".guard.yaml").write_text(cfg_content, encoding="utf-8")

    if findings is not None:
        out_dir = proj / "out"
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "findings.json").write_text(json.dumps(findings), encoding="utf-8")

    if metrics is not None:
        out_dir = proj / "out"
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "scan_metrics.json").write_text(json.dumps(metrics), encoding="utf-8")

    return proj


# ---------------------------------------------------------------------------
# discover_projects tests
# ---------------------------------------------------------------------------

class TestDiscoverProjects:
    def test_discover_projects_finds_sentrik_config(self, tmp_path):
        _setup_project(tmp_path, "alpha", use_sentrik=True)
        result = discover_projects(tmp_path)
        assert len(result) == 1
        assert result[0].name == "alpha"

    def test_discover_projects_finds_guard_yaml(self, tmp_path):
        _setup_project(tmp_path, "beta", use_sentrik=False)
        result = discover_projects(tmp_path)
        assert len(result) == 1
        assert result[0].name == "beta"

    def test_discover_projects_empty_dir(self, tmp_path):
        result = discover_projects(tmp_path)
        assert result == []

    def test_discover_projects_skips_hidden_dirs(self, tmp_path):
        # Create a hidden directory with config — should be skipped
        hidden = tmp_path / ".hidden-project"
        hidden.mkdir()
        (hidden / ".guard.yaml").write_text("standards_packs: []", encoding="utf-8")

        # Create a visible project
        _setup_project(tmp_path, "visible", use_sentrik=True)

        result = discover_projects(tmp_path)
        assert len(result) == 1
        assert result[0].name == "visible"

    def test_discover_multiple_projects(self, tmp_path):
        _setup_project(tmp_path, "aaa", use_sentrik=True)
        _setup_project(tmp_path, "zzz", use_sentrik=False)
        _setup_project(tmp_path, "mmm", use_sentrik=True)

        result = discover_projects(tmp_path)
        names = [p.name for p in result]
        assert names == ["aaa", "mmm", "zzz"]  # sorted

    def test_discover_does_not_recurse_into_sub_projects(self, tmp_path):
        """If project A contains sub-project B, only A is returned."""
        proj = _setup_project(tmp_path, "parent", use_sentrik=True)
        child = proj / "child"
        child.mkdir()
        (child / ".guard.yaml").write_text("standards_packs: []", encoding="utf-8")

        result = discover_projects(tmp_path)
        assert len(result) == 1
        assert result[0].name == "parent"

    def test_discover_nonexistent_dir(self, tmp_path):
        result = discover_projects(tmp_path / "nope")
        assert result == []


# ---------------------------------------------------------------------------
# collect_project_data tests
# ---------------------------------------------------------------------------

class TestCollectProjectData:
    def test_collect_project_data_with_findings(self, tmp_path):
        findings = [
            {"severity": "critical", "rule_id": "R1", "message": "bad", "finding_id": "F1",
             "evidence": {"file": "a.py"}, "confidence": 1.0},
            {"severity": "high", "rule_id": "R2", "message": "warn", "finding_id": "F2",
             "evidence": {"file": "b.py"}, "confidence": 1.0},
            {"severity": "low", "rule_id": "R3", "message": "ok", "finding_id": "F3",
             "evidence": {"file": "c.py"}, "confidence": 1.0},
        ]
        metrics = {
            "timestamp": "2026-03-16T10:00:00Z",
            "compliance_score": {"score": 75.0, "rules_total": 20, "rules_passed": 15},
        }
        proj = _setup_project(tmp_path, "proj-x", findings=findings, metrics=metrics,
                              packs=["owasp-top-10"])
        result = collect_project_data(proj)
        assert result.name == "proj-x"
        assert result.total_findings == 3
        assert result.findings_by_severity["critical"] == 1
        assert result.findings_by_severity["high"] == 1
        assert result.findings_by_severity["low"] == 1
        assert result.compliance_score == 75.0
        assert result.gate_status == "failed"  # has critical+high
        assert result.last_scan is not None
        assert "owasp-top-10" in result.frameworks

    def test_collect_project_data_no_output(self, tmp_path):
        proj = _setup_project(tmp_path, "empty-proj", packs=["soc2"])
        result = collect_project_data(proj)
        assert result.name == "empty-proj"
        assert result.total_findings == 0
        assert result.gate_status == "unknown"
        assert result.compliance_score == 0.0
        assert result.frameworks == ["soc2"]

    def test_collect_project_data_passing_gate(self, tmp_path):
        findings = [
            {"severity": "low", "rule_id": "R1", "message": "ok", "finding_id": "F1",
             "evidence": {"file": "a.py"}, "confidence": 1.0},
        ]
        proj = _setup_project(tmp_path, "good-proj", findings=findings)
        result = collect_project_data(proj)
        assert result.gate_status == "passed"

    def test_collect_project_data_empty_findings_file(self, tmp_path):
        proj = _setup_project(tmp_path, "zero-proj", findings=[])
        result = collect_project_data(proj)
        assert result.total_findings == 0
        assert result.gate_status == "passed"  # no blocking findings


# ---------------------------------------------------------------------------
# aggregate_org_data tests
# ---------------------------------------------------------------------------

class TestAggregateOrgData:
    def test_aggregate_totals(self):
        projects = [
            _make_project("a", total_findings=3, score=90.0, gate="passed"),
            _make_project("b", total_findings=7, score=70.0, gate="failed"),
        ]
        agg = aggregate_org_data(projects)
        assert agg["total_projects"] == 2
        assert agg["total_findings"] == 10
        assert agg["projects_passing"] == 1
        assert agg["projects_failing"] == 1

    def test_aggregate_severity_counts(self):
        projects = [
            _make_project("a", sev={"critical": 2, "high": 1}),
            _make_project("b", sev={"critical": 1, "medium": 3}),
        ]
        agg = aggregate_org_data(projects)
        assert agg["findings_by_severity"]["critical"] == 3
        assert agg["findings_by_severity"]["high"] == 1
        assert agg["findings_by_severity"]["medium"] == 3

    def test_aggregate_worst_projects(self):
        projects = [
            _make_project("low", total_findings=1),
            _make_project("high", total_findings=100),
            _make_project("mid", total_findings=50),
        ]
        agg = aggregate_org_data(projects)
        worst_names = [p.name for p in agg["worst_projects"]]
        assert worst_names[0] == "high"
        assert worst_names[1] == "mid"
        assert worst_names[2] == "low"

    def test_aggregate_compliance_average(self):
        projects = [
            _make_project("a", score=80.0),
            _make_project("b", score=100.0),
        ]
        agg = aggregate_org_data(projects)
        assert agg["avg_compliance_score"] == 90.0

    def test_aggregate_empty_projects(self):
        agg = aggregate_org_data([])
        assert agg["total_projects"] == 0
        assert agg["total_findings"] == 0
        assert agg["avg_compliance_score"] == 0.0

    def test_aggregate_worst_projects_limits_to_five(self):
        projects = [_make_project(f"p{i}", total_findings=i) for i in range(10)]
        agg = aggregate_org_data(projects)
        assert len(agg["worst_projects"]) == 5

    def test_aggregate_frameworks_coverage(self):
        projects = [
            _make_project("a", frameworks=["iec-62304", "owasp"]),
            _make_project("b", frameworks=["owasp", "soc2"]),
            _make_project("c", frameworks=["owasp"]),
        ]
        agg = aggregate_org_data(projects)
        assert agg["frameworks_coverage"]["owasp"] == 3
        assert agg["frameworks_coverage"]["iec-62304"] == 1
        assert agg["frameworks_coverage"]["soc2"] == 1


# ---------------------------------------------------------------------------
# CLI + HTML tests
# ---------------------------------------------------------------------------

class TestCLIOrgDashboard:
    def test_cli_org_dashboard_json(self, tmp_path):
        from typer.testing import CliRunner
        from guard.cli import app

        findings = [
            {"severity": "medium", "rule_id": "R1", "message": "test", "finding_id": "F1",
             "evidence": {"file": "x.py"}, "confidence": 1.0},
        ]
        _setup_project(tmp_path, "myrepo", findings=findings, packs=["soc2"])

        runner = CliRunner()
        result = runner.invoke(app, ["org-dashboard", "--root", str(tmp_path), "--json"])
        assert result.exit_code == 0
        # Output should contain valid JSON with project data
        # The Rich console JSON output includes the data
        assert "myrepo" in result.output
        assert "total_projects" in result.output


class TestHTMLReport:
    def test_html_report_contains_projects(self):
        projects = [
            _make_project("alpha", total_findings=3, score=92.0, gate="passed"),
            _make_project("beta", total_findings=12, score=65.0, gate="failed"),
        ]
        agg = aggregate_org_data(projects)
        html = generate_org_html_report(projects, agg)
        assert "<!DOCTYPE html>" in html
        assert "alpha" in html
        assert "beta" in html
        assert "Organization Dashboard" in html
        assert "92.0%" in html
        assert "65.0%" in html

    def test_html_report_has_severity_bar(self):
        projects = [_make_project("x", sev={"critical": 5, "high": 10})]
        agg = aggregate_org_data(projects)
        html = generate_org_html_report(projects, agg)
        assert "Severity Distribution" in html
        assert "sev-bar" in html

    def test_html_report_dark_light_theme(self):
        projects = [_make_project("x")]
        agg = aggregate_org_data(projects)
        html = generate_org_html_report(projects, agg)
        assert "prefers-color-scheme: light" in html

    def test_html_report_empty_projects(self):
        agg = aggregate_org_data([])
        html = generate_org_html_report([], agg)
        assert "No projects found" in html

    def test_html_report_framework_coverage(self):
        projects = [
            _make_project("a", frameworks=["owasp-top-10"]),
            _make_project("b", frameworks=["owasp-top-10", "soc2"]),
        ]
        agg = aggregate_org_data(projects)
        html = generate_org_html_report(projects, agg)
        assert "Framework Coverage" in html
        assert "owasp-top-10" in html


class TestOrgDataToJson:
    def test_json_structure(self):
        projects = [_make_project("proj1", score=80.0)]
        agg = aggregate_org_data(projects)
        data = org_data_to_json(projects, agg)
        assert "generated_at" in data
        assert "sentrik_version" in data
        assert data["summary"]["total_projects"] == 1
        assert len(data["projects"]) == 1
        assert data["projects"][0]["name"] == "proj1"
        assert data["projects"][0]["compliance_score"] == 80.0
