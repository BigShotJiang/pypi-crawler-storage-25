"""Tests for the SENTRIK MCP server tool functions.

Tests the tool handler functions directly — does NOT start the MCP
transport layer.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from guard.mcp_server import (
    _TOOL_DISPATCH,
    _TOOLS_SPEC,
    tool_check_code_snippet,
    tool_explain_rule,
    tool_get_compliance_context,
    tool_get_scan_summary,
    tool_get_vulnerabilities,
    tool_run_scan,
    tool_scan_file,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def project_dir(tmp_path: Path):
    """Create a minimal project directory structure."""
    out = tmp_path / "out"
    out.mkdir()
    return tmp_path


@pytest.fixture()
def py_file(tmp_path: Path) -> Path:
    """Create a Python file with a known violation (eval usage)."""
    f = tmp_path / "bad.py"
    f.write_text('result = eval(user_input)\n', encoding="utf-8")
    return f


@pytest.fixture()
def clean_py_file(tmp_path: Path) -> Path:
    """Create a clean Python file with no violations."""
    f = tmp_path / "clean.py"
    f.write_text('x = 1 + 2\n', encoding="utf-8")
    return f


# ---------------------------------------------------------------------------
# scan_file tests
# ---------------------------------------------------------------------------


class TestScanFile:
    def test_scan_file_with_findings(self, py_file: Path):
        """File with eval() should produce at least one finding."""
        result = tool_scan_file(str(py_file))
        assert "issue(s)" in result or "No compliance issues" in result
        # eval is flagged by multiple packs — we just need a non-error result
        assert "Error" not in result

    def test_scan_file_clean(self, clean_py_file: Path):
        """A clean file should report no issues."""
        result = tool_scan_file(str(clean_py_file))
        assert "No compliance issues" in result

    def test_scan_file_not_found(self):
        """Missing file should return a clear error message."""
        result = tool_scan_file("/nonexistent/path/foo.py")
        assert "Error" in result or "not found" in result

    def test_scan_file_returns_severity_and_rule(self, tmp_path: Path):
        """Findings should include severity and rule_id."""
        f = tmp_path / "vuln.py"
        f.write_text(
            'import os\npassword = "hunter2"\nos.system(password)\n',
            encoding="utf-8",
        )
        result = tool_scan_file(str(f))
        # Either finds issues or not — but should not error
        assert "Error:" not in result


# ---------------------------------------------------------------------------
# get_compliance_context tests
# ---------------------------------------------------------------------------


class TestGetComplianceContext:
    def test_returns_json(self):
        """Should return valid JSON with expected keys."""
        result = tool_get_compliance_context("src/main.cpp")
        data = json.loads(result)
        assert "file" in data
        assert "applicable_rules" in data
        assert "frameworks" in data
        assert "constraints" in data
        assert data["file"] == "src/main.cpp"

    def test_python_file(self):
        """Python file should match Python-glob rules."""
        result = tool_get_compliance_context("app.py")
        data = json.loads(result)
        assert data["file"] == "app.py"
        # Should have at least some rules from the built-in packs
        assert isinstance(data["applicable_rules"], list)


# ---------------------------------------------------------------------------
# check_code_snippet tests
# ---------------------------------------------------------------------------


class TestCheckCodeSnippet:
    def test_clean_code(self):
        """Clean code should return a valid string result (not an error)."""
        result = tool_check_code_snippet("x = 1 + 2\n", "clean.py")
        # May trigger required_pattern rules (traceability, logging) from
        # standards packs — the important thing is it doesn't error out.
        assert isinstance(result, str)
        assert "Error:" not in result

    def test_empty_code(self):
        """Empty code should be handled gracefully."""
        result = tool_check_code_snippet("", "test.py")
        assert "No code provided" in result

    def test_code_with_violation(self):
        """Code with eval should flag a violation."""
        result = tool_check_code_snippet('eval(user_input)\n', "bad.py")
        # eval triggers OWASP/IEC rules
        assert "issue" in result.lower() or "no compliance" in result.lower()


# ---------------------------------------------------------------------------
# get_scan_summary tests
# ---------------------------------------------------------------------------


class TestGetScanSummary:
    def test_no_output_files(self, project_dir: Path):
        """When no scan has been run, return a helpful message."""
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_scan_summary()
        assert "No scan results" in result or "total_findings" in result

    def test_with_findings_file(self, project_dir: Path):
        """Should parse findings.json and return severity counts."""
        findings = [
            {"severity": "critical", "rule_id": "R1", "message": "Bad"},
            {"severity": "high", "rule_id": "R2", "message": "Also bad"},
            {"severity": "medium", "rule_id": "R3", "message": "Meh"},
        ]
        (project_dir / "out" / "findings.json").write_text(
            json.dumps(findings), encoding="utf-8"
        )
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_scan_summary()
        data = json.loads(result)
        assert data["total_findings"] == 3
        assert data["by_severity"]["critical"] == 1
        assert data["by_severity"]["high"] == 1
        assert data["gate_status"] == "FAIL"

    def test_with_passing_gate(self, project_dir: Path):
        """Gate should PASS when no critical/high findings."""
        findings = [
            {"severity": "low", "rule_id": "R1", "message": "Minor"},
        ]
        (project_dir / "out" / "findings.json").write_text(
            json.dumps(findings), encoding="utf-8"
        )
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_scan_summary()
        data = json.loads(result)
        assert data["gate_status"] == "PASS"

    def test_no_scan_results_graceful(self, tmp_path: Path):
        """When output dir has no findings, return helpful message."""
        empty_out = tmp_path / "empty_out"
        empty_out.mkdir()
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(empty_out)}, clear=False):
            result = tool_get_scan_summary()
        assert "No scan results" in result


# ---------------------------------------------------------------------------
# explain_rule tests
# ---------------------------------------------------------------------------


class TestExplainRule:
    def test_explain_existing_rule(self):
        """Should return details for a known rule ID."""
        result = tool_explain_rule("HIPAA-164.312-a1")
        data = json.loads(result)
        assert data["id"] == "HIPAA-164.312-a1"
        assert data["standard"] == "HIPAA"
        assert "description" in data
        assert "severity" in data
        assert "remediation_guidance" in data

    def test_explain_rule_not_found(self):
        """Unknown rule ID should return not found message."""
        result = tool_explain_rule("NONEXISTENT-RULE-999")
        assert "not found" in result.lower()

    def test_explain_rule_has_pack(self):
        """Rule details should include the pack it belongs to."""
        result = tool_explain_rule("HIPAA-164.312-a1")
        data = json.loads(result)
        assert data["pack"] == "hipaa"


# ---------------------------------------------------------------------------
# get_vulnerabilities tests
# ---------------------------------------------------------------------------


class TestGetVulnerabilities:
    def test_no_vuln_file(self, project_dir: Path):
        """When no vulnerability scan has been run, return helpful message."""
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_vulnerabilities()
        assert "No vulnerability data" in result or "vulnerabilities" in result.lower()

    def test_with_vuln_data(self, project_dir: Path):
        """Should parse and return vulnerability data."""
        vulns = [
            {"cve": "CVE-2024-0001", "package": "requests", "severity": "high"},
        ]
        (project_dir / "out" / "vulnerabilities.json").write_text(
            json.dumps(vulns), encoding="utf-8"
        )
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_vulnerabilities()
        data = json.loads(result)
        assert data["total_vulnerabilities"] == 1

    def test_empty_vuln_list(self, project_dir: Path):
        """Empty vulnerabilities list should report no issues."""
        (project_dir / "out" / "vulnerabilities.json").write_text(
            "[]", encoding="utf-8"
        )
        with patch.dict(os.environ, {"GUARD_OUTPUT_DIR": str(project_dir / "out")}, clear=False):
            result = tool_get_vulnerabilities()
        assert "No vulnerabilities" in result


# ---------------------------------------------------------------------------
# Tool dispatch and spec tests
# ---------------------------------------------------------------------------


class TestToolSpec:
    def test_all_tools_have_dispatch(self):
        """Every tool in the spec should have a dispatch handler."""
        spec_names = {t["name"] for t in _TOOLS_SPEC}
        dispatch_names = set(_TOOL_DISPATCH.keys())
        assert spec_names == dispatch_names

    def test_tool_specs_have_required_fields(self):
        """Each tool spec should have name, description, and inputSchema."""
        for spec in _TOOLS_SPEC:
            assert "name" in spec
            assert "description" in spec
            assert "inputSchema" in spec
            assert spec["inputSchema"]["type"] == "object"


# ---------------------------------------------------------------------------
# run_scan tests
# ---------------------------------------------------------------------------


class TestRunScan:
    def test_run_scan_returns_string(self, tmp_path: Path):
        """run_scan should return a string result (even if scan fails)."""
        result = tool_run_scan(str(tmp_path))
        assert isinstance(result, str)
        assert len(result) > 0
