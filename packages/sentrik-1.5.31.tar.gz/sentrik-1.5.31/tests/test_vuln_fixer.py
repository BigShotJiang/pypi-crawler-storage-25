"""Tests for the vuln_fixer auto-remediation module."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from guard.core.vuln_fixer import (
    FixAction,
    FixReport,
    apply_fixes,
    generate_fix_actions,
    _patch_cargo_toml,
    _patch_package_json,
    _patch_pyproject_toml,
    _patch_requirements_txt,
)
from guard.core.vuln_scanner import Vulnerability


def _vuln(pkg: str, version: str, fixed: str | None = None, severity: str = "high") -> Vulnerability:
    """Helper to create a Vulnerability instance."""
    return Vulnerability(
        id=f"CVE-2024-{pkg}",
        summary=f"Vuln in {pkg}",
        severity=severity,
        affected_package=pkg,
        affected_version=version,
        fixed_version=fixed,
    )


class TestGenerateFixActions:
    def test_generate_fix_actions_with_fixed_version(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\nflask==2.0.0\n")

        vulns = [_vuln("requests", "2.25.0", "2.32.0")]
        actions = generate_fix_actions(vulns, [req])

        assert len(actions) == 1
        assert actions[0].package == "requests"
        assert actions[0].fixed_version == "2.32.0"
        assert actions[0].manifest_file == str(req)
        assert actions[0].applied is False

    def test_generate_fix_actions_no_fixed_version(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        vulns = [_vuln("requests", "2.25.0", None)]
        actions = generate_fix_actions(vulns, [req])

        assert len(actions) == 0

    def test_generate_fix_actions_dedup_highest(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        vulns = [
            _vuln("requests", "2.25.0", "2.28.0"),
            _vuln("requests", "2.25.0", "2.32.0"),
            _vuln("requests", "2.25.0", "2.30.0"),
        ]
        actions = generate_fix_actions(vulns, [req])

        assert len(actions) == 1
        assert actions[0].fixed_version == "2.32.0"

    def test_no_actions_for_no_vulns(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        actions = generate_fix_actions([], [req])
        assert actions == []

    def test_no_actions_for_no_manifests(self):
        vulns = [_vuln("requests", "2.25.0", "2.32.0")]
        actions = generate_fix_actions(vulns, [])
        assert actions == []

    def test_generate_fix_actions_multiple_manifests(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        pkg = tmp_path / "package.json"
        pkg.write_text(json.dumps({"dependencies": {"lodash": "^4.17.20"}}))

        vulns = [
            _vuln("requests", "2.25.0", "2.32.0"),
            _vuln("lodash", "4.17.20", "4.17.21"),
        ]
        actions = generate_fix_actions(vulns, [req, pkg])

        assert len(actions) == 2
        packages = {a.package for a in actions}
        assert "requests" in packages
        assert "lodash" in packages


class TestPatchRequirementsTxt:
    def test_patch_pinned(self, tmp_path: Path):
        f = tmp_path / "requirements.txt"
        f.write_text("requests==2.25.0\nflask==2.0.0\n")

        result = _patch_requirements_txt(f, "requests", "2.32.0")

        assert result is True
        content = f.read_text()
        assert "requests==2.32.0" in content
        assert "flask==2.0.0" in content

    def test_patch_gte(self, tmp_path: Path):
        f = tmp_path / "requirements.txt"
        f.write_text("requests>=2.25.0\n")

        result = _patch_requirements_txt(f, "requests", "2.32.0")

        assert result is True
        assert "requests>=2.32.0" in f.read_text()

    def test_patch_compatible(self, tmp_path: Path):
        f = tmp_path / "requirements.txt"
        f.write_text("requests~=2.25.0\n")

        result = _patch_requirements_txt(f, "requests", "2.32.0")

        assert result is True
        assert "requests~=2.32.0" in f.read_text()

    def test_patch_no_pin(self, tmp_path: Path):
        f = tmp_path / "requirements.txt"
        f.write_text("requests\nflask==2.0.0\n")

        result = _patch_requirements_txt(f, "requests", "2.32.0")

        assert result is False
        content = f.read_text()
        assert content == "requests\nflask==2.0.0\n"

    def test_preserves_comments(self, tmp_path: Path):
        f = tmp_path / "requirements.txt"
        f.write_text("# important\nrequests==2.25.0\n# also important\n")

        _patch_requirements_txt(f, "requests", "2.32.0")

        content = f.read_text()
        assert "# important" in content
        assert "# also important" in content


class TestPatchPackageJson:
    def test_patch_dependencies(self, tmp_path: Path):
        f = tmp_path / "package.json"
        f.write_text(json.dumps({
            "dependencies": {"lodash": "^4.17.20", "express": "^4.18.0"},
        }, indent=2))

        result = _patch_package_json(f, "lodash", "4.17.21")

        assert result is True
        data = json.loads(f.read_text())
        assert data["dependencies"]["lodash"] == "^4.17.21"
        assert data["dependencies"]["express"] == "^4.18.0"

    def test_patch_dev_dependencies(self, tmp_path: Path):
        f = tmp_path / "package.json"
        f.write_text(json.dumps({
            "devDependencies": {"jest": "~29.0.0"},
        }, indent=2))

        result = _patch_package_json(f, "jest", "29.7.0")

        assert result is True
        data = json.loads(f.read_text())
        assert data["devDependencies"]["jest"] == "~29.7.0"

    def test_patch_missing_package(self, tmp_path: Path):
        f = tmp_path / "package.json"
        f.write_text(json.dumps({"dependencies": {"express": "^4.18.0"}}, indent=2))

        result = _patch_package_json(f, "lodash", "4.17.21")

        assert result is False


class TestPatchPyprojectToml:
    def test_patch_dependency(self, tmp_path: Path):
        f = tmp_path / "pyproject.toml"
        f.write_text(
            '[project]\nname = "myapp"\ndependencies = [\n'
            '    "requests>=2.25.0",\n'
            '    "flask>=2.0.0",\n'
            "]\n"
        )

        result = _patch_pyproject_toml(f, "requests", "2.32.0")

        assert result is True
        content = f.read_text()
        assert "requests>=2.32.0" in content
        assert "flask>=2.0.0" in content

    def test_patch_missing_package(self, tmp_path: Path):
        f = tmp_path / "pyproject.toml"
        f.write_text(
            '[project]\nname = "myapp"\ndependencies = [\n'
            '    "flask>=2.0.0",\n'
            "]\n"
        )

        result = _patch_pyproject_toml(f, "requests", "2.32.0")

        assert result is False


class TestPatchCargoToml:
    def test_patch_simple(self, tmp_path: Path):
        f = tmp_path / "Cargo.toml"
        f.write_text(
            '[package]\nname = "myapp"\n\n'
            "[dependencies]\n"
            'serde = "1.0.150"\n'
            'tokio = "1.25.0"\n'
        )

        result = _patch_cargo_toml(f, "serde", "1.0.200")

        assert result is True
        content = f.read_text()
        assert 'serde = "1.0.200"' in content
        assert 'tokio = "1.25.0"' in content

    def test_patch_table_form(self, tmp_path: Path):
        f = tmp_path / "Cargo.toml"
        f.write_text(
            "[dependencies]\n"
            'serde = { version = "1.0.150", features = ["derive"] }\n'
        )

        result = _patch_cargo_toml(f, "serde", "1.0.200")

        assert result is True
        content = f.read_text()
        assert '"1.0.200"' in content
        assert "derive" in content


class TestApplyFixes:
    def test_apply_fixes_success(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        actions = [
            FixAction(
                package="requests",
                current_version="2.25.0",
                fixed_version="2.32.0",
                manifest_file=str(req),
            ),
        ]

        report = apply_fixes(actions)

        assert report.applied_count == 1
        assert report.skipped_count == 0
        assert actions[0].applied is True
        assert actions[0].error is None
        assert "requests==2.32.0" in req.read_text()

    def test_apply_fixes_file_not_found(self, tmp_path: Path):
        actions = [
            FixAction(
                package="requests",
                current_version="2.25.0",
                fixed_version="2.32.0",
                manifest_file=str(tmp_path / "nonexistent" / "requirements.txt"),
            ),
        ]

        report = apply_fixes(actions)

        assert report.applied_count == 0
        assert report.skipped_count == 1
        assert actions[0].applied is False
        assert "not found" in actions[0].error.lower() or "No such file" in actions[0].error

    def test_fix_report_counts(self, tmp_path: Path):
        req = tmp_path / "requirements.txt"
        req.write_text("requests==2.25.0\n")

        actions = [
            FixAction(
                package="requests",
                current_version="2.25.0",
                fixed_version="2.32.0",
                manifest_file=str(req),
            ),
            FixAction(
                package="flask",
                current_version="2.0.0",
                fixed_version="2.3.0",
                manifest_file=str(tmp_path / "nonexistent" / "requirements.txt"),
            ),
        ]

        report = apply_fixes(actions)

        assert report.applied_count == 1
        assert report.skipped_count == 1

    def test_apply_fixes_unsupported_manifest(self, tmp_path: Path):
        f = tmp_path / "go.mod"
        f.write_text("module example.com/foo\n")

        actions = [
            FixAction(
                package="foo",
                current_version="1.0.0",
                fixed_version="1.1.0",
                manifest_file=str(f),
            ),
        ]

        report = apply_fixes(actions)

        assert report.skipped_count == 1
        assert "Unsupported" in actions[0].error


class TestFixReport:
    def test_empty_report(self):
        report = FixReport()
        assert report.applied_count == 0
        assert report.skipped_count == 0

    def test_report_with_mixed_actions(self):
        actions = [
            FixAction("a", "1.0", "2.0", "req.txt", applied=True),
            FixAction("b", "1.0", "2.0", "req.txt", applied=False, error="fail"),
            FixAction("c", "1.0", "2.0", "req.txt", applied=True),
        ]
        report = FixReport(actions=actions)
        assert report.applied_count == 2
        assert report.skipped_count == 1
