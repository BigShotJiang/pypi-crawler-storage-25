"""Tests for the file watcher and interval scheduler."""

from __future__ import annotations

import os
import time
import threading

import pytest

from guard.core.watcher import (
    DEBOUNCE_DELAY,
    POLL_INTERVAL,
    SOURCE_EXTENSIONS,
    FileWatcher,
    IntervalScheduler,
    _is_source_file,
    _matches_exclude,
    _print_scan_summary,
)


# ---------------------------------------------------------------------------
# _is_source_file
# ---------------------------------------------------------------------------


class TestIsSourceFile:
    def test_python_file(self):
        assert _is_source_file("app.py") is True

    def test_javascript_file(self):
        assert _is_source_file("index.js") is True

    def test_typescript_file(self):
        assert _is_source_file("component.tsx") is True

    def test_java_file(self):
        assert _is_source_file("Main.java") is True

    def test_c_file(self):
        assert _is_source_file("main.c") is True

    def test_go_file(self):
        assert _is_source_file("server.go") is True

    def test_rust_file(self):
        assert _is_source_file("lib.rs") is True

    def test_non_source_file(self):
        assert _is_source_file("image.png") is False

    def test_binary_file(self):
        assert _is_source_file("program.exe") is False

    def test_markdown_not_source(self):
        assert _is_source_file("README.md") is False

    def test_case_insensitive(self):
        assert _is_source_file("App.PY") is True
        assert _is_source_file("Module.JS") is True

    def test_no_extension(self):
        assert _is_source_file("Makefile") is False

    def test_path_with_directory(self):
        assert _is_source_file("src/utils/helper.py") is True

    def test_yaml_is_source(self):
        assert _is_source_file("config.yaml") is True

    def test_json_is_source(self):
        assert _is_source_file("package.json") is True


# ---------------------------------------------------------------------------
# _matches_exclude
# ---------------------------------------------------------------------------


class TestMatchesExclude:
    def test_directory_pattern(self):
        assert _matches_exclude("tests/test_foo.py", ["tests/"]) is True

    def test_no_match(self):
        assert _matches_exclude("src/main.py", ["tests/"]) is False

    def test_glob_pattern(self):
        assert _matches_exclude("test_foo.py", ["test_*"]) is True

    def test_nested_directory(self):
        assert _matches_exclude("docs/api/reference.md", ["docs/"]) is True

    def test_wildcard_extension(self):
        assert _matches_exclude("output/report.html", ["*.html"]) is True

    def test_multiple_patterns(self):
        assert _matches_exclude("tests/test_foo.py", ["docs/", "tests/"]) is True

    def test_empty_excludes(self):
        assert _matches_exclude("src/main.py", []) is False

    def test_backslash_normalization(self):
        assert _matches_exclude("tests\\test_foo.py", ["tests/"]) is True


# ---------------------------------------------------------------------------
# FileWatcher
# ---------------------------------------------------------------------------


class TestFileWatcher:
    def test_take_snapshot(self, tmp_path):
        """Snapshot captures existing source files."""
        (tmp_path / "app.py").write_text("x = 1")
        (tmp_path / "readme.md").write_text("hello")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        assert "app.py" in watcher._snapshot
        # .md is not a source extension
        assert "readme.md" not in watcher._snapshot

    def test_detect_new_file(self, tmp_path):
        """New source files are detected as changes."""
        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        (tmp_path / "new_module.py").write_text("print('hello')")
        changes = watcher.detect_changes()

        assert "new_module.py" in changes

    def test_detect_modified_file(self, tmp_path):
        """Modified files are detected as changes."""
        src = tmp_path / "app.py"
        src.write_text("x = 1")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        # Ensure mtime changes (some filesystems have 1s resolution)
        time.sleep(0.05)
        src.write_text("x = 2")
        # Force mtime to be different
        os.utime(src, (time.time() + 1, time.time() + 1))

        changes = watcher.detect_changes()
        assert "app.py" in changes

    def test_no_changes(self, tmp_path):
        """No changes reported when files are unchanged."""
        (tmp_path / "app.py").write_text("x = 1")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        changes = watcher.detect_changes()
        assert changes == []

    def test_respects_exclude_patterns(self, tmp_path):
        """Excluded directories are not watched."""
        (tmp_path / "tests").mkdir()

        watcher = FileWatcher(tmp_path, excludes=["tests/"])
        watcher.take_snapshot()

        (tmp_path / "tests" / "test_new.py").write_text("assert True")
        changes = watcher.detect_changes()

        assert changes == []

    def test_ignores_non_source_files(self, tmp_path):
        """Non-source files (e.g. images) are not tracked."""
        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        (tmp_path / "photo.png").write_bytes(b"\x89PNG")
        changes = watcher.detect_changes()

        assert changes == []

    def test_skips_hidden_directories(self, tmp_path):
        """Hidden directories (starting with .) are skipped."""
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "secret.py").write_text("x = 1")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        assert ".hidden/secret.py" not in watcher._snapshot

    def test_skips_node_modules(self, tmp_path):
        """node_modules directory is skipped."""
        nm = tmp_path / "node_modules"
        nm.mkdir()
        (nm / "index.js").write_text("module.exports = {}")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        assert not any("node_modules" in k for k in watcher._snapshot)

    def test_subdirectory_files(self, tmp_path):
        """Files in subdirectories are tracked."""
        sub = tmp_path / "src" / "utils"
        sub.mkdir(parents=True)
        (sub / "helper.py").write_text("def help(): pass")

        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        assert "src/utils/helper.py" in watcher._snapshot

    def test_detect_changes_updates_snapshot(self, tmp_path):
        """After detecting changes, the snapshot is updated so the same
        change is not reported twice."""
        watcher = FileWatcher(tmp_path)
        watcher.take_snapshot()

        (tmp_path / "new.py").write_text("x = 1")
        changes1 = watcher.detect_changes()
        assert "new.py" in changes1

        changes2 = watcher.detect_changes()
        assert changes2 == []

    def test_multiple_excludes(self, tmp_path):
        """Multiple exclude patterns work together."""
        (tmp_path / "build").mkdir()
        (tmp_path / "dist").mkdir()

        watcher = FileWatcher(tmp_path, excludes=["build/", "dist/"])
        watcher.take_snapshot()

        (tmp_path / "build" / "output.js").write_text("var x;")
        (tmp_path / "dist" / "bundle.js").write_text("var y;")
        (tmp_path / "app.js").write_text("var z;")

        changes = watcher.detect_changes()
        assert "app.js" in changes
        assert not any("build" in c for c in changes)
        assert not any("dist" in c for c in changes)


# ---------------------------------------------------------------------------
# FileWatcher debounce
# ---------------------------------------------------------------------------


class TestFileWatcherDebounce:
    def test_wait_for_changes_returns_on_stop(self, tmp_path):
        """wait_for_changes returns empty list when stop_event is set."""
        watcher = FileWatcher(tmp_path, poll_interval=0.05, debounce=0.05)
        watcher.take_snapshot()

        stop = threading.Event()
        stop.set()  # Already stopped
        result = watcher.wait_for_changes(stop)
        assert result == []

    def test_wait_for_changes_detects_file(self, tmp_path):
        """wait_for_changes returns changed files after debounce."""
        watcher = FileWatcher(tmp_path, poll_interval=0.05, debounce=0.1)
        watcher.take_snapshot()

        stop = threading.Event()

        def create_file():
            time.sleep(0.02)
            (tmp_path / "added.py").write_text("x = 1")

        t = threading.Thread(target=create_file)
        t.start()

        result = watcher.wait_for_changes(stop)
        t.join()

        assert "added.py" in result

    def test_debounce_batches_rapid_changes(self, tmp_path):
        """Rapid changes within the debounce window are batched together."""
        watcher = FileWatcher(tmp_path, poll_interval=0.05, debounce=0.3)
        watcher.take_snapshot()

        stop = threading.Event()

        def create_files():
            time.sleep(0.02)
            (tmp_path / "a.py").write_text("a")
            time.sleep(0.05)
            (tmp_path / "b.py").write_text("b")

        t = threading.Thread(target=create_files)
        t.start()

        result = watcher.wait_for_changes(stop)
        t.join()

        assert "a.py" in result
        assert "b.py" in result


# ---------------------------------------------------------------------------
# IntervalScheduler
# ---------------------------------------------------------------------------


class TestIntervalScheduler:
    def test_not_due_initially(self):
        """Scheduler is not due right after creation (interval not elapsed)."""
        sched = IntervalScheduler(interval=10)
        sched.reset()
        assert sched.is_due() is False

    def test_due_after_interval(self):
        """Scheduler is due after the interval has elapsed."""
        sched = IntervalScheduler(interval=0.05)
        sched.reset()
        time.sleep(0.06)
        assert sched.is_due() is True

    def test_trigger_resets_timer(self):
        """Calling trigger() resets so is_due() becomes False."""
        sched = IntervalScheduler(interval=0.05)
        sched.reset()
        time.sleep(0.06)
        assert sched.is_due() is True
        sched.trigger()
        assert sched.is_due() is False

    def test_zero_interval_never_due(self):
        """Interval of 0 means the scheduler never triggers."""
        sched = IntervalScheduler(interval=0)
        assert sched.is_due() is False
        time.sleep(0.01)
        assert sched.is_due() is False

    def test_seconds_until_next(self):
        """seconds_until_next returns a reasonable value."""
        sched = IntervalScheduler(interval=1.0)
        sched.reset()
        remaining = sched.seconds_until_next()
        assert 0 < remaining <= 1.0

    def test_seconds_until_next_zero_interval(self):
        """With zero interval, seconds_until_next is infinity."""
        sched = IntervalScheduler(interval=0)
        assert sched.seconds_until_next() == float("inf")

    def test_reset_sets_last_trigger(self):
        """reset() makes is_due() return False for the interval duration."""
        sched = IntervalScheduler(interval=100)
        # Before reset, _last_trigger is 0 so it would be "due" immediately
        # because monotonic() is large.
        sched.reset()
        assert sched.is_due() is False


# ---------------------------------------------------------------------------
# _print_scan_summary
# ---------------------------------------------------------------------------


class TestPrintScanSummary:
    def test_passed_output(self, capsys):
        _print_scan_summary(True, {"low": 2, "info": 1}, 3)
        out = capsys.readouterr().out
        assert "Gate passed" in out
        assert "3 findings" in out

    def test_failed_output(self, capsys):
        _print_scan_summary(False, {"critical": 1, "high": 2}, 3)
        out = capsys.readouterr().out
        assert "Gate failed" in out
        assert "1 critical" in out
        assert "2 high" in out

    def test_quiet_suppresses_passed(self, capsys):
        _print_scan_summary(True, {}, 0, quiet=True)
        out = capsys.readouterr().out
        assert out == ""

    def test_quiet_shows_failed(self, capsys):
        _print_scan_summary(False, {"critical": 1}, 1, quiet=True)
        out = capsys.readouterr().out
        assert "Gate failed" in out

    def test_clean_scan(self, capsys):
        _print_scan_summary(True, {}, 0)
        out = capsys.readouterr().out
        assert "clean" in out


# ---------------------------------------------------------------------------
# Source extensions coverage
# ---------------------------------------------------------------------------


class TestSourceExtensions:
    def test_common_extensions_present(self):
        expected = {".py", ".js", ".ts", ".java", ".c", ".cpp", ".go", ".rb", ".rs"}
        assert expected.issubset(SOURCE_EXTENSIONS)

    def test_extensions_are_lowercase(self):
        for ext in SOURCE_EXTENSIONS:
            assert ext == ext.lower(), f"Extension {ext} should be lowercase"
            assert ext.startswith("."), f"Extension {ext} should start with '.'"
