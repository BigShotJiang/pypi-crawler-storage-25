"""Tests for the Policy-as-Code engine."""

from __future__ import annotations

import json
import os
import textwrap
from pathlib import Path

import pytest

from guard.rules.policy_engine import (
    Policy,
    PolicyCondition,
    PolicyResult,
    evaluate_policies,
    generate_template,
    load_policies,
    policy_results_to_findings,
)


@pytest.fixture()
def tmp_repo(tmp_path: Path):
    """Create a minimal repo structure for policy testing."""
    # src/safety/allocator.c
    safety_dir = tmp_path / "src" / "safety"
    safety_dir.mkdir(parents=True)
    (safety_dir / "allocator.c").write_text(
        textwrap.dedent("""\
            #include <stdlib.h>
            void* allocate(int size) {
                return malloc(size);
            }
            void deallocate(void* ptr) {
                free(ptr);
            }
        """),
        encoding="utf-8",
    )

    # src/app/main.py
    app_dir = tmp_path / "src" / "app"
    app_dir.mkdir(parents=True)
    (app_dir / "main.py").write_text(
        textwrap.dedent("""\
            # Copyright 2024 MedFiles Inc.
            import os
            import pdb

            def hello():
                print("hello")

            def world():
                print("world")
        """),
        encoding="utf-8",
    )

    # src/app/utils.py — no copyright header, many functions
    (app_dir / "utils.py").write_text(
        textwrap.dedent("""\
            import os
            def f1(): pass
            def f2(): pass
            def f3(): pass
            def f4(): pass
            def f5(): pass
        """),
        encoding="utf-8",
    )

    # src/safety/controller.cpp — with #include
    (safety_dir / "controller.cpp").write_text(
        textwrap.dedent("""\
            #include <stdio.h>
            #include "memory.h"
            int main() {
                printf("hello");
                return 0;
            }
        """),
        encoding="utf-8",
    )

    return tmp_path


class TestMustNotContain:
    def test_must_not_contain_flags_match(self, tmp_repo: Path):
        """Regex pattern is flagged when found."""
        policy = Policy(
            name="No eval",
            severity="critical",
            scope="src/**/*.py",
            conditions=[PolicyCondition(type="must_not_contain", value=r"\beval\s*\(")],
        )
        # Add a file with eval
        (tmp_repo / "src" / "app" / "dangerous.py").write_text(
            "result = eval(user_input)\n", encoding="utf-8"
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) >= 1
        assert "eval" in failed[0].message.lower() or "forbidden" in failed[0].message.lower()

    def test_must_not_contain_passes_when_absent(self, tmp_repo: Path):
        """No match means policy passes."""
        policy = Policy(
            name="No eval",
            severity="critical",
            scope="src/app/main.py",
            conditions=[PolicyCondition(type="must_not_contain", value=r"\beval\s*\(")],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 0


class TestMustContain:
    def test_must_contain_flags_missing_pattern(self, tmp_repo: Path):
        """Missing pattern is flagged."""
        policy = Policy(
            name="Must have logging",
            severity="medium",
            scope="src/app/utils.py",
            conditions=[PolicyCondition(type="must_contain", value=r"import logging")],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 1
        assert "required pattern" in failed[0].message.lower()

    def test_must_contain_passes_when_present(self, tmp_repo: Path):
        """Pattern present means policy passes."""
        policy = Policy(
            name="Must have os import",
            severity="medium",
            scope="src/app/main.py",
            conditions=[PolicyCondition(type="must_contain", value=r"import os")],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 0


class TestMustNotImport:
    def test_must_not_import_python(self, tmp_repo: Path):
        """Banned Python import detected."""
        policy = Policy(
            name="No debugger imports",
            severity="high",
            scope="src/**/*.py",
            conditions=[PolicyCondition(type="must_not_import", value=["pdb", "ipdb"])],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) >= 1
        assert any("pdb" in r.message for r in failed)

    def test_must_not_import_cpp(self, tmp_repo: Path):
        """Banned C/C++ #include detected."""
        policy = Policy(
            name="No stdio",
            severity="medium",
            scope="src/**/*.cpp",
            conditions=[PolicyCondition(type="must_not_import", value=["stdio.h"])],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) >= 1
        assert any("stdio.h" in r.message for r in failed)


class TestMaxLines:
    def test_max_lines_flags_long_file(self, tmp_repo: Path):
        """File exceeding line limit is flagged."""
        # Create a long file
        long_content = "\n".join(f"line_{i} = {i}" for i in range(600))
        (tmp_repo / "src" / "app" / "long.py").write_text(long_content, encoding="utf-8")

        policy = Policy(
            name="Max file length",
            severity="low",
            scope="src/**/*.py",
            conditions=[PolicyCondition(type="max_lines", value=500)],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        # Only long.py should fail
        long_failures = [r for r in failed if "long.py" in r.file]
        assert len(long_failures) == 1
        assert "600" in long_failures[0].message

    def test_max_lines_passes_short_file(self, tmp_repo: Path):
        """Short file passes the check."""
        policy = Policy(
            name="Max file length",
            severity="low",
            scope="src/app/main.py",
            conditions=[PolicyCondition(type="max_lines", value=500)],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 0


class TestMaxFunctions:
    def test_max_functions_flags_excess(self, tmp_repo: Path):
        """Too many functions flagged."""
        policy = Policy(
            name="Max functions",
            severity="low",
            scope="src/app/utils.py",
            conditions=[PolicyCondition(type="max_functions", value=3)],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 1
        assert "5" in failed[0].message  # utils.py has 5 functions


class TestRequiresHeader:
    def test_requires_header_flags_missing(self, tmp_repo: Path):
        """Missing header is flagged."""
        policy = Policy(
            name="Copyright header",
            severity="medium",
            scope="src/app/utils.py",
            conditions=[PolicyCondition(type="requires_header", value=r"Copyright.*MedFiles")],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 1
        assert "header" in failed[0].message.lower()

    def test_requires_header_present(self, tmp_repo: Path):
        """Correct header passes."""
        policy = Policy(
            name="Copyright header",
            severity="medium",
            scope="src/app/main.py",
            conditions=[PolicyCondition(type="requires_header", value=r"Copyright.*MedFiles")],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) == 0


class TestNoCallsTo:
    def test_no_calls_to_flags_banned(self, tmp_repo: Path):
        """Banned function call detected."""
        policy = Policy(
            name="No malloc in safety code",
            severity="critical",
            scope="src/safety/**",
            conditions=[PolicyCondition(type="no_calls_to", value=["malloc", "free"])],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        assert len(failed) >= 2  # malloc and free in allocator.c
        messages = [r.message for r in failed]
        assert any("malloc" in m for m in messages)
        assert any("free" in m for m in messages)


class TestScopeFiltering:
    def test_scope_filtering(self, tmp_repo: Path):
        """Only files matching scope are checked."""
        policy = Policy(
            name="No malloc in safety code",
            severity="critical",
            scope="src/safety/**",
            conditions=[PolicyCondition(type="no_calls_to", value=["printf"])],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        # printf is in controller.cpp (safety dir) — should be flagged
        # But NOT in app dir files
        for r in failed:
            assert "src/safety" in r.file.replace("\\", "/") or "src\\safety" in r.file


class TestActionWarnVsDeny:
    def test_action_warn_vs_deny(self, tmp_repo: Path):
        """Both warn and deny actions produce results; severity is preserved."""
        warn_policy = Policy(
            name="Warn policy",
            severity="low",
            scope="src/app/utils.py",
            action="warn",
            conditions=[PolicyCondition(type="max_functions", value=3)],
        )
        deny_policy = Policy(
            name="Deny policy",
            severity="critical",
            scope="src/app/utils.py",
            action="deny",
            conditions=[PolicyCondition(type="max_functions", value=3)],
        )
        warn_results = evaluate_policies([warn_policy], str(tmp_repo))
        deny_results = evaluate_policies([deny_policy], str(tmp_repo))
        warn_failed = [r for r in warn_results if not r.passed]
        deny_failed = [r for r in deny_results if not r.passed]
        assert len(warn_failed) >= 1
        assert len(deny_failed) >= 1
        assert warn_failed[0].severity == "low"
        assert deny_failed[0].severity == "critical"


class TestMultipleConditions:
    def test_multiple_conditions_all_checked(self, tmp_repo: Path):
        """All conditions in a policy are evaluated."""
        policy = Policy(
            name="Multi-condition",
            severity="high",
            scope="src/app/main.py",
            conditions=[
                PolicyCondition(type="must_not_import", value=["pdb"]),
                PolicyCondition(type="requires_header", value=r"Copyright.*MedFiles"),
            ],
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        # pdb import should fail; header should pass
        assert len(failed) == 1
        assert "pdb" in failed[0].message


class TestLoadPolicies:
    def test_load_policies(self, tmp_path: Path):
        """YAML parsing works correctly."""
        policies_yaml = tmp_path / "policies.yaml"
        policies_yaml.write_text(
            textwrap.dedent("""\
                policies:
                  - name: "Test Policy"
                    description: "A test"
                    severity: high
                    scope: "src/**/*.py"
                    action: deny
                    conditions:
                      - type: must_not_contain
                        value: "TODO"
            """),
            encoding="utf-8",
        )
        policies = load_policies(str(policies_yaml))
        assert len(policies) == 1
        assert policies[0].name == "Test Policy"
        assert policies[0].severity == "high"
        assert len(policies[0].conditions) == 1
        assert policies[0].conditions[0].type == "must_not_contain"

    def test_load_policies_missing(self, tmp_path: Path):
        """Missing file returns empty list."""
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            policies = load_policies()
            assert policies == []
        finally:
            os.chdir(old_cwd)


class TestInitGeneratesTemplate:
    def test_init_generates_template(self, tmp_path: Path):
        """Creates example policies.yaml file."""
        path = generate_template(tmp_path / "policies.yaml")
        assert path.exists()
        content = path.read_text(encoding="utf-8")
        assert "policies:" in content
        assert "no_calls_to" in content
        assert "requires_header" in content
        assert "max_lines" in content


class TestPolicyResultsToFindings:
    def test_policy_results_to_findings(self):
        """Correct Finding fields from PolicyResult."""
        results = [
            PolicyResult(
                policy_name="No malloc",
                file="src/safety/alloc.c",
                line=5,
                message="Banned call to malloc()",
                severity="critical",
                passed=False,
            ),
            PolicyResult(
                policy_name="No malloc",
                file="src/safety/alloc.c",
                line=0,
                message="This one passed",
                severity="critical",
                passed=True,
            ),
        ]
        findings = policy_results_to_findings(results)
        assert len(findings) == 1  # Only failed results become findings
        f = findings[0]
        assert f.rule_id == "POLICY-no-malloc"
        assert f.severity.value == "critical"
        assert f.standard == "Policy"
        assert "No malloc" in f.message
        assert "malloc" in f.message
        assert f.evidence.file == "src/safety/alloc.c"
        assert f.evidence.lines == [5]
        assert f.confidence == 1.0
        assert f.deterministic is True


class TestCustomRegex:
    def test_custom_regex_with_dict_value(self, tmp_repo: Path):
        """Custom regex with dict value containing pattern and message."""
        policy = Policy(
            name="No TODO comments",
            severity="low",
            scope="src/**/*.py",
            conditions=[
                PolicyCondition(
                    type="custom_regex",
                    value={"pattern": r"TODO|FIXME|HACK", "message": "Unresolved TODO found"},
                )
            ],
        )
        # Add a file with a TODO
        (tmp_repo / "src" / "app" / "todo_file.py").write_text(
            "# TODO: fix this\ndef foo(): pass\n", encoding="utf-8"
        )
        results = evaluate_policies([policy], str(tmp_repo))
        failed = [r for r in results if not r.passed]
        todo_failures = [r for r in failed if "todo_file.py" in r.file]
        assert len(todo_failures) >= 1
        assert "TODO" in todo_failures[0].message


class TestCLICheckPoliciesJson:
    def test_cli_check_policies_json(self, tmp_path: Path):
        """CLI JSON output produces valid JSON."""
        from typer.testing import CliRunner
        from guard.cli import app

        # Create a policies file and a source file that violates it
        policies_yaml = tmp_path / "policies.yaml"
        policies_yaml.write_text(
            textwrap.dedent("""\
                policies:
                  - name: "No eval"
                    severity: critical
                    scope: "**/*.py"
                    action: deny
                    conditions:
                      - type: must_not_contain
                        value: "eval\\\\("
            """),
            encoding="utf-8",
        )
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "bad.py").write_text("x = eval(input())\n", encoding="utf-8")

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(app, ["check-policies", "--config", str(policies_yaml), "--json"])
        finally:
            os.chdir(old_cwd)

        # Should produce valid JSON
        assert result.exit_code == 0
        output = result.output.strip()
        parsed = json.loads(output)
        assert isinstance(parsed, list)


class TestCLICheckPoliciesInit:
    def test_cli_init_creates_file(self, tmp_path: Path):
        """--init flag generates template file."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(app, ["check-policies", "--init"])
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert (tmp_path / "policies.yaml").exists()


class TestWithExplicitFileList:
    def test_evaluate_with_file_list(self, tmp_repo: Path):
        """Evaluate policies with explicit file list."""
        policy = Policy(
            name="No pdb",
            severity="high",
            scope="**/*.py",
            conditions=[PolicyCondition(type="must_not_import", value=["pdb"])],
        )
        # Only check main.py (which has pdb import)
        results = evaluate_policies(
            [policy],
            str(tmp_repo),
            files=["src/app/main.py"],
        )
        failed = [r for r in results if not r.passed]
        assert len(failed) == 1
        assert "pdb" in failed[0].message

        # Check utils.py (which does NOT have pdb import)
        results2 = evaluate_policies(
            [policy],
            str(tmp_repo),
            files=["src/app/utils.py"],
        )
        failed2 = [r for r in results2 if not r.passed]
        assert len(failed2) == 0
