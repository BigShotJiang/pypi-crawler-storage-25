"""Comprehensive tests for scan cache (Phase 9)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.helpers import make_finding as _finding
from guard.core.cache import ScanCache, content_hash, rules_hash


# ===================================================================
# content_hash and rules_hash
# ===================================================================


class TestHashFunctions:
    def test_content_hash_deterministic(self):
        assert content_hash("hello") == content_hash("hello")

    def test_content_hash_different(self):
        assert content_hash("a") != content_hash("b")

    def test_content_hash_hex_string(self):
        h = content_hash("test")
        assert len(h) == 64  # SHA-256 hex

    def test_rules_hash_deterministic(self):
        rules = [{"id": "R1", "type": "regex"}]
        assert rules_hash(rules) == rules_hash(rules)

    def test_rules_hash_different(self):
        r1 = [{"id": "R1"}]
        r2 = [{"id": "R2"}]
        assert rules_hash(r1) != rules_hash(r2)

    def test_rules_hash_empty(self):
        h = rules_hash([])
        assert len(h) == 64

    def test_rules_hash_order_independent(self):
        # JSON sort_keys ensures deterministic hashing regardless of dict order
        r1 = [{"id": "R1", "type": "regex"}]
        r2 = [{"type": "regex", "id": "R1"}]
        assert rules_hash(r1) == rules_hash(r2)


# ===================================================================
# ScanCache basic operations
# ===================================================================


class TestScanCacheBasic:
    def test_empty_cache_returns_none(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        assert cache.get("a.py", "hash1", "rhash") is None

    def test_put_then_get(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        f = _finding("F1")
        cache.put("a.py", "hash1", "rhash", [f])
        result = cache.get("a.py", "hash1", "rhash")
        assert result is not None
        assert len(result) == 1
        assert result[0].finding_id == "F1"

    def test_different_content_hash_misses(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "hash1", "rhash", [_finding()])
        assert cache.get("a.py", "hash2", "rhash") is None

    def test_different_rules_hash_misses(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "hash1", "rhash1", [_finding()])
        assert cache.get("a.py", "hash1", "rhash2") is None

    def test_different_file_misses(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "hash1", "rhash", [_finding()])
        assert cache.get("b.py", "hash1", "rhash") is None

    def test_empty_findings_cached(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "hash1", "rhash", [])
        result = cache.get("a.py", "hash1", "rhash")
        assert result == []

    def test_size(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        assert cache.size == 0
        cache.put("a.py", "h1", "r", [])
        assert cache.size == 1
        cache.put("b.py", "h2", "r", [])
        assert cache.size == 2


# ===================================================================
# Cache persistence
# ===================================================================


class TestCachePersistence:
    def test_save_and_reload(self, tmp_path):
        cache_dir = tmp_path / ".cache"
        cache = ScanCache(cache_dir)
        cache.put("a.py", "hash1", "rhash", [_finding("F1")])
        cache.save()

        # Reload
        cache2 = ScanCache(cache_dir)
        result = cache2.get("a.py", "hash1", "rhash")
        assert result is not None
        assert result[0].finding_id == "F1"

    def test_save_creates_directory(self, tmp_path):
        cache_dir = tmp_path / "deep" / "nested" / ".cache"
        cache = ScanCache(cache_dir)
        cache.put("a.py", "h", "r", [])
        cache.save()
        assert cache_dir.exists()

    def test_corrupted_cache_resets(self, tmp_path):
        cache_dir = tmp_path / ".cache"
        cache_dir.mkdir()
        (cache_dir / "findings_cache.json").write_text("not json!")
        cache = ScanCache(cache_dir)
        assert cache.size == 0


# ===================================================================
# Cache invalidation
# ===================================================================


class TestCacheInvalidation:
    def test_invalidate_file(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "h", "r", [_finding()])
        cache.invalidate("a.py")
        assert cache.get("a.py", "h", "r") is None

    def test_invalidate_nonexistent_no_error(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.invalidate("nope.py")  # no error

    def test_clear(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "h1", "r", [])
        cache.put("b.py", "h2", "r", [])
        cache.clear()
        assert cache.size == 0
        assert cache.get("a.py", "h1", "r") is None


# ===================================================================
# Cache with multiple findings
# ===================================================================


class TestCacheMultipleFindings:
    def test_cache_multiple_findings(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        findings = [_finding("F1"), _finding("F2"), _finding("F3")]
        cache.put("a.py", "h", "r", findings)
        result = cache.get("a.py", "h", "r")
        assert len(result) == 3
        assert {f.finding_id for f in result} == {"F1", "F2", "F3"}

    def test_overwrite_entry(self, tmp_path):
        cache = ScanCache(tmp_path / ".cache")
        cache.put("a.py", "h1", "r", [_finding("F1")])
        cache.put("a.py", "h2", "r", [_finding("F2")])
        assert cache.get("a.py", "h1", "r") is None
        result = cache.get("a.py", "h2", "r")
        assert result[0].finding_id == "F2"
