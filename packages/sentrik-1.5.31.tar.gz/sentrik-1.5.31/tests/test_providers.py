"""Comprehensive tests for provider factory and LLM scanner (Phase 6 + 7)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from tests.helpers import write_file as _write
from guard.config import GuardConfig
from guard.core.models import Severity
from guard.providers.devops_stub import DevOpsStub
from guard.providers.factory import (
    build_devops,
    build_llm,
    build_providers,
    build_scanner,
    build_standards,
)
from guard.providers.llm_base import LLMProvider
from guard.providers.llm_stub import LLMStub
from guard.providers.scanners_composite import ScannersComposite
from guard.providers.scanners_llm import ScannersLLM
from guard.providers.scanners_sarif import ScannersSarif
from guard.providers.scanners_stub import ScannersStub
from guard.providers.standards_stub import StandardsStub
from guard.rules.engine import RulesEngine


class FakeLLM(LLMProvider):
    """LLM that returns canned findings for testing."""

    def __init__(self, findings: list[dict] | None = None):
        self._findings = findings or []

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "findings": self._findings,
            "summary": "Fake LLM analysis.",
            "confidence": 0.8,
        }


class ErrorLLM(LLMProvider):
    """LLM that always raises."""

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        raise ValueError("LLM unavailable")


# ===================================================================
# Provider factory
# ===================================================================


class TestProviderFactory:
    def test_build_providers_default_config(self):
        config = GuardConfig()
        devops, standards, scanner, engine, llm = build_providers(config)

        assert isinstance(devops, DevOpsStub)
        assert isinstance(standards, StandardsStub)
        assert isinstance(scanner, ScannersStub)
        assert isinstance(engine, RulesEngine)
        assert isinstance(llm, LLMStub)

    def test_build_providers_llm_enabled(self):
        config = GuardConfig(llm_enabled=True)
        devops, standards, scanner, engine, llm = build_providers(config)

        assert isinstance(scanner, ScannersLLM)

    def test_build_providers_llm_disabled(self):
        config = GuardConfig(llm_enabled=False)
        _, _, scanner, _, _ = build_providers(config)

        assert isinstance(scanner, ScannersStub)

    def test_build_devops(self):
        config = GuardConfig()
        devops = build_devops(config)
        assert isinstance(devops, DevOpsStub)

    def test_build_devops_github(self):
        from guard.providers.devops_github import DevOpsGitHub
        config = GuardConfig(
            devops_provider="github",
            github_owner="acme",
            github_repo="app",
            github_label="guard",
            github_milestone="v1",
        )
        devops = build_devops(config)
        assert isinstance(devops, DevOpsGitHub)
        assert devops._owner == "acme"
        assert devops._repo == "app"
        assert devops._label == "guard"
        assert devops._milestone == "v1"

    def test_build_standards(self):
        config = GuardConfig()
        standards = build_standards(config)
        assert isinstance(standards, StandardsStub)

    def test_build_standards_github(self):
        from guard.providers.standards_github import StandardsGitHub
        config = GuardConfig(
            standards_provider="github",
            github_owner="acme",
            github_standards_repo="standards",
            github_standards_file="rules.yaml",
            github_standards_ref="develop",
        )
        standards = build_standards(config)
        assert isinstance(standards, StandardsGitHub)
        assert standards._owner == "acme"
        assert standards._repo == "standards"
        assert standards._file_path == "rules.yaml"
        assert standards._ref == "develop"

    def test_build_standards_github_fallback_repo(self):
        from guard.providers.standards_github import StandardsGitHub
        config = GuardConfig(
            standards_provider="github",
            github_owner="acme",
            github_repo="main-app",
            github_standards_repo="",
        )
        standards = build_standards(config)
        assert isinstance(standards, StandardsGitHub)
        assert standards._repo == "main-app"  # Falls back to github_repo

    def test_build_devops_jira(self):
        from guard.providers.devops_jira import DevOpsJira
        config = GuardConfig(
            devops_provider="jira",
            jira_base_url="https://jira.example.com",
            jira_project_key="PROJ",
            jira_jql="assignee = me",
        )
        devops = build_devops(config)
        assert isinstance(devops, DevOpsJira)
        assert devops._base_url == "https://jira.example.com"
        assert devops._project_key == "PROJ"
        assert devops._jql == "assignee = me"

    def test_build_standards_jira(self):
        from guard.providers.standards_jira import StandardsJira
        config = GuardConfig(
            standards_provider="jira",
            jira_base_url="https://jira.example.com",
            jira_standards_issue_key="STDS-1",
        )
        standards = build_standards(config)
        assert isinstance(standards, StandardsJira)
        assert standards._base_url == "https://jira.example.com"
        assert standards._issue_key == "STDS-1"

    def test_build_llm(self):
        config = GuardConfig()
        llm = build_llm(config)
        assert isinstance(llm, LLMStub)

    def test_build_scanner_stub(self):
        config = GuardConfig(llm_enabled=False)
        scanner = build_scanner(config)
        assert isinstance(scanner, ScannersStub)

    def test_build_scanner_llm_with_provider(self):
        config = GuardConfig(llm_enabled=True)
        llm = LLMStub()
        scanner = build_scanner(config, llm)
        assert isinstance(scanner, ScannersLLM)

    def test_build_scanner_llm_enabled_but_no_provider(self):
        config = GuardConfig(llm_enabled=True)
        scanner = build_scanner(config, None)
        assert isinstance(scanner, ScannersStub)

    def test_build_scanner_sarif_provider(self, tmp_path):
        config = GuardConfig(provider="sarif", sarif_files=[str(tmp_path / "r.sarif")])
        scanner = build_scanner(config)
        assert isinstance(scanner, ScannersSarif)

    def test_build_scanner_composite_with_sarif(self, tmp_path):
        config = GuardConfig(
            provider="composite",
            sarif_files=[str(tmp_path / "r.sarif")],
        )
        scanner = build_scanner(config)
        # Only one sub-scanner → returned directly (not wrapped in Composite)
        assert isinstance(scanner, ScannersSarif)

    def test_build_scanner_composite_with_sarif_and_llm(self, tmp_path):
        config = GuardConfig(
            provider="composite",
            sarif_files=[str(tmp_path / "r.sarif")],
            llm_enabled=True,
        )
        llm = LLMStub()
        scanner = build_scanner(config, llm)
        assert isinstance(scanner, ScannersComposite)
        assert len(scanner.scanners) == 2

    def test_build_scanner_composite_no_sources_falls_back(self):
        config = GuardConfig(provider="composite")
        scanner = build_scanner(config)
        assert isinstance(scanner, ScannersStub)

    def test_build_scanner_composite_llm_only(self):
        config = GuardConfig(provider="composite", llm_enabled=True)
        llm = LLMStub()
        scanner = build_scanner(config, llm)
        assert isinstance(scanner, ScannersLLM)


# ===================================================================
# LLM stub
# ===================================================================


class TestLLMStub:
    def test_returns_empty_findings(self):
        llm = LLMStub()
        result = llm.analyze("test", {"file": "a.py", "content": "x = 1"})

        assert result["findings"] == []
        assert result["confidence"] == 0.0

    def test_summary_indicates_disabled(self):
        llm = LLMStub()
        result = llm.analyze("test", {})

        assert "disabled" in result["summary"].lower() or "stub" in result["summary"].lower()


# ===================================================================
# LLM scanner
# ===================================================================


class TestScannersLLM:
    def test_produces_heuristic_findings(self, tmp_path):
        _write(tmp_path, "app.py", "x = eval(input())\n")
        llm = FakeLLM([
            {
                "rule_id": "llm-eval-usage",
                "severity": "high",
                "message": "Use of eval() is dangerous",
                "line": 1,
                "snippet": "x = eval(input())",
                "suggestion": "Replace eval() with ast.literal_eval()",
                "confidence": 0.85,
            },
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "llm-eval-usage"
        assert f.severity == Severity.HIGH
        assert f.deterministic is False
        assert f.confidence == 0.85
        assert f.evidence.file == "app.py"
        assert f.evidence.lines == [1]
        assert f.suggestion == "Replace eval() with ast.literal_eval()"

    def test_multiple_findings_multiple_files(self, tmp_path):
        _write(tmp_path, "a.py", "eval('x')\n")
        _write(tmp_path, "b.py", "exec('y')\n")
        llm = FakeLLM([
            {"rule_id": "llm-issue", "severity": "medium", "message": "Issue found", "confidence": 0.7},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        # One finding per file (FakeLLM returns same finding for each)
        assert len(findings) == 2
        files = {f.evidence.file for f in findings}
        assert "a.py" in files
        assert "b.py" in files

    def test_respects_changed_files_scoping(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        _write(tmp_path, "b.py", "y = 2\n")
        llm = FakeLLM([
            {"rule_id": "llm-x", "severity": "low", "message": "Issue", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path), changed_files=["a.py"])

        assert len(findings) == 1
        assert findings[0].evidence.file == "a.py"

    def test_empty_changed_files_returns_empty(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        llm = FakeLLM([
            {"rule_id": "llm-x", "severity": "low", "message": "Issue", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path), changed_files=[])

        assert findings == []

    def test_llm_error_gracefully_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        scanner = ScannersLLM(ErrorLLM())
        findings = scanner.scan(str(tmp_path))

        assert findings == []

    def test_llm_returns_no_findings(self, tmp_path):
        _write(tmp_path, "clean.py", "x = 1\n")
        llm = FakeLLM([])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert findings == []

    def test_malformed_finding_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        llm = FakeLLM([
            "not a dict",  # type: ignore[list-item]
            {"rule_id": "good", "severity": "low", "message": "OK", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].rule_id == "good"

    def test_invalid_severity_defaults_to_info(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        llm = FakeLLM([
            {"rule_id": "x", "severity": "banana", "message": "test", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].severity == Severity.INFO

    def test_confidence_clamped(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        llm = FakeLLM([
            {"rule_id": "x", "severity": "low", "message": "over", "confidence": 5.0},
            {"rule_id": "y", "severity": "low", "message": "under", "confidence": -1.0},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 2
        assert findings[0].confidence == 1.0
        assert findings[1].confidence == 0.0

    def test_finding_without_line(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        llm = FakeLLM([
            {"rule_id": "x", "severity": "low", "message": "no line", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].evidence.lines == []

    def test_binary_file_skipped(self, tmp_path):
        bin_path = tmp_path / "bad.py"
        bin_path.write_bytes(b"\x80\x81\x82")
        llm = FakeLLM([
            {"rule_id": "x", "severity": "low", "message": "test", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm)
        findings = scanner.scan(str(tmp_path))

        assert findings == []

    def test_custom_file_glob(self, tmp_path):
        _write(tmp_path, "app.py", "x = 1\n")
        _write(tmp_path, "app.js", "var x = 1;\n")
        llm = FakeLLM([
            {"rule_id": "x", "severity": "low", "message": "test", "confidence": 0.5},
        ])
        scanner = ScannersLLM(llm, file_glob="**/*.js")
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].evidence.file == "app.js"

    def test_llm_returns_non_list_findings(self, tmp_path):
        """When LLM returns findings as a non-list, scanner returns empty."""
        _write(tmp_path, "a.py", "x = 1\n")

        class BadLLM(LLMProvider):
            def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
                return {"findings": "not a list"}

        scanner = ScannersLLM(BadLLM())
        findings = scanner.scan(str(tmp_path))

        assert findings == []
