"""Tests for governance engine — policy profiles, policy engine, and audit log."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from guard.core.governance import (
    AuditConfig,
    AuditEntry,
    AuditLog,
    AutoPatchConfig,
    GateConfig,
    GovernanceConfig,
    HumanReviewConfig,
    PolicyDecision,
    PolicyEngine,
    SyncConfig,
    SEVERITY_ORDER,
    VALID_PROFILES,
    _PROFILE_DEFAULTS,
    build_governance_config,
    get_profile_defaults,
)


# ===================================================================
# GovernanceConfig & profile defaults
# ===================================================================


class TestGovernanceConfig:
    def test_default_profile_is_standard(self):
        gov = GovernanceConfig()
        assert gov.profile == "standard"

    def test_all_valid_profiles_have_defaults(self):
        for profile in VALID_PROFILES:
            assert profile in _PROFILE_DEFAULTS

    def test_strict_profile_defaults(self):
        defaults = get_profile_defaults("strict")
        assert defaults["gate"]["fail_on"] == ["critical", "high", "medium"]
        assert defaults["gate"]["block_merge_on_obligations"] is True
        assert defaults["sync"]["require_sign_off"] is True
        assert defaults["auto_patch"]["max_severity"] == "low"

    def test_standard_profile_defaults(self):
        defaults = get_profile_defaults("standard")
        assert defaults["gate"]["fail_on"] == ["critical", "high"]
        assert defaults["gate"]["block_merge_on_obligations"] is False
        assert defaults["sync"]["require_sign_off"] is False

    def test_permissive_profile_defaults(self):
        defaults = get_profile_defaults("permissive")
        assert defaults["gate"]["fail_on"] == ["critical"]
        assert defaults["auto_patch"]["max_severity"] == "high"
        assert defaults["human_review_required"]["on_requirement_change"] is False

    def test_unknown_profile_falls_back_to_standard(self):
        defaults = get_profile_defaults("nonexistent")
        assert defaults == _PROFILE_DEFAULTS["standard"]

    def test_sub_config_models(self):
        gov = GovernanceConfig()
        assert isinstance(gov.human_review_required, HumanReviewConfig)
        assert isinstance(gov.auto_patch, AutoPatchConfig)
        assert isinstance(gov.gate, GateConfig)
        assert isinstance(gov.sync, SyncConfig)
        assert isinstance(gov.audit, AuditConfig)


# ===================================================================
# build_governance_config
# ===================================================================


class TestBuildGovernanceConfig:
    def test_none_input_returns_default(self):
        gov = build_governance_config(None)
        assert gov.profile == "standard"

    def test_empty_dict_returns_default(self):
        gov = build_governance_config({})
        assert gov.profile == "standard"

    def test_strict_profile(self):
        gov = build_governance_config({"profile": "strict"})
        assert gov.profile == "strict"
        assert gov.gate.fail_on == ["critical", "high", "medium"]
        assert gov.sync.require_sign_off is True

    def test_permissive_profile(self):
        gov = build_governance_config({"profile": "permissive"})
        assert gov.profile == "permissive"
        assert gov.gate.fail_on == ["critical"]
        assert gov.human_review_required.on_requirement_change is False

    def test_user_overrides_merge_on_top_of_profile(self):
        raw = {
            "profile": "strict",
            "gate": {"fail_on": ["critical"]},
        }
        gov = build_governance_config(raw)
        assert gov.profile == "strict"
        # User override wins
        assert gov.gate.fail_on == ["critical"]
        # Other strict defaults still apply
        assert gov.sync.require_sign_off is True

    def test_partial_sub_override(self):
        raw = {
            "profile": "standard",
            "auto_patch": {"max_severity": "high"},
        }
        gov = build_governance_config(raw)
        # Overridden field
        assert gov.auto_patch.max_severity == "high"
        # Non-overridden field keeps profile default
        assert gov.auto_patch.enabled is True

    def test_audit_log_file_override(self):
        raw = {
            "audit": {"log_file": "custom/audit.jsonl"},
        }
        gov = build_governance_config(raw)
        assert gov.audit.log_file == "custom/audit.jsonl"
        assert gov.audit.enabled is True

    def test_non_dict_override_ignored(self):
        raw = {
            "profile": "standard",
            "gate": "not_a_dict",
        }
        gov = build_governance_config(raw)
        # Should use profile defaults since override is not a dict
        assert gov.gate.fail_on == ["critical", "high"]


# ===================================================================
# PolicyEngine — check_auto_patch
# ===================================================================


class TestPolicyEngineAutoPatch:
    def _engine(self, **kw) -> PolicyEngine:
        gov = GovernanceConfig(**kw)
        return PolicyEngine(gov)

    def test_auto_patch_allowed_for_low_severity(self):
        engine = self._engine()
        decision = engine.check_auto_patch("low")
        assert decision.allowed is True
        assert decision.action == "auto_patch"

    def test_auto_patch_allowed_for_info_severity(self):
        engine = self._engine()
        decision = engine.check_auto_patch("info")
        assert decision.allowed is True

    def test_auto_patch_blocked_for_high_severity_default(self):
        engine = self._engine()
        decision = engine.check_auto_patch("high")
        assert decision.allowed is False
        assert "exceeds" in decision.reason

    def test_auto_patch_blocked_for_critical(self):
        engine = self._engine()
        decision = engine.check_auto_patch("critical")
        assert decision.allowed is False

    def test_auto_patch_disabled(self):
        engine = self._engine(auto_patch=AutoPatchConfig(enabled=False))
        decision = engine.check_auto_patch("low")
        assert decision.allowed is False
        assert "disabled" in decision.reason

    def test_auto_patch_high_max_severity(self):
        engine = self._engine(auto_patch=AutoPatchConfig(max_severity="high"))
        decision = engine.check_auto_patch("high")
        assert decision.allowed is True

    def test_auto_patch_requires_human_review_above_threshold(self):
        engine = self._engine(
            auto_patch=AutoPatchConfig(max_severity="medium"),
            human_review_required=HumanReviewConfig(on_auto_patch_above="low"),
        )
        # medium > low threshold, and medium <= max_severity so allowed
        decision = engine.check_auto_patch("medium")
        assert decision.allowed is True

    def test_auto_patch_human_review_for_blocked_patch(self):
        engine = self._engine(
            auto_patch=AutoPatchConfig(max_severity="low"),
            human_review_required=HumanReviewConfig(on_auto_patch_above="low"),
        )
        # high > low max_severity, blocked; and high > low threshold, needs review
        decision = engine.check_auto_patch("high")
        assert decision.allowed is False
        assert decision.require_human_review is True

    def test_auto_patch_no_human_review_when_threshold_empty(self):
        engine = self._engine(
            auto_patch=AutoPatchConfig(max_severity="low"),
            human_review_required=HumanReviewConfig(on_auto_patch_above=""),
        )
        decision = engine.check_auto_patch("high")
        assert decision.allowed is False
        assert decision.require_human_review is False


# ===================================================================
# PolicyEngine — check_requirement_change
# ===================================================================


class TestPolicyEngineRequirementChange:
    def test_requires_review_when_enabled(self):
        gov = GovernanceConfig(
            human_review_required=HumanReviewConfig(on_requirement_change=True)
        )
        engine = PolicyEngine(gov)
        decision = engine.check_requirement_change()
        assert decision.allowed is True
        assert decision.require_human_review is True

    def test_no_review_when_disabled(self):
        gov = GovernanceConfig(
            human_review_required=HumanReviewConfig(on_requirement_change=False)
        )
        engine = PolicyEngine(gov)
        decision = engine.check_requirement_change()
        assert decision.allowed is True
        assert decision.require_human_review is False


# ===================================================================
# PolicyEngine — check_gate_failure
# ===================================================================


class TestPolicyEngineGateFailure:
    def test_critical_finding_requires_review(self):
        gov = GovernanceConfig(
            human_review_required=HumanReviewConfig(on_critical_finding=True)
        )
        engine = PolicyEngine(gov)
        decision = engine.check_gate_failure(has_critical=True)
        assert decision.allowed is False
        assert decision.require_human_review is True

    def test_no_critical_no_review(self):
        gov = GovernanceConfig(
            human_review_required=HumanReviewConfig(on_critical_finding=True)
        )
        engine = PolicyEngine(gov)
        decision = engine.check_gate_failure(has_critical=False)
        assert decision.allowed is False
        assert decision.require_human_review is False

    def test_critical_review_disabled(self):
        gov = GovernanceConfig(
            human_review_required=HumanReviewConfig(on_critical_finding=False)
        )
        engine = PolicyEngine(gov)
        decision = engine.check_gate_failure(has_critical=True)
        assert decision.allowed is False
        assert decision.require_human_review is False


# ===================================================================
# PolicyEngine — check_work_item_close
# ===================================================================


class TestPolicyEngineWorkItemClose:
    def test_requires_signoff(self):
        gov = GovernanceConfig(sync=SyncConfig(require_sign_off=True))
        engine = PolicyEngine(gov)
        decision = engine.check_work_item_close()
        assert decision.allowed is True
        assert decision.require_human_review is True

    def test_no_signoff_required(self):
        gov = GovernanceConfig(sync=SyncConfig(require_sign_off=False))
        engine = PolicyEngine(gov)
        decision = engine.check_work_item_close()
        assert decision.allowed is True
        assert decision.require_human_review is False


# ===================================================================
# PolicyEngine — check_merge_with_obligations
# ===================================================================


class TestPolicyEngineMerge:
    def test_merge_blocked_with_unresolved_obligations(self):
        gov = GovernanceConfig(gate=GateConfig(block_merge_on_obligations=True))
        engine = PolicyEngine(gov)
        decision = engine.check_merge_with_obligations(has_unresolved=True)
        assert decision.allowed is False
        assert "obligations" in decision.reason.lower()

    def test_merge_allowed_no_unresolved(self):
        gov = GovernanceConfig(gate=GateConfig(block_merge_on_obligations=True))
        engine = PolicyEngine(gov)
        decision = engine.check_merge_with_obligations(has_unresolved=False)
        assert decision.allowed is True

    def test_merge_allowed_when_blocking_disabled(self):
        gov = GovernanceConfig(gate=GateConfig(block_merge_on_obligations=False))
        engine = PolicyEngine(gov)
        decision = engine.check_merge_with_obligations(has_unresolved=True)
        assert decision.allowed is True

    def test_get_gate_fail_on(self):
        gov = GovernanceConfig(gate=GateConfig(fail_on=["critical", "high", "medium"]))
        engine = PolicyEngine(gov)
        assert engine.get_gate_fail_on() == ["critical", "high", "medium"]


# ===================================================================
# PolicyDecision
# ===================================================================


class TestPolicyDecision:
    def test_default_no_human_review(self):
        d = PolicyDecision(action="test", allowed=True, reason="ok")
        assert d.require_human_review is False

    def test_fields_set(self):
        d = PolicyDecision(
            action="auto_patch", allowed=False, reason="blocked",
            require_human_review=True,
        )
        assert d.action == "auto_patch"
        assert d.allowed is False
        assert d.reason == "blocked"
        assert d.require_human_review is True


# ===================================================================
# AuditLog
# ===================================================================


class TestAuditLog:
    def test_log_writes_entry(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        entry = audit.log("scan", actor="agent", details={"files": 10})
        assert entry is not None
        assert entry.action == "scan"
        assert entry.actor == "agent"
        assert entry.details == {"files": 10}
        assert log_file.exists()
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 1
        parsed = json.loads(lines[0])
        assert parsed["action"] == "scan"

    def test_log_disabled_returns_none(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=False, log_file=str(log_file)))
        entry = audit.log("scan")
        assert entry is None
        assert not log_file.exists()

    def test_log_multiple_entries(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        audit.log("scan")
        audit.log("gate")
        audit.log("reconcile")
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 3

    def test_log_with_policy_decision(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        decision = PolicyDecision(
            action="gate_failure", allowed=False, reason="critical findings",
            require_human_review=True,
        )
        entry = audit.log("gate", decision=decision, result="blocked")
        assert entry is not None
        assert entry.result == "blocked"
        parsed = json.loads(log_file.read_text().strip())
        assert parsed["policy_decision"]["action"] == "gate_failure"
        assert parsed["policy_decision"]["require_human_review"] is True

    def test_log_creates_parent_dirs(self, tmp_path):
        log_file = tmp_path / "deep" / "nested" / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        audit.log("test")
        assert log_file.exists()

    def test_read_empty_log(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        entries = audit.read()
        assert entries == []

    def test_read_entries(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        audit.log("scan", details={"a": 1})
        audit.log("gate", details={"b": 2})
        entries = audit.read()
        assert len(entries) == 2
        assert entries[0]["action"] == "scan"
        assert entries[1]["action"] == "gate"

    def test_read_respects_limit(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        for i in range(10):
            audit.log(f"action_{i}")
        entries = audit.read(limit=3)
        assert len(entries) == 3
        # Returns most recent 3
        assert entries[0]["action"] == "action_7"
        assert entries[2]["action"] == "action_9"

    def test_log_timestamp_format(self, tmp_path):
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        entry = audit.log("test")
        assert entry is not None
        # Should be ISO format with timezone
        assert "T" in entry.timestamp
        assert "+" in entry.timestamp or "Z" in entry.timestamp


# ===================================================================
# SEVERITY_ORDER
# ===================================================================


class TestSeverityOrder:
    def test_all_severities_present(self):
        expected = {"critical", "high", "medium", "low", "info"}
        assert set(SEVERITY_ORDER.keys()) == expected

    def test_ordering(self):
        assert SEVERITY_ORDER["critical"] > SEVERITY_ORDER["high"]
        assert SEVERITY_ORDER["high"] > SEVERITY_ORDER["medium"]
        assert SEVERITY_ORDER["medium"] > SEVERITY_ORDER["low"]
        assert SEVERITY_ORDER["low"] > SEVERITY_ORDER["info"]


# ===================================================================
# Config integration (GuardConfig.get_governance + validate_config)
# ===================================================================


class TestGovernanceConfigIntegration:
    def test_guard_config_get_governance_default(self):
        from guard.config import GuardConfig
        config = GuardConfig()
        gov = config.get_governance()
        assert isinstance(gov, GovernanceConfig)
        assert gov.profile == "standard"

    def test_guard_config_get_governance_with_profile(self):
        from guard.config import GuardConfig
        config = GuardConfig(governance={"profile": "strict"})
        gov = config.get_governance()
        assert gov.profile == "strict"
        assert gov.sync.require_sign_off is True

    def test_guard_config_validate_unknown_profile(self):
        from guard.config import GuardConfig
        config = GuardConfig(governance={"profile": "nonexistent"})
        warnings = config.validate_config()
        gov_warnings = [w for w in warnings if w.field == "governance.profile"]
        assert len(gov_warnings) == 1
        assert gov_warnings[0].level == "error"

    def test_guard_config_validate_valid_profile_no_error(self):
        from guard.config import GuardConfig
        config = GuardConfig(governance={"profile": "strict"})
        warnings = config.validate_config()
        gov_warnings = [w for w in warnings if w.field == "governance.profile"]
        assert len(gov_warnings) == 0


# ===================================================================
# Context builder governance integration
# ===================================================================


class TestContextBuilderGovernance:
    def test_governance_included_in_context(self):
        from guard.config import GuardConfig
        from guard.core.context_builder import build_agent_context
        from tests.helpers import FakeDevOps, FakeStandards
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert "profile" in ctx.governance
        assert ctx.governance["profile"] == "standard"

    def test_governance_reflects_strict_profile(self):
        from guard.config import GuardConfig
        from guard.core.context_builder import build_agent_context
        from tests.helpers import FakeDevOps, FakeStandards
        config = GuardConfig(governance={"profile": "strict"})
        ctx = build_agent_context("/repo", config, FakeDevOps(), FakeStandards())
        assert ctx.governance["profile"] == "strict"
        assert ctx.governance["gate"]["block_merge_on_obligations"] is True
        assert ctx.governance["sync"]["require_sign_off"] is True
