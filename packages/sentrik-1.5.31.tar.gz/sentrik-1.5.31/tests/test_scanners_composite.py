"""Comprehensive tests for ScannersComposite (Phase 7)."""

from __future__ import annotations

import pytest

from tests.helpers import FakeScanner, make_finding
from guard.core.models import Finding, Severity
from guard.providers.scanners_base import ScannersProvider
from guard.providers.scanners_composite import ScannersComposite
from guard.providers.scanners_stub import ScannersStub


class ErrorScanner(ScannersProvider):
    """Scanner that always raises."""

    def scan(self, repo_root: str, changed_files: list[str] | None = None) -> list[Finding]:
        raise ValueError("Scanner crashed")


def _finding(fid: str, rule: str = "test", sev: Severity = Severity.LOW) -> Finding:
    return make_finding(fid=fid, rule=rule, sev=sev, msg=f"Finding {fid}")


# ===================================================================
# Basic aggregation
# ===================================================================


class TestBasicAggregation:
    def test_empty_scanners_list(self):
        composite = ScannersComposite([])
        assert composite.scan("/tmp") == []

    def test_single_scanner(self):
        f1 = _finding("F1")
        composite = ScannersComposite([FakeScanner([f1])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1
        assert findings[0].finding_id == "F1"

    def test_multiple_scanners_aggregated(self):
        f1 = _finding("F1")
        f2 = _finding("F2")
        composite = ScannersComposite([FakeScanner([f1]), FakeScanner([f2])])
        findings = composite.scan("/tmp")
        assert len(findings) == 2
        ids = {f.finding_id for f in findings}
        assert ids == {"F1", "F2"}

    def test_three_scanners(self):
        scanners = [FakeScanner([_finding(f"F{i}")]) for i in range(3)]
        composite = ScannersComposite(scanners)
        findings = composite.scan("/tmp")
        assert len(findings) == 3

    def test_scanner_with_multiple_findings(self):
        findings_list = [_finding("F1"), _finding("F2"), _finding("F3")]
        composite = ScannersComposite([FakeScanner(findings_list)])
        findings = composite.scan("/tmp")
        assert len(findings) == 3

    def test_empty_scanner_contributes_nothing(self):
        f1 = _finding("F1")
        composite = ScannersComposite([FakeScanner([f1]), FakeScanner([])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1

    def test_all_empty_scanners(self):
        composite = ScannersComposite([FakeScanner([]), FakeScanner([])])
        assert composite.scan("/tmp") == []


# ===================================================================
# Deduplication
# ===================================================================


class TestDeduplication:
    def test_duplicate_finding_ids_deduplicated(self):
        f1a = _finding("F1", rule="rule-a")
        f1b = _finding("F1", rule="rule-b")
        composite = ScannersComposite([FakeScanner([f1a]), FakeScanner([f1b])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1
        assert findings[0].rule_id == "rule-a"  # first one wins

    def test_different_ids_not_deduplicated(self):
        f1 = _finding("F1")
        f2 = _finding("F2")
        composite = ScannersComposite([FakeScanner([f1]), FakeScanner([f2])])
        findings = composite.scan("/tmp")
        assert len(findings) == 2

    def test_dedup_within_same_scanner(self):
        f1a = _finding("F1", rule="first")
        f1b = _finding("F1", rule="second")
        composite = ScannersComposite([FakeScanner([f1a, f1b])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1
        assert findings[0].rule_id == "first"

    def test_dedup_across_three_scanners(self):
        dup = _finding("DUP")
        unique = _finding("UNIQUE")
        composite = ScannersComposite([
            FakeScanner([dup]),
            FakeScanner([dup, unique]),
            FakeScanner([dup]),
        ])
        findings = composite.scan("/tmp")
        assert len(findings) == 2


# ===================================================================
# Error handling
# ===================================================================


class TestErrorHandling:
    def test_failing_scanner_skipped(self):
        f1 = _finding("F1")
        composite = ScannersComposite([ErrorScanner(), FakeScanner([f1])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1
        assert findings[0].finding_id == "F1"

    def test_all_scanners_fail(self):
        composite = ScannersComposite([ErrorScanner(), ErrorScanner()])
        assert composite.scan("/tmp") == []

    def test_failing_scanner_between_good_ones(self):
        f1 = _finding("F1")
        f2 = _finding("F2")
        composite = ScannersComposite([
            FakeScanner([f1]),
            ErrorScanner(),
            FakeScanner([f2]),
        ])
        findings = composite.scan("/tmp")
        assert len(findings) == 2


# ===================================================================
# Changed files passthrough
# ===================================================================


class TestChangedFiles:
    def test_changed_files_passed_to_sub_scanners(self):
        class RecordingScanner(ScannersProvider):
            def __init__(self):
                self.last_changed_files = None

            def scan(self, repo_root, changed_files=None):
                self.last_changed_files = changed_files
                return []

        s1 = RecordingScanner()
        s2 = RecordingScanner()
        composite = ScannersComposite([s1, s2])
        composite.scan("/tmp", changed_files=["a.py", "b.py"])

        assert s1.last_changed_files == ["a.py", "b.py"]
        assert s2.last_changed_files == ["a.py", "b.py"]

    def test_none_changed_files_passed_through(self):
        class RecordingScanner(ScannersProvider):
            def __init__(self):
                self.last_changed_files = "NOT_SET"

            def scan(self, repo_root, changed_files=None):
                self.last_changed_files = changed_files
                return []

        s = RecordingScanner()
        composite = ScannersComposite([s])
        composite.scan("/tmp")
        assert s.last_changed_files is None


# ===================================================================
# Properties
# ===================================================================


class TestProperties:
    def test_scanners_property(self):
        s1 = FakeScanner([])
        s2 = FakeScanner([])
        composite = ScannersComposite([s1, s2])
        assert len(composite.scanners) == 2

    def test_scanners_property_is_copy(self):
        s1 = FakeScanner([])
        composite = ScannersComposite([s1])
        scanners = composite.scanners
        scanners.append(FakeScanner([]))
        assert len(composite.scanners) == 1  # original unchanged


# ===================================================================
# Integration with ScannersStub
# ===================================================================


class TestWithStub:
    def test_composite_with_stub_returns_empty(self):
        composite = ScannersComposite([ScannersStub()])
        assert composite.scan("/tmp") == []

    def test_composite_with_stub_and_real_scanner(self):
        f1 = _finding("F1")
        composite = ScannersComposite([ScannersStub(), FakeScanner([f1])])
        findings = composite.scan("/tmp")
        assert len(findings) == 1
