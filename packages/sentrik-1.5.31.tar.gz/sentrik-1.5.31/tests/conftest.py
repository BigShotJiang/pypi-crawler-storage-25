"""Shared pytest fixtures for AI SDLC Guard tests."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from guard.config import GuardConfig
from tests.helpers import make_finding, write_file


def _home_env(**extra: str) -> dict:
    """Return a dict preserving HOME-related env vars.

    On Windows, ``Path.home()`` needs HOME or USERPROFILE (or
    HOMEDRIVE+HOMEPATH).  When tests use ``patch.dict(os.environ, …,
    clear=True)`` those vars are wiped and ``Path.home()`` raises
    ``RuntimeError``.  Merging this dict into the patched environment
    prevents the failure.

    Any *extra* keyword arguments are added to the returned dict so
    callers can do ``_home_env(GITHUB_TOKEN="ghp_test")`` in one shot.
    """
    keep: dict[str, str] = {}
    for key in ("HOME", "USERPROFILE", "HOMEDRIVE", "HOMEPATH",
                "APPDATA", "LOCALAPPDATA", "SYSTEMROOT"):
        val = os.environ.get(key)
        if val is not None:
            keep[key] = val
    keep.update(extra)
    return keep


@pytest.fixture(autouse=True)
def _disable_rate_limiting():
    """Disable API rate limiting for all tests to prevent 429 errors."""
    try:
        import guard.server as srv
        srv._RATE_LIMIT_ENABLED = False
        yield
        srv._RATE_LIMIT_ENABLED = True
    except Exception:
        yield


@pytest.fixture()
def finding_factory():
    """Fixture wrapping :func:`make_finding`."""
    return make_finding


@pytest.fixture()
def file_writer(tmp_path: Path):
    """Fixture binding :func:`write_file` to the current ``tmp_path``."""

    def _writer(rel: str, content: str) -> Path:
        return write_file(tmp_path, rel, content)

    return _writer


@pytest.fixture()
def guard_config(tmp_path: Path) -> GuardConfig:
    """A :class:`GuardConfig` pointing ``output_dir`` at a temp directory."""
    return GuardConfig(output_dir=str(tmp_path / "out"))
