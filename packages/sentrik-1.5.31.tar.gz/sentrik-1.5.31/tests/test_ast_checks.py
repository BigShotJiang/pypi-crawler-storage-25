"""Tests for AST check functions (Phase 17)."""

from __future__ import annotations

import ast

import pytest

from guard.rules.ast_checks import (
    AST_CHECKS,
    ASTIssue,
    high_complexity,
    max_function_length,
    no_global_variables,
    no_mutable_defaults,
    no_nested_functions,
    no_star_imports,
    _mccabe_complexity,
)


def _parse(code: str):
    """Parse code and return (tree, source_lines)."""
    tree = ast.parse(code)
    return tree, code.splitlines()


# ===================================================================
# no_mutable_defaults
# ===================================================================


class TestNoMutableDefaults:
    def test_list_default(self):
        tree, lines = _parse("def f(x=[]):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1
        assert "Mutable default" in issues[0].message
        assert "'f'" in issues[0].message

    def test_dict_default(self):
        tree, lines = _parse("def f(x={}):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_set_default(self):
        tree, lines = _parse("def f(x={1, 2}):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_list_call_default(self):
        tree, lines = _parse("def f(x=list()):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_dict_call_default(self):
        tree, lines = _parse("def f(x=dict()):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_set_call_default(self):
        tree, lines = _parse("def f(x=set()):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_none_default_ok(self):
        tree, lines = _parse("def f(x=None):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert issues == []

    def test_string_default_ok(self):
        tree, lines = _parse("def f(x='hello'):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert issues == []

    def test_tuple_default_ok(self):
        tree, lines = _parse("def f(x=(1, 2)):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert issues == []

    def test_multiple_mutable_defaults(self):
        tree, lines = _parse("def f(x=[], y={}):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 2

    def test_async_function(self):
        tree, lines = _parse("async def f(x=[]):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_kwonly_default(self):
        tree, lines = _parse("def f(*, x=[]):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert len(issues) == 1

    def test_clean_code(self):
        tree, lines = _parse("def f(x, y=None, z=0):\n    pass\n")
        issues = no_mutable_defaults(tree, lines)
        assert issues == []


# ===================================================================
# no_global_variables
# ===================================================================


class TestNoGlobalVariables:
    def test_module_level_assignment(self):
        tree, lines = _parse("counter = 0\n")
        issues = no_global_variables(tree, lines)
        assert len(issues) == 1
        assert "counter" in issues[0].message

    def test_constant_ok(self):
        tree, lines = _parse("MAX_SIZE = 100\n")
        issues = no_global_variables(tree, lines)
        assert issues == []

    def test_dunder_ok(self):
        tree, lines = _parse("__version__ = '1.0'\n")
        issues = no_global_variables(tree, lines)
        assert issues == []

    def test_type_alias_ok(self):
        tree, lines = _parse("MyType = str\n")
        issues = no_global_variables(tree, lines)
        assert issues == []

    def test_function_not_flagged(self):
        tree, lines = _parse("def f():\n    x = 1\n")
        issues = no_global_variables(tree, lines)
        assert issues == []

    def test_annotated_ok(self):
        tree, lines = _parse("x: int = 0\n")
        issues = no_global_variables(tree, lines)
        assert issues == []


# ===================================================================
# no_nested_functions
# ===================================================================


class TestNoNestedFunctions:
    def test_deeply_nested(self):
        code = "def a():\n    def b():\n        def c():\n            pass\n"
        tree, lines = _parse(code)
        issues = no_nested_functions(tree, lines)
        # c is at depth 2, which is > 1
        assert len(issues) == 1
        assert "'c'" in issues[0].message

    def test_single_nested_ok(self):
        code = "def a():\n    def b():\n        pass\n"
        tree, lines = _parse(code)
        issues = no_nested_functions(tree, lines)
        # b is at depth 1, not > 1
        assert issues == []

    def test_no_nesting_ok(self):
        code = "def a():\n    pass\ndef b():\n    pass\n"
        tree, lines = _parse(code)
        issues = no_nested_functions(tree, lines)
        assert issues == []

    def test_async_nested(self):
        code = "async def a():\n    async def b():\n        async def c():\n            pass\n"
        tree, lines = _parse(code)
        issues = no_nested_functions(tree, lines)
        assert len(issues) == 1


# ===================================================================
# no_star_imports
# ===================================================================


class TestNoStarImports:
    def test_star_import(self):
        tree, lines = _parse("from os import *\n")
        issues = no_star_imports(tree, lines)
        assert len(issues) == 1
        assert "'os'" in issues[0].message

    def test_normal_import_ok(self):
        tree, lines = _parse("from os import path\n")
        issues = no_star_imports(tree, lines)
        assert issues == []

    def test_import_module_ok(self):
        tree, lines = _parse("import os\n")
        issues = no_star_imports(tree, lines)
        assert issues == []

    def test_multiple_star_imports(self):
        tree, lines = _parse("from os import *\nfrom sys import *\n")
        issues = no_star_imports(tree, lines)
        assert len(issues) == 2


# ===================================================================
# high_complexity
# ===================================================================


class TestHighComplexity:
    def test_simple_function_ok(self):
        code = "def f(x):\n    return x + 1\n"
        tree, lines = _parse(code)
        issues = high_complexity(tree, lines)
        assert issues == []

    def test_complex_function(self):
        # Build a function with many branches to exceed complexity 10
        branches = "\n".join(f"    if x == {i}:\n        pass" for i in range(12))
        code = f"def f(x):\n{branches}\n"
        tree, lines = _parse(code)
        issues = high_complexity(tree, lines)
        assert len(issues) == 1
        assert "'f'" in issues[0].message
        assert "complexity" in issues[0].message.lower()

    def test_moderate_complexity_ok(self):
        code = "def f(x):\n    if x > 0:\n        return x\n    else:\n        return -x\n"
        tree, lines = _parse(code)
        issues = high_complexity(tree, lines)
        assert issues == []


# ===================================================================
# McCabe complexity helper
# ===================================================================


class TestMcCabeComplexity:
    def test_empty_function(self):
        tree = ast.parse("def f():\n    pass\n")
        func = tree.body[0]
        assert _mccabe_complexity(func) == 1

    def test_single_if(self):
        tree = ast.parse("def f(x):\n    if x:\n        pass\n")
        func = tree.body[0]
        assert _mccabe_complexity(func) == 2

    def test_if_and_for(self):
        tree = ast.parse("def f(x):\n    if x:\n        pass\n    for i in x:\n        pass\n")
        func = tree.body[0]
        assert _mccabe_complexity(func) == 3

    def test_boolean_ops(self):
        tree = ast.parse("def f(x, y):\n    if x and y:\n        pass\n")
        func = tree.body[0]
        # 1 base + 1 if + 1 and
        assert _mccabe_complexity(func) == 3

    def test_try_except(self):
        tree = ast.parse("def f():\n    try:\n        pass\n    except:\n        pass\n")
        func = tree.body[0]
        assert _mccabe_complexity(func) == 2  # 1 base + 1 except


# ===================================================================
# AST_CHECKS registry
# ===================================================================


class TestMaxFunctionLength:
    def test_short_function_ok(self):
        code = "def f():\n    return 1\n"
        tree, lines = _parse(code)
        issues = max_function_length(tree, lines)
        assert issues == []

    def test_long_function_flagged(self):
        body = "\n".join(f"    x = {i}" for i in range(55))
        code = f"def f():\n{body}\n"
        tree, lines = _parse(code)
        issues = max_function_length(tree, lines)
        assert len(issues) == 1
        assert "'f'" in issues[0].message
        assert "lines" in issues[0].message.lower()

    def test_custom_threshold(self):
        body = "\n".join(f"    x = {i}" for i in range(8))
        code = f"def f():\n{body}\n"
        tree, lines = _parse(code)
        # Default 50 → OK
        assert max_function_length(tree, lines) == []
        # Custom threshold 5 → flagged
        issues = max_function_length(tree, lines, {"max_lines": 5})
        assert len(issues) == 1

    def test_exactly_at_threshold(self):
        # 50-line function (def + 49 body lines)
        body = "\n".join(f"    x = {i}" for i in range(49))
        code = f"def f():\n{body}\n"
        tree, lines = _parse(code)
        issues = max_function_length(tree, lines)
        assert issues == []

    def test_async_function(self):
        body = "\n".join(f"    x = {i}" for i in range(55))
        code = f"async def f():\n{body}\n"
        tree, lines = _parse(code)
        issues = max_function_length(tree, lines)
        assert len(issues) == 1

    def test_multiple_functions(self):
        body = "\n".join(f"    x = {i}" for i in range(55))
        code = f"def f():\n{body}\ndef g():\n    pass\n"
        tree, lines = _parse(code)
        issues = max_function_length(tree, lines)
        assert len(issues) == 1
        assert "'f'" in issues[0].message


class TestASTChecksRegistry:
    def test_all_checks_registered(self):
        assert "no_mutable_defaults" in AST_CHECKS
        assert "no_global_variables" in AST_CHECKS
        assert "no_nested_functions" in AST_CHECKS
        assert "no_star_imports" in AST_CHECKS
        assert "high_complexity" in AST_CHECKS
        assert "max_function_length" in AST_CHECKS

    def test_all_checks_callable(self):
        for name, fn in AST_CHECKS.items():
            assert callable(fn), f"{name} is not callable"
