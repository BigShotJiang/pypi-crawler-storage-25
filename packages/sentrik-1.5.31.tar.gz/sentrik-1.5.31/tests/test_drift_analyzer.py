"""Tests for context-aware requirement drift analysis."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
import yaml

from guard.core.drift_analyzer import DriftAnalyzer
from guard.core.models import GeneratedRequirement


# ---------------------------------------------------------------------------
# Mock LLM
# ---------------------------------------------------------------------------


class MockLLM:
    """Mock LLM that returns pre-configured responses."""

    def __init__(self, responses: list[dict] | None = None):
        self._responses = responses or []
        self._call_count = 0
        self.prompts: list[str] = []

    def analyze(self, prompt: str, context: dict[str, Any]) -> dict[str, Any]:
        self.prompts.append(prompt)
        if self._call_count < len(self._responses):
            resp = self._responses[self._call_count]
        else:
            resp = {"satisfies": True, "drifts": [], "issues": [], "criteria_results": []}
        self._call_count += 1
        return resp


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _write_requirements(tmp_path, reqs):
    data = {"requirements": [r if isinstance(r, dict) else r.model_dump() for r in reqs]}
    path = tmp_path / "requirements.yaml"
    path.write_text(yaml.dump(data), encoding="utf-8")
    return path


def _make_req(req_id="REQ-001", title="Test Requirement", source_files=None, **kw):
    return GeneratedRequirement(
        req_id=req_id,
        title=title,
        description=kw.get("description", "The system should do X"),
        acceptance_criteria=kw.get("acceptance_criteria", ["It does X", "It handles errors"]),
        source_files=source_files or ["src/app.py"],
        status=kw.get("status", "approved"),
    )


# ---------------------------------------------------------------------------
# Cross-file tracking (no LLM needed)
# ---------------------------------------------------------------------------


class TestCrossFileTracking:
    def test_missing_file_detected(self, tmp_path):
        req = _make_req(source_files=["src/gone.py"])
        _write_requirements(tmp_path, [req])
        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")

        findings = analyzer.analyze()

        assert len(findings) == 1
        assert "missing" in findings[0].message.lower()
        assert "cross-file" in findings[0].tags

    def test_moved_file_detected(self, tmp_path):
        (tmp_path / "src" / "new_location").mkdir(parents=True)
        (tmp_path / "src" / "new_location" / "app.py").write_text("# code", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])  # old location
        _write_requirements(tmp_path, [req])
        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")

        findings = analyzer.analyze()

        assert len(findings) == 1
        assert "moved" in findings[0].suggestion.lower() or "appears" in findings[0].suggestion.lower()

    def test_existing_file_no_finding(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("print('ok')", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])
        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")

        findings = analyzer.analyze()

        assert len(findings) == 0


# ---------------------------------------------------------------------------
# Behavioral drift (LLM)
# ---------------------------------------------------------------------------


class TestBehavioralDrift:
    def test_drift_detected(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("def broken(): pass", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        llm = MockLLM([{
            "satisfies": False,
            "confidence": 0.8,
            "drifts": [{
                "type": "behavioral",
                "description": "Function does not implement required behavior",
                "severity": "high",
                "file": "src/app.py",
                "line_hint": 1,
                "suggestion": "Implement the actual logic",
            }],
        }])

        analyzer = DriftAnalyzer(str(tmp_path), llm=llm, requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        assert len(findings) >= 1
        behavioral = [f for f in findings if "behavioral" in f.tags]
        assert len(behavioral) == 1
        assert behavioral[0].severity.value == "high"

    def test_no_drift_when_satisfied(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("def working(): return True", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        llm = MockLLM([{"satisfies": True, "drifts": []}])
        analyzer = DriftAnalyzer(str(tmp_path), llm=llm, requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        behavioral = [f for f in findings if "behavioral" in f.tags]
        assert len(behavioral) == 0


# ---------------------------------------------------------------------------
# Structural drift
# ---------------------------------------------------------------------------


class TestStructuralDrift:
    def test_llm_structural_issue(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("verify = False", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        llm = MockLLM([
            {"satisfies": True, "drifts": []},  # behavioral pass
            {"issues": [{
                "type": "structural",
                "description": "TLS verification disabled",
                "severity": "critical",
                "file": "src/app.py",
                "suggestion": "Enable TLS verification",
            }]},
        ])

        analyzer = DriftAnalyzer(str(tmp_path), llm=llm, requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        structural = [f for f in findings if "structural" in f.tags]
        assert len(structural) == 1
        assert structural[0].severity.value == "critical"

    def test_heuristic_detects_tls_bypass(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("requests.get(url, verify=False)", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        # No LLM — should use heuristic
        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        structural = [f for f in findings if "structural" in f.tags]
        assert len(structural) >= 1
        assert "verification" in structural[0].message.lower() or "verify" in structural[0].evidence.snippet.lower()

    def test_heuristic_detects_weak_crypto(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("algorithm = 'md5'", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        structural = [f for f in findings if "structural" in f.tags]
        assert len(structural) >= 1


# ---------------------------------------------------------------------------
# Acceptance criteria validation (LLM)
# ---------------------------------------------------------------------------


class TestAcceptanceCriteria:
    def test_failed_criterion_creates_finding(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("def handler(): pass", encoding="utf-8")
        req = _make_req(
            source_files=["src/app.py"],
            acceptance_criteria=["It validates input", "It returns JSON"],
        )
        _write_requirements(tmp_path, [req])

        llm = MockLLM([
            {"satisfies": True, "drifts": []},   # behavioral
            {"issues": []},                       # structural
            {"criteria_results": [               # acceptance criteria
                {"criterion": "It validates input", "satisfied": False, "confidence": 0.8,
                 "evidence": "No validation found", "file": "src/app.py", "line_hint": 1},
                {"criterion": "It returns JSON", "satisfied": True, "confidence": 0.9,
                 "evidence": "Returns JSON", "file": "src/app.py", "line_hint": 1},
            ]},
        ])

        analyzer = DriftAnalyzer(str(tmp_path), llm=llm, requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        ac_findings = [f for f in findings if "acceptance-criteria" in f.tags]
        assert len(ac_findings) == 1
        assert "validates input" in ac_findings[0].message

    def test_all_criteria_satisfied_no_findings(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("def handler(): pass", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"], acceptance_criteria=["Works"])
        _write_requirements(tmp_path, [req])

        llm = MockLLM([
            {"satisfies": True, "drifts": []},
            {"issues": []},
            {"criteria_results": [{"criterion": "Works", "satisfied": True, "confidence": 1.0,
             "evidence": "It works", "file": "src/app.py"}]},
        ])

        analyzer = DriftAnalyzer(str(tmp_path), llm=llm, requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()

        ac_findings = [f for f in findings if "acceptance-criteria" in f.tags]
        assert len(ac_findings) == 0


# ---------------------------------------------------------------------------
# Integration
# ---------------------------------------------------------------------------


class TestDriftAnalyzerIntegration:
    def test_no_requirements_returns_empty(self, tmp_path):
        analyzer = DriftAnalyzer(str(tmp_path))
        assert analyzer.analyze() == []
        assert not analyzer.has_requirements

    def test_rejected_requirements_skipped(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("code", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"], status="rejected")
        _write_requirements(tmp_path, [req])

        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")
        findings = analyzer.analyze()
        assert len(findings) == 0

    def test_changed_files_filter(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("code", encoding="utf-8")
        (tmp_path / "src" / "other.py").write_text("code", encoding="utf-8")
        req1 = _make_req(req_id="REQ-001", source_files=["src/app.py"])
        req2 = _make_req(req_id="REQ-002", source_files=["src/other.py"])
        _write_requirements(tmp_path, [req1, req2])

        analyzer = DriftAnalyzer(str(tmp_path), requirements_path=tmp_path / "requirements.yaml")
        # Only scan app.py changes — REQ-002 should be skipped
        findings = analyzer.analyze(changed_files=["src/app.py"])
        # No drift findings expected (files exist, no LLM)
        assert all("REQ-002" not in f.rule_id for f in findings)

    def test_has_llm_property(self, tmp_path):
        assert DriftAnalyzer(str(tmp_path)).has_llm is False
        assert DriftAnalyzer(str(tmp_path), llm=MockLLM()).has_llm is True

    def test_llm_error_handled_gracefully(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("code", encoding="utf-8")
        req = _make_req(source_files=["src/app.py"])
        _write_requirements(tmp_path, [req])

        class BrokenLLM:
            def analyze(self, prompt, context):
                raise RuntimeError("API error")

        analyzer = DriftAnalyzer(str(tmp_path), llm=BrokenLLM(), requirements_path=tmp_path / "requirements.yaml")
        # Should not crash, just return whatever it can
        findings = analyzer.analyze()
        # Cross-file check still runs (no LLM needed)
        assert isinstance(findings, list)
