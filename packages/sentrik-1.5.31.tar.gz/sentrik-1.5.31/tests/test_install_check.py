"""Tests for the install-check CLI command."""

from __future__ import annotations

from datetime import date, timedelta

from typer.testing import CliRunner

from guard.cli import app
from guard.core.licensing import generate_key

runner = CliRunner()


class TestInstallCheck:
    def test_basic_output(self):
        """install-check should show version and platform info."""
        result = runner.invoke(app, ["install-check"])
        assert result.exit_code == 0
        assert "Installation Check" in result.output
        assert "Version:" in result.output
        assert "Python:" in result.output
        assert "Platform:" in result.output

    def test_shows_license_tier(self):
        """install-check should display the license tier."""
        result = runner.invoke(app, ["install-check"])
        assert result.exit_code == 0
        assert "Tier:" in result.output

    def test_shows_quick_start(self):
        """install-check should show the quick start guide."""
        result = runner.invoke(app, ["install-check"])
        assert result.exit_code == 0
        assert "Quick Start" in result.output
        assert "sentrik init" in result.output

    def test_shows_optional_deps(self):
        """install-check should check optional dependencies."""
        result = runner.invoke(app, ["install-check"])
        assert result.exit_code == 0
        assert "Optional Dependencies" in result.output
