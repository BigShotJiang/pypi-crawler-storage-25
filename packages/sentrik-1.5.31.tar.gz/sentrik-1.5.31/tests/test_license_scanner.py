"""Tests for the dependency license scanner."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from guard.core.license_scanner import (
    LicenseInfo,
    LicenseScanResult,
    _classify_license,
    _license_cache,
    result_to_dict,
    scan_licenses,
)
from guard.core.sbom import Component


class TestClassifyLicense:
    """Tests for _classify_license."""

    def test_classify_mit(self):
        """MIT should be permissive, no risk, not copyleft."""
        name, risk, copyleft = _classify_license("MIT")
        assert name == "MIT"
        assert risk == "none"
        assert copyleft is False

    def test_classify_gpl3(self):
        """GPL-3.0 should be high risk, copyleft."""
        name, risk, copyleft = _classify_license("GPL-3.0")
        assert name == "GPL-3.0"
        assert risk == "high"
        assert copyleft is True

    def test_classify_apache(self):
        """Apache-2.0 should be permissive, no risk."""
        name, risk, copyleft = _classify_license("Apache-2.0")
        assert name == "Apache-2.0"
        assert risk == "none"
        assert copyleft is False

    def test_classify_lgpl(self):
        """LGPL-2.1 should be medium risk, copyleft."""
        name, risk, copyleft = _classify_license("LGPL-2.1")
        assert name == "LGPL-2.1"
        assert risk == "medium"
        assert copyleft is True

    def test_classify_lgpl3(self):
        """LGPL-3.0 should be medium risk, copyleft."""
        name, risk, copyleft = _classify_license("LGPL-3.0")
        assert name == "LGPL-3.0"
        assert risk == "medium"
        assert copyleft is True

    def test_classify_mpl(self):
        """MPL-2.0 should be medium risk, copyleft."""
        name, risk, copyleft = _classify_license("MPL-2.0")
        assert name == "MPL-2.0"
        assert risk == "medium"
        assert copyleft is True

    def test_classify_unknown(self):
        """Custom/unknown license should be low risk, not copyleft."""
        name, risk, copyleft = _classify_license("Custom License v1.0")
        assert name == "Custom License v1.0"
        assert risk == "low"
        assert copyleft is False

    def test_classify_empty(self):
        """Empty string should return unknown, low risk."""
        name, risk, copyleft = _classify_license("")
        assert name == "unknown"
        assert risk == "low"
        assert copyleft is False

    def test_classify_agpl(self):
        """AGPL-3.0 should be high risk, copyleft."""
        name, risk, copyleft = _classify_license("AGPL-3.0")
        assert name == "AGPL-3.0"
        assert risk == "high"
        assert copyleft is True

    def test_classify_bsd3(self):
        """BSD-3-Clause should be permissive, no risk."""
        name, risk, copyleft = _classify_license("BSD-3-Clause")
        assert name == "BSD-3-Clause"
        assert risk == "none"
        assert copyleft is False

    def test_classify_alias(self):
        """Common non-SPDX strings should normalize."""
        name, risk, copyleft = _classify_license("MIT License")
        assert name == "MIT"
        assert risk == "none"
        assert copyleft is False


class TestScanLicenses:
    """Tests for scan_licenses."""

    def setup_method(self):
        """Clear cache before each test."""
        _license_cache.clear()

    def test_scan_empty(self):
        """Empty component list should return zero counts."""
        result = scan_licenses([])
        assert result.total_packages == 0
        assert result.scanned == 0
        assert result.copyleft_count == 0
        assert result.licenses == []

    @patch("guard.core.license_scanner.requests.get")
    def test_scan_pypi(self, mock_get):
        """Mock PyPI API, verify license extracted."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "info": {
                "license": "MIT",
                "classifiers": [],
            }
        }
        mock_get.return_value = mock_resp

        components = [Component(name="requests", version="2.31.0", ecosystem="pypi")]
        result = scan_licenses(components)

        assert result.total_packages == 1
        assert result.scanned == 1
        assert len(result.licenses) == 1
        assert result.licenses[0].license == "MIT"
        assert result.licenses[0].risk == "none"
        assert result.licenses[0].copyleft is False
        mock_get.assert_called_once_with(
            "https://pypi.org/pypi/requests/2.31.0/json", timeout=10
        )

    @patch("guard.core.license_scanner.requests.get")
    def test_scan_pypi_classifier_fallback(self, mock_get):
        """When license field is empty, fall back to classifiers."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "info": {
                "license": "",
                "classifiers": [
                    "License :: OSI Approved :: Apache Software License",
                    "Programming Language :: Python :: 3",
                ],
            }
        }
        mock_get.return_value = mock_resp

        components = [Component(name="flask", version="3.0.0", ecosystem="pypi")]
        result = scan_licenses(components)

        assert result.licenses[0].license == "Apache-2.0"

    @patch("guard.core.license_scanner.requests.get")
    def test_scan_npm(self, mock_get):
        """Mock npm API, verify license extracted."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"license": "ISC"}
        mock_get.return_value = mock_resp

        components = [Component(name="express", version="4.18.2", ecosystem="npm")]
        result = scan_licenses(components)

        assert result.total_packages == 1
        assert result.licenses[0].license == "ISC"
        assert result.licenses[0].risk == "none"
        mock_get.assert_called_once_with(
            "https://registry.npmjs.org/express/4.18.2", timeout=10
        )

    @patch("guard.core.license_scanner.requests.get")
    def test_scan_npm_license_object(self, mock_get):
        """npm license can be an object with 'type' key."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "license": {"type": "MIT", "url": "https://opensource.org/licenses/MIT"}
        }
        mock_get.return_value = mock_resp

        components = [Component(name="lodash", version="4.17.21", ecosystem="npm")]
        result = scan_licenses(components)

        assert result.licenses[0].license == "MIT"

    @patch("guard.core.license_scanner.requests.get")
    def test_scan_network_error(self, mock_get):
        """Network error should return unknown license, not crash."""
        mock_get.side_effect = Exception("Connection timeout")

        components = [Component(name="broken-pkg", version="1.0.0", ecosystem="pypi")]
        result = scan_licenses(components)

        assert result.total_packages == 1
        assert result.licenses[0].license == "unknown"
        assert result.licenses[0].risk == "low"

    def test_scan_unknown_ecosystem(self):
        """Non-pypi/npm ecosystems should return unknown license."""
        components = [Component(name="serde", version="1.0.0", ecosystem="cargo")]
        result = scan_licenses(components)

        assert result.licenses[0].license == "unknown"
        assert result.licenses[0].risk == "low"

    @patch("guard.core.license_scanner.requests.get")
    def test_result_counts(self, mock_get):
        """by_risk and copyleft_count should be accurate."""
        responses = [
            # MIT — permissive
            MagicMock(
                status_code=200,
                raise_for_status=MagicMock(),
                json=MagicMock(return_value={"info": {"license": "MIT", "classifiers": []}}),
            ),
            # GPL-3.0 — copyleft
            MagicMock(
                status_code=200,
                raise_for_status=MagicMock(),
                json=MagicMock(return_value={"info": {"license": "GPL-3.0", "classifiers": []}}),
            ),
            # LGPL-2.1 — weak copyleft
            MagicMock(
                status_code=200,
                raise_for_status=MagicMock(),
                json=MagicMock(return_value={"info": {"license": "LGPL-2.1", "classifiers": []}}),
            ),
        ]
        mock_get.side_effect = responses

        components = [
            Component(name="pkg-a", version="1.0", ecosystem="pypi"),
            Component(name="pkg-b", version="2.0", ecosystem="pypi"),
            Component(name="pkg-c", version="3.0", ecosystem="pypi"),
        ]
        result = scan_licenses(components)

        assert result.total_packages == 3
        assert result.by_risk["none"] == 1
        assert result.by_risk["high"] == 1
        assert result.by_risk["medium"] == 1
        assert result.copyleft_count == 2

    @patch("guard.core.license_scanner.requests.get")
    def test_copyleft_filter(self, mock_get):
        """Filtering copyleft-only from results should work."""
        responses = [
            MagicMock(
                status_code=200,
                raise_for_status=MagicMock(),
                json=MagicMock(return_value={"info": {"license": "MIT", "classifiers": []}}),
            ),
            MagicMock(
                status_code=200,
                raise_for_status=MagicMock(),
                json=MagicMock(return_value={"info": {"license": "GPL-3.0", "classifiers": []}}),
            ),
        ]
        mock_get.side_effect = responses

        components = [
            Component(name="safe-pkg", version="1.0", ecosystem="pypi"),
            Component(name="gpl-pkg", version="2.0", ecosystem="pypi"),
        ]
        result = scan_licenses(components)

        copyleft_only = [li for li in result.licenses if li.copyleft]
        assert len(copyleft_only) == 1
        assert copyleft_only[0].package == "gpl-pkg"
        assert copyleft_only[0].license == "GPL-3.0"

    @patch("guard.core.license_scanner.requests.get")
    def test_result_to_dict(self, mock_get):
        """result_to_dict should produce a JSON-serializable dictionary."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"info": {"license": "Apache-2.0", "classifiers": []}}
        mock_get.return_value = mock_resp

        components = [Component(name="httpx", version="0.25.0", ecosystem="pypi")]
        result = scan_licenses(components)
        d = result_to_dict(result)

        assert isinstance(d, dict)
        assert d["total_packages"] == 1
        assert d["scanned"] == 1
        assert d["copyleft_count"] == 0
        assert len(d["licenses"]) == 1
        assert d["licenses"][0]["package"] == "httpx"
        assert d["licenses"][0]["license"] == "Apache-2.0"
        assert d["licenses"][0]["risk"] == "none"
        assert d["licenses"][0]["copyleft"] is False

        # Verify it's truly JSON-serializable
        import json
        json.dumps(d)

    @patch("guard.core.license_scanner.requests.get")
    def test_cache_prevents_duplicate_requests(self, mock_get):
        """Cache should prevent duplicate network requests."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"info": {"license": "MIT", "classifiers": []}}
        mock_get.return_value = mock_resp

        components = [
            Component(name="cached-pkg", version="1.0", ecosystem="pypi"),
            Component(name="cached-pkg", version="1.0", ecosystem="pypi"),
        ]
        scan_licenses(components)

        # Should only call the API once due to cache
        assert mock_get.call_count == 1
