"""Tests for C/C++ semantic analysis module."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from guard.core.cpp_analyzer import (
    CppAnalyzerResult,
    _map_check_to_standard,
    _map_clang_tidy_severity,
    _map_cppcheck_severity,
    _parse_clang_tidy_output,
    _parse_cppcheck_output,
    collect_cpp_files,
    is_clang_tidy_available,
    is_cppcheck_available,
    run_clang_tidy,
    run_cppcheck,
    run_cpp_analysis,
)
from guard.core.models import Severity


class TestAvailability:
    """Tests for tool availability checks."""

    @patch("guard.core.cpp_analyzer.shutil.which", return_value=None)
    def test_clang_tidy_not_available(self, mock_which):
        assert is_clang_tidy_available() is False

    @patch("guard.core.cpp_analyzer.shutil.which", return_value="/usr/bin/clang-tidy")
    def test_clang_tidy_available(self, mock_which):
        assert is_clang_tidy_available() is True

    @patch("guard.core.cpp_analyzer.shutil.which", return_value=None)
    def test_cppcheck_not_available(self, mock_which):
        assert is_cppcheck_available() is False

    @patch("guard.core.cpp_analyzer.shutil.which", return_value="/usr/bin/cppcheck")
    def test_cppcheck_available(self, mock_which):
        assert is_cppcheck_available() is True


class TestSeverityMapping:
    """Tests for severity mapping functions."""

    def test_severity_mapping_clang_tidy(self):
        assert _map_clang_tidy_severity("warning") == Severity.MEDIUM
        assert _map_clang_tidy_severity("error") == Severity.HIGH
        assert _map_clang_tidy_severity("note") == Severity.LOW
        assert _map_clang_tidy_severity("unknown") == Severity.INFO

    def test_severity_mapping_cppcheck(self):
        assert _map_cppcheck_severity("error") == Severity.HIGH
        assert _map_cppcheck_severity("warning") == Severity.MEDIUM
        assert _map_cppcheck_severity("style") == Severity.LOW
        assert _map_cppcheck_severity("performance") == Severity.LOW
        assert _map_cppcheck_severity("portability") == Severity.LOW
        assert _map_cppcheck_severity("information") == Severity.INFO
        assert _map_cppcheck_severity("unknown") == Severity.INFO


class TestStandardMapping:
    """Tests for check-to-standard mapping."""

    def test_standard_mapping(self):
        assert _map_check_to_standard("cert-err33-c") == "CERT C"
        assert _map_check_to_standard("bugprone-use-after-move") == "C++ Core Guidelines"
        assert _map_check_to_standard("cppcoreguidelines-init-variables") == "C++ Core Guidelines"
        assert _map_check_to_standard("misc-unused-alias-decls") == "Best Practices"
        assert _map_check_to_standard("modernize-use-nullptr") == "C++ Modernization"
        assert _map_check_to_standard("performance-unnecessary-copy") == "C++ Performance"
        assert _map_check_to_standard("readability-braces-around-statements") == "C++ Readability"
        assert _map_check_to_standard("misra-c2012-15.1") == "MISRA C/C++"
        assert _map_check_to_standard("unknown-check") == "C/C++ Analysis"


class TestParseClangTidyOutput:
    """Tests for parsing clang-tidy output."""

    def test_parse_clang_tidy_output(self):
        output = (
            "/repo/src/main.cpp:10:5: warning: use of 'strcpy' is insecure [bugprone-not-null-terminated-result]\n"
            "/repo/src/main.cpp:20:3: warning: variable 'x' is not initialized [cppcoreguidelines-init-variables]\n"
        )
        findings = _parse_clang_tidy_output(output, "/repo")
        assert len(findings) == 2
        assert findings[0].rule_id == "bugprone-not-null-terminated-result"
        assert findings[0].severity == Severity.MEDIUM
        assert findings[0].evidence.lines == [10]
        assert findings[1].rule_id == "cppcoreguidelines-init-variables"
        assert findings[1].evidence.lines == [20]

    def test_parse_clang_tidy_error(self):
        output = "/repo/src/main.cpp:5:1: error: expected ';' after expression [clang-diagnostic-error]\n"
        findings = _parse_clang_tidy_output(output, "/repo")
        assert len(findings) == 1
        assert findings[0].severity == Severity.HIGH
        assert findings[0].rule_id == "clang-diagnostic-error"

    def test_empty_output(self):
        findings = _parse_clang_tidy_output("", "/repo")
        assert findings == []

    def test_non_matching_lines_ignored(self):
        output = (
            "3 warnings generated.\n"
            "Suppressed 1 warning.\n"
            "/repo/src/main.cpp:10:5: warning: msg [check-name]\n"
        )
        findings = _parse_clang_tidy_output(output, "/repo")
        assert len(findings) == 1

    def test_finding_has_correct_fields(self):
        output = "/repo/src/util.cpp:42:8: warning: pointer dereference [cert-err33-c]\n"
        findings = _parse_clang_tidy_output(output, "/repo")
        assert len(findings) == 1
        f = findings[0]
        assert f.confidence == 1.0
        assert f.deterministic is True
        assert f.standard == "CERT C"
        assert f.rule_id == "cert-err33-c"
        assert "util.cpp" in f.evidence.file
        assert f.evidence.lines == [42]


class TestParseCppcheckOutput:
    """Tests for parsing cppcheck output."""

    def test_parse_cppcheck_output(self):
        output = (
            "src/main.cpp:15:error:nullPointer:Null pointer dereference\n"
            "src/main.cpp:30:warning:uninitvar:Uninitialized variable: x\n"
            "src/util.cpp:5:style:unusedVariable:Unused variable: y\n"
        )
        findings = _parse_cppcheck_output(output, "/repo")
        assert len(findings) == 3
        assert findings[0].severity == Severity.HIGH
        assert findings[0].rule_id == "cppcheck-nullPointer"
        assert findings[1].severity == Severity.MEDIUM
        assert findings[1].rule_id == "cppcheck-uninitvar"
        assert findings[2].severity == Severity.LOW
        assert findings[2].rule_id == "cppcheck-unusedVariable"

    def test_empty_cppcheck_output(self):
        findings = _parse_cppcheck_output("", "/repo")
        assert findings == []


class TestRunClangTidy:
    """Tests for running clang-tidy (mocked subprocess)."""

    @patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=False)
    def test_clang_tidy_not_installed(self, mock_avail):
        result = run_clang_tidy(["main.cpp"], repo_root="/repo")
        assert result.tool == "clang-tidy"
        assert len(result.findings) == 0
        assert len(result.errors) == 1
        assert "not installed" in result.errors[0]

    @patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=True)
    @patch("guard.core.cpp_analyzer.subprocess.run")
    def test_clang_tidy_parses_output(self, mock_run, mock_avail):
        mock_run.return_value = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout="/repo/main.cpp:10:5: warning: use of strcpy [bugprone-not-null-terminated-result]\n",
            stderr="",
        )
        result = run_clang_tidy(["main.cpp"], repo_root="/repo")
        assert result.tool == "clang-tidy"
        assert len(result.findings) == 1
        assert result.files_analyzed == 1

    @patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=True)
    def test_clang_tidy_empty_files(self, mock_avail):
        result = run_clang_tidy([], repo_root="/repo")
        assert len(result.findings) == 0
        assert result.files_analyzed == 0

    @patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=True)
    @patch("guard.core.cpp_analyzer.subprocess.run", side_effect=subprocess.TimeoutExpired("cmd", 300))
    def test_clang_tidy_timeout(self, mock_run, mock_avail):
        result = run_clang_tidy(["main.cpp"], repo_root="/repo")
        assert len(result.errors) == 1
        assert "timed out" in result.errors[0]


class TestRunCppcheck:
    """Tests for running cppcheck (mocked subprocess)."""

    @patch("guard.core.cpp_analyzer.is_cppcheck_available", return_value=False)
    def test_cppcheck_not_installed(self, mock_avail):
        result = run_cppcheck(["main.cpp"], repo_root="/repo")
        assert result.tool == "cppcheck"
        assert len(result.findings) == 0
        assert len(result.errors) == 1
        assert "not installed" in result.errors[0]

    @patch("guard.core.cpp_analyzer.is_cppcheck_available", return_value=True)
    @patch("guard.core.cpp_analyzer.subprocess.run")
    def test_cppcheck_parses_output(self, mock_run, mock_avail):
        mock_run.return_value = subprocess.CompletedProcess(
            args=[],
            returncode=0,
            stdout="",
            stderr="main.cpp:15:error:nullPointer:Null pointer dereference\n",
        )
        result = run_cppcheck(["main.cpp"], repo_root="/repo")
        assert result.tool == "cppcheck"
        assert len(result.findings) == 1
        assert result.findings[0].severity == Severity.HIGH


class TestMultipleFiles:
    """Tests for analyzing multiple files."""

    @patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=True)
    @patch("guard.core.cpp_analyzer.subprocess.run")
    def test_multiple_files(self, mock_run, mock_avail):
        mock_run.return_value = subprocess.CompletedProcess(
            args=[],
            returncode=1,
            stdout=(
                "/repo/src/a.cpp:10:5: warning: msg1 [cert-err33-c]\n"
                "/repo/src/b.cpp:20:3: warning: msg2 [bugprone-use-after-move]\n"
                "/repo/src/b.cpp:25:1: error: msg3 [clang-diagnostic-error]\n"
            ),
            stderr="",
        )
        result = run_clang_tidy(
            ["src/a.cpp", "src/b.cpp"],
            repo_root="/repo",
        )
        assert len(result.findings) == 3
        assert result.files_analyzed == 2
        files = {f.evidence.file for f in result.findings}
        assert len(files) == 2  # findings from both files


class TestCollectCppFiles:
    """Tests for collecting C/C++ files."""

    def test_filter_specific_files(self):
        files = ["main.cpp", "util.py", "header.h", "readme.md"]
        result = collect_cpp_files("/repo", specific_files=files)
        assert result == ["main.cpp", "header.h"]

    def test_filter_specific_files_empty(self):
        files = ["readme.md", "config.yaml"]
        result = collect_cpp_files("/repo", specific_files=files)
        assert result == []


class TestRunCppAnalysis:
    """Tests for the top-level run_cpp_analysis function."""

    @patch("guard.core.cpp_analyzer.run_clang_tidy")
    @patch("guard.core.cpp_analyzer.run_cppcheck")
    @patch("guard.core.cpp_analyzer.collect_cpp_files", return_value=["main.cpp"])
    def test_both_tools(self, mock_collect, mock_cppcheck, mock_clang):
        mock_clang.return_value = CppAnalyzerResult(tool="clang-tidy")
        mock_cppcheck.return_value = CppAnalyzerResult(tool="cppcheck")

        results = run_cpp_analysis("/repo", tool="both")
        assert len(results) == 2
        mock_clang.assert_called_once()
        mock_cppcheck.assert_called_once()

    @patch("guard.core.cpp_analyzer.run_clang_tidy")
    @patch("guard.core.cpp_analyzer.collect_cpp_files", return_value=["main.cpp"])
    def test_clang_tidy_only(self, mock_collect, mock_clang):
        mock_clang.return_value = CppAnalyzerResult(tool="clang-tidy")

        results = run_cpp_analysis("/repo", tool="clang-tidy")
        assert len(results) == 1
        assert results[0].tool == "clang-tidy"


class TestCLIAnalyzeCpp:
    """Tests for the CLI analyze-cpp command."""

    def test_cli_no_tools(self):
        """CLI shows install message when no tools available."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        with patch("guard.core.cpp_analyzer.is_clang_tidy_available", return_value=False), \
             patch("guard.core.cpp_analyzer.is_cppcheck_available", return_value=False):
            result = runner.invoke(app, ["analyze-cpp"])
            assert result.exit_code == 1
            assert "No C/C++ analysis tools found" in result.output or result.exit_code == 1
