"""Tests for render_report() and render_next_actions()."""

from __future__ import annotations

from tests.helpers import make_finding
from guard.core.models import Severity
from guard.core.renderer import render_next_actions, render_report


# ===================================================================
# render_report
# ===================================================================


class TestRenderReport:
    def test_empty_findings(self):
        md = render_report([])
        assert "No findings detected" in md

    def test_header(self):
        md = render_report([])
        assert md.startswith("# Guard Scan Report")

    def test_single_finding_all_fields(self):
        f = make_finding(
            fid="F1", rule="R1", sev=Severity.HIGH, file="app.py",
            lines=[10], msg="Bad code", suggestion="Fix it",
            snippet="eval()", confidence=0.9, deterministic=False,
        )
        md = render_report([f])
        assert "F1" in md
        assert "R1" in md
        assert "Bad code" in md
        assert "app.py" in md
        assert "[10]" in md
        assert "eval()" in md
        assert "Fix it" in md
        assert "0.9" in md
        assert "heuristic" in md

    def test_severity_sections_ordered(self):
        findings = [
            make_finding(fid="I1", sev=Severity.INFO),
            make_finding(fid="C1", sev=Severity.CRITICAL),
        ]
        md = render_report(findings)
        crit_pos = md.index("CRITICAL")
        info_pos = md.index("INFO")
        assert crit_pos < info_pos

    def test_only_present_severities_shown(self):
        findings = [make_finding(sev=Severity.MEDIUM)]
        md = render_report(findings)
        assert "MEDIUM" in md
        assert "CRITICAL" not in md
        assert "HIGH" not in md

    def test_snippet_in_code_block(self):
        f = make_finding(snippet="x = eval(input())")
        md = render_report([f])
        assert "```\nx = eval(input())\n```" in md

    def test_suggestion_present(self):
        f = make_finding(suggestion="Use literal_eval")
        md = render_report([f])
        assert "Use literal_eval" in md

    def test_suggestion_absent(self):
        f = make_finding(suggestion=None)
        md = render_report([f])
        assert "**Suggestion:**" not in md

    def test_lines_present(self):
        f = make_finding(lines=[42])
        md = render_report([f])
        assert "[42]" in md

    def test_lines_absent(self):
        f = make_finding(lines=[])
        md = render_report([f])
        assert "**Lines:**" not in md

    def test_work_items_present(self):
        f = make_finding(related_work_items=["WI-101"])
        md = render_report([f])
        assert "WI-101" in md

    def test_work_items_absent(self):
        f = make_finding()
        md = render_report([f])
        assert "**Related work items:**" not in md

    def test_deterministic_label(self):
        f = make_finding(deterministic=True)
        md = render_report([f])
        assert "deterministic" in md

    def test_heuristic_label(self):
        f = make_finding(deterministic=False)
        md = render_report([f])
        assert "heuristic" in md

    def test_multiple_findings_same_severity_count(self):
        findings = [
            make_finding(fid="F1", sev=Severity.HIGH),
            make_finding(fid="F2", sev=Severity.HIGH),
        ]
        md = render_report(findings)
        assert "HIGH (2)" in md


# ===================================================================
# render_next_actions
# ===================================================================


class TestRenderNextActions:
    def test_empty_findings(self):
        md = render_next_actions([])
        assert "No actions required" in md

    def test_header(self):
        md = render_next_actions([])
        assert md.startswith("# Next Actions")

    def test_single_action(self):
        f = make_finding(file="app.py", suggestion="Fix it")
        md = render_next_actions([f])
        assert "1." in md
        assert "app.py" in md

    def test_suggestion_as_action_text(self):
        f = make_finding(suggestion="Use literal_eval")
        md = render_next_actions([f])
        assert "Use literal_eval" in md

    def test_message_as_fallback(self):
        f = make_finding(msg="Bad code", suggestion=None)
        md = render_next_actions([f])
        assert "Fix: Bad code" in md

    def test_ordered_by_severity(self):
        findings = [
            make_finding(fid="L1", sev=Severity.LOW, file="low.py"),
            make_finding(fid="C1", sev=Severity.CRITICAL, file="crit.py"),
        ]
        md = render_next_actions(findings)
        crit_pos = md.index("CRITICAL")
        low_pos = md.index("LOW")
        assert crit_pos < low_pos

    def test_sequential_numbering(self):
        findings = [
            make_finding(fid="F1", sev=Severity.HIGH),
            make_finding(fid="F2", sev=Severity.LOW),
        ]
        md = render_next_actions(findings)
        assert "1." in md
        assert "2." in md

    def test_all_five_severities_represented(self):
        findings = [
            make_finding(fid="C1", sev=Severity.CRITICAL),
            make_finding(fid="H1", sev=Severity.HIGH),
            make_finding(fid="M1", sev=Severity.MEDIUM),
            make_finding(fid="L1", sev=Severity.LOW),
            make_finding(fid="I1", sev=Severity.INFO),
        ]
        md = render_next_actions(findings)
        assert "CRITICAL" in md
        assert "HIGH" in md
        assert "MEDIUM" in md
        assert "LOW" in md
        assert "INFO" in md


# ===================================================================
# Compliance obligations in reports
# ===================================================================


class TestObligationRendering:
    @staticmethod
    def _obligation(
        rule_id="DOC-001",
        standard="IEC 62304",
        clause="5.1.1",
        msg="Must have dev plan",
        remediation="Create a development plan",
    ):
        from guard.core.models import Evidence, Finding
        return Finding(
            finding_id=f"{rule_id}-obligation",
            rule_id=rule_id,
            severity=Severity.INFO,
            message=msg,
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0,
            is_obligation=True,
            standard=standard,
            clause=clause,
            remediation_guidance=remediation,
        )

    def test_report_has_compliance_section(self):
        md = render_report([self._obligation()])
        assert "## Compliance Obligations" in md

    def test_report_obligations_grouped_by_standard(self):
        o1 = self._obligation(rule_id="A", standard="IEC 62304")
        o2 = self._obligation(rule_id="B", standard="ISO 14971")
        md = render_report([o1, o2])
        assert "### IEC 62304" in md
        assert "### ISO 14971" in md

    def test_report_obligation_shows_clause(self):
        md = render_report([self._obligation(clause="5.1.1")])
        assert "5.1.1" in md

    def test_report_obligation_shows_remediation(self):
        md = render_report([self._obligation(remediation="Create a plan")])
        assert "Create a plan" in md

    def test_report_code_finding_with_standard(self):
        from guard.core.models import Evidence, Finding
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.HIGH,
            message="Bad code", evidence=Evidence(file="app.py", lines=[1], snippet="x"),
            confidence=1.0, standard="IEC 62304", clause="5.5.5",
        )
        md = render_report([f])
        assert "**Standard:** IEC 62304 clause 5.5.5" in md

    def test_report_empty_with_only_obligations(self):
        md = render_report([self._obligation()])
        # Should not have severity sections (no code findings)
        assert "## CRITICAL" not in md
        assert "## Compliance Obligations" in md

    def test_next_actions_has_obligation_section(self):
        md = render_next_actions([self._obligation()])
        assert "## Compliance Obligations (non-code)" in md

    def test_next_actions_obligation_tag(self):
        md = render_next_actions([self._obligation()])
        assert "[OBLIGATION]" in md

    def test_next_actions_obligation_clause(self):
        md = render_next_actions([self._obligation(clause="5.1.1")])
        assert "5.1.1" in md

    def test_next_actions_mixed(self):
        code_f = make_finding(fid="C1", sev=Severity.HIGH)
        obl = self._obligation()
        md = render_next_actions([code_f, obl])
        assert "[HIGH]" in md
        assert "[OBLIGATION]" in md
