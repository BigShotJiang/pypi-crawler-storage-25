"""Smoke tests for the standalone binary (skipped if binary not built)."""

from __future__ import annotations

import platform
import subprocess
from pathlib import Path

import pytest

_BINARY = Path("dist/guard.exe") if platform.system() == "Windows" else Path("dist/guard")
_SKIP = not _BINARY.exists()
_REASON = f"Binary not found at {_BINARY} — run 'pyinstaller guard.spec' first"


@pytest.mark.skipif(_SKIP, reason=_REASON)
class TestBinarySmoke:
    def test_help(self):
        result = subprocess.run(
            [str(_BINARY), "--help"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "guard" in result.stdout.lower() or "usage" in result.stdout.lower()

    def test_license(self):
        result = subprocess.run(
            [str(_BINARY), "license"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "license" in result.stdout.lower()

    def test_install_check(self):
        result = subprocess.run(
            [str(_BINARY), "install-check"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "Installation Check" in result.output

    def test_validate_config(self):
        result = subprocess.run(
            [str(_BINARY), "validate-config"],
            capture_output=True, text=True, timeout=30,
        )
        # May fail if no config, but should not crash
        assert result.returncode in (0, 1)

    def test_list_packs(self):
        result = subprocess.run(
            [str(_BINARY), "list-packs"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "pack" in result.stdout.lower()
