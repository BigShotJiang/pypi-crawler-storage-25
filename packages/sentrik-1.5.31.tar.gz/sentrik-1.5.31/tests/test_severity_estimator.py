"""Tests for heuristic severity rescoring."""

from __future__ import annotations

import pytest

from guard.core.models import Evidence, Finding, Severity
from guard.ml.severity_estimator import (
    DEFAULT_WEIGHTS,
    FeatureVector,
    SeverityEstimator,
    _calibrate_confidence,
    _score_blast_radius,
    _score_code_context,
    _score_exploitability,
    _score_file_risk,
    _score_pattern_risk,
    compute_score,
    extract_features,
    score_to_severity,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_finding(
    severity: str = "medium",
    confidence: float = 0.7,
    deterministic: bool = False,
    file: str = "src/app.py",
    snippet: str = "x = 1",
    message: str = "Test finding",
    lines: list[int] | None = None,
    is_obligation: bool = False,
    rule_id: str = "TEST-001",
) -> Finding:
    return Finding(
        finding_id=f"{rule_id}-{file}:1",
        rule_id=rule_id,
        severity=Severity(severity),
        message=message,
        evidence=Evidence(
            file=file,
            lines=lines or [1],
            snippet=snippet,
        ),
        confidence=confidence,
        deterministic=deterministic,
        is_obligation=is_obligation,
    )


# ---------------------------------------------------------------------------
# FeatureVector
# ---------------------------------------------------------------------------

class TestFeatureVector:
    def test_to_dict(self):
        fv = FeatureVector(
            base_severity=0.8,
            confidence=0.9,
            code_context=0.5,
            pattern_risk=0.3,
            file_risk=0.4,
            density=0.1,
            exploitability=0.6,
            blast_radius=0.7,
        )
        d = fv.to_dict()
        assert d["base_severity"] == 0.8
        assert d["confidence"] == 0.9
        assert d["code_context"] == 0.5
        assert d["pattern_risk"] == 0.3
        assert d["file_risk"] == 0.4
        assert d["density"] == 0.1
        assert d["exploitability"] == 0.6
        assert d["blast_radius"] == 0.7
        assert len(d) == 8

    def test_default_values(self):
        fv = FeatureVector()
        assert fv.base_severity == 0.0
        assert fv.confidence == 0.5
        assert fv.code_context == 0.0
        assert fv.density == 0.0


# ---------------------------------------------------------------------------
# Feature extraction
# ---------------------------------------------------------------------------

class TestExtractFeatures:
    def test_critical_severity_maps_to_1(self):
        finding = _make_finding(severity="critical")
        fv = extract_features(finding)
        assert fv.base_severity == 1.0

    def test_info_severity_maps_to_low_score(self):
        finding = _make_finding(severity="info")
        fv = extract_features(finding)
        assert fv.base_severity == 0.1

    def test_confidence_pass_through(self):
        finding = _make_finding(confidence=0.85)
        fv = extract_features(finding)
        assert fv.confidence == 0.85

    def test_high_density_file(self):
        finding = _make_finding()
        fv = extract_features(finding, file_findings_count=20, total_file_lines=100)
        assert fv.density > 0.5

    def test_low_density_file(self):
        finding = _make_finding()
        fv = extract_features(finding, file_findings_count=1, total_file_lines=1000)
        assert fv.density < 0.2

    def test_density_capped_at_1(self):
        finding = _make_finding()
        fv = extract_features(finding, file_findings_count=500, total_file_lines=100)
        assert fv.density <= 1.0


# ---------------------------------------------------------------------------
# Code context scoring
# ---------------------------------------------------------------------------

class TestScoreCodeContext:
    def test_empty_snippet_default(self):
        finding = _make_finding(snippet="")
        score = _score_code_context(finding)
        assert score == 0.3

    def test_exception_handler_boosts(self):
        finding = _make_finding(snippet="except ValueError:")
        score = _score_code_context(finding)
        assert score > 0.3

    def test_function_definition_boosts(self):
        finding = _make_finding(snippet="def process_payment():")
        score = _score_code_context(finding)
        assert score > 0.3

    def test_class_definition_boosts(self):
        finding = _make_finding(snippet="class AuthManager:")
        score = _score_code_context(finding)
        assert score > 0.3

    def test_import_statement_boosts(self):
        finding = _make_finding(snippet="import os")
        score = _score_code_context(finding)
        assert score > 0.3

    def test_score_capped_at_1(self):
        finding = _make_finding(snippet="def foo(): class Bar: except: import x; return y")
        score = _score_code_context(finding)
        assert score <= 1.0


# ---------------------------------------------------------------------------
# Pattern risk scoring
# ---------------------------------------------------------------------------

class TestScorePatternRisk:
    def test_no_risky_patterns(self):
        finding = _make_finding(message="Variable unused", snippet="x = 1")
        score = _score_pattern_risk(finding)
        assert score == 0.1

    def test_password_pattern(self):
        finding = _make_finding(message="Hardcoded password detected", snippet="password='abc'")
        score = _score_pattern_risk(finding)
        assert score > 0.3

    def test_sql_injection_pattern(self):
        finding = _make_finding(message="SQL injection risk", snippet="execute(sql)")
        score = _score_pattern_risk(finding)
        assert score > 0.3

    def test_multiple_patterns_boost(self):
        finding = _make_finding(
            message="Eval with password", snippet="eval(password)"
        )
        score = _score_pattern_risk(finding)
        assert score > 0.5

    def test_score_capped_at_1(self):
        finding = _make_finding(
            message="password token secret credential sql inject eval exec",
            snippet="password token secret credential sql inject eval exec",
        )
        score = _score_pattern_risk(finding)
        assert score <= 1.0


# ---------------------------------------------------------------------------
# File risk scoring
# ---------------------------------------------------------------------------

class TestScoreFileRisk:
    def test_generic_file(self):
        score = _score_file_risk("src/utils/helpers.py")
        assert score == 0.2

    def test_auth_file(self):
        score = _score_file_risk("src/auth/login.py")
        assert score > 0.2

    def test_config_file(self):
        score = _score_file_risk("src/settings.py")
        assert score > 0.2

    def test_api_file(self):
        score = _score_file_risk("src/api/endpoints.py")
        assert score > 0.2

    def test_multiple_risk_signals(self):
        score = _score_file_risk("src/auth/admin_config.py")
        assert score > 0.5


class TestScoreExploitability:
    def _finding(self, snippet="x = 1", file="app.py"):
        return Finding(
            finding_id="test-1",
            rule_id="TEST-001",
            severity=Severity.MEDIUM,
            message="test finding",
            evidence=Evidence(file=file, lines=[1], snippet=snippet),
            confidence=0.8,
        )

    def test_baseline(self):
        score = _score_exploitability(self._finding())
        assert score == pytest.approx(0.1, abs=0.05)

    def test_user_input(self):
        score = _score_exploitability(self._finding("data = request.get('key')"))
        assert score > 0.3

    def test_route_handler(self):
        score = _score_exploitability(self._finding("@app.route('/api/users')"))
        assert score > 0.3

    def test_public_file(self):
        score = _score_exploitability(self._finding(file="src/controller/users.py"))
        assert score > 0.2

    def test_test_file_discounted(self):
        score = _score_exploitability(self._finding(
            "data = request.get('key')", file="tests/test_api.py"
        ))
        base = _score_exploitability(self._finding("data = request.get('key')"))
        assert score < base


class TestScoreBlastRadius:
    def _finding(self, snippet="x = 1", file="src/logic.py"):
        return Finding(
            finding_id="test-1",
            rule_id="TEST-001",
            severity=Severity.MEDIUM,
            message="test finding",
            evidence=Evidence(file=file, lines=[1], snippet=snippet),
            confidence=0.8,
        )

    def test_baseline(self):
        score = _score_blast_radius(self._finding())
        assert score == pytest.approx(0.1, abs=0.05)

    def test_middleware(self):
        score = _score_blast_radius(self._finding(file="src/middleware/auth.py"))
        assert score > 0.3

    def test_sensitive_data(self):
        score = _score_blast_radius(self._finding("patient_data = db.query()"))
        assert score > 0.3

    def test_init_file(self):
        score = _score_blast_radius(self._finding(file="src/__init__.py"))
        assert score > 0.2

    def test_config_file(self):
        score = _score_blast_radius(self._finding(file="config.yaml"))
        assert score > 0.2


class TestRiskScoreOnFinding:
    def test_rescored_finding_has_risk_score(self):
        finding = Finding(
            finding_id="test-1",
            rule_id="TEST-001",
            severity=Severity.MEDIUM,
            message="eval(user_input)",
            evidence=Evidence(file="src/api/handler.py", lines=[10], snippet="eval(request.get('code'))"),
            confidence=0.7,
            deterministic=False,
        )
        estimator = SeverityEstimator()
        results = estimator.estimate([finding])
        assert len(results) == 1
        assert results[0].risk_score is not None
        assert "exploitability" in results[0].risk_score
        assert "blast_radius" in results[0].risk_score
        assert "score" in results[0].risk_score
        assert results[0].risk_score["exploitability"] > 0


# ---------------------------------------------------------------------------
# Scoring engine
# ---------------------------------------------------------------------------

class TestComputeScore:
    def test_all_high_features(self):
        fv = FeatureVector(
            base_severity=1.0,
            confidence=1.0,
            code_context=1.0,
            pattern_risk=1.0,
            file_risk=1.0,
            density=1.0,
            exploitability=1.0,
            blast_radius=1.0,
        )
        score = compute_score(fv)
        assert score == pytest.approx(1.0, abs=0.01)

    def test_all_low_features(self):
        fv = FeatureVector(
            base_severity=0.0,
            confidence=0.0,
            code_context=0.0,
            pattern_risk=0.0,
            file_risk=0.0,
            density=0.0,
        )
        score = compute_score(fv)
        assert score == 0.0

    def test_custom_weights(self):
        fv = FeatureVector(base_severity=1.0, confidence=0.0)
        # Only weight base_severity
        weights = {"base_severity": 1.0, "confidence": 0.0}
        score = compute_score(fv, weights)
        assert score == pytest.approx(1.0, abs=0.01)

    def test_zero_total_weight(self):
        fv = FeatureVector()
        score = compute_score(fv, {})
        assert score == 0.0

    def test_score_bounded(self):
        fv = FeatureVector(base_severity=5.0, confidence=5.0)  # Out of range
        score = compute_score(fv)
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# Score to severity mapping
# ---------------------------------------------------------------------------

class TestScoreToSeverity:
    def test_high_score_is_critical(self):
        assert score_to_severity(0.9) == Severity.CRITICAL

    def test_medium_high_is_high(self):
        assert score_to_severity(0.7) == Severity.HIGH

    def test_medium_score(self):
        assert score_to_severity(0.5) == Severity.MEDIUM

    def test_low_score(self):
        assert score_to_severity(0.3) == Severity.LOW

    def test_very_low_score(self):
        assert score_to_severity(0.05) == Severity.INFO

    def test_zero_score(self):
        assert score_to_severity(0.0) == Severity.INFO

    def test_one_score(self):
        assert score_to_severity(1.0) == Severity.CRITICAL


# ---------------------------------------------------------------------------
# Confidence calibration
# ---------------------------------------------------------------------------

class TestCalibrateConfidence:
    def test_returns_bounded_value(self):
        conf = _calibrate_confidence(0.5, 0.7)
        assert 0.0 <= conf <= 1.0

    def test_high_original_confidence_dominates(self):
        conf = _calibrate_confidence(0.5, 0.95)
        assert conf > 0.5

    def test_near_threshold_lowers_certainty(self):
        # Score 0.65 is exactly at a boundary
        conf_at_boundary = _calibrate_confidence(0.65, 0.5)
        conf_away = _calibrate_confidence(0.5, 0.5)
        # Both valid but the away-from-boundary should differ
        assert 0.0 <= conf_at_boundary <= 1.0
        assert 0.0 <= conf_away <= 1.0


# ---------------------------------------------------------------------------
# SeverityEstimator
# ---------------------------------------------------------------------------

class TestSeverityEstimator:
    def test_empty_findings(self):
        estimator = SeverityEstimator()
        result = estimator.estimate([])
        assert result == []

    def test_skips_deterministic_by_default(self):
        estimator = SeverityEstimator()
        finding = _make_finding(deterministic=True, severity="medium")
        result = estimator.estimate([finding])
        assert len(result) == 1
        assert result[0].severity == Severity.MEDIUM
        assert result[0].deterministic is True

    def test_processes_non_deterministic(self):
        estimator = SeverityEstimator()
        finding = _make_finding(
            deterministic=False,
            severity="info",
            confidence=0.9,
            message="Hardcoded password detected",
            snippet="password = 'secret123'",
            file="src/auth/login.py",
        )
        result = estimator.estimate([finding])
        assert len(result) == 1
        # The finding should be re-scored (high security risk signals)
        assert result[0].deterministic is False

    def test_re_score_deterministic_when_enabled(self):
        estimator = SeverityEstimator(re_score_deterministic=True)
        finding = _make_finding(deterministic=True, severity="info", confidence=0.5)
        result = estimator.estimate([finding])
        assert len(result) == 1

    def test_obligations_never_re_scored(self):
        estimator = SeverityEstimator(re_score_deterministic=True)
        finding = _make_finding(
            is_obligation=True,
            severity="info",
            deterministic=True,
        )
        result = estimator.estimate([finding])
        assert len(result) == 1
        assert result[0].severity == Severity.INFO
        assert result[0].is_obligation is True

    def test_preserves_finding_count(self):
        estimator = SeverityEstimator()
        findings = [
            _make_finding(deterministic=False, rule_id=f"TEST-{i}")
            for i in range(5)
        ]
        result = estimator.estimate(findings)
        assert len(result) == 5

    def test_custom_weights(self):
        # Weight only base_severity
        estimator = SeverityEstimator(
            weights={"base_severity": 1.0},
        )
        finding = _make_finding(
            deterministic=False,
            severity="critical",
            confidence=0.1,
        )
        result = estimator.estimate([finding])
        assert len(result) == 1
        # High base severity should keep it high
        assert result[0].severity in (Severity.CRITICAL, Severity.HIGH)

    def test_does_not_mutate_original(self):
        estimator = SeverityEstimator()
        finding = _make_finding(
            deterministic=False,
            severity="info",
            confidence=0.9,
            message="SQL injection risk",
            snippet="execute(query)",
            file="src/api/endpoints.py",
        )
        original_severity = finding.severity
        original_confidence = finding.confidence
        estimator.estimate([finding])
        assert finding.severity == original_severity
        assert finding.confidence == original_confidence

    def test_file_density_affects_score(self):
        estimator = SeverityEstimator()
        # Same finding in a file with many issues vs few issues
        findings_sparse = [_make_finding(deterministic=False)]
        findings_dense = [
            _make_finding(deterministic=False, rule_id=f"TEST-{i}")
            for i in range(10)
        ]
        result_sparse = estimator.estimate(findings_sparse)
        result_dense = estimator.estimate(findings_dense)
        # Both should work without errors
        assert len(result_sparse) == 1
        assert len(result_dense) == 10

    def test_mixed_deterministic_and_non(self):
        estimator = SeverityEstimator()
        findings = [
            _make_finding(deterministic=True, rule_id="DET-001"),
            _make_finding(deterministic=False, rule_id="NONDET-001"),
            _make_finding(deterministic=True, rule_id="DET-002"),
            _make_finding(deterministic=False, rule_id="NONDET-002"),
        ]
        result = estimator.estimate(findings)
        assert len(result) == 4
        # Deterministic ones should be unchanged
        assert result[0].deterministic is True
        assert result[2].deterministic is True

    def test_min_confidence_delta_threshold(self):
        estimator = SeverityEstimator(min_confidence_delta=0.5)
        finding = _make_finding(deterministic=False, severity="medium", confidence=0.5)
        result = estimator.estimate([finding])
        assert len(result) == 1


# ---------------------------------------------------------------------------
# Default weights validation
# ---------------------------------------------------------------------------

class TestDefaultWeights:
    def test_weights_sum_to_1(self):
        total = sum(DEFAULT_WEIGHTS.values())
        assert total == pytest.approx(1.0, abs=0.01)

    def test_all_weights_positive(self):
        for key, val in DEFAULT_WEIGHTS.items():
            assert val > 0, f"Weight {key} should be positive"

    def test_weight_keys_match_features(self):
        fv = FeatureVector()
        feature_keys = set(fv.to_dict().keys())
        weight_keys = set(DEFAULT_WEIGHTS.keys())
        assert feature_keys == weight_keys
