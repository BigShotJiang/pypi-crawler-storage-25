"""Tests for pipeline progress callback and history archiving (Phase 26i)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from guard.config import GuardConfig
from guard.core.pipeline import _archive_history, run_scan, run_scan_and_write
from guard.rules.engine import RulesEngine
from tests.helpers import FakeScanner, make_finding


class TestProgressCallback:
    def test_run_scan_calls_progress_callback(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "out"))
        config = GuardConfig(output_dir=str(tmp_path / "out"))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        callback = MagicMock()
        run_scan(
            str(tmp_path), config, engine, scanner,
            progress_callback=callback,
        )
        # Should be called with at least rules_engine and ml_severity phases
        phases = [call.args[0] for call in callback.call_args_list]
        assert "rules_engine" in phases
        assert "scanner" in phases
        assert "ml_severity" in phases
        assert "traceability" in phases

    def test_run_scan_and_write_calls_complete(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "out"))
        config = GuardConfig(output_dir=str(tmp_path / "out"))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        callback = MagicMock()
        run_scan_and_write(
            str(tmp_path), config, engine, scanner,
            progress_callback=callback,
        )
        phases = [call.args[0] for call in callback.call_args_list]
        assert "writing" in phases
        assert "complete" in phases

    def test_run_scan_works_without_callback(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "out"))
        config = GuardConfig(output_dir=str(tmp_path / "out"))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        # Should not raise
        findings = run_scan(str(tmp_path), config, engine, scanner)
        assert isinstance(findings, list)

    def test_progress_values_are_increasing(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "out"))
        config = GuardConfig(output_dir=str(tmp_path / "out"))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        callback = MagicMock()
        run_scan_and_write(
            str(tmp_path), config, engine, scanner,
            progress_callback=callback,
        )
        values = [call.args[1] for call in callback.call_args_list]
        assert all(0 <= v <= 1.0 for v in values)
        # Values should be non-decreasing
        for i in range(1, len(values)):
            assert values[i] >= values[i - 1]


class TestArchiveHistory:
    def test_no_archive_when_no_files(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        _archive_history(out)
        assert not (out / "history").exists()

    def test_archive_findings(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text('[{"test": true}]')
        _archive_history(out)
        history = out / "history"
        assert history.exists()
        archived = list(history.glob("findings_*.json"))
        assert len(archived) == 1

    def test_archive_metrics(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        (out / "scan_metrics.json").write_text('{"total": 5}')
        _archive_history(out)
        archived = list((out / "history").glob("scan_metrics_*.json"))
        assert len(archived) == 1

    def test_archive_both(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        (out / "scan_metrics.json").write_text("{}")
        _archive_history(out)
        history = out / "history"
        assert len(list(history.glob("findings_*.json"))) == 1
        assert len(list(history.glob("scan_metrics_*.json"))) == 1

    def test_retention_limit(self, tmp_path):
        out = tmp_path / "out"
        history = out / "history"
        history.mkdir(parents=True)
        # Create 25 existing history files (over the limit of 20)
        for i in range(25):
            ts = f"202601{i:02d}T000000Z"
            (history / f"findings_{ts}.json").write_text("[]")
            (history / f"scan_metrics_{ts}.json").write_text("{}")
        # Add a current findings.json
        (out / "findings.json").write_text("[]")
        (out / "scan_metrics.json").write_text("{}")
        _archive_history(out, max_history=20)
        findings_files = list(history.glob("findings_*.json"))
        metrics_files = list(history.glob("scan_metrics_*.json"))
        assert len(findings_files) <= 20
        assert len(metrics_files) <= 20


class TestSuppressionInPipeline:
    def test_suppression_filters_in_scan(self, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "out"))
        config = GuardConfig(
            output_dir=str(tmp_path / "out"),
            suppressions=[{"rule_id": "suppress-me"}],
        )
        engine = RulesEngine([])
        scanner = FakeScanner([
            make_finding(fid="F1", rule="suppress-me"),
            make_finding(fid="F2", rule="keep-me"),
        ])
        findings = run_scan(str(tmp_path), config, engine, scanner)
        rule_ids = [f.rule_id for f in findings]
        assert "suppress-me" not in rule_ids
        assert "keep-me" in rule_ids
