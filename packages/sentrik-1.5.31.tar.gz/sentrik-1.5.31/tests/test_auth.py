"""Tests for authentication module — models, session management, JWT handler."""

from __future__ import annotations

import json
import time

import pytest

from guard.auth.models import AuthConfig, TokenPayload, UserContext, VALID_ROLES
from guard.auth.oidc import OIDCClient, SessionManager


# ===================================================================
# UserContext
# ===================================================================


class TestUserContext:
    def test_anonymous_defaults(self):
        ctx = UserContext.anonymous()
        assert ctx.user_id == "anonymous"
        assert ctx.is_authenticated is False
        assert ctx.auth_method == "none"
        assert ctx.roles == []

    def test_from_api_key(self):
        ctx = UserContext.from_api_key()
        assert ctx.user_id == "api-key"
        assert ctx.is_authenticated is True
        assert ctx.auth_method == "api_key"
        assert "admin" in ctx.roles

    def test_from_token(self):
        payload = TokenPayload(
            sub="auth0|abc123",
            email="dev@example.com",
            name="Dev User",
            org_id="org_456",
            roles=["developer"],
        )
        ctx = UserContext.from_token(payload)
        assert ctx.user_id == "auth0|abc123"
        assert ctx.email == "dev@example.com"
        assert ctx.name == "Dev User"
        assert ctx.org_id == "org_456"
        assert ctx.auth_method == "jwt"
        assert ctx.is_authenticated is True

    def test_has_role_direct(self):
        ctx = UserContext(roles=["developer", "viewer"])
        assert ctx.has_role("developer") is True
        assert ctx.has_role("admin") is False

    def test_has_role_admin_has_all(self):
        ctx = UserContext(roles=["admin"])
        assert ctx.has_role("developer") is True
        assert ctx.has_role("security-lead") is True

    def test_has_any_role(self):
        ctx = UserContext(roles=["viewer"])
        assert ctx.has_any_role("admin", "viewer") is True
        assert ctx.has_any_role("admin", "developer") is False

    def test_repo_access_default_empty(self):
        ctx = UserContext()
        assert ctx.repo_access == []

    def test_repo_access_set(self):
        ctx = UserContext(repo_access=["repo-a", "repo-b"])
        assert ctx.repo_access == ["repo-a", "repo-b"]

    def test_has_permission_positive(self):
        ctx = UserContext(roles=["developer"])
        assert ctx.has_permission("scan") is True
        assert ctx.has_permission("findings:read") is True

    def test_has_permission_negative(self):
        ctx = UserContext(roles=["viewer"])
        assert ctx.has_permission("scan") is False
        assert ctx.has_permission("config:edit") is False


# ===================================================================
# TokenPayload
# ===================================================================


class TestTokenPayload:
    def test_defaults(self):
        tp = TokenPayload()
        assert tp.sub == ""
        assert tp.roles == []
        assert tp.permissions == []
        assert tp.exp == 0

    def test_with_values(self):
        tp = TokenPayload(
            sub="auth0|123",
            email="user@test.com",
            roles=["admin"],
            permissions=["scan:read", "gate:enforce"],
            exp=9999999999,
        )
        assert tp.sub == "auth0|123"
        assert len(tp.roles) == 1
        assert len(tp.permissions) == 2


# ===================================================================
# AuthConfig
# ===================================================================


class TestAuthConfig:
    def test_defaults(self):
        cfg = AuthConfig()
        assert cfg.enabled is False
        assert cfg.provider == "none"
        assert cfg.auth0_domain == ""
        assert cfg.jwt_algorithms == ["RS256"]
        assert cfg.session_expiry_hours == 24

    def test_from_dict(self):
        cfg = AuthConfig(
            enabled=True,
            provider="auth0",
            auth0_domain="myco.auth0.com",
            auth0_client_id="client123",
            auth0_audience="https://api.myco.com",
        )
        assert cfg.enabled is True
        assert cfg.provider == "auth0"


# ===================================================================
# SessionManager
# ===================================================================


class TestSessionManager:
    def test_create_and_read_session(self):
        mgr = SessionManager(secret="test-secret-key-1234", expiry_hours=1)
        data = {"user_id": "u1", "email": "test@test.com", "roles": ["developer"]}
        cookie = mgr.create_session(data)

        assert isinstance(cookie, str)
        assert "." in cookie  # base64.signature format

        result = mgr.read_session(cookie)
        assert result is not None
        assert result["user_id"] == "u1"
        assert result["email"] == "test@test.com"
        assert result["roles"] == ["developer"]

    def test_expired_session_returns_none(self):
        mgr = SessionManager(secret="test-secret", expiry_hours=0)
        # expiry_hours=0 means 0 seconds TTL → immediately expired
        cookie = mgr.create_session({"user_id": "u1"})
        # Session was created with _exp = now + 0 seconds, so it's already expired
        time.sleep(0.1)
        result = mgr.read_session(cookie)
        assert result is None

    def test_tampered_cookie_returns_none(self):
        mgr = SessionManager(secret="test-secret", expiry_hours=1)
        cookie = mgr.create_session({"user_id": "u1"})
        # Tamper with the signature
        parts = cookie.rsplit(".", 1)
        tampered = parts[0] + ".badbadbadbad"
        result = mgr.read_session(tampered)
        assert result is None

    def test_invalid_cookie_returns_none(self):
        mgr = SessionManager(secret="test-secret", expiry_hours=1)
        assert mgr.read_session("") is None
        assert mgr.read_session("garbage") is None
        assert mgr.read_session(None) is None

    def test_different_secrets_fail(self):
        mgr1 = SessionManager(secret="secret-A", expiry_hours=1)
        mgr2 = SessionManager(secret="secret-B", expiry_hours=1)
        cookie = mgr1.create_session({"user_id": "u1"})
        result = mgr2.read_session(cookie)
        assert result is None

    def test_empty_secret_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            SessionManager(secret="", expiry_hours=1)


# ===================================================================
# OIDCClient
# ===================================================================


class TestOIDCClient:
    def _make_client(self, domain="test.auth0.com", client_id="cid123"):
        config = AuthConfig(
            enabled=True,
            provider="auth0",
            auth0_domain=domain,
            auth0_client_id=client_id,
            auth0_audience="https://api.test.com",
        )
        return OIDCClient(
            config=config,
            client_secret="secret123",
            redirect_uri="http://localhost:8000/auth/callback",
        )

    def test_authorize_url_contains_required_params(self):
        client = self._make_client()
        url = client.get_authorize_url(state="abc123")
        assert "https://test.auth0.com/authorize?" in url
        assert "response_type=code" in url
        assert "client_id=cid123" in url
        assert "state=abc123" in url
        assert "scope=openid" in url
        assert "redirect_uri=" in url

    def test_authorize_url_includes_audience(self):
        client = self._make_client()
        url = client.get_authorize_url()
        assert "audience=https" in url

    def test_logout_url_with_return_to(self):
        client = self._make_client()
        url = client.get_logout_url(return_to="http://localhost/dashboard")
        assert "https://test.auth0.com/v2/logout?" in url
        assert "client_id=cid123" in url
        assert "returnTo=" in url

    def test_logout_url_without_return_to(self):
        client = self._make_client()
        url = client.get_logout_url()
        assert "returnTo" not in url

    def test_domain_without_scheme_gets_https(self):
        client = self._make_client(domain="myco.auth0.com")
        url = client.get_authorize_url()
        assert url.startswith("https://myco.auth0.com/")

    def test_domain_with_scheme_preserved(self):
        client = self._make_client(domain="https://custom.auth0.com")
        url = client.get_authorize_url()
        assert url.startswith("https://custom.auth0.com/")


# ===================================================================
# Config integration
# ===================================================================


class TestConfigIntegration:
    def test_guard_config_get_auth_config_defaults(self):
        from guard.config import GuardConfig
        config = GuardConfig()
        auth = config.get_auth_config()
        assert isinstance(auth, AuthConfig)
        assert auth.enabled is False
        assert auth.provider == "none"

    def test_guard_config_with_auth_section(self):
        from guard.config import GuardConfig
        config = GuardConfig(auth={
            "enabled": True,
            "provider": "auth0",
            "auth0_domain": "test.auth0.com",
            "auth0_client_id": "myclient",
        })
        auth = config.get_auth_config()
        assert auth.enabled is True
        assert auth.provider == "auth0"
        assert auth.auth0_domain == "test.auth0.com"


# ===================================================================
# AuditEntry identity fields
# ===================================================================


class TestAuditEntryIdentity:
    def test_audit_entry_has_identity_fields(self):
        from guard.core.governance import AuditEntry
        entry = AuditEntry(
            timestamp="2026-01-01T00:00:00Z",
            action="scan",
            actor="human",
            user_id="auth0|abc",
            email="dev@co.com",
            org_id="org_1",
        )
        assert entry.user_id == "auth0|abc"
        assert entry.email == "dev@co.com"
        assert entry.org_id == "org_1"

    def test_audit_entry_identity_defaults_empty(self):
        from guard.core.governance import AuditEntry
        entry = AuditEntry(
            timestamp="2026-01-01T00:00:00Z",
            action="scan",
            actor="agent",
        )
        assert entry.user_id == ""
        assert entry.email == ""
        assert entry.org_id == ""

    def test_audit_log_writes_identity_fields(self, tmp_path):
        from guard.core.governance import AuditConfig, AuditLog
        log_file = tmp_path / "audit.jsonl"
        audit = AuditLog(AuditConfig(enabled=True, log_file=str(log_file)))
        entry = audit.log(
            action="gate",
            actor="human",
            result="success",
            user_id="auth0|xyz",
            email="admin@co.com",
            org_id="org_2",
        )
        assert entry is not None
        assert entry.user_id == "auth0|xyz"

        # Verify persisted to file
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["user_id"] == "auth0|xyz"
        assert data["email"] == "admin@co.com"
        assert data["org_id"] == "org_2"
