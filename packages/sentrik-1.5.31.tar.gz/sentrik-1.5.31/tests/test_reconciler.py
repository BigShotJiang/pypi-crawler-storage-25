"""Tests for the reconciler engine."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from guard.core.models import Evidence, Finding, Severity, WorkItem
from guard.core.reconciler import (
    ReconcileAction,
    ReconcileResult,
    _build_acceptance_criteria,
    _build_description,
    _build_title,
    _next_wi_id,
    execute_reconcile,
    group_findings_by_rule,
    reconcile,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _finding(
    rule_id: str = "STD-001",
    severity: str = "high",
    message: str = "Test finding",
    file: str = "src/app.py",
    compliance_category: str | None = None,
    suggestion: str | None = None,
    standard: str | None = None,
    clause: str | None = None,
    remediation_guidance: str | None = None,
) -> Finding:
    return Finding(
        finding_id=f"F-{rule_id}-1",
        rule_id=rule_id,
        severity=Severity(severity),
        message=message,
        evidence=Evidence(file=file, lines=[1], snippet="x"),
        confidence=1.0,
        compliance_category=compliance_category,
        suggestion=suggestion,
        standard=standard,
        clause=clause,
        remediation_guidance=remediation_guidance,
    )


def _work_item(
    id: str = "WI-1",
    title: str = "Test WI",
    rule_id: str | None = None,
    devops_id: int | None = None,
    state: str = "active",
    description: str = "",
) -> WorkItem:
    return WorkItem(
        id=id,
        title=title,
        state=state,
        rule_id=rule_id,
        devops_id=devops_id,
        description=description,
    )


# ---------------------------------------------------------------------------
# TestGroupFindings
# ---------------------------------------------------------------------------


class TestGroupFindings:
    def test_single_rule(self):
        findings = [_finding(rule_id="R-1"), _finding(rule_id="R-1")]
        groups = group_findings_by_rule(findings)
        assert list(groups.keys()) == ["R-1"]
        assert len(groups["R-1"]) == 2

    def test_multiple_rules(self):
        findings = [
            _finding(rule_id="R-1"),
            _finding(rule_id="R-2"),
            _finding(rule_id="R-1"),
        ]
        groups = group_findings_by_rule(findings)
        assert set(groups.keys()) == {"R-1", "R-2"}
        assert len(groups["R-1"]) == 2
        assert len(groups["R-2"]) == 1

    def test_empty_findings(self):
        groups = group_findings_by_rule([])
        assert groups == {}


# ---------------------------------------------------------------------------
# TestReconcile — create / update / close actions
# ---------------------------------------------------------------------------


class TestReconcile:
    def test_create_for_new_finding(self):
        findings = [_finding(rule_id="R-NEW")]
        actions = reconcile(findings, [])
        assert len(actions) == 1
        assert actions[0].action == "create"
        assert actions[0].rule_id == "R-NEW"

    def test_no_action_when_wi_matches(self):
        desc = _build_description("R-1", [_finding(rule_id="R-1")])
        wi = _work_item(rule_id="R-1", description=desc)
        findings = [_finding(rule_id="R-1")]
        actions = reconcile(findings, [wi])
        assert len(actions) == 0

    def test_update_when_description_changes(self):
        wi = _work_item(rule_id="R-1", description="old description")
        findings = [_finding(rule_id="R-1")]
        actions = reconcile(findings, [wi])
        assert len(actions) == 1
        assert actions[0].action == "update"
        assert actions[0].work_item == wi

    def test_close_when_findings_resolved(self):
        wi = _work_item(rule_id="R-GONE", state="active")
        actions = reconcile([], [wi])
        assert len(actions) == 1
        assert actions[0].action == "close"
        assert actions[0].rule_id == "R-GONE"

    def test_no_close_already_closed(self):
        wi = _work_item(rule_id="R-GONE", state="closed")
        actions = reconcile([], [wi])
        assert len(actions) == 0

    def test_reopen_closed_wi(self):
        wi = _work_item(rule_id="R-1", state="closed")
        findings = [_finding(rule_id="R-1")]
        actions = reconcile(findings, [wi])
        assert len(actions) == 1
        assert actions[0].action == "update"

    def test_skip_info_severity(self):
        findings = [_finding(rule_id="R-INFO", severity="info")]
        actions = reconcile(findings, [], skip_info=True)
        assert len(actions) == 0

    def test_keep_info_documentation(self):
        findings = [_finding(
            rule_id="R-DOC", severity="info",
            compliance_category="documentation",
        )]
        actions = reconcile(findings, [], skip_info=True)
        assert len(actions) == 1
        assert actions[0].action == "create"

    def test_no_skip_info_when_disabled(self):
        findings = [_finding(rule_id="R-INFO", severity="info")]
        actions = reconcile(findings, [], skip_info=False)
        assert len(actions) == 1

    def test_wi_without_rule_id_ignored(self):
        """Work items without rule_id are not touched by reconcile."""
        wi = _work_item(rule_id=None, state="active")
        findings = [_finding(rule_id="R-1")]
        actions = reconcile(findings, [wi])
        # Should create R-1 but not close the untagged WI
        assert len(actions) == 1
        assert actions[0].action == "create"

    def test_multiple_actions(self):
        wi_match = _work_item(id="WI-1", rule_id="R-1", description="old")
        wi_gone = _work_item(id="WI-2", rule_id="R-GONE", state="active")
        findings = [
            _finding(rule_id="R-1"),
            _finding(rule_id="R-NEW"),
        ]
        actions = reconcile(findings, [wi_match, wi_gone])
        action_types = {a.action for a in actions}
        assert action_types == {"create", "update", "close"}


# ---------------------------------------------------------------------------
# TestExecuteReconcile
# ---------------------------------------------------------------------------


class TestExecuteReconcile:
    def test_create_action(self, tmp_path):
        devops = MagicMock()
        devops.create_work_item.return_value = 99

        action = ReconcileAction(
            action="create", rule_id="R-1", work_item=None,
            title="New WI", description="desc", acceptance_criteria="ac",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [], wi_path)

        assert result.created == ["WI-1"]
        assert result.errors == []
        devops.create_work_item.assert_called_once()

        data = json.loads(wi_path.read_text())
        assert len(data) == 1
        assert data[0]["id"] == "WI-1"
        assert data[0]["devops_id"] == 99
        assert data[0]["rule_id"] == "R-1"

    def test_create_devops_failure(self, tmp_path):
        devops = MagicMock()
        devops.create_work_item.return_value = None

        action = ReconcileAction(
            action="create", rule_id="R-1", work_item=None,
            title="New WI", description="desc",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [], wi_path)

        assert result.created == ["WI-1"]
        assert len(result.errors) == 1
        assert "create failed" in result.errors[0]

    def test_update_action(self, tmp_path):
        devops = MagicMock()
        devops.update_work_item.return_value = True

        wi = _work_item(id="WI-5", rule_id="R-1", devops_id=42, description="old")
        action = ReconcileAction(
            action="update", rule_id="R-1", work_item=wi,
            title="Updated title", description="new desc",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [wi], wi_path)

        assert result.updated == ["WI-5"]
        devops.update_work_item.assert_called_once_with(
            42, title="Updated title", description="new desc",
        )

    def test_update_reopens_closed_wi(self, tmp_path):
        devops = MagicMock()
        devops.update_work_item.return_value = True

        wi = _work_item(id="WI-5", rule_id="R-1", devops_id=42, state="closed")
        action = ReconcileAction(
            action="update", rule_id="R-1", work_item=wi,
            title="Reopened", description="desc", acceptance_criteria="ac",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [wi], wi_path)

        assert wi.state == "active"
        call_kw = devops.update_work_item.call_args
        assert call_kw[1].get("state") == "Doing"

    def test_close_action(self, tmp_path):
        devops = MagicMock()
        devops.close_work_item.return_value = True

        wi = _work_item(id="WI-3", rule_id="R-GONE", devops_id=10, state="active")
        action = ReconcileAction(
            action="close", rule_id="R-GONE", work_item=wi,
            title=wi.title,
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [wi], wi_path)

        assert result.closed == ["WI-3"]
        assert wi.state == "closed"
        devops.close_work_item.assert_called_once_with(10)

    def test_close_without_devops_id(self, tmp_path):
        devops = MagicMock()

        wi = _work_item(id="WI-3", rule_id="R-GONE", devops_id=None, state="active")
        action = ReconcileAction(
            action="close", rule_id="R-GONE", work_item=wi,
            title=wi.title,
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, [wi], wi_path)

        assert result.closed == ["WI-3"]
        devops.close_work_item.assert_not_called()

    def test_writes_summary_artifact(self, tmp_path):
        devops = MagicMock()
        devops.create_work_item.return_value = 1

        action = ReconcileAction(
            action="create", rule_id="R-1", work_item=None,
            title="WI", description="d",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")
        out = tmp_path / "out"

        result = execute_reconcile([action], devops, [], wi_path, output_dir=out)

        summary_path = out / "reconcile_summary.json"
        assert summary_path.exists()
        summary = json.loads(summary_path.read_text())
        assert summary["created"] == ["WI-1"]

    def test_wi_id_generation_continues_sequence(self, tmp_path):
        devops = MagicMock()
        devops.create_work_item.return_value = 100

        existing = [_work_item(id="WI-25")]
        action = ReconcileAction(
            action="create", rule_id="R-X", work_item=None,
            title="New", description="d",
        )
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = execute_reconcile([action], devops, existing, wi_path)

        assert result.created == ["WI-26"]


# ---------------------------------------------------------------------------
# TestNextWiId
# ---------------------------------------------------------------------------


class TestNextWiId:
    def test_empty_list(self):
        assert _next_wi_id([]) == "WI-1"

    def test_sequential(self):
        items = [_work_item(id="WI-1"), _work_item(id="WI-2")]
        assert _next_wi_id(items) == "WI-3"

    def test_non_sequential(self):
        items = [_work_item(id="WI-1"), _work_item(id="WI-10")]
        assert _next_wi_id(items) == "WI-11"

    def test_ignores_non_wi_ids(self):
        items = [_work_item(id="CUSTOM-1"), _work_item(id="WI-5")]
        assert _next_wi_id(items) == "WI-6"


# ---------------------------------------------------------------------------
# TestBuildContent
# ---------------------------------------------------------------------------


class TestBuildContent:
    def test_build_title_short_message(self):
        findings = [_finding(rule_id="R-1", message="No eval calls allowed")]
        title = _build_title("R-1", findings)
        assert title == "[R-1] No eval calls allowed"

    def test_build_title_truncates_long_message(self):
        long_msg = "A" * 100 + ". More details here."
        findings = [_finding(rule_id="R-1", message=long_msg)]
        title = _build_title("R-1", findings)
        assert len(title.split("] ", 1)[1]) <= 80

    def test_build_description_includes_metadata(self):
        findings = [_finding(
            rule_id="R-1", severity="critical",
            standard="IEC 62304", clause="5.1.1",
            compliance_category="code",
            remediation_guidance="Fix it",
        )]
        desc = _build_description("R-1", findings)
        assert "R-1" in desc
        assert "critical" in desc
        assert "IEC 62304" in desc
        assert "5.1.1" in desc
        assert "Fix it" in desc

    def test_build_description_lists_files(self):
        findings = [
            _finding(rule_id="R-1", file="src/a.py"),
            _finding(rule_id="R-1", file="src/b.py"),
        ]
        desc = _build_description("R-1", findings)
        assert "src/a.py" in desc
        assert "src/b.py" in desc

    def test_build_acceptance_criteria(self):
        findings = [_finding(rule_id="R-1", suggestion="Use specific exceptions")]
        ac = _build_acceptance_criteria("R-1", findings)
        assert "R-1" in ac
        assert "sentrik gate" in ac
        assert "Use specific exceptions" in ac

    def test_build_acceptance_criteria_no_suggestion(self):
        findings = [_finding(rule_id="R-1")]
        ac = _build_acceptance_criteria("R-1", findings)
        assert "R-1" in ac
        # Only 2 list items when no suggestion
        assert ac.count("<li>") == 2

    def test_build_description_uses_html(self):
        """Description should use HTML tags, not markdown."""
        findings = [_finding(
            rule_id="R-1", severity="high",
            standard="IEC 62304", clause="5.1.1",
            remediation_guidance="Fix it",
        )]
        desc = _build_description("R-1", findings)
        # HTML bold tags instead of markdown **bold**
        assert "<b>Rule:</b>" in desc
        assert "<b>Severity:</b>" in desc
        assert "**" not in desc
        # File list uses HTML list tags
        assert "<ul>" in desc
        assert "<li>" in desc
        assert "<code>" in desc

    def test_build_acceptance_criteria_uses_html(self):
        """Acceptance criteria should use HTML list tags."""
        findings = [_finding(rule_id="R-1")]
        ac = _build_acceptance_criteria("R-1", findings)
        assert "<ul>" in ac
        assert "<li>" in ac
        assert "- " not in ac  # No markdown bullets
