"""Tests for the per-framework compliance report generator."""

from __future__ import annotations

import pytest

from guard.core.models import Evidence, Finding, Severity
from guard.reporters.compliance_report import (
    generate_compliance_report,
    list_frameworks,
)


def _make_finding(
    rule_id: str = "TEST-001",
    severity: str = "high",
    standard: str = "IEC 62304",
    clause: str = "5.1.1",
    message: str = "Test finding",
    is_obligation: bool = False,
    file: str = "src/main.py",
    lines: list[int] | None = None,
    suggestion: str | None = None,
    remediation_guidance: str | None = None,
) -> Finding:
    return Finding(
        finding_id="F1",
        rule_id=rule_id,
        severity=Severity(severity),
        message=message,
        evidence=Evidence(file=file, lines=lines or []),
        confidence=1.0,
        is_obligation=is_obligation,
        standard=standard,
        clause=clause,
        suggestion=suggestion,
        remediation_guidance=remediation_guidance,
    )


class TestListFrameworks:
    def test_empty_findings(self):
        assert list_frameworks([]) == []

    def test_single_framework(self):
        findings = [_make_finding(standard="SOC2"), _make_finding(standard="SOC2")]
        assert list_frameworks(findings) == ["SOC2"]

    def test_multiple_frameworks_sorted(self):
        findings = [
            _make_finding(standard="SOC2"),
            _make_finding(standard="IEC 62304"),
            _make_finding(standard="OWASP"),
        ]
        assert list_frameworks(findings) == ["IEC 62304", "OWASP", "SOC2"]

    def test_none_standard_excluded(self):
        findings = [
            _make_finding(standard="SOC2"),
            _make_finding(standard=None),
        ]
        # standard=None findings should be excluded
        # Need to construct manually since _make_finding defaults to "IEC 62304"
        f = Finding(
            finding_id="F2",
            rule_id="X",
            severity=Severity.LOW,
            message="no standard",
            evidence=Evidence(file="x.py"),
            confidence=1.0,
            standard=None,
        )
        assert list_frameworks([findings[0], f]) == ["SOC2"]


class TestGenerateComplianceReport:
    def test_returns_html(self):
        findings = [_make_finding()]
        html = generate_compliance_report(findings)
        assert "<!DOCTYPE html>" in html
        assert "Compliance Report" in html

    def test_framework_filter(self):
        findings = [
            _make_finding(standard="IEC 62304", clause="5.1.1"),
            _make_finding(standard="SOC2", clause="CC6.1"),
        ]
        html = generate_compliance_report(findings, framework="IEC 62304")
        assert "IEC 62304 Compliance Report" in html
        # SOC2 clause should not appear
        assert "CC6.1" not in html

    def test_framework_filter_case_insensitive(self):
        findings = [_make_finding(standard="IEC 62304")]
        html = generate_compliance_report(findings, framework="iec 62304")
        assert "iec 62304" in html.lower()

    def test_all_frameworks_when_none(self):
        findings = [
            _make_finding(standard="IEC 62304"),
            _make_finding(standard="SOC2", clause="CC6.1"),
        ]
        html = generate_compliance_report(findings)
        assert "All Frameworks" in html
        assert "5.1.1" in html
        assert "CC6.1" in html

    def test_clause_by_clause_table(self):
        findings = [
            _make_finding(clause="5.1.1"),
            _make_finding(clause="5.5.5", severity="critical"),
        ]
        html = generate_compliance_report(findings)
        assert "5.1.1" in html
        assert "5.5.5" in html
        assert "FAIL" in html

    def test_obligations_section(self):
        findings = [
            _make_finding(is_obligation=True, message="Must maintain audit log"),
        ]
        html = generate_compliance_report(findings)
        assert "Documentation Obligations" in html
        assert "Must maintain audit log" in html

    def test_no_obligations_table_when_none(self):
        findings = [_make_finding(is_obligation=False)]
        html = generate_compliance_report(findings)
        # The summary card label "Documentation Obligations" is always present,
        # but the full <h2> section should not render
        assert "<h2>Documentation Obligations</h2>" not in html

    def test_pass_status_for_obligation_only_clause(self):
        findings = [
            _make_finding(clause="5.1.1", is_obligation=True),
        ]
        html = generate_compliance_report(findings)
        assert "PASS" in html

    def test_severity_badges(self):
        findings = [
            _make_finding(severity="critical"),
            _make_finding(severity="high"),
        ]
        html = generate_compliance_report(findings)
        assert "CRITICAL: 1" in html
        assert "HIGH: 1" in html

    def test_compliance_score_all_pass(self):
        # No code findings = 100%
        findings = [_make_finding(is_obligation=True)]
        html = generate_compliance_report(findings, rules_total=5)
        assert "100.0%" in html

    def test_compliance_score_with_failures(self):
        findings = [
            _make_finding(rule_id="R1"),
            _make_finding(rule_id="R2"),
        ]
        html = generate_compliance_report(findings, rules_total=10)
        # 8 of 10 passed = 80%
        assert "80.0%" in html

    def test_remediation_guidance_shown(self):
        findings = [
            _make_finding(remediation_guidance="Use environment variables instead"),
        ]
        html = generate_compliance_report(findings)
        assert "Use environment variables instead" in html

    def test_suggestion_as_fallback(self):
        findings = [
            _make_finding(suggestion="Replace with safe alternative"),
        ]
        html = generate_compliance_report(findings)
        assert "Replace with safe alternative" in html

    def test_empty_findings(self):
        html = generate_compliance_report([])
        assert "all rules passed" in html.lower() or "All Frameworks" in html

    def test_file_and_line_display(self):
        findings = [_make_finding(file="src/main.cpp", lines=[42])]
        html = generate_compliance_report(findings)
        assert "src/main.cpp:42" in html

    def test_dark_mode_support(self):
        html = generate_compliance_report([_make_finding()])
        assert "prefers-color-scheme: dark" in html

    def test_print_styles(self):
        html = generate_compliance_report([_make_finding()])
        assert "@media print" in html

    def test_multiple_rules_per_clause(self):
        findings = [
            _make_finding(rule_id="R1", clause="5.5.5"),
            _make_finding(rule_id="R2", clause="5.5.5"),
            _make_finding(rule_id="R3", clause="5.5.5"),
        ]
        html = generate_compliance_report(findings)
        assert "R1" in html
        assert "R2" in html
        assert "R3" in html

    def test_html_escaping(self):
        findings = [_make_finding(message="<script>alert('xss')</script>")]
        html = generate_compliance_report(findings)
        assert "<script>" not in html
        assert "&lt;script&gt;" in html
