"""Tests for AgentOrchestrator."""

from __future__ import annotations

import pytest

from guard.core.agent import ComplianceAgent
from guard.core.orchestrator import AgentOrchestrator


def _make_rule(rule_id: str, pattern: str = "TODO") -> dict:
    return {
        "id": rule_id,
        "name": rule_id.lower(),
        "type": "regex",
        "pattern": pattern,
        "severity": "medium",
        "file_glob": "**/*.py",
    }


class TestAgentOrchestrator:
    def test_two_agents_merge_findings(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO and FIXME\n", encoding="utf-8")
        agent_a = ComplianceAgent("pack-a", [_make_rule("A-001", "TODO")])
        agent_b = ComplianceAgent("pack-b", [_make_rule("B-001", "FIXME")])
        orch = AgentOrchestrator([agent_a, agent_b])

        findings = orch.evaluate(str(tmp_path))

        assert len(findings) >= 2
        rule_ids = {f.rule_id for f in findings}
        assert "A-001" in rule_ids
        assert "B-001" in rule_ids

    def test_agent_results_populated(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO\n", encoding="utf-8")
        agent = ComplianceAgent("solo", [_make_rule("S-001", "TODO")])
        orch = AgentOrchestrator([agent])

        orch.evaluate(str(tmp_path))

        assert len(orch.agent_results) == 1
        assert orch.agent_results[0].pack_id == "solo"
        assert orch.agent_results[0].duration_ms > 0

    def test_deduplication(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO\n", encoding="utf-8")
        # Same rule ID in two agents — should dedup
        agent_a = ComplianceAgent("pack-a", [_make_rule("DUP-001", "TODO")])
        agent_b = ComplianceAgent("pack-b", [_make_rule("DUP-001", "TODO")])
        orch = AgentOrchestrator([agent_a, agent_b])

        findings = orch.evaluate(str(tmp_path))

        dup_findings = [f for f in findings if f.rule_id == "DUP-001"]
        assert len(dup_findings) == 1  # deduped by finding_id

    def test_failure_isolation(self, tmp_path, monkeypatch):
        (tmp_path / "app.py").write_text("# FIXME\n", encoding="utf-8")
        agent_good = ComplianceAgent("good", [_make_rule("G-001", "FIXME")])
        agent_bad = ComplianceAgent("bad", [_make_rule("B-001", "NOPE")])
        monkeypatch.setattr(
            agent_bad._engine, "evaluate",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("crash")),
        )
        orch = AgentOrchestrator([agent_good, agent_bad])

        findings = orch.evaluate(str(tmp_path))

        # Good agent's findings survive
        assert len(findings) >= 1
        assert any(f.rule_id == "G-001" for f in findings)
        # Bad agent recorded error
        bad_result = next(r for r in orch.agent_results if r.pack_id == "bad")
        assert bad_result.error == "crash"

    def test_empty_agents(self):
        orch = AgentOrchestrator([])
        findings = orch.evaluate("/nonexistent")
        assert findings == []
        assert orch.agent_results == []

    def test_single_agent_no_threadpool(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO\n", encoding="utf-8")
        agent = ComplianceAgent("solo", [_make_rule("S-001", "TODO")])
        orch = AgentOrchestrator([agent])

        findings = orch.evaluate(str(tmp_path))

        # Should work identically to direct agent evaluation
        assert len(findings) >= 1
        assert len(orch.agent_results) == 1

    def test_max_concurrency_respected(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO\n", encoding="utf-8")
        agents = [ComplianceAgent(f"p-{i}", [_make_rule(f"R-{i}", "TODO")]) for i in range(5)]
        orch = AgentOrchestrator(agents, max_concurrency=2)

        findings = orch.evaluate(str(tmp_path))

        assert len(orch.agent_results) == 5
        assert orch._max_concurrency == 2

    def test_files_scanned_aggregated(self, tmp_path):
        (tmp_path / "a.py").write_text("# TODO\n", encoding="utf-8")
        (tmp_path / "b.py").write_text("# FIXME\n", encoding="utf-8")
        agent_a = ComplianceAgent("pack-a", [_make_rule("A-001", "TODO")])
        agent_b = ComplianceAgent("pack-b", [_make_rule("B-001", "FIXME")])
        orch = AgentOrchestrator([agent_a, agent_b])

        orch.evaluate(str(tmp_path))

        assert orch.files_scanned >= 2

    def test_max_workers_exposed(self):
        agents = [ComplianceAgent("p", [])]
        orch = AgentOrchestrator(agents, max_concurrency=3)
        assert orch._max_workers == 3
