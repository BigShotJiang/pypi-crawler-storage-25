"""Tests for the trust center page generator."""

from __future__ import annotations

import json

import pytest

from guard.core.models import Evidence, Finding, Severity
from guard.reporters.trust_center import (
    _compute_framework_scores,
    _overall_status,
    generate_trust_center,
    generate_trust_center_json,
)


def _make_finding(
    rule_id: str = "R1",
    severity: str = "medium",
    standard: str | None = "IEC 62304",
    clause: str | None = "5.1",
    is_obligation: bool = False,
) -> Finding:
    return Finding(
        finding_id=f"f-{rule_id}-{severity}",
        rule_id=rule_id,
        severity=Severity(severity),
        message=f"Test finding {rule_id}",
        evidence=Evidence(file="test.py", lines=[1], snippet="x = 1"),
        standard=standard,
        clause=clause,
        is_obligation=is_obligation,
        confidence=1.0,
    )


class TestOverallStatus:
    def test_healthy_above_90(self):
        label, color, icon = _overall_status(95.0)
        assert label == "Healthy"
        assert "4caf50" in color

    def test_needs_attention_70_to_90(self):
        label, _, _ = _overall_status(75.0)
        assert label == "Needs Attention"

    def test_at_risk_below_70(self):
        label, _, _ = _overall_status(50.0)
        assert label == "At Risk"

    def test_boundary_90(self):
        label, _, _ = _overall_status(90.0)
        assert label == "Healthy"

    def test_boundary_70(self):
        label, _, _ = _overall_status(70.0)
        assert label == "Needs Attention"


class TestComputeFrameworkScores:
    def test_single_framework(self):
        findings = [
            _make_finding("R1", "critical", "SOC2"),
            _make_finding("R2", "low", "SOC2"),
            _make_finding("R3", "info", "SOC2", is_obligation=True),
        ]
        scores = _compute_framework_scores(findings)
        assert len(scores) == 1
        assert scores[0]["name"] == "SOC2"
        # 3 unique rules, 2 have code findings (R1, R2), R3 is obligation
        assert scores[0]["rules_total"] == 3
        assert scores[0]["rules_passed"] == 1
        assert scores[0]["obligations"] == 1

    def test_multiple_frameworks(self):
        findings = [
            _make_finding("R1", "high", "IEC 62304"),
            _make_finding("R2", "low", "SOC2"),
        ]
        scores = _compute_framework_scores(findings)
        assert len(scores) == 2
        names = [s["name"] for s in scores]
        assert "IEC 62304" in names
        assert "SOC2" in names

    def test_no_standard_findings_ignored(self):
        findings = [_make_finding("R1", "high", standard=None)]
        scores = _compute_framework_scores(findings)
        assert len(scores) == 0

    def test_all_passing(self):
        findings = [_make_finding("R1", "info", "SOC2", is_obligation=True)]
        scores = _compute_framework_scores(findings)
        assert scores[0]["score"] == 100.0
        assert scores[0]["rules_passed"] == 1

    def test_severity_counts(self):
        findings = [
            _make_finding("R1", "critical", "OWASP"),
            _make_finding("R2", "critical", "OWASP"),
            _make_finding("R3", "low", "OWASP"),
        ]
        scores = _compute_framework_scores(findings)
        assert scores[0]["severity_counts"]["critical"] == 2
        assert scores[0]["severity_counts"]["low"] == 1


class TestGenerateTrustCenter:
    def test_returns_html(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings)
        assert "<!DOCTYPE html>" in html
        assert "Trust Center" in html

    def test_contains_score(self):
        findings = [_make_finding("R1", "critical", "SOC2")]
        html = generate_trust_center(findings, rules_total=10)
        assert "90.0%" in html  # 9/10 passing

    def test_contains_framework_name(self):
        findings = [_make_finding("R1", "high", "IEC 62304")]
        html = generate_trust_center(findings)
        assert "IEC 62304" in html

    def test_org_name_in_header(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings, org_name="Acme Corp")
        assert "Acme Corp" in html

    def test_no_file_paths(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings)
        assert "test.py" not in html

    def test_no_code_snippets(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings)
        assert "x = 1" not in html

    def test_no_finding_messages(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings)
        assert "Test finding" not in html

    def test_empty_findings(self):
        html = generate_trust_center([])
        assert "Trust Center" in html
        assert "No standards frameworks detected" in html

    def test_custom_timestamp(self):
        findings = [_make_finding()]
        html = generate_trust_center(findings, scan_timestamp="2026-03-12T10:00:00Z")
        assert "2026-03-12 10:00:00" in html

    def test_dark_theme_variables(self):
        html = generate_trust_center([_make_finding()])
        assert "--bg:" in html
        assert "--surface:" in html

    def test_sentrik_version(self):
        from guard import __version__
        html = generate_trust_center([_make_finding()])
        assert __version__ in html

    def test_print_friendly(self):
        html = generate_trust_center([_make_finding()])
        assert "@media print" in html

    def test_healthy_status_above_90(self):
        findings = [_make_finding("R1", "low", "SOC2")]
        html = generate_trust_center(findings, rules_total=20)
        assert "Healthy" in html

    def test_at_risk_status_below_70(self):
        findings = [
            _make_finding(f"R{i}", "critical", "SOC2") for i in range(8)
        ]
        html = generate_trust_center(findings, rules_total=10)
        assert "At Risk" in html


class TestGenerateTrustCenterJson:
    def test_returns_dict(self):
        findings = [_make_finding()]
        data = generate_trust_center_json(findings)
        assert isinstance(data, dict)

    def test_overall_score(self):
        findings = [_make_finding("R1", "critical", "SOC2")]
        data = generate_trust_center_json(findings, rules_total=10)
        assert data["overall"]["score"] == 90.0
        assert data["overall"]["rules_passed"] == 9
        assert data["overall"]["rules_total"] == 10

    def test_severity_summary(self):
        findings = [
            _make_finding("R1", "critical"),
            _make_finding("R2", "low"),
        ]
        data = generate_trust_center_json(findings)
        assert data["severity_summary"]["critical"] == 1
        assert data["severity_summary"]["low"] == 1
        assert data["severity_summary"]["high"] == 0

    def test_frameworks_list(self):
        findings = [
            _make_finding("R1", "high", "IEC 62304"),
            _make_finding("R2", "low", "SOC2"),
        ]
        data = generate_trust_center_json(findings)
        assert len(data["frameworks"]) == 2
        names = [fw["name"] for fw in data["frameworks"]]
        assert "IEC 62304" in names
        assert "SOC2" in names

    def test_org_name(self):
        data = generate_trust_center_json([_make_finding()], org_name="TestOrg")
        assert data["org_name"] == "TestOrg"

    def test_status_healthy(self):
        data = generate_trust_center_json([_make_finding()], rules_total=100)
        assert data["overall"]["status"] == "healthy"

    def test_status_at_risk(self):
        findings = [_make_finding(f"R{i}", "critical") for i in range(8)]
        data = generate_trust_center_json(findings, rules_total=10)
        assert data["overall"]["status"] == "at_risk"

    def test_json_serializable(self):
        findings = [_make_finding()]
        data = generate_trust_center_json(findings)
        serialized = json.dumps(data)
        assert isinstance(serialized, str)

    def test_sentrik_version(self):
        from guard import __version__
        data = generate_trust_center_json([_make_finding()])
        assert data["sentrik_version"] == __version__

    def test_no_file_paths_in_json(self):
        findings = [_make_finding()]
        data = generate_trust_center_json(findings)
        serialized = json.dumps(data)
        assert "test.py" not in serialized
