"""Tests for the spec importer (OpenAPI, AsyncAPI, protobuf → Sentrik rules)."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from guard.spec_importer import (
    detect_format,
    import_openapi,
    import_asyncapi,
    import_protobuf,
    import_spec,
    SUPPORTED_FORMATS,
)
from guard.packs.registry import validate_pack_yaml


# ===================================================================
# Fixtures — sample spec files
# ===================================================================


OPENAPI_SPEC = {
    "openapi": "3.0.3",
    "info": {"title": "Pet Store", "version": "1.0.0"},
    "servers": [
        {"url": "http://api.petstore.example.com"},
        {"url": "https://api.petstore.example.com"},
    ],
    "paths": {
        "/pets": {
            "get": {
                "operationId": "listPets",
                "responses": {
                    "200": {
                        "description": "OK",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "id": {"type": "integer"},
                                        "name": {"type": "string"},
                                    },
                                }
                            }
                        },
                    }
                },
            },
            "post": {
                "operationId": "createPet",
                "security": [{"bearerAuth": []}],
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "breed": {"type": "string", "maxLength": 100},
                                },
                            }
                        }
                    }
                },
                "responses": {"201": {"description": "Created"}},
            },
        },
        "/users/{userId}": {
            "get": {
                "operationId": "getUser",
                "security": [{"bearerAuth": []}],
                "parameters": [
                    {"name": "userId", "in": "path", "schema": {"type": "string"}},
                ],
                "responses": {
                    "200": {
                        "description": "OK",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "id": {"type": "string"},
                                        "email": {"type": "string"},
                                        "password_hash": {"type": "string"},
                                        "ssn": {"type": "string"},
                                    },
                                }
                            }
                        },
                    }
                },
            },
        },
    },
    "components": {
        "securitySchemes": {
            "bearerAuth": {"type": "http", "scheme": "bearer"},
        }
    },
}


OPENAPI_SPEC_NO_SECURITY = {
    "openapi": "3.0.3",
    "info": {"title": "Insecure API", "version": "0.1.0"},
    "paths": {
        "/data": {
            "get": {
                "operationId": "getData",
                "responses": {"200": {"description": "OK"}},
            }
        }
    },
}


ASYNCAPI_SPEC = {
    "asyncapi": "2.6.0",
    "info": {"title": "Order Events", "version": "1.0.0"},
    "servers": {
        "production": {"url": "mqtt://broker.example.com", "protocol": "mqtt"},
    },
    "channels": {
        "orders/new": {
            "subscribe": {
                "message": {
                    "payload": {
                        "type": "object",
                        "properties": {
                            "orderId": {"type": "string"},
                            "credit_card_number": {"type": "string"},
                            "amount": {"type": "number"},
                            "notes": {"type": "string"},
                        },
                    }
                }
            }
        },
        "orders/status": {
            "security": [{"apiKey": []}],
            "publish": {
                "message": {
                    "payload": {
                        "type": "object",
                        "properties": {
                            "status": {"type": "string", "enum": ["pending", "shipped"]},
                        },
                    }
                }
            },
        },
    },
}


PROTO_SPEC = """\
syntax = "proto3";

package acme.payments;

message PaymentRequest {
  string transaction_id = 1;
  string credit_card_number = 2;
  double amount = 3;
  string description = 4;
}

message PaymentResponse {
  string transaction_id = 1;
  string status = 2;
  string auth_token = 3;
}

service PaymentService {
  rpc ProcessPayment (PaymentRequest) returns (PaymentResponse);
  rpc RefundPayment (PaymentRequest) returns (PaymentResponse);
}
"""


@pytest.fixture()
def openapi_file(tmp_path):
    p = tmp_path / "petstore.yaml"
    p.write_text(yaml.dump(OPENAPI_SPEC), encoding="utf-8")
    return p


@pytest.fixture()
def openapi_no_security_file(tmp_path):
    p = tmp_path / "insecure.yaml"
    p.write_text(yaml.dump(OPENAPI_SPEC_NO_SECURITY), encoding="utf-8")
    return p


@pytest.fixture()
def asyncapi_file(tmp_path):
    p = tmp_path / "orders.yaml"
    p.write_text(yaml.dump(ASYNCAPI_SPEC), encoding="utf-8")
    return p


@pytest.fixture()
def proto_file(tmp_path):
    p = tmp_path / "payment.proto"
    p.write_text(PROTO_SPEC, encoding="utf-8")
    return p


# ===================================================================
# Format detection
# ===================================================================


class TestDetectFormat:
    def test_openapi_yaml(self, openapi_file):
        assert detect_format(openapi_file) == "openapi"

    def test_asyncapi_yaml(self, asyncapi_file):
        assert detect_format(asyncapi_file) == "asyncapi"

    def test_proto_file(self, proto_file):
        assert detect_format(proto_file) == "protobuf"

    def test_unknown_file(self, tmp_path):
        p = tmp_path / "readme.txt"
        p.write_text("hello world", encoding="utf-8")
        assert detect_format(p) is None

    def test_non_yaml(self, tmp_path):
        p = tmp_path / "data.yaml"
        p.write_text("just a string\n", encoding="utf-8")
        assert detect_format(p) is None


# ===================================================================
# OpenAPI importer
# ===================================================================


class TestOpenAPIImporter:
    def test_generates_pack(self, openapi_file):
        pack = import_openapi(openapi_file)
        assert pack["name"] == "OpenAPI: Pet Store"
        assert "Pet Store" in pack["description"]
        assert len(pack["rules"]) > 0

    def test_pack_validates(self, openapi_file):
        pack = import_openapi(openapi_file)
        errors = validate_pack_yaml(pack)
        assert errors == [], f"Validation errors: {errors}"

    def test_unauthenticated_endpoint_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        auth_rules = [r for r in pack["rules"] if "AUTH" in r["id"]]
        # GET /pets has no security
        listpets_rule = [r for r in auth_rules if "listpets" in r["name"].lower()]
        assert len(listpets_rule) >= 1

    def test_unbounded_string_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        input_rules = [r for r in pack["rules"] if "INPUT" in r["id"]]
        # "name" field in POST /pets has no maxLength
        name_rules = [r for r in input_rules if "name" in r["name"]]
        assert len(name_rules) >= 1

    def test_bounded_string_not_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        input_rules = [r for r in pack["rules"] if "INPUT" in r["id"]]
        # "breed" has maxLength=100, should not be flagged
        breed_rules = [r for r in input_rules if "breed" in r["name"]]
        assert len(breed_rules) == 0

    def test_sensitive_response_field_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        expose_rules = [r for r in pack["rules"] if "EXPOSE" in r["id"]]
        field_names = [r["name"] for r in expose_rules]
        assert any("password" in n for n in field_names)
        assert any("ssn" in n for n in field_names)

    def test_http_server_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        tls_rules = [r for r in pack["rules"] if "TLS" in r["id"]]
        assert len(tls_rules) == 1
        assert tls_rules[0]["type"] == "regex"
        assert tls_rules[0]["severity"] == "high"

    def test_path_param_without_constraints_flagged(self, openapi_file):
        pack = import_openapi(openapi_file)
        param_rules = [r for r in pack["rules"] if "PARAM" in r["id"]]
        userid_rules = [r for r in param_rules if "userid" in r["name"].lower()]
        assert len(userid_rules) >= 1

    def test_no_security_schemes_flagged(self, openapi_no_security_file):
        pack = import_openapi(openapi_no_security_file)
        scheme_rules = [r for r in pack["rules"] if "SCHEME" in r["id"]]
        assert len(scheme_rules) == 1
        assert scheme_rules[0]["severity"] == "high"

    def test_all_rules_have_tags(self, openapi_file):
        pack = import_openapi(openapi_file)
        for r in pack["rules"]:
            assert "spec-import" in r["tags"]
            assert "openapi" in r["tags"]

    def test_rule_ids_unique(self, openapi_file):
        pack = import_openapi(openapi_file)
        ids = [r["id"] for r in pack["rules"]]
        assert len(ids) == len(set(ids))


# ===================================================================
# AsyncAPI importer
# ===================================================================


class TestAsyncAPIImporter:
    def test_generates_pack(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        assert pack["name"] == "AsyncAPI: Order Events"
        assert len(pack["rules"]) > 0

    def test_pack_validates(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        errors = validate_pack_yaml(pack)
        assert errors == [], f"Validation errors: {errors}"

    def test_unauthenticated_channel_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        auth_rules = [r for r in pack["rules"] if "ASYNC-AUTH" in r["id"]]
        # orders/new has no security
        assert any("orders-new" in r["name"] for r in auth_rules)

    def test_authenticated_channel_not_auth_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        auth_rules = [r for r in pack["rules"] if "ASYNC-AUTH" in r["id"]]
        # orders/status has security
        assert not any("orders-status" in r["name"] for r in auth_rules)

    def test_sensitive_payload_field_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        data_rules = [r for r in pack["rules"] if "ASYNC-DATA" in r["id"]]
        assert any("credit-card" in r["name"] or "credit_card" in r["name"] for r in data_rules)

    def test_unbounded_string_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        input_rules = [r for r in pack["rules"] if "ASYNC-INPUT" in r["id"]]
        # "notes" and "orderId" are unbounded strings; "status" has enum
        name_list = [r["name"] for r in input_rules]
        assert any("notes" in n for n in name_list)

    def test_enum_string_not_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        input_rules = [r for r in pack["rules"] if "ASYNC-INPUT" in r["id"]]
        # "status" has enum, should not be flagged
        assert not any("status" in r["name"] for r in input_rules)

    def test_insecure_server_flagged(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        srv_rules = [r for r in pack["rules"] if "ASYNC-SRV" in r["id"]]
        assert len(srv_rules) == 1
        assert "mqtt" in srv_rules[0]["description"]

    def test_rule_ids_unique(self, asyncapi_file):
        pack = import_asyncapi(asyncapi_file)
        ids = [r["id"] for r in pack["rules"]]
        assert len(ids) == len(set(ids))


# ===================================================================
# Protobuf importer
# ===================================================================


class TestProtobufImporter:
    def test_generates_pack(self, proto_file):
        pack = import_protobuf(proto_file)
        assert "acme.payments" in pack["name"]
        assert len(pack["rules"]) > 0

    def test_pack_validates(self, proto_file):
        pack = import_protobuf(proto_file)
        errors = validate_pack_yaml(pack)
        assert errors == [], f"Validation errors: {errors}"

    def test_sensitive_field_flagged(self, proto_file):
        pack = import_protobuf(proto_file)
        data_rules = [r for r in pack["rules"] if "PROTO-DATA" in r["id"]]
        names = [r["name"] for r in data_rules]
        assert any("credit" in n for n in names)
        assert any("auth-token" in n or "auth_token" in n for n in names)

    def test_string_fields_get_validation_rules(self, proto_file):
        pack = import_protobuf(proto_file)
        str_rules = [r for r in pack["rules"] if "PROTO-STR" in r["id"]]
        assert len(str_rules) > 0

    def test_rpc_auth_obligations(self, proto_file):
        pack = import_protobuf(proto_file)
        rpc_rules = [r for r in pack["rules"] if "PROTO-RPC" in r["id"]]
        assert len(rpc_rules) == 2
        names = [r["name"] for r in rpc_rules]
        assert any("processpayment" in n for n in names)
        assert any("refundpayment" in n for n in names)

    def test_rule_ids_unique(self, proto_file):
        pack = import_protobuf(proto_file)
        ids = [r["id"] for r in pack["rules"]]
        assert len(ids) == len(set(ids))


# ===================================================================
# Dispatcher (import_spec)
# ===================================================================


class TestImportSpec:
    def test_auto_detect_openapi(self, openapi_file):
        pack = import_spec(openapi_file)
        assert "OpenAPI" in pack["name"]

    def test_auto_detect_asyncapi(self, asyncapi_file):
        pack = import_spec(asyncapi_file)
        assert "AsyncAPI" in pack["name"]

    def test_auto_detect_protobuf(self, proto_file):
        pack = import_spec(proto_file)
        assert "Protobuf" in pack["name"]

    def test_explicit_format_override(self, openapi_file):
        pack = import_spec(openapi_file, fmt="openapi")
        assert "OpenAPI" in pack["name"]

    def test_unknown_format_raises(self, tmp_path):
        p = tmp_path / "readme.txt"
        p.write_text("not a spec", encoding="utf-8")
        with pytest.raises(ValueError, match="Cannot detect"):
            import_spec(p)

    def test_invalid_format_raises(self, openapi_file):
        with pytest.raises(ValueError, match="Cannot detect"):
            import_spec(openapi_file, fmt="graphql")


# ===================================================================
# Edge cases
# ===================================================================


class TestEdgeCases:
    def test_empty_openapi_paths_with_security(self, tmp_path):
        spec = {
            "openapi": "3.0.3",
            "info": {"title": "Empty", "version": "1.0"},
            "paths": {},
            "components": {"securitySchemes": {"bearer": {"type": "http", "scheme": "bearer"}}},
        }
        p = tmp_path / "empty.yaml"
        p.write_text(yaml.dump(spec), encoding="utf-8")
        pack = import_openapi(p)
        assert len(pack["rules"]) == 0

    def test_empty_openapi_paths_no_security_still_warns(self, tmp_path):
        spec = {"openapi": "3.0.3", "info": {"title": "Empty", "version": "1.0"}, "paths": {}}
        p = tmp_path / "empty.yaml"
        p.write_text(yaml.dump(spec), encoding="utf-8")
        pack = import_openapi(p)
        assert len(pack["rules"]) == 1
        assert "SCHEME" in pack["rules"][0]["id"]

    def test_empty_asyncapi_channels(self, tmp_path):
        spec = {"asyncapi": "2.6.0", "info": {"title": "Empty", "version": "1.0"}, "channels": {}}
        p = tmp_path / "empty.yaml"
        p.write_text(yaml.dump(spec), encoding="utf-8")
        pack = import_asyncapi(p)
        assert len(pack["rules"]) == 0

    def test_empty_proto_file(self, tmp_path):
        p = tmp_path / "empty.proto"
        p.write_text("syntax = \"proto3\";\n", encoding="utf-8")
        pack = import_protobuf(p)
        assert len(pack["rules"]) == 0

    def test_openapi_with_ref(self, tmp_path):
        spec = {
            "openapi": "3.0.3",
            "info": {"title": "Ref Test", "version": "1.0"},
            "paths": {
                "/accounts": {
                    "get": {
                        "operationId": "listAccounts",
                        "responses": {
                            "200": {
                                "description": "OK",
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/Account"}
                                    }
                                },
                            }
                        },
                    }
                }
            },
            "components": {
                "schemas": {
                    "Account": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer"},
                            "bank_account": {"type": "string"},
                        },
                    }
                }
            },
        }
        p = tmp_path / "ref.yaml"
        p.write_text(yaml.dump(spec), encoding="utf-8")
        pack = import_openapi(p)
        expose_rules = [r for r in pack["rules"] if "EXPOSE" in r["id"]]
        assert any("bank-account" in r["name"] or "bank_account" in r["name"] for r in expose_rules)
