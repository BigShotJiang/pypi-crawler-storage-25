"""Shared test helpers and fake providers for AI SDLC Guard tests."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from guard.core.models import Evidence, Finding, Severity, WorkItem
from guard.providers.devops_base import DevOpsProvider
from guard.providers.scanners_base import ScannersProvider
from guard.providers.standards_base import StandardsProvider


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def make_finding(
    fid: str = "F1",
    rule: str = "test-rule",
    sev: Severity = Severity.LOW,
    file: str = "a.py",
    lines: list[int] | None = None,
    msg: str = "Test finding",
    suggestion: str | None = None,
    snippet: str = "",
    deterministic: bool = True,
    confidence: float = 1.0,
    related_work_items: list[str] | None = None,
) -> Finding:
    """Superset finding factory — replaces all per-file ``_finding`` variants."""
    return Finding(
        finding_id=fid,
        rule_id=rule,
        severity=sev,
        message=msg,
        evidence=Evidence(file=file, lines=lines or [], snippet=snippet),
        suggestion=suggestion,
        confidence=confidence,
        deterministic=deterministic,
        related_work_items=related_work_items or [],
    )


def write_file(tmp_path: Path, rel: str, content: str) -> Path:
    """Write *content* to ``tmp_path / rel``, creating parents as needed."""
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Fake providers
# ---------------------------------------------------------------------------


class FakeScanner(ScannersProvider):
    """Scanner that returns pre-configured findings."""

    def __init__(self, findings: list[Finding] | None = None):
        self._findings = findings or []

    def scan(self, repo_root: str, changed_files: list[str] | None = None) -> list[Finding]:
        return list(self._findings)


class FakeDevOps(DevOpsProvider):
    """DevOps provider that returns pre-configured work items."""

    def __init__(self, work_items: list[WorkItem] | None = None):
        self._work_items = work_items or []

    def get_work_items(self, ids: list[str] | None = None) -> list[WorkItem]:
        if ids is not None:
            return [w for w in self._work_items if w.id in ids]
        return list(self._work_items)


class FakeStandards(StandardsProvider):
    """Standards provider that returns pre-configured rules/rule_ids."""

    def __init__(
        self,
        rules: list[dict[str, Any]] | None = None,
        rule_ids: list[str] | None = None,
    ):
        self._rules = rules or []
        self._rule_ids = rule_ids or [r.get("id", "") for r in self._rules]

    def get_rules(self) -> list[dict[str, Any]]:
        return list(self._rules)

    def get_rule_ids(self) -> list[str]:
        return list(self._rule_ids)
