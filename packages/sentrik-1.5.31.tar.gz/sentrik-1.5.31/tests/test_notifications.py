"""Tests for webhook notifications (Slack and Microsoft Teams)."""

from __future__ import annotations

import json
import urllib.error
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from guard.core.notifications import (
    build_slack_payload,
    build_teams_payload,
    notify_gate_failure,
    send_slack_notification,
    send_teams_notification,
    _post_json,
    _severity_breakdown,
    _top_failing_rules,
    _compliance_score,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_gate_result(passed=False, total=5, critical=2, high=1, medium=1, low=1, info=0):
    return SimpleNamespace(
        passed=passed,
        total_findings=total,
        critical=critical,
        high=high,
        medium=medium,
        low=low,
        info=info,
    )


def _make_findings():
    """Return a list of dict findings for testing."""
    return [
        {"rule_id": "SEC-001", "severity": "critical", "message": "Hardcoded secret"},
        {"rule_id": "SEC-001", "severity": "critical", "message": "Hardcoded secret 2"},
        {"rule_id": "SEC-002", "severity": "high", "message": "SQL injection"},
        {"rule_id": "STYLE-001", "severity": "medium", "message": "Long function"},
        {"rule_id": "STYLE-002", "severity": "low", "message": "Missing docstring"},
    ]


def _make_config(slack_url="", teams_url="", notify_on=None):
    notif = {
        "slack_webhook_url": slack_url,
        "teams_webhook_url": teams_url,
        "notify_on": notify_on if notify_on is not None else ["gate_failed"],
    }
    return SimpleNamespace(notifications=notif)


# ---------------------------------------------------------------------------
# Unit tests: helper functions
# ---------------------------------------------------------------------------

class TestSeverityBreakdown:
    def test_extracts_counts(self):
        gr = _make_gate_result()
        result = _severity_breakdown(gr)
        assert result == {"critical": 2, "high": 1, "medium": 1, "low": 1, "info": 0}

    def test_defaults_to_zero(self):
        gr = SimpleNamespace()
        result = _severity_breakdown(gr)
        assert all(v == 0 for v in result.values())


class TestTopFailingRules:
    def test_returns_top_rules(self):
        findings = _make_findings()
        result = _top_failing_rules(findings, limit=3)
        assert len(result) == 2  # SEC-001 (2), SEC-002 (1)
        assert result[0]["rule_id"] == "SEC-001"
        assert result[0]["count"] == 2
        assert result[1]["rule_id"] == "SEC-002"
        assert result[1]["count"] == 1

    def test_limit_applied(self):
        findings = _make_findings()
        result = _top_failing_rules(findings, limit=1)
        assert len(result) == 1

    def test_empty_findings(self):
        result = _top_failing_rules([])
        assert result == []

    def test_no_critical_high(self):
        findings = [{"rule_id": "X", "severity": "low"}]
        result = _top_failing_rules(findings)
        assert result == []

    def test_model_objects(self):
        """Works with objects that have attributes rather than dict keys."""
        f = SimpleNamespace(rule_id="R1", severity="critical")
        result = _top_failing_rules([f])
        assert result == [{"rule_id": "R1", "count": 1}]


class TestComplianceScore:
    def test_empty_findings(self):
        assert _compliance_score([]) == 100.0

    def test_all_critical(self):
        findings = [{"severity": "critical"}, {"severity": "high"}]
        assert _compliance_score(findings) == 0.0

    def test_mixed(self):
        findings = [
            {"severity": "low"},
            {"severity": "info"},
            {"severity": "critical"},
            {"severity": "high"},
        ]
        # 2 out of 4 are low/info => 50%
        assert _compliance_score(findings) == 50.0


# ---------------------------------------------------------------------------
# Slack payload
# ---------------------------------------------------------------------------

class TestSlackPayload:
    def test_structure(self):
        gr = _make_gate_result()
        payload = build_slack_payload(gr, _make_findings())

        assert "blocks" in payload
        blocks = payload["blocks"]
        assert len(blocks) >= 4

        # Header
        assert blocks[0]["type"] == "header"
        assert "Gate Failed" in blocks[0]["text"]["text"]

        # Severity section
        sev_block = blocks[1]
        assert "Critical" in sev_block["text"]["text"]
        assert "Total findings" in sev_block["text"]["text"]

        # Top rules section
        rules_block = blocks[2]
        assert "SEC-001" in rules_block["text"]["text"]

    def test_compliance_score_present(self):
        gr = _make_gate_result()
        payload = build_slack_payload(gr, _make_findings())
        texts = [b.get("text", {}).get("text", "") for b in payload["blocks"]]
        assert any("Compliance score" in t for t in texts)

    def test_view_full_report_present(self):
        gr = _make_gate_result()
        payload = build_slack_payload(gr, _make_findings())
        texts = [b.get("text", {}).get("text", "") for b in payload["blocks"]]
        assert any("View full report" in t for t in texts)

    def test_no_critical_high(self):
        gr = _make_gate_result(critical=0, high=0)
        findings = [{"severity": "medium", "rule_id": "X"}]
        payload = build_slack_payload(gr, findings)
        rules_block = payload["blocks"][2]
        assert "No critical/high findings" in rules_block["text"]["text"]


# ---------------------------------------------------------------------------
# Teams payload
# ---------------------------------------------------------------------------

class TestTeamsPayload:
    def test_adaptive_card_structure(self):
        gr = _make_gate_result()
        payload = build_teams_payload(gr, _make_findings())

        assert payload["type"] == "message"
        assert len(payload["attachments"]) == 1
        card = payload["attachments"][0]
        assert card["contentType"] == "application/vnd.microsoft.card.adaptive"
        content = card["content"]
        assert content["type"] == "AdaptiveCard"
        assert content["version"] == "1.4"

        body = content["body"]
        assert body[0]["type"] == "TextBlock"
        assert "Gate Failed" in body[0]["text"]

    def test_severity_in_body(self):
        gr = _make_gate_result()
        payload = build_teams_payload(gr, _make_findings())
        body = payload["attachments"][0]["content"]["body"]
        all_text = " ".join(item.get("text", "") for item in body)
        assert "Critical" in all_text

    def test_top_rules_in_body(self):
        gr = _make_gate_result()
        payload = build_teams_payload(gr, _make_findings())
        body = payload["attachments"][0]["content"]["body"]
        all_text = " ".join(item.get("text", "") for item in body)
        assert "SEC-001" in all_text

    def test_compliance_score_in_body(self):
        gr = _make_gate_result()
        payload = build_teams_payload(gr, _make_findings())
        body = payload["attachments"][0]["content"]["body"]
        all_text = " ".join(item.get("text", "") for item in body)
        assert "Compliance score" in all_text

    def test_view_report_text(self):
        gr = _make_gate_result()
        payload = build_teams_payload(gr, _make_findings())
        body = payload["attachments"][0]["content"]["body"]
        all_text = " ".join(item.get("text", "") for item in body)
        assert "View full report" in all_text


# ---------------------------------------------------------------------------
# HTTP posting
# ---------------------------------------------------------------------------

class TestPostJson:
    @patch("guard.core.notifications.urllib.request.urlopen")
    def test_success(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        result = _post_json("https://hooks.example.com/test", {"hello": "world"})
        assert result is True
        mock_urlopen.assert_called_once()

        # Verify the request body is JSON
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        assert req.get_header("Content-type") == "application/json"
        body = json.loads(req.data.decode("utf-8"))
        assert body == {"hello": "world"}

    @patch("guard.core.notifications.urllib.request.urlopen")
    def test_http_error(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.HTTPError(
            "https://hooks.example.com/test", 500, "Server Error", {}, None
        )
        result = _post_json("https://hooks.example.com/test", {})
        assert result is False

    @patch("guard.core.notifications.urllib.request.urlopen")
    def test_url_error(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        result = _post_json("https://hooks.example.com/test", {})
        assert result is False

    @patch("guard.core.notifications.urllib.request.urlopen")
    def test_os_error(self, mock_urlopen):
        mock_urlopen.side_effect = OSError("Network unreachable")
        result = _post_json("https://hooks.example.com/test", {})
        assert result is False


# ---------------------------------------------------------------------------
# send_slack_notification / send_teams_notification
# ---------------------------------------------------------------------------

class TestSendSlackNotification:
    @patch("guard.core.notifications._post_json", return_value=True)
    def test_sends_payload(self, mock_post):
        gr = _make_gate_result()
        result = send_slack_notification("https://hooks.slack.com/test", gr, _make_findings())
        assert result is True
        mock_post.assert_called_once()
        url, payload = mock_post.call_args[0]
        assert url == "https://hooks.slack.com/test"
        assert "blocks" in payload

    @patch("guard.core.notifications._post_json", return_value=False)
    def test_returns_false_on_failure(self, mock_post):
        gr = _make_gate_result()
        result = send_slack_notification("https://hooks.slack.com/test", gr, [])
        assert result is False


class TestSendTeamsNotification:
    @patch("guard.core.notifications._post_json", return_value=True)
    def test_sends_payload(self, mock_post):
        gr = _make_gate_result()
        result = send_teams_notification("https://outlook.webhook.office.com/test", gr, _make_findings())
        assert result is True
        mock_post.assert_called_once()
        url, payload = mock_post.call_args[0]
        assert url == "https://outlook.webhook.office.com/test"
        assert payload["type"] == "message"

    @patch("guard.core.notifications._post_json", return_value=False)
    def test_returns_false_on_failure(self, mock_post):
        gr = _make_gate_result()
        result = send_teams_notification("https://outlook.webhook.office.com/test", gr, [])
        assert result is False


# ---------------------------------------------------------------------------
# notify_gate_failure dispatcher
# ---------------------------------------------------------------------------

class TestNotifyGateFailure:
    @patch("guard.core.notifications.send_slack_notification", return_value=True)
    @patch("guard.core.notifications.send_teams_notification", return_value=True)
    def test_dispatches_both(self, mock_teams, mock_slack):
        config = _make_config(
            slack_url="https://hooks.slack.com/s",
            teams_url="https://outlook.webhook.office.com/t",
        )
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"slack": True, "teams": True}
        mock_slack.assert_called_once()
        mock_teams.assert_called_once()

    @patch("guard.core.notifications.send_slack_notification", return_value=True)
    def test_dispatches_slack_only(self, mock_slack):
        config = _make_config(slack_url="https://hooks.slack.com/s")
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"slack": True}

    @patch("guard.core.notifications.send_teams_notification", return_value=True)
    def test_dispatches_teams_only(self, mock_teams):
        config = _make_config(teams_url="https://outlook.webhook.office.com/t")
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"teams": True}

    def test_no_webhooks_configured(self):
        config = _make_config()
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {}

    def test_no_notifications_attribute(self):
        """Config without a notifications attribute should not crash."""
        config = SimpleNamespace()
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {}

    def test_notify_on_empty_list(self):
        """If notify_on doesn't include gate_failed, no notifications sent."""
        config = _make_config(
            slack_url="https://hooks.slack.com/s",
            notify_on=["scan_completed"],
        )
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {}

    @patch("guard.core.notifications.send_slack_notification", return_value=False)
    def test_returns_false_on_delivery_failure(self, mock_slack):
        config = _make_config(slack_url="https://hooks.slack.com/s")
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"slack": False}

    @patch("guard.core.notifications.send_slack_notification", return_value=True)
    def test_env_var_slack(self, mock_slack, monkeypatch):
        """GUARD_SLACK_WEBHOOK_URL env var should be picked up."""
        monkeypatch.setenv("GUARD_SLACK_WEBHOOK_URL", "https://hooks.slack.com/env")
        config = _make_config()  # no URL in config
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"slack": True}
        url_arg = mock_slack.call_args[0][0]
        assert url_arg == "https://hooks.slack.com/env"

    @patch("guard.core.notifications.send_teams_notification", return_value=True)
    def test_env_var_teams(self, mock_teams, monkeypatch):
        """GUARD_TEAMS_WEBHOOK_URL env var should be picked up."""
        monkeypatch.setenv("GUARD_TEAMS_WEBHOOK_URL", "https://outlook.webhook.office.com/env")
        config = _make_config()
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {"teams": True}
        url_arg = mock_teams.call_args[0][0]
        assert url_arg == "https://outlook.webhook.office.com/env"

    def test_notifications_not_dict(self):
        """If notifications is not a dict, should not crash."""
        config = SimpleNamespace(notifications="bad")
        gr = _make_gate_result()
        results = notify_gate_failure(config, gr, _make_findings())
        assert results == {}


# ---------------------------------------------------------------------------
# Config integration
# ---------------------------------------------------------------------------

class TestConfigNotifications:
    def test_default_notifications_field(self):
        from guard.config import GuardConfig
        config = GuardConfig()
        assert isinstance(config.notifications, dict)
        assert config.notifications["slack_webhook_url"] == ""
        assert config.notifications["teams_webhook_url"] == ""
        assert "gate_failed" in config.notifications["notify_on"]

    def test_env_var_override(self, monkeypatch, tmp_path):
        monkeypatch.setenv("GUARD_SLACK_WEBHOOK_URL", "https://hooks.slack.com/from-env")
        monkeypatch.setenv("GUARD_TEAMS_WEBHOOK_URL", "https://outlook.webhook.office.com/from-env")
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        config = GuardConfig.load()
        assert config.notifications["slack_webhook_url"] == "https://hooks.slack.com/from-env"
        assert config.notifications["teams_webhook_url"] == "https://outlook.webhook.office.com/from-env"
