"""Tests for the status reporter module (Phase 26f)."""

from __future__ import annotations

import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.core.models import GateResult
from guard.core.status_reporter import (
    AzureStatusReporter,
    GitHubStatusReporter,
    _detect_commit_sha,
    report_status,
)


# ===================================================================
# GitHubStatusReporter
# ===================================================================


class TestGitHubStatusReporter:
    def test_no_token(self):
        reporter = GitHubStatusReporter(owner="acme", repo="app")
        with patch.dict("os.environ", _home_env(), clear=True):
            result = reporter.report_status(
                GateResult(passed=True, total_findings=0), "abc123",
            )
        assert result is False

    def test_passed(self):
        reporter = GitHubStatusReporter(owner="acme", repo="app")
        mock_resp = MagicMock()
        mock_resp.status = 201
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        gate = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = reporter.report_status(gate, "abc123")

        assert result is True
        req = mock_open.call_args[0][0]
        assert "/check-runs" in req.full_url
        import json
        body = json.loads(req.data.decode("utf-8"))
        assert body["conclusion"] == "success"
        assert body["head_sha"] == "abc123"

    def test_failed(self):
        reporter = GitHubStatusReporter(owner="acme", repo="app")
        mock_resp = MagicMock()
        mock_resp.status = 201
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        gate = GateResult(passed=False, total_findings=3, critical=1, high=2)
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = reporter.report_status(gate, "def456")

        assert result is True
        import json
        body = json.loads(mock_open.call_args[0][0].data.decode("utf-8"))
        assert body["conclusion"] == "failure"

    def test_http_error(self):
        reporter = GitHubStatusReporter(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.HTTPError(
                    "url", 422, "Unprocessable", {}, None,
                )
                result = reporter.report_status(
                    GateResult(passed=True, total_findings=0), "abc123",
                )
        assert result is False


# ===================================================================
# AzureStatusReporter
# ===================================================================


class TestAzureStatusReporter:
    def test_no_pat(self):
        reporter = AzureStatusReporter(org="myorg", project="myproj", repo="myrepo")
        with patch.dict("os.environ", _home_env(), clear=True):
            result = reporter.report_status(
                GateResult(passed=True, total_findings=0), "abc123",
            )
        assert result is False

    def test_passed(self):
        reporter = AzureStatusReporter(org="myorg", project="myproj", repo="myrepo")
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        gate = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "pat123"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = reporter.report_status(gate, "abc123")

        assert result is True
        req = mock_open.call_args[0][0]
        assert "/commits/abc123/statuses" in req.full_url
        import json
        body = json.loads(req.data.decode("utf-8"))
        assert body["state"] == "succeeded"

    def test_failed(self):
        reporter = AzureStatusReporter(org="myorg", project="myproj", repo="myrepo")
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        gate = GateResult(passed=False, total_findings=5, critical=2, high=3)
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "pat123"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = reporter.report_status(gate, "def456")

        assert result is True
        import json
        body = json.loads(mock_open.call_args[0][0].data.decode("utf-8"))
        assert body["state"] == "failed"

    def test_http_error(self):
        reporter = AzureStatusReporter(org="myorg", project="myproj", repo="myrepo")
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "pat123"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.HTTPError(
                    "url", 500, "Server Error", {}, None,
                )
                result = reporter.report_status(
                    GateResult(passed=True, total_findings=0), "abc123",
                )
        assert result is False


# ===================================================================
# _detect_commit_sha
# ===================================================================


class TestDetectCommitSha:
    def test_github_sha(self):
        with patch.dict("os.environ", _home_env(GITHUB_SHA="gh_sha_123"), clear=True):
            assert _detect_commit_sha() == "gh_sha_123"

    def test_azure_sha(self):
        with patch.dict("os.environ", _home_env(BUILD_SOURCEVERSION="az_sha_456"), clear=True):
            assert _detect_commit_sha() == "az_sha_456"

    def test_no_sha(self):
        with patch.dict("os.environ", _home_env(), clear=True):
            assert _detect_commit_sha() is None


# ===================================================================
# report_status (orchestrator)
# ===================================================================


class TestReportStatus:
    def test_no_commit_sha(self):
        """No SHA available → returns False."""
        gate = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", _home_env(), clear=True):
            assert report_status(gate) is False

    def test_github_auto_detect(self):
        """GITHUB_SHA present → GitHubStatusReporter is used."""
        gate = GateResult(passed=True, total_findings=0)
        env = {
            **_home_env(),
            "GITHUB_SHA": "sha123",
            "GUARD_GITHUB_OWNER": "acme",
            "GUARD_GITHUB_REPO": "app",
            "GITHUB_TOKEN": "ghp_test",
        }
        with patch.dict("os.environ", env, clear=True):
            with patch(
                "guard.core.status_reporter.GitHubStatusReporter.report_status",
                return_value=True,
            ) as mock_report:
                assert report_status(gate) is True
        mock_report.assert_called_once_with(gate, "sha123")

    def test_azure_auto_detect(self):
        """BUILD_SOURCEVERSION present → AzureStatusReporter is used."""
        gate = GateResult(passed=False, total_findings=2)
        env = {
            **_home_env(),
            "BUILD_SOURCEVERSION": "azsha789",
            "GUARD_AZURE_DEVOPS_ORG": "myorg",
            "GUARD_AZURE_DEVOPS_PROJECT": "myproj",
            "BUILD_REPOSITORY_NAME": "myrepo",
            "AZURE_DEVOPS_PAT": "pat123",
        }
        with patch.dict("os.environ", env, clear=True):
            with patch(
                "guard.core.status_reporter.AzureStatusReporter.report_status",
                return_value=True,
            ) as mock_report:
                assert report_status(gate) is True
        mock_report.assert_called_once_with(gate, "azsha789")

    def test_missing_config_skips(self):
        """SHA present but no owner/repo → returns False."""
        gate = GateResult(passed=True, total_findings=0)
        env = {**_home_env(), "GITHUB_SHA": "sha123"}
        with patch.dict("os.environ", env, clear=True):
            assert report_status(gate) is False
