"""Tests for the LSP server."""

from __future__ import annotations

import re

import pytest

from guard.lsp_server import (
    _analyze_text,
    _file_matches_glob,
    _load_fast_rules,
    create_lsp_server,
)


class TestFileMatchesGlob:
    def test_simple_match(self):
        assert _file_matches_glob("src/app.py", "**/*.py")

    def test_brace_expansion(self):
        assert _file_matches_glob("src/app.py", "**/*.{py,js}")
        assert _file_matches_glob("src/app.js", "**/*.{py,js}")
        assert not _file_matches_glob("src/app.go", "**/*.{py,js}")

    def test_wildcard(self):
        assert _file_matches_glob("src/app.py", "**/*")

    def test_no_match(self):
        assert not _file_matches_glob("src/app.go", "**/*.py")


class TestLoadFastRules:
    def test_loads_rules(self):
        rules = _load_fast_rules()
        assert isinstance(rules, list)
        # Should have at least some regex rules from enabled packs
        for r in rules:
            assert r.get("type") == "regex"
            assert "_compiled" in r
            assert isinstance(r["_compiled"], re.Pattern)

    def test_cached(self):
        r1 = _load_fast_rules()
        r2 = _load_fast_rules()
        assert r1 is r2  # Same object (cached)


class TestAnalyzeText:
    def test_finds_violations(self):
        # Use a pattern we know exists across most pack configs
        # (hardcoded password pattern from OWASP/HIPAA/etc)
        diagnostics = _analyze_text(
            "file:///src/app.py",
            "password = 'supersecretpassword123'\n",
        )
        # Should find at least one finding if any security pack is enabled
        # If no packs enabled, this gracefully returns empty
        assert isinstance(diagnostics, list)

    def test_clean_code(self):
        diagnostics = _analyze_text(
            "file:///src/clean.py",
            "x = 1 + 2\nprint(x)\n",
        )
        # Should have few or no findings for trivial code
        # (some rules might match 'print' but that's fine)
        assert isinstance(diagnostics, list)

    def test_correct_line_numbers(self):
        diagnostics = _analyze_text(
            "file:///src/app.py",
            "x = 1\ny = 2\nresult = eval('code')\n",
        )
        eval_diags = [d for d in diagnostics if "eval" in d.message.lower()]
        if eval_diags:
            assert eval_diags[0].range.start.line == 2  # 0-indexed

    def test_severity_mapping(self):
        from lsprotocol import types as lsp
        diagnostics = _analyze_text(
            "file:///src/app.py",
            "os.system('rm -rf /')\n",
        )
        # os.system should be critical → Error severity
        os_diags = [d for d in diagnostics if "os.system" in d.message.lower() or "PY-SEC-007" in (d.code or "")]
        if os_diags:
            assert os_diags[0].severity == lsp.DiagnosticSeverity.Error

    def test_glob_filtering(self):
        # Go rules shouldn't fire on .py files
        diagnostics = _analyze_text(
            "file:///src/app.py",
            "InsecureSkipVerify: true\n",
        )
        go_diags = [d for d in diagnostics if "GO-SEC" in (d.code or "")]
        assert len(go_diags) == 0


class TestCreateServer:
    def test_creates_server(self):
        server = create_lsp_server()
        assert server.name == "sentrik-lsp"
