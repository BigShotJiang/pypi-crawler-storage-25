"""Comprehensive tests for diff parser — Phase 2."""

from __future__ import annotations

import subprocess

import pytest

from guard.core.diff_parser import (
    extract_changed_files_from_diff,
    get_changed_files_from_range,
    parse_diff,
)


# ---------------------------------------------------------------------------
# parse_diff — unit tests
# ---------------------------------------------------------------------------

def test_parse_diff_empty_string():
    assert parse_diff("") == []


def test_parse_diff_whitespace_only():
    assert parse_diff("   \n\n  ") == []


SINGLE_FILE_DIFF = """\
diff --git a/src/main.py b/src/main.py
--- a/src/main.py
+++ b/src/main.py
@@ -1,3 +1,4 @@
 import os
+import sys

 def main():
"""


def test_parse_diff_single_file_modification():
    results = parse_diff(SINGLE_FILE_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert fd.old_path == "src/main.py"
    assert fd.new_path == "src/main.py"
    assert fd.path == "src/main.py"
    assert not fd.is_new
    assert not fd.is_deleted
    assert not fd.is_binary
    assert not fd.is_rename
    assert len(fd.hunks) == 1
    hunk = fd.hunks[0]
    assert hunk.src_start == 1
    assert hunk.src_count == 3
    assert hunk.tgt_start == 1
    assert hunk.tgt_count == 4
    assert "+import sys" in hunk.lines


NEW_FILE_DIFF = """\
diff --git a/newfile.py b/newfile.py
--- /dev/null
+++ b/newfile.py
@@ -0,0 +1,2 @@
+# new file
+print("hello")
"""


def test_parse_diff_new_file():
    results = parse_diff(NEW_FILE_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert fd.is_new
    assert not fd.is_deleted
    assert fd.new_path == "newfile.py"
    assert fd.path == "newfile.py"
    assert len(fd.hunks) == 1
    assert any("+" in line for line in fd.hunks[0].lines)


DELETED_FILE_DIFF = """\
diff --git a/old.py b/old.py
--- a/old.py
+++ /dev/null
@@ -1,2 +0,0 @@
-# old file
-print("bye")
"""


def test_parse_diff_deleted_file():
    results = parse_diff(DELETED_FILE_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert fd.is_deleted
    assert not fd.is_new
    assert fd.old_path == "old.py"
    assert len(fd.hunks) == 1


BINARY_DIFF = """\
diff --git a/image.png b/image.png
Binary files a/image.png and b/image.png differ
"""


def test_parse_diff_binary_file():
    results = parse_diff(BINARY_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert fd.is_binary
    assert fd.hunks == []


RENAME_DIFF = """\
diff --git a/old_name.py b/new_name.py
similarity index 100%
rename from old_name.py
rename to new_name.py
"""


def test_parse_diff_renamed_file():
    results = parse_diff(RENAME_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert fd.is_rename
    assert fd.old_path == "old_name.py"
    assert fd.new_path == "new_name.py"
    assert fd.path == "new_name.py"


MULTI_FILE_DIFF = """\
diff --git a/a.py b/a.py
--- a/a.py
+++ b/a.py
@@ -1 +1,2 @@
 x = 1
+y = 2
diff --git a/b.py b/b.py
--- a/b.py
+++ b/b.py
@@ -1 +1,2 @@
 a = 10
+b = 20
"""


def test_parse_diff_multiple_files():
    results = parse_diff(MULTI_FILE_DIFF)
    assert len(results) == 2
    paths = {fd.path for fd in results}
    assert paths == {"a.py", "b.py"}


MULTI_HUNK_DIFF = """\
diff --git a/big.py b/big.py
--- a/big.py
+++ b/big.py
@@ -1,3 +1,4 @@
 line1
+added_top
 line2
 line3
@@ -10,3 +11,4 @@
 line10
+added_bottom
 line11
 line12
"""


def test_parse_diff_multiple_hunks():
    results = parse_diff(MULTI_HUNK_DIFF)
    assert len(results) == 1
    fd = results[0]
    assert len(fd.hunks) == 2
    assert fd.hunks[0].src_start == 1
    assert fd.hunks[1].src_start == 10


# ---------------------------------------------------------------------------
# extract_changed_files_from_diff — unit tests
# ---------------------------------------------------------------------------

def test_extract_changed_files_empty():
    assert extract_changed_files_from_diff("") == []


def test_extract_changed_files_multiple():
    files = extract_changed_files_from_diff(MULTI_FILE_DIFF)
    assert files == ["a.py", "b.py"]


def test_extract_changed_files_deduplicates():
    # A single file diff should return one path, not duplicates
    files = extract_changed_files_from_diff(SINGLE_FILE_DIFF)
    assert files == ["src/main.py"]


# ---------------------------------------------------------------------------
# get_changed_files_from_range — integration tests (real git repos)
# ---------------------------------------------------------------------------

def _init_repo(path):
    """Create a minimal git repo and return the path."""
    subprocess.run(["git", "init"], cwd=str(path), capture_output=True, check=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(path), capture_output=True, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(path), capture_output=True, check=True,
    )
    # Initial commit so HEAD exists
    (path / "init.txt").write_text("init")
    subprocess.run(["git", "add", "."], cwd=str(path), capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=str(path), capture_output=True, check=True,
    )


def test_get_changed_files_single(tmp_path):
    _init_repo(tmp_path)
    (tmp_path / "foo.py").write_text("x = 1")
    subprocess.run(["git", "add", "."], cwd=str(tmp_path), capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "add foo"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    files = get_changed_files_from_range("HEAD~1..HEAD", str(tmp_path))
    assert "foo.py" in files


def test_get_changed_files_multiple(tmp_path):
    _init_repo(tmp_path)
    (tmp_path / "a.py").write_text("a")
    (tmp_path / "b.py").write_text("b")
    subprocess.run(["git", "add", "."], cwd=str(tmp_path), capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "add a and b"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    files = get_changed_files_from_range("HEAD~1..HEAD", str(tmp_path))
    assert set(files) >= {"a.py", "b.py"}


def test_get_changed_files_invalid_range(tmp_path):
    _init_repo(tmp_path)
    with pytest.raises(RuntimeError):
        get_changed_files_from_range("nonexistent..alsonotreal", str(tmp_path))


def test_get_changed_files_empty_range(tmp_path):
    _init_repo(tmp_path)
    files = get_changed_files_from_range("HEAD..HEAD", str(tmp_path))
    assert files == []
