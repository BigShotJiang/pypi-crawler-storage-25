"""Tests for sentrik pull-reqs — pulling requirements from DevOps providers."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from guard.core.models import GeneratedRequirement, WorkItem
from guard.core.pull_reqs import (
    auto_map_files,
    convert_work_items_to_requirements,
    merge_requirements,
    pull_requirements,
)
from guard.providers.devops_stub import DevOpsStub


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def stub_work_items_file(tmp_path: Path) -> Path:
    """Create a temporary work_items.json with sample items."""
    items = [
        {
            "id": "WI-1",
            "title": "Patient data encryption",
            "description": "Encrypt all patient data at rest and in transit",
            "state": "active",
            "devops_id": 101,
        },
        {
            "id": "WI-2",
            "title": "Audit logging module",
            "description": "Implement audit trail for all data access",
            "state": "active",
            "devops_id": 102,
        },
        {
            "id": "WI-3",
            "title": "User authentication",
            "description": "OAuth2 based user authentication",
            "state": "active",
            "devops_id": 103,
        },
    ]
    path = tmp_path / "work_items.json"
    path.write_text(json.dumps(items), encoding="utf-8")
    return path


@pytest.fixture()
def empty_work_items_file(tmp_path: Path) -> Path:
    """Create a temporary empty work_items.json."""
    path = tmp_path / "work_items.json"
    path.write_text("[]", encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPullFromStubProvider:
    """Test pulling work items from the stub provider."""

    def test_pull_from_stub_provider(self, stub_work_items_file: Path, tmp_path: Path):
        """Pull work items from stub provider and write to YAML."""
        devops = DevOpsStub(str(stub_work_items_file))
        output = tmp_path / "requirements.yaml"

        reqs = pull_requirements(
            devops=devops,
            provider="stub",
            output_path=output,
        )

        assert len(reqs) == 3
        assert output.exists()

        # Verify YAML content
        with open(output, encoding="utf-8") as f:
            loaded = yaml.safe_load(f)
        assert "requirements" in loaded
        assert len(loaded["requirements"]) == 3

    def test_empty_provider(self, empty_work_items_file: Path, tmp_path: Path):
        """No work items returns empty list."""
        devops = DevOpsStub(str(empty_work_items_file))
        output = tmp_path / "requirements.yaml"

        reqs = pull_requirements(
            devops=devops,
            provider="stub",
            output_path=output,
        )

        assert reqs == []
        assert not output.exists()


class TestConvertToRequirements:
    """Test WorkItem -> GeneratedRequirement conversion."""

    def test_convert_to_requirements(self):
        """WorkItem objects are mapped to GeneratedRequirements with correct IDs."""
        work_items = [
            WorkItem(id="WI-1", title="Patient data encryption",
                     description="Encrypt PII", devops_id=123),
            WorkItem(id="WI-2", title="Audit logging",
                     description="Log all access", devops_id=456),
        ]

        reqs = convert_work_items_to_requirements(work_items, "azure")

        assert len(reqs) == 2
        assert reqs[0].req_id == "ADO-123"
        assert reqs[0].title == "Patient data encryption"
        assert reqs[0].description == "Encrypt PII"
        assert reqs[0].devops_id == 123
        assert reqs[0].status == "draft"
        assert reqs[0].source_files == []

        assert reqs[1].req_id == "ADO-456"

    def test_convert_github_prefix(self):
        """GitHub work items get GH- prefix."""
        work_items = [
            WorkItem(id="42", title="Fix login bug", devops_id=42),
        ]
        reqs = convert_work_items_to_requirements(work_items, "github")
        assert reqs[0].req_id == "GH-42"

    def test_convert_jira_prefix(self):
        """Jira work items get JIRA- prefix."""
        work_items = [
            WorkItem(id="PROJ-67", title="Add dashboard", devops_id="PROJ-67"),
        ]
        reqs = convert_work_items_to_requirements(work_items, "jira")
        assert reqs[0].req_id == "JIRA-PROJ-67"

    def test_convert_preserves_acceptance_criteria(self):
        """Acceptance criteria from work items are preserved."""
        work_items = [
            WorkItem(id="WI-1", title="Feature X", devops_id=1,
                     acceptance_criteria=["Criterion A", "Criterion B"]),
        ]
        reqs = convert_work_items_to_requirements(work_items, "azure")
        assert reqs[0].acceptance_criteria == ["Criterion A", "Criterion B"]

    def test_convert_no_devops_id_falls_back_to_id(self):
        """When devops_id is None, use the work item id for req_id."""
        work_items = [
            WorkItem(id="WI-99", title="Some task"),
        ]
        reqs = convert_work_items_to_requirements(work_items, "azure")
        assert reqs[0].req_id == "ADO-WI-99"


class TestAutoMapFiles:
    """Test auto-mapping of source files to requirements."""

    def test_auto_map_files(self):
        """Title tokens match filenames and set source_files."""
        reqs = [
            GeneratedRequirement(
                req_id="ADO-1", title="Patient data encryption",
                description="Encrypt PII",
            ),
            GeneratedRequirement(
                req_id="ADO-2", title="Audit logging module",
                description="Log access",
            ),
        ]
        source_files = [
            "src/patient_data.py",
            "src/encryption.py",
            "src/audit.py",
            "src/main.py",
        ]

        mapped = auto_map_files(reqs, source_files)

        # "patient" matches patient_data.py, "encryption" matches encryption.py
        assert "src/patient_data.py" in mapped[0].source_files
        assert "src/encryption.py" in mapped[0].source_files

        # "audit" matches audit.py
        assert "src/audit.py" in mapped[1].source_files

    def test_auto_map_no_match(self):
        """Requirements with no matching files keep empty source_files."""
        reqs = [
            GeneratedRequirement(
                req_id="ADO-1", title="Deploy to cloud",
                description="Cloud deployment",
            ),
        ]
        source_files = ["src/main.py", "src/utils.py"]

        mapped = auto_map_files(reqs, source_files)
        assert mapped[0].source_files == []

    def test_auto_map_short_tokens_ignored(self):
        """Tokens shorter than min_token_length are ignored."""
        reqs = [
            GeneratedRequirement(
                req_id="ADO-1", title="Do it now",
                description="Short tokens",
            ),
        ]
        # "do", "it" are < 3 chars, "now" is 3 chars
        source_files = ["src/do.py", "src/now.py"]

        mapped = auto_map_files(reqs, source_files)
        # "now" matches now.py
        assert "src/now.py" in mapped[0].source_files


class TestMergeRequirements:
    """Test merging incoming requirements with existing ones."""

    def test_merge_preserves_existing(self):
        """Existing source_files are not overwritten when merging."""
        existing = [
            GeneratedRequirement(
                req_id="ADO-101", title="Old title",
                description="Old desc", devops_id=101,
                source_files=["src/patient.py"],
                status="approved",
            ),
        ]
        incoming = [
            GeneratedRequirement(
                req_id="ADO-101", title="Updated title",
                description="Updated desc", devops_id=101,
            ),
        ]

        merged = merge_requirements(existing, incoming)

        assert len(merged) == 1
        assert merged[0].title == "Updated title"
        assert merged[0].description == "Updated desc"
        # source_files preserved from existing
        assert merged[0].source_files == ["src/patient.py"]
        # status preserved from existing
        assert merged[0].status == "approved"

    def test_merge_adds_new(self):
        """New DevOps items are appended to the list."""
        existing = [
            GeneratedRequirement(
                req_id="ADO-101", title="Existing",
                devops_id=101,
            ),
        ]
        incoming = [
            GeneratedRequirement(
                req_id="ADO-101", title="Existing updated",
                devops_id=101,
            ),
            GeneratedRequirement(
                req_id="ADO-202", title="Brand new",
                devops_id=202,
            ),
        ]

        merged = merge_requirements(existing, incoming)

        assert len(merged) == 2
        assert merged[0].req_id == "ADO-101"
        assert merged[0].title == "Existing updated"
        assert merged[1].req_id == "ADO-202"
        assert merged[1].title == "Brand new"

    def test_merge_updates_title(self):
        """Changed titles are updated in existing entries."""
        existing = [
            GeneratedRequirement(
                req_id="GH-10", title="Original title",
                description="Original desc", devops_id=10,
            ),
        ]
        incoming = [
            GeneratedRequirement(
                req_id="GH-10", title="Renamed feature",
                description="New description", devops_id=10,
            ),
        ]

        merged = merge_requirements(existing, incoming)

        assert len(merged) == 1
        assert merged[0].title == "Renamed feature"
        assert merged[0].description == "New description"


class TestCLIPullReqs:
    """Test the CLI pull-reqs command."""

    def test_cli_pull_reqs(self, stub_work_items_file: Path, tmp_path: Path):
        """CLI command produces output file with requirements."""
        from typer.testing import CliRunner
        from guard.cli import app

        output = tmp_path / "pulled.yaml"
        runner = CliRunner()

        # Override the config to use stub provider with our file
        result = runner.invoke(app, [
            "pull-reqs",
            "--provider", "stub",
            "--output", str(output),
        ])

        # Stub provider with default work_items file might not have items,
        # so we just verify the command runs without crashing
        assert result.exit_code in (0, 1)  # 1 if no provider configured

    def test_cli_pull_reqs_no_provider(self):
        """CLI errors when no provider is configured."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["pull-reqs"])

        # Should fail with exit code 1 since default is stub
        assert result.exit_code == 1
        assert "No DevOps provider" in result.output


class TestPullRequirementsIntegration:
    """Integration tests for pull_requirements with merge and map."""

    def test_pull_with_merge(self, stub_work_items_file: Path, tmp_path: Path):
        """Merge mode preserves existing entries and adds new ones."""
        output = tmp_path / "requirements.yaml"

        # Write an initial file with a manually-edited entry
        existing_data = {
            "generated_at": "2026-01-01T00:00:00Z",
            "requirements": [
                {
                    "req_id": "STUB-101",
                    "title": "Old patient encryption title",
                    "description": "Manual desc",
                    "source_files": ["src/crypto.py"],
                    "status": "approved",
                    "devops_id": 101,
                },
            ],
        }
        with open(output, "w", encoding="utf-8") as f:
            yaml.dump(existing_data, f)

        devops = DevOpsStub(str(stub_work_items_file))
        reqs = pull_requirements(
            devops=devops,
            provider="stub",
            output_path=output,
            merge=True,
        )

        # Should have 3 total: 1 updated existing + 2 new
        assert len(reqs) == 3

        # Existing entry should have updated title but preserved source_files
        existing_req = next(r for r in reqs if r.devops_id == 101)
        assert existing_req.title == "Patient data encryption"  # updated
        assert existing_req.source_files == ["src/crypto.py"]  # preserved
        assert existing_req.status == "approved"  # preserved

    def test_pull_with_map_files(self, stub_work_items_file: Path, tmp_path: Path):
        """Map-files mode auto-maps source files to requirements."""
        # Create some source files to match against
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "patient_data.py").write_text("# patient data")
        (src_dir / "audit.py").write_text("# audit")
        (src_dir / "main.py").write_text("# main")

        output = tmp_path / "requirements.yaml"
        devops = DevOpsStub(str(stub_work_items_file))

        source_files = [
            "src/patient_data.py",
            "src/audit.py",
            "src/main.py",
        ]

        reqs = pull_requirements(
            devops=devops,
            provider="stub",
            output_path=output,
            map_files=True,
            source_files=source_files,
        )

        assert len(reqs) == 3

        # "Patient data encryption" should match patient_data.py
        patient_req = next(r for r in reqs if r.devops_id == 101)
        assert "src/patient_data.py" in patient_req.source_files

        # "Audit logging module" should match audit.py
        audit_req = next(r for r in reqs if r.devops_id == 102)
        assert "src/audit.py" in audit_req.source_files
