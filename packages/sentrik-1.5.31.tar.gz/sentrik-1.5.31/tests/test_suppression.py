"""Tests for finding suppression module."""

from __future__ import annotations

from datetime import date, timedelta

import pytest

from guard.core.models import Evidence, Finding, Severity
from guard.core.suppression import filter_suppressed, is_suppressed


def _make_finding(
    rule_id: str = "RULE-001",
    file: str = "src/app.py",
    severity: Severity = Severity.HIGH,
    message: str = "Test finding",
) -> Finding:
    return Finding(
        finding_id=f"F-{rule_id}",
        rule_id=rule_id,
        severity=severity,
        message=message,
        evidence=Evidence(file=file, lines=[10]),
        confidence=0.9,
        deterministic=True,
    )


class TestIsSuppressed:
    def test_exact_rule_match(self):
        f = _make_finding(rule_id="RULE-001")
        assert is_suppressed(f, {"rule_id": "RULE-001"}) is True

    def test_rule_glob_match(self):
        f = _make_finding(rule_id="RULE-001")
        assert is_suppressed(f, {"rule_id": "RULE-*"}) is True

    def test_rule_no_match(self):
        f = _make_finding(rule_id="RULE-001")
        assert is_suppressed(f, {"rule_id": "RULE-999"}) is False

    def test_file_glob_match(self):
        f = _make_finding(file="src/app.py")
        assert is_suppressed(f, {"rule_id": "RULE-001", "file_pattern": "src/*.py"}) is True

    def test_file_glob_no_match(self):
        f = _make_finding(file="tests/test_app.py")
        assert is_suppressed(f, {"rule_id": "RULE-001", "file_pattern": "src/*.py"}) is False

    def test_expired_suppression(self):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        f = _make_finding()
        assert is_suppressed(f, {"rule_id": "RULE-001", "expires": yesterday}) is False

    def test_not_yet_expired(self):
        tomorrow = (date.today() + timedelta(days=1)).isoformat()
        f = _make_finding()
        assert is_suppressed(f, {"rule_id": "RULE-001", "expires": tomorrow}) is True

    def test_empty_rule_id(self):
        f = _make_finding()
        assert is_suppressed(f, {"rule_id": ""}) is False

    def test_both_rule_and_file_must_match(self):
        f = _make_finding(rule_id="RULE-001", file="src/app.py")
        assert is_suppressed(f, {"rule_id": "RULE-001", "file_pattern": "tests/*"}) is False

    def test_invalid_expiry_treated_as_active(self):
        f = _make_finding()
        assert is_suppressed(f, {"rule_id": "RULE-001", "expires": "not-a-date"}) is True


class TestFilterSuppressed:
    def test_empty_suppressions_returns_all(self):
        findings = [_make_finding(), _make_finding(rule_id="RULE-002")]
        active, suppressed = filter_suppressed(findings, [])
        assert len(active) == 2
        assert len(suppressed) == 0

    def test_one_suppressed(self):
        findings = [
            _make_finding(rule_id="RULE-001"),
            _make_finding(rule_id="RULE-002"),
        ]
        active, suppressed = filter_suppressed(findings, [{"rule_id": "RULE-001"}])
        assert len(active) == 1
        assert active[0].rule_id == "RULE-002"
        assert len(suppressed) == 1
        assert suppressed[0].rule_id == "RULE-001"

    def test_glob_suppresses_multiple(self):
        findings = [
            _make_finding(rule_id="SEC-001"),
            _make_finding(rule_id="SEC-002"),
            _make_finding(rule_id="RULE-001"),
        ]
        active, suppressed = filter_suppressed(findings, [{"rule_id": "SEC-*"}])
        assert len(active) == 1
        assert len(suppressed) == 2

    def test_all_suppressed(self):
        findings = [_make_finding(rule_id="RULE-001")]
        active, suppressed = filter_suppressed(findings, [{"rule_id": "*"}])
        assert len(active) == 0
        assert len(suppressed) == 1
