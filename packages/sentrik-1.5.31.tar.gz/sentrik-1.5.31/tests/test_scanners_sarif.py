"""Comprehensive tests for ScannersSarif (Phase 7)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from guard.core.models import Severity
from guard.providers.scanners_sarif import ScannersSarif


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_sarif(tmp_path: Path, filename: str, data: dict) -> Path:
    p = tmp_path / filename
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def _minimal_sarif(
    tool_name: str = "test-tool",
    results: list[dict] | None = None,
) -> dict:
    """Build a minimal valid SARIF 2.1.0 document."""
    return {
        "version": "2.1.0",
        "runs": [
            {
                "tool": {"driver": {"name": tool_name}},
                "results": results or [],
            }
        ],
    }


def _result(
    rule_id: str = "R1",
    level: str = "warning",
    message: str = "Issue found",
    uri: str = "app.py",
    line: int = 1,
    snippet: str = "",
) -> dict:
    """Build a SARIF result object."""
    region: dict = {"startLine": line}
    if snippet:
        region["snippet"] = {"text": snippet}
    return {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": message},
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {"uri": uri},
                    "region": region,
                }
            }
        ],
    }


# ===================================================================
# Basic parsing
# ===================================================================


class TestBasicParsing:
    def test_single_result(self, tmp_path):
        sarif = _minimal_sarif(results=[_result()])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "R1"
        assert f.severity == Severity.MEDIUM  # "warning" → medium
        assert f.message == "Issue found"
        assert f.evidence.file == "app.py"
        assert f.evidence.lines == [1]
        assert f.deterministic is True
        assert f.confidence == 0.9

    def test_multiple_results(self, tmp_path):
        results = [
            _result(rule_id="R1", uri="a.py", line=1),
            _result(rule_id="R2", uri="b.py", line=5),
        ]
        sarif = _minimal_sarif(results=results)
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path))

        assert len(findings) == 2
        rule_ids = {f.rule_id for f in findings}
        assert rule_ids == {"R1", "R2"}

    def test_empty_results(self, tmp_path):
        sarif = _minimal_sarif(results=[])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        assert scanner.scan(str(tmp_path)) == []

    def test_no_runs(self, tmp_path):
        sarif = {"version": "2.1.0", "runs": []}
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        assert scanner.scan(str(tmp_path)) == []


# ===================================================================
# Severity mapping
# ===================================================================


class TestSeverityMapping:
    def test_error_maps_to_high(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(level="error")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].severity == Severity.HIGH

    def test_warning_maps_to_medium(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(level="warning")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].severity == Severity.MEDIUM

    def test_note_maps_to_low(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(level="note")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].severity == Severity.LOW

    def test_none_maps_to_info(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(level="none")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].severity == Severity.INFO

    def test_unknown_level_defaults_to_medium(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(level="banana")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].severity == Severity.MEDIUM


# ===================================================================
# Tool name extraction
# ===================================================================


class TestToolName:
    def test_tool_name_in_finding_id(self, tmp_path):
        sarif = _minimal_sarif(tool_name="bandit", results=[_result()])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert "bandit" in findings[0].finding_id

    def test_missing_driver_name(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [{"tool": {"driver": {}}, "results": [_result()]}],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert "unknown-tool" in findings[0].finding_id

    def test_missing_tool_entirely(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [{"results": [_result()]}],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert "unknown-tool" in findings[0].finding_id


# ===================================================================
# Location extraction
# ===================================================================


class TestLocationExtraction:
    def test_full_location(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(uri="src/main.py", line=42)])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].evidence.file == "src/main.py"
        assert findings[0].evidence.lines == [42]

    def test_no_locations(self, tmp_path):
        result = {"ruleId": "R1", "level": "warning", "message": {"text": "x"}}
        sarif = _minimal_sarif(results=[result])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].evidence.file == "unknown"
        assert findings[0].evidence.lines == []

    def test_no_region(self, tmp_path):
        result = {
            "ruleId": "R1",
            "level": "warning",
            "message": {"text": "x"},
            "locations": [
                {"physicalLocation": {"artifactLocation": {"uri": "app.py"}}}
            ],
        }
        sarif = _minimal_sarif(results=[result])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].evidence.file == "app.py"
        assert findings[0].evidence.lines == []

    def test_snippet_extracted(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(snippet="x = eval(input())")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].evidence.snippet == "x = eval(input())"


# ===================================================================
# Changed files scoping
# ===================================================================


class TestChangedFilesScoping:
    def test_scoped_to_changed_files(self, tmp_path):
        results = [
            _result(rule_id="R1", uri="a.py"),
            _result(rule_id="R2", uri="b.py"),
        ]
        sarif = _minimal_sarif(results=results)
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path), changed_files=["a.py"])
        assert len(findings) == 1
        assert findings[0].rule_id == "R1"

    def test_no_changed_files_returns_all(self, tmp_path):
        results = [
            _result(rule_id="R1", uri="a.py"),
            _result(rule_id="R2", uri="b.py"),
        ]
        sarif = _minimal_sarif(results=results)
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path), changed_files=None)
        assert len(findings) == 2

    def test_empty_changed_files_returns_none(self, tmp_path):
        sarif = _minimal_sarif(results=[_result()])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path), changed_files=[])
        assert findings == []

    def test_forward_slash_normalization(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(uri="src\\app.py")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        findings = scanner.scan(str(tmp_path), changed_files=["src/app.py"])
        assert len(findings) == 1


# ===================================================================
# Multiple SARIF files
# ===================================================================


class TestMultipleSarifFiles:
    def test_reads_multiple_files(self, tmp_path):
        sarif1 = _minimal_sarif(tool_name="tool-a", results=[_result(rule_id="A1")])
        sarif2 = _minimal_sarif(tool_name="tool-b", results=[_result(rule_id="B1")])
        p1 = _write_sarif(tmp_path, "a.sarif", sarif1)
        p2 = _write_sarif(tmp_path, "b.sarif", sarif2)

        scanner = ScannersSarif([str(p1), str(p2)])
        findings = scanner.scan(str(tmp_path))
        rule_ids = {f.rule_id for f in findings}
        assert rule_ids == {"A1", "B1"}

    def test_empty_sarif_files_list(self):
        scanner = ScannersSarif([])
        assert scanner.scan("/tmp") == []


# ===================================================================
# Error handling
# ===================================================================


class TestErrorHandling:
    def test_missing_file_skipped(self, tmp_path):
        scanner = ScannersSarif([str(tmp_path / "nonexistent.sarif")])
        assert scanner.scan(str(tmp_path)) == []

    def test_invalid_json_skipped(self, tmp_path):
        bad = tmp_path / "bad.sarif"
        bad.write_text("not json!", encoding="utf-8")
        scanner = ScannersSarif([str(bad)])
        assert scanner.scan(str(tmp_path)) == []

    def test_non_object_json_skipped(self, tmp_path):
        bad = tmp_path / "bad.sarif"
        bad.write_text("[1, 2, 3]", encoding="utf-8")
        scanner = ScannersSarif([str(bad)])
        assert scanner.scan(str(tmp_path)) == []

    def test_non_list_runs_skipped(self, tmp_path):
        sarif = {"version": "2.1.0", "runs": "not a list"}
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        scanner = ScannersSarif([str(path)])
        assert scanner.scan(str(tmp_path)) == []

    def test_non_dict_result_skipped(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {"driver": {"name": "t"}},
                    "results": ["not a dict", _result()],
                }
            ],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert len(findings) == 1

    def test_non_dict_run_skipped(self, tmp_path):
        sarif = {"version": "2.1.0", "runs": ["not a dict"]}
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        assert ScannersSarif([str(path)]).scan(str(tmp_path)) == []

    def test_non_list_results_skipped(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "t"}}, "results": "bad"}],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        assert ScannersSarif([str(path)]).scan(str(tmp_path)) == []

    def test_good_file_after_bad_file(self, tmp_path):
        bad = tmp_path / "bad.sarif"
        bad.write_text("not json!", encoding="utf-8")
        good = _write_sarif(
            tmp_path, "good.sarif",
            _minimal_sarif(results=[_result()]),
        )
        scanner = ScannersSarif([str(bad), str(good)])
        findings = scanner.scan(str(tmp_path))
        assert len(findings) == 1


# ===================================================================
# Message extraction
# ===================================================================


class TestMessageExtraction:
    def test_message_text(self, tmp_path):
        sarif = _minimal_sarif(results=[_result(message="Custom msg")])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].message == "Custom msg"

    def test_non_dict_message(self, tmp_path):
        result = {
            "ruleId": "R1",
            "level": "warning",
            "message": "plain string",
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": "app.py"},
                        "region": {"startLine": 1},
                    }
                }
            ],
        }
        sarif = _minimal_sarif(results=[result])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].message == "plain string"

    def test_missing_rule_id_defaults(self, tmp_path):
        result = {
            "level": "warning",
            "message": {"text": "Issue"},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": "app.py"},
                        "region": {"startLine": 1},
                    }
                }
            ],
        }
        sarif = _minimal_sarif(tool_name="mytool", results=[result])
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        assert findings[0].rule_id == "mytool-0"


# ===================================================================
# Multiple runs
# ===================================================================


class TestMultipleRuns:
    def test_findings_from_multiple_runs(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {"driver": {"name": "tool-a"}},
                    "results": [_result(rule_id="A1")],
                },
                {
                    "tool": {"driver": {"name": "tool-b"}},
                    "results": [_result(rule_id="B1")],
                },
            ],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        rule_ids = {f.rule_id for f in findings}
        assert rule_ids == {"A1", "B1"}

    def test_finding_ids_unique_across_runs(self, tmp_path):
        sarif = {
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {"driver": {"name": "t"}},
                    "results": [_result(rule_id="R1")],
                },
                {
                    "tool": {"driver": {"name": "t"}},
                    "results": [_result(rule_id="R1")],
                },
            ],
        }
        path = _write_sarif(tmp_path, "r.sarif", sarif)
        findings = ScannersSarif([str(path)]).scan(str(tmp_path))
        ids = [f.finding_id for f in findings]
        assert len(ids) == len(set(ids))  # all unique
