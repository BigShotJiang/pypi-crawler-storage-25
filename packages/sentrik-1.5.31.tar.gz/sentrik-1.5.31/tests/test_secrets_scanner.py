"""Tests for the dedicated secrets scanner."""

from pathlib import Path

from guard.core.secrets_scanner import (
    SecretFinding,
    SecretsScanResult,
    _redact,
    _shannon_entropy,
    scan_directory,
    scan_file,
)


class TestEntropy:
    def test_low_entropy(self):
        assert _shannon_entropy("aaaaaaaaaa") < 1.0

    def test_high_entropy(self):
        assert _shannon_entropy("aB3$xZ9!kL2@mN5&") > 3.5

    def test_empty(self):
        assert _shannon_entropy("") == 0.0


class TestRedact:
    def test_long_secret(self):
        assert _redact("sk_live_1234567890abcdef") == "sk_l****cdef"

    def test_short_secret(self):
        assert _redact("AKIA1234") == "AKIA****"


class TestScanFile:
    def test_aws_access_key(self, tmp_path):
        f = tmp_path / "config.py"
        f.write_text('AWS_KEY = "AKIAIOSFODNN7XYZABCD"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-AWS-KEY"
        assert findings[0].severity == "critical"

    def test_github_pat(self, tmp_path):
        f = tmp_path / "auth.py"
        f.write_text('token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-GH-PAT"

    def test_stripe_live_key(self, tmp_path):
        f = tmp_path / "billing.py"
        f.write_text('STRIPE_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-STRIPE-LIVE"
        assert findings[0].severity == "critical"

    def test_stripe_test_key_is_medium(self, tmp_path):
        f = tmp_path / "billing.py"
        f.write_text('STRIPE_KEY = "sk_test_4eC39HqLyjWDarjtT1zdp7dc"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].severity == "medium"

    def test_private_key(self, tmp_path):
        f = tmp_path / "key.pem"
        f.write_text("-----BEGIN RSA PRIVATE KEY-----\nMIIEpA...\n-----END RSA PRIVATE KEY-----\n")
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-PRIVATE-KEY"

    def test_database_uri(self, tmp_path):
        f = tmp_path / "settings.py"
        f.write_text('DB_URL = "postgres://admin:s3cret@db.internal.io:5432/mydb"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-DB-URI"

    def test_no_false_positive_on_example(self, tmp_path):
        f = tmp_path / "docs.py"
        f.write_text('# Example: api_key = "your_api_key_here"\n')
        findings = scan_file(f)
        assert len(findings) == 0

    def test_no_false_positive_on_placeholder(self, tmp_path):
        f = tmp_path / "config.py"
        f.write_text('api_key = "REPLACE_ME_WITH_REAL_KEY"\n')
        findings = scan_file(f)
        assert len(findings) == 0

    def test_clean_file(self, tmp_path):
        f = tmp_path / "app.py"
        f.write_text("import os\napi_key = os.getenv('API_KEY')\nprint('hello')\n")
        findings = scan_file(f)
        assert len(findings) == 0

    def test_skips_binary_files(self, tmp_path):
        f = tmp_path / "image.png"
        f.write_bytes(b"\x89PNG\r\n\x1a\nfake")
        findings = scan_file(f)
        assert len(findings) == 0

    def test_skips_lock_files(self, tmp_path):
        f = tmp_path / "package-lock.json"
        f.write_text('{"resolved": "https://registry.npmjs.org/foo"}\n')
        findings = scan_file(f)
        assert len(findings) == 0

    def test_slack_webhook(self, tmp_path):
        f = tmp_path / "notify.py"
        f.write_text('WEBHOOK = "https://hooks.slack.com/services/T0000/B0000/abcdefghijklmnop"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-SLACK-WEBHOOK"

    def test_hardcoded_password(self, tmp_path):
        f = tmp_path / "auth.py"
        f.write_text('password = "SuperS3cretP@ssw0rd!"\n')
        findings = scan_file(f)
        assert len(findings) >= 1
        assert findings[0].rule == "SECRET-PASSWORD"


class TestScanDirectory:
    def test_scans_multiple_files(self, tmp_path):
        (tmp_path / "a.py").write_text('AWS_KEY = "AKIAIOSFODNN7XYZABCD"\n')
        (tmp_path / "b.py").write_text("import os\n")
        result = scan_directory(tmp_path)
        assert result.files_scanned >= 2
        assert len(result.findings) >= 1

    def test_skips_hidden_dirs(self, tmp_path):
        hidden = tmp_path / ".git"
        hidden.mkdir()
        (hidden / "config").write_text('token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij"\n')
        (tmp_path / "app.py").write_text("x = 1\n")
        result = scan_directory(tmp_path)
        assert len(result.findings) == 0

    def test_respects_excludes(self, tmp_path):
        (tmp_path / "vendor.py").write_text('key = "AKIAIOSFODNN7XYZABCD"\n')
        result = scan_directory(tmp_path, excludes=["vendor*"])
        assert len(result.findings) == 0

    def test_to_dict(self, tmp_path):
        (tmp_path / "a.py").write_text('key = "AKIAIOSFODNN7XYZABCD"\n')
        result = scan_directory(tmp_path)
        d = result.to_dict()
        assert "findings_count" in d
        assert "by_severity" in d
        assert "findings" in d

    def test_sorted_by_severity(self, tmp_path):
        (tmp_path / "a.py").write_text('key = "sk_test_4eC39HqLyjWDarjtT1zdp7dc"\n')
        (tmp_path / "b.py").write_text('key = "AKIAIOSFODNN7XYZABCD"\n')
        result = scan_directory(tmp_path)
        if len(result.findings) >= 2:
            sev_order = {"critical": 0, "high": 1, "medium": 2}
            for i in range(len(result.findings) - 1):
                assert sev_order.get(result.findings[i].severity, 3) <= sev_order.get(result.findings[i + 1].severity, 3)
