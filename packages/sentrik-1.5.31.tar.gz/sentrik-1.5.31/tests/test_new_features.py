"""Tests for new features: threat modeler, new API endpoints, quality scorer,
expertise tracker, design reviewer, and project profile."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient

from guard.core.threat_modeler import (
    Threat,
    format_threats,
    save_threats,
    load_threats,
    mitigate_threat,
    generate_threat_model,
)
from guard.core.quality_scorer import (
    DimensionScore,
    QualityScore,
    score_compliance,
    score_complexity,
    score_test_coverage,
    score_documentation,
    score_consistency,
    score_dependency_health,
    calculate_quality_score,
    format_quality_report,
)
from guard.core.expertise_tracker import (
    DeveloperProfile,
    ExpertiseGap,
    check_expertise_gaps,
    format_gaps,
    save_profiles,
    load_profiles,
)
from guard.core.design_reviewer import (
    DesignDecision,
    format_decisions,
    save_decisions,
    load_decisions,
    acknowledge_decision,
    review_design,
    get_diff,
)
from guard.core.project_profile import (
    save_profile,
    load_profile,
    get_design_constraints,
    build_project_profile,
    _detect_languages,
    _detect_architecture,
    _find_adrs,
    _build_module_map,
)
from guard.server import app


# ===================================================================
# Fixtures
# ===================================================================


@pytest.fixture
def client():
    """Create a test client without API key auth."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("GUARD_API_KEY", None)
        import guard.server as srv
        srv._API_KEY = None
        yield TestClient(app)


@pytest.fixture
def sample_threat() -> Threat:
    return Threat(
        threat_id="TM-ABC123",
        category="tampering",
        component="src/auth.py",
        description="SQL injection in login",
        attack_vector="Malicious input in username field",
        impact="Full database access",
        likelihood="high",
        severity="critical",
        mitigation="Use parameterized queries",
    )


@pytest.fixture
def sample_threats(sample_threat) -> list[Threat]:
    return [
        sample_threat,
        Threat(
            threat_id="TM-DEF456",
            category="spoofing",
            component="src/api.py",
            description="Missing authentication on endpoint",
            attack_vector="Direct API call without token",
            impact="Unauthorized data access",
            likelihood="medium",
            severity="high",
            mitigation="Add auth middleware",
        ),
    ]


# ===================================================================
# Threat dataclass
# ===================================================================


class TestThreatDataclass:
    def test_to_dict_round_trip(self, sample_threat):
        d = sample_threat.to_dict()
        restored = Threat.from_dict(d)
        assert restored.threat_id == sample_threat.threat_id
        assert restored.category == sample_threat.category
        assert restored.component == sample_threat.component
        assert restored.description == sample_threat.description
        assert restored.severity == sample_threat.severity
        assert restored.mitigated == sample_threat.mitigated

    def test_from_dict_defaults(self):
        t = Threat.from_dict({})
        assert t.category == "tampering"
        assert t.description == "Threat detected"
        assert t.likelihood == "medium"
        assert t.severity == "medium"
        assert t.mitigated is False
        assert t.threat_id.startswith("TM-")

    def test_to_dict_contains_all_fields(self, sample_threat):
        d = sample_threat.to_dict()
        expected_keys = {
            "threat_id", "category", "component", "description",
            "attack_vector", "impact", "likelihood", "severity",
            "mitigation", "mitigated", "mitigation_note",
        }
        assert set(d.keys()) == expected_keys


# ===================================================================
# format_threats
# ===================================================================


class TestFormatThreats:
    def test_empty_list(self):
        result = format_threats([])
        assert "No security threats detected" in result

    def test_with_threats(self, sample_threats):
        result = format_threats(sample_threats)
        assert "2 threat(s) identified" in result
        assert "CRITICAL" in result
        assert "TAMPERING" in result
        assert "SQL injection" in result
        assert "SPOOFING" in result

    def test_sorted_by_severity(self, sample_threats):
        result = format_threats(sample_threats)
        # Critical should appear before high
        crit_pos = result.index("CRITICAL")
        high_pos = result.index("HIGH")
        assert crit_pos < high_pos

    def test_mitigated_label(self):
        t = Threat(
            threat_id="TM-001",
            category="tampering",
            component="x.py",
            description="Test threat",
            mitigated=True,
            mitigation_note="Fixed it",
        )
        result = format_threats([t])
        assert "MITIGATED" in result
        assert "Fixed it" in result


# ===================================================================
# save_threats / load_threats
# ===================================================================


class TestSaveLoadThreats:
    def test_round_trip(self, tmp_path, sample_threats):
        out_dir = str(tmp_path / "out")
        save_threats(sample_threats, out_dir)
        loaded = load_threats(out_dir)
        assert len(loaded) == 2
        assert loaded[0].threat_id == "TM-ABC123"
        assert loaded[1].threat_id == "TM-DEF456"

    def test_load_empty_dir(self, tmp_path):
        result = load_threats(str(tmp_path / "nonexistent"))
        assert result == []

    def test_load_corrupt_json(self, tmp_path):
        out_dir = tmp_path / "out"
        out_dir.mkdir()
        (out_dir / "threat_model.json").write_text("not json", encoding="utf-8")
        result = load_threats(str(out_dir))
        assert result == []


# ===================================================================
# mitigate_threat
# ===================================================================


class TestMitigateThreat:
    def test_marks_correct_threat(self, tmp_path, sample_threats):
        out_dir = str(tmp_path / "out")
        save_threats(sample_threats, out_dir)
        result = mitigate_threat("TM-ABC123", note="Applied fix", output_dir=out_dir)
        assert result is True
        reloaded = load_threats(out_dir)
        matched = [t for t in reloaded if t.threat_id == "TM-ABC123"][0]
        assert matched.mitigated is True
        assert matched.mitigation_note == "Applied fix"

    def test_returns_false_for_missing_id(self, tmp_path, sample_threats):
        out_dir = str(tmp_path / "out")
        save_threats(sample_threats, out_dir)
        result = mitigate_threat("TM-NONEXIST", output_dir=out_dir)
        assert result is False


# ===================================================================
# generate_threat_model
# ===================================================================


class TestGenerateThreatModel:
    def test_empty_code_changes(self, tmp_path):
        llm = MagicMock()
        result = generate_threat_model(llm, "", output_dir=str(tmp_path))
        assert result == []
        llm.analyze.assert_not_called()

    def test_llm_exception_returns_empty(self, tmp_path):
        llm = MagicMock()
        llm.analyze.side_effect = RuntimeError("LLM down")
        result = generate_threat_model(llm, "def foo(): pass", output_dir=str(tmp_path))
        assert result == []

    def test_llm_returns_threats(self, tmp_path):
        llm = MagicMock()
        llm.analyze.return_value = {
            "threats": [
                {
                    "category": "tampering",
                    "component": "app.py",
                    "description": "SQL injection risk",
                    "severity": "high",
                    "likelihood": "medium",
                }
            ]
        }
        result = generate_threat_model(llm, "def login(user): ...", output_dir=str(tmp_path))
        assert len(result) == 1
        assert result[0].category == "tampering"
        assert result[0].severity == "high"


# ===================================================================
# New API Endpoints — empty state
# ===================================================================


class TestAPIEndpointsEmpty:
    """Test new API endpoints return sensible defaults when no data exists."""

    def test_quality_score_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/quality-score")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_project_profile_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/project-profile")
        assert resp.status_code == 200
        assert resp.json() == {}

    def test_design_decisions_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/design-decisions")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_developer_profiles_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/developer-profiles")
        assert resp.status_code == 200
        assert resp.json() == {}

    def test_attestation_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/attestation")
        assert resp.status_code == 200
        assert resp.json() == {}

    def test_threat_model_empty(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/threat-model")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_design_decisions_ack_404(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.post("/api/design-decisions/ack?decision_id=DD-001")
        assert resp.status_code == 404

    def test_threat_model_mitigate_404(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        resp = client.post("/api/threat-model/mitigate?threat_id=TM-001")
        assert resp.status_code == 404


# ===================================================================
# New API Endpoints — with data
# ===================================================================


class TestAPIEndpointsWithData:
    """Test API endpoints return data when JSON files exist."""

    def test_quality_score_with_data(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        out = tmp_path / "out"
        out.mkdir()
        data = [{"score": 85, "timestamp": "2026-04-01"}]
        (out / "quality_history.json").write_text(json.dumps(data), encoding="utf-8")
        resp = client.get("/api/quality-score")
        assert resp.status_code == 200
        assert resp.json() == data

    def test_threat_model_with_data(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        out = tmp_path / "out"
        out.mkdir()
        data = [{"threat_id": "TM-001", "category": "tampering", "description": "Test"}]
        (out / "threat_model.json").write_text(json.dumps(data), encoding="utf-8")
        resp = client.get("/api/threat-model")
        assert resp.status_code == 200
        assert resp.json() == data

    def test_threat_model_mitigate_success(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        out = tmp_path / "out"
        out.mkdir()
        data = [{"threat_id": "TM-001", "category": "tampering", "description": "Test"}]
        (out / "threat_model.json").write_text(json.dumps(data), encoding="utf-8")
        resp = client.post("/api/threat-model/mitigate?threat_id=TM-001&note=Fixed")
        assert resp.status_code == 200
        assert resp.json()["success"] is True
        # Verify file was updated
        updated = json.loads((out / "threat_model.json").read_text(encoding="utf-8"))
        assert updated[0]["mitigated"] is True
        assert updated[0]["mitigation_note"] == "Fixed"

    def test_design_decisions_ack_success(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        out = tmp_path / "out"
        out.mkdir()
        data = [{"decision_id": "DD-001", "description": "Use Redis"}]
        (out / "design_decisions.json").write_text(json.dumps(data), encoding="utf-8")
        resp = client.post("/api/design-decisions/ack?decision_id=DD-001&note=OK")
        assert resp.status_code == 200
        assert resp.json()["success"] is True
        updated = json.loads((out / "design_decisions.json").read_text(encoding="utf-8"))
        assert updated[0]["acknowledged"] is True

    def test_threat_model_mitigate_not_found(self, client, monkeypatch, tmp_path):
        monkeypatch.chdir(tmp_path)
        out = tmp_path / "out"
        out.mkdir()
        data = [{"threat_id": "TM-001", "category": "tampering"}]
        (out / "threat_model.json").write_text(json.dumps(data), encoding="utf-8")
        resp = client.post("/api/threat-model/mitigate?threat_id=TM-999")
        assert resp.status_code == 404


# ===================================================================
# Quality Scorer
# ===================================================================


class TestQualityScoreDataclass:
    def test_to_dict(self):
        dim = DimensionScore("compliance", 85, "3 findings", ["1 critical"])
        qs = QualityScore(overall=80, dimensions=[dim], trend=5)
        d = qs.to_dict()
        assert d["overall"] == 80
        assert d["trend"] == 5
        assert len(d["dimensions"]) == 1
        assert d["dimensions"][0]["name"] == "compliance"
        assert d["dimensions"][0]["issues"] == ["1 critical"]


class TestScoreCompliance:
    def test_no_findings_file(self, tmp_path):
        result = score_compliance(tmp_path / "missing.json")
        assert result.score == 100
        assert result.name == "compliance"

    def test_empty_findings(self, tmp_path):
        p = tmp_path / "findings.json"
        p.write_text("[]", encoding="utf-8")
        result = score_compliance(p)
        assert result.score == 100

    def test_with_findings(self, tmp_path):
        p = tmp_path / "findings.json"
        findings = [
            {"severity": "critical", "rule_id": "r1"},
            {"severity": "high", "rule_id": "r2"},
            {"severity": "medium", "rule_id": "r3"},
        ]
        p.write_text(json.dumps(findings), encoding="utf-8")
        result = score_compliance(p)
        # penalty = 10 + 5 + 2 = 17, score = 83
        assert result.score == 83
        assert "critical" in result.issues[0]

    def test_obligations_excluded(self, tmp_path):
        p = tmp_path / "findings.json"
        findings = [
            {"severity": "critical", "rule_id": "r1"},
            {"severity": "high", "rule_id": "r2", "is_obligation": True},
        ]
        p.write_text(json.dumps(findings), encoding="utf-8")
        result = score_compliance(p)
        # Only the critical counts: penalty = 10, score = 90
        assert result.score == 90


class TestScoreComplexity:
    def test_no_python_files(self, tmp_path):
        result = score_complexity(tmp_path)
        assert result.name == "complexity"
        assert result.score == 85  # default when no functions

    def test_simple_functions(self, tmp_path):
        f = tmp_path / "simple.py"
        f.write_text("def foo():\n    return 1\n\ndef bar():\n    return 2\n", encoding="utf-8")
        result = score_complexity(tmp_path)
        assert result.score >= 90


class TestScoreTestCoverage:
    def test_no_files(self, tmp_path):
        result = score_test_coverage(tmp_path)
        assert result.name == "test_coverage"
        assert result.score == 50

    def test_with_test_files(self, tmp_path):
        (tmp_path / "app.py").write_text("x = 1", encoding="utf-8")
        (tmp_path / "test_app.py").write_text("x = 1", encoding="utf-8")
        result = score_test_coverage(tmp_path)
        assert result.score > 0


class TestScoreDocumentation:
    def test_no_functions(self, tmp_path):
        result = score_documentation(tmp_path)
        assert result.name == "documentation"

    def test_with_readme(self, tmp_path):
        # tmp_path contains "test" in its path so score_documentation skips
        # all .py files in it. But README.md presence gives 70 vs 50.
        (tmp_path / "README.md").write_text("# Readme", encoding="utf-8")
        result = score_documentation(tmp_path)
        assert result.score == 70


class TestScoreConsistency:
    def test_no_names(self, tmp_path):
        result = score_consistency(tmp_path)
        assert result.name == "consistency"
        assert result.score == 80

    def test_snake_case_code(self, tmp_path):
        f = tmp_path / "mod.py"
        f.write_text("def my_func():\n    pass\ndef another_func():\n    pass\n", encoding="utf-8")
        result = score_consistency(tmp_path)
        assert result.score >= 80


class TestScoreDependencyHealth:
    def test_no_vuln_file(self, tmp_path):
        result = score_dependency_health(tmp_path / "vulns.json")
        assert result.name == "dependency_health"
        assert result.score == 70

    def test_with_vulns(self, tmp_path):
        p = tmp_path / "vulns.json"
        data = [
            {"severity": "critical", "id": "CVE-1"},
            {"severity": "high", "id": "CVE-2"},
        ]
        p.write_text(json.dumps(data), encoding="utf-8")
        result = score_dependency_health(p)
        # penalty = 15 + 8 = 23, score = 77
        assert result.score == 77

    def test_with_licenses(self, tmp_path):
        vulns = tmp_path / "vulns.json"
        vulns.write_text("[]", encoding="utf-8")
        lics = tmp_path / "licenses.json"
        lics.write_text(json.dumps([{"name": "GPL-3.0", "risk": "copyleft"}]), encoding="utf-8")
        result = score_dependency_health(vulns, lics)
        assert result.score == 95  # 100 - 5


class TestCalculateQualityScore:
    def test_basic(self, tmp_path):
        src = tmp_path / "src"
        src.mkdir()
        (src / "app.py").write_text("def main():\n    pass\n", encoding="utf-8")
        result = calculate_quality_score(str(tmp_path), str(tmp_path / "out"))
        assert 0 <= result.overall <= 100
        assert len(result.dimensions) == 6


class TestFormatQualityReport:
    def test_format(self):
        dim = DimensionScore("compliance", 85, "ok", [])
        qs = QualityScore(overall=85, dimensions=[dim], trend=3)
        report = format_quality_report(qs)
        assert "85/100" in report
        assert "+3" in report

    def test_format_negative_trend(self):
        qs = QualityScore(overall=60, dimensions=[], trend=-5)
        report = format_quality_report(qs)
        assert "-5" in report
        assert "degrading" in report

    def test_format_stable_trend(self):
        qs = QualityScore(overall=75, dimensions=[], trend=0)
        report = format_quality_report(qs)
        assert "stable" in report


# ===================================================================
# Expertise Tracker
# ===================================================================


class TestDeveloperProfile:
    def test_strength_ratio_empty(self):
        p = DeveloperProfile(email="a@b.com")
        assert p.strength_ratio("Python") == 0.0

    def test_strength_ratio(self):
        p = DeveloperProfile(
            email="a@b.com",
            languages={"Python": 8, "Go": 2},
            total_commits=10,
        )
        assert p.strength_ratio("Python") == 0.8
        assert p.strength_ratio("Rust") == 0.0

    def test_module_ratio(self):
        p = DeveloperProfile(
            email="a@b.com",
            modules={"src": 5},
            total_commits=10,
        )
        assert p.module_ratio("src") == 0.5
        assert p.module_ratio("lib") == 0.0

    def test_to_dict(self):
        p = DeveloperProfile(email="a@b.com", name="Alice", total_commits=5)
        d = p.to_dict()
        assert d["email"] == "a@b.com"
        assert d["name"] == "Alice"


class TestExpertiseGap:
    def test_to_dict(self):
        g = ExpertiseGap(
            file="src/main.rs",
            language="Rust",
            module="src",
            developer_ratio=0.05,
            message="Rust is outside your expertise",
        )
        d = g.to_dict()
        assert d["developer_ratio"] == 0.05
        assert d["language"] == "Rust"


class TestCheckExpertiseGaps:
    def test_no_gaps_within_expertise(self):
        p = DeveloperProfile(
            email="a@b.com",
            languages={"Python": 90},
            total_commits=100,
        )
        gaps = check_expertise_gaps(p, ["src/app.py"])
        assert len(gaps) == 0

    def test_gap_detected(self):
        p = DeveloperProfile(
            email="a@b.com",
            languages={"Python": 90},
            total_commits=100,
        )
        gaps = check_expertise_gaps(p, ["src/main.rs"], threshold=0.3)
        assert len(gaps) == 1
        assert gaps[0].language == "Rust"

    def test_unknown_extension_skipped(self):
        p = DeveloperProfile(email="a@b.com", total_commits=10)
        gaps = check_expertise_gaps(p, ["data.csv"])
        assert len(gaps) == 0


class TestFormatGaps:
    def test_no_gaps(self):
        p = DeveloperProfile(email="a@b.com")
        result = format_gaps([], p)
        assert "No expertise gaps" in result

    def test_with_gaps(self):
        p = DeveloperProfile(email="a@b.com", name="Alice", languages={"Python": 50})
        gap = ExpertiseGap(
            file="x.rs", language="Rust", module="src",
            developer_ratio=0.0, message="Rust is new for you",
        )
        result = format_gaps([gap], p)
        assert "1 expertise gap" in result
        assert "Alice" in result


class TestSaveLoadProfiles:
    def test_round_trip(self, tmp_path):
        profiles = {
            "a@b.com": DeveloperProfile(
                email="a@b.com", name="Alice",
                languages={"Python": 10}, total_commits=10,
            )
        }
        save_profiles(profiles, str(tmp_path / "out"))
        loaded = load_profiles(str(tmp_path / "out"))
        assert "a@b.com" in loaded
        assert loaded["a@b.com"].name == "Alice"

    def test_load_missing(self, tmp_path):
        assert load_profiles(str(tmp_path / "nope")) == {}


# ===================================================================
# Design Reviewer
# ===================================================================


class TestDesignDecision:
    def test_to_dict_round_trip(self):
        d = DesignDecision(
            decision_id="DD-001",
            category="architecture",
            summary="Use Redis for caching",
            file="src/cache.py",
            alternatives=["Memcached", "In-memory"],
            risk="Redis adds operational complexity",
            question="Is Redis the right choice here?",
        )
        data = d.to_dict()
        assert data["decision_id"] == "DD-001"
        assert len(data["alternatives"]) == 2


class TestFormatDecisions:
    def test_empty(self):
        result = format_decisions([])
        assert "No significant design decisions" in result

    def test_with_decisions(self):
        d = DesignDecision(
            decision_id="DD-001",
            category="architecture",
            summary="Use Redis",
            file="src/cache.py",
            line_start=10,
            line_end=20,
            alternatives=["Memcached"],
            risk="Complexity",
            question="Is this right?",
        )
        result = format_decisions([d])
        assert "ARCHITECTURE" in result
        assert "Redis" in result
        assert "src/cache.py:10-20" in result
        assert "Memcached" in result
        assert "Is this right?" in result


class TestSaveLoadDecisions:
    def test_round_trip(self, tmp_path):
        decisions = [
            DesignDecision(
                decision_id="DD-001",
                category="architecture",
                summary="Test",
                file="x.py",
            )
        ]
        save_decisions(decisions, str(tmp_path / "out"))
        loaded = load_decisions(str(tmp_path / "out"))
        assert len(loaded) == 1
        assert loaded[0].decision_id == "DD-001"

    def test_load_missing(self, tmp_path):
        assert load_decisions(str(tmp_path / "nope")) == []

    def test_load_corrupt(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        (out / "design_decisions.json").write_text("bad", encoding="utf-8")
        assert load_decisions(str(out)) == []


class TestAcknowledgeDecision:
    def test_acknowledge(self, tmp_path):
        decisions = [
            DesignDecision(decision_id="DD-001", category="architecture",
                           summary="Test", file="x.py")
        ]
        save_decisions(decisions, str(tmp_path / "out"))
        result = acknowledge_decision("DD-001", "Intentional", str(tmp_path / "out"))
        assert result is True
        loaded = load_decisions(str(tmp_path / "out"))
        assert loaded[0].acknowledged is True

    def test_acknowledge_missing(self, tmp_path):
        decisions = [
            DesignDecision(decision_id="DD-001", category="architecture",
                           summary="Test", file="x.py")
        ]
        save_decisions(decisions, str(tmp_path / "out"))
        result = acknowledge_decision("DD-999", output_dir=str(tmp_path / "out"))
        assert result is False


class TestReviewDesign:
    def test_empty_changes(self, tmp_path):
        llm = MagicMock()
        result = review_design(llm, "", output_dir=str(tmp_path))
        assert result == []

    def test_llm_exception(self, tmp_path):
        llm = MagicMock()
        llm.analyze.side_effect = RuntimeError("fail")
        result = review_design(llm, "def foo(): pass", output_dir=str(tmp_path))
        assert result == []

    def test_llm_returns_decisions(self, tmp_path):
        llm = MagicMock()
        llm.analyze.return_value = {
            "decisions": [
                {
                    "category": "architecture",
                    "summary": "Use singleton",
                    "file": "app.py",
                }
            ]
        }
        result = review_design(llm, "class Db: ...", output_dir=str(tmp_path))
        assert len(result) == 1
        assert result[0].category == "architecture"


class TestGetDiff:
    def test_file_path(self, tmp_path):
        f = tmp_path / "hello.py"
        f.write_text("print('hi')", encoding="utf-8")
        result = get_diff(file_path="hello.py", repo_root=str(tmp_path))
        assert "print('hi')" in result

    def test_file_path_missing(self, tmp_path):
        result = get_diff(file_path="nope.py", repo_root=str(tmp_path))
        assert result == ""


# ===================================================================
# Project Profile
# ===================================================================


class TestSaveLoadProfile:
    def test_round_trip(self, tmp_path):
        profile = {"languages": ["Python"], "frameworks": []}
        save_profile(profile, str(tmp_path / "out"))
        loaded = load_profile(str(tmp_path / "out"))
        assert loaded["languages"] == ["Python"]

    def test_load_missing(self, tmp_path):
        assert load_profile(str(tmp_path / "nope")) is None

    def test_load_corrupt(self, tmp_path):
        out = tmp_path / "out"
        out.mkdir()
        (out / "project-profile.json").write_text("bad", encoding="utf-8")
        assert load_profile(str(out)) is None


class TestGetDesignConstraints:
    def test_empty_profile(self):
        constraints = get_design_constraints({})
        assert constraints["tech_stack"] == []
        assert constraints["conventions"] == {}

    def test_with_frameworks(self):
        profile = {
            "frameworks": [{"name": "FastAPI"}],
            "architecture": [{"pattern": "MVC"}],
            "adrs": [],
            "conventions": {"naming": "snake_case"},
            "tech_stack": ["Python", "FastAPI"],
        }
        constraints = get_design_constraints(profile, file_path="api/routes/users.py")
        assert any("FastAPI" in p for p in constraints["established_patterns"])

    def test_with_intent(self):
        profile = {"frameworks": [{"name": "Django"}], "tech_stack": ["Python"]}
        constraints = get_design_constraints(profile, intent="add auth middleware")
        assert any("auth" in p.lower() for p in constraints["established_patterns"])

    def test_tech_stack_warnings(self):
        profile = {"frameworks": [{"name": "React"}], "tech_stack": ["React"]}
        constraints = get_design_constraints(profile)
        assert len(constraints["tech_stack_warnings"]) > 0


class TestDetectLanguages:
    def test_detects_python(self, tmp_path):
        (tmp_path / "app.py").write_text("x=1", encoding="utf-8")
        (tmp_path / "lib.py").write_text("x=1", encoding="utf-8")
        langs = _detect_languages(tmp_path)
        assert "Python" in langs


class TestDetectArchitecture:
    def test_detects_service_layer(self, tmp_path):
        (tmp_path / "service").mkdir()
        (tmp_path / "service" / "x.py").write_text("", encoding="utf-8")
        patterns = _detect_architecture(tmp_path)
        assert any(p["pattern"] == "Service Layer" for p in patterns)


class TestFindADRs:
    def test_finds_adrs(self, tmp_path):
        adr_dir = tmp_path / "docs" / "adr"
        adr_dir.mkdir(parents=True)
        (adr_dir / "001-use-fastapi.md").write_text("# Use FastAPI", encoding="utf-8")
        adrs = _find_adrs(tmp_path)
        assert len(adrs) == 1
        assert "FastAPI" in adrs[0]["title"]

    def test_no_adrs(self, tmp_path):
        assert _find_adrs(tmp_path) == []


class TestBuildModuleMap:
    def test_maps_directories(self, tmp_path):
        src = tmp_path / "src"
        src.mkdir()
        (src / "app.py").write_text("x=1", encoding="utf-8")
        tests = tmp_path / "tests"
        tests.mkdir()
        (tests / "test_app.py").write_text("x=1", encoding="utf-8")
        m = _build_module_map(tmp_path)
        dirs = {e["directory"] for e in m}
        assert "src" in dirs
        assert "tests" in dirs


class TestBuildProjectProfile:
    def test_basic(self, tmp_path):
        (tmp_path / "app.py").write_text("import fastapi\n", encoding="utf-8")
        profile = build_project_profile(str(tmp_path))
        assert "languages" in profile
        assert "frameworks" in profile
        assert "module_map" in profile
