"""Comprehensive tests for run comparison (Phase 8)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.helpers import make_finding as _finding
from guard.core.comparison import compare_runs, load_findings, render_comparison
from guard.core.models import Finding, RunComparison, Severity


def _write_findings(tmp_path: Path, filename: str, findings: list[Finding]) -> Path:
    p = tmp_path / filename
    data = [f.model_dump() for f in findings]
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


# ===================================================================
# compare_runs
# ===================================================================


class TestCompareRuns:
    def test_all_new(self):
        current = [_finding("F1"), _finding("F2")]
        comp = compare_runs(current, [])
        assert len(comp.new_findings) == 2
        assert comp.resolved_findings == []
        assert comp.unchanged_findings == []

    def test_all_resolved(self):
        previous = [_finding("F1"), _finding("F2")]
        comp = compare_runs([], previous)
        assert comp.new_findings == []
        assert len(comp.resolved_findings) == 2
        assert comp.unchanged_findings == []

    def test_all_unchanged(self):
        findings = [_finding("F1"), _finding("F2")]
        comp = compare_runs(findings, findings)
        assert comp.new_findings == []
        assert comp.resolved_findings == []
        assert len(comp.unchanged_findings) == 2

    def test_mixed(self):
        previous = [_finding("F1"), _finding("F2")]
        current = [_finding("F2"), _finding("F3")]
        comp = compare_runs(current, previous)
        assert [f.finding_id for f in comp.new_findings] == ["F3"]
        assert [f.finding_id for f in comp.resolved_findings] == ["F1"]
        assert [f.finding_id for f in comp.unchanged_findings] == ["F2"]

    def test_both_empty(self):
        comp = compare_runs([], [])
        assert comp.new_findings == []
        assert comp.resolved_findings == []
        assert comp.unchanged_findings == []

    def test_single_new(self):
        comp = compare_runs([_finding("F1")], [])
        assert len(comp.new_findings) == 1
        assert comp.new_findings[0].finding_id == "F1"

    def test_single_resolved(self):
        comp = compare_runs([], [_finding("F1")])
        assert len(comp.resolved_findings) == 1
        assert comp.resolved_findings[0].finding_id == "F1"

    def test_preserves_finding_data(self):
        f = _finding("F1", msg="Specific message", sev=Severity.HIGH)
        comp = compare_runs([f], [])
        assert comp.new_findings[0].message == "Specific message"
        assert comp.new_findings[0].severity == Severity.HIGH

    def test_same_id_different_content_is_unchanged(self):
        prev = _finding("F1", msg="Old message")
        curr = _finding("F1", msg="New message")
        comp = compare_runs([curr], [prev])
        assert len(comp.unchanged_findings) == 1
        assert comp.unchanged_findings[0].message == "New message"


# ===================================================================
# load_findings
# ===================================================================


class TestLoadFindings:
    def test_load_valid_file(self, tmp_path):
        findings = [_finding("F1"), _finding("F2")]
        path = _write_findings(tmp_path, "findings.json", findings)
        loaded = load_findings(path)
        assert len(loaded) == 2
        assert loaded[0].finding_id == "F1"

    def test_load_nonexistent_file(self, tmp_path):
        result = load_findings(tmp_path / "nope.json")
        assert result == []

    def test_load_invalid_json(self, tmp_path):
        p = tmp_path / "bad.json"
        p.write_text("not json!", encoding="utf-8")
        assert load_findings(p) == []

    def test_load_non_list_json(self, tmp_path):
        p = tmp_path / "obj.json"
        p.write_text('{"key": "value"}', encoding="utf-8")
        assert load_findings(p) == []

    def test_load_with_malformed_entries(self, tmp_path):
        data = [
            _finding("F1").model_dump(),
            {"bad": "entry"},
            _finding("F2").model_dump(),
        ]
        p = tmp_path / "mixed.json"
        p.write_text(json.dumps(data), encoding="utf-8")
        loaded = load_findings(p)
        assert len(loaded) == 2

    def test_load_empty_list(self, tmp_path):
        p = tmp_path / "empty.json"
        p.write_text("[]", encoding="utf-8")
        assert load_findings(p) == []


# ===================================================================
# render_comparison
# ===================================================================


class TestRenderComparison:
    def test_renders_markdown(self):
        comp = RunComparison(
            new_findings=[_finding("F1")],
            resolved_findings=[_finding("F2")],
            unchanged_findings=[_finding("F3")],
        )
        md = render_comparison(comp)
        assert "# Run Comparison" in md
        assert "New findings:** 1" in md
        assert "Resolved findings:** 1" in md
        assert "Unchanged findings:** 1" in md

    def test_new_findings_section(self):
        comp = RunComparison(new_findings=[_finding("F1", sev=Severity.HIGH)])
        md = render_comparison(comp)
        assert "## New Findings" in md
        assert "HIGH" in md
        assert "F1" in md

    def test_resolved_findings_section(self):
        comp = RunComparison(resolved_findings=[_finding("F2")])
        md = render_comparison(comp)
        assert "## Resolved Findings" in md
        assert "F2" in md

    def test_no_sections_when_empty(self):
        comp = RunComparison()
        md = render_comparison(comp)
        assert "## New Findings" not in md
        assert "## Resolved Findings" not in md

    def test_all_zeros(self):
        comp = RunComparison()
        md = render_comparison(comp)
        assert "New findings:** 0" in md
        assert "Resolved findings:** 0" in md


# ===================================================================
# RunComparison model
# ===================================================================


class TestRunComparisonModel:
    def test_defaults(self):
        comp = RunComparison()
        assert comp.new_findings == []
        assert comp.resolved_findings == []
        assert comp.unchanged_findings == []

    def test_serialization(self):
        comp = RunComparison(new_findings=[_finding("F1")])
        data = comp.model_dump()
        assert len(data["new_findings"]) == 1
        assert data["new_findings"][0]["finding_id"] == "F1"
