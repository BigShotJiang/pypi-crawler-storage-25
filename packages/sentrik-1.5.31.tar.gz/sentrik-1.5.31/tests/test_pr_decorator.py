"""Tests for the PR decorator module (Phase 26d)."""

from __future__ import annotations

import json
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.core.models import Evidence, Finding, GateResult, Severity
from guard.core.pr_decorator import (
    AzurePRDecorator,
    GitHubPRDecorator,
    _detect_azure_pr_id,
    _detect_azure_repo,
    _detect_github_pr_number,
    decorate_pr,
    format_findings_comment,
)


def _make_finding(
    rule_id: str = "RULE-001",
    severity: Severity = Severity.HIGH,
    message: str = "Test finding",
    file: str = "src/main.py",
) -> Finding:
    return Finding(
        finding_id=f"f-{rule_id}",
        rule_id=rule_id,
        severity=severity,
        message=message,
        evidence=Evidence(file=file),
        confidence=0.9,
    )


# ===================================================================
# format_findings_comment
# ===================================================================


class TestFormatFindingsComment:
    def test_passed_gate_badge(self):
        result = GateResult(passed=True, total_findings=0)
        comment = format_findings_comment([], result)
        assert "PASSED" in comment
        assert "\u2705" in comment

    def test_failed_gate_badge(self):
        result = GateResult(passed=False, total_findings=3, critical=1, high=2)
        comment = format_findings_comment([], result)
        assert "FAILED" in comment
        assert "\u274C" in comment

    def test_severity_table(self):
        result = GateResult(
            passed=False, total_findings=6,
            critical=1, high=2, medium=1, low=1, info=1,
        )
        comment = format_findings_comment([], result)
        assert "| Critical | 1 |" in comment
        assert "| High | 2 |" in comment
        assert "**6** findings" in comment

    def test_top_findings_listed(self):
        findings = [
            _make_finding(rule_id="R-001", severity=Severity.CRITICAL, message="SQL injection"),
            _make_finding(rule_id="R-002", severity=Severity.HIGH, message="XSS vuln"),
        ]
        result = GateResult(passed=False, total_findings=2, critical=1, high=1)
        comment = format_findings_comment(findings, result)
        assert "R-001" in comment
        assert "SQL injection" in comment
        assert "R-002" in comment

    def test_more_than_10_findings_truncated(self):
        findings = [_make_finding(rule_id=f"R-{i:03d}") for i in range(15)]
        result = GateResult(passed=False, total_findings=15)
        comment = format_findings_comment(findings, result)
        assert "... and 5 more" in comment

    def test_footer_present(self):
        result = GateResult(passed=True, total_findings=0)
        comment = format_findings_comment([], result)
        assert "SENTRIK" in comment

    def test_no_findings_section_when_empty(self):
        result = GateResult(passed=True, total_findings=0)
        comment = format_findings_comment([], result)
        assert "Top Findings" not in comment


# ===================================================================
# GitHubPRDecorator
# ===================================================================


class TestGitHubPRDecorator:
    def test_post_comment_no_token(self):
        decorator = GitHubPRDecorator(owner="acme", repo="app")
        with patch.dict("os.environ", _home_env(), clear=True):
            result = decorator.post_comment("Hello", pr_number=1)
        assert result is False

    def test_post_comment_success(self):
        decorator = GitHubPRDecorator(owner="acme", repo="app")
        mock_resp = MagicMock()
        mock_resp.status = 201
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = decorator.post_comment("Hello", pr_number=42)

        assert result is True
        call_args = mock_open.call_args[0][0]
        assert "/issues/42/comments" in call_args.full_url

    def test_post_comment_http_error(self):
        decorator = GitHubPRDecorator(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.HTTPError(
                    "url", 403, "Forbidden", {}, None,
                )
                result = decorator.post_comment("Hello", pr_number=1)
        assert result is False

    def test_post_comment_url_error(self):
        decorator = GitHubPRDecorator(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.URLError("Connection refused")
                result = decorator.post_comment("Hello", pr_number=1)
        assert result is False


# ===================================================================
# _detect_github_pr_number
# ===================================================================


class TestDetectGitHubPRNumber:
    def test_no_event_path(self):
        with patch.dict("os.environ", _home_env(), clear=True):
            assert _detect_github_pr_number() is None

    def test_valid_event_file(self, tmp_path):
        event_file = tmp_path / "event.json"
        event_file.write_text(json.dumps({"pull_request": {"number": 42}}))
        with patch.dict("os.environ", {"GITHUB_EVENT_PATH": str(event_file)}):
            result = _detect_github_pr_number()
        assert result == 42

    def test_missing_pr_key(self, tmp_path):
        event_file = tmp_path / "event.json"
        event_file.write_text(json.dumps({"action": "push"}))
        with patch.dict("os.environ", {"GITHUB_EVENT_PATH": str(event_file)}):
            result = _detect_github_pr_number()
        assert result is None

    def test_invalid_json(self, tmp_path):
        event_file = tmp_path / "event.json"
        event_file.write_text("not json")
        with patch.dict("os.environ", {"GITHUB_EVENT_PATH": str(event_file)}):
            result = _detect_github_pr_number()
        assert result is None


# ===================================================================
# decorate_pr (integration)
# ===================================================================


class TestDecoratePR:
    def test_missing_owner_repo(self):
        result = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", _home_env(), clear=True):
            assert decorate_pr([], result) is False

    def test_missing_pr_number(self):
        result = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", {
            **_home_env(),
            "GUARD_GITHUB_OWNER": "acme",
            "GUARD_GITHUB_REPO": "app",
        }, clear=True):
            assert decorate_pr([], result) is False

    def test_success_with_explicit_pr_number(self):
        result = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", {
            "GUARD_GITHUB_OWNER": "acme",
            "GUARD_GITHUB_REPO": "app",
            "GITHUB_TOKEN": "ghp_test",
        }):
            with patch("guard.core.pr_decorator.GitHubPRDecorator.post_comment", return_value=True):
                assert decorate_pr([], result, pr_number=10) is True

    def test_passes_owner_repo_params(self):
        result = GateResult(passed=True, total_findings=0)
        with patch.dict("os.environ", _home_env(GITHUB_TOKEN="ghp_test"), clear=True):
            with patch("guard.core.pr_decorator.GitHubPRDecorator.post_comment", return_value=True) as mock_post:
                assert decorate_pr([], result, owner="my-org", repo="my-repo", pr_number=5) is True


# ===================================================================
# AzurePRDecorator
# ===================================================================


class TestAzurePRDecorator:
    def test_post_comment_no_pat(self):
        decorator = AzurePRDecorator(org="myorg", project="myproj", repo="myrepo")
        with patch.dict("os.environ", _home_env(), clear=True):
            result = decorator.post_comment("Hello", pr_id=1)
        assert result is False

    def test_post_comment_success(self):
        decorator = AzurePRDecorator(org="myorg", project="myproj", repo="myrepo")
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "mytoken"}):
            with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
                result = decorator.post_comment("Hello", pr_id=42)

        assert result is True
        call_args = mock_open.call_args[0][0]
        assert "/pullrequests/42/threads" in call_args.full_url
        assert "Basic" in call_args.get_header("Authorization")

    def test_post_comment_http_error(self):
        decorator = AzurePRDecorator(org="myorg", project="myproj", repo="myrepo")
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "mytoken"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.HTTPError(
                    "url", 403, "Forbidden", {}, None,
                )
                result = decorator.post_comment("Hello", pr_id=1)
        assert result is False

    def test_post_comment_url_error(self):
        decorator = AzurePRDecorator(org="myorg", project="myproj", repo="myrepo")
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "mytoken"}):
            with patch("urllib.request.urlopen") as mock_open:
                mock_open.side_effect = urllib.error.URLError("Connection refused")
                result = decorator.post_comment("Hello", pr_id=1)
        assert result is False


# ===================================================================
# _detect_azure_pr_id
# ===================================================================


class TestDetectAzurePRId:
    def test_no_env_var(self):
        with patch.dict("os.environ", _home_env(), clear=True):
            assert _detect_azure_pr_id() is None

    def test_valid_pr_id(self):
        with patch.dict("os.environ", {"SYSTEM_PULLREQUEST_PULLREQUESTID": "123"}):
            assert _detect_azure_pr_id() == 123

    def test_invalid_pr_id(self):
        with patch.dict("os.environ", {"SYSTEM_PULLREQUEST_PULLREQUESTID": "abc"}):
            assert _detect_azure_pr_id() is None


# ===================================================================
# _detect_azure_repo
# ===================================================================


class TestDetectAzureRepo:
    def test_no_env_var(self):
        with patch.dict("os.environ", _home_env(), clear=True):
            assert _detect_azure_repo() is None

    def test_valid_repo(self):
        with patch.dict("os.environ", {"BUILD_REPOSITORY_NAME": "my-repo"}):
            assert _detect_azure_repo() == "my-repo"


# ===================================================================
# decorate_pr — Azure path
# ===================================================================


class TestDecoratePRAzure:
    def test_azure_auto_detect(self):
        """Azure env vars present → AzurePRDecorator is used."""
        result = GateResult(passed=True, total_findings=0)
        env = {
            **_home_env(),
            "SYSTEM_PULLREQUEST_PULLREQUESTID": "99",
            "GUARD_AZURE_DEVOPS_ORG": "myorg",
            "GUARD_AZURE_DEVOPS_PROJECT": "myproj",
            "BUILD_REPOSITORY_NAME": "myrepo",
            "AZURE_DEVOPS_PAT": "pat123",
        }
        with patch.dict("os.environ", env, clear=True):
            with patch("guard.core.pr_decorator.AzurePRDecorator.post_comment", return_value=True) as mock_post:
                assert decorate_pr([], result) is True
        mock_post.assert_called_once()

    def test_azure_missing_org_skips(self):
        """Azure PR ID detected but org not configured → returns False."""
        result = GateResult(passed=True, total_findings=0)
        env = {**_home_env(), "SYSTEM_PULLREQUEST_PULLREQUESTID": "99"}
        with patch.dict("os.environ", env, clear=True):
            assert decorate_pr([], result) is False

    def test_azure_falls_through_to_github(self):
        """No Azure env vars → falls through to GitHub path."""
        result = GateResult(passed=True, total_findings=0)
        env = {
            **_home_env(),
            "GUARD_GITHUB_OWNER": "acme",
            "GUARD_GITHUB_REPO": "app",
            "GITHUB_TOKEN": "ghp_test",
        }
        with patch.dict("os.environ", env, clear=True):
            with patch("guard.core.pr_decorator.GitHubPRDecorator.post_comment", return_value=True) as mock_post:
                assert decorate_pr([], result, pr_number=10) is True
        mock_post.assert_called_once()

    def test_azure_repo_auto_detected(self):
        """BUILD_REPOSITORY_NAME used as repo fallback."""
        result = GateResult(passed=True, total_findings=0)
        env = {
            **_home_env(),
            "SYSTEM_PULLREQUEST_PULLREQUESTID": "50",
            "GUARD_AZURE_DEVOPS_ORG": "myorg",
            "GUARD_AZURE_DEVOPS_PROJECT": "myproj",
            "BUILD_REPOSITORY_NAME": "auto-repo",
            "AZURE_DEVOPS_PAT": "pat123",
        }
        with patch.dict("os.environ", env, clear=True):
            with patch("guard.core.pr_decorator.AzurePRDecorator.post_comment", return_value=True) as mock_post:
                assert decorate_pr([], result) is True
        mock_post.assert_called_once()
