"""Tests for ComplianceAgent."""

from __future__ import annotations

import pytest

from guard.core.agent import AgentResult, ComplianceAgent


def _make_rule(rule_id: str, pattern: str = "TODO") -> dict:
    return {
        "id": rule_id,
        "name": rule_id.lower(),
        "type": "regex",
        "pattern": pattern,
        "severity": "medium",
        "file_glob": "**/*.py",
    }


class TestAgentResult:
    def test_defaults(self):
        r = AgentResult(pack_id="test")
        assert r.pack_id == "test"
        assert r.findings == []
        assert r.duration_ms == 0.0
        assert r.error is None

    def test_with_error(self):
        r = AgentResult(pack_id="test", error="boom")
        assert r.error == "boom"


class TestComplianceAgent:
    def test_evaluate_returns_findings(self, tmp_path):
        (tmp_path / "app.py").write_text("# TODO fix this\n", encoding="utf-8")
        agent = ComplianceAgent("test-pack", [_make_rule("T-001", "TODO")])
        result = agent.evaluate(str(tmp_path))

        assert result.pack_id == "test-pack"
        assert result.rule_count == 1
        assert len(result.findings) >= 1
        assert result.duration_ms > 0
        assert result.error is None

    def test_evaluate_empty_rules(self, tmp_path):
        (tmp_path / "app.py").write_text("print('hello')\n", encoding="utf-8")
        agent = ComplianceAgent("empty", [])
        result = agent.evaluate(str(tmp_path))

        assert result.pack_id == "empty"
        assert result.findings == []
        assert result.rule_count == 0
        assert result.error is None

    def test_evaluate_no_matches(self, tmp_path):
        (tmp_path / "app.py").write_text("print('clean')\n", encoding="utf-8")
        agent = ComplianceAgent("clean", [_make_rule("T-001", "HACK")])
        result = agent.evaluate(str(tmp_path))

        assert result.findings == []
        assert result.files_scanned >= 1

    def test_error_isolation(self, tmp_path, monkeypatch):
        agent = ComplianceAgent("broken", [_make_rule("T-001")])
        monkeypatch.setattr(
            agent._engine, "evaluate",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("engine crash")),
        )
        result = agent.evaluate(str(tmp_path))

        assert result.error == "engine crash"
        assert result.findings == []
        assert result.duration_ms > 0

    def test_pack_id_property(self):
        agent = ComplianceAgent("my-pack", [])
        assert agent.pack_id == "my-pack"

    def test_rule_count_property(self):
        agent = ComplianceAgent("x", [_make_rule("A"), _make_rule("B")])
        assert agent.rule_count == 2
