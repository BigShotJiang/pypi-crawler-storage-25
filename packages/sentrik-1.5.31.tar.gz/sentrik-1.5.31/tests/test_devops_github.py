"""Tests for the GitHub DevOps provider (Phase 16)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.providers.devops_github import (
    DevOpsGitHub,
    _extract_acceptance_criteria,
    _normalize_state,
)


# ===================================================================
# State normalization
# ===================================================================


class TestNormalizeState:
    def test_open_maps_to_active(self):
        assert _normalize_state("open") == "active"

    def test_closed_maps_to_closed(self):
        assert _normalize_state("closed") == "closed"

    def test_case_insensitive(self):
        assert _normalize_state("Open") == "active"
        assert _normalize_state("CLOSED") == "closed"

    def test_none_defaults_to_active(self):
        assert _normalize_state(None) == "active"

    def test_unknown_defaults_to_active(self):
        assert _normalize_state("in_progress") == "active"


# ===================================================================
# Acceptance criteria extraction
# ===================================================================


class TestExtractAcceptanceCriteria:
    def test_empty_body(self):
        assert _extract_acceptance_criteria("") == []
        assert _extract_acceptance_criteria(None) == []

    def test_no_acceptance_section(self):
        body = "# Description\nSome feature description."
        assert _extract_acceptance_criteria(body) == []

    def test_bullet_list(self):
        body = (
            "## Description\nSome text\n\n"
            "## Acceptance Criteria\n"
            "- First criterion\n"
            "- Second criterion\n"
            "- Third criterion\n"
        )
        result = _extract_acceptance_criteria(body)
        assert result == ["First criterion", "Second criterion", "Third criterion"]

    def test_star_list(self):
        body = "## Acceptance Criteria\n* Item A\n* Item B\n"
        result = _extract_acceptance_criteria(body)
        assert result == ["Item A", "Item B"]

    def test_numbered_list(self):
        body = "## Acceptance Criteria\n1. First\n2. Second\n3. Third\n"
        result = _extract_acceptance_criteria(body)
        assert result == ["First", "Second", "Third"]

    def test_stops_at_next_heading(self):
        body = (
            "## Acceptance Criteria\n"
            "- Criterion 1\n"
            "## Notes\n"
            "- Not a criterion\n"
        )
        result = _extract_acceptance_criteria(body)
        assert result == ["Criterion 1"]

    def test_case_insensitive_heading(self):
        body = "## acceptance criteria\n- Works\n"
        result = _extract_acceptance_criteria(body)
        assert result == ["Works"]


# ===================================================================
# DevOpsGitHub provider
# ===================================================================


def _make_issue(
    number: int = 1,
    title: str = "Test issue",
    state: str = "open",
    body: str = "",
) -> dict:
    """Create a minimal GitHub issue JSON object."""
    return {
        "number": number,
        "title": title,
        "state": state,
        "body": body,
    }


class TestDevOpsGitHub:
    def test_init_stores_params(self):
        p = DevOpsGitHub(owner="acme", repo="app", label="guard", milestone="v1")
        assert p._owner == "acme"
        assert p._repo == "app"
        assert p._label == "guard"
        assert p._milestone == "v1"

    def test_get_headers_without_token(self):
        p = DevOpsGitHub(owner="o", repo="r")
        with patch.dict("os.environ", _home_env(), clear=True):
            headers = p._get_headers()
        assert "Authorization" not in headers
        assert "Accept" in headers

    def test_get_headers_with_token(self):
        p = DevOpsGitHub(owner="o", repo="r")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test123"}):
            headers = p._get_headers()
        assert headers["Authorization"] == "Bearer ghp_test123"

    def test_map_issue_basic(self):
        p = DevOpsGitHub(owner="o", repo="r")
        issue = _make_issue(number=42, title="My Issue", state="open", body="A description")
        wi = p._map_issue(issue)
        assert wi.id == "42"
        assert wi.title == "My Issue"
        assert wi.state == "active"
        assert wi.description == "A description"

    def test_map_issue_with_acceptance_criteria(self):
        p = DevOpsGitHub(owner="o", repo="r")
        body = "Description\n\n## Acceptance Criteria\n- AC 1\n- AC 2\n"
        issue = _make_issue(body=body)
        wi = p._map_issue(issue)
        assert wi.acceptance_criteria == ["AC 1", "AC 2"]

    def test_map_issue_closed(self):
        p = DevOpsGitHub(owner="o", repo="r")
        issue = _make_issue(state="closed")
        wi = p._map_issue(issue)
        assert wi.state == "closed"

    def test_map_issue_no_body(self):
        p = DevOpsGitHub(owner="o", repo="r")
        issue = {"number": 1, "title": "T", "state": "open", "body": None}
        wi = p._map_issue(issue)
        assert wi.description == ""
        assert wi.acceptance_criteria == []

    def test_fetch_by_ids_calls_api(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        issue1 = _make_issue(number=1, title="Issue 1")
        issue2 = _make_issue(number=2, title="Issue 2")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.side_effect = [issue1, issue2]
            result = p.get_work_items(ids=["1", "2"])

        assert len(result) == 2
        assert result[0].id == "1"
        assert result[1].id == "2"
        assert mock_get.call_count == 2

    def test_fetch_by_ids_handles_failure(self):
        p = DevOpsGitHub(owner="acme", repo="app")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.side_effect = OSError("Network error")
            result = p.get_work_items(ids=["1"])

        assert result == []

    def test_fetch_by_query(self):
        p = DevOpsGitHub(owner="acme", repo="app", label="guard")
        issues = [
            _make_issue(number=1, title="Issue 1"),
            _make_issue(number=2, title="Issue 2"),
        ]

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = issues
            result = p.get_work_items()

        assert len(result) == 2
        # Verify label is in the URL
        call_url = mock_get.call_args[0][0]
        assert "labels=guard" in call_url

    def test_fetch_by_query_filters_prs(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        issues = [
            _make_issue(number=1, title="Issue 1"),
            {**_make_issue(number=2, title="PR 1"), "pull_request": {"url": "..."}},
        ]

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = issues
            result = p.get_work_items()

        assert len(result) == 1
        assert result[0].title == "Issue 1"

    def test_fetch_by_query_empty_response(self):
        p = DevOpsGitHub(owner="acme", repo="app")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = []
            result = p.get_work_items()

        assert result == []

    def test_fetch_by_query_none_response(self):
        p = DevOpsGitHub(owner="acme", repo="app")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = None
            result = p.get_work_items()

        assert result == []

    def test_api_get_http_error(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.HTTPError(
                "https://api.github.com/test", 404, "Not Found", {}, None
            )
            result = p._api_get("https://api.github.com/test", {})

        assert result is None

    def test_api_get_url_error(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
            result = p._api_get("https://api.github.com/test", {})

        assert result is None

    def test_description_uses_first_paragraph(self):
        p = DevOpsGitHub(owner="o", repo="r")
        body = "First line of desc.\nSecond line.\n\nAnother paragraph."
        issue = _make_issue(body=body)
        wi = p._map_issue(issue)
        assert wi.description == "First line of desc. Second line."


# ===================================================================
# Write operations
# ===================================================================


class TestDevOpsGitHubWrite:
    def test_create_work_item_success(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"number": 99, "id": 123}
                result = p.create_work_item("Bug title", description="desc")

        assert result == 99
        call_args = mock_req.call_args
        assert call_args[1]["method"] == "POST"
        payload = call_args[1]["data"]
        assert payload["title"] == "Bug title"
        assert "guard" in payload["labels"]

    def test_create_work_item_with_tags(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"number": 10}
                result = p.create_work_item("Title", tags="bug, security")

        assert result == 10
        payload = mock_req.call_args[1]["data"]
        assert "bug" in payload["labels"]
        assert "security" in payload["labels"]

    def test_create_work_item_failure(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = None
                result = p.create_work_item("Title")

        assert result is None

    def test_update_work_item_success(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"number": 5, "state": "open"}
                result = p.update_work_item(5, title="New title")

        assert result is True
        payload = mock_req.call_args[1]["data"]
        assert payload["title"] == "New title"

    def test_update_work_item_state_closed(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"number": 5}
                result = p.update_work_item(5, state="closed")

        assert result is True
        payload = mock_req.call_args[1]["data"]
        assert payload["state"] == "closed"

    def test_update_work_item_noop(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        result = p.update_work_item(5)
        assert result is True

    def test_update_work_item_failure(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = None
                result = p.update_work_item(5, title="New")

        assert result is False

    def test_close_work_item_delegates(self):
        p = DevOpsGitHub(owner="acme", repo="app")
        with patch.object(p, "update_work_item") as mock_update:
            mock_update.return_value = True
            result = p.close_work_item(42)

        assert result is True
        mock_update.assert_called_once_with(42, state="closed")
