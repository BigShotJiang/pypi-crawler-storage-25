"""Tests for fine-grained authorization and RBAC (Phase 2)."""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from guard.auth.models import UserContext
from guard.authz.models import (
    AuthzRequest,
    AuthzResult,
    Permission,
    ResourceType,
    ROLE_PERMISSIONS,
)
from guard.authz.policy import (
    LocalPolicyEngine,
    get_policy_engine,
    set_policy_engine,
)
from guard.authz.checks import require_permission
from guard.authz.fga_client import OpenFGAClient
from guard.authz.sync import sync_roles_on_login, sync_repo_access


# ── TestRolePermissions ──────────────────────────────────────────────


class TestRolePermissions:
    """Verify the RBAC matrix for each role."""

    def test_admin_has_all_permissions(self):
        assert ROLE_PERMISSIONS["admin"] == frozenset(Permission)

    def test_security_lead_permissions(self):
        expected = {
            Permission.SCAN, Permission.GATE, Permission.RECONCILE,
            Permission.FINDINGS_READ, Permission.FINDINGS_WRITE,
            Permission.AUDIT_READ, Permission.PACKS_READ,
            Permission.APPROVAL_REVIEW,
        }
        assert ROLE_PERMISSIONS["security-lead"] == expected

    def test_developer_permissions(self):
        expected = {
            Permission.SCAN, Permission.GATE,
            Permission.FINDINGS_READ, Permission.PACKS_READ,
        }
        assert ROLE_PERMISSIONS["developer"] == expected

    def test_viewer_permissions(self):
        expected = {Permission.FINDINGS_READ, Permission.AUDIT_READ, Permission.PACKS_READ}
        assert ROLE_PERMISSIONS["viewer"] == expected

    def test_agent_permissions(self):
        expected = {Permission.SCAN, Permission.GATE, Permission.FINDINGS_READ, Permission.APPROVAL_REQUEST}
        assert ROLE_PERMISSIONS["agent"] == expected

    def test_all_roles_present(self):
        assert set(ROLE_PERMISSIONS.keys()) == {"admin", "security-lead", "developer", "viewer", "agent"}


# ── TestLocalPolicyEngine ────────────────────────────────────────────


class TestLocalPolicyEngine:
    """Test the built-in RBAC policy engine."""

    def setup_method(self):
        self.engine = LocalPolicyEngine()

    def test_admin_allowed_everything(self):
        for perm in Permission:
            result = self.engine.check(AuthzRequest(
                user_id="u1", action=perm.value, roles=["admin"],
            ))
            assert result.allowed, f"admin should have {perm.value}"

    def test_developer_allowed_scan(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="scan", roles=["developer"],
        ))
        assert result.allowed

    def test_developer_denied_reconcile(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="reconcile", roles=["developer"],
        ))
        assert not result.allowed
        assert "developer" in result.reason

    def test_viewer_denied_scan(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="scan", roles=["viewer"],
        ))
        assert not result.allowed

    def test_viewer_allowed_findings_read(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="findings:read", roles=["viewer"],
        ))
        assert result.allowed

    def test_unknown_permission_denied(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="nonexistent", roles=["admin"],
        ))
        assert not result.allowed
        assert "Unknown permission" in result.reason

    def test_unknown_role_denied(self):
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="scan", roles=["unknown-role"],
        ))
        assert not result.allowed

    def test_multi_role_union(self):
        """A user with both viewer and developer roles gets the union of permissions."""
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="scan", roles=["viewer", "developer"],
        ))
        assert result.allowed  # developer has scan

        result = self.engine.check(AuthzRequest(
            user_id="u1", action="audit:read", roles=["viewer", "developer"],
        ))
        assert result.allowed  # viewer has audit:read

    def test_agent_repo_scoped_allowed(self):
        result = self.engine.check(AuthzRequest(
            user_id="agent1", action="scan", roles=["agent"],
            resource_type=ResourceType.REPO.value,
            resource_id="my-repo",
            repo_access=["my-repo", "other-repo"],
        ))
        assert result.allowed

    def test_agent_repo_scoped_denied(self):
        result = self.engine.check(AuthzRequest(
            user_id="agent1", action="scan", roles=["agent"],
            resource_type=ResourceType.REPO.value,
            resource_id="forbidden-repo",
            repo_access=["my-repo"],
        ))
        assert not result.allowed
        assert "forbidden-repo" in result.reason

    def test_agent_global_allowed(self):
        """Agent with global resource type (no repo scoping) should be allowed."""
        result = self.engine.check(AuthzRequest(
            user_id="agent1", action="scan", roles=["agent"],
        ))
        assert result.allowed

    def test_agent_with_other_role_bypasses_repo_scope(self):
        """Agent role combined with another role bypasses repo scoping."""
        result = self.engine.check(AuthzRequest(
            user_id="u1", action="scan", roles=["agent", "developer"],
            resource_type=ResourceType.REPO.value,
            resource_id="forbidden-repo",
            repo_access=["my-repo"],
        ))
        assert result.allowed  # multi-role means agent repo check doesn't apply


# ── TestRequirePermission ────────────────────────────────────────────


class TestRequirePermission:
    """Test the FastAPI dependency function."""

    def setup_method(self):
        set_policy_engine(LocalPolicyEngine())

    def teardown_method(self):
        set_policy_engine(None)

    def test_anonymous_user_passes(self):
        """Anonymous users (auth disabled) should pass all checks."""
        checker = require_permission("scan")
        user = UserContext.anonymous()
        result = checker(user)
        assert result.user_id == "anonymous"

    def test_api_key_user_passes(self):
        """API key users (admin role) should pass all checks."""
        checker = require_permission("scan")
        user = UserContext.from_api_key()
        result = checker(user)
        assert result.user_id == "api-key"

    def test_jwt_admin_passes(self):
        checker = require_permission("config:edit")
        user = UserContext(
            user_id="u1", roles=["admin"],
            auth_method="jwt", is_authenticated=True,
        )
        result = checker(user)
        assert result.user_id == "u1"

    def test_jwt_viewer_denied_scan(self):
        checker = require_permission("scan")
        user = UserContext(
            user_id="u2", roles=["viewer"],
            auth_method="jwt", is_authenticated=True,
        )
        with pytest.raises(HTTPException) as exc_info:
            checker(user)
        assert exc_info.value.status_code == 403

    def test_jwt_developer_allowed_scan(self):
        checker = require_permission("scan")
        user = UserContext(
            user_id="u3", roles=["developer"],
            auth_method="jwt", is_authenticated=True,
        )
        result = checker(user)
        assert result.user_id == "u3"

    def test_jwt_developer_denied_config_edit(self):
        checker = require_permission("config:edit")
        user = UserContext(
            user_id="u4", roles=["developer"],
            auth_method="jwt", is_authenticated=True,
        )
        with pytest.raises(HTTPException) as exc_info:
            checker(user)
        assert exc_info.value.status_code == 403

    def test_unknown_permission_raises_403(self):
        checker = require_permission("nonexistent")
        user = UserContext(
            user_id="u5", roles=["admin"],
            auth_method="jwt", is_authenticated=True,
        )
        with pytest.raises(HTTPException) as exc_info:
            checker(user)
        assert exc_info.value.status_code == 403


# ── TestPolicyEngineSingleton ────────────────────────────────────────


class TestPolicyEngineSingleton:
    """Test get/set/reset of the policy engine singleton."""

    def teardown_method(self):
        set_policy_engine(None)

    def test_default_engine_is_local(self):
        set_policy_engine(None)
        engine = get_policy_engine()
        assert isinstance(engine, LocalPolicyEngine)

    def test_set_custom_engine(self):
        custom = OpenFGAClient()
        set_policy_engine(custom)
        assert get_policy_engine() is custom

    def test_reset_to_none_recreates_local(self):
        set_policy_engine(OpenFGAClient())
        set_policy_engine(None)
        engine = get_policy_engine()
        assert isinstance(engine, LocalPolicyEngine)


# ── TestOpenFGAClientStub ────────────────────────────────────────────


class TestOpenFGAClientStub:
    """Test the OpenFGA stub client."""

    def test_stub_delegates_to_local(self):
        client = OpenFGAClient()
        result = client.check(AuthzRequest(
            user_id="u1", action="scan", roles=["developer"],
        ))
        assert result.allowed

    def test_stub_denies_correctly(self):
        client = OpenFGAClient(api_url="https://fga.example.com")
        result = client.check(AuthzRequest(
            user_id="u1", action="reconcile", roles=["viewer"],
        ))
        assert not result.allowed


# ── TestUserContextAuthz ─────────────────────────────────────────────


class TestUserContextAuthz:
    """Test UserContext authz integration."""

    def test_repo_access_default_empty(self):
        user = UserContext()
        assert user.repo_access == []

    def test_repo_access_set(self):
        user = UserContext(repo_access=["repo-a", "repo-b"])
        assert user.repo_access == ["repo-a", "repo-b"]

    def test_has_permission_positive(self):
        user = UserContext(roles=["developer"])
        assert user.has_permission("scan")
        assert user.has_permission("gate")
        assert user.has_permission("findings:read")

    def test_has_permission_negative(self):
        user = UserContext(roles=["viewer"])
        assert not user.has_permission("scan")
        assert not user.has_permission("reconcile")

    def test_has_permission_unknown(self):
        user = UserContext(roles=["admin"])
        assert not user.has_permission("nonexistent")

    def test_has_permission_admin_has_all(self):
        user = UserContext(roles=["admin"])
        for perm in Permission:
            assert user.has_permission(perm.value), f"admin should have {perm.value}"


# ── TestSyncStubs ────────────────────────────────────────────────────


class TestSyncStubs:
    """Test the sync no-op stubs."""

    def test_sync_roles_on_login_passthrough(self):
        roles = sync_roles_on_login("u1", ["developer", "viewer"])
        assert roles == ["developer", "viewer"]

    def test_sync_repo_access_empty(self):
        repos = sync_repo_access("u1", org_id="org1")
        assert repos == []


# ── TestServerBackwardCompat ─────────────────────────────────────────


class TestServerBackwardCompat:
    """Test that server endpoints remain accessible under backward-compatible modes."""

    def setup_method(self):
        from guard.server import app
        from fastapi.testclient import TestClient
        self.client = TestClient(app)

    def test_health_no_auth(self):
        resp = self.client.get("/health")
        assert resp.status_code == 200

    def test_dashboard_no_auth(self):
        resp = self.client.get("/dashboard")
        assert resp.status_code == 200

    def test_onboarding_no_auth(self):
        resp = self.client.get("/api/onboarding-status")
        assert resp.status_code == 200

    def test_api_docs_no_auth(self):
        resp = self.client.get("/api")
        assert resp.status_code == 200
