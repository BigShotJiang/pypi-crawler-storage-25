"""Tests for LLM-powered confidence scoring."""

from __future__ import annotations

from unittest.mock import MagicMock

from guard.core.confidence_scorer import score_findings
from guard.core.models import Evidence, Finding, Severity


def _make_finding(
    rule_id: str = "TEST-001",
    confidence: float = 0.5,
    deterministic: bool = False,
    file: str = "app.py",
    line: int = 1,
    snippet: str = "# TODO fix",
) -> Finding:
    return Finding(
        finding_id=f"{rule_id}-{file}:{line}",
        rule_id=rule_id,
        severity=Severity.LOW,
        message="Test finding",
        evidence=Evidence(file=file, lines=[line], snippet=snippet),
        confidence=confidence,
        deterministic=deterministic,
    )


class TestScoreFindings:
    def test_skips_deterministic_findings(self):
        llm = MagicMock()
        findings = [_make_finding(deterministic=True, confidence=1.0)]
        result = score_findings(findings, llm)
        llm.analyze.assert_not_called()
        assert result[0].confidence == 1.0

    def test_rescores_non_deterministic_finding(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 0.9}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        llm.analyze.assert_called_once()
        assert result[0].confidence == 0.9

    def test_marks_high_confidence_as_deterministic(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 0.98}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        assert result[0].deterministic is True
        assert result[0].confidence == 0.98

    def test_does_not_mark_low_confidence_as_deterministic(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 0.6}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        assert result[0].deterministic is False
        assert result[0].confidence == 0.6

    def test_caps_at_max_findings(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 0.8}
        findings = [_make_finding(confidence=0.5, deterministic=False, line=i) for i in range(10)]
        result = score_findings(findings, llm, max_findings=3)
        assert llm.analyze.call_count == 3
        # First 3 rescored, rest unchanged
        assert result[0].confidence == 0.8
        assert result[3].confidence == 0.5

    def test_clamps_confidence_to_valid_range(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 1.5}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        assert result[0].confidence == 1.0

    def test_handles_llm_error_gracefully(self):
        llm = MagicMock()
        llm.analyze.side_effect = RuntimeError("API down")
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        # Original confidence unchanged
        assert result[0].confidence == 0.5

    def test_handles_no_confidence_in_response(self):
        llm = MagicMock()
        llm.analyze.return_value = {"summary": "looks fine"}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        assert result[0].confidence == 0.5

    def test_extracts_confidence_from_findings_list(self):
        llm = MagicMock()
        llm.analyze.return_value = {"findings": [{"confidence": 0.85}]}
        findings = [_make_finding(confidence=0.5, deterministic=False)]
        result = score_findings(findings, llm)
        assert result[0].confidence == 0.85

    def test_mixed_deterministic_and_non(self):
        llm = MagicMock()
        llm.analyze.return_value = {"confidence": 0.9}
        findings = [
            _make_finding(confidence=1.0, deterministic=True, line=1),
            _make_finding(confidence=0.5, deterministic=False, line=2),
            _make_finding(confidence=1.0, deterministic=True, line=3),
        ]
        result = score_findings(findings, llm)
        assert llm.analyze.call_count == 1
        assert result[0].confidence == 1.0  # unchanged
        assert result[1].confidence == 0.9  # rescored
        assert result[2].confidence == 1.0  # unchanged

    def test_empty_findings_list(self):
        llm = MagicMock()
        result = score_findings([], llm)
        llm.analyze.assert_not_called()
        assert result == []


class TestLLMOpenAI:
    def test_parse_response_valid_json(self):
        from guard.providers.llm_openai import LLMOpenAI
        result = LLMOpenAI._parse_response('{"confidence": 0.8, "findings": []}')
        assert result["confidence"] == 0.8

    def test_parse_response_no_json(self):
        from guard.providers.llm_openai import LLMOpenAI
        result = LLMOpenAI._parse_response("no json here")
        assert result["findings"] == []

    def test_no_api_key_returns_empty(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        from guard.providers.llm_openai import LLMOpenAI
        provider = LLMOpenAI(api_key="")
        result = provider.analyze("test", {"file": "a.py", "content": "x"})
        assert result["findings"] == []


class TestLLMOllama:
    def test_parse_response_valid_json(self):
        from guard.providers.llm_ollama import LLMOllama
        result = LLMOllama._parse_response('{"confidence": 0.7}')
        assert result["confidence"] == 0.7

    def test_parse_response_no_json(self):
        from guard.providers.llm_ollama import LLMOllama
        result = LLMOllama._parse_response("no json")
        assert result["findings"] == []
