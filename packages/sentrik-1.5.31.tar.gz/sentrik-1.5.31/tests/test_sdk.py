"""Tests for the compliance-aware AI agent SDK."""

from __future__ import annotations

import json
import pytest
from unittest.mock import patch

from guard.sdk.checker import (
    ComplianceResult,
    check_code,
    check_diff,
    get_compliance_context,
    get_rules_for_file,
    _glob_matches,
    _rule_to_constraint,
)


# ---------------------------------------------------------------------------
# Helpers — minimal rule sets for testing
# ---------------------------------------------------------------------------

_OWASP_STRCPY_RULE = {
    "id": "OWASP-A08-CPP-001",
    "name": "no-strcpy",
    "description": "strcpy is unsafe — use strncpy or snprintf instead",
    "type": "regex",
    "pattern": r"\bstrcpy\s*\(",
    "severity": "critical",
    "file_glob": "**/*.{c,cpp,h,hpp}",
    "standard": "OWASP Top 10",
    "clause": "A08:2021",
    "remediation_guidance": "Replace strcpy with strncpy or snprintf to prevent buffer overflow",
    "pack_id": "owasp-top-10",
}

_IEC_MALLOC_RULE = {
    "id": "IEC62304-5.5.5-CPP",
    "name": "no-unsafe-memory",
    "description": "Dynamic memory allocation is unsafe for safety-critical software",
    "type": "regex",
    "pattern": r"\bmalloc\s*\(",
    "severity": "high",
    "file_glob": "**/*.{c,cpp,h,hpp}",
    "standard": "IEC 62304",
    "clause": "5.5.5",
    "remediation_guidance": "Use static allocation or safe wrappers instead of malloc",
    "pack_id": "fda-iec-62304",
}

_PY_EVAL_RULE = {
    "id": "OWASP-A03-001",
    "name": "no-eval",
    "description": "eval() can execute arbitrary code and is a critical injection risk",
    "type": "regex",
    "pattern": r"\beval\s*\(",
    "severity": "critical",
    "file_glob": "**/*.py",
    "standard": "OWASP Top 10",
    "clause": "A03:2021",
    "remediation_guidance": "Use ast.literal_eval or a safe parser instead of eval()",
    "pack_id": "owasp-top-10",
}

_DOC_OBLIGATION_RULE = {
    "id": "IEC62304-DOC-001",
    "name": "software-plan",
    "description": "Software development plan required",
    "type": "documentation_obligation",
    "severity": "medium",
    "file_glob": "**/*",
    "standard": "IEC 62304",
    "pack_id": "fda-iec-62304",
}


MOCK_RULES = [_OWASP_STRCPY_RULE, _IEC_MALLOC_RULE, _PY_EVAL_RULE, _DOC_OBLIGATION_RULE]


def _mock_load_rules(frameworks=None):
    """Return mock rules, optionally filtered by framework."""
    from guard.sdk.checker import _load_rules as real_load
    rules = list(MOCK_RULES)
    if frameworks is None:
        return rules
    fw_lower = [f.lower() for f in frameworks]
    return [
        r for r in rules
        if any(
            fw in (r.get("standard") or "").lower()
            or fw in (r.get("pack_id") or "").lower()
            for fw in fw_lower
        )
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCheckCode:
    """Tests for check_code()."""

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_code_with_violation(self, mock_rules):
        """Code containing strcpy should be flagged as non-compliant."""
        result = check_code('strcpy(dest, src);', "src/main.cpp")
        assert not result.compliant
        assert len(result.findings) >= 1
        assert any(f["rule_id"] == "OWASP-A08-CPP-001" for f in result.findings)
        assert any("strcpy" in s.lower() or "strncpy" in s.lower() for s in result.suggestions)

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_code_clean(self, mock_rules):
        """Clean code should return compliant=True."""
        result = check_code('int x = 42;\nreturn x;\n', "src/main.cpp")
        assert result.compliant
        assert len(result.findings) == 0
        assert result.confidence == 1.0

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_code_with_framework_filter(self, mock_rules):
        """Only rules from the specified framework should be checked."""
        # malloc should match IEC 62304 but not OWASP when filtering to IEC
        result = check_code('void *p = malloc(100);', "src/memory.cpp", frameworks=["IEC 62304"])
        assert not result.compliant
        assert any(f["rule_id"] == "IEC62304-5.5.5-CPP" for f in result.findings)

        # Same code should not be flagged if we only check OWASP
        result2 = check_code('void *p = malloc(100);', "src/memory.cpp", frameworks=["OWASP"])
        # malloc is not in OWASP rules, so should be compliant
        assert result2.compliant

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_code_python_eval(self, mock_rules):
        """Python eval() should be flagged."""
        result = check_code('result = eval(user_input)', "src/handler.py")
        assert not result.compliant
        assert any(f["rule_id"] == "OWASP-A03-001" for f in result.findings)

    def test_empty_code(self):
        """Empty string should return compliant."""
        result = check_code("", "src/main.cpp")
        assert result.compliant
        assert len(result.findings) == 0

    def test_whitespace_only_code(self):
        """Whitespace-only code should return compliant."""
        result = check_code("   \n\n  ", "src/main.cpp")
        assert result.compliant


class TestCheckDiff:
    """Tests for check_diff()."""

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_diff_new_lines_only(self, mock_rules):
        """Only added lines in the diff should be checked."""
        diff = """\
--- a/src/main.cpp
+++ b/src/main.cpp
@@ -1,3 +1,4 @@
 int main() {
-    return 0;
+    char dest[10];
+    strcpy(dest, "hello");
+    return 0;
 }
"""
        result = check_diff(diff)
        assert not result.compliant
        assert any(f["rule_id"] == "OWASP-A08-CPP-001" for f in result.findings)

    def test_check_diff_empty(self):
        """Empty diff should return compliant."""
        result = check_diff("")
        assert result.compliant

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_check_diff_clean_additions(self, mock_rules):
        """Diff with only clean additions should be compliant."""
        diff = """\
--- a/src/main.cpp
+++ b/src/main.cpp
@@ -1,3 +1,4 @@
 int main() {
+    int x = 42;
     return 0;
 }
"""
        result = check_diff(diff)
        assert result.compliant


class TestGetRulesForFile:
    """Tests for get_rules_for_file()."""

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_get_rules_for_cpp_file(self, mock_rules):
        """C++ files should get C/C++ rules."""
        rules = get_rules_for_file("src/main.cpp")
        rule_ids = [r["id"] for r in rules]
        assert "OWASP-A08-CPP-001" in rule_ids
        assert "IEC62304-5.5.5-CPP" in rule_ids
        # Python-only rule should not appear
        assert "OWASP-A03-001" not in rule_ids

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_get_rules_for_python_file(self, mock_rules):
        """Python files should get Python rules."""
        rules = get_rules_for_file("src/handler.py")
        rule_ids = [r["id"] for r in rules]
        assert "OWASP-A03-001" in rule_ids
        # C++ rules should not appear for .py files
        assert "OWASP-A08-CPP-001" not in rule_ids

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_unknown_file_type(self, mock_rules):
        """Unknown file types should not get language-specific rules."""
        rules = get_rules_for_file("config.unknown")
        rule_ids = [r["id"] for r in rules]
        # Language-specific rules should not appear
        assert "OWASP-A08-CPP-001" not in rule_ids
        assert "OWASP-A03-001" not in rule_ids
        # Generic globs (like **/*) may still match
        assert all(r.get("type") == "documentation_obligation" for r in rules if r["id"] not in ("OWASP-A08-CPP-001", "OWASP-A03-001", "IEC62304-5.5.5-CPP"))


class TestGetComplianceContext:
    """Tests for get_compliance_context()."""

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_get_compliance_context(self, mock_rules):
        """Context should contain structured compliance info."""
        ctx = get_compliance_context("src/main.cpp")
        assert ctx["file"] == "src/main.cpp"
        assert isinstance(ctx["applicable_rules"], list)
        assert isinstance(ctx["frameworks"], list)
        assert isinstance(ctx["constraints"], list)
        assert len(ctx["applicable_rules"]) >= 1

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_context_includes_constraints(self, mock_rules):
        """Context should include human-readable constraints."""
        ctx = get_compliance_context("src/main.cpp")
        assert len(ctx["constraints"]) >= 1
        # Should include actionable remediation guidance
        all_constraints = " ".join(ctx["constraints"]).lower()
        assert "strcpy" in all_constraints or "strncpy" in all_constraints or "malloc" in all_constraints

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_context_frameworks(self, mock_rules):
        """Context should list applicable frameworks."""
        ctx = get_compliance_context("src/main.cpp")
        # C++ file should match rules from both OWASP and IEC 62304
        assert "OWASP Top 10" in ctx["frameworks"]
        assert "IEC 62304" in ctx["frameworks"]

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_context_with_framework_filter(self, mock_rules):
        """Context with framework filter should only show relevant rules."""
        ctx = get_compliance_context("src/main.cpp", frameworks=["IEC 62304"])
        # Should only have IEC 62304
        assert "IEC 62304" in ctx["frameworks"]
        rule_ids = [r["id"] for r in ctx["applicable_rules"]]
        assert "IEC62304-5.5.5-CPP" in rule_ids


class TestGlobMatching:
    """Tests for internal glob matching."""

    def test_brace_expansion(self):
        assert _glob_matches("**/*.{py,cpp,h}", "src/main.cpp")
        assert _glob_matches("**/*.{py,cpp,h}", "main.py")
        assert not _glob_matches("**/*.{py,cpp,h}", "main.js")

    def test_simple_glob(self):
        assert _glob_matches("*.py", "test.py")
        assert not _glob_matches("*.py", "test.cpp")

    def test_double_star_prefix(self):
        assert _glob_matches("**/*.cpp", "src/deep/main.cpp")


class TestRuleToConstraint:
    """Tests for _rule_to_constraint()."""

    def test_with_remediation(self):
        c = _rule_to_constraint({"remediation_guidance": "Use strncpy", "description": "strcpy unsafe"})
        assert c == "Use strncpy"

    def test_regex_without_remediation(self):
        c = _rule_to_constraint({"type": "regex", "description": "eval is unsafe"})
        assert "eval is unsafe" in c

    def test_empty_rule(self):
        c = _rule_to_constraint({})
        assert c == ""


class TestComplianceResult:
    """Tests for ComplianceResult dataclass."""

    def test_defaults(self):
        r = ComplianceResult(compliant=True)
        assert r.compliant is True
        assert r.findings == []
        assert r.suggestions == []
        assert r.confidence == 1.0

    def test_with_findings(self):
        r = ComplianceResult(
            compliant=False,
            findings=[{"rule_id": "TEST-001", "severity": "high"}],
            suggestions=["Fix it"],
            confidence=0.8,
        )
        assert not r.compliant
        assert len(r.findings) == 1
        assert r.confidence == 0.8


# ---------------------------------------------------------------------------
# API endpoint tests
# ---------------------------------------------------------------------------


class TestSDKAPIEndpoints:
    """Tests for the SDK REST API endpoints."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient
        from guard.server import app
        return TestClient(app)

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_api_check_endpoint(self, mock_rules, client):
        """POST /api/sdk/check should return compliance results."""
        resp = client.post("/api/sdk/check", json={
            "code": "strcpy(dest, src);",
            "filename": "src/main.cpp",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["compliant"] is False
        assert len(data["findings"]) >= 1
        assert isinstance(data["suggestions"], list)

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_api_check_clean(self, mock_rules, client):
        """POST /api/sdk/check with clean code should return compliant."""
        resp = client.post("/api/sdk/check", json={
            "code": "int x = 42;",
            "filename": "src/main.cpp",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["compliant"] is True

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_api_context_endpoint(self, mock_rules, client):
        """GET /api/sdk/context should return compliance context."""
        resp = client.get("/api/sdk/context", params={"filename": "src/main.cpp"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["file"] == "src/main.cpp"
        assert "applicable_rules" in data
        assert "frameworks" in data
        assert "constraints" in data

    @patch("guard.sdk.checker._load_rules", side_effect=_mock_load_rules)
    def test_api_rules_endpoint(self, mock_rules, client):
        """GET /api/sdk/rules should return applicable rules."""
        resp = client.get("/api/sdk/rules", params={"filename": "src/main.cpp"})
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        rule_ids = [r["id"] for r in data]
        assert "OWASP-A08-CPP-001" in rule_ids
