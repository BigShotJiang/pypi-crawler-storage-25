"""Tests for standards pack loading, composition, and pack validation."""

from __future__ import annotations

import copy
from pathlib import Path

import pytest
import yaml

from guard.config import GuardConfig
from guard.packs.registry import (
    PackInfo,
    _BUILTIN_PACKS,
    apply_pack_overrides,
    delete_custom_pack,
    export_pack,
    import_pack,
    is_known_pack,
    list_available_packs,
    load_pack_rules,
    validate_pack_yaml,
    _discover_custom_pack_ids,
)
from guard.providers.factory import _load_pack_rules, build_providers
from guard.rules.engine import RulesEngine
from guard.rules.rule_schema import RuleDefinition


# ===================================================================
# Pack discovery
# ===================================================================


class TestListAvailablePacks:
    def test_returns_fda_pack(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "fda-iec-62304" in ids

    def test_returns_owasp_pack(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "owasp-top-10" in ids

    def test_returns_soc2_pack(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "soc2" in ids

    def test_fda_pack_has_metadata(self):
        packs = list_available_packs()
        fda = next(p for p in packs if p.pack_id == "fda-iec-62304")
        assert fda.name == "FDA IEC 62304"
        assert fda.rule_count > 0
        assert fda.description != ""

    def test_owasp_pack_has_metadata(self):
        packs = list_available_packs()
        owasp = next(p for p in packs if p.pack_id == "owasp-top-10")
        assert owasp.name == "OWASP Top 10"
        assert owasp.rule_count > 0
        assert owasp.description != ""

    def test_soc2_pack_has_metadata(self):
        packs = list_available_packs()
        soc2 = next(p for p in packs if p.pack_id == "soc2")
        assert soc2.name == "SOC2 Trust Services"
        assert soc2.rule_count > 0
        assert soc2.description != ""

    def test_pack_info_model(self):
        info = PackInfo(pack_id="test", name="Test Pack", description="desc", rule_count=5)
        assert info.pack_id == "test"
        assert info.rule_count == 5


# ===================================================================
# Pack loading
# ===================================================================


class TestLoadPackRules:
    def test_fda_pack_loads(self):
        rules = load_pack_rules("fda-iec-62304")
        assert len(rules) > 0

    def test_unknown_pack_returns_empty(self):
        rules = load_pack_rules("nonexistent-pack")
        assert rules == []

    def test_pack_id_stamped(self):
        rules = load_pack_rules("fda-iec-62304")
        for r in rules:
            assert r["pack_id"] == "fda-iec-62304"

    def test_all_rules_have_required_fields(self):
        rules = load_pack_rules("fda-iec-62304")
        for r in rules:
            assert "id" in r
            assert "name" in r
            assert "type" in r

    def test_all_rules_are_valid(self):
        rules = load_pack_rules("fda-iec-62304")
        for r in rules:
            # Should parse successfully
            rd = RuleDefinition(**r)
            assert rd.id == r["id"]


# ===================================================================
# FDA pack content validation
# ===================================================================


class TestFDAPack:
    @pytest.fixture()
    def fda_rules(self):
        return load_pack_rules("fda-iec-62304")

    def test_has_code_rules(self, fda_rules):
        code_rules = [r for r in fda_rules if r["type"] == "regex"]
        assert len(code_rules) >= 4

    def test_has_documentation_obligations(self, fda_rules):
        obligations = [r for r in fda_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 8

    def test_has_ml_obligations(self, fda_rules):
        ml_rules = [r for r in fda_rules if r["id"].startswith("IEC62304-ML")]
        assert len(ml_rules) >= 2

    def test_all_rules_have_standard(self, fda_rules):
        for r in fda_rules:
            assert r.get("standard") == "IEC 62304"

    def test_all_rules_have_clause(self, fda_rules):
        for r in fda_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, fda_rules):
        for r in fda_rules:
            assert "fda" in r.get("tags", []), f"Rule {r['id']} missing 'fda' tag"

    def test_code_rules_have_remediation(self, fda_rules):
        code_rules = [r for r in fda_rules if r["type"] == "regex"]
        for r in code_rules:
            assert r.get("remediation_guidance"), f"Rule {r['id']} missing remediation_guidance"


# ===================================================================
# Pack composition with user rules
# ===================================================================


class TestPackComposition:
    def test_load_pack_rules_helper(self):
        rules = _load_pack_rules(["owasp-top-10"])
        assert len(rules) > 0

    def test_empty_pack_list(self):
        rules = _load_pack_rules([])
        assert rules == []

    def test_unknown_pack_in_list(self):
        rules = _load_pack_rules(["nonexistent"])
        assert rules == []

    def test_build_providers_includes_packs(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "standards.yaml").write_text("rules:\n  - id: USER-001\n    name: user-rule\n    type: regex\n    pattern: TODO\n    severity: low\n")
        (tmp_path / "items.json").write_text("[]")

        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            standards_packs=["owasp-top-10"],
        )
        _, _, _, rules_engine, _ = build_providers(config)
        # Engine should have both user rules and pack rules
        assert len(rules_engine._rules) > 1

    def test_pack_rules_evaluate(self, tmp_path):
        """Pack regex rules should produce findings against matching code."""
        (tmp_path / "app.py").write_text("assert x > 0\n", encoding="utf-8")

        rules = load_pack_rules("fda-iec-62304")
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))

        assert any(f.rule_id == "IEC62304-CODE-001" for f in findings)


# ===================================================================
# Pack YAML structure
# ===================================================================


# ===================================================================
# OWASP pack content validation
# ===================================================================


class TestOWASPPack:
    @pytest.fixture()
    def owasp_rules(self):
        return load_pack_rules("owasp-top-10")

    def test_has_code_rules(self, owasp_rules):
        code_rules = [r for r in owasp_rules if r["type"] == "regex"]
        assert len(code_rules) >= 10

    def test_has_documentation_obligations(self, owasp_rules):
        obligations = [r for r in owasp_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 4

    def test_all_rules_have_standard(self, owasp_rules):
        for r in owasp_rules:
            assert r.get("standard") == "OWASP Top 10", f"Rule {r['id']} missing standard"

    def test_all_rules_have_clause(self, owasp_rules):
        for r in owasp_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, owasp_rules):
        for r in owasp_rules:
            assert "owasp" in r.get("tags", []), f"Rule {r['id']} missing 'owasp' tag"

    def test_code_rules_have_remediation(self, owasp_rules):
        code_rules = [r for r in owasp_rules if r["type"] == "regex"]
        for r in code_rules:
            assert r.get("remediation_guidance"), f"Rule {r['id']} missing remediation_guidance"

    def test_has_injection_rules(self, owasp_rules):
        injection = [r for r in owasp_rules if "A03" in r["id"]]
        assert len(injection) >= 2

    def test_has_critical_severity_rules(self, owasp_rules):
        critical = [r for r in owasp_rules if r.get("severity") == "critical"]
        assert len(critical) >= 3


# ===================================================================
# SOC2 pack content validation
# ===================================================================


class TestSOC2Pack:
    @pytest.fixture()
    def soc2_rules(self):
        return load_pack_rules("soc2")

    def test_has_code_rules(self, soc2_rules):
        code_rules = [r for r in soc2_rules if r["type"] == "regex"]
        assert len(code_rules) >= 5

    def test_has_documentation_obligations(self, soc2_rules):
        obligations = [r for r in soc2_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 7

    def test_all_rules_have_standard(self, soc2_rules):
        for r in soc2_rules:
            assert r.get("standard") == "SOC2", f"Rule {r['id']} missing standard"

    def test_all_rules_have_clause(self, soc2_rules):
        for r in soc2_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, soc2_rules):
        for r in soc2_rules:
            assert "soc2" in r.get("tags", []), f"Rule {r['id']} missing 'soc2' tag"

    def test_code_rules_have_remediation(self, soc2_rules):
        code_rules = [r for r in soc2_rules if r["type"] == "regex"]
        for r in code_rules:
            assert r.get("remediation_guidance"), f"Rule {r['id']} missing remediation_guidance"

    def test_has_access_control_rules(self, soc2_rules):
        cc6 = [r for r in soc2_rules if r["id"].startswith("SOC2-CC6")]
        assert len(cc6) >= 3

    def test_has_operations_rules(self, soc2_rules):
        cc7 = [r for r in soc2_rules if r["id"].startswith("SOC2-CC7")]
        assert len(cc7) >= 3

    def test_has_change_management_rules(self, soc2_rules):
        cc8 = [r for r in soc2_rules if r["id"].startswith("SOC2-CC8")]
        assert len(cc8) >= 2

    def test_has_confidentiality_rules(self, soc2_rules):
        c1 = [r for r in soc2_rules if r["id"].startswith("SOC2-C1")]
        assert len(c1) >= 2


# ===================================================================
# Pack YAML structure
# ===================================================================


class TestPackYAMLStructure:
    @pytest.mark.parametrize("package_path", [
        "guard.packs.fda_iec_62304",
        "guard.packs.owasp_top_10",
        "guard.packs.soc2",
    ])
    def test_pack_yaml_is_valid(self, package_path):
        import importlib.resources

        pack_ref = importlib.resources.files(package_path)
        pack_yaml = pack_ref.joinpath("pack.yaml")
        raw = yaml.safe_load(pack_yaml.read_text(encoding="utf-8"))

        assert "name" in raw
        assert "description" in raw
        assert "rules" in raw
        assert isinstance(raw["rules"], list)

    @pytest.mark.parametrize("pack_id", ["fda-iec-62304", "owasp-top-10", "soc2"])
    def test_all_pack_rules_are_valid(self, pack_id):
        rules = load_pack_rules(pack_id)
        for r in rules:
            rd = RuleDefinition(**r)
            assert rd.id == r["id"]
            assert rd.pack_id == pack_id


# ===================================================================
# Custom pack discovery
# ===================================================================


def _make_custom_pack(base_dir: Path, pack_id: str, pack_data: dict | None = None):
    """Helper: write a minimal custom pack to disk."""
    if pack_data is None:
        pack_data = {
            "name": f"Custom {pack_id}",
            "description": "A custom pack",
            "rules": [
                {
                    "id": f"{pack_id}-001",
                    "name": "custom-rule",
                    "type": "regex",
                    "pattern": "TODO",
                    "severity": "low",
                }
            ],
        }
    pack_dir = base_dir / ".guard" / "packs" / pack_id
    pack_dir.mkdir(parents=True, exist_ok=True)
    (pack_dir / "pack.yaml").write_text(
        yaml.dump(pack_data, default_flow_style=False), encoding="utf-8"
    )
    return pack_dir


class TestCustomPackDiscovery:
    def test_no_custom_dir(self, tmp_path):
        ids = _discover_custom_pack_ids(tmp_path)
        assert ids == []

    def test_empty_custom_dir(self, tmp_path):
        (tmp_path / ".guard" / "packs").mkdir(parents=True)
        ids = _discover_custom_pack_ids(tmp_path)
        assert ids == []

    def test_valid_custom_pack_found(self, tmp_path):
        _make_custom_pack(tmp_path, "my-pack")
        ids = _discover_custom_pack_ids(tmp_path)
        assert "my-pack" in ids

    def test_missing_pack_yaml_ignored(self, tmp_path):
        (tmp_path / ".guard" / "packs" / "bad-pack").mkdir(parents=True)
        ids = _discover_custom_pack_ids(tmp_path)
        assert "bad-pack" not in ids

    def test_list_available_includes_custom(self, tmp_path):
        _make_custom_pack(tmp_path, "my-pack")
        packs = list_available_packs(tmp_path)
        ids = {p.pack_id for p in packs}
        assert "my-pack" in ids
        custom = next(p for p in packs if p.pack_id == "my-pack")
        assert custom.source == "custom"

    def test_load_pack_rules_loads_custom(self, tmp_path):
        _make_custom_pack(tmp_path, "my-pack")
        rules = load_pack_rules("my-pack", tmp_path)
        assert len(rules) == 1
        assert rules[0]["id"] == "my-pack-001"
        assert rules[0]["pack_id"] == "my-pack"


# ===================================================================
# Pack overrides
# ===================================================================


class TestPackOverrides:
    def _sample_rules(self):
        return [
            {"id": "R-001", "name": "rule-one", "type": "regex", "severity": "high", "pattern": "TODO"},
            {"id": "R-002", "name": "rule-two", "type": "regex", "severity": "medium", "pattern": "FIXME"},
        ]

    def test_disable_rule(self):
        rules = self._sample_rules()
        overrides = {"test-pack": {"R-001": {"enabled": False}}}
        result = apply_pack_overrides(rules, "test-pack", overrides)
        assert len(result) == 1
        assert result[0]["id"] == "R-002"

    def test_change_severity(self):
        rules = self._sample_rules()
        overrides = {"test-pack": {"R-001": {"severity": "low"}}}
        result = apply_pack_overrides(rules, "test-pack", overrides)
        r001 = next(r for r in result if r["id"] == "R-001")
        assert r001["severity"] == "low"

    def test_change_pattern(self):
        rules = self._sample_rules()
        overrides = {"test-pack": {"R-002": {"pattern": "HACK"}}}
        result = apply_pack_overrides(rules, "test-pack", overrides)
        r002 = next(r for r in result if r["id"] == "R-002")
        assert r002["pattern"] == "HACK"

    def test_no_overrides_passthrough(self):
        rules = self._sample_rules()
        result = apply_pack_overrides(rules, "test-pack", {})
        assert len(result) == 2

    def test_no_mutation_of_originals(self):
        rules = self._sample_rules()
        originals = copy.deepcopy(rules)
        overrides = {"test-pack": {"R-001": {"severity": "low"}}}
        apply_pack_overrides(rules, "test-pack", overrides)
        assert rules == originals

    def test_factory_applies_overrides(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "standards.yaml").write_text(
            "rules:\n  - id: USER-001\n    name: user-rule\n    type: regex\n    pattern: TODO\n    severity: low\n"
        )
        (tmp_path / "items.json").write_text("[]")

        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            standards_packs=["owasp-top-10"],
            pack_overrides={"owasp-top-10": {"OWASP-A01-001": {"enabled": False}}},
        )
        _, _, _, rules_engine, _ = build_providers(config)
        rule_ids = [r["id"] if isinstance(r, dict) else r.id for r in rules_engine._rules]
        assert "OWASP-A01-001" not in rule_ids


# ===================================================================
# Pack validation
# ===================================================================


class TestPackValidation:
    def test_valid_pack(self):
        raw = {
            "name": "Test Pack",
            "rules": [
                {"id": "T-001", "name": "test-rule", "type": "regex", "pattern": "TODO", "severity": "low"},
            ],
        }
        errors = validate_pack_yaml(raw)
        assert errors == []

    def test_missing_name(self):
        raw = {"rules": [{"id": "T-001", "name": "r", "type": "regex"}]}
        errors = validate_pack_yaml(raw)
        assert any("name" in e for e in errors)

    def test_missing_rules(self):
        raw = {"name": "Test"}
        errors = validate_pack_yaml(raw)
        assert any("rules" in e for e in errors)

    def test_invalid_rule_type(self):
        raw = {
            "name": "Test",
            "rules": [{"id": "T-001", "name": "r", "type": "unknown_type"}],
        }
        errors = validate_pack_yaml(raw)
        assert any("invalid type" in e for e in errors)

    def test_invalid_regex(self):
        raw = {
            "name": "Test",
            "rules": [{"id": "T-001", "name": "r", "type": "regex", "pattern": "[invalid"}],
        }
        errors = validate_pack_yaml(raw)
        assert any("invalid regex" in e.lower() for e in errors)

    def test_duplicate_ids(self):
        raw = {
            "name": "Test",
            "rules": [
                {"id": "T-001", "name": "r1", "type": "regex", "pattern": "a"},
                {"id": "T-001", "name": "r2", "type": "regex", "pattern": "b"},
            ],
        }
        errors = validate_pack_yaml(raw)
        assert any("Duplicate" in e for e in errors)


# ===================================================================
# Pack import/export
# ===================================================================


class TestPackImportExport:
    def _valid_pack_data(self):
        return {
            "name": "Imported Pack",
            "description": "An imported pack",
            "rules": [
                {"id": "IMP-001", "name": "imported-rule", "type": "regex", "pattern": "TODO", "severity": "low"},
            ],
        }

    def test_import_creates_pack(self, tmp_path):
        raw = self._valid_pack_data()
        path = import_pack("my-import", raw, base_dir=tmp_path)
        assert path.exists()
        assert (tmp_path / ".guard" / "packs" / "my-import" / "pack.yaml").exists()

    def test_import_rejects_builtin_name(self, tmp_path):
        with pytest.raises(ValueError, match="built-in"):
            import_pack("fda-iec-62304", self._valid_pack_data(), base_dir=tmp_path)

    def test_import_rejects_overwrite_by_default(self, tmp_path):
        raw = self._valid_pack_data()
        import_pack("my-import", raw, base_dir=tmp_path)
        with pytest.raises(ValueError, match="already exists"):
            import_pack("my-import", raw, base_dir=tmp_path)

    def test_import_overwrite_flag(self, tmp_path):
        raw = self._valid_pack_data()
        import_pack("my-import", raw, base_dir=tmp_path)
        raw["name"] = "Updated Pack"
        path = import_pack("my-import", raw, base_dir=tmp_path, overwrite=True)
        assert path.exists()
        reloaded = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert reloaded["name"] == "Updated Pack"

    def test_export_builtin(self):
        raw = export_pack("fda-iec-62304")
        assert "name" in raw
        assert "rules" in raw

    def test_export_custom(self, tmp_path):
        _make_custom_pack(tmp_path, "my-pack")
        raw = export_pack("my-pack", base_dir=tmp_path)
        assert raw["name"] == "Custom my-pack"

    def test_export_unknown_raises(self, tmp_path):
        with pytest.raises(ValueError, match="Unknown pack"):
            export_pack("nonexistent", base_dir=tmp_path)

    def test_delete_custom(self, tmp_path):
        _make_custom_pack(tmp_path, "my-pack")
        delete_custom_pack("my-pack", base_dir=tmp_path)
        assert not (tmp_path / ".guard" / "packs" / "my-pack").exists()

    def test_delete_builtin_raises(self, tmp_path):
        with pytest.raises(ValueError, match="built-in"):
            delete_custom_pack("fda-iec-62304", base_dir=tmp_path)


# ===================================================================
# Config validation with custom packs
# ===================================================================


class TestPackRulesStructure:
    """Tests that pack rules endpoint returns correct structure (used by dashboard)."""

    def test_export_pack_has_rules_list(self):
        raw = export_pack("fda-iec-62304")
        assert "rules" in raw
        assert isinstance(raw["rules"], list)
        for rule in raw["rules"]:
            assert "id" in rule
            assert "name" in rule
            assert "type" in rule

    def test_export_pack_rules_match_load(self):
        raw = export_pack("fda-iec-62304")
        loaded = load_pack_rules("fda-iec-62304")
        export_ids = {r["id"] for r in raw["rules"]}
        loaded_ids = {r["id"] for r in loaded}
        assert export_ids == loaded_ids


# ===================================================================
# New packs — HIPAA, PCI DSS, ISO 27001
# ===================================================================


class TestHIPAAPack:
    @pytest.fixture()
    def hipaa_rules(self):
        return load_pack_rules("hipaa")

    def test_hipaa_pack_loads(self, hipaa_rules):
        assert len(hipaa_rules) == 25

    def test_has_code_rules(self, hipaa_rules):
        code_rules = [r for r in hipaa_rules if r["type"] in ("regex", "required_pattern")]
        assert len(code_rules) >= 6

    def test_has_documentation_obligations(self, hipaa_rules):
        obligations = [r for r in hipaa_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 9

    def test_all_rules_have_standard(self, hipaa_rules):
        for r in hipaa_rules:
            assert r.get("standard") == "HIPAA"

    def test_all_rules_have_clause(self, hipaa_rules):
        for r in hipaa_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, hipaa_rules):
        for r in hipaa_rules:
            assert "hipaa" in r.get("tags", []), f"Rule {r['id']} missing 'hipaa' tag"

    def test_pack_id_stamped(self, hipaa_rules):
        for r in hipaa_rules:
            assert r["pack_id"] == "hipaa"


class TestPCIDSSPack:
    @pytest.fixture()
    def pci_rules(self):
        return load_pack_rules("pci-dss")

    def test_pci_pack_loads(self, pci_rules):
        assert len(pci_rules) == 33

    def test_has_code_rules(self, pci_rules):
        code_rules = [r for r in pci_rules if r["type"] == "regex"]
        assert len(code_rules) >= 8

    def test_has_documentation_obligations(self, pci_rules):
        obligations = [r for r in pci_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 8

    def test_all_rules_have_standard(self, pci_rules):
        for r in pci_rules:
            assert r.get("standard") == "PCI DSS"

    def test_all_rules_have_clause(self, pci_rules):
        for r in pci_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, pci_rules):
        for r in pci_rules:
            assert "pci-dss" in r.get("tags", []), f"Rule {r['id']} missing 'pci-dss' tag"

    def test_pack_id_stamped(self, pci_rules):
        for r in pci_rules:
            assert r["pack_id"] == "pci-dss"


class TestISO27001Pack:
    @pytest.fixture()
    def iso_rules(self):
        return load_pack_rules("iso-27001")

    def test_iso_pack_loads(self, iso_rules):
        assert len(iso_rules) == 32

    def test_has_code_rules(self, iso_rules):
        code_rules = [r for r in iso_rules if r["type"] == "regex"]
        assert len(code_rules) >= 5

    def test_has_documentation_obligations(self, iso_rules):
        obligations = [r for r in iso_rules if r["type"] == "documentation_obligation"]
        assert len(obligations) >= 9

    def test_all_rules_have_standard(self, iso_rules):
        for r in iso_rules:
            assert r.get("standard") == "ISO 27001"

    def test_all_rules_have_clause(self, iso_rules):
        for r in iso_rules:
            assert r.get("clause"), f"Rule {r['id']} missing clause"

    def test_all_rules_have_tags(self, iso_rules):
        for r in iso_rules:
            assert "iso-27001" in r.get("tags", []), f"Rule {r['id']} missing 'iso-27001' tag"

    def test_pack_id_stamped(self, iso_rules):
        for r in iso_rules:
            assert r["pack_id"] == "iso-27001"


class TestNewPacksDiscovery:
    def test_hipaa_in_available_packs(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "hipaa" in ids

    def test_pci_dss_in_available_packs(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "pci-dss" in ids

    def test_iso_27001_in_available_packs(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "iso-27001" in ids

    def test_builtin_packs_count(self):
        assert len(_BUILTIN_PACKS) == 23

    def test_all_new_packs_validate(self):
        for pack_id in ("hipaa", "pci-dss", "iso-27001"):
            raw = export_pack(pack_id)
            errors = validate_pack_yaml(raw)
            assert errors == [], f"Pack {pack_id} has validation errors: {errors}"


class TestNewPacksYAMLStructure:
    """Validate YAML structure of all new packs."""

    @pytest.mark.parametrize("pack_id", ["hipaa", "pci-dss", "iso-27001"])
    def test_pack_has_name_and_description(self, pack_id):
        raw = export_pack(pack_id)
        assert "name" in raw
        assert "description" in raw
        assert len(raw["description"]) > 10

    @pytest.mark.parametrize("pack_id", ["hipaa", "pci-dss", "iso-27001"])
    def test_pack_rules_have_required_fields(self, pack_id):
        rules = load_pack_rules(pack_id)
        for r in rules:
            assert "id" in r
            assert "name" in r
            assert "type" in r
            assert "severity" in r
            assert "standard" in r
            assert "clause" in r
            assert "compliance_category" in r
            assert "tags" in r

    @pytest.mark.parametrize("pack_id", ["hipaa", "pci-dss", "iso-27001"])
    def test_pack_code_rules_have_remediation(self, pack_id):
        rules = load_pack_rules(pack_id)
        code_rules = [r for r in rules if r["type"] in ("regex", "required_pattern")]
        for r in code_rules:
            assert r.get("remediation_guidance"), f"Rule {r['id']} missing remediation_guidance"

    @pytest.mark.parametrize("pack_id", ["hipaa", "pci-dss", "iso-27001"])
    def test_pack_rule_ids_unique(self, pack_id):
        rules = load_pack_rules(pack_id)
        ids = [r["id"] for r in rules]
        assert len(ids) == len(set(ids)), f"Duplicate IDs in {pack_id}"


class TestCustomPacksLicenseGating:
    """Verify custom_packs feature gating and per-tier limits."""

    def test_custom_packs_in_all_tiers(self):
        from guard.core.licensing import TIER_FEATURES
        for tier in ("FREE", "TRIAL", "TEAM", "ORG", "ENTERPRISE"):
            assert "custom_packs" in TIER_FEATURES[tier], f"custom_packs missing from {tier}"

    def test_custom_pack_limits_per_tier(self):
        from guard.core.licensing import MAX_CUSTOM_PACKS
        assert MAX_CUSTOM_PACKS["FREE"] == 5
        assert MAX_CUSTOM_PACKS["TEAM"] == 25
        assert MAX_CUSTOM_PACKS["ORG"] == 100
        assert MAX_CUSTOM_PACKS["ENTERPRISE"] >= 9999

    def test_free_tier_limit_is_lowest(self):
        from guard.core.licensing import MAX_CUSTOM_PACKS
        free_limit = MAX_CUSTOM_PACKS["FREE"]
        for tier, limit in MAX_CUSTOM_PACKS.items():
            if tier != "FREE":
                assert limit > free_limit, f"{tier} limit should exceed FREE"

    def test_builtin_packs_load_without_enterprise(self):
        """Built-in packs should always load regardless of license tier."""
        for pack_id in ("hipaa", "pci-dss", "iso-27001", "fda-iec-62304", "owasp-top-10", "soc2"):
            rules = load_pack_rules(pack_id)
            assert len(rules) > 0, f"Built-in pack {pack_id} failed to load"


class TestConfigValidationWithCustomPacks:
    def test_unknown_pack_in_overrides_warns(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "standards.yaml").write_text("rules: []\n")
        (tmp_path / "items.json").write_text("[]")
        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            pack_overrides={"nonexistent-pack": {"R-001": {"severity": "low"}}},
        )
        warnings = config.validate_config()
        override_warnings = [w for w in warnings if w.field == "pack_overrides"]
        assert any("unknown pack" in w.message.lower() for w in override_warnings)

    def test_invalid_severity_in_overrides_errors(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "standards.yaml").write_text("rules: []\n")
        (tmp_path / "items.json").write_text("[]")
        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            pack_overrides={"fda-iec-62304": {"R-001": {"severity": "banana"}}},
        )
        warnings = config.validate_config()
        errors = [w for w in warnings if w.level == "error" and w.field == "pack_overrides"]
        assert len(errors) >= 1

    def test_custom_pack_in_standards_packs_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _make_custom_pack(tmp_path, "my-pack")
        (tmp_path / "standards.yaml").write_text("rules: []\n")
        (tmp_path / "items.json").write_text("[]")
        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            standards_packs=["my-pack"],
        )
        warnings = config.validate_config()
        pack_warnings = [w for w in warnings if w.field == "standards_packs"]
        assert len(pack_warnings) == 0


# ===================================================================
# Organization-tier pack license gating (TC-125)
# ===================================================================


class TestOrgTierPackGating:
    """Verify that org-tier packs are blocked without a valid license key."""

    def test_org_tier_packs_set(self):
        from guard.packs.registry import ORG_TIER_PACKS
        assert ORG_TIER_PACKS == {
            "iec-81001-5-1", "fda-21cfr11", "iso-14971",
        }

    def test_cpp_packs_in_free_tier(self):
        from guard.packs.registry import FREE_TIER_PACKS
        for pack_id in ("misra-c", "do-178c", "iso-26262"):
            assert pack_id in FREE_TIER_PACKS, f"{pack_id} should be in free tier"

    def test_is_org_pack_true(self):
        from guard.packs.registry import is_org_pack
        for pack_id in ("iec-81001-5-1", "fda-21cfr11", "iso-14971"):
            assert is_org_pack(pack_id), f"{pack_id} should be org-tier"

    def test_is_org_pack_false_for_non_org(self):
        from guard.packs.registry import is_org_pack
        for pack_id in ("owasp-top-10", "soc2", "hipaa", "pci-dss", "fda-iec-62304", "misra-c", "do-178c", "iso-26262"):
            assert not is_org_pack(pack_id), f"{pack_id} should not be org-tier"

    def test_pack_tier_classification(self):
        from guard.packs.registry import pack_tier
        assert pack_tier("owasp-top-10") == "Free"
        assert pack_tier("soc2") == "Free"
        assert pack_tier("fda-iec-62304") == "Team"
        assert pack_tier("hipaa") == "Team"
        assert pack_tier("iec-81001-5-1") == "Org"

    def test_free_packs_load_without_key(self, monkeypatch):
        """Free-tier packs load even with no license key."""
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        for pack_id in ("owasp-top-10", "soc2", "python-security", "go-security", "supply-chain-security"):
            rules = _load_pack_rules([pack_id], license_key="")
            assert len(rules) > 0, f"Free pack {pack_id} should load without a key"

    def test_team_packs_blocked_without_key(self, monkeypatch):
        """Team-tier packs are skipped when no license key is provided."""
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        for pack_id in ("fda-iec-62304", "hipaa", "pci-dss", "iso-27001"):
            rules = _load_pack_rules([pack_id], license_key="")
            assert rules == [], f"Team pack {pack_id} should be blocked without a key"

    def test_org_packs_blocked_without_key(self, monkeypatch):
        """Org-tier packs are skipped when no license key is provided."""
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        for pack_id in ("iec-81001-5-1", "fda-21cfr11", "iso-14971"):
            rules = _load_pack_rules([pack_id], license_key="")
            assert rules == [], f"Org pack {pack_id} should be blocked without a key"

    def test_cpp_packs_load_without_key(self, monkeypatch):
        """C++ packs (misra-c, do-178c, iso-26262) are free tier — load without a key."""
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        for pack_id in ("misra-c", "do-178c", "iso-26262"):
            rules = _load_pack_rules([pack_id], license_key="")
            assert len(rules) > 0, f"Free pack {pack_id} should load without a key"

    def test_org_packs_load_with_trial_key(self, monkeypatch):
        """Trial keys (ENTERPRISE tier) unlock org packs."""
        from guard.core.licensing import generate_trial_key
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        key = generate_trial_key(days=30)
        for pack_id in ("iec-81001-5-1", "fda-21cfr11", "iso-14971"):
            rules = _load_pack_rules([pack_id], license_key=key)
            assert len(rules) > 0, f"Org pack {pack_id} should load with trial key"

    def test_org_packs_load_with_org_key(self, monkeypatch):
        """ORG-tier keys unlock org packs."""
        from datetime import date, timedelta
        from guard.core.licensing import generate_key
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        key = generate_key("ORG", date.today() + timedelta(days=365))
        rules = _load_pack_rules(["iec-81001-5-1"], license_key=key)
        assert len(rules) > 0

    def test_team_key_unlocks_team_packs(self, monkeypatch):
        """TEAM-tier keys unlock team packs but not org packs."""
        from datetime import date, timedelta
        from guard.core.licensing import generate_key
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        key = generate_key("TEAM", date.today() + timedelta(days=365))
        # Team packs load
        rules = _load_pack_rules(["fda-iec-62304"], license_key=key)
        assert len(rules) > 0
        # Org packs still blocked
        rules = _load_pack_rules(["iec-81001-5-1"], license_key=key)
        assert len(rules) == 0

    def test_org_key_unlocks_org_packs(self, monkeypatch):
        """ORG-tier keys unlock org packs."""
        from datetime import date, timedelta
        from guard.core.licensing import generate_key
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        key = generate_key("ORG", date.today() + timedelta(days=365))
        rules = _load_pack_rules(["iec-81001-5-1"], license_key=key)
        assert len(rules) > 0

    def test_mixed_packs_only_free_load_without_key(self, monkeypatch):
        """When mixing free and team/org packs without a key, only free packs load."""
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        rules = _load_pack_rules(["owasp-top-10", "fda-iec-62304", "iec-81001-5-1"], license_key="")
        pack_ids = {r["pack_id"] for r in rules}
        assert "owasp-top-10" in pack_ids
        assert "fda-iec-62304" not in pack_ids  # team-tier, blocked
        assert "iec-81001-5-1" not in pack_ids  # org-tier, blocked

    def test_expired_key_blocks_org_packs(self, monkeypatch):
        """An expired key should block org packs."""
        from datetime import date, timedelta
        from guard.core.licensing import generate_key
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        key = generate_key("ENTERPRISE", date.today() - timedelta(days=1))
        rules = _load_pack_rules(["iec-81001-5-1"], license_key=key)
        assert rules == []

    def test_env_var_key_unlocks_org_packs(self, monkeypatch):
        """GUARD_LICENSE_KEY env var should unlock org packs."""
        from guard.core.licensing import generate_trial_key
        key = generate_trial_key(days=30)
        monkeypatch.setenv("GUARD_LICENSE_KEY", key)
        # Pass empty license_key — the env var is checked by get_license_info
        rules = _load_pack_rules(["iec-81001-5-1"], license_key="")
        assert len(rules) > 0


# ===================================================================
# Supply Chain Security pack
# ===================================================================


class TestSupplyChainSecurityPack:
    """Tests for the supply-chain-security standards pack."""

    @pytest.fixture()
    def scs_rules(self):
        return load_pack_rules("supply-chain-security")

    def test_pack_loads(self, scs_rules):
        assert len(scs_rules) >= 20

    def test_pack_in_available_packs(self):
        packs = list_available_packs()
        ids = {p.pack_id for p in packs}
        assert "supply-chain-security" in ids

    def test_pack_metadata(self):
        packs = list_available_packs()
        scs = next(p for p in packs if p.pack_id == "supply-chain-security")
        assert scs.name == "Supply Chain Security"
        assert scs.rule_count >= 20
        assert "supply chain" in scs.description.lower()

    def test_pack_validates(self):
        raw = export_pack("supply-chain-security")
        errors = validate_pack_yaml(raw)
        assert errors == [], f"Validation errors: {errors}"

    def test_all_rules_are_valid_definitions(self, scs_rules):
        for r in scs_rules:
            rd = RuleDefinition(**r)
            assert rd.id == r["id"]
            assert rd.pack_id == "supply-chain-security"

    def test_rules_have_required_fields(self, scs_rules):
        for r in scs_rules:
            assert "id" in r
            assert "name" in r
            assert "type" in r
            assert "severity" in r
            assert "standard" in r
            assert "clause" in r
            assert "compliance_category" in r
            assert "tags" in r
            assert "supply-chain" in r["tags"]

    def test_code_rules_have_remediation(self, scs_rules):
        code_rules = [r for r in scs_rules if r["type"] in ("regex", "required_pattern")]
        for r in code_rules:
            assert r.get("remediation_guidance"), f"Rule {r['id']} missing remediation_guidance"

    def test_rule_ids_unique(self, scs_rules):
        ids = [r["id"] for r in scs_rules]
        assert len(ids) == len(set(ids)), "Duplicate rule IDs"

    def test_rule_id_prefixes(self, scs_rules):
        for r in scs_rules:
            assert r["id"].startswith("SCS-"), f"Rule {r['id']} should start with SCS-"

    def test_curl_pipe_bash_rule_matches(self, scs_rules):
        import re
        rule = next(r for r in scs_rules if r["id"] == "SCS-CI-001")
        assert re.search(rule["pattern"], "curl -sL https://example.com/install.sh | bash")
        assert not re.search(rule["pattern"], "curl -o script.sh https://example.com/install.sh")

    def test_unpinned_actions_rule_matches(self, scs_rules):
        import re
        rule = next(r for r in scs_rules if r["id"] == "SCS-CI-003")
        assert re.search(rule["pattern"], "uses: actions/checkout@v4")
        assert not re.search(rule["pattern"], "uses: actions/checkout@a5ac7e51b41094c92402da3b24376905380afc29")

    def test_private_key_rule_matches(self, scs_rules):
        import re
        rule = next(r for r in scs_rules if r["id"] == "SCS-SEC-001")
        assert re.search(rule["pattern"], "-----BEGIN RSA PRIVATE KEY-----")
        assert re.search(rule["pattern"], "-----BEGIN PRIVATE KEY-----")
        assert not re.search(rule["pattern"], "-----BEGIN PUBLIC KEY-----")

    def test_aws_credentials_rule_matches(self, scs_rules):
        import re
        rule = next(r for r in scs_rules if r["id"] == "SCS-SEC-002")
        assert re.search(rule["pattern"], "AKIAIOSFODNN7EXAMPLE")

    def test_docker_digest_rule_matches(self, scs_rules):
        import re
        rule = next(r for r in scs_rules if r["id"] == "SCS-DEP-005")
        assert re.search(rule["pattern"], "FROM python:3.12-slim")
        assert not re.search(rule["pattern"], "FROM python:3.12-slim@sha256:abc123")
        assert not re.search(rule["pattern"], "FROM scratch")

    def test_has_documentation_obligations(self, scs_rules):
        doc_rules = [r for r in scs_rules if r["type"] == "documentation_obligation"]
        assert len(doc_rules) >= 4
