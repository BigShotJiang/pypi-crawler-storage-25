"""Comprehensive tests for traceability linking (Phase 4)."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from tests.helpers import make_finding
from guard.core.models import Severity
from guard.core.traceability import (
    build_traceability_matrix,
    extract_work_item_ids,
    get_current_branch,
    link_findings_to_work_items,
    scan_files_for_reqs,
)


def _make_finding(
    finding_id: str = "F-001",
    rule_id: str = "R-001",
    related: list[str] | None = None,
):
    """Thin wrapper preserving original parameter names."""
    return make_finding(
        fid=finding_id, rule=rule_id, file="test.py",
        msg="test finding", related_work_items=related,
    )


# ===================================================================
# extract_work_item_ids
# ===================================================================


class TestExtractWorkItemIds:
    def test_branch_with_single_id(self):
        assert extract_work_item_ids("feature/WI-123-add-auth") == ["WI-123"]

    def test_branch_with_multiple_ids(self):
        assert extract_work_item_ids("feature/WI-101-WI-102-combined") == [
            "WI-101",
            "WI-102",
        ]

    def test_commit_message(self):
        msg = "Fix login bug [WI-200] and update tests [WI-201]"
        assert extract_work_item_ids(msg) == ["WI-200", "WI-201"]

    def test_deduplicates_ids(self):
        text = "WI-100 mentioned again WI-100 and WI-100"
        assert extract_work_item_ids(text) == ["WI-100"]

    def test_no_ids_returns_empty(self):
        assert extract_work_item_ids("feature/add-auth") == []

    def test_empty_string_returns_empty(self):
        assert extract_work_item_ids("") == []

    def test_none_like_empty(self):
        # Passing empty is the documented way, but let's be safe
        assert extract_work_item_ids("") == []

    def test_custom_pattern(self):
        ids = extract_work_item_ids(
            "JIRA-99 and JIRA-100 are done",
            pattern=r"JIRA-\d+",
        )
        assert ids == ["JIRA-99", "JIRA-100"]

    def test_invalid_pattern_returns_empty(self):
        assert extract_work_item_ids("WI-123", pattern=r"[invalid") == []

    def test_preserves_order_of_first_occurrence(self):
        text = "WI-300 WI-200 WI-100 WI-300"
        assert extract_work_item_ids(text) == ["WI-300", "WI-200", "WI-100"]

    def test_hyphenated_branch_names(self):
        assert extract_work_item_ids("fix/WI-42-login-page") == ["WI-42"]

    def test_slash_separated_ids(self):
        assert extract_work_item_ids("WI-1/WI-2") == ["WI-1", "WI-2"]


# ===================================================================
# link_findings_to_work_items
# ===================================================================


class TestLinkFindingsToWorkItems:
    def test_links_ids_to_all_findings(self):
        f1 = _make_finding("F-1")
        f2 = _make_finding("F-2")
        result = link_findings_to_work_items([f1, f2], ["WI-101"])

        assert f1.related_work_items == ["WI-101"]
        assert f2.related_work_items == ["WI-101"]
        assert result is not None  # returns the list

    def test_preserves_existing_work_items(self):
        f = _make_finding(related=["WI-50"])
        link_findings_to_work_items([f], ["WI-101"])

        assert f.related_work_items == ["WI-50", "WI-101"]

    def test_no_duplicate_when_already_linked(self):
        f = _make_finding(related=["WI-101"])
        link_findings_to_work_items([f], ["WI-101"])

        assert f.related_work_items == ["WI-101"]

    def test_empty_work_item_ids_no_change(self):
        f = _make_finding()
        link_findings_to_work_items([f], [])

        assert f.related_work_items == []

    def test_empty_findings_list(self):
        result = link_findings_to_work_items([], ["WI-101"])
        assert result == []

    def test_multiple_work_item_ids(self):
        f = _make_finding()
        link_findings_to_work_items([f], ["WI-101", "WI-102"])

        assert f.related_work_items == ["WI-101", "WI-102"]

    def test_returns_same_list(self):
        findings = [_make_finding()]
        result = link_findings_to_work_items(findings, ["WI-1"])
        assert result is findings


# ===================================================================
# get_current_branch
# ===================================================================


class TestGetCurrentBranch:
    def test_returns_branch_name(self):
        with patch("guard.core.traceability.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "feature/WI-123-auth\n"
            assert get_current_branch() == "feature/WI-123-auth"

    def test_returns_none_on_failure(self):
        with patch("guard.core.traceability.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 128
            mock_sub.run.return_value.stdout = ""
            assert get_current_branch() is None

    def test_returns_none_for_detached_head(self):
        with patch("guard.core.traceability.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "HEAD\n"
            assert get_current_branch() is None

    def test_returns_none_when_git_not_found(self):
        with patch("guard.core.traceability.subprocess") as mock_sub:
            mock_sub.run.side_effect = FileNotFoundError
            assert get_current_branch() is None


# ===================================================================
# Integration: extract + link
# ===================================================================


class TestIntegration:
    def test_branch_to_findings_pipeline(self):
        branch = "feature/WI-101-add-login"
        ids = extract_work_item_ids(branch)
        findings = [_make_finding("F-1"), _make_finding("F-2")]
        link_findings_to_work_items(findings, ids)

        for f in findings:
            assert f.related_work_items == ["WI-101"]

    def test_no_branch_means_no_linking(self):
        ids = extract_work_item_ids("")
        findings = [_make_finding()]
        link_findings_to_work_items(findings, ids)

        assert findings[0].related_work_items == []

    def test_multiple_ids_from_branch(self):
        branch = "fix/WI-200-WI-201-combined-fix"
        ids = extract_work_item_ids(branch)
        findings = [_make_finding()]
        link_findings_to_work_items(findings, ids)

        assert findings[0].related_work_items == ["WI-200", "WI-201"]


# ===================================================================
# scan_files_for_reqs
# ===================================================================


class TestScanFilesForReqs:
    def test_finds_cpp_style_req_comments(self, tmp_path):
        src = tmp_path / "main.cpp"
        src.write_text("// REQ-001: Parser\n// REQ-002: Windowing\nint main() {}\n")
        result = scan_files_for_reqs(str(tmp_path))
        assert "main.cpp" in result
        assert result["main.cpp"] == ["REQ-001", "REQ-002"]

    def test_finds_python_style_req_comments(self, tmp_path):
        src = tmp_path / "app.py"
        src.write_text("# REQ-010: Feature\nimport os\n")
        result = scan_files_for_reqs(str(tmp_path))
        assert "app.py" in result
        assert result["app.py"] == ["REQ-010"]

    def test_finds_srs_style_refs(self, tmp_path):
        src = tmp_path / "module.c"
        src.write_text("// SRS-005: Safety requirement\nvoid f() {}\n")
        result = scan_files_for_reqs(str(tmp_path))
        assert result["module.c"] == ["SRS-005"]

    def test_deduplicates_within_file(self, tmp_path):
        src = tmp_path / "dup.cpp"
        src.write_text("// REQ-001: First\n// REQ-001: Again\n// REQ-002: Other\n")
        result = scan_files_for_reqs(str(tmp_path))
        assert result["dup.cpp"] == ["REQ-001", "REQ-002"]

    def test_respects_scan_exclude(self, tmp_path):
        (tmp_path / "src").mkdir()
        (tmp_path / "docs").mkdir()
        (tmp_path / "src" / "a.cpp").write_text("// REQ-001\n")
        (tmp_path / "docs" / "b.cpp").write_text("// REQ-002\n")
        result = scan_files_for_reqs(str(tmp_path), scan_exclude=["docs/"])
        assert "src/a.cpp" in result
        assert "docs/b.cpp" not in result

    def test_respects_file_glob(self, tmp_path):
        (tmp_path / "a.cpp").write_text("// REQ-001\n")
        (tmp_path / "a.py").write_text("# REQ-002\n")
        result = scan_files_for_reqs(str(tmp_path), file_globs=["**/*.cpp"])
        assert "a.cpp" in result
        assert "a.py" not in result

    def test_empty_dir_returns_empty(self, tmp_path):
        result = scan_files_for_reqs(str(tmp_path))
        assert result == {}

    def test_files_without_refs_excluded(self, tmp_path):
        (tmp_path / "noreqs.cpp").write_text("int main() { return 0; }\n")
        result = scan_files_for_reqs(str(tmp_path))
        assert result == {}


# ===================================================================
# build_traceability_matrix
# ===================================================================


class TestBuildTraceabilityMatrix:
    def test_full_coverage(self):
        file_reqs = {
            "src/parser.cpp": ["REQ-001"],
            "src/viewer.cpp": ["REQ-002"],
        }
        work_items = [
            {"id": "REQ-001", "title": "Parser"},
            {"id": "REQ-002", "title": "Viewer"},
        ]
        matrix = build_traceability_matrix(file_reqs, work_items)
        assert matrix["summary"]["coverage_pct"] == 100.0
        assert matrix["summary"]["implemented"] == 2
        assert matrix["summary"]["unimplemented"] == 0
        assert len(matrix["unimplemented"]) == 0
        assert len(matrix["unlinked_files"]) == 0

    def test_unimplemented_requirement(self):
        file_reqs = {"src/parser.cpp": ["REQ-001"]}
        work_items = [
            {"id": "REQ-001", "title": "Parser"},
            {"id": "REQ-002", "title": "Viewer"},
        ]
        matrix = build_traceability_matrix(file_reqs, work_items)
        assert matrix["summary"]["implemented"] == 1
        assert matrix["summary"]["unimplemented"] == 1
        assert matrix["summary"]["coverage_pct"] == 50.0
        assert len(matrix["unimplemented"]) == 1
        assert matrix["unimplemented"][0]["id"] == "REQ-002"

    def test_unlinked_file_with_unknown_ref(self):
        file_reqs = {"src/extra.cpp": ["REQ-099"]}
        work_items = [{"id": "REQ-001", "title": "Parser"}]
        matrix = build_traceability_matrix(file_reqs, work_items)
        assert len(matrix["unlinked_files"]) == 1
        assert matrix["unlinked_files"][0]["unknown_refs"] == ["REQ-099"]

    def test_empty_inputs(self):
        matrix = build_traceability_matrix({}, [])
        assert matrix["summary"]["total_requirements"] == 0
        assert matrix["summary"]["coverage_pct"] == 0.0
        assert matrix["requirements"] == []

    def test_multiple_files_per_requirement(self):
        file_reqs = {
            "src/a.cpp": ["REQ-001"],
            "src/a.h": ["REQ-001"],
            "src/b.cpp": ["REQ-001", "REQ-002"],
        }
        work_items = [
            {"id": "REQ-001", "title": "Feature A"},
            {"id": "REQ-002", "title": "Feature B"},
        ]
        matrix = build_traceability_matrix(file_reqs, work_items)
        req1 = next(r for r in matrix["requirements"] if r["id"] == "REQ-001")
        assert len(req1["files"]) == 3
        assert matrix["summary"]["coverage_pct"] == 100.0

    def test_case_insensitive_matching(self):
        file_reqs = {"src/a.cpp": ["REQ-001"]}  # scan_files_for_reqs uppercases
        work_items = [{"id": "req-001", "title": "Lower case"}]
        matrix = build_traceability_matrix(file_reqs, work_items)
        # wi_by_id keys are uppercased, so req-001 → REQ-001
        assert matrix["summary"]["implemented"] == 1
