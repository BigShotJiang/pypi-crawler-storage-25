"""Tests for CSV reporter (Phase 26i — Platform Polish)."""

from __future__ import annotations

import csv
import io

import pytest

from tests.helpers import make_finding
from guard.core.models import Evidence, Finding, Severity
from guard.reporters.csv_reporter import CsvReporter
from guard.reporters.factory import available_reporters, get_reporter


class TestCsvReporterBasic:
    def test_extension(self):
        assert CsvReporter().extension == ".csv"

    def test_empty_findings(self):
        output = CsvReporter().render([])
        reader = csv.reader(io.StringIO(output))
        rows = list(reader)
        assert len(rows) == 1  # header only
        assert "finding_id" in rows[0]
        assert "rule_id" in rows[0]

    def test_header_columns(self):
        output = CsvReporter().render([])
        reader = csv.reader(io.StringIO(output))
        header = next(reader)
        expected = [
            "finding_id", "rule_id", "severity", "file", "lines",
            "message", "suggestion", "confidence", "standard",
            "clause", "is_obligation",
        ]
        assert header == expected

    def test_single_finding(self):
        f = make_finding(fid="F1", rule="test-rule", sev=Severity.HIGH, file="app.py", lines=[10])
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        rows = list(reader)
        assert len(rows) == 2  # header + 1 data row
        data = rows[1]
        assert data[0] == "F1"           # finding_id
        assert data[1] == "test-rule"    # rule_id
        assert data[2] == "high"         # severity
        assert data[3] == "app.py"       # file
        assert data[4] == "10"           # lines
        assert data[10] == "false"       # is_obligation

    def test_multiple_lines(self):
        f = make_finding(lines=[1, 5, 10])
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        next(reader)  # skip header
        data = next(reader)
        assert data[4] == "1;5;10"

    def test_no_lines(self):
        f = make_finding(lines=[])
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[4] == ""

    def test_suggestion_present(self):
        f = make_finding(suggestion="Fix this")
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[6] == "Fix this"

    def test_suggestion_absent(self):
        f = make_finding(suggestion=None)
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[6] == ""

    def test_special_chars_escaped(self):
        f = make_finding(msg='He said "hello, world"')
        output = CsvReporter().render([f])
        # CSV should properly handle commas and quotes
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[5] == 'He said "hello, world"'

    def test_obligation_included(self):
        obl = Finding(
            finding_id="OBL-1", rule_id="OBL-1",
            severity=Severity.INFO, message="Must have plan",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0, is_obligation=True,
            standard="IEC 62304", clause="5.1.1",
        )
        output = CsvReporter().render([obl])
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[0] == "OBL-1"
        assert data[8] == "IEC 62304"    # standard
        assert data[9] == "5.1.1"        # clause
        assert data[10] == "true"        # is_obligation

    def test_multiple_findings(self):
        findings = [make_finding(fid=f"F{i}") for i in range(5)]
        output = CsvReporter().render(findings)
        reader = csv.reader(io.StringIO(output))
        rows = list(reader)
        assert len(rows) == 6  # header + 5 data rows

    def test_confidence_formatting(self):
        f = make_finding(confidence=0.85)
        output = CsvReporter().render([f])
        reader = csv.reader(io.StringIO(output))
        next(reader)
        data = next(reader)
        assert data[7] == "85%"


class TestCsvReporterFactory:
    def test_csv_in_available_reporters(self):
        names = available_reporters()
        assert "csv" in names

    def test_get_reporter_csv(self):
        r = get_reporter("csv")
        assert isinstance(r, CsvReporter)

    def test_csv_in_valid_reporters_config(self):
        from guard.config import VALID_REPORTERS
        assert "csv" in VALID_REPORTERS
