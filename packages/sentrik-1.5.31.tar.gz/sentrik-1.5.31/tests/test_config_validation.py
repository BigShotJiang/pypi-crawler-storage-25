"""Comprehensive tests for configuration validation (Phase 9)."""

from __future__ import annotations

from pathlib import Path

import pytest

from guard.config import ConfigWarning, GuardConfig


# ===================================================================
# Valid configurations
# ===================================================================


class TestValidConfig:
    def test_default_config_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Create required files so file-existence checks pass
        examples = tmp_path / "examples"
        examples.mkdir()
        (examples / "sample_work_items.json").write_text("[]")
        (examples / "sample_standards.yaml").write_text("rules: []")

        config = GuardConfig()
        warnings = config.validate_config()
        assert warnings == []

    def test_explicit_valid_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "standards.yaml").write_text("rules: []")
        (tmp_path / "items.json").write_text("[]")

        config = GuardConfig(
            standards_file="standards.yaml",
            work_items_file="items.json",
            gate_fail_on=["critical", "high"],
            provider="stub",
            reporters=["html", "junit"],
        )
        warnings = config.validate_config()
        assert warnings == []


# ===================================================================
# Severity validation
# ===================================================================


class TestSeverityValidation:
    def test_invalid_severity_in_gate_fail_on(self):
        config = GuardConfig(gate_fail_on=["critical", "banana"])
        warnings = config.validate_config()
        errors = [w for w in warnings if w.field == "gate_fail_on" and w.level == "error"]
        assert len(errors) == 1
        assert "banana" in errors[0].message

    def test_multiple_invalid_severities(self):
        config = GuardConfig(gate_fail_on=["foo", "bar"])
        warnings = config.validate_config()
        errors = [w for w in warnings if w.field == "gate_fail_on"]
        assert len(errors) == 2

    def test_empty_gate_fail_on_is_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        (tmp_path / "examples" / "sample_standards.yaml").write_text("rules: []")
        config = GuardConfig(gate_fail_on=[])
        sev_errors = [w for w in config.validate_config() if w.field == "gate_fail_on"]
        assert sev_errors == []


# ===================================================================
# Provider validation
# ===================================================================


class TestProviderValidation:
    def test_invalid_provider(self):
        config = GuardConfig(provider="azure")
        warnings = config.validate_config()
        errors = [w for w in warnings if w.field == "provider"]
        assert len(errors) == 1

    def test_valid_providers(self):
        for p in ["stub", "sarif", "composite"]:
            config = GuardConfig(provider=p)
            errors = [w for w in config.validate_config() if w.field == "provider" and w.level == "error"]
            assert errors == [], f"Provider {p!r} should be valid"

    def test_invalid_llm_provider(self):
        config = GuardConfig(llm_provider="nonexistent")
        warnings = config.validate_config()
        errors = [w for w in warnings if w.field == "llm_provider"]
        assert len(errors) == 1


# ===================================================================
# Reporter validation
# ===================================================================


class TestReporterValidation:
    def test_unknown_reporter_warns(self):
        config = GuardConfig(reporters=["html", "unknown"])
        warnings = config.validate_config()
        reporter_warns = [w for w in warnings if w.field == "reporters"]
        assert len(reporter_warns) == 1
        assert "unknown" in reporter_warns[0].message

    def test_valid_reporters(self):
        config = GuardConfig(reporters=["html", "junit", "sarif"])
        reporter_warns = [w for w in config.validate_config() if w.field == "reporters"]
        assert reporter_warns == []


# ===================================================================
# File existence checks
# ===================================================================


class TestFileExistenceChecks:
    def test_missing_standards_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig(standards_file="nonexistent.yaml")
        warnings = config.validate_config()
        file_warns = [w for w in warnings if w.field == "standards_file"]
        assert len(file_warns) == 1
        assert file_warns[0].level == "warning"

    def test_missing_work_items_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig(work_items_file="nonexistent.json")
        warnings = config.validate_config()
        file_warns = [w for w in warnings if w.field == "work_items_file"]
        assert len(file_warns) == 1

    def test_missing_sarif_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig(sarif_files=[str(tmp_path / "nope.sarif")])
        warnings = config.validate_config()
        sarif_warns = [w for w in warnings if w.field == "sarif_files"]
        assert len(sarif_warns) == 1

    def test_existing_files_no_warning(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "s.yaml").write_text("rules: []")
        (tmp_path / "w.json").write_text("[]")
        config = GuardConfig(standards_file="s.yaml", work_items_file="w.json")
        file_warns = [w for w in config.validate_config()
                      if w.field in ("standards_file", "work_items_file")]
        assert file_warns == []


# ===================================================================
# Composite/SARIF provider warnings
# ===================================================================


class TestProviderSourceWarnings:
    def test_composite_no_sources_warns(self):
        config = GuardConfig(provider="composite", sarif_files=[], llm_enabled=False)
        warnings = config.validate_config()
        comp_warns = [w for w in warnings if "Composite" in w.message]
        assert len(comp_warns) == 1

    def test_composite_with_sarif_no_warn(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        sarif = tmp_path / "r.sarif"
        sarif.write_text("{}")
        config = GuardConfig(provider="composite", sarif_files=[str(sarif)])
        comp_warns = [w for w in config.validate_config() if "Composite" in w.message]
        assert comp_warns == []

    def test_composite_with_llm_no_warn(self):
        config = GuardConfig(provider="composite", llm_enabled=True)
        comp_warns = [w for w in config.validate_config() if "Composite" in w.message]
        assert comp_warns == []

    def test_sarif_no_files_warns(self):
        config = GuardConfig(provider="sarif", sarif_files=[])
        warnings = config.validate_config()
        sarif_warns = [w for w in warnings if "SARIF provider" in w.message]
        assert len(sarif_warns) == 1


# ===================================================================
# ConfigWarning model
# ===================================================================


class TestConfigWarning:
    def test_default_level(self):
        w = ConfigWarning(field="test", message="msg")
        assert w.level == "warning"

    def test_error_level(self):
        w = ConfigWarning(field="test", message="msg", level="error")
        assert w.level == "error"

    def test_serialization(self):
        w = ConfigWarning(field="f", message="m")
        d = w.model_dump()
        assert d == {"field": "f", "message": "m", "level": "warning", "hint": ""}


# ===================================================================
# Standards packs validation
# ===================================================================


class TestStandardsPacksValidation:
    def test_valid_pack(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        (tmp_path / "examples" / "sample_standards.yaml").write_text("rules: []")
        config = GuardConfig(standards_packs=["fda-iec-62304"])
        pack_warns = [w for w in config.validate_config() if w.field == "standards_packs"]
        assert pack_warns == []

    def test_unknown_pack_warns(self):
        config = GuardConfig(standards_packs=["nonexistent-pack"])
        warnings = config.validate_config()
        pack_warns = [w for w in warnings if w.field == "standards_packs"]
        assert len(pack_warns) == 1
        assert "nonexistent-pack" in pack_warns[0].message
        assert pack_warns[0].level == "warning"

    def test_multiple_unknown_packs(self):
        config = GuardConfig(standards_packs=["bad-1", "bad-2"])
        warnings = config.validate_config()
        pack_warns = [w for w in warnings if w.field == "standards_packs"]
        assert len(pack_warns) == 2

    def test_empty_packs_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        (tmp_path / "examples" / "sample_standards.yaml").write_text("rules: []")
        config = GuardConfig(standards_packs=[])
        pack_warns = [w for w in config.validate_config() if w.field == "standards_packs"]
        assert pack_warns == []

    def test_env_var_override(self, monkeypatch):
        monkeypatch.setenv("GUARD_STANDARDS_PACKS", "fda-iec-62304")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.standards_packs == ["fda-iec-62304"]

    def test_env_var_comma_separated(self, monkeypatch):
        monkeypatch.setenv("GUARD_STANDARDS_PACKS", "pack-a, pack-b")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.standards_packs == ["pack-a", "pack-b"]


# ===================================================================
# GitHub provider validation
# ===================================================================


class TestGitHubProviderValidation:
    def test_github_devops_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        (tmp_path / "examples" / "sample_standards.yaml").write_text("rules: []")
        config = GuardConfig(
            devops_provider="github",
            github_owner="acme",
            github_repo="app",
        )
        gh_warns = [w for w in config.validate_config()
                    if "github" in w.field.lower() or "GitHub" in w.message]
        assert gh_warns == []

    def test_github_devops_missing_owner(self):
        config = GuardConfig(devops_provider="github", github_owner="", github_repo="app")
        warnings = config.validate_config()
        owner_warns = [w for w in warnings if w.field == "github_owner"]
        assert len(owner_warns) == 1
        assert "github_owner" in owner_warns[0].message

    def test_github_devops_missing_repo(self):
        config = GuardConfig(devops_provider="github", github_owner="acme", github_repo="")
        warnings = config.validate_config()
        repo_warns = [w for w in warnings if w.field == "github_repo"]
        assert len(repo_warns) == 1

    def test_github_standards_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        config = GuardConfig(
            standards_provider="github",
            github_owner="acme",
            github_standards_repo="standards",
        )
        gh_warns = [w for w in config.validate_config()
                    if w.field in ("github_owner", "github_standards_repo")]
        assert gh_warns == []

    def test_github_standards_missing_owner(self):
        config = GuardConfig(
            standards_provider="github",
            github_owner="",
            github_standards_repo="standards",
        )
        warnings = config.validate_config()
        owner_warns = [w for w in warnings if w.field == "github_owner"]
        assert len(owner_warns) == 1

    def test_github_standards_missing_repo(self):
        config = GuardConfig(
            standards_provider="github",
            github_owner="acme",
            github_standards_repo="",
        )
        warnings = config.validate_config()
        repo_warns = [w for w in warnings if w.field == "github_standards_repo"]
        assert len(repo_warns) == 1

    def test_github_provider_is_valid(self):
        config = GuardConfig(devops_provider="github")
        errors = [w for w in config.validate_config()
                  if w.field == "devops_provider" and w.level == "error"]
        assert errors == []

    def test_github_standards_provider_is_valid(self):
        config = GuardConfig(standards_provider="github")
        errors = [w for w in config.validate_config()
                  if w.field == "standards_provider" and w.level == "error"]
        assert errors == []

    def test_github_env_var_overrides(self, monkeypatch):
        monkeypatch.setenv("GUARD_GITHUB_OWNER", "myorg")
        monkeypatch.setenv("GUARD_GITHUB_REPO", "myrepo")
        monkeypatch.setenv("GUARD_GITHUB_LABEL", "guard")
        monkeypatch.setenv("GUARD_GITHUB_MILESTONE", "v1")
        monkeypatch.setenv("GUARD_GITHUB_STANDARDS_REPO", "standards")
        monkeypatch.setenv("GUARD_GITHUB_STANDARDS_FILE", "rules.yaml")
        monkeypatch.setenv("GUARD_GITHUB_STANDARDS_REF", "develop")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.github_owner == "myorg"
        assert config.github_repo == "myrepo"
        assert config.github_label == "guard"
        assert config.github_milestone == "v1"
        assert config.github_standards_repo == "standards"
        assert config.github_standards_file == "rules.yaml"
        assert config.github_standards_ref == "develop"


# ===================================================================
# Jira provider validation
# ===================================================================


class TestJiraProviderValidation:
    def test_jira_devops_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        (tmp_path / "examples" / "sample_standards.yaml").write_text("rules: []")
        config = GuardConfig(
            devops_provider="jira",
            jira_base_url="https://jira.example.com",
            jira_project_key="PROJ",
        )
        jira_warns = [w for w in config.validate_config()
                      if "jira" in w.field.lower() or "Jira" in w.message]
        assert jira_warns == []

    def test_jira_devops_missing_base_url(self):
        config = GuardConfig(devops_provider="jira", jira_base_url="", jira_project_key="PROJ")
        warnings = config.validate_config()
        url_warns = [w for w in warnings if w.field == "jira_base_url"]
        assert len(url_warns) == 1

    def test_jira_devops_missing_project_key(self):
        config = GuardConfig(devops_provider="jira", jira_base_url="https://jira.com", jira_project_key="")
        warnings = config.validate_config()
        key_warns = [w for w in warnings if w.field == "jira_project_key"]
        assert len(key_warns) == 1

    def test_jira_standards_valid(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "examples").mkdir()
        (tmp_path / "examples" / "sample_work_items.json").write_text("[]")
        config = GuardConfig(
            standards_provider="jira",
            jira_base_url="https://jira.example.com",
            jira_standards_issue_key="STDS-1",
        )
        jira_warns = [w for w in config.validate_config()
                      if w.field in ("jira_base_url", "jira_standards_issue_key")]
        assert jira_warns == []

    def test_jira_standards_missing_base_url(self):
        config = GuardConfig(
            standards_provider="jira",
            jira_base_url="",
            jira_standards_issue_key="STDS-1",
        )
        warnings = config.validate_config()
        url_warns = [w for w in warnings if w.field == "jira_base_url"]
        assert len(url_warns) == 1

    def test_jira_standards_missing_issue_key(self):
        config = GuardConfig(
            standards_provider="jira",
            jira_base_url="https://jira.com",
            jira_standards_issue_key="",
        )
        warnings = config.validate_config()
        key_warns = [w for w in warnings if w.field == "jira_standards_issue_key"]
        assert len(key_warns) == 1

    def test_jira_provider_is_valid(self):
        config = GuardConfig(devops_provider="jira")
        errors = [w for w in config.validate_config()
                  if w.field == "devops_provider" and w.level == "error"]
        assert errors == []

    def test_jira_standards_provider_is_valid(self):
        config = GuardConfig(standards_provider="jira")
        errors = [w for w in config.validate_config()
                  if w.field == "standards_provider" and w.level == "error"]
        assert errors == []

    def test_jira_env_var_overrides(self, monkeypatch):
        monkeypatch.setenv("GUARD_JIRA_BASE_URL", "https://jira.corp.com")
        monkeypatch.setenv("GUARD_JIRA_PROJECT_KEY", "MYPROJ")
        monkeypatch.setenv("GUARD_JIRA_JQL", "assignee = me")
        monkeypatch.setenv("GUARD_JIRA_STANDARDS_ISSUE_KEY", "STDS-42")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.jira_base_url == "https://jira.corp.com"
        assert config.jira_project_key == "MYPROJ"
        assert config.jira_jql == "assignee = me"
        assert config.jira_standards_issue_key == "STDS-42"


# ===================================================================
# Empty env var override handling
# ===================================================================


class TestEmptyEnvVarOverride:
    def test_empty_license_key_env_does_not_override_yaml(self, tmp_path, monkeypatch):
        """Empty GUARD_LICENSE_KEY='' should not wipe out a YAML-configured key."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: GUARD-TEAM-20261231-abc123\n")
        monkeypatch.setenv("GUARD_LICENSE_KEY", "")
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "GUARD-TEAM-20261231-abc123"

    def test_nonempty_license_key_env_overrides_yaml(self, tmp_path, monkeypatch):
        """Non-empty GUARD_LICENSE_KEY should override the YAML value."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: old-key\n")
        monkeypatch.setenv("GUARD_LICENSE_KEY", "new-key")
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "new-key"

    def test_unset_license_key_env_uses_yaml(self, tmp_path, monkeypatch):
        """When GUARD_LICENSE_KEY is not set, YAML value is used."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: yaml-key\n")
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "yaml-key"

    def test_empty_governance_profile_env_does_not_override(self, tmp_path, monkeypatch):
        """Empty GUARD_GOVERNANCE_PROFILE='' should not override YAML governance."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("governance:\n  profile: strict\n")
        monkeypatch.setenv("GUARD_GOVERNANCE_PROFILE", "")
        config = GuardConfig.load(cfg_file)
        assert config.governance.get("profile") == "strict"


# ===================================================================
# Empty env var override tests
# ===================================================================


class TestEmptyEnvVarOverride:
    def test_empty_license_key_env_does_not_override_yaml(self, tmp_path, monkeypatch):
        """An empty GUARD_LICENSE_KEY env var should not wipe out the YAML value."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: GUARD-TEAM-20261231-abc123\n")
        monkeypatch.setenv("GUARD_LICENSE_KEY", "")
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "GUARD-TEAM-20261231-abc123"

    def test_nonempty_license_key_env_overrides_yaml(self, tmp_path, monkeypatch):
        """A non-empty GUARD_LICENSE_KEY env var should override the YAML value."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: GUARD-TEAM-20261231-abc123\n")
        monkeypatch.setenv("GUARD_LICENSE_KEY", "GUARD-ENTERPRISE-20271231-xyz789")
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "GUARD-ENTERPRISE-20271231-xyz789"

    def test_unset_license_key_env_uses_yaml(self, tmp_path, monkeypatch):
        """When GUARD_LICENSE_KEY is not set, the YAML value is used."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("license_key: GUARD-TEAM-20261231-abc123\n")
        monkeypatch.delenv("GUARD_LICENSE_KEY", raising=False)
        config = GuardConfig.load(cfg_file)
        assert config.license_key == "GUARD-TEAM-20261231-abc123"

    def test_empty_governance_profile_env_does_not_override(self, tmp_path, monkeypatch):
        """An empty GUARD_GOVERNANCE_PROFILE should not override the YAML value."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("governance:\n  profile: strict\n")
        monkeypatch.setenv("GUARD_GOVERNANCE_PROFILE", "")
        config = GuardConfig.load(cfg_file)
        assert config.governance.get("profile") == "strict"


# ===================================================================
# Severity rescoring config aliases
# ===================================================================


class TestSeverityRescoringConfig:
    """Test that severity_rescoring_enabled and ml_severity_enabled
    work interchangeably with full backward compatibility."""

    def test_default_both_false(self):
        config = GuardConfig()
        assert config.severity_rescoring_enabled is False
        assert config.ml_severity_enabled is False
        assert config.is_severity_rescoring_enabled is False

    def test_new_name_in_yaml(self, tmp_path, monkeypatch):
        """severity_rescoring_enabled: true in YAML enables rescoring."""
        monkeypatch.delenv("GUARD_SEVERITY_RESCORING_ENABLED", raising=False)
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("severity_rescoring_enabled: true\n")
        config = GuardConfig.load(cfg_file)
        assert config.is_severity_rescoring_enabled is True

    def test_legacy_name_in_yaml(self, tmp_path, monkeypatch):
        """ml_severity_enabled: true in YAML still enables rescoring."""
        monkeypatch.delenv("GUARD_SEVERITY_RESCORING_ENABLED", raising=False)
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("ml_severity_enabled: true\n")
        config = GuardConfig.load(cfg_file)
        assert config.is_severity_rescoring_enabled is True

    def test_new_name_takes_precedence_in_yaml(self, tmp_path, monkeypatch):
        """When both keys present, new name wins (is ORed)."""
        monkeypatch.delenv("GUARD_SEVERITY_RESCORING_ENABLED", raising=False)
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text(
            "severity_rescoring_enabled: true\nml_severity_enabled: false\n"
        )
        config = GuardConfig.load(cfg_file)
        assert config.is_severity_rescoring_enabled is True

    def test_legacy_true_new_false_still_enabled(self, tmp_path, monkeypatch):
        """Either field being True enables rescoring (OR semantics)."""
        monkeypatch.delenv("GUARD_SEVERITY_RESCORING_ENABLED", raising=False)
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text(
            "severity_rescoring_enabled: false\nml_severity_enabled: true\n"
        )
        config = GuardConfig.load(cfg_file)
        assert config.is_severity_rescoring_enabled is True

    def test_new_env_var(self, monkeypatch):
        """GUARD_SEVERITY_RESCORING_ENABLED env var enables rescoring."""
        monkeypatch.setenv("GUARD_SEVERITY_RESCORING_ENABLED", "true")
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.severity_rescoring_enabled is True
        assert config.is_severity_rescoring_enabled is True

    def test_legacy_env_var(self, monkeypatch):
        """GUARD_ML_SEVERITY_ENABLED env var still works."""
        monkeypatch.delenv("GUARD_SEVERITY_RESCORING_ENABLED", raising=False)
        monkeypatch.setenv("GUARD_ML_SEVERITY_ENABLED", "1")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.ml_severity_enabled is True
        assert config.is_severity_rescoring_enabled is True

    def test_env_var_overrides_yaml(self, tmp_path, monkeypatch):
        """Env var overrides YAML value."""
        cfg_file = tmp_path / ".guard.yaml"
        cfg_file.write_text("severity_rescoring_enabled: false\n")
        monkeypatch.setenv("GUARD_SEVERITY_RESCORING_ENABLED", "true")
        monkeypatch.delenv("GUARD_ML_SEVERITY_ENABLED", raising=False)
        config = GuardConfig.load(cfg_file)
        assert config.is_severity_rescoring_enabled is True

    def test_both_env_vars_false(self, monkeypatch):
        """Both env vars set to false keeps rescoring disabled."""
        monkeypatch.setenv("GUARD_SEVERITY_RESCORING_ENABLED", "false")
        monkeypatch.setenv("GUARD_ML_SEVERITY_ENABLED", "false")
        config = GuardConfig.load(Path("/nonexistent"))
        assert config.is_severity_rescoring_enabled is False

    def test_direct_construction_new_name(self):
        """Direct construction with severity_rescoring_enabled works."""
        config = GuardConfig(severity_rescoring_enabled=True)
        assert config.is_severity_rescoring_enabled is True

    def test_direct_construction_legacy_name(self):
        """Direct construction with ml_severity_enabled works."""
        config = GuardConfig(ml_severity_enabled=True)
        assert config.is_severity_rescoring_enabled is True
