"""Tests for requirements_generator module."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

from guard.core.models import GeneratedRequirement, WorkItem
from guard.core.requirements_generator import (
    _build_generation_prompt,
    _group_files_by_module,
    _next_wi_id,
    _stub_requirement,
    generate_requirements,
    generate_requirements_stub,
    get_already_covered_files,
    push_requirements_to_devops,
    write_requirements_yaml,
)


# ---------------------------------------------------------------------------
# _group_files_by_module
# ---------------------------------------------------------------------------


class TestGroupFilesByModule:
    def test_same_dir_grouped(self):
        files = ["app/routers/auth.py", "app/routers/export.py"]
        groups = _group_files_by_module(files)
        assert "app/routers" in groups
        assert len(groups["app/routers"]) == 2

    def test_different_dirs_separate(self):
        files = ["app/models/user.py", "app/routers/auth.py"]
        groups = _group_files_by_module(files)
        assert len(groups) == 2
        assert "app/models" in groups
        assert "app/routers" in groups

    def test_root_files(self):
        files = ["main.py", "setup.py"]
        groups = _group_files_by_module(files)
        assert "(root)" in groups
        assert len(groups["(root)"]) == 2

    def test_empty_input(self):
        groups = _group_files_by_module([])
        assert groups == {}


# ---------------------------------------------------------------------------
# generate_requirements with mock LLM
# ---------------------------------------------------------------------------


class TestGenerateRequirements:
    def test_generates_from_mock_llm(self, tmp_path):
        """Mock LLM returns structured JSON; verify output structure."""
        # Create source files
        src = tmp_path / "app" / "auth.py"
        src.parent.mkdir(parents=True)
        src.write_text("def login(): pass")

        mock_llm = MagicMock()
        mock_llm.analyze.return_value = {
            "title": "Authentication Module",
            "description": "Handles user login.",
            "acceptance_criteria": ["Users can log in", "Invalid creds rejected"],
        }

        reqs = generate_requirements(
            ["app/auth.py"], str(tmp_path), mock_llm,
        )
        assert len(reqs) == 1
        req = reqs[0]
        assert req.req_id == "REQ-GEN-001"
        assert req.title == "Authentication Module"
        assert req.status == "draft"
        assert "app/auth.py" in req.source_files
        assert len(req.acceptance_criteria) == 2

    def test_sequential_ids(self, tmp_path):
        """Multiple groups get sequential IDs."""
        (tmp_path / "a").mkdir()
        (tmp_path / "a" / "x.py").write_text("pass")
        (tmp_path / "b").mkdir()
        (tmp_path / "b" / "y.py").write_text("pass")

        mock_llm = MagicMock()
        mock_llm.analyze.return_value = {
            "title": "Module",
            "description": "desc",
            "acceptance_criteria": [],
        }

        reqs = generate_requirements(["a/x.py", "b/y.py"], str(tmp_path), mock_llm)
        ids = [r.req_id for r in reqs]
        assert "REQ-GEN-001" in ids
        assert "REQ-GEN-002" in ids

    def test_falls_back_on_llm_error(self, tmp_path):
        """When LLM raises, falls back to stub."""
        src = tmp_path / "handler.py"
        src.write_text("pass")

        mock_llm = MagicMock()
        mock_llm.analyze.side_effect = ValueError("API down")

        reqs = generate_requirements(["handler.py"], str(tmp_path), mock_llm)
        assert len(reqs) == 1
        assert reqs[0].req_id == "REQ-GEN-001"
        assert reqs[0].title  # Should have a derived title

    def test_skips_missing_files(self, tmp_path):
        """Files that don't exist are skipped."""
        mock_llm = MagicMock()
        reqs = generate_requirements(["nonexistent.py"], str(tmp_path), mock_llm)
        assert len(reqs) == 0

    def test_llm_response_from_summary(self, tmp_path):
        """Handles LLM response where data is in 'summary' field."""
        src = tmp_path / "util.py"
        src.write_text("def helper(): pass")

        mock_llm = MagicMock()
        mock_llm.analyze.return_value = {
            "summary": json.dumps({
                "title": "Utility Functions",
                "description": "Helper utilities",
                "acceptance_criteria": ["Tests pass"],
            }),
            "findings": [],
            "confidence": 0.8,
        }

        reqs = generate_requirements(["util.py"], str(tmp_path), mock_llm)
        assert len(reqs) == 1
        assert reqs[0].title == "Utility Functions"


# ---------------------------------------------------------------------------
# generate_requirements_stub
# ---------------------------------------------------------------------------


class TestGenerateRequirementsStub:
    def test_generates_from_paths(self):
        reqs = generate_requirements_stub(["app/routers/auth.py", "app/routers/users.py"])
        assert len(reqs) == 1  # Same directory → one requirement
        req = reqs[0]
        assert req.req_id == "REQ-GEN-001"
        assert req.status == "draft"
        assert len(req.source_files) == 2

    def test_includes_acceptance_criteria(self):
        reqs = generate_requirements_stub(["main.py"])
        assert len(reqs[0].acceptance_criteria) > 0

    def test_multiple_groups(self):
        reqs = generate_requirements_stub(["a/x.py", "b/y.py"])
        assert len(reqs) == 2


# ---------------------------------------------------------------------------
# _build_generation_prompt
# ---------------------------------------------------------------------------


class TestBuildGenerationPrompt:
    def test_prompt_contains_file_paths(self):
        prompt, ctx = _build_generation_prompt(
            ["auth.py", "login.py"],
            ["def login(): pass", "def auth(): pass"],
        )
        assert "auth.py" in prompt
        assert "login.py" in prompt
        assert "def login(): pass" in prompt
        assert ctx["files"] == ["auth.py", "login.py"]


# ---------------------------------------------------------------------------
# write_requirements_yaml
# ---------------------------------------------------------------------------


class TestWriteRequirementsYaml:
    def test_creates_new_file(self, tmp_path):
        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="Test Requirement",
            description="A test",
            acceptance_criteria=["Tests pass"],
            source_files=["test.py"],
        )]
        path = tmp_path / "requirements.yaml"
        result = write_requirements_yaml(reqs, path)
        assert result == path
        assert path.exists()

        with open(path) as f:
            content = f.read()
        assert "REQ-GEN-001" in content
        assert "Test Requirement" in content

        # Verify valid YAML
        data = yaml.safe_load(content)
        assert "requirements" in data
        assert len(data["requirements"]) == 1

    def test_merges_with_existing(self, tmp_path):
        path = tmp_path / "requirements.yaml"
        # Write initial
        initial = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="First",
            status="approved",
            source_files=["a.py"],
        )]
        write_requirements_yaml(initial, path)

        # Merge new
        new = [GeneratedRequirement(
            req_id="REQ-GEN-002",
            title="Second",
            source_files=["b.py"],
        )]
        write_requirements_yaml(new, path)

        with open(path) as f:
            data = yaml.safe_load(f.read())

        assert len(data["requirements"]) == 2
        ids = [r["req_id"] for r in data["requirements"]]
        assert "REQ-GEN-001" in ids
        assert "REQ-GEN-002" in ids

    def test_does_not_duplicate_existing(self, tmp_path):
        path = tmp_path / "requirements.yaml"
        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="Test",
            source_files=["a.py"],
        )]
        write_requirements_yaml(reqs, path)
        write_requirements_yaml(reqs, path)  # Write same again

        with open(path) as f:
            data = yaml.safe_load(f.read())

        assert len(data["requirements"]) == 1


# ---------------------------------------------------------------------------
# push_requirements_to_devops
# ---------------------------------------------------------------------------


class TestPushRequirementsToDevops:
    def test_creates_work_items(self, tmp_path):
        mock_devops = MagicMock()
        mock_devops.create_work_item.return_value = 42

        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="Auth Module",
            description="Handle login",
            acceptance_criteria=["Users can log in"],
            source_files=["auth.py"],
        )]
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = push_requirements_to_devops(
            reqs, mock_devops, [], wi_path,
        )

        assert len(result) == 1
        assert result[0].devops_id == 42
        assert result[0].work_item_id == "WI-1"
        mock_devops.create_work_item.assert_called_once()

    def test_updates_work_items_json(self, tmp_path):
        mock_devops = MagicMock()
        mock_devops.create_work_item.return_value = 100

        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="Test",
            source_files=["x.py"],
        )]
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        push_requirements_to_devops(reqs, mock_devops, [], wi_path)

        with open(wi_path) as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["id"] == "WI-1"
        assert data[0]["devops_id"] == 100

    def test_skips_non_draft(self, tmp_path):
        mock_devops = MagicMock()

        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="Approved",
            status="approved",
            source_files=["x.py"],
        )]
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text("[]")

        result = push_requirements_to_devops(reqs, mock_devops, [], wi_path)
        assert result[0].work_item_id is None
        mock_devops.create_work_item.assert_not_called()

    def test_increments_wi_id(self, tmp_path):
        mock_devops = MagicMock()
        mock_devops.create_work_item.return_value = 200

        existing = [WorkItem(id="WI-5", title="Existing")]
        reqs = [GeneratedRequirement(
            req_id="REQ-GEN-001",
            title="New",
            source_files=["x.py"],
        )]
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text(json.dumps([e.model_dump(exclude_none=True) for e in existing]))

        result = push_requirements_to_devops(reqs, mock_devops, existing, wi_path)
        assert result[0].work_item_id == "WI-6"


# ---------------------------------------------------------------------------
# _next_wi_id
# ---------------------------------------------------------------------------


class TestNextWiId:
    def test_empty_list(self):
        assert _next_wi_id([]) == "WI-1"

    def test_increments(self):
        items = [WorkItem(id="WI-3", title="A"), WorkItem(id="WI-7", title="B")]
        assert _next_wi_id(items) == "WI-8"


# ---------------------------------------------------------------------------
# get_already_covered_files
# ---------------------------------------------------------------------------


class TestGetAlreadyCoveredFiles:
    def test_from_requirements_yaml(self, tmp_path):
        """Files listed in requirements.yaml are detected as covered."""
        req_path = tmp_path / "requirements.yaml"
        req_path.write_text(yaml.dump({
            "requirements": [
                {"req_id": "REQ-GEN-001", "source_files": ["app/auth.py", "app/login.py"]},
            ]
        }))
        covered = get_already_covered_files(req_path, [])
        assert "app/auth.py" in covered
        assert "app/login.py" in covered

    def test_from_work_item_descriptions(self, tmp_path):
        """Files mentioned in work item descriptions are detected."""
        req_path = tmp_path / "requirements.yaml"  # doesn't exist
        wi = WorkItem(
            id="WI-1",
            title="Auth Module",
            description="Covers auth.\n\nSource files:\n- app/auth.py\n- app/login.py",
        )
        covered = get_already_covered_files(req_path, [wi])
        assert "app/auth.py" in covered
        assert "app/login.py" in covered

    def test_from_html_descriptions(self, tmp_path):
        """Files in HTML <code> tags are detected."""
        req_path = tmp_path / "requirements.yaml"
        wi = WorkItem(
            id="WI-1",
            title="Auth",
            description="<h3>Source Files</h3><ul><li><code>app/auth.py</code></li></ul>",
        )
        covered = get_already_covered_files(req_path, [wi])
        assert "app/auth.py" in covered

    def test_empty_inputs(self, tmp_path):
        """No crash on empty inputs."""
        req_path = tmp_path / "requirements.yaml"
        covered = get_already_covered_files(req_path, [])
        assert covered == set()

    def test_combined_sources(self, tmp_path):
        """Merges coverage from YAML and work items."""
        req_path = tmp_path / "requirements.yaml"
        req_path.write_text(yaml.dump({
            "requirements": [
                {"req_id": "REQ-GEN-001", "source_files": ["app/a.py"]},
            ]
        }))
        wi = WorkItem(
            id="WI-1", title="B",
            description="Source files:\n- app/b.py",
        )
        covered = get_already_covered_files(req_path, [wi])
        assert "app/a.py" in covered
        assert "app/b.py" in covered
