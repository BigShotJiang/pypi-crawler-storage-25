"""Tests for the AI chat fix assistant API endpoints."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from guard.server import app


@pytest.fixture
def client():
    """Create a test client without API key or RBAC auth."""
    import guard.server as srv
    from guard.auth.models import AuthConfig

    old_key = srv._API_KEY
    srv._API_KEY = None
    # Patch auth config to disable auth so anonymous access works
    with patch.object(srv, '_get_auth_config', return_value=AuthConfig(enabled=False)):
        yield TestClient(app)
    srv._API_KEY = old_key


@pytest.fixture
def tmp_source_file(tmp_path):
    """Create a temporary source file for apply-fix tests."""
    f = tmp_path / "example.py"
    f.write_text(
        "import os\n"
        "password = 'hardcoded'\n"
        "print(password)\n"
        "# end\n",
        encoding="utf-8",
    )
    return f


# ===================================================================
# POST /api/chat
# ===================================================================


class TestChatEndpoint:
    def test_chat_no_llm_configured(self, client):
        """Returns error when llm_provider is stub (default)."""
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("GUARD_LLM_PROVIDER", None)
            resp = client.post(
                "/api/chat",
                json={"messages": [{"role": "user", "content": "Fix this"}]},
            )
        assert resp.status_code == 400
        data = resp.json()
        assert "No LLM provider configured" in data["detail"]

    def test_chat_with_finding_context(self, client):
        """Sends finding context to the LLM and returns a response."""
        mock_llm = MagicMock()
        mock_llm.chat.return_value = "Here is the fix:\n```python\npassword = os.getenv('PASSWORD')\n```"

        with patch("guard.server._load_config") as mock_config:
            cfg = MagicMock()
            cfg.llm_provider = "openai"
            mock_config.return_value = cfg

            with patch("guard.providers.factory.build_llm", return_value=mock_llm):
                resp = client.post(
                    "/api/chat",
                    json={
                        "messages": [{"role": "user", "content": "Fix this hardcoded password"}],
                        "finding_context": {
                            "rule_id": "SEC-001",
                            "severity": "critical",
                            "message": "Hardcoded password detected",
                            "standard": "OWASP",
                            "clause": "A2",
                            "remediation": "Use environment variables",
                            "evidence": {
                                "file": "app.py",
                                "lines": [5],
                                "matched_text": "password = 'secret'",
                            },
                        },
                    },
                )

        assert resp.status_code == 200
        data = resp.json()
        assert "response" in data
        # Verify the LLM was called with messages and a system prompt
        mock_llm.chat.assert_called_once()
        call_args = mock_llm.chat.call_args
        assert call_args[0][0] == [{"role": "user", "content": "Fix this hardcoded password"}]
        # System prompt is passed as keyword arg
        system = call_args.kwargs.get("system", "")
        assert "SEC-001" in system
        assert "OWASP" in system

    def test_chat_extracts_code_fix(self, client):
        """Extracts code block from LLM response as suggested_fix."""
        mock_llm = MagicMock()
        mock_llm.chat.return_value = (
            "Here is the corrected code:\n"
            "```python\n"
            "import os\n"
            "password = os.getenv('DB_PASSWORD', '')\n"
            "```\n"
            "This uses an environment variable instead."
        )

        with patch("guard.server._load_config") as mock_config:
            cfg = MagicMock()
            cfg.llm_provider = "anthropic"
            mock_config.return_value = cfg

            with patch("guard.providers.factory.build_llm", return_value=mock_llm):
                resp = client.post(
                    "/api/chat",
                    json={"messages": [{"role": "user", "content": "Fix it"}]},
                )

        assert resp.status_code == 200
        data = resp.json()
        assert data["suggested_fix"] is not None
        assert "os.getenv" in data["suggested_fix"]["code"]

    def test_chat_message_history(self, client):
        """Multiple messages maintain context — all are passed to LLM."""
        mock_llm = MagicMock()
        mock_llm.chat.return_value = "Sure, here is a follow-up explanation."

        messages = [
            {"role": "user", "content": "What is wrong with this code?"},
            {"role": "assistant", "content": "The password is hardcoded."},
            {"role": "user", "content": "How do I fix it?"},
        ]

        with patch("guard.server._load_config") as mock_config:
            cfg = MagicMock()
            cfg.llm_provider = "openai"
            mock_config.return_value = cfg

            with patch("guard.providers.factory.build_llm", return_value=mock_llm):
                resp = client.post(
                    "/api/chat",
                    json={"messages": messages},
                )

        assert resp.status_code == 200
        # Verify all 3 messages were passed to the LLM
        call_args = mock_llm.chat.call_args
        passed_messages = call_args[0][0]
        assert len(passed_messages) == 3
        assert passed_messages[2]["content"] == "How do I fix it?"

    def test_chat_with_file_path(self, client, tmp_path):
        """Reads file content when file_path is provided."""
        src = tmp_path / "target.py"
        src.write_text("x = eval(input())\n", encoding="utf-8")

        mock_llm = MagicMock()
        mock_llm.chat.return_value = "Use ast.literal_eval instead of eval."

        with patch("guard.server._load_config") as mock_config:
            cfg = MagicMock()
            cfg.llm_provider = "openai"
            mock_config.return_value = cfg

            with patch("guard.providers.factory.build_llm", return_value=mock_llm):
                # Temporarily chdir so the file is resolvable
                old_cwd = os.getcwd()
                try:
                    os.chdir(tmp_path)
                    resp = client.post(
                        "/api/chat",
                        json={
                            "messages": [{"role": "user", "content": "Fix eval usage"}],
                            "file_path": "target.py",
                        },
                    )
                finally:
                    os.chdir(old_cwd)

        assert resp.status_code == 200
        # System prompt should contain the file content
        call_args = mock_llm.chat.call_args
        system = call_args[1].get("system", "") or (call_args[0][1] if len(call_args[0]) > 1 else "")
        assert "eval(input())" in system


# ===================================================================
# POST /api/apply-fix
# ===================================================================


class TestApplyFixEndpoint:
    def test_apply_fix_success(self, client, tmp_source_file):
        """Modifies file correctly when original_code matches."""
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_source_file.parent)
            resp = client.post(
                "/api/apply-fix",
                json={
                    "file_path": "example.py",
                    "original_code": "password = 'hardcoded'",
                    "fixed_code": "password = os.getenv('PASSWORD', '')",
                    "start_line": 2,
                    "end_line": 2,
                },
            )
        finally:
            os.chdir(old_cwd)

        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True

        # Verify the file was modified
        content = tmp_source_file.read_text(encoding="utf-8")
        assert "os.getenv('PASSWORD', '')" in content
        assert "'hardcoded'" not in content

    def test_apply_fix_creates_backup(self, client, tmp_source_file):
        """Backup file is created before modifying."""
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_source_file.parent)
            client.post(
                "/api/apply-fix",
                json={
                    "file_path": "example.py",
                    "original_code": "password = 'hardcoded'",
                    "fixed_code": "password = os.getenv('PASSWORD', '')",
                    "start_line": 2,
                    "end_line": 2,
                },
            )
        finally:
            os.chdir(old_cwd)

        backup = tmp_source_file.with_suffix(".py.bak")
        assert backup.exists()
        # Backup should contain the original content
        backup_content = backup.read_text(encoding="utf-8")
        assert "'hardcoded'" in backup_content

    def test_apply_fix_mismatch_proceeds(self, client, tmp_source_file):
        """Mismatched original_code logs warning but proceeds (soft verification)."""
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_source_file.parent)
            resp = client.post(
                "/api/apply-fix",
                json={
                    "file_path": "example.py",
                    "original_code": "this does not match anything",
                    "fixed_code": "new code",
                    "start_line": 2,
                    "end_line": 2,
                },
            )
        finally:
            os.chdir(old_cwd)

        assert resp.status_code == 200

    def test_apply_fix_file_not_found(self, client, tmp_path):
        """Returns error when file doesn't exist."""
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            resp = client.post(
                "/api/apply-fix",
                json={
                    "file_path": "nonexistent.py",
                    "original_code": "x",
                    "fixed_code": "y",
                    "start_line": 1,
                    "end_line": 1,
                },
            )
        finally:
            os.chdir(old_cwd)

        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()
