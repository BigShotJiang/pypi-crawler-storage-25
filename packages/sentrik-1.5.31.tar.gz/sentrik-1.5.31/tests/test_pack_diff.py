"""Tests for pack version tracking and diff."""

from __future__ import annotations

import pytest

from guard.packs.registry import diff_pack_rules, list_available_packs, PackInfo


def _rule(rule_id: str, **overrides) -> dict:
    base = {
        "id": rule_id,
        "name": rule_id.lower(),
        "type": "regex",
        "pattern": "TODO",
        "severity": "medium",
    }
    base.update(overrides)
    return base


class TestDiffPackRules:
    def test_no_changes(self):
        rules = [_rule("R-001"), _rule("R-002")]
        result = diff_pack_rules(rules, rules)
        assert result["added"] == []
        assert result["removed"] == []
        assert result["modified"] == []
        assert sorted(result["unchanged"]) == ["R-001", "R-002"]

    def test_added_rules(self):
        old = [_rule("R-001")]
        new = [_rule("R-001"), _rule("R-002"), _rule("R-003")]
        result = diff_pack_rules(old, new)
        assert result["added"] == ["R-002", "R-003"]
        assert result["removed"] == []
        assert result["unchanged"] == ["R-001"]

    def test_removed_rules(self):
        old = [_rule("R-001"), _rule("R-002")]
        new = [_rule("R-001")]
        result = diff_pack_rules(old, new)
        assert result["removed"] == ["R-002"]
        assert result["added"] == []

    def test_modified_rule(self):
        old = [_rule("R-001", severity="medium")]
        new = [_rule("R-001", severity="high")]
        result = diff_pack_rules(old, new)
        assert result["modified"] == ["R-001"]
        assert result["unchanged"] == []
        assert "severity" in result["details"]["R-001"][0]

    def test_multiple_changes_in_one_rule(self):
        old = [_rule("R-001", severity="low", pattern="OLD")]
        new = [_rule("R-001", severity="high", pattern="NEW")]
        result = diff_pack_rules(old, new)
        assert result["modified"] == ["R-001"]
        assert len(result["details"]["R-001"]) == 2

    def test_empty_old(self):
        result = diff_pack_rules([], [_rule("R-001")])
        assert result["added"] == ["R-001"]
        assert result["removed"] == []

    def test_empty_new(self):
        result = diff_pack_rules([_rule("R-001")], [])
        assert result["removed"] == ["R-001"]
        assert result["added"] == []

    def test_both_empty(self):
        result = diff_pack_rules([], [])
        assert result["added"] == []
        assert result["removed"] == []
        assert result["modified"] == []
        assert result["unchanged"] == []

    def test_complex_diff(self):
        old = [_rule("R-001"), _rule("R-002", severity="low"), _rule("R-003")]
        new = [_rule("R-001"), _rule("R-002", severity="high"), _rule("R-004")]
        result = diff_pack_rules(old, new)
        assert result["added"] == ["R-004"]
        assert result["removed"] == ["R-003"]
        assert result["modified"] == ["R-002"]
        assert result["unchanged"] == ["R-001"]


class TestPackInfoVersion:
    def test_builtin_packs_have_version(self):
        packs = list_available_packs()
        for pack in packs:
            if pack.source == "builtin":
                assert pack.version, f"Pack {pack.pack_id} missing version"

    def test_pack_info_includes_version_field(self):
        info = PackInfo(
            pack_id="test", name="Test", version="1.2.0", last_updated="2026-03-30",
        )
        assert info.version == "1.2.0"
        assert info.last_updated == "2026-03-30"
