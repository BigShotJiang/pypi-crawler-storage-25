"""Tests for requirement coverage checking."""

from __future__ import annotations

import pytest

from guard.core.models import WorkItem
from guard.core.requirement_tracker import (
    DEFAULT_EXCLUDE_PATTERNS,
    _is_covered,
    _tokenize,
    check_requirement_coverage,
)


# ---------------------------------------------------------------------------
# _tokenize tests
# ---------------------------------------------------------------------------


class TestTokenize:
    def test_basic_path(self):
        tokens = _tokenize("src/auth/login_handler.py")
        assert "auth" in tokens
        assert "login" in tokens
        assert "handler" in tokens
        # Stop words filtered out
        assert "src" not in tokens
        assert "py" not in tokens

    def test_dashes_and_underscores(self):
        tokens = _tokenize("user-profile_manager")
        assert "user" in tokens
        assert "profile" in tokens
        assert "manager" in tokens

    def test_dots_split(self):
        tokens = _tokenize("config.backup.old")
        assert "config" in tokens
        assert "backup" in tokens
        assert "old" in tokens

    def test_single_char_tokens_filtered(self):
        tokens = _tokenize("a/b/c")
        assert len(tokens) == 0

    def test_stop_words_removed(self):
        tokens = _tokenize("the quick and brown fox")
        assert "the" not in tokens
        assert "and" not in tokens
        assert "quick" in tokens
        assert "brown" in tokens
        assert "fox" in tokens

    def test_empty_string(self):
        assert _tokenize("") == set()


# ---------------------------------------------------------------------------
# _is_covered tests
# ---------------------------------------------------------------------------


class TestIsCovered:
    def test_covered_by_token_overlap(self):
        file_tokens = {"auth", "login", "handler"}
        wi_tokens = [{"login", "authentication", "handler"}]
        assert _is_covered(file_tokens, wi_tokens, "src/auth/login_handler.py", [])

    def test_not_covered_single_token_overlap(self):
        file_tokens = {"auth", "login", "handler"}
        wi_tokens = [{"login", "database", "migration"}]
        assert not _is_covered(file_tokens, wi_tokens, "src/auth/login_handler.py", [])

    def test_covered_by_work_item_id(self):
        file_tokens = {"auth", "handler"}
        wi_tokens = [{"database", "migration"}]
        assert _is_covered(file_tokens, wi_tokens, "src/REQ-001/handler.py", ["REQ-001"])

    def test_work_item_id_case_insensitive(self):
        file_tokens = set()
        wi_tokens: list[set[str]] = []
        assert _is_covered(file_tokens, wi_tokens, "src/req-001_impl.py", ["REQ-001"])

    def test_no_coverage(self):
        file_tokens = {"auth", "login"}
        wi_tokens = [{"database", "migration"}]
        assert not _is_covered(file_tokens, wi_tokens, "src/auth/login.py", ["WI-99"])


# ---------------------------------------------------------------------------
# check_requirement_coverage tests
# ---------------------------------------------------------------------------


class TestCheckRequirementCoverage:
    def test_file_covered_by_keyword_match(self):
        """File matching work item tokens should not be flagged."""
        wi = WorkItem(id="WI-1", title="Implement login handler", state="active")
        findings = check_requirement_coverage(
            ["src/auth/login_handler.py"],
            [wi],
        )
        assert len(findings) == 0

    def test_file_not_covered(self):
        """File not matching any work item should produce a finding."""
        wi = WorkItem(id="WI-1", title="Implement login handler", state="active")
        findings = check_requirement_coverage(
            ["src/billing/payment_processor.py"],
            [wi],
        )
        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "GUARD-REQ-COVERAGE"
        assert f.severity.value == "medium"
        assert "payment_processor.py" in f.message
        assert f.evidence.file == "src/billing/payment_processor.py"
        assert f.compliance_category == "traceability"

    def test_excluded_patterns_skipped(self):
        """Test files and config files should be excluded by default."""
        wi = WorkItem(id="WI-1", title="Anything", state="active")
        findings = check_requirement_coverage(
            [
                "tests/test_auth.py",
                "test_billing.py",
                "README.md",
                "config.yaml",
                "package.json",
                "pyproject.toml",
            ],
            [wi],
        )
        assert len(findings) == 0

    def test_custom_exclude_patterns(self):
        """Custom exclude patterns should override defaults."""
        wi = WorkItem(id="WI-1", title="Anything", state="active")
        findings = check_requirement_coverage(
            ["src/billing/payment.py", "vendor/lib.py"],
            [wi],
            exclude_patterns=["vendor/*"],
        )
        # vendor/lib.py excluded, but src/billing/payment.py is not covered
        assert len(findings) == 1
        assert findings[0].evidence.file == "src/billing/payment.py"

    def test_empty_work_items(self):
        """All source files should be flagged when there are no work items."""
        findings = check_requirement_coverage(
            ["src/auth/login.py", "src/billing/payment.py"],
            [],
        )
        assert len(findings) == 2

    def test_empty_file_list(self):
        """No findings when there are no files to check."""
        wi = WorkItem(id="WI-1", title="Anything", state="active")
        findings = check_requirement_coverage([], [wi])
        assert len(findings) == 0

    def test_work_item_id_in_file_path(self):
        """File containing work item ID should be covered."""
        wi = WorkItem(id="REQ-007", title="Unrelated title", state="active")
        findings = check_requirement_coverage(
            ["src/REQ-007/implementation.py"],
            [wi],
        )
        assert len(findings) == 0

    def test_closed_work_items_ignored(self):
        """Closed work items should not provide coverage."""
        wi = WorkItem(
            id="WI-1",
            title="Implement login handler",
            state="closed",
        )
        findings = check_requirement_coverage(
            ["src/auth/login_handler.py"],
            [wi],
        )
        assert len(findings) == 1

    def test_multiple_work_items_cover_different_files(self):
        """Each file should be checked against all work items."""
        wi1 = WorkItem(id="WI-1", title="Implement login handler", state="active")
        wi2 = WorkItem(id="WI-2", title="Implement payment processor", state="active")
        findings = check_requirement_coverage(
            [
                "src/auth/login_handler.py",
                "src/billing/payment_processor.py",
                "src/notification/email_sender.py",
            ],
            [wi1, wi2],
        )
        # Only email_sender should be untracked
        assert len(findings) == 1
        assert "email_sender" in findings[0].evidence.file

    def test_finding_fields(self):
        """Verify all finding fields are set correctly."""
        findings = check_requirement_coverage(
            ["src/feature/module.py"],
            [],
        )
        assert len(findings) == 1
        f = findings[0]
        assert f.finding_id.startswith("REQ-COV-")
        assert f.rule_id == "GUARD-REQ-COVERAGE"
        assert f.severity == "medium"
        assert f.confidence == 1.0
        assert f.deterministic is True
        assert f.compliance_category == "traceability"
        assert f.evidence.lines == [1]
        assert f.evidence.snippet == ""

    def test_description_coverage(self):
        """Work item description tokens should also be used for matching."""
        wi = WorkItem(
            id="WI-1",
            title="Implement feature",
            description="Add email notification sender",
            state="active",
        )
        findings = check_requirement_coverage(
            ["src/notification/email_sender.py"],
            [wi],
        )
        assert len(findings) == 0
