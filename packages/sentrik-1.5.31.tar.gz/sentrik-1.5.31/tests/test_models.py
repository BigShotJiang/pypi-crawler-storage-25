"""Tests for Pydantic models — construction, validation, defaults, and serialization."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from guard.core.models import (
    AgentContext,
    DefinitionOfDone,
    DiffHunk,
    Evidence,
    FileDiff,
    FileScope,
    Finding,
    GateResult,
    RunComparison,
    RunMetadata,
    Severity,
    WorkItem,
)


# ===================================================================
# Severity
# ===================================================================


class TestSeverity:
    def test_enum_values(self):
        assert Severity.CRITICAL.value == "critical"
        assert Severity.HIGH.value == "high"
        assert Severity.MEDIUM.value == "medium"
        assert Severity.LOW.value == "low"
        assert Severity.INFO.value == "info"

    def test_string_construction(self):
        assert Severity("critical") is Severity.CRITICAL
        assert Severity("high") is Severity.HIGH

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            Severity("banana")

    def test_str_subclass(self):
        assert isinstance(Severity.LOW, str)
        assert Severity.LOW == "low"

    def test_all_values_present(self):
        assert len(Severity) == 5


# ===================================================================
# Evidence
# ===================================================================


class TestEvidence:
    def test_defaults(self):
        e = Evidence(file="a.py")
        assert e.lines == []
        assert e.snippet == ""

    def test_required_file(self):
        with pytest.raises(ValidationError):
            Evidence()  # type: ignore[call-arg]

    def test_round_trip(self):
        e = Evidence(file="a.py", lines=[1, 2], snippet="x = 1")
        restored = Evidence(**e.model_dump())
        assert restored == e

    def test_full_construction(self):
        e = Evidence(file="src/main.py", lines=[10, 20], snippet="print('hi')")
        assert e.file == "src/main.py"
        assert e.lines == [10, 20]
        assert e.snippet == "print('hi')"


# ===================================================================
# Finding
# ===================================================================


class TestFinding:
    def test_minimal_construction(self):
        f = Finding(
            finding_id="F1",
            rule_id="R1",
            severity=Severity.LOW,
            message="msg",
            evidence=Evidence(file="a.py"),
            confidence=1.0,
        )
        assert f.finding_id == "F1"
        assert f.suggestion is None
        assert f.deterministic is True
        assert f.related_work_items == []

    def test_full_construction(self):
        f = Finding(
            finding_id="F1",
            rule_id="R1",
            severity=Severity.CRITICAL,
            message="Big problem",
            evidence=Evidence(file="b.py", lines=[5], snippet="eval()"),
            suggestion="Remove eval",
            confidence=0.85,
            deterministic=False,
            related_work_items=["WI-100"],
        )
        assert f.severity == Severity.CRITICAL
        assert f.suggestion == "Remove eval"
        assert f.deterministic is False
        assert f.related_work_items == ["WI-100"]

    def test_confidence_lower_bound(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.LOW,
            message="m", evidence=Evidence(file="a.py"), confidence=0.0,
        )
        assert f.confidence == 0.0

    def test_confidence_upper_bound(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.LOW,
            message="m", evidence=Evidence(file="a.py"), confidence=1.0,
        )
        assert f.confidence == 1.0

    def test_confidence_below_zero_raises(self):
        with pytest.raises(ValidationError):
            Finding(
                finding_id="F1", rule_id="R1", severity=Severity.LOW,
                message="m", evidence=Evidence(file="a.py"), confidence=-0.1,
            )

    def test_confidence_above_one_raises(self):
        with pytest.raises(ValidationError):
            Finding(
                finding_id="F1", rule_id="R1", severity=Severity.LOW,
                message="m", evidence=Evidence(file="a.py"), confidence=1.1,
            )

    def test_defaults(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.LOW,
            message="m", evidence=Evidence(file="a.py"), confidence=0.5,
        )
        assert f.suggestion is None
        assert f.deterministic is True
        assert f.related_work_items == []

    def test_serialization_round_trip(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.LOW,
            message="m", evidence=Evidence(file="a.py"), confidence=0.5,
        )
        data = f.model_dump()
        restored = Finding(**data)
        assert restored == f

    def test_json_round_trip(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.CRITICAL,
            message="m", evidence=Evidence(file="a.py", lines=[1], snippet="x"),
            suggestion="fix", confidence=0.9, deterministic=False,
            related_work_items=["WI-1"],
        )
        json_str = f.model_dump_json()
        restored = Finding.model_validate_json(json_str)
        assert restored == f

    def test_severity_from_string(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity="high",  # type: ignore[arg-type]
            message="m", evidence=Evidence(file="a.py"), confidence=1.0,
        )
        assert f.severity == Severity.HIGH


# ===================================================================
# WorkItem
# ===================================================================


class TestWorkItem:
    def test_minimal(self):
        w = WorkItem(id="WI-1", title="Do thing")
        assert w.id == "WI-1"
        assert w.description == ""
        assert w.acceptance_criteria == []
        assert w.state == "active"

    def test_defaults(self):
        w = WorkItem(id="WI-1", title="T")
        assert w.state == "active"

    def test_round_trip(self):
        w = WorkItem(
            id="WI-1", title="T", description="D",
            acceptance_criteria=["A"], state="closed",
        )
        restored = WorkItem(**w.model_dump())
        assert restored == w


# ===================================================================
# FileScope
# ===================================================================


class TestFileScope:
    def test_defaults(self):
        fs = FileScope()
        assert fs.allowed == ["**/*"]
        assert fs.blocked == []

    def test_custom(self):
        fs = FileScope(allowed=["src/**"], blocked=["tests/**"])
        assert fs.allowed == ["src/**"]
        assert fs.blocked == ["tests/**"]

    def test_round_trip(self):
        fs = FileScope(allowed=["*.py"], blocked=["vendor/*"])
        restored = FileScope(**fs.model_dump())
        assert restored == fs


# ===================================================================
# DefinitionOfDone
# ===================================================================


class TestDefinitionOfDone:
    def test_defaults(self):
        d = DefinitionOfDone()
        assert d.gate_must_pass is True
        assert d.required_rules == []

    def test_custom(self):
        d = DefinitionOfDone(gate_must_pass=False, required_rules=["R1", "R2"])
        assert d.gate_must_pass is False
        assert d.required_rules == ["R1", "R2"]

    def test_round_trip(self):
        d = DefinitionOfDone(required_rules=["R1"])
        restored = DefinitionOfDone(**d.model_dump())
        assert restored == d


# ===================================================================
# AgentContext
# ===================================================================


class TestAgentContext:
    def test_defaults(self):
        ac = AgentContext(repo_root="/repo")
        assert ac.repo_root == "/repo"
        assert ac.work_items == []
        assert ac.standards_rule_ids == []
        assert ac.commands == {}

    def test_full(self):
        ac = AgentContext(
            repo_root="/repo",
            work_items=[WorkItem(id="WI-1", title="T")],
            standards_rule_ids=["R1"],
            commands={"scan": "guard scan"},
            definition_of_done=DefinitionOfDone(required_rules=["R1"]),
        )
        assert len(ac.work_items) == 1
        assert ac.commands["scan"] == "guard scan"

    def test_round_trip(self):
        ac = AgentContext(
            repo_root="/repo",
            standards_rule_ids=["R1"],
            commands={"scan": "guard scan"},
        )
        restored = AgentContext(**ac.model_dump())
        assert restored == ac


# ===================================================================
# RunMetadata
# ===================================================================


class TestRunMetadata:
    def test_full(self):
        rm = RunMetadata(
            run_id="abc", timestamp="2025-01-01T00:00:00Z",
            guard_version="0.1.0", command="scan", exit_code=0,
            findings_count=5, duration_ms=123.4,
        )
        assert rm.run_id == "abc"
        assert rm.scoped_files is None

    def test_scoped_files_none(self):
        rm = RunMetadata(
            run_id="x", timestamp="t", guard_version="v",
            command="scan", exit_code=0, findings_count=0, duration_ms=0,
        )
        assert rm.scoped_files is None

    def test_round_trip(self):
        rm = RunMetadata(
            run_id="x", timestamp="t", guard_version="v",
            command="gate", exit_code=1, findings_count=3,
            duration_ms=99.9, scoped_files=["a.py"],
        )
        restored = RunMetadata(**rm.model_dump())
        assert restored == rm


# ===================================================================
# FileDiff
# ===================================================================


class TestFileDiff:
    def test_path_prefers_new_path(self):
        fd = FileDiff(old_path="old.py", new_path="new.py")
        assert fd.path == "new.py"

    def test_path_falls_back_to_old_path(self):
        fd = FileDiff(old_path="old.py", new_path="")
        assert fd.path == "old.py"

    def test_defaults(self):
        fd = FileDiff(old_path="a.py", new_path="a.py")
        assert fd.is_binary is False
        assert fd.is_rename is False
        assert fd.is_new is False
        assert fd.is_deleted is False
        assert fd.hunks == []

    def test_round_trip(self):
        fd = FileDiff(
            old_path="a.py", new_path="b.py", is_rename=True,
            hunks=[DiffHunk(src_start=1, src_count=1, tgt_start=1, tgt_count=0, lines=["-x"])],
        )
        restored = FileDiff(**fd.model_dump())
        assert restored == fd


# ===================================================================
# GateResult
# ===================================================================


class TestGateResult:
    def test_passed_true(self):
        gr = GateResult(passed=True, total_findings=0)
        assert gr.passed is True

    def test_passed_false(self):
        gr = GateResult(passed=False, total_findings=3, critical=1, high=2)
        assert gr.passed is False
        assert gr.critical == 1

    def test_default_counts_zero(self):
        gr = GateResult(passed=True, total_findings=0)
        assert gr.critical == 0
        assert gr.high == 0
        assert gr.medium == 0
        assert gr.low == 0
        assert gr.info == 0

    def test_round_trip(self):
        gr = GateResult(
            passed=False, total_findings=5,
            critical=1, high=2, medium=1, low=1, info=0,
        )
        restored = GateResult(**gr.model_dump())
        assert restored == gr


# ===================================================================
# RunComparison
# ===================================================================


class TestRunComparison:
    def test_defaults(self):
        rc = RunComparison()
        assert rc.new_findings == []
        assert rc.resolved_findings == []
        assert rc.unchanged_findings == []

    def test_with_findings(self):
        f = Finding(
            finding_id="F1", rule_id="R1", severity=Severity.LOW,
            message="m", evidence=Evidence(file="a.py"), confidence=1.0,
        )
        rc = RunComparison(new_findings=[f])
        assert len(rc.new_findings) == 1
        assert rc.new_findings[0].finding_id == "F1"
