"""Tests for DevOpsAzure provider — all Azure SDK calls are mocked."""

from __future__ import annotations

import os
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.config import GuardConfig, VALID_DEVOPS_PROVIDERS
from guard.providers.devops_azure import (
    DevOpsAzure,
    _normalize_state,
    _parse_acceptance_criteria,
    _strip_html,
)
from guard.providers.devops_base import DevOpsProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_raw_work_item(
    wi_id: int = 1,
    title: str = "Test item",
    description: str | None = None,
    acceptance_criteria: str | None = None,
    state: str = "Active",
) -> SimpleNamespace:
    """Create a mock Azure DevOps work item object."""
    fields = {
        "System.Id": wi_id,
        "System.Title": title,
        "System.State": state,
    }
    if description is not None:
        fields["System.Description"] = description
    if acceptance_criteria is not None:
        fields["Microsoft.VSTS.Common.AcceptanceCriteria"] = acceptance_criteria
    return SimpleNamespace(id=wi_id, fields=fields)


def _make_provider(pat: str | None = "fake-pat") -> DevOpsAzure:
    """Create a DevOpsAzure with a mocked client, skipping real auth."""
    provider = DevOpsAzure(
        org="myorg",
        project="MyProject",
        team="MyTeam",
        iteration="Sprint 1",
    )
    # Inject a mock client so we never hit the real SDK
    provider._client = MagicMock()
    return provider


# ---------------------------------------------------------------------------
# HTML stripping
# ---------------------------------------------------------------------------

class TestStripHtml:
    def test_plain_text(self):
        assert _strip_html("hello world") == "hello world"

    def test_html_tags_removed(self):
        assert _strip_html("<p>Hello <b>world</b></p>") == "Hello world"

    def test_none_returns_empty(self):
        assert _strip_html(None) == ""

    def test_empty_returns_empty(self):
        assert _strip_html("") == ""


# ---------------------------------------------------------------------------
# Acceptance criteria parsing
# ---------------------------------------------------------------------------

class TestParseAcceptanceCriteria:
    def test_li_items(self):
        html = "<ul><li>First</li><li>Second</li></ul>"
        assert _parse_acceptance_criteria(html) == ["First", "Second"]

    def test_br_separated(self):
        html = "Criterion A<br>Criterion B<br>Criterion C"
        assert _parse_acceptance_criteria(html) == [
            "Criterion A",
            "Criterion B",
            "Criterion C",
        ]

    def test_numbered_items(self):
        html = "<ol><li>1. First item</li><li>2) Second item</li></ol>"
        assert _parse_acceptance_criteria(html) == ["First item", "Second item"]

    def test_none_returns_empty(self):
        assert _parse_acceptance_criteria(None) == []

    def test_empty_returns_empty(self):
        assert _parse_acceptance_criteria("") == []

    def test_plain_text_single_item(self):
        assert _parse_acceptance_criteria("Just a string") == ["Just a string"]


# ---------------------------------------------------------------------------
# State normalization
# ---------------------------------------------------------------------------

class TestNormalizeState:
    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("Active", "active"),
            ("New", "active"),
            ("Resolved", "active"),
            ("Committed", "active"),
            ("Done", "closed"),
            ("Closed", "closed"),
            ("Removed", "removed"),
        ],
    )
    def test_known_states(self, raw, expected):
        assert _normalize_state(raw) == expected

    def test_unknown_defaults_to_active(self):
        assert _normalize_state("CustomState") == "active"

    def test_none_defaults_to_active(self):
        assert _normalize_state(None) == "active"


# ---------------------------------------------------------------------------
# Field mapping
# ---------------------------------------------------------------------------

class TestFieldMapping:
    def test_basic_mapping(self):
        provider = _make_provider()
        raw = _make_raw_work_item(
            wi_id=42,
            title="My Task",
            description="<p>Do something</p>",
            acceptance_criteria="<ul><li>AC1</li><li>AC2</li></ul>",
            state="Active",
        )
        provider._client.get_work_items.return_value = [raw]

        items = provider.get_work_items(ids=["42"])

        assert len(items) == 1
        wi = items[0]
        assert wi.id == "42"
        assert wi.title == "My Task"
        assert wi.description == "Do something"
        assert wi.acceptance_criteria == ["AC1", "AC2"]
        assert wi.state == "active"

    def test_null_fields(self):
        provider = _make_provider()
        raw = _make_raw_work_item(
            wi_id=1,
            title="Minimal",
            description=None,
            acceptance_criteria=None,
            state="New",
        )
        provider._client.get_work_items.return_value = [raw]

        items = provider.get_work_items(ids=["1"])

        wi = items[0]
        assert wi.description == ""
        assert wi.acceptance_criteria == []
        assert wi.state == "active"


# ---------------------------------------------------------------------------
# get_work_items by ID
# ---------------------------------------------------------------------------

class TestGetWorkItemsById:
    def test_fetch_by_ids(self):
        provider = _make_provider()
        raw1 = _make_raw_work_item(wi_id=10, title="Item 10")
        raw2 = _make_raw_work_item(wi_id=20, title="Item 20")
        provider._client.get_work_items.return_value = [raw1, raw2]

        items = provider.get_work_items(ids=["10", "20"])

        assert len(items) == 2
        assert items[0].id == "10"
        assert items[1].id == "20"
        provider._client.get_work_items.assert_called_once()

    def test_batch_fetching(self):
        """IDs > 200 should be split into batches."""
        provider = _make_provider()
        # Return empty for simplicity — we just want to verify batching
        provider._client.get_work_items.return_value = []

        ids = [str(i) for i in range(1, 402)]  # 401 items → 3 batches
        provider.get_work_items(ids=ids)

        assert provider._client.get_work_items.call_count == 3


# ---------------------------------------------------------------------------
# get_work_items by iteration (WIQL)
# ---------------------------------------------------------------------------

class TestGetWorkItemsByIteration:
    def test_fetch_by_iteration(self):
        provider = _make_provider()
        # Mock WIQL query result
        wiql_result = SimpleNamespace(
            work_items=[SimpleNamespace(id=5), SimpleNamespace(id=6)]
        )
        provider._client.query_by_wiql.return_value = wiql_result
        provider._client.get_work_items.return_value = [
            _make_raw_work_item(wi_id=5, title="Story 5"),
            _make_raw_work_item(wi_id=6, title="Story 6"),
        ]

        with patch(
            "guard.providers.devops_azure.Wiql",
            create=True,
        ) as mock_wiql_cls:
            # Patch the import inside _fetch_by_iteration
            import guard.providers.devops_azure as mod

            original_fetch = mod.DevOpsAzure._fetch_by_iteration

            def patched_fetch(self, client):
                # Simulate what _fetch_by_iteration does with mocked Wiql
                wiql_query = (
                    "SELECT [System.Id] FROM WorkItems "
                    f"WHERE [System.IterationPath] UNDER '{self._iteration}' "
                    "AND [System.State] <> 'Removed'"
                )
                wiql = SimpleNamespace(query=wiql_query)
                team_ctx = {"project": self._project, "team": self._team}
                result = client.query_by_wiql(wiql, team_context=team_ctx)
                if not result.work_items:
                    return []
                wi_ids = [wi.id for wi in result.work_items]
                return self._fetch_by_ids(client, wi_ids)

            with patch.object(mod.DevOpsAzure, "_fetch_by_iteration", patched_fetch):
                items = provider.get_work_items()

        assert len(items) == 2
        assert items[0].title == "Story 5"

    def test_empty_iteration_result(self):
        provider = _make_provider()
        wiql_result = SimpleNamespace(work_items=[])
        provider._client.query_by_wiql.return_value = wiql_result

        with patch(
            "guard.providers.devops_azure.Wiql",
            create=True,
        ):
            import guard.providers.devops_azure as mod

            def patched_fetch(self, client):
                wiql = SimpleNamespace(query="...")
                team_ctx = {"project": self._project}
                result = client.query_by_wiql(wiql, team_context=team_ctx)
                if not result.work_items:
                    return []
                wi_ids = [wi.id for wi in result.work_items]
                return self._fetch_by_ids(client, wi_ids)

            with patch.object(mod.DevOpsAzure, "_fetch_by_iteration", patched_fetch):
                items = provider.get_work_items()

        assert items == []


# ---------------------------------------------------------------------------
# Auth paths
# ---------------------------------------------------------------------------

class TestAuth:
    def test_pat_auth_used_when_env_set(self):
        """When AZURE_DEVOPS_PAT is set, BasicAuthentication is used."""
        provider = DevOpsAzure(org="myorg", project="MyProject")

        mock_connection_cls = MagicMock()
        mock_basic_auth_cls = MagicMock()
        mock_connection_instance = MagicMock()
        mock_connection_cls.return_value = mock_connection_instance

        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "test-token"}):
            with patch(
                "guard.providers.devops_azure.Connection",
                mock_connection_cls,
                create=True,
            ):
                with patch(
                    "guard.providers.devops_azure.BasicAuthentication",
                    mock_basic_auth_cls,
                    create=True,
                ):
                    # Trigger lazy import path
                    import guard.providers.devops_azure as mod

                    # Reset client to force re-init
                    provider._client = None

                    # Patch the import statements within _get_client
                    original_get_client = mod.DevOpsAzure._get_client

                    def mock_get_client(self):
                        from unittest.mock import MagicMock as MM

                        pat = os.environ.get("AZURE_DEVOPS_PAT")
                        assert pat == "test-token"
                        self._client = MM()
                        return self._client

                    with patch.object(mod.DevOpsAzure, "_get_client", mock_get_client):
                        client = provider._get_client()
                        assert client is not None


# ---------------------------------------------------------------------------
# Factory integration
# ---------------------------------------------------------------------------

class TestFactory:
    def test_default_returns_stub(self):
        from guard.providers.devops_stub import DevOpsStub
        from guard.providers.factory import build_devops

        config = GuardConfig()
        provider = build_devops(config)
        assert isinstance(provider, DevOpsStub)

    def test_azure_returns_devops_azure(self):
        from guard.providers.factory import build_devops

        config = GuardConfig(
            devops_provider="azure",
            azure_devops_org="myorg",
            azure_devops_project="MyProject",
        )
        provider = build_devops(config)
        assert isinstance(provider, DevOpsAzure)
        assert isinstance(provider, DevOpsProvider)


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------

class TestConfigValidation:
    def test_valid_devops_providers_set(self):
        assert "stub" in VALID_DEVOPS_PROVIDERS
        assert "azure" in VALID_DEVOPS_PROVIDERS

    def test_invalid_provider_errors(self):
        config = GuardConfig(devops_provider="bitbucket")
        warnings = config.validate_config()
        errors = [w for w in warnings if w.field == "devops_provider" and w.level == "error"]
        assert len(errors) == 1
        assert "bitbucket" in errors[0].message

    def test_azure_missing_org_warns(self):
        config = GuardConfig(
            devops_provider="azure",
            azure_devops_org="",
            azure_devops_project="Proj",
        )
        warnings = config.validate_config()
        org_warns = [w for w in warnings if w.field == "azure_devops_org"]
        assert len(org_warns) == 1

    def test_azure_missing_project_warns(self):
        config = GuardConfig(
            devops_provider="azure",
            azure_devops_org="myorg",
            azure_devops_project="",
        )
        warnings = config.validate_config()
        proj_warns = [w for w in warnings if w.field == "azure_devops_project"]
        assert len(proj_warns) == 1

    def test_stub_provider_no_azure_warnings(self):
        config = GuardConfig(devops_provider="stub")
        warnings = config.validate_config()
        azure_warns = [
            w
            for w in warnings
            if w.field in ("azure_devops_org", "azure_devops_project")
        ]
        assert azure_warns == []

    def test_work_items_file_check_skipped_for_azure(self):
        config = GuardConfig(
            devops_provider="azure",
            azure_devops_org="myorg",
            azure_devops_project="Proj",
            work_items_file="nonexistent.json",
        )
        warnings = config.validate_config()
        wi_warns = [w for w in warnings if w.field == "work_items_file"]
        assert wi_warns == []

    def test_env_var_overrides(self):
        import os

        env = {
            "GUARD_DEVOPS_PROVIDER": "azure",
            "GUARD_AZURE_DEVOPS_ORG": "envorg",
            "GUARD_AZURE_DEVOPS_PROJECT": "envproj",
            "GUARD_AZURE_DEVOPS_TEAM": "envteam",
            "GUARD_AZURE_DEVOPS_ITERATION": "Sprint 5",
        }
        with patch.dict(os.environ, env):
            config = GuardConfig.load()

        assert config.devops_provider == "azure"
        assert config.azure_devops_org == "envorg"
        assert config.azure_devops_project == "envproj"
        assert config.azure_devops_team == "envteam"
        assert config.azure_devops_iteration == "Sprint 5"


# ---------------------------------------------------------------------------
# Create / Update / Close via REST API
# ---------------------------------------------------------------------------


class TestCreateWorkItem:
    def test_create_success(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"id": 42}

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.post.return_value = mock_resp
                result = provider.create_work_item(
                    title="Test WI",
                    description="desc",
                    acceptance_criteria="ac",
                    tags="guard;R-1",
                )

        assert result == 42
        mock_req.post.assert_called_once()
        call_args = mock_req.post.call_args
        patch_doc = call_args[1]["json"]
        titles = [p["value"] for p in patch_doc if p["path"] == "/fields/System.Title"]
        assert titles == ["Test WI"]

    def test_create_no_pat(self):
        provider = _make_provider()
        with patch.dict(os.environ, _home_env(), clear=True):
            os.environ.pop("AZURE_DEVOPS_PAT", None)
            result = provider.create_work_item(title="Test")
        assert result is None

    def test_create_api_failure(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 400
        mock_resp.text = "Bad Request"

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.post.return_value = mock_resp
                result = provider.create_work_item(title="Test")

        assert result is None

    def test_create_with_iteration(self):
        provider = DevOpsAzure(
            org="myorg", project="MyProject", iteration="Sprint 5",
        )
        provider._client = MagicMock()

        mock_resp = MagicMock()
        mock_resp.status_code = 201
        mock_resp.json.return_value = {"id": 99}

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.post.return_value = mock_resp
                result = provider.create_work_item(title="Iter WI")

        assert result == 99
        patch_doc = mock_req.post.call_args[1]["json"]
        iter_fields = [p for p in patch_doc if p["path"] == "/fields/System.IterationPath"]
        assert len(iter_fields) == 1
        assert iter_fields[0]["value"] == "Sprint 5"


class TestUpdateWorkItem:
    def test_update_success(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 200

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.patch.return_value = mock_resp
                result = provider.update_work_item(42, title="New Title")

        assert result is True
        mock_req.patch.assert_called_once()

    def test_update_no_fields(self):
        provider = _make_provider()
        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            result = provider.update_work_item(42)
        assert result is True  # no-op is success

    def test_update_api_failure(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_resp.text = "Not Found"

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.patch.return_value = mock_resp
                result = provider.update_work_item(42, title="X")

        assert result is False

    def test_update_no_pat(self):
        provider = _make_provider()
        with patch.dict(os.environ, _home_env(), clear=True):
            os.environ.pop("AZURE_DEVOPS_PAT", None)
            result = provider.update_work_item(42, title="X")
        assert result is False


# ---------------------------------------------------------------------------
# @CurrentIteration error handling
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Title-based rule_id extraction and devops_id
# ---------------------------------------------------------------------------

class TestRuleIdExtraction:
    def test_reconcile_title_extracts_rule_id(self):
        """Titles like '[IEC62304-CODE-001] description' should set rule_id."""
        provider = _make_provider()
        raw = _make_raw_work_item(
            wi_id=35,
            title="[IEC62304-CODE-001] no-assert-in-production",
            state="Active",
        )
        provider._client.get_work_items.return_value = [raw]
        items = provider.get_work_items(ids=["35"])
        assert items[0].rule_id == "IEC62304-CODE-001"

    def test_dotted_rule_id_extracted(self):
        """Titles like '[IEC62304-5.1.1] description' should also set rule_id."""
        provider = _make_provider()
        raw = _make_raw_work_item(
            wi_id=36,
            title="[IEC62304-5.1.1] software-development-plan",
            state="Active",
        )
        provider._client.get_work_items.return_value = [raw]
        items = provider.get_work_items(ids=["36"])
        assert items[0].rule_id == "IEC62304-5.1.1"

    def test_normal_title_no_rule_id(self):
        """Regular titles should not extract a rule_id."""
        provider = _make_provider()
        raw = _make_raw_work_item(wi_id=27, title="User Authentication", state="Active")
        provider._client.get_work_items.return_value = [raw]
        items = provider.get_work_items(ids=["27"])
        assert items[0].rule_id is None

    def test_devops_id_is_set(self):
        """Azure work items should have devops_id set to the numeric ID."""
        provider = _make_provider()
        raw = _make_raw_work_item(wi_id=42, title="Test", state="Active")
        provider._client.get_work_items.return_value = [raw]
        items = provider.get_work_items(ids=["42"])
        assert items[0].devops_id == 42


# ---------------------------------------------------------------------------
# @CurrentIteration error handling
# ---------------------------------------------------------------------------

class TestCurrentIterationErrors:
    def test_no_team_falls_back_to_all_items(self):
        """When no team or iteration is set, fetch all active work items."""
        provider = DevOpsAzure(org="myorg", project="MyProject", team="", iteration="")
        provider._client = MagicMock()
        provider._client.query_by_wiql.return_value = MagicMock(work_items=[])

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                result = provider._fetch_by_iteration(provider._client)
                assert result == []

    def test_no_team_query_failure_gives_helpful_error(self):
        """When fallback query fails without team, give a helpful error."""
        provider = DevOpsAzure(org="myorg", project="MyProject", team="", iteration="")
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("TF401243: team not found")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="WIQL query failed"):
                    provider._fetch_by_iteration(provider._client)

    def test_team_set_but_fails_gives_helpful_error(self):
        """When @CurrentIteration fails with a team, suggest checking iteration config."""
        provider = DevOpsAzure(org="myorg", project="MyProject", team="MyTeam", iteration="")
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("No iteration found")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="iteration settings"):
                    provider._fetch_by_iteration(provider._client)

    def test_specific_path_fails_includes_path(self):
        """When a specific iteration path fails, the error includes the path."""
        provider = DevOpsAzure(
            org="myorg", project="MyProject", team="", iteration="MyProject\\Sprint 99",
        )
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("path not found")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="Sprint 99"):
                    provider._fetch_by_iteration(provider._client)


class TestCloseWorkItem:
    def test_close_success(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 200

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.patch.return_value = mock_resp
                result = provider.close_work_item(42)

        assert result is True
        patch_doc = mock_req.patch.call_args[1]["json"]
        state_ops = [p for p in patch_doc if "System.State" in p["path"]]
        assert len(state_ops) == 1
        assert state_ops[0]["value"] == "Done"

    def test_close_failure(self):
        provider = _make_provider()
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text = "Server Error"

        with patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "test-pat"}):
            with patch("guard.providers.devops_azure._requests_mod") as mock_req:
                mock_req.patch.return_value = mock_resp
                result = provider.close_work_item(42)

        assert result is False


# ---------------------------------------------------------------------------
# @CurrentIteration error handling
# ---------------------------------------------------------------------------


class TestIterationErrorHandling:
    def test_current_iteration_no_team_fallback(self):
        """@CurrentIteration without a team should fall back to all active items."""
        provider = DevOpsAzure(org="myorg", project="MyProject", team="", iteration="")
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("TF401243: team not found")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="WIQL query failed"):
                    provider._fetch_by_iteration(provider._client)

    def test_current_iteration_with_team_error(self):
        """@CurrentIteration with a team that fails should suggest checking iteration config."""
        provider = DevOpsAzure(org="myorg", project="MyProject", team="MyTeam", iteration="")
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("iteration not configured")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="active iteration configured"):
                    provider._fetch_by_iteration(provider._client)

    def test_specific_iteration_error(self):
        """A specific iteration path that fails should include the path in the error."""
        provider = DevOpsAzure(
            org="myorg", project="MyProject", team="", iteration="MyProject\\Sprint 99",
        )
        provider._client = MagicMock()
        provider._client.query_by_wiql.side_effect = Exception("not found")

        with patch("guard.providers.devops_azure.Wiql", create=True):
            with patch("guard.providers.devops_azure.TeamContext", create=True):
                with pytest.raises(RuntimeError, match="Sprint 99"):
                    provider._fetch_by_iteration(provider._client)
