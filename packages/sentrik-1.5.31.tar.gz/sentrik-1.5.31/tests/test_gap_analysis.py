"""Tests for regulatory gap analysis."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from guard.core.gap_analysis import analyze_gap, format_gap_report


def _pack_yaml(rules, version="1.0.0"):
    return {"name": "Test Pack", "version": version, "rules": rules}


def _rule(rule_id, severity="medium", **kw):
    base = {"id": rule_id, "name": rule_id.lower(), "type": "regex", "pattern": "TODO", "severity": severity}
    base.update(kw)
    return base


def _obligation(rule_id, severity="info", **kw):
    base = {"id": rule_id, "name": rule_id.lower(), "type": "documentation_obligation", "severity": severity, "clause": "1.1"}
    base.update(kw)
    return base


class TestAnalyzeGap:
    def test_no_changes(self, tmp_path):
        rules = [_rule("R-001"), _rule("R-002")]
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml(rules, "0.9.0")), encoding="utf-8")

        # Use supply-chain-security since it's a known pack
        result = analyze_gap("supply-chain-security", old_pack_data=_pack_yaml(
            [{"id": r["id"], **{k: v for k, v in r.items()}} for r in
             __import__("guard.packs.registry", fromlist=["load_pack_rules"]).load_pack_rules("supply-chain-security")]
        ))
        assert result["summary"]["total_gaps"] == 0

    def test_new_obligations(self):
        old = _pack_yaml([_rule("R-001")])
        new_rules = [_rule("R-001"), _obligation("R-NEW", clause="2.1")]
        result = analyze_gap.__wrapped__(old, new_rules) if hasattr(analyze_gap, '__wrapped__') else None
        # Use data-based approach
        from guard.core.gap_analysis import analyze_gap as _ag
        # We'll test via pack data directly

    def test_added_rules_are_gaps(self, tmp_path):
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml([])), encoding="utf-8")
        result = analyze_gap("supply-chain-security", old_pack_path=old_path)
        assert result["summary"]["new_obligations"] > 0
        assert result["summary"]["total_gaps"] > 0

    def test_no_old_file_baseline(self):
        result = analyze_gap("supply-chain-security")
        # All current rules are "new" when no old version provided
        assert result["summary"]["new_obligations"] > 0
        assert result["old_version"] == "none"

    def test_version_tracking(self, tmp_path):
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml([], "0.5.0")), encoding="utf-8")
        result = analyze_gap("supply-chain-security", old_pack_path=old_path)
        assert result["old_version"] == "0.5.0"
        assert result["current_version"]

    def test_severity_strengthening(self, tmp_path):
        # Create old version with a rule at low severity
        from guard.packs.registry import load_pack_rules
        current_rules = load_pack_rules("supply-chain-security")
        # Modify first code rule to have lower severity in "old" version
        old_rules = []
        for r in current_rules:
            copy = dict(r)
            if copy.get("type") == "regex" and copy.get("severity") in ("critical", "high"):
                copy["severity"] = "low"  # weaken it
            old_rules.append(copy)
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml(old_rules, "0.9.0")), encoding="utf-8")
        result = analyze_gap("supply-chain-security", old_pack_path=old_path)
        assert result["summary"]["strengthened_rules"] > 0

    def test_removed_obligations(self, tmp_path):
        from guard.packs.registry import load_pack_rules
        current_rules = load_pack_rules("supply-chain-security")
        # Add an extra rule to old that doesn't exist in current
        old_rules = list(current_rules) + [_rule("REMOVED-001")]
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml(old_rules)), encoding="utf-8")
        result = analyze_gap("supply-chain-security", old_pack_path=old_path)
        assert result["summary"]["removed_obligations"] == 1
        assert result["removed_obligations"][0]["rule_id"] == "REMOVED-001"

    def test_unknown_pack_raises(self):
        with pytest.raises(ValueError, match="not found"):
            analyze_gap("nonexistent-pack")

    def test_json_serializable(self, tmp_path):
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml([])), encoding="utf-8")
        result = analyze_gap("supply-chain-security", old_pack_path=old_path)
        # Should not raise
        json.dumps(result)


class TestFormatGapReport:
    def test_format_output(self, tmp_path):
        old_path = tmp_path / "old.yaml"
        old_path.write_text(yaml.dump(_pack_yaml([])), encoding="utf-8")
        analysis = analyze_gap("supply-chain-security", old_pack_path=old_path)
        report = format_gap_report(analysis)
        assert "Gap Analysis" in report
        assert "Supply Chain Security" in report
        assert "NEW OBLIGATIONS" in report

    def test_format_no_changes(self):
        analysis = {
            "pack_id": "test",
            "pack_name": "Test",
            "old_version": "1.0",
            "current_version": "1.0",
            "timestamp": "2026-03-30T00:00:00Z",
            "summary": {
                "total_gaps": 0,
                "blocking_gaps": 0,
                "new_obligations": 0,
                "removed_obligations": 0,
                "strengthened_rules": 0,
                "relaxed_rules": 0,
                "unchanged_rules": 5,
            },
            "new_obligations": [],
            "removed_obligations": [],
            "strengthened_rules": [],
            "relaxed_rules": [],
        }
        report = format_gap_report(analysis)
        assert "Total gaps:        0" in report
        assert "NEW OBLIGATIONS" not in report
