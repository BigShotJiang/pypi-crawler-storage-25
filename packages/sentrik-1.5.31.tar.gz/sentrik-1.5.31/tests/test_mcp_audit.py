"""Tests for MCP security auditing."""

import json
from pathlib import Path

from guard.core.mcp_audit import audit_mcp_config, MCPAuditResult


class TestMCPAuditBasic:
    def test_no_configs_found(self, tmp_path):
        result = audit_mcp_config(config_paths=[tmp_path / "nonexistent.json"])
        assert result.servers_scanned == 0
        assert result.findings == []
        assert result.passed

    def test_empty_config(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text("{}")
        result = audit_mcp_config(config_paths=[cfg])
        assert result.servers_scanned == 1
        assert result.passed

    def test_safe_server(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "sentrik": {
                    "command": "sentrik",
                    "args": ["mcp-server"],
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert result.servers_scanned == 1
        assert result.passed


class TestDangerousCommands:
    def test_raw_shell_command(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "danger": {"command": "bash", "args": ["-c", "echo hello"]}
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert not result.passed
        assert result.critical_count >= 1
        assert any(f.category == "shell_exec" for f in result.findings)

    def test_powershell_command(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "ps": {"command": "powershell", "args": []}
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert result.critical_count >= 1


class TestCredentialExposure:
    def test_hardcoded_api_key(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "api-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "env": {"API_KEY": "sk-1234567890abcdef"}
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert any(f.category == "credential_exposure" for f in result.findings)

    def test_env_var_reference_is_safe(self, tmp_path):
        """Env vars that start with $ are references, not hardcoded."""
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "api-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "env": {"API_KEY": "${OPENAI_API_KEY}"}
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert not any(f.category == "credential_exposure" for f in result.findings)


class TestExcessiveScope:
    def test_root_filesystem_scope(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "files": {
                    "command": "mcp-filesystem",
                    "args": ["/"]
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert any(f.category == "excessive_scope" for f in result.findings)


class TestToolAudit:
    def test_dangerous_tool_no_restrictions(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "code-runner": {
                    "command": "node",
                    "args": ["server.js"],
                    "tools": [
                        {
                            "name": "execute_command",
                            "description": "Run a shell command",
                            "inputSchema": {"type": "object", "properties": {"cmd": {"type": "string"}}}
                        }
                    ]
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        assert any(f.category == "shell_exec" for f in result.findings)

    def test_restricted_tool_passes(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text(json.dumps({
            "mcpServers": {
                "safe": {
                    "command": "node",
                    "args": ["server.js"],
                    "tools": [
                        {
                            "name": "run_query",
                            "description": "Execute a database query",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "query_type": {"type": "string", "enum": ["select", "count"]}
                                }
                            }
                        }
                    ]
                }
            }
        }))
        result = audit_mcp_config(config_paths=[cfg])
        # Should not flag because the tool has enum restrictions
        assert not any(f.category == "database" for f in result.findings)


class TestResultSerialization:
    def test_to_dict(self, tmp_path):
        result = MCPAuditResult(servers_scanned=1, tools_scanned=3)
        d = result.to_dict()
        assert d["passed"] is True
        assert d["servers_scanned"] == 1
        assert d["tools_scanned"] == 3
        assert "by_severity" in d
        assert "findings" in d

    def test_invalid_json_config(self, tmp_path):
        cfg = tmp_path / ".mcp.json"
        cfg.write_text("not valid json{{{")
        result = audit_mcp_config(config_paths=[cfg])
        assert any(f.category == "config_error" for f in result.findings)
