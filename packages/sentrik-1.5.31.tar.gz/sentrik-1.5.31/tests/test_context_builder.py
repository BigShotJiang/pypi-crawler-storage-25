"""Tests for build_agent_context()."""

from __future__ import annotations

from tests.helpers import FakeDevOps, FakeStandards
from guard.config import GuardConfig
from guard.core.context_builder import build_agent_context
from guard.core.models import AgentContext, WorkItem


# ===================================================================
# build_agent_context
# ===================================================================


class TestBuildAgentContext:
    def test_returns_agent_context_type(self):
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert isinstance(ctx, AgentContext)

    def test_repo_root_set(self):
        ctx = build_agent_context("/my/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert ctx.repo_root == "/my/repo"

    def test_all_command_keys_present(self):
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        expected_keys = {"scan", "gate", "apply_patches", "reconcile", "report", "compare", "list_rules", "validate_config"}
        assert set(ctx.commands.keys()) == expected_keys

    def test_work_items_from_devops(self):
        items = [WorkItem(id="WI-1", title="Task 1")]
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(items), FakeStandards())
        assert len(ctx.work_items) == 1
        assert ctx.work_items[0].id == "WI-1"

    def test_rule_ids_from_standards(self):
        ctx = build_agent_context(
            "/repo", GuardConfig(), FakeDevOps(),
            FakeStandards(rule_ids=["R1", "R2"]),
        )
        assert ctx.standards_rule_ids == ["R1", "R2"]

    def test_definition_of_done_required_rules_matches_standards(self):
        ctx = build_agent_context(
            "/repo", GuardConfig(), FakeDevOps(),
            FakeStandards(rule_ids=["R1", "R2"]),
        )
        assert ctx.definition_of_done.required_rules == ["R1", "R2"]
        assert ctx.definition_of_done.gate_must_pass is True

    def test_empty_providers(self):
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert ctx.work_items == []
        assert ctx.standards_rule_ids == []
        assert ctx.definition_of_done.required_rules == []

    def test_serialization_round_trip(self):
        ctx = build_agent_context(
            "/repo", GuardConfig(),
            FakeDevOps([WorkItem(id="WI-1", title="T")]),
            FakeStandards(rule_ids=["R1"]),
        )
        data = ctx.model_dump()
        restored = AgentContext(**data)
        assert restored == ctx

    def test_scan_command_value(self):
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert ctx.commands["scan"] == "guard scan"

    def test_gate_command_value(self):
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(), FakeStandards())
        assert ctx.commands["gate"] == "guard gate"

    def test_multiple_work_items(self):
        items = [
            WorkItem(id="WI-1", title="First"),
            WorkItem(id="WI-2", title="Second"),
            WorkItem(id="WI-3", title="Third"),
        ]
        ctx = build_agent_context("/repo", GuardConfig(), FakeDevOps(items), FakeStandards())
        assert len(ctx.work_items) == 3

    def test_multiple_rule_ids(self):
        ctx = build_agent_context(
            "/repo", GuardConfig(), FakeDevOps(),
            FakeStandards(rule_ids=["R1", "R2", "R3"]),
        )
        assert len(ctx.standards_rule_ids) == 3
        assert len(ctx.definition_of_done.required_rules) == 3
