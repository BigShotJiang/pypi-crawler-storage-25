"""Tests for list_files() and find_repo_root()."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from tests.helpers import write_file
from guard.core.repo_reader import _expand_braces, find_repo_root, get_git_repo_name, list_files


# ===================================================================
# list_files
# ===================================================================


class TestListFiles:
    def test_default_glob_returns_all_files(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        write_file(tmp_path, "b.txt", "y")
        result = list_files(tmp_path)
        names = {Path(p).name for p in result}
        assert "a.py" in names
        assert "b.txt" in names

    def test_py_glob_filters(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        write_file(tmp_path, "b.txt", "y")
        result = list_files(tmp_path, "**/*.py")
        names = {Path(p).name for p in result}
        assert "a.py" in names
        assert "b.txt" not in names

    def test_nested_dirs(self, tmp_path):
        write_file(tmp_path, "src/core/main.py", "x")
        result = list_files(tmp_path, "**/*.py")
        # Normalize separators for cross-platform
        normalized = [p.replace("\\", "/") for p in result]
        assert any("src/core/main.py" in p for p in normalized)

    def test_empty_dir(self, tmp_path):
        result = list_files(tmp_path)
        assert result == []

    def test_relative_paths(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        result = list_files(tmp_path)
        for p in result:
            assert not Path(p).is_absolute()

    def test_excludes_directories(self, tmp_path):
        write_file(tmp_path, "dir/file.py", "x")
        result = list_files(tmp_path)
        # Should only have files, not the directory itself
        for p in result:
            assert (tmp_path / p).is_file()

    def test_single_level_glob(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        write_file(tmp_path, "sub/b.py", "y")
        result = list_files(tmp_path, "*.py")
        names = {Path(p).name for p in result}
        assert "a.py" in names
        assert "b.py" not in names

    def test_nonexistent_dir(self):
        result = list_files(Path("/tmp/nonexistent_xyz_test_dir_12345"))
        assert result == []

    def test_brace_expansion_matches_multiple_extensions(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        write_file(tmp_path, "b.js", "y")
        write_file(tmp_path, "c.ts", "z")
        write_file(tmp_path, "d.txt", "w")
        result = list_files(tmp_path, "**/*.{py,js,ts}")
        names = {Path(p).name for p in result}
        assert names == {"a.py", "b.js", "c.ts"}

    def test_brace_expansion_nested_dirs(self, tmp_path):
        write_file(tmp_path, "src/main.cpp", "x")
        write_file(tmp_path, "include/header.h", "y")
        write_file(tmp_path, "src/util.hpp", "z")
        write_file(tmp_path, "readme.md", "w")
        result = list_files(tmp_path, "**/*.{cpp,c,h,hpp}")
        names = {Path(p).name for p in result}
        assert names == {"main.cpp", "header.h", "util.hpp"}

    def test_brace_expansion_no_duplicates(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        result = list_files(tmp_path, "**/*.{py,py}")
        assert len(result) == 1

    def test_no_braces_unchanged(self, tmp_path):
        write_file(tmp_path, "a.py", "x")
        write_file(tmp_path, "b.js", "y")
        result = list_files(tmp_path, "**/*.py")
        names = {Path(p).name for p in result}
        assert names == {"a.py"}


class TestExpandBraces:
    def test_simple(self):
        assert _expand_braces("**/*.{py,js}") == ["**/*.py", "**/*.js"]

    def test_no_braces(self):
        assert _expand_braces("**/*.py") == ["**/*.py"]

    def test_multiple_alternatives(self):
        assert _expand_braces("**/*.{a,b,c,d}") == ["**/*.a", "**/*.b", "**/*.c", "**/*.d"]

    def test_wildcard_all(self):
        assert _expand_braces("**/*") == ["**/*"]


# ===================================================================
# find_repo_root
# ===================================================================


class TestFindRepoRoot:
    def test_returns_git_root_in_repo(self, tmp_path):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = str(tmp_path) + "\n"
            root = find_repo_root(tmp_path)
            assert root == tmp_path

    def test_falls_back_to_cwd(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 128
            mock_sub.run.return_value.stdout = ""
            root = find_repo_root()
            assert root == Path.cwd()

    def test_custom_start_path(self, tmp_path):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 128
            mock_sub.run.return_value.stdout = ""
            root = find_repo_root(tmp_path)
            assert root == tmp_path

    def test_git_not_installed(self, tmp_path):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.side_effect = FileNotFoundError
            root = find_repo_root(tmp_path)
            assert root == tmp_path

    def test_returns_path_type(self, tmp_path):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = str(tmp_path) + "\n"
            root = find_repo_root(tmp_path)
            assert isinstance(root, Path)

    def test_none_start_uses_cwd(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 128
            mock_sub.run.return_value.stdout = ""
            root = find_repo_root(None)
            assert root == Path.cwd()


class TestGetGitRepoName:
    def test_https_url(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "https://github.com/acme/my-repo.git\n"
            assert get_git_repo_name() == "my-repo"

    def test_ssh_url(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "git@github.com:acme/my-repo.git\n"
            assert get_git_repo_name() == "my-repo"

    def test_https_no_git_suffix(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "https://dev.azure.com/org/project\n"
            assert get_git_repo_name() == "project"

    def test_no_remote(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 128
            mock_sub.run.return_value.stdout = ""
            assert get_git_repo_name() is None

    def test_git_not_installed(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.side_effect = FileNotFoundError
            assert get_git_repo_name() is None

    def test_trailing_slash_stripped(self):
        with patch("guard.core.repo_reader.subprocess") as mock_sub:
            mock_sub.run.return_value.returncode = 0
            mock_sub.run.return_value.stdout = "https://github.com/acme/my-repo.git/\n"
            assert get_git_repo_name() == "my-repo"
