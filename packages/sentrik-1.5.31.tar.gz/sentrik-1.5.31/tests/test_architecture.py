"""Tests for architecture rules enforcement (dependency violation detection)."""

from __future__ import annotations

import json
import os
import textwrap
from pathlib import Path

import pytest

from guard.core.architecture import (
    ArchReport,
    ArchRule,
    ArchViolation,
    _matches_any_glob,
    _slugify,
    check_architecture,
    extract_imports,
    generate_template,
    load_arch_rules,
    violations_to_findings,
)
from guard.core.models import Finding, Severity


# ---------------------------------------------------------------------------
# extract_imports — Python
# ---------------------------------------------------------------------------


class TestExtractImportsPython:
    def test_import_statement(self):
        content = "import os\nimport sys\n"
        result = extract_imports("app.py", content)
        assert ("os", 1) in result
        assert ("sys", 2) in result

    def test_from_import_statement(self):
        content = "from pathlib import Path\nfrom os.path import join\n"
        result = extract_imports("app.py", content)
        assert ("pathlib", 1) in result
        assert ("os/path", 2) in result

    def test_dotted_import(self):
        content = "import guard.core.models\n"
        result = extract_imports("app.py", content)
        assert ("guard/core/models", 1) in result

    def test_mixed_imports(self):
        content = "import os\nfrom guard.core import models\nprint('hello')\nimport json\n"
        result = extract_imports("app.py", content)
        assert len(result) == 3
        paths = [p for p, _ in result]
        assert "os" in paths
        assert "guard/core" in paths
        assert "json" in paths

    def test_indented_import_in_function(self):
        content = "def foo():\n    import os\n"
        result = extract_imports("app.py", content)
        assert ("os", 2) in result


# ---------------------------------------------------------------------------
# extract_imports — C/C++
# ---------------------------------------------------------------------------


class TestExtractImportsCpp:
    def test_include_quotes(self):
        content = '#include "drivers/motor.h"\n'
        result = extract_imports("main.c", content)
        assert ("drivers/motor.h", 1) in result

    def test_include_angle_brackets(self):
        content = "#include <stdio.h>\n"
        result = extract_imports("main.c", content)
        assert ("stdio.h", 1) in result

    def test_multiple_includes(self):
        content = '#include <stdio.h>\n#include "mylib/utils.h"\n#include "config.h"\n'
        result = extract_imports("main.cpp", content)
        assert len(result) == 3
        assert ("stdio.h", 1) in result
        assert ("mylib/utils.h", 2) in result
        assert ("config.h", 3) in result

    def test_header_file(self):
        content = '#include "base.h"\n'
        result = extract_imports("module.h", content)
        assert ("base.h", 1) in result


# ---------------------------------------------------------------------------
# extract_imports — JavaScript / TypeScript
# ---------------------------------------------------------------------------


class TestExtractImportsJavaScript:
    def test_es6_import(self):
        content = "import { foo } from './utils/helper';\n"
        result = extract_imports("app.js", content)
        assert ("./utils/helper", 1) in result

    def test_default_import(self):
        content = "import React from 'react';\n"
        result = extract_imports("app.tsx", content)
        assert ("react", 1) in result

    def test_require(self):
        content = "const fs = require('fs');\n"
        result = extract_imports("app.js", content)
        assert ("fs", 1) in result

    def test_plain_import(self):
        content = "import './styles.css';\n"
        result = extract_imports("app.js", content)
        assert ("./styles.css", 1) in result

    def test_typescript(self):
        content = "import { Component } from '@angular/core';\nimport type { Config } from './config';\n"
        result = extract_imports("app.ts", content)
        paths = [p for p, _ in result]
        assert "@angular/core" in paths
        assert "./config" in paths


# ---------------------------------------------------------------------------
# extract_imports — Go
# ---------------------------------------------------------------------------


class TestExtractImportsGo:
    def test_single_import(self):
        content = 'import "fmt"\n'
        result = extract_imports("main.go", content)
        assert ("fmt", 1) in result

    def test_grouped_imports(self):
        content = 'import (\n\t"fmt"\n\t"os"\n)\n'
        result = extract_imports("main.go", content)
        paths = [p for p, _ in result]
        assert "fmt" in paths
        assert "os" in paths

    def test_aliased_import(self):
        content = 'package main\n\nimport (\n\tpb "github.com/org/proto"\n)\n'
        result = extract_imports("main.go", content)
        paths = [p for p, _ in result]
        assert "github.com/org/proto" in paths


# ---------------------------------------------------------------------------
# extract_imports — Unknown language
# ---------------------------------------------------------------------------


class TestExtractImportsUnknown:
    def test_unsupported_extension(self):
        result = extract_imports("file.rs", "use std::io;\n")
        assert result == []


# ---------------------------------------------------------------------------
# check_architecture — violation detection
# ---------------------------------------------------------------------------


class TestCheckArchitecture:
    def test_violation_detected(self, tmp_path):
        """Import matches must_not_import → violation created."""
        ui_dir = tmp_path / "src" / "ui"
        ui_dir.mkdir(parents=True)
        (ui_dir / "app.py").write_text("from src.drivers.motor import Motor\n", encoding="utf-8")

        drivers_dir = tmp_path / "src" / "drivers"
        drivers_dir.mkdir(parents=True)
        (drivers_dir / "motor.py").write_text("class Motor: pass\n", encoding="utf-8")

        rule = ArchRule(
            name="UI no drivers",
            from_pattern="src/ui/**",
            must_not_import=["src/drivers/**"],
            severity="high",
        )

        report = check_architecture([rule], str(tmp_path))
        assert len(report.violations) == 1
        assert report.violations[0].rule_name == "UI no drivers"
        assert report.violations[0].severity == "high"

    def test_no_violation(self, tmp_path):
        """Valid import not matching must_not_import → no violation."""
        ui_dir = tmp_path / "src" / "ui"
        ui_dir.mkdir(parents=True)
        (ui_dir / "app.py").write_text("import os\n", encoding="utf-8")

        rule = ArchRule(
            name="UI no drivers",
            from_pattern="src/ui/**",
            must_not_import=["src/drivers/**"],
        )

        report = check_architecture([rule], str(tmp_path))
        assert len(report.violations) == 0

    def test_from_pattern_filtering(self, tmp_path):
        """Only files matching from_pattern are checked."""
        # File in src/api/ should NOT be checked by a rule targeting src/ui/**
        api_dir = tmp_path / "src" / "api"
        api_dir.mkdir(parents=True)
        (api_dir / "handler.py").write_text("from src.drivers.motor import Motor\n", encoding="utf-8")

        rule = ArchRule(
            name="UI no drivers",
            from_pattern="src/ui/**",
            must_not_import=["src/drivers/**"],
        )

        report = check_architecture([rule], str(tmp_path))
        assert len(report.violations) == 0

    def test_multiple_rules(self, tmp_path):
        """Multiple architecture rules each produce independent violations."""
        ui_dir = tmp_path / "src" / "ui"
        ui_dir.mkdir(parents=True)
        (ui_dir / "view.py").write_text("from src.drivers.gpio import pin\n", encoding="utf-8")

        tests_dir = tmp_path / "tests"
        tests_dir.mkdir(parents=True)
        (tests_dir / "test_app.py").write_text("from src.config.secrets.vault import get_secret\n", encoding="utf-8")

        rules = [
            ArchRule(
                name="UI no drivers",
                from_pattern="src/ui/**",
                must_not_import=["src/drivers/**"],
                severity="high",
            ),
            ArchRule(
                name="Tests no secrets",
                from_pattern="tests/**",
                must_not_import=["src/config/secrets/**"],
                severity="critical",
            ),
        ]

        report = check_architecture(rules, str(tmp_path))
        assert len(report.violations) == 2
        rule_names = {v.rule_name for v in report.violations}
        assert "UI no drivers" in rule_names
        assert "Tests no secrets" in rule_names

    def test_report_counts(self, tmp_path):
        """files_analyzed and rules_checked are correct."""
        ui_dir = tmp_path / "src" / "ui"
        ui_dir.mkdir(parents=True)
        (ui_dir / "a.py").write_text("import os\n", encoding="utf-8")
        (ui_dir / "b.py").write_text("import sys\n", encoding="utf-8")

        rules = [
            ArchRule(name="R1", from_pattern="src/ui/**", must_not_import=["src/x/**"]),
            ArchRule(name="R2", from_pattern="src/ui/**", must_not_import=["src/y/**"]),
        ]

        report = check_architecture(rules, str(tmp_path))
        assert report.rules_checked == 2
        assert report.files_analyzed == 2

    def test_explicit_files_list(self, tmp_path):
        """Passing explicit files limits which files are checked."""
        ui_dir = tmp_path / "src" / "ui"
        ui_dir.mkdir(parents=True)
        (ui_dir / "a.py").write_text("from src.drivers.x import y\n", encoding="utf-8")
        (ui_dir / "b.py").write_text("from src.drivers.x import y\n", encoding="utf-8")

        rule = ArchRule(
            name="UI no drivers",
            from_pattern="src/ui/**",
            must_not_import=["src/drivers/**"],
        )

        report = check_architecture([rule], str(tmp_path), files=["src/ui/a.py"])
        assert len(report.violations) == 1
        assert report.violations[0].source_file == "src/ui/a.py"


# ---------------------------------------------------------------------------
# load_arch_rules — YAML parsing
# ---------------------------------------------------------------------------


class TestLoadArchRules:
    def test_valid_yaml(self, tmp_path):
        yaml_content = textwrap.dedent("""\
            architecture_rules:
              - name: "No cross-layer"
                from: "src/ui/**"
                must_not_import:
                  - "src/db/**"
                severity: high
                description: "UI must not access DB directly"
        """)
        cfg = tmp_path / "architecture.yaml"
        cfg.write_text(yaml_content, encoding="utf-8")

        rules = load_arch_rules(str(cfg))
        assert len(rules) == 1
        assert rules[0].name == "No cross-layer"
        assert rules[0].from_pattern == "src/ui/**"
        assert rules[0].must_not_import == ["src/db/**"]
        assert rules[0].severity == "high"
        assert rules[0].description == "UI must not access DB directly"

    def test_missing_file(self, tmp_path):
        rules = load_arch_rules(str(tmp_path / "nonexistent.yaml"))
        assert rules == []

    def test_incomplete_rule_skipped(self, tmp_path):
        yaml_content = textwrap.dedent("""\
            architecture_rules:
              - name: "Incomplete"
                from: "src/**"
        """)
        cfg = tmp_path / "arch.yaml"
        cfg.write_text(yaml_content, encoding="utf-8")

        rules = load_arch_rules(str(cfg))
        assert rules == []

    def test_default_search_sentrik_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        sentrik_dir = tmp_path / ".sentrik"
        sentrik_dir.mkdir()
        yaml_content = textwrap.dedent("""\
            architecture_rules:
              - name: "R1"
                from: "src/**"
                must_not_import: ["lib/**"]
        """)
        (sentrik_dir / "architecture.yaml").write_text(yaml_content, encoding="utf-8")

        rules = load_arch_rules()
        assert len(rules) == 1
        assert rules[0].name == "R1"

    def test_default_search_repo_root(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        yaml_content = textwrap.dedent("""\
            architecture_rules:
              - name: "R2"
                from: "app/**"
                must_not_import: ["vendor/**"]
        """)
        (tmp_path / "architecture.yaml").write_text(yaml_content, encoding="utf-8")

        rules = load_arch_rules()
        assert len(rules) == 1
        assert rules[0].name == "R2"


# ---------------------------------------------------------------------------
# violations_to_findings
# ---------------------------------------------------------------------------


class TestViolationsToFindings:
    def test_correct_finding_fields(self):
        v = ArchViolation(
            rule_name="UI no drivers",
            source_file="src/ui/app.py",
            imported_module="src/drivers/motor",
            line=5,
            severity="high",
        )
        findings = violations_to_findings([v])
        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "ARCH-ui-no-drivers"
        assert f.severity == Severity.HIGH
        assert f.standard == "Architecture"
        assert f.confidence == 1.0
        assert f.deterministic is True
        assert "src/ui/app.py" in f.finding_id
        assert f.evidence.file == "src/ui/app.py"
        assert f.evidence.lines == [5]
        assert "src/drivers/motor" in f.message

    def test_empty_list(self):
        assert violations_to_findings([]) == []

    def test_critical_severity(self):
        v = ArchViolation(
            rule_name="No secrets",
            source_file="tests/test.py",
            imported_module="config/secrets/vault",
            line=1,
            severity="critical",
        )
        findings = violations_to_findings([v])
        assert findings[0].severity == Severity.CRITICAL


# ---------------------------------------------------------------------------
# generate_template (--init)
# ---------------------------------------------------------------------------


class TestGenerateTemplate:
    def test_creates_file(self, tmp_path):
        out = generate_template(tmp_path / "arch.yaml")
        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert "architecture_rules:" in content
        assert "must_not_import:" in content

    def test_default_location(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        out = generate_template()
        assert out == Path(".sentrik") / "architecture.yaml"
        assert out.exists()


# ---------------------------------------------------------------------------
# Relative import resolution
# ---------------------------------------------------------------------------


class TestRelativeImportResolution:
    def test_relative_import_resolved(self, tmp_path):
        """Relative imports (from . import X) resolve to correct path."""
        pkg_dir = tmp_path / "src" / "ui"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "view.py").write_text("from .drivers_bridge import connect\n", encoding="utf-8")

        # Even though the import is relative, it should NOT match src/drivers/**
        # because .drivers_bridge resolves to src/ui/drivers_bridge, not src/drivers/
        rule = ArchRule(
            name="UI no drivers",
            from_pattern="src/ui/**",
            must_not_import=["src/drivers/**"],
        )

        report = check_architecture([rule], str(tmp_path))
        # The relative import ".drivers_bridge" in src/ui/view.py resolves to
        # something like src/ui/drivers_bridge which does NOT match src/drivers/**
        assert len(report.violations) == 0


# ---------------------------------------------------------------------------
# CLI JSON output
# ---------------------------------------------------------------------------


class TestCliCheckArchJson:
    def test_json_output_structure(self, tmp_path):
        """Verify the JSON output from check_architecture can be serialized correctly."""
        rule = ArchRule(
            name="R1",
            from_pattern="src/**",
            must_not_import=["lib/**"],
        )
        report = check_architecture([rule], str(tmp_path))

        # Simulate the JSON output the CLI would produce
        data = {
            "rules_checked": report.rules_checked,
            "files_analyzed": report.files_analyzed,
            "violations_count": len(report.violations),
            "violations": [
                {
                    "rule_name": v.rule_name,
                    "source_file": v.source_file,
                    "imported_module": v.imported_module,
                    "line": v.line,
                    "severity": v.severity,
                }
                for v in report.violations
            ],
        }

        serialized = json.dumps(data)
        parsed = json.loads(serialized)
        assert parsed["rules_checked"] == 1
        assert parsed["files_analyzed"] == 0
        assert parsed["violations_count"] == 0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class TestHelpers:
    def test_slugify(self):
        assert _slugify("UI must not access hardware drivers") == "ui-must-not-access-hardware-drivers"
        assert _slugify("No-Secrets!") == "no-secrets"

    def test_matches_any_glob_direct(self):
        assert _matches_any_glob("src/drivers/motor.py", ["src/drivers/**"])
        assert not _matches_any_glob("src/ui/app.py", ["src/drivers/**"])

    def test_matches_any_glob_prefix(self):
        assert _matches_any_glob("src/drivers/sub/deep.py", ["src/drivers/**"])
