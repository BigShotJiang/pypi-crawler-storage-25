"""Tests for Phase 2 auto-remediation: PR creation for vulnerability fixes."""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch, call

import pytest

from guard.core.vuln_fixer import FixAction, FixReport
from guard.core.vuln_pr import (
    _generate_pr_body,
    _get_default_branch,
    _run_git,
    create_fix_pr,
)
from guard.core.vuln_scanner import Vulnerability


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_fix_report(applied: bool = True) -> FixReport:
    actions = [
        FixAction(
            package="requests",
            current_version="2.25.0",
            fixed_version="2.32.0",
            manifest_file="requirements.txt",
            applied=applied,
        ),
        FixAction(
            package="flask",
            current_version="2.0.0",
            fixed_version="2.3.3",
            manifest_file="requirements.txt",
            applied=applied,
        ),
    ]
    return FixReport(actions=actions)


def _make_vulns() -> list[Vulnerability]:
    return [
        Vulnerability(
            id="GHSA-xxx-001",
            summary="Request smuggling",
            severity="high",
            affected_package="requests",
            affected_version="2.25.0",
            fixed_version="2.32.0",
        ),
        Vulnerability(
            id="PYSEC-2023-100",
            summary="Another requests vuln",
            severity="medium",
            affected_package="requests",
            affected_version="2.25.0",
            fixed_version="2.32.0",
        ),
        Vulnerability(
            id="GHSA-yyy-002",
            summary="Flask SSTI",
            severity="critical",
            affected_package="flask",
            affected_version="2.0.0",
            fixed_version="2.3.3",
        ),
    ]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestGeneratePrBody:
    """Test _generate_pr_body produces correct markdown."""

    def test_basic_table(self):
        report = _make_fix_report()
        body = _generate_pr_body(report.actions)
        assert "## Vulnerable Dependencies Updated" in body
        assert "| requests | 2.25.0 | 2.32.0 |" in body
        assert "| flask | 2.0.0 | 2.3.3 |" in body
        assert "SENTRIK" in body

    def test_with_cves(self):
        report = _make_fix_report()
        vulns = _make_vulns()
        body = _generate_pr_body(report.actions, vulns)
        # requests has 2 CVEs
        assert "GHSA-xxx-001" in body
        assert "PYSEC-2023-100" in body
        # flask has 1 CVE
        assert "GHSA-yyy-002" in body

    def test_skipped_actions_excluded(self):
        actions = [
            FixAction(
                package="requests",
                current_version="2.25.0",
                fixed_version="2.32.0",
                manifest_file="requirements.txt",
                applied=True,
            ),
            FixAction(
                package="flask",
                current_version="2.0.0",
                fixed_version="2.3.3",
                manifest_file="requirements.txt",
                applied=False,
                error="Not found",
            ),
        ]
        body = _generate_pr_body(actions)
        assert "requests" in body
        assert "flask" not in body


class TestCreateBranch:
    """Test that git checkout -b is called correctly."""

    @patch("guard.core.vuln_pr.subprocess.run")
    def test_creates_branch(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        _run_git(["checkout", "-b", "sentrik/fix-vulns-20260320"], "/repo")
        mock_run.assert_called_once_with(
            ["git", "checkout", "-b", "sentrik/fix-vulns-20260320"],
            capture_output=True,
            text=True,
            cwd="/repo",
        )

    @patch("guard.core.vuln_pr.subprocess.run")
    def test_raises_on_failure(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=1, stdout="", stderr="branch already exists"
        )
        with pytest.raises(RuntimeError, match="branch already exists"):
            _run_git(["checkout", "-b", "sentrik/fix-vulns-20260320"], "/repo")


class TestCommitChanges:
    """Test that git add + commit are called."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    @patch("guard.core.vuln_pr._create_pr_via_provider", return_value={})
    def test_stages_and_commits(self, _mock_pr, _mock_branch, mock_git):
        report = _make_fix_report()
        config = MagicMock()

        create_fix_pr(report, config, "/repo", devops_provider=MagicMock())

        # Verify git add was called for the manifest
        add_calls = [c for c in mock_git.call_args_list if c[0][0][0] == "add"]
        assert len(add_calls) == 1  # deduplicated: both actions use same file
        assert add_calls[0] == call(["add", "requirements.txt"], "/repo")

        # Verify git commit was called
        commit_calls = [c for c in mock_git.call_args_list if c[0][0][0] == "commit"]
        assert len(commit_calls) == 1
        commit_msg = commit_calls[0][0][0][2]  # args[0][2] = -m value
        assert "update 2 vulnerable dependencies" in commit_msg


class TestPushBranch:
    """Test that git push is called."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    @patch("guard.core.vuln_pr._create_pr_via_provider", return_value={})
    def test_pushes_branch(self, _mock_pr, _mock_branch, mock_git):
        report = _make_fix_report()
        config = MagicMock()

        create_fix_pr(report, config, "/repo", devops_provider=MagicMock())

        push_calls = [c for c in mock_git.call_args_list if c[0][0][0] == "push"]
        assert len(push_calls) == 1
        push_args = push_calls[0][0][0]
        assert push_args[0] == "push"
        assert push_args[1] == "-u"
        assert push_args[2] == "origin"
        assert push_args[3].startswith("sentrik/fix-vulns-")


class TestCreatePrAzure:
    """Test PR creation via Azure DevOps provider."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    def test_azure_pr_called(self, _mock_branch, mock_git):
        report = _make_fix_report()
        config = MagicMock()
        provider = MagicMock()
        provider.create_pull_request.return_value = {
            "pr_id": 42,
            "pr_url": "https://dev.azure.com/org/proj/_git/repo/pullrequest/42",
        }

        result = create_fix_pr(
            report, config, "/repo",
            vulns=_make_vulns(),
            devops_provider=provider,
        )

        provider.create_pull_request.assert_called_once()
        call_args = provider.create_pull_request.call_args
        assert "fix: Update 2 vulnerable dependencies" == call_args[0][0]
        assert call_args[0][2].startswith("sentrik/fix-vulns-")
        assert call_args[0][3] == "main"
        assert result["pr_id"] == 42
        assert result["pr_url"] == "https://dev.azure.com/org/proj/_git/repo/pullrequest/42"


class TestCreatePrGitHub:
    """Test PR creation via GitHub provider."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    def test_github_pr_called(self, _mock_branch, mock_git):
        report = _make_fix_report()
        config = MagicMock()
        provider = MagicMock()
        provider.create_pull_request.return_value = {
            "pr_id": 7,
            "pr_url": "https://github.com/owner/repo/pull/7",
        }

        result = create_fix_pr(
            report, config, "/repo",
            devops_provider=provider,
        )

        provider.create_pull_request.assert_called_once()
        assert result["pr_id"] == 7
        assert result["pr_url"] == "https://github.com/owner/repo/pull/7"
        assert result["changes_count"] == 2


class TestCliFixCreatePr:
    """Test CLI end-to-end flow with mocked dependencies."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    @patch("guard.core.vuln_pr._create_pr_via_provider", return_value={"pr_url": "https://example.com/pr/1", "pr_id": 1})
    def test_create_fix_pr_returns_result(self, _mock_pr, _mock_branch, mock_git):
        report = _make_fix_report()
        config = MagicMock()

        result = create_fix_pr(report, config, "/repo", devops_provider=MagicMock())

        assert result["branch"].startswith("sentrik/fix-vulns-")
        assert result["changes_count"] == 2
        assert result["pr_url"] == "https://example.com/pr/1"

    def test_no_applied_fixes_raises(self):
        report = _make_fix_report(applied=False)
        config = MagicMock()

        with pytest.raises(ValueError, match="No applied fixes"):
            create_fix_pr(report, config, "/repo", devops_provider=MagicMock())


class TestCreatePrRequiresFix:
    """Test that --create-pr without --fix errors."""

    def test_create_pr_without_fix_exits(self):
        """Verify the CLI rejects --create-pr without --fix."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["vulns", "--create-pr"])
        assert result.exit_code != 0
        assert "--create-pr requires --fix" in result.output


class TestCreatePrRequiresProvider:
    """Test that --create-pr with stub provider errors."""

    @patch("guard.core.vuln_pr._run_git")
    def test_stub_provider_rejected(self, mock_git):
        """CLI rejects --create-pr when devops_provider is stub."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["vulns", "--fix", "--create-pr"])
        # Default provider is "stub", so this should fail
        assert result.exit_code != 0
        assert "requires a DevOps provider" in result.output


class TestGetDefaultBranch:
    """Test default branch detection."""

    @patch("guard.core.vuln_pr.subprocess.run")
    def test_detects_main_from_symbolic_ref(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0, stdout="refs/remotes/origin/main", stderr=""
        )
        assert _get_default_branch("/repo") == "main"

    @patch("guard.core.vuln_pr.subprocess.run")
    def test_falls_back_to_master(self, mock_run):
        # Both commands fail
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="error")
        assert _get_default_branch("/repo") == "master"


class TestSingleDependencyGrammar:
    """Test singular grammar when only one dependency is fixed."""

    @patch("guard.core.vuln_pr._run_git")
    @patch("guard.core.vuln_pr._get_default_branch", return_value="main")
    def test_singular_title(self, _mock_branch, mock_git):
        actions = [
            FixAction(
                package="requests",
                current_version="2.25.0",
                fixed_version="2.32.0",
                manifest_file="requirements.txt",
                applied=True,
            ),
        ]
        report = FixReport(actions=actions)
        config = MagicMock()
        provider = MagicMock()
        provider.create_pull_request.return_value = {"pr_id": 1, "pr_url": "http://x"}

        create_fix_pr(report, config, "/repo", devops_provider=provider)

        title = provider.create_pull_request.call_args[0][0]
        assert "dependency" in title
        assert "dependencies" not in title
