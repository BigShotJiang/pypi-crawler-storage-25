"""Tests for the FastAPI REST API server (Phase 18)."""

from __future__ import annotations

import json
import os
from datetime import date, timedelta
from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient

from guard.core.licensing import generate_key
from guard.server import app, _check_api_key

# Generate a valid ENTERPRISE key for tests that hit licensed endpoints
_ENTERPRISE_KEY = generate_key("ENTERPRISE", date.today() + timedelta(days=365))


@pytest.fixture
def client():
    """Create a test client without API key auth."""
    with patch.dict(os.environ, {}, clear=False):
        # Ensure GUARD_API_KEY is not set
        os.environ.pop("GUARD_API_KEY", None)
        # Reset the module-level _API_KEY
        import guard.server as srv
        srv._API_KEY = None
        yield TestClient(app)


@pytest.fixture
def auth_client():
    """Create a test client with API key auth enabled."""
    import guard.server as srv
    srv._API_KEY = "test-key-123"
    yield TestClient(app)
    srv._API_KEY = None


# ===================================================================
# Health endpoint
# ===================================================================


class TestHealthEndpoint:
    def test_health_returns_ok(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_health_no_auth_required(self, auth_client):
        resp = auth_client.get("/health")
        assert resp.status_code == 200


# ===================================================================
# Scan endpoint
# ===================================================================


class TestScanEndpoint:
    def test_scan_inline_files(self, client):
        resp = client.post("/scan", json={
            "files": {
                "app.py": "x = eval(input())\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "findings" in data
        assert "total" in data
        assert isinstance(data["findings"], list)

    def test_scan_empty_files(self, client):
        resp = client.post("/scan", json={
            "files": {
                "clean.py": '"""Module docstring."""\nx = 1\n',
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data["total"], int)

    def test_scan_with_changed_files(self, client):
        resp = client.post("/scan", json={
            "files": {
                "a.py": "x = 1\n",
                "b.py": "y = 2\n",
            },
            "changed_files": ["a.py"],
        })
        assert resp.status_code == 200

    def test_scan_by_severity(self, client):
        resp = client.post("/scan", json={
            "files": {
                "bad.py": "# TODO fix this\nprint('hello')\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "by_severity" in data
        assert isinstance(data["by_severity"], dict)

    def test_scan_no_body(self, client):
        resp = client.post("/scan", json={})
        assert resp.status_code == 200


# ===================================================================
# Gate endpoint
# ===================================================================


class TestGateEndpoint:
    def test_gate_passes_clean_code(self, client):
        resp = client.post("/gate", json={
            "files": {
                "clean.py": '"""Clean module."""\nx = 1\n',
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "passed" in data
        assert isinstance(data["passed"], bool)
        assert "total_findings" in data

    def test_gate_response_has_severity_counts(self, client):
        resp = client.post("/gate", json={
            "files": {
                "app.py": "x = 1\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        for key in ("critical", "high", "medium", "low", "info"):
            assert key in data


# ===================================================================
# Report endpoint
# ===================================================================


class TestReportEndpoint:
    def test_report_html(self, client):
        resp = client.post("/report?format=html", json={
            "files": {
                "app.py": "x = 1\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "html"
        assert "<html" in data["content"] or "No findings" in data["content"]

    def test_report_junit(self, client):
        resp = client.post("/report?format=junit", json={
            "files": {
                "app.py": "x = 1\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "junit"
        assert "<?xml" in data["content"]

    def test_report_sarif(self, client):
        resp = client.post("/report?format=sarif", json={
            "files": {
                "app.py": "x = 1\n",
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "sarif"

    def test_report_unknown_format(self, client):
        resp = client.post("/report?format=pdf", json={
            "files": {"app.py": "x = 1\n"},
        })
        assert resp.status_code == 400
        assert "Unknown report format" in resp.json()["detail"]

    def test_report_default_format(self, client):
        resp = client.post("/report", json={
            "files": {"app.py": "x = 1\n"},
        })
        assert resp.status_code == 200
        assert resp.json()["format"] == "html"


# ===================================================================
# Rules endpoint
# ===================================================================


class TestRulesEndpoint:
    def test_list_rules(self, client):
        resp = client.get("/rules")
        assert resp.status_code == 200
        data = resp.json()
        assert "rules" in data
        assert "total" in data
        assert data["total"] > 0
        assert isinstance(data["rules"], list)

    def test_rules_have_required_fields(self, client):
        resp = client.get("/rules")
        data = resp.json()
        for rule in data["rules"]:
            assert "id" in rule
            assert "name" in rule
            assert "type" in rule
            assert "severity" in rule


# ===================================================================
# Authentication
# ===================================================================


class TestAuthentication:
    def test_scan_requires_key_when_enabled(self, auth_client):
        resp = auth_client.post("/scan", json={"files": {"a.py": "x=1\n"}})
        assert resp.status_code == 401

    def test_scan_with_valid_key(self, auth_client):
        resp = auth_client.post(
            "/scan",
            json={"files": {"a.py": "x=1\n"}},
            headers={"X-API-Key": "test-key-123"},
        )
        assert resp.status_code == 200

    def test_scan_with_wrong_key(self, auth_client):
        resp = auth_client.post(
            "/scan",
            json={"files": {"a.py": "x=1\n"}},
            headers={"X-API-Key": "wrong-key"},
        )
        assert resp.status_code == 401

    def test_gate_requires_key(self, auth_client):
        resp = auth_client.post("/gate", json={"files": {"a.py": "x=1\n"}})
        assert resp.status_code == 401

    def test_report_requires_key(self, auth_client):
        resp = auth_client.post("/report", json={"files": {"a.py": "x=1\n"}})
        assert resp.status_code == 401

    def test_rules_requires_key(self, auth_client):
        resp = auth_client.get("/rules")
        assert resp.status_code == 401

    def test_health_no_key_needed(self, auth_client):
        resp = auth_client.get("/health")
        assert resp.status_code == 200

    def test_metrics_requires_key(self, auth_client):
        resp = auth_client.get("/api/metrics")
        assert resp.status_code == 401


# ===================================================================
# Dashboard endpoint
# ===================================================================


class TestDashboardEndpoint:
    def test_dashboard_returns_html(self, client):
        resp = client.get("/dashboard")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "SENTRIK" in resp.text

    def test_dashboard_no_auth_required(self, auth_client):
        resp = auth_client.get("/dashboard")
        assert resp.status_code == 200


# ===================================================================
# Metrics endpoint
# ===================================================================


class TestMetricsEndpoint:
    def test_metrics_returns_json(self, client):
        resp = client.get("/api/metrics")
        assert resp.status_code == 200
        data = resp.json()
        assert "scan_metrics" in data
        assert "findings_count" in data
        assert "findings_by_file" in data

    def test_metrics_no_scan_data(self, client, tmp_path, monkeypatch):
        # Point output to empty dir
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "empty"))
        resp = client.get("/api/metrics")
        assert resp.status_code == 200
        data = resp.json()
        assert data["scan_metrics"] is None
        assert data["findings_count"] == 0


# ===================================================================
# Config API endpoints
# ===================================================================


class TestConfigEndpoint:
    def test_get_config(self, client):
        resp = client.get("/api/config")
        assert resp.status_code == 200
        data = resp.json()
        assert "output_dir" in data
        assert "provider" in data

    def test_get_config_requires_auth(self, auth_client):
        resp = auth_client.get("/api/config")
        assert resp.status_code == 401

    def test_update_config(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Create initial config
        from guard.config import GuardConfig
        GuardConfig().save()
        resp = client.post("/api/config", json={"updates": {"output_dir": "custom_out"}})
        assert resp.status_code == 200
        data = resp.json()
        assert data["config"]["output_dir"] == "custom_out"


# ===================================================================
# Governance API endpoint
# ===================================================================


class TestGovernanceEndpoint:
    def test_get_governance(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        resp = client.get("/api/governance")
        assert resp.status_code == 200
        data = resp.json()
        assert "profile" in data
        assert "valid_profiles" in data
        assert "human_review_required" in data
        assert "auto_patch" in data
        assert "gate" in data
        assert "sync" in data
        assert "audit" in data

    def test_default_profile_is_standard(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        resp = client.get("/api/governance")
        data = resp.json()
        assert data["profile"] == "standard"

    def test_governance_requires_enterprise_license(self, client, monkeypatch):
        """Governance endpoint requires enterprise license — FREE tier gets 403."""
        monkeypatch.setenv("GUARD_LICENSE_KEY", "")
        resp = client.get("/api/governance")
        # FREE tier does not have governance feature
        assert resp.status_code in (200, 403)  # 200 if config has valid key, 403 otherwise


# ===================================================================
# Audit API endpoint
# ===================================================================


class TestAuditEndpoint:
    def test_get_audit_empty(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        resp = client.get("/api/audit")
        assert resp.status_code == 200
        data = resp.json()
        assert "entries" in data
        assert isinstance(data["entries"], list)

    def test_get_audit_with_limit(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        resp = client.get("/api/audit?limit=5")
        assert resp.status_code == 200

    def test_audit_requires_license(self, client):
        """Audit endpoint requires a license."""
        resp = client.get("/api/audit")
        assert resp.status_code == 403


# ===================================================================
# Packs API endpoint
# ===================================================================


class TestPacksEndpoint:
    def test_get_packs(self, client):
        resp = client.get("/api/packs")
        assert resp.status_code == 200
        data = resp.json()
        assert "packs" in data
        assert "total" in data
        assert data["total"] >= 3  # fda, owasp, soc2

    def test_packs_have_fields(self, client):
        resp = client.get("/api/packs")
        data = resp.json()
        for p in data["packs"]:
            assert "pack_id" in p
            assert "name" in p
            assert "rule_count" in p
            assert "enabled" in p


# ===================================================================
# Findings API endpoint
# ===================================================================


class TestFindingsEndpoint:
    def test_get_findings_empty(self, client, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "empty"))
        resp = client.get("/api/findings")
        assert resp.status_code == 200
        data = resp.json()
        assert data["findings"] == []
        assert data["total"] == 0

    def test_get_findings_with_data(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        findings = [
            {
                "finding_id": "f1", "rule_id": "R001", "severity": "high",
                "message": "Test finding", "confidence": 1.0,
                "evidence": {"file": "a.py", "line": 1, "snippet": "x"},
            },
            {
                "finding_id": "f2", "rule_id": "R002", "severity": "low",
                "message": "Low finding", "confidence": 1.0,
                "evidence": {"file": "b.py", "line": 2, "snippet": "y"},
            },
        ]
        (out / "findings.json").write_text(json.dumps(findings))
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/findings")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["findings"]) == 2

    def test_get_findings_filter_severity(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        findings = [
            {
                "finding_id": "f1", "rule_id": "R001", "severity": "high",
                "message": "High", "confidence": 1.0,
                "evidence": {"file": "a.py", "line": 1, "snippet": "x"},
            },
            {
                "finding_id": "f2", "rule_id": "R002", "severity": "low",
                "message": "Low", "confidence": 1.0,
                "evidence": {"file": "b.py", "line": 2, "snippet": "y"},
            },
        ]
        (out / "findings.json").write_text(json.dumps(findings))
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/findings?severity=high")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["findings"][0]["rule_id"] == "R001"


# ===================================================================
# Report generate endpoint
# ===================================================================


class TestReportGenerateEndpoint:
    def test_generate_html_report(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate?format=html")
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "html"
        assert "content" in data
        assert data["findings_count"] == 0

    def test_generate_junit_report(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate?format=junit")
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "junit"

    def test_generate_sarif_report(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate?format=sarif")
        assert resp.status_code == 200
        assert resp.json()["format"] == "sarif"

    def test_generate_unknown_format(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate?format=pdf")
        assert resp.status_code == 400
        assert "Unknown format" in resp.json()["detail"]

    def test_generate_default_format(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate")
        assert resp.status_code == 200
        assert resp.json()["format"] == "html"


# ===================================================================
# Run scan endpoint
# ===================================================================


class TestRunScanEndpoint:
    def test_run_scan(self, client):
        resp = client.post("/api/run-scan")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert "total_findings" in data
        assert "gate_passed" in data
        assert "by_severity" in data
        assert "output_dir" in data

    def test_run_scan_requires_auth(self, auth_client):
        resp = auth_client.post("/api/run-scan")
        assert resp.status_code == 401


# ===================================================================
# Run gate endpoint
# ===================================================================


class TestRunGateEndpoint:
    def test_run_gate(self, client):
        resp = client.post("/api/run-gate")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert "gate_passed" in data
        assert "total_findings" in data
        for key in ("critical", "high", "medium", "low", "info"):
            assert key in data

    def test_run_gate_requires_auth(self, auth_client):
        resp = auth_client.post("/api/run-gate")
        assert resp.status_code == 401


# ===================================================================
# Packs toggle endpoint
# ===================================================================


class TestPackRulesEndpoint:
    def test_get_pack_rules_builtin(self, client):
        resp = client.get("/api/packs/fda-iec-62304/rules")
        assert resp.status_code == 200
        data = resp.json()
        assert data["pack_id"] == "fda-iec-62304"
        assert "rules" in data
        assert isinstance(data["rules"], list)
        assert len(data["rules"]) > 0
        assert "overrides" in data
        assert isinstance(data["overrides"], dict)

    def test_get_pack_rules_has_rule_fields(self, client):
        resp = client.get("/api/packs/fda-iec-62304/rules")
        data = resp.json()
        for rule in data["rules"]:
            assert "id" in rule
            assert "name" in rule
            assert "type" in rule

    def test_get_pack_rules_unknown_pack(self, client):
        resp = client.get("/api/packs/nonexistent-pack/rules")
        assert resp.status_code == 404

    def test_get_pack_rules_with_overrides(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        GuardConfig(pack_overrides={"fda-iec-62304": {"IEC62304-CODE-001": {"severity": "low"}}}).save()
        resp = client.get("/api/packs/fda-iec-62304/rules")
        assert resp.status_code == 200
        data = resp.json()
        assert data["overrides"]["IEC62304-CODE-001"]["severity"] == "low"

    def test_get_pack_rules_requires_auth(self, auth_client):
        resp = auth_client.get("/api/packs/fda-iec-62304/rules")
        assert resp.status_code == 401


class TestPacksToggleEndpoint:
    def test_toggle_pack_enable(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        GuardConfig().save()
        resp = client.post("/api/packs/toggle", json={"pack_id": "owasp-top-10", "enabled": True})
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "owasp-top-10" in data["standards_packs"]

    def test_toggle_pack_disable(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        cfg = GuardConfig(standards_packs=["owasp-top-10"])
        cfg.save()
        resp = client.post("/api/packs/toggle", json={"pack_id": "owasp-top-10", "enabled": False})
        assert resp.status_code == 200
        data = resp.json()
        assert "owasp-top-10" not in data["standards_packs"]

    def test_toggle_pack_idempotent_enable(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        cfg = GuardConfig(standards_packs=["owasp-top-10"])
        cfg.save()
        resp = client.post("/api/packs/toggle", json={"pack_id": "owasp-top-10", "enabled": True})
        assert resp.status_code == 200
        # Should not duplicate
        assert resp.json()["standards_packs"].count("owasp-top-10") == 1

    def test_toggle_pack_requires_auth(self, auth_client):
        resp = auth_client.post("/api/packs/toggle", json={"pack_id": "x", "enabled": True})
        assert resp.status_code == 401


# ===================================================================
# DevOps Status endpoint
# ===================================================================


class TestDevOpsStatusEndpoint:
    def test_default_stub(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        resp = client.get("/api/devops/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["provider"] == "stub"
        assert data["configured"] is False
        assert data["env_vars"] == {}
        assert data["config_summary"] == {}

    def test_github_configured(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "github")
        monkeypatch.setenv("GUARD_GITHUB_OWNER", "myorg")
        monkeypatch.setenv("GUARD_GITHUB_REPO", "myrepo")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_fake")
        resp = client.get("/api/devops/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["provider"] == "github"
        assert data["configured"] is True
        assert data["config_summary"]["owner"] == "myorg"
        assert data["env_vars"]["GITHUB_TOKEN"] is True

    def test_requires_auth(self, auth_client):
        resp = auth_client.get("/api/devops/status")
        assert resp.status_code == 401


# ===================================================================
# DevOps Test Connection endpoint
# ===================================================================


class TestDevOpsTestConnectionEndpoint:
    def test_stub_succeeds(self, client):
        resp = client.post("/api/devops/test-connection", json={
            "devops_provider": "stub",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["provider"] == "stub"

    def test_invalid_provider(self, client):
        resp = client.post("/api/devops/test-connection", json={
            "devops_provider": "invalid-provider",
        })
        assert resp.status_code == 400
        assert "Invalid provider" in resp.json()["detail"]

    def test_requires_auth(self, auth_client):
        resp = auth_client.post("/api/devops/test-connection", json={
            "devops_provider": "stub",
        })
        assert resp.status_code == 401


# ===================================================================
# Work Items endpoint
# ===================================================================


class TestWorkItemsEndpoint:
    def test_stub_returns_work_items(self, client, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        # Create a work_items.json with test data
        wi_data = [
            {"id": "WI-1", "title": "Fix bug", "state": "active", "rule_id": "R001"},
            {"id": "WI-2", "title": "Add feature", "state": "closed", "rule_id": "R002"},
        ]
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text(json.dumps(wi_data))
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        resp = client.get("/api/work-items")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert data["provider"] == "stub"
        assert len(data["work_items"]) == 2
        # Each work item should have linked_findings_count
        for wi in data["work_items"]:
            assert "linked_findings_count" in wi

    def test_response_structure(self, client, monkeypatch):
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        resp = client.get("/api/work-items")
        assert resp.status_code == 200
        data = resp.json()
        assert "work_items" in data
        assert "total" in data
        assert "provider" in data

    def test_requires_auth(self, auth_client):
        resp = auth_client.get("/api/work-items")
        assert resp.status_code == 401


# ===================================================================
# Reconcile endpoint
# ===================================================================


class TestReconcileEndpoint:
    def test_dry_run_no_findings(self, client, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "empty"))
        resp = client.post("/api/reconcile?dry_run=true")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "no_findings"
        assert data["actions"] == []

    def test_dry_run_with_findings(self, client, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        out = tmp_path / "out"
        out.mkdir()
        findings = [
            {
                "finding_id": "f1", "rule_id": "R001", "severity": "high",
                "message": "Test finding", "confidence": 1.0, "deterministic": True,
                "evidence": {"file": "a.py", "lines": [1], "snippet": "x"},
            },
        ]
        (out / "findings.json").write_text(json.dumps(findings))
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.post("/api/reconcile?dry_run=true")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "dry_run"
        assert len(data["actions"]) > 0
        assert data["actions"][0]["action"] == "create"
        assert data["result"] is None

    def test_blocked_with_expired_license(self, client, monkeypatch):
        """Expired license should get 403 on reconcile endpoint."""
        expired_key = generate_key("TEAM", date.today() - timedelta(days=1))
        monkeypatch.setenv("GUARD_LICENSE_KEY", expired_key)
        resp = client.post("/api/reconcile?dry_run=true")
        assert resp.status_code == 403

    def test_requires_auth(self, auth_client, monkeypatch):
        monkeypatch.setenv("GUARD_LICENSE_KEY", _ENTERPRISE_KEY)
        resp = auth_client.post("/api/reconcile?dry_run=true")
        assert resp.status_code == 401


# ===================================================================
# Dashboard DevOps content
# ===================================================================


class TestDashboardDevOpsContent:
    def test_has_devops_tab(self, client):
        resp = client.get("/dashboard")
        assert 'data-tab="devops"' in resp.text

    def test_has_workitems_tab(self, client):
        resp = client.get("/dashboard")
        assert 'data-tab="workitems"' in resp.text

    def test_has_devops_status_indicator(self, client):
        resp = client.get("/dashboard")
        assert "devops-status-indicator" in resp.text

    def test_has_reconcile_button(self, client):
        resp = client.get("/dashboard")
        assert "btn-reconcile" in resp.text


# ===================================================================
# Run context endpoint
# ===================================================================


class TestRunContextEndpoint:
    def test_run_context(self, client):
        resp = client.post("/api/run-context")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert "work_items_count" in data
        assert isinstance(data["work_items_count"], int)

    def test_run_context_requires_auth(self, auth_client):
        resp = auth_client.post("/api/run-context")
        assert resp.status_code == 401


# ===================================================================
# Dashboard Run Context button
# ===================================================================


class TestDashboardContextButton:
    def test_has_context_button(self, client):
        resp = client.get("/dashboard")
        assert 'id="btn-context"' in resp.text

    def test_has_run_context_function(self, client):
        resp = client.get("/dashboard")
        assert "runContext()" in resp.text


# ===================================================================
# Dashboard audit log enhancements
# ===================================================================


class TestDashboardAuditEnhancements:
    def test_has_audit_details_css(self, client):
        resp = client.get("/dashboard")
        assert "audit-details" in resp.text

    def test_has_toggle_audit_detail_function(self, client):
        resp = client.get("/dashboard")
        assert "toggleAuditDetail" in resp.text

    def test_has_audit_chevron_css(self, client):
        resp = client.get("/dashboard")
        assert "audit-chevron" in resp.text


# ===================================================================
# Requirement coverage endpoint & dashboard
# ===================================================================


class TestCheckCoverageEndpoint:
    def test_check_coverage_returns_expected_fields(self, client, tmp_path, monkeypatch):
        """POST /api/check-coverage?force=true returns 200 with expected fields."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        # Create a minimal work_items.json
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text(json.dumps([
            {"id": "WI-1", "title": "Implement auth login handler", "state": "active"},
        ]))
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        # Create a source file so the directory walk finds something
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "login_handler.py").write_text("pass")
        resp = client.post("/api/check-coverage?force=true")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert "untracked_count" in data
        assert "untracked_files" in data
        assert "findings" in data
        assert isinstance(data["untracked_files"], list)

    def test_check_coverage_disabled_without_force(self, client, tmp_path, monkeypatch):
        """POST /api/check-coverage without force should fail when disabled."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text("[]")
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        resp = client.post("/api/check-coverage")
        assert resp.status_code == 400


class TestDashboardCoverageElements:
    def test_dashboard_has_check_coverage_button(self, client):
        resp = client.get("/dashboard")
        assert "Check Coverage" in resp.text

    def test_dashboard_has_check_coverage_function(self, client):
        resp = client.get("/dashboard")
        assert "checkCoverage" in resp.text


class TestGenerateReqsEndpoint:
    def test_generate_reqs_dry_run(self, client, tmp_path, monkeypatch):
        """POST /api/generate-reqs?dry_run=true returns preview."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text("[]")
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        # Create a source file that won't be covered
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "app.py").write_text("def main(): pass")
        resp = client.post("/api/generate-reqs?dry_run=true")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] in ("preview", "completed")
        assert "requirements" in data
        assert "requirements_count" in data
        assert "untracked_count" in data
        assert data["requirements_count"] >= 0

    def test_generate_reqs_writes_yaml(self, client, tmp_path, monkeypatch):
        """POST /api/generate-reqs?push=false writes YAML file."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text("[]")
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "handler.py").write_text("class Handler: pass")
        resp = client.post("/api/generate-reqs?push=false")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        yaml_path = tmp_path / data["requirements_file"]
        assert yaml_path.exists()

    def test_generate_reqs_returns_expected_fields(self, client, tmp_path, monkeypatch):
        """Returns expected response fields including requirements_file."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("GUARD_DEVOPS_PROVIDER", "stub")
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text("[]")
        monkeypatch.setenv("GUARD_WORK_ITEMS_FILE", str(wi_file))
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "app.py").write_text("pass")
        resp = client.post("/api/generate-reqs?push=false")
        assert resp.status_code == 200
        data = resp.json()
        assert "status" in data
        assert "requirements" in data
        assert "requirements_file" in data
        assert "work_items_created" in data
        assert "untracked_count" in data
        assert "requirements_count" in data


class TestDashboardGenerateReqsElements:
    def test_dashboard_has_generate_requirements_button(self, client):
        resp = client.get("/dashboard")
        assert "Generate Requirements" in resp.text

    def test_dashboard_has_generate_requirements_function(self, client):
        resp = client.get("/dashboard")
        assert "generateRequirements" in resp.text

    def test_coverage_modal_has_generate_button(self, client):
        resp = client.get("/dashboard")
        assert "executeGenerateReqs" in resp.text


# ===================================================================
# Onboarding endpoint
# ===================================================================


class TestOnboardingEndpoint:
    def test_onboarding_status_returns_steps(self, client):
        resp = client.get("/api/onboarding-status")
        assert resp.status_code == 200
        data = resp.json()
        assert "steps" in data
        assert "health" in data
        assert "all_complete" in data
        assert "devops_configured" in data["steps"]
        assert "packs_enabled" in data["steps"]
        assert "scan_run" in data["steps"]

    def test_onboarding_health_has_fields(self, client):
        resp = client.get("/api/onboarding-status")
        assert resp.status_code == 200
        data = resp.json()
        health = data["health"]
        assert "config_loaded" in health
        assert "devops_provider" in health
        assert "rules_active_count" in health
        assert "findings_count" in health
        assert "packs_enabled_count" in health


# ===================================================================
# Dashboard onboarding elements
# ===================================================================


class TestDashboardOnboarding:
    def test_has_onboarding_panel(self, client):
        resp = client.get("/dashboard")
        assert "onboarding-panel" in resp.text

    def test_has_health_status_grid(self, client):
        resp = client.get("/dashboard")
        assert "health-status" in resp.text

    def test_has_onboarding_js_functions(self, client):
        resp = client.get("/dashboard")
        assert "loadOnboarding" in resp.text
        assert "dismissOnboarding" in resp.text

    def test_has_onboarding_css(self, client):
        resp = client.get("/dashboard")
        assert "onboarding-step" in resp.text
        assert "health-card" in resp.text


class TestSnippetEndpoint:
    def test_snippet_returns_lines(self, client, tmp_path, monkeypatch):
        # Create a source file in the CWD
        src = tmp_path / "example.py"
        src.write_text("line1\nline2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10\n")
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/snippet", params={"file": "example.py", "line": 5, "context": 2})
        assert resp.status_code == 200
        data = resp.json()
        assert "lines" in data
        assert len(data["lines"]) == 5  # lines 3-7
        # The highlighted line should be line 5
        highlighted = [l for l in data["lines"] if l["highlight"]]
        assert len(highlighted) == 1
        assert highlighted[0]["num"] == 5
        assert highlighted[0]["text"] == "line5"

    def test_snippet_missing_file(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/snippet", params={"file": "nonexistent.py", "line": 1})
        assert resp.status_code == 200
        data = resp.json()
        assert data["error"] == "File not found"

    def test_snippet_path_traversal_blocked(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        resp = client.get("/api/snippet", params={"file": "../../../etc/passwd", "line": 1})
        assert resp.status_code == 400


class TestDashboardSnippetUI:
    def test_has_snippet_css(self, client):
        resp = client.get("/dashboard")
        assert "snippet-line" in resp.text
        assert "snippet-line-num" in resp.text

    def test_has_fetch_snippet_js(self, client):
        resp = client.get("/dashboard")
        assert "fetchSnippet" in resp.text
        assert "renderSnippetLines" in resp.text
        assert "snippetCache" in resp.text
