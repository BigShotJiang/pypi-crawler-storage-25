"""Comprehensive tests for the rules engine (Phase 3)."""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

import pytest

from tests.helpers import write_file
from guard.core.models import Severity
from guard.rules.engine import RulesEngine


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_rule(
    rule_id: str = "TEST-001",
    name: str = "test-rule",
    rule_type: str = "regex",
    pattern: str | None = None,
    check: str | None = None,
    severity: str = "low",
    file_glob: str = "**/*.py",
    description: str = "Test rule.",
) -> dict:
    d: dict = {
        "id": rule_id,
        "name": name,
        "type": rule_type,
        "severity": severity,
        "file_glob": file_glob,
        "description": description,
    }
    if pattern is not None:
        d["pattern"] = pattern
    if check is not None:
        d["check"] = check
    return d


def _write(tmp_path: Path, rel: str, content: str) -> Path:
    return write_file(tmp_path, rel, content)


# ===================================================================
# Regex evaluation
# ===================================================================


class TestRegexEvaluation:
    def test_todo_comment_produces_finding(self, tmp_path):
        _write(tmp_path, "app.py", "# TODO fix this\nx = 1\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "TEST-001"
        assert f.severity == Severity.LOW
        assert f.evidence.file == "app.py"
        assert f.evidence.lines == [1]
        assert "TODO" in f.evidence.snippet

    def test_multiple_matches_produce_multiple_findings(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO one\n# TODO two\n# TODO three\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 3
        lines = sorted(f.evidence.lines[0] for f in findings)
        assert lines == [1, 2, 3]

    def test_file_glob_skips_non_matching_extensions(self, tmp_path):
        _write(tmp_path, "app.py", "# TODO\n")
        _write(tmp_path, "app.js", "// TODO\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b", file_glob="**/*.py")])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].evidence.file == "app.py"

    def test_no_matches_returns_empty(self, tmp_path):
        _write(tmp_path, "clean.py", "x = 1\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_invalid_regex_skips_rule(self, tmp_path):
        _write(tmp_path, "a.py", "anything\n")
        engine = RulesEngine([_make_rule(pattern=r"[invalid")])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_confidence_lower_in_comment(self, tmp_path):
        _write(tmp_path, "app.py", "# eval('x')\n")
        engine = RulesEngine([_make_rule(pattern=r"\beval\(")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].confidence == 0.5
        assert findings[0].deterministic is False

    def test_confidence_full_in_code(self, tmp_path):
        _write(tmp_path, "app.py", "result = eval('x')\n")
        engine = RulesEngine([_make_rule(pattern=r"\beval\(")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].confidence == 1.0
        assert findings[0].deterministic is True

    def test_confidence_lower_in_string_literal(self, tmp_path):
        _write(tmp_path, "app.py", '"""eval() is dangerous"""\n')
        engine = RulesEngine([_make_rule(pattern=r"\beval\(")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].confidence == 0.4

    def test_confidence_lower_in_test_file(self, tmp_path):
        _write(tmp_path, "test_app.py", "result = eval('x')\n")
        engine = RulesEngine([_make_rule(pattern=r"\beval\(")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].confidence == 0.7

    def test_confidence_comment_in_js_file(self, tmp_path):
        _write(tmp_path, "app.js", "// eval('x')\n")
        engine = RulesEngine([_make_rule(pattern=r"\beval\(", file_glob="**/*.js")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].confidence == 0.5


# ===================================================================
# File-policy evaluation
# ===================================================================


class TestFilePolicyEvaluation:
    def test_file_with_double_quote_docstring_passes(self, tmp_path):
        _write(tmp_path, "good.py", '"""Module docstring."""\nx = 1\n')
        engine = RulesEngine([
            _make_rule(rule_type="file_policy", check="starts_with_docstring"),
        ])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_file_with_single_quote_docstring_passes(self, tmp_path):
        _write(tmp_path, "good.py", "'''Module docstring.'''\nx = 1\n")
        engine = RulesEngine([
            _make_rule(rule_type="file_policy", check="starts_with_docstring"),
        ])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_bare_code_file_produces_finding(self, tmp_path):
        _write(tmp_path, "bad.py", "x = 1\n")
        engine = RulesEngine([
            _make_rule(rule_type="file_policy", check="starts_with_docstring"),
        ])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        assert findings[0].evidence.file == "bad.py"

    def test_empty_file_produces_finding(self, tmp_path):
        _write(tmp_path, "empty.py", "")
        engine = RulesEngine([
            _make_rule(rule_type="file_policy", check="starts_with_docstring"),
        ])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1

    def test_leading_blank_lines_before_docstring_passes(self, tmp_path):
        _write(tmp_path, "spaced.py", '\n\n"""Docstring."""\n')
        engine = RulesEngine([
            _make_rule(rule_type="file_policy", check="starts_with_docstring"),
        ])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []


# ===================================================================
# Scoping (changed_files)
# ===================================================================


class TestChangedFilesScoping:
    def test_only_evaluates_changed_files(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        _write(tmp_path, "b.py", "# TODO\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path), changed_files=["a.py"])

        assert len(findings) == 1
        assert findings[0].evidence.file == "a.py"

    def test_none_changed_files_evaluates_all(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        _write(tmp_path, "b.py", "# TODO\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path), changed_files=None)

        assert len(findings) == 2

    def test_empty_changed_files_evaluates_nothing(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path), changed_files=[])

        assert findings == []


# ===================================================================
# Integration
# ===================================================================


class TestIntegration:
    def test_multiple_rules_multiple_files(self, tmp_path):
        _write(tmp_path, "main.py", '# TODO: clean up\nprint("debug")\n')
        _write(tmp_path, "lib.py", '"""Good module."""\nx = 1\n')
        rules = [
            _make_rule(rule_id="R1", pattern=r"(?i)\bTODO\b", severity="low"),
            _make_rule(rule_id="R2", pattern=r"\bprint\s*\(", severity="medium"),
            _make_rule(
                rule_id="R3", rule_type="file_policy",
                check="starts_with_docstring", severity="low",
            ),
        ]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))

        rule_ids = {f.rule_id for f in findings}
        # main.py has TODO (R1), print (R2), no docstring (R3)
        # lib.py has docstring (R3 passes), no TODO, no print
        assert "R1" in rule_ids
        assert "R2" in rule_ids
        assert "R3" in rule_ids
        # R3 should fire for main.py only (lib.py has docstring)
        r3_findings = [f for f in findings if f.rule_id == "R3"]
        assert len(r3_findings) == 1
        assert r3_findings[0].evidence.file == "main.py"

    def test_sample_standards_style_rules(self, tmp_path):
        _write(
            tmp_path, "app.py",
            '# TODO fix\npassword = "supersecret"\nprint("hello")\n',
        )
        rules = [
            {
                "id": "STD-001", "name": "no-todo-comments",
                "type": "regex", "pattern": r"(?i)\bTODO\b",
                "severity": "low", "file_glob": "**/*.py",
            },
            {
                "id": "STD-002", "name": "no-print-statements",
                "type": "regex", "pattern": r"\bprint\s*\(",
                "severity": "medium", "file_glob": "**/*.py",
            },
            {
                "id": "STD-003", "name": "no-hardcoded-secrets",
                "type": "regex",
                "pattern": r'(?i)(password|api_key|secret)\s*=\s*["\'][^"\']{4,}',
                "severity": "critical", "file_glob": "**/*",
            },
        ]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))

        found_ids = {f.rule_id for f in findings}
        assert "STD-001" in found_ids
        assert "STD-002" in found_ids
        assert "STD-003" in found_ids


# ===================================================================
# Edge cases
# ===================================================================


class TestEdgeCases:
    def test_binary_file_skipped(self, tmp_path):
        # Write bytes that are not valid UTF-8
        bin_path = tmp_path / "data.py"
        bin_path.write_bytes(b"\x80\x81\x82\x83 TODO\n")
        engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    @pytest.mark.skipif(sys.platform == "win32", reason="chmod not effective on Windows")
    def test_unreadable_file_skipped(self, tmp_path):
        p = _write(tmp_path, "secret.py", "# TODO\n")
        p.chmod(0o000)
        try:
            engine = RulesEngine([_make_rule(pattern=r"(?i)\bTODO\b")])
            findings = engine.evaluate(str(tmp_path))
            assert findings == []
        finally:
            p.chmod(stat.S_IRUSR | stat.S_IWUSR)

    def test_empty_rules_returns_empty(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        engine = RulesEngine([])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_unknown_rule_type_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        engine = RulesEngine([_make_rule(rule_type="alien")])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_invalid_rule_dict_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "# TODO\n")
        engine = RulesEngine([{"bad": "data"}])
        findings = engine.evaluate(str(tmp_path))

        assert findings == []

    def test_nonexistent_repo_root(self):
        engine = RulesEngine([_make_rule(pattern=r"TODO")])
        findings = engine.evaluate("/tmp/nonexistent_path_xyz")

        assert findings == []


# ===================================================================
# Documentation obligation
# ===================================================================


class TestDocumentationObligation:
    def test_obligation_produces_one_finding(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        rule = {
            "id": "DOC-001", "name": "dev-plan",
            "description": "Must have a development plan",
            "type": "documentation_obligation",
            "severity": "info",
            "standard": "IEC 62304",
            "clause": "5.1.1",
            "compliance_category": "documentation",
            "remediation_guidance": "Create a development plan document",
            "tags": ["fda"],
        }
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.rule_id == "DOC-001"
        assert f.is_obligation is True
        assert f.evidence.file == "<project>"
        assert f.standard == "IEC 62304"
        assert f.clause == "5.1.1"
        assert f.compliance_category == "documentation"
        assert f.suggestion == "Create a development plan document"
        assert "fda" in f.tags

    def test_obligation_not_per_file(self, tmp_path):
        """Obligations produce exactly one finding regardless of files."""
        _write(tmp_path, "a.py", "x = 1\n")
        _write(tmp_path, "b.py", "y = 2\n")
        rule = {
            "id": "DOC-002", "name": "verify-plan",
            "type": "documentation_obligation",
            "severity": "info",
        }
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1

    def test_obligation_with_code_rules(self, tmp_path):
        """Obligations and code rules can coexist."""
        _write(tmp_path, "a.py", "# TODO fix\n")
        rules = [
            _make_rule(pattern=r"(?i)\bTODO\b"),
            {
                "id": "DOC-001", "name": "dev-plan",
                "type": "documentation_obligation",
                "severity": "info",
            },
        ]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))

        code_findings = [f for f in findings if not f.is_obligation]
        obligations = [f for f in findings if f.is_obligation]
        assert len(code_findings) == 1
        assert len(obligations) == 1


# ===================================================================
# Regulatory metadata propagation
# ===================================================================


class TestRegulatoryMetadata:
    def test_regex_propagates_metadata(self, tmp_path):
        _write(tmp_path, "app.py", "assert x > 0\n")
        rule = {
            "id": "R-META", "name": "no-assert",
            "type": "regex", "pattern": r"\bassert\b",
            "severity": "medium", "file_glob": "**/*.py",
            "standard": "IEC 62304", "clause": "5.5.5",
            "compliance_category": "code",
            "remediation_guidance": "Use explicit checks",
            "tags": ["fda"],
        }
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.standard == "IEC 62304"
        assert f.clause == "5.5.5"
        assert f.compliance_category == "code"
        assert f.suggestion == "Use explicit checks"
        assert "fda" in f.tags
        assert f.is_obligation is False

    def test_file_policy_propagates_metadata(self, tmp_path):
        _write(tmp_path, "bad.py", "x = 1\n")
        rule = {
            "id": "R-FP", "name": "need-docstring",
            "type": "file_policy", "check": "starts_with_docstring",
            "severity": "low", "file_glob": "**/*.py",
            "standard": "Custom", "clause": "1.0",
            "remediation_guidance": "Add a docstring",
        }
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))

        assert len(findings) == 1
        f = findings[0]
        assert f.standard == "Custom"
        assert f.clause == "1.0"
        assert f.suggestion == "Add a docstring"


# ===================================================================
# AST rule evaluation
# ===================================================================


def _make_ast_rule(
    rule_id: str = "AST-001",
    name: str = "ast-test-rule",
    ast_check: str = "no_mutable_defaults",
    severity: str = "high",
    file_glob: str = "**/*.py",
    **kwargs,
) -> dict:
    d = {
        "id": rule_id,
        "name": name,
        "type": "ast",
        "ast_check": ast_check,
        "severity": severity,
        "file_glob": file_glob,
    }
    d.update(kwargs)
    return d


class TestASTRuleEvaluation:
    def test_mutable_default_detected(self, tmp_path):
        _write(tmp_path, "bad.py", "def f(x=[]):\n    pass\n")
        engine = RulesEngine([_make_ast_rule()])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].rule_id == "AST-001"
        assert findings[0].severity == Severity.HIGH
        assert "Mutable default" in findings[0].message

    def test_clean_code_no_findings(self, tmp_path):
        _write(tmp_path, "clean.py", "def f(x=None):\n    pass\n")
        engine = RulesEngine([_make_ast_rule()])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_syntax_error_skipped(self, tmp_path):
        _write(tmp_path, "broken.py", "def f(\n")
        engine = RulesEngine([_make_ast_rule()])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_star_import_detected(self, tmp_path):
        _write(tmp_path, "wild.py", "from os import *\n")
        engine = RulesEngine([_make_ast_rule(ast_check="no_star_imports", severity="medium")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert "Wildcard import" in findings[0].message

    def test_high_complexity_detected(self, tmp_path):
        branches = "\n".join(f"    if x == {i}:\n        pass" for i in range(12))
        _write(tmp_path, "complex.py", f"def f(x):\n{branches}\n")
        engine = RulesEngine([_make_ast_rule(ast_check="high_complexity", severity="medium")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert "complexity" in findings[0].message.lower()

    def test_nested_functions_detected(self, tmp_path):
        _write(tmp_path, "nested.py", "def a():\n    def b():\n        def c():\n            pass\n")
        engine = RulesEngine([_make_ast_rule(ast_check="no_nested_functions", severity="low")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert "'c'" in findings[0].message

    def test_unknown_ast_check_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        engine = RulesEngine([_make_ast_rule(ast_check="nonexistent_check")])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_no_ast_check_skipped(self, tmp_path):
        _write(tmp_path, "a.py", "x = 1\n")
        rule = {"id": "AST-X", "name": "bad-rule", "type": "ast", "severity": "low"}
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_binary_file_skipped(self, tmp_path):
        p = tmp_path / "bad.py"
        p.write_bytes(b"\x80\x81\x82")
        engine = RulesEngine([_make_ast_rule()])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_file_glob_respected(self, tmp_path):
        _write(tmp_path, "bad.py", "def f(x=[]):\n    pass\n")
        _write(tmp_path, "ok.txt", "def f(x=[]):\n    pass\n")
        engine = RulesEngine([_make_ast_rule(file_glob="**/*.py")])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].evidence.file == "bad.py"

    def test_metadata_propagated(self, tmp_path):
        _write(tmp_path, "a.py", "def f(x=[]):\n    pass\n")
        rule = _make_ast_rule(
            standard="Custom Standard",
            clause="1.2.3",
            remediation_guidance="Fix it",
            tags=["quality"],
        )
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        f = findings[0]
        assert f.standard == "Custom Standard"
        assert f.clause == "1.2.3"
        assert f.suggestion == "Fix it"
        assert "quality" in f.tags

    def test_changed_files_scoping(self, tmp_path):
        _write(tmp_path, "a.py", "def f(x=[]):\n    pass\n")
        _write(tmp_path, "b.py", "def g(y=[]):\n    pass\n")
        engine = RulesEngine([_make_ast_rule()])
        findings = engine.evaluate(str(tmp_path), changed_files=["a.py"])
        assert len(findings) == 1
        assert findings[0].evidence.file == "a.py"

    def test_ast_and_regex_coexist(self, tmp_path):
        _write(tmp_path, "code.py", "def f(x=[]):\n    # TODO fix\n    pass\n")
        rules = [
            _make_ast_rule(),
            _make_rule(pattern=r"(?i)\bTODO\b"),
        ]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))
        ast_findings = [f for f in findings if f.rule_id == "AST-001"]
        regex_findings = [f for f in findings if f.rule_id == "TEST-001"]
        assert len(ast_findings) == 1
        assert len(regex_findings) == 1


# ===================================================================
# Requirement Verification Rule Type
# ===================================================================

def _make_req_verification_rule(**overrides) -> dict:
    d = {
        "id": "REQ-VERIFY-001",
        "name": "Requirement drift detection",
        "type": "requirement_verification",
        "severity": "low",
        "file_glob": "**/*",
        "description": "Verify requirements match actual code behavior",
        "params": {},
    }
    d.update(overrides)
    return d


class TestRequirementVerification:
    def test_no_requirements_file_returns_empty(self, tmp_path):
        """No requirements.yaml → no findings."""
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_empty_requirements_returns_empty(self, tmp_path):
        """requirements.yaml with no entries → no findings."""
        (tmp_path / "requirements.yaml").write_text(
            "requirements: []\n", encoding="utf-8"
        )
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_stub_detects_missing_file(self, tmp_path):
        """Stub verifier flags requirements pointing to missing files."""
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Auth module\n"
            "    description: Handles authentication\n"
            "    source_files: [src/auth.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert "no longer exists" in findings[0].message
        assert "requirement-drift" in findings[0].tags

    def test_stub_detects_empty_file(self, tmp_path):
        """Stub verifier flags requirements pointing to empty files."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "auth.py").write_text("", encoding="utf-8")
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Auth module\n"
            "    source_files: [src/auth.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert "empty" in findings[0].message

    def test_no_drift_when_files_exist(self, tmp_path):
        """No findings when all source files exist and are non-empty."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "auth.py").write_text("def login(): pass\n", encoding="utf-8")
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Auth module\n"
            "    source_files: [src/auth.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_skips_rejected_requirements(self, tmp_path):
        """Rejected requirements are not verified."""
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Rejected feature\n"
            "    source_files: [missing.py]\n"
            "    status: rejected\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule()
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert findings == []

    def test_severity_capped_to_rule_severity(self, tmp_path):
        """Findings with severity above the rule's configured severity are capped."""
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Auth module\n"
            "    source_files: [missing.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        # Stub returns "medium" for missing files — rule caps to "low"
        rule = _make_req_verification_rule(severity="low")
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        sev = findings[0].severity
        sev_str = sev.value if hasattr(sev, "value") else sev
        assert sev_str in ("low", "info")

    def test_custom_requirements_file_path(self, tmp_path):
        """params.requirements_file allows pointing to a different file."""
        (tmp_path / "my_reqs.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-001\n"
            "    title: Custom\n"
            "    source_files: [gone.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule(
            params={"requirements_file": "my_reqs.yaml"}
        )
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1

    def test_regulatory_metadata_propagated(self, tmp_path):
        """Rule metadata (standard, clause, tags) propagates to findings."""
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Auth module\n"
            "    source_files: [missing.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rule = _make_req_verification_rule(
            standard="IEC 62304",
            clause="5.5.1",
            tags=["traceability"],
        )
        engine = RulesEngine([rule])
        findings = engine.evaluate(str(tmp_path))
        assert len(findings) == 1
        assert findings[0].standard == "IEC 62304"
        assert findings[0].clause == "5.5.1"
        assert "traceability" in findings[0].tags

    def test_coexists_with_other_rule_types(self, tmp_path):
        """requirement_verification rules run alongside regex rules."""
        _write(tmp_path, "code.py", "# TODO fix this\n")
        (tmp_path / "requirements.yaml").write_text(
            "requirements:\n"
            "  - req_id: REQ-001\n"
            "    title: Module\n"
            "    source_files: [gone.py]\n"
            "    status: draft\n",
            encoding="utf-8",
        )
        rules = [
            _make_rule(pattern=r"(?i)\bTODO\b"),
            _make_req_verification_rule(),
        ]
        engine = RulesEngine(rules)
        findings = engine.evaluate(str(tmp_path))
        regex_findings = [f for f in findings if f.rule_id == "TEST-001"]
        drift_findings = [f for f in findings if "REQ-DRIFT" in f.rule_id]
        assert len(regex_findings) == 1
        assert len(drift_findings) == 1
