"""Tests for the change impact analysis feature."""

from __future__ import annotations

import json

import pytest

from guard.core.impact_analysis import (
    ImpactItem,
    ImpactReport,
    _file_matches_glob,
    analyze_impact,
    report_to_dict,
)
from guard.core.models import GeneratedRequirement


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _rule(
    rule_id: str = "R-001",
    severity: str = "low",
    file_glob: str = "**/*",
    standard: str | None = None,
) -> dict:
    return {
        "id": rule_id,
        "name": f"Rule {rule_id}",
        "type": "regex",
        "pattern": "TODO",
        "severity": severity,
        "file_glob": file_glob,
        "standard": standard,
    }


def _req(
    req_id: str = "REQ-001",
    source_files: list[str] | None = None,
) -> GeneratedRequirement:
    return GeneratedRequirement(
        req_id=req_id,
        title=f"Requirement {req_id}",
        source_files=source_files or [],
    )


# ---------------------------------------------------------------------------
# Tests — file_matches_glob
# ---------------------------------------------------------------------------


class TestFileMatchesGlob:
    def test_star_star_slash_star_py(self):
        assert _file_matches_glob("src/foo.py", "**/*.py") is True

    def test_star_star_no_match(self):
        assert _file_matches_glob("src/foo.cpp", "**/*.py") is False

    def test_nested_path(self):
        assert _file_matches_glob("src/deep/nested/file.cpp", "**/*.cpp") is True

    def test_simple_glob(self):
        assert _file_matches_glob("foo.py", "*.py") is True

    def test_specific_dir_glob(self):
        assert _file_matches_glob("src/main.cpp", "src/*.cpp") is True

    def test_specific_dir_no_match(self):
        assert _file_matches_glob("lib/main.cpp", "src/*.cpp") is False


# ---------------------------------------------------------------------------
# Tests — analyze_impact
# ---------------------------------------------------------------------------


class TestAnalyzeImpact:
    def test_no_changed_files(self):
        """Empty file list returns an empty report."""
        report = analyze_impact([], [_rule()])
        assert report.changed_files == []
        assert report.items == []
        assert report.total_rules_affected == 0
        assert report.total_requirements_affected == 0
        assert report.total_frameworks_affected == 0
        assert report.requires_revalidation is False

    def test_file_matches_rule_glob(self):
        """A changed .cpp file matches a **/*.cpp rule."""
        rules = [_rule(rule_id="CPP-001", file_glob="**/*.cpp", severity="medium")]
        report = analyze_impact(["src/patient_data.cpp"], rules)

        assert len(report.items) == 1
        assert "CPP-001" in report.items[0].rules
        assert report.total_rules_affected == 1

    def test_file_matches_requirement(self):
        """A changed file found in requirement source_files is flagged."""
        rules = [_rule()]
        reqs = [_req(req_id="REQ-GEN-001", source_files=["src/main.py"])]
        report = analyze_impact(["src/main.py"], rules, reqs)

        assert len(report.items) == 1
        assert "REQ-GEN-001" in report.items[0].requirements
        assert report.total_requirements_affected == 1

    def test_framework_from_rule(self):
        """Rule's standard field maps to a framework on the impact item."""
        rules = [_rule(standard="IEC 62304", file_glob="**/*.py")]
        report = analyze_impact(["src/device.py"], rules)

        assert len(report.items) == 1
        assert "IEC 62304" in report.items[0].frameworks
        assert report.total_frameworks_affected == 1

    def test_risk_level_high(self):
        """A file with a critical-severity rule gets high risk."""
        rules = [_rule(severity="critical", file_glob="**/*.py")]
        report = analyze_impact(["src/auth.py"], rules)

        assert report.items[0].risk_level == "high"

    def test_risk_level_high_from_high_severity(self):
        """A file with a high-severity rule also gets high risk."""
        rules = [_rule(severity="high", file_glob="**/*.py")]
        report = analyze_impact(["src/auth.py"], rules)

        assert report.items[0].risk_level == "high"

    def test_risk_level_medium(self):
        """A file with only medium-severity rules gets medium risk."""
        rules = [_rule(severity="medium", file_glob="**/*.py")]
        report = analyze_impact(["src/utils.py"], rules)

        assert report.items[0].risk_level == "medium"

    def test_risk_level_low(self):
        """A file with only low/info rules gets low risk."""
        rules = [_rule(severity="low", file_glob="**/*.py")]
        report = analyze_impact(["src/helpers.py"], rules)

        assert report.items[0].risk_level == "low"

    def test_requires_revalidation_true(self):
        """requires_revalidation is True when critical/high rules are affected."""
        rules = [_rule(severity="critical", file_glob="**/*.py")]
        report = analyze_impact(["src/main.py"], rules)

        assert report.requires_revalidation is True

    def test_no_revalidation_for_low_risk(self):
        """requires_revalidation is False when only low/medium rules apply."""
        rules = [_rule(severity="low", file_glob="**/*.py")]
        report = analyze_impact(["src/main.py"], rules)

        assert report.requires_revalidation is False

    def test_no_revalidation_for_medium_risk(self):
        """requires_revalidation is False for medium-only rules."""
        rules = [_rule(severity="medium", file_glob="**/*.py")]
        report = analyze_impact(["src/main.py"], rules)

        assert report.requires_revalidation is False

    def test_multiple_files(self):
        """Multiple changed files aggregate correctly across items."""
        rules = [
            _rule(rule_id="PY-001", severity="high", file_glob="**/*.py", standard="SOC2"),
            _rule(rule_id="CPP-001", severity="low", file_glob="**/*.cpp", standard="IEC 62304"),
        ]
        reqs = [
            _req(req_id="REQ-001", source_files=["src/main.py"]),
            _req(req_id="REQ-002", source_files=["src/device.cpp"]),
        ]
        report = analyze_impact(
            ["src/main.py", "src/device.cpp", "README.md"],
            rules,
            reqs,
        )

        assert len(report.items) == 3
        assert report.total_rules_affected == 2
        assert report.total_requirements_affected == 2
        assert report.total_frameworks_affected == 2
        assert report.requires_revalidation is True  # PY-001 is high

    def test_file_no_matching_rules(self):
        """A file that matches no rule globs gets empty rules and low risk."""
        rules = [_rule(file_glob="**/*.java")]
        report = analyze_impact(["src/main.py"], rules)

        assert len(report.items) == 1
        assert report.items[0].rules == []
        assert report.items[0].risk_level == "low"
        assert report.total_rules_affected == 0


# ---------------------------------------------------------------------------
# Tests — report_to_dict
# ---------------------------------------------------------------------------


class TestReportToDict:
    def test_report_to_dict_serializable(self):
        """report_to_dict returns a JSON-serializable dict."""
        rules = [_rule(severity="high", file_glob="**/*.py", standard="OWASP")]
        reqs = [_req(req_id="REQ-001", source_files=["src/main.py"])]
        report = analyze_impact(["src/main.py"], rules, reqs)

        d = report_to_dict(report)

        # Should be JSON serializable
        serialized = json.dumps(d)
        assert isinstance(serialized, str)

        # Verify structure
        assert d["changed_files"] == ["src/main.py"]
        assert len(d["items"]) == 1
        assert d["total_rules_affected"] == 1
        assert d["total_requirements_affected"] == 1
        assert d["total_frameworks_affected"] == 1
        assert d["requires_revalidation"] is True

    def test_empty_report_to_dict(self):
        """Empty report serialises correctly."""
        report = analyze_impact([], [])
        d = report_to_dict(report)

        assert d["changed_files"] == []
        assert d["items"] == []
        assert d["total_rules_affected"] == 0
        assert d["requires_revalidation"] is False


# ---------------------------------------------------------------------------
# Tests — CLI integration
# ---------------------------------------------------------------------------


class TestCLIImpact:
    def test_cli_impact_json(self):
        """CLI impact command with --json produces valid JSON."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        result = runner.invoke(app, ["impact", "--json", "--files", "nonexistent.py"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "changed_files" in data
        assert "items" in data
        assert "requires_revalidation" in data

    def test_cli_impact_no_files(self):
        """CLI impact with no changed files shows a warning."""
        from typer.testing import CliRunner
        from guard.cli import app

        runner = CliRunner()
        # --files with an explicit empty won't work, so use --staged which in
        # a non-git dir returns nothing
        result = runner.invoke(app, ["impact", "--staged"])
        # Should not crash
        assert result.exit_code == 0
