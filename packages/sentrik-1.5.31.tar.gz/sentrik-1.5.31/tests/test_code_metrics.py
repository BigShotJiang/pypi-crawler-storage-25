"""Tests for language-agnostic code metrics."""

from pathlib import Path

from guard.core.code_metrics import FileMetrics, analyze_file, analyze_directory


class TestAnalyzeFile:
    def test_python_file(self, tmp_path):
        f = tmp_path / "app.py"
        f.write_text("# comment\nimport os\n\ndef main():\n    print('hi')\n\ndef helper():\n    pass\n")
        m = analyze_file(f)
        assert m.total_lines == 8
        assert m.code_lines == 5  # import, def main, print, def helper, pass
        assert m.comment_lines == 1
        assert m.blank_lines == 2
        assert m.function_count == 2

    def test_javascript_file(self, tmp_path):
        f = tmp_path / "app.js"
        f.write_text("// init\nfunction main() {\n  console.log('hi');\n}\n")
        m = analyze_file(f)
        assert m.function_count >= 1
        assert m.comment_lines == 1
        assert m.max_nesting >= 1

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.py"
        f.write_text("")
        m = analyze_file(f)
        assert m.total_lines == 0
        assert m.code_lines == 0

    def test_nesting_depth_braces(self, tmp_path):
        f = tmp_path / "nested.js"
        f.write_text("function a() {\n  if (x) {\n    if (y) {\n      z();\n    }\n  }\n}\n")
        m = analyze_file(f)
        assert m.max_nesting >= 3

    def test_nesting_depth_python(self, tmp_path):
        f = tmp_path / "nested.py"
        f.write_text("def main():\n    if True:\n        for x in y:\n            print(x)\n")
        m = analyze_file(f)
        assert m.max_nesting >= 3

    def test_nonexistent_file(self):
        m = analyze_file("/nonexistent/file.py")
        assert m.total_lines == 0

    def test_go_functions(self, tmp_path):
        f = tmp_path / "main.go"
        f.write_text("package main\n\nfunc main() {\n}\n\nfunc helper() {\n}\n")
        m = analyze_file(f)
        assert m.function_count == 2

    def test_rust_functions(self, tmp_path):
        f = tmp_path / "main.rs"
        f.write_text("fn main() {\n}\n\npub fn helper() {\n}\n")
        m = analyze_file(f)
        assert m.function_count == 2


class TestAnalyzeDirectory:
    def test_finds_files(self, tmp_path):
        (tmp_path / "a.py").write_text("x = 1\ny = 2\n")
        (tmp_path / "b.js").write_text("const x = 1;\n")
        results = analyze_directory(tmp_path)
        assert len(results) >= 2

    def test_sorted_by_code_lines(self, tmp_path):
        (tmp_path / "small.py").write_text("x = 1\n")
        (tmp_path / "big.py").write_text("\n".join(f"line_{i} = {i}" for i in range(100)))
        results = analyze_directory(tmp_path)
        assert results[0].code_lines >= results[-1].code_lines

    def test_filters_by_file_paths(self, tmp_path):
        (tmp_path / "a.py").write_text("x = 1\n")
        (tmp_path / "b.py").write_text("y = 2\n")
        results = analyze_directory(tmp_path, file_paths=["a.py"])
        assert len(results) == 1
        assert "a.py" in results[0].file

    def test_skips_hidden_dirs(self, tmp_path):
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "secret.py").write_text("x = 1\n")
        (tmp_path / "visible.py").write_text("y = 2\n")
        results = analyze_directory(tmp_path)
        files = [m.file for m in results]
        assert not any(".hidden" in f for f in files)
