"""Tests for signed compliance attestation."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from guard.core.attestation import generate_attestation, verify_attestation


@pytest.fixture()
def scan_output(tmp_path):
    findings = [
        {"rule_id": "TEST-001", "severity": "high", "file": "app.py", "line": 10, "message": "test"},
        {"rule_id": "TEST-002", "severity": "medium", "file": "app.py", "line": 20, "message": "test2"},
    ]
    metrics = {
        "total_duration_ms": 123.4,
        "files_scanned": 5,
        "findings_by_rule": {"TEST-001": 1, "TEST-002": 1},
    }
    findings_path = tmp_path / "findings.json"
    metrics_path = tmp_path / "scan_metrics.json"
    findings_path.write_text(json.dumps(findings), encoding="utf-8")
    metrics_path.write_text(json.dumps(metrics), encoding="utf-8")
    return findings_path, metrics_path


class TestGenerateAttestation:
    def test_generates_valid_structure(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path)

        assert "attestation" in doc
        assert "signature" in doc
        assert doc["algorithm"] == "hmac-sha256"
        assert len(doc["signature"]) == 64  # SHA-256 hex

    def test_attestation_fields(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path, {
            "gate_fail_on": ["critical", "high"],
            "standards_packs": ["owasp-top-10"],
        })
        att = doc["attestation"]

        assert att["version"] == "1.0"
        assert att["type"] == "sentrik.compliance.attestation"
        assert "timestamp" in att
        assert att["scan"]["total_findings"] == 2
        assert att["scan"]["findings_sha256"]
        assert att["scan"]["severity_counts"]["high"] == 1
        assert att["scan"]["severity_counts"]["medium"] == 1
        assert att["scan"]["files_scanned"] == 5
        assert att["scan"]["packs_enabled"] == ["owasp-top-10"]
        assert att["environment"]["tool"] == "sentrik"

    def test_gate_passed_no_blocking(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path, {
            "gate_fail_on": ["critical"],  # only critical blocks, we have high+medium
        })
        assert doc["attestation"]["scan"]["gate_passed"] is True

    def test_gate_failed_with_blocking(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path, {
            "gate_fail_on": ["critical", "high"],  # high blocks
        })
        assert doc["attestation"]["scan"]["gate_passed"] is False

    def test_empty_findings(self, tmp_path):
        findings_path = tmp_path / "findings.json"
        metrics_path = tmp_path / "scan_metrics.json"
        findings_path.write_text("[]", encoding="utf-8")
        metrics_path.write_text("{}", encoding="utf-8")

        doc = generate_attestation(findings_path, metrics_path)
        assert doc["attestation"]["scan"]["total_findings"] == 0
        assert doc["attestation"]["scan"]["gate_passed"] is True

    def test_missing_files(self, tmp_path):
        doc = generate_attestation(
            tmp_path / "nope.json",
            tmp_path / "nope2.json",
        )
        assert doc["attestation"]["scan"]["total_findings"] == 0


class TestVerifyAttestation:
    def test_valid_signature(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path)
        assert verify_attestation(doc) is True

    def test_tampered_payload(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path)
        doc["attestation"]["scan"]["gate_passed"] = True  # tamper
        assert verify_attestation(doc) is False

    def test_tampered_signature(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path)
        doc["signature"] = "a" * 64
        assert verify_attestation(doc) is False

    def test_missing_fields(self):
        assert verify_attestation({}) is False
        assert verify_attestation({"attestation": {}, "signature": "abc"}) is False

    def test_wrong_algorithm(self, scan_output):
        findings_path, metrics_path = scan_output
        doc = generate_attestation(findings_path, metrics_path)
        doc["algorithm"] = "rsa-sha512"
        assert verify_attestation(doc) is False
