"""Tests for the license key validation system."""

from __future__ import annotations

from datetime import date, timedelta

import pytest

from guard.core.licensing import (
    LicenseError,
    LicenseInfo,
    TIER_FEATURES,
    VALID_TIERS,
    _minimum_tier_for_feature,
    check_feature,
    enforce_license,
    generate_key,
    generate_trial_key,
    get_license_info,
    require_license,
    validate_key,
)


# ===================================================================
# Key generation
# ===================================================================


class TestGenerateKey:
    def test_generates_valid_format(self):
        key = generate_key("TEAM", date(2027, 12, 31))
        parts = key.split("-")
        assert len(parts) == 4
        assert parts[0] == "GUARD"
        assert parts[1] == "TEAM"
        assert parts[2] == "20271231"
        assert len(parts[3]) == 16

    def test_all_tiers(self):
        for tier in VALID_TIERS:
            key = generate_key(tier, date(2027, 1, 1))
            assert key.startswith(f"GUARD-{tier}-")

    def test_invalid_tier_raises(self):
        with pytest.raises(ValueError, match="Invalid tier"):
            generate_key("INVALID", date(2027, 1, 1))

    def test_different_dates_produce_different_keys(self):
        k1 = generate_key("TEAM", date(2027, 1, 1))
        k2 = generate_key("TEAM", date(2027, 6, 15))
        assert k1 != k2

    def test_different_tiers_produce_different_keys(self):
        k1 = generate_key("TEAM", date(2027, 1, 1))
        k2 = generate_key("ORG", date(2027, 1, 1))
        assert k1 != k2


# ===================================================================
# Key validation
# ===================================================================


class TestValidateKey:
    def test_valid_key(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("TEAM", future)
        info = validate_key(key)
        assert info.valid is True
        assert info.tier == "TEAM"
        assert info.expired is False
        assert info.expiry == future

    def test_expired_key(self):
        past = date.today() - timedelta(days=1)
        key = generate_key("TEAM", past)
        info = validate_key(key)
        assert info.valid is True
        assert info.expired is True
        assert info.features == set()  # No features when expired

    def test_empty_key(self):
        info = validate_key("")
        assert info.valid is False
        assert "No license key" in info.message

    def test_whitespace_key(self):
        info = validate_key("   ")
        assert info.valid is False

    def test_invalid_format(self):
        info = validate_key("not-a-valid-key")
        assert info.valid is False
        assert "Invalid key format" in info.message

    def test_wrong_prefix(self):
        info = validate_key("WRONG-TEAM-20271231-abcdef1234567890")
        assert info.valid is False

    def test_unknown_tier(self):
        info = validate_key("GUARD-MEGA-20271231-abcdef1234567890")
        assert info.valid is False
        assert "Unknown tier" in info.message

    def test_invalid_date(self):
        info = validate_key("GUARD-TEAM-99999999-abcdef1234567890")
        assert info.valid is False
        assert "Invalid expiry" in info.message

    def test_tampered_signature(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("TEAM", future)
        # Tamper with the signature
        tampered = key[:-1] + ("a" if key[-1] != "a" else "b")
        info = validate_key(tampered)
        assert info.valid is False
        assert "Invalid key signature" in info.message

    def test_tampered_tier(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("TEAM", future)
        # Change tier but keep original signature
        tampered = key.replace("TEAM", "ORG")
        info = validate_key(tampered)
        assert info.valid is False

    def test_all_tier_features(self):
        future = date.today() + timedelta(days=365)
        for tier in VALID_TIERS:
            key = generate_key(tier, future)
            info = validate_key(key)
            assert info.valid is True
            assert info.features == TIER_FEATURES[tier]


# ===================================================================
# get_license_info
# ===================================================================


class TestGetLicenseInfo:
    def test_no_key_returns_free(self):
        info = get_license_info("")
        assert info.valid is True
        assert info.tier == "FREE"
        assert "free" in info.message.lower()

    def test_valid_key_from_config(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("ORG", future)
        info = get_license_info(key)
        assert info.valid is True
        assert info.tier == "ORG"

    def test_env_var_fallback(self, monkeypatch):
        future = date.today() + timedelta(days=365)
        key = generate_key("ENTERPRISE", future)
        monkeypatch.setenv("GUARD_LICENSE_KEY", key)
        info = get_license_info("")
        assert info.valid is True
        assert info.tier == "ENTERPRISE"


# ===================================================================
# check_feature
# ===================================================================


class TestCheckFeature:
    def test_trial_has_scan(self):
        info = get_license_info("")  # Trial
        assert check_feature(info, "scan") is True

    def test_trial_no_governance(self):
        info = get_license_info("")
        assert check_feature(info, "governance") is False

    def test_enterprise_has_all(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("ENTERPRISE", future)
        info = validate_key(key)
        assert check_feature(info, "governance") is True
        assert check_feature(info, "audit") is True
        assert check_feature(info, "ml") is True

    def test_expired_has_nothing(self):
        past = date.today() - timedelta(days=1)
        key = generate_key("ENTERPRISE", past)
        info = validate_key(key)
        assert check_feature(info, "scan") is False


# ===================================================================
# Tier feature hierarchy
# ===================================================================


class TestTierHierarchy:
    def test_enterprise_superset_of_org(self):
        assert TIER_FEATURES["ORG"].issubset(TIER_FEATURES["ENTERPRISE"])

    def test_org_superset_of_team(self):
        assert TIER_FEATURES["TEAM"].issubset(TIER_FEATURES["ORG"])

    def test_team_superset_of_trial(self):
        assert TIER_FEATURES["TRIAL"].issubset(TIER_FEATURES["TEAM"])


# ===================================================================
# require_license
# ===================================================================


class TestRequireLicense:
    """Tests for the require_license enforcement function."""

    def test_succeeds_for_available_feature(self):
        """FREE has 'scan', so require_license should succeed."""
        info = require_license("scan", "")
        assert info.valid is True
        assert info.tier == "FREE"

    def test_raises_for_unavailable_feature(self):
        """FREE does NOT have 'governance', so it should raise."""
        with pytest.raises(LicenseError) as exc_info:
            require_license("governance", "")
        assert exc_info.value.feature == "governance"

    def test_raises_for_expired_key(self):
        """An expired key should raise for any feature."""
        past = date.today() - timedelta(days=1)
        key = generate_key("ENTERPRISE", past)
        with pytest.raises(LicenseError):
            require_license("scan", key)

    def test_enterprise_has_all_features(self):
        """ENTERPRISE should succeed for governance and audit."""
        future = date.today() + timedelta(days=365)
        key = generate_key("ENTERPRISE", future)
        info = require_license("governance", key)
        assert info.tier == "ENTERPRISE"
        info = require_license("audit", key)
        assert info.tier == "ENTERPRISE"

    def test_org_lacks_governance(self):
        """ORG should raise for governance."""
        future = date.today() + timedelta(days=365)
        key = generate_key("ORG", future)
        with pytest.raises(LicenseError) as exc_info:
            require_license("governance", key)
        assert exc_info.value.feature == "governance"
        assert exc_info.value.tier == "ORG"

    def test_org_has_ml(self):
        """ORG should succeed for ml."""
        future = date.today() + timedelta(days=365)
        key = generate_key("ORG", future)
        info = require_license("ml", key)
        assert info.tier == "ORG"

    def test_trial_has_api(self):
        """TRIAL has api, so serve command license check should pass."""
        info = require_license("api", "")
        assert "api" in info.features

    def test_free_does_not_have_reconcile(self):
        """FREE does not have reconcile — it requires TRIAL+."""
        with pytest.raises(LicenseError) as exc_info:
            require_license("reconcile", "")
        assert exc_info.value.feature == "reconcile"


# ===================================================================
# enforce_license decorator
# ===================================================================


class TestEnforceLicenseDecorator:
    """Tests for the @enforce_license decorator."""

    def test_allows_permitted_feature(self):
        @enforce_license("scan")
        def do_scan(config_key=""):
            return "scanned"

        assert do_scan() == "scanned"

    def test_blocks_unpermitted_feature(self):
        @enforce_license("governance")
        def do_governance(config_key=""):
            return "governed"

        with pytest.raises(LicenseError):
            do_governance()

    def test_extracts_config_key_from_args(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("ENTERPRISE", future)

        @enforce_license("governance")
        def do_governance(config_key=""):
            return "governed"

        assert do_governance(config_key=key) == "governed"

    def test_extracts_config_key_from_positional(self):
        future = date.today() + timedelta(days=365)
        key = generate_key("ENTERPRISE", future)

        @enforce_license("governance")
        def do_governance(key_arg):
            return "governed"

        assert do_governance(key) == "governed"


# ===================================================================
# LicenseError attributes
# ===================================================================


class TestLicenseError:
    """Tests for LicenseError attributes."""

    def test_has_feature_attribute(self):
        err = LicenseError(feature="governance", tier="TRIAL")
        assert err.feature == "governance"

    def test_has_tier_attribute(self):
        err = LicenseError(feature="governance", tier="TRIAL")
        assert err.tier == "TRIAL"

    def test_message_mentions_upgrade(self):
        err = LicenseError(feature="governance", tier="TRIAL")
        assert "Enterprise" in str(err)

    def test_custom_message(self):
        err = LicenseError(feature="x", tier="TRIAL", message="custom msg")
        assert str(err) == "custom msg"


# ===================================================================
# _minimum_tier_for_feature
# ===================================================================


class TestMinimumTierForFeature:
    """Tests for _minimum_tier_for_feature."""

    def test_scan_is_free(self):
        assert _minimum_tier_for_feature("scan") == "FREE"

    def test_governance_is_enterprise(self):
        assert _minimum_tier_for_feature("governance") == "ENTERPRISE"

    def test_ml_is_org(self):
        assert _minimum_tier_for_feature("ml") == "ORG"

    def test_unknown_defaults_to_enterprise(self):
        assert _minimum_tier_for_feature("unknown_feature_xyz") == "ENTERPRISE"


# ===================================================================
# Trial key generation
# ===================================================================


class TestGenerateTrialKey:
    """Tests for generate_trial_key()."""

    def test_generates_enterprise_key(self):
        key = generate_trial_key()
        assert "GUARD-ENTERPRISE-" in key

    def test_key_is_valid(self):
        key = generate_trial_key()
        info = validate_key(key)
        assert info.valid
        assert info.tier == "ENTERPRISE"
        assert not info.expired

    def test_default_30_days(self):
        key = generate_trial_key()
        info = validate_key(key)
        expected = date.today() + timedelta(days=30)
        assert info.expiry == expected

    def test_custom_days(self):
        key = generate_trial_key(days=7)
        info = validate_key(key)
        expected = date.today() + timedelta(days=7)
        assert info.expiry == expected

    def test_all_enterprise_features_available(self):
        key = generate_trial_key()
        info = validate_key(key)
        assert "parallel" in info.features
        assert "ml" in info.features
        assert "governance" in info.features
        assert "audit" in info.features
        assert "async_approval" in info.features


# ===================================================================
# Trial CLI command
# ===================================================================



class TestOnlineLicenseCheck:
    """Tests for online license check with caching."""

    def test_online_check_success(self, monkeypatch, tmp_path):
        from guard.core import licensing
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(tmp_path / "cache.json"))

        import httpx
        from unittest.mock import MagicMock

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "valid": True, "tier": "TEAM", "expiry": "2026-12-31", "days_remaining": 300,
        }
        mock_resp.raise_for_status = MagicMock()

        monkeypatch.setattr(httpx, "get", lambda *a, **kw: mock_resp)
        result = licensing.check_license_online("GUARD-TEAM-20261231-abc", "http://localhost")
        assert result.checked is True
        assert result.valid is True
        assert result.tier == "TEAM"
        assert result.days_remaining == 300
        assert result.cached is False

    def test_online_check_timeout(self, monkeypatch, tmp_path):
        from guard.core import licensing
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(tmp_path / "cache.json"))

        import httpx
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: (_ for _ in ()).throw(httpx.ConnectTimeout("timeout")))
        result = licensing.check_license_online("GUARD-TEAM-20261231-abc", "http://localhost")
        assert result.checked is False
        assert "unreachable" in result.error.lower() or "timeout" in result.error.lower()

    def test_online_check_cache_hit(self, monkeypatch, tmp_path):
        from guard.core import licensing
        import json, time

        cache_file = tmp_path / "cache.json"
        cache_data = {
            "key": "GUARD-TEAM-20261231-abc",
            "valid": True, "tier": "TEAM", "expiry": "2026-12-31",
            "days_remaining": 300, "cached_at": time.time(),
        }
        cache_file.write_text(json.dumps(cache_data))
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(cache_file))

        # Should not call httpx at all
        import httpx
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: (_ for _ in ()).throw(AssertionError("should not call")))
        result = licensing.check_license_online("GUARD-TEAM-20261231-abc", "http://localhost")
        assert result.checked is True
        assert result.cached is True
        assert result.valid is True

    def test_online_check_cache_expired(self, monkeypatch, tmp_path):
        from guard.core import licensing
        import json, time

        cache_file = tmp_path / "cache.json"
        cache_data = {
            "key": "GUARD-TEAM-20261231-abc",
            "valid": True, "tier": "TEAM", "expiry": "2026-12-31",
            "days_remaining": 300, "cached_at": time.time() - 100000,  # expired
        }
        cache_file.write_text(json.dumps(cache_data))
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(cache_file))

        import httpx
        from unittest.mock import MagicMock
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"valid": True, "tier": "TEAM", "expiry": "2026-12-31", "days_remaining": 250}
        mock_resp.raise_for_status = MagicMock()
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: mock_resp)

        result = licensing.check_license_online("GUARD-TEAM-20261231-abc", "http://localhost")
        assert result.checked is True
        assert result.cached is False
        assert result.days_remaining == 250

    def test_offline_mode_skips_check(self, monkeypatch, tmp_path):
        from guard.core import licensing
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(tmp_path / "cache.json"))

        result = licensing.check_license_online("", "http://localhost")
        assert result.checked is False
        assert result.error == "No key provided"

    def test_expiry_warning_threshold(self, monkeypatch, tmp_path):
        from guard.core import licensing
        monkeypatch.setattr(licensing, "_CACHE_FILE", str(tmp_path / "cache.json"))

        import httpx
        from unittest.mock import MagicMock
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"valid": True, "tier": "TEAM", "expiry": "2026-03-10", "days_remaining": 5}
        mock_resp.raise_for_status = MagicMock()
        monkeypatch.setattr(httpx, "get", lambda *a, **kw: mock_resp)

        result = licensing.check_license_online("GUARD-TEAM-20260310-abc", "http://localhost")
        assert result.checked is True
        assert result.days_remaining == 5
