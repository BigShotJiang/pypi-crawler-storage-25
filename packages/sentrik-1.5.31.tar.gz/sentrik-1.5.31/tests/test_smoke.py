"""Smoke tests for Phase 1 — verify end-to-end CLI and artifact generation."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from guard.cli import app
from guard.config import GuardConfig
from guard.core.context_builder import build_agent_context
from guard.core.models import GateResult, Severity
from guard.core.pipeline import evaluate_gate, run_scan
from guard.providers.devops_stub import DevOpsStub
from guard.providers.scanners_stub import ScannersStub
from guard.providers.standards_stub import StandardsStub
from guard.rules.engine import RulesEngine

runner = CliRunner()


def test_init_creates_config(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init", "--no-interactive"])
    assert result.exit_code == 0
    assert (tmp_path / ".sentrik" / "config.yaml").exists()


def test_context_writes_agent_context(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    # Create config and sample data
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    # Create examples dir with sample data
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["context"])
    assert result.exit_code == 0
    ctx_path = tmp_path / "out" / "agent_context.json"
    assert ctx_path.exists()
    ctx = json.loads(ctx_path.read_text())
    assert "repo_root" in ctx
    assert "commands" in ctx


def test_scan_writes_artifacts(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    out = tmp_path / "out"
    assert (out / "findings.json").exists()
    assert (out / "report.md").exists()
    assert (out / "next_actions.md").exists()
    assert (out / "run_metadata.json").exists()

    findings = json.loads((out / "findings.json").read_text())
    assert isinstance(findings, list)


def test_gate_returns_correct_exit_code(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    # stub returns LOW severity — default gate_fail_on is [critical, high]
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["gate"])
    assert result.exit_code == 0  # LOW finding should not fail gate
    assert "GATE PASSED" in result.output


def test_gate_fails_on_critical():
    from guard.core.models import Evidence, Finding

    findings = [
        Finding(
            finding_id="TEST-001",
            rule_id="test-critical",
            severity=Severity.CRITICAL,
            message="Critical issue",
            evidence=Evidence(file="test.py"),
            confidence=1.0,
        )
    ]
    config = GuardConfig()
    gate = evaluate_gate(findings, config)
    assert not gate.passed
    assert gate.critical == 1


def test_stub_scanner_returns_empty():
    scanner = ScannersStub()
    findings = scanner.scan("/tmp/fake")
    assert findings == []


def test_stub_devops_loads_items(tmp_path):
    items_file = tmp_path / "items.json"
    items_file.write_text(json.dumps([
        {"id": "WI-1", "title": "Test item"}
    ]))
    devops = DevOpsStub(str(items_file))
    items = devops.get_work_items()
    assert len(items) == 1
    assert items[0].id == "WI-1"


def test_stub_standards_loads_rules(tmp_path):
    rules_file = tmp_path / "rules.yaml"
    rules_file.write_text('rules:\n  - id: "R1"\n    name: "test"\n    type: "regex"\n')
    standards = StandardsStub(str(rules_file))
    assert standards.get_rule_ids() == ["R1"]


def test_rules_engine_returns_empty():
    engine = RulesEngine([])
    findings = engine.evaluate("/tmp/fake")
    assert findings == []


# ---------------------------------------------------------------------------
# Phase 2 — CLI tests for --git-range and --diff flags
# ---------------------------------------------------------------------------


def test_scan_with_git_range(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    monkeypatch.setattr(
        "guard.cli.get_changed_files_from_range",
        lambda git_range, repo_root: ["changed.py"],
    )
    result = runner.invoke(app, ["scan", "--git-range", "HEAD~1..HEAD"])
    assert result.exit_code == 0
    assert "Scope: 1 file(s) from git range HEAD~1..HEAD" in result.output


def test_gate_with_diff_flag(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    diff_text = (
        "diff --git a/x.py b/x.py\n"
        "--- a/x.py\n"
        "+++ b/x.py\n"
        "@@ -1 +1,2 @@\n"
        " old\n"
        "+new\n"
    )
    result = runner.invoke(app, ["gate", "--diff", diff_text])
    assert result.exit_code == 0
    assert "Scope: 1 file(s) from provided diff" in result.output
    assert "GATE PASSED" in result.output


def test_scan_mutual_exclusion(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, [
        "scan", "--git-range", "main..HEAD", "--diff", "some diff text",
    ])
    assert result.exit_code == 1


def test_scan_finds_real_rule_violations(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    # Write a .py file with known violations
    src = tmp_path / "src"
    src.mkdir()
    (src / "buggy.py").write_text('# TODO fix\nprint("debug")\n', encoding="utf-8")

    # Use inline rules matching sample_standards patterns
    rules_yaml = (
        "rules:\n"
        '  - id: "R1"\n'
        '    name: "no-todo-comments"\n'
        '    type: "regex"\n'
        '    pattern: "(?i)\\\\bTODO\\\\b"\n'
        '    severity: "low"\n'
        '    file_glob: "**/*.py"\n'
        '  - id: "R2"\n'
        '    name: "no-print-statements"\n'
        '    type: "regex"\n'
        '    pattern: "\\\\bprint\\\\s*\\\\("\n'
        '    severity: "medium"\n'
        '    file_glob: "**/*.py"\n'
    )
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text(rules_yaml)

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    rule_ids = {f["rule_id"] for f in findings}
    assert "R1" in rule_ids
    assert "R2" in rule_ids


# ---------------------------------------------------------------------------
# Phase 4 — Traceability smoke tests
# ---------------------------------------------------------------------------


def test_scan_with_branch_links_work_items(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    # Add a rule so the rules engine produces a finding
    rules_yaml = (
        "rules:\n"
        '  - id: "R-todo"\n'
        '    name: "no-todo"\n'
        '    type: "regex"\n'
        '    pattern: "(?i)\\\\bTODO\\\\b"\n'
        '    severity: "low"\n'
        '    file_glob: "**/*.py"\n'
    )
    (examples / "sample_standards.yaml").write_text(rules_yaml)

    # Create a file with a TODO so the rule fires
    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text("# TODO fix this\n", encoding="utf-8")

    # --branch carries a work-item ID; findings should get linked
    result = runner.invoke(app, ["scan", "--branch", "feature/WI-101-add-auth"])
    assert result.exit_code == 0

    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    assert len(findings) >= 1
    assert "WI-101" in findings[0]["related_work_items"]


def test_scan_without_branch_no_work_items(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    # Add a rule so the rules engine produces a finding
    rules_yaml = (
        "rules:\n"
        '  - id: "R-todo"\n'
        '    name: "no-todo"\n'
        '    type: "regex"\n'
        '    pattern: "(?i)\\\\bTODO\\\\b"\n'
        '    severity: "low"\n'
        '    file_glob: "**/*.py"\n'
    )
    (examples / "sample_standards.yaml").write_text(rules_yaml)

    # Create a file with a TODO so the rule fires
    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text("# TODO fix this\n", encoding="utf-8")

    # Disable auto-detection so no branch is resolved
    monkeypatch.setattr("guard.cli.get_current_branch", lambda: None)
    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    assert len(findings) >= 1
    assert findings[0]["related_work_items"] == []


# ---------------------------------------------------------------------------
# Phase 5 — Patch generation and application smoke tests
# ---------------------------------------------------------------------------


def test_scan_generates_patches_for_fixable_findings(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    # Write a file with a print statement (auto-fixable)
    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text('"""Module."""\nprint("debug")\nx = 1\n', encoding="utf-8")

    # Rules with autofix
    rules_yaml = (
        "rules:\n"
        '  - id: "R-print"\n'
        '    name: "no-print"\n'
        '    type: "regex"\n'
        '    pattern: "\\\\bprint\\\\s*\\\\("\n'
        '    severity: "medium"\n'
        '    file_glob: "**/*.py"\n'
        '    autofix: "remove_line"\n'
    )
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text(rules_yaml)

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    # Patches should have been generated
    patches_dir = tmp_path / "out" / "patches"
    patch_files = list(patches_dir.glob("*.patch"))
    assert len(patch_files) >= 1


def test_apply_patches_cli(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    # Create a file to patch
    (tmp_path / "app.py").write_text('print("debug")\nx = 1\n', encoding="utf-8")

    # Create a patch manually
    patches_dir = tmp_path / "out" / "patches"
    patches_dir.mkdir(parents=True)
    patch_content = (
        "--- a/app.py\n"
        "+++ b/app.py\n"
        "@@ -1,2 +1,1 @@\n"
        '-print("debug")\n'
        " x = 1\n"
    )
    (patches_dir / "0001.patch").write_text(patch_content, encoding="utf-8")

    result = runner.invoke(app, ["apply-patches"])
    assert result.exit_code == 0
    assert "Applied 1 patch(es)" in result.output

    # Verify file was patched
    assert "print" not in (tmp_path / "app.py").read_text(encoding="utf-8")


def test_apply_patches_no_patches(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    result = runner.invoke(app, ["apply-patches"])
    assert result.exit_code == 1
    assert "No patches found" in result.output or "patch" in result.output.lower()


# ---------------------------------------------------------------------------
# Phase 6 — Provider factory and LLM integration smoke tests
# ---------------------------------------------------------------------------


def test_scan_with_llm_enabled_stub(tmp_path, monkeypatch):
    """With llm_enabled=True and stub LLM, scan produces no LLM findings but still works."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"), llm_enabled=True)
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    # Write a .py file so the LLM scanner has something to scan
    (tmp_path / "app.py").write_text('x = 1\n', encoding="utf-8")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    assert "Scan Complete" in result.output or "finding(s)" in result.output

    # LLMStub returns empty findings, so findings.json should still exist
    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    assert isinstance(findings, list)


def test_provider_factory_used_by_cli(tmp_path, monkeypatch):
    """Verify the CLI builds providers from config (factory integration)."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["gate"])
    assert result.exit_code == 0
    assert "GATE PASSED" in result.output


def test_scan_without_flags_scans_all(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    assert "Scope:" not in result.output


# ---------------------------------------------------------------------------
# Phase 7 — Composite scanner and SARIF import smoke tests
# ---------------------------------------------------------------------------


def test_scan_with_sarif_provider(tmp_path, monkeypatch):
    """Scan with provider=sarif reads findings from a SARIF file."""
    monkeypatch.chdir(tmp_path)

    sarif_file = tmp_path / "results.sarif"
    sarif_data = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {"driver": {"name": "test-tool"}},
                "results": [
                    {
                        "ruleId": "TEST-001",
                        "level": "warning",
                        "message": {"text": "Test issue"},
                        "locations": [
                            {
                                "physicalLocation": {
                                    "artifactLocation": {"uri": "app.py"},
                                    "region": {"startLine": 1},
                                }
                            }
                        ],
                    }
                ],
            }
        ],
    }
    sarif_file.write_text(json.dumps(sarif_data), encoding="utf-8")

    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        provider="sarif",
        sarif_files=[str(sarif_file)],
    )
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    sarif_findings = [f for f in findings if f["rule_id"] == "TEST-001"]
    assert len(sarif_findings) == 1
    assert sarif_findings[0]["evidence"]["file"] == "app.py"


def test_scan_with_composite_provider(tmp_path, monkeypatch):
    """Scan with provider=composite aggregates SARIF findings."""
    monkeypatch.chdir(tmp_path)

    sarif_file = tmp_path / "results.sarif"
    sarif_data = {
        "version": "2.1.0",
        "runs": [
            {
                "tool": {"driver": {"name": "bandit"}},
                "results": [
                    {
                        "ruleId": "B101",
                        "level": "warning",
                        "message": {"text": "Use of assert detected."},
                        "locations": [
                            {
                                "physicalLocation": {
                                    "artifactLocation": {"uri": "app.py"},
                                    "region": {"startLine": 5},
                                }
                            }
                        ],
                    }
                ],
            }
        ],
    }
    sarif_file.write_text(json.dumps(sarif_data), encoding="utf-8")

    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        provider="composite",
        sarif_files=[str(sarif_file)],
    )
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    findings = json.loads((tmp_path / "out" / "findings.json").read_text())
    sarif_findings = [f for f in findings if f["rule_id"] == "B101"]
    assert len(sarif_findings) == 1


# ---------------------------------------------------------------------------
# Phase 8 — Reporter and comparison smoke tests
# ---------------------------------------------------------------------------


def test_scan_with_reporters_generates_html(tmp_path, monkeypatch):
    """Scan with reporters=[html] generates an HTML report file."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        reporters=["html"],
    )
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    assert (tmp_path / "out" / "report.html").exists()
    html = (tmp_path / "out" / "report.html").read_text(encoding="utf-8")
    assert "<html" in html


def test_scan_with_multiple_reporters(tmp_path, monkeypatch):
    """Scan with multiple reporters generates all output files."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        reporters=["html", "junit", "sarif"],
    )
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    assert (tmp_path / "out" / "report.html").exists()
    assert (tmp_path / "out" / "report.xml").exists()
    assert (tmp_path / "out" / "report.sarif.json").exists()


def test_report_command_generates_html(tmp_path, monkeypatch):
    """The report command generates a report from existing findings."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    # Create findings.json manually
    out = tmp_path / "out"
    out.mkdir(parents=True)
    findings = [
        {
            "finding_id": "F1",
            "rule_id": "test",
            "severity": "low",
            "message": "Test",
            "evidence": {"file": "a.py", "lines": [], "snippet": ""},
            "confidence": 1.0,
            "deterministic": True,
            "related_work_items": [],
        }
    ]
    (out / "findings.json").write_text(json.dumps(findings), encoding="utf-8")

    result = runner.invoke(app, ["report", "--format", "html"])
    assert result.exit_code == 0
    assert "Report written to" in result.output
    assert (out / "report.html").exists()


def test_report_command_junit(tmp_path, monkeypatch):
    """The report command generates JUnit XML."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    out = tmp_path / "out"
    out.mkdir(parents=True)
    (out / "findings.json").write_text("[]", encoding="utf-8")

    result = runner.invoke(app, ["report", "--format", "junit"])
    assert result.exit_code == 0
    assert (out / "report.xml").exists()


def test_report_command_no_findings(tmp_path, monkeypatch):
    """The report command fails gracefully when no findings exist."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    result = runner.invoke(app, ["report"])
    assert result.exit_code == 1
    assert "No findings.json found" in result.output or "findings" in result.output.lower()


def test_report_command_unknown_format(tmp_path, monkeypatch):
    """The report command fails on unknown format."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    out = tmp_path / "out"
    out.mkdir(parents=True)
    (out / "findings.json").write_text("[]", encoding="utf-8")

    result = runner.invoke(app, ["report", "--format", "banana"])
    assert result.exit_code == 1


def test_compare_command(tmp_path, monkeypatch):
    """The compare command shows new/resolved/unchanged findings."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    out = tmp_path / "out"
    out.mkdir(parents=True)

    prev_findings = [
        {
            "finding_id": "F1", "rule_id": "test", "severity": "low",
            "message": "Old", "evidence": {"file": "a.py"},
            "confidence": 1.0, "deterministic": True, "related_work_items": [],
        },
        {
            "finding_id": "F2", "rule_id": "test", "severity": "low",
            "message": "Resolved", "evidence": {"file": "b.py"},
            "confidence": 1.0, "deterministic": True, "related_work_items": [],
        },
    ]
    curr_findings = [
        {
            "finding_id": "F1", "rule_id": "test", "severity": "low",
            "message": "Old", "evidence": {"file": "a.py"},
            "confidence": 1.0, "deterministic": True, "related_work_items": [],
        },
        {
            "finding_id": "F3", "rule_id": "test", "severity": "low",
            "message": "New", "evidence": {"file": "c.py"},
            "confidence": 1.0, "deterministic": True, "related_work_items": [],
        },
    ]

    prev_path = tmp_path / "prev_findings.json"
    prev_path.write_text(json.dumps(prev_findings), encoding="utf-8")
    (out / "findings.json").write_text(json.dumps(curr_findings), encoding="utf-8")

    result = runner.invoke(app, ["compare", "--previous", str(prev_path)])
    assert result.exit_code == 0
    assert "+ New" in result.output
    assert "Resolved" in result.output
    assert "Unchanged" in result.output
    assert (out / "comparison.md").exists()


def test_compare_no_previous_flag(tmp_path, monkeypatch):
    """Compare without --previous auto-detects history or exits gracefully."""
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    out = tmp_path / "out"
    out.mkdir(parents=True)
    (out / "findings.json").write_text("[]", encoding="utf-8")

    result = runner.invoke(app, ["compare"])
    # Exits 0 (auto-detects no history) or 1 (no previous found)
    assert result.exit_code in (0, 1)


# ---------------------------------------------------------------------------
# Phase 9 — Config validation, cache, list-rules, autofix smoke tests
# ---------------------------------------------------------------------------


def test_validate_config_valid(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["validate-config"])
    assert result.exit_code == 0
    assert "valid" in result.output.lower()


def test_validate_config_errors(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        provider="nonexistent",
        gate_fail_on=["banana"],
    )
    config.save(tmp_path / ".guard.yaml")

    result = runner.invoke(app, ["validate-config"])
    assert result.exit_code == 1
    assert "ERROR" in result.output


def test_list_rules_command(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["list-rules"])
    assert result.exit_code == 0
    assert "BUILTIN-001" in result.output
    assert "no-todo-comments" in result.output
    assert "Total:" in result.output


def test_scan_with_cache_enabled(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    cache_dir = tmp_path / ".guard_cache"
    config = GuardConfig(
        output_dir=str(tmp_path / "out"),
        cache_enabled=True,
        cache_dir=str(cache_dir),
    )
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    rules_yaml = (
        "rules:\n"
        '  - id: "R-todo"\n'
        '    name: "no-todo"\n'
        '    type: "regex"\n'
        '    pattern: "(?i)\\\\bTODO\\\\b"\n'
        '    severity: "low"\n'
        '    file_glob: "**/*.py"\n'
    )
    (examples / "sample_standards.yaml").write_text(rules_yaml)
    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text("# TODO fix\n", encoding="utf-8")

    # First scan
    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0
    assert cache_dir.exists()

    # Second scan (should use cache)
    result2 = runner.invoke(app, ["scan"])
    assert result2.exit_code == 0


def test_comment_out_autofix(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")

    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text('x = 1\nprint("debug")\ny = 2\n', encoding="utf-8")

    rules_yaml = (
        "rules:\n"
        '  - id: "R-print"\n'
        '    name: "no-print"\n'
        '    type: "regex"\n'
        '    pattern: "\\\\bprint\\\\s*\\\\("\n'
        '    severity: "medium"\n'
        '    file_glob: "**/*.py"\n'
        '    autofix: "comment_out"\n'
    )
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text(rules_yaml)

    result = runner.invoke(app, ["scan"])
    assert result.exit_code == 0

    patches_dir = tmp_path / "out" / "patches"
    patches = list(patches_dir.glob("*.patch"))
    assert len(patches) >= 1

    patch_content = patches[0].read_text(encoding="utf-8")
    assert "# print" in patch_content


def test_context_includes_new_commands(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = GuardConfig(output_dir=str(tmp_path / "out"))
    config.save(tmp_path / ".guard.yaml")
    examples = tmp_path / "examples"
    examples.mkdir()
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")

    result = runner.invoke(app, ["context"])
    assert result.exit_code == 0

    ctx = json.loads((tmp_path / "out" / "agent_context.json").read_text())
    assert "report" in ctx["commands"]
    assert "compare" in ctx["commands"]
    assert "list_rules" in ctx["commands"]
    assert "validate_config" in ctx["commands"]
