"""Tests for Phase 22 — Custom Rules & Extensibility."""

from __future__ import annotations

import ast
import os
import tempfile
import textwrap

import pytest

from guard.core.models import Finding
from guard.rules.ast_checks import AST_CHECKS, high_complexity, max_function_length, no_nested_functions
from guard.rules.engine import (
    FILE_POLICY_CHECKS,
    RulesEngine,
    _check_max_function_count,
    _check_max_lines,
    _check_must_contain_pattern,
    _check_must_not_import,
    _check_starts_with_docstring,
    _evaluate_composite_regex,
    _evaluate_required_pattern,
)
from guard.rules.rule_schema import RuleDefinition


# ===================================================================
# Helpers
# ===================================================================


def _make_rule(**overrides) -> RuleDefinition:
    defaults = {
        "id": "TEST-001",
        "name": "test-rule",
        "description": "A test rule",
        "type": "regex",
        "severity": "medium",
        "file_glob": "**/*.py",
    }
    defaults.update(overrides)
    return RuleDefinition(**defaults)


def _scan_content(rule_dict: dict, filename: str, content: str) -> list[Finding]:
    """Run a single rule against a single in-memory file and return findings."""
    with tempfile.TemporaryDirectory() as tmp:
        filepath = os.path.join(tmp, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        engine = RulesEngine([rule_dict])
        return engine.evaluate(tmp)


# ===================================================================
# TestFilePolicyMaxLines
# ===================================================================


class TestFilePolicyMaxLines:
    def test_under_limit(self):
        passed, _ = _check_max_lines("line1\nline2\nline3\n", {})
        assert passed

    def test_over_default_limit(self):
        content = "\n".join(f"line {i}" for i in range(501))
        passed, detail = _check_max_lines(content, {})
        assert not passed
        assert "501" in detail
        assert "500" in detail

    def test_custom_threshold(self):
        content = "\n".join(f"line {i}" for i in range(11))
        passed, detail = _check_max_lines(content, {"max_lines": 10})
        assert not passed
        assert "11" in detail

    def test_exactly_at_limit(self):
        content = "\n".join(f"line {i}" for i in range(500))
        passed, _ = _check_max_lines(content, {})
        assert passed

    def test_integration(self):
        content = "\n".join(f"# line {i}" for i in range(15))
        findings = _scan_content(
            {"id": "FP-MAX", "name": "max-lines", "type": "file_policy",
             "check": "max_lines", "severity": "low", "file_glob": "**/*.py",
             "params": {"max_lines": 10}},
            "big.py", content,
        )
        assert len(findings) == 1


# ===================================================================
# TestFilePolicyMustContainPattern
# ===================================================================


class TestFilePolicyMustContainPattern:
    def test_found(self):
        passed, _ = _check_must_contain_pattern("# Copyright 2024", {"pattern": r"Copyright \d{4}"})
        assert passed

    def test_not_found(self):
        passed, detail = _check_must_contain_pattern("# No copyright here", {"pattern": r"Copyright \d{4}"})
        assert not passed
        assert "Copyright" in detail

    def test_invalid_regex(self):
        passed, _ = _check_must_contain_pattern("hello", {"pattern": r"[invalid"})
        assert passed  # invalid regex → skip, return True

    def test_no_pattern_param(self):
        passed, _ = _check_must_contain_pattern("anything", {})
        assert passed


# ===================================================================
# TestFilePolicyMustNotImport
# ===================================================================


class TestFilePolicyMustNotImport:
    def test_import_statement(self):
        passed, detail = _check_must_not_import("import os\n", {"forbidden_modules": ["os"]})
        assert not passed
        assert "os" in detail

    def test_from_import(self):
        passed, detail = _check_must_not_import("from os import path\n", {"forbidden_modules": ["os"]})
        assert not passed
        assert "os" in detail

    def test_clean_file(self):
        passed, _ = _check_must_not_import("import sys\n", {"forbidden_modules": ["os"]})
        assert passed

    def test_empty_forbidden_list(self):
        passed, _ = _check_must_not_import("import os\n", {"forbidden_modules": []})
        assert passed

    def test_multiple_forbidden(self):
        passed, detail = _check_must_not_import("import pickle\n", {"forbidden_modules": ["os", "pickle"]})
        assert not passed
        assert "pickle" in detail

    def test_no_params(self):
        passed, _ = _check_must_not_import("import os\n", {})
        assert passed


# ===================================================================
# TestFilePolicyMaxFunctionCount
# ===================================================================


class TestFilePolicyMaxFunctionCount:
    def test_under_limit(self):
        code = "def a(): pass\ndef b(): pass\n"
        passed, _ = _check_max_function_count(code, {"max_functions": 5})
        assert passed

    def test_over_limit(self):
        funcs = "\n".join(f"def f{i}(): pass" for i in range(25))
        passed, detail = _check_max_function_count(funcs, {"max_functions": 20})
        assert not passed
        assert "25" in detail

    def test_default_threshold(self):
        funcs = "\n".join(f"def f{i}(): pass" for i in range(21))
        passed, _ = _check_max_function_count(funcs, {})
        assert not passed

    def test_syntax_error_passes(self):
        passed, _ = _check_max_function_count("def broken(:", {})
        assert passed


# ===================================================================
# TestFilePolicyRegistry
# ===================================================================


class TestFilePolicyRegistry:
    def test_all_checks_registered(self):
        assert "starts_with_docstring" in FILE_POLICY_CHECKS
        assert "max_lines" in FILE_POLICY_CHECKS
        assert "must_contain_pattern" in FILE_POLICY_CHECKS
        assert "must_not_import" in FILE_POLICY_CHECKS
        assert "max_function_count" in FILE_POLICY_CHECKS

    def test_unknown_check_skipped(self):
        findings = _scan_content(
            {"id": "FP-UNK", "name": "unknown", "type": "file_policy",
             "check": "nonexistent_check", "severity": "low", "file_glob": "**/*.py"},
            "test.py", "hello\n",
        )
        assert findings == []


# ===================================================================
# TestRequiredPattern
# ===================================================================


class TestRequiredPattern:
    def test_pattern_found(self):
        rule = _make_rule(type="required_pattern", pattern=r"Copyright \d{4}")
        findings = _evaluate_required_pattern(rule, "test.py", "# Copyright 2024\n")
        assert findings == []

    def test_pattern_not_found(self):
        rule = _make_rule(type="required_pattern", pattern=r"Copyright \d{4}")
        findings = _evaluate_required_pattern(rule, "test.py", "# No copyright\n")
        assert len(findings) == 1
        assert findings[0].rule_id == "TEST-001"

    def test_no_pattern(self):
        rule = _make_rule(type="required_pattern", pattern=None)
        findings = _evaluate_required_pattern(rule, "test.py", "anything\n")
        assert findings == []

    def test_invalid_regex(self):
        rule = _make_rule(type="required_pattern", pattern=r"[invalid")
        findings = _evaluate_required_pattern(rule, "test.py", "anything\n")
        assert findings == []

    def test_file_glob_filtering(self):
        findings = _scan_content(
            {"id": "RP-001", "name": "require-copyright", "type": "required_pattern",
             "pattern": r"Copyright", "severity": "low", "file_glob": "**/*.py"},
            "test.py", "# No copyright\n",
        )
        assert len(findings) == 1

    def test_metadata_propagation(self):
        rule = _make_rule(
            type="required_pattern", pattern=r"License",
            standard="MIT", clause="1.0", tags=["license"],
        )
        findings = _evaluate_required_pattern(rule, "test.py", "no license\n")
        assert len(findings) == 1
        assert findings[0].standard == "MIT"


# ===================================================================
# TestParameterizedAST
# ===================================================================


class TestParameterizedAST:
    def test_custom_complexity_threshold(self):
        # Build function with complexity ~5 (1 base + 4 ifs)
        branches = "\n".join(f"    if x == {i}:\n        pass" for i in range(4))
        code = f"def f(x):\n{branches}\n"
        tree = ast.parse(code)
        lines = code.splitlines()

        # Default threshold 10 → no issues
        issues = high_complexity(tree, lines)
        assert issues == []

        # Custom threshold 3 → flagged
        issues = high_complexity(tree, lines, {"max_complexity": 3})
        assert len(issues) == 1

    def test_custom_nesting_depth(self):
        code = "def a():\n    def b():\n        pass\n"
        tree = ast.parse(code)
        lines = code.splitlines()

        # Default max_depth 1 → no issues (b is at depth 1)
        issues = no_nested_functions(tree, lines)
        assert issues == []

        # Custom max_depth 0 → b is flagged
        issues = no_nested_functions(tree, lines, {"max_depth": 0})
        assert len(issues) == 1

    def test_custom_function_length(self):
        body = "\n".join(f"    x = {i}" for i in range(20))
        code = f"def f():\n{body}\n"
        tree = ast.parse(code)
        lines = code.splitlines()

        # Default threshold 50 → no issues
        issues = max_function_length(tree, lines)
        assert issues == []

        # Custom threshold 10 → flagged
        issues = max_function_length(tree, lines, {"max_lines": 10})
        assert len(issues) == 1

    def test_defaults_work_without_params(self):
        code = "def f(x):\n    return x\n"
        tree = ast.parse(code)
        lines = code.splitlines()

        # All checks work with no params
        assert high_complexity(tree, lines) == []
        assert no_nested_functions(tree, lines) == []
        assert max_function_length(tree, lines) == []

    def test_integration_parameterized_ast(self):
        # Function with 4 ifs → complexity 5
        branches = "\n".join(f"    if x == {i}:\n        pass" for i in range(4))
        code = f"def f(x):\n{branches}\n"
        findings = _scan_content(
            {"id": "AST-P", "name": "custom-complexity", "type": "ast",
             "ast_check": "high_complexity", "severity": "high",
             "file_glob": "**/*.py", "params": {"max_complexity": 3}},
            "mod.py", code,
        )
        assert len(findings) == 1


# ===================================================================
# TestCompositeRegex
# ===================================================================


class TestCompositeRegex:
    def test_all_match(self):
        rule = _make_rule(all_patterns=[r"import os", r"import sys"])
        content = "import os\nimport sys\n"
        findings = _evaluate_composite_regex(rule, "test.py", content)
        assert len(findings) == 1

    def test_one_missing(self):
        rule = _make_rule(all_patterns=[r"import os", r"import sys"])
        content = "import os\n"
        findings = _evaluate_composite_regex(rule, "test.py", content)
        assert findings == []

    def test_invalid_pattern(self):
        rule = _make_rule(all_patterns=[r"import os", r"[invalid"])
        content = "import os\n"
        findings = _evaluate_composite_regex(rule, "test.py", content)
        assert findings == []

    def test_evidence_location(self):
        rule = _make_rule(all_patterns=[r"import os", r"import sys"])
        content = "import os\nimport sys\n"
        findings = _evaluate_composite_regex(rule, "test.py", content)
        assert len(findings) == 1
        assert findings[0].evidence.lines == [1]
        assert "import os" in findings[0].evidence.snippet

    def test_integration_composite(self):
        content = "import os\nimport sys\nprint('hello')\n"
        findings = _scan_content(
            {"id": "CR-001", "name": "os-and-sys", "type": "regex",
             "severity": "medium", "file_glob": "**/*.py",
             "all_patterns": [r"import os", r"import sys"]},
            "test.py", content,
        )
        assert len(findings) == 1

    def test_empty_all_patterns_falls_through(self):
        # When all_patterns is empty, normal regex evaluation applies
        findings = _scan_content(
            {"id": "CR-002", "name": "normal-regex", "type": "regex",
             "pattern": r"\bprint\b", "severity": "low", "file_glob": "**/*.py",
             "all_patterns": []},
            "test.py", "print('hi')\n",
        )
        assert len(findings) == 1


# ===================================================================
# TestBackwardCompatibility
# ===================================================================


class TestBackwardCompatibility:
    def test_existing_starts_with_docstring(self):
        findings = _scan_content(
            {"id": "BC-001", "name": "require-docstring", "type": "file_policy",
             "check": "starts_with_docstring", "severity": "low", "file_glob": "**/*.py"},
            "nodoc.py", "x = 1\n",
        )
        assert len(findings) == 1

    def test_existing_starts_with_docstring_passes(self):
        findings = _scan_content(
            {"id": "BC-002", "name": "require-docstring", "type": "file_policy",
             "check": "starts_with_docstring", "severity": "low", "file_glob": "**/*.py"},
            "hasdoc.py", '"""Module docstring."""\nx = 1\n',
        )
        assert findings == []

    def test_ast_checks_without_params(self):
        code = "def f(x=[]):\n    pass\n"
        findings = _scan_content(
            {"id": "BC-003", "name": "no-mutable", "type": "ast",
             "ast_check": "no_mutable_defaults", "severity": "high", "file_glob": "**/*.py"},
            "test.py", code,
        )
        assert len(findings) == 1

    def test_regex_without_all_patterns(self):
        findings = _scan_content(
            {"id": "BC-004", "name": "no-print", "type": "regex",
             "pattern": r"\bprint\s*\(", "severity": "medium", "file_glob": "**/*.py"},
            "test.py", "print('hello')\n",
        )
        assert len(findings) == 1
