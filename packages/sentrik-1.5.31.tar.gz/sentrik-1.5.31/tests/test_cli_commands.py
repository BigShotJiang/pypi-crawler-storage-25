"""Tests for CLI commands not covered in test_smoke.py.

Targets: sync (Azure + GitHub), list-packs, add-pack, remove-pack,
serve, gate failure via CLI, report with --output, compare edge cases,
scan --staged, validate-config warnings-only, and reconcile.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from guard.cli import app
from guard.config import GuardConfig
from guard.core.models import Evidence, Finding, Severity, WorkItem

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helper: set up a minimal guard project
# ---------------------------------------------------------------------------


def _setup_project(tmp_path: Path, *, config_overrides: dict | None = None) -> None:
    """Create .guard.yaml + sample data in *tmp_path*."""
    defaults = {"output_dir": str(tmp_path / "out")}
    if config_overrides:
        defaults.update(config_overrides)
    config = GuardConfig(**defaults)
    config.save(tmp_path / ".guard.yaml")

    examples = tmp_path / "examples"
    examples.mkdir(exist_ok=True)
    (examples / "sample_work_items.json").write_text("[]")
    (examples / "sample_standards.yaml").write_text("rules: []")


def _setup_work_items(tmp_path: Path, items: list[dict]) -> str:
    """Write work items and return the relative path."""
    wi_path = tmp_path / "work_items.json"
    wi_path.write_text(json.dumps(items))
    return "work_items.json"


# ---------------------------------------------------------------------------
# list-packs
# ---------------------------------------------------------------------------


class TestListPacks:
    def test_list_packs_shows_available(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["list-packs"])
        assert result.exit_code == 0
        assert "fda-iec-62304" in result.output
        assert "available" in result.output.lower()

    def test_list_packs_shows_enabled(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"standards_packs": ["fda-iec-62304"]})
        result = runner.invoke(app, ["list-packs"])
        assert result.exit_code == 0
        assert "ENABLED" in result.output


# ---------------------------------------------------------------------------
# add-pack
# ---------------------------------------------------------------------------


class TestAddPack:
    def test_add_pack_success(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["add-pack", "owasp-top-10"])
        assert result.exit_code == 0
        assert "Added pack" in result.output

        # Verify it was persisted
        config = GuardConfig.load(tmp_path / ".guard.yaml")
        assert "owasp-top-10" in config.standards_packs

    def test_add_pack_already_enabled(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"standards_packs": ["fda-iec-62304"]})
        result = runner.invoke(app, ["add-pack", "fda-iec-62304"])
        assert result.exit_code == 0
        assert "already enabled" in result.output

    def test_add_pack_unknown(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["add-pack", "nonexistent-pack"])
        assert result.exit_code == 1
        assert "unknown pack" in result.output.lower()


# ---------------------------------------------------------------------------
# remove-pack
# ---------------------------------------------------------------------------


class TestRemovePack:
    def test_remove_pack_success(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"standards_packs": ["fda-iec-62304"]})
        result = runner.invoke(app, ["remove-pack", "fda-iec-62304"])
        assert result.exit_code == 0
        assert "Removed pack" in result.output

        # Verify it was persisted
        config = GuardConfig.load(tmp_path / ".guard.yaml")
        assert "fda-iec-62304" not in config.standards_packs

    def test_remove_pack_not_enabled(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["remove-pack", "fda-iec-62304"])
        assert result.exit_code == 0
        assert "not currently enabled" in result.output


# ---------------------------------------------------------------------------
# serve
# ---------------------------------------------------------------------------


class TestServe:
    def test_serve_import_error(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        # Mock the import inside serve() to raise ImportError
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "uvicorn":
                raise ImportError("no uvicorn")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)

        result = runner.invoke(app, ["dashboard"])
        assert result.exit_code == 1
        assert "FastAPI" in result.output or "Uvicorn" in result.output

    def test_serve_with_uvicorn_installed(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        mock_run = MagicMock()
        mock_uvicorn = MagicMock()
        mock_uvicorn.run = mock_run

        import sys
        monkeypatch.setitem(sys.modules, "uvicorn", mock_uvicorn)

        result = runner.invoke(app, ["dashboard", "--port", "9090"])
        assert result.exit_code == 0
        mock_run.assert_called_once_with(
            "guard.server:app", host="127.0.0.1", port=9090, reload=False,
        )


# ---------------------------------------------------------------------------
# gate failure through CLI
# ---------------------------------------------------------------------------


class TestGateFailure:
    def test_gate_fails_on_critical_finding(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        src = tmp_path / "src"
        src.mkdir()
        (src / "app.py").write_text('import os\neval("dangerous")\n', encoding="utf-8")

        rules_yaml = (
            "rules:\n"
            '  - id: "R-eval"\n'
            '    name: "no-eval"\n'
            '    type: "regex"\n'
            '    pattern: "\\\\beval\\\\s*\\\\("\n'
            '    severity: "critical"\n'
            '    file_glob: "**/*.py"\n'
        )
        examples = tmp_path / "examples"
        (examples / "sample_standards.yaml").write_text(rules_yaml)

        result = runner.invoke(app, ["gate"])
        assert result.exit_code == 1
        assert "GATE FAILED" in result.output
        assert "critical=1" in result.output


# ---------------------------------------------------------------------------
# report with --output
# ---------------------------------------------------------------------------


class TestReportOutput:
    def test_report_custom_output_path(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        out = tmp_path / "out"
        out.mkdir(parents=True)
        (out / "findings.json").write_text("[]", encoding="utf-8")

        custom_path = tmp_path / "custom" / "my_report.html"
        result = runner.invoke(app, ["report", "--format", "html", "--output", str(custom_path)])
        assert result.exit_code == 0
        assert custom_path.exists()
        assert "Report written to" in result.output

    def test_report_sarif_format(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        out = tmp_path / "out"
        out.mkdir(parents=True)
        (out / "findings.json").write_text("[]", encoding="utf-8")

        result = runner.invoke(app, ["report", "--format", "sarif"])
        assert result.exit_code == 0
        assert (out / "report.sarif.json").exists()


# ---------------------------------------------------------------------------
# compare edge cases
# ---------------------------------------------------------------------------


class TestCompareEdgeCases:
    def test_compare_previous_file_not_found(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        out = tmp_path / "out"
        out.mkdir(parents=True)
        (out / "findings.json").write_text("[]", encoding="utf-8")

        result = runner.invoke(app, ["compare", "--previous", str(tmp_path / "nonexistent.json")])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_compare_no_current_findings(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        result = runner.invoke(app, ["compare", "--previous", "dummy.json"])
        assert result.exit_code == 1
        assert "No findings.json found" in result.output


# ---------------------------------------------------------------------------
# scan --staged
# ---------------------------------------------------------------------------


class TestScanStaged:
    def test_scan_staged_flag(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        monkeypatch.setattr(
            "guard.cli.get_staged_files",
            lambda repo_root: ["staged_file.py"],
        )

        result = runner.invoke(app, ["scan", "--staged"])
        assert result.exit_code == 0
        assert "Scope: 1 staged file(s)" in result.output


# ---------------------------------------------------------------------------
# validate-config warnings only
# ---------------------------------------------------------------------------


class TestValidateConfigWarnings:
    def test_validate_config_warnings_no_errors(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig(
            output_dir=str(tmp_path / "out"),
            standards_file="nonexistent.yaml",
        )
        config.save(tmp_path / ".guard.yaml")

        result = runner.invoke(app, ["validate-config"])
        if "ERROR" in result.output:
            assert result.exit_code == 1
        else:
            assert result.exit_code == 0
            assert "warning" in result.output.lower()


# ---------------------------------------------------------------------------
# sync command — Azure DevOps
# ---------------------------------------------------------------------------


class TestSyncAzure:
    def test_sync_azure_no_pat(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"devops_provider": "azure"})
        monkeypatch.delenv("AZURE_DEVOPS_PAT", raising=False)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "AZURE_DEVOPS_PAT" in result.output

    def test_sync_azure_no_org(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "",
            "azure_devops_project": "",
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "azure_devops_org" in result.output

    def test_sync_azure_no_work_items_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": "nonexistent.json",
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_sync_azure_processes_work_items(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Test item", "state": "closed"},
            {"id": "WI-2", "title": "Unknown state", "state": "weird"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp_wiql = MagicMock()
        mock_resp_wiql.status_code = 200
        mock_resp_wiql.json.return_value = {"workItems": [{"id": 42}]}

        mock_resp_detail = MagicMock()
        mock_resp_detail.status_code = 200
        mock_resp_detail.json.return_value = {"fields": {"System.State": "Doing"}}

        mock_resp_patch = MagicMock()
        mock_resp_patch.status_code = 200

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp_wiql
        mock_requests.get.return_value = mock_resp_detail
        mock_requests.patch.return_value = mock_resp_patch

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Done:" in result.output
        assert "SKIP" in result.output  # WI-2 with unknown state

    def test_sync_azure_wiql_failure(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.text = "Unauthorized"

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "failed" in result.output.lower()

    def test_sync_azure_no_matches(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"workItems": []}

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "skipped" in result.output.lower()

    def test_sync_azure_multiple_matches(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"workItems": [{"id": 1}, {"id": 2}]}

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Multiple matches" in result.output

    def test_sync_azure_already_correct_state(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "closed"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp_wiql = MagicMock()
        mock_resp_wiql.status_code = 200
        mock_resp_wiql.json.return_value = {"workItems": [{"id": 42}]}

        mock_resp_detail = MagicMock()
        mock_resp_detail.status_code = 200
        mock_resp_detail.json.return_value = {"fields": {"System.State": "Done"}}

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp_wiql
        mock_requests.get.return_value = mock_resp_detail

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Already" in result.output

    def test_sync_azure_detail_fetch_failure(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp_wiql = MagicMock()
        mock_resp_wiql.status_code = 200
        mock_resp_wiql.json.return_value = {"workItems": [{"id": 42}]}

        mock_resp_detail = MagicMock()
        mock_resp_detail.status_code = 500

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp_wiql
        mock_requests.get.return_value = mock_resp_detail

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "1 failed" in result.output

    def test_sync_azure_patch_failure(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "closed"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "azure",
            "azure_devops_org": "myorg",
            "azure_devops_project": "myproj",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("AZURE_DEVOPS_PAT", "test-token")

        mock_resp_wiql = MagicMock()
        mock_resp_wiql.status_code = 200
        mock_resp_wiql.json.return_value = {"workItems": [{"id": 42}]}

        mock_resp_detail = MagicMock()
        mock_resp_detail.status_code = 200
        mock_resp_detail.json.return_value = {"fields": {"System.State": "Doing"}}

        mock_resp_patch = MagicMock()
        mock_resp_patch.status_code = 403
        mock_resp_patch.text = "Forbidden"

        mock_requests = MagicMock()
        mock_requests.post.return_value = mock_resp_wiql
        mock_requests.get.return_value = mock_resp_detail
        mock_requests.patch.return_value = mock_resp_patch

        with patch.dict("sys.modules", {"requests": mock_requests}):
            result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "PATCH failed" in result.output


# ---------------------------------------------------------------------------
# sync command — GitHub
# ---------------------------------------------------------------------------


class TestSyncGitHub:
    def test_sync_github_no_token(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"devops_provider": "github"})
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "GITHUB_TOKEN" in result.output

    def test_sync_github_no_owner(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "",
            "github_repo": "",
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "github_owner" in result.output

    def test_sync_github_no_work_items_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": "nonexistent.json",
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_sync_github_processes_work_items(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Test item", "state": "closed"},
            {"id": "WI-2", "title": "Other item", "state": "weird"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        search_resp = MagicMock()
        search_resp.read.return_value = json.dumps({
            "items": [{"title": "Test item", "number": 5, "state": "open"}]
        }).encode()
        search_resp.__enter__ = lambda s: s
        search_resp.__exit__ = MagicMock(return_value=False)

        patch_resp = MagicMock()
        patch_resp.status = 200
        patch_resp.__enter__ = lambda s: s
        patch_resp.__exit__ = MagicMock(return_value=False)

        def mock_urlopen(req):
            if "search" in req.full_url:
                return search_resp
            return patch_resp

        monkeypatch.setattr("urllib.request.urlopen", mock_urlopen)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Done:" in result.output
        assert "SKIP" in result.output  # WI-2 with unknown state

    def test_sync_github_no_matches(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        search_resp = MagicMock()
        search_resp.read.return_value = json.dumps({"items": []}).encode()
        search_resp.__enter__ = lambda s: s
        search_resp.__exit__ = MagicMock(return_value=False)

        monkeypatch.setattr("urllib.request.urlopen", lambda req: search_resp)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "No GitHub issue found" in result.output

    def test_sync_github_search_error(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        import urllib.error

        def mock_urlopen(req):
            raise urllib.error.HTTPError(req.full_url, 500, "Server Error", {}, None)

        monkeypatch.setattr("urllib.request.urlopen", mock_urlopen)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Search failed" in result.output

    def test_sync_github_already_correct_state(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "closed"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        search_resp = MagicMock()
        search_resp.read.return_value = json.dumps({
            "items": [{"title": "Item", "number": 10, "state": "closed"}]
        }).encode()
        search_resp.__enter__ = lambda s: s
        search_resp.__exit__ = MagicMock(return_value=False)

        monkeypatch.setattr("urllib.request.urlopen", lambda req: search_resp)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Already" in result.output

    def test_sync_github_multiple_matches(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "active"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        search_resp = MagicMock()
        search_resp.read.return_value = json.dumps({
            "items": [
                {"title": "Item", "number": 1, "state": "open"},
                {"title": "Item", "number": 2, "state": "open"},
            ]
        }).encode()
        search_resp.__enter__ = lambda s: s
        search_resp.__exit__ = MagicMock(return_value=False)

        monkeypatch.setattr("urllib.request.urlopen", lambda req: search_resp)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "Multiple matches" in result.output

    def test_sync_github_patch_error(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wi_file = _setup_work_items(tmp_path, [
            {"id": "WI-1", "title": "Item", "state": "closed"},
        ])
        _setup_project(tmp_path, config_overrides={
            "devops_provider": "github",
            "github_owner": "testuser",
            "github_repo": "testrepo",
            "work_items_file": wi_file,
        })
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        import urllib.error

        search_resp = MagicMock()
        search_resp.read.return_value = json.dumps({
            "items": [{"title": "Item", "number": 5, "state": "open"}]
        }).encode()
        search_resp.__enter__ = lambda s: s
        search_resp.__exit__ = MagicMock(return_value=False)

        call_count = {"n": 0}

        def mock_urlopen(req):
            call_count["n"] += 1
            if "search" in req.full_url:
                return search_resp
            raise urllib.error.HTTPError(req.full_url, 403, "Forbidden", {}, None)

        monkeypatch.setattr("urllib.request.urlopen", mock_urlopen)

        result = runner.invoke(app, ["sync"])
        assert result.exit_code == 0
        assert "PATCH failed" in result.output


# ---------------------------------------------------------------------------
# list-rules with pack rules
# ---------------------------------------------------------------------------


class TestListRulesWithPacks:
    def test_list_rules_with_owasp_pack(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path, config_overrides={"standards_packs": ["owasp-top-10"]})

        result = runner.invoke(app, ["list-rules"])
        assert result.exit_code == 0
        assert "OWASP" in result.output
        assert "Total:" in result.output

    def test_list_rules_empty(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)

        result = runner.invoke(app, ["list-rules"])
        assert result.exit_code == 0
        assert "Total:" in result.output


# ---------------------------------------------------------------------------
# reconcile command
# ---------------------------------------------------------------------------


class TestReconcileCommand:
    def _setup_reconcile_project(self, tmp_path, work_items=None):
        """Set up a project with work items for reconcile testing."""
        from datetime import date, timedelta
        from guard.core.licensing import generate_key
        wi = work_items or []
        wi_path = tmp_path / "work_items.json"
        wi_path.write_text(json.dumps(wi))
        # Reconcile requires TEAM+ tier
        key = generate_key("TEAM", date.today() + timedelta(days=365))
        _setup_project(tmp_path, config_overrides={
            "work_items_file": "work_items.json",
            "license_key": key,
        })

    def test_reconcile_dry_run_no_actions(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self._setup_reconcile_project(tmp_path)

        result = runner.invoke(app, ["reconcile", "--dry-run"])
        assert result.exit_code == 0
        assert "No reconcile actions" in result.output

    def test_reconcile_dry_run_with_findings(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self._setup_reconcile_project(tmp_path)

        # Create a file with eval to trigger a finding
        src = tmp_path / "src"
        src.mkdir()
        (src / "bad.py").write_text('eval("x")\n', encoding="utf-8")

        rules_yaml = (
            "rules:\n"
            '  - id: "R-eval"\n'
            '    name: "no-eval"\n'
            '    type: "regex"\n'
            '    pattern: "\\\\beval\\\\s*\\\\("\n'
            '    severity: "critical"\n'
            '    file_glob: "**/*.py"\n'
        )
        examples = tmp_path / "examples"
        (examples / "sample_standards.yaml").write_text(rules_yaml)

        result = runner.invoke(app, ["reconcile", "--dry-run"])
        assert result.exit_code == 0
        assert "CREATE" in result.output
        assert "R-eval" in result.output

    def test_reconcile_execute_creates_wi(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self._setup_reconcile_project(tmp_path)

        src = tmp_path / "src"
        src.mkdir()
        (src / "bad.py").write_text('eval("x")\n', encoding="utf-8")

        rules_yaml = (
            "rules:\n"
            '  - id: "R-eval"\n'
            '    name: "no-eval"\n'
            '    type: "regex"\n'
            '    pattern: "\\\\beval\\\\s*\\\\("\n'
            '    severity: "critical"\n'
            '    file_glob: "**/*.py"\n'
        )
        examples = tmp_path / "examples"
        (examples / "sample_standards.yaml").write_text(rules_yaml)

        result = runner.invoke(app, ["reconcile"])
        assert result.exit_code == 0
        assert "1 created" in result.output

        # Verify work_items.json was updated
        wi_data = json.loads((tmp_path / "work_items.json").read_text())
        assert len(wi_data) == 1
        assert wi_data[0]["rule_id"] == "R-eval"

    def test_reconcile_closes_resolved(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self._setup_reconcile_project(tmp_path, work_items=[
            {"id": "WI-1", "title": "Old finding", "state": "active", "rule_id": "R-GONE"},
        ])

        result = runner.invoke(app, ["reconcile"])
        assert result.exit_code == 0
        assert "1 closed" in result.output

        wi_data = json.loads((tmp_path / "work_items.json").read_text())
        assert wi_data[0]["state"] == "closed"


# ===================================================================
# guard init wizard
# ===================================================================


class TestInitWizard:
    def test_no_interactive_creates_default_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init", "--no-interactive"])
        assert result.exit_code == 0
        assert (tmp_path / ".sentrik" / "config.yaml").exists()
        assert "Initialized config" in result.output

    def test_interactive_wizard_default_answers(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Provide default answers: 1 (stub), 1 (web/OWASP), 1 (standard), "out", "html", n (no precommit)
        result = runner.invoke(app, ["init"], input="1\n1\n1\nout\nhtml\nn\n")
        assert result.exit_code == 0
        assert (tmp_path / ".sentrik" / "config.yaml").exists()
        import yaml
        with open(tmp_path / ".sentrik" / "config.yaml") as f:
            data = yaml.safe_load(f)
        assert data["devops_provider"] == "stub"
        assert "owasp-top-10" in data.get("standards_packs", [])
        assert data["governance"]["profile"] == "standard"

    def test_interactive_wizard_strict_profile(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # stub platform, medical project, strict profile, n for precommit
        result = runner.invoke(app, ["init"], input="1\n2\n2\nout\nhtml\nn\n")
        assert result.exit_code == 0
        import yaml
        with open(tmp_path / ".sentrik" / "config.yaml") as f:
            data = yaml.safe_load(f)
        assert "fda-iec-62304" in data.get("standards_packs", [])
        assert data["governance"]["profile"] == "strict"

    def test_interactive_wizard_azure_devops(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Azure DevOps, web project, standard profile, n for precommit
        result = runner.invoke(app, ["init"], input="2\nmyorg\nmyproj\nmyteam\n1\n1\nout\nhtml\nn\n")
        assert result.exit_code == 0
        import yaml
        with open(tmp_path / ".sentrik" / "config.yaml") as f:
            data = yaml.safe_load(f)
        assert data["devops_provider"] == "azure"
        assert data["azure_devops_org"] == "myorg"
        assert data["azure_devops_project"] == "myproj"
        assert "AZURE_DEVOPS_PAT" in result.output

    def test_interactive_wizard_github(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # GitHub, SOC2 project, permissive, n for precommit
        result = runner.invoke(app, ["init"], input="3\nmyowner\nmyrepo\n3\n3\nout\nhtml\nn\n")
        assert result.exit_code == 0
        import yaml
        with open(tmp_path / ".sentrik" / "config.yaml") as f:
            data = yaml.safe_load(f)
        assert data["devops_provider"] == "github"
        assert data["github_owner"] == "myowner"
        assert data["governance"]["profile"] == "permissive"
        assert "GITHUB_TOKEN" in result.output


# ---------------------------------------------------------------------------
# Init wizard upgrade: auto-detection + pre-commit + env example
# ---------------------------------------------------------------------------


class TestInitWizardUpgrade:
    def test_detect_github_from_github_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".github").mkdir()
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["platform"] == "github"

    def test_detect_azure_from_pipeline_yml(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "azure-pipelines.yml").write_text("trigger:\n  - main\n")
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["platform"] == "azure"

    def test_detect_python_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'test'\n")
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["language"] == "python"

    def test_detect_node_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "package.json").write_text('{"name": "test"}')
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["language"] == "node"

    def test_detect_medical_from_readme(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "README.md").write_text("# App\nFollows IEC 62304 standard\n")
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["project_type"] == "2"

    def test_detect_no_platform(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.cli import _detect_project_context
        hints = _detect_project_context()
        assert hints["platform"] is None

    def test_precommit_config_created(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.cli import _create_precommit_config
        result = _create_precommit_config()
        assert result is True
        assert (tmp_path / ".pre-commit-config.yaml").exists()
        content = (tmp_path / ".pre-commit-config.yaml").read_text()
        assert "sentrik pre-commit-scan" in content

    def test_precommit_config_not_overwritten(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".pre-commit-config.yaml").write_text("existing: true\n")
        from guard.cli import _create_precommit_config
        result = _create_precommit_config()
        assert result is False
        assert (tmp_path / ".pre-commit-config.yaml").read_text() == "existing: true\n"

    def test_env_example_created(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.cli import _create_env_example
        result = _create_env_example("azure")
        assert result is True
        content = (tmp_path / ".env.example").read_text()
        assert "AZURE_DEVOPS_PAT" in content

    def test_env_example_github(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.cli import _create_env_example
        result = _create_env_example("github")
        assert result is True
        content = (tmp_path / ".env.example").read_text()
        assert "GITHUB_TOKEN" in content

    def test_env_example_not_overwritten(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".env.example").write_text("EXISTING=true\n")
        from guard.cli import _create_env_example
        result = _create_env_example("azure")
        assert result is False
        assert (tmp_path / ".env.example").read_text() == "EXISTING=true\n"


# ---------------------------------------------------------------------------
# CLI polish: Rich output in scan, gate, validate-config, init
# ---------------------------------------------------------------------------


class TestCLIPolish:
    def test_scan_output_contains_hint(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["scan"])
        assert result.exit_code == 0
        assert "sentrik gate" in result.output

    def test_gate_passed_output(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["gate"])
        assert "PASSED" in result.output

    def test_validate_config_success(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        _setup_project(tmp_path)
        result = runner.invoke(app, ["validate-config"])
        assert result.exit_code == 0
        assert "valid" in result.output.lower()

    def test_init_shows_next_step(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["init"], input="1\n1\n1\nout\nhtml\nn\n")
        assert result.exit_code == 0
        assert "scan" in result.output.lower()
