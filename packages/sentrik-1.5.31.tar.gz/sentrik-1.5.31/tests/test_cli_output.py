"""Tests for the cli_output Rich helper module."""

from __future__ import annotations

from guard.cli_output import (
    GUARD_THEME,
    HINTS,
    SEV_STYLES,
    severity_label,
)


class TestCliOutput:
    def test_severity_label_returns_styled_string(self):
        result = severity_label("critical")
        assert "critical" in result
        assert "bold red" in result

    def test_sev_styles_has_all_levels(self):
        expected = {"critical", "high", "medium", "low", "info"}
        assert expected == set(SEV_STYLES.keys())

    def test_hints_has_expected_commands(self):
        expected = {
            "init", "scan", "gate_passed", "gate_failed", "reconcile", "validate_config",
            "migrate", "context", "trace", "generate_reqs", "verify_reqs", "pull_reqs",
            "apply_patches",
            "list_packs", "add_pack", "remove_pack", "approve", "export_audit", "license",
            "compliance_report", "history_report", "trust_center", "evidence_export",
            "watch", "sbom", "org_dashboard", "vulns", "licenses", "impact", "analyze_cpp",
            "grc_push", "check_policies", "check_arch", "check_inline",
        }
        assert expected == set(HINTS.keys())

    def test_guard_theme_is_valid(self):
        # Theme should have styles for all severity levels plus base styles
        assert "success" in GUARD_THEME.styles
        assert "error" in GUARD_THEME.styles
        assert "hint" in GUARD_THEME.styles
        assert "sev.critical" in GUARD_THEME.styles
        assert "sev.info" in GUARD_THEME.styles
