"""Tests for scripts/sync_work_items.py — all HTTP calls are mocked."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env
import yaml

# Import the module under test
import importlib
import sys
from pathlib import Path

# Ensure the scripts directory is importable
SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"


@pytest.fixture()
def _import_sync():
    """Import sync_work_items as a module."""
    spec = importlib.util.spec_from_file_location(
        "sync_work_items", SCRIPTS_DIR / "sync_work_items.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------
# load_config
# ---------------------------------------------------------------------------

class TestLoadConfig:
    def test_reads_org_and_project(self, tmp_path, _import_sync):
        config_file = tmp_path / ".guard.yaml"
        config_file.write_text(
            yaml.dump({
                "azure_devops_org": "myorg",
                "azure_devops_project": "MyProject",
            })
        )
        org, project = _import_sync.load_config(str(config_file))
        assert org == "myorg"
        assert project == "MyProject"


# ---------------------------------------------------------------------------
# load_work_items
# ---------------------------------------------------------------------------

class TestLoadWorkItems:
    def test_reads_work_items(self, tmp_path, _import_sync):
        items = [
            {"id": "WI-1", "title": "Task A", "state": "active"},
            {"id": "WI-2", "title": "Task B", "state": "closed"},
        ]
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text(json.dumps(items))
        result = _import_sync.load_work_items(str(wi_file))
        assert result == items


# ---------------------------------------------------------------------------
# find_work_item_by_title
# ---------------------------------------------------------------------------

class TestFindWorkItemByTitle:
    def test_single_match(self, _import_sync):
        wiql_response = MagicMock()
        wiql_response.status_code = 200
        wiql_response.json.return_value = {"workItems": [{"id": 42}]}

        detail_response = MagicMock()
        detail_response.status_code = 200
        detail_response.json.return_value = {
            "fields": {"System.State": "Active"}
        }

        with patch.object(_import_sync.requests, "post", return_value=wiql_response):
            with patch.object(_import_sync.requests, "get", return_value=detail_response):
                result = _import_sync.find_work_item_by_title(
                    "My Task", "org", "proj", "pat"
                )

        assert result == (42, "Active")

    def test_no_match(self, _import_sync):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"workItems": []}

        with patch.object(_import_sync.requests, "post", return_value=resp):
            result = _import_sync.find_work_item_by_title(
                "Missing", "org", "proj", "pat"
            )

        assert result is None

    def test_multiple_matches_skipped(self, _import_sync):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"workItems": [{"id": 1}, {"id": 2}]}

        with patch.object(_import_sync.requests, "post", return_value=resp):
            result = _import_sync.find_work_item_by_title(
                "Ambiguous", "org", "proj", "pat"
            )

        assert result is None

    def test_api_error(self, _import_sync):
        resp = MagicMock()
        resp.status_code = 401
        resp.text = "Unauthorized"

        with patch.object(_import_sync.requests, "post", return_value=resp):
            result = _import_sync.find_work_item_by_title(
                "Task", "org", "proj", "bad-pat"
            )

        assert result is None


# ---------------------------------------------------------------------------
# update_work_item_state
# ---------------------------------------------------------------------------

class TestUpdateWorkItemState:
    def test_success(self, _import_sync):
        resp = MagicMock()
        resp.status_code = 200

        with patch.object(_import_sync.requests, "patch", return_value=resp) as mock_patch:
            ok = _import_sync.update_work_item_state(42, "Done", "org", "proj", "pat")

        assert ok is True
        call_kwargs = mock_patch.call_args
        assert call_kwargs.kwargs["headers"]["Content-Type"] == "application/json-patch+json"
        payload = call_kwargs.kwargs["json"]
        assert payload[0]["value"] == "Done"

    def test_failure(self, _import_sync):
        resp = MagicMock()
        resp.status_code = 400
        resp.text = "Bad Request"

        with patch.object(_import_sync.requests, "patch", return_value=resp):
            ok = _import_sync.update_work_item_state(42, "Done", "org", "proj", "pat")

        assert ok is False


# ---------------------------------------------------------------------------
# main (end-to-end with mocks)
# ---------------------------------------------------------------------------

class TestMain:
    def test_missing_pat_exits(self, _import_sync):
        with patch.dict("os.environ", _home_env(), clear=True):
            # Ensure AZURE_DEVOPS_PAT is not set
            import os
            env = os.environ.copy()
            env.pop("AZURE_DEVOPS_PAT", None)
            with patch.dict("os.environ", env, clear=True):
                with pytest.raises(SystemExit) as exc:
                    _import_sync.main()
                assert exc.value.code == 1

    def test_end_to_end_sync(self, tmp_path, _import_sync):
        # Write config and work items to tmp_path
        config_file = tmp_path / ".guard.yaml"
        config_file.write_text(
            yaml.dump({
                "azure_devops_org": "testorg",
                "azure_devops_project": "TestProj",
            })
        )
        wi_file = tmp_path / "work_items.json"
        wi_file.write_text(
            json.dumps([
                {"id": "WI-1", "title": "Task A", "state": "active"},
                {"id": "WI-2", "title": "Task B", "state": "closed"},
            ])
        )

        # Mock the lower-level functions
        with patch.dict("os.environ", {"AZURE_DEVOPS_PAT": "fake-pat"}):
            with patch.object(
                _import_sync, "load_config", return_value=("testorg", "TestProj")
            ):
                with patch.object(
                    _import_sync,
                    "load_work_items",
                    return_value=[
                        {"id": "WI-1", "title": "Task A", "state": "active"},
                        {"id": "WI-2", "title": "Task B", "state": "closed"},
                    ],
                ):
                    with patch.object(
                        _import_sync,
                        "find_work_item_by_title",
                        side_effect=[
                            (100, "To Do"),    # Task A: needs update
                            (200, "Done"),     # Task B: already correct
                        ],
                    ):
                        with patch.object(
                            _import_sync,
                            "update_work_item_state",
                            return_value=True,
                        ) as mock_update:
                            _import_sync.main()

        # Only Task A should have been updated (To Do -> Doing)
        mock_update.assert_called_once_with(
            100, "Doing", "testorg", "TestProj", "fake-pat"
        )
