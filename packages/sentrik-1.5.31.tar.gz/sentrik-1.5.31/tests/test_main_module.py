"""Tests for the __main__.py module (python -m guard support)."""

from __future__ import annotations

import subprocess
import sys


class TestMainModule:
    def test_main_importable(self):
        """__main__ module should be importable."""
        import guard.__main__  # noqa: F401

    def test_python_m_guard_help(self):
        """python -m guard --help should succeed."""
        env = {**__import__("os").environ, "PYTHONIOENCODING": "utf-8"}
        result = subprocess.run(
            [sys.executable, "-m", "guard", "--help"],
            capture_output=True,
            timeout=30,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        assert result.returncode == 0
        assert "sentrik" in result.stdout.lower() or "guard" in result.stdout.lower() or "usage" in result.stdout.lower()

    def test_python_m_guard_license(self):
        """python -m guard license should succeed."""
        result = subprocess.run(
            [sys.executable, "-m", "guard", "license"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0
        assert "license" in result.stdout.lower() or "tier" in result.stdout.lower()
