"""Tests for LLMAnthropic provider — all API calls are mocked."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.providers.llm_anthropic import LLMAnthropic


# ---------------------------------------------------------------------------
# _parse_response
# ---------------------------------------------------------------------------

class TestParseResponse:
    def test_valid_json(self):
        text = '{"findings": [{"rule_id": "SEC-1", "severity": "high"}], "summary": "ok"}'
        result = LLMAnthropic._parse_response(text)
        assert len(result["findings"]) == 1
        assert result["findings"][0]["rule_id"] == "SEC-1"

    def test_json_with_surrounding_text(self):
        text = 'Here is the analysis:\n{"findings": [], "summary": "clean"}\nDone.'
        result = LLMAnthropic._parse_response(text)
        assert result["findings"] == []
        assert result["summary"] == "clean"

    def test_no_json_returns_empty(self):
        result = LLMAnthropic._parse_response("No JSON here.")
        assert result["findings"] == []

    def test_invalid_json_returns_empty(self):
        result = LLMAnthropic._parse_response("{broken json")
        assert result["findings"] == []

    def test_missing_findings_key(self):
        result = LLMAnthropic._parse_response('{"summary": "no findings key"}')
        assert result["findings"] == []


# ---------------------------------------------------------------------------
# analyze
# ---------------------------------------------------------------------------

class TestAnalyze:
    def test_missing_api_key(self):
        with patch.dict("os.environ", _home_env(), clear=True):
            provider = LLMAnthropic()
            result = provider.analyze("check this", {"file": "x.py", "content": "pass"})
        assert result["findings"] == []
        assert "No API key" in result["summary"]

    def test_successful_call(self):
        resp_body = {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({
                        "findings": [{"rule_id": "BUG-1", "severity": "medium", "message": "issue"}],
                        "summary": "1 issue found",
                    }),
                }
            ]
        }
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = resp_body

        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "sk-test"}):
            provider = LLMAnthropic()
            with patch("guard.providers.llm_anthropic.requests.post", return_value=mock_resp) as mock_post:
                result = provider.analyze("analyze", {"file": "app.py", "content": "x = 1"})

        assert len(result["findings"]) == 1
        assert result["findings"][0]["rule_id"] == "BUG-1"
        # Verify API call
        call_kwargs = mock_post.call_args
        assert "x-api-key" in call_kwargs.kwargs["headers"]

    def test_api_error_status(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text = "Internal Server Error"

        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "sk-test"}):
            provider = LLMAnthropic()
            with patch("guard.providers.llm_anthropic.requests.post", return_value=mock_resp):
                result = provider.analyze("analyze", {"file": "a.py", "content": ""})

        assert result["findings"] == []
        assert "500" in result["summary"]

    def test_request_exception(self):
        import requests as req

        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "sk-test"}):
            provider = LLMAnthropic()
            with patch(
                "guard.providers.llm_anthropic.requests.post",
                side_effect=req.ConnectionError("offline"),
            ):
                result = provider.analyze("analyze", {"file": "a.py", "content": ""})

        assert result["findings"] == []


# ---------------------------------------------------------------------------
# Factory integration
# ---------------------------------------------------------------------------

class TestFactoryIntegration:
    def test_anthropic_provider_built(self):
        from guard.config import GuardConfig
        from guard.providers.factory import build_llm

        config = GuardConfig(llm_provider="anthropic")
        provider = build_llm(config)
        assert isinstance(provider, LLMAnthropic)

    def test_stub_still_default(self):
        from guard.config import GuardConfig
        from guard.providers.factory import build_llm
        from guard.providers.llm_stub import LLMStub

        config = GuardConfig()
        provider = build_llm(config)
        assert isinstance(provider, LLMStub)

    def test_config_validates_anthropic(self):
        from guard.config import GuardConfig

        config = GuardConfig(llm_provider="anthropic")
        warnings = config.validate_config()
        llm_errors = [w for w in warnings if w.field == "llm_provider"]
        assert llm_errors == []
