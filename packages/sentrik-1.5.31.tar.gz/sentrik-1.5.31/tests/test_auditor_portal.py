"""Tests for auditor portal — token management and server endpoints."""

from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from guard.core.auditor_portal import (
    ALL_SCOPES,
    AuditorToken,
    generate_auditor_token,
    list_auditor_tokens,
    revoke_auditor_token,
    revoke_by_prefix,
    validate_auditor_token,
)


# ── Fixtures ──────────────────────────────────────────────────────────

@pytest.fixture()
def token_file(tmp_path):
    """Return a temp path for auditor tokens."""
    return tmp_path / "auditor_tokens.json"


# ===================================================================
# Token management unit tests
# ===================================================================


class TestGenerateToken:
    def test_generate_token(self, token_file):
        tok = generate_auditor_token(
            "Jane Smith", "jane@auditor.com", _storage=token_file,
        )
        assert tok.auditor_name == "Jane Smith"
        assert tok.auditor_email == "jane@auditor.com"
        assert len(tok.token) > 20
        assert tok.access_scope == ALL_SCOPES

        # Verify persisted
        raw = json.loads(token_file.read_text(encoding="utf-8"))
        assert len(raw) == 1
        assert raw[0]["token"] == tok.token

    def test_generate_token_custom_scope(self, token_file):
        tok = generate_auditor_token(
            "Bob", "bob@example.com",
            scope=["findings", "compliance"],
            _storage=token_file,
        )
        assert tok.access_scope == ["findings", "compliance"]

    def test_generate_token_custom_hours(self, token_file):
        tok = generate_auditor_token(
            "Alice", "alice@example.com",
            expires_hours=24,
            _storage=token_file,
        )
        created = datetime.strptime(tok.created_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        expires = datetime.strptime(tok.expires_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        delta = expires - created
        assert 23 <= delta.total_seconds() / 3600 <= 25  # ~24 hours


class TestTokenValidation:
    def test_valid_token_accepted(self, token_file):
        tok = generate_auditor_token("A", "a@a.com", _storage=token_file)
        result = validate_auditor_token(tok.token, _storage=token_file)
        assert result is not None
        assert result.token == tok.token
        assert result.auditor_name == "A"

    def test_invalid_token_rejected(self, token_file):
        generate_auditor_token("A", "a@a.com", _storage=token_file)
        result = validate_auditor_token("bogus-token", _storage=token_file)
        assert result is None

    def test_expired_token_rejected(self, token_file):
        # Create a token that expires in 0 hours (already expired)
        tok = generate_auditor_token("A", "a@a.com", expires_hours=0, _storage=token_file)
        # Manually set expiry to the past
        raw = json.loads(token_file.read_text(encoding="utf-8"))
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        raw[0]["expires_at"] = past
        token_file.write_text(json.dumps(raw), encoding="utf-8")

        result = validate_auditor_token(tok.token, _storage=token_file)
        assert result is None

    def test_empty_storage_returns_none(self, token_file):
        result = validate_auditor_token("anything", _storage=token_file)
        assert result is None


class TestRevokeToken:
    def test_revoke_existing_token(self, token_file):
        tok = generate_auditor_token("A", "a@a.com", _storage=token_file)
        assert revoke_auditor_token(tok.token, _storage=token_file) is True
        # Verify it's gone
        assert validate_auditor_token(tok.token, _storage=token_file) is None

    def test_revoke_nonexistent_token(self, token_file):
        assert revoke_auditor_token("nope", _storage=token_file) is False

    def test_revoke_by_prefix(self, token_file):
        tok1 = generate_auditor_token("A", "a@a.com", _storage=token_file)
        tok2 = generate_auditor_token("B", "b@b.com", _storage=token_file)
        prefix = tok1.token[:8]
        count = revoke_by_prefix(prefix, _storage=token_file)
        assert count >= 1
        # tok1 should be gone
        assert validate_auditor_token(tok1.token, _storage=token_file) is None


class TestListTokens:
    def test_list_active_tokens_only(self, token_file):
        tok1 = generate_auditor_token("A", "a@a.com", _storage=token_file)
        tok2 = generate_auditor_token("B", "b@b.com", _storage=token_file)

        # Expire tok1
        raw = json.loads(token_file.read_text(encoding="utf-8"))
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        for entry in raw:
            if entry["token"] == tok1.token:
                entry["expires_at"] = past
        token_file.write_text(json.dumps(raw), encoding="utf-8")

        active = list_auditor_tokens(_storage=token_file)
        assert len(active) == 1
        assert active[0].token == tok2.token

    def test_list_empty(self, token_file):
        assert list_auditor_tokens(_storage=token_file) == []


# ===================================================================
# Server endpoint tests
# ===================================================================

class TestAuditorEndpoints:
    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        self.tmp = tmp_path
        self.token_file = tmp_path / "auditor_tokens.json"
        self.out_dir = tmp_path / "out"
        self.out_dir.mkdir()

        # Write minimal findings
        findings = [
            {
                "rule_id": "no-eval",
                "message": "Use of eval()",
                "severity": "critical",
                "evidence": {"file": "src/app.py", "lines": [10]},
                "standard": "OWASP",
                "clause": "A03",
            },
            {
                "rule_id": "no-hardcoded-secret",
                "message": "Hardcoded secret found",
                "severity": "high",
                "evidence": {"file": "src/config.py", "lines": [5]},
                "standard": "SOC2",
                "clause": "CC6.1",
            },
        ]
        (self.out_dir / "findings.json").write_text(json.dumps(findings), encoding="utf-8")

        # Write minimal metrics
        metrics = {
            "total_findings": 2,
            "by_severity": {"critical": 1, "high": 1},
            "compliance_score": {"score": 0.85, "rules_total": 10},
            "files_scanned": 5,
        }
        (self.out_dir / "scan_metrics.json").write_text(json.dumps(metrics), encoding="utf-8")

        # Write minimal audit log
        audit = [
            {"timestamp": "2026-03-20T10:00:00Z", "action": "gate_fail", "decision": "blocked"},
        ]
        with open(self.out_dir / "agent_audit.jsonl", "w", encoding="utf-8") as f:
            for e in audit:
                f.write(json.dumps(e) + "\n")

    def _get_client(self):
        from fastapi.testclient import TestClient
        from guard.server import app
        return TestClient(app)

    def _create_token(self):
        return generate_auditor_token(
            "Test Auditor", "test@auditor.com", _storage=self.token_file,
        )

    def test_portal_page_returns_html(self):
        client = self._get_client()
        resp = client.get("/auditor")
        assert resp.status_code == 200
        assert "SENTRIK" in resp.text
        assert "Auditor Portal" in resp.text

    def test_portal_data_with_valid_token(self):
        tok = self._create_token()
        client = self._get_client()
        with patch("guard.core.auditor_portal._storage_path", return_value=self.token_file), \
             patch("guard.server._load_config") as mock_cfg:
            mock_cfg.return_value = _FakeConfig(str(self.out_dir))
            resp = client.get(f"/api/auditor/portal-data?token={tok.token}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["auditor_name"] == "Test Auditor"
        assert "findings_by_rule" in data
        assert "metrics" in data

    def test_portal_data_with_invalid_token(self):
        client = self._get_client()
        with patch("guard.core.auditor_portal._storage_path", return_value=self.token_file):
            resp = client.get("/api/auditor/portal-data?token=invalid")
        assert resp.status_code == 403

    def test_portal_data_with_expired_token(self):
        tok = self._create_token()
        # Expire it
        raw = json.loads(self.token_file.read_text(encoding="utf-8"))
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        raw[0]["expires_at"] = past
        self.token_file.write_text(json.dumps(raw), encoding="utf-8")

        client = self._get_client()
        with patch("guard.core.auditor_portal._storage_path", return_value=self.token_file):
            resp = client.get(f"/api/auditor/portal-data?token={tok.token}")
        assert resp.status_code == 403

    def test_portal_data_no_token(self):
        client = self._get_client()
        with patch("guard.core.auditor_portal._storage_path", return_value=self.token_file):
            resp = client.get("/api/auditor/portal-data?token=")
        assert resp.status_code == 403


# ===================================================================
# CLI tests
# ===================================================================

class TestAuditorCLI:
    def test_cli_create_token(self, tmp_path):
        token_file = tmp_path / "auditor_tokens.json"
        runner = CliRunner()

        from guard.cli import app as cli_app

        with patch("guard.core.auditor_portal._storage_path", return_value=token_file):
            result = runner.invoke(cli_app, [
                "auditor", "create",
                "--name", "Jane Smith",
                "--email", "jane@audit.com",
                "--hours", "48",
            ])

        assert result.exit_code == 0
        assert "Jane Smith" in result.output
        assert "jane@audit.com" in result.output
        assert "Portal URL:" in result.output
        assert "localhost:8000/auditor?token=" in result.output

    def test_cli_list_empty(self, tmp_path):
        token_file = tmp_path / "auditor_tokens.json"
        runner = CliRunner()
        from guard.cli import app as cli_app

        with patch("guard.core.auditor_portal._storage_path", return_value=token_file):
            result = runner.invoke(cli_app, ["auditor", "list"])

        assert result.exit_code == 0
        assert "No active" in result.output

    def test_cli_list_shows_tokens(self, tmp_path):
        token_file = tmp_path / "auditor_tokens.json"
        generate_auditor_token("Alice", "alice@a.com", _storage=token_file)

        runner = CliRunner()
        from guard.cli import app as cli_app

        with patch("guard.core.auditor_portal._storage_path", return_value=token_file):
            result = runner.invoke(cli_app, ["auditor", "list"])

        assert result.exit_code == 0
        assert "Alice" in result.output
        assert "alice@a.com" in result.output

    def test_cli_revoke(self, tmp_path):
        token_file = tmp_path / "auditor_tokens.json"
        tok = generate_auditor_token("Bob", "bob@b.com", _storage=token_file)

        runner = CliRunner()
        from guard.cli import app as cli_app

        with patch("guard.core.auditor_portal._storage_path", return_value=token_file):
            result = runner.invoke(cli_app, ["auditor", "revoke", tok.token[:8]])

        assert result.exit_code == 0
        assert "Revoked" in result.output

    def test_cli_revoke_not_found(self, tmp_path):
        token_file = tmp_path / "auditor_tokens.json"
        runner = CliRunner()
        from guard.cli import app as cli_app

        with patch("guard.core.auditor_portal._storage_path", return_value=token_file):
            result = runner.invoke(cli_app, ["auditor", "revoke", "nonexistent"])

        assert result.exit_code == 0  # typer doesn't exit(1) for this
        assert "No tokens found" in result.output


# ── Helper ────────────────────────────────────────────────────────────

class _FakeConfig:
    """Minimal config stub for server endpoint tests."""
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self.license_key = ""
        self.standards_file = ""
        self.standards_packs = []
        self.online_license_check = False
        self.portal_url = ""

    def get_auth_config(self):
        from guard.auth.models import AuthConfig
        return AuthConfig(enabled=False)
