"""Tests for the dependency vulnerability scanner."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from guard.core.sbom import Component
from guard.core.vuln_scanner import (
    ECOSYSTEM_MAP,
    Vulnerability,
    VulnScanResult,
    _cvss_to_level,
    _extract_fixed_version,
    _map_severity,
    _query_osv_batch,
    result_to_dict,
    scan_dependencies,
)


# ---------------------------------------------------------------------------
# Helpers — realistic OSV API response structures
# ---------------------------------------------------------------------------

def _make_osv_vuln(
    vuln_id: str = "GHSA-xxxx-yyyy-zzzz",
    summary: str = "Test vulnerability",
    cvss_vector: str = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
    fixed_version: str | None = "1.2.3",
    references: list[dict] | None = None,
) -> dict:
    """Build a realistic OSV vulnerability entry."""
    vuln: dict = {
        "id": vuln_id,
        "summary": summary,
        "severity": [{"type": "CVSS_V3", "score": cvss_vector}] if cvss_vector else [],
        "references": references or [{"type": "WEB", "url": f"https://nvd.nist.gov/vuln/detail/{vuln_id}"}],
        "affected": [],
    }
    if fixed_version:
        vuln["affected"] = [
            {
                "ranges": [
                    {
                        "type": "ECOSYSTEM",
                        "events": [
                            {"introduced": "0"},
                            {"fixed": fixed_version},
                        ],
                    }
                ]
            }
        ]
    return vuln


def _make_batch_response(*result_lists: list[dict]) -> dict:
    """Build an OSV querybatch response."""
    return {
        "results": [{"vulns": vulns} for vulns in result_lists]
    }


# ---------------------------------------------------------------------------
# Test scan_dependencies
# ---------------------------------------------------------------------------

class TestScanDependencies:

    def test_scan_no_components(self):
        """Empty component list returns zero vulns."""
        result = scan_dependencies([])
        assert result.total_dependencies == 0
        assert result.vulnerable_count == 0
        assert result.vulnerabilities == []
        assert result.by_severity == {"critical": 0, "high": 0, "medium": 0, "low": 0}

    @patch("guard.core.vuln_scanner._query_osv_batch")
    def test_scan_with_vulns(self, mock_query):
        """Mock OSV response with vulns, verify parsing."""
        components = [
            Component(name="express", version="4.17.1", ecosystem="npm"),
            Component(name="lodash", version="4.17.20", ecosystem="npm"),
        ]
        mock_query.return_value = [
            [_make_osv_vuln("GHSA-1111-2222-3333", "XSS in express", fixed_version="4.18.0")],
            [],  # lodash — no vulns
        ]

        result = scan_dependencies(components)

        assert result.total_dependencies == 2
        assert result.vulnerable_count == 1
        assert len(result.vulnerabilities) == 1
        assert result.vulnerabilities[0].id == "GHSA-1111-2222-3333"
        assert result.vulnerabilities[0].affected_package == "express"
        assert result.vulnerabilities[0].affected_version == "4.17.1"
        assert result.vulnerabilities[0].fixed_version == "4.18.0"
        assert result.scan_timestamp  # non-empty

    @patch("guard.core.vuln_scanner._query_osv_batch")
    def test_scan_no_vulns(self, mock_query):
        """Mock OSV response with no vulns for any component."""
        components = [
            Component(name="requests", version="2.31.0", ecosystem="pypi"),
        ]
        mock_query.return_value = [[]]

        result = scan_dependencies(components)
        assert result.total_dependencies == 1
        assert result.vulnerable_count == 0
        assert result.vulnerabilities == []

    @patch("guard.core.vuln_scanner._query_osv_batch")
    def test_result_by_severity_counts(self, mock_query):
        """by_severity dict correctly counts each level."""
        components = [
            Component(name="a", version="1.0", ecosystem="npm"),
            Component(name="b", version="1.0", ecosystem="npm"),
            Component(name="c", version="1.0", ecosystem="npm"),
        ]
        # a has a critical vuln (high CVSS), b has a low vuln, c has nothing
        mock_query.return_value = [
            [_make_osv_vuln("CVE-2024-0001", cvss_vector="9.8")],  # numeric score → critical
            [_make_osv_vuln("CVE-2024-0002", cvss_vector="2.0")],  # low
            [],
        ]

        result = scan_dependencies(components)
        assert result.by_severity["critical"] == 1
        assert result.by_severity["low"] == 1
        assert result.by_severity.get("high", 0) == 0
        assert result.by_severity.get("medium", 0) == 0


# ---------------------------------------------------------------------------
# Test severity mapping
# ---------------------------------------------------------------------------

class TestSeverityMapping:

    def test_severity_mapping_critical(self):
        """CVSS 9.5 maps to critical."""
        assert _cvss_to_level(9.5) == "critical"

    def test_severity_mapping_high(self):
        """CVSS 7.5 maps to high."""
        assert _cvss_to_level(7.5) == "high"

    def test_severity_mapping_medium(self):
        """CVSS 5.0 maps to medium."""
        assert _cvss_to_level(5.0) == "medium"

    def test_severity_mapping_low(self):
        """CVSS 2.0 maps to low."""
        assert _cvss_to_level(2.0) == "low"

    def test_severity_mapping_boundary_9(self):
        """CVSS exactly 9.0 maps to critical."""
        assert _cvss_to_level(9.0) == "critical"

    def test_severity_mapping_boundary_7(self):
        """CVSS exactly 7.0 maps to high."""
        assert _cvss_to_level(7.0) == "high"

    def test_severity_mapping_boundary_4(self):
        """CVSS exactly 4.0 maps to medium."""
        assert _cvss_to_level(4.0) == "medium"

    def test_severity_mapping_no_cvss(self):
        """No CVSS score defaults to medium."""
        assert _map_severity([]) == "medium"

    def test_severity_mapping_numeric_score(self):
        """Numeric score in severity entry is handled."""
        result = _map_severity([{"type": "CVSS_V3", "score": 9.8}])
        assert result == "critical"


# ---------------------------------------------------------------------------
# Test ecosystem mapping
# ---------------------------------------------------------------------------

class TestEcosystemMapping:

    def test_ecosystem_mapping_pypi(self):
        assert ECOSYSTEM_MAP["pypi"] == "PyPI"

    def test_ecosystem_mapping_npm(self):
        assert ECOSYSTEM_MAP["npm"] == "npm"

    def test_ecosystem_mapping_cargo(self):
        assert ECOSYSTEM_MAP["cargo"] == "crates.io"

    def test_ecosystem_mapping_go(self):
        assert ECOSYSTEM_MAP["golang"] == "Go"
        assert ECOSYSTEM_MAP["go"] == "Go"

    def test_ecosystem_mapping_maven(self):
        assert ECOSYSTEM_MAP["maven"] == "Maven"


# ---------------------------------------------------------------------------
# Test framework mapping
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Test batch chunking
# ---------------------------------------------------------------------------

class TestBatchChunking:

    @patch("guard.core.vuln_scanner.requests.post")
    def test_batch_chunking(self, mock_post):
        """>100 components are split into multiple batches."""
        components = [
            Component(name=f"pkg-{i}", version="1.0.0", ecosystem="npm")
            for i in range(150)
        ]

        # First batch (100 items) — return 100 empty results
        resp1 = MagicMock()
        resp1.status_code = 200
        resp1.json.return_value = _make_batch_response(*[[] for _ in range(100)])
        resp1.raise_for_status = MagicMock()

        # Second batch (50 items) — return 50 empty results
        resp2 = MagicMock()
        resp2.status_code = 200
        resp2.json.return_value = _make_batch_response(*[[] for _ in range(50)])
        resp2.raise_for_status = MagicMock()

        mock_post.side_effect = [resp1, resp2]

        results = _query_osv_batch(components)
        assert len(results) == 150
        assert mock_post.call_count == 2

        # Verify first batch sent 100 queries
        first_call_body = mock_post.call_args_list[0][1]["json"]
        assert len(first_call_body["queries"]) == 100

        # Verify second batch sent 50 queries
        second_call_body = mock_post.call_args_list[1][1]["json"]
        assert len(second_call_body["queries"]) == 50


# ---------------------------------------------------------------------------
# Test network error handling
# ---------------------------------------------------------------------------

class TestNetworkError:

    @patch("guard.core.vuln_scanner.requests.post")
    def test_network_error_graceful(self, mock_post):
        """requests.post raises an exception; returns empty results."""
        mock_post.side_effect = ConnectionError("Network unreachable")

        components = [
            Component(name="express", version="4.17.1", ecosystem="npm"),
        ]
        results = _query_osv_batch(components)
        assert len(results) == 1
        assert results[0] == []


# ---------------------------------------------------------------------------
# Test fixed version extraction
# ---------------------------------------------------------------------------

class TestFixedVersion:

    def test_fixed_version_extraction(self):
        """Extracts fixed version from OSV affected ranges."""
        vuln_data = {
            "affected": [
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [
                                {"introduced": "0"},
                                {"fixed": "2.0.1"},
                            ],
                        }
                    ]
                }
            ]
        }
        assert _extract_fixed_version(vuln_data) == "2.0.1"

    def test_no_fixed_version(self):
        """No fixed version available returns None."""
        vuln_data = {
            "affected": [
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [{"introduced": "0"}],
                        }
                    ]
                }
            ]
        }
        assert _extract_fixed_version(vuln_data) is None

    def test_no_affected_key(self):
        """Missing affected key returns None."""
        assert _extract_fixed_version({}) is None


# ---------------------------------------------------------------------------
# Test result_to_dict serialization
# ---------------------------------------------------------------------------

class TestResultToDict:

    def test_result_to_dict_structure(self):
        """result_to_dict produces valid JSON-serializable output."""
        result = VulnScanResult(
            total_dependencies=5,
            vulnerable_count=1,
            vulnerabilities=[
                Vulnerability(
                    id="CVE-2024-1234",
                    summary="A vulnerability",
                    severity="high",
                    affected_package="pkg",
                    affected_version="1.0",
                    fixed_version="1.1",
                    references=["https://example.com"],
                )
            ],
            scan_timestamp="2024-01-01T00:00:00+00:00",
            by_severity={"critical": 0, "high": 1, "medium": 0, "low": 0},
        )
        d = result_to_dict(result)
        # Ensure it's JSON serializable
        json_str = json.dumps(d)
        parsed = json.loads(json_str)
        assert parsed["total_dependencies"] == 5
        assert parsed["vulnerable_count"] == 1
        assert len(parsed["vulnerabilities"]) == 1
        assert parsed["vulnerabilities"][0]["id"] == "CVE-2024-1234"
        assert parsed["vulnerabilities"][0]["references"] == ["https://example.com"]


# ---------------------------------------------------------------------------
# Test CLI command (mocked)
# ---------------------------------------------------------------------------

class TestCLIVulns:

    @patch("guard.core.vuln_scanner._query_osv_batch")
    def test_cli_vulns_json(self, mock_query, tmp_path):
        """CLI --json output produces valid JSON."""
        from typer.testing import CliRunner
        from guard.cli import app

        mock_query.return_value = [
            [_make_osv_vuln("CVE-2024-9999", "Test vuln", cvss_vector="7.5", fixed_version="2.0.0")],
        ]

        # Create a manifest for the CLI to find
        pkg_json = tmp_path / "package.json"
        pkg_json.write_text(json.dumps({
            "dependencies": {"express": "4.17.1"}
        }))

        runner = CliRunner()
        result = runner.invoke(app, [
            "vulns", "--json",
            "--output", str(tmp_path / "vulns.json"),
        ], catch_exceptions=False)

        # The command should succeed (exit 0)
        assert result.exit_code == 0 or result.exit_code is None

        # Output file should exist
        out_file = tmp_path / "vulns.json"
        assert out_file.exists()
        data = json.loads(out_file.read_text())
        assert "vulnerabilities" in data
        assert "total_dependencies" in data
