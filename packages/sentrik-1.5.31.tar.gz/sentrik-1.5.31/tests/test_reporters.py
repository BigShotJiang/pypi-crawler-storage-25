"""Comprehensive tests for reporter plugins (Phase 8)."""

from __future__ import annotations

import json
from xml.etree.ElementTree import fromstring

import pytest

from tests.helpers import make_finding
from guard.core.models import Severity
from guard.reporters.base import Reporter
from guard.reporters.factory import available_reporters, build_reporters, get_reporter
from guard.reporters.html import HtmlReporter
from guard.reporters.junit import JUnitReporter
from guard.reporters.sarif_output import SarifOutputReporter


def _finding(
    fid: str = "F1",
    rule: str = "test-rule",
    sev: Severity = Severity.LOW,
    file: str = "app.py",
    line: int = 1,
    msg: str = "Test finding",
    suggestion: str | None = None,
    snippet: str = "",
    deterministic: bool = True,
    confidence: float = 1.0,
):
    """Thin wrapper preserving the original ``line`` parameter interface."""
    return make_finding(
        fid=fid, rule=rule, sev=sev, file=file,
        lines=[line] if line else [],
        msg=msg, suggestion=suggestion, snippet=snippet,
        deterministic=deterministic, confidence=confidence,
    )


# ===================================================================
# Reporter factory
# ===================================================================


class TestReporterFactory:
    def test_available_reporters(self):
        names = available_reporters()
        assert "html" in names
        assert "junit" in names
        assert "sarif" in names

    def test_get_reporter_html(self):
        r = get_reporter("html")
        assert isinstance(r, HtmlReporter)

    def test_get_reporter_junit(self):
        r = get_reporter("junit")
        assert isinstance(r, JUnitReporter)

    def test_get_reporter_sarif(self):
        r = get_reporter("sarif")
        assert isinstance(r, SarifOutputReporter)

    def test_get_reporter_unknown_returns_none(self):
        assert get_reporter("banana") is None

    def test_build_reporters_multiple(self):
        reporters = build_reporters(["html", "junit"])
        assert len(reporters) == 2

    def test_build_reporters_skips_unknown(self):
        reporters = build_reporters(["html", "unknown", "junit"])
        assert len(reporters) == 2

    def test_build_reporters_empty(self):
        assert build_reporters([]) == []


# ===================================================================
# HTML reporter
# ===================================================================


class TestHtmlReporter:
    def test_extension(self):
        assert HtmlReporter().extension == ".html"

    def test_empty_findings(self):
        html = HtmlReporter().render([])
        assert "No findings detected" in html
        assert "<html" in html

    def test_single_finding(self):
        html = HtmlReporter().render([_finding()])
        assert "F1" in html
        assert "test-rule" in html
        assert "app.py" in html
        assert "LOW" in html

    def test_severity_sections(self):
        findings = [
            _finding(fid="C1", sev=Severity.CRITICAL),
            _finding(fid="L1", sev=Severity.LOW),
        ]
        html = HtmlReporter().render(findings)
        assert "CRITICAL" in html
        assert "LOW" in html

    def test_suggestion_rendered(self):
        html = HtmlReporter().render([_finding(suggestion="Fix it")])
        assert "Fix it" in html

    def test_html_escaping(self):
        html = HtmlReporter().render([_finding(msg="<script>alert(1)</script>")])
        assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html
        assert "<script>alert(1)</script>" not in html

    def test_total_findings_count(self):
        findings = [_finding(fid=f"F{i}") for i in range(5)]
        html = HtmlReporter().render(findings)
        assert "5" in html

    def test_heuristic_label(self):
        html = HtmlReporter().render([_finding(deterministic=False, confidence=0.7)])
        assert "heuristic" in html
        assert "70%" in html

    def test_deterministic_label(self):
        html = HtmlReporter().render([_finding(deterministic=True)])
        assert "deterministic" in html

    def test_snippet_in_finding(self):
        html = HtmlReporter().render([_finding(snippet="x = eval(input())")])
        # Snippet isn't shown in table currently, but the row renders without error
        assert "F1" in html

    def test_no_lines_shows_dash(self):
        f = _finding(line=0)
        f.evidence.lines = []
        html = HtmlReporter().render([f])
        assert "-" in html

    def test_valid_html_structure(self):
        html = HtmlReporter().render([_finding()])
        assert html.startswith("<!DOCTYPE html>")
        assert "</html>" in html
        assert "<table>" in html

    def test_obligations_section(self):
        from guard.core.models import Evidence, Finding
        obl = Finding(
            finding_id="OBL-1-obligation", rule_id="OBL-1",
            severity=Severity.INFO, message="Must have dev plan",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0, is_obligation=True,
            standard="IEC 62304", clause="5.1.1",
            remediation_guidance="Create a development plan",
        )
        html = HtmlReporter().render([obl])
        assert "Compliance Obligations" in html
        assert "IEC 62304" in html
        assert "5.1.1" in html
        assert "Create a development plan" in html

    def test_obligations_with_code_findings(self):
        from guard.core.models import Evidence, Finding
        code_f = _finding(fid="F1", sev=Severity.HIGH)
        obl = Finding(
            finding_id="OBL-1-obligation", rule_id="OBL-1",
            severity=Severity.INFO, message="Dev plan needed",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0, is_obligation=True,
            standard="IEC 62304", clause="5.1.1",
        )
        html = HtmlReporter().render([code_f, obl])
        assert "HIGH" in html
        assert "Compliance Obligations" in html
        # Total should only count code findings
        assert "<strong>Total findings:</strong> 1" in html

    def test_code_finding_with_standard_metadata(self):
        from guard.core.models import Evidence, Finding
        f = Finding(
            finding_id="F1", rule_id="R1",
            severity=Severity.MEDIUM, message="Bad code",
            evidence=Evidence(file="app.py", lines=[10], snippet="x"),
            confidence=1.0, standard="IEC 62304", clause="5.5.5",
        )
        html = HtmlReporter().render([f])
        assert "IEC 62304" in html
        assert "5.5.5" in html

    def test_obligations_no_remediation(self):
        from guard.core.models import Evidence, Finding
        obl = Finding(
            finding_id="OBL-1-obligation", rule_id="OBL-1",
            severity=Severity.INFO, message="Obligation without remediation",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0, is_obligation=True,
            standard="General",
        )
        html = HtmlReporter().render([obl])
        assert "Compliance Obligations" in html
        assert "-" in html  # remediation shows dash when None


# ===================================================================
# JUnit XML reporter
# ===================================================================


class TestJUnitReporter:
    def test_extension(self):
        assert JUnitReporter().extension == ".xml"

    def test_empty_findings(self):
        xml = JUnitReporter().render([])
        root = fromstring(xml)
        assert root.tag == "testsuite"
        assert root.get("tests") == "0"
        assert root.get("failures") == "0"

    def test_single_low_finding_no_failure(self):
        xml = JUnitReporter().render([_finding(sev=Severity.LOW)])
        root = fromstring(xml)
        assert root.get("tests") == "1"
        assert root.get("failures") == "0"
        tc = root.find("testcase")
        assert tc is not None
        assert tc.find("failure") is None
        assert tc.find("system-out") is not None

    def test_critical_finding_is_failure(self):
        xml = JUnitReporter().render([_finding(sev=Severity.CRITICAL)])
        root = fromstring(xml)
        assert root.get("failures") == "1"
        tc = root.find("testcase")
        fail = tc.find("failure")
        assert fail is not None
        assert fail.get("type") == "critical"

    def test_high_finding_is_failure(self):
        xml = JUnitReporter().render([_finding(sev=Severity.HIGH)])
        root = fromstring(xml)
        assert root.get("failures") == "1"

    def test_medium_finding_not_failure(self):
        xml = JUnitReporter().render([_finding(sev=Severity.MEDIUM)])
        root = fromstring(xml)
        assert root.get("failures") == "0"

    def test_multiple_findings(self):
        findings = [
            _finding(fid="C1", sev=Severity.CRITICAL),
            _finding(fid="L1", sev=Severity.LOW),
            _finding(fid="H1", sev=Severity.HIGH),
        ]
        xml = JUnitReporter().render(findings)
        root = fromstring(xml)
        assert root.get("tests") == "3"
        assert root.get("failures") == "2"

    def test_testcase_attributes(self):
        xml = JUnitReporter().render([_finding(fid="F1", rule="my-rule", file="src/main.py")])
        root = fromstring(xml)
        tc = root.find("testcase")
        assert tc.get("name") == "F1"
        assert tc.get("classname") == "my-rule"
        assert tc.get("file") == "src/main.py"

    def test_xml_declaration(self):
        xml = JUnitReporter().render([])
        assert xml.startswith('<?xml version="1.0"')

    def test_failure_message(self):
        xml = JUnitReporter().render([_finding(sev=Severity.CRITICAL, msg="Bad stuff")])
        root = fromstring(xml)
        fail = root.find(".//failure")
        assert fail.get("message") == "Bad stuff"

    def test_suggestion_in_detail(self):
        xml = JUnitReporter().render([_finding(sev=Severity.CRITICAL, suggestion="Fix it")])
        root = fromstring(xml)
        fail = root.find(".//failure")
        assert "Fix it" in fail.text

    def test_system_out_content(self):
        xml = JUnitReporter().render([_finding(sev=Severity.LOW, msg="Info msg")])
        root = fromstring(xml)
        out = root.find(".//system-out")
        assert "Info msg" in out.text


# ===================================================================
# SARIF output reporter
# ===================================================================


class TestSarifOutputReporter:
    def test_extension(self):
        assert SarifOutputReporter().extension == ".sarif.json"

    def test_empty_findings(self):
        output = SarifOutputReporter().render([])
        sarif = json.loads(output)
        assert sarif["version"] == "2.1.0"
        assert sarif["runs"][0]["results"] == []

    def test_single_finding(self):
        output = SarifOutputReporter().render([_finding()])
        sarif = json.loads(output)
        results = sarif["runs"][0]["results"]
        assert len(results) == 1
        assert results[0]["ruleId"] == "test-rule"
        assert results[0]["message"]["text"] == "Test finding"

    def test_severity_mapping_critical(self):
        output = SarifOutputReporter().render([_finding(sev=Severity.CRITICAL)])
        sarif = json.loads(output)
        assert sarif["runs"][0]["results"][0]["level"] == "error"

    def test_severity_mapping_high(self):
        output = SarifOutputReporter().render([_finding(sev=Severity.HIGH)])
        sarif = json.loads(output)
        assert sarif["runs"][0]["results"][0]["level"] == "error"

    def test_severity_mapping_medium(self):
        output = SarifOutputReporter().render([_finding(sev=Severity.MEDIUM)])
        sarif = json.loads(output)
        assert sarif["runs"][0]["results"][0]["level"] == "warning"

    def test_severity_mapping_low(self):
        output = SarifOutputReporter().render([_finding(sev=Severity.LOW)])
        sarif = json.loads(output)
        assert sarif["runs"][0]["results"][0]["level"] == "note"

    def test_severity_mapping_info(self):
        output = SarifOutputReporter().render([_finding(sev=Severity.INFO)])
        sarif = json.loads(output)
        assert sarif["runs"][0]["results"][0]["level"] == "none"

    def test_location_with_line(self):
        output = SarifOutputReporter().render([_finding(file="src/x.py", line=42)])
        sarif = json.loads(output)
        loc = sarif["runs"][0]["results"][0]["locations"][0]
        assert loc["physicalLocation"]["artifactLocation"]["uri"] == "src/x.py"
        assert loc["physicalLocation"]["region"]["startLine"] == 42

    def test_location_without_line(self):
        f = _finding()
        f.evidence.lines = []
        output = SarifOutputReporter().render([f])
        sarif = json.loads(output)
        loc = sarif["runs"][0]["results"][0]["locations"][0]
        assert "region" not in loc["physicalLocation"]

    def test_snippet_in_region(self):
        output = SarifOutputReporter().render([_finding(snippet="eval(x)")])
        sarif = json.loads(output)
        region = sarif["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["region"]
        assert region["snippet"]["text"] == "eval(x)"

    def test_suggestion_as_fix(self):
        output = SarifOutputReporter().render([_finding(suggestion="Use ast.literal_eval()")])
        sarif = json.loads(output)
        result = sarif["runs"][0]["results"][0]
        assert "fixes" in result
        assert result["fixes"][0]["description"]["text"] == "Use ast.literal_eval()"

    def test_no_suggestion_no_fix(self):
        output = SarifOutputReporter().render([_finding()])
        sarif = json.loads(output)
        result = sarif["runs"][0]["results"][0]
        assert "fixes" not in result

    def test_tool_driver(self):
        output = SarifOutputReporter().render([_finding()])
        sarif = json.loads(output)
        driver = sarif["runs"][0]["tool"]["driver"]
        assert driver["name"] == "ai-sdlc-guard"
        assert "version" in driver

    def test_rules_deduped(self):
        findings = [
            _finding(fid="F1", rule="R1"),
            _finding(fid="F2", rule="R1"),
            _finding(fid="F3", rule="R2"),
        ]
        output = SarifOutputReporter().render(findings)
        sarif = json.loads(output)
        rules = sarif["runs"][0]["tool"]["driver"]["rules"]
        rule_ids = [r["id"] for r in rules]
        assert sorted(rule_ids) == ["R1", "R2"]

    def test_valid_json(self):
        output = SarifOutputReporter().render([_finding()])
        sarif = json.loads(output)
        assert "$schema" in sarif

    def test_multiple_findings(self):
        findings = [_finding(fid=f"F{i}") for i in range(5)]
        output = SarifOutputReporter().render(findings)
        sarif = json.loads(output)
        assert len(sarif["runs"][0]["results"]) == 5


# ===================================================================
# HTML report enhancements (Phase 26i)
# ===================================================================


class TestHtmlReporterEnhancements:
    def test_filter_buttons_present(self):
        findings = [
            _finding(fid="C1", sev=Severity.CRITICAL),
            _finding(fid="L1", sev=Severity.LOW),
        ]
        html = HtmlReporter().render(findings)
        assert "filter-btn" in html
        assert "toggleFilter" in html

    def test_sortable_headers(self):
        html = HtmlReporter().render([_finding()])
        assert "sortable" in html
        assert "sortTable" in html

    def test_expandable_rows(self):
        html = HtmlReporter().render([_finding()])
        assert "expandable-row" in html
        assert "detail-row" in html

    def test_executive_summary_donut(self):
        findings = [
            _finding(fid="C1", sev=Severity.CRITICAL),
            _finding(fid="L1", sev=Severity.LOW),
        ]
        html = HtmlReporter().render(findings)
        assert "donut" in html
        assert "<svg" in html

    def test_search_filter_input(self):
        html = HtmlReporter().render([_finding()])
        assert "filterFindings" in html
        assert "search-box" in html

    def test_print_styles(self):
        html = HtmlReporter().render([_finding()])
        assert "@media print" in html

    def test_footer_has_version_and_timestamp(self):
        html = HtmlReporter().render([_finding()])
        assert "Guard v" in html
        assert "UTC" in html

    def test_dark_mode_support(self):
        html = HtmlReporter().render([_finding()])
        assert "prefers-color-scheme: dark" in html

    def test_css_variables_in_report(self):
        html = HtmlReporter().render([_finding()])
        assert "--text-color" in html
        assert "--bg-color" in html

    def test_donut_not_shown_for_empty(self):
        html = HtmlReporter().render([])
        assert "<svg" not in html

    def test_sev_section_data_attribute(self):
        html = HtmlReporter().render([_finding(sev=Severity.HIGH)])
        assert 'data-sev="high"' in html
