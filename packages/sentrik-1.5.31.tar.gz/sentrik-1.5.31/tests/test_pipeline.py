"""Tests for pipeline orchestration — run_scan, write_artifacts, evaluate_gate, build_autofix_map, build_replacement_map."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from tests.helpers import FakeScanner, make_finding
from guard.config import GuardConfig
from guard.core.models import Evidence, Finding, GateResult, Severity
from guard.core.pipeline import (
    build_autofix_map,
    build_replacement_map,
    evaluate_gate,
    get_current_run_id,
    list_historical_runs,
    load_historical_findings,
    load_historical_metadata,
    run_scan,
    write_artifacts,
)
from guard.rules.engine import RulesEngine


# ===================================================================
# run_scan
# ===================================================================


class TestRunScan:
    def _config(self, tmp_path, **kw):
        return GuardConfig(output_dir=str(tmp_path / "out"), **kw)

    def test_empty_rules_stub_scanner(self, tmp_path):
        config = self._config(tmp_path)
        engine = RulesEngine([])
        scanner = FakeScanner([])
        findings = run_scan(str(tmp_path), config, engine, scanner)
        assert findings == []

    def test_rules_engine_findings_returned(self, tmp_path):
        (tmp_path / "a.py").write_text("# TODO fix\n", encoding="utf-8")
        config = self._config(tmp_path)
        engine = RulesEngine([{
            "id": "R1", "name": "todo", "type": "regex",
            "pattern": r"TODO", "severity": "low", "file_glob": "**/*.py",
        }])
        scanner = FakeScanner([])
        findings = run_scan(str(tmp_path), config, engine, scanner)
        assert len(findings) >= 1
        assert any(f.rule_id == "R1" for f in findings)

    def test_scanner_findings_returned(self, tmp_path):
        config = self._config(tmp_path)
        engine = RulesEngine([])
        f1 = make_finding(fid="S1", rule="scanner-rule")
        scanner = FakeScanner([f1])
        findings = run_scan(str(tmp_path), config, engine, scanner)
        assert len(findings) == 1
        assert findings[0].finding_id == "S1"

    def test_both_aggregated(self, tmp_path):
        (tmp_path / "a.py").write_text("# TODO\n", encoding="utf-8")
        config = self._config(tmp_path)
        engine = RulesEngine([{
            "id": "R1", "name": "todo", "type": "regex",
            "pattern": r"TODO", "severity": "low", "file_glob": "**/*.py",
        }])
        scanner = FakeScanner([make_finding(fid="S1")])
        findings = run_scan(str(tmp_path), config, engine, scanner)
        ids = {f.finding_id for f in findings}
        assert "S1" in ids
        assert len(findings) >= 2  # at least one from engine + one from scanner

    def test_changed_files_forwarded(self, tmp_path):
        (tmp_path / "a.py").write_text("# TODO\n", encoding="utf-8")
        (tmp_path / "b.py").write_text("# TODO\n", encoding="utf-8")
        config = self._config(tmp_path)
        engine = RulesEngine([{
            "id": "R1", "name": "todo", "type": "regex",
            "pattern": r"TODO", "severity": "low", "file_glob": "**/*.py",
        }])
        scanner = FakeScanner([])
        findings = run_scan(str(tmp_path), config, engine, scanner, changed_files=["a.py"])
        # Only a.py should be evaluated
        files = {f.evidence.file for f in findings}
        assert "a.py" in files
        assert "b.py" not in files

    def test_branch_links_work_items(self, tmp_path):
        config = self._config(tmp_path)
        engine = RulesEngine([])
        f1 = make_finding(fid="F1")
        scanner = FakeScanner([f1])
        findings = run_scan(str(tmp_path), config, engine, scanner, branch="feature/WI-101-auth")
        assert "WI-101" in findings[0].related_work_items

    def test_no_branch_no_linking(self, tmp_path):
        config = self._config(tmp_path)
        engine = RulesEngine([])
        f1 = make_finding(fid="F1")
        scanner = FakeScanner([f1])
        findings = run_scan(str(tmp_path), config, engine, scanner, branch=None)
        assert findings[0].related_work_items == []

    def test_cache_enabled_creates_cache(self, tmp_path):
        cache_dir = tmp_path / ".cache"
        config = self._config(tmp_path, cache_enabled=True, cache_dir=str(cache_dir))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        run_scan(str(tmp_path), config, engine, scanner)
        # cache.save() should create the directory
        assert cache_dir.exists()

    def test_cache_disabled_no_cache(self, tmp_path):
        cache_dir = tmp_path / ".cache"
        config = self._config(tmp_path, cache_enabled=False, cache_dir=str(cache_dir))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        run_scan(str(tmp_path), config, engine, scanner)
        assert not cache_dir.exists()

    def test_cache_save_called(self, tmp_path):
        cache_dir = tmp_path / ".cache"
        config = self._config(tmp_path, cache_enabled=True, cache_dir=str(cache_dir))
        engine = RulesEngine([])
        scanner = FakeScanner([])
        with patch("guard.core.pipeline.ScanCache") as MockCache:
            instance = MockCache.return_value
            instance.save.return_value = None
            run_scan(str(tmp_path), config, engine, scanner)
            instance.save.assert_called_once()

    def test_empty_changed_files_list(self, tmp_path):
        (tmp_path / "a.py").write_text("# TODO\n", encoding="utf-8")
        config = self._config(tmp_path)
        engine = RulesEngine([{
            "id": "R1", "name": "todo", "type": "regex",
            "pattern": r"TODO", "severity": "low", "file_glob": "**/*.py",
        }])
        scanner = FakeScanner([])
        findings = run_scan(str(tmp_path), config, engine, scanner, changed_files=[])
        assert findings == []


# ===================================================================
# write_artifacts
# ===================================================================


class TestWriteArtifacts:
    def _config(self, tmp_path, **kw):
        return GuardConfig(output_dir=str(tmp_path / "out"), **kw)

    def test_creates_output_dir(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([], config, "scan", 0, 100.0)
        assert out.exists()
        assert out.is_dir()

    def test_writes_findings_json(self, tmp_path):
        config = self._config(tmp_path)
        f = make_finding(fid="F1")
        out = write_artifacts([f], config, "scan", 0, 100.0)
        data = json.loads((out / "findings.json").read_text(encoding="utf-8"))
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["finding_id"] == "F1"

    def test_writes_report_md(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([make_finding()], config, "scan", 0, 100.0)
        report = (out / "report.md").read_text()
        assert "Guard Scan Report" in report

    def test_writes_next_actions_md(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([make_finding()], config, "scan", 0, 100.0)
        actions = (out / "next_actions.md").read_text()
        assert "Next Actions" in actions

    def test_writes_run_metadata(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([make_finding()], config, "scan", 0, 123.4)
        meta = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        assert "run_id" in meta
        assert "timestamp" in meta
        assert meta["command"] == "scan"
        assert meta["exit_code"] == 0
        assert meta["findings_count"] == 1
        assert meta["duration_ms"] == 123.4

    def test_metadata_guard_version(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([], config, "scan", 0, 0)
        meta = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        from guard import __version__
        assert meta["guard_version"] == __version__

    def test_patches_dir_created(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([], config, "scan", 0, 0)
        assert (out / "patches").exists()
        assert (out / "patches").is_dir()

    def test_patches_generated_with_autofix_map(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "a.py").write_text('print("debug")\nx = 1\n', encoding="utf-8")
        config = self._config(tmp_path)
        f = make_finding(fid="F1", rule="R-print", file="a.py", lines=[1])
        out = write_artifacts(
            [f], config, "scan", 0, 0,
            repo_root=str(repo), autofix_map={"R-print": "remove_line"},
        )
        patches = list((out / "patches").glob("*.patch"))
        assert len(patches) >= 1

    def test_no_patches_without_autofix(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([make_finding()], config, "scan", 0, 0)
        patches = list((out / "patches").glob("*.patch"))
        assert patches == []

    def test_no_patches_without_repo_root(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts(
            [make_finding()], config, "scan", 0, 0,
            repo_root="", autofix_map={"R1": "remove_line"},
        )
        patches = list((out / "patches").glob("*.patch"))
        assert patches == []

    def test_reporters_generate_output(self, tmp_path):
        config = self._config(tmp_path, reporters=["html", "junit"])
        out = write_artifacts([make_finding()], config, "scan", 0, 0)
        assert (out / "report.html").exists()
        assert (out / "report.xml").exists()

    def test_empty_findings_creates_all_files(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([], config, "scan", 0, 0)
        assert (out / "findings.json").exists()
        assert (out / "report.md").exists()
        assert (out / "next_actions.md").exists()
        assert (out / "run_metadata.json").exists()

    def test_scoped_files_in_metadata(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts(
            [], config, "scan", 0, 0, changed_files=["a.py", "b.py"],
        )
        meta = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        assert meta["scoped_files"] == ["a.py", "b.py"]

    def test_scoped_files_none_in_metadata(self, tmp_path):
        config = self._config(tmp_path)
        out = write_artifacts([], config, "scan", 0, 0, changed_files=None)
        meta = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        assert meta["scoped_files"] is None


# ===================================================================
# evaluate_gate
# ===================================================================


class TestEvaluateGate:
    def test_no_findings_passes(self):
        config = GuardConfig()
        result = evaluate_gate([], config)
        assert result.passed is True
        assert result.total_findings == 0

    def test_critical_fails(self):
        config = GuardConfig()  # default gate_fail_on = ["critical", "high"]
        result = evaluate_gate([make_finding(sev=Severity.CRITICAL)], config)
        assert result.passed is False
        assert result.critical == 1

    def test_high_fails(self):
        config = GuardConfig()
        result = evaluate_gate([make_finding(sev=Severity.HIGH)], config)
        assert result.passed is False
        assert result.high == 1

    def test_medium_passes(self):
        config = GuardConfig()
        result = evaluate_gate([make_finding(sev=Severity.MEDIUM)], config)
        assert result.passed is True

    def test_low_passes(self):
        config = GuardConfig()
        result = evaluate_gate([make_finding(sev=Severity.LOW)], config)
        assert result.passed is True

    def test_info_passes(self):
        config = GuardConfig()
        result = evaluate_gate([make_finding(sev=Severity.INFO)], config)
        assert result.passed is True

    def test_custom_gate_fail_on(self):
        config = GuardConfig(gate_fail_on=["medium"])
        result = evaluate_gate([make_finding(sev=Severity.MEDIUM)], config)
        assert result.passed is False

    def test_empty_gate_fail_on_always_passes(self):
        config = GuardConfig(gate_fail_on=[])
        findings = [
            make_finding(fid="C1", sev=Severity.CRITICAL),
            make_finding(fid="H1", sev=Severity.HIGH),
        ]
        result = evaluate_gate(findings, config)
        assert result.passed is True

    def test_counts_correct(self):
        findings = [
            make_finding(fid="C1", sev=Severity.CRITICAL),
            make_finding(fid="H1", sev=Severity.HIGH),
            make_finding(fid="M1", sev=Severity.MEDIUM),
            make_finding(fid="L1", sev=Severity.LOW),
            make_finding(fid="I1", sev=Severity.INFO),
        ]
        config = GuardConfig()
        result = evaluate_gate(findings, config)
        assert result.total_findings == 5
        assert result.critical == 1
        assert result.high == 1
        assert result.medium == 1
        assert result.low == 1
        assert result.info == 1

    def test_mixed_severities(self):
        findings = [
            make_finding(fid="L1", sev=Severity.LOW),
            make_finding(fid="M1", sev=Severity.MEDIUM),
            make_finding(fid="I1", sev=Severity.INFO),
        ]
        config = GuardConfig()  # fails on critical/high
        result = evaluate_gate(findings, config)
        assert result.passed is True
        assert result.total_findings == 3

    def test_obligations_excluded_from_gate(self):
        """Obligation findings should not cause gate failure."""
        obligation = Finding(
            finding_id="OBL-1",
            rule_id="DOC-001",
            severity=Severity.CRITICAL,
            message="Must have dev plan",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0,
            is_obligation=True,
        )
        config = GuardConfig()  # fails on critical
        result = evaluate_gate([obligation], config)
        assert result.passed is True
        assert result.total_findings == 0

    def test_obligations_excluded_mixed(self):
        """Obligations excluded but code findings still counted."""
        obligation = Finding(
            finding_id="OBL-1",
            rule_id="DOC-001",
            severity=Severity.CRITICAL,
            message="Must have dev plan",
            evidence=Evidence(file="<project>", lines=[], snippet=""),
            confidence=1.0,
            is_obligation=True,
        )
        code_finding = make_finding(fid="C1", sev=Severity.LOW)
        config = GuardConfig()
        result = evaluate_gate([obligation, code_finding], config)
        assert result.passed is True
        assert result.total_findings == 1
        assert result.low == 1
        assert result.critical == 0


# ===================================================================
# build_autofix_map
# ===================================================================


class TestBuildAutofixMap:
    def test_empty_rules(self):
        assert build_autofix_map([]) == {}

    def test_rules_with_autofix(self):
        rules = [{"id": "R1", "autofix": "remove_line"}]
        assert build_autofix_map(rules) == {"R1": "remove_line"}

    def test_without_autofix_skipped(self):
        rules = [{"id": "R1", "name": "test"}]
        assert build_autofix_map(rules) == {}

    def test_mixed(self):
        rules = [
            {"id": "R1", "autofix": "remove_line"},
            {"id": "R2", "name": "no-fix"},
            {"id": "R3", "autofix": "replace_match"},
        ]
        result = build_autofix_map(rules)
        assert result == {"R1": "remove_line", "R3": "replace_match"}

    def test_no_id_skipped(self):
        rules = [{"autofix": "remove_line"}]
        assert build_autofix_map(rules) == {}


# ===================================================================
# build_replacement_map
# ===================================================================


class TestBuildReplacementMap:
    def test_empty_rules(self):
        assert build_replacement_map([]) == {}

    def test_with_replacement(self):
        rules = [{"id": "R1", "autofix_replacement": "safe_call()"}]
        assert build_replacement_map(rules) == {"R1": "safe_call()"}

    def test_without_replacement_skipped(self):
        rules = [{"id": "R1", "name": "test"}]
        assert build_replacement_map(rules) == {}

    def test_empty_string_kept(self):
        rules = [{"id": "R1", "autofix_replacement": ""}]
        assert build_replacement_map(rules) == {"R1": ""}


# ===================================================================
# Historical audit reports
# ===================================================================


class TestHistoricalReports:
    def _config(self, tmp_path, **kw):
        return GuardConfig(output_dir=str(tmp_path / "out"), **kw)

    def _write_two_runs(self, tmp_path):
        """Write two sequential scan runs, creating history."""
        config = self._config(tmp_path)
        f1 = make_finding(fid="F1", msg="First run finding")
        # First run
        out = write_artifacts([f1], config, "scan", 0, 100.0)
        meta1 = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        run_id_1 = meta1["run_id"]

        # Second run — archives the first
        f2 = make_finding(fid="F2", msg="Second run finding")
        write_artifacts([f2], config, "gate", 1, 200.0)
        meta2 = json.loads((out / "run_metadata.json").read_text(encoding="utf-8"))
        run_id_2 = meta2["run_id"]

        return config, run_id_1, run_id_2

    def test_archive_creates_manifest(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        manifest = tmp_path / "out" / "history" / "manifest.jsonl"
        assert manifest.exists()
        lines = manifest.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) >= 1
        entry = json.loads(lines[0])
        assert entry["run_id"] == run_id_1

    def test_archive_includes_metadata(self, tmp_path):
        config, _, _ = self._write_two_runs(tmp_path)
        history = tmp_path / "out" / "history"
        metadata_files = list(history.glob("run_metadata_*.json"))
        assert len(metadata_files) >= 1

    def test_list_historical_runs(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        runs = list_historical_runs(config.output_dir)
        assert len(runs) >= 1
        run_ids = [r["run_id"] for r in runs]
        assert run_id_1 in run_ids

    def test_list_historical_runs_newest_first(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        runs = list_historical_runs(config.output_dir)
        # Most recent archived run should be first
        assert runs[0]["run_id"] == run_id_1

    def test_list_historical_runs_empty_dir(self, tmp_path):
        runs = list_historical_runs(str(tmp_path / "nonexistent"))
        assert runs == []

    def test_load_historical_findings(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        findings = load_historical_findings(config.output_dir, run_id_1)
        assert findings is not None
        assert len(findings) == 1
        assert findings[0].finding_id == "F1"

    def test_load_historical_findings_not_found(self, tmp_path):
        config, _, _ = self._write_two_runs(tmp_path)
        result = load_historical_findings(config.output_dir, "nonexistent-id")
        assert result is None

    def test_load_historical_metadata(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        meta = load_historical_metadata(config.output_dir, run_id_1)
        assert meta is not None
        assert meta["run_id"] == run_id_1
        assert meta["command"] == "scan"

    def test_load_historical_metadata_not_found(self, tmp_path):
        config, _, _ = self._write_two_runs(tmp_path)
        result = load_historical_metadata(config.output_dir, "nonexistent-id")
        assert result is None

    def test_get_current_run_id(self, tmp_path):
        config = self._config(tmp_path)
        write_artifacts([], config, "scan", 0, 0)
        run_id = get_current_run_id(config.output_dir)
        assert run_id is not None
        assert len(run_id) == 36  # UUID format

    def test_get_current_run_id_no_metadata(self, tmp_path):
        assert get_current_run_id(str(tmp_path)) is None

    def test_manifest_contains_command_and_count(self, tmp_path):
        config, run_id_1, _ = self._write_two_runs(tmp_path)
        runs = list_historical_runs(config.output_dir)
        first_run = next(r for r in runs if r["run_id"] == run_id_1)
        assert first_run["command"] == "scan"
        assert first_run["findings_count"] == 1

    def test_manifest_trimmed_to_max_history(self, tmp_path):
        config = self._config(tmp_path)
        # Write 25 runs (max_history defaults to 20)
        for i in range(25):
            write_artifacts([make_finding(fid=f"F{i}")], config, "scan", 0, 0)
        # Write one final to trigger archive of the 25th
        write_artifacts([], config, "scan", 0, 0)

        manifest = tmp_path / "out" / "history" / "manifest.jsonl"
        lines = manifest.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) <= 20
