"""Tests for OAuth 2.0 Device Authorization Grant flow."""

from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch

import pytest

from guard.auth.device_flow import (
    DeviceCodeResponse,
    TokenResponse,
    clear_tokens,
    get_valid_token,
    load_tokens,
    poll_for_tokens,
    refresh_access_token,
    request_device_code,
    save_tokens,
)


def _make_device_code_json() -> dict:
    return {
        "device_code": "dev-abc123",
        "user_code": "ABCD-1234",
        "verification_uri": "https://example.auth0.com/activate",
        "verification_uri_complete": "https://example.auth0.com/activate?user_code=ABCD-1234",
        "expires_in": 900,
        "interval": 5,
    }


def _make_token_json() -> dict:
    return {
        "access_token": "eyJ-access",
        "refresh_token": "eyJ-refresh",
        "id_token": "eyJ-id",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email offline_access",
    }


class TestRequestDeviceCode:
    """Tests for request_device_code."""

    @patch("guard.auth.device_flow.httpx.post")
    def test_request_device_code_success(self, mock_post: MagicMock) -> None:
        """Mock httpx.post to return 200 with device code data and verify DeviceCodeResponse fields."""
        payload = _make_device_code_json()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = payload
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        result = request_device_code(domain="test.auth0.com", client_id="cli-id", audience="https://api.test.dev")

        assert isinstance(result, DeviceCodeResponse)
        assert result.device_code == "dev-abc123"
        assert result.user_code == "ABCD-1234"
        assert result.verification_uri == "https://example.auth0.com/activate"
        assert result.verification_uri_complete == "https://example.auth0.com/activate?user_code=ABCD-1234"
        assert result.expires_in == 900
        assert result.interval == 5
        mock_post.assert_called_once()
        call_url = mock_post.call_args[0][0]
        assert call_url == "https://test.auth0.com/oauth/device/code"

    def test_request_device_code_missing_config(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Call with no domain/client_id and no env vars. Expect ValueError."""
        monkeypatch.delenv("GUARD_AUTH0_DOMAIN", raising=False)
        monkeypatch.delenv("GUARD_AUTH0_CLI_CLIENT_ID", raising=False)

        with pytest.raises(ValueError, match="Auth0 domain and client ID are required"):
            request_device_code()


class TestPollForTokens:
    """Tests for poll_for_tokens."""

    @patch("guard.auth.device_flow.time.sleep")
    @patch("guard.auth.device_flow.httpx.post")
    def test_poll_pending_then_success(self, mock_post: MagicMock, mock_sleep: MagicMock) -> None:
        """Return authorization_pending once, then succeed with tokens."""
        pending_resp = MagicMock()
        pending_resp.status_code = 403
        pending_resp.json.return_value = {"error": "authorization_pending"}

        success_resp = MagicMock()
        success_resp.status_code = 200
        success_resp.json.return_value = _make_token_json()

        mock_post.side_effect = [pending_resp, success_resp]

        result = poll_for_tokens(
            domain="test.auth0.com",
            client_id="cli-id",
            device_code="dev-abc123",
            interval=0,
            timeout=10,
        )

        assert isinstance(result, TokenResponse)
        assert result.access_token == "eyJ-access"
        assert result.refresh_token == "eyJ-refresh"
        assert mock_post.call_count == 2

    @patch("guard.auth.device_flow.time.sleep")
    @patch("guard.auth.device_flow.httpx.post")
    def test_poll_timeout(self, mock_post: MagicMock, mock_sleep: MagicMock) -> None:
        """Always return authorization_pending. Expect TimeoutError."""
        pending_resp = MagicMock()
        pending_resp.status_code = 403
        pending_resp.json.return_value = {"error": "authorization_pending"}
        mock_post.return_value = pending_resp

        with pytest.raises(TimeoutError, match="Polling timed out"):
            poll_for_tokens(
                domain="test.auth0.com",
                client_id="cli-id",
                device_code="dev-abc123",
                interval=0,
                timeout=1,
            )

    @patch("guard.auth.device_flow.time.sleep")
    @patch("guard.auth.device_flow.httpx.post")
    def test_poll_slow_down(self, mock_post: MagicMock, mock_sleep: MagicMock) -> None:
        """Return slow_down once, then succeed. Verify interval increases."""
        slow_resp = MagicMock()
        slow_resp.status_code = 403
        slow_resp.json.return_value = {"error": "slow_down"}

        success_resp = MagicMock()
        success_resp.status_code = 200
        success_resp.json.return_value = _make_token_json()

        mock_post.side_effect = [slow_resp, success_resp]

        result = poll_for_tokens(
            domain="test.auth0.com",
            client_id="cli-id",
            device_code="dev-abc123",
            interval=0,
            timeout=60,
        )

        assert isinstance(result, TokenResponse)
        assert result.access_token == "eyJ-access"
        # After slow_down, interval should have increased by 5
        # First sleep(0), then sleep(5) after slow_down bumps interval to 5
        assert mock_sleep.call_count == 2
        second_sleep_arg = mock_sleep.call_args_list[1][0][0]
        assert second_sleep_arg == 5


class TestTokenPersistence:
    """Tests for save_tokens, load_tokens, and clear_tokens."""

    def test_save_load_roundtrip(self, tmp_path: pytest.TempPathFactory) -> None:
        """Create TokenResponse, save to tmp file, load back, verify fields match."""
        tokens = TokenResponse(
            access_token="eyJ-access",
            refresh_token="eyJ-refresh",
            id_token="eyJ-id",
            token_type="Bearer",
            expires_in=86400,
            scope="openid profile email offline_access",
        )
        auth_file = str(tmp_path / "auth.json")
        path = save_tokens(tokens, auth_file=auth_file)

        assert path.exists()

        loaded = load_tokens(auth_file=auth_file)
        assert loaded is not None
        assert loaded["access_token"] == "eyJ-access"
        assert loaded["refresh_token"] == "eyJ-refresh"
        assert loaded["id_token"] == "eyJ-id"
        assert loaded["token_type"] == "Bearer"
        assert loaded["expires_in"] == 86400
        assert loaded["scope"] == "openid profile email offline_access"
        assert "saved_at" in loaded

    def test_load_tokens_missing(self, tmp_path: pytest.TempPathFactory) -> None:
        """load_tokens with nonexistent file returns None."""
        result = load_tokens(auth_file=str(tmp_path / "nonexistent.json"))
        assert result is None

    def test_clear_tokens(self, tmp_path: pytest.TempPathFactory) -> None:
        """Create file, clear_tokens returns True and file deleted. Missing returns False."""
        auth_file = str(tmp_path / "auth.json")
        tokens = TokenResponse(
            access_token="a", refresh_token="r", id_token="i",
            token_type="Bearer", expires_in=3600, scope="openid",
        )
        save_tokens(tokens, auth_file=auth_file)

        assert clear_tokens(auth_file=auth_file) is True
        assert not (tmp_path / "auth.json").exists()
        assert clear_tokens(auth_file=auth_file) is False


class TestRefreshAccessToken:
    """Tests for refresh_access_token."""

    @patch("guard.auth.device_flow.httpx.post")
    def test_refresh_access_token(self, mock_post: MagicMock) -> None:
        """Mock httpx.post to return 200 with new token data. Verify TokenResponse."""
        new_tokens = {
            "access_token": "eyJ-new-access",
            "refresh_token": "eyJ-new-refresh",
            "id_token": "eyJ-new-id",
            "token_type": "Bearer",
            "expires_in": 86400,
            "scope": "openid profile",
        }
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = new_tokens
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        result = refresh_access_token(
            domain="test.auth0.com",
            client_id="cli-id",
            refresh_token="eyJ-old-refresh",
        )

        assert isinstance(result, TokenResponse)
        assert result.access_token == "eyJ-new-access"
        assert result.refresh_token == "eyJ-new-refresh"
        mock_post.assert_called_once()


class TestGetValidToken:
    """Tests for get_valid_token."""

    def test_get_valid_token_fresh(self, tmp_path: pytest.TempPathFactory) -> None:
        """Write auth.json with saved_at=now and expires_in=3600. Should return access_token without refresh."""
        auth_file = str(tmp_path / "auth.json")
        data = {
            "access_token": "eyJ-fresh",
            "refresh_token": "eyJ-refresh",
            "id_token": "eyJ-id",
            "token_type": "Bearer",
            "expires_in": 3600,
            "scope": "openid",
            "saved_at": int(time.time()),
        }
        (tmp_path / "auth.json").write_text(json.dumps(data), encoding="utf-8")

        result = get_valid_token(domain="test.auth0.com", client_id="cli-id", auth_file=auth_file)

        assert result == "eyJ-fresh"

    @patch("guard.auth.device_flow.httpx.post")
    def test_get_valid_token_stale(self, mock_post: MagicMock, tmp_path: pytest.TempPathFactory) -> None:
        """Write auth.json with saved_at far in the past. Mock refresh to succeed. Verify new token returned and saved."""
        auth_file = str(tmp_path / "auth.json")
        data = {
            "access_token": "eyJ-old",
            "refresh_token": "eyJ-refresh",
            "id_token": "eyJ-id",
            "token_type": "Bearer",
            "expires_in": 3600,
            "scope": "openid",
            "saved_at": int(time.time()) - 7200,  # 2 hours ago, well past expiry
        }
        (tmp_path / "auth.json").write_text(json.dumps(data), encoding="utf-8")

        refreshed_tokens = {
            "access_token": "eyJ-refreshed",
            "refresh_token": "eyJ-new-refresh",
            "id_token": "eyJ-new-id",
            "token_type": "Bearer",
            "expires_in": 86400,
            "scope": "openid",
        }
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = refreshed_tokens
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        result = get_valid_token(domain="test.auth0.com", client_id="cli-id", auth_file=auth_file)

        assert result == "eyJ-refreshed"
        # Verify tokens were saved back to disk
        saved = json.loads((tmp_path / "auth.json").read_text(encoding="utf-8"))
        assert saved["access_token"] == "eyJ-refreshed"
        assert saved["refresh_token"] == "eyJ-new-refresh"
