"""Tests for requirement drift detection (verify-reqs)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from guard.core.models import Evidence, Finding, GeneratedRequirement
from guard.core.requirements_verifier import (
    _build_verification_prompt,
    _parse_verification_response,
    load_requirements,
    verify_requirements,
    verify_requirements_stub,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_req():
    return GeneratedRequirement(
        req_id="REQ-GEN-001",
        title="User authentication module",
        description="Handles user login via password and token refresh",
        acceptance_criteria=[
            "Users can log in with email and password",
            "Tokens refresh automatically on expiry",
        ],
        source_files=["src/auth.py"],
        status="draft",
    )


@pytest.fixture
def sample_req_no_files():
    return GeneratedRequirement(
        req_id="REQ-GEN-002",
        title="Documentation obligation",
        description="Must document security procedures",
        source_files=[],
        status="draft",
    )


@pytest.fixture
def rejected_req():
    return GeneratedRequirement(
        req_id="REQ-GEN-003",
        title="Rejected feature",
        description="This was rejected",
        source_files=["src/removed.py"],
        status="rejected",
    )


@pytest.fixture
def tmp_repo(tmp_path):
    """Create a temp repo with a source file."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "auth.py").write_text(
        'def login(email, password):\n    """Authenticate user."""\n    return True\n',
        encoding="utf-8",
    )
    return tmp_path


@pytest.fixture
def tmp_repo_missing_file(tmp_path):
    """Repo where the referenced file does not exist."""
    return tmp_path


@pytest.fixture
def tmp_repo_empty_file(tmp_path):
    """Repo where the referenced file is empty."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "auth.py").write_text("", encoding="utf-8")
    return tmp_path


# ---------------------------------------------------------------------------
# load_requirements
# ---------------------------------------------------------------------------

class TestLoadRequirements:
    def test_load_from_dict_format(self, tmp_path):
        path = tmp_path / "requirements.yaml"
        path.write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Test\n"
            "    source_files: [src/a.py]\n",
            encoding="utf-8",
        )
        reqs = load_requirements(path)
        assert len(reqs) == 1
        assert reqs[0].req_id == "REQ-GEN-001"

    def test_load_from_list_format(self, tmp_path):
        path = tmp_path / "requirements.yaml"
        path.write_text(
            "- req_id: REQ-GEN-001\n"
            "  title: Test\n"
            "  source_files: [src/a.py]\n",
            encoding="utf-8",
        )
        reqs = load_requirements(path)
        assert len(reqs) == 1

    def test_load_nonexistent(self, tmp_path):
        reqs = load_requirements(tmp_path / "missing.yaml")
        assert reqs == []

    def test_load_invalid_yaml(self, tmp_path):
        path = tmp_path / "bad.yaml"
        path.write_text(": : : invalid", encoding="utf-8")
        reqs = load_requirements(path)
        assert reqs == []

    def test_load_skips_invalid_entries(self, tmp_path):
        path = tmp_path / "requirements.yaml"
        path.write_text(
            "requirements:\n"
            "  - req_id: REQ-GEN-001\n"
            "    title: Valid\n"
            "  - not_a_req: true\n",
            encoding="utf-8",
        )
        reqs = load_requirements(path)
        assert len(reqs) == 1


# ---------------------------------------------------------------------------
# _build_verification_prompt
# ---------------------------------------------------------------------------

class TestBuildVerificationPrompt:
    def test_prompt_contains_requirement_details(self, sample_req):
        prompt, ctx = _build_verification_prompt(
            sample_req, {"src/auth.py": "def login(): pass"}
        )
        assert "REQ-GEN-001" in prompt
        assert "User authentication module" in prompt
        assert "Handles user login" in prompt
        assert "Users can log in" in prompt
        assert "src/auth.py" in prompt
        assert "def login(): pass" in prompt
        assert ctx["req_id"] == "REQ-GEN-001"

    def test_prompt_with_no_acceptance_criteria(self):
        req = GeneratedRequirement(
            req_id="REQ-GEN-010",
            title="Empty criteria",
            source_files=["x.py"],
        )
        prompt, _ = _build_verification_prompt(req, {"x.py": "pass"})
        assert "(none)" in prompt


# ---------------------------------------------------------------------------
# _parse_verification_response
# ---------------------------------------------------------------------------

class TestParseVerificationResponse:
    def test_no_drift(self, sample_req):
        response = {"matches": True, "drifts": []}
        findings = _parse_verification_response(response, sample_req)
        assert findings == []

    def test_drift_detected(self, sample_req):
        response = {
            "matches": False,
            "drifts": [
                {
                    "description": "Requirement says tokens refresh but code has no refresh logic",
                    "severity": "medium",
                    "file": "src/auth.py",
                    "suggestion": "Add token refresh functionality",
                }
            ],
        }
        findings = _parse_verification_response(response, sample_req)
        assert len(findings) == 1
        assert findings[0].severity == "medium"
        assert "tokens refresh" in findings[0].message
        assert findings[0].evidence.file == "src/auth.py"
        assert findings[0].suggestion == "Add token refresh functionality"
        assert findings[0].deterministic is False
        assert findings[0].confidence == 0.7

    def test_multiple_drifts(self, sample_req):
        response = {
            "matches": False,
            "drifts": [
                {"description": "Drift 1", "severity": "low", "file": "a.py"},
                {"description": "Drift 2", "severity": "medium", "file": "b.py"},
            ],
        }
        findings = _parse_verification_response(response, sample_req)
        assert len(findings) == 2

    def test_invalid_severity_defaults_to_low(self, sample_req):
        response = {
            "matches": False,
            "drifts": [{"description": "Drift", "severity": "banana", "file": "a.py"}],
        }
        findings = _parse_verification_response(response, sample_req)
        assert findings[0].severity == "low"

    def test_parse_from_summary_field(self, sample_req):
        response = {
            "summary": json.dumps({
                "matches": False,
                "drifts": [{"description": "Found drift", "severity": "low", "file": "src/auth.py"}],
            })
        }
        findings = _parse_verification_response(response, sample_req)
        assert len(findings) == 1

    def test_skips_non_dict_drifts(self, sample_req):
        response = {"matches": False, "drifts": ["not a dict", 42]}
        findings = _parse_verification_response(response, sample_req)
        assert findings == []

    def test_rule_id_includes_req_id(self, sample_req):
        response = {
            "matches": False,
            "drifts": [{"description": "Drift", "file": "a.py"}],
        }
        findings = _parse_verification_response(response, sample_req)
        assert findings[0].rule_id == "REQ-DRIFT-REQ-GEN-001"

    def test_tags_present(self, sample_req):
        response = {
            "matches": False,
            "drifts": [{"description": "Drift", "file": "a.py"}],
        }
        findings = _parse_verification_response(response, sample_req)
        assert "requirement-drift" in findings[0].tags
        assert "verification" in findings[0].tags


# ---------------------------------------------------------------------------
# verify_requirements (LLM)
# ---------------------------------------------------------------------------

class TestVerifyRequirements:
    def test_calls_llm_and_returns_findings(self, sample_req, tmp_repo):
        llm = MagicMock()
        llm.analyze.return_value = {
            "matches": False,
            "drifts": [
                {"description": "Login does not validate password", "severity": "medium", "file": "src/auth.py"},
            ],
        }
        findings = verify_requirements([sample_req], str(tmp_repo), llm)
        assert len(findings) == 1
        llm.analyze.assert_called_once()

    def test_skips_rejected_requirements(self, rejected_req, tmp_repo):
        llm = MagicMock()
        findings = verify_requirements([rejected_req], str(tmp_repo), llm)
        assert findings == []
        llm.analyze.assert_not_called()

    def test_skips_requirements_without_files(self, sample_req_no_files, tmp_repo):
        llm = MagicMock()
        findings = verify_requirements([sample_req_no_files], str(tmp_repo), llm)
        assert findings == []
        llm.analyze.assert_not_called()

    def test_skips_when_source_files_missing(self, sample_req, tmp_repo_missing_file):
        llm = MagicMock()
        findings = verify_requirements([sample_req], str(tmp_repo_missing_file), llm)
        assert findings == []
        llm.analyze.assert_not_called()

    def test_handles_llm_error_gracefully(self, sample_req, tmp_repo):
        llm = MagicMock()
        llm.analyze.side_effect = ValueError("LLM unavailable")
        findings = verify_requirements([sample_req], str(tmp_repo), llm)
        assert findings == []

    def test_no_drift_returns_empty(self, sample_req, tmp_repo):
        llm = MagicMock()
        llm.analyze.return_value = {"matches": True, "drifts": []}
        findings = verify_requirements([sample_req], str(tmp_repo), llm)
        assert findings == []


# ---------------------------------------------------------------------------
# verify_requirements_stub
# ---------------------------------------------------------------------------

class TestVerifyRequirementsStub:
    def test_no_drift_when_files_exist(self, sample_req, tmp_repo):
        findings = verify_requirements_stub([sample_req], str(tmp_repo))
        assert findings == []

    def test_drift_when_file_missing(self, sample_req, tmp_repo_missing_file):
        findings = verify_requirements_stub([sample_req], str(tmp_repo_missing_file))
        assert len(findings) == 1
        assert "no longer exists" in findings[0].message
        assert findings[0].severity == "medium"
        assert findings[0].deterministic is True
        assert "missing-file" in findings[0].tags

    def test_drift_when_file_empty(self, sample_req, tmp_repo_empty_file):
        findings = verify_requirements_stub([sample_req], str(tmp_repo_empty_file))
        assert len(findings) == 1
        assert "empty" in findings[0].message
        assert findings[0].severity == "low"
        assert "empty-file" in findings[0].tags

    def test_skips_rejected(self, rejected_req, tmp_repo):
        findings = verify_requirements_stub([rejected_req], str(tmp_repo))
        assert findings == []

    def test_skips_no_source_files(self, sample_req_no_files, tmp_repo):
        findings = verify_requirements_stub([sample_req_no_files], str(tmp_repo))
        assert findings == []

    def test_multiple_reqs(self, tmp_path):
        (tmp_path / "a.py").write_text("code", encoding="utf-8")
        reqs = [
            GeneratedRequirement(req_id="R1", title="A", source_files=["a.py"]),
            GeneratedRequirement(req_id="R2", title="B", source_files=["missing.py"]),
        ]
        findings = verify_requirements_stub(reqs, str(tmp_path))
        assert len(findings) == 1
        assert "missing.py" in findings[0].message
