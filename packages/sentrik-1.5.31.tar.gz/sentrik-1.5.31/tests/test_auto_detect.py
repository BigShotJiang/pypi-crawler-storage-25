"""Tests for zero-config auto-detection and .sentrik/ config directory."""

from __future__ import annotations

import os
import textwrap
from pathlib import Path

import pytest

from guard.core.auto_detect import ProjectProfile, detect_project
from guard.config import (
    CONFIG_FILENAME,
    SENTRIK_CONFIG_FILENAME,
    GuardConfig,
    ensure_sentrik_dir,
    resolve_config_path,
)


# ---------------------------------------------------------------------------
# detect_project()
# ---------------------------------------------------------------------------

class TestDetectProject:
    """Test auto-detection of project characteristics."""

    def test_empty_directory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        profile = detect_project(tmp_path)
        assert isinstance(profile, ProjectProfile)
        assert profile.languages == []
        assert profile.ci_platform is None
        # owasp-top-10 always included as baseline
        assert "owasp-top-10" in profile.suggested_packs
        assert profile.governance_profile == "standard"

    def test_python_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text("[project]\nname='foo'\n")
        profile = detect_project(tmp_path)
        assert "python" in profile.languages

    def test_python_from_requirements(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "requirements.txt").write_text("flask\n")
        profile = detect_project(tmp_path)
        assert "python" in profile.languages

    def test_python_from_py_files(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "app.py").write_text("print('hi')\n")
        profile = detect_project(tmp_path)
        assert "python" in profile.languages

    def test_node_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "package.json").write_text('{"name":"foo"}')
        profile = detect_project(tmp_path)
        assert "javascript" in profile.languages

    def test_typescript_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "tsconfig.json").write_text("{}")
        (tmp_path / "package.json").write_text('{"name":"foo"}')
        profile = detect_project(tmp_path)
        assert "typescript" in profile.languages
        assert "javascript" in profile.languages

    def test_java_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pom.xml").write_text("<project/>")
        profile = detect_project(tmp_path)
        assert "java" in profile.languages

    def test_go_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "go.mod").write_text("module example.com/foo")
        profile = detect_project(tmp_path)
        assert "go" in profile.languages

    def test_rust_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "Cargo.toml").write_text("[package]\nname='foo'\n")
        profile = detect_project(tmp_path)
        assert "rust" in profile.languages

    def test_github_ci(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".github" / "workflows").mkdir(parents=True)
        profile = detect_project(tmp_path)
        assert profile.ci_platform == "github"

    def test_azure_ci(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "azure-pipelines.yml").write_text("trigger: none")
        profile = detect_project(tmp_path)
        assert profile.ci_platform == "azure"

    def test_gitlab_ci(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".gitlab-ci.yml").write_text("stages: [build]")
        profile = detect_project(tmp_path)
        assert profile.ci_platform == "gitlab"

    def test_medical_device_readme(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "README.md").write_text("# Project\nCompliant with IEC 62304.\n")
        profile = detect_project(tmp_path)
        assert "fda-iec-62304" in profile.suggested_packs
        assert "owasp-top-10" in profile.suggested_packs

    def test_fda_readme(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "README.md").write_text("# FDA submission\nRegulatory docs.\n")
        profile = detect_project(tmp_path)
        assert "fda-iec-62304" in profile.suggested_packs

    def test_soc2_readme(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "README.md").write_text("# Project\nSOC 2 compliant.\n")
        profile = detect_project(tmp_path)
        assert "soc2" in profile.suggested_packs

    def test_multi_language_project(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text("[project]\nname='foo'\n")
        (tmp_path / "package.json").write_text('{"name":"foo"}')
        (tmp_path / "go.mod").write_text("module example.com/foo")
        profile = detect_project(tmp_path)
        assert "python" in profile.languages
        assert "javascript" in profile.languages
        assert "go" in profile.languages

    def test_owasp_always_included(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        profile = detect_project(tmp_path)
        assert "owasp-top-10" in profile.suggested_packs


# ---------------------------------------------------------------------------
# Config resolution order
# ---------------------------------------------------------------------------

class TestConfigResolution:
    """Test config file resolution order."""

    def test_explicit_path_takes_precedence(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        explicit = tmp_path / "custom.yaml"
        explicit.write_text("output_dir: custom\n")
        resolved = resolve_config_path(explicit)
        assert resolved == explicit

    def test_sentrik_config_over_guard(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".sentrik").mkdir()
        (tmp_path / ".sentrik" / "config.yaml").write_text("output_dir: sentrik\n")
        (tmp_path / ".guard.yaml").write_text("output_dir: guard\n")
        resolved = resolve_config_path()
        assert resolved == Path(SENTRIK_CONFIG_FILENAME)

    def test_guard_yaml_fallback(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".guard.yaml").write_text("output_dir: guard\n")
        resolved = resolve_config_path()
        assert resolved == Path(CONFIG_FILENAME)

    def test_no_config_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        resolved = resolve_config_path()
        assert resolved is None

    def test_load_reads_sentrik_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".sentrik").mkdir()
        (tmp_path / ".sentrik" / "config.yaml").write_text("output_dir: from_sentrik\n")
        config = GuardConfig.load()
        assert config.output_dir == "from_sentrik"

    def test_load_reads_guard_yaml_fallback(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".guard.yaml").write_text("output_dir: from_guard\n")
        config = GuardConfig.load()
        assert config.output_dir == "from_guard"

    def test_load_no_config_returns_defaults(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig.load()
        assert config.output_dir == "out"  # default


# ---------------------------------------------------------------------------
# from_profile()
# ---------------------------------------------------------------------------

class TestFromProfile:
    """Test GuardConfig.from_profile()."""

    def test_basic_profile(self):
        profile = ProjectProfile(
            languages=["python"],
            ci_platform="github",
            suggested_packs=["owasp-top-10"],
            governance_profile="standard",
        )
        config = GuardConfig.from_profile(profile)
        assert config.standards_packs == ["owasp-top-10"]
        assert config.devops_provider == "github"
        assert config.governance == {"profile": "standard"}

    def test_azure_platform(self):
        profile = ProjectProfile(ci_platform="azure", suggested_packs=["owasp-top-10"])
        config = GuardConfig.from_profile(profile)
        assert config.devops_provider == "azure"

    def test_no_platform(self):
        profile = ProjectProfile(suggested_packs=["owasp-top-10"])
        config = GuardConfig.from_profile(profile)
        assert config.devops_provider == "stub"

    def test_multiple_packs(self):
        profile = ProjectProfile(
            suggested_packs=["fda-iec-62304", "owasp-top-10", "soc2"]
        )
        config = GuardConfig.from_profile(profile)
        assert config.standards_packs == ["fda-iec-62304", "owasp-top-10", "soc2"]

    def test_produces_valid_config(self):
        profile = ProjectProfile(
            languages=["python"],
            suggested_packs=["owasp-top-10"],
        )
        config = GuardConfig.from_profile(profile)
        # Should not raise
        warnings = config.validate_config()
        errors = [w for w in warnings if w.level == "error"]
        assert len(errors) == 0


# ---------------------------------------------------------------------------
# ensure_sentrik_dir()
# ---------------------------------------------------------------------------

class TestEnsureSentrikDir:
    """Test .sentrik/ directory creation."""

    def test_creates_structure(self, tmp_path):
        sentrik_dir = ensure_sentrik_dir(tmp_path)
        assert sentrik_dir == tmp_path / ".sentrik"
        assert (tmp_path / ".sentrik" / "rules").is_dir()
        assert (tmp_path / ".sentrik" / "local").is_dir()
        assert (tmp_path / ".sentrik" / ".gitignore").exists()
        assert "local/" in (tmp_path / ".sentrik" / ".gitignore").read_text()

    def test_idempotent(self, tmp_path):
        ensure_sentrik_dir(tmp_path)
        ensure_sentrik_dir(tmp_path)  # should not raise
        assert (tmp_path / ".sentrik" / "rules").is_dir()


# ---------------------------------------------------------------------------
# save() defaults to .sentrik/config.yaml
# ---------------------------------------------------------------------------

class TestSaveDefaults:
    """Test that save() writes to .sentrik/config.yaml by default."""

    def test_save_creates_sentrik_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = GuardConfig()
        path = config.save()
        assert path == Path(SENTRIK_CONFIG_FILENAME)
        assert (tmp_path / ".sentrik" / "config.yaml").exists()


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------

class TestBackwardCompat:
    """Test that .guard.yaml still works."""

    def test_guard_yaml_still_loads(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".guard.yaml").write_text(
            "output_dir: legacy\nstandards_packs:\n  - owasp-top-10\n"
        )
        config = GuardConfig.load()
        assert config.output_dir == "legacy"
        assert "owasp-top-10" in config.standards_packs

    def test_explicit_guard_yaml_path(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        guard_yaml = tmp_path / ".guard.yaml"
        guard_yaml.write_text("output_dir: explicit\n")
        config = GuardConfig.load(guard_yaml)
        assert config.output_dir == "explicit"


# ---------------------------------------------------------------------------
# Migrate command (CLI)
# ---------------------------------------------------------------------------

class TestMigrateCommand:
    """Test the migrate CLI command."""

    def test_migrate_copies_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".guard.yaml").write_text("output_dir: migrated\n")
        from typer.testing import CliRunner
        from guard.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["migrate"])
        assert result.exit_code == 0
        assert (tmp_path / ".sentrik" / "config.yaml").exists()
        import yaml
        data = yaml.safe_load((tmp_path / ".sentrik" / "config.yaml").read_text())
        assert data["output_dir"] == "migrated"

    def test_migrate_no_guard_yaml(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from typer.testing import CliRunner
        from guard.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["migrate"])
        assert result.exit_code == 0
        assert "nothing to migrate" in result.output.lower()

    def test_migrate_refuses_overwrite(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".guard.yaml").write_text("output_dir: old\n")
        (tmp_path / ".sentrik").mkdir()
        (tmp_path / ".sentrik" / "config.yaml").write_text("output_dir: new\n")
        from typer.testing import CliRunner
        from guard.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["migrate"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# Sentrik rules directory in registry
# ---------------------------------------------------------------------------

class TestSentrikRulesDir:
    """Test that .sentrik/rules/ is checked for custom packs."""

    def test_discovers_sentrik_rules(self, tmp_path):
        rules_dir = tmp_path / ".sentrik" / "rules" / "my-pack"
        rules_dir.mkdir(parents=True)
        (rules_dir / "pack.yaml").write_text(
            "name: My Pack\nrules:\n  - id: r1\n    name: Rule 1\n    type: regex\n    pattern: 'foo'\n    severity: low\n"
        )
        from guard.packs.registry import _discover_custom_pack_ids, load_pack_rules
        pack_ids = _discover_custom_pack_ids(tmp_path)
        assert "my-pack" in pack_ids
        rules = load_pack_rules("my-pack", tmp_path)
        assert len(rules) == 1
        assert rules[0]["id"] == "r1"

    def test_sentrik_rules_takes_precedence(self, tmp_path):
        """If same pack exists in both dirs, .sentrik/rules/ wins."""
        # Create in both locations
        for subdir, output in [(".sentrik/rules", "sentrik_out"), (".guard/packs", "guard_out")]:
            pack_dir = tmp_path / subdir / "my-pack"
            pack_dir.mkdir(parents=True)
            (pack_dir / "pack.yaml").write_text(
                f"name: My Pack\nrules:\n  - id: r1\n    name: Rule 1\n    type: regex\n    pattern: '{output}'\n    severity: low\n"
            )
        from guard.packs.registry import load_pack_rules
        rules = load_pack_rules("my-pack", tmp_path)
        assert rules[0]["pattern"] == "sentrik_out"

    def test_guard_packs_still_works(self, tmp_path):
        """Legacy .guard/packs/ still discovered when .sentrik/rules/ doesn't exist."""
        pack_dir = tmp_path / ".guard" / "packs" / "legacy-pack"
        pack_dir.mkdir(parents=True)
        (pack_dir / "pack.yaml").write_text(
            "name: Legacy\nrules:\n  - id: l1\n    name: Legacy Rule\n    type: regex\n    pattern: 'bar'\n    severity: low\n"
        )
        from guard.packs.registry import _discover_custom_pack_ids
        pack_ids = _discover_custom_pack_ids(tmp_path)
        assert "legacy-pack" in pack_ids
