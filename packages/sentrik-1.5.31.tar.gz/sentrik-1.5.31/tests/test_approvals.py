"""Tests for the Async Approval Gates feature (Phase 3)."""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone

import pytest

from guard.core.approvals import (
    ApprovalRequest,
    AsyncApprovalConfig,
    MemoryApprovalStore,
    create_approval_request,
    get_approval_store,
    set_approval_store,
)
from guard.core.models import GateResult


# ---------------------------------------------------------------------------
# AsyncApprovalConfig
# ---------------------------------------------------------------------------

class TestAsyncApprovalConfig:
    def test_defaults(self):
        cfg = AsyncApprovalConfig()
        assert cfg.enabled is False
        assert cfg.timeout_seconds == 3600
        assert cfg.notify_roles == ["security-lead", "admin"]

    def test_custom(self):
        cfg = AsyncApprovalConfig(enabled=True, timeout_seconds=600, notify_roles=["admin"])
        assert cfg.enabled is True
        assert cfg.timeout_seconds == 600


# ---------------------------------------------------------------------------
# ApprovalRequest
# ---------------------------------------------------------------------------

class TestApprovalRequest:
    def test_defaults(self):
        req = ApprovalRequest()
        assert req.status == "pending"
        assert req.id  # UUID generated
        assert req.requested_by == ""
        assert req.resolved_by == ""

    def test_is_expired_within_ttl(self):
        req = ApprovalRequest(requested_at=datetime.now(timezone.utc))
        assert req.is_expired(timeout_seconds=3600) is False

    def test_is_expired_past_ttl(self):
        req = ApprovalRequest(
            requested_at=datetime.now(timezone.utc) - timedelta(seconds=7200)
        )
        assert req.is_expired(timeout_seconds=3600) is True

    def test_is_expired_already_resolved(self):
        req = ApprovalRequest(
            status="approved",
            requested_at=datetime.now(timezone.utc) - timedelta(seconds=7200),
        )
        # Already resolved — not expired even if past TTL
        assert req.is_expired(timeout_seconds=3600) is False


# ---------------------------------------------------------------------------
# MemoryApprovalStore
# ---------------------------------------------------------------------------

class TestMemoryApprovalStore:
    def test_create_and_get(self):
        store = MemoryApprovalStore()
        req = ApprovalRequest(requested_by="user1")
        created = store.create(req)
        assert created.id == req.id
        fetched = store.get(req.id)
        assert fetched is not None
        assert fetched.requested_by == "user1"

    def test_get_missing(self):
        store = MemoryApprovalStore()
        assert store.get("nonexistent") is None

    def test_resolve_approve(self):
        store = MemoryApprovalStore()
        req = ApprovalRequest()
        store.create(req)
        resolved = store.resolve(req.id, "approved", "admin-user", "looks good")
        assert resolved is not None
        assert resolved.status == "approved"
        assert resolved.resolved_by == "admin-user"
        assert resolved.comment == "looks good"
        assert resolved.resolved_at is not None

    def test_resolve_reject(self):
        store = MemoryApprovalStore()
        req = ApprovalRequest()
        store.create(req)
        resolved = store.resolve(req.id, "rejected", "sec-lead", "too risky")
        assert resolved.status == "rejected"

    def test_resolve_already_resolved(self):
        store = MemoryApprovalStore()
        req = ApprovalRequest()
        store.create(req)
        store.resolve(req.id, "approved", "user1")
        # Resolving again should return the already-resolved request unchanged
        result = store.resolve(req.id, "rejected", "user2")
        assert result.status == "approved"  # Still approved, not re-resolved

    def test_resolve_missing(self):
        store = MemoryApprovalStore()
        assert store.resolve("nonexistent", "approved", "user") is None

    def test_list_pending(self):
        store = MemoryApprovalStore()
        r1 = ApprovalRequest(requested_by="a")
        r2 = ApprovalRequest(requested_by="b")
        r3 = ApprovalRequest(requested_by="c")
        store.create(r1)
        store.create(r2)
        store.create(r3)
        store.resolve(r2.id, "approved", "admin")
        pending = store.list_pending()
        assert len(pending) == 2
        ids = {r.id for r in pending}
        assert r1.id in ids
        assert r3.id in ids

    def test_list_pending_empty(self):
        store = MemoryApprovalStore()
        assert store.list_pending() == []


# ---------------------------------------------------------------------------
# Singleton management
# ---------------------------------------------------------------------------

class TestSingleton:
    def test_get_creates_default(self):
        set_approval_store(None)  # type: ignore[arg-type]
        # Force reset
        import guard.core.approvals as m
        m._approval_store = None
        store = get_approval_store()
        assert isinstance(store, MemoryApprovalStore)

    def test_set_and_get(self):
        custom = MemoryApprovalStore()
        set_approval_store(custom)
        assert get_approval_store() is custom
        # Cleanup
        import guard.core.approvals as m
        m._approval_store = None


# ---------------------------------------------------------------------------
# create_approval_request (integration)
# ---------------------------------------------------------------------------

class TestCreateApprovalRequest:
    def setup_method(self):
        import guard.core.approvals as m
        m._approval_store = None

    def test_creates_and_stores(self):
        gate = GateResult(passed=False, total_findings=5, critical=2, high=3)
        cfg = AsyncApprovalConfig(enabled=True)
        req = create_approval_request(gate, cfg, user_id="dev@co.com")
        assert req.status == "pending"
        assert req.requested_by == "dev@co.com"
        assert req.findings_summary["critical"] == 2
        assert req.findings_summary["high"] == 3
        assert req.findings_summary["total"] == 5
        # Verify it's in the store
        store = get_approval_store()
        assert store.get(req.id) is not None

    def test_gate_result_summary_stored(self):
        gate = GateResult(passed=False, total_findings=1, critical=0, high=1)
        cfg = AsyncApprovalConfig(enabled=True)
        req = create_approval_request(gate, cfg)
        assert req.gate_result["passed"] is False
        assert req.gate_result["high"] == 1

    def test_full_lifecycle(self):
        """Create → get → approve → verify resolved."""
        gate = GateResult(passed=False, total_findings=3, critical=1, high=2)
        cfg = AsyncApprovalConfig(enabled=True, timeout_seconds=60)
        req = create_approval_request(gate, cfg, user_id="agent")

        store = get_approval_store()
        # Still pending
        assert store.get(req.id).status == "pending"
        assert len(store.list_pending()) == 1

        # Approve
        resolved = store.resolve(req.id, "approved", "sec-lead", "verified safe")
        assert resolved.status == "approved"
        assert len(store.list_pending()) == 0


# ---------------------------------------------------------------------------
# Config integration
# ---------------------------------------------------------------------------

class TestConfigIntegration:
    def test_guard_config_get_async_approval_config(self):
        from guard.config import GuardConfig
        cfg = GuardConfig(async_approval={"enabled": True, "timeout_seconds": 120})
        ac = cfg.get_async_approval_config()
        assert ac.enabled is True
        assert ac.timeout_seconds == 120

    def test_guard_config_default(self):
        from guard.config import GuardConfig
        cfg = GuardConfig()
        ac = cfg.get_async_approval_config()
        assert ac.enabled is False



# ---------------------------------------------------------------------------
# GateResult approval fields
# ---------------------------------------------------------------------------

class TestGateResultApprovalFields:
    def test_defaults(self):
        gr = GateResult(passed=True, total_findings=0)
        assert gr.approval_id == ""
        assert gr.pending_approval is False

    def test_set_fields(self):
        gr = GateResult(passed=False, total_findings=1, approval_id="abc-123", pending_approval=True)
        assert gr.approval_id == "abc-123"
        assert gr.pending_approval is True


# ---------------------------------------------------------------------------
# RBAC permissions for approvals
# ---------------------------------------------------------------------------

class TestApprovalPermissions:
    def test_agent_has_approval_request(self):
        from guard.authz.models import ROLE_PERMISSIONS, Permission
        assert Permission.APPROVAL_REQUEST in ROLE_PERMISSIONS["agent"]

    def test_security_lead_has_approval_review(self):
        from guard.authz.models import ROLE_PERMISSIONS, Permission
        assert Permission.APPROVAL_REVIEW in ROLE_PERMISSIONS["security-lead"]

    def test_admin_has_all_approval_perms(self):
        from guard.authz.models import ROLE_PERMISSIONS, Permission
        assert Permission.APPROVAL_REQUEST in ROLE_PERMISSIONS["admin"]
        assert Permission.APPROVAL_REVIEW in ROLE_PERMISSIONS["admin"]

    def test_developer_no_approval_review(self):
        from guard.authz.models import ROLE_PERMISSIONS, Permission
        assert Permission.APPROVAL_REVIEW not in ROLE_PERMISSIONS["developer"]

    def test_viewer_no_approval_perms(self):
        from guard.authz.models import ROLE_PERMISSIONS, Permission
        assert Permission.APPROVAL_REQUEST not in ROLE_PERMISSIONS["viewer"]
        assert Permission.APPROVAL_REVIEW not in ROLE_PERMISSIONS["viewer"]


# ---------------------------------------------------------------------------
# Licensing
# ---------------------------------------------------------------------------

class TestApprovalLicensing:
    def test_async_approval_enterprise_only(self):
        from guard.core.licensing import TIER_FEATURES
        assert "async_approval" in TIER_FEATURES["ENTERPRISE"]
        assert "async_approval" not in TIER_FEATURES["ORG"]
        assert "async_approval" not in TIER_FEATURES["TEAM"]

