"""Tests for the Jira Standards provider (Phase 23)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.providers.standards_jira import StandardsJira, _extract_yaml


# ===================================================================
# YAML extraction helper
# ===================================================================


class TestExtractYaml:
    def test_fenced_code_block(self):
        text = (
            "Some intro text.\n\n"
            "```yaml\n"
            "rules:\n"
            "  - id: STD-001\n"
            "```\n"
            "Some footer."
        )
        result = _extract_yaml(text)
        assert "rules:" in result
        assert "STD-001" in result
        assert "Some intro" not in result
        assert "Some footer" not in result

    def test_fenced_yml_block(self):
        text = "```yml\nrules:\n  - id: R1\n```\n"
        result = _extract_yaml(text)
        assert "rules:" in result

    def test_no_code_block_returns_raw(self):
        text = "rules:\n  - id: STD-001\n"
        result = _extract_yaml(text)
        assert result == text

    def test_empty_string(self):
        assert _extract_yaml("") == ""


# ===================================================================
# StandardsJira provider
# ===================================================================


SAMPLE_YAML = """\
rules:
  - id: STD-001
    name: no-todo-comments
    type: regex
    severity: low
    pattern: "# TODO"
    description: "TODO comments should be resolved"
  - id: STD-002
    name: no-print-statements
    type: regex
    severity: medium
    pattern: "print\\\\("
    description: "Use logging instead of print"
"""


def _make_jira_response(description: str) -> bytes:
    """Create a mock Jira issue API response body."""
    return json.dumps({
        "key": "STDS-1",
        "fields": {"description": description},
    }).encode()


class TestStandardsJira:
    def test_init_stores_params(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        assert p._base_url == "https://jira.example.com"
        assert p._issue_key == "STDS-1"

    def test_init_strips_trailing_slash(self):
        p = StandardsJira(base_url="https://jira.example.com/", issue_key="STDS-1")
        assert p._base_url == "https://jira.example.com"

    def test_get_rules_raw_yaml(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response(SAMPLE_YAML)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert len(rules) == 2
        assert rules[0]["id"] == "STD-001"
        assert rules[1]["id"] == "STD-002"

    def test_get_rules_code_block(self):
        desc = f"Some intro.\n\n```yaml\n{SAMPLE_YAML}```\n\nSome footer."
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response(desc)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert len(rules) == 2

    def test_get_rule_ids(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response(SAMPLE_YAML)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                ids = p.get_rule_ids()

        assert ids == ["STD-001", "STD-002"]

    def test_get_rules_http_error(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.HTTPError(
                "https://jira.example.com/test", 404, "Not Found", {}, None
            )
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert rules == []

    def test_get_rules_url_error(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert rules == []

    def test_get_rules_empty_description(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response("")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert rules == []

    def test_get_rules_null_description(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "key": "STDS-1",
            "fields": {"description": None},
        }).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                rules = p.get_rules()

        assert rules == []

    def test_auth_header_with_user_token(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me@corp.com", "JIRA_TOKEN": "tok123"}, clear=True):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert req.get_header("Authorization").startswith("Basic ")

    def test_auth_header_with_pat(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-1")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", _home_env(JIRA_PAT="pat456"), clear=True):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer pat456"

    def test_url_construction(self):
        p = StandardsJira(base_url="https://jira.example.com", issue_key="STDS-42")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_jira_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", _home_env(JIRA_PAT="tok"), clear=True):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert "STDS-42" in req.full_url
        assert "rest/api/2/issue" in req.full_url
