"""Tests for the Jira DevOps provider (Phase 23)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from tests.conftest import _home_env

from guard.providers.devops_jira import (
    DevOpsJira,
    _extract_acceptance_criteria,
    _normalize_state,
)


# ===================================================================
# State normalization
# ===================================================================


class TestNormalizeState:
    def test_open_maps_to_active(self):
        assert _normalize_state("Open") == "active"

    def test_in_progress_maps_to_active(self):
        assert _normalize_state("In Progress") == "active"

    def test_to_do_maps_to_active(self):
        assert _normalize_state("To Do") == "active"

    def test_done_maps_to_closed(self):
        assert _normalize_state("Done") == "closed"

    def test_closed_maps_to_closed(self):
        assert _normalize_state("Closed") == "closed"

    def test_resolved_maps_to_closed(self):
        assert _normalize_state("Resolved") == "closed"

    def test_cancelled_maps_to_removed(self):
        assert _normalize_state("Cancelled") == "removed"

    def test_wont_do_maps_to_removed(self):
        assert _normalize_state("Won't Do") == "removed"

    def test_case_insensitive(self):
        assert _normalize_state("DONE") == "closed"
        assert _normalize_state("in progress") == "active"

    def test_none_defaults_to_active(self):
        assert _normalize_state(None) == "active"

    def test_unknown_defaults_to_active(self):
        assert _normalize_state("Custom Status") == "active"


# ===================================================================
# Acceptance criteria extraction
# ===================================================================


class TestExtractAcceptanceCriteria:
    def test_empty_description(self):
        assert _extract_acceptance_criteria("") == []
        assert _extract_acceptance_criteria(None) == []

    def test_no_acceptance_section(self):
        desc = "# Description\nSome feature description."
        assert _extract_acceptance_criteria(desc) == []

    def test_markdown_heading_bullet_list(self):
        desc = (
            "## Description\nSome text\n\n"
            "## Acceptance Criteria\n"
            "- First criterion\n"
            "- Second criterion\n"
        )
        result = _extract_acceptance_criteria(desc)
        assert result == ["First criterion", "Second criterion"]

    def test_jira_wiki_heading(self):
        desc = (
            "h2. Description\nSome text\n\n"
            "h2. Acceptance Criteria\n"
            "- AC 1\n"
            "- AC 2\n"
        )
        result = _extract_acceptance_criteria(desc)
        assert result == ["AC 1", "AC 2"]

    def test_star_list(self):
        desc = "## Acceptance Criteria\n* Item A\n* Item B\n"
        result = _extract_acceptance_criteria(desc)
        assert result == ["Item A", "Item B"]

    def test_numbered_list(self):
        desc = "## Acceptance Criteria\n1. First\n2. Second\n"
        result = _extract_acceptance_criteria(desc)
        assert result == ["First", "Second"]

    def test_jira_ordered_list(self):
        desc = "## Acceptance Criteria\n# Item one\n# Item two\n"
        result = _extract_acceptance_criteria(desc)
        assert result == ["Item one", "Item two"]

    def test_stops_at_next_heading(self):
        desc = (
            "## Acceptance Criteria\n"
            "- Criterion 1\n"
            "## Notes\n"
            "- Not a criterion\n"
        )
        result = _extract_acceptance_criteria(desc)
        assert result == ["Criterion 1"]


# ===================================================================
# DevOpsJira provider
# ===================================================================


def _make_issue(
    key: str = "PROJ-1",
    summary: str = "Test issue",
    status: str = "Open",
    description: str = "",
) -> dict:
    """Create a minimal Jira issue JSON object."""
    return {
        "key": key,
        "fields": {
            "summary": summary,
            "status": {"name": status},
            "description": description,
        },
    }


class TestDevOpsJira:
    def test_init_stores_params(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ", jql="assignee=me")
        assert p._base_url == "https://jira.example.com"
        assert p._project_key == "PROJ"
        assert p._jql == "assignee=me"

    def test_init_strips_trailing_slash(self):
        p = DevOpsJira(base_url="https://jira.example.com/", project_key="P")
        assert p._base_url == "https://jira.example.com"

    def test_get_auth_headers_with_user_token(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me@corp.com", "JIRA_TOKEN": "tok123"}, clear=True):
            headers = p._get_auth_headers()
        assert headers["Authorization"].startswith("Basic ")

    def test_get_auth_headers_with_pat(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        with patch.dict("os.environ", _home_env(JIRA_PAT="pat123"), clear=True):
            headers = p._get_auth_headers()
        assert headers["Authorization"] == "Bearer pat123"

    def test_get_auth_headers_no_credentials(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        with patch.dict("os.environ", _home_env(), clear=True):
            headers = p._get_auth_headers()
        assert "Authorization" not in headers

    def test_map_issue_basic(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        issue = _make_issue(key="PROJ-42", summary="My Issue", status="In Progress", description="A description")
        wi = p._map_issue(issue)
        assert wi.id == "PROJ-42"
        assert wi.title == "My Issue"
        assert wi.state == "active"
        assert wi.description == "A description"

    def test_map_issue_closed(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        issue = _make_issue(status="Done")
        wi = p._map_issue(issue)
        assert wi.state == "closed"

    def test_map_issue_with_acceptance_criteria(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        desc = "Description\n\n## Acceptance Criteria\n- AC 1\n- AC 2\n"
        issue = _make_issue(description=desc)
        wi = p._map_issue(issue)
        assert wi.acceptance_criteria == ["AC 1", "AC 2"]

    def test_map_issue_no_description(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        issue = {"key": "P-1", "fields": {"summary": "T", "status": {"name": "Open"}, "description": None}}
        wi = p._map_issue(issue)
        assert wi.description == ""
        assert wi.acceptance_criteria == []

    def test_fetch_by_keys_calls_api(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        issue1 = _make_issue(key="PROJ-1", summary="Issue 1")
        issue2 = _make_issue(key="PROJ-2", summary="Issue 2")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.side_effect = [issue1, issue2]
            result = p.get_work_items(ids=["PROJ-1", "PROJ-2"])

        assert len(result) == 2
        assert result[0].id == "PROJ-1"
        assert result[1].id == "PROJ-2"
        assert mock_get.call_count == 2

    def test_fetch_by_keys_handles_failure(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.side_effect = OSError("Network error")
            result = p.get_work_items(ids=["PROJ-1"])

        assert result == []

    def test_fetch_by_jql_default_query(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        search_response = {
            "issues": [
                _make_issue(key="PROJ-1", summary="Issue 1"),
                _make_issue(key="PROJ-2", summary="Issue 2"),
            ]
        }

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = search_response
            result = p.get_work_items()

        assert len(result) == 2
        call_url = mock_get.call_args[0][0]
        assert "project" in call_url

    def test_fetch_by_jql_custom_query(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ", jql="assignee = me")
        search_response = {"issues": [_make_issue()]}

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = search_response
            result = p.get_work_items()

        assert len(result) == 1
        call_url = mock_get.call_args[0][0]
        assert "assignee" in call_url

    def test_fetch_by_jql_empty_response(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = {"issues": []}
            result = p.get_work_items()

        assert result == []

    def test_fetch_by_jql_none_response(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")

        with patch.object(p, "_api_get") as mock_get:
            mock_get.return_value = None
            result = p.get_work_items()

        assert result == []

    def test_api_get_http_error(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.HTTPError(
                "https://jira.example.com/test", 401, "Unauthorized", {}, None
            )
            result = p._api_get("https://jira.example.com/test", {})

        assert result is None

    def test_api_get_url_error(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
            result = p._api_get("https://jira.example.com/test", {})

        assert result is None

    def test_description_uses_first_paragraph(self):
        p = DevOpsJira(base_url="https://j.com", project_key="P")
        desc = "First line of desc.\nSecond line.\n\nAnother paragraph."
        issue = _make_issue(description=desc)
        wi = p._map_issue(issue)
        assert wi.description == "First line of desc. Second line."


# ===================================================================
# Write operations
# ===================================================================


class TestDevOpsJiraWrite:
    def test_create_work_item_success(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"id": "10001", "key": "PROJ-42"}
                result = p.create_work_item("Bug title", description="desc")

        assert result == "PROJ-42"
        call_args = mock_req.call_args
        assert call_args[1]["method"] == "POST"
        payload = call_args[1]["data"]
        assert payload["fields"]["summary"] == "Bug title"
        assert payload["fields"]["project"]["key"] == "PROJ"
        assert "guard" in payload["fields"]["labels"]

    def test_create_work_item_with_tags(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = {"key": "PROJ-10"}
                result = p.create_work_item("Title", tags="bug, security")

        assert result == "PROJ-10"
        labels = mock_req.call_args[1]["data"]["fields"]["labels"]
        assert "guard" in labels
        assert "bug" in labels
        assert "security" in labels

    def test_create_work_item_failure(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = None
                result = p.create_work_item("Title")

        assert result is None

    def test_update_work_item_success(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = True  # 204 No Content
                result = p.update_work_item("PROJ-5", title="New title")

        assert result is True
        payload = mock_req.call_args[1]["data"]
        assert payload["fields"]["summary"] == "New title"

    def test_update_work_item_noop(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        result = p.update_work_item("PROJ-5")
        assert result is True

    def test_update_work_item_failure(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_request") as mock_req:
                mock_req.return_value = None
                result = p.update_work_item("PROJ-5", title="New")

        assert result is False

    def test_close_work_item_success(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        transitions = {
            "transitions": [
                {"id": "11", "name": "In Progress", "to": {"name": "In Progress"}},
                {"id": "31", "name": "Done", "to": {"name": "Done"}},
            ]
        }
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_get") as mock_get, \
                 patch.object(p, "_api_request") as mock_req:
                mock_get.return_value = transitions
                mock_req.return_value = True
                result = p.close_work_item("PROJ-5")

        assert result is True
        payload = mock_req.call_args[1]["data"]
        assert payload["transition"]["id"] == "31"

    def test_close_work_item_case_insensitive(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        transitions = {
            "transitions": [
                {"id": "21", "name": "Resolve Issue", "to": {"name": "Resolved"}},
            ]
        }
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_get") as mock_get, \
                 patch.object(p, "_api_request") as mock_req:
                mock_get.return_value = transitions
                mock_req.return_value = True
                result = p.close_work_item("PROJ-5")

        assert result is True
        payload = mock_req.call_args[1]["data"]
        assert payload["transition"]["id"] == "21"

    def test_close_work_item_no_transition(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        transitions = {
            "transitions": [
                {"id": "11", "name": "In Progress", "to": {"name": "In Progress"}},
            ]
        }
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_get") as mock_get:
                mock_get.return_value = transitions
                result = p.close_work_item("PROJ-5")

        assert result is False

    def test_close_work_item_fetch_transitions_fails(self):
        p = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        with patch.dict("os.environ", {**_home_env(), "JIRA_USER": "me", "JIRA_TOKEN": "tok"}, clear=True):
            with patch.object(p, "_api_get") as mock_get:
                mock_get.return_value = None
                result = p.close_work_item("PROJ-5")

        assert result is False
