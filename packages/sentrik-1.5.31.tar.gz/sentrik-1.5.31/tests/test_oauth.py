"""Tests for guard.oauth package."""

from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from unittest import mock

import pytest

from tests.conftest import _home_env

from guard.oauth.models import OAuthConfig, OAuthToken
from guard.oauth.manager import OAuthManager, build_oauth_config
from guard.oauth import store


# ---------------------------------------------------------------------------
# OAuthToken model
# ---------------------------------------------------------------------------


class TestOAuthToken:
    def test_not_expired_when_no_expiry(self):
        token = OAuthToken(provider="github", access_token="abc", expires_at=0)
        assert not token.is_expired()

    def test_not_expired_when_future(self):
        token = OAuthToken(provider="azure", access_token="abc", expires_at=time.time() + 3600)
        assert not token.is_expired()

    def test_expired_when_past(self):
        token = OAuthToken(provider="azure", access_token="abc", expires_at=time.time() - 100)
        assert token.is_expired()

    def test_expired_within_buffer(self):
        token = OAuthToken(provider="azure", access_token="abc", expires_at=time.time() + 60)
        assert token.is_expired(buffer_seconds=120)

    def test_not_expired_outside_buffer(self):
        token = OAuthToken(provider="azure", access_token="abc", expires_at=time.time() + 600)
        assert not token.is_expired(buffer_seconds=300)


# ---------------------------------------------------------------------------
# OAuthConfig
# ---------------------------------------------------------------------------


class TestOAuthConfig:
    def test_from_dict(self):
        data = {
            "azure_client_id": "my-id",
            "azure_client_secret": "my-secret",
            "unknown_field": "ignored",
        }
        config = OAuthConfig.from_dict(data)
        assert config.azure_client_id == "my-id"
        assert config.azure_client_secret == "my-secret"

    def test_defaults(self):
        config = OAuthConfig()
        assert config.azure_client_id == ""
        assert config.github_client_id == ""
        assert config.jira_client_id == ""


# ---------------------------------------------------------------------------
# Token Store
# ---------------------------------------------------------------------------


class TestTokenStore:
    def setup_method(self):
        self._tmpdir = tempfile.mkdtemp()
        self._orig_cwd = os.getcwd()
        os.chdir(self._tmpdir)
        # Create .sentrik/ so store uses project-local path
        os.makedirs(".sentrik/local", exist_ok=True)

    def teardown_method(self):
        os.chdir(self._orig_cwd)

    def test_save_and_load(self):
        token = OAuthToken(
            provider="azure",
            access_token="tok123",
            refresh_token="ref456",
            expires_at=time.time() + 3600,
        )
        store.save_token(token)
        loaded = store.load_token("azure")
        assert loaded is not None
        assert loaded.access_token == "tok123"
        assert loaded.refresh_token == "ref456"

    def test_load_nonexistent(self):
        assert store.load_token("github") is None

    def test_has_token(self):
        assert not store.has_token("azure")
        token = OAuthToken(provider="azure", access_token="tok")
        store.save_token(token)
        assert store.has_token("azure")

    def test_delete_token(self):
        token = OAuthToken(provider="github", access_token="tok")
        store.save_token(token)
        assert store.has_token("github")
        store.delete_token("github")
        assert not store.has_token("github")

    def test_delete_nonexistent(self):
        store.delete_token("jira")  # Should not raise

    def test_multiple_providers(self):
        store.save_token(OAuthToken(provider="azure", access_token="a"))
        store.save_token(OAuthToken(provider="github", access_token="g"))
        assert store.load_token("azure").access_token == "a"
        assert store.load_token("github").access_token == "g"

    def test_overwrite_token(self):
        store.save_token(OAuthToken(provider="azure", access_token="old"))
        store.save_token(OAuthToken(provider="azure", access_token="new"))
        assert store.load_token("azure").access_token == "new"


# ---------------------------------------------------------------------------
# OAuthManager
# ---------------------------------------------------------------------------


class TestOAuthManager:
    def setup_method(self):
        self._tmpdir = tempfile.mkdtemp()
        self._orig_cwd = os.getcwd()
        os.chdir(self._tmpdir)
        os.makedirs(".sentrik/local", exist_ok=True)

    def teardown_method(self):
        os.chdir(self._orig_cwd)

    def test_get_access_token_from_stored_oauth(self):
        token = OAuthToken(provider="azure", access_token="oauth_tok",
                           expires_at=time.time() + 3600)
        store.save_token(token)
        mgr = OAuthManager()
        assert mgr.get_access_token("azure") == "oauth_tok"

    def test_get_access_token_falls_back_to_pat(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "pat123"}):
            assert mgr.get_access_token("azure") == "pat123"

    def test_get_access_token_none_when_nothing(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, _home_env(), clear=True):
            # Remove any env vars
            for k in ["AZURE_DEVOPS_PAT", "GITHUB_TOKEN", "JIRA_TOKEN", "JIRA_PAT"]:
                os.environ.pop(k, None)
            assert mgr.get_access_token("azure") is None

    def test_github_pat_fallback(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, {"GITHUB_TOKEN": "ghp_xxx"}):
            assert mgr.get_access_token("github") == "ghp_xxx"

    def test_jira_pat_fallback(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, {"JIRA_PAT": "jira_pat"}):
            assert mgr.get_access_token("jira") == "jira_pat"

    def test_jira_token_fallback(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, {"JIRA_TOKEN": "jira_tok"}):
            assert mgr.get_access_token("jira") == "jira_tok"

    def test_is_oauth_connected(self):
        mgr = OAuthManager()
        assert not mgr.is_oauth_connected("azure")
        store.save_token(OAuthToken(provider="azure", access_token="tok"))
        assert mgr.is_oauth_connected("azure")

    def test_disconnect(self):
        store.save_token(OAuthToken(provider="github", access_token="tok"))
        mgr = OAuthManager()
        assert mgr.is_oauth_connected("github")
        mgr.disconnect("github")
        assert not mgr.is_oauth_connected("github")

    def test_get_connection_status_not_connected(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, _home_env(), clear=True):
            for k in ["AZURE_DEVOPS_PAT"]:
                os.environ.pop(k, None)
            status = mgr.get_connection_status("azure")
            assert not status["connected"]

    def test_get_connection_status_oauth(self):
        store.save_token(OAuthToken(provider="azure", access_token="tok",
                                    refresh_token="ref", expires_at=time.time() + 3600))
        mgr = OAuthManager()
        status = mgr.get_connection_status("azure")
        assert status["connected"]
        assert status["method"] == "oauth"

    def test_get_connection_status_pat(self):
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "pat"}):
            status = mgr.get_connection_status("azure")
            assert status["connected"]
            assert status["method"] == "pat"

    def test_get_connection_status_expired_no_refresh(self):
        store.save_token(OAuthToken(provider="azure", access_token="tok",
                                    expires_at=time.time() - 100))
        mgr = OAuthManager()
        with mock.patch.dict(os.environ, _home_env(), clear=True):
            os.environ.pop("AZURE_DEVOPS_PAT", None)
            status = mgr.get_connection_status("azure")
            assert not status["connected"]

    def test_get_authorize_url_azure(self):
        config = OAuthConfig(
            azure_client_id="my-client",
            azure_tenant_id="my-tenant",
            azure_redirect_uri="http://localhost:8000/oauth/azure/callback",
        )
        mgr = OAuthManager(config)
        url, state = mgr.get_authorize_url("azure", "http://localhost:8000")
        assert "login.microsoftonline.com/my-tenant" in url
        assert "my-client" in url
        assert state

    def test_get_authorize_url_github(self):
        config = OAuthConfig(
            github_client_id="gh-client",
            github_redirect_uri="http://localhost:8000/oauth/github/callback",
        )
        mgr = OAuthManager(config)
        url, state = mgr.get_authorize_url("github", "http://localhost:8000")
        assert "github.com/login/oauth" in url
        assert "gh-client" in url

    def test_get_authorize_url_jira(self):
        config = OAuthConfig(
            jira_client_id="jira-client",
            jira_redirect_uri="http://localhost:8000/oauth/jira/callback",
        )
        mgr = OAuthManager(config)
        url, state = mgr.get_authorize_url("jira", "http://localhost:8000")
        assert "auth.atlassian.com" in url
        assert "jira-client" in url

    def test_get_authorize_url_unknown_provider(self):
        mgr = OAuthManager()
        with pytest.raises(ValueError, match="Unknown OAuth provider"):
            mgr.get_authorize_url("unknown")

    def test_auto_fill_redirect_uris(self):
        config = OAuthConfig(azure_client_id="test")
        mgr = OAuthManager(config)
        url, _ = mgr.get_authorize_url("azure", "http://localhost:9000")
        assert "localhost%3A9000" in url or "localhost:9000" in url


# ---------------------------------------------------------------------------
# build_oauth_config
# ---------------------------------------------------------------------------


class TestBuildOAuthConfig:
    def test_reads_env_vars(self):
        env = {
            "GUARD_AZURE_OAUTH_CLIENT_ID": "az-id",
            "GUARD_AZURE_OAUTH_CLIENT_SECRET": "az-secret",
            "GUARD_GITHUB_OAUTH_CLIENT_ID": "gh-id",
            "GUARD_JIRA_OAUTH_CLIENT_ID": "jira-id",
        }
        with mock.patch.dict(os.environ, env):
            config = build_oauth_config()
            assert config.azure_client_id == "az-id"
            assert config.azure_client_secret == "az-secret"
            assert config.github_client_id == "gh-id"
            assert config.jira_client_id == "jira-id"

    def test_defaults_to_empty(self):
        with mock.patch.dict(os.environ, _home_env(), clear=True):
            config = build_oauth_config()
            assert config.azure_client_id == ""


# ---------------------------------------------------------------------------
# Provider token resolution in DevOps providers
# ---------------------------------------------------------------------------


class TestProviderOAuthIntegration:
    """Test that DevOps providers pick up OAuth tokens."""

    def setup_method(self):
        self._tmpdir = tempfile.mkdtemp()
        self._orig_cwd = os.getcwd()
        os.chdir(self._tmpdir)
        os.makedirs(".sentrik/local", exist_ok=True)

    def teardown_method(self):
        os.chdir(self._orig_cwd)

    def test_azure_resolve_token_from_oauth(self):
        from guard.providers.devops_azure import DevOpsAzure
        store.save_token(OAuthToken(provider="azure", access_token="oauth_az",
                                    expires_at=time.time() + 3600))
        provider = DevOpsAzure(org="test", project="test")
        token, is_bearer = provider._resolve_token()
        assert token == "oauth_az"
        assert is_bearer is True

    def test_azure_resolve_token_explicit_jwt(self):
        from guard.providers.devops_azure import DevOpsAzure
        provider = DevOpsAzure(org="test", project="test", access_token="eyJhbGciOiJSUzI1NiJ9.test")
        token, is_bearer = provider._resolve_token()
        assert token == "eyJhbGciOiJSUzI1NiJ9.test"
        assert is_bearer is True

    def test_azure_resolve_token_explicit_pat(self):
        from guard.providers.devops_azure import DevOpsAzure
        provider = DevOpsAzure(org="test", project="test", access_token="pat_value")
        token, is_bearer = provider._resolve_token()
        assert token == "pat_value"
        assert is_bearer is False

    def test_azure_resolve_token_env_fallback(self):
        from guard.providers.devops_azure import DevOpsAzure
        # Ensure no stored OAuth token
        store.delete_token("azure")
        with mock.patch.dict(os.environ, {"AZURE_DEVOPS_PAT": "env_pat"}):
            provider = DevOpsAzure(org="test", project="test")
            token, is_bearer = provider._resolve_token()
            assert token == "env_pat"
            assert is_bearer is False

    def test_github_resolve_token_from_oauth(self):
        from guard.providers.devops_github import DevOpsGitHub
        store.save_token(OAuthToken(provider="github", access_token="oauth_gh"))
        provider = DevOpsGitHub(owner="test", repo="test")
        token = provider._resolve_token()
        assert token == "oauth_gh"

    def test_jira_resolve_oauth_token(self):
        from guard.providers.devops_jira import DevOpsJira
        store.save_token(OAuthToken(provider="jira", access_token="oauth_jira",
                                    cloud_id="cloud123", expires_at=time.time() + 3600))
        provider = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        oauth_token, cloud_id = provider._resolve_oauth()
        assert oauth_token == "oauth_jira"
        assert cloud_id == "cloud123"

    def test_jira_api_base_with_cloud_id(self):
        from guard.providers.devops_jira import DevOpsJira
        provider = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        provider._oauth_cloud_id = "cloud123"
        assert provider._api_base() == "https://api.atlassian.com/ex/jira/cloud123"

    def test_jira_api_base_without_cloud_id(self):
        from guard.providers.devops_jira import DevOpsJira
        provider = DevOpsJira(base_url="https://jira.example.com", project_key="PROJ")
        assert provider._api_base() == "https://jira.example.com"
