"""Performance benchmarks and parallel scanning tests."""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from guard.config import GuardConfig
from guard.core.cache import ScanCache
from guard.core.metrics import MetricsCollector, RuleMetrics, ScanMetrics
from guard.core.models import Evidence, Finding, Severity
from guard.rules.engine import RulesEngine


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _create_repo(tmp_path: Path, file_count: int, content: str = "") -> Path:
    """Create a synthetic repo with N Python files."""
    src = tmp_path / "src"
    src.mkdir()
    default_content = '"""Module docstring."""\n\nimport os\n\ndef hello():\n    print("hello")\n'
    for i in range(file_count):
        subdir = src / f"pkg{i // 50}"
        subdir.mkdir(exist_ok=True)
        (subdir / f"file_{i}.py").write_text(content or default_content, encoding="utf-8")
    return tmp_path


def _make_rules(count: int = 3) -> list[dict]:
    """Create N regex rules."""
    rules = []
    for i in range(count):
        rules.append({
            "id": f"PERF-{i:03d}",
            "name": f"perf-rule-{i}",
            "type": "regex",
            "pattern": r"\bprint\s*\(",
            "severity": "low",
            "file_glob": "**/*.py",
        })
    return rules


# ---------------------------------------------------------------------------
# ScanMetrics
# ---------------------------------------------------------------------------


class TestScanMetrics:
    def test_default_values(self):
        m = ScanMetrics()
        assert m.total_duration_ms == 0.0
        assert m.cache_hits == 0
        assert m.cache_misses == 0
        assert m.files_scanned == 0
        assert m.parallel_workers == 1

    def test_cache_hit_rate_zero_when_empty(self):
        m = ScanMetrics()
        assert m.cache_hit_rate == 0.0

    def test_cache_hit_rate_calculation(self):
        m = ScanMetrics(cache_hits=8, cache_misses=2)
        assert m.cache_hit_rate == 80.0

    def test_cache_hit_rate_100_percent(self):
        m = ScanMetrics(cache_hits=50, cache_misses=0)
        assert m.cache_hit_rate == 100.0

    def test_to_dict(self):
        m = ScanMetrics(
            total_duration_ms=123.456,
            rules_engine_ms=100.0,
            scanner_ms=20.0,
            files_scanned=50,
            cache_hits=30,
            cache_misses=20,
            total_findings=5,
            parallel_workers=4,
        )
        d = m.to_dict()
        assert d["total_duration_ms"] == 123.46
        assert d["rules_engine_ms"] == 100.0
        assert d["files_scanned"] == 50
        assert d["cache_hit_rate"] == 60.0
        assert d["parallel_workers"] == 4

    def test_to_dict_with_rule_metrics(self):
        m = ScanMetrics()
        m.rule_metrics.append(RuleMetrics(
            rule_id="R001",
            rule_type="regex",
            files_evaluated=10,
            findings_count=3,
            duration_ms=50.5,
        ))
        d = m.to_dict()
        assert len(d["rule_metrics"]) == 1
        assert d["rule_metrics"][0]["rule_id"] == "R001"
        assert d["rule_metrics"][0]["duration_ms"] == 50.5

    def test_save(self, tmp_path):
        m = ScanMetrics(total_duration_ms=100.0, files_scanned=10)
        path = m.save(tmp_path)
        assert path.exists()
        data = json.loads(path.read_text(encoding="utf-8"))
        assert data["total_duration_ms"] == 100.0
        assert data["files_scanned"] == 10


# ---------------------------------------------------------------------------
# MetricsCollector
# ---------------------------------------------------------------------------


class TestMetricsCollector:
    def test_start_stop_records_duration(self):
        collector = MetricsCollector()
        collector.start()
        time.sleep(0.01)  # 10ms
        collector.stop()
        assert collector.metrics.total_duration_ms > 5

    def test_time_rules_engine(self):
        collector = MetricsCollector()
        collector.start()
        with collector.time_rules_engine():
            time.sleep(0.01)
        collector.stop()
        assert collector.metrics.rules_engine_ms > 5

    def test_time_scanner(self):
        collector = MetricsCollector()
        collector.start()
        with collector.time_scanner():
            time.sleep(0.01)
        collector.stop()
        assert collector.metrics.scanner_ms > 5

    def test_time_ml_estimator(self):
        collector = MetricsCollector()
        collector.start()
        with collector.time_ml_estimator():
            time.sleep(0.01)
        collector.stop()
        assert collector.metrics.ml_estimator_ms > 5
        assert collector.metrics.rescorer_ms > 5  # new canonical field synced

    def test_time_rescorer(self):
        collector = MetricsCollector()
        collector.start()
        with collector.time_rescorer():
            time.sleep(0.01)
        collector.stop()
        assert collector.metrics.rescorer_ms > 5
        assert collector.metrics.ml_estimator_ms > 5  # backward-compat field synced

    def test_record_cache_hit(self):
        collector = MetricsCollector()
        collector.record_cache_hit()
        collector.record_cache_hit()
        assert collector.metrics.cache_hits == 2

    def test_record_cache_miss(self):
        collector = MetricsCollector()
        collector.record_cache_miss()
        assert collector.metrics.cache_misses == 1

    def test_record_file_scanned(self):
        collector = MetricsCollector()
        collector.record_file_scanned()
        collector.record_file_scanned()
        collector.record_file_scanned()
        assert collector.metrics.files_scanned == 3

    def test_record_findings(self):
        collector = MetricsCollector()
        findings = [
            Finding(
                finding_id="F1", rule_id="R1", severity=Severity.HIGH,
                message="m", evidence=Evidence(file="f.py"), confidence=1.0,
            ),
            Finding(
                finding_id="F2", rule_id="R1", severity=Severity.HIGH,
                message="m", evidence=Evidence(file="f.py"), confidence=1.0,
            ),
            Finding(
                finding_id="F3", rule_id="R2", severity=Severity.LOW,
                message="m", evidence=Evidence(file="f.py"), confidence=1.0,
            ),
        ]
        collector.record_findings(findings)
        assert collector.metrics.total_findings == 3
        assert collector.metrics.findings_by_severity == {"high": 2, "low": 1}
        assert collector.metrics.findings_by_rule == {"R1": 2, "R2": 1}

    def test_add_rule_metrics(self):
        collector = MetricsCollector()
        rm = RuleMetrics(rule_id="R1", rule_type="regex")
        collector.add_rule_metrics(rm)
        assert len(collector.metrics.rule_metrics) == 1

    def test_parallel_workers_passed_through(self):
        collector = MetricsCollector(parallel_workers=8)
        assert collector.metrics.parallel_workers == 8


# ---------------------------------------------------------------------------
# RulesEngine parallel scanning
# ---------------------------------------------------------------------------


class TestParallelScanning:
    def test_sequential_scan(self, tmp_path):
        repo = _create_repo(tmp_path, 20)
        rules = _make_rules(1)
        engine = RulesEngine(rules, max_workers=1)
        findings = engine.evaluate(str(repo))
        assert len(findings) > 0

    def test_parallel_scan_produces_same_findings(self, tmp_path):
        repo = _create_repo(tmp_path, 50)
        rules = _make_rules(1)

        engine_seq = RulesEngine(rules, max_workers=1)
        engine_par = RulesEngine(rules, max_workers=4)

        findings_seq = engine_seq.evaluate(str(repo))
        findings_par = engine_par.evaluate(str(repo))

        # Same count of findings
        assert len(findings_seq) == len(findings_par)
        # Same set of finding IDs (order may differ)
        ids_seq = {f.finding_id for f in findings_seq}
        ids_par = {f.finding_id for f in findings_par}
        assert ids_seq == ids_par

    def test_parallel_with_cache(self, tmp_path):
        repo = _create_repo(tmp_path, 30)
        rules = _make_rules(1)
        engine = RulesEngine(rules, max_workers=4)

        cache_dir = tmp_path / ".cache"
        cache = ScanCache(str(cache_dir))

        # First run — populates cache
        findings1 = engine.evaluate(str(repo), cache=cache)
        cache.save()

        # Second run — should use cache
        cache2 = ScanCache(str(cache_dir))
        findings2 = engine.evaluate(str(repo), cache=cache2)

        assert len(findings1) == len(findings2)

    def test_parallel_with_multiple_rules(self, tmp_path):
        repo = _create_repo(tmp_path, 20)
        rules = _make_rules(3)
        engine = RulesEngine(rules, max_workers=4)
        findings = engine.evaluate(str(repo))
        # Each rule should find print() in each file
        assert len(findings) > 0

    def test_max_workers_1_is_sequential(self, tmp_path):
        repo = _create_repo(tmp_path, 10)
        rules = _make_rules(1)
        engine = RulesEngine(rules, max_workers=1)
        findings = engine.evaluate(str(repo))
        assert len(findings) > 0

    def test_parallel_ast_rules(self, tmp_path):
        content = '"""Docstring."""\n\ndef foo(x=[]):\n    pass\n'
        repo = _create_repo(tmp_path, 20, content=content)
        rules = [{
            "id": "PERF-AST-001",
            "name": "no-mutable-defaults",
            "type": "ast",
            "ast_check": "no_mutable_defaults",
            "severity": "high",
            "file_glob": "**/*.py",
        }]
        engine = RulesEngine(rules, max_workers=4)
        findings = engine.evaluate(str(repo))
        assert len(findings) == 20  # One finding per file

    def test_parallel_file_policy_rules(self, tmp_path):
        content = "no_docstring = True\n" * 10
        repo = _create_repo(tmp_path, 15, content=content)
        rules = [{
            "id": "PERF-FP-001",
            "name": "require-docstring",
            "type": "file_policy",
            "check": "starts_with_docstring",
            "severity": "low",
            "file_glob": "**/*.py",
        }]
        engine = RulesEngine(rules, max_workers=4)
        findings = engine.evaluate(str(repo))
        assert len(findings) == 15


# ---------------------------------------------------------------------------
# Benchmark: large repo scan timing
# ---------------------------------------------------------------------------


class TestBenchmarkLargeRepo:
    @pytest.mark.parametrize("file_count", [100, 500])
    def test_scan_scales(self, tmp_path, file_count):
        """Verify scans complete in reasonable time for large repos."""
        repo = _create_repo(tmp_path, file_count)
        rules = _make_rules(2)
        engine = RulesEngine(rules, max_workers=1)

        start = time.perf_counter()
        findings = engine.evaluate(str(repo))
        elapsed = time.perf_counter() - start

        # Should complete in under 10 seconds even for 500 files
        assert elapsed < 10.0
        assert len(findings) > 0

    def test_parallel_faster_than_sequential(self, tmp_path):
        """Parallel scanning should not be slower than sequential for large repos."""
        repo = _create_repo(tmp_path, 200)
        rules = _make_rules(2)

        # Sequential
        engine_seq = RulesEngine(rules, max_workers=1)
        start = time.perf_counter()
        findings_seq = engine_seq.evaluate(str(repo))
        time_seq = time.perf_counter() - start

        # Parallel
        engine_par = RulesEngine(rules, max_workers=4)
        start = time.perf_counter()
        findings_par = engine_par.evaluate(str(repo))
        time_par = time.perf_counter() - start

        # Same results
        assert len(findings_seq) == len(findings_par)
        # Parallel should finish (no deadlocks/hangs)
        assert time_par < 30.0

    def test_cache_speedup(self, tmp_path):
        """Second scan with cache should be faster than first."""
        repo = _create_repo(tmp_path, 200)
        rules = _make_rules(2)
        engine = RulesEngine(rules, max_workers=1)

        cache_dir = tmp_path / ".cache"

        # First scan (cold cache)
        cache1 = ScanCache(str(cache_dir))
        start = time.perf_counter()
        findings1 = engine.evaluate(str(repo), cache=cache1)
        time_cold = time.perf_counter() - start
        cache1.save()

        # Second scan (warm cache)
        cache2 = ScanCache(str(cache_dir))
        start = time.perf_counter()
        findings2 = engine.evaluate(str(repo), cache=cache2)
        time_warm = time.perf_counter() - start

        assert len(findings1) == len(findings2)
        # Warm cache should be faster (or at worst equal on fast machines)
        assert time_warm <= time_cold * 2  # Allow some variance


# ---------------------------------------------------------------------------
# Config integration
# ---------------------------------------------------------------------------


class TestParallelConfig:
    def test_default_config(self):
        config = GuardConfig()
        assert config.parallel_scan is False
        assert config.max_workers == 4

    def test_env_var_override(self, monkeypatch):
        monkeypatch.setenv("GUARD_PARALLEL_SCAN", "true")
        monkeypatch.setenv("GUARD_MAX_WORKERS", "8")
        config = GuardConfig.load()
        assert config.parallel_scan is True
        assert config.max_workers == 8

    def test_invalid_max_workers_ignored(self, monkeypatch):
        monkeypatch.setenv("GUARD_MAX_WORKERS", "abc")
        config = GuardConfig.load()
        assert config.max_workers == 4  # Default preserved


# ---------------------------------------------------------------------------
# Pipeline metrics integration
# ---------------------------------------------------------------------------


class TestPipelineMetrics:
    def test_scan_writes_metrics_file(self, tmp_path):
        from guard.core.pipeline import run_scan
        from guard.providers.scanners_stub import ScannersStub

        config = GuardConfig(output_dir=str(tmp_path / "out"))
        engine = RulesEngine([], max_workers=1)
        scanner = ScannersStub()

        run_scan(str(tmp_path), config, engine, scanner)

        metrics_path = tmp_path / "out" / "scan_metrics.json"
        assert metrics_path.exists()

        data = json.loads(metrics_path.read_text(encoding="utf-8"))
        assert "total_duration_ms" in data
        assert "rules_engine_ms" in data
        assert "scanner_ms" in data
        assert data["total_findings"] == 0
