"""Tests for security posture scoring."""

import json
from pathlib import Path

from guard.core.posture import PostureScore, calculate_posture


class TestPostureScoreBasic:
    def test_default_posture_no_data(self, tmp_path):
        """Returns neutral scores when no scan data exists."""
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert 0 <= score.overall <= 100
        assert score.status in ("healthy", "needs_attention", "at_risk", "critical")

    def test_perfect_compliance_no_vulns(self, tmp_path):
        """High posture with perfect compliance and no vulnerabilities."""
        metrics = {
            "compliance_score": {"score": 100.0, "rules_total": 10, "rules_passed": 10, "blocking_findings": 0}
        }
        (tmp_path / "scan_metrics.json").write_text(json.dumps(metrics))
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert score.compliance == 100.0
        assert score.vulnerability == 100.0
        assert score.overall >= 70.0

    def test_vulns_reduce_score(self, tmp_path):
        """Vulnerabilities reduce the posture score."""
        metrics = {"compliance_score": {"score": 90.0, "rules_total": 10, "rules_passed": 9}}
        vulns = {"total_dependencies": 10, "vulnerable_count": 5, "vulnerabilities": [
            {"severity": "critical"}, {"severity": "high"}, {"severity": "medium"},
            {"severity": "low"}, {"severity": "low"},
        ]}
        (tmp_path / "scan_metrics.json").write_text(json.dumps(metrics))
        (tmp_path / "vulnerabilities.json").write_text(json.dumps(vulns))
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert score.vulnerability < 50.0
        assert score.overall < score.compliance

    def test_status_labels(self, tmp_path):
        """Status reflects overall score ranges."""
        # High score → healthy
        metrics = {"compliance_score": {"score": 100.0}}
        (tmp_path / "scan_metrics.json").write_text(json.dumps(metrics))
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert score.status == "healthy"

    def test_to_dict_structure(self, tmp_path):
        """to_dict returns the expected shape."""
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        d = score.to_dict()
        assert "overall" in d
        assert "status" in d
        assert "components" in d
        assert "compliance" in d["components"]
        assert "vulnerability" in d["components"]
        assert "trend" in d["components"]
        assert "gate_reliability" in d["components"]
        for comp in d["components"].values():
            assert "score" in comp
            assert "weight" in comp

    def test_critical_vulns_extra_penalty(self, tmp_path):
        """Critical/high vulns apply extra penalty beyond ratio."""
        vulns = {"total_dependencies": 100, "vulnerable_count": 1, "vulnerabilities": [
            {"severity": "critical"},
        ]}
        (tmp_path / "vulnerabilities.json").write_text(json.dumps(vulns))
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert score.vulnerability < 95.0  # 1% ratio but critical penalty

    def test_numeric_compliance_score(self, tmp_path):
        """Handles compliance_score as a plain number (not dict)."""
        metrics = {"compliance_score": 85.0}
        (tmp_path / "scan_metrics.json").write_text(json.dumps(metrics))
        score = calculate_posture(output_dir=str(tmp_path), metrics_db_path=tmp_path / "nope.db")
        assert score.compliance == 85.0
