"""Tests for Platform Polish features (Phase 26i).

Covers: config validation endpoint, trends endpoint, suppressions endpoint,
API docs page, SSE scan progress, CSV export, dashboard theme/search/help/skeletons.
"""

from __future__ import annotations

import json
import os
from datetime import date, timedelta
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from guard.server import app


@pytest.fixture
def client():
    """Create a test client without API key auth."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("GUARD_API_KEY", None)
        import guard.server as srv
        srv._API_KEY = None
        yield TestClient(app)


# ===================================================================
# Config Validation endpoint
# ===================================================================


class TestConfigValidateEndpoint:
    def test_validate_returns_valid_structure(self, client):
        resp = client.get("/api/config/validate")
        assert resp.status_code == 200
        data = resp.json()
        assert "valid" in data
        assert "warnings" in data
        assert "error_count" in data
        assert "warning_count" in data
        assert isinstance(data["warnings"], list)

    def test_validate_default_config_is_valid(self, client):
        resp = client.get("/api/config/validate")
        data = resp.json()
        assert data["valid"] is True
        assert data["error_count"] == 0

    def test_validate_catches_errors(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        cfg = GuardConfig(provider="invalid_provider")
        cfg.save()
        resp = client.get("/api/config/validate")
        data = resp.json()
        assert data["valid"] is False
        assert data["error_count"] > 0

    def test_validate_catches_warnings(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        cfg = GuardConfig(reporters=["banana"])
        cfg.save()
        resp = client.get("/api/config/validate")
        data = resp.json()
        assert data["warning_count"] > 0


# ===================================================================
# Trends endpoint
# ===================================================================


class TestTrendsEndpoint:
    def test_trends_empty_history(self, client, tmp_path, monkeypatch):
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(tmp_path / "empty"))
        monkeypatch.chdir(tmp_path)  # ensure no .sentrik/local/metrics.db exists
        resp = client.get("/api/trends")
        assert resp.status_code == 200
        data = resp.json()
        assert data["runs"] == []

    def test_trends_with_history(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)  # ensure no .sentrik/local/metrics.db exists
        out = tmp_path / "out"
        history = out / "history"
        history.mkdir(parents=True)
        metrics = {
            "findings_by_severity": {"critical": 1, "high": 2, "medium": 0, "low": 0, "info": 0},
        }
        (history / "scan_metrics_20260101T000000Z.json").write_text(json.dumps(metrics))
        (history / "scan_metrics_20260102T000000Z.json").write_text(json.dumps(metrics))
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/trends")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["runs"]) == 2
        assert data["runs"][0]["total"] == 3  # 1 + 2
        assert "by_severity" in data["runs"][0]


# ===================================================================
# Suppressions endpoint
# ===================================================================


class TestSuppressionsEndpoint:
    def test_suppressions_empty(self, client):
        resp = client.get("/api/suppressions")
        assert resp.status_code == 200
        data = resp.json()
        assert "suppressions" in data
        assert isinstance(data["suppressions"], list)

    def test_suppressions_with_config(self, client, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from guard.config import GuardConfig
        cfg = GuardConfig(suppressions=[
            {"rule_id": "RULE-001", "reason": "False positive"},
        ])
        cfg.save()
        resp = client.get("/api/suppressions")
        data = resp.json()
        assert len(data["suppressions"]) == 1
        assert data["suppressions"][0]["rule_id"] == "RULE-001"


# ===================================================================
# API Documentation page
# ===================================================================


class TestApiDocsPage:
    def test_api_docs_returns_html(self, client):
        resp = client.get("/api")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]

    def test_api_docs_lists_endpoints(self, client):
        text = client.get("/api").text
        assert "/scan" in text
        assert "/gate" in text
        assert "/health" in text
        assert "/rules" in text
        assert "/api/metrics" in text

    def test_api_docs_has_brand(self, client):
        text = client.get("/api").text
        assert "SENTRIK" in text


# ===================================================================
# SSE Scan Progress endpoint
# ===================================================================


class TestRunScanStreamEndpoint:
    def test_stream_endpoint_is_registered(self):
        """Verify the SSE streaming endpoint is registered on the app."""
        from guard.server import app
        routes = [r.path for r in app.routes if hasattr(r, "path")]
        assert "/api/run-scan-stream" in routes

    def test_dashboard_references_stream(self, client):
        """Verify the dashboard JS references the streaming endpoint."""
        text = client.get("/dashboard").text
        assert "run-scan-stream" in text


# ===================================================================
# CSV report via /report endpoint
# ===================================================================


class TestReportCsvFormat:
    def test_report_csv_format(self, client):
        resp = client.post("/report?format=csv", json={
            "files": {"app.py": "x = 1\n"},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "csv"
        assert "finding_id" in data["content"]  # CSV header

    def test_generate_csv_report(self, client, tmp_path, monkeypatch):
        out = tmp_path / "out"
        out.mkdir()
        (out / "findings.json").write_text("[]")
        monkeypatch.setenv("GUARD_OUTPUT_DIR", str(out))
        resp = client.get("/api/report/generate?format=csv")
        assert resp.status_code == 200
        data = resp.json()
        assert data["format"] == "csv"
        assert "finding_id" in data["content"]


# ===================================================================
# Dashboard Theme Toggle
# ===================================================================


class TestDashboardThemeToggle:
    def test_has_theme_toggle_button(self, client):
        text = client.get("/dashboard").text
        assert "theme-toggle" in text

    def test_has_toggle_theme_function(self, client):
        text = client.get("/dashboard").text
        assert "toggleTheme" in text

    def test_has_light_theme_css(self, client):
        text = client.get("/dashboard").text
        assert '[data-theme="light"]' in text

    def test_has_css_variables(self, client):
        text = client.get("/dashboard").text
        assert "--bg-primary" in text
        assert "--text-primary" in text
        assert "--accent" in text


# ===================================================================
# Dashboard Mobile Responsiveness
# ===================================================================


class TestDashboardMobileResponsive:
    def test_has_viewport_meta(self, client):
        text = client.get("/dashboard").text
        assert "viewport" in text

    def test_has_media_queries(self, client):
        text = client.get("/dashboard").text
        assert "@media" in text
        assert "max-width" in text


# ===================================================================
# Dashboard Global Search
# ===================================================================


class TestDashboardGlobalSearch:
    def test_has_search_overlay(self, client):
        text = client.get("/dashboard").text
        assert "search-overlay" in text

    def test_has_open_search_function(self, client):
        text = client.get("/dashboard").text
        assert "openSearch" in text
        assert "closeSearch" in text

    def test_has_search_input(self, client):
        text = client.get("/dashboard").text
        assert "search-input" in text


# ===================================================================
# Dashboard Keyboard Shortcuts
# ===================================================================


class TestDashboardKeyboardShortcuts:
    def test_has_help_overlay(self, client):
        text = client.get("/dashboard").text
        assert "help-overlay" in text

    def test_has_keyboard_shortcut_handlers(self, client):
        text = client.get("/dashboard").text
        assert "openHelp" in text
        assert "closeHelp" in text


# ===================================================================
# Dashboard Copy to Clipboard
# ===================================================================


class TestDashboardCopyToClipboard:
    def test_has_copy_function(self, client):
        text = client.get("/dashboard").text
        assert "copyToClipboard" in text

    def test_has_copy_btn_css(self, client):
        text = client.get("/dashboard").text
        assert "copy-btn" in text


# ===================================================================
# Dashboard Skeleton Loading
# ===================================================================


class TestDashboardSkeletonLoading:
    def test_has_skeleton_css(self, client):
        text = client.get("/dashboard").text
        assert "skeleton" in text

    def test_has_skeleton_animation(self, client):
        text = client.get("/dashboard").text
        assert "shimmer" in text

    def test_has_render_skeleton_function(self, client):
        text = client.get("/dashboard").text
        assert "renderSkeleton" in text


# ===================================================================
# Dashboard Export CSV Button
# ===================================================================


class TestDashboardExportCSV:
    def test_has_export_csv_function(self, client):
        text = client.get("/dashboard").text
        assert "exportFindingsCSV" in text


# ===================================================================
# Dashboard Config Validation
# ===================================================================


class TestDashboardConfigValidation:
    def test_has_validate_config_function(self, client):
        text = client.get("/dashboard").text
        assert "validateConfig" in text

    def test_has_validation_indicator_css(self, client):
        text = client.get("/dashboard").text
        assert "validation-indicator" in text


# ===================================================================
# Dashboard Trends Section
# ===================================================================


class TestDashboardTrends:
    def test_has_trends_section(self, client):
        text = client.get("/dashboard").text
        assert "trends-section" in text

    def test_has_load_trends_function(self, client):
        text = client.get("/dashboard").text
        assert "loadTrends" in text

    def test_has_render_trends_chart_function(self, client):
        text = client.get("/dashboard").text
        assert "renderTrendsChart" in text


# ===================================================================
# Dashboard Suppress Modal
# ===================================================================


class TestDashboardSuppressModal:
    def test_has_suppress_functions(self, client):
        text = client.get("/dashboard").text
        assert "showSuppressModal" in text
        assert "submitSuppression" in text


# ===================================================================
# Dashboard SSE Progress
# ===================================================================


class TestDashboardScanProgress:
    def test_has_scan_progress_css(self, client):
        text = client.get("/dashboard").text
        assert "scan-progress" in text
