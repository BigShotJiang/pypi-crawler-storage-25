"""Comprehensive tests for patch generation and application (Phase 5)."""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.helpers import make_finding, write_file
from guard.core.models import Severity
from guard.core.patcher import (
    apply_patches,
    generate_patches,
    write_patches,
)


def _make_finding(
    rule_id: str = "R-001",
    file: str = "app.py",
    lines: list[int] | None = None,
    snippet: str = "",
):
    """Thin wrapper preserving original parameter names."""
    return make_finding(
        fid=f"{rule_id}-{file}:{(lines or [0])[0]}",
        rule=rule_id, sev=Severity.MEDIUM, file=file,
        lines=lines, snippet=snippet, msg="test",
    )


def _write(tmp_path: Path, rel: str, content: str) -> Path:
    return write_file(tmp_path, rel, content)


# ===================================================================
# generate_patches
# ===================================================================


class TestGeneratePatches:
    def test_removes_print_line(self, tmp_path):
        _write(tmp_path, "app.py", 'x = 1\nprint("debug")\ny = 2\n')
        finding = _make_finding(rule_id="R-print", file="app.py", lines=[2])
        autofix_map = {"R-print": "remove_line"}

        patches = generate_patches([finding], str(tmp_path), autofix_map)

        assert len(patches) == 1
        assert "-print" in patches[0]
        assert "+y = 2" not in patches[0] or "y = 2" in patches[0]

    def test_removes_multiple_lines_same_file(self, tmp_path):
        _write(tmp_path, "app.py", 'print("a")\nx = 1\nprint("b")\n')
        findings = [
            _make_finding(rule_id="R-print", file="app.py", lines=[1]),
            _make_finding(rule_id="R-print", file="app.py", lines=[3]),
        ]
        autofix_map = {"R-print": "remove_line"}

        patches = generate_patches(findings, str(tmp_path), autofix_map)

        assert len(patches) == 1
        # The patch should remove both print lines
        assert patches[0].count("-print") == 2 or patches[0].count('-print("') >= 2

    def test_no_autofix_map_returns_empty(self, tmp_path):
        _write(tmp_path, "app.py", 'print("debug")\n')
        finding = _make_finding(rule_id="R-print", file="app.py", lines=[1])

        assert generate_patches([finding], str(tmp_path), None) == []
        assert generate_patches([finding], str(tmp_path), {}) == []

    def test_rule_not_in_autofix_map_skipped(self, tmp_path):
        _write(tmp_path, "app.py", '# TODO fix\n')
        finding = _make_finding(rule_id="R-todo", file="app.py", lines=[1])
        autofix_map = {"R-other": "remove_line"}

        patches = generate_patches([finding], str(tmp_path), autofix_map)

        assert patches == []

    def test_unknown_strategy_skipped(self, tmp_path):
        _write(tmp_path, "app.py", '# TODO fix\n')
        finding = _make_finding(rule_id="R-todo", file="app.py", lines=[1])
        autofix_map = {"R-todo": "unknown_strategy"}

        patches = generate_patches([finding], str(tmp_path), autofix_map)

        assert patches == []

    def test_no_findings_returns_empty(self, tmp_path):
        patches = generate_patches([], str(tmp_path), {"R-x": "remove_line"})
        assert patches == []

    def test_file_not_found_skipped(self, tmp_path):
        finding = _make_finding(rule_id="R-x", file="missing.py", lines=[1])
        patches = generate_patches([finding], str(tmp_path), {"R-x": "remove_line"})
        assert patches == []

    def test_patches_multiple_files(self, tmp_path):
        _write(tmp_path, "a.py", 'print("a")\nx = 1\n')
        _write(tmp_path, "b.py", 'print("b")\ny = 2\n')
        findings = [
            _make_finding(rule_id="R-print", file="a.py", lines=[1]),
            _make_finding(rule_id="R-print", file="b.py", lines=[1]),
        ]
        autofix_map = {"R-print": "remove_line"}

        patches = generate_patches(findings, str(tmp_path), autofix_map)

        assert len(patches) == 2

    def test_no_change_produces_no_patch(self, tmp_path):
        _write(tmp_path, "app.py", 'x = 1\n')
        # Finding points to a line but the line doesn't exist at that index
        finding = _make_finding(rule_id="R-x", file="app.py", lines=[99])
        autofix_map = {"R-x": "remove_line"}

        patches = generate_patches([finding], str(tmp_path), autofix_map)

        assert patches == []


# ===================================================================
# write_patches
# ===================================================================


class TestWritePatches:
    def test_writes_patch_files(self, tmp_path):
        patches_dir = tmp_path / "patches"
        patch_content = ["--- a/a.py\n+++ b/a.py\n@@ -1,2 +1 @@\n-print('a')\n x = 1\n"]

        written = write_patches(patch_content, patches_dir)

        assert len(written) == 1
        assert written[0].exists()
        assert written[0].name == "0001.patch"
        assert written[0].read_text(encoding="utf-8") == patch_content[0]

    def test_writes_multiple_patches(self, tmp_path):
        patches_dir = tmp_path / "patches"
        written = write_patches(["patch1", "patch2", "patch3"], patches_dir)

        assert len(written) == 3
        assert written[0].name == "0001.patch"
        assert written[1].name == "0002.patch"
        assert written[2].name == "0003.patch"

    def test_empty_patches_writes_nothing(self, tmp_path):
        patches_dir = tmp_path / "patches"
        written = write_patches([], patches_dir)

        assert written == []

    def test_creates_directory(self, tmp_path):
        patches_dir = tmp_path / "nested" / "patches"
        write_patches(["content"], patches_dir)

        assert patches_dir.exists()


# ===================================================================
# apply_patches
# ===================================================================


class TestApplyPatches:
    def test_applies_remove_line_patch(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "app.py").write_text('print("debug")\nx = 1\n', encoding="utf-8")

        patches_dir = tmp_path / "patches"
        patches_dir.mkdir()
        patch = (
            "--- a/app.py\n"
            "+++ b/app.py\n"
            "@@ -1,2 +1,1 @@\n"
            '-print("debug")\n'
            " x = 1\n"
        )
        (patches_dir / "0001.patch").write_text(patch, encoding="utf-8")

        applied = apply_patches(patches_dir, str(repo))

        assert applied == 1
        assert (repo / "app.py").read_text(encoding="utf-8") == "x = 1\n"

    def test_applies_multiple_patches(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "a.py").write_text('print("a")\nx = 1\n', encoding="utf-8")
        (repo / "b.py").write_text('print("b")\ny = 2\n', encoding="utf-8")

        patches_dir = tmp_path / "patches"
        patches_dir.mkdir()
        (patches_dir / "0001.patch").write_text(
            "--- a/a.py\n+++ b/a.py\n@@ -1,2 +1,1 @@\n"
            '-print("a")\n x = 1\n',
            encoding="utf-8",
        )
        (patches_dir / "0002.patch").write_text(
            "--- a/b.py\n+++ b/b.py\n@@ -1,2 +1,1 @@\n"
            '-print("b")\n y = 2\n',
            encoding="utf-8",
        )

        applied = apply_patches(patches_dir, str(repo))

        assert applied == 2
        assert (repo / "a.py").read_text(encoding="utf-8") == "x = 1\n"
        assert (repo / "b.py").read_text(encoding="utf-8") == "y = 2\n"

    def test_missing_patches_dir_returns_zero(self, tmp_path):
        applied = apply_patches(tmp_path / "nonexistent", str(tmp_path))
        assert applied == 0

    def test_empty_patches_dir_returns_zero(self, tmp_path):
        patches_dir = tmp_path / "patches"
        patches_dir.mkdir()
        applied = apply_patches(patches_dir, str(tmp_path))
        assert applied == 0

    def test_target_file_missing_returns_zero(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()

        patches_dir = tmp_path / "patches"
        patches_dir.mkdir()
        (patches_dir / "0001.patch").write_text(
            "--- a/missing.py\n+++ b/missing.py\n@@ -1,1 +1,0 @@\n-x\n",
            encoding="utf-8",
        )

        applied = apply_patches(patches_dir, str(repo))
        assert applied == 0

    def test_malformed_patch_skipped(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()

        patches_dir = tmp_path / "patches"
        patches_dir.mkdir()
        (patches_dir / "0001.patch").write_text("not a valid patch", encoding="utf-8")

        applied = apply_patches(patches_dir, str(repo))
        assert applied == 0


# ===================================================================
# Integration: generate → write → apply
# ===================================================================


class TestEndToEnd:
    def test_full_cycle(self, tmp_path):
        # Set up repo with a fixable violation
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "app.py").write_text(
            '"""Module."""\nprint("debug")\nx = 1\n', encoding="utf-8"
        )

        # Generate patches
        finding = _make_finding(rule_id="R-print", file="app.py", lines=[2])
        patches = generate_patches([finding], str(repo), {"R-print": "remove_line"})
        assert len(patches) == 1

        # Write patches
        patches_dir = tmp_path / "out" / "patches"
        written = write_patches(patches, patches_dir)
        assert len(written) == 1

        # Apply patches
        applied = apply_patches(patches_dir, str(repo))
        assert applied == 1

        # Verify the file was fixed
        content = (repo / "app.py").read_text(encoding="utf-8")
        assert "print" not in content
        assert '"""Module."""' in content
        assert "x = 1" in content

    def test_full_cycle_multiple_files(self, tmp_path):
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "a.py").write_text('x = 1\nprint("a")\n', encoding="utf-8")
        (repo / "b.py").write_text('print("b")\ny = 2\n', encoding="utf-8")

        findings = [
            _make_finding(rule_id="R-print", file="a.py", lines=[2]),
            _make_finding(rule_id="R-print", file="b.py", lines=[1]),
        ]
        patches = generate_patches(findings, str(repo), {"R-print": "remove_line"})
        patches_dir = tmp_path / "out" / "patches"
        write_patches(patches, patches_dir)
        applied = apply_patches(patches_dir, str(repo))

        assert applied == 2
        assert "print" not in (repo / "a.py").read_text(encoding="utf-8")
        assert "print" not in (repo / "b.py").read_text(encoding="utf-8")
