"""Tests for the GitHub Standards provider (Phase 16)."""

from __future__ import annotations

import json
from base64 import b64encode
from unittest.mock import patch, MagicMock

import pytest

from tests.conftest import _home_env

from guard.providers.standards_github import StandardsGitHub


def _make_contents_response(content: str) -> bytes:
    """Create a mock GitHub Contents API response body."""
    b64 = b64encode(content.encode()).decode()
    return json.dumps({"content": b64}).encode()


SAMPLE_YAML = """\
rules:
  - id: STD-001
    name: no-todo-comments
    type: regex
    severity: low
    pattern: "# TODO"
    description: "TODO comments should be resolved"
  - id: STD-002
    name: no-print-statements
    type: regex
    severity: medium
    pattern: "print\\\\("
    description: "Use logging instead of print"
"""


class TestStandardsGitHub:
    def test_init_stores_params(self):
        p = StandardsGitHub(owner="acme", repo="standards", file_path="rules.yaml", ref="develop")
        assert p._owner == "acme"
        assert p._repo == "standards"
        assert p._file_path == "rules.yaml"
        assert p._ref == "develop"

    def test_init_defaults(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        assert p._file_path == "standards.yaml"
        assert p._ref == "main"

    def test_get_rules_success(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response(SAMPLE_YAML)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                rules = p.get_rules()

        assert len(rules) == 2
        assert rules[0]["id"] == "STD-001"
        assert rules[1]["id"] == "STD-002"

    def test_get_rule_ids(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response(SAMPLE_YAML)
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                ids = p.get_rule_ids()

        assert ids == ["STD-001", "STD-002"]

    def test_get_rules_http_error(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.HTTPError(
                "https://api.github.com/test", 404, "Not Found", {}, None
            )
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                rules = p.get_rules()

        assert rules == []

    def test_get_rules_url_error(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        import urllib.error

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                rules = p.get_rules()

        assert rules == []

    def test_get_rules_empty_yaml(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response("")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                rules = p.get_rules()

        assert rules == []

    def test_fetch_url_construction(self):
        p = StandardsGitHub(owner="acme", repo="my-standards", file_path="config/rules.yaml", ref="v2")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_test"}):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert "acme/my-standards" in req.full_url
        assert "config/rules.yaml" in req.full_url
        assert "ref=v2" in req.full_url

    def test_auth_header_with_token(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", {"GITHUB_TOKEN": "ghp_abc123"}):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer ghp_abc123"

    def test_no_auth_header_without_token(self):
        p = StandardsGitHub(owner="acme", repo="standards")
        mock_resp = MagicMock()
        mock_resp.read.return_value = _make_contents_response("rules: []")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            with patch.dict("os.environ", _home_env(), clear=True):
                p.get_rules()

        req = mock_open.call_args[0][0]
        assert req.get_header("Authorization") is None
