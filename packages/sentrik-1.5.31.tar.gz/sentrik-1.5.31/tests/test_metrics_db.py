"""Tests for the SQLite-based metrics database."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from guard.core.metrics_db import MetricsDB


def _sample_run_metadata(run_id: str = "run-001", **overrides) -> dict:
    """Return a minimal run_metadata dict."""
    base = {
        "run_id": run_id,
        "timestamp": "2026-03-20T10:00:00Z",
        "command": "scan",
        "duration_ms": 1234.5,
        "findings_count": 5,
        "files_scanned": 42,
    }
    base.update(overrides)
    return base


def _sample_findings_summary(**overrides) -> dict:
    base = {"critical": 1, "high": 2, "medium": 1, "low": 1, "info": 0}
    base.update(overrides)
    return base


def _sample_vuln_result(**overrides) -> dict:
    base = {
        "total_dependencies": 30,
        "vulnerable_count": 3,
        "scan_timestamp": "2026-03-20T10:05:00Z",
        "by_severity": {"critical": 1, "high": 1, "medium": 1, "low": 0},
    }
    base.update(overrides)
    return base


class TestMetricsDB:
    """Tests for MetricsDB."""

    def test_create_db(self, tmp_path: Path):
        """Creating a MetricsDB initializes scan_runs and vuln_scans tables."""
        db_path = tmp_path / "metrics.db"
        db = MetricsDB(db_path)
        try:
            conn = sqlite3.connect(str(db_path))
            tables = {
                row[0]
                for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            conn.close()
            assert "scan_runs" in tables
            assert "vuln_scans" in tables
        finally:
            db.close()

    def test_record_scan(self, tmp_path: Path):
        """record_scan inserts a row into scan_runs."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_scan(
                run_metadata=_sample_run_metadata(),
                findings_summary=_sample_findings_summary(),
                compliance_score=85.5,
                gate_passed=True,
            )
            rows = db.get_scan_history(limit=10)
            assert len(rows) == 1
            row = rows[0]
            assert row["run_id"] == "run-001"
            assert row["command"] == "scan"
            assert row["findings_total"] == 5
            assert row["critical"] == 1
            assert row["high"] == 2
            assert row["compliance_score"] == 85.5
            assert row["gate_passed"] == 1
            assert row["files_scanned"] == 42
            assert row["duration_ms"] == 1234.5
        finally:
            db.close()

    def test_record_scan_with_dict_compliance(self, tmp_path: Path):
        """record_scan accepts compliance_score as a dict from calculate_compliance_score."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            compliance = {
                "score": 92.3,
                "rules_total": 20,
                "rules_passed": 18,
                "rules_failed": 2,
            }
            db.record_scan(
                run_metadata=_sample_run_metadata(),
                findings_summary=_sample_findings_summary(),
                compliance_score=compliance,
                gate_passed=True,
            )
            rows = db.get_scan_history()
            assert len(rows) == 1
            assert rows[0]["compliance_score"] == 92.3
            assert rows[0]["rules_total"] == 20
            assert rows[0]["rules_passed"] == 18
        finally:
            db.close()

    def test_record_vuln_scan(self, tmp_path: Path):
        """record_vuln_scan inserts a row into vuln_scans."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_vuln_scan(_sample_vuln_result())
            conn = sqlite3.connect(str(tmp_path / "metrics.db"))
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM vuln_scans").fetchall()
            conn.close()
            assert len(rows) == 1
            row = dict(rows[0])
            assert row["total_deps"] == 30
            assert row["vulnerable_count"] == 3
            assert row["critical"] == 1
            assert row["high"] == 1
            assert row["medium"] == 1
            assert row["low"] == 0
        finally:
            db.close()

    def test_get_scan_history(self, tmp_path: Path):
        """get_scan_history returns scans ordered by timestamp desc."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            for i in range(3):
                db.record_scan(
                    run_metadata=_sample_run_metadata(
                        run_id=f"run-{i:03d}",
                        timestamp=f"2026-03-{20 + i:02d}T10:00:00Z",
                    ),
                    findings_summary=_sample_findings_summary(),
                )
            history = db.get_scan_history()
            assert len(history) == 3
            # Should be newest first
            assert history[0]["run_id"] == "run-002"
            assert history[1]["run_id"] == "run-001"
            assert history[2]["run_id"] == "run-000"
        finally:
            db.close()

    def test_get_scan_history_limit(self, tmp_path: Path):
        """get_scan_history respects the limit parameter."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            for i in range(10):
                db.record_scan(
                    run_metadata=_sample_run_metadata(
                        run_id=f"run-{i:03d}",
                        timestamp=f"2026-03-{10 + i:02d}T10:00:00Z",
                    ),
                    findings_summary=_sample_findings_summary(),
                )
            history = db.get_scan_history(limit=3)
            assert len(history) == 3
        finally:
            db.close()

    def test_get_trend_data(self, tmp_path: Path):
        """get_trend_data returns data grouped by day."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            # Insert two scans on the same day, one on a different day
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="a1", timestamp="2026-03-20T08:00:00Z"
                ),
                findings_summary=_sample_findings_summary(critical=2),
                compliance_score=80.0,
            )
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="a2", timestamp="2026-03-20T14:00:00Z"
                ),
                findings_summary=_sample_findings_summary(critical=4),
                compliance_score=70.0,
            )
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="b1", timestamp="2026-03-21T10:00:00Z"
                ),
                findings_summary=_sample_findings_summary(critical=0),
                compliance_score=95.0,
            )

            trend = db.get_trend_data(days=90)
            assert len(trend) == 2

            day1 = trend[0]
            assert day1["day"] == "2026-03-20"
            assert day1["scan_count"] == 2
            assert day1["critical"] == 6  # 2 + 4
            assert day1["avg_compliance"] == 75.0

            day2 = trend[1]
            assert day2["day"] == "2026-03-21"
            assert day2["scan_count"] == 1
            assert day2["critical"] == 0
        finally:
            db.close()

    def test_get_compliance_trend(self, tmp_path: Path):
        """get_compliance_trend returns compliance scores over time."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="c1", timestamp="2026-03-18T10:00:00Z"
                ),
                findings_summary=_sample_findings_summary(),
                compliance_score=70.0,
            )
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="c2", timestamp="2026-03-19T10:00:00Z"
                ),
                findings_summary=_sample_findings_summary(),
                compliance_score=85.0,
            )
            # One without compliance score — should be excluded
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="c3", timestamp="2026-03-20T10:00:00Z"
                ),
                findings_summary=_sample_findings_summary(),
                compliance_score=None,
            )

            trend = db.get_compliance_trend(days=90)
            assert len(trend) == 2
            assert trend[0]["compliance_score"] == 70.0
            assert trend[1]["compliance_score"] == 85.0
            # Ordered by timestamp ascending
            assert trend[0]["timestamp"] < trend[1]["timestamp"]
        finally:
            db.close()

    def test_get_stats(self, tmp_path: Path):
        """get_stats returns aggregate statistics."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="s1", timestamp="2026-03-18T10:00:00Z", findings_count=3
                ),
                findings_summary=_sample_findings_summary(),
                compliance_score=80.0,
                gate_passed=True,
            )
            db.record_scan(
                run_metadata=_sample_run_metadata(
                    run_id="s2", timestamp="2026-03-19T10:00:00Z", findings_count=7
                ),
                findings_summary=_sample_findings_summary(),
                compliance_score=60.0,
                gate_passed=False,
            )

            stats = db.get_stats()
            assert stats["total_scans"] == 2
            assert stats["avg_compliance"] == 70.0
            assert stats["min_compliance"] == 60.0
            assert stats["max_compliance"] == 80.0
            assert stats["gates_passed"] == 1
            assert stats["gates_failed"] == 1
            assert stats["first_scan"] == "2026-03-18T10:00:00Z"
            assert stats["last_scan"] == "2026-03-19T10:00:00Z"
        finally:
            db.close()

    def test_empty_db(self, tmp_path: Path):
        """An empty DB returns empty lists and zero stats."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            assert db.get_scan_history() == []
            assert db.get_trend_data() == []
            assert db.get_compliance_trend() == []

            stats = db.get_stats()
            assert stats["total_scans"] == 0
            assert stats["avg_compliance"] is None
            assert stats["gates_passed"] == 0
        finally:
            db.close()

    def test_duplicate_run_id(self, tmp_path: Path):
        """Duplicate run_id is ignored (INSERT OR IGNORE)."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_scan(
                run_metadata=_sample_run_metadata(run_id="dup-1"),
                findings_summary=_sample_findings_summary(critical=1),
                compliance_score=80.0,
            )
            # Same run_id again — should be silently ignored
            db.record_scan(
                run_metadata=_sample_run_metadata(run_id="dup-1"),
                findings_summary=_sample_findings_summary(critical=99),
                compliance_score=10.0,
            )

            rows = db.get_scan_history()
            assert len(rows) == 1
            # Original values preserved
            assert rows[0]["critical"] == 1
            assert rows[0]["compliance_score"] == 80.0
        finally:
            db.close()

    def test_context_manager(self, tmp_path: Path):
        """MetricsDB works as a context manager."""
        db_path = tmp_path / "metrics.db"
        with MetricsDB(db_path) as db:
            db.record_scan(
                run_metadata=_sample_run_metadata(),
                findings_summary=_sample_findings_summary(),
            )

        # Re-open to verify data persisted
        with MetricsDB(db_path) as db:
            rows = db.get_scan_history()
            assert len(rows) == 1

    def test_gate_passed_none(self, tmp_path: Path):
        """gate_passed=None is stored as NULL."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            db.record_scan(
                run_metadata=_sample_run_metadata(),
                findings_summary=_sample_findings_summary(),
                gate_passed=None,
            )
            rows = db.get_scan_history()
            assert rows[0]["gate_passed"] is None
        finally:
            db.close()

    def test_multiple_vuln_scans(self, tmp_path: Path):
        """Multiple vuln scans are all recorded (no uniqueness constraint)."""
        db = MetricsDB(tmp_path / "metrics.db")
        try:
            for i in range(3):
                db.record_vuln_scan(
                    _sample_vuln_result(
                        scan_timestamp=f"2026-03-{20 + i:02d}T10:00:00Z"
                    )
                )
            conn = sqlite3.connect(str(tmp_path / "metrics.db"))
            count = conn.execute("SELECT COUNT(*) FROM vuln_scans").fetchone()[0]
            conn.close()
            assert count == 3
        finally:
            db.close()

    def test_db_created_in_subdirectory(self, tmp_path: Path):
        """MetricsDB creates parent directories if they don't exist."""
        db_path = tmp_path / "deep" / "nested" / "metrics.db"
        db = MetricsDB(db_path)
        db.close()
        assert db_path.exists()
