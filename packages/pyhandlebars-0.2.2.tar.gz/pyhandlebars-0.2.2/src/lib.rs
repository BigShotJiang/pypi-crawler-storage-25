use std::sync::OnceLock;

use pyo3::pyclass;
use pyo3::types::PyAnyMethods;
use pyo3::{prelude::*, types::PyCFunction};

use handlebars::{
    Context, Handlebars, Helper, HelperDef, HelperResult, Output, RenderContext, RenderError,
    RenderErrorReason,
};

mod utils;
use utils::{make_template_name, py_to_json};

pyo3::create_exception!(
    pyhandlebars,
    PyHandlebarsError,
    pyo3::exceptions::PyException
);
pyo3::create_exception!(pyhandlebars, TemplateParseError, PyHandlebarsError);
pyo3::create_exception!(pyhandlebars, FormatError, PyHandlebarsError);
pyo3::create_exception!(pyhandlebars, HelperError, PyHandlebarsError);

struct PyHelper(Py<PyAny>);

// SAFETY: Py<PyAny> is Send. We never access it without holding the GIL via Python::attach.
unsafe impl Sync for PyHelper {}

impl HelperDef for PyHelper {
    fn call<'reg: 'rc, 'rc>(
        &self,
        h: &Helper<'rc>,
        _: &'reg Handlebars<'reg>,
        ctx: &'rc Context,
        _: &mut RenderContext<'reg, 'rc>,
        out: &mut dyn Output,
    ) -> HelperResult {
        let result = Python::attach(|py| -> PyResult<String> {
            let json_mod = py.import("json")?;

            let args: Vec<Py<PyAny>> = h
                .params()
                .iter()
                .map(|p| {
                    let s = serde_json::to_string(p.value())
                        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
                    json_mod.call_method1("loads", (s,)).map(|r| r.into())
                })
                .collect::<PyResult<_>>()?;

            let data_str = serde_json::to_string(ctx.data())
                .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
            let data_py: Py<PyAny> = json_mod.call_method1("loads", (data_str,))?.into();

            let ret = self.0.call1(py, (args, data_py))?;
            if let Ok(s) = ret.extract::<String>(py) {
                Ok(s)
            } else {
                json_mod.call_method1("dumps", (ret,))?.extract::<String>()
            }
        });

        match result {
            Ok(s) => {
                out.write(&s)?;
                Ok(())
            }
            Err(e) => Err(RenderErrorReason::Other(format!("\x00helper\x00{}", e)).into()),
        }
    }
}

fn _register(
    py: Python<'_>,
    target: Py<PyHandlebars>,
    name: Option<String>,
    func: Bound<'_, PyAny>,
) -> Result<Py<PyAny>, PyErr> {
    let func_clone = func.clone();
    let resolved_name = match name {
        Some(n) => n,
        None => func_clone.getattr("__name__")?.extract::<String>()?,
    };

    target
        .borrow_mut(py)
        .register_helper(&resolved_name, func.unbind());
    Ok(func_clone.unbind())
}

#[pyclass]
struct HelperMethod;

#[pymethods]
impl HelperMethod {
    fn __get__<'py>(
        &self,
        py: Python<'py>,
        obj: Option<Py<PyHandlebars>>,
        _cls: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<Bound<'py, PyCFunction>> {
        let target: Py<PyHandlebars> = match obj {
            Some(instance) => instance,
            None => global_client(py)?,
        };

        PyCFunction::new_closure(py, None, None, move |args: &Bound<'_, pyo3::types::PyTuple>, kwargs: Option<&Bound<'_, pyo3::types::PyDict>>| {
            let raw_func = args.get_item(0).ok();
            let name: Option<String> = match kwargs {
                Some(kw) => kw
                    .get_item("name")?
                    .map(|v: Bound<'_, PyAny>| v.extract::<String>())
                    .transpose()?,
                None => None,
            };

            let target_none = target.clone_ref(args.py());

            match raw_func {
                Some(f) => _register(args.py(), target.clone_ref(args.py()), name, f),
                None => {
                    let new_f =
                        PyCFunction::new_closure(args.py(), None, None, move |args: &Bound<'_, pyo3::types::PyTuple>, _kwargs: Option<&Bound<'_, pyo3::types::PyDict>>| {
                            let raw_func = args.get_item(0)?;
                            _register(
                                args.py(),
                                target_none.clone_ref(args.py()),
                                name.clone(),
                                raw_func,
                            )
                        })?;
                    Ok(new_f.into_any().unbind())
                }
            }
        })
    }
}

static GLOBAL_CLIENT: OnceLock<Py<PyHandlebars>> = OnceLock::new();

fn global_client(py: Python<'_>) -> PyResult<Py<PyHandlebars>> {
    let client = GLOBAL_CLIENT.get_or_init(|| {
        Py::new(
            py,
            PyHandlebars {
                client: Handlebars::new(),
            },
        )
        .expect("failed to create global client")
    });
    Ok(client.clone_ref(py))
}

#[pyclass]
struct PyHandlebars {
    client: Handlebars<'static>,
}

#[pymethods]
impl PyHandlebars {
    #[new]
    #[pyo3(signature = (*, dev_mode=false, strict_mode=false))]
    fn new(dev_mode: bool, strict_mode: bool) -> Self {
        let mut client = Handlebars::new();
        client.set_strict_mode(strict_mode);
        client.set_dev_mode(dev_mode);
        PyHandlebars { client }
    }

    fn register_helper(&mut self, name: &str, func: Py<PyAny>) {
        self.client.register_helper(name, Box::new(PyHelper(func)));
    }

    #[classattr]
    fn helper(py: Python<'_>) -> PyResult<Py<HelperMethod>> {
        Py::new(py, HelperMethod)
    }

    // #[pyo3(signature=(*, name=None))]
    // fn helper(
    //     slf: Py<PyHandlebars>,
    //     py: Python<'_>,
    //     name: Option<String>,
    // ) -> PyResult<Bound<'_, PyCFunction>> {
    //     PyCFunction::new_closure(py, None, None, move |args, _kwargs| {
    //         let func = args.get_item(0)?;
    //         let resolved_name = match &name {
    //             Some(n) => n.clone(),
    //             None => func.getattr("__name__")?.extract::<String>()?,
    //         };

    //         let py = args.py();
    //         let func_clone = func.clone();
    //         slf.borrow_mut(py)
    //             .client
    //             .register_helper(&resolved_name, Box::new(PyHelper(func_clone.unbind())));
    //         Ok::<_, PyErr>(func.unbind())
    //     })
    // }
}

fn render_error_to_py(e: RenderError) -> PyErr {
    let msg = e.to_string();
    if let Some(pos) = msg.find("\x00helper\x00") {
        return HelperError::new_err(msg[pos + "\x00helper\x00".len()..].to_string());
    }
    let detail = match e.reason() {
        RenderErrorReason::MissingVariable(Some(var)) => {
            format!(
                "In the template the variable '{var}' is expected, but not provided when calling Template.format(). This error is only raised if the PyHandlebars(strict_mode=True) is set."
            )
        }
        _ => msg,
    };
    FormatError::new_err(detail)
}

#[pyclass]
struct Template {
    client: Py<PyHandlebars>,
    key: String,
}

#[pymethods]
impl Template {
    #[new]
    #[pyo3(signature = (template, *, name=None, client=None))]
    fn new(
        py: Python,
        template: &str,
        name: Option<String>,
        client: Option<Py<PyHandlebars>>,
    ) -> PyResult<Self> {
        let client = match client {
            Some(c) => c,
            None => global_client(py)?,
        };
        let key = make_template_name(name);
        client
            .borrow_mut(py)
            .client
            .register_template_string(&key, template)
            .map_err(|e| TemplateParseError::new_err(e.to_string()))?;
        Ok(Template { client, key })
    }

    #[classmethod]
    #[pyo3(signature = (path, *, name=None, client=None))]
    fn from_file(
        _cls: &Bound<'_, pyo3::types::PyType>,
        py: Python,
        path: &Bound<'_, PyAny>,
        name: Option<String>,
        client: Option<Py<PyHandlebars>>,
    ) -> PyResult<Self> {
        let key = make_template_name(name);
        let path_str: String = path.str()?.extract()?;
        let client = match client {
            Some(c) => c,
            None => global_client(py)?,
        };
        client
            .borrow_mut(py)
            .client
            .register_template_file(&key, &path_str)
            .map_err(|e| TemplateParseError::new_err(e.to_string()))?;
        Ok(Template { client, key })
    }

    fn format(&self, data: &Bound<'_, PyAny>) -> PyResult<String> {
        let py = data.py();

        let serializable = if data.hasattr("model_dump")? {
            data.call_method0("model_dump")?
        } else {
            data.clone()
        };

        let json_data = py_to_json(&serializable)?;

        self.client
            .borrow(py)
            .client
            .render(&self.key, &json_data)
            .map_err(render_error_to_py)
    }
}

impl Drop for Template {
    fn drop(&mut self) {
        Python::attach(|py| {
            self.client
                .borrow_mut(py)
                .client
                .unregister_template(&self.key);
        });
    }
}

#[pymodule]
fn pyhandlebars(_py: Python<'_>, m: &Bound<PyModule>) -> PyResult<()> {
    m.add_class::<PyHandlebars>()?;
    m.add_class::<Template>()?;

    m.add("PyHandlebarsError", m.py().get_type::<PyHandlebarsError>())?;
    m.add(
        "TemplateParseError",
        m.py().get_type::<TemplateParseError>(),
    )?;
    m.add("FormatError", m.py().get_type::<FormatError>())?;
    m.add("HelperError", m.py().get_type::<HelperError>())?;

    Ok(())
}
