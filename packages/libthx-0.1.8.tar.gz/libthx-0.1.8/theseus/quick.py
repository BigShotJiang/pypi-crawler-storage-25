"""
Quick job runner for rapid prototyping and testing.

Usage:
    from theseus.quick import quick
    from theseus.registry import JOBS

    job = JOBS["continual/train/abcd"]

    with quick(job, "/sailhome/houjun/theseus/", "test") as j:
        j.config.logging.checkpoint_interval = 16384
        j.config.logging.validation_interval = 2048
        j.config.training.per_device_batch_size = 16

        j()

    # Or save config to file for later submission:
    with quick(job, "/sailhome/houjun/theseus/", "test") as j:
        j.config.training.per_device_batch_size = 16
        j.save("config.yaml", chip="h100", n_chips=8, n_shards=4)
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, TYPE_CHECKING

from omegaconf import OmegaConf

from theseus.config import build, configuration, _current_config
from theseus.registry import JOBS


if TYPE_CHECKING:
    from contextvars import Token
    from omegaconf import DictConfig


def _resolve_job(job: Any | str, name: str) -> tuple[Any, str]:
    """Resolve a job class or name string into (job_cls, job_name)."""
    if isinstance(job, str):
        job_name = job
        if job not in JOBS:
            raise ValueError(
                f"Job '{job}' not found in registry. Available: {list(JOBS.keys())}"
            )
        return JOBS[job], job_name
    job_cls = job
    job_name = next(
        (n for n, cls in JOBS.items() if cls is job_cls),
        "unknown",
    )
    return job_cls, job_name


class QuickJob:
    """Wrapper for quick job execution."""

    def __init__(
        self,
        job_cls: Any,
        job_name: str,
        out_path: str | None,
        name: str,
        project: str | None = None,
        group: str | None = None,
        config: DictConfig | None = None,
    ):
        self._job_cls = job_cls
        self._job_name = job_name
        self._out_path = out_path
        self._name = name
        self._project = project
        self._group = group
        self._instance: Any = None
        self._config_token: Token[Any] | None = None

        if config is not None:
            self.config: DictConfig = config
        else:
            # Build config from job class
            job_config = job_cls.config()
            if isinstance(job_config, (list, tuple)):
                self.config = build(*job_config)
            else:
                self.config = build(job_config)

    def close(self) -> None:
        """Reset the global config context set by init()."""
        if self._config_token is not None:
            _current_config.reset(self._config_token)
            self._config_token = None

    def create(self) -> Any:
        """Create and return the job instance without running it."""
        if self._instance is None:
            out_path = self._out_path or os.environ.get("THESEUS_ROOT", ".")
            self._instance = self._job_cls.local(
                out_path,
                name=self._name,
                project=self._project,
                group=self._group,
            )
        return self._instance

    def __call__(self) -> Any:
        """Run the job."""
        return self.create()()

    def save(
        self,
        out_yaml: str,
        chip: str | None = None,
        n_chips: int | None = None,
        n_shards: int | None = None,
    ) -> Path:
        """Save the config to a YAML file.

        Args:
            out_yaml: Output path for the YAML config
            chip: Optional chip type for hardware request (e.g., "h100", "a100")
            n_chips: Optional minimum number of chips for hardware request
            n_shards: Optional number of tensor parallel shards for the model

        Returns:
            Path to the saved config file
        """
        from theseus.base.chip import SUPPORTED_CHIPS

        # Validate chip if specified
        if chip and chip not in SUPPORTED_CHIPS:
            raise ValueError(
                f"Unknown chip '{chip}'. Available: {list(SUPPORTED_CHIPS.keys())}"
            )

        # Make a copy of config to modify
        config = OmegaConf.create(OmegaConf.to_container(self.config))
        OmegaConf.set_struct(config, False)

        # Add job name
        config.job = self._job_name

        # Add hardware request if specified
        if chip or n_chips or n_shards:
            config.request = OmegaConf.create({})
            if chip:
                config.request.chip = chip
            if n_chips:
                config.request.min_chips = n_chips
            if n_shards:
                config.request.n_shards = n_shards

        OmegaConf.set_struct(config, True)

        # Write the config
        out_path = Path(out_yaml)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        yaml_str = OmegaConf.to_yaml(config)
        out_path.write_text(yaml_str)

        return out_path


@contextmanager
def quick(
    job: Any | str,
    name: str,
    out_path: str | None = None,
    project: str | None = None,
    group: str | None = None,
    config: DictConfig | None = None,
) -> Generator[QuickJob, None, None]:
    """Context manager for quick job execution.

    Args:
        job: Job class or job name string (e.g., "continual/train/abcd")
        name: Name of the job run
        out_path: Output path for job results. If None, uses $THESEUS_ROOT or "."
        project: Optional project name
        group: Optional group name
        config: Optional OmegaConf config to use instead of the job's default

    Yields:
        QuickJob instance with .config attribute for modification

    Example:
        with quick(JOBS["my/job"], "/path/to/output", "test") as j:
            j.config.training.batch_size = 32
            j()
    """
    job_cls, job_name = _resolve_job(job, name)
    quick_job = QuickJob(job_cls, job_name, out_path, name, project, group, config)

    with configuration(quick_job.config):
        yield quick_job


def init(
    job: Any | str,
    name: str,
    out_path: str | None = None,
    project: str | None = None,
    group: str | None = None,
    config: DictConfig | None = None,
) -> QuickJob:
    """Non-context-manager variant of quick().

    Sets the global config directly. Call .close() when done to reset it.

    Args:
        job: Job class or job name string (e.g., "continual/train/abcd")
        name: Name of the job run
        out_path: Output path for job results. If None, uses $THESEUS_ROOT or "."
        project: Optional project name
        group: Optional group name
        config: Optional OmegaConf config to use instead of the job's default

    Returns:
        QuickJob instance with .config attribute for modification.

    Example:
        j = init(BackbonedTrainer, "test")
        j.config.training.per_device_batch_size = 1
        job = j.create()
        # ... use job ...
        j.close()
    """
    job_cls, job_name = _resolve_job(job, name)
    quick_job = QuickJob(job_cls, job_name, out_path, name, project, group, config)
    quick_job._config_token = _current_config.set(quick_job.config)
    return quick_job
