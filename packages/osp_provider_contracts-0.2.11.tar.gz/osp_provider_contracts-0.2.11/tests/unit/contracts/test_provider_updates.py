"""Contract tests for provider update envelope helpers."""

import pytest

from osp_provider_contracts.provider_updates import (
    ALLOWED_PROVIDER_UPDATE_STATUS_CODES,
    PROVIDER_UPDATE_KIND_TASK_EVENT,
    PROVIDER_UPDATE_STATUS_CODES,
    build_provider_update_envelope,
    is_allowed_provider_update_status,
    parse_provider_update_envelope,
)


def test_build_provider_update_envelope_uses_contract_shape() -> None:
    """Build helper should emit normalized contract envelope fields."""
    envelope = build_provider_update_envelope(
        envelope_version="1.0",
        contract_version="1.0",
        message_id="evt-1",
        task_ref="task-42",
        task_id=42,
        status_code=160,
        severity=20,
        message="running",
        payload={"step": "clone"},
    )

    assert envelope["kind"] == PROVIDER_UPDATE_KIND_TASK_EVENT
    assert envelope["task_id"] == "42"
    assert envelope["payload"]["status_code"] == 160
    assert envelope["payload"]["severity"] == 20
    assert envelope["payload"]["message"] == "running"
    assert envelope["payload"]["payload"] == {"step": "clone"}


def test_parse_provider_update_envelope_derives_task_id_from_task_ref() -> None:
    task_id, _event = parse_provider_update_envelope(
        {
            "envelope_version": "1.0",
            "contract_version": "1.0",
            "message_id": "evt-2",
            "task_ref": "task-77",
            "kind": "task_event",
            "payload": {
                "status_code": 200,
                "severity": 20,
                "message": "done",
                "payload": {},
            },
        }
    )
    assert task_id == 77


def test_parse_provider_update_envelope_coerces_task_id_and_payload() -> None:
    """Parse helper should normalize task_id and event payload values."""
    task_id, event = parse_provider_update_envelope(
        {
            "envelope_version": "1.0",
            "contract_version": "1.0",
            "message_id": "evt-1",
            "task_ref": "task-42",
            "task_id": "42",
            "kind": "task_event",
            "payload": {
                "status_code": 200,
                "severity": 20,
                "message": "done",
                "payload": {"x": 1},
            },
        }
    )

    assert task_id == 42
    assert event["status_code"] == 200
    assert event["severity"] == 20
    assert event["message"] == "done"
    assert event["payload"] == {"x": 1}


def test_parse_provider_update_envelope_rejects_invalid_shape() -> None:
    """Parser should fail closed for non-contract or malformed envelopes."""
    with pytest.raises(ValueError):
        parse_provider_update_envelope({"kind": "legacy"})

    with pytest.raises(ValueError):
        parse_provider_update_envelope(
            {
                "envelope_version": "1.0",
                "contract_version": "1.0",
                "message_id": "evt-1",
                "task_ref": "task-42",
                "task_id": "not-an-int",
                "kind": "task_event",
                "payload": {
                    "status_code": 200,
                    "severity": 20,
                    "message": "done",
                    "payload": {},
                },
            }
        )


def test_allowed_provider_update_status_codes_match_exported_named_map() -> None:
    assert ALLOWED_PROVIDER_UPDATE_STATUS_CODES == frozenset(PROVIDER_UPDATE_STATUS_CODES.values())


def test_provider_update_status_helper_accepts_runtime_statuses_only() -> None:
    assert is_allowed_provider_update_status(PROVIDER_UPDATE_STATUS_CODES["DISPATCHED"]) is True
    assert is_allowed_provider_update_status(PROVIDER_UPDATE_STATUS_CODES["RUNNING"]) is True
    assert is_allowed_provider_update_status(PROVIDER_UPDATE_STATUS_CODES["COMPLETED"]) is True
    assert is_allowed_provider_update_status(105) is False
    assert is_allowed_provider_update_status(101) is False
    assert is_allowed_provider_update_status(None) is False

    with pytest.raises(ValueError):
        parse_provider_update_envelope(
            {
                "envelope_version": "1.0",
                "contract_version": "1.0",
                "message_id": "evt-1",
                "task_ref": "task-42",
                "task_id": "41",
                "kind": "task_event",
                "payload": {
                    "status_code": 200,
                    "severity": 20,
                    "message": "done",
                    "payload": {},
                },
            }
        )
