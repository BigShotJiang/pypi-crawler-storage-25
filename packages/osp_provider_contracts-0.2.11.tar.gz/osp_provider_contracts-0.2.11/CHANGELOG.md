# Changelog

## 0.2.11 - 2026-04-19

- Added the shared provider-update status vocabulary in
  `osp_provider_contracts.provider_updates`:
  - `PROVIDER_UPDATE_STATUS_CODES`
  - `ALLOWED_PROVIDER_UPDATE_STATUS_CODES`
  - `is_allowed_provider_update_status()`
- This makes the provider-emittable status set a contracts concern so
  orchestrator can import the vocabulary instead of carrying a parallel copy
  next to its local transition policy.

## 0.2.10 - 2026-04-19

- Fixed the runtime package version to match the published project metadata.
- `osp_provider_contracts.__version__` now reports the actual release instead of
  the stale `0.2.7` constant that leaked into `0.2.9`.

## 0.2.9 - 2026-04-19

- Added shared gate-vocabulary helpers in `osp_provider_contracts.approval`:
  - `normalize_gate_reason()`
  - `gate_tags_for_reason()`
- These helpers centralize legacy gate-alias normalization and default tag
  mapping so providers stop carrying parallel copies of the same contract
  logic.

## 0.2.8 - 2026-04-13

- Added the minimum shared planner result types:
  `PlanningState`, `PlanningDecision`, `PlannerGate`, and `PlannerResult`.
- Exported planner result validation so providers can validate request-time
  planner output against one shared contract.
- Switched repository quality gates and release workflows from `mypy` to `ty`
  so publishing uses the same type checker as local Hatch checks.

## 0.2.7 - 2026-02-22

- Simplified approval gate reasons to the canonical five strings and removed
  legacy names from the GateReason enum.
- Added optional `required_approvals` to approval-required payloads and
  documented quorum calculation with importance + policy.
- Updated approval examples and gate troubleshooting guidance.

## 0.2.6 - 2026-02-22

- Docs-only patch: clarify capabilities as advisory hints and record missing
  0.2.5 release notes.

## 0.2.5 - 2026-02-22

- Canonicalized gate reasons and `task_ref` update envelope fields to keep
  approvals and provider updates aligned across orchestrator/clients.
- Accepted capabilities payloads in the protocol so RPC callers can pass
  request metadata for provider filtering.
- Documentation: switched gate docs to `gate_reason` and clarified that
  capabilities are advisory hints, not enforcement.

## 0.2.4 - 2026-02-20

- Added shared provider update envelope contracts in
  `osp_provider_contracts.provider_updates`:
  - `ProviderUpdateEnvelope`
  - `ProviderTaskEvent`
  - `build_provider_update_envelope()`
  - `parse_provider_update_envelope()`
- Exported provider update contracts from package root.
- Added regression tests for update envelope build/parse behavior.

## 0.2.3 - 2026-02-20

- Exported approval TypedDict contracts at package root to simplify imports
  for provider and orchestrator consumers.
- Hardened capabilities validation to reject string values for
  `capabilities.resources` while still accepting generic mappings.
- Renamed conformance helpers from `testing` to `conformance` and reorganized
  tests under `tests/unit/` with matching docs updates.
- Added broader module and API documentation polish for maintainers.

## 0.2.2 - 2026-02-17

- Added typed approval payload contracts for violations-first gate
  evidence:
  - `CommentKind`
  - `GateViolation`
  - `ApprovalTargets`
  - `ApprovalDetails`
  - `ApprovalRequiredExtra`
- Aligns provider and orchestrator/CLI consumers on the
  `violations[]` contract shape for gate explainability.

## 0.2.1 - 2026-02-17

- Added canonical `GateCode` enum for approval gate responses in
  `osp_provider_contracts.approval`.
- Added `GateCode.EXTRA_EYES_REQUIRED = 432` for orchestrator
  dual-control approval gating.

## 0.2.0 - 2026-02-12

- Removed ambiguous `ProviderResult.state`; providers now return result payload via `data`.
- Kept `external_id` as the canonical top-level identifier field on `ProviderResult`.
- Hardened idempotency hashing input encoding to avoid delimiter-collision ambiguity.
- Removed unused `osp_provider_contracts.conformance.fixtures` helpers.
- Reduced repository `.gitignore` to a focused package-level set.

## 0.1.0 - 2026-02-12

- Initial alpha release.
- Added provider protocol, shared types, and canonical errors.
- Added capabilities validation and idempotency key helper.
- Added lightweight conformance assertions for provider tests.
