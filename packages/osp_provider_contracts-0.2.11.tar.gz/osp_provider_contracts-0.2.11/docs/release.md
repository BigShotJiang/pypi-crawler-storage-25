# Release Guide

## Automated on tag

On tag `vX.Y.Z`, CI:
- runs lint, type-check, and tests
- builds `sdist` and wheel
- runs `twine check dist/*`
- uploads artifacts to the GitHub Release

## Manual/gated publish

Publishing to PyPI (or internal index) is intentionally manual/gated.

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run dev:check
hatch run dev:publish
```

If using a custom repository:

```bash
hatch run dev:publish -- -r <repo-name>
```

`dev:publish` behavior:
- removes `dist/` first (no stale artifact uploads)
- builds fresh wheel + sdist for the current version
- refuses publish if unexpected files are present in `dist/`
- runs `twine check` before upload
- disables keyring backend to avoid locked desktop keyring failures
- removes `dist/` again after successful upload

Credentials should be stored in `~/.pypirc` (or env vars), not committed.

TestPyPI dry run publish:

```bash
hatch run dev:publish-test
```
