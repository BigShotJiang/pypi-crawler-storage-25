# v1.4 P2: Command Consolidation Design

> **For agentic workers:** Use superpowers:subagent-driven-development to implement this spec after the plan is written.

**Goal:** Reduce cognitive overhead by merging 5 commands into 2 logical groups, bringing visible command count from 27 to 23.

**Version:** v1.4.0 (ships alongside context recovery)

---

## Problem

Three commands (`save`, `templates`, `use`) do one thing — manage prompt templates — but live as separate top-level commands. Two more commands (`effectiveness`, `merge-view`) surface niche analytics that belong inside the existing `insights` command. This fragments the CLI surface and increases the learning curve.

### Current State

| Command | Purpose | Weekly usage (estimated) |
|---------|---------|------------------------|
| `save` | Save prompt as template | Low |
| `templates` | List saved templates | Low |
| `use` | Interpolate template | Low |
| `effectiveness` | Pattern effectiveness scores | Low |
| `merge-view` | Clusters of similar prompts | Low |

All five are Tier C commands (from the v1.3 command audit) with low discoverability and unclear naming.

---

## Solution

### 1. `reprompt template` Command Group

Merge `save`, `templates`, and `use` into a Typer sub-app under `reprompt template`.

#### Subcommands

| Subcommand | Maps from | Signature |
|------------|-----------|-----------|
| `template save "text"` | `save` | `--name/-n`, `--category/-c`, `--json` (new) |
| `template list` | `templates` | `--category/-c`, `--json` |
| `template use <name> [vars...]` | `use` | `--json` (new), `--copy` (new) |

#### Behavior

- `reprompt template` with no subcommand → runs `template list` (sensible default)
- `template save` gains `--json` for pipeline consistency
- `template use` gains `--json` and `--copy` (aligned with roadmap P5)
- All subcommands support existing flags unchanged

#### Implementation

```python
template_app = typer.Typer(help="Manage prompt templates.", invoke_without_command=True)

@template_app.callback(invoke_without_command=True)
def template_default(ctx: typer.Context) -> None:
    """Manage prompt templates."""
    if ctx.invoked_subcommand is None:
        template_list()

@template_app.command("save")
def template_save(
    text: str = typer.Argument(..., help="Prompt text to save as template"),
    name: str = typer.Option("", "--name", "-n", help="Template name"),
    category: str = typer.Option("", "--category", "-c", help="Category"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None: ...

@template_app.command("list")
def template_list(
    category: str = typer.Option("", "--category", "-c", help="Filter by category"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None: ...

@template_app.command("use")
def template_use(
    name: str = typer.Argument(..., help="Template name"),
    variables: list[str] = typer.Argument(None, help="Variables as key=value"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    copy: bool = typer.Option(False, "--copy", help="Copy to clipboard"),
) -> None: ...

app.add_typer(template_app, name="template")
```

#### Core Module

`core/templates.py` is unchanged. The CLI layer calls the same functions:
- `save_template(db, text, name, category)`
- `db.list_templates(category=...)`
- `db.get_template(name)`, `render_template(text, vars)`, `extract_variables(text)`

### 2. `insights` Expansion

Fold `effectiveness` and `merge-view` data into the existing `insights` command output.

#### New Sections

Added after existing insights sections (specificity, structure, context):

**Effectiveness section:**
- Top 3 patterns by effectiveness score (star rating + use count + avg score)
- Worst 1 pattern (improvement opportunity)
- Sourced from `db.get_patterns()` sorted by `effectiveness_avg DESC`, filtered to patterns where `effectiveness_avg IS NOT NULL`. Use `effectiveness_stars()` from `core/effectiveness.py` to convert the normalized score to stars. Pattern `frequency` maps to "N uses", `effectiveness_avg * 100` maps to displayed integer score (e.g., 78). **Important:** Pass the raw `0.0-1.0` float to `effectiveness_stars()` (it multiplies by 5 internally), but display the `* 100` integer to the user.

**Similar Prompts section:**
- Top 3 clusters of near-duplicate prompts (cluster size + representative text)
- Sourced from `build_clusters()` from `core/merge_view.py`. **Note:** `build_clusters()` has no `source` parameter — source filtering is done upstream by calling `db.get_all_prompts(source=source)` before passing texts to `build_clusters()`.

#### Output Format

```
── Your Insights ──────────────────────
[existing sections unchanged]

── Effectiveness ──────────────────────
  Your top patterns:
    ★★★ "fix bug in..." (12 uses, avg 78)
    ★★☆ "add feature..." (8 uses, avg 65)
  Weakest: "help me with..." (5 uses, avg 32)
  → Try: reprompt score "prompt" (improve weak patterns)

── Similar Prompts ────────────────────
  3 clusters of near-duplicate prompts found
    "explain X" — 5 variations (consider templating)
    "debug Y" — 4 variations
  → Try: reprompt template save "..." (reuse instead of rewrite)
```

#### Behavior Rules

- **Minimum data threshold:** Both sections require >= 5 prompts in DB. Below that, section is silently omitted.
- **Empty state:** If no effectiveness data or no clusters found, section is silently omitted (no "no data" message).
- **`--json` output:** Adds `effectiveness` and `similar_prompts` keys to existing JSON envelope.
- **`--source` filter:** Threads through to both new sections. Effectiveness: `db.get_patterns()` already stores source-agnostic data, so `get_effectiveness_insight()` filters patterns by checking their associated prompts' source. Similar prompts: `get_similar_prompts_insight(db, source=source)` calls `db.get_all_prompts(source=source)` to get filtered texts, then passes them to `build_clusters()` (which has no source parameter itself).
- **Suggestions suppressed in `--json` mode** (existing behavior, applies to new sections too).

#### Core Module Changes

`core/insights.py` gains two new functions:

```python
def get_effectiveness_insight(db: PromptDB, source: str | None = None) -> dict | None:
    """Returns top 3 + worst 1 effectiveness patterns, or None if insufficient data."""

def get_similar_prompts_insight(db: PromptDB, source: str | None = None) -> dict | None:
    """Returns top 3 duplicate clusters, or None if insufficient data."""
```

These import from `core/effectiveness.py` and `core/merge_view.py` respectively. No changes to those modules.

`output/terminal.py` gains rendering functions for the two new sections, following existing Rich panel patterns.

### 3. Deprecation Layer

Old commands remain as hidden, deprecated aliases for one release cycle (v1.4 → removed in v1.5 or v2.0).

```python
@app.command(deprecated=True, hidden=True)
def save(
    text: str = typer.Argument(...),
    name: str = typer.Option("", "--name", "-n"),
    category: str = typer.Option("", "--category", "-c"),
) -> None:
    """Deprecated: use `reprompt template save` instead."""
    template_save(text=text, name=name, category=category)

@app.command(deprecated=True, hidden=True)
def templates(
    category: str = typer.Option("", "--category", "-c"),
    json_output: bool = typer.Option(False, "--json"),
) -> None:
    """Deprecated: use `reprompt template list` instead."""
    template_list(category=category, json_output=json_output)

@app.command(deprecated=True, hidden=True)
def use(
    name: str = typer.Argument(...),
    variables: list[str] = typer.Argument(None),
) -> None:
    """Deprecated: use `reprompt template use` instead."""
    template_use(name=name, variables=variables)

@app.command(deprecated=True, hidden=True)
def effectiveness(
    top: int = typer.Option(10),
    worst: int = typer.Option(3),
    format: str = typer.Option("terminal"),
) -> None:
    """Deprecated: use `reprompt insights` instead."""
    typer.echo("Warning: 'effectiveness' is deprecated. Use 'reprompt insights' instead.", err=True)
    insights(json_output=(format == "json"), source=None)

@app.command(deprecated=True, hidden=True)
def merge_view(
    json_output: bool = typer.Option(False, "--json"),
    limit: int = typer.Option(0, "--limit"),
) -> None:
    """Deprecated: use `reprompt insights` instead."""
    typer.echo("Warning: 'merge-view' is deprecated. Use 'reprompt insights' instead.", err=True)
    insights(json_output=json_output, source=None)
```

**Note:** `effectiveness` and `merge-view` deprecated commands redirect to full `insights` output, not to their specific section. This is intentional — users should see the unified view.

### 4. Cross-Reference Updates

| Location | Current | Updated |
|----------|---------|---------|
| `output/terminal.py` `render_merge_view()` footer | `reprompt save` | `reprompt template save` |
| `output/terminal.py` `render_templates()` empty state | `reprompt save` | `reprompt template save` |
| `core/suggestions.py` — insights entry | (no reference) | Add `"reprompt template save \"...\" (reuse effective patterns)"` |
| `core/suggestions.py` — new template entry | (doesn't exist) | Add template journey hint → `"reprompt insights (see which patterns work best)"` |
| `docs/roadmap.md` | 27 commands | 23 visible commands |
| `CLAUDE.md` | command list includes save/templates/use/effectiveness/merge-view | Update to show `template [save\|list\|use]` and note insights expansion |

---

## Testing Strategy

### New Tests (~23 tests)

**`tests/test_template_cli.py`** (~10 tests):
- `template save` basic, with `--name`/`--category`, with `--json`
- `template list` empty, with data, filtered by category, `--json`
- `template use` basic, with variables, missing template, `--json`, `--copy`

**`tests/test_insights_expanded.py`** (~8 tests):
- Insights output includes effectiveness section when data exists
- Insights output includes similar prompts section when clusters exist
- Sections omitted when < 5 prompts
- Sections omitted when no effectiveness data / no clusters
- `--json` includes new keys
- `--source` threads through to new sections

**`tests/test_deprecated_commands.py`** (~5 tests):
- `save` still works, delegates to `template save`
- `templates` still works, delegates to `template list`
- `use` still works, delegates to `template use`
- `effectiveness` redirects to insights with warning
- `merge-view` redirects to insights with warning

### Existing Tests

All 62 existing tests for these 5 commands continue passing — they test core modules (`core/templates.py`, `core/effectiveness.py`, `core/merge_view.py`) and DB layer, not CLI layer.

---

## Files Changed

| File | Change |
|------|--------|
| `src/reprompt/cli.py` | Add `template_app` Typer sub-app; deprecate 5 old commands; expand `insights` call |
| `src/reprompt/core/insights.py` | Add `get_effectiveness_insight()`, `get_similar_prompts_insight()` |
| `src/reprompt/output/terminal.py` | Add render functions for effectiveness + similar prompts sections; update cross-references |
| `src/reprompt/core/suggestions.py` | Add template + insights journey hints |
| `docs/roadmap.md` | Update command count |
| `CLAUDE.md` | Update command list |
| `tests/test_template_cli.py` | New |
| `tests/test_insights_expanded.py` | New |
| `tests/test_deprecated_commands.py` | New |

## Files Unchanged

- `core/templates.py` — all logic stays
- `core/effectiveness.py` — all logic stays
- `core/merge_view.py` — all logic stays
- `storage/db.py` — all DB methods stay
- All existing test files — core module tests unaffected

---

## Open/Pro Boundary

All changes are open-source (rule-based, no LLM). No Pro plugin impact.

---

## Success Criteria

1. `reprompt template save/list/use` works with all flags
2. `reprompt insights` shows effectiveness + similar prompts sections
3. Old commands (`save`, `templates`, `use`, `effectiveness`, `merge-view`) still work with deprecation warnings
4. `--json` on all template subcommands
5. All existing 62 tests pass
6. ~23 new tests pass
7. `reprompt --help` shows 23 visible commands (down from 27)
