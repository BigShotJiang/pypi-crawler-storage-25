#!/bin/bash
# reprompt icon generator — produces all standard sizes from SVG sources
# Requires: rsvg-convert (from librsvg, brew install librsvg)
set -euo pipefail
cd "$(dirname "$0")"

SIZES=(512 256 128 96 48 32 16)

echo "Generating production PNGs..."

# Full icon sets at all sizes
for icon in brand-icon cli-icon; do
  for size in "${SIZES[@]}"; do
    rsvg-convert -w "$size" -h "$size" "${icon}.svg" -o "${icon}-${size}.png"
    echo "  ${icon}-${size}.png"
  done
done

# Simplified favicons (optimized for small sizes)
for icon in favicon cli-favicon; do
  for size in "${SIZES[@]}"; do
    rsvg-convert -w "$size" -h "$size" "${icon}.svg" -o "${icon}-${size}.png"
    echo "  ${icon}-${size}.png"
  done
done

echo ""
echo "Generated $(ls -1 *.png 2>/dev/null | wc -l | tr -d ' ') PNG files."
echo ""
echo "Icon selection guide:"
echo ""
echo "  BRAND (rP on red gradient):"
echo "    Chrome Extension store:  brand-icon-128.png"
echo "    PyPI / GitHub / npm:     brand-icon-512.png or brand-icon-128.png"
echo "    macOS/iOS (maskable):    brand-icon-512.png (platform applies mask)"
echo "    Browser toolbar (48px):  brand-icon-48.png"
echo "    Browser tab (≤32px):     favicon-32.png or favicon-16.png (bold P)"
echo ""
echo "  CLI (>r: on dark):"
echo "    CLI package icon:        cli-icon-512.png or cli-icon-128.png"
echo "    Terminal/toolbar (48px): cli-icon-48.png"
echo "    Browser tab (≤32px):     cli-favicon-32.png (bold r:)"
echo ""
echo "  Social sharing:            Use logo SVGs from docs/ (1200x630)"
