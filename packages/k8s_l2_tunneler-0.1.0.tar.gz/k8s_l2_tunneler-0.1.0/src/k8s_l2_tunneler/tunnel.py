"""tunnel.py — high-level tunnel lifecycle orchestration.

Three public functions: connect_cluster, connect_cni, clean.
Each builds a cleanup stack that is unwound LIFO on any exception.

NAT traversal
─────────────
When behind_nat=True is passed, both connect_cluster and connect_cni perform
UDP hole punching instead of connecting directly to the NodePort:

  socat mode  — developer starts a UDP socat server on NAT_HOLE_PUNCH_PORT;
                pod reads /tmp/dev_endpoint and connects outbound, punching
                the NAT.  No separate probe or port-sharing needed.

  vxlan-wg mode — developer's WG listens; pod's WG is told to initiate TO the
                  developer's IP:port; the resulting outbound handshake punches
                  the NAT hole; developer's WG learns the pod endpoint from the
                  first authenticated packet it receives.

If the NAT is symmetric (different external port per destination) or the pod
cannot reach the developer's IP, a NatHolePunchError is raised with a
descriptive message so the user knows what to do next.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Dict, Optional

from kubernetes import client as k8s_client

from k8s_l2_tunneler import k8s_ops, net_ops
from k8s_l2_tunneler.config import (
    NAT_HOLE_PUNCH_PORT,
    POD_INTERNAL_PORT,
    WG_DEV_LISTEN_PORT,
    AlreadyExistsError,
    DonorIdentity,
    LocalState,
    NatHolePunchError,
    TunnelIDs,
    TunnelType,
)
from k8s_l2_tunneler.naming import derive_cluster_ids, derive_cni_ids

# ── connect-to-cluster ────────────────────────────────────────────────────────


def connect_cluster(
    v1: k8s_client.CoreV1Api,
    apps: k8s_client.AppsV1Api,
    custom: k8s_client.CustomObjectsApi,
    namespace: str,
    owner: str,
    mtu: int,
    local_iface_name: Optional[str],
    tunnel_type: TunnelType,
    wg_subnet: str,
    tunnel_image: str,
    node_selector: Optional[Dict[str, str]],
    behind_nat: bool = False,
    dev_ip: Optional[str] = None,
    nat_ip: Optional[str] = None,
) -> None:
    """Create tunnel pod + donor pod + NAD. Steal donor's default-iface identity.

    Args:
        behind_nat: When True, perform UDP NAT hole punching instead of
                    connecting directly to the node's external IP.
        dev_ip:     IP of the developer machine as reachable FROM the pod.
                    Auto-detected when None (requires ``ip route get`` to work).
        nat_ip:     Public IP of the cluster-side NAT.  Auto-extracted from the
                    active kubeconfig server URL when None.
    """
    ids = derive_cluster_ids(namespace, owner, local_iface_name)

    if k8s_ops.cluster_tunnel_exists(v1, owner):
        raise AlreadyExistsError(
            f"A cluster tunnel for owner {owner!r} already exists. Run 'clean' first."
        )

    cni = k8s_ops.detect_cni(apps)
    is_calico = cni == "calico"
    is_harvester = k8s_ops.detect_harvester(custom)
    nat_tag = " [NAT mode]" if behind_nat else ""
    print(
        f"[cluster] owner={owner} namespace={namespace} cni={cni} "
        f"harvester={is_harvester} tunnel={tunnel_type} mtu={mtu}{nat_tag}"
    )

    # ── NAT pre-flight ────────────────────────────────────────────────────────
    if behind_nat:
        nat_ip = _resolve_nat_ip(nat_ip)
        dev_ip = _resolve_dev_ip(dev_ip, nat_ip)
        print(f"  [NAT] NAT public IP : {nat_ip}")
        print(f"  [NAT] Developer IP  : {dev_ip}")

    cleanup: list[Callable[[], None]] = []

    try:
        print("[1/7] Namespace...")
        k8s_ops.ensure_namespace(v1, namespace)

        if is_harvester:
            print("[2/7] Harvester ClusterNetwork...")
            k8s_ops.create_harvester_cluster_network(custom, ids)
            cleanup.append(lambda: k8s_ops.delete_harvester_cluster_network(custom, ids))
        else:
            print("[2/7] (skipping Harvester ClusterNetwork)")

        print("[3/7] NAD...")
        k8s_ops.create_nad(custom, ids, mtu)
        cleanup.append(lambda: k8s_ops.delete_nad(custom, ids))

        print("[4/7] Tunnel pod...")
        k8s_ops.create_tunnel_pod_cluster(
            v1,
            ids,
            port=POD_INTERNAL_PORT,
            mtu=mtu,
            tunnel_type=tunnel_type,
            wg_subnet=wg_subnet,
            node_selector=node_selector,
            tunnel_image=tunnel_image,
            behind_nat=behind_nat,
        )
        cleanup.append(lambda: k8s_ops.delete_pod(v1, namespace, ids.tunnel_pod_name))

        print("[5/7] Waiting for tunnel pod scheduling...")
        node_name = k8s_ops.wait_for_pod_scheduled(v1, namespace, ids.tunnel_pod_name)

        print(f"[5/7] Donor pod → node {node_name}...")
        k8s_ops.create_donor_pod(v1, ids, mtu, node_name, tunnel_image)
        cleanup.append(lambda: k8s_ops.delete_pod(v1, namespace, ids.donor_pod_name))  # type: ignore[arg-type]

        print("[6/7] Service...")
        k8s_ops.create_service(v1, ids, tunnel_type=tunnel_type)
        cleanup.append(lambda: k8s_ops.delete_service(v1, namespace, ids.service_name))

        print("[6/7] Waiting for pods ready...")
        # node_ip is the internal node IP (useless in NAT mode, but still returned).
        node_ip = k8s_ops.wait_for_pod_ready(v1, namespace, ids.donor_pod_name)  # type: ignore[arg-type]

        print("[7/7] Reading donor identity...")
        donor_iface = k8s_ops.discover_donor_iface(v1, namespace, ids.donor_pod_name)  # type: ignore[arg-type]
        identity = k8s_ops.read_pod_identity(v1, namespace, ids.donor_pod_name, donor_iface)  # type: ignore[arg-type]
        print(f"      ip={identity.pod_ip} mac={identity.pod_mac} iface={identity.iface}")

        k8s_ops.signal_proceed(v1, namespace, ids.donor_pod_name)  # type: ignore[arg-type]
        k8s_ops.wait_for_done(v1, namespace, ids.donor_pod_name)  # type: ignore[arg-type]

        # ── Tunnel setup (direct or NAT) ──────────────────────────────────────
        if tunnel_type == TunnelType.SOCAT:
            if behind_nat:
                assert dev_ip
                print("[7/7] NAT socat setup (pod connects outbound to developer)...")
                # Must ensure the tunnel pod container is running (phase=Running)
                # before exec-ing dev_endpoint into it.  We cannot call
                # wait_for_pod_ready here because /tmp/ready is set only AFTER
                # the pod receives dev_endpoint — calling it would deadlock.
                k8s_ops.wait_for_pod_running(v1, namespace, ids.tunnel_pod_name)
                socat_pid = _setup_socat_nat(v1, ids, namespace, dev_ip)
            else:
                print("[7/7] Starting local socat + TAP...")
                socat_pid = net_ops.start_socat(ids, node_ip)

            cleanup.append(lambda: net_ops.stop_socat(socat_pid))
            net_ops.wait_for_tap(ids.local_tap_name)
            net_ops.configure_tap(ids.local_tap_name, identity, is_calico=is_calico, mtu=mtu)
            garp_mac = (
                identity.pod_mac if not is_calico else net_ops.get_tap_mac(ids.local_tap_name)
            )
            net_ops.send_gratuitous_arp(ids.local_tap_name, identity.pod_ip, garp_mac)
            net_ops.save_state(
                LocalState(
                    tid=ids.tid,
                    tunnel_type=TunnelType.SOCAT,
                    local_tap=ids.local_tap_name,
                    socat_pid=socat_pid,
                )
            )
        else:  # VXLAN_WG
            if behind_nat:
                assert dev_ip
                print("[7/7] WireGuard NAT key exchange + VXLAN setup...")
                wg_iface = _setup_wg_nat(v1, ids, namespace, dev_ip, wg_subnet)
            else:
                print("[7/7] WireGuard key exchange + VXLAN setup...")
                dev_priv, dev_pub = net_ops.generate_wg_keypair()
                pod_pub = k8s_ops.read_wg_pubkey(v1, namespace, ids.tunnel_pod_name)
                k8s_ops.write_dev_pubkey(v1, namespace, ids.tunnel_pod_name, dev_pub)
                wg_iface = net_ops.start_wg_vxlan(ids, node_ip, pod_pub, dev_priv, wg_subnet)

            cleanup.append(lambda: net_ops.stop_wg_vxlan(wg_iface, ids.local_tap_name))
            net_ops.wait_for_tap(ids.local_tap_name)
            net_ops.configure_tap(ids.local_tap_name, identity, is_calico=is_calico, mtu=mtu)
            garp_mac = (
                identity.pod_mac if not is_calico else net_ops.get_tap_mac(ids.local_tap_name)
            )
            net_ops.send_gratuitous_arp(ids.local_tap_name, identity.pod_ip, garp_mac)
            net_ops.save_state(
                LocalState(
                    tid=ids.tid,
                    tunnel_type=TunnelType.VXLAN_WG,
                    local_tap=ids.local_tap_name,
                    wg_iface=wg_iface,
                )
            )

    except NatHolePunchError:
        # _run_cleanup(cleanup)
        raise
    except Exception:
        # _run_cleanup(cleanup)  # uncomment to auto-cleanup on other errors
        raise

    display_ip = nat_ip or node_ip
    _print_success_cluster(ids, identity, display_ip, is_calico, mtu, tunnel_type, behind_nat)


# ── connect-to-cni ────────────────────────────────────────────────────────────


def connect_cni(
    v1: k8s_client.CoreV1Api,
    apps: k8s_client.AppsV1Api,
    custom: k8s_client.CustomObjectsApi,
    namespace: str,
    owner: str,
    cni_name: str,
    cni_ns: str,
    mtu: int,
    local_iface_name: Optional[str],
    tunnel_type: TunnelType,
    wg_subnet: str,
    tunnel_image: str,
    node_selector: Optional[Dict[str, str]],
    behind_nat: bool = False,
    dev_ip: Optional[str] = None,
    nat_ip: Optional[str] = None,
) -> None:
    """Single tunnel pod annotated with an existing CNI NAD. No donor pod needed."""
    ids = derive_cni_ids(namespace, owner, cni_name, cni_ns, local_iface_name)

    if k8s_ops.cni_tunnel_exists(v1, ids):
        raise AlreadyExistsError(
            f"CNI tunnel for owner={owner!r} cni={cni_name!r} already exists. Run 'clean' first."
        )

    cni = k8s_ops.detect_cni(apps)
    is_calico = cni == "calico"
    nat_tag = " [NAT mode]" if behind_nat else ""
    print(
        f"[cni] owner={owner} namespace={namespace} cni-nad={cni_name} "
        f"cni-namespace={cni_ns} detected-cni={cni} tunnel={tunnel_type} "
        f"mtu={mtu}{nat_tag}"
    )

    if behind_nat:
        nat_ip = _resolve_nat_ip(nat_ip)
        dev_ip = _resolve_dev_ip(dev_ip, nat_ip)
        print(f"  [NAT] NAT public IP : {nat_ip}")
        print(f"  [NAT] Developer IP  : {dev_ip}")

    cleanup: list[Callable[[], None]] = []

    try:
        print("[1/5] Namespace...")
        k8s_ops.ensure_namespace(v1, namespace)

        print("[2/5] Tunnel pod...")
        k8s_ops.create_tunnel_pod_cni(
            v1,
            ids,
            port=POD_INTERNAL_PORT,
            mtu=mtu,
            existing_cni_nad=cni_name,
            existing_cni_ns=cni_ns,
            tunnel_type=tunnel_type,
            tunnel_image=tunnel_image,
            wg_subnet=wg_subnet,
            node_selector=node_selector,
            behind_nat=behind_nat,
        )
        cleanup.append(lambda: k8s_ops.delete_pod(v1, namespace, ids.tunnel_pod_name))

        print("[3/5] Service...")
        k8s_ops.create_service(v1, ids, tunnel_type=tunnel_type)
        cleanup.append(lambda: k8s_ops.delete_service(v1, namespace, ids.service_name))

        print("[4/5] Waiting for tunnel pod ready...")
        node_ip = k8s_ops.wait_for_pod_ready(v1, namespace, ids.tunnel_pod_name)

        print("[5/5] Reading net1 identity...")
        identity = k8s_ops.read_pod_identity(v1, namespace, ids.tunnel_pod_name, "net1")
        print(f"      ip={identity.pod_ip} mac={identity.pod_mac}")

        k8s_ops.signal_proceed(v1, namespace, ids.tunnel_pod_name)
        k8s_ops.wait_for_done(v1, namespace, ids.tunnel_pod_name)

        if tunnel_type == TunnelType.SOCAT:
            if behind_nat:
                assert dev_ip
                print("[5/5] NAT socat setup (pod connects outbound to developer)...")
                # wait_for_done already guarantees socat is ready (it runs as
                # part of the 'proceed' phase in the CNI script), so no extra
                # wait_for_pod_running is needed here.
                socat_pid = _setup_socat_nat(v1, ids, namespace, dev_ip)
            else:
                print("[5/5] Starting local socat + TAP...")
                socat_pid = net_ops.start_socat(ids, node_ip)

            cleanup.append(lambda: net_ops.stop_socat(socat_pid))
            net_ops.wait_for_tap(ids.local_tap_name)
            net_ops.configure_tap(ids.local_tap_name, identity, is_calico=is_calico, mtu=mtu)
            garp_mac = (
                identity.pod_mac if not is_calico else net_ops.get_tap_mac(ids.local_tap_name)
            )
            net_ops.send_gratuitous_arp(ids.local_tap_name, identity.pod_ip, garp_mac)
            net_ops.save_state(
                LocalState(
                    tid=ids.tid,
                    tunnel_type=TunnelType.SOCAT,
                    local_tap=ids.local_tap_name,
                    socat_pid=socat_pid,
                )
            )
        else:  # VXLAN_WG
            if behind_nat:
                assert dev_ip
                print("[5/5] WireGuard NAT key exchange + VXLAN setup...")
                wg_iface = _setup_wg_nat(v1, ids, namespace, dev_ip, wg_subnet)
            else:
                print("[5/5] WireGuard key exchange + VXLAN setup...")
                dev_priv, dev_pub = net_ops.generate_wg_keypair()
                pod_pub = k8s_ops.read_wg_pubkey(v1, namespace, ids.tunnel_pod_name)
                k8s_ops.write_dev_pubkey(v1, namespace, ids.tunnel_pod_name, dev_pub)
                wg_iface = net_ops.start_wg_vxlan(ids, node_ip, pod_pub, dev_priv, wg_subnet)

            cleanup.append(lambda: net_ops.stop_wg_vxlan(wg_iface, ids.local_tap_name))
            net_ops.wait_for_tap(ids.local_tap_name)
            net_ops.configure_tap(ids.local_tap_name, identity, is_calico=is_calico, mtu=mtu)
            garp_mac = (
                identity.pod_mac if not is_calico else net_ops.get_tap_mac(ids.local_tap_name)
            )
            net_ops.send_gratuitous_arp(ids.local_tap_name, identity.pod_ip, garp_mac)
            net_ops.save_state(
                LocalState(
                    tid=ids.tid,
                    tunnel_type=TunnelType.VXLAN_WG,
                    local_tap=ids.local_tap_name,
                    wg_iface=wg_iface,
                )
            )

    except NatHolePunchError:
        _run_cleanup(cleanup)
        raise
    except Exception:
        _run_cleanup(cleanup)
        raise

    display_ip = nat_ip or node_ip
    _print_success_cni(ids, identity, display_ip, is_calico, mtu, cni_name, tunnel_type, behind_nat)


# ── clean ─────────────────────────────────────────────────────────────────────


def clean(
    v1: k8s_client.CoreV1Api,
    custom: k8s_client.CustomObjectsApi,
    owner: str,
) -> None:
    """Remove all k8s resources for an owner, then clean up local state.

    Harvester ClusterNetworks are detected automatically — no flag required.
    Waits until all resources are confirmed gone before reporting success.
    """
    is_harvester = k8s_ops.detect_harvester(custom)

    # ── Collect TIDs from k8s pods so we can clean local state ───────────────
    pods = k8s_ops.list_pods_by_owner(v1, owner)
    tids = {
        pod.metadata.labels.get("tunneler-tid")
        for pod in pods
        if pod.metadata and pod.metadata.labels
    }
    tids.discard(None)

    # ── Stop local tunnel processes + remove local interfaces ─────────────────
    for tid in tids:
        state = net_ops.load_state(tid)
        if state:
            if state.tunnel_type == TunnelType.SOCAT and state.socat_pid is not None:
                net_ops.stop_socat(state.socat_pid)
                net_ops.remove_tap(state.local_tap)
            elif state.tunnel_type == TunnelType.VXLAN_WG and state.wg_iface is not None:
                net_ops.stop_wg_vxlan(state.wg_iface, state.local_tap)
            else:
                net_ops.remove_tap(state.local_tap)
            net_ops.remove_state(state.tid)

    # ── Delete k8s pods ───────────────────────────────────────────────────────
    for pod in pods:
        if pod.metadata and pod.metadata.name and pod.metadata.namespace:
            k8s_ops.delete_pod(v1, pod.metadata.namespace, pod.metadata.name)

    # ── Delete services ───────────────────────────────────────────────────────
    for svc in k8s_ops.list_services_by_owner(v1, owner):
        if svc.metadata and svc.metadata.name and svc.metadata.namespace:
            k8s_ops.delete_service(v1, svc.metadata.namespace, svc.metadata.name)

    # ── Delete NADs ───────────────────────────────────────────────────────────
    for nad in k8s_ops.list_nads_by_owner(custom, owner):
        meta = nad.get("metadata", {})
        name, ns = meta.get("name"), meta.get("namespace")
        if name and ns:
            k8s_ops.delete_custom_namespaced(
                custom,
                k8s_ops._NAD_GROUP,
                k8s_ops._NAD_VERSION,
                k8s_ops._NAD_PLURAL,
                ns,
                name,
            )

    # ── Delete Harvester ClusterNetworks ──────────────────────────────────────
    if is_harvester:
        # Harvester ClusterNetworks has a strict webhook that forces the NAD deletion
        # before the ClusterNetwork deletion.
        print(
            "Detected Harvester, waiting for NADs to be deleted before deleting ClusterNetworks..."
        )
        k8s_ops.wait_for_nad_gone(v1, custom, owner)
        for cn in k8s_ops.list_cluster_networks_by_owner(custom, owner):
            name = cn.get("metadata", {}).get("name")
            if name:
                k8s_ops.delete_custom_cluster(
                    custom,
                    k8s_ops._HCN_GROUP,
                    k8s_ops._HCN_VERSION,
                    k8s_ops._HCN_PLURAL,
                    name,
                )

    print("Waiting for resources to be deleted...")
    k8s_ops.wait_for_owner_resources_gone(v1, custom, owner, is_harvester)
    print(f"✅  Cleaned all resources for owner={owner!r}.")


# ── NAT helpers ───────────────────────────────────────────────────────────────


def _resolve_nat_ip(nat_ip: Optional[str]) -> str:
    """Return nat_ip if given, otherwise extract it from the active kubeconfig."""
    if nat_ip:
        return nat_ip
    detected = k8s_ops.get_nat_ip_from_config()
    if not detected:
        raise NatHolePunchError(
            "Cannot auto-detect NAT public IP from kubeconfig.\n"
            "Pass --nat-ip <PUBLIC_IP> explicitly."
        )
    return detected


def _resolve_dev_ip(dev_ip: Optional[str], nat_ip: str) -> str:
    """Return dev_ip if given, otherwise detect it via 'ip route get'."""
    if dev_ip:
        return dev_ip
    try:
        return net_ops.get_local_ip_toward(nat_ip)
    except Exception as exc:
        raise NatHolePunchError(
            f"Cannot auto-detect developer machine IP (tried routing toward {nat_ip}): {exc}\n"
            "Pass --dev-ip <YOUR_IP> explicitly."
        ) from exc


def _setup_socat_nat(
    v1: k8s_client.CoreV1Api,
    ids: TunnelIDs,
    namespace: str,
    dev_ip: str,
) -> int:
    """Set up socat for NAT-traversal mode. Returns the socat PID.

    Protocol
    ────────
    The developer machine acts as the UDP *server*; the pod acts as the UDP
    *client*.  This flips the normal socat model and is the key to avoiding
    both the NodePort direct-route requirement and the port-reuse conflict that
    would occur if we tried to send a probe from the pod's already-bound
    socat port (51820).

    1. Start developer socat listener on NAT_HOLE_PUNCH_PORT (4500) FIRST —
       before writing the endpoint to the pod — so it is ready to accept the
       pod's first packet.
    2. Write /tmp/dev_endpoint to the pod (dev_ip:NAT_HOLE_PUNCH_PORT).
    3. Pod reads the endpoint, starts socat outbound to dev_ip:4500.
    4. The outbound connection punches the cluster NAT:
         pod_ip:ephemeral → NAT → NAT_ext:X → dev_ip:4500
    5. Developer socat receives the pod's first packet; from that point
       each side sends UDP to the other's observed address and the tunnel flows.
    6. wait_for_tap() called by the caller (tunnel.py) detects the TAP creation.

    Note: NAT_HOLE_PUNCH_PORT (4500) is not the same as the pod's socat port
    (51820).  Traffic flows symmetrically: dev→pod uses the NAT mapping, pod→dev
    uses the direct route that the pod already has to the developer's IP.
    """
    print(
        f"  [NAT] Starting developer socat listener on UDP {NAT_HOLE_PUNCH_PORT}. "
        "Ensure this port is open in your local firewall."
    )
    socat_pid = net_ops.start_socat_nat_listener(ids, NAT_HOLE_PUNCH_PORT)

    print(f"  [NAT] Writing dev endpoint ({dev_ip}:{NAT_HOLE_PUNCH_PORT}) to pod...")
    k8s_ops.write_dev_endpoint(v1, namespace, ids.tunnel_pod_name, dev_ip, NAT_HOLE_PUNCH_PORT)

    return socat_pid


def _setup_wg_nat(
    v1: k8s_client.CoreV1Api,
    ids: TunnelIDs,
    namespace: str,
    dev_ip: str,
    wg_subnet: str,
) -> str:
    """Set up WireGuard for NAT-traversal mode. Returns the WG interface name.

    Protocol
    ────────
    1. Developer generates a WG keypair and creates a WG interface that
       LISTENS on WG_DEV_LISTEN_PORT (no peer endpoint configured yet).
    2. Developer writes its public key to the pod (existing mechanism).
    3. Developer also writes dev_ip:WG_DEV_LISTEN_PORT to /tmp/dev_endpoint.
    4. Pod's WG reads dev_endpoint and configures the peer WITH that endpoint,
       then sends a WG handshake initiation to dev_ip:WG_DEV_LISTEN_PORT.
    5. The cluster NAT creates a binding: NAT_IP:X → pod:POD_INTERNAL_PORT.
    6. Developer's WG receives and authenticates the handshake via the known
       pod public key; it learns the peer endpoint from the source address.
    7. Developer's persistent-keepalive=25 keeps the NAT hole alive.
    8. wait_for_wg_handshake() blocks until WG reports a completed handshake.
    """
    dev_priv, dev_pub = net_ops.generate_wg_keypair()

    # Read pod pubkey first (pod writes it synchronously during init).
    pod_pub = k8s_ops.read_wg_pubkey(v1, namespace, ids.tunnel_pod_name)

    # Create developer WG interface — listening, no endpoint for the pod peer.
    wg_iface = net_ops.start_wg_vxlan_nat(
        ids,
        pod_wg_pubkey=pod_pub,
        dev_wg_privkey=dev_priv,
        wg_subnet=wg_subnet,
        dev_wg_listen_port=WG_DEV_LISTEN_PORT,
    )

    # Tell the pod who to connect to.  The pod script checks for /tmp/dev_endpoint
    # and, if present, adds the endpoint to the wg peer config.
    k8s_ops.write_dev_pubkey(v1, namespace, ids.tunnel_pod_name, dev_pub)
    k8s_ops.write_dev_endpoint(v1, namespace, ids.tunnel_pod_name, dev_ip, WG_DEV_LISTEN_PORT)

    # Block until the pod's WG handshake reaches the developer.
    net_ops.wait_for_wg_handshake(wg_iface)

    return wg_iface


# ── Generic helpers ───────────────────────────────────────────────────────────


def _run_cleanup(stack: list[Callable[[], None]]) -> None:
    for fn in reversed(stack):
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"  [warn] cleanup step failed: {exc}")


def _print_success_cluster(
    ids: TunnelIDs,
    identity: DonorIdentity,
    display_ip: str,
    is_calico: bool,
    mtu: int,
    tunnel_type: TunnelType,
    behind_nat: bool,
) -> None:
    mac_note = "own random MAC (Calico)" if is_calico else identity.pod_mac
    nat_note = f"   NAT  hole-punched via {display_ip} (UDP)\n" if behind_nat else ""
    print(
        f"\n✅  Cluster tunnel ready ({tunnel_type}"
        + (" + NAT traversal" if behind_nat else "")
        + ").\n"
        f"   TAP  {ids.local_tap_name}  {identity.pod_ip}/{identity.prefix}\n"
        f"   MAC  {mac_note}\n"
        f"{nat_note}"
        f"   MTU  {mtu}\n"
        f"\n   ping {identity.pod_ip}\n"
        f"   k8s-l2-tunneler clean --owner {ids.owner}  (to tear down)\n"
    )


def _print_success_cni(
    ids: TunnelIDs,
    identity: DonorIdentity,
    display_ip: str,
    is_calico: bool,
    mtu: int,
    cni_name: str,
    tunnel_type: TunnelType,
    behind_nat: bool,
) -> None:
    mac_note = "own random MAC (Calico)" if is_calico else identity.pod_mac
    nat_note = f"   NAT  hole-punched via {display_ip} (UDP)\n" if behind_nat else ""
    print(
        f"\n✅  CNI tunnel ready ({cni_name}, {tunnel_type}"
        + (" + NAT traversal" if behind_nat else "")
        + ").\n"
        f"   TAP  {ids.local_tap_name}  {identity.pod_ip}/{identity.prefix}\n"
        f"   MAC  {mac_note}\n"
        f"{nat_note}"
        f"   MTU  {mtu}\n"
        f"\n   ping {identity.pod_ip}\n"
        f"   k8s-l2-tunneler clean --owner {ids.owner}  (tears down all tunnels for this owner)\n"
    )
