"""net_ops.py — local OS and network operations.

All `ip` commands run with sudo (CAP_NET_ADMIN required). No Kubernetes calls.
MTU is passed as a parameter rather than read from a global constant.
Local state is persisted in ~/.k8s-l2-tunneler/ rather than /tmp.

NAT traversal additions
───────────────────────
get_local_ip_toward()        — detect the dev machine's IP facing the cluster
start_socat_nat_listener()   — start developer-side socat server for NAT socat mode
                               (pod connects outbound, punching the NAT hole)
start_wg_vxlan_nat()         — WireGuard variant where developer listens and pod initiates
wait_for_wg_handshake()      — blocks until wg reports a successful handshake
"""

from __future__ import annotations

import contextlib
import os
import pathlib
import re
import shutil
import signal
import socket
import struct
import subprocess
import time
from typing import Literal, Optional, Tuple

from k8s_l2_tunneler.config import (
    LOCAL_TAP_APPEAR_TIMEOUT,
    STATE_DIR,
    WG_DEV_CLIENT_ID,
    WG_DEV_LISTEN_PORT,
    WG_HANDSHAKE_TIMEOUT,
    WG_POD_CLIENT_ID,
    DonorIdentity,
    LocalState,
    NatHolePunchError,
    RouteAlreadyInUseError,
    SetupError,
    TunnelIDs,
)

# ── Helpers ───────────────────────────────────────────────────────────────────


def _run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(list(args), capture_output=True, text=True, check=check)


def _ip(*args: str) -> None:
    _run("sudo", "ip", *args)


# ── Tool availability ─────────────────────────────────────────────────────────


def check_socat_installed() -> bool:
    """Return True if socat is available on PATH."""
    return shutil.which("socat") is not None


def check_wg_installed() -> bool:
    """Return True if wg (wireguard-tools) is available on PATH."""
    return shutil.which("wg") is not None


# ── Local state ───────────────────────────────────────────────────────────────


def _state_path(tid: str) -> pathlib.Path:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    return STATE_DIR / f"{tid}.json"


def save_state(state: LocalState) -> None:
    pathlib.Path(_state_path(state.tid)).write_text(state.to_json())


def load_state(tid: str) -> Optional[LocalState]:
    try:
        return LocalState.from_json(pathlib.Path(_state_path(tid)).read_text())
    except (FileNotFoundError, KeyError, TypeError, ValueError):
        return None


def remove_state(tid: str) -> None:
    _state_path(tid).unlink(missing_ok=True)


# ── socat process ─────────────────────────────────────────────────────────────


def _is_socat_process(pid: int) -> bool:
    """Return True if the process at pid has 'socat' in its command line."""
    try:
        cmdline = pathlib.Path(f"/proc/{pid}/cmdline").read_bytes()
        return b"socat" in cmdline
    except (FileNotFoundError, PermissionError, OSError):
        return False


def start_socat(ids: TunnelIDs, node_ip: str) -> int:
    """Spawn background socat for direct (non-NAT) mode, returns PID.

    New session so Ctrl-C won't kill it.
    """
    cmd = [
        "socat",
        f"TUN:169.254.0.1/30,tun-type=tap,tun-name={ids.local_tap_name},iff-up,iff-no-pi",
        f"UDP:{node_ip}:{ids.node_port}",
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return proc.pid


def start_socat_nat_listener(ids: TunnelIDs, listen_port: int) -> int:
    """Spawn a background socat TAP server listening on *listen_port* (UDP).

    NAT-traversal socat mode: the DEVELOPER machine is the UDP server and the
    TUNNEL POD is the UDP client (connects outbound, punching the cluster NAT).

    Developer listens:  socat TUN:... UDP4-LISTEN:<listen_port>,reuseaddr
    Pod connects out:   socat TUN:... UDP:<dev_ip>:<listen_port>

    The pod's outbound connection creates a NAT conntrack entry whose reverse
    path allows the developer's socat replies to reach the pod.  No separate
    NAT probe is needed, and there is no conflict with the pod's existing socat
    listener port.

    Returns the PID of the socat process.
    """
    cmd = [
        "socat",
        f"TUN:169.254.0.1/30,tun-type=tap,tun-name={ids.local_tap_name},iff-up,iff-no-pi",
        f"UDP4-LISTEN:{listen_port},reuseaddr",
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    return proc.pid


def stop_socat(pid: int) -> None:
    """Send SIGTERM to a socat process after verifying it is actually socat."""
    if not _is_socat_process(pid):
        print(f"  [warn] PID {pid} is not a socat process — skipping kill.")
        return
    with contextlib.suppress(ProcessLookupError):
        os.kill(pid, signal.SIGTERM)


# ── WireGuard + VXLAN tunnel (direct mode) ───────────────────────────────────


def generate_wg_keypair() -> Tuple[str, str]:
    """Generate a WireGuard keypair. Returns (private_key, public_key)."""
    priv = _run("wg", "genkey").stdout.strip()
    pub = subprocess.run(
        ["wg", "pubkey"],
        input=priv,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    return priv, pub


def start_wg_vxlan(
    ids: TunnelIDs,
    node_ip: str,
    pod_wg_pubkey: str,
    dev_wg_privkey: str,
    wg_subnet: str,
) -> str:
    """Set up local WireGuard + VXLAN interfaces for direct (non-NAT) mode.

    Developer's WG acts as the client and points its endpoint at the NodePort.
    Returns the WireGuard interface name.
    """
    wg_iface = f"wg-{ids.tid[:8]}"
    vxlan_iface = ids.local_tap_name

    priv_file = f"/tmp/.wg-priv-{ids.tid[:8]}"
    try:
        pathlib.Path(priv_file).write_text(dev_wg_privkey)
        pathlib.Path(priv_file).chmod(0o600)

        _ip("link", "add", wg_iface, "type", "wireguard")
        _run(
            "sudo",
            "wg",
            "set",
            wg_iface,
            "private-key",
            priv_file,
            "peer",
            pod_wg_pubkey,
            "allowed-ips",
            "0.0.0.0/0",
            "endpoint",
            f"{node_ip}:{ids.node_port}",
        )
    finally:
        pathlib.Path(priv_file).unlink(missing_ok=True)

    _ip("addr", "add", populate_subnet_ip(wg_subnet, WG_DEV_CLIENT_ID), "dev", wg_iface)
    _ip("link", "set", wg_iface, "up")

    # VXLAN unicast over WireGuard — remote is the pod's WireGuard IP
    _ip(
        "link",
        "add",
        vxlan_iface,
        "type",
        "vxlan",
        "id",
        str(ids.vxlan_id),
        "remote",
        construct_ip_from_subnet(wg_subnet, WG_POD_CLIENT_ID),
        "dstport",
        "4789",
        "dev",
        wg_iface,
    )
    _ip("link", "set", vxlan_iface, "up")

    return wg_iface


def start_wg_vxlan_nat(
    ids: TunnelIDs,
    pod_wg_pubkey: str,
    dev_wg_privkey: str,
    wg_subnet: str,
    dev_wg_listen_port: int = WG_DEV_LISTEN_PORT,
) -> str:
    """Set up local WireGuard + VXLAN interfaces for NAT-traversal mode.

    In NAT mode the developer's WG is a *server* (listening on dev_wg_listen_port
    with NO endpoint configured for the pod peer).  The pod's WG, after
    receiving the developer's public key AND the endpoint hint written by the
    orchestrator to /tmp/dev_endpoint, initiates the handshake outbound through
    the NAT.  The NAT creates a binding, the developer's WG receives the
    handshake, authenticates it via the known pod public key, and replies.
    WireGuard then learns the peer endpoint dynamically from the source of the
    first valid authenticated packet.

    A persistent-keepalive of 25 s is set so the NAT binding is refreshed
    continuously while the tunnel is active.

    Returns the WireGuard interface name.
    """
    wg_iface = f"wg-{ids.tid[:8]}"
    vxlan_iface = ids.local_tap_name

    priv_file = f"/tmp/.wg-priv-{ids.tid[:8]}"
    try:
        pathlib.Path(priv_file).write_text(dev_wg_privkey)
        pathlib.Path(priv_file).chmod(0o600)

        _ip("link", "add", wg_iface, "type", "wireguard")
        # No endpoint — developer listens, pod initiates.
        # persistent-keepalive keeps the NAT hole open.
        _run(
            "sudo",
            "wg",
            "set",
            wg_iface,
            "private-key",
            priv_file,
            "listen-port",
            str(dev_wg_listen_port),
            "peer",
            pod_wg_pubkey,
            "allowed-ips",
            "0.0.0.0/0",
            "persistent-keepalive",
            "25",
        )
    finally:
        pathlib.Path(priv_file).unlink(missing_ok=True)

    _ip("addr", "add", populate_subnet_ip(wg_subnet, WG_DEV_CLIENT_ID), "dev", wg_iface)
    _ip("link", "set", wg_iface, "up")

    # VXLAN unicast over WireGuard — remote is the pod's WireGuard IP.
    # This is identical to direct mode; the WG tunnel itself handles NAT.
    _ip(
        "link",
        "add",
        vxlan_iface,
        "type",
        "vxlan",
        "id",
        str(ids.vxlan_id),
        "remote",
        construct_ip_from_subnet(wg_subnet, WG_POD_CLIENT_ID),
        "dstport",
        "4789",
        "dev",
        wg_iface,
    )
    _ip("link", "set", vxlan_iface, "up")

    return wg_iface


def wait_for_wg_handshake(
    wg_iface: str,
    timeout: int = WG_HANDSHAKE_TIMEOUT,
) -> None:
    """Block until `wg show` reports a latest-handshake for wg_iface.

    Used in NAT mode to confirm that the pod successfully reached the developer
    machine through the NAT and completed a WireGuard handshake.

    Raises NatHolePunchError with a diagnostic message if the handshake does
    not complete within *timeout* seconds.
    """
    print(
        f"  [NAT] Waiting up to {timeout}s for WireGuard handshake (pod initiates through NAT)..."
    )
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        result = _run("sudo", "wg", "show", wg_iface, check=False)
        if "latest handshake" in result.stdout:
            print("  [NAT] WireGuard handshake complete — NAT hole punched successfully.")
            return
        time.sleep(1)

    raise NatHolePunchError(
        f"NAT hole punching failed: the WireGuard handshake did not complete within {timeout}s.\n"
        "\n"
        "Possible causes:\n"
        "  • The cluster NAT uses symmetric port mapping — each outbound UDP\n"
        "    destination gets a different external port, so the developer cannot\n"
        "    predict which port to accept traffic from.  Symmetric NATs cannot be\n"
        "    punched with this technique.\n"
        "  • A firewall on your developer machine is blocking UDP on port\n"
        f"    {WG_DEV_LISTEN_PORT} (the WireGuard listen port).\n"
        "  • The pod cannot route packets to your developer machine's IP.\n"
        "\n"
        "Remediation options:\n"
        "  • Expose a UDP NodePort directly on your NAT device (port-forward\n"
        "    the tunnel NodePort) and run without --cluster-behind-nat.\n"
        "  • Check your local firewall: sudo ufw allow {WG_DEV_LISTEN_PORT}/udp\n"
        "  • Verify the pod can ping your machine: kubectl exec -n <ns> <pod> -- ping <dev-ip>"
    )


def stop_wg_vxlan(wg_iface: str, vxlan_iface: str) -> None:
    """Tear down local WireGuard and VXLAN interfaces."""
    for iface in (vxlan_iface, wg_iface):
        if _run("ip", "link", "show", iface, check=False).returncode == 0:
            try:
                _ip("link", "delete", iface)
            except subprocess.CalledProcessError as exc:
                print(f"  [warn] removing interface {iface!r}: {exc.stderr.strip()}")


# ── NAT traversal helpers ─────────────────────────────────────────────────────


def get_local_ip_toward(target_ip: str) -> str:
    """Return the local IP of the interface that the kernel would use to reach target_ip.

    Uses ``ip route get`` which honours the routing table including policy routes.
    Raises SetupError if the IP cannot be determined.
    """
    result = _run("ip", "route", "get", target_ip, check=False)
    if result.returncode != 0:
        raise SetupError(
            f"Cannot determine local IP toward {target_ip!r}: "
            f"'ip route get' failed: {result.stderr.strip()}"
        )
    tokens = result.stdout.split()
    try:
        src_idx = tokens.index("src")
        return tokens[src_idx + 1]
    except (ValueError, IndexError):
        raise SetupError(
            f"Cannot parse local IP from 'ip route get {target_ip}' output: "
            f"{result.stdout.strip()!r}"
        ) from None


# ── TAP / VXLAN interface lifecycle ───────────────────────────────────────────


def wait_for_tap(tap_name: str) -> None:
    deadline = time.monotonic() + LOCAL_TAP_APPEAR_TIMEOUT
    while time.monotonic() < deadline:
        if _run("ip", "link", "show", tap_name, check=False).returncode == 0:
            return
        time.sleep(0.2)
    raise SetupError(f"Interface {tap_name!r} did not appear within {LOCAL_TAP_APPEAR_TIMEOUT}s.")


def remove_tap(tap_name: str) -> None:
    if _run("ip", "link", "show", tap_name, check=False).returncode == 0:
        try:
            _ip("link", "delete", tap_name)
        except subprocess.CalledProcessError as exc:
            print(f"  [warn] removing interface {tap_name!r}: {exc.stderr.strip()}")


def is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


def assert_subnet_not_in_use(subnet: str) -> None:
    result = _run("ip", "-4", "route", check=False)
    if result.returncode != 0:
        raise SetupError(
            f"Cannot assert subnet not in use: 'ip route get' failed: {result.stderr.strip()}"
        )
    full_route_lines = result.stdout.splitlines()
    try:
        for route_line in full_route_lines:
            route_line_tokens = route_line.split()
            route_subnet = route_line_tokens[0]
            if route_subnet == subnet:
                used_by_iface = route_line_tokens[route_line_tokens.index("dev") + 1]
                raise RouteAlreadyInUseError(f"Route already in use by interface: {used_by_iface}")
    except (ValueError, IndexError):
        raise SetupError(
            f"Cannot parse output of 'ip -4 route' output: {result.stdout.strip()!r}"
        ) from None


# ── TAP / VXLAN configuration ─────────────────────────────────────────────────


def get_tap_mac(tap_name: str) -> str:
    """Return the hardware MAC address currently assigned to the interface."""
    result = _run("ip", "link", "show", tap_name)
    for token in result.stdout.split():
        if len(token) == 17 and token.count(":") == 5:
            return token
    raise SetupError(f"Could not read MAC from interface {tap_name!r}.")


def configure_tap(
    tap_name: str,
    identity: DonorIdentity,
    *,
    is_calico: bool,
    mtu: int,
) -> None:
    """Configure the local TAP/VXLAN interface with the stolen donor identity.

    On Calico we keep the interface's own random MAC and rely on promisc mode.
    On all other CNIs we apply the stolen donor MAC directly.
    """
    _ip("link", "set", tap_name, "down")
    _ip("link", "set", tap_name, "mtu", str(mtu))

    if not is_calico:
        _ip("link", "set", tap_name, "address", identity.pod_mac)

    _ip("addr", "flush", "dev", tap_name)
    _ip("addr", "add", f"{identity.pod_ip}/8", "dev", tap_name)
    _ip("link", "set", tap_name, "promisc", "on")
    _ip("link", "set", tap_name, "up")


# ── Gratuitous ARP ────────────────────────────────────────────────────────────


def send_gratuitous_arp(tap_name: str, ip_str: str, mac_str: str) -> None:
    """Broadcast 3 GARP frames from the local TAP via raw AF_PACKET socket.

    Flushes stale ARP caches on the cluster node and teaches the br-donor
    bridge the correct forwarding port for the stolen MAC.
    """
    try:
        mac_b = bytes.fromhex(mac_str.replace(":", ""))
        ip_b = socket.inet_aton(ip_str)
    except (ValueError, OSError) as exc:
        print(f"  [warn] GARP skipped: {exc}")
        return

    eth = b"\xff\xff\xff\xff\xff\xff" + mac_b + b"\x08\x06"
    arp = struct.pack(
        "!HHBBH6s4s6s4s",
        1,
        0x0800,
        6,
        4,
        1,
        mac_b,
        ip_b,
        b"\x00" * 6,
        ip_b,
    )
    frame = eth + arp

    try:
        with socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(0x0806)) as sock:
            sock.bind((tap_name, 0))
            for _ in range(3):
                sock.send(frame)
                time.sleep(0.1)
    except OSError as exc:
        print(f"  [warn] GARP failed: {exc}")


# ── Subnet utils  ─────────────────────────────────────────────────────────────


def is_subnet_valid(subnet: str) -> bool:
    """
    subnet must be an IPv4 subnet, use a /30 mask, and the final octet must be 0.
    """
    _OCTET = r"(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)"
    _SUBNET_RE = re.compile(rf"^{_OCTET}\.{_OCTET}\.{_OCTET}\.0/30$")
    return bool(_SUBNET_RE.fullmatch(subnet))


def populate_subnet_ip(subnet: str, client_id: Literal["1", "2"]) -> str:
    if not is_subnet_valid(subnet):
        raise ValueError(f"Got invalid subnet. (Got: {subnet})")
    return subnet[:-4] + str(client_id) + subnet[-3:]


def construct_ip_from_subnet(subnet: str, client_id: Literal["1", "2"]) -> str:
    if not is_subnet_valid(subnet):
        raise ValueError(f"Got invalid subnet. (Got: {subnet})")
    return subnet[:-4] + str(client_id)
