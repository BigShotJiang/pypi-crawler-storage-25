"""cli.py — command-line interface.

Must run as root: TAP creation and raw ARP sockets require CAP_NET_ADMIN.
"""

from __future__ import annotations

import json
import os
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar

import click
from kubernetes.client import AppsV1Api, CoreV1Api, CustomObjectsApi

from k8s_l2_tunneler import k8s_ops, net_ops, tunnel
from k8s_l2_tunneler.config import (
    DEFAULT_MTU,
    DEFAULT_TUNNEL_TYPE,
    NAT_HOLE_PUNCH_PORT,
    TUNNEL_IMAGE,
    TUNNEL_TYPE_VALUES,
    WG_DEFAULT_SUBNET,
    WG_DEV_LISTEN_PORT,
    NatHolePunchError,
    RouteAlreadyInUseError,
    TunnelerError,
    TunnelType,
)


def _require_root() -> None:
    if os.geteuid() != 0:
        raise click.UsageError(
            "k8s-l2-tunneler must run as root (TAP + raw ARP require CAP_NET_ADMIN).\n"
            "Try: sudo k8s-l2-tunneler ..."
        )


def _clients() -> Tuple[CoreV1Api, AppsV1Api, CustomObjectsApi]:
    k8s_ops.load_kube_config()
    return k8s_ops.get_core_client(), k8s_ops.get_apps_client(), k8s_ops.get_custom_client()


def _validate_iface_name(
    ctx: click.Context, param: click.Parameter, value: Optional[str]
) -> Optional[str]:
    if value is not None and len(value) > 15:
        raise click.BadParameter(f"Interface name must be ≤ 15 characters (got {len(value)}).")
    return value


def _validate_wg_subnet(
    ctx: click.Context, param: click.Parameter, value: Optional[str]
) -> Optional[str]:
    if value is not None and not net_ops.is_subnet_valid(value):
        raise click.BadParameter(
            "WireGuard subnet must be an IPv4 subnet, "
            "use a /30 mask, and the final octet must be 0."
        )
    return value


def _validate_node_selector_dict(
    ctx: click.Context, param: click.Parameter, value: Optional[str]
) -> Optional[Dict[str, str]]:
    if not isinstance(value, str):
        return None
    try:
        obj = json.loads(value)
    except Exception as e:
        raise click.BadParameter(f"invalid JSON: {e}") from None
    if not isinstance(obj, dict):
        raise click.BadParameter("value must be a JSON object")
    for k, v in obj.items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise click.BadParameter("all keys and values must be strings")
    return obj


def _check_tunnel_tool(tunnel_type: TunnelType, wg_subnet: str) -> None:
    """Abort early if the required tunnel binary is not installed
    or the current machine state does not allow using it."""
    if tunnel_type == TunnelType.SOCAT and not net_ops.check_socat_installed():
        raise click.ClickException(
            "socat is not installed. "
            "Install it first (e.g. `apt install socat` or `brew install socat`)."
        )
    if tunnel_type == TunnelType.VXLAN_WG:
        if not net_ops.check_wg_installed():
            raise click.ClickException(
                "wireguard-tools (wg) is not installed. Install it first "
                "(e.g. `apt install wireguard-tools` or `brew install wireguard-tools`)."
            )
        try:
            net_ops.assert_subnet_not_in_use(wg_subnet)
        except RouteAlreadyInUseError as exc:
            raise click.ClickException(
                str(exc) + "\nUse --wg-subnet to select a custom subnet"
            ) from exc


def _nat_pre_check(
    behind_nat: bool,
    tunnel_type: TunnelType,
    hole_punch_port: int,
    wg_listen_port: int,
) -> None:
    """Emit helpful pre-flight warnings when NAT mode is requested."""
    if not behind_nat:
        return
    if tunnel_type == TunnelType.SOCAT:
        click.echo(
            f"[NAT] socat mode: developer will listen on UDP {hole_punch_port} for the NAT probe.\n"
            f"      Ensure your local firewall allows inbound UDP on port {hole_punch_port}.\n"
            f"      Example: sudo ufw allow {hole_punch_port}/udp"
        )
    else:
        click.echo(
            f"[NAT] vxlan-wg mode: developer WireGuard will listen on UDP {wg_listen_port}.\n"
            f"      Ensure your local firewall allows inbound UDP on port {wg_listen_port}.\n"
            f"      Example: sudo ufw allow {wg_listen_port}/udp\n"
            f"      The pod will initiate the WG handshake to your IP to punch the NAT."
        )


# ── Shared Common options ─────────────────────────────────────────────────────

_common_options = [
    click.option(
        "--namespace",
        default=None,
        show_default=False,
        help="Kubernetes namespace for created resources. Defaults to --owner value.",
    ),
    click.option(
        "--owner",
        required=True,
        help="Owner token — labels all created resources.",
    ),
    click.option(
        "--mtu",
        default=DEFAULT_MTU,
        show_default=True,
        help="MTU for all tunnel interfaces.",
    ),
    click.option(
        "--local-iface-name",
        "local_iface_name",
        default=None,
        callback=_validate_iface_name,
        is_eager=False,
        help="Name for the local interface (max 15 chars).",
    ),
    click.option(
        "--tunnel-type",
        "tunnel_type",
        type=click.Choice(list(TUNNEL_TYPE_VALUES)),
        default=DEFAULT_TUNNEL_TYPE.value,
        show_default=True,
        help=f"Tunneling backend: {TunnelType.SOCAT} (UDP TAP) or "
        f"{TunnelType.VXLAN_WG} (VXLAN over WireGuard).",
    ),
    click.option(
        "--wg-subnet",
        "wg_subnet",
        callback=_validate_wg_subnet,
        is_eager=False,
        default=WG_DEFAULT_SUBNET,
        show_default=True,
        help="Subnet when using WireGuard.\n"
        "WireGuard subnet must be an IPv4 subnet, use a /30 mask, and the final octet must be 0.",
    ),
    click.option(
        "--tunnel-image",
        "tunnel_image",
        default=TUNNEL_IMAGE,
        show_default=True,
        help="Docker image used for the Tunnel & Donor pod."
        "Note: must be ubuntu, overridable for package installation optimizations",
    ),
    click.option(
        "--node-selector",
        "node_selector",
        callback=_validate_node_selector_dict,
        is_eager=False,
        default=None,
        show_default=True,
        help="Passed directly to the Tunnel pod."
        "Must be a json with a dict that both its key and value are strings",
    ),
]


# ── Shared NAT options ────────────────────────────────────────────────────────

_nat_options = [
    click.option(
        "--cluster-behind-nat",
        "behind_nat",
        is_flag=True,
        default=False,
        help=(
            "Enable UDP NAT hole punching. Use when the cluster nodes are NOT directly "
            "routable from your machine (e.g. the cluster is behind a NAT that only exposes "
            "port 443). The pod punches a hole in the NAT and the tunnel is established through "
            "it. Fails gracefully with a diagnostic message if the NAT type is incompatible "
            "(e.g. symmetric NAT)."
        ),
    ),
    click.option(
        "--nat-ip",
        "nat_ip",
        default=None,
        metavar="IP",
        help=(
            "Public IP address of the cluster-side NAT (required only with "
            "--cluster-behind-nat). Auto-detected from the kubeconfig server URL when omitted."
        ),
    ),
    click.option(
        "--dev-ip",
        "dev_ip",
        default=None,
        metavar="IP",
        help=(
            "IP address of this developer machine as reachable FROM the cluster pod "
            "(required only with --cluster-behind-nat). Auto-detected via 'ip route get' "
            "when omitted."
        ),
    ),
]

F = TypeVar("F", bound=Callable[..., Any])


def _add_common_options(f: F) -> F:
    """Decorator that adds common options to a Click command."""
    for opt in reversed(_common_options):
        f = opt(f)
    return f


def _add_nat_options(f: F) -> F:
    """Decorator that adds NAT-related options to a Click command."""
    for opt in reversed(_nat_options):
        f = opt(f)
    return f


@click.group()
def main() -> None:
    """Layer-2 TAP tunnel into a Kubernetes cluster."""


# ── connect-to-cluster ────────────────────────────────────────────────────────


@main.command("connect-to-cluster")
@_add_common_options
@_add_nat_options
def connect_to_cluster(
    namespace: Optional[str],
    owner: str,
    mtu: int,
    local_iface_name: Optional[str],
    tunnel_type: TunnelType,
    wg_subnet: str,
    behind_nat: bool,
    tunnel_image: str,
    node_selector: Optional[Dict[str, str]],
    nat_ip: Optional[str],
    dev_ip: Optional[str],
) -> None:
    """Tunnel into the cluster network. Creates tunnel pod + donor pod + NAD.

    Dynamically discovers the donor pod's default interface (typically eth0).
    Only one cluster tunnel per owner is allowed at a time.

    \b
    NAT traversal (--cluster-behind-nat)
    ─────────────────────────────────────
    When the cluster sits behind a NAT that only exposes port 443, use this
    flag to enable UDP hole punching.  The tool will:

      1. Make the tunnel pod send a UDP probe FROM its listener port toward
         your machine, causing the NAT to create a port mapping.
      2. Capture the NAT's public IP and the allocated port.
      3. Connect the local tunnel client THROUGH that NAT mapping.

    If the NAT uses symmetric mapping (different external port per destination)
    or a firewall blocks the probe, an error is printed with remediation steps.
    No public relay server is used.
    """
    _require_root()
    _check_tunnel_tool(tunnel_type, wg_subnet)
    _nat_pre_check(behind_nat, tunnel_type, NAT_HOLE_PUNCH_PORT, WG_DEV_LISTEN_PORT)

    ns = namespace or owner
    v1, apps, custom = _clients()
    try:
        tunnel.connect_cluster(
            v1,
            apps,
            custom,
            ns,
            owner,
            mtu,
            local_iface_name,
            tunnel_type,
            wg_subnet,
            tunnel_image,
            node_selector,
            behind_nat=behind_nat,
            dev_ip=dev_ip,
            nat_ip=nat_ip,
        )
    except NatHolePunchError as exc:
        raise click.ClickException(f"NAT hole punching failed:\n\n{exc}") from exc
    except TunnelerError as exc:
        raise click.ClickException(str(exc)) from exc


# ── connect-to-cni ────────────────────────────────────────────────────────────


@main.command("connect-to-cni")
@_add_common_options
@_add_nat_options
@click.option(
    "--existing-cni-name",
    "cni_name",
    required=True,
    help="Name of an existing NetworkAttachmentDefinition to attach to the tunnel pod.",
)
@click.option(
    "--existing-cni-namespace",
    "cni_ns",
    required=True,
    help="Namespace of the provided existing NetworkAttachmentDefinition"
    "to attach to the tunnel pod.",
)
def connect_to_cni(
    namespace: Optional[str],
    owner: str,
    cni_name: str,
    cni_ns: str,
    mtu: int,
    local_iface_name: Optional[str],
    tunnel_type: TunnelType,
    wg_subnet: str,
    behind_nat: bool,
    tunnel_image: str,
    node_selector: Optional[Dict[str, str]],
    nat_ip: Optional[str],
    dev_ip: Optional[str],
) -> None:
    """Tunnel into a CNI network. Uses an existing NAD — no donor pod needed.

    Multiple CNI tunnels per owner are allowed (one per unique cni-name).
    Supports --cluster-behind-nat the same way as connect-to-cluster.
    """
    _require_root()
    _check_tunnel_tool(tunnel_type, wg_subnet)
    _nat_pre_check(behind_nat, tunnel_type, NAT_HOLE_PUNCH_PORT, WG_DEV_LISTEN_PORT)

    ns = namespace or owner
    v1, apps, custom = _clients()
    try:
        tunnel.connect_cni(
            v1,
            apps,
            custom,
            ns,
            owner,
            cni_name,
            cni_ns,
            mtu,
            local_iface_name,
            tunnel_type,
            wg_subnet,
            tunnel_image,
            node_selector,
            behind_nat=behind_nat,
            dev_ip=dev_ip,
            nat_ip=nat_ip,
        )
    except NatHolePunchError as exc:
        raise click.ClickException(f"NAT hole punching failed:\n\n{exc}") from exc
    except TunnelerError as exc:
        raise click.ClickException(str(exc)) from exc


# ── clean ─────────────────────────────────────────────────────────────────────


@main.command("clean")
@click.option("--owner", required=True, help="Owner token — removes all resources with this label.")
def clean(owner: str) -> None:
    """Remove all k8s resources and local state for an owner.

    Discovers resources via k8s labels (tunneler-owner=<owner>),
    so it works even if local state files were lost.
    Harvester ClusterNetworks are detected and cleaned automatically.
    """
    _require_root()
    k8s_ops.load_kube_config()
    v1 = k8s_ops.get_core_client()
    custom = k8s_ops.get_custom_client()
    try:
        tunnel.clean(v1, custom, owner)
    except TunnelerError as exc:
        raise click.ClickException(str(exc)) from exc
