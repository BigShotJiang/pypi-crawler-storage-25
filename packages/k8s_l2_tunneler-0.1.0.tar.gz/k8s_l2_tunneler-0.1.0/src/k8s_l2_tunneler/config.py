"""config.py — constants, frozen dataclasses, and custom exceptions."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum, unique
from pathlib import Path
from typing import Final, Optional

# ── Pod image ─────────────────────────────────────────────────────────────────

TUNNEL_IMAGE: str = "ubuntu:22.04"

# ── Networking ────────────────────────────────────────────────────────────────

# Default MTU for all tunnel interfaces. Leaves headroom for tunnel overhead
# and CNI overlay encapsulation (VXLAN ~50 B). Exposed as a CLI flag.
DEFAULT_MTU: int = 1370

POD_INTERNAL_PORT: int = 51820
NODEPORT_MIN: int = 32000
NODEPORT_MAX: int = 32767

# WireGuard point-to-point addresses (pod ↔ developer machine).
WG_DEFAULT_SUBNET: str = "192.168.222.0/30"
WG_POD_CLIENT_ID: Final = "1"
WG_DEV_CLIENT_ID: Final = "2"

# ── NAT traversal ─────────────────────────────────────────────────────────────

# UDP port the developer machine listens on to receive the pod's NAT probe.
# The pod sends one UDP datagram FROM POD_INTERNAL_PORT to this port so the
# NAT creates a binding that the developer can reverse-connect through.
NAT_HOLE_PUNCH_PORT: int = 4500

# WireGuard listen port on the developer machine in NAT mode.  The pod's WG
# initiates to this port (punching the NAT), so the developer must NOT be
# behind a NAT that blocks incoming UDP on this port.
WG_DEV_LISTEN_PORT: int = 51821

# Seconds to wait for WireGuard handshake to complete after key exchange.
# Also used as the timeout before declaring NAT hole punching as failed.
WG_HANDSHAKE_TIMEOUT: int = 30

# ── Timeouts ──────────────────────────────────────────────────────────────────

POD_READY_TIMEOUT: int = 300
LOCAL_TAP_APPEAR_TIMEOUT: int = 15
CLEAN_WAIT_TIMEOUT: int = 120

# ── Local state directory ─────────────────────────────────────────────────────

STATE_DIR: Path = Path.home() / ".k8s-l2-tunneler"

# ── K8s label keys ────────────────────────────────────────────────────────────

LABEL_APP: str = "app"
LABEL_APP_VALUE: str = "k8s-l2-tunneler"
LABEL_OWNER: str = "tunneler-owner"
LABEL_TID: str = "tunneler-tid"
LABEL_MODE: str = "tunneler-mode"
LABEL_ROLE: str = "role"


# ── Exceptions ────────────────────────────────────────────────────────────────


class TunnelerError(Exception):
    """Base error for all k8s-l2-tunneler failures."""


class AlreadyExistsError(TunnelerError):
    """A tunnel for this owner/mode already exists."""


class SetupError(TunnelerError):
    """A setup step failed unrecoverably."""


class NatHolePunchError(TunnelerError):
    """NAT hole punching was attempted but failed or is not feasible."""


class RouteAlreadyInUseError(TunnelerError):
    """A route already exists."""


# ── Dataclasses ───────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class TunnelIDs:
    """All Kubernetes and local resource names for one tunnel instance."""

    tid: str
    mode: str  # "cluster" | "cni"
    owner: str
    namespace: str
    tunnel_pod_name: str
    donor_pod_name: Optional[str]  # None in cni mode
    service_name: str
    nad_name: Optional[str]  # None in cni mode (uses existing NAD)
    nad_bridge_name: Optional[str]  # None in cni mode
    harvester_cluster_network_name: Optional[str]  # None in cni mode
    local_tap_name: str
    node_port: int
    vxlan_id: int  # VXLAN VNI derived from tid; used only in vxlan-wg mode


@dataclass(frozen=True)
class DonorIdentity:
    """Network identity read from a pod interface before it is stripped."""

    pod_ip: str
    pod_mac: str
    iface: str  # interface name the identity was read from
    prefix: int  # subnet prefix length from the original CIDR assignment


@dataclass(frozen=True)
class LocalState:
    """Minimal local-only state. Everything else is re-derived from k8s labels."""

    tid: str
    tunnel_type: TunnelType
    local_tap: str
    socat_pid: Optional[int] = None  # socat mode only
    wg_iface: Optional[str] = None  # vxlan-wg mode only

    def to_json(self) -> str:
        return json.dumps(self.__dict__, indent=2)

    @staticmethod
    def from_json(raw: str) -> LocalState:
        return LocalState(**json.loads(raw))


# ── Tunnel Types ──────────────────────────────────────────────────────────────


@unique
class TunnelType(str, Enum):
    VXLAN_WG = "vxlan-wg"
    SOCAT = "socat"


TUNNEL_TYPE_VALUES = frozenset([m.value for m in TunnelType])
DEFAULT_TUNNEL_TYPE = TunnelType.VXLAN_WG
