"""k8s_ops.py — all Kubernetes API operations.

Functions perform exactly one operation each. Orchestration lives in tunnel.py.
Raises TunnelerError subclasses on logical failures; lets ApiException propagate
for unexpected API errors.

NAT additions
─────────────
trigger_nat_probe()    — exec socat one-shot probe in pod to punch NAT hole
write_dev_endpoint()   — write /tmp/dev_endpoint in pod (WG NAT mode)
get_nat_ip_from_config() — extract NAT public IP from the active kubeconfig
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional, cast
from urllib.parse import urlparse

from kubernetes import client
from kubernetes import config as k8s_config
from kubernetes.client.rest import ApiException
from kubernetes.stream import stream

from k8s_l2_tunneler.config import (
    CLEAN_WAIT_TIMEOUT,
    LABEL_APP,
    LABEL_APP_VALUE,
    LABEL_MODE,
    LABEL_OWNER,
    LABEL_ROLE,
    LABEL_TID,
    POD_INTERNAL_PORT,
    POD_READY_TIMEOUT,
    DonorIdentity,
    SetupError,
    TunnelIDs,
    TunnelType,
)
from k8s_l2_tunneler.scripts import (
    build_donor_script,
    build_tunnel_cluster_script,
    build_tunnel_cluster_script_nat,
    build_tunnel_cluster_script_wg,
    build_tunnel_cni_script,
    build_tunnel_cni_script_nat,
    build_tunnel_cni_script_wg,
)

# ── CRD coordinates ───────────────────────────────────────────────────────────

_NAD_GROUP = "k8s.cni.cncf.io"
_NAD_VERSION = "v1"
_NAD_PLURAL = "network-attachment-definitions"

_HCN_GROUP = "network.harvesterhci.io"
_HCN_VERSION = "v1beta1"
_HCN_PLURAL = "clusternetworks"

# ── Client factories ──────────────────────────────────────────────────────────


def load_kube_config() -> None:
    try:
        k8s_config.load_incluster_config()
    except k8s_config.ConfigException:
        k8s_config.load_kube_config()


def get_core_client() -> client.CoreV1Api:
    return client.CoreV1Api()


def get_apps_client() -> client.AppsV1Api:
    return client.AppsV1Api()


def get_custom_client() -> client.CustomObjectsApi:
    return client.CustomObjectsApi()


# ── Kubeconfig inspection ─────────────────────────────────────────────────────


def get_nat_ip_from_config() -> Optional[str]:
    """Extract the server hostname/IP from the active kubeconfig.

    When a cluster is behind NAT with only port 443 forwarded, the API server
    URL in kubeconfig is ``https://NAT_PUBLIC_IP:443``.  This function returns
    just the hostname/IP portion so the CLI can auto-detect the NAT address.

    Returns None on any error so the caller can fall back to a user-provided
    ``--nat-ip`` flag.
    """
    try:
        cfg = client.Configuration.get_default_copy()
        parsed = urlparse(cfg.host)
        hostname = parsed.hostname
        return hostname if hostname else None
    except Exception:
        return None


# ── CNI detection ─────────────────────────────────────────────────────────────


def detect_cni(apps: client.AppsV1Api) -> str:
    """Best-effort detection via kube-system DaemonSet names."""
    try:
        items = cast(
            List[client.V1DaemonSet],
            apps.list_namespaced_daemon_set("kube-system").items,
        )
        names = {ds.metadata.name for ds in items if ds.metadata and ds.metadata.name}
    except ApiException:
        return "unknown"
    if "calico-node" in names and "kube-flannel-ds" not in names:
        return "calico"
    if "cilium" in names:
        return "cilium"
    if "kube-flannel-ds" in names or any("flannel" in n for n in names):
        return "flannel"
    if "weave-net" in names:
        return "weave"
    if "antrea-agent" in names:
        return "antrea"
    return "unknown"


def detect_harvester(custom: client.CustomObjectsApi) -> bool:
    """Return True if the Harvester ClusterNetwork CRD exists in the cluster."""
    try:
        custom.list_cluster_custom_object(
            group=_HCN_GROUP,
            version=_HCN_VERSION,
            plural=_HCN_PLURAL,
        )
        return True
    except ApiException as exc:
        # 404 = CRD does not exist; 403 = CRD exists but we lack list permission
        status = cast(bool, exc.status)
        if status in (404, 403):
            return status == 403
        return False


# ── Namespace ─────────────────────────────────────────────────────────────────


def ensure_namespace(v1: client.CoreV1Api, namespace: str) -> None:
    try:
        v1.read_namespace(name=namespace)
    except ApiException as exc:
        if exc.status == 404:
            v1.create_namespace(
                body=client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
            )
        else:
            raise


# ── Tunnel existence checks ───────────────────────────────────────────────────


def cluster_tunnel_exists(v1: client.CoreV1Api, owner: str) -> bool:
    """Return True if any cluster-mode tunnel pod exists for this owner."""
    sel = f"{LABEL_APP}={LABEL_APP_VALUE},{LABEL_OWNER}={owner},{LABEL_MODE}=cluster"
    pods = v1.list_pod_for_all_namespaces(label_selector=sel).items
    return len(pods) > 0


def cni_tunnel_exists(v1: client.CoreV1Api, ids: TunnelIDs) -> bool:
    """Return True if this specific CNI tunnel pod already exists."""
    sel = f"{LABEL_APP}={LABEL_APP_VALUE},{LABEL_TID}={ids.tid}"
    pods = v1.list_namespaced_pod(namespace=ids.namespace, label_selector=sel).items
    return len(pods) > 0


# ── NAD ───────────────────────────────────────────────────────────────────────


def create_nad(custom: client.CustomObjectsApi, ids: TunnelIDs, mtu: int) -> None:
    """Create a per-tunnel bridge NAD. hairpinMode=true is required for ARP."""
    assert ids.nad_name and ids.nad_bridge_name
    cfg = json.dumps(
        {
            "cniVersion": "0.3.1",
            "name": ids.nad_name,
            "type": "bridge",
            "bridge": ids.nad_bridge_name,
            "isGateway": False,
            "isDefaultGateway": False,
            "ipMasq": False,
            "hairpinMode": True,
            "mtu": mtu,
            "ipam": {},
        }
    )
    body = {
        "apiVersion": f"{_NAD_GROUP}/{_NAD_VERSION}",
        "kind": "NetworkAttachmentDefinition",
        "metadata": {
            "name": ids.nad_name,
            "namespace": ids.namespace,
            "labels": _labels(ids, "nad"),
        },
        "spec": {"config": cfg},
    }
    try:
        custom.create_namespaced_custom_object(
            group=_NAD_GROUP,
            version=_NAD_VERSION,
            namespace=ids.namespace,
            plural=_NAD_PLURAL,
            body=body,
        )
    except ApiException as exc:
        if exc.status != 409:
            raise


def delete_nad(custom: client.CustomObjectsApi, ids: TunnelIDs) -> None:
    if not ids.nad_name:
        return
    try:
        custom.delete_namespaced_custom_object(
            group=_NAD_GROUP,
            version=_NAD_VERSION,
            namespace=ids.namespace,
            plural=_NAD_PLURAL,
            name=ids.nad_name,
        )
    except ApiException as exc:
        if exc.status != 404:
            print(f"  [warn] deleting NAD {ids.nad_name}: {exc.reason}")


# ── Harvester ClusterNetwork ──────────────────────────────────────────────────


def create_harvester_cluster_network(custom: client.CustomObjectsApi, ids: TunnelIDs) -> None:
    """Create the Harvester ClusterNetwork that the NAD VlanConfig references."""
    body = {
        "apiVersion": f"{_HCN_GROUP}/{_HCN_VERSION}",
        "kind": "ClusterNetwork",
        "metadata": {
            "name": ids.harvester_cluster_network_name,
            "labels": _labels(ids, "clusternetwork"),
        },
        "spec": {"description": f"k8s-l2-tunneler cluster network for tid {ids.tid}"},
    }
    try:
        custom.create_cluster_custom_object(
            group=_HCN_GROUP,
            version=_HCN_VERSION,
            plural=_HCN_PLURAL,
            body=body,
        )
    except ApiException as exc:
        if exc.status != 409:
            raise


def delete_harvester_cluster_network(custom: client.CustomObjectsApi, ids: TunnelIDs) -> None:
    try:
        custom.delete_cluster_custom_object(
            group=_HCN_GROUP,
            version=_HCN_VERSION,
            plural=_HCN_PLURAL,
            name=ids.harvester_cluster_network_name,
        )
    except ApiException as exc:
        if exc.status != 404:
            print(
                "  [warn] deleting ClusterNetwork "
                f"{ids.harvester_cluster_network_name}: {exc.reason}"
            )


# ── Pod creation ──────────────────────────────────────────────────────────────


def _labels(ids: TunnelIDs, role: str) -> Dict[Any, Any]:
    return {
        LABEL_APP: LABEL_APP_VALUE,
        LABEL_OWNER: ids.owner,
        LABEL_TID: ids.tid,
        LABEL_MODE: ids.mode,
        LABEL_ROLE: role,
    }


def _readiness_probe(sentinel: str = "ready") -> client.V1Probe:
    return client.V1Probe(
        _exec=client.V1ExecAction(command=["test", "-f", f"/tmp/{sentinel}"]),
        initial_delay_seconds=10,
        period_seconds=3,
        failure_threshold=60,
    )


def _tun_volume() -> tuple:  # type: ignore[type-arg]
    return (
        client.V1VolumeMount(name="dev-net-tun", mount_path="/dev/net/tun"),
        client.V1Volume(
            name="dev-net-tun",
            host_path=client.V1HostPathVolumeSource(path="/dev/net/tun", type="CharDevice"),
        ),
    )


def create_tunnel_pod_cluster(
    v1: client.CoreV1Api,
    ids: TunnelIDs,
    port: int,
    mtu: int,
    tunnel_type: TunnelType,
    wg_subnet: str,
    tunnel_image: str,
    node_selector: Optional[Dict[str, str]],
    behind_nat: bool = False,
) -> None:
    """Cluster-mode tunnel pod. Needs /dev/net/tun for socat mode.

    When behind_nat=True and tunnel_type=SOCAT, a NAT-aware script is used:
    the pod connects OUTBOUND to the developer's socat listener (written to
    /tmp/dev_endpoint by the orchestrator) rather than listening for an inbound
    NodePort connection.  This avoids requiring a direct route to the node IP
    and eliminates the port-reuse conflict when probing from port 51820.
    """
    assert ids.nad_name
    if tunnel_type == TunnelType.SOCAT:
        script = (
            build_tunnel_cluster_script_nat(mtu=mtu)
            if behind_nat
            else build_tunnel_cluster_script(port=port, mtu=mtu)
        )
        extra_volumes: List[Any] = []
        extra_mounts: List[Any] = []
        mount, volume = _tun_volume()
        extra_mounts.append(mount)
        extra_volumes.append(volume)
    else:
        script = build_tunnel_cluster_script_wg(
            port=port, mtu=mtu, vxlan_id=ids.vxlan_id, wg_subnet=wg_subnet
        )
        extra_volumes = []
        extra_mounts = []

    pod = client.V1Pod(
        api_version="v1",
        kind="Pod",
        metadata=client.V1ObjectMeta(
            name=ids.tunnel_pod_name,
            namespace=ids.namespace,
            labels=_labels(ids, "tunnel"),
            annotations={"k8s.v1.cni.cncf.io/networks": ids.nad_name},
        ),
        spec=client.V1PodSpec(
            node_selector=node_selector,
            restart_policy="Never",
            containers=[
                client.V1Container(
                    name="tunnel",
                    image=tunnel_image,
                    command=["sh", "-c", script],
                    security_context=client.V1SecurityContext(
                        privileged=True,
                        capabilities=client.V1Capabilities(
                            add=["NET_ADMIN", "NET_RAW", "SYS_MODULE"]
                        ),
                    ),
                    readiness_probe=_readiness_probe("ready"),
                    volume_mounts=extra_mounts or None,
                )
            ],
            volumes=extra_volumes or None,
        ),
    )
    try:
        v1.create_namespaced_pod(body=pod, namespace=ids.namespace)
    except ApiException as exc:
        if exc.status != 409:
            raise


def create_donor_pod(
    v1: client.CoreV1Api,
    ids: TunnelIDs,
    mtu: int,
    node_name: str,
    tunnel_image: str,
) -> None:
    """Donor pod pinned to the same node as the tunnel pod."""
    assert ids.donor_pod_name and ids.nad_name
    script = build_donor_script(mtu=mtu)
    pod = client.V1Pod(
        api_version="v1",
        kind="Pod",
        metadata=client.V1ObjectMeta(
            name=ids.donor_pod_name,
            namespace=ids.namespace,
            labels=_labels(ids, "donor"),
            annotations={"k8s.v1.cni.cncf.io/networks": ids.nad_name},
        ),
        spec=client.V1PodSpec(
            restart_policy="Never",
            node_name=node_name,
            containers=[
                client.V1Container(
                    name="donor",
                    image=tunnel_image,
                    command=["sh", "-c", script],
                    security_context=client.V1SecurityContext(
                        privileged=True,
                        capabilities=client.V1Capabilities(add=["NET_ADMIN", "NET_RAW"]),
                    ),
                    readiness_probe=_readiness_probe("ready"),
                )
            ],
        ),
    )
    try:
        v1.create_namespaced_pod(body=pod, namespace=ids.namespace)
    except ApiException as exc:
        if exc.status != 409:
            raise


def create_tunnel_pod_cni(
    v1: client.CoreV1Api,
    ids: TunnelIDs,
    port: int,
    mtu: int,
    existing_cni_nad: str,
    existing_cni_ns: str,
    tunnel_type: TunnelType,
    tunnel_image: str,
    wg_subnet: str,
    node_selector: Optional[Dict[str, str]],
    behind_nat: bool = False,
) -> None:
    """CNI-mode tunnel pod annotated with an existing NAD.

    When behind_nat=True and tunnel_type=SOCAT, the NAT-aware script is used
    (same semantics as create_tunnel_pod_cluster with behind_nat=True).
    """
    if tunnel_type == TunnelType.SOCAT:
        script = (
            build_tunnel_cni_script_nat(mtu=mtu)
            if behind_nat
            else build_tunnel_cni_script(port=port, mtu=mtu)
        )
        extra_volumes: List[Any] = []
        extra_mounts: List[Any] = []
        mount, volume = _tun_volume()
        extra_mounts.append(mount)
        extra_volumes.append(volume)
    else:
        script = build_tunnel_cni_script_wg(
            port=port,
            mtu=mtu,
            vxlan_id=ids.vxlan_id,
            wg_subnet=wg_subnet,
        )
        extra_volumes = []
        extra_mounts = []

    cni_annotaion_value = [{"name": existing_cni_nad, "namespace": existing_cni_ns}]

    pod = client.V1Pod(
        api_version="v1",
        kind="Pod",
        metadata=client.V1ObjectMeta(
            name=ids.tunnel_pod_name,
            namespace=ids.namespace,
            labels=_labels(ids, "tunnel"),
            annotations={"k8s.v1.cni.cncf.io/networks": json.dumps(cni_annotaion_value)},
        ),
        spec=client.V1PodSpec(
            node_selector=node_selector,
            restart_policy="Never",
            containers=[
                client.V1Container(
                    name="tunnel",
                    image=tunnel_image,
                    command=["sh", "-c", script],
                    security_context=client.V1SecurityContext(
                        privileged=True,
                        capabilities=client.V1Capabilities(
                            add=["NET_ADMIN", "NET_RAW", "SYS_MODULE"]
                        ),
                    ),
                    readiness_probe=_readiness_probe("ready"),
                    volume_mounts=extra_mounts or None,
                )
            ],
            volumes=extra_volumes or None,
        ),
    )
    try:
        v1.create_namespaced_pod(body=pod, namespace=ids.namespace)
    except ApiException as exc:
        if exc.status != 409:
            raise


def create_service(
    v1: client.CoreV1Api,
    ids: TunnelIDs,
    tunnel_type: TunnelType,
) -> None:
    """Create a UDP NodePort service pointing at the tunnel pod.

    For vxlan-wg, sets externalTrafficPolicy=Local so the WireGuard endpoint
    address seen by the pod matches the actual client NodeIP.
    """
    extra_kwargs: Dict[Any, Any] = {}
    if tunnel_type == TunnelType.VXLAN_WG:
        extra_kwargs["external_traffic_policy"] = "Local"

    svc = client.V1Service(
        api_version="v1",
        kind="Service",
        metadata=client.V1ObjectMeta(
            name=ids.service_name,
            namespace=ids.namespace,
            labels=_labels(ids, "service"),
        ),
        spec=client.V1ServiceSpec(
            type="NodePort",
            selector={
                LABEL_APP: LABEL_APP_VALUE,
                LABEL_TID: ids.tid,
                LABEL_ROLE: "tunnel",
            },
            ports=[
                client.V1ServicePort(
                    port=POD_INTERNAL_PORT,
                    target_port=POD_INTERNAL_PORT,
                    node_port=ids.node_port,
                    protocol="UDP",
                )
            ],
            **extra_kwargs,
        ),
    )
    try:
        v1.create_namespaced_service(body=svc, namespace=ids.namespace)
    except ApiException as exc:
        if exc.status == 409:
            pass  # reuse existing
        elif exc.status == 422:
            raise SetupError(
                f"NodePort {ids.node_port} already allocated — try a different owner or namespace."
            ) from None
        else:
            raise


# ── Wait helpers ──────────────────────────────────────────────────────────────


def _pod_failed(pod: client.V1Pod) -> bool:
    return bool(pod.status and pod.status.phase in ("Failed", "Unknown"))


def _pod_failure_detail(pod: client.V1Pod) -> str:
    if pod.status and pod.status.container_statuses:
        st = pod.status.container_statuses[0].state
        if st and st.terminated:
            return f" ({st.terminated.reason}: {st.terminated.message})"
    return ""


def wait_for_pod_scheduled(v1: client.CoreV1Api, namespace: str, pod_name: str) -> str:
    """Block until the pod is assigned to a node. Returns node name."""
    deadline = time.monotonic() + POD_READY_TIMEOUT
    while time.monotonic() < deadline:
        pod = v1.read_namespaced_pod(name=pod_name, namespace=namespace)
        if pod.spec and pod.spec.node_name:
            return cast(str, pod.spec.node_name)
        if _pod_failed(pod):
            raise SetupError(
                f"Pod {pod_name!r} failed before scheduling{_pod_failure_detail(pod)}."
            )
        time.sleep(2)
    raise SetupError(f"Pod {pod_name!r} was not scheduled within {POD_READY_TIMEOUT}s.")


def wait_for_pod_ready(v1: client.CoreV1Api, namespace: str, pod_name: str) -> str:
    """Block until the pod is Running + all containers ready. Returns host IP."""
    deadline = time.monotonic() + POD_READY_TIMEOUT
    while time.monotonic() < deadline:
        pod = v1.read_namespaced_pod(name=pod_name, namespace=namespace)
        if _pod_failed(pod):
            raise SetupError(
                f"Pod {pod_name!r} failed{_pod_failure_detail(pod)}.\n"
                f"  Debug: kubectl describe pod -n {namespace} {pod_name}"
            )
        if pod.status and pod.status.phase == "Running":
            statuses = cast(List[client.V1ContainerStatus], pod.status.container_statuses or [])
            if statuses and all(cs.ready for cs in statuses):
                return cast(str, pod.status.host_ip or "")
        time.sleep(2)
    raise SetupError(
        f"Pod {pod_name!r} not ready within {POD_READY_TIMEOUT}s.\n"
        f"  Debug: kubectl describe pod -n {namespace} {pod_name}"
    )


def wait_for_pod_running(v1: client.CoreV1Api, namespace: str, pod_name: str) -> None:
    """Block until the pod phase is Running (containers may not be ready yet).

    Used before exec-ing into a pod in NAT mode: we need the container to be
    started (so the shell is available) but we cannot wait for full readiness
    because the pod is still waiting for a sentinel we haven't written yet.
    """
    deadline = time.monotonic() + POD_READY_TIMEOUT
    while time.monotonic() < deadline:
        pod = v1.read_namespaced_pod(name=pod_name, namespace=namespace)
        if _pod_failed(pod):
            raise SetupError(
                f"Pod {pod_name!r} failed{_pod_failure_detail(pod)}.\n"
                f"  Debug: kubectl describe pod -n {namespace} {pod_name}"
            )
        if pod.status and pod.status.phase == "Running":
            return
        time.sleep(2)
    raise SetupError(
        f"Pod {pod_name!r} did not reach Running phase within {POD_READY_TIMEOUT}s.\n"
        f"  Debug: kubectl describe pod -n {namespace} {pod_name}"
    )


def wait_for_nad_gone(
    v1: client.CoreV1Api,
    custom: client.CustomObjectsApi,
    owner: str,
) -> None:
    """Block until all NADs for this owner are gone from the cluster."""
    sel = _owner_selector(owner)
    deadline = time.monotonic() + CLEAN_WAIT_TIMEOUT
    while time.monotonic() < deadline:
        try:
            nads = custom.list_cluster_custom_object(
                group=_NAD_GROUP,
                version=_NAD_VERSION,
                plural=_NAD_PLURAL,
                label_selector=sel,
            ).get("items", [])
        except ApiException:
            nads = []

        if not nads:
            return
        time.sleep(2)
    print(f"  [warn] Timed out waiting for deletion — still present: {nads}.")


def wait_for_owner_resources_gone(
    v1: client.CoreV1Api,
    custom: client.CustomObjectsApi,
    owner: str,
    is_harvester: bool,
) -> None:
    """Block until all pods, services, and NADs for this owner are gone from the cluster."""
    sel = _owner_selector(owner)
    deadline = time.monotonic() + CLEAN_WAIT_TIMEOUT
    while time.monotonic() < deadline:
        pods = v1.list_pod_for_all_namespaces(label_selector=sel).items
        svcs = v1.list_service_for_all_namespaces(label_selector=sel).items
        try:
            nads = custom.list_cluster_custom_object(
                group=_NAD_GROUP,
                version=_NAD_VERSION,
                plural=_NAD_PLURAL,
                label_selector=sel,
            ).get("items", [])
        except ApiException:
            nads = []

        cns: List[Any] = []
        if is_harvester:
            try:
                cns = custom.list_cluster_custom_object(
                    group=_HCN_GROUP,
                    version=_HCN_VERSION,
                    plural=_HCN_PLURAL,
                    label_selector=sel,
                ).get("items", [])
            except ApiException:
                cns = []

        if not pods and not svcs and not nads and not cns:
            return
        time.sleep(2)

    remaining = []
    if pods:
        remaining.append(f"{len(pods)} pod(s)")
    if svcs:
        remaining.append(f"{len(svcs)} service(s)")
    if nads:
        remaining.append(f"{len(nads)} NAD(s)")
    if cns:
        remaining.append(f"{len(cns)} ClusterNetwork(s)")
    print(f"  [warn] Timed out waiting for deletion — still present: {', '.join(remaining)}.")


# ── Identity operations ───────────────────────────────────────────────────────


def _exec_sh(v1: client.CoreV1Api, namespace: str, pod_name: str, cmd: str) -> str:
    """Run a shell command in a pod and return stdout."""
    return cast(
        str,
        stream(
            v1.connect_get_namespaced_pod_exec,
            pod_name,
            namespace,
            command=["sh", "-c", cmd],
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
        ),
    )


def discover_donor_iface(v1: client.CoreV1Api, namespace: str, pod_name: str) -> str:
    """Exec into pod and return the default-route interface name."""
    iface = _exec_sh(
        v1,
        namespace,
        pod_name,
        "ip route show default | awk '/default/ {print $5}' | head -1",
    ).strip()
    if not iface:
        raise SetupError(f"Could not discover default interface in pod {pod_name!r}.")
    return iface


def read_pod_identity(
    v1: client.CoreV1Api, namespace: str, pod_name: str, iface: str
) -> DonorIdentity:
    """Read IP, MAC, and subnet prefix from a pod interface via exec."""
    ip_cidr = _exec_sh(
        v1,
        namespace,
        pod_name,
        f"ip -4 addr show {iface} | awk '/inet / {{print $2}}' | head -1",
    ).strip()
    if not ip_cidr or "/" not in ip_cidr:
        raise SetupError(f"No IPv4 address on {iface!r} in pod {pod_name!r}.")
    pod_ip, prefix_str = ip_cidr.split("/", 1)

    mac = _exec_sh(
        v1,
        namespace,
        pod_name,
        f"ip link show {iface} | awk '/link\\/ether/ {{print $2}}'",
    ).strip()
    if not mac:
        raise SetupError(f"Could not read MAC from {iface!r} in pod {pod_name!r}.")

    return DonorIdentity(pod_ip=pod_ip, pod_mac=mac, iface=iface, prefix=int(prefix_str))


def signal_proceed(v1: client.CoreV1Api, namespace: str, pod_name: str) -> None:
    """Write /tmp/proceed inside a pod, unblocking its bridge-setup phase."""
    _exec_sh(v1, namespace, pod_name, "touch /tmp/proceed")


def wait_for_done(v1: client.CoreV1Api, namespace: str, pod_name: str) -> None:
    """Block until /tmp/done exists inside the pod (bridge setup complete)."""
    _exec_sh(
        v1,
        namespace,
        pod_name,
        "i=0; while [ ! -f /tmp/done ]; do i=$((i+1)); [ $i -ge 120 ] && exit 1; sleep 1; done",
    )


# ── WireGuard key exchange (vxlan-wg mode) ────────────────────────────────────


def read_wg_pubkey(v1: client.CoreV1Api, namespace: str, pod_name: str) -> str:
    """Read the pod's WireGuard public key from /tmp/wg_pub (set by pod init script)."""
    _exec_sh(
        v1,
        namespace,
        pod_name,
        "i=0; while [ ! -f /tmp/wg_keys_ready ]; do i=$((i+1)); "
        "[ $i -ge 120 ] && exit 1; sleep 1; done",
    )
    pubkey = _exec_sh(v1, namespace, pod_name, "cat /tmp/wg_pub").strip()
    if not pubkey:
        raise SetupError(f"Could not read WireGuard public key from pod {pod_name!r}.")
    return pubkey


def write_dev_pubkey(v1: client.CoreV1Api, namespace: str, pod_name: str, pubkey: str) -> None:
    """Write the developer's WireGuard public key to /tmp/dev_pub in the pod."""
    _exec_sh(v1, namespace, pod_name, f"echo '{pubkey}' > /tmp/dev_pub")


def write_dev_endpoint(
    v1: client.CoreV1Api,
    namespace: str,
    pod_name: str,
    dev_ip: str,
    dev_wg_port: int,
) -> None:
    """Write the developer's WireGuard endpoint to /tmp/dev_endpoint in the pod.

    This file is checked by the WG pod init script.  When present, the pod
    configures its WG peer WITH the endpoint so it initiates the handshake
    (required for NAT traversal — the pod must send the first packet outbound
    so the NAT creates a binding that the developer can use).
    """
    _exec_sh(v1, namespace, pod_name, f"printf '%s' '{dev_ip}:{dev_wg_port}' > /tmp/dev_endpoint")


# ── Label-based discovery for clean ──────────────────────────────────────────


def _owner_selector(owner: str) -> str:
    return f"{LABEL_APP}={LABEL_APP_VALUE},{LABEL_OWNER}={owner}"


def list_pods_by_owner(v1: client.CoreV1Api, owner: str) -> List[client.V1Pod]:
    return cast(
        List[client.V1Pod],
        v1.list_pod_for_all_namespaces(label_selector=_owner_selector(owner)).items,
    )


def list_services_by_owner(v1: client.CoreV1Api, owner: str) -> List[client.V1Service]:
    return cast(
        List[client.V1Service],
        v1.list_service_for_all_namespaces(label_selector=_owner_selector(owner)).items,
    )


def list_nads_by_owner(custom: client.CustomObjectsApi, owner: str) -> List[Any]:
    try:
        return cast(
            List[Any],
            custom.list_cluster_custom_object(
                group=_NAD_GROUP,
                version=_NAD_VERSION,
                plural=_NAD_PLURAL,
                label_selector=_owner_selector(owner),
            ).get("items", []),
        )
    except ApiException:
        return []


def list_cluster_networks_by_owner(custom: client.CustomObjectsApi, owner: str) -> List[Any]:
    try:
        return cast(
            List[Any],
            custom.list_cluster_custom_object(
                group=_HCN_GROUP,
                version=_HCN_VERSION,
                plural=_HCN_PLURAL,
                label_selector=_owner_selector(owner),
            ).get("items", []),
        )
    except ApiException:
        return []


# ── Deletion ──────────────────────────────────────────────────────────────────


def delete_pod(v1: client.CoreV1Api, namespace: str, pod_name: str) -> None:
    try:
        v1.delete_namespaced_pod(name=pod_name, namespace=namespace)
    except ApiException as exc:
        if exc.status != 404:
            print(f"  [warn] deleting pod {pod_name}: {exc.reason}")


def delete_service(v1: client.CoreV1Api, namespace: str, svc_name: str) -> None:
    try:
        v1.delete_namespaced_service(name=svc_name, namespace=namespace)
    except ApiException as exc:
        if exc.status != 404:
            print(f"  [warn] deleting service {svc_name}: {exc.reason}")


def delete_custom_namespaced(
    custom: client.CustomObjectsApi,
    group: str,
    version: str,
    plural: str,
    namespace: str,
    name: str,
) -> None:
    try:
        custom.delete_namespaced_custom_object(
            group=group,
            version=version,
            plural=plural,
            namespace=namespace,
            name=name,
        )
    except ApiException as exc:
        if exc.status != 404:
            print(f"  [warn] deleting {plural}/{name}: {exc.reason}")


def delete_custom_cluster(
    custom: client.CustomObjectsApi,
    group: str,
    version: str,
    plural: str,
    name: str,
) -> None:
    try:
        custom.delete_cluster_custom_object(
            group=group,
            version=version,
            plural=plural,
            name=name,
        )
    except ApiException as exc:
        if exc.status != 404:
            print(f"  [warn] deleting {plural}/{name}: {exc.reason}")
