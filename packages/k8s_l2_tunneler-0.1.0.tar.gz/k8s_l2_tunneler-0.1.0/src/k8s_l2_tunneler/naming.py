"""naming.py — collision-resistant, deterministic resource name derivation.

All names are keyed via SHA-256 so tunnels with different owners or CNI names
are fully independent. Interface name limits: 15 chars max on Linux.
"""

from __future__ import annotations

import hashlib
from typing import Optional

from k8s_l2_tunneler.config import NODEPORT_MAX, NODEPORT_MIN, TunnelIDs

_SLOTS: int = NODEPORT_MAX - NODEPORT_MIN + 1
_VXLAN_MAX: int = 16777215  # 24-bit VNI space


def _tid(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()[:8]


def _port(key: str) -> int:
    return (int(hashlib.sha256(key.encode()).hexdigest(), 16) % _SLOTS) + NODEPORT_MIN


def _vxlan_id(key: str) -> int:
    # Use a different digest slice to avoid correlation with port.
    return (int(hashlib.sha256(key.encode()).hexdigest()[8:16], 16) % _VXLAN_MAX) + 1


def derive_cluster_ids(
    namespace: str, owner: str, local_iface_name: Optional[str] = None
) -> TunnelIDs:
    """IDs for a cluster-network tunnel (tunnel pod + donor pod + new NAD)."""
    key = f"cluster/{namespace}/{owner}"
    tid = _tid(key)
    tap_name = local_iface_name or f"tap-{tid}"
    return TunnelIDs(
        tid=tid,
        mode="cluster",
        owner=owner,
        namespace=namespace,
        tunnel_pod_name=f"tunneler-{tid}",
        donor_pod_name=f"tunneler-donor-{tid}",
        service_name=f"tunneler-svc-{tid}",
        nad_name=f"tunneler-nad-{tid}",
        nad_bridge_name=f"nad-{tid[:8]}-br",
        harvester_cluster_network_name=f"nad-{tid[:8]}",
        local_tap_name=tap_name,
        node_port=_port(key),
        vxlan_id=_vxlan_id(key),
    )


def derive_cni_ids(
    namespace: str, owner: str, cni_name: str, cni_ns: str, local_iface_name: Optional[str] = None
) -> TunnelIDs:
    """IDs for a CNI tunnel (single tunnel pod using an existing NAD)."""
    key = f"cni/{namespace}/{owner}/{cni_name}/{cni_ns}"
    tid = _tid(key)
    tap_name = local_iface_name or f"tap-{tid}"
    return TunnelIDs(
        tid=tid,
        mode="cni",
        owner=owner,
        namespace=namespace,
        tunnel_pod_name=f"tunneler-{tid}",
        donor_pod_name=None,
        service_name=f"tunneler-svc-{tid}",
        nad_name=None,
        harvester_cluster_network_name=None,
        nad_bridge_name=None,
        local_tap_name=tap_name,
        node_port=_port(key),
        vxlan_id=_vxlan_id(key),
    )
