"""scripts.py — composable shell script fragments for pod init commands.

Fragments are string constants parametrised with .format(). Build functions
concatenate them into complete pod init scripts for each tunnel mode.

Double-braces {{}} in fragments produce literal {…} in the final shell script
after .format() is called.

NAT mode note
─────────────
The WireGuard server setup (_WG_SERVER_SETUP) automatically detects whether
the orchestrator wrote /tmp/dev_endpoint (NAT mode).  If present, it
configures the WG peer *with* an explicit endpoint so the pod initiates the
handshake, punching the NAT hole.  If absent (direct-route mode), the peer
is configured without an endpoint and the developer connects inbound.
No separate NAT-specific script build functions are needed.
"""

from k8s_l2_tunneler.config import WG_DEV_CLIENT_ID, WG_POD_CLIENT_ID
from k8s_l2_tunneler.net_ops import construct_ip_from_subnet, populate_subnet_ip

# ── Fragments ─────────────────────────────────────────────────────────────────
# Each fragment is a self-contained shell snippet ending with a newline.
# Parameters are written as {param_name}; literal braces are escaped as {{/}}.

_HEADER = "set -e\n\n"

_ENSURE_TUN = """\
echo '[pod] Ensuring /dev/net/tun exists...'
mkdir -p /dev/net
[ ! -c /dev/net/tun ] && mknod /dev/net/tun c 10 200
"""

_INSTALL_FULL = """\
echo '[pod] Installing packages (socat iproute2 bridge-utils tcpdump)...'
apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y socat iproute2 bridge-utils tcpdump 2>&1 | tail -5
"""

_INSTALL_MINIMAL = """\
echo '[pod] Installing packages (iproute2 bridge-utils tcpdump)...'
apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y iproute2 bridge-utils tcpdump 2>&1 | tail -5
"""

_INSTALL_WG = """\
echo '[pod] Installing packages (wireguard-tools iproute2 bridge-utils)...'
apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y wireguard-tools iproute2 bridge-utils tcpdump 2>&1 | tail -5
"""

# Parameters: iface, mtu
_WAIT_IFACE = """\
echo '[pod] Waiting for interface {iface}...'
i=0
while ! ip link show {iface} >/dev/null 2>&1; do
    i=$((i+1)); [ $i -ge 120 ] && echo "[error] {iface} never appeared" && exit 1; sleep 1
done
echo '[pod] Interface {iface} is up; setting MTU {mtu}.'
ip link set {iface} mtu {mtu} up
"""

# Parameters: port, mtu
# Starts socat in background, waits for tap0 to appear, then flushes the
# dummy address socat assigned so the caller can set the real one.
_SOCAT_START = """\
echo '[pod] Starting socat UDP listener on port {port}...'
socat "TUN:169.254.0.1/30,tun-type=tap,tun-name=tap0,iff-up,iff-no-pi" \
    "UDP4-LISTEN:{port},reuseaddr" &
SOCAT_PID=$!
echo '[pod] Waiting for tap0 to appear...'
i=0
while ! ip link show tap0 >/dev/null 2>&1; do
    i=$((i+1)); [ $i -ge 40 ] && echo "[error] tap0 never appeared" && exit 1; sleep 0.5
done
echo '[pod] tap0 appeared; flushing dummy address and setting MTU {mtu}.'
ip addr flush dev tap0
ip link set tap0 mtu {mtu} up
"""

# Parameters: port, vxlan_id, mtu
# Sets up WireGuard server + VXLAN.
#
# Key-exchange / NAT protocol
# ───────────────────────────
# /tmp/wg_keys_ready  — WG interface is up and listening; Python reads wg_pub
# /tmp/dev_pub        — developer's WG public key (written by Python via exec)
# /tmp/dev_endpoint   — [optional, NAT mode only] "DEV_IP:DEV_WG_PORT"
#                       written by Python; when present the pod configures the
#                       WG peer WITH an endpoint so it initiates the handshake,
#                       which punches the hole in the cluster-side NAT.
# /tmp/ready          — bridge up; Python can configure the local VXLAN
#
_WG_SERVER_SETUP = """\
echo '[pod] Starting WireGuard listener on port {port}...'
WG_PRIV=$(wg genkey)
WG_PUB=$(echo "$WG_PRIV" | wg pubkey)
echo "$WG_PUB" > /tmp/wg_pub
ip link add wg0 type wireguard
echo "$WG_PRIV" | wg set wg0 private-key /dev/stdin listen-port {port}
ip addr add {wg_pod_addr} dev wg0
ip link set wg0 up
touch /tmp/wg_keys_ready
echo '[pod] Waiting for orchestrator to write the developer public key...'
i=0
while [ ! -f /tmp/dev_pub ]; do
    i=$((i+1)); [ $i -ge 300 ] && echo "[error] dev_pub never appeared" && exit 1; sleep 1
done
echo '[pod] Configuring WireGuard peer...'
DEV_PUB=$(cat /tmp/dev_pub)
if [ -f /tmp/dev_endpoint ]; then
    DEV_EP=$(cat /tmp/dev_endpoint)
    echo "[pod] NAT mode detected — peer endpoint: $DEV_EP (pod will initiate handshake)"
    wg set wg0 peer "$DEV_PUB" allowed-ips 0.0.0.0/0 endpoint "$DEV_EP"
else
    wg set wg0 peer "$DEV_PUB" allowed-ips 0.0.0.0/0
fi
echo '[pod] Creating VXLAN interface and setting MTU {mtu}.'
ip link add vxlan0 type vxlan id {vxlan_id} remote {wg_dev_ip} dstport 4789 dev wg0
ip link set vxlan0 mtu {mtu} up
"""

# Parameters: bridge_iface, mtu
# Bridges tap0 to bridge_iface. Does NOT strip identity — caller composes that.
_BRIDGE_TAP0_TO = """\
echo '[pod] Creating bridge br0 (tap0 <-> {bridge_iface})...'
brctl addbr br0
brctl addif br0 tap0
brctl addif br0 {bridge_iface}
ip link set {bridge_iface} promisc on
ip link set br0 mtu {mtu} promisc on up
brctl setageing br0 0
echo '[pod] Bridge br0 is up.'
"""

# Parameters: bridge_iface, mtu
# Bridges vxlan0 to bridge_iface.
_BRIDGE_VXLAN0_TO = """\
echo '[pod] Bridging vxlan iface to: {bridge_iface} with mtu: {mtu}...'
brctl addbr br0
brctl addif br0 vxlan0
brctl addif br0 {bridge_iface}
ip link set {bridge_iface} promisc on
ip link set br0 mtu {mtu} promisc on up
brctl setageing br0 0
"""

# Parameters: iface
# Strips IP and replaces MAC with a locally-administered dummy.
_STRIP_IDENTITY = """\
echo '[pod] Stripping identity from {iface}...'
ip addr flush dev {iface}
ip link set {iface} down
ip link set {iface} address 02:00:00:00:00:02
ip link set {iface} up
echo '[pod] Identity stripped from {iface}.'
"""

# Parameters: mtu
# Auto-discovers the default-route interface, builds br-donor (net1 + donor_iface),
# and strips the donor interface's identity. The {{ }} escaping is intentional:
# .format(mtu=...) leaves the awk pattern as a literal {print $5} in the shell script.
_DONOR_BRIDGE = """\
echo '[pod] Discovering default-route interface...'
DONOR_IFACE=$(ip route show default | awk '/default/ {{print $5}}' | head -1)
echo "[pod] Donor interface: $DONOR_IFACE; creating br-donor bridge..."
brctl addbr br-donor
brctl addif br-donor "$DONOR_IFACE"
brctl addif br-donor net1
ip link set "$DONOR_IFACE" promisc on
ip link set net1 promisc on
echo '[pod] Stripping donor identity from '"$DONOR_IFACE"'...'
ip addr flush dev "$DONOR_IFACE"
ip link set "$DONOR_IFACE" down
ip link set "$DONOR_IFACE" address 02:00:00:00:00:02
ip link set "$DONOR_IFACE" mtu {mtu}
ip link set "$DONOR_IFACE" up
ip link set br-donor mtu {mtu} promisc on up
brctl setageing br-donor 0
echo '[pod] br-donor bridge is up.'
"""

# Parameters: sentinel
_SIGNAL = """\
echo '[pod] Signalling /tmp/{sentinel}...'
touch /tmp/{sentinel}
"""

# Parameters: sentinel
_WAIT_SENTINEL = """\
echo '[pod] Waiting for /tmp/{sentinel}...'
i=0
while [ ! -f /tmp/{sentinel} ]; do
    i=$((i+1)); [ $i -ge 300 ] && echo "[error] timed out waiting for {sentinel}" && exit 1; sleep 1
done
echo '[pod] /tmp/{sentinel} received.'
"""

_WAIT_SOCAT = """\
trap "echo '[pod] Termination received, exiting...'; exit 0" TERM

echo "[pod] Monitoring socat (PID: $SOCAT_PID)..."

# kill -0 returns 0 (true) if the process is running
while kill -0 "$SOCAT_PID" 2>/dev/null; do
    # We use 'sleep & wait' so the trap can interrupt the sleep immediately.
    sleep 0.5 & wait $!
done

echo "[pod] socat process died on its own. Exiting."
"""

# Parameters: mtu
#
# NAT-traversal variant of _SOCAT_START.  Instead of LISTENING for an inbound
# UDP connection from the developer (which requires the NodePort to be directly
# reachable), the pod connects OUTBOUND to the developer's socat listener.
#
# The outbound connection punches a hole in the cluster-side NAT:
#   pod_ip:SOCAT_EPHEMERAL_PORT → NAT → NAT_ext:X → dev_ip:DEV_PORT
#
# The developer's socat server (already listening when we write /tmp/dev_endpoint)
# replies through the same NAT mapping.  No separate probe is needed.
#
# Sentinel: writes /tmp/dev_endpoint (read by Python via exec, not here).
#           This script READS /tmp/dev_endpoint (written by Python).
#
_SOCAT_START_NAT = """\
echo '[pod] Waiting for orchestrator to write /tmp/dev_endpoint...'
i=0
while [ ! -f /tmp/dev_endpoint ]; do
    i=$((i+1)); [ $i -ge 300 ] && echo "[error] dev_endpoint never appeared" && exit 1; sleep 1
done
DEV_EP=$(cat /tmp/dev_endpoint)
DEV_IP=$(printf '%s' "$DEV_EP" | cut -d: -f1)
DEV_PORT=$(printf '%s' "$DEV_EP" | cut -d: -f2)
echo "[pod] Connecting socat outbound to developer at $DEV_IP:$DEV_PORT (punches NAT)..."
socat "TUN:169.254.0.1/30,tun-type=tap,tun-name=tap0,iff-up,iff-no-pi" \
    "UDP:${{DEV_IP}}:${{DEV_PORT}}" &
SOCAT_PID=$!
echo '[pod] Waiting for tap0 to appear...'
i=0
while ! ip link show tap0 >/dev/null 2>&1; do
    i=$((i+1)); [ $i -ge 40 ] && echo "[error] tap0 never appeared" && exit 1; sleep 0.5
done
echo '[pod] tap0 appeared; flushing dummy address and setting MTU {mtu}.'
ip addr flush dev tap0
ip link set tap0 mtu {mtu} up
"""

_SLEEP_FOREVER = """\
trap "exit 0" TERM
while true; do sleep 0.5 & wait $!; done
"""


# ── Build functions ───────────────────────────────────────────────────────────


def build_tunnel_cluster_script(port: int, mtu: int) -> str:
    """Tunnel pod (socat) for cluster mode: socat server + bridge(tap0 ↔ net1).

    net1 is the secondary interface injected by our new NAD (no identity
    to steal — the donor pod handles that). Signals /tmp/ready when the
    bridge is up and socat is listening.
    """
    return (
        _HEADER
        + _ENSURE_TUN
        + _INSTALL_FULL
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SOCAT_START.format(port=port, mtu=mtu)
        + _BRIDGE_TAP0_TO.format(bridge_iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SOCAT
    )


def build_tunnel_cluster_script_wg(port: int, mtu: int, vxlan_id: int, wg_subnet: str) -> str:
    """Tunnel pod (vxlan-wg) for cluster mode: WireGuard server + VXLAN + bridge(vxlan0 ↔ net1).

    Key exchange protocol:
      /tmp/wg_pub       — pod's WireGuard public key (read by Python via exec)
      /tmp/wg_keys_ready— WireGuard interface is up and listening
      /tmp/dev_pub      — developer's public key (written by Python via exec)
      /tmp/dev_endpoint — [NAT mode] developer's WG IP:port (written by Python)
      /tmp/ready        — bridge up; Python can configure local VXLAN
    """
    return (
        _HEADER
        + _INSTALL_WG
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _WG_SERVER_SETUP.format(
            port=port,
            vxlan_id=vxlan_id,
            mtu=mtu,
            wg_pod_addr=populate_subnet_ip(wg_subnet, WG_POD_CLIENT_ID),
            wg_dev_ip=construct_ip_from_subnet(wg_subnet, WG_DEV_CLIENT_ID),
        )
        + _BRIDGE_VXLAN0_TO.format(bridge_iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _SLEEP_FOREVER
    )


def build_donor_script(mtu: int) -> str:
    """Donor pod for cluster mode: auto-discovers its default interface,
    then bridges net1 ↔ donor_iface and strips donor_iface's identity.

    Sentinel protocol:
      /tmp/ready   — net1 appeared; Python can exec-read IP+MAC from donor_iface
      /tmp/proceed — written by Python after identity is read
      /tmp/done    — bridge setup complete; Python can proceed with local TAP
    """
    return (
        _HEADER
        + _INSTALL_MINIMAL
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SENTINEL.format(sentinel="proceed")
        + _DONOR_BRIDGE.format(mtu=mtu)
        + _SIGNAL.format(sentinel="done")
        + _SLEEP_FOREVER
    )


def build_tunnel_cni_script(port: int, mtu: int) -> str:
    """Tunnel pod (socat) for CNI mode: reads identity from net1, then bridges
    tap0 ↔ net1 and strips net1's identity.

    The existing CNI NAD provides net1. The pod's primary eth0 is untouched
    so the socat NodePort path stays alive throughout.

    Sentinel protocol:
      /tmp/ready   — net1 appeared; Python can exec-read IP+MAC from net1
      /tmp/proceed — written by Python after identity is read
      /tmp/done    — socat started, bridge up, net1 stripped; Python can configure TAP
    """
    return (
        _HEADER
        + _ENSURE_TUN
        + _INSTALL_FULL
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SENTINEL.format(sentinel="proceed")
        + _SOCAT_START.format(port=port, mtu=mtu)
        + _BRIDGE_TAP0_TO.format(bridge_iface="net1", mtu=mtu)
        + _STRIP_IDENTITY.format(iface="net1")
        + _SIGNAL.format(sentinel="done")
        + _WAIT_SOCAT
    )


def build_tunnel_cni_script_wg(port: int, mtu: int, vxlan_id: int, wg_subnet: str) -> str:
    """Tunnel pod (vxlan-wg) for CNI mode: reads identity from net1, then bridges
    vxlan0 ↔ net1 and strips net1's identity.

    Key exchange protocol:
      /tmp/wg_pub       — pod's WireGuard public key (read by Python via exec)
      /tmp/wg_keys_ready— WireGuard interface is up and listening
      /tmp/dev_pub      — developer's public key (written by Python via exec)
      /tmp/dev_endpoint — [NAT mode] developer's WG IP:port (written by Python)
      /tmp/ready        — net1 identity read, bridge up, net1 stripped; Python configures VXLAN
    """
    return (
        _HEADER
        + _INSTALL_WG
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SENTINEL.format(sentinel="proceed")
        + _WG_SERVER_SETUP.format(
            port=port,
            vxlan_id=vxlan_id,
            mtu=mtu,
            wg_pod_addr=populate_subnet_ip(wg_subnet, WG_POD_CLIENT_ID),
            wg_dev_ip=construct_ip_from_subnet(wg_subnet, WG_DEV_CLIENT_ID),
        )
        + _BRIDGE_VXLAN0_TO.format(bridge_iface="net1", mtu=mtu)
        + _STRIP_IDENTITY.format(iface="net1")
        + _SIGNAL.format(sentinel="done")
        + _SLEEP_FOREVER
    )


def build_tunnel_cluster_script_nat(mtu: int) -> str:
    """Tunnel pod (socat) for cluster mode — NAT traversal variant.

    Instead of listening for an inbound UDP connection, the pod connects
    OUTBOUND to the developer's socat listener.  This punches the hole in
    the cluster-side NAT without needing a separate probe:

      Developer opens: socat TUN:... UDP4-LISTEN:<DEV_PORT>,reuseaddr
      Pod opens:       socat TUN:... UDP:<DEV_IP>:<DEV_PORT>   ← outbound ← punches NAT

    The developer writes the endpoint to /tmp/dev_endpoint (via Python exec)
    after starting its own socat listener.

    Sentinel protocol:
      /tmp/dev_endpoint — written by Python; triggers socat connect
      /tmp/ready        — bridge up, socat running; Python configures local TAP
    """
    return (
        _HEADER
        + _ENSURE_TUN
        + _INSTALL_FULL
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SOCAT_START_NAT.format(mtu=mtu)
        + _BRIDGE_TAP0_TO.format(bridge_iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SOCAT
    )


def build_tunnel_cni_script_nat(mtu: int) -> str:
    """Tunnel pod (socat) for CNI mode — NAT traversal variant.

    Like build_tunnel_cluster_script_nat but for CNI mode: reads identity from
    net1, then bridges tap0 ↔ net1 and strips net1's identity.

    Sentinel protocol:
      /tmp/ready        — net1 appeared; Python can exec-read IP+MAC from net1
      /tmp/proceed      — written by Python after identity is read
      /tmp/dev_endpoint — written by Python; triggers socat connect
      /tmp/done         — bridge up, net1 stripped; Python configures local TAP
    """
    return (
        _HEADER
        + _ENSURE_TUN
        + _INSTALL_FULL
        + _WAIT_IFACE.format(iface="net1", mtu=mtu)
        + _SIGNAL.format(sentinel="ready")
        + _WAIT_SENTINEL.format(sentinel="proceed")
        + _SOCAT_START_NAT.format(mtu=mtu)
        + _BRIDGE_TAP0_TO.format(bridge_iface="net1", mtu=mtu)
        + _STRIP_IDENTITY.format(iface="net1")
        + _SIGNAL.format(sentinel="done")
        + _WAIT_SOCAT
    )
