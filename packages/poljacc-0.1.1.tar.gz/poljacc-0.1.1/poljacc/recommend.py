"""Recommendation logic based on vocabulary separability diagnostics."""

# Jaccard thresholds from the paper's empirical findings
HIGH_OVERLAP_THRESHOLD = 0.7
LOW_OVERLAP_THRESHOLD = 0.4

# Centroid distance threshold for secondary signal
CLOSE_CENTROID_THRESHOLD = 0.05

RECOMMENDATIONS = {
    "high": (
        "High vocabulary overlap (Jaccard > 0.7). "
        "Signal is likely distributed across many shared terms. "
        "TF-IDF recommended."
    ),
    "moderate": (
        "Moderate vocabulary overlap (0.4 < Jaccard <= 0.7). "
        "Consider both TF-IDF and neural models."
    ),
    "low": (
        "Low vocabulary overlap (Jaccard <= 0.4). "
        "Signal is likely concentrated in class-specific terms. "
        "Neural models may outperform TF-IDF."
    ),
}

CENTROID_CAVEAT_CLOSE = (
    " Note: TF-IDF centroids are close, suggesting subtle distributional "
    "differences -- dense representations may capture these better."
)

CENTROID_CAVEAT_FAR = (
    " Note: TF-IDF centroids are well-separated, reinforcing that "
    "sparse models should perform competitively."
)


def get_recommendation(mean_jaccard, mean_centroid_distance):
    """Generate a model recommendation from Jaccard and centroid distance.

    Args:
        mean_jaccard: Mean pairwise Jaccard similarity (0-1).
        mean_centroid_distance: Mean pairwise Euclidean centroid distance.

    Returns:
        Human-readable recommendation string.
    """
    if mean_jaccard > HIGH_OVERLAP_THRESHOLD:
        base = RECOMMENDATIONS["high"]
    elif mean_jaccard > LOW_OVERLAP_THRESHOLD:
        base = RECOMMENDATIONS["moderate"]
    else:
        base = RECOMMENDATIONS["low"]

    if mean_centroid_distance < CLOSE_CENTROID_THRESHOLD:
        return base + CENTROID_CAVEAT_CLOSE
    elif mean_jaccard > LOW_OVERLAP_THRESHOLD and mean_centroid_distance > 0.15:
        return base + CENTROID_CAVEAT_FAR
    return base
