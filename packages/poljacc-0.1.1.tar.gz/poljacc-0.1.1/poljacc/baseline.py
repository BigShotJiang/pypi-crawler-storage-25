"""TF-IDF + LogisticRegression one-click baseline."""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import (
    f1_score, accuracy_score, classification_report as sk_report,
    make_scorer,
)

from .utils import TFIDF_PARAMS, LOGREG_C_GRID, CV_FOLDS, RANDOM_SEED, is_binary, split_data


class ComparisonResult:
    """Container for TF-IDF baseline evaluation results.

    Attributes:
        f1: F1 score (binary F1 for two classes, macro F1 for multi-class).
        accuracy: Classification accuracy on the test set.
        classification_report: Formatted sklearn classification report string.
        best_C: Best regularization parameter from cross-validation.
        n_train: Number of training documents.
        n_test: Number of test documents.
    """

    def __init__(self, f1, accuracy, classification_report, best_C,
                 n_train, n_test):
        self.f1 = f1
        self.accuracy = accuracy
        self.classification_report = classification_report
        self.best_C = best_C
        self.n_train = n_train
        self.n_test = n_test

    def __repr__(self):
        return (
            f"ComparisonResult(f1={self.f1:.3f}, accuracy={self.accuracy:.3f}, "
            f"best_C={self.best_C}, n_train={self.n_train}, n_test={self.n_test})"
        )


def compare(texts, labels, test_size=0.2, val_size=None,
            random_state=RANDOM_SEED, groups=None, stratify_groups=False,
            test_texts=None, test_labels=None):
    """Run a TF-IDF + LogisticRegression baseline on labeled text data.

    By default, splits data internally. Pass test_texts and test_labels
    to use pre-split data instead (texts/labels become training data).

    Args:
        texts: List of text strings. Used as training data when
            test_texts is provided.
        labels: List of class labels (str or int), same length as texts.
            Used as training labels when test_labels is provided.
        test_size: Fraction of data reserved for testing (default 0.2).
            Ignored when test_texts is provided.
        val_size: Optional fraction for validation set.
        random_state: Random seed for reproducibility (default 1017).
        groups: Optional list of group identifiers for group-level splitting.
        stratify_groups: If True and groups is provided, use
            StratifiedGroupKFold to preserve label proportions.
        test_texts: Optional pre-split test texts. When provided,
            texts/labels are used as training data directly.
        test_labels: Optional pre-split test labels. Required if
            test_texts is provided.

    Returns:
        ComparisonResult with F1, accuracy, and full classification report.
    """
    if len(texts) != len(labels):
        raise ValueError(
            f"Length mismatch: {len(texts)} texts vs {len(labels)} labels."
        )

    np.random.seed(random_state)

    if test_texts is not None:
        if test_labels is None:
            raise ValueError("test_labels is required when test_texts is provided.")
        X_train = list(texts)
        y_train = list(labels)
        X_test = list(test_texts)
        y_test = list(test_labels)
        all_labels = list(labels) + list(test_labels)
    else:
        splits = split_data(
            texts, labels, test_size=test_size, val_size=val_size,
            random_state=random_state, groups=groups,
            stratify_groups=stratify_groups,
        )
        X_train = splits["train"]["texts"]
        y_train = splits["train"]["labels"]
        X_test = splits["test"]["texts"]
        y_test = splits["test"]["labels"]
        all_labels = labels

    vectorizer = TfidfVectorizer(**TFIDF_PARAMS)
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    unique_labels = sorted(set(all_labels), key=str)
    binary = is_binary(all_labels)

    if binary:
        pos_label = unique_labels[1]
        scorer = make_scorer(f1_score, pos_label=pos_label, average="binary")
        solver = "lbfgs"
    else:
        pos_label = None
        scorer = "f1_macro"
        solver = "saga"

    min_class_size = min(
        sum(1 for y in y_train if y == c) for c in unique_labels
    )
    n_folds = min(CV_FOLDS, min_class_size)
    if n_folds < 2:
        n_folds = 2

    grid = GridSearchCV(
        LogisticRegression(
            max_iter=5000, random_state=random_state, solver=solver,
        ),
        param_grid={"C": LOGREG_C_GRID},
        scoring=scorer,
        cv=n_folds,
        n_jobs=-1,
    )
    grid.fit(X_train_tfidf, y_train)

    best_model = grid.best_estimator_
    y_pred = best_model.predict(X_test_tfidf)

    if binary:
        f1 = f1_score(y_test, y_pred, pos_label=pos_label)
    else:
        f1 = f1_score(y_test, y_pred, average="macro")
    accuracy = accuracy_score(y_test, y_pred)
    report = sk_report(y_test, y_pred)

    return ComparisonResult(
        f1=f1,
        accuracy=accuracy,
        classification_report=report,
        best_C=grid.best_params_["C"],
        n_train=len(X_train),
        n_test=len(X_test),
    )
