"""Vocabulary separability diagnostics: Jaccard overlap and centroid distance."""

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from scipy.spatial.distance import euclidean

from .utils import TFIDF_PARAMS, RANDOM_SEED, split_data
from .recommend import get_recommendation


class DiagnosticResult:
    """Container for vocabulary separability diagnostic results.

    Attributes:
        jaccard: Mean pairwise Jaccard similarity across all class pairs.
        jaccard_matrix: Pairwise Jaccard similarity matrix (n_classes x n_classes).
        centroid_distance: Mean pairwise Euclidean centroid distance.
        centroid_matrix: Pairwise centroid distance matrix (n_classes x n_classes).
        labels: Unique class labels used in the analysis.
        recommendation: Human-readable model recommendation string.
        n_train: Number of training documents used for the diagnostic.
    """

    def __init__(self, jaccard, jaccard_matrix, centroid_distance,
                 centroid_matrix, labels, recommendation, n_train):
        self.jaccard = jaccard
        self.jaccard_matrix = jaccard_matrix
        self.centroid_distance = centroid_distance
        self.centroid_matrix = centroid_matrix
        self.labels = labels
        self.recommendation = recommendation
        self.n_train = n_train

    def report(self):
        """Print a formatted summary of the diagnostic results."""
        n_classes = len(self.labels)
        print("=" * 60)
        print("  poljacc: Vocabulary Separability Diagnostic")
        print("=" * 60)
        print(f"  Classes ({n_classes}): {', '.join(str(l) for l in self.labels)}")
        print(f"  Training documents:         {self.n_train}")
        print(f"  Mean Jaccard similarity:    {self.jaccard:.3f}")
        print(f"  Mean centroid distance:     {self.centroid_distance:.3f}")
        print("-" * 60)
        print(f"  Recommendation: {self.recommendation}")
        print("=" * 60)

    def plot(self, figsize=None):
        """Display diagnostic visualizations."""
        from .report import plot_diagnostics
        plot_diagnostics(self, figsize=figsize)


def _build_class_vocabularies(texts, labels, unique_labels, top_k):
    vocabularies = {}
    for label in unique_labels:
        class_texts = [t for t, l in zip(texts, labels) if l == label]
        cv = CountVectorizer(binary=True, max_features=top_k)
        cv.fit(class_texts)
        vocabularies[label] = set(cv.get_feature_names_out())
    return vocabularies


def _compute_jaccard_matrix(vocabularies, unique_labels):
    n = len(unique_labels)
    matrix = np.ones((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            vi = vocabularies[unique_labels[i]]
            vj = vocabularies[unique_labels[j]]
            intersection = len(vi & vj)
            union = len(vi | vj)
            jaccard = intersection / union if union > 0 else 0.0
            matrix[i, j] = jaccard
            matrix[j, i] = jaccard
    return matrix


def _compute_centroid_matrix(texts, labels, unique_labels):
    vectorizer = TfidfVectorizer(**TFIDF_PARAMS)
    tfidf = vectorizer.fit_transform(texts)
    labels_arr = np.array(labels)

    centroids = {}
    for label in unique_labels:
        mask = labels_arr == label
        centroids[label] = np.asarray(tfidf[mask].mean(axis=0)).flatten()

    n = len(unique_labels)
    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            dist = euclidean(centroids[unique_labels[i]], centroids[unique_labels[j]])
            matrix[i, j] = dist
            matrix[j, i] = dist
    return matrix


def _mean_off_diagonal(matrix):
    n = matrix.shape[0]
    if n < 2:
        return matrix[0, 0]
    indices = np.triu_indices(n, k=1)
    return float(np.mean(matrix[indices]))


def diagnose(texts, labels, top_k=5000, test_size=0.2, val_size=None,
             random_state=RANDOM_SEED, groups=None, stratify_groups=False,
             split=True):
    """Diagnose vocabulary separability between labeled text classes.

    By default, splits data and computes diagnostics on training data only
    to prevent information leakage. Set split=False to compute directly
    on the provided data (useful when you have pre-split training data).

    Args:
        texts: List of text strings.
        labels: List of class labels (str or int), same length as texts.
        top_k: Number of top terms (by document frequency) per class.
        test_size: Fraction of data held out for test (default 0.2).
        val_size: Optional fraction for validation set.
        random_state: Random seed (default 1017).
        groups: Optional list of group identifiers (e.g., congress number)
            for group-level splitting.
        stratify_groups: If True and groups is provided, use
            StratifiedGroupKFold to preserve label proportions.
        split: If True (default), split data and use training portion only.
            If False, compute diagnostics on all provided data as-is.

    Returns:
        DiagnosticResult with Jaccard and centroid distance metrics.
    """
    if len(texts) != len(labels):
        raise ValueError(
            f"Length mismatch: {len(texts)} texts vs {len(labels)} labels."
        )

    if split:
        splits = split_data(
            texts, labels, test_size=test_size, val_size=val_size,
            random_state=random_state, groups=groups,
            stratify_groups=stratify_groups,
        )
        train_texts = splits["train"]["texts"]
        train_labels = splits["train"]["labels"]
    else:
        train_texts = list(texts)
        train_labels = list(labels)

    unique_labels = sorted(set(train_labels), key=str)

    vocabularies = _build_class_vocabularies(
        train_texts, train_labels, unique_labels, top_k
    )
    jaccard_matrix = _compute_jaccard_matrix(vocabularies, unique_labels)
    centroid_matrix = _compute_centroid_matrix(
        train_texts, train_labels, unique_labels
    )

    mean_jaccard = _mean_off_diagonal(jaccard_matrix)
    mean_centroid = _mean_off_diagonal(centroid_matrix)

    recommendation = get_recommendation(mean_jaccard, mean_centroid)

    return DiagnosticResult(
        jaccard=mean_jaccard,
        jaccard_matrix=jaccard_matrix,
        centroid_distance=mean_centroid,
        centroid_matrix=centroid_matrix,
        labels=unique_labels,
        recommendation=recommendation,
        n_train=len(train_texts),
    )
