"""Visualization for vocabulary separability diagnostics."""

import numpy as np
import matplotlib.pyplot as plt


def _configure_academic_style():
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.dpi": 150,
    })


def _plot_binary(result, fig, axes):
    """Bar chart for binary classification diagnostics."""
    ax1, ax2 = axes

    labels_str = [str(l) for l in result.labels]
    pair_label = f"{labels_str[0]} vs {labels_str[1]}"

    ax1.bar([pair_label], [result.jaccard], color="#4a4a4a", width=0.4)
    ax1.set_ylabel("Jaccard Similarity")
    ax1.set_title("Vocabulary Overlap")
    ax1.set_ylim(0, 1)
    ax1.axhline(y=0.7, color="#999999", linestyle="--", linewidth=0.8, label="High (0.7)")
    ax1.axhline(y=0.4, color="#bbbbbb", linestyle="--", linewidth=0.8, label="Low (0.4)")
    ax1.legend(fontsize=8)
    ax1.bar_label(ax1.containers[0], fmt="%.3f", fontsize=9)

    ax2.bar([pair_label], [result.centroid_distance], color="#4a4a4a", width=0.4)
    ax2.set_ylabel("Euclidean Distance")
    ax2.set_title("TF-IDF Centroid Distance")
    ax2.bar_label(ax2.containers[0], fmt="%.3f", fontsize=9)


def _plot_multiclass(result, fig, axes):
    """Heatmaps for multi-class diagnostics."""
    ax1, ax2 = axes
    labels_str = [str(l) for l in result.labels]
    n = len(labels_str)

    for ax, matrix, title, cmap, vrange in [
        (ax1, result.jaccard_matrix, "Jaccard Similarity", "Greys", (0, 1)),
        (ax2, result.centroid_matrix, "TF-IDF Centroid Distance", "Greys", None),
    ]:
        vmin, vmax = vrange if vrange else (matrix.min(), matrix.max())
        im = ax.imshow(matrix, cmap=cmap, vmin=vmin, vmax=vmax, aspect="equal")
        ax.set_xticks(range(n))
        ax.set_xticklabels(labels_str, rotation=45, ha="right", fontsize=9)
        ax.set_yticks(range(n))
        ax.set_yticklabels(labels_str, fontsize=9)
        ax.set_title(title)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

        for i in range(n):
            for j in range(n):
                color = "white" if matrix[i, j] > (vmin + vmax) / 2 else "black"
                ax.text(j, i, f"{matrix[i, j]:.2f}", ha="center", va="center",
                        fontsize=8, color=color)


def plot_diagnostics(result, figsize=None):
    """Plot vocabulary separability diagnostics.

    For binary tasks: bar chart showing Jaccard similarity and centroid distance.
    For multi-class tasks: heatmaps of pairwise Jaccard and centroid matrices.

    Args:
        result: DiagnosticResult from diagnose().
        figsize: Optional (width, height) tuple for the figure.
    """
    _configure_academic_style()

    is_binary = len(result.labels) == 2
    if figsize is None:
        figsize = (8, 3.5) if is_binary else (10, 4.5)

    fig, axes = plt.subplots(1, 2, figsize=figsize)

    if is_binary:
        _plot_binary(result, fig, axes)
    else:
        _plot_multiclass(result, fig, axes)

    fig.suptitle("poljacc: Vocabulary Separability Diagnostic", fontsize=12, y=1.02)
    fig.tight_layout()
    plt.show()
