"""poljacc: Vocabulary separability diagnostics for text classification.

Companion package for "When Sparse Beats Dense" (Political Analysis).
Computes Jaccard-based vocabulary overlap between classes and recommends
whether TF-IDF or neural/dense models are appropriate.
"""

from .diagnostics import diagnose, DiagnosticResult
from .baseline import compare, ComparisonResult
from .report import plot_diagnostics

__version__ = "0.1.0"


def analyze(texts, labels, top_k=5000, test_size=0.2, val_size=None,
            random_state=1017, groups=None, stratify_groups=False,
            test_texts=None, test_labels=None):
    """Run diagnostic and TF-IDF baseline together.

    Two modes of operation:

    1. Auto-split (default): pass all data, let poljacc split internally.
       diag, comp = poljacc.analyze(texts, labels, test_size=0.1)

    2. Pre-split: pass training data as texts/labels, test data separately.
       diag, comp = analyze(train_texts, train_labels,
                            test_texts=test_texts, test_labels=test_labels)

    Args:
        texts: List of text strings. Training data when test_texts is given.
        labels: List of class labels. Training labels when test_labels is given.
        top_k: Number of top terms per class for Jaccard (default 5000).
        test_size: Fraction held out for testing (default 0.2).
        val_size: Optional fraction for validation set.
        random_state: Random seed (default 1017).
        groups: Optional list of group identifiers (e.g., congress number).
        stratify_groups: If True, use StratifiedGroupKFold.
        test_texts: Optional pre-split test texts.
        test_labels: Optional pre-split test labels.

    Returns:
        Tuple of (DiagnosticResult, ComparisonResult).
    """
    pre_split = test_texts is not None

    diag = diagnose(
        texts, labels, top_k=top_k,
        test_size=test_size, val_size=val_size,
        random_state=random_state, groups=groups,
        stratify_groups=stratify_groups,
        split=not pre_split,
    )
    comp = compare(
        texts, labels, test_size=test_size, val_size=val_size,
        random_state=random_state, groups=groups,
        stratify_groups=stratify_groups,
        test_texts=test_texts, test_labels=test_labels,
    )
    return diag, comp


__all__ = [
    "diagnose",
    "compare",
    "analyze",
    "plot_diagnostics",
    "DiagnosticResult",
    "ComparisonResult",
]
