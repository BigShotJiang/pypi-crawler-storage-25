"""Shared utilities for poljacc."""

import numpy as np

RANDOM_SEED = 1017

TFIDF_PARAMS = {
    "ngram_range": (1, 2),
    "max_features": 50000,
    "sublinear_tf": True,
}

LOGREG_C_GRID = [0.01, 0.1, 1, 10, 100]
CV_FOLDS = 5


def set_seed(seed=RANDOM_SEED):
    np.random.seed(seed)


def is_binary(labels):
    return len(set(labels)) == 2


def split_data(texts, labels, test_size=0.2, val_size=None,
               random_state=RANDOM_SEED, groups=None, stratify_groups=False):
    """Split data into train(/val)/test sets.

    Supports four split strategies:
        1. groups=None: random stratified split by labels (default)
        2. groups + stratify_groups=False: GroupShuffleSplit (group-level)
        3. groups + stratify_groups=True: StratifiedGroupKFold
           (group-level split preserving label proportions)

    Args:
        texts: List of text strings.
        labels: List of class labels.
        test_size: Fraction for test set (default 0.2).
        val_size: Optional fraction for validation set. When provided,
            returns a three-way split (train/val/test).
        random_state: Random seed (default 1017).
        groups: Optional list of group identifiers (e.g., congress number).
        stratify_groups: If True and groups is provided, use
            StratifiedGroupKFold to preserve label proportions within
            the group-level split.

    Returns:
        Dict with keys 'train', 'test', and optionally 'val'.
        Each value is a dict with 'texts', 'labels', and 'indices'.
    """
    n = len(texts)
    all_idx = np.arange(n)
    texts_arr = np.array(texts, dtype=object)
    labels_arr = np.array(labels, dtype=object)
    groups_arr = np.array(groups) if groups is not None else None

    if groups is not None and stratify_groups:
        from sklearn.model_selection import StratifiedGroupKFold
        n_splits = max(2, round(1.0 / test_size))
        sgkf = StratifiedGroupKFold(
            n_splits=n_splits, shuffle=True, random_state=random_state,
        )
        train_val_idx, test_idx = next(
            sgkf.split(all_idx, labels_arr, groups_arr)
        )

        if val_size is not None:
            val_ratio = val_size / (1.0 - test_size)
            n_val_splits = max(2, round(1.0 / val_ratio))
            sgkf2 = StratifiedGroupKFold(
                n_splits=n_val_splits, shuffle=True,
                random_state=random_state + 1,
            )
            train_idx, val_idx = next(
                sgkf2.split(
                    train_val_idx,
                    labels_arr[train_val_idx],
                    groups_arr[train_val_idx],
                )
            )
            train_idx = train_val_idx[train_idx]
            val_idx = train_val_idx[val_idx]
        else:
            train_idx = train_val_idx
            val_idx = None

    elif groups is not None:
        from sklearn.model_selection import GroupShuffleSplit
        gss = GroupShuffleSplit(
            n_splits=1, test_size=test_size, random_state=random_state,
        )
        train_val_idx, test_idx = next(
            gss.split(all_idx, labels_arr, groups_arr)
        )

        if val_size is not None:
            val_ratio = val_size / (1.0 - test_size)
            gss2 = GroupShuffleSplit(
                n_splits=1, test_size=val_ratio,
                random_state=random_state + 1,
            )
            train_idx, val_idx = next(
                gss2.split(
                    train_val_idx,
                    labels_arr[train_val_idx],
                    groups_arr[train_val_idx],
                )
            )
            train_idx = train_val_idx[train_idx]
            val_idx = train_val_idx[val_idx]
        else:
            train_idx = train_val_idx
            val_idx = None

    else:
        from sklearn.model_selection import train_test_split
        train_val_idx, test_idx = train_test_split(
            all_idx, test_size=test_size,
            random_state=random_state, stratify=labels_arr,
        )

        if val_size is not None:
            val_ratio = val_size / (1.0 - test_size)
            train_idx, val_idx = train_test_split(
                train_val_idx, test_size=val_ratio,
                random_state=random_state + 1,
                stratify=labels_arr[train_val_idx],
            )
        else:
            train_idx = train_val_idx
            val_idx = None

    result = {
        "train": {
            "texts": texts_arr[train_idx].tolist(),
            "labels": labels_arr[train_idx].tolist(),
            "indices": train_idx,
        },
        "test": {
            "texts": texts_arr[test_idx].tolist(),
            "labels": labels_arr[test_idx].tolist(),
            "indices": test_idx,
        },
    }

    if val_idx is not None:
        result["val"] = {
            "texts": texts_arr[val_idx].tolist(),
            "labels": labels_arr[val_idx].tolist(),
            "indices": val_idx,
        }

    return result
