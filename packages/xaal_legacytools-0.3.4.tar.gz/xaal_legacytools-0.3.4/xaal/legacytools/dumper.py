# -*- coding: utf-8 -*-


from xaal.lib import Engine, Message, helpers

helpers.set_console_title("xaal-dumper")


def display(msg: Message):
    msg.dump()


def main():
    try:
        eng = Engine()
        eng.subscribe(display)
        eng.disable_msg_filter()
        eng.run()
    except KeyboardInterrupt:
        print("Bye Bye")


if __name__ == '__main__':
    main()
