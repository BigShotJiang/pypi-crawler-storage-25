"""
Type annotations for evs service Client.

[Documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from boto3.session import Session
    from mypy_boto3_evs.client import EVSClient

    session = Session()
    client: EVSClient = session.client("evs")
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from typing import Any, overload

from botocore.client import BaseClient, ClientMeta
from botocore.errorfactory import BaseClientExceptions
from botocore.exceptions import ClientError as BotocoreClientError

from .paginator import (
    ListEnvironmentConnectorsPaginator,
    ListEnvironmentHostsPaginator,
    ListEnvironmentsPaginator,
    ListEnvironmentVlansPaginator,
    ListVmEntitlementsPaginator,
)
from .type_defs import (
    AssociateEipToVlanRequestTypeDef,
    AssociateEipToVlanResponseTypeDef,
    CreateEntitlementRequestTypeDef,
    CreateEntitlementResponseTypeDef,
    CreateEnvironmentConnectorRequestTypeDef,
    CreateEnvironmentConnectorResponseTypeDef,
    CreateEnvironmentHostRequestTypeDef,
    CreateEnvironmentHostResponseTypeDef,
    CreateEnvironmentRequestTypeDef,
    CreateEnvironmentResponseTypeDef,
    DeleteEntitlementRequestTypeDef,
    DeleteEntitlementResponseTypeDef,
    DeleteEnvironmentConnectorRequestTypeDef,
    DeleteEnvironmentConnectorResponseTypeDef,
    DeleteEnvironmentHostRequestTypeDef,
    DeleteEnvironmentHostResponseTypeDef,
    DeleteEnvironmentRequestTypeDef,
    DeleteEnvironmentResponseTypeDef,
    DisassociateEipFromVlanRequestTypeDef,
    DisassociateEipFromVlanResponseTypeDef,
    GetDepotUrlRequestTypeDef,
    GetDepotUrlResponseTypeDef,
    GetEnvironmentRequestTypeDef,
    GetEnvironmentResponseTypeDef,
    GetVersionsResponseTypeDef,
    ListEnvironmentConnectorsRequestTypeDef,
    ListEnvironmentConnectorsResponseTypeDef,
    ListEnvironmentHostsRequestTypeDef,
    ListEnvironmentHostsResponseTypeDef,
    ListEnvironmentsRequestTypeDef,
    ListEnvironmentsResponseTypeDef,
    ListEnvironmentVlansRequestTypeDef,
    ListEnvironmentVlansResponseTypeDef,
    ListTagsForResourceRequestTypeDef,
    ListTagsForResourceResponseTypeDef,
    ListVmEntitlementsRequestTypeDef,
    ListVmEntitlementsResponseTypeDef,
    TagResourceRequestTypeDef,
    UntagResourceRequestTypeDef,
    UpdateEnvironmentConnectorRequestTypeDef,
    UpdateEnvironmentConnectorResponseTypeDef,
)

if sys.version_info >= (3, 12):
    from typing import Literal, Unpack
else:
    from typing_extensions import Literal, Unpack

__all__ = ("EVSClient",)

class Exceptions(BaseClientExceptions):
    ClientError: type[BotocoreClientError]
    InternalServerException: type[BotocoreClientError]
    ResourceNotFoundException: type[BotocoreClientError]
    ServiceQuotaExceededException: type[BotocoreClientError]
    TagPolicyException: type[BotocoreClientError]
    ThrottlingException: type[BotocoreClientError]
    TooManyTagsException: type[BotocoreClientError]
    ValidationException: type[BotocoreClientError]

class EVSClient(BaseClient):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs.html#EVS.Client)
    [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/)
    """

    meta: ClientMeta

    @property
    def exceptions(self) -> Exceptions:
        """
        EVSClient exceptions.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs.html#EVS.Client)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#exceptions)
        """

    def can_paginate(self, operation_name: str) -> bool:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/can_paginate.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#can_paginate)
        """

    def generate_presigned_url(
        self,
        ClientMethod: str,
        Params: Mapping[str, Any] = ...,
        ExpiresIn: int = 3600,
        HttpMethod: str = ...,
    ) -> str:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/generate_presigned_url.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#generate_presigned_url)
        """

    def associate_eip_to_vlan(
        self, **kwargs: Unpack[AssociateEipToVlanRequestTypeDef]
    ) -> AssociateEipToVlanResponseTypeDef:
        """
        Associates an Elastic IP address with a public HCX VLAN.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/associate_eip_to_vlan.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#associate_eip_to_vlan)
        """

    def create_entitlement(
        self, **kwargs: Unpack[CreateEntitlementRequestTypeDef]
    ) -> CreateEntitlementResponseTypeDef:
        """
        Creates a Windows Server License entitlement for virtual machines in an Amazon
        EVS environment using the provided vCenter Server connector.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/create_entitlement.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#create_entitlement)
        """

    def create_environment(
        self, **kwargs: Unpack[CreateEnvironmentRequestTypeDef]
    ) -> CreateEnvironmentResponseTypeDef:
        """
        Creates an Amazon EVS environment that runs VCF software, such as SDDC Manager,
        NSX Manager, and vCenter Server.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/create_environment.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#create_environment)
        """

    def create_environment_connector(
        self, **kwargs: Unpack[CreateEnvironmentConnectorRequestTypeDef]
    ) -> CreateEnvironmentConnectorResponseTypeDef:
        """
        Creates a connector for an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/create_environment_connector.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#create_environment_connector)
        """

    def create_environment_host(
        self, **kwargs: Unpack[CreateEnvironmentHostRequestTypeDef]
    ) -> CreateEnvironmentHostResponseTypeDef:
        """
        Creates an ESX host and adds it to an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/create_environment_host.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#create_environment_host)
        """

    def delete_entitlement(
        self, **kwargs: Unpack[DeleteEntitlementRequestTypeDef]
    ) -> DeleteEntitlementResponseTypeDef:
        """
        Deletes a Windows Server License entitlement for virtual machines in an Amazon
        EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/delete_entitlement.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#delete_entitlement)
        """

    def delete_environment(
        self, **kwargs: Unpack[DeleteEnvironmentRequestTypeDef]
    ) -> DeleteEnvironmentResponseTypeDef:
        """
        Deletes an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/delete_environment.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#delete_environment)
        """

    def delete_environment_connector(
        self, **kwargs: Unpack[DeleteEnvironmentConnectorRequestTypeDef]
    ) -> DeleteEnvironmentConnectorResponseTypeDef:
        """
        Deletes a connector from an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/delete_environment_connector.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#delete_environment_connector)
        """

    def delete_environment_host(
        self, **kwargs: Unpack[DeleteEnvironmentHostRequestTypeDef]
    ) -> DeleteEnvironmentHostResponseTypeDef:
        """
        Deletes a host from an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/delete_environment_host.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#delete_environment_host)
        """

    def disassociate_eip_from_vlan(
        self, **kwargs: Unpack[DisassociateEipFromVlanRequestTypeDef]
    ) -> DisassociateEipFromVlanResponseTypeDef:
        """
        Disassociates an Elastic IP address from a public HCX VLAN.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/disassociate_eip_from_vlan.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#disassociate_eip_from_vlan)
        """

    def get_depot_url(
        self, **kwargs: Unpack[GetDepotUrlRequestTypeDef]
    ) -> GetDepotUrlResponseTypeDef:
        """
        Returns a URL and authentication token for accessing the Amazon EVS Custom
        Addon depot.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_depot_url.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_depot_url)
        """

    def get_environment(
        self, **kwargs: Unpack[GetEnvironmentRequestTypeDef]
    ) -> GetEnvironmentResponseTypeDef:
        """
        Returns a description of the specified environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_environment.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_environment)
        """

    def get_versions(self) -> GetVersionsResponseTypeDef:
        """
        Returns information about VCF versions, ESX versions and EC2 instance types
        provided by Amazon EVS.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_versions.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_versions)
        """

    def list_environment_connectors(
        self, **kwargs: Unpack[ListEnvironmentConnectorsRequestTypeDef]
    ) -> ListEnvironmentConnectorsResponseTypeDef:
        """
        Lists the connectors within an environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_environment_connectors.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_environment_connectors)
        """

    def list_environment_hosts(
        self, **kwargs: Unpack[ListEnvironmentHostsRequestTypeDef]
    ) -> ListEnvironmentHostsResponseTypeDef:
        """
        List the hosts within an environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_environment_hosts.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_environment_hosts)
        """

    def list_environment_vlans(
        self, **kwargs: Unpack[ListEnvironmentVlansRequestTypeDef]
    ) -> ListEnvironmentVlansResponseTypeDef:
        """
        Lists environment VLANs that are associated with the specified environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_environment_vlans.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_environment_vlans)
        """

    def list_environments(
        self, **kwargs: Unpack[ListEnvironmentsRequestTypeDef]
    ) -> ListEnvironmentsResponseTypeDef:
        """
        Lists the Amazon EVS environments in your Amazon Web Services account in the
        specified Amazon Web Services Region.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_environments.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_environments)
        """

    def list_tags_for_resource(
        self, **kwargs: Unpack[ListTagsForResourceRequestTypeDef]
    ) -> ListTagsForResourceResponseTypeDef:
        """
        Lists the tags for an Amazon EVS resource.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_tags_for_resource.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_tags_for_resource)
        """

    def list_vm_entitlements(
        self, **kwargs: Unpack[ListVmEntitlementsRequestTypeDef]
    ) -> ListVmEntitlementsResponseTypeDef:
        """
        Lists the Windows Server License entitlements for virtual machines in an Amazon
        EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/list_vm_entitlements.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#list_vm_entitlements)
        """

    def tag_resource(self, **kwargs: Unpack[TagResourceRequestTypeDef]) -> dict[str, Any]:
        """
        Associates the specified tags to an Amazon EVS resource with the specified
        <code>resourceArn</code>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/tag_resource.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#tag_resource)
        """

    def untag_resource(self, **kwargs: Unpack[UntagResourceRequestTypeDef]) -> dict[str, Any]:
        """
        Deletes specified tags from an Amazon EVS resource.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/untag_resource.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#untag_resource)
        """

    def update_environment_connector(
        self, **kwargs: Unpack[UpdateEnvironmentConnectorRequestTypeDef]
    ) -> UpdateEnvironmentConnectorResponseTypeDef:
        """
        Updates a connector for an Amazon EVS environment.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/update_environment_connector.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#update_environment_connector)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_environment_connectors"]
    ) -> ListEnvironmentConnectorsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_paginator.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_environment_hosts"]
    ) -> ListEnvironmentHostsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_paginator.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_environment_vlans"]
    ) -> ListEnvironmentVlansPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_paginator.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_environments"]
    ) -> ListEnvironmentsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_paginator.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_vm_entitlements"]
    ) -> ListVmEntitlementsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/evs/client/get_paginator.html)
        [Show boto3-stubs documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_evs/client/#get_paginator)
        """
