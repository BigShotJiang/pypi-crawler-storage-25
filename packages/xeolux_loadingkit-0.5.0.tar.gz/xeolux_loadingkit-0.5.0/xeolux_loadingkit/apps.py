from django.apps import AppConfig


class XeoluxLoadingKitConfig(AppConfig):
    name = "xeolux_loadingkit"
    verbose_name = "Xeolux LoadingKit"
