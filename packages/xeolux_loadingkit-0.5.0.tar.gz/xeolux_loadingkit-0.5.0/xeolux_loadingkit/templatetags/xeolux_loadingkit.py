from django import template
from django.templatetags.static import static
from django.utils.html import format_html

register = template.Library()

_MAX_TEXT_LEN = 200  # longueur max d'un texte utilisateur
_MAX_LINES = 20      # borne haute pour éviter un DoS via boucle de rendu
_MAX_ROWS = 50


def _safe_text(value, default="", max_len=_MAX_TEXT_LEN):
    """Convertit en str, strip, tronque — n'accepte jamais None passé tel quel."""
    if value is None:
        return default
    return str(value).strip()[:max_len]


def _safe_int(value, default, min_val=1, max_val=_MAX_LINES):
    """Convertit en int de manière sûre avec bornes min/max."""
    try:
        return max(min_val, min(int(value), max_val))
    except (TypeError, ValueError):
        return default


@register.simple_tag
def xeolux_loadingkit_css():
    """Injecte la feuille de style CSS du package."""
    url = static("xeolux_loadingkit/css/loadingkit.css")
    return format_html('<link rel="stylesheet" href="{}">', url)


@register.inclusion_tag("xeolux_loadingkit/loader.html")
def xeolux_loader(size="md", text=None):
    """
    Affiche un spinner de chargement.

    Args:
        size (str): Taille du spinner — "sm", "md" ou "lg". Défaut : "md".
        text (str|None): Texte optionnel affiché sous le spinner.
    """
    valid_sizes = ("sm", "md", "lg")
    if size not in valid_sizes:
        size = "md"
    return {"size": size, "text": _safe_text(text) or None}


@register.inclusion_tag("xeolux_loadingkit/overlay.html")
def xeolux_overlay(text="Chargement en cours...", active=False):
    """
    Affiche un overlay plein écran.

    Args:
        text (str): Texte affiché dans l'overlay. Défaut : "Chargement en cours...".
        active (bool): Si True, l'overlay est visible. Défaut : False.
    """
    return {
        "text": _safe_text(text, default="Chargement en cours..."),
        "active": bool(active),
    }


@register.inclusion_tag("xeolux_loadingkit/skeleton.html")
def xeolux_skeleton(type="text", lines=3, rows=4, format="landscape"):
    """
    Affiche un skeleton loader.

    Args:
        type (str): Type de skeleton — "text", "card", "avatar", "table", "form",
                    "list", "image". Défaut : "text".
        lines (int): Nombre de lignes pour "text" / "form", colonnes pour "table",
                     items pour "list". Défaut : 3.
        rows (int): Nombre de rangées pour "table". Défaut : 4.
        format (str): Format de l'image pour type="image" —
                      "square", "landscape", "portrait", "panoramic", "thumbnail".
                      Défaut : "landscape".
    """
    valid_types = (
        "text", "card", "avatar", "table", "form", "list", "image",
        "nav", "footer", "dashboard", "product", "profile",
    )
    if type not in valid_types:
        type = "text"
    valid_formats = ("square", "landscape", "portrait", "panoramic", "thumbnail")
    if format not in valid_formats:
        format = "landscape"
    lines = _safe_int(lines, default=3, min_val=1, max_val=_MAX_LINES)
    rows = _safe_int(rows, default=4, min_val=1, max_val=_MAX_ROWS)
    return {
        "type": type,
        "lines": lines,
        "rows": rows,
        "format": format,
        "lines_range": range(lines),
        "rows_range": range(rows),
    }


@register.inclusion_tag("xeolux_loadingkit/htmx_indicator.html")
def xeolux_htmx_indicator(text="Chargement..."):
    """
    Affiche un indicateur HTMX masqué par défaut, visible lors d'une requête HTMX.

    Args:
        text (str): Texte affiché pendant le chargement. Défaut : "Chargement...".
    """
    return {"text": _safe_text(text, default="Chargement...")}


@register.inclusion_tag("xeolux_loadingkit/progress.html")
def xeolux_progress(value=0, label=None, animated=True, striped=False):
    """
    Affiche une barre de progression.

    Args:
        value (int|float): Valeur entre 0 et 100. Défaut : 0.
        label (str|None): Texte affiché au-dessus de la barre. Défaut : None.
        animated (bool): Active l'animation de brillance sur le remplissage. Défaut : True.
        striped (bool): Active le motif rayé. Défaut : False.
    """
    try:
        value = max(0, min(float(value), 100))
    except (TypeError, ValueError):
        value = 0
    # Arrondi à 1 décimale pour l'affichage du pourcentage
    display = int(value) if value == int(value) else round(value, 1)
    return {
        "value": value,
        "display": display,
        "label": _safe_text(label) or None,
        "animated": bool(animated),
        "striped": bool(striped),
    }


@register.inclusion_tag("xeolux_loadingkit/topbar.html")
def xeolux_topbar(active=False, done=False, animated=True):
    """
    Affiche une barre fine en haut de page (style NProgress / YouTube).

    Usage JavaScript recommandé :
        const bar = document.querySelector('.xlk-topbar');
        bar.classList.add('xlk-topbar--active');      // démarrer
        bar.classList.add('xlk-topbar--done');         // terminer
        setTimeout(() => bar.classList.remove('xlk-topbar--active', 'xlk-topbar--done'), 700);

    Args:
        active (bool): Si True, la barre est en cours de chargement. Défaut : False.
        done (bool): Si True, la barre atteint 100% et disparaît. Défaut : False.
        animated (bool): Active l'effet shimmer. Défaut : True.
    """
    return {
        "active": bool(active),
        "done": bool(done),
        "animated": bool(animated),
    }
