"""
Tests for xeolux_loadingkit template tags.

Run with:
    python -m pytest tests/ -v
or:
    python -m django test --settings=tests.settings tests
"""
import django
from django.conf import settings

if not settings.configured:
    settings.configure(
        INSTALLED_APPS=[
            "django.contrib.staticfiles",
            "xeolux_loadingkit",
        ],
        TEMPLATES=[
            {
                "BACKEND": "django.template.backends.django.DjangoTemplates",
                "DIRS": [],
                "APP_DIRS": True,
                "OPTIONS": {
                    "context_processors": [],
                },
            }
        ],
        STATIC_URL="/static/",
        DATABASES={},
    )
    django.setup()

from django.test import SimpleTestCase
from django.template import Context, Template


def render(template_str: str, context: dict | None = None) -> str:
    """Helper : compile et rend un template Django inline."""
    tpl = Template("{% load xeolux_loadingkit %}" + template_str)
    return tpl.render(Context(context or {}))


class LoadingKitCSSTagTest(SimpleTestCase):
    def test_css_tag_renders_link(self):
        output = render("{% xeolux_loadingkit_css %}")
        self.assertIn("<link", output)
        self.assertIn("loadingkit.css", output)
        self.assertIn('rel="stylesheet"', output)


class LoaderTagTest(SimpleTestCase):
    def test_default_render(self):
        output = render("{% xeolux_loader %}")
        self.assertIn("xlk-loader", output)
        self.assertIn("xlk-loader--md", output)
        self.assertIn("xlk-spinner", output)
        self.assertIn('role="status"', output)

    def test_size_sm(self):
        output = render('{% xeolux_loader size="sm" %}')
        self.assertIn("xlk-loader--sm", output)

    def test_size_lg(self):
        output = render('{% xeolux_loader size="lg" %}')
        self.assertIn("xlk-loader--lg", output)

    def test_invalid_size_fallback_to_md(self):
        output = render('{% xeolux_loader size="xxl" %}')
        self.assertIn("xlk-loader--md", output)

    def test_text_is_rendered(self):
        output = render('{% xeolux_loader text="Chargement..." %}')
        self.assertIn("Chargement...", output)
        self.assertIn("xlk-loader__text", output)

    def test_no_text_no_text_element(self):
        output = render("{% xeolux_loader %}")
        self.assertNotIn("xlk-loader__text", output)


class OverlayTagTest(SimpleTestCase):
    def test_default_render_inactive(self):
        output = render("{% xeolux_overlay %}")
        self.assertIn("xlk-overlay", output)
        self.assertNotIn("xlk-overlay--active", output)
        self.assertIn('aria-hidden="true"', output)

    def test_active_overlay(self):
        output = render("{% xeolux_overlay active=True %}")
        self.assertIn("xlk-overlay--active", output)
        # Le conteneur principal ne doit pas avoir aria-hidden quand actif.
        # (Le spinner interne a toujours aria-hidden="true", c'est voulu.)
        self.assertNotIn('aria-hidden="true" aria-label', output)

    def test_custom_text(self):
        output = render('{% xeolux_overlay text="Traitement en cours..." %}')
        self.assertIn("Traitement en cours...", output)


class SkeletonTagTest(SimpleTestCase):
    def test_text_type_default(self):
        output = render("{% xeolux_skeleton %}")
        self.assertIn("xlk-skeleton--text", output)
        self.assertIn("xlk-skeleton__line", output)
        self.assertIn('aria-hidden="true"', output)

    def test_card_type(self):
        output = render('{% xeolux_skeleton type="card" %}')
        self.assertIn("xlk-skeleton--card", output)
        self.assertIn("xlk-skeleton__card-image", output)

    def test_avatar_type(self):
        output = render('{% xeolux_skeleton type="avatar" %}')
        self.assertIn("xlk-skeleton--avatar", output)
        self.assertIn("xlk-skeleton__avatar-circle", output)

    def test_table_type(self):
        output = render('{% xeolux_skeleton type="table" %}')
        self.assertIn("xlk-skeleton--table", output)
        self.assertIn("xlk-skeleton__table-row", output)

    def test_form_type(self):
        output = render('{% xeolux_skeleton type="form" %}')
        self.assertIn("xlk-skeleton--form", output)
        self.assertIn("xlk-skeleton__input", output)
        self.assertIn("xlk-skeleton__button", output)

    def test_list_type(self):
        output = render('{% xeolux_skeleton type="list" %}')
        self.assertIn("xlk-skeleton--list", output)
        self.assertIn("xlk-skeleton__list-item", output)
        self.assertIn("xlk-skeleton__list-icon", output)
        self.assertIn("xlk-skeleton__list-content", output)

    def test_list_type_custom_lines(self):
        output = render('{% xeolux_skeleton type="list" lines=5 %}')
        self.assertIn("xlk-skeleton--list", output)
        self.assertEqual(output.count("xlk-skeleton__list-item"), 5)

    def test_image_type_default_landscape(self):
        output = render('{% xeolux_skeleton type="image" %}')
        self.assertIn("xlk-skeleton--image", output)
        self.assertIn("xlk-skeleton--image-landscape", output)
        self.assertIn("xlk-skeleton__image-block", output)
        self.assertIn('aria-hidden="true"', output)

    def test_image_type_square(self):
        output = render('{% xeolux_skeleton type="image" format="square" %}')
        self.assertIn("xlk-skeleton--image-square", output)

    def test_image_type_portrait(self):
        output = render('{% xeolux_skeleton type="image" format="portrait" %}')
        self.assertIn("xlk-skeleton--image-portrait", output)

    def test_image_type_panoramic(self):
        output = render('{% xeolux_skeleton type="image" format="panoramic" %}')
        self.assertIn("xlk-skeleton--image-panoramic", output)

    def test_image_type_thumbnail(self):
        output = render('{% xeolux_skeleton type="image" format="thumbnail" %}')
        self.assertIn("xlk-skeleton--image-thumbnail", output)

    def test_image_invalid_format_fallback_to_landscape(self):
        output = render('{% xeolux_skeleton type="image" format="unknown" %}')
        self.assertIn("xlk-skeleton--image-landscape", output)

    def test_nav_type(self):
        output = render('{% xeolux_skeleton type="nav" %}')
        self.assertIn("xlk-skeleton--nav", output)
        self.assertIn("xlk-skeleton__nav-logo", output)
        self.assertIn("xlk-skeleton__nav-action", output)
        self.assertIn('aria-hidden="true"', output)

    def test_footer_type(self):
        output = render('{% xeolux_skeleton type="footer" lines=3 %}')
        self.assertIn("xlk-skeleton--footer", output)
        self.assertIn("xlk-skeleton__footer-col", output)
        self.assertEqual(output.count("xlk-skeleton__footer-col"), 3)

    def test_dashboard_type(self):
        output = render('{% xeolux_skeleton type="dashboard" lines=4 %}')
        self.assertIn("xlk-skeleton--dashboard", output)
        self.assertIn("xlk-skeleton__dashboard-card", output)
        self.assertEqual(output.count("xlk-skeleton__dashboard-card"), 4)

    def test_product_type(self):
        output = render('{% xeolux_skeleton type="product" %}')
        self.assertIn("xlk-skeleton--product", output)
        self.assertIn("xlk-skeleton__product-image", output)
        self.assertIn("xlk-skeleton__product-price", output)
        self.assertIn("xlk-skeleton__product-btn", output)

    def test_profile_type(self):
        output = render('{% xeolux_skeleton type="profile" %}')
        self.assertIn("xlk-skeleton--profile", output)
        self.assertIn("xlk-skeleton__profile-banner", output)
        self.assertIn("xlk-skeleton__profile-avatar", output)
        self.assertIn("xlk-skeleton__profile-name", output)

    def test_invalid_type_fallback_to_text(self):
        output = render('{% xeolux_skeleton type="unknown" %}')
        self.assertIn("xlk-skeleton--text", output)


class HTMXIndicatorTagTest(SimpleTestCase):
    def test_default_render(self):
        output = render("{% xeolux_htmx_indicator %}")
        self.assertIn("xlk-htmx-indicator", output)
        self.assertIn("htmx-indicator", output)
        self.assertIn('id="xeolux-htmx-loader"', output)
        self.assertIn("Chargement...", output)

    def test_custom_text(self):
        output = render('{% xeolux_htmx_indicator text="Envoi..." %}')
        self.assertIn("Envoi...", output)

    def test_accessible_attributes(self):
        output = render("{% xeolux_htmx_indicator %}")
        self.assertIn('role="status"', output)
        self.assertIn('aria-live="polite"', output)


class ProgressTagTest(SimpleTestCase):
    def test_default_render(self):
        output = render("{% xeolux_progress %}")
        self.assertIn("xlk-progress-track", output)
        self.assertIn("xlk-progress-fill", output)
        self.assertIn('role="progressbar"', output)
        self.assertIn('aria-valuenow="0"', output)

    def test_value_clamped_to_100(self):
        output = render("{% xeolux_progress value=150 %}")
        self.assertIn('aria-valuenow="100"', output)
        self.assertIn("width: 100%", output)

    def test_value_clamped_to_0(self):
        output = render("{% xeolux_progress value=-20 %}")
        self.assertIn('aria-valuenow="0"', output)
        self.assertIn("width: 0%", output)

    def test_value_50(self):
        output = render("{% xeolux_progress value=50 %}")
        self.assertIn('aria-valuenow="50"', output)
        self.assertIn("width: 50%", output)

    def test_label_rendered(self):
        output = render('{% xeolux_progress value=30 label="Téléchargement" %}')
        self.assertIn("Téléchargement", output)
        self.assertIn("xlk-progress-label", output)
        self.assertIn("xlk-progress-value", output)

    def test_no_label_by_default(self):
        output = render("{% xeolux_progress %}")
        self.assertNotIn("xlk-progress-label", output)

    def test_animated_class_default(self):
        output = render("{% xeolux_progress value=60 %}")
        self.assertIn("xlk-progress-fill--animated", output)

    def test_animated_false(self):
        output = render("{% xeolux_progress value=60 animated=False %}")
        self.assertNotIn("xlk-progress-fill--animated", output)

    def test_striped_class(self):
        output = render("{% xeolux_progress value=40 striped=True %}")
        self.assertIn("xlk-progress-fill--striped", output)

    def test_invalid_value_fallback_to_0(self):
        output = render('{% xeolux_progress value="abc" %}')
        self.assertIn('aria-valuenow="0"', output)


class TopbarTagTest(SimpleTestCase):
    def test_default_render(self):
        output = render("{% xeolux_topbar %}")
        self.assertIn("xlk-topbar", output)
        self.assertIn("xlk-topbar__fill", output)
        self.assertIn('role="progressbar"', output)
        self.assertIn('aria-hidden="true"', output)

    def test_active_state(self):
        output = render("{% xeolux_topbar active=True %}")
        self.assertIn("xlk-topbar--active", output)
        self.assertIn('aria-hidden="false"', output)

    def test_done_state(self):
        output = render("{% xeolux_topbar done=True %}")
        self.assertIn("xlk-topbar--done", output)

    def test_animated_class_default(self):
        output = render("{% xeolux_topbar %}")
        self.assertIn("xlk-topbar__fill--animated", output)

    def test_animated_false(self):
        output = render("{% xeolux_topbar animated=False %}")
        self.assertNotIn("xlk-topbar__fill--animated", output)
