class InsufficientTrainingDataException(Exception):
    pass