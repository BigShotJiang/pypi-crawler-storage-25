import logging
from collections.abc import Awaitable, Callable
from importlib import import_module
from pathlib import Path

from fastapi import FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles

from mpt_extension_sdk.api.builders.api import create_api_route
from mpt_extension_sdk.api.builders.event import create_event_route
from mpt_extension_sdk.errors.runtime import ConfigError
from mpt_extension_sdk.extension_app import ExtensionApp
from mpt_extension_sdk.observability.bootstrap import ObservabilityBootstrap
from mpt_extension_sdk.observability.config import ObservabilityConfig
from mpt_extension_sdk.routing.models import (
    APIRouteDefinition,
    EventRouteDefinition,
    PlugRouteDefinition,
)
from mpt_extension_sdk.runtime.logging import correlation_id_ctx, setup_logging, task_id_ctx
from mpt_extension_sdk.settings.runtime import RuntimeSettings

logger = logging.getLogger(__name__)


def load_extension_app(module_name: str) -> ExtensionApp:
    """Load the explicit extension app exported by the configured module.

    Args:
        module_name: Dotted Python module path that exports `ext_app`.

    Returns:
        The extension app exported by the module.

    Raises:
        ConfigError: If the module name is empty, the export is missing, or the
            exported object is not an `ExtensionApp`.
    """
    if not module_name:
        raise ConfigError("Extension app module cannot be empty")

    module = import_module(module_name)
    extension_app = getattr(module, "ext_app", None)
    if extension_app is None:
        raise ConfigError(f"Extension app module '{module_name}' must export 'ext_app'")

    if not isinstance(extension_app, ExtensionApp):
        raise ConfigError(f"Extension app module '{module_name}.ext_app' must be an ExtensionApp")

    return extension_app


def create_runtime_app(runtime_settings: RuntimeSettings) -> FastAPI:
    """Create and configure the FastAPI application for the extension.

    Loads runtime settings, derives metadata from the extension app, and
    registers all routes on the FastAPI instance.

    Returns:
        A fully configured `FastAPI` application.

    """
    setup_logging(runtime_settings.log_level, runtime_settings.extension_package)
    observability_config = ObservabilityConfig.from_runtime_settings(runtime_settings)
    ObservabilityBootstrap.bootstrap(observability_config)
    extension_app = load_extension_app(runtime_settings.app_module)

    app = _create_fastapi_app(extension_app)
    _configure_observability(app, observability_config)
    _configure_middlewares(app)
    _register_builtin_routes(app)
    app.mount(
        "/static",
        StaticFiles(directory=Path.cwd() / "static", check_dir=False),
        name="static",
    )
    register_extension_routes(app, extension_app)
    return app


def register_extension_routes(app: FastAPI, extension_app: ExtensionApp) -> None:  # noqa: WPS231
    """Register all decorated handlers on the FastAPI app.

    Args:
        app: The FastAPI application to register routes on.
        extension_app: Extension app that owns the registered routes.
    """
    for registered_route in extension_app.routes:
        match registered_route:
            case PlugRouteDefinition():
                continue
            case EventRouteDefinition():
                app.include_router(create_event_route(registered_route, extension_app))
            case APIRouteDefinition():
                app.include_router(create_api_route(registered_route, extension_app))
            case _:
                raise ConfigError("Only event, api, and plug routes are supported")


def _create_fastapi_app(extension_app: ExtensionApp) -> FastAPI:
    """Create the base FastAPI application for the extension runtime."""
    return FastAPI(
        title="MPT Extension API",
        description="MPT Extension API",
        version=extension_app.version,
        openapi_url=extension_app.openapi,
        docs_url="/bypass/docs",
        redoc_url="/bypass/redoc",
    )


def _configure_observability(app: FastAPI, observability_config: ObservabilityConfig) -> None:
    """Attach runtime observability integrations to the FastAPI app."""
    ObservabilityBootstrap.instrument_fastapi_app(app, observability_config)


def _configure_middlewares(app: FastAPI) -> None:
    """Register request middlewares used by the extension runtime."""

    @app.middleware("http")
    async def correlation_id_middleware(  # noqa: WPS430
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        correlation_id = request.headers.get("x-request-id", "")
        correlation_id_ctx.set(correlation_id)
        response = await call_next(request)
        response.headers["x-request-id"] = correlation_id
        return response

    @app.middleware("http")
    async def mpt_task_id_middleware(  # noqa: WPS430
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        task_id = request.headers.get("mpt-task-id", "")
        task_id_ctx.set(task_id)
        response = await call_next(request)
        response.headers["mpt-task-id"] = task_id
        return response


def _register_builtin_routes(app: FastAPI) -> None:
    """Register built-in operational routes exposed by the runtime."""

    @app.get("/health", tags=["ops"])
    async def health() -> dict[str, str]:  # noqa: WPS430
        return {"status": "ok", "version": app.version}
