from pydantic import Field

from mpt_extension_sdk.models.account import Account, BuyerAccount, SellerAccount
from mpt_extension_sdk.models.asset import AssetSimple
from mpt_extension_sdk.models.authorization import Authorization
from mpt_extension_sdk.models.base import BaseModel
from mpt_extension_sdk.models.external_id import ExternalIds
from mpt_extension_sdk.models.licensee import Licensee
from mpt_extension_sdk.models.parameter import ParameterBag
from mpt_extension_sdk.models.product import Product, ProductItem
from mpt_extension_sdk.models.subscription import SubscriptionSimple


class AgreementLine(BaseModel):
    """Agreement line model."""

    id: str
    description: str | None = None
    quantity: int
    status: str | None = None

    product_item: ProductItem = Field(
        alias="item", serialization_alias="item", validation_alias="item"
    )


class Agreement(BaseModel):
    """Agreement model."""

    id: str
    icon: str | None = None
    name: str
    revision: int | None = None
    status: str | None = None

    authorization: Authorization | None = None
    assets: list[AssetSimple] = Field(default_factory=list)
    buyer: BuyerAccount | None = None
    client: Account
    external_ids: ExternalIds = Field(
        default_factory=ExternalIds,
        serialization_alias="externalIds",
        validation_alias="externalIds",
    )
    licensee: Licensee
    lines: list[AgreementLine] = Field(default_factory=list)
    parameters: ParameterBag = Field(default_factory=ParameterBag)  # noqa: WPS110
    product: Product
    seller: SellerAccount | None = None
    subscriptions: list[SubscriptionSimple] = Field(default_factory=list)
    vendor: Account | None = None
