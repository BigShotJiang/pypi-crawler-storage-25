import logging
from typing import Any, Self

from pydantic import BaseModel, ConfigDict

logger = logging.getLogger(__name__)


class APIBaseModel(BaseModel):
    """Base schema."""

    model_config = ConfigDict(
        extra="allow",
        from_attributes=True,
        frozen=True,
        serialize_by_alias=True,
        validate_by_alias=True,
        validate_by_name=True,
    )

    def to_dict(self) -> dict[str, Any]:
        """Dump the model using the alias field names."""
        return self.model_dump(exclude_unset=True)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> Self:
        """Build a model from an API payload."""
        return cls.model_validate(payload, by_alias=True)
