"""Otter - A search and operation layer over network traffic."""
__version__ = "0.0.1"
