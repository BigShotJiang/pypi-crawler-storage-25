"""MCP usage examples."""
