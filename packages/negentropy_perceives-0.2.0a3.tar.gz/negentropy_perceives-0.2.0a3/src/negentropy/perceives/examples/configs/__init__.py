"""Extraction configuration examples."""
