__version__ = '0.41.3'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")