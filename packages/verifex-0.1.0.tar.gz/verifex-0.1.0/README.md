# Verifex Python SDK

Official Python SDK for [Verifex](https://verifex.dev) - Real-time Sanctions Screening API.

Screen persons and entities against OFAC, UN, EU, UK, Canada, and PEP lists in a single API call. 730,000+ entities across 9 data sources.

## Installation

```bash
pip install verifex
```

## Quick Start

```python
from verifex import VerifexClient

client = VerifexClient("vfx_your_api_key")

# Screen a person
result = client.screen("Vladimir Putin", type="person")
print(result.risk_level)        # RiskLevel.CRITICAL
print(result.total_matches)     # 1
print(result.matches[0].name)   # "PUTIN, Vladimir Vladimirovich"
print(result.matches[0].source) # "OFAC"
print(result.matches[0].confidence)  # 100
```

## Screening

### Single screening

```python
result = client.screen("John Doe")

if result.is_clear:
    print("No matches found")
else:
    print(f"Risk: {result.risk_level}")
    for match in result.matches:
        print(f"  {match.name} ({match.source}, {match.confidence}%)")
```

### With filters

```python
# Filter by entity type
result = client.screen("Sberbank", type="entity")

# Filter by country
result = client.screen("Ali", country="Iran")
```

### Batch screening

```python
results = client.batch_screen([
    {"name": "Vladimir Putin", "type": "person"},
    {"name": "Jane Doe"},
    {"name": "Sberbank", "type": "entity"},
])

for r in results.results:
    status = "MATCH" if r.is_match else "CLEAR"
    print(f"{r.query['name']}: {status} ({r.risk_level})")
```

## Usage and Keys

```python
# Check usage
usage = client.usage()
print(f"Plan: {usage.plan}")
print(f"Used: {usage.current_month_usage} / {usage.monthly_quota}")
print(f"Remaining: {usage.remaining}")

# Health check (no auth required)
health = client.health()
print(f"Status: {health.status}")
print(f"Total entries: {health.total_entries}")
```

## Error Handling

```python
from verifex import VerifexClient
from verifex.types import ApiError

client = VerifexClient("vfx_invalid_key")

try:
    result = client.screen("test")
except ApiError as e:
    print(e.code)        # "UNAUTHORIZED"
    print(e.error)       # "Invalid or revoked API key"
    print(e.status_code) # 401
```

## Risk Levels

| Level | Confidence | Meaning |
|-------|-----------|---------|
| `critical` | 90%+ | Exact or near-exact match |
| `high` | 75-89% | Strong fuzzy match |
| `medium` | 60-74% | Moderate similarity |
| `low` | 40-59% | Weak match |
| `clear` | No matches | No matches found |

## Requirements

- Python 3.9+
- No external dependencies (uses stdlib `urllib`)

## Links

- Website: [verifex.dev](https://verifex.dev)
- API Docs: [api.verifex.dev/docs](https://api.verifex.dev/docs)
- Dashboard: [verifex.dev/dashboard](https://verifex.dev/dashboard)
- Get API Key: [verifex.dev/auth/signup](https://verifex.dev/auth/signup)
