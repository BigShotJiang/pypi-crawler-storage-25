"""Verifex API client for Python."""

import json
from typing import Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from .types import (
    ScreenResult,
    BatchScreenResult,
    UsageStats,
    HealthResponse,
    ApiError,
)

DEFAULT_BASE_URL = "https://api.verifex.dev"
DEFAULT_TIMEOUT = 30


class VerifexClient:
    """Client for the Verifex sanctions screening API.

    Usage:
        from verifex import VerifexClient

        client = VerifexClient("vfx_your_api_key")

        # Screen a person
        result = client.screen("Vladimir Putin", type="person")
        print(result.risk_level)  # "critical"
        print(result.matches[0].source)  # "OFAC"

        # Screen with no match
        result = client.screen("John Doe")
        print(result.is_clear)  # True

        # Batch screening
        results = client.batch_screen([
            {"name": "Vladimir Putin"},
            {"name": "Jane Doe"},
        ])
        for r in results.results:
            print(f"{r.query['name']}: {r.risk_level}")

        # Check usage
        usage = client.usage()
        print(f"Used {usage.current_month_usage} of {usage.monthly_quota}")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[dict] = None,
        auth: bool = True,
    ) -> dict:
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self.api_key}"

        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, headers=headers, method=method)

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except HTTPError as e:
            try:
                error_body = json.loads(e.read().decode())
                raise ApiError(
                    error=error_body.get("error", str(e)),
                    code=error_body.get("code", "UNKNOWN"),
                    request_id=error_body.get("request_id", ""),
                    status_code=e.code,
                )
            except (json.JSONDecodeError, UnicodeDecodeError):
                raise ApiError(
                    error=str(e),
                    code="HTTP_ERROR",
                    status_code=e.code,
                )

    def screen(
        self,
        name: str,
        type: Optional[str] = None,
        country: Optional[str] = None,
    ) -> ScreenResult:
        """Screen a single person or entity against sanctions lists.

        Args:
            name: Name to screen (required).
            type: "person" or "entity" (optional filter).
            country: Country filter (optional).

        Returns:
            ScreenResult with matches, confidence scores, and risk level.

        Raises:
            ApiError: If the API returns an error.
        """
        body: dict = {"name": name}
        if type:
            body["type"] = type
        if country:
            body["country"] = country

        data = self._request("POST", "/v1/screen", body)
        return ScreenResult.from_dict(data)

    def batch_screen(
        self,
        entities: list[dict],
    ) -> BatchScreenResult:
        """Screen multiple entities in a single request.

        Args:
            entities: List of dicts with "name" (required), "type", "country".
                      Max 100 entities per request (depends on plan).

        Returns:
            BatchScreenResult with individual results for each entity.

        Raises:
            ApiError: If the API returns an error.
        """
        data = self._request("POST", "/v1/screen/batch", {"entities": entities})
        return BatchScreenResult.from_dict(data)

    def usage(self) -> UsageStats:
        """Get current month's usage statistics.

        Returns:
            UsageStats with quota, usage count, and daily breakdown.
        """
        data = self._request("GET", "/v1/usage")
        return UsageStats.from_dict(data)

    def health(self) -> HealthResponse:
        """Check API health status (no authentication required).

        Returns:
            HealthResponse with database, Redis, and list sync status.
        """
        data = self._request("GET", "/v1/health", auth=False)
        return HealthResponse.from_dict(data)

    def list_keys(self) -> list[dict]:
        """List all API keys for the authenticated user.

        Returns:
            List of API key metadata (never includes the key hash).
        """
        return self._request("GET", "/v1/keys")

    def create_key(self, name: str = "Default") -> dict:
        """Create a new API key.

        Args:
            name: Label for the key.

        Returns:
            Dict with the full key (shown only once), prefix, and name.
        """
        return self._request("POST", "/v1/keys", {"name": name})

    def revoke_key(self, key_id: str) -> dict:
        """Revoke an API key (cannot be undone).

        Args:
            key_id: The ID of the key to revoke.

        Returns:
            Confirmation message.
        """
        return self._request("DELETE", f"/v1/keys/{key_id}")
