"""Type definitions for Verifex API responses."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class RiskLevel(str, Enum):
    CLEAR = "clear"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class MatchType(str, Enum):
    EXACT = "EXACT"
    FUZZY = "FUZZY"
    PHONETIC = "PHONETIC"


@dataclass
class MatchResult:
    id: str
    name: str
    aliases: list[str]
    source: str
    entity_type: str
    confidence: int
    risk_level: RiskLevel
    match_type: MatchType
    nationality: Optional[str] = None
    date_of_birth: Optional[str] = None
    reason: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MatchResult":
        return cls(
            id=data["id"],
            name=data["name"],
            aliases=data.get("aliases", []),
            source=data["source"],
            entity_type=data["entity_type"],
            confidence=data["confidence"],
            risk_level=RiskLevel(data["risk_level"]),
            match_type=MatchType(data["match_type"]),
            nationality=data.get("nationality"),
            date_of_birth=data.get("date_of_birth"),
            reason=data.get("reason"),
        )


@dataclass
class ScreenResult:
    query: dict
    matches: list[MatchResult]
    total_matches: int
    risk_level: RiskLevel
    screened_at: str
    request_id: str

    @classmethod
    def from_dict(cls, data: dict) -> "ScreenResult":
        return cls(
            query=data["query"],
            matches=[MatchResult.from_dict(m) for m in data.get("matches", [])],
            total_matches=data["total_matches"],
            risk_level=RiskLevel(data["risk_level"]),
            screened_at=data["screened_at"],
            request_id=data["request_id"],
        )

    @property
    def is_clear(self) -> bool:
        return self.risk_level == RiskLevel.CLEAR

    @property
    def is_match(self) -> bool:
        return self.total_matches > 0

    @property
    def highest_confidence(self) -> int:
        if not self.matches:
            return 0
        return max(m.confidence for m in self.matches)


@dataclass
class BatchScreenResult:
    results: list[ScreenResult]
    total_duration_ms: int

    @classmethod
    def from_dict(cls, data: dict) -> "BatchScreenResult":
        return cls(
            results=[ScreenResult.from_dict(r) for r in data.get("results", [])],
            total_duration_ms=data.get("total_duration_ms", 0),
        )


@dataclass
class UsageStats:
    plan: str
    monthly_quota: int
    current_month_usage: int
    remaining: int
    daily_breakdown: list[dict]
    period: dict

    @classmethod
    def from_dict(cls, data: dict) -> "UsageStats":
        return cls(
            plan=data["plan"],
            monthly_quota=data["monthly_quota"],
            current_month_usage=data["current_month_usage"],
            remaining=data["remaining"],
            daily_breakdown=data.get("daily_breakdown", []),
            period=data.get("period", {}),
        )


@dataclass
class HealthResponse:
    status: str
    version: str
    uptime: int
    database: str
    redis: str
    lists: dict

    @classmethod
    def from_dict(cls, data: dict) -> "HealthResponse":
        return cls(
            status=data["status"],
            version=data["version"],
            uptime=data["uptime"],
            database=data["database"],
            redis=data["redis"],
            lists=data.get("lists", {}),
        )

    @property
    def is_healthy(self) -> bool:
        return self.status == "ok"

    @property
    def total_entries(self) -> int:
        return sum(info.get("count", 0) for info in self.lists.values())


@dataclass
class ApiError(Exception):
    error: str
    code: str
    request_id: str = ""
    status_code: int = 0

    def __str__(self) -> str:
        return f"VerifexError [{self.code}]: {self.error}"
