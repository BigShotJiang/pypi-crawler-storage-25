# coding:utf-8
import json
import sys
import unittest
from unittest.mock import patch, MagicMock

from sd2.video.task import (
    create_video_task,
    query_video_task,
    poll_tasks,
    list_video_tasks,
    delete_video_task,
    build_text_content,
    build_image_content,
    build_video_content,
    build_audio_content,
)
from sd2.cli import main


MOCK_CREATE_RESPONSE = {
    "id": "task-mock-001",
    "model": "doubao-seedance-2-0-260128",
    "status": "submitted",
    "content": [
        {"type": "text", "text": "一只猫在跳舞"}
    ],
    "created_at": 1710000000,
}

MOCK_QUERY_RESPONSE = {
    "id": "task-mock-001",
    "model": "doubao-seedance-2-0-260128",
    "data": {
        "status": "Succeed",
        "content": [
            {
                "type": "video_url",
                "video_url": {"url": "https://mock-cdn.example.com/output_video.mp4"},
            }
        ],
    },
}


class TestCreateVideoTask(unittest.TestCase):

    @patch("sd2.video.task.requests.post")
    def test_create_video_task_basic(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = MOCK_CREATE_RESPONSE
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        result = create_video_task(
            api_key="mock-api-key",
            model="doubao-seedance-2-0-260128",
            content=[build_text_content("一只猫在跳舞")],
            duration=5,
            resolution="720p",
        )

        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertEqual(call_args[1]["headers"]["Authorization"], "Bearer mock-api-key")

        payload = call_args[1]["json"]
        self.assertEqual(payload["model"], "doubao-seedance-2-0-260128")
        self.assertEqual(payload["content"][0]["text"], "一只猫在跳舞")
        self.assertEqual(payload["duration"], 5)
        self.assertEqual(payload["resolution"], "720p")
        self.assertTrue(payload["generate_audio"])

        self.assertEqual(result["id"], "task-mock-001")
        self.assertEqual(result["status"], "submitted")

    @patch("sd2.video.task.requests.post")
    def test_create_video_task_with_video_asset(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = MOCK_CREATE_RESPONSE
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        content = [
            build_text_content("换背景为海滩"),
            build_video_content("asset://asset-mock-123"),
            build_image_content("https://example.com/ref.jpg", "first_frame"),
        ]

        result = create_video_task(
            api_key="mock-api-key",
            model="doubao-seedance-2-0-260128",
            content=content,
            duration=-1,
            generate_audio=False,
        )

        payload = mock_post.call_args[1]["json"]
        self.assertEqual(payload["duration"], -1)
        self.assertFalse(payload["generate_audio"])
        self.assertEqual(payload["content"][1]["type"], "video_url")
        self.assertEqual(payload["content"][1]["video_url"]["url"], "asset://asset-mock-123")
        self.assertEqual(payload["content"][2]["type"], "image_url")
        self.assertEqual(payload["content"][2]["role"], "first_frame")

    @patch("sd2.video.task.requests.post")
    def test_create_video_task_api_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = '{"error": "bad request"}'
        mock_post.return_value = mock_resp

        with self.assertRaises(Exception) as ctx:
            create_video_task(
                api_key="mock-api-key",
                model="doubao-seedance-2-0-260128",
                content=[build_text_content("test")],
            )
        self.assertIn("HTTP 400", str(ctx.exception))

    @patch("sd2.video.task.requests.get")
    def test_query_video_task(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = MOCK_QUERY_RESPONSE
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = query_video_task(api_key="mock-api-key", task_id="task-mock-001")

        self.assertEqual(result["data"]["status"], "Succeed")
        mock_get.assert_called_once()

    @patch("sd2.video.task.time.sleep", return_value=None)
    @patch("sd2.video.task.query_video_task")
    def test_poll_tasks_completed(self, mock_query, mock_sleep):
        mock_query.return_value = MOCK_QUERY_RESPONSE

        results = poll_tasks(
            api_key="mock-api-key",
            task_ids=["task-mock-001"],
            retries=5,
            interval=1,
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["data"]["status"], "Succeed")
        mock_query.assert_called_once()

    @patch("sd2.video.task.time.sleep", return_value=None)
    @patch("sd2.video.task.query_video_task")
    def test_poll_tasks_polling(self, mock_query, mock_sleep):
        pending_resp = {
            "id": "task-mock-001",
            "data": {"status": "Processing"},
        }
        mock_query.side_effect = [pending_resp, pending_resp, MOCK_QUERY_RESPONSE]

        results = poll_tasks(
            api_key="mock-api-key",
            task_ids=["task-mock-001"],
            retries=10,
            interval=1,
        )

        self.assertEqual(mock_query.call_count, 3)
        self.assertEqual(results[0]["data"]["status"], "Succeed")


class TestCLI(unittest.TestCase):

    @patch("sd2.cli.create_video_task")
    def test_cli_create_video_text_only(self, mock_create):
        mock_create.return_value = MOCK_CREATE_RESPONSE

        with patch("sys.argv", ["sd2", "create-video",
                                "--api_key", "mock-api-key",
                                "--text", "一只猫在跳舞",
                                "--duration", "5"]):
            with patch("builtins.print") as mock_print:
                main()

        mock_create.assert_called_once()
        call_kwargs = mock_create.call_args[1]
        self.assertEqual(call_kwargs["api_key"], "mock-api-key")
        self.assertEqual(call_kwargs["duration"], 5)
        self.assertTrue(call_kwargs["generate_audio"])

        output = mock_print.call_args[0][0]
        parsed = json.loads(output)
        self.assertEqual(parsed["id"], "task-mock-001")

    @patch("sd2.cli.create_video_task")
    def test_cli_create_video_with_image_and_video(self, mock_create):
        mock_create.return_value = MOCK_CREATE_RESPONSE

        with patch("sys.argv", ["sd2", "create-video",
                                "--api_key", "mock-api-key",
                                "--text", "换背景",
                                "--video", "asset://asset-001",
                                "--image", "https://example.com/img.jpg|first_frame",
                                "--duration", "-1",
                                "--no_audio"]):
            with patch("builtins.print") as mock_print:
                main()

        call_kwargs = mock_create.call_args[1]
        self.assertFalse(call_kwargs["generate_audio"])
        self.assertEqual(call_kwargs["duration"], -1)

        content = call_kwargs["content"]
        self.assertEqual(len(content), 3)
        self.assertEqual(content[0]["type"], "text")
        self.assertEqual(content[1]["type"], "image_url")
        self.assertEqual(content[1]["role"], "first_frame")
        self.assertEqual(content[2]["type"], "video_url")

    @patch("sd2.cli.create_video_task")
    def test_cli_create_video_default_model_by_region(self, mock_create):
        mock_create.return_value = MOCK_CREATE_RESPONSE

        with patch("sys.argv", ["sd2", "create-video",
                                "--api_key", "mock-api-key",
                                "--text", "test",
                                "--region", "ap-southeast-1"]):
            with patch("builtins.print"):
                main()

        call_kwargs = mock_create.call_args[1]
        self.assertEqual(call_kwargs["model"], "dreamina-seedance-2-0-260128")

    @patch("sd2.cli.poll_tasks")
    def test_cli_query_task(self, mock_poll):
        mock_poll.return_value = [MOCK_QUERY_RESPONSE]

        with patch("sys.argv", ["sd2", "query-task",
                                "--api_key", "mock-api-key",
                                "--task_ids", "task-001", "task-002",
                                "--retries", "3",
                                "--interval", "5"]):
            with patch("builtins.print"):
                main()

        mock_poll.assert_called_once()
        call_kwargs = mock_poll.call_args[1]
        self.assertEqual(call_kwargs["task_ids"], ["task-001", "task-002"])
        self.assertEqual(call_kwargs["retries"], 3)
        self.assertEqual(call_kwargs["interval"], 5)


class TestBuildContentHelpers(unittest.TestCase):

    def test_build_text_content(self):
        result = build_text_content("hello world")
        self.assertEqual(result, {"type": "text", "text": "hello world"})

    def test_build_image_content_default_role(self):
        result = build_image_content("https://example.com/img.jpg")
        self.assertEqual(result["type"], "image_url")
        self.assertEqual(result["role"], "reference_image")
        self.assertEqual(result["image_url"]["url"], "https://example.com/img.jpg")

    def test_build_image_content_first_frame(self):
        result = build_image_content("https://example.com/img.jpg", "first_frame")
        self.assertEqual(result["role"], "first_frame")

    def test_build_video_content(self):
        result = build_video_content("asset://asset-123")
        self.assertEqual(result["type"], "video_url")
        self.assertEqual(result["video_url"]["url"], "asset://asset-123")
        self.assertEqual(result["role"], "reference_video")

    def test_build_audio_content(self):
        result = build_audio_content("https://example.com/audio.wav")
        self.assertEqual(result["type"], "audio_url")
        self.assertEqual(result["audio_url"]["url"], "https://example.com/audio.wav")
        self.assertEqual(result["role"], "reference_audio")


MOCK_LIST_TASKS_RESPONSE = {
    "total": 2,
    "items": [
        {
            "id": "cgt-2025-mock-001",
            "model": "doubao-seedance-2-0-260128",
            "status": "succeeded",
            "content": {
                "video_url": "https://mock-cdn.example.com/output_001.mp4"
            },
            "usage": {
                "completion_tokens": 108900,
                "total_tokens": 108900
            },
            "created_at": 1743414619,
            "updated_at": 1743414673,
            "seed": 10,
            "resolution": "720p",
            "ratio": "16:9",
            "duration": 5,
            "framespersecond": 24,
            "service_tier": "default",
            "execution_expires_after": 172800,
            "generate_audio": True,
            "draft": False,
        },
        {
            "id": "cgt-2025-mock-002",
            "model": "doubao-seedance-2-0-260128",
            "status": "running",
            "content": {},
            "usage": {},
            "created_at": 1743414700,
            "updated_at": 1743414710,
            "seed": 42,
            "resolution": "720p",
            "ratio": "adaptive",
            "duration": -1,
            "framespersecond": 24,
            "service_tier": "default",
            "execution_expires_after": 172800,
            "generate_audio": True,
            "draft": False,
        },
    ],
}


class TestListVideoTasks(unittest.TestCase):

    @patch("sd2.video.task.requests.get")
    def test_list_video_tasks_basic(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = MOCK_LIST_TASKS_RESPONSE
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = list_video_tasks(api_key="mock-api-key")

        mock_get.assert_called_once()
        call_args = mock_get.call_args
        self.assertEqual(call_args[1]["headers"]["Authorization"], "Bearer mock-api-key")
        self.assertEqual(call_args[1]["params"]["page_size"], 10)

        self.assertEqual(result["total"], 2)
        self.assertEqual(len(result["items"]), 2)
        self.assertEqual(result["items"][0]["id"], "cgt-2025-mock-001")
        self.assertEqual(result["items"][0]["status"], "succeeded")
        self.assertEqual(result["items"][1]["status"], "running")

    @patch("sd2.video.task.requests.get")
    def test_list_video_tasks_with_filters(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"total": 1, "items": [MOCK_LIST_TASKS_RESPONSE["items"][0]]}
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        result = list_video_tasks(
            api_key="mock-api-key",
            page_size=5,
            task_ids=["cgt-2025-mock-001"],
            model="doubao-seedance-2-0-260128",
            status="succeeded",
            service_tier="default",
        )

        call_args = mock_get.call_args
        params = call_args[1]["params"]
        self.assertEqual(params["page_size"], 5)
        self.assertEqual(params["filter.model"], "doubao-seedance-2-0-260128")
        self.assertEqual(params["filter.status"], "succeeded")
        self.assertEqual(params["filter.service_tier"], "default")

    @patch("sd2.video.task.requests.get")
    def test_list_video_tasks_api_error(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 401
        mock_resp.text = '{"error": "unauthorized"}'
        mock_get.return_value = mock_resp

        with self.assertRaises(Exception) as ctx:
            list_video_tasks(api_key="bad-key")
        self.assertIn("HTTP 401", str(ctx.exception))

    @patch("sd2.video.task.requests.get")
    def test_list_video_tasks_region(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"total": 0, "items": []}
        mock_resp.raise_for_status = MagicMock()
        mock_get.return_value = mock_resp

        list_video_tasks(api_key="mock-api-key", region="ap-southeast-1")

        call_url = mock_get.call_args[0][0]
        self.assertIn("ap-southeast", call_url)


class TestCLIListTasks(unittest.TestCase):

    @patch("sd2.cli.list_video_tasks")
    def test_cli_list_tasks_basic(self, mock_list):
        mock_list.return_value = MOCK_LIST_TASKS_RESPONSE

        with patch("sys.argv", ["sd2", "list-tasks",
                                "--api_key", "mock-api-key"]):
            with patch("builtins.print") as mock_print:
                main()

        mock_list.assert_called_once()
        call_kwargs = mock_list.call_args[1]
        self.assertEqual(call_kwargs["api_key"], "mock-api-key")
        self.assertEqual(call_kwargs["page_size"], 10)
        self.assertIsNone(call_kwargs["task_ids"])
        self.assertIsNone(call_kwargs["model"])
        self.assertIsNone(call_kwargs["status"])

        output = mock_print.call_args[0][0]
        parsed = json.loads(output)
        self.assertEqual(parsed["total"], 2)

    @patch("sd2.cli.list_video_tasks")
    def test_cli_list_tasks_with_filters(self, mock_list):
        mock_list.return_value = {"total": 1, "items": [MOCK_LIST_TASKS_RESPONSE["items"][0]]}

        with patch("sys.argv", ["sd2", "list-tasks",
                                "--api_key", "mock-api-key",
                                "--page_size", "5",
                                "--status", "succeeded",
                                "--model", "doubao-seedance-2-0-260128"]):
            with patch("builtins.print") as mock_print:
                main()

        call_kwargs = mock_list.call_args[1]
        self.assertEqual(call_kwargs["page_size"], 5)
        self.assertEqual(call_kwargs["status"], "succeeded")
        self.assertEqual(call_kwargs["model"], "doubao-seedance-2-0-260128")

    @patch("sd2.cli.list_video_tasks")
    def test_cli_list_tasks_with_task_ids(self, mock_list):
        mock_list.return_value = {"total": 1, "items": [MOCK_LIST_TASKS_RESPONSE["items"][0]]}

        with patch("sys.argv", ["sd2", "list-tasks",
                                "--api_key", "mock-api-key",
                                "--task_ids", "cgt-001", "cgt-002"]):
            with patch("builtins.print"):
                main()

        call_kwargs = mock_list.call_args[1]
        self.assertEqual(call_kwargs["task_ids"], ["cgt-001", "cgt-002"])


class TestDeleteVideoTask(unittest.TestCase):

    @patch("sd2.video.task.requests.delete")
    def test_delete_video_task_success(self, mock_delete):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_delete.return_value = mock_resp

        delete_video_task(api_key="mock-api-key", task_id="cgt-2025-mock-001")

        mock_delete.assert_called_once()
        call_args = mock_delete.call_args
        self.assertEqual(call_args[1]["headers"]["Authorization"], "Bearer mock-api-key")
        self.assertIn("cgt-2025-mock-001", call_args[0][0])
        self.assertEqual(call_args[0][0].split("/")[-1], "cgt-2025-mock-001")

    @patch("sd2.video.task.requests.delete")
    def test_delete_video_task_not_supported(self, mock_delete):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = '{"error": "cannot delete running task"}'
        mock_delete.return_value = mock_resp

        with self.assertRaises(Exception) as ctx:
            delete_video_task(api_key="mock-api-key", task_id="cgt-running-task")
        self.assertIn("HTTP 400", str(ctx.exception))

    @patch("sd2.video.task.requests.delete")
    def test_delete_video_task_region(self, mock_delete):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_delete.return_value = mock_resp

        delete_video_task(api_key="mock-api-key", task_id="cgt-001", region="ap-southeast-1")

        call_url = mock_delete.call_args[0][0]
        self.assertIn("ap-southeast", call_url)


class TestCLIDeleteTask(unittest.TestCase):

    @patch("sd2.cli.delete_video_task")
    def test_cli_delete_task(self, mock_delete):
        with patch("sys.argv", ["sd2", "delete-task",
                                "--api_key", "mock-api-key",
                                "--task_id", "cgt-2025-mock-001"]):
            with patch("builtins.print") as mock_print:
                main()

        mock_delete.assert_called_once_with(
            api_key="mock-api-key",
            task_id="cgt-2025-mock-001",
            region="cn-beijing",
        )
        output = mock_print.call_args[0][0]
        self.assertIn("cgt-2025-mock-001", output)
        self.assertIn("已成功取消/删除", output)

    @patch("sd2.cli.delete_video_task")
    def test_cli_delete_task_error(self, mock_delete):
        mock_delete.side_effect = Exception("HTTP 400 - cannot delete running task")

        with patch("sys.argv", ["sd2", "delete-task",
                                "--api_key", "mock-api-key",
                                "--task_id", "cgt-running"]):
            with self.assertRaises(SystemExit):
                main()


if __name__ == "__main__":
    unittest.main()
