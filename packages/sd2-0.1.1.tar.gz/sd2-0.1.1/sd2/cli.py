# coding:utf-8
import argparse
import json
import os
import sys

from sd2.video.task import (
    create_video_task,
    query_video_task,
    poll_tasks,
    list_video_tasks,
    delete_video_task,
    build_text_content,
    build_image_content,
    build_video_content,
    build_audio_content,
    REGION_DEFAULT_MODEL,
)
from sd2.video.split import split_video
from sd2.video.merge import merge_video
from sd2.assets.create_asset import create_asset
from sd2.assets.create_asset_group import create_asset_group
from sd2.assets.get_asset import get_asset
from sd2.assets.get_asset_group import get_asset_group
from sd2.assets.list_assets import list_assets
from sd2.assets.list_asset_groups import list_asset_groups
from sd2.assets.update_asset import update_asset
from sd2.assets.update_asset_group import update_asset_group
from sd2.assets.upload_tos import upload_to_tos


def cmd_create_video(args):
    content_list = []
    if args.text:
        content_list.append(build_text_content(args.text))
    if args.image:
        for img_str in args.image:
            if "|" in img_str:
                url, role = img_str.rsplit("|", 1)
            else:
                url = img_str
                role = "reference_image"
            content_list.append(build_image_content(url, role))
    if args.video:
        for vid_url in args.video:
            content_list.append(build_video_content(vid_url))
    if args.audio:
        for aud_url in args.audio:
            content_list.append(build_audio_content(aud_url))
    if not content_list:
        print("Error: 必须至少提供一项内容参数 (--text, --image, --video, --audio)", file=sys.stderr)
        sys.exit(1)

    model = args.model
    if not model:
        model = REGION_DEFAULT_MODEL.get(args.region, REGION_DEFAULT_MODEL["cn-beijing"])

    result = create_video_task(
        api_key=args.api_key,
        model=model,
        content=content_list,
        generate_audio=not args.no_audio,
        resolution=args.resolution,
        ratio=args.ratio,
        duration=args.duration,
        watermark=args.watermark,
        use_web_search=args.use_web_search,
        region=args.region,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_query_task(args):
    if not args.task_ids:
        print("Error: 必须提供 --task_ids", file=sys.stderr)
        sys.exit(1)
    poll_tasks(
        api_key=args.api_key,
        task_ids=args.task_ids,
        retries=args.retries,
        interval=args.interval,
        region=args.region,
    )


def cmd_list_tasks(args):
    try:
        result = list_video_tasks(
            api_key=args.api_key,
            page_size=args.page_size,
            task_ids=args.task_ids,
            model=args.model,
            status=args.status,
            service_tier=args.service_tier,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_delete_task(args):
    try:
        delete_video_task(
            api_key=args.api_key,
            task_id=args.task_id,
            region=args.region,
        )
        print(f"任务 {args.task_id} 已成功取消/删除。")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_split_video(args):
    try:
        files = split_video(
            input_video=args.input,
            output_dir=args.output_dir,
            segment_duration=args.segment_duration,
            ffmpeg_path=args.ffmpeg,
            ffprobe_path=args.ffprobe,
        )
        print(json.dumps(files, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_merge_video(args):
    try:
        output = merge_video(
            input_dir=args.input_dir,
            output_video=args.output,
            ffmpeg_path=args.ffmpeg,
        )
        print(f"Merged video: {output}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_create_asset(args):
    try:
        result = create_asset(
            ak=args.ak,
            sk=args.sk,
            group_id=args.group_id,
            url=args.url,
            name=args.name,
            asset_type=args.asset_type,
            project_name=args.project_name,
            region=args.region,
            pre_filter=args.pre_filter,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_create_asset_group(args):
    try:
        result = create_asset_group(
            ak=args.ak,
            sk=args.sk,
            name=args.name,
            description=args.description,
            group_type=args.group_type,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_get_asset(args):
    try:
        result = get_asset(
            ak=args.ak,
            sk=args.sk,
            asset_id=args.asset_id,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_get_asset_group(args):
    try:
        result = get_asset_group(
            ak=args.ak,
            sk=args.sk,
            group_id=args.group_id,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_list_assets(args):
    try:
        result = list_assets(
            ak=args.ak,
            sk=args.sk,
            group_type=args.group_type,
            group_ids=args.group_ids,
            statuses=args.statuses,
            name=args.name,
            page_number=args.page_number,
            page_size=args.page_size,
            sort_by=args.sort_by,
            sort_order=args.sort_order,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_list_asset_groups(args):
    try:
        result = list_asset_groups(
            ak=args.ak,
            sk=args.sk,
            group_type=args.group_type,
            name=args.name,
            group_ids=args.group_ids,
            page_number=args.page_number,
            page_size=args.page_size,
            sort_by=args.sort_by,
            sort_order=args.sort_order,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_update_asset(args):
    try:
        result = update_asset(
            ak=args.ak,
            sk=args.sk,
            asset_id=args.asset_id,
            name=args.name,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_update_asset_group(args):
    try:
        result = update_asset_group(
            ak=args.ak,
            sk=args.sk,
            group_id=args.group_id,
            name=args.name,
            description=args.description,
            project_name=args.project_name,
            region=args.region,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_upload_tos(args):
    try:
        url = upload_to_tos(
            file_path=args.file,
            ak=args.tos_ak,
            sk=args.tos_sk,
            object_prefix=args.object_prefix,
            bucket=args.bucket,
            region=args.region,
        )
        print(f"URL: {url}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _add_auth_args(parser):
    parser.add_argument("--ak", default=os.environ.get("VOLC_AK"), help="访问密钥 AK (默认读取环境变量 VOLC_AK)")
    parser.add_argument("--sk", default=os.environ.get("VOLC_SK"), help="访问密钥 SK (默认读取环境变量 VOLC_SK)")


def _add_region_arg(parser):
    parser.add_argument("--region", default=os.environ.get("VOLC_REGION", "cn-beijing"), help="区域 (默认 cn-beijing)")


def _add_project_arg(parser):
    parser.add_argument("--project_name", default="default", help="项目名称 (默认 default)")


def main():
    parser = argparse.ArgumentParser(
        prog="sd2",
        description="Seedance 2.0 视频处理与资产管理命令行工具",
        epilog=(
            "建议设置以下环境变量以避免每次手动传入参数：\n"
            '  export VOLC_REGION="cn-beijing"    # 或 ap-southeast-1\n'
            '  export VOLC_AK="你的Access Key"\n'
            '  export VOLC_SK="你的Secret Key"\n'
            '  export ARK_API_KEY="你的API Key"'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="可用子命令")

    # ---- create-video ----
    p_cv = subparsers.add_parser("create-video", help="创建视频生成任务")
    p_cv.add_argument("--api_key", default=os.environ.get("ARK_API_KEY"), help="API Key (默认读取 ARK_API_KEY)")
    p_cv.add_argument("--model", help="模型名称 (默认根据 region 自动选择)")
    p_cv.add_argument("--text", help="文本 prompt")
    p_cv.add_argument("--image", action="append", help="图片 URL 或 URL|role，可多次使用")
    p_cv.add_argument("--video", action="append", help="视频 URL 或 asset://ID，可多次使用")
    p_cv.add_argument("--audio", action="append", help="音频 URL 或 asset://ID，可多次使用")
    p_cv.add_argument("--no_audio", action="store_true", help="不生成音频")
    p_cv.add_argument("--resolution", default="720p", help="分辨率 (默认 720p)")
    p_cv.add_argument("--ratio", default="adaptive", help="宽高比 (默认 adaptive)")
    p_cv.add_argument("--duration", type=int, default=5, help="视频时长(秒)，-1为自适应 (默认 5)")
    p_cv.add_argument("--watermark", action="store_true", help="添加水印")
    p_cv.add_argument("--use_web_search", action="store_true", help="允许联网搜索")
    _add_region_arg(p_cv)
    p_cv.set_defaults(func=cmd_create_video)

    # ---- query-task ----
    p_qt = subparsers.add_parser("query-task", help="查询视频生成任务状态")
    p_qt.add_argument("--api_key", default=os.environ.get("ARK_API_KEY"), help="API Key (默认读取 ARK_API_KEY)")
    p_qt.add_argument("--task_ids", nargs="+", required=True, help="任务ID列表")
    p_qt.add_argument("--retries", type=int, default=50, help="查询次数 (默认 50)")
    p_qt.add_argument("--interval", type=int, default=20, help="查询间隔秒数 (默认 20)")
    _add_region_arg(p_qt)
    p_qt.set_defaults(func=cmd_query_task)

    # ---- list-tasks ----
    p_lt = subparsers.add_parser("list-tasks", help="查询视频生成任务列表")
    p_lt.add_argument("--api_key", default=os.environ.get("ARK_API_KEY"), help="API Key (默认读取 ARK_API_KEY)")
    p_lt.add_argument("--page_size", type=int, default=10, help="每页数量 (默认 10)")
    p_lt.add_argument("--task_ids", nargs="+", help="按任务ID过滤，支持多个")
    p_lt.add_argument("--model", help="按模型名称过滤")
    p_lt.add_argument("--status", help="按任务状态过滤 (queued, running, succeeded, failed, cancelled, expired)")
    p_lt.add_argument("--service_tier", help="按服务等级过滤 (default)")
    _add_region_arg(p_lt)
    p_lt.set_defaults(func=cmd_list_tasks)

    # ---- delete-task ----
    p_dt = subparsers.add_parser(
        "delete-task",
        help="取消或删除视频生成任务",
        description=(
            "取消排队中的视频生成任务，或删除已结束的任务记录。\n"
            "根据任务当前状态，操作效果不同：\n"
            "  queued    → 取消排队，状态变更为 cancelled\n"
            "  running   → 不支持删除（会返回错误）\n"
            "  succeeded → 删除任务记录，后续不可查询\n"
            "  failed    → 删除任务记录，后续不可查询\n"
            "  cancelled → 不支持删除（会返回错误）\n"
            "  expired   → 删除任务记录，后续不可查询\n"
            "\n"
            "注意：对 succeeded/failed/expired 状态的任务执行删除后，"
            "该任务记录将被永久移除，无法再通过查询接口获取。"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_dt.add_argument("--api_key", default=os.environ.get("ARK_API_KEY"), help="API Key (默认读取 ARK_API_KEY)")
    p_dt.add_argument("--task_id", required=True, help="需要取消或删除的任务ID")
    _add_region_arg(p_dt)
    p_dt.set_defaults(func=cmd_delete_task)

    # ---- split-video ----
    p_sv = subparsers.add_parser("split-video", help="将长视频切片为片段")
    p_sv.add_argument("--input", required=True, help="输入视频路径")
    p_sv.add_argument("--output_dir", required=True, help="输出目录")
    p_sv.add_argument("--segment_duration", type=int, default=12, help="每段时长秒数 (默认 12)")
    p_sv.add_argument("--ffmpeg", default=None, help="ffmpeg 路径 (默认系统 PATH)")
    p_sv.add_argument("--ffprobe", default=None, help="ffprobe 路径 (默认系统 PATH)")
    p_sv.set_defaults(func=cmd_split_video)

    # ---- merge-video ----
    p_mv = subparsers.add_parser("merge-video", help="合并视频片段")
    p_mv.add_argument("--input_dir", required=True, help="包含视频片段的目录")
    p_mv.add_argument("--output", required=True, help="输出视频路径")
    p_mv.add_argument("--ffmpeg", default=None, help="ffmpeg 路径 (默认系统 PATH)")
    p_mv.set_defaults(func=cmd_merge_video)

    # ---- create-asset ----
    p_ca = subparsers.add_parser("create-asset", help="创建素材资产")
    _add_auth_args(p_ca)
    p_ca.add_argument("--group_id", default=os.environ.get("VOLC_GROUP_ID"), help="素材组ID (默认读取 VOLC_GROUP_ID)")
    p_ca.add_argument("--url", required=True, help="素材公网URL")
    p_ca.add_argument("--name", default="", help="素材名称")
    p_ca.add_argument("--asset_type", default="Image", help="素材类型 (默认 Image)")
    _add_project_arg(p_ca)
    _add_region_arg(p_ca)
    p_ca.add_argument("--pre_filter", default=None, help="预过滤策略，off跳过审核")
    p_ca.set_defaults(func=cmd_create_asset)

    # ---- create-asset-group ----
    p_cag = subparsers.add_parser("create-asset-group", help="创建素材资产组")
    _add_auth_args(p_cag)
    p_cag.add_argument("--name", required=True, help="素材组名称")
    p_cag.add_argument("--description", help="素材组描述")
    p_cag.add_argument("--group_type", default="AIGC", help="素材组类型 (默认 AIGC)")
    _add_project_arg(p_cag)
    _add_region_arg(p_cag)
    p_cag.set_defaults(func=cmd_create_asset_group)

    # ---- get-asset ----
    p_ga = subparsers.add_parser("get-asset", help="查询素材资产详情")
    _add_auth_args(p_ga)
    p_ga.add_argument("--asset_id", required=True, help="素材资产ID")
    _add_project_arg(p_ga)
    _add_region_arg(p_ga)
    p_ga.set_defaults(func=cmd_get_asset)

    # ---- get-asset-group ----
    p_gag = subparsers.add_parser("get-asset-group", help="查询素材资产组详情")
    _add_auth_args(p_gag)
    p_gag.add_argument("--group_id", default=os.environ.get("VOLC_GROUP_ID"), help="素材组ID (默认读取 VOLC_GROUP_ID)")
    _add_project_arg(p_gag)
    _add_region_arg(p_gag)
    p_gag.set_defaults(func=cmd_get_asset_group)

    # ---- list-assets ----
    p_la = subparsers.add_parser("list-assets", help="查询素材资产列表")
    _add_auth_args(p_la)
    p_la.add_argument("--group_type", default="AIGC", help="素材组类型 (默认 AIGC)")
    p_la.add_argument("--group_ids", nargs="+", help="素材组ID列表")
    p_la.add_argument("--statuses", nargs="+", help="状态过滤 (Active, Processing, Failed)")
    p_la.add_argument("--name", help="名称过滤")
    p_la.add_argument("--page_number", type=int, default=1, help="页码 (默认 1)")
    p_la.add_argument("--page_size", type=int, default=100, help="每页数量 (默认 100)")
    p_la.add_argument("--sort_by", default="CreateTime", help="排序字段 (默认 CreateTime)")
    p_la.add_argument("--sort_order", default="Desc", help="排序顺序 (默认 Desc)")
    _add_project_arg(p_la)
    _add_region_arg(p_la)
    p_la.set_defaults(func=cmd_list_assets)

    # ---- list-asset-groups ----
    p_lag = subparsers.add_parser("list-asset-groups", help="查询素材资产组列表")
    _add_auth_args(p_lag)
    p_lag.add_argument("--group_type", default="AIGC", help="素材组类型 (默认 AIGC)")
    p_lag.add_argument("--name", help="名称过滤")
    p_lag.add_argument("--group_ids", nargs="+", help="素材组ID列表")
    p_lag.add_argument("--page_number", type=int, default=1, help="页码 (默认 1)")
    p_lag.add_argument("--page_size", type=int, default=10, help="每页数量 (默认 10)")
    p_lag.add_argument("--sort_by", default="CreateTime", help="排序字段 (默认 CreateTime)")
    p_lag.add_argument("--sort_order", default="Desc", help="排序顺序 (默认 Desc)")
    _add_project_arg(p_lag)
    _add_region_arg(p_lag)
    p_lag.set_defaults(func=cmd_list_asset_groups)

    # ---- update-asset ----
    p_ua = subparsers.add_parser("update-asset", help="更新素材资产名称")
    _add_auth_args(p_ua)
    p_ua.add_argument("--asset_id", required=True, help="素材资产ID")
    p_ua.add_argument("--name", help="新名称")
    _add_project_arg(p_ua)
    _add_region_arg(p_ua)
    p_ua.set_defaults(func=cmd_update_asset)

    # ---- update-asset-group ----
    p_uag = subparsers.add_parser("update-asset-group", help="更新素材资产组信息")
    _add_auth_args(p_uag)
    p_uag.add_argument("--group_id", default=os.environ.get("VOLC_GROUP_ID"), help="素材组ID (默认读取 VOLC_GROUP_ID)")
    p_uag.add_argument("--name", help="新名称")
    p_uag.add_argument("--description", help="新描述")
    _add_project_arg(p_uag)
    _add_region_arg(p_uag)
    p_uag.set_defaults(func=cmd_update_asset_group)

    # ---- upload-tos ----
    p_ut = subparsers.add_parser("upload-tos", help="上传文件到火山引擎TOS存储桶")
    p_ut.add_argument("--file", required=True, help="本地文件路径")
    p_ut.add_argument("--tos_ak", help="TOS AK (默认读取 VOLC_AK)")
    p_ut.add_argument("--tos_sk", help="TOS SK (默认读取 VOLC_SK)")
    p_ut.add_argument("--object_prefix", default="videos/", help="TOS路径前缀 (默认 videos/)")
    p_ut.add_argument("--bucket", default="qwer123", help="TOS存储桶名称 (默认 qwer123)")
    _add_region_arg(p_ut)
    p_ut.set_defaults(func=cmd_upload_tos)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
