# coding:utf-8
import os
import subprocess
import json


def _find_ffmpeg():
    return "ffmpeg"


def _find_ffprobe():
    return "ffprobe"


def split_video(
    input_video: str,
    output_dir: str,
    segment_duration: int = 12,
    ffmpeg_path: str = None,
    ffprobe_path: str = None,
) -> list:
    ffmpeg = ffmpeg_path or _find_ffmpeg()
    ffprobe = ffprobe_path or _find_ffprobe()

    os.makedirs(output_dir, exist_ok=True)

    filename = os.path.basename(input_video)
    basename = os.path.splitext(filename)[0]

    print(f"Calculating duration for '{input_video}'...")
    result = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", input_video],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed: {result.stderr}")
    duration = float(result.stdout.strip())

    print(f"Splitting into segments (intelligent tail handling)...")

    output_files = []
    start = 0.0
    index = 0

    while start < duration:
        remaining = duration - start

        if remaining < (segment_duration + 2) and index > 0:
            print(f"Adding remaining {remaining:.1f}s to the last segment...")
            t_param = []
        else:
            t_param = ["-t", str(segment_duration)]

        output_file = os.path.join(output_dir, f"{basename}_{index:03d}.mp4")
        print(f"Exporting segment {index} (starting at {start:.1f}s)...")

        cmd = [
            ffmpeg, "-y",
            "-ss", str(start),
            *t_param,
            "-i", input_video,
            "-c:v", "libx264", "-crf", "18", "-preset", "fast",
            "-g", "30", "-sc_threshold", "0",
            "-c:a", "aac", "-avoid_negative_ts", "make_zero",
            output_file
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg split failed for segment {index}: {proc.stderr}")

        output_files.append(output_file)

        if not t_param:
            break

        start += segment_duration
        index += 1

        next_remaining = duration - start
        if next_remaining < 0.5:
            break

    print("Video splitting completed successfully.")
    return output_files
