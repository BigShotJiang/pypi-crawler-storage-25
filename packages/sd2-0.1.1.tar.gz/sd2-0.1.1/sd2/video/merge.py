# coding:utf-8
import os
import subprocess
import tempfile


def _find_ffmpeg():
    return "ffmpeg"


def merge_video(
    input_dir: str,
    output_video: str,
    ffmpeg_path: str = None,
) -> str:
    ffmpeg = ffmpeg_path or _find_ffmpeg()

    mp4_files = sorted([
        f for f in os.listdir(input_dir)
        if f.endswith(".mp4")
    ])

    if not mp4_files:
        raise FileNotFoundError(f"No mp4 files found in '{input_dir}'.")

    print(f"Generating file list from '{input_dir}'...")

    filelist_fd, filelist_path = tempfile.mkstemp(suffix=".txt")
    try:
        with os.fdopen(filelist_fd, "w") as f:
            for mp4_file in mp4_files:
                abs_path = os.path.join(os.path.abspath(input_dir), mp4_file)
                f.write(f"file '{abs_path}'\n")

        print(f"Merging {len(mp4_files)} segments into '{output_video}'...")

        cmd = [
            ffmpeg, "-y",
            "-f", "concat", "-safe", "0",
            "-i", filelist_path,
            "-vf", "fps=30",
            "-c:v", "libx264", "-crf", "18", "-preset", "slow",
            "-pix_fmt", "yuv420p",
            "-video_track_timescale", "15360",
            "-c:a", "aac", "-b:a", "192k",
            output_video
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg merge failed: {proc.stderr}")

    finally:
        os.unlink(filelist_path)

    print(f"Video merging completed successfully: '{output_video}'")
    return output_video
