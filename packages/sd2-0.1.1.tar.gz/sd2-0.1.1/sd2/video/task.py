# coding:utf-8
import requests
import time
import sys
import json
import os
from typing import List, Dict, Any, Optional

REGION_API_BASE_MAP = {
    "cn-beijing": "https://ark.cn-beijing.volces.com",
    "ap-southeast-1": "https://ark.ap-southeast.bytepluses.com",
}

REGION_DEFAULT_MODEL = {
    "cn-beijing": "doubao-seedance-2-0-260128",
    "ap-southeast-1": "dreamina-seedance-2-0-260128",
}


def _get_api_url(region: str = None) -> str:
    base = REGION_API_BASE_MAP.get(region or "cn-beijing", REGION_API_BASE_MAP["cn-beijing"])
    return f"{base}/api/v3/contents/generations/tasks"


def create_video_task(
    api_key: str,
    model: str,
    content: List[Dict[str, Any]],
    generate_audio: bool = True,
    resolution: str = "720p",
    ratio: str = "adaptive",
    duration: int = 5,
    watermark: bool = False,
    use_web_search: bool = False,
    region: str = None,
) -> Dict[str, Any]:
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": model,
        "content": content,
        "generate_audio": generate_audio,
        "resolution": resolution,
        "ratio": ratio,
        "duration": duration,
        "watermark": watermark
    }

    if use_web_search:
        payload["tools"] = [{"type": "web_search"}]

    response = requests.post(_get_api_url(region), headers=headers, json=payload)
    if not response.ok:
        raise Exception(f"HTTP {response.status_code} - API Error: {response.text}")
    response.raise_for_status()

    return response.json()


def build_text_content(text: str) -> Dict[str, Any]:
    return {
        "type": "text",
        "text": text
    }


def build_image_content(url: str, role: str = "reference_image") -> Dict[str, Any]:
    return {
        "type": "image_url",
        "image_url": {"url": url},
        "role": role
    }


def build_video_content(url: str, role: str = "reference_video") -> Dict[str, Any]:
    return {
        "type": "video_url",
        "video_url": {"url": url},
        "role": role
    }


def build_audio_content(url: str, role: str = "reference_audio") -> Dict[str, Any]:
    return {
        "type": "audio_url",
        "audio_url": {"url": url},
        "role": role
    }


def query_video_task(api_key: str, task_id: str, region: str = None) -> Dict[str, Any]:
    base = REGION_API_BASE_MAP.get(region or "cn-beijing", REGION_API_BASE_MAP["cn-beijing"])
    query_url = f"{base}/api/v3/contents/generations/tasks/{task_id}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    response = requests.get(query_url, headers=headers)
    response.raise_for_status()
    return response.json()


def list_video_tasks(
    api_key: str,
    page_size: int = 10,
    task_ids: Optional[List[str]] = None,
    model: Optional[str] = None,
    status: Optional[str] = None,
    service_tier: Optional[str] = None,
    region: str = None,
) -> Dict[str, Any]:
    base = REGION_API_BASE_MAP.get(region or "cn-beijing", REGION_API_BASE_MAP["cn-beijing"])
    list_url = f"{base}/api/v3/contents/generations/tasks"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    params = {"page_size": page_size}
    if task_ids:
        for tid in task_ids:
            params.setdefault("filter.task_ids", [])
            if isinstance(params.get("filter.task_ids"), list):
                params["filter.task_ids"].append(tid)
    if model:
        params["filter.model"] = model
    if status:
        params["filter.status"] = status
    if service_tier:
        params["filter.service_tier"] = service_tier

    response = requests.get(list_url, headers=headers, params=params)
    if not response.ok:
        raise Exception(f"HTTP {response.status_code} - API Error: {response.text}")
    response.raise_for_status()
    return response.json()


def delete_video_task(
    api_key: str,
    task_id: str,
    region: str = None,
) -> None:
    base = REGION_API_BASE_MAP.get(region or "cn-beijing", REGION_API_BASE_MAP["cn-beijing"])
    delete_url = f"{base}/api/v3/contents/generations/tasks/{task_id}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    response = requests.delete(delete_url, headers=headers)
    if not response.ok:
        raise Exception(f"HTTP {response.status_code} - API Error: {response.text}")
    response.raise_for_status()


def poll_tasks(
    api_key: str,
    task_ids: List[str],
    retries: int = 50,
    interval: int = 20,
    region: str = None,
) -> List[Dict[str, Any]]:
    for attempt in range(retries):
        results = []
        all_completed = True
        print(f"--- 查询第 {attempt + 1}/{retries} 次 ---", file=sys.stderr)
        for task_id in task_ids:
            try:
                res = query_video_task(api_key=api_key, task_id=task_id, region=region)
                status = ""
                if "data" in res and isinstance(res["data"], dict):
                    status = str(res["data"].get("status", "")).lower()
                else:
                    status = str(res.get("status", "")).lower()

                results.append(res)

                if status not in ["succeed", "succeeded", "success", "failed", "completed", "error"]:
                    all_completed = False
            except Exception as e:
                print(f"查询任务 {task_id} 时发生错误: {e}", file=sys.stderr)
                results.append({"task_id": task_id, "error": str(e)})
                all_completed = False

        print(json.dumps(results, indent=2, ensure_ascii=False), file=sys.stderr)

        if all_completed:
            print("所有任务均已到达结束状态。", file=sys.stderr)
            print(json.dumps(results, indent=2, ensure_ascii=False))
            return results

        if attempt < retries - 1:
            time.sleep(interval)

    print("已达到最大重试次数，部分任务可能未完成。", file=sys.stderr)
    return results
