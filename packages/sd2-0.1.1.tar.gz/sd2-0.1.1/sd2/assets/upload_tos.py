# coding:utf-8
import os
import tos

REGION_ENDPOINT_MAP = {
    "cn-beijing": "tos-cn-beijing.volces.com",
    "ap-southeast-1": "tos-ap-southeast-1.bytepluses.com",
}


def upload_to_tos(
    file_path: str,
    ak: str = None,
    sk: str = None,
    object_prefix: str = "videos/",
    bucket: str = "qwer123",
    region: str = None,
) -> str:
    ak = ak or os.getenv("VOLC_AK")
    sk = sk or os.getenv("VOLC_SK")
    region = region or os.getenv("VOLC_REGION", "cn-beijing")

    if not ak or not sk:
        raise ValueError("必须提供 AK/SK，可以通过参数传入或设置环境变量 VOLC_AK / VOLC_SK")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"本地文件 {file_path} 不存在")

    endpoint = REGION_ENDPOINT_MAP.get(region, REGION_ENDPOINT_MAP["cn-beijing"])

    file_name = os.path.basename(file_path)
    object_key = f"{object_prefix.rstrip('/')}/{file_name}"

    client = tos.TosClientV2(ak, sk, endpoint, region)

    with open(file_path, "rb") as f:
        result = client.put_object(
            bucket,
            object_key,
            content=f,
            acl=tos.ACLType.ACL_Public_Read,
            storage_class=tos.StorageClassType.Storage_Class_Standard
        )

    public_url = f"https://{bucket}.{endpoint}/{object_key}"
    print(f"上传成功！")
    print(f"HTTP状态码: {result.status_code}")
    print(f"请求ID: {result.request_id}")
    print(f"公网访问URL: {public_url}")
    return public_url
