# coding:utf-8
import datetime
import json
from typing import Optional, Dict
from sd2.assets.sign_util import VERSION, request_api

ACTION = "CreateAssetGroup"


def create_asset_group(
    ak: str,
    sk: str,
    name: str,
    description: Optional[str] = None,
    group_type: str = "AIGC",
    project_name: str = "default",
    region: str = None
) -> Dict:
    data = {
        "Name": name,
        "GroupType": group_type,
        "ProjectName": project_name,
    }
    if description is not None:
        data["Description"] = description

    data_json = json.dumps(data)
    current_date = datetime.datetime.utcnow()

    response = request_api(
        action=ACTION,
        method="POST",
        date=current_date,
        query={},
        header={},
        ak=ak,
        sk=sk,
        body=data_json,
        region=region
    )

    response.raise_for_status()
    return response.json()
