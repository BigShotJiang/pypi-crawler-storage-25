# coding:utf-8
import datetime
import json
from typing import Optional, List, Dict
from sd2.assets.sign_util import VERSION, request_api

ACTION = "ListAssetGroups"


def list_asset_groups(
    ak: str,
    sk: str,
    group_type: str = "AIGC",
    name: Optional[str] = None,
    group_ids: Optional[List[str]] = None,
    page_number: int = 1,
    page_size: int = 10,
    sort_by: str = "CreateTime",
    sort_order: str = "Desc",
    project_name: str = "default",
    region: str = None
) -> Dict:
    filter_data = {
        "GroupType": group_type
    }
    if name is not None:
        filter_data["name"] = name
    if group_ids:
        filter_data["GroupIds"] = group_ids

    data = {
        "Filter": filter_data,
        "PageNumber": page_number,
        "PageSize": page_size,
        "SortBy": sort_by,
        "SortOrder": sort_order,
        "ProjectName": project_name
    }

    data_json = json.dumps(data)
    current_date = datetime.datetime.utcnow()

    response = request_api(
        action=ACTION,
        method="POST",
        date=current_date,
        query={},
        header={},
        ak=ak,
        sk=sk,
        body=data_json,
        region=region
    )

    response.raise_for_status()
    return response.json()
