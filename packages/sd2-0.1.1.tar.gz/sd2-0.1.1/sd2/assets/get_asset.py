# coding:utf-8
import datetime
import json
from typing import Dict
from sd2.assets.sign_util import VERSION, request_api

ACTION = "GetAsset"


def get_asset(
    ak: str,
    sk: str,
    asset_id: str,
    project_name: str = "default",
    region: str = None
) -> Dict:
    data = {
        "Id": asset_id,
        "ProjectName": project_name,
    }
    data_json = json.dumps(data)
    current_date = datetime.datetime.utcnow()

    response = request_api(
        action=ACTION,
        method="POST",
        date=current_date,
        query={},
        header={},
        ak=ak,
        sk=sk,
        body=data_json,
        region=region
    )

    response.raise_for_status()
    return response.json()
