# coding:utf-8
import datetime
import json
from typing import Dict
from sd2.assets.sign_util import VERSION, request_api

ACTION = "CreateAsset"


def create_asset(
    ak: str,
    sk: str,
    group_id: str,
    url: str,
    name: str = "",
    asset_type: str = "Image",
    project_name: str = "default",
    region: str = None,
    pre_filter: str = None
) -> Dict:
    data = {
        "GroupId": group_id,
        "URL": url,
        "AssetType": asset_type,
        "ProjectName": project_name,
    }
    if name:
        data["Name"] = name
    if pre_filter == "off":
        data["Moderation"] = {"Strategy": "Skip"}

    data_json = json.dumps(data)
    current_date = datetime.datetime.utcnow()

    response = request_api(
        action=ACTION,
        method="POST",
        date=current_date,
        query={},
        header={},
        ak=ak,
        sk=sk,
        body=data_json,
        region=region
    )

    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code} - {response.text}")
    return response.json()
