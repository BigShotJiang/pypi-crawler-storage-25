# coding:utf-8
import datetime
import json
from typing import Optional, Dict
from sd2.assets.sign_util import VERSION, request_api

ACTION = "UpdateAsset"


def update_asset(
    ak: str,
    sk: str,
    asset_id: str,
    name: Optional[str] = None,
    project_name: str = "default",
    region: str = None
) -> Dict:
    data = {
        "Id": asset_id,
        "ProjectName": project_name,
    }
    if name is not None:
        data["Name"] = name

    data_json = json.dumps(data)
    current_date = datetime.datetime.utcnow()

    response = request_api(
        action=ACTION,
        method="POST",
        date=current_date,
        query={},
        header={},
        ak=ak,
        sk=sk,
        body=data_json,
        region=region
    )

    response.raise_for_status()
    return response.json()
