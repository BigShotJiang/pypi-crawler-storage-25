# coding:utf-8
import datetime
import hashlib
import hmac
from urllib.parse import quote
import requests

SERVICE = "ark"
VERSION = "2024-01-01"
REGION = "cn-beijing"
HOST = "ark.cn-beijing.volcengineapi.com"
CONTENT_TYPE = "application/json"
PATH = "/"

REGION_HOST_MAP = {
    "cn-beijing": "ark.cn-beijing.volcengineapi.com",
    "ap-southeast-1": "ark.ap-southeast-1.byteplusapi.com",
}


def norm_query(params: dict) -> str:
    query = ""
    for key in sorted(params.keys()):
        if isinstance(params[key], list):
            for k in params[key]:
                query += quote(key, safe="-_.~") + "=" + quote(str(k), safe="-_.~") + "&"
        else:
            query += quote(key, safe="-_.~") + "=" + quote(str(params[key]), safe="-_.~") + "&"
    return query[:-1].replace("+", "%20")


def hmac_sha256(key: bytes, content: str) -> bytes:
    return hmac.new(key, content.encode("utf-8"), hashlib.sha256).digest()


def hash_sha256(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def request_api(action: str, method: str, date: datetime.datetime, query: dict, header: dict, ak: str, sk: str, body: str = "", region: str = None) -> requests.Response:
    actual_region = region or REGION
    actual_host = REGION_HOST_MAP.get(actual_region, HOST)

    credential = {
        "access_key_id": ak,
        "secret_access_key": sk,
        "service": SERVICE,
        "region": actual_region,
    }

    final_query = {"Action": action, "Version": VERSION}
    if query:
        final_query.update(query)

    request_param = {
        "body": body if body else "",
        "host": actual_host,
        "path": PATH,
        "method": method.upper(),
        "content_type": CONTENT_TYPE,
        "date": date,
        "query": final_query,
    }

    x_date = request_param["date"].strftime("%Y%m%dT%H%M%SZ")
    short_x_date = x_date[:8]
    x_content_sha256 = hash_sha256(request_param["body"])

    sign_result = {
        "Host": request_param["host"],
        "X-Content-Sha256": x_content_sha256,
        "X-Date": x_date,
        "Content-Type": request_param["content_type"],
    }

    signed_headers_str = ";".join(["content-type", "host", "x-content-sha256", "x-date"])

    canonical_request_str = "\n".join([
        request_param["method"],
        request_param["path"],
        norm_query(request_param["query"]),
        "\n".join([
            "content-type:" + request_param["content_type"],
            "host:" + request_param["host"],
            "x-content-sha256:" + x_content_sha256,
            "x-date:" + x_date,
        ]),
        "",
        signed_headers_str,
        x_content_sha256,
    ])

    hashed_canonical_request = hash_sha256(canonical_request_str)
    credential_scope = "/".join([short_x_date, credential["region"], credential["service"], "request"])

    string_to_sign = "\n".join(["HMAC-SHA256", x_date, credential_scope, hashed_canonical_request])

    k_date = hmac_sha256(credential["secret_access_key"].encode("utf-8"), short_x_date)
    k_region = hmac_sha256(k_date, credential["region"])
    k_service = hmac_sha256(k_region, credential["service"])
    k_signing = hmac_sha256(k_service, "request")
    signature = hmac_sha256(k_signing, string_to_sign).hex()

    sign_result["Authorization"] = "HMAC-SHA256 Credential={}, SignedHeaders={}, Signature={}".format(
        credential["access_key_id"] + "/" + credential_scope,
        signed_headers_str,
        signature,
    )

    final_headers = header.copy() if header else {}
    final_headers.update(sign_result)

    response = requests.request(
        method=request_param["method"],
        url="https://{}{}".format(request_param["host"], request_param["path"]),
        headers=final_headers,
        params=request_param["query"],
        data=request_param["body"]
    )
    return response
