"""Tests for export/import module."""

import pytest
from pathlib import Path

from env_sync.store import Store
from env_sync.export_import import parse_env_file, import_env, export_env
from env_sync import config as cfg


@pytest.fixture
def initialized_project(tmp_path):
    cfg.init_dir(tmp_path)
    return tmp_path


@pytest.fixture
def store(initialized_project):
    return Store(project_path=initialized_project, password="test-pass")


class TestParseEnvFile:
    def test_basic(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("KEY=value\nOTHER=thing\n")
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "value"), ("OTHER", "thing")]

    def test_quoted_values(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text('KEY="value with spaces"\n')
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "value with spaces")]

    def test_single_quoted(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("KEY='value'\n")
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "value")]

    def test_comments_skipped(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("# comment\nKEY=value\n")
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "value")]

    def test_empty_lines_skipped(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("\nKEY=value\n\n")
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "value")]

    def test_nonexistent_file(self, tmp_path):
        pairs = parse_env_file(tmp_path / "nope")
        assert pairs == []

    def test_equals_in_value(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("KEY=val=ue\n")
        pairs = parse_env_file(f)
        assert pairs == [("KEY", "val=ue")]


class TestImportEnv:
    def test_basic_import(self, initialized_project, store, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("DATABASE_URL=postgresql://host/db\nPORT=3000\n")
        results = import_env(env_file, store)
        assert len(results) == 2
        assert store.get("PORT") == "3000"

    def test_detects_secrets(self, initialized_project, store, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('password = "supersecret123"\nPORT=3000\n')
        results = import_env(env_file, store)
        secret_keys = [k for k, is_secret in results if is_secret]
        assert any("password" in k.lower() or "PASSWORD" in k for k in secret_keys)


class TestExportEnv:
    def test_basic_export(self, initialized_project, store, tmp_path):
        store.add("KEY1", "value1", encrypted=False)
        store.add("KEY2", "value2", encrypted=True)

        out = tmp_path / ".env"
        count = export_env(out, store)
        assert count == 2

        content = out.read_text()
        assert "KEY1=value1" in content
        assert "KEY2=value2" in content

    def test_empty_store(self, initialized_project, store, tmp_path):
        out = tmp_path / ".env"
        count = export_env(out, store)
        assert count == 0
