"""Tests for store module."""

import pytest
from pathlib import Path

from env_sync.store import Store
from env_sync import config as cfg


@pytest.fixture
def initialized_project(tmp_path):
    """Create an initialized project directory."""
    cfg.init_dir(tmp_path)
    return tmp_path


@pytest.fixture
def store(initialized_project):
    """Create a store with a test password."""
    return Store(project_path=initialized_project, password="test-pass")


class TestStore:
    def test_add_and_get(self, store):
        store.add("KEY1", "value1", encrypted=True)
        assert store.get("KEY1") == "value1"

    def test_add_unencrypted(self, store):
        store.add("KEY2", "value2", encrypted=False)
        assert store.get("KEY2") == "value2"

    def test_get_nonexistent(self, store):
        assert store.get("NOPE") is None

    def test_remove(self, store):
        store.add("KEY", "val", encrypted=False)
        assert store.remove("KEY") is True
        assert store.get("KEY") is None

    def test_remove_nonexistent(self, store):
        assert store.remove("NOPE") is False

    def test_list_all_empty(self, store):
        assert store.list_all() == {}

    def test_list_all(self, store):
        store.add("A", "1", encrypted=False)
        store.add("B", "2", encrypted=True)
        variables = store.list_all()
        assert "A" in variables
        assert "B" in variables
        assert variables["A"]["encrypted"] is False
        assert variables["B"]["encrypted"] is True

    def test_update_overwrites(self, store):
        store.add("KEY", "old", encrypted=False)
        store.add("KEY", "new", encrypted=False)
        assert store.get("KEY") == "new"

    def test_get_all_decrypted(self, store):
        store.add("A", "plain", encrypted=False)
        store.add("B", "secret", encrypted=True)
        result = store.get_all_decrypted()
        assert result["A"] == "plain"
        assert result["B"] == "secret"

    def test_get_entry(self, store):
        store.add("KEY", "val", encrypted=True)
        entry = store.get_entry("KEY")
        assert entry is not None
        assert entry["encrypted"] is True

    def test_special_characters(self, store):
        store.add("KEY", "val=ue=with=equals", encrypted=True)
        assert store.get("KEY") == "val=ue=with=equals"

    def test_empty_value(self, store):
        store.add("KEY", "", encrypted=True)
        assert store.get("KEY") == ""

    def test_persistence(self, initialized_project):
        """Data persists across store instances."""
        s1 = Store(project_path=initialized_project, password="pass")
        s1.add("KEY", "value", encrypted=True)

        s2 = Store(project_path=initialized_project, password="pass")
        assert s2.get("KEY") == "value"

    def test_wrong_password_fails(self, initialized_project):
        s1 = Store(project_path=initialized_project, password="correct")
        s1.add("KEY", "secret", encrypted=True)

        s2 = Store(project_path=initialized_project, password="wrong")
        with pytest.raises(Exception):
            s2.get("KEY")
