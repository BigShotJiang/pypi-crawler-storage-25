"""Tests for diff module."""

import pytest
from pathlib import Path

from env_sync.diff import mask_value, diff_environments
from env_sync import config as cfg
from env_sync.store import Store


@pytest.fixture
def initialized_project(tmp_path):
    cfg.init_dir(tmp_path)
    return tmp_path


class TestMaskValue:
    def test_short_value(self):
        assert "•" in mask_value("abc")

    def test_encrypted(self):
        assert mask_value("anything", encrypted=True) == "••••••••"

    def test_normal_value(self):
        result = mask_value("hello")
        assert "he" in result
        assert "lo" in result


class TestDiffEnvironments:
    def test_identical_environments(self, initialized_project):
        store = Store(project_path=initialized_project, password="pass")
        store.add("KEY1", "val1", encrypted=False)
        store.add("KEY2", "val2", encrypted=False)

        result = diff_environments("default", "default", initialized_project, "pass")
        # Same env compared to itself should be all identical
        assert len(result["identical"]) >= 0  # Depends on implementation

    def test_mask_value_long(self):
        result = mask_value("a" * 100)
        assert "•" in result
