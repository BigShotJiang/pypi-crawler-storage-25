"""Tests for rotation module."""

import pytest
from pathlib import Path

from env_sync.store import Store
from env_sync.rotation import generate_secret, generate_api_key, generate_password, generate_token, rotate_key
from env_sync import config as cfg


@pytest.fixture
def initialized_project(tmp_path):
    cfg.init_dir(tmp_path)
    return tmp_path


@pytest.fixture
def store(initialized_project):
    return Store(project_path=initialized_project, password="test-pass")


class TestGeneration:
    def test_generate_secret_default_length(self):
        s = generate_secret()
        assert len(s) == 32

    def test_generate_secret_custom_length(self):
        s = generate_secret(64)
        assert len(s) == 64

    def test_generate_secret_unique(self):
        s1 = generate_secret()
        s2 = generate_secret()
        assert s1 != s2

    def test_generate_api_key(self):
        key = generate_api_key(prefix="sk-", length=32)
        assert key.startswith("sk-")
        assert len(key) == 35

    def test_generate_password(self):
        pwd = generate_password(20)
        assert len(pwd) == 20

    def test_generate_token(self):
        token = generate_token()
        assert len(token) > 0


class TestRotation:
    def test_rotate_existing_key(self, store):
        store.add("API_KEY", "old-value", encrypted=True)
        new = rotate_key(store, "API_KEY", machine="test")
        assert new is not None
        assert new != "old-value"
        assert store.get("API_KEY") == new

    def test_rotate_nonexistent(self, store):
        result = rotate_key(store, "NOPE", machine="test")
        assert result is None

    def test_rotate_creates_audit_entry(self, initialized_project, store):
        store.add("KEY", "val", encrypted=True)
        rotate_key(store, "KEY", machine="test")
        from env_sync.audit import get_audit_log
        entries = get_audit_log(initialized_project)
        assert any(e["action"] == "rotate" for e in entries)
