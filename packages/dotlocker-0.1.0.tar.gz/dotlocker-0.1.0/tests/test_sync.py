"""Tests for sync module."""

import pytest
from pathlib import Path

from env_sync.store import Store
from env_sync.sync import create_bundle, receive_bundle
from env_sync import config as cfg


@pytest.fixture
def initialized_project(tmp_path):
    cfg.init_dir(tmp_path)
    return tmp_path


@pytest.fixture
def store(initialized_project):
    s = Store(project_path=initialized_project, password="store-pass")
    s.add("KEY1", "value1", encrypted=True)
    s.add("KEY2", "value2", encrypted=False)
    return s


class TestSync:
    def test_create_bundle(self, store, tmp_path):
        bundle_path = create_bundle(store, "shared-pass", tmp_path / "bundle.enc")
        assert bundle_path.exists()
        assert bundle_path.stat().st_size > 0

    def test_bundle_roundtrip(self, initialized_project, store, tmp_path):
        bundle_path = create_bundle(store, "shared-pass", tmp_path / "bundle.enc")

        # New store to receive
        receive_store = Store(project_path=initialized_project, password="store-pass")
        imported = receive_bundle(receive_store, bundle_path, "shared-pass")
        assert len(imported) == 2
        assert receive_store.get("KEY1") == "value1"
        assert receive_store.get("KEY2") == "value2"

    def test_wrong_passphrase_fails(self, store, tmp_path):
        bundle_path = create_bundle(store, "correct-pass", tmp_path / "bundle.enc")
        new_store = Store(project_path=tmp_path, password="store-pass")
        cfg.init_dir(tmp_path)
        with pytest.raises(Exception):
            receive_bundle(new_store, bundle_path, "wrong-pass")
