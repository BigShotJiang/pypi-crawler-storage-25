"""Tests for audit module."""

import pytest
from pathlib import Path

from env_sync.audit import log_access, get_audit_log, clear_audit_log
from env_sync import config as cfg


@pytest.fixture
def initialized_project(tmp_path):
    cfg.init_dir(tmp_path)
    return tmp_path


class TestAudit:
    def test_log_and_retrieve(self, initialized_project):
        log_access(initialized_project, "API_KEY", "read", "macbook")
        entries = get_audit_log(initialized_project)
        assert len(entries) == 1
        assert entries[0]["key"] == "API_KEY"
        assert entries[0]["action"] == "read"
        assert entries[0]["machine"] == "macbook"

    def test_multiple_entries(self, initialized_project):
        log_access(initialized_project, "KEY1", "read", "m1")
        log_access(initialized_project, "KEY2", "rotate", "m2")
        entries = get_audit_log(initialized_project)
        assert len(entries) == 2

    def test_limit(self, initialized_project):
        for i in range(10):
            log_access(initialized_project, f"KEY{i}", "read", "m")
        entries = get_audit_log(initialized_project, limit=5)
        assert len(entries) == 5

    def test_clear(self, initialized_project):
        log_access(initialized_project, "KEY", "read", "m")
        clear_audit_log(initialized_project)
        assert get_audit_log(initialized_project) == []

    def test_empty_log(self, initialized_project):
        assert get_audit_log(initialized_project) == []

    def test_entry_has_timestamp(self, initialized_project):
        log_access(initialized_project, "KEY", "read", "m")
        entries = get_audit_log(initialized_project)
        assert "timestamp" in entries[0]
