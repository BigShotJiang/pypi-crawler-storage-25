"""Tests for CLI."""

import pytest
from click.testing import CliRunner
from pathlib import Path

from env_sync.cli import cli
from env_sync import config as cfg


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def initialized_project(tmp_path, monkeypatch):
    """Initialize env-sync in tmp_path and cd there."""
    monkeypatch.chdir(tmp_path)
    cfg.init_dir(tmp_path)
    return tmp_path


@pytest.fixture
def runner_with_password(runner, monkeypatch):
    """Runner with ENV_SYNC_PASSWORD set."""
    monkeypatch.setenv("ENV_SYNC_PASSWORD", "test-password")
    return runner


class TestInit:
    def test_init(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0
        assert "initialized" in result.output.lower() or "✓" in result.output

    def test_init_already_initialized(self, runner, initialized_project):
        result = runner.invoke(cli, ["init"])
        assert "already" in result.output.lower()


class TestAddGet:
    def test_add_and_get(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["add", "MY_KEY=value123"])
        assert r.exit_code == 0
        assert "✓" in r.output

        r = runner_with_password.invoke(cli, ["get", "MY_KEY"])
        assert r.exit_code == 0
        assert "value123" in r.output

    def test_add_invalid_format(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["add", "NOEQUALSSIGN"])
        assert r.exit_code == 1

    def test_get_nonexistent(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["get", "NOPE"])
        assert r.exit_code == 1

    def test_not_initialized(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        r = runner.invoke(cli, ["get", "KEY"])
        assert r.exit_code == 1


class TestList:
    def test_list_empty(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["list"])
        assert "no variables" in r.output.lower() or r.exit_code == 0

    def test_list_with_vars(self, runner_with_password, initialized_project):
        runner_with_password.invoke(cli, ["add", "KEY1=val1"])
        runner_with_password.invoke(cli, ["add", "KEY2=val2"])
        r = runner_with_password.invoke(cli, ["list"])
        assert r.exit_code == 0
        assert "KEY1" in r.output
        assert "KEY2" in r.output


class TestRemove:
    def test_remove(self, runner_with_password, initialized_project):
        runner_with_password.invoke(cli, ["add", "KEY=val"])
        r = runner_with_password.invoke(cli, ["remove", "KEY"])
        assert r.exit_code == 0
        assert "✓" in r.output

    def test_remove_nonexistent(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["remove", "NOPE"])
        assert "not found" in r.output.lower()


class TestExportImport:
    def test_export(self, runner_with_password, initialized_project):
        runner_with_password.invoke(cli, ["add", "KEY=val"])
        r = runner_with_password.invoke(cli, ["export", "-o", str(initialized_project / ".env")])
        assert r.exit_code == 0

    def test_import(self, runner_with_password, initialized_project):
        env_file = initialized_project / ".env.test"
        env_file.write_text("IMPORTED_KEY=imported_value\n")
        r = runner_with_password.invoke(cli, ["import", str(env_file)])
        assert r.exit_code == 0
        assert "IMPORTED_KEY" in r.output


class TestAudit:
    def test_audit_empty(self, runner_with_password, initialized_project):
        r = runner_with_password.invoke(cli, ["audit"])
        assert r.exit_code == 0

    def test_audit_with_entries(self, runner_with_password, initialized_project):
        runner_with_password.invoke(cli, ["add", "KEY=val"])
        r = runner_with_password.invoke(cli, ["audit"])
        assert r.exit_code == 0


class TestVersion:
    def test_version(self, runner):
        r = runner.invoke(cli, ["--version"])
        assert "0.1.0" in r.output
