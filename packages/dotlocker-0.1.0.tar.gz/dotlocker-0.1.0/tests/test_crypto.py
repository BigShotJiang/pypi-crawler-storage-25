"""Tests for crypto module."""

import pytest
from pathlib import Path
import tempfile
import os

from env_sync.crypto import (
    encrypt_value, decrypt_value, encrypt_bundle, decrypt_bundle,
    _derive_key, _get_machine_id
)


class TestEncryptDecrypt:
    def test_encrypt_decrypt_roundtrip(self, tmp_path):
        salt_path = tmp_path / "salt"
        password = "test-password-123"
        plaintext = "hello world"

        encrypted = encrypt_value(plaintext, password, salt_path)
        assert encrypted != plaintext
        decrypted = decrypt_value(encrypted, password, salt_path)
        assert decrypted == plaintext

    def test_different_password_fails(self, tmp_path):
        salt_path = tmp_path / "salt"
        encrypted = encrypt_value("secret", "password1", salt_path)
        with pytest.raises(Exception):
            decrypt_value(encrypted, "password2", salt_path)

    def test_empty_value(self, tmp_path):
        salt_path = tmp_path / "salt"
        encrypted = encrypt_value("", "pass", salt_path)
        assert decrypt_value(encrypted, "pass", salt_path) == ""

    def test_long_value(self, tmp_path):
        salt_path = tmp_path / "salt"
        value = "x" * 10000
        encrypted = encrypt_value(value, "pass", salt_path)
        assert decrypt_value(encrypted, "pass", salt_path) == value

    def test_unicode_value(self, tmp_path):
        salt_path = tmp_path / "salt"
        value = "héllo wörld 🔑"
        encrypted = encrypt_value(value, "pass", salt_path)
        assert decrypt_value(encrypted, "pass", salt_path) == value

    def test_salt_persistence(self, tmp_path):
        salt_path = tmp_path / "salt"
        password = "pass"
        encrypt_value("val1", password, salt_path)
        assert salt_path.exists()
        # Second encryption reuses same salt
        encrypted = encrypt_value("val2", password, salt_path)
        assert decrypt_value(encrypted, password, salt_path) == "val2"

    def test_same_value_different_ciphertext(self, tmp_path):
        salt_path = tmp_path / "salt"
        password = "pass"
        enc1 = encrypt_value("same", password, salt_path)
        enc2 = encrypt_value("same", password, salt_path)
        assert enc1 != enc2  # Different nonce each time


class TestBundle:
    def test_bundle_roundtrip(self):
        data = {"key1": "value1", "key2": "value2"}
        raw = encrypt_bundle(data, "passphrase")
        result = decrypt_bundle(raw, "passphrase")
        assert result == data

    def test_bundle_wrong_passphrase(self):
        data = {"key": "val"}
        raw = encrypt_bundle(data, "correct")
        with pytest.raises(Exception):
            decrypt_bundle(raw, "wrong")

    def test_bundle_complex_data(self):
        data = {"vars": {"a": "1"}, "nested": {"deep": {"val": "x"}}}
        raw = encrypt_bundle(data, "pass")
        assert decrypt_bundle(raw, "pass") == data


class TestKeyDerivation:
    def test_derive_key_length(self):
        key = _derive_key("password", b"salt123456789012")
        assert len(key) == 32

    def test_derive_key_deterministic(self):
        salt = os.urandom(16)
        k1 = _derive_key("password", salt)
        k2 = _derive_key("password", salt)
        assert k1 == k2

    def test_different_passwords_different_keys(self):
        salt = os.urandom(16)
        k1 = _derive_key("pass1", salt)
        k2 = _derive_key("pass2", salt)
        assert k1 != k2


class TestMachineId:
    def test_returns_string(self):
        assert isinstance(_get_machine_id(), str)

    def test_is_consistent(self):
        assert _get_machine_id() == _get_machine_id()
