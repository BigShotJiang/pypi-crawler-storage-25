"""Tests for secret detector."""

import pytest
from pathlib import Path

from env_sync.secret_detector import (
    detect_secrets_in_file, detect_secrets_in_text, SecretMatch
)


class TestDetectInText:
    def test_aws_key(self):
        matches = detect_secrets_in_text("AWS_KEY=AKIAIOSFODNN7EXAMPLE")
        assert any(m.pattern_name == "AWS Access Key" for m in matches)

    def test_password(self):
        matches = detect_secrets_in_text('password = "supersecret123"')
        assert any(m.pattern_name == "Password" for m in matches)

    def test_api_key(self):
        matches = detect_secrets_in_text('api_key = "sk-1234567890abcdef"')
        assert any(m.pattern_name == "Generic API Key" for m in matches)

    def test_token(self):
        matches = detect_secrets_in_text('token = "ghp_1234567890abcdef"')
        assert any(m.pattern_name == "Generic Token" for m in matches)

    def test_private_key(self):
        matches = detect_secrets_in_text("-----BEGIN RSA PRIVATE KEY-----")
        assert any(m.pattern_name == "Private Key" for m in matches)

    def test_database_url(self):
        matches = detect_secrets_in_text("DATABASE_URL=postgresql://user:pass@host/db")
        assert any(m.pattern_name == "Database Connection" for m in matches)

    def test_webhook(self):
        matches = detect_secrets_in_text('webhook = "https://hooks.slack.com/services/xxx"')
        assert any(m.pattern_name == "Webhook URL" for m in matches)

    def test_jwt(self):
        matches = detect_secrets_in_text("token=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc123def456")
        assert any(m.pattern_name == "JWT" for m in matches)

    def test_ignores_comments(self):
        matches = detect_secrets_in_text("# password = secret123")
        assert len(matches) == 0

    def test_no_secrets(self):
        matches = detect_secrets_in_text("PORT=3000\nNODE_ENV=development")
        assert len(matches) == 0

    def test_multiple_secrets(self):
        text = 'password = "abc"\napi_key = "sk-12345678"'
        matches = detect_secrets_in_text(text)
        assert len(matches) >= 2

    def test_line_numbers(self):
        matches = detect_secrets_in_text("safe line\npassword = secret123")
        pwd_matches = [m for m in matches if m.pattern_name == "Password"]
        assert any(m.line_number == 2 for m in pwd_matches)


class TestDetectInFile:
    def test_detect_in_file(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text('password = "supersecret"\nPORT=3000\n')
        matches = detect_secrets_in_file(f)
        assert len(matches) >= 1

    def test_skip_binary_extensions(self, tmp_path):
        f = tmp_path / "image.png"
        f.write_text("password = secret")
        matches = detect_secrets_in_file(f)
        assert len(matches) == 0

    def test_empty_file(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("")
        matches = detect_secrets_in_file(f)
        assert len(matches) == 0

    def test_comments_only(self, tmp_path):
        f = tmp_path / ".env"
        f.write_text("# password = secret\n# API_KEY = abc\n")
        matches = detect_secrets_in_file(f)
        assert len(matches) == 0
