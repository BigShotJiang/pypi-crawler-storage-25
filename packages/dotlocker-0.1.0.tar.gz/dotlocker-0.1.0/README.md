# env-sync

CLI tool for managing and syncing `.env` files across machines and team members. Encrypts secrets locally, syncs via git or file transfer, diffs between environments, and auto-rotates secrets.

## Install

```bash
pip install env-sync
```

## Quick Start

```bash
# Initialize in your project
env-sync init

# Add variables (auto-detects and encrypts secrets)
env-sync add DATABASE_URL=postgresql://user:pass@host/db
env-sync add NODE_ENV=development
env-sync add API_KEY=sk-abc123def456

# List all variables (secrets masked)
env-sync list

# Get a specific value
env-sync get API_KEY

# Import from existing .env
env-sync import .env

# Export to .env file
env-sync export

# Compare environments
env-sync diff staging prod

# Rotate a secret
env-sync rotate API_KEY

# Share encrypted bundle with team
env-sync share

# Check for secrets in git-staged files
env-sync ci

# Install as pre-commit hook
env-sync ci --install
```

## How It Works

1. `env-sync init` creates `.env-sync/` with encrypted storage
2. All variables are encrypted at rest using **AES-256-GCM**
3. Encryption key derived from password + salt via **PBKDF2** (600k iterations)
4. Secret keys are auto-detected by name patterns (password, token, key, etc.)
5. Share creates an encrypted bundle — safe to commit or transfer
6. Audit log tracks all access

## Security

- **AES-256-GCM** encryption for all stored secrets
- **PBKDF2** key derivation with 600k iterations
- Cryptographically secure random values via `secrets` module
- Secret values are never logged or displayed unmasked
- Pre-commit hook prevents secrets from being committed to git

## Secret Detection Patterns

- AWS Access Keys (`AKIA...`)
- API keys and secrets
- Bearer tokens
- Passwords
- Private keys (RSA, EC, OpenSSH)
- Database connection strings
- Webhook URLs
- JWT tokens

## License

MIT © Hiren Thakore
