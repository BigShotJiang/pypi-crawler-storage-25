from __future__ import annotations
"""Environment diffing."""

from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from . import config as cfg
from .store import Store


def mask_value(value: str, encrypted: bool = False) -> str:
    """Mask a value for display."""
    if encrypted:
        return "••••••••"
    if len(value) <= 4:
        return "••••"
    return value[:2] + "••" + value[-2:]


def diff_environments(env1: str, env2: str, project_path: Path | None = None, password: str = "") -> dict:
    """Compare two environments. Returns diff summary dict."""
    store1_path = project_path or Path.cwd()
    env1_dir = cfg.get_env_sync_dir(store1_path).parent / f".env-sync-{env1}"
    env2_dir = cfg.get_env_sync_dir(store1_path).parent / f".env-sync-{env2}"

    # For MVP, environments are stored as separate store files in .env-sync/
    store = Store(project_path, password)
    data = store._load()
    all_vars = data.get("variables", {})

    # Simple approach: tag variables with environment metadata
    # For now, diff between two sets of keys
    env1_vars = {k: v for k, v in all_vars.items() if v.get("environment", "default") == env1} if any(v.get("environment") for v in all_vars.values()) else all_vars
    env2_vars = {k: v for k, v in all_vars.items() if v.get("environment", "default") == env2} if any(v.get("environment") for v in all_vars.values()) else all_vars

    keys1 = set(env1_vars.keys())
    keys2 = set(env2_vars.keys())

    identical = []
    different = []
    only_in_1 = []
    only_in_2 = []

    all_keys = keys1 | keys2
    for key in all_keys:
        in1 = key in env1_vars
        in2 = key in env2_vars
        if in1 and in2:
            if env1_vars[key] == env2_vars[key]:
                identical.append(key)
            else:
                different.append(key)
        elif in1:
            only_in_1.append(key)
        else:
            only_in_2.append(key)

    return {
        "identical": sorted(identical),
        "different": sorted(different),
        "only_in_env1": sorted(only_in_1),
        "only_in_env2": sorted(only_in_2),
        "env1": env1,
        "env2": env2,
        "env1_vars": env1_vars,
        "env2_vars": env2_vars,
    }


def display_diff(diff_result: dict) -> None:
    """Display diff results using rich."""
    console = Console()
    lines = []
    lines.append("")
    lines.append(f"✅ IDENTICAL ({len(diff_result['identical'])})")
    lines.append("")

    if diff_result["different"]:
        lines.append(f"⚠️  DIFFERENT ({len(diff_result['different'])})")
        for key in diff_result["different"]:
            v1 = diff_result["env1_vars"][key]
            v2 = diff_result["env2_vars"][key]
            val1 = mask_value(v1.get("value", ""), v1.get("encrypted", False))
            val2 = mask_value(v2.get("value", ""), v2.get("encrypted", False))
            lines.append(f"├─ {key:20s} {diff_result['env1']}={val1}  {diff_result['env2']}={val2}")
        lines.append("")

    if diff_result["only_in_env2"]:
        lines.append(f"🆕 IN {diff_result['env2'].upper()} ONLY ({len(diff_result['only_in_env2'])})")
        for key in diff_result["only_in_env2"]:
            v = diff_result["env2_vars"][key]
            val = mask_value(v.get("value", ""), v.get("encrypted", False))
            lines.append(f"└─ {key:20s} {val}")
        lines.append("")

    if diff_result["only_in_env1"]:
        lines.append(f"🆕 IN {diff_result['env1'].upper()} ONLY ({len(diff_result['only_in_env1'])})")
        for key in diff_result["only_in_env1"]:
            v = diff_result["env1_vars"][key]
            val = mask_value(v.get("value", ""), v.get("encrypted", False))
            lines.append(f"└─ {key:20s} {val}")
        lines.append("")

    panel = Panel("\n".join(lines), title=f"Environment Diff: {diff_result['env1']} vs {diff_result['env2']}", border_style="blue")
    console.print(panel)
