from __future__ import annotations
"""Encrypted storage for environment variables."""

import json
from pathlib import Path

from . import config as cfg
from . import crypto


class Store:
    """Encrypted key-value store for environment variables."""

    def __init__(self, project_path: Path | None = None, password: str = ""):
        self.project_path = project_path or Path.cwd()
        self.password = password
        self.env_dir = cfg.get_env_sync_dir(self.project_path)
        self.salt_path = self.env_dir / cfg.SALT_FILE
        self.store_path = self.env_dir / cfg.STORE_FILE

    def _load(self) -> dict:
        """Load and decrypt the store."""
        if not self.store_path.exists():
            return {"variables": {}}
        encrypted = self.store_path.read_text().strip()
        if not encrypted:
            return {"variables": {}}
        decrypted = crypto.decrypt_value(encrypted, self.password, self.salt_path)
        return json.loads(decrypted)

    def _save(self, data: dict) -> None:
        """Encrypt and save the store."""
        plaintext = json.dumps(data)
        encrypted = crypto.encrypt_value(plaintext, self.password, self.salt_path)
        self.store_path.write_text(encrypted)

    def add(self, key: str, value: str, encrypted: bool = True) -> None:
        """Add or update a variable."""
        data = self._load()
        data["variables"][key] = {
            "value": crypto.encrypt_value(value, self.password, self.salt_path) if encrypted else value,
            "encrypted": encrypted,
            "source": ".env",
        }
        self._save(data)

    def get(self, key: str) -> str | None:
        """Get a decrypted variable value."""
        data = self._load()
        entry = data["variables"].get(key)
        if entry is None:
            return None
        if entry["encrypted"]:
            return crypto.decrypt_value(entry["value"], self.password, self.salt_path)
        return entry["value"]

    def get_entry(self, key: str) -> dict | None:
        """Get full entry including metadata."""
        data = self._load()
        return data["variables"].get(key)

    def list_all(self) -> dict:
        """List all variables with metadata (values encrypted/masked)."""
        data = self._load()
        return data.get("variables", {})

    def remove(self, key: str) -> bool:
        """Remove a variable. Returns True if found."""
        data = self._load()
        if key in data["variables"]:
            del data["variables"][key]
            self._save(data)
            return True
        return False

    def get_all_decrypted(self) -> dict:
        """Get all variables with decrypted values."""
        data = self._load()
        result = {}
        for key, entry in data["variables"].items():
            if entry["encrypted"]:
                result[key] = crypto.decrypt_value(entry["value"], self.password, self.salt_path)
            else:
                result[key] = entry["value"]
        return result
