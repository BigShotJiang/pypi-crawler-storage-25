"""Click CLI for env-sync."""

import sys
import platform
from pathlib import Path
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from . import config as cfg
from .store import Store
from .diff import diff_environments, display_diff
from .export_import import import_env, export_env
from .secret_detector import detect_secrets_in_path, detect_secrets_in_file
from .rotation import rotate_key, generate_secret
from .audit import get_audit_log, log_access
from .sync import create_bundle, receive_bundle
from .git_hook import check_staged_files, install_hook
from . import crypto

console = Console()


def _get_password() -> str:
    """Get encryption password from env var or prompt."""
    import os
    password = os.environ.get("ENV_SYNC_PASSWORD", "")
    if not password:
        password = click.prompt("Enter encryption password", hide_input=True)
    return password


def _get_machine() -> str:
    return platform.node() or "unknown"


@click.group()
@click.version_option(version="0.1.0")
def cli():
    """env-sync — Manage and sync .env files across machines."""
    pass


@cli.command()
def init():
    """Initialize env-sync in current project."""
    if cfg.is_initialized():
        console.print("[yellow]env-sync already initialized.[/yellow]")
        return

    cfg.init_dir()
    console.print("[green]✓[/green] env-sync initialized.")
    console.print("  Created .env-sync/ directory")
    console.print("  Run [bold]env-sync add KEY=VALUE[/bold] to add variables")


@cli.command()
@click.argument("key_value")
def add(key_value: str):
    """Add a variable (KEY=VALUE)."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized. Run 'env-sync init' first.[/red]")
        sys.exit(1)

    if "=" not in key_value:
        console.print("[red]✗ Format: KEY=VALUE[/red]")
        sys.exit(1)

    key, value = key_value.split("=", 1)
    password = _get_password()
    store = Store(password=password)

    is_secret = _looks_like_secret(key)
    store.add(key, value, encrypted=is_secret)
    log_access(Path.cwd(), key, "add", _get_machine())

    icon = "🔒" if is_secret else "🔓"
    console.print(f"[green]✓[/green] Added {key} {icon}")


def _looks_like_secret(key: str) -> bool:
    indicators = ["password", "secret", "token", "key", "auth", "credential", "private", "database_url", "db_url", "redis_url"]
    return any(i in key.lower() for i in indicators)


@cli.command()
@click.argument("key")
def get(key: str):
    """Get a variable value."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)
    value = store.get(key)

    if value is None:
        console.print(f"[yellow]Key '{key}' not found.[/yellow]")
        sys.exit(1)

    log_access(Path.cwd(), key, "read", _get_machine())
    console.print(value)


@cli.command("list")
def list_vars():
    """List all variables (secrets masked)."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)
    variables = store.list_all()

    if not variables:
        console.print("[yellow]No variables stored.[/yellow]")
        return

    table = Table(title=f"Environment Variables ({len(variables)})")
    table.add_column("KEY", style="cyan")
    table.add_column("VALUE")
    table.add_column("SOURCE")
    table.add_column("ENCRYPTED")

    for key in sorted(variables.keys()):
        entry = variables[key]
        encrypted = entry.get("encrypted", False)
        if encrypted:
            value_display = "••••••••"
            enc_display = "🔒 yes"
        else:
            val = entry.get("value", "")
            value_display = val if len(val) < 30 else val[:27] + "..."
            enc_display = "🔓 no"

        source = entry.get("source", ".env")
        table.add_row(key, value_display, source, enc_display)

    console.print(table)

    log_access(Path.cwd(), "*", "list", _get_machine())


@cli.command()
@click.argument("key")
def remove(key: str):
    """Remove a variable."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)

    if store.remove(key):
        log_access(Path.cwd(), key, "remove", _get_machine())
        console.print(f"[green]✓[/green] Removed {key}")
    else:
        console.print(f"[yellow]Key '{key}' not found.[/yellow]")


@cli.command()
@click.argument("env1")
@click.argument("env2")
def diff(env1: str, env2: str):
    """Compare two environments."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    result = diff_environments(env1, env2, password=password)
    display_diff(result)


@cli.command("export")
@click.option("--output", "-o", default=".env", help="Output file path")
def export_cmd(output: str):
    """Export to .env file."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)
    count = export_env(Path(output), store)
    console.print(f"[green]✓[/green] Exported {count} variables to {output}")


@cli.command("import")
@click.argument("filepath", required=False, default=".env")
def import_cmd(filepath: str):
    """Import from existing .env file."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    path = Path(filepath)
    if not path.exists():
        console.print(f"[red]✗ File not found: {filepath}[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)
    results = import_env(path, store)

    console.print(f"[green]✓[/green] Imported {len(results)} variables:")
    for key, is_secret in results:
        icon = "🔒" if is_secret else "🔓"
        console.print(f"  {key} {icon}")


@cli.command()
def encrypt():
    """Encrypt an existing .env file."""
    env_path = Path(".env")
    if not env_path.exists():
        console.print("[red]✗ No .env file found.[/red]")
        sys.exit(1)

    from .export_import import parse_env_file
    pairs = parse_env_file(env_path)

    password = _get_password()
    store = Store(password=password)

    for key, value in pairs:
        is_secret = _looks_like_secret(key)
        store.add(key, value, encrypted=is_secret)

    console.print(f"[green]✓[/green] Encrypted {len(pairs)} variables from .env")


@cli.command()
def decrypt():
    """Decrypt to .env file."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)
    count = export_env(Path(".env"), store)
    console.print(f"[green]✓[/green] Decrypted {count} variables to .env")


@cli.command()
@click.argument("passphrase", required=False)
def share(passphrase: str):
    """Share encrypted env bundle."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    if not passphrase:
        passphrase = click.prompt("Enter shared passphrase", hide_input=True)

    password = _get_password()
    store = Store(password=password)
    bundle_path = create_bundle(store, passphrase)

    console.print(f"[green]✓[/green] Created encrypted bundle: {bundle_path}")
    console.print("  Share this file and the passphrase with your team member (out-of-band)")


@cli.command()
@click.argument("bundle_path")
@click.argument("passphrase", required=False)
def receive(bundle_path: str, passphrase: str):
    """Receive and decrypt a shared bundle."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized. Run 'env-sync init' first.[/red]")
        sys.exit(1)

    path = Path(bundle_path)
    if not path.exists():
        console.print(f"[red]✗ Bundle not found: {bundle_path}[/red]")
        sys.exit(1)

    if not passphrase:
        passphrase = click.prompt("Enter shared passphrase", hide_input=True)

    password = _get_password()
    store = Store(password=password)
    imported = receive_bundle(store, path, passphrase)

    console.print(f"[green]✓[/green] Imported {len(imported)} variables:")
    for key in imported:
        console.print(f"  {key}")


@cli.command()
@click.argument("key")
def rotate(key: str):
    """Rotate a secret value (generate new random)."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    password = _get_password()
    store = Store(password=password)

    new_value = rotate_key(store, key, machine=_get_machine())
    if new_value is None:
        console.print(f"[yellow]Key '{key}' not found.[/yellow]")
        sys.exit(1)

    console.print(f"[green]✓[/green] Rotated {key}")
    console.print(f"  New value: {new_value}")


@cli.command()
def audit():
    """Show access log."""
    if not cfg.is_initialized():
        console.print("[red]✗ Not initialized.[/red]")
        sys.exit(1)

    entries = get_audit_log(Path.cwd())
    if not entries:
        console.print("[yellow]No audit entries.[/yellow]")
        return

    table = Table(title="Access Log (last 7 days)")
    table.add_column("TIMESTAMP", style="dim")
    table.add_column("KEY", style="cyan")
    table.add_column("ACTION")
    table.add_column("MACHINE")

    for entry in entries[-20:]:
        ts = entry.get("timestamp", "")[:16]
        table.add_row(ts, entry.get("key", ""), entry.get("action", ""), entry.get("machine", ""))

    console.print(table)


@cli.command()
@click.option("--install", is_flag=True, help="Install as git pre-commit hook")
def ci(install: bool):
    """Check for secrets in git-traged files."""
    if install:
        try:
            hook_path = install_hook()
            console.print(f"[green]✓[/green] Installed pre-commit hook: {hook_path}")
        except FileNotFoundError as e:
            console.print(f"[red]✗ {e}[/red]")
            sys.exit(1)
        return

    matches = check_staged_files()
    if not matches:
        console.print("[green]✓ No secrets detected in staged files.[/green]")
        return

    console.print(f"[red]✗ Found {len(matches)} potential secrets:[/red]\n")
    for m in matches:
        console.print(f"  {m.pattern_name} in {m.file}:{m.line_number}")
        console.print(f"    {m.line_content[:80]}")
        console.print()

    sys.exit(1)


if __name__ == "__main__":
    cli()
