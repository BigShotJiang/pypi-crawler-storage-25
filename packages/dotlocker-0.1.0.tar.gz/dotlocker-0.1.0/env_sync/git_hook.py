"""Pre-commit hook to detect secrets in git-tracked files."""

import subprocess
import sys
from pathlib import Path

from .secret_detector import detect_secrets_in_file


def get_staged_files() -> list[Path]:
    """Get list of staged files from git."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
            capture_output=True, text=True, check=True,
        )
        return [Path(f) for f in result.stdout.strip().splitlines() if f]
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []


def check_staged_files() -> list:
    """Check all staged files for secrets."""
    staged = get_staged_files()
    all_matches = []

    for filepath in staged:
        if not filepath.exists():
            continue
        if filepath.suffix in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".woff", ".woff2", ".ttf", ".eot", ".pdf", ".zip", ".tar", ".gz"}:
            continue
        matches = detect_secrets_in_file(filepath)
        all_matches.extend(matches)

    return all_matches


def install_hook() -> Path:
    """Install the pre-commit hook."""
    git_dir = Path.cwd() / ".git"
    if not git_dir.exists():
        raise FileNotFoundError("Not a git repository")

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    hook_path = hooks_dir / "pre-commit"
    hook_content = """#!/bin/sh
# env-sync pre-commit hook - check for secrets
env-sync ci
if [ $? -ne 0 ]; then
    echo "❌ Commit blocked: secrets detected. Use 'env-sync ci' for details."
    exit 1
fi
"""
    hook_path.write_text(hook_content)
    hook_path.chmod(0o755)
    return hook_path
