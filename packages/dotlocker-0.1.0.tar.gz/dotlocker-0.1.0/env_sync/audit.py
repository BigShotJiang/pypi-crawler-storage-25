"""Access audit logging."""

import json
from datetime import datetime
from pathlib import Path

from . import config as cfg


def log_access(project_path: Path, key: str, action: str, machine: str = "unknown") -> None:
    """Log an access event."""
    env_dir = cfg.get_env_sync_dir(project_path)
    audit_path = env_dir / cfg.AUDIT_FILE

    entries = []
    if audit_path.exists():
        try:
            entries = json.loads(audit_path.read_text())
        except (json.JSONDecodeError, ValueError):
            entries = []

    entries.append({
        "timestamp": datetime.now().isoformat(),
        "key": key,
        "action": action,
        "machine": machine,
    })

    # Keep last 1000 entries
    entries = entries[-1000:]
    audit_path.write_text(json.dumps(entries, indent=2))


def get_audit_log(project_path: Path, limit: int = 50) -> list[dict]:
    """Get recent audit log entries."""
    env_dir = cfg.get_env_sync_dir(project_path)
    audit_path = env_dir / cfg.AUDIT_FILE

    if not audit_path.exists():
        return []

    try:
        entries = json.loads(audit_path.read_text())
    except (json.JSONDecodeError, ValueError):
        return []

    return entries[-limit:]


def clear_audit_log(project_path: Path) -> None:
    """Clear the audit log."""
    env_dir = cfg.get_env_sync_dir(project_path)
    audit_path = env_dir / cfg.AUDIT_FILE
    audit_path.write_text("[]")
