from __future__ import annotations
"""Configuration management for env-sync."""

import json
from pathlib import Path

ENV_SYNC_DIR = ".env-sync"
STORE_FILE = "store.enc"
SALT_FILE = "salt"
AUDIT_FILE = "audit.json"
CONFIG_FILE = "config.json"


def get_env_sync_dir(project_path: Path | None = None) -> Path:
    """Get the .env-sync directory path."""
    base = project_path or Path.cwd()
    return base / ENV_SYNC_DIR


def is_initialized(project_path: Path | None = None) -> bool:
    """Check if env-sync is initialized in the project."""
    return get_env_sync_dir(project_path).exists()


def init_dir(project_path: Path | None = None) -> Path:
    """Initialize the .env-sync directory structure."""
    base = project_path or Path.cwd()
    env_dir = base / ENV_SYNC_DIR
    env_dir.mkdir(exist_ok=True)

    # Create gitignore to prevent committing encrypted blobs
    gitignore = env_dir / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text("# env-sync internal data - do not commit\n*.enc\nsalt\naudit.json\n")

    # Create default config
    config_path = env_dir / CONFIG_FILE
    if not config_path.exists():
        config = {
            "machine_id": None,
            "environments": ["default"],
            "current_env": "default",
        }
        config_path.write_text(json.dumps(config, indent=2))

    return env_dir


def load_config(project_path: Path | None = None) -> dict:
    """Load configuration."""
    config_path = get_env_sync_dir(project_path) / CONFIG_FILE
    if config_path.exists():
        return json.loads(config_path.read_text())
    return {"machine_id": None, "environments": ["default"], "current_env": "default"}


def save_config(config: dict, project_path: Path | None = None) -> None:
    """Save configuration."""
    config_path = get_env_sync_dir(project_path) / CONFIG_FILE
    config_path.write_text(json.dumps(config, indent=2))
