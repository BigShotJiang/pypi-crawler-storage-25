"""Encryption and decryption using AES-256-GCM."""

import os
import base64
import hashlib
import json
import platform
import uuid
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


def _get_machine_id() -> str:
    """Get a machine-specific identifier."""
    machine = platform.node() or "unknown"
    mac = uuid.getnode()
    return f"{machine}:{mac}"


def _derive_key(password: str, salt: bytes) -> bytes:
    """Derive a 256-bit key from password and salt using PBKDF2."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=600_000,
    )
    return kdf.derive(password.encode("utf-8"))


def _get_or_create_salt(salt_path: Path) -> bytes:
    """Load or generate a salt file."""
    if salt_path.exists():
        return base64.b64decode(salt_path.read_text().strip())
    salt = os.urandom(16)
    salt_path.write_text(base64.b64encode(salt).decode("utf-8"))
    return salt


def encrypt_value(plaintext: str, password: str, salt_path: Path) -> str:
    """Encrypt a string value. Returns base64-encoded ciphertext."""
    salt = _get_or_create_salt(salt_path)
    key = _derive_key(password, salt)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return base64.b64encode(nonce + ciphertext).decode("utf-8")


def decrypt_value(encrypted: str, password: str, salt_path: Path) -> str:
    """Decrypt a base64-encoded encrypted string."""
    salt = _get_or_create_salt(salt_path)
    key = _derive_key(password, salt)
    raw = base64.b64decode(encrypted)
    nonce = raw[:12]
    ciphertext = raw[12:]
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, None).decode("utf-8")


def encrypt_bundle(data: dict, passphrase: str) -> bytes:
    """Encrypt a dict into a bundle bytes using a passphrase."""
    salt = os.urandom(16)
    key = _derive_key(passphrase, salt)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    plaintext = json.dumps(data).encode("utf-8")
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    return salt + nonce + ciphertext


def decrypt_bundle(raw: bytes, passphrase: str) -> dict:
    """Decrypt a bundle back to dict."""
    salt = raw[:16]
    nonce = raw[16:28]
    ciphertext = raw[28:]
    key = _derive_key(passphrase, salt)
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return json.loads(plaintext.decode("utf-8"))
