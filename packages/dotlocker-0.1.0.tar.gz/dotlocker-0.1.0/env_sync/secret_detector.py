"""Secret detection using regex patterns."""

import re
from pathlib import Path
from dataclasses import dataclass


@dataclass
class SecretMatch:
    """A detected secret in a file."""
    file: str
    line_number: int
    line_content: str
    pattern_name: str
    match_value: str


PATTERNS = [
    ("AWS Access Key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS Secret Key", re.compile(r"(?i)aws[_\-]?secret[_\-]?access[_\-]?key\s*[=:]\s*\S+")),
    ("Generic API Key", re.compile(r"(?i)(api[_\-]?key|api[_\-]?secret)\s*[=:]\s*['\"]?\S{8,}['\"]?")),
    ("Generic Token", re.compile(r"(?i)(token|bearer|authorization)\s*[=:]\s*['\"]?\S{8,}['\"]?")),
    ("Password", re.compile(r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"]?\S{4,}['\"]?")),
    ("Private Key", re.compile(r"-----BEGIN\s+(RSA|EC|OPENSSH)\s+PRIVATE\s+KEY-----")),
    ("Database Connection", re.compile(r"(postgresql|mysql|mongodb|redis)://\S+")),
    ("Webhook URL", re.compile(r"(?i)(webhook|slack[_\-]?webhook)\s*[=:]\s*['\"]?https?://\S+['\"]?")),
    ("Generic Secret", re.compile(r"(?i)(secret|private[_\-]?key)\s*[=:]\s*['\"]?\S{8,}['\"]?")),
    ("JWT", re.compile(r"eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+")),
]

# Files to skip during scanning
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".env-sync", "venv", ".venv"}
SKIP_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".woff", ".woff2", ".ttf", ".eot", ".pdf", ".zip", ".tar", ".gz"}


def detect_secrets_in_file(filepath: Path) -> list[SecretMatch]:
    """Scan a file for potential secrets."""
    if filepath.suffix in SKIP_EXTENSIONS:
        return []

    matches = []
    try:
        lines = filepath.read_text(errors="ignore").splitlines()
    except (OSError, PermissionError):
        return []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//"):
            continue
        for name, pattern in PATTERNS:
            found = pattern.search(line)
            if found:
                matches.append(SecretMatch(
                    file=str(filepath),
                    line_number=i,
                    line_content=stripped,
                    pattern_name=name,
                    match_value=found.group(),
                ))
    return matches


def detect_secrets_in_path(path: Path) -> list[SecretMatch]:
    """Scan a directory recursively for secrets."""
    all_matches = []
    if path.is_file():
        return detect_secrets_in_file(path)

    for root, dirs, files in path.rglob("*"):
        # Skip certain directories
        root_path = Path(root) if not isinstance(root, Path) else root
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS] if isinstance(dirs, list) else dirs
        for f in files:
            filepath = Path(root) / f
            if filepath.suffix in SKIP_EXTENSIONS:
                continue
            all_matches.extend(detect_secrets_in_file(filepath))
    return all_matches


def detect_secrets_in_text(text: str, filename: str = "input") -> list[SecretMatch]:
    """Scan text content for secrets."""
    matches = []
    lines = text.splitlines()
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//"):
            continue
        for name, pattern in PATTERNS:
            found = pattern.search(line)
            if found:
                matches.append(SecretMatch(
                    file=filename,
                    line_number=i,
                    line_content=stripped,
                    pattern_name=name,
                    match_value=found.group(),
                ))
    return matches
