"""Import and export .env files."""

import re
from pathlib import Path

from .store import Store
from .secret_detector import detect_secrets_in_text


def parse_env_file(filepath: Path) -> list[tuple[str, str]]:
    """Parse a .env file into key-value pairs."""
    if not filepath.exists():
        return []

    pairs = []
    for line in filepath.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", line)
        if match:
            key = match.group(1)
            value = match.group(2).strip().strip("'\"")
            pairs.append((key, value))
    return pairs


def import_env(filepath: Path, store: Store, auto_detect_secrets: bool = True) -> list[tuple[str, bool]]:
    """Import variables from a .env file. Returns list of (key, was_secret)."""
    pairs = parse_env_file(filepath)
    results = []

    # Detect which lines contain secrets
    secret_keys = set()
    if auto_detect_secrets:
        content = filepath.read_text(errors="ignore")
        matches = detect_secrets_in_text(content, str(filepath))
        for m in matches:
            # Try to extract the key from the line
            key_match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=", m.line_content)
            if key_match:
                secret_keys.add(key_match.group(1))

    for key, value in pairs:
        is_secret = key in secret_keys or _looks_like_secret(key)
        store.add(key, value, encrypted=is_secret)
        results.append((key, is_secret))

    return results


def _looks_like_secret(key: str) -> bool:
    """Heuristic: does the key name suggest it's a secret?"""
    secret_indicators = [
        "password", "passwd", "pwd", "secret", "token", "key", "auth",
        "credential", "private", "api_key", "api_secret", "access_key",
        "database_url", "db_url", "redis_url", "connection_string",
    ]
    key_lower = key.lower()
    return any(ind in key_lower for ind in secret_indicators)


def export_env(filepath: Path, store: Store) -> int:
    """Export all variables to a .env file. Returns count of variables exported."""
    variables = store.list_all()
    if not variables:
        return 0

    lines = []
    for key in sorted(variables.keys()):
        entry = variables[key]
        value = store.get(key)
        if value is not None:
            # Quote values that contain spaces or special characters
            if any(c in value for c in " \t\n\"'#"):
                value = f'"{value}"'
            lines.append(f"{key}={value}")

    filepath.write_text("\n".join(lines) + "\n")
    return len(lines)
