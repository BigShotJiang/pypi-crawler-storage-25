from __future__ import annotations
"""Sync between machines via encrypted bundles."""

import json
from pathlib import Path

from . import crypto
from .store import Store


def create_bundle(store: Store, passphrase: str, output_path: Path | None = None) -> Path:
    """Create an encrypted bundle of all environment variables."""
    variables = store.get_all_decrypted()
    bundle_data = {
        "variables": {k: v for k, v in variables.items()},
        "metadata": {
            "source_machine": store.project_path.name,
        },
    }

    raw = crypto.encrypt_bundle(bundle_data, passphrase)
    if output_path is None:
        output_path = store.project_path / "env-sync-bundle.enc"
    output_path.write_bytes(raw)
    return output_path


def receive_bundle(store: Store, bundle_path: Path, passphrase: str) -> list[str]:
    """Receive and import an encrypted bundle. Returns list of imported keys."""
    raw = bundle_path.read_bytes()
    data = crypto.decrypt_bundle(raw, passphrase)

    imported = []
    for key, value in data.get("variables", {}).items():
        is_secret = True  # Assume all shared variables are secrets
        store.add(key, value, encrypted=is_secret)
        imported.append(key)

    return imported
