"""env-sync - CLI tool for managing and syncing .env files."""

__version__ = "0.1.0"
