from __future__ import annotations
"""Secret rotation and generation."""

import secrets
import string

from .store import Store
from .audit import log_access


def generate_secret(length: int = 32, charset: str | None = None) -> str:
    """Generate a cryptographically secure random string."""
    if charset is None:
        charset = string.ascii_letters + string.digits + "!@#$%^&*"
    return "".join(secrets.choice(charset) for _ in range(length))


def generate_api_key(prefix: str = "", length: int = 32) -> str:
    """Generate a random API key with optional prefix."""
    key = generate_secret(length, string.ascii_letters + string.digits)
    return f"{prefix}{key}" if prefix else key


def generate_password(length: int = 20) -> str:
    """Generate a strong random password."""
    return generate_secret(length, string.ascii_letters + string.digits + "!@#$%^&*()-_=+")


def generate_token(length: int = 40) -> str:
    """Generate a random token."""
    return secrets.token_urlsafe(length)


def rotate_key(store: Store, key: str, length: int = 32, machine: str = "unknown") -> str | None:
    """Rotate a secret by generating a new value."""
    entry = store.get_entry(key)
    if entry is None:
        return None

    new_value = generate_secret(length)
    store.add(key, new_value, encrypted=True)
    log_access(store.project_path, key, "rotate", machine)
    return new_value
