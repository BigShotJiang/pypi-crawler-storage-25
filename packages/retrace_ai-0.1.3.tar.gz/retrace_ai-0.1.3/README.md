# retrace

Record, replay, fork & share AI agent executions.

## Installation

```bash
pip install retrace
```

## Quick Start

```python
import retrace

retrace.configure(api_key="rt_live_...", project_id="your-project-id")

@retrace.record(name="my-agent")
def my_agent(prompt: str):
    import openai
    client = openai.OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

result = my_agent("What is the meaning of life?")
```

All OpenAI and Anthropic calls are automatically captured as spans.

## Configuration

```python
retrace.configure(
    api_key="rt_live_...",           # or RETRACE_API_KEY env var
    base_url="http://localhost:3001", # or RETRACE_BASE_URL env var
    project_id="...",                 # or RETRACE_PROJECT_ID env var
)
```

Set `RETRACE_ENABLED=false` to disable recording without changing code.

## OpenAI Auto-Capture

```python
import retrace
import openai

retrace.configure(api_key="rt_live_...")

@retrace.record(name="chat-agent")
def chat(prompt):
    client = openai.OpenAI()
    return client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )

chat("Hello!")
# All LLM calls, tokens, cost, and duration are captured automatically
```

## Anthropic Auto-Capture

```python
import retrace
import anthropic

retrace.configure(api_key="rt_live_...")

@retrace.record(name="claude-agent")
def ask_claude(prompt):
    client = anthropic.Anthropic()
    return client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}]
    )

ask_claude("Explain quantum computing")
```

## Manual Span Creation

```python
import retrace

retrace.configure(api_key="rt_live_...")

with retrace.record(name="custom-agent") as t:
    recorder = t._recorder if hasattr(t, '_recorder') else t

    span = recorder.start_span(
        name="web-search",
        span_type=retrace.SpanType.TOOL_CALL,
        input={"query": "latest news"}
    )
    # ... do work ...
    recorder.end_span(span.id, output={"results": [...]})

    t.output = "Done"
```

## Context Manager

```python
with retrace.record(name="my-agent", input={"prompt": "hello"}) as t:
    result = do_work()
    t.output = result
```

## Transport Options

The SDK uses WebSocket by default for real-time streaming. Falls back to HTTP if `websocket-client` is not installed.

```python
from retrace.transport import create_transport

# Force HTTP transport
transport = create_transport(mode="http")

# Force WebSocket
transport = create_transport(mode="ws")

# Auto-detect (default)
transport = create_transport(mode="auto")
```
