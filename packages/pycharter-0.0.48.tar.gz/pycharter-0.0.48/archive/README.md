# Archive

This directory is reserved for obsolete or no-longer-needed files from the repository.

Currently empty. The migration to the `src/` layout has been completed and all remnants have been removed.

Do not use archived code in active development. Remove items from this directory only when they are no longer needed for history or reference.
