```mermaid
flowchart TD
    %% Subgraph: Sources
    subgraph Sources [Data Sources]
        API[External APIs]
        LegacyDB[(Legacy DBs)]
        AppDB[(App Databases)]
        MQ[Message Queues / Kafka]
    end

    %% Subgraph: Ingestion Layer
    subgraph Ingestion [Ingestion Layer]
        CDC["CDC Connectors<br/>(Debezium)"]
        DagsterIngest[Dagster Ingestion Asset]
        Kafka[Kafka / Event Bus]
    end

    %% Connections to Ingestion
    API --> DagsterIngest
    LegacyDB --> DagsterIngest
    AppDB -.-> CDC --> Kafka
    MQ --> Kafka

    %% Subgraph: Batch Pipeline
    %% FIX: Added quotes around "Batch Pipeline (Dagster)"
    subgraph BatchPipeline ["Batch Pipeline (Dagster)"]
        S3Raw_Batch[S3 Raw Bucket]
        StagingDB[(Staging DB)]
        DQ_Raw{"Data Quality<br/>Check"}
        Transform_Batch[dbt / SQL Transformation]
        DQ_Serve{"Data Quality<br/>Check"}

        DagsterIngest --> S3Raw_Batch
        S3Raw_Batch --> DQ_Raw
        DQ_Raw -- Pass --> StagingDB
        StagingDB --> Transform_Batch
        Transform_Batch --> DQ_Serve
    end

    %% Subgraph: Streaming Pipeline
    %% FIX: Added quotes around "Streaming Pipeline (Improved)"
    subgraph StreamPipeline ["Streaming Pipeline (Improved)"]
        S3_Archive["S3 Archive<br/>(Firehose)"]
        StreamProc["Stream Processor<br/>(Flink/Spark/Consumer)"]

        subgraph Pattern [Inbox-Outbox Pattern]
            Inbox[(Inbox Table)]
            Logic[Business Logic]
            Outbox[(Outbox Table)]
        end

        RetryHandler[Retry Runner]
        DLQ[(Dead Letter Queue)]

        Kafka --> S3_Archive
        Kafka --> StreamProc
        StreamProc --> Inbox
        Inbox --> Logic --> Outbox

        %% Error Handling
        StreamProc -- Error --> RetryHandler
        RetryHandler -- Fail --> DLQ
        RetryHandler -- Retry --> Kafka
    end

    %% Subgraph: Serving
    subgraph Serving [Serving Layer]
        ServingDB[(Serving Database)]
        API_Layer[Data API / BI Tool]
    end

    %% Convergence
    DQ_Serve -- Pass --> ServingDB
    Outbox -- CDC/Relay --> ServingDB
    ServingDB --> API_Layer
    ```
