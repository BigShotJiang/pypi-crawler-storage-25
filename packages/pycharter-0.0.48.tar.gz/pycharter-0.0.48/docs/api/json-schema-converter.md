# JSON Schema Converter

Convert Pydantic models to JSON Schema.

## Overview

```python
from pycharter import to_dict, to_file, to_json
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int

schema = to_dict(User)
```

## API Reference

### Output Functions

::: pycharter.json_schema_converter.to_dict
    options:
      show_root_heading: true

::: pycharter.json_schema_converter.to_file
    options:
      show_root_heading: true

::: pycharter.json_schema_converter.to_json
    options:
      show_root_heading: true

## Examples

```python
from pycharter import to_dict, to_file, to_json
from pydantic import BaseModel

class Product(BaseModel):
    name: str
    price: float
    in_stock: bool = True

# To dictionary
schema = to_dict(Product)
print(schema)

# To JSON string
json_str = to_json(Product)

# To file
to_file(Product, "schemas/product.json")
```

## Round-Trip

```python
from pycharter import from_dict, to_dict

# Generate model from schema
User = from_dict(original_schema, "User")

# Convert back to schema
exported_schema = to_dict(User)

# Schemas should be equivalent
```

## See Also

- [Pydantic Generator](pydantic-generator.md)
