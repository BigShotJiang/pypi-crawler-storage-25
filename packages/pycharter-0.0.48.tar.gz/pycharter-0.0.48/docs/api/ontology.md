# Ontology API

The **semantic layer** (`pycharter.semantic.ontology`) provides types, parsers, and validators for field-level semantic annotations, concept vocabularies, and lineage. Field mappings (ontology) can be stored with data contracts and used for validation and governance.

See the [Ontology guide](../guides/ontology.md) for the conceptual overview.

## Core models

::: pycharter.semantic.ontology.models.FieldMapping
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.FieldBinding
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.FieldConceptBinding
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.Concept
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.ConceptScheme
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.Lineage
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.Relationship
    options:
      show_root_heading: true
      heading_level: 3

## Enumerations

::: pycharter.semantic.ontology.models.ConceptTier
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.ConceptType
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.models.RelationshipType
    options:
      show_root_heading: true
      heading_level: 3

## Parsing

::: pycharter.semantic.ontology.parser.parse_field_mapping
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.parser.parse_field_mapping_file
    options:
      show_root_heading: true
      heading_level: 3

## Validation

::: pycharter.semantic.ontology.validator.validate_field_mapping
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.validator.validate_field_mapping_payload
    options:
      show_root_heading: true
      heading_level: 3

## Taxonomy

::: pycharter.semantic.ontology.taxonomy.classify_concept
    options:
      show_root_heading: true
      heading_level: 3

::: pycharter.semantic.ontology.taxonomy.register_core_concept
    options:
      show_root_heading: true
      heading_level: 3

## See also

- [Ontology guide](../guides/ontology.md)
- [Contract Builder](contract-builder.md) — contracts can include `field_mapping` (ontology)
- [Contract Store](contract-store.md) — `get_field_mapping` / `store_field_mapping` by contract name and version
