# Pydantic Generator

Generate Pydantic models from JSON Schema.

## Overview

```python
from pycharter import from_dict, from_file, from_json

User = from_dict(schema, "User")
```

## API Reference

### Input Functions

::: pycharter.pydantic_generator.from_dict
    options:
      show_root_heading: true

::: pycharter.pydantic_generator.from_file
    options:
      show_root_heading: true

::: pycharter.pydantic_generator.from_json
    options:
      show_root_heading: true

::: pycharter.pydantic_generator.from_url
    options:
      show_root_heading: true

## Examples

```python
from pycharter import from_dict, from_file, from_json

# From dictionary
schema = {
    "type": "object",
    "version": "1.0.0",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"}
    }
}
User = from_dict(schema, "User")

# From file
Product = from_file("schemas/product.json", "Product")

# From JSON string
json_str = '{"type": "object", "properties": {...}}'
Model = from_json(json_str, "Model")

# Use the model
user = User(name="Alice", age=30)
print(user.model_dump())
```

## See Also

- [JSON Schema Converter](json-schema-converter.md)
- [Validator](validator.md)
