# Example Notebooks

Interactive Jupyter notebooks that mirror the former `pycharter/examples` scripts and extend the documentation.

| Notebook | Description |
|----------|-------------|
| [01_getting_started.ipynb](01_getting_started.ipynb) | Core features: validation, Validator, ETL pipeline, quality check |
| [02_etl_pipelines.ipynb](02_etl_pipelines.ipynb) | ETL pipelines: HTTP/file extraction, transformers, config-driven |
| [03_contracts.ipynb](03_contracts.ipynb) | Data contracts: parse, build from artifacts, PyCharter extensions |
| [04_validation_quality.ipynb](04_validation_quality.ipynb) | Validation & quality: basic/batch/contract validation, QualityCheck, thresholds, profiling |
| [05_contract_store.ipynb](05_contract_store.ipynb) | Contract store: in-memory, rules, versioning, production backends |
| [06_schema_conversion.ipynb](06_schema_conversion.ipynb) | JSON Schema ↔ Pydantic: from_dict/to_dict, nested, round-trip, formats |

Run locally: `jupyter notebook` or open in VS Code. Each notebook includes an "Open in Colab" badge when viewed on GitHub.
