# Ontology Governance RFC for Data Contracts

## Status

- Draft
- Author: PyCharter team
- Target release: phased rollout over 2-3 releases

## Context

PyCharter already has the core building blocks:

- Ontology relationship and concept-type control via `ontology_schema.yaml`
- Contract-level `ontology` section support
- Ontology collaboration primitives (branches, proposals, reviews)
- RDF / JSON-LD / SHACL capabilities

What is missing is a clear operating model that connects ontology governance to contract lifecycle and validation behavior.

## Problem Statement

Today, ontology is available but not yet fully operationalized as a governed semantic layer for contracts.

Main gaps:

1. Ontology payload in contracts is structurally permissive (`dict[str, Any]`) and can drift.
2. Approval workflow is generic and not policy-aware by concept tier/change type.
3. Contract validations do not consistently consume ontology relationships as executable checks.
4. No explicit contract semantic quality gates (coverage, mapping health, impact checks).

## Goals

1. Make ontology first-class and governed, without over-constraining early adoption.
2. Keep contracts focused on field-to-concept binding, not full concept redefinition.
3. Convert ontology into practical value:
   - Better data validation
   - Better ownership/stakeholder routing
   - Better impact analysis and change safety
4. Use existing ontology proposal/review UI and APIs as the governance control point.

## Non-goals

1. Full OWL reasoner or advanced inference engine in this phase.
2. Enforcing 100% semantic coverage from day one.
3. Replacing JSON Schema validations with ontology validations.

## Industry-Informed Pattern

Adopt a split model seen in ontology-centric data platforms:

1. Central Concept Registry (global truth):
   - Concept definitions, tiers, node kinds, lifecycle
   - Allowed predicate catalog
2. Contract Semantic Bindings (local truth):
   - Field -> concept binding
   - Local relationship hints and lineage references
3. Governed change workflow:
   - Proposals + approvals + merge gates
4. Runtime policy enforcement:
   - Validation checks and routing derived from ontology

This follows the same core direction as ontology-first enterprise platforms (for example, Palantir-style object/link governance), while remaining lightweight in PyCharter’s current architecture.

## Proposed Conceptual Model

## 1) Ontology Registry

System of record for:

- `concept_id`, label, definition, owner, tier, concept_type, status
- Relationships between concepts (`is_a`, `depends_on`, `governs`, etc.)
- Allowed relationship types from `ontology_schema.yaml`

## 2) Contract Semantic Bindings

Each data contract contains only semantic mappings for its fields:

```yaml
ontology:
  version: "1.1.0"
  field_bindings:
    customer_id:
      concept_id: CustomerIdentifier
      confidence: high
      relationships:
        - type: references
          target_field: customers.id
    total_amount:
      concept_id: MonetaryAmount
      relationships:
        - type: derived_from
          target_field: line_items.extended_amount
      lineage:
        source_system: billing_service
```

Notes:

- `concept_id` must resolve in the registry.
- `relationships.type` must be in allowed predicate set.
- Contracts should not redefine concept definitions unless in an explicit exception path.

## 3) Governance Policy

Governance depends on concept tier and change type:

1. `core` concepts:
   - Require central steward + domain owner approvals.
2. `domain` concepts:
   - Require domain owner approval.
3. `free` concepts:
   - Single approval or auto-merge with audit trail (configurable).

Change types:

- Add concept
- Update concept definition/tier/node_kind
- Deprecate concept
- Add/remove concept relationship
- Remap contract field to a different concept

## Integration With Current PyCharter Components

## Contract Parser and Schema

Current:

- `ontology` accepted but mostly opaque.

Proposed:

1. Add strict Pydantic models for `ontology.field_bindings`.
2. Enforce:
   - `concept_id` required
   - Known relationship types only
   - Optional confidence enum (`low`, `medium`, `high`)
3. Preserve backward compatibility:
   - Continue reading existing `fields` shape
   - Normalize to canonical `field_bindings` internally

Target files:

- `src/pycharter/db/schemas/data_contract.py`
- `src/pycharter/contract_parser/parser.py`
- `src/pycharter/wiki/ontology/validator.py`

## Ontology collaboration layer

Current:

- Proposals/reviews exist, but policy logic is thin.

Proposed:

1. Add policy evaluator:
   - Determine required approvers based on impacted concept tier + change type.
2. Add merge gates:
   - Ontology schema validation
   - Relationship catalog validation
   - SHACL validation (when RDF artifacts are available)
   - Impact report generation
3. Persist governance metadata:
   - Required approvals
   - Approval evidence
   - Gate run results

Target files:

- `src/pycharter/wiki/collaboration/proposals.py`
- `src/pycharter/wiki/collaboration/review.py`
- `src/pycharter/wiki/collaboration/permissions.py`
- `src/pycharter/db/models/semantic/` (proposal-related models; extend as needed)

## Ontology UI proposal flow

Use existing `/ontology/proposals` flow and add ontology-specific UX:

1. Proposal type selector (`concept_change`, `mapping_change`, `relationship_change`).
2. Auto-generated impact panel:
   - affected contracts
   - affected fields
   - owners to notify
3. Merge gate status panel:
   - pass/fail per gate
4. Approval requirement panel:
   - who must approve and why

Target files:

- `src/pycharter/ui/src/app/ontology/proposals/page.tsx`
- `src/pycharter/ui/src/components/ontology/CreateProposalModal.tsx`
- `src/pycharter/ui/src/components/ontology/ReviewList.tsx`

## Runtime Use in Data Contracts

Ontology should power concrete checks and operations:

1. Semantic coverage check
   - `% required fields mapped to concept_id`
   - Fail/warn thresholds by contract tier.
2. Referential integrity quality checks
   - `references` relationships become foreign-key quality checks.
3. Derivation lineage checks
   - `derived_from` relationships require valid upstream mapping evidence.
4. Policy checks
   - e.g. `pii`-tagged concepts require masking/governance metadata.
5. Stakeholder routing
   - Validation incidents route to concept owners + contract owners.

## API Changes (Draft)

Add or extend endpoints under the semantic API:

1. `POST /api/v1/semantic/proposals`:
   - include `proposal_type`, `change_set`, `impact_preview`
2. `POST /api/v1/semantic/proposals/{id}/validate`:
   - runs merge gates; returns structured results
3. `GET /api/v1/semantic/contracts/{contract_id}/semantic-health`:
   - coverage, invalid mappings, deprecated concept usage
4. `GET /api/v1/semantic/concepts/{concept_id}/impact`:
   - contract and field usage graph

## Data Model Changes (Draft)

Proposed additive changes:

1. `proposals` table:
   - `proposal_type`
   - `required_approvals`
   - `gate_status` (JSON)
2. `reviews` table:
   - optional `review_scope` (concept/mapping/global)
3. optional mapping audit table:
   - `contract_id`, `field_path`, `concept_id`, `status`, `changed_by`, timestamps

Keep existing `concepts`, `concept_relationships`, `field_concepts` models as base.

## Rollout Plan

## Phase 0 (Foundation)

1. Formalize canonical ontology-in-contract schema (`field_bindings`).
2. Add normalizer for legacy `fields` shape.
3. Add semantic health report endpoint (read-only).

Exit criteria:

- Existing contracts continue to parse.
- Semantic health can be computed for all active contracts.

## Phase 1 (Governed Proposals)

1. Add proposal types and policy-aware approval requirements.
2. Add merge validation endpoint and UI gate display.
3. Require successful gates before merge for `core` concepts.

Exit criteria:

- Core ontology changes blocked unless policy + gates pass.

## Phase 2 (Contract Enforcement)

1. Add semantic coverage policy checks to contract validation.
2. Add `references` and `derived_from` quality checks.
3. Add incident routing to concept + contract owners.

Exit criteria:

- Ontology adds measurable validation and governance value in production workflows.

## Phase 3 (Optimization)

1. Add impact simulation before concept deprecations.
2. Add recommendation tooling for unmapped fields (assisted mapping).
3. Add analytics dashboard (coverage, change lead time, validation defect trends).

## Success Metrics

1. Semantic coverage rate by contract/domain.
2. % contracts using deprecated concepts.
3. Proposal lead time (open -> merged).
4. Rejected/rolled-back ontology changes.
5. Validation defects detected via ontology-derived rules.
6. Mean time to route and resolve data incidents.

## Risks and Mitigations

1. Over-governance slows teams.
   - Mitigation: tiered policy; lighter defaults for `free/domain`.
2. Taxonomy sprawl.
   - Mitigation: concept de-dup checks and required broader/owner metadata.
3. Mapping quality inconsistency.
   - Mitigation: confidence levels + review requirements + health score visibility.
4. Backward compatibility issues.
   - Mitigation: normalization layer and phased enforcement.

## Open Questions

1. Should `field -> concept` be one-to-one or many-to-many by default?
2. Should `same_as/equivalent_to` be auto-collapsed in lineage/discovery views?
3. Should domain admins be able to override core concept mappings locally?
4. What minimum semantic coverage is required per contract maturity tier?

## Recommended Next Implementation Slice

Build the smallest vertical slice first:

1. Canonical `field_bindings` schema + parser normalizer.
2. Semantic health endpoint.
3. Proposal validation endpoint with:
   - relationship-type validation
   - concept existence check
   - coverage delta report

This delivers immediate value with low migration risk and sets up stricter governance later.
