# Ontology UI/UX Enhancement Plan

## Goal

Elevate the Ontology UI from a utilitarian page set into a high-signal workspace where users can immediately:

1. understand ontology + governance status,
2. navigate to relevant actions quickly, and
3. execute core workflows (discover -> propose -> validate -> merge) with low friction.

## Current Gaps

1. Landing page is card-based but visually flat and low-context.
2. Navigation is not persistent inside ontology workflows.
3. Governance state (gates/blockers/readiness) is not prominent enough.
4. Discovery and exploration actions are distributed without a command-center pattern.

## Design Principles

1. Search-first with explicit quick actions.
2. High information scent: users should know where to click in <5 seconds.
3. Dense but scannable: clear sections, hierarchy, and semantic color cues.
4. Progressive disclosure: overview first, detail second.
5. Workflow-oriented UX: reflect governance and ontology lifecycle states.

## Implemented (Phase 1 + partial Phase 2/4)

1. Ontology shell layout with persistent navigation and quick command bar:
   - `src/pycharter/ui/src/app/ontology/layout.tsx`
2. Redesigned command-center landing page:
   - strong hero, KPI strip, high-impact actions, workflow guidance
   - `src/pycharter/ui/src/app/ontology/page.tsx`
3. Proposal governance UX improvements:
   - gate status, merge blockers, validation action
   - `src/pycharter/ui/src/app/ontology/proposals/detail/page.tsx`
4. Proposal create modal now captures governance context:
   - proposal type + affected tiers
   - `src/pycharter/ui/src/components/ontology/CreateProposalModal.tsx`

## Planned Next Phases

## Phase 2: Command Center Data Density

1. Add live widgets:
   - open proposal count by tier
   - semantic health trends
   - deprecated concept usage alerts
2. Add “recent activity” feed from proposal/review/version history.
3. Add “attention queue” cards for blocking issues.

## Phase 3: Unified Explore Workspace

1. Merge concepts/search/discovery affordances into a split-pane workspace.
2. Add coordinated interactions:
   - selecting concept updates related fields + lineage preview.
3. Add keyboard shortcuts and action palette.

## Phase 4: Governance Experience

1. Proposal list with gate summary badges and readiness status.
2. Proposal detail impact panel:
   - affected contracts, fields, concepts.
3. Reviewer assistance:
   - checklist and auto-summarized gate findings.

## Phase 5: Polish + Instrumentation

1. UX telemetry:
   - time to first action,
   - search-to-action completion,
   - merge lead time.
2. Performance and skeleton-state tuning for dense screens.
3. Visual refinement for mobile responsiveness and accessibility checks.

## Metrics

1. Time from `/ontology` load to first meaningful action.
2. Proposal validation run rate before merge attempts.
3. Merge failure rate due to missing gates/approvals.
4. Discovery usage and concept mapping throughput.
5. Weekly active users in ontology surfaces.
