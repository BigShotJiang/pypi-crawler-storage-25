# Examples & Notebooks

PyCharter’s examples live in the **docs/notebooks/** directory as Jupyter notebooks. They cover the same topics as the old `pycharter/examples` scripts and are kept in sync with the current API.

## Notebooks

| Notebook | Contents |
|----------|----------|
| **01 Getting Started** | Validation, Validator class, a simple ETL pipeline, and a quality check. |
| **02 ETL Pipelines** | HTTP/file extraction, transformer showcase, chained transforms, config-driven pipelines. |
| **03 Data Contracts** | Parsing contracts (dict/file), building from artifacts, coercion and validation extensions. |
| **04 Validation & Quality** | Basic and batch validation, contract-based validation, QualityCheck, thresholds, DataProfiler. |
| **05 Contract Store** | In-memory store, coercion/validation rules, versioning, production backends (Postgres, MongoDB, Redis, SQLite). |
| **06 Schema Conversion** | JSON Schema → Pydantic and Pydantic → JSON Schema; nested types, round-trip, formats. |

## Where to run them

- **Local**: From the repo root, run `jupyter notebook docs/notebooks/` or open the `.ipynb` files in VS Code.
- **Colab**: Use the “Open in Colab” badge on each notebook when viewing the repo on GitHub (e.g. `docs/notebooks/01_getting_started.ipynb`).

## Related docs

- [Quick Start](getting-started/quickstart.md)
- [Tutorials](tutorials/index.md) (markdown tutorials)
- [API Reference](api/index.md)
