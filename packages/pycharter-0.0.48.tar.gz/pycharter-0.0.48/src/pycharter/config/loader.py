"""YAML/JSON configuration loader with environment variable substitution."""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml

from pycharter.shared.errors import ConfigError

logger = logging.getLogger(__name__)

_ENV_PATTERN = re.compile(
    r"\$\{(?P<var>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?::(?P<flag>[-?])(?P<val>[^}]*))?\}"
)


class ConfigLoader:
    """Loads data contract configs from YAML/JSON files.

    Supports environment variable substitution:
    - ``${VAR}`` -- replaced with env var (error if unset)
    - ``${VAR:-default}`` -- replaced with default if unset
    - ``${VAR:?error}`` -- raises ConfigError if unset

    Args:
        validate: Whether to validate against schema.
    """

    def __init__(self, validate: bool = True) -> None:
        self._validate = validate

    def load(self, path: str | Path) -> dict[str, Any]:
        """Load config from a YAML or JSON file.

        Args:
            path: Path to the config file.

        Returns:
            Parsed config dict with env vars substituted.

        Raises:
            ConfigError: If file not found or parse error.
        """
        file_path = Path(path)
        if not file_path.exists():
            raise ConfigError(
                f"Config file not found: {file_path}",
                path=str(file_path),
            )
        try:
            raw = file_path.read_text(encoding="utf-8")
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            raise ConfigError(
                f"Failed to parse YAML: {exc}",
                path=str(file_path),
            ) from exc
        if not isinstance(data, dict):
            raise ConfigError(
                "Config must be a YAML mapping",
                path=str(file_path),
            )
        return self.load_dict(data)

    def load_dict(self, config: dict[str, Any]) -> dict[str, Any]:
        """Process a config dict with env var substitution.

        Args:
            config: Raw config dict.

        Returns:
            Config with env vars substituted.
        """
        return _substitute_env_vars(config)


def _substitute_env_vars(obj: Any) -> Any:
    """Recursively substitute env vars in string values."""
    if isinstance(obj, str):
        return _ENV_PATTERN.sub(_env_replacer, obj)
    if isinstance(obj, dict):
        return {k: _substitute_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_env_vars(item) for item in obj]
    return obj


def _env_replacer(match: re.Match[str]) -> str:
    """Replace a single env var match."""
    var = match.group("var")
    flag = match.group("flag")
    val = match.group("val")
    env_value = os.environ.get(var)
    if env_value is not None:
        return env_value
    if flag == "-":
        return val or ""
    if flag == "?":
        raise ConfigError(
            f"Required env var '{var}' not set: {val or ''}",
        )
    raise ConfigError(
        f"Env var '{var}' not set (use ${{var:-default}} for fallback)",
    )
