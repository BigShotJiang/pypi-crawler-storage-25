"""Internal config helpers: file lookup and .cfg reader."""

from __future__ import annotations

import logging
from configparser import ConfigParser
from pathlib import Path

logger = logging.getLogger(__name__)

_CONFIG_FILENAME = "pycharter.cfg"
_MAX_PARENT_WALK = 5


def find_config_file(filename: str = _CONFIG_FILENAME) -> Path | None:
    """Locate a config file by searching standard locations.

    Search order:
        1. Current working directory
        2. ``~/.pycharter/``
        3. Package/project directory (directory containing the pycharter package)
        4. Project root (directory containing alembic.ini)
    """
    for p in [Path.cwd() / filename, Path.home() / ".pycharter" / filename]:
        if p.exists():
            return p

    try:
        import pycharter

        start = Path(pycharter.__file__).resolve().parent
        for _ in range(10):
            cand = start / filename
            if cand.exists():
                return cand
            parent = start.parent
            if parent == start:
                break
            start = parent
    except (ImportError, AttributeError):
        pass

    current = Path.cwd()
    for _ in range(_MAX_PARENT_WALK):
        if (current / "alembic.ini").exists():
            cand = current / filename
            if cand.exists():
                return cand
        current = current.parent
    return None


def _cfg(section: str, key: str) -> str | None:
    """Read a single value from pycharter.cfg."""
    path = find_config_file(_CONFIG_FILENAME)
    if not path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        logger.debug(
            "Failed to read config from %s [%s].%s", path, section, key, exc_info=True
        )
    return None
