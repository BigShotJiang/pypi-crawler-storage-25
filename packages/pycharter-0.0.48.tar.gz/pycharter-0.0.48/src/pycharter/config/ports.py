"""Default local development ports (aligned with workspace PORTS.md)."""

from __future__ import annotations

UI_PORT = 3002
API_PORT = 8002
DOCS_PORT = 5002
