"""Version-based conflict resolution (Excalidraw algorithm)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class VersionedField:
    """A config field with version tracking for reconciliation.

    Attributes:
        id: Unique field identifier.
        version: Incremented on every local edit.
        version_nonce: Random value for tie-breaking.
        value: The field's current value.
    """

    id: str
    version: int
    version_nonce: int
    value: Any


def reconcile(
    local: dict[str, VersionedField],
    remote: list[VersionedField],
    *,
    editing_id: str | None = None,
) -> dict[str, VersionedField]:
    """Merge remote fields into local state.

    Uses Excalidraw's deterministic algorithm:
    - Currently-editing field: always keep local
    - Higher version wins
    - Equal version: lower version_nonce wins
    - Unknown remote fields are added

    Args:
        local: Current local fields keyed by ID.
        remote: Incoming remote fields.
        editing_id: ID of the field being actively edited
            (always keeps local version).

    Returns:
        Merged field map.
    """
    result = dict(local)
    for remote_field in remote:
        fid = remote_field.id
        local_field = local.get(fid)

        if local_field is None:
            # New field from remote -- accept it
            result[fid] = remote_field
            continue

        if fid == editing_id:
            # User is editing this field -- keep local
            continue

        if _should_accept_remote(local_field, remote_field):
            result[fid] = remote_field

    return result


def _should_accept_remote(
    local: VersionedField,
    remote: VersionedField,
) -> bool:
    """Determine if the remote version should replace local."""
    if remote.version > local.version:
        return True
    if remote.version == local.version:
        return remote.version_nonce < local.version_nonce
    return False
