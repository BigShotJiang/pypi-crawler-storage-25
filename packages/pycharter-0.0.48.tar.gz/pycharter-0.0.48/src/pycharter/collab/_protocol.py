"""Protocol constants and message types for collaboration."""

from __future__ import annotations

import enum


class WSSubtype(enum.StrEnum):
    """Message subtypes sent inside encrypted payloads."""

    CONFIG_INIT = "CONFIG_INIT"
    CONFIG_UPDATE = "CONFIG_UPDATE"
    CURSOR_LOCATION = "CURSOR_LOCATION"
    IDLE_STATUS = "IDLE_STATUS"
    USER_SELECTION = "USER_SELECTION"
    NOTE_STATE_UPSERT = "NOTE_STATE_UPSERT"
    NOTE_STATE_DELETE = "NOTE_STATE_DELETE"
    NOTE_TRANSITION_UPSERT = "NOTE_TRANSITION_UPSERT"
    NOTE_TRANSITION_DELETE = "NOTE_TRANSITION_DELETE"


# Socket.IO event names (matching Excalidraw's protocol)
EVENT_JOIN_ROOM = "join-room"
EVENT_INIT_ROOM = "init-room"
EVENT_FIRST_IN_ROOM = "first-in-room"
EVENT_NEW_USER = "new-user"
EVENT_ROOM_USER_CHANGE = "room-user-change"
EVENT_SERVER_BROADCAST = "server-broadcast"
EVENT_CLIENT_BROADCAST = "client-broadcast"
EVENT_SERVER_VOLATILE_BROADCAST = "server-volatile-broadcast"
