"""Room ID and encryption key generation."""

from __future__ import annotations

import base64
import logging
import re
import secrets

logger = logging.getLogger(__name__)

# Room link format: #room={20 hex},{22 base64}
_ROOM_LINK_PATTERN = re.compile(r"^#room=([a-zA-Z0-9_-]+),([a-zA-Z0-9_-]+)$")

ROOM_ID_BYTES = 10  # 20 hex characters
KEY_BYTES = 16  # 128-bit AES key -> 22 base64 characters


def generate_room_id() -> str:
    """Generate a cryptographically random room ID.

    Returns:
        20-character hex string.
    """
    return secrets.token_hex(ROOM_ID_BYTES)


def generate_room_key() -> str:
    """Generate a 128-bit AES encryption key.

    Returns:
        22-character URL-safe base64 string.
    """
    raw = secrets.token_bytes(KEY_BYTES)
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_room_link(fragment: str) -> tuple[str, str] | None:
    """Parse a room link fragment.

    Args:
        fragment: URL hash fragment
            (e.g. ``#room=abc123,key456``).

    Returns:
        Tuple of (room_id, room_key) or None if invalid.
    """
    match = _ROOM_LINK_PATTERN.match(fragment)
    if not match:
        return None
    return match.group(1), match.group(2)


def build_room_link(room_id: str, room_key: str) -> str:
    """Build a room link fragment.

    Args:
        room_id: The room identifier.
        room_key: The encryption key.

    Returns:
        URL hash fragment: ``#room={id},{key}``.
    """
    return f"#room={room_id},{room_key}"
