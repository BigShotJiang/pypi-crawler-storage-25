"""Optional real-time collaboration module (Excalidraw-style).

Install: ``pip install pycharter[collab]``

Usage::

    from pycharter.collab import create_collab_app
    from fastapi import FastAPI

    app = FastAPI()
    collab_app = create_collab_app()
    app.mount("/collab", collab_app)

Clients connect via Socket.IO at ``/collab/socket.io/``.
The server is a stateless encrypted relay — it never sees
unencrypted data.
"""

from __future__ import annotations

from pycharter.collab._server import create_collab_app

__all__ = ["create_collab_app"]
