"""Pydantic configuration models and store factory for the DLQ.

Provides ``DLQConfig`` for YAML/env-var-driven setup and a
``create_store`` factory that instantiates the appropriate backend.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, ConfigDict

from pycharter.dlq._retry import BackoffStrategy

if TYPE_CHECKING:
    from pycharter.dlq._protocols import DeadLetterStore


class RetryConfig(BaseModel):
    """Retry engine configuration.

    Attributes:
        enabled: Whether automatic retry is active.
        max_retries: Maximum retry attempts before ignoring.
        backoff: Backoff algorithm (fixed, linear, exponential).
        base_delay_seconds: Base delay for the first retry.
        max_delay_seconds: Upper bound on computed delay.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    max_retries: int = 3
    backoff: BackoffStrategy = BackoffStrategy.EXPONENTIAL
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 300.0


class RetentionConfig(BaseModel):
    """TTL / retention configuration.

    Attributes:
        ttl_seconds: Time-to-live for pending records (``None`` = no TTL).
        resolved_retention_seconds: How long to keep resolved records.
        cleanup_interval_seconds: How often the cleaner loop runs.
    """

    model_config = ConfigDict(extra="forbid")

    ttl_seconds: int | None = None
    resolved_retention_seconds: int = 604_800  # 7 days
    cleanup_interval_seconds: float = 3600.0


class DLQConfig(BaseModel):
    """Top-level DLQ configuration.

    Attributes:
        enabled: Whether the DLQ is active.
        backend: Storage backend type.
        database_url: Connection URL for the database backend.
        table_name: Table name for the database backend.
        schema_name: PostgreSQL schema name (optional).
        storage_path: Directory path for the file backend.
        max_memory_size: Maximum records for the in-memory backend.
        retry: Retry engine sub-configuration.
        retention: TTL / retention sub-configuration.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    backend: Literal["memory", "database", "file"] = "memory"
    database_url: str | None = None
    table_name: str = "dead_letter_queue"
    schema_name: str | None = None
    storage_path: str | None = None
    max_memory_size: int = 10_000
    retry: RetryConfig = RetryConfig()
    retention: RetentionConfig = RetentionConfig()


def create_store(config: DLQConfig) -> DeadLetterStore:
    """Instantiate a DeadLetterStore from configuration.

    Args:
        config: A validated :class:`DLQConfig`.

    Returns:
        A store instance matching the configured backend.

    Raises:
        ValueError: If the backend requires a missing parameter.
    """
    if config.backend == "database":
        if not config.database_url:
            raise ValueError("database_url is required for the database backend")
        from pycharter.dlq.database_store import DatabaseDeadLetterStore

        return DatabaseDeadLetterStore(
            database_url=config.database_url,
            table_name=config.table_name,
            schema_name=config.schema_name,
        )

    if config.backend == "file":
        if not config.storage_path:
            raise ValueError("storage_path is required for the file backend")
        from pycharter.dlq.file_store import FileDeadLetterStore

        return FileDeadLetterStore(storage_path=config.storage_path)

    # Default: in-memory
    from pycharter.dlq.memory_store import InMemoryDeadLetterStore

    return InMemoryDeadLetterStore(max_size=config.max_memory_size)
