"""Core DLQ data types: record, status enum, query result, statistics.

These types form the data contract shared by all DLQ store backends and
are intentionally domain-agnostic so that any package can adopt them.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


class DLQStatus(StrEnum):
    """Lifecycle status of a dead-lettered record.

    Attributes:
        PENDING: Awaiting processing or retry.
        RETRYING: Currently being retried.
        RESOLVED: Successfully reprocessed or manually closed.
        IGNORED: Permanently skipped (e.g. max retries exceeded).
        EXPIRED: Removed by TTL policy.
    """

    PENDING = "pending"
    RETRYING = "retrying"
    RESOLVED = "resolved"
    IGNORED = "ignored"
    EXPIRED = "expired"


def _generate_record_id() -> str:
    """Generate a unique DLQ record ID (16-char hex)."""
    return uuid.uuid4().hex[:16]


@dataclass(frozen=True, slots=True)
class DeadLetterRecord:
    """Immutable record of a dead-lettered event or data item.

    Uses generic field names so any package (FSM worker, ETL pipeline, etc.)
    can adopt the same structure.

    Attributes:
        record_id: Unique identifier for this DLQ record.
        source_name: Scope identifier (machine name, pipeline name, etc.).
        reason: String value describing why the item was dead-lettered.
        error_message: Human-readable error description.
        error_type: Exception class name (or empty string).
        stage: Processing stage where failure occurred (free-form).
        payload: The actual data that failed processing.
        metadata: Arbitrary caller-supplied context.
        attempt: Which processing attempt failed.
        max_attempts: Maximum configured attempts.
        status: Current lifecycle status.
        retry_count: Number of times retried from DLQ.
        created_at: UTC timestamp when the record was created.
        updated_at: UTC timestamp of last status change.
        expires_at: Optional TTL expiry timestamp.
    """

    record_id: str = field(default_factory=_generate_record_id)
    source_name: str = ""
    reason: str = "unknown"
    error_message: str = ""
    error_type: str = ""
    stage: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    attempt: int = 1
    max_attempts: int = 5
    status: DLQStatus = DLQStatus.PENDING
    retry_count: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime | None = None
    expires_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize this record to a plain dictionary.

        Returns:
            Dict with all record fields; datetimes as ISO strings,
            status as its string value.
        """
        return {
            "record_id": self.record_id,
            "source_name": self.source_name,
            "reason": self.reason,
            "error_message": self.error_message,
            "error_type": self.error_type,
            "stage": self.stage,
            "payload": self.payload,
            "metadata": self.metadata,
            "attempt": self.attempt,
            "max_attempts": self.max_attempts,
            "status": str(self.status),
            "retry_count": self.retry_count,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }


@dataclass(frozen=True, slots=True)
class QueryResult:
    """Paginated query result from a DLQ store.

    Attributes:
        records: Matching records for the current page.
        total: Total number of matching records across all pages.
        has_more: Whether more records exist beyond this page.
        next_cursor: Opaque cursor for keyset pagination (database backend).
    """

    records: list[DeadLetterRecord] = field(default_factory=list)
    total: int = 0
    has_more: bool = False
    next_cursor: str | None = None


@dataclass(frozen=True, slots=True)
class DLQStatistics:
    """Aggregate statistics for dead-lettered records.

    Attributes:
        total: Total record count.
        by_reason: Count per reason string.
        by_status: Count per DLQStatus value.
        by_stage: Count per stage string.
    """

    total: int = 0
    by_reason: dict[str, int] = field(default_factory=dict)
    by_status: dict[str, int] = field(default_factory=dict)
    by_stage: dict[str, int] = field(default_factory=dict)
