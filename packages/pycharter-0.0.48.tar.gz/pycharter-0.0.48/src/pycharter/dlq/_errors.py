"""DLQ exception hierarchy.

Provides a base exception and domain-specific subclasses for dead letter
queue operations.
"""

from __future__ import annotations


class DLQError(Exception):
    """Base exception for all DLQ operations."""


class RecordNotFoundError(DLQError):
    """Raised when a DLQ record cannot be found by its ID.

    Attributes:
        record_id: The ID that was looked up.
    """

    def __init__(self, record_id: str) -> None:
        self.record_id = record_id
        super().__init__(f"DLQ record not found: {record_id}")


class StoreError(DLQError):
    """Raised when a storage backend encounters an unrecoverable error.

    Attributes:
        backend: Name of the backend that failed (e.g. ``"database"``, ``"file"``).
        detail: Human-readable description of the failure.
    """

    def __init__(self, backend: str, detail: str) -> None:
        self.backend = backend
        self.detail = detail
        super().__init__(f"DLQ store error ({backend}): {detail}")


class ConfigError(DLQError):
    """Raised when DLQ configuration is invalid."""
