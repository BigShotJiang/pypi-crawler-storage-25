"""Thread-safe, bounded in-memory dead letter store.

Stores records in an ordered dict with FIFO eviction when the maximum
size is reached.  Suitable for development, testing, and lightweight
single-process deployments where persistence is not required.
"""

from __future__ import annotations

import dataclasses
import logging
import threading
from collections import OrderedDict
from datetime import UTC, datetime
from typing import Any

from pycharter.dlq._types import (
    DeadLetterRecord,
    DLQStatistics,
    DLQStatus,
    QueryResult,
)

logger = logging.getLogger(__name__)


class InMemoryDeadLetterStore:
    """Thread-safe, bounded in-memory dead letter store.

    Records are kept in insertion order.  When *max_size* is reached the
    oldest records are evicted (FIFO).

    Args:
        max_size: Maximum number of records to store.
    """

    def __init__(self, max_size: int = 10_000) -> None:
        self._max_size = max_size
        self._records: OrderedDict[str, DeadLetterRecord] = OrderedDict()
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    async def add(self, record: DeadLetterRecord) -> None:
        """Add a record, evicting oldest if at capacity.

        Args:
            record: The record to store.
        """
        with self._lock:
            if record.record_id in self._records:
                return
            while len(self._records) >= self._max_size:
                self._records.popitem(last=False)
            self._records[record.record_id] = record

    async def add_batch(self, records: list[DeadLetterRecord]) -> int:
        """Add multiple records in a single lock acquisition.

        Args:
            records: Records to store.

        Returns:
            Number of records actually inserted.
        """
        inserted = 0
        with self._lock:
            for record in records:
                if record.record_id in self._records:
                    continue
                while len(self._records) >= self._max_size:
                    self._records.popitem(last=False)
                self._records[record.record_id] = record
                inserted += 1
        return inserted

    async def get(self, record_id: str) -> DeadLetterRecord | None:
        """Retrieve a single record by ID.

        Args:
            record_id: The unique record identifier.

        Returns:
            The record if found, or ``None``.
        """
        with self._lock:
            return self._records.get(record_id)

    # ------------------------------------------------------------------
    # Query with pagination
    # ------------------------------------------------------------------

    async def query(
        self,
        *,
        source_name: str | None = None,
        reason: str | None = None,
        stage: str | None = None,
        status: DLQStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cursor: str | None = None,
    ) -> QueryResult:
        """Query records with optional filters, newest first.

        Args:
            source_name: Filter by source name.
            reason: Filter by reason string.
            stage: Filter by processing stage.
            status: Filter by lifecycle status.
            limit: Maximum records per page.
            offset: Number of records to skip.
            cursor: Ignored for in-memory store (offset-only).

        Returns:
            A :class:`QueryResult` with the matching page.
        """
        with self._lock:
            filtered = self._apply_filters(
                source_name=source_name,
                reason=reason,
                stage=stage,
                status=status,
            )
            total = len(filtered)
            page = filtered[offset : offset + limit]
            has_more = (offset + limit) < total
            return QueryResult(
                records=page,
                total=total,
                has_more=has_more,
            )

    def _apply_filters(
        self,
        *,
        source_name: str | None,
        reason: str | None,
        stage: str | None,
        status: DLQStatus | None,
    ) -> list[DeadLetterRecord]:
        """Return all matching records, newest first (caller holds lock)."""
        results: list[DeadLetterRecord] = []
        for record in reversed(self._records.values()):
            if source_name is not None and record.source_name != source_name:
                continue
            if reason is not None and record.reason != reason:
                continue
            if stage is not None and record.stage != stage:
                continue
            if status is not None and record.status != status:
                continue
            results.append(record)
        return results

    # ------------------------------------------------------------------
    # Status mutations
    # ------------------------------------------------------------------

    async def mark_retry(self, record_id: str) -> bool:
        """Mark a record as retrying and increment retry_count.

        Args:
            record_id: The record to mark.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(
            record_id,
            DLQStatus.RETRYING,
            increment_retry=True,
        )

    async def resolve(self, record_id: str) -> bool:
        """Mark a record as resolved.

        Args:
            record_id: The record to resolve.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(record_id, DLQStatus.RESOLVED)

    async def ignore(self, record_id: str) -> bool:
        """Mark a record as permanently ignored.

        Args:
            record_id: The record to ignore.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(record_id, DLQStatus.IGNORED)

    def _update_status(
        self,
        record_id: str,
        new_status: DLQStatus,
        *,
        increment_retry: bool = False,
    ) -> bool:
        """Replace a record with an updated status (caller-agnostic lock)."""
        with self._lock:
            record = self._records.get(record_id)
            if record is None:
                return False
            changes: dict[str, Any] = {
                "status": new_status,
                "updated_at": datetime.now(UTC),
            }
            if increment_retry:
                changes["retry_count"] = record.retry_count + 1
            self._records[record_id] = dataclasses.replace(record, **changes)
            return True

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    async def statistics(
        self,
        source_name: str | None = None,
    ) -> DLQStatistics:
        """Get aggregate statistics for stored records.

        Args:
            source_name: Optional filter by source name.

        Returns:
            A :class:`DLQStatistics` instance.
        """
        with self._lock:
            by_reason: dict[str, int] = {}
            by_status: dict[str, int] = {}
            by_stage: dict[str, int] = {}
            total = 0
            for record in self._records.values():
                if source_name is not None and record.source_name != source_name:
                    continue
                total += 1
                by_reason[record.reason] = by_reason.get(record.reason, 0) + 1
                status_key = str(record.status)
                by_status[status_key] = by_status.get(status_key, 0) + 1
                if record.stage:
                    by_stage[record.stage] = by_stage.get(record.stage, 0) + 1
            return DLQStatistics(
                total=total,
                by_reason=by_reason,
                by_status=by_status,
                by_stage=by_stage,
            )

    # ------------------------------------------------------------------
    # TTL / cleanup
    # ------------------------------------------------------------------

    async def purge_expired(self) -> int:
        """Delete records whose ``expires_at`` is in the past.

        Returns:
            Number of records removed.
        """
        now = datetime.now(UTC)
        with self._lock:
            to_remove = [
                rid
                for rid, rec in self._records.items()
                if rec.expires_at is not None and rec.expires_at <= now
            ]
            for rid in to_remove:
                del self._records[rid]
            return len(to_remove)

    async def purge_resolved(
        self,
        older_than: datetime | None = None,
    ) -> int:
        """Delete resolved records, optionally filtered by age.

        Args:
            older_than: If provided, only delete resolved records created
                before this timestamp.

        Returns:
            Number of records removed.
        """
        with self._lock:
            to_remove = [
                rid
                for rid, rec in self._records.items()
                if rec.status == DLQStatus.RESOLVED
                and (older_than is None or rec.created_at < older_than)
            ]
            for rid in to_remove:
                del self._records[rid]
            return len(to_remove)
