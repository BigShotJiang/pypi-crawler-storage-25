"""Automatic retry engine for dead-lettered records.

Provides configurable backoff strategies and a polling loop that queries
pending records, invokes a caller-supplied handler, and updates record
status based on the outcome.
"""

from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pycharter.dlq._protocols import DeadLetterStore, RetryHandler

logger = logging.getLogger(__name__)


class BackoffStrategy(StrEnum):
    """Backoff algorithm for spacing retry attempts.

    Attributes:
        FIXED: Constant delay between retries.
        LINEAR: Delay grows linearly with retry count.
        EXPONENTIAL: Delay doubles with each retry (capped).
    """

    FIXED = "fixed"
    LINEAR = "linear"
    EXPONENTIAL = "exponential"


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Configuration for automatic DLQ retry behaviour.

    Attributes:
        max_retries: Maximum number of retry attempts before ignoring.
        backoff: Backoff algorithm to use.
        base_delay_seconds: Base delay for the first retry.
        max_delay_seconds: Upper bound on computed delay.
        retryable_reasons: If set, only retry records with these reasons.
            ``None`` means all reasons are retryable.
    """

    max_retries: int = 3
    backoff: BackoffStrategy = BackoffStrategy.EXPONENTIAL
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 300.0
    retryable_reasons: frozenset[str] | None = None


@dataclass(frozen=True, slots=True)
class RetryResult:
    """Summary of a single retry processing pass.

    Attributes:
        processed: Number of records attempted.
        succeeded: Number resolved on this pass.
        failed: Number that failed and remain pending/retrying.
        ignored: Number permanently ignored (max retries exceeded).
    """

    processed: int = 0
    succeeded: int = 0
    failed: int = 0
    ignored: int = 0


def compute_delay(
    policy: RetryPolicy,
    retry_count: int,
) -> float:
    """Compute the delay in seconds before the next retry.

    Args:
        policy: Active retry policy.
        retry_count: Current retry count of the record.

    Returns:
        Delay in seconds, capped by ``policy.max_delay_seconds``.
    """
    base = policy.base_delay_seconds
    if policy.backoff == BackoffStrategy.FIXED:
        delay = base
    elif policy.backoff == BackoffStrategy.LINEAR:
        delay = base * (retry_count + 1)
    else:
        delay = base * math.pow(2, retry_count)
    return min(delay, policy.max_delay_seconds)


def _is_eligible(
    record_updated_at: datetime | None,
    retry_count: int,
    policy: RetryPolicy,
    now: datetime,
) -> bool:
    """Check whether a record is eligible for retry based on backoff."""
    if record_updated_at is None:
        return True
    delay = compute_delay(policy, retry_count)
    eligible_at = record_updated_at + timedelta(seconds=delay)
    return now >= eligible_at


class RetryEngine:
    """Polls a DLQ store and retries eligible records via a handler.

    Args:
        store: The dead letter store to query and update.
        policy: Retry policy controlling backoff and limits.
        handler: Caller-supplied handler that reprocesses records.
    """

    def __init__(
        self,
        store: DeadLetterStore,
        policy: RetryPolicy,
        handler: RetryHandler,
    ) -> None:
        self._store = store
        self._policy = policy
        self._handler = handler

    async def process_pending(self, limit: int = 50) -> RetryResult:
        """Query pending records, attempt retries, update statuses.

        Args:
            limit: Maximum number of records to process per pass.

        Returns:
            A :class:`RetryResult` summarising the pass.
        """
        from pycharter.dlq._types import DLQStatus

        result = await self._store.query(
            status=DLQStatus.PENDING,
            limit=limit,
        )

        now = datetime.now(UTC)
        processed = 0
        succeeded = 0
        failed = 0
        ignored = 0

        for record in result.records:
            # Check retryable reasons filter
            if (
                self._policy.retryable_reasons is not None
                and record.reason not in self._policy.retryable_reasons
            ):
                continue

            # Check backoff eligibility
            if not _is_eligible(
                record.updated_at, record.retry_count, self._policy, now
            ):
                continue

            # Check if max retries exceeded
            if record.retry_count >= self._policy.max_retries:
                await self._store.ignore(record.record_id)
                ignored += 1
                processed += 1
                logger.info(
                    "DLQ record %s ignored after %s retries",
                    record.record_id,
                    record.retry_count,
                )
                continue

            # Attempt retry
            await self._store.mark_retry(record.record_id)
            processed += 1

            try:
                ok = await self._handler.handle(record)
            except Exception:
                logger.exception("Retry handler raised for record %s", record.record_id)
                ok = False

            if ok:
                await self._store.resolve(record.record_id)
                succeeded += 1
                logger.debug("DLQ record %s resolved on retry", record.record_id)
            else:
                failed += 1
                logger.debug(
                    "DLQ record %s retry failed (count=%s)",
                    record.record_id,
                    record.retry_count + 1,
                )

        return RetryResult(
            processed=processed,
            succeeded=succeeded,
            failed=failed,
            ignored=ignored,
        )

    async def run_once(self) -> RetryResult:
        """Run a single retry pass.

        Returns:
            A :class:`RetryResult` summarising the pass.
        """
        return await self.process_pending()

    async def run_loop(self, interval_seconds: float = 60.0) -> None:
        """Run retry passes in a loop at the given interval.

        This is intended to be launched as an ``asyncio.Task`` in a worker
        process.  It runs indefinitely until the task is cancelled.

        Args:
            interval_seconds: Seconds to sleep between passes.
        """
        logger.info(
            "DLQ retry loop started (interval=%ss, max_retries=%s, backoff=%s)",
            interval_seconds,
            self._policy.max_retries,
            self._policy.backoff,
        )
        while True:
            try:
                result = await self.process_pending()
                if result.processed > 0:
                    logger.info(
                        "DLQ retry pass: processed=%s succeeded=%s "
                        "failed=%s ignored=%s",
                        result.processed,
                        result.succeeded,
                        result.failed,
                        result.ignored,
                    )
            except Exception:
                logger.exception("DLQ retry pass failed")
            await asyncio.sleep(interval_seconds)
