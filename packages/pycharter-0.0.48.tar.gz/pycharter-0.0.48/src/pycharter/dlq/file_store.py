"""File-backed dead letter store using JSON files.

Each record is persisted as a single JSON file in a configurable
directory.  Suitable for lightweight deployments or debugging where
human-readable output is preferred over database storage.
"""

from __future__ import annotations

import dataclasses
import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pycharter.dlq._types import (
    DeadLetterRecord,
    DLQStatistics,
    DLQStatus,
    QueryResult,
)

logger = logging.getLogger(__name__)


class FileDeadLetterStore:
    """Persist dead letter records as JSON files in a directory.

    File names follow the pattern ``{source_name}_{timestamp}_{record_id}.json``
    so that lexicographic sorting approximates chronological order.

    Args:
        storage_path: Directory where JSON files are written.  Created if
            it does not exist.
    """

    def __init__(self, storage_path: str | Path) -> None:
        self._path = Path(storage_path)
        self._path.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # File helpers
    # ------------------------------------------------------------------

    def _file_for(self, record: DeadLetterRecord) -> Path:
        """Build the file path for a record."""
        ts = record.created_at.strftime("%Y%m%d_%H%M%S")
        return self._path / f"{record.source_name}_{ts}_{record.record_id}.json"

    def _find_file(self, record_id: str) -> Path | None:
        """Find the JSON file for a given record_id."""
        for filepath in self._path.glob("*.json"):
            if record_id in filepath.stem:
                return filepath
        return None

    def _read_record(self, filepath: Path) -> DeadLetterRecord | None:
        """Read and parse a single JSON file into a record."""
        try:
            data = json.loads(filepath.read_text())
            return self._dict_to_record(data)
        except Exception as exc:
            logger.warning("Failed to read DLQ file %s: %s", filepath, exc)
            return None

    @staticmethod
    def _dict_to_record(data: dict[str, Any]) -> DeadLetterRecord:
        """Convert a deserialized JSON dict to a DeadLetterRecord."""
        created_at = datetime.fromisoformat(data["created_at"])
        updated_at = (
            datetime.fromisoformat(data["updated_at"])
            if data.get("updated_at")
            else None
        )
        expires_at = (
            datetime.fromisoformat(data["expires_at"])
            if data.get("expires_at")
            else None
        )
        try:
            status = DLQStatus(data.get("status", "pending"))
        except ValueError:
            status = DLQStatus.PENDING
        return DeadLetterRecord(
            record_id=data["record_id"],
            source_name=data["source_name"],
            reason=data["reason"],
            error_message=data.get("error_message", ""),
            error_type=data.get("error_type", ""),
            stage=data.get("stage", ""),
            payload=data.get("payload", {}),
            metadata=data.get("metadata", {}),
            attempt=data.get("attempt", 1),
            max_attempts=data.get("max_attempts", 5),
            status=status,
            retry_count=data.get("retry_count", 0),
            created_at=created_at,
            updated_at=updated_at,
            expires_at=expires_at,
        )

    def _write_record(self, record: DeadLetterRecord) -> None:
        """Serialize a record to its JSON file."""
        filepath = self._file_for(record)
        filepath.write_text(json.dumps(record.to_dict(), indent=2, default=str))

    def _all_records_sorted(self) -> list[DeadLetterRecord]:
        """Load all records from disk, sorted newest first."""
        records: list[DeadLetterRecord] = []
        for filepath in sorted(self._path.glob("*.json"), reverse=True):
            rec = self._read_record(filepath)
            if rec is not None:
                records.append(rec)
        return records

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    async def add(self, record: DeadLetterRecord) -> None:
        """Persist a record as a JSON file.

        Args:
            record: The record to store.
        """
        filepath = self._file_for(record)
        if filepath.exists():
            return
        self._write_record(record)
        logger.debug("Persisted DLQ record to file: %s", filepath)

    async def add_batch(self, records: list[DeadLetterRecord]) -> int:
        """Persist multiple records as JSON files.

        Args:
            records: Records to store.

        Returns:
            Number of records actually written.
        """
        written = 0
        for record in records:
            filepath = self._file_for(record)
            if filepath.exists():
                continue
            self._write_record(record)
            written += 1
        return written

    async def get(self, record_id: str) -> DeadLetterRecord | None:
        """Retrieve a single record by ID.

        Args:
            record_id: The unique record identifier.

        Returns:
            The record if found, or ``None``.
        """
        filepath = self._find_file(record_id)
        if filepath is None:
            return None
        return self._read_record(filepath)

    # ------------------------------------------------------------------
    # Query with pagination
    # ------------------------------------------------------------------

    async def query(
        self,
        *,
        source_name: str | None = None,
        reason: str | None = None,
        stage: str | None = None,
        status: DLQStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cursor: str | None = None,
    ) -> QueryResult:
        """Query records with optional filters, newest first.

        Args:
            source_name: Filter by source name.
            reason: Filter by reason string.
            stage: Filter by processing stage.
            status: Filter by lifecycle status.
            limit: Maximum records per page.
            offset: Number of records to skip.
            cursor: Ignored for file store (offset-only).

        Returns:
            A :class:`QueryResult` with the matching page.
        """
        all_records = self._all_records_sorted()
        filtered = _filter_records(
            all_records,
            source_name=source_name,
            reason=reason,
            stage=stage,
            status=status,
        )
        total = len(filtered)
        page = filtered[offset : offset + limit]
        has_more = (offset + limit) < total
        return QueryResult(
            records=page,
            total=total,
            has_more=has_more,
        )

    # ------------------------------------------------------------------
    # Status mutations
    # ------------------------------------------------------------------

    async def mark_retry(self, record_id: str) -> bool:
        """Mark a record as retrying and increment retry_count.

        Args:
            record_id: The record to mark.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(
            record_id,
            DLQStatus.RETRYING,
            increment_retry=True,
        )

    async def resolve(self, record_id: str) -> bool:
        """Mark a record as resolved.

        Args:
            record_id: The record to resolve.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(record_id, DLQStatus.RESOLVED)

    async def ignore(self, record_id: str) -> bool:
        """Mark a record as permanently ignored.

        Args:
            record_id: The record to ignore.

        Returns:
            ``True`` if the record was found and updated.
        """
        return self._update_status(record_id, DLQStatus.IGNORED)

    def _update_status(
        self,
        record_id: str,
        new_status: DLQStatus,
        *,
        increment_retry: bool = False,
    ) -> bool:
        """Read-modify-write a record's JSON file to update its status."""
        filepath = self._find_file(record_id)
        if filepath is None:
            return False
        record = self._read_record(filepath)
        if record is None:
            return False
        changes: dict[str, Any] = {
            "status": new_status,
            "updated_at": datetime.now(UTC),
        }
        if increment_retry:
            changes["retry_count"] = record.retry_count + 1
        updated = dataclasses.replace(record, **changes)
        filepath.write_text(json.dumps(updated.to_dict(), indent=2, default=str))
        return True

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    async def statistics(
        self,
        source_name: str | None = None,
    ) -> DLQStatistics:
        """Get aggregate statistics for stored records.

        Args:
            source_name: Optional filter by source name.

        Returns:
            A :class:`DLQStatistics` instance.
        """
        all_records = self._all_records_sorted()
        if source_name is not None:
            all_records = [r for r in all_records if r.source_name == source_name]

        by_reason: dict[str, int] = {}
        by_status: dict[str, int] = {}
        by_stage: dict[str, int] = {}
        for rec in all_records:
            by_reason[rec.reason] = by_reason.get(rec.reason, 0) + 1
            status_key = str(rec.status)
            by_status[status_key] = by_status.get(status_key, 0) + 1
            if rec.stage:
                by_stage[rec.stage] = by_stage.get(rec.stage, 0) + 1

        return DLQStatistics(
            total=len(all_records),
            by_reason=by_reason,
            by_status=by_status,
            by_stage=by_stage,
        )

    # ------------------------------------------------------------------
    # TTL / cleanup
    # ------------------------------------------------------------------

    async def purge_expired(self) -> int:
        """Delete record files whose ``expires_at`` is in the past.

        Returns:
            Number of files removed.
        """
        now = datetime.now(UTC)
        removed = 0
        for filepath in self._path.glob("*.json"):
            rec = self._read_record(filepath)
            if rec and rec.expires_at is not None and rec.expires_at <= now:
                filepath.unlink(missing_ok=True)
                removed += 1
        return removed

    async def purge_resolved(
        self,
        older_than: datetime | None = None,
    ) -> int:
        """Delete resolved record files, optionally filtered by age.

        Args:
            older_than: If provided, only delete resolved records created
                before this timestamp.

        Returns:
            Number of files removed.
        """
        removed = 0
        for filepath in self._path.glob("*.json"):
            rec = self._read_record(filepath)
            if rec is None:
                continue
            if rec.status != DLQStatus.RESOLVED:
                continue
            if older_than is not None and rec.created_at >= older_than:
                continue
            filepath.unlink(missing_ok=True)
            removed += 1
        return removed


def _filter_records(
    records: list[DeadLetterRecord],
    *,
    source_name: str | None,
    reason: str | None,
    stage: str | None,
    status: DLQStatus | None,
) -> list[DeadLetterRecord]:
    """Apply optional filters to a list of records."""
    result = records
    if source_name is not None:
        result = [r for r in result if r.source_name == source_name]
    if reason is not None:
        result = [r for r in result if r.reason == reason]
    if stage is not None:
        result = [r for r in result if r.stage == stage]
    if status is not None:
        result = [r for r in result if r.status == status]
    return result
