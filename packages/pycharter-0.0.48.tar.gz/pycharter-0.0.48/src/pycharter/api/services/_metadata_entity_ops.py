"""Entity CRUD and listing operations for the metadata service.

Internal module containing entity create, update, list, and artifact listing
logic. Re-exported via ``metadata_service`` for public consumption.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel
from sqlalchemy.orm import Session

from pycharter.api.utils import get_by_id_with_fallback, model_to_dict

from ._metadata_helpers import (
    DuplicateEntityError,
    EntityNotFoundError,
    InvalidIdFormatError,
)

# ---------------------------------------------------------------------------
# Entity listing
# ---------------------------------------------------------------------------

_ENTITY_MAP: dict[str, type] | None = None

_SUPPORTED_ENTITY_TYPES = frozenset(
    {
        "owners",
        "domains",
        "systems",
        "environments",
        "storage_locations",
        "tags",
    }
)


def _get_entity_map() -> dict[str, type]:
    """Return the entity-type-to-model mapping, importing models lazily."""
    global _ENTITY_MAP  # noqa: PLW0603
    if _ENTITY_MAP is None:
        from pycharter.db.models import (
            DomainModel,
            EnvironmentModel,
            OwnerModel,
            StorageLocationModel,
            SystemModel,
            TagModel,
        )

        _ENTITY_MAP = {
            "owners": OwnerModel,
            "domains": DomainModel,
            "systems": SystemModel,
            "environments": EnvironmentModel,
            "storage_locations": StorageLocationModel,
            "tags": TagModel,
        }
    return _ENTITY_MAP


def list_metadata_entities(
    entity_type: str,
    db: Session,
) -> list[dict[str, Any]]:
    """List all entities of the given type.

    Args:
        entity_type: One of ``owners``, ``domains``, ``systems``,
            ``environments``, ``storage_locations``, ``tags``.
        db: Active SQLAlchemy session.

    Returns:
        List of entity dictionaries.

    Raises:
        EntityNotFoundError: If *entity_type* is not a recognised type.
    """
    entity_map = _get_entity_map()

    if entity_type not in entity_map:
        raise EntityNotFoundError(
            f"Unknown entity type: {entity_type}. "
            f"Supported types: {', '.join(entity_map.keys())}"
        )

    model_class = entity_map[entity_type]
    entities = db.query(model_class).all()

    if entity_type == "storage_locations":
        return _enrich_storage_locations(entities)

    return [model_to_dict(entity) for entity in entities]


# ---------------------------------------------------------------------------
# Generic entity create / update
# ---------------------------------------------------------------------------


def create_entity(
    model_class: type,
    data: BaseModel,
    db: Session,
    *,
    unique_field: str = "name",
) -> dict[str, Any]:
    """Create a new entity after checking for duplicates.

    Args:
        model_class: SQLAlchemy model class to instantiate.
        data: Pydantic request model whose fields map to model columns.
        db: Active SQLAlchemy session.
        unique_field: Column name used for duplicate detection.

    Returns:
        Dictionary representation of the newly created entity.

    Raises:
        DuplicateEntityError: If an entity with the same *unique_field*
            value already exists.
    """
    unique_value = getattr(data, unique_field)
    column = getattr(model_class, unique_field)
    existing = db.query(model_class).filter(column == unique_value).first()
    if existing:
        entity_label = model_class.__tablename__.rstrip("s").replace("_", " ")
        raise DuplicateEntityError(
            f"{entity_label.title()} with {unique_field} "
            f"'{unique_value}' already exists"
        )

    field_values = data.model_dump(exclude_unset=False)
    entity = model_class(**field_values)
    db.add(entity)
    db.commit()
    db.refresh(entity)

    result = model_to_dict(entity)
    if model_class.__tablename__ == "storage_locations":
        _append_storage_location_relations(entity, result)
    return result


def update_entity(
    model_class: type,
    entity_id: str,
    data: BaseModel,
    db: Session,
    *,
    entity_label: str | None = None,
    validate_uuid: bool = True,
) -> dict[str, Any]:
    """Update an existing entity with only non-None fields.

    Args:
        model_class: SQLAlchemy model class.
        entity_id: Primary-key value (string or UUID-formatted string).
        data: Pydantic update request whose non-None fields are applied.
        db: Active SQLAlchemy session.
        entity_label: Human-friendly name for error messages.
        validate_uuid: When True, validate *entity_id* as a UUID.

    Returns:
        Dictionary representation of the updated entity.

    Raises:
        InvalidIdFormatError: If *entity_id* is not a valid UUID.
        EntityNotFoundError: If no entity with the given ID exists.
    """
    if entity_label is None:
        entity_label = model_class.__name__.replace("Model", "")

    if validate_uuid:
        _ensure_uuid_format(entity_id, entity_label)

    entity = get_by_id_with_fallback(db, model_class, entity_id)
    if entity is None:
        raise EntityNotFoundError(f"{entity_label} with ID '{entity_id}' not found")

    update_fields = data.model_dump(exclude_unset=True)
    for field_name, value in update_fields.items():
        if value is not None:
            setattr(entity, field_name, value)

    db.commit()
    db.refresh(entity)

    result = model_to_dict(entity)
    if model_class.__tablename__ == "storage_locations":
        _append_storage_location_relations(entity, result)
    return result


# ---------------------------------------------------------------------------
# Artifact listing
# ---------------------------------------------------------------------------


def list_artifacts(db: Session) -> dict[str, list[dict[str, Any]]]:
    """List all artifacts grouped by type.

    Args:
        db: Active SQLAlchemy session.

    Returns:
        Dictionary keyed by artifact type with lists of dicts.
    """
    from pycharter.db.models import (
        CoercionRuleModel,
        MetadataRecordModel,
        SchemaModel,
        ValidationRuleModel,
    )

    schemas = (
        db.query(SchemaModel).order_by(SchemaModel.title, SchemaModel.version).all()
    )
    coercion_rules = (
        db.query(CoercionRuleModel)
        .order_by(CoercionRuleModel.title, CoercionRuleModel.version)
        .all()
    )
    validation_rules = (
        db.query(ValidationRuleModel)
        .order_by(ValidationRuleModel.title, ValidationRuleModel.version)
        .all()
    )
    metadata_records = (
        db.query(MetadataRecordModel)
        .order_by(MetadataRecordModel.title, MetadataRecordModel.version)
        .all()
    )

    return {
        "schemas": [
            {"title": s.title, "version": s.version, "id": str(s.id)} for s in schemas
        ],
        "coercion_rules": [
            {"title": cr.title, "version": cr.version, "id": str(cr.id)}
            for cr in coercion_rules
        ],
        "validation_rules": [
            {"title": vr.title, "version": vr.version, "id": str(vr.id)}
            for vr in validation_rules
        ],
        "metadata": [
            {"title": mr.title, "version": mr.version, "id": str(mr.id)}
            for mr in metadata_records
        ],
    }


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _ensure_uuid_format(value: str, entity_label: str) -> None:
    """Validate that *value* looks like a UUID string."""
    from pycharter.api.utils import ensure_uuid

    try:
        ensure_uuid(value)
    except ValueError:
        raise InvalidIdFormatError(
            f"Invalid {entity_label.lower()} ID format: {value}"
        ) from None


def _enrich_storage_locations(
    entities: list[Any],
) -> list[dict[str, Any]]:
    """Convert storage location models to dicts and attach related names."""
    result: list[dict[str, Any]] = []
    for entity in entities:
        data = model_to_dict(entity)
        if entity.system:
            data["system_name"] = entity.system.name
        if entity.environment:
            data["environment_name"] = entity.environment.name
        result.append(data)
    return result


def _append_storage_location_relations(
    entity: Any,
    result: dict[str, Any],
) -> None:
    """Mutate *result* to include system_name / environment_name."""
    if entity.system:
        result["system_name"] = entity.system.name
    if entity.environment:
        result["environment_name"] = entity.environment.name
