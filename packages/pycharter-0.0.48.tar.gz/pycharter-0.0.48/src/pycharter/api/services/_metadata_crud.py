"""CRUD operations for schemas, metadata records, and rules.

Provides the public service functions for schema storage/retrieval,
metadata record storage/retrieval, rules storage/retrieval, and
reference-function listing. Entity CRUD lives in ``_metadata_entity_ops``.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.contract_store import ContractStoreClient
from pycharter.utils.version import compare_versions, get_latest_version

from ._metadata_helpers import (
    DuplicateContractError,
    InvalidVersionError,
    MetadataNotFoundError,
    RulesNotFoundError,
    SchemaListItemResult,
    SchemaNotFoundError,
    SchemaResult,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema storage
# ---------------------------------------------------------------------------


def store_schema(
    schema_name: str,
    version: str,
    schema_data: dict[str, Any],
    store: ContractStoreClient,
) -> str:
    """Validate version constraints and persist a schema.

    Args:
        schema_name: Human-readable name of the data contract.
        version: SemVer version string for the schema.
        schema_data: JSON Schema definition to store.
        store: Metadata store client instance.

    Returns:
        The contract ID assigned by the contract store.

    Raises:
        DuplicateContractError: If the same name+version combination exists.
        InvalidVersionError: If the version is not higher than the latest.
        ValueError: If the underlying store rejects the schema.
    """
    existing_contracts = [
        c
        for c in store.list_contracts()
        if (c.get("name") or c.get("title")) == schema_name
    ]

    if existing_contracts:
        for contract in existing_contracts:
            if contract.get("version") == version:
                raise DuplicateContractError(
                    f"Contract '{schema_name}' with version '{version}' "
                    f"already exists. Cannot create duplicate contracts. "
                    f"Use a different version number."
                )

        existing_versions = [
            c.get("version") for c in existing_contracts if c.get("version")
        ]
        latest = get_latest_version(existing_versions) if existing_versions else None

        if latest:
            if compare_versions(version, latest) <= 0:
                raise InvalidVersionError(
                    f"Version '{version}' must be higher than the latest "
                    f"existing version '{latest}' for contract "
                    f"'{schema_name}'. "
                    f"Existing versions: {', '.join(existing_versions)}"
                )

    return store.store_schema(schema_name, version, schema_data)


# ---------------------------------------------------------------------------
# Schema retrieval
# ---------------------------------------------------------------------------


def get_schema(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient,
) -> SchemaResult:
    """Retrieve a schema by contract name and version.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        store: Metadata store client instance.

    Returns:
        SchemaResult with the schema dict and version.

    Raises:
        SchemaNotFoundError: If no matching schema exists.
    """
    schema = store.get_schema(contract_name, contract_version)
    if not schema:
        raise SchemaNotFoundError(
            f"Schema not found for contract {contract_name!r} @ {contract_version!r}"
        )
    ver = schema.get("version") if isinstance(schema, dict) else None
    return SchemaResult(schema=schema, version=ver)


def get_complete_schema(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient,
) -> SchemaResult:
    """Retrieve a complete schema with rules merged.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        store: Metadata store client instance.

    Returns:
        SchemaResult with the complete schema dict and version.

    Raises:
        SchemaNotFoundError: If no matching schema exists.
    """
    complete = store.get_complete_schema(contract_name, contract_version)
    if not complete:
        raise SchemaNotFoundError(
            f"Schema not found for contract {contract_name!r} @ {contract_version!r}"
        )
    ver = complete.get("version") if isinstance(complete, dict) else None
    return SchemaResult(schema=complete, version=ver)


def list_schemas(store: ContractStoreClient) -> list[SchemaListItemResult]:
    """List all schemas in the contract store.

    Args:
        store: Metadata store client instance.

    Returns:
        List of SchemaListItemResult objects.
    """
    contracts = store.list_contracts()
    return [
        SchemaListItemResult(
            id=c.get("id", ""),
            name=c.get("name"),
            title=c.get("name"),
            version=c.get("version"),
        )
        for c in contracts
    ]


# ---------------------------------------------------------------------------
# Metadata storage and retrieval
# ---------------------------------------------------------------------------


def store_metadata_record(
    contract_name: str,
    contract_version: str,
    metadata: dict[str, Any],
    store: ContractStoreClient,
) -> str:
    """Store metadata for a schema in the contract store.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        metadata: Metadata dictionary to store.
        store: Metadata store client instance.

    Returns:
        The metadata ID assigned by the store.
    """
    return store.store_metadata(contract_name, contract_version, metadata)


def get_metadata(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient,
) -> dict[str, Any]:
    """Retrieve metadata for a data contract.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        store: Metadata store client instance.

    Returns:
        Metadata dictionary.

    Raises:
        MetadataNotFoundError: If no metadata exists for the contract.
    """
    metadata = store.get_metadata(contract_name, contract_version)
    if not metadata:
        raise MetadataNotFoundError(
            f"Metadata not found for contract {contract_name!r} @ {contract_version!r}"
        )
    return metadata


# ---------------------------------------------------------------------------
# Rules storage and retrieval
# ---------------------------------------------------------------------------


def store_coercion_rules(
    contract_name: str,
    contract_version: str,
    coercion_rules: dict[str, Any],
    store: ContractStoreClient,
) -> str:
    """Store coercion rules for a schema.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        coercion_rules: Coercion rules dictionary.
        store: Metadata store client instance.

    Returns:
        The rule ID assigned by the store.
    """
    return store.store_coercion_rules(contract_name, contract_version, coercion_rules)


def store_validation_rules(
    contract_name: str,
    contract_version: str,
    validation_rules: dict[str, Any],
    store: ContractStoreClient,
) -> str:
    """Store validation rules for a schema.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        validation_rules: Validation rules dictionary.
        store: Metadata store client instance.

    Returns:
        The rule ID assigned by the store.
    """
    return store.store_validation_rules(
        contract_name, contract_version, validation_rules
    )


def get_coercion_rules(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient,
) -> dict[str, Any]:
    """Retrieve coercion rules for a data contract.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        store: Metadata store client instance.

    Returns:
        Coercion rules dictionary.

    Raises:
        RulesNotFoundError: If no coercion rules exist.
    """
    rules = store.get_coercion_rules(contract_name, contract_version)
    if not rules:
        raise RulesNotFoundError(
            f"Coercion rules not found for contract "
            f"{contract_name!r} @ {contract_version!r}"
        )
    return rules


def get_validation_rules(
    contract_name: str,
    contract_version: str,
    store: ContractStoreClient,
) -> dict[str, Any]:
    """Retrieve validation rules for a data contract.

    Args:
        contract_name: Data contract name.
        contract_version: Data contract version.
        store: Metadata store client instance.

    Returns:
        Validation rules dictionary.

    Raises:
        RulesNotFoundError: If no validation rules exist.
    """
    rules = store.get_validation_rules(contract_name, contract_version)
    if not rules:
        raise RulesNotFoundError(
            f"Validation rules not found for contract "
            f"{contract_name!r} @ {contract_version!r}"
        )
    return rules


# ---------------------------------------------------------------------------
# Reference function listing
# ---------------------------------------------------------------------------


def list_coercion_functions() -> list[dict[str, str]]:
    """List built-in coercion functions with short descriptions.

    Returns:
        List of dicts with function name and description.
    """
    from pycharter.shared.coercions import (
        list_coercion_functions as _list,
    )

    return _list()


def list_validation_functions() -> list[dict[str, Any]]:
    """List built-in validation functions with descriptions and arguments.

    Returns:
        List of dicts with function details.
    """
    from pycharter.shared.validations import (
        list_validation_functions as _list,
    )

    return _list()
