"""Semantic schema CRUD business logic.

Extracts database operations and model conversions from the semantic
schema route handlers so that routes remain thin HTTP adapters.
Functions raise domain exceptions -- callers map them to HTTP responses.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.ontology.schema_loader import (
    get_concept_types,
    get_registry,
    get_relationship_types,
    get_tiers,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class SchemaItemNotFoundError(LookupError):
    """Raised when a schema item is not found."""


class SchemaItemConflictError(ValueError):
    """Raised when a schema item already exists."""


class SchemaItemProtectedError(PermissionError):
    """Raised when attempting to delete a built-in schema item."""


# ---------------------------------------------------------------------------
# Internal CRUD helpers
# ---------------------------------------------------------------------------


def _get_row(session: Any, model: type, name: str) -> Any:
    """Fetch a row by name or raise SchemaItemNotFoundError."""
    row = session.query(model).filter(model.name == name).first()
    if row is None:
        raise SchemaItemNotFoundError(f"Not found: {name}")
    return row


def _ensure_unique(session: Any, model: type, name: str, label: str) -> None:
    """Raise SchemaItemConflictError if a row with *name* already exists."""
    if session.query(model).filter(model.name == name).first():
        raise SchemaItemConflictError(f"{label} already exists: {name}")


def _delete_custom(session: Any, model: type, name: str, label: str) -> dict[str, str]:
    """Delete a non-built-in row by name."""
    row = _get_row(session, model, name)
    if row.is_builtin:
        raise SchemaItemProtectedError(f"Cannot delete built-in {label}")
    session.delete(row)
    session.flush()
    get_registry().invalidate()
    return {"status": "deleted"}


# ---------------------------------------------------------------------------
# Row-to-response converters
# ---------------------------------------------------------------------------


def rel_row_to_response(row: Any) -> dict[str, Any]:
    """Convert a RelationshipTypeModel row to a response dict."""
    return {
        "id": str(row.id),
        "name": row.name,
        "meaning": row.meaning or "",
        "graph_shape": row.graph_shape or "generic",
        "inverse": row.inverse or "",
        "symmetric": row.symmetric,
        "predicate": row.predicate,
        "domain_types": row.domain_types or [],
        "range_types": row.range_types or [],
        "is_builtin": row.is_builtin,
    }


def ct_row_to_response(row: Any) -> dict[str, Any]:
    """Convert a ConceptTypeModel row to a response dict."""
    return {
        "id": str(row.id),
        "name": row.name,
        "description": row.description or "",
        "is_builtin": row.is_builtin,
    }


def tier_row_to_response(row: Any) -> dict[str, Any]:
    """Convert a TierModel row to a response dict."""
    return {
        "id": str(row.id),
        "name": row.name,
        "description": row.description or "",
        "is_builtin": row.is_builtin,
    }


# ---------------------------------------------------------------------------
# Relationship type CRUD
# ---------------------------------------------------------------------------


def list_relationship_types(session: Any) -> list[dict[str, Any]]:
    """List all relationship types, falling back to YAML if DB is empty."""
    from pycharter.db.models.semantic.ontology_schema import RelationshipTypeModel

    try:
        rows = (
            session.query(RelationshipTypeModel)
            .order_by(RelationshipTypeModel.name)
            .all()
        )
        if rows:
            return [rel_row_to_response(r) for r in rows]
    except Exception:
        logger.debug(
            "DB query for relationship types failed, falling back to YAML",
            exc_info=True,
        )

    types = get_relationship_types()
    return [
        {
            "id": None,
            "name": name,
            "meaning": info.meaning,
            "graph_shape": info.graph_shape,
            "inverse": info.inverse,
            "symmetric": info.symmetric,
            "predicate": info.predicate,
            "domain_types": list(info.domain_types),
            "range_types": list(info.range_types),
            "is_builtin": info.is_builtin,
        }
        for name, info in types.items()
    ]


def create_relationship_type(session: Any, request: Any) -> dict[str, Any]:
    """Create a custom relationship type."""
    from pycharter.db.models.semantic.ontology_schema import RelationshipTypeModel

    _ensure_unique(session, RelationshipTypeModel, request.name, "Relationship type")
    row = RelationshipTypeModel(
        name=request.name,
        meaning=request.meaning,
        graph_shape=request.graph_shape,
        inverse=request.inverse or request.name,
        symmetric=request.symmetric,
        predicate=request.predicate,
        domain_types=request.domain_types,
        range_types=request.range_types,
        is_builtin=False,
    )
    session.add(row)
    session.flush()
    get_registry().invalidate()
    return rel_row_to_response(row)


def update_relationship_type(session: Any, name: str, request: Any) -> dict[str, Any]:
    """Update a relationship type."""
    from pycharter.db.models.semantic.ontology_schema import RelationshipTypeModel

    row = _get_row(session, RelationshipTypeModel, name)
    for attr in (
        "meaning",
        "graph_shape",
        "inverse",
        "symmetric",
        "predicate",
        "domain_types",
        "range_types",
    ):
        val = getattr(request, attr, None)
        if val is not None:
            setattr(row, attr, val)
    session.flush()
    get_registry().invalidate()
    return rel_row_to_response(row)


def delete_relationship_type(session: Any, name: str) -> dict[str, str]:
    """Delete a custom relationship type."""
    from pycharter.db.models.semantic.ontology_schema import RelationshipTypeModel

    return _delete_custom(session, RelationshipTypeModel, name, "relationship types")


# ---------------------------------------------------------------------------
# Concept type CRUD
# ---------------------------------------------------------------------------


def list_concept_types(session: Any) -> list[dict[str, Any]]:
    """List all concept types, falling back to YAML if DB is empty."""
    from pycharter.db.models.semantic.ontology_schema import ConceptTypeModel

    try:
        rows = session.query(ConceptTypeModel).order_by(ConceptTypeModel.name).all()
        if rows:
            return [ct_row_to_response(r) for r in rows]
    except Exception:
        logger.debug(
            "DB query for concept types failed, falling back to YAML",
            exc_info=True,
        )

    types = get_concept_types()
    return [
        {"id": None, "name": name, "description": desc, "is_builtin": True}
        for name, desc in types.items()
    ]


def create_concept_type(session: Any, request: Any) -> dict[str, Any]:
    """Create a custom concept type."""
    from pycharter.db.models.semantic.ontology_schema import ConceptTypeModel

    _ensure_unique(session, ConceptTypeModel, request.name, "Concept type")
    row = ConceptTypeModel(
        name=request.name, description=request.description, is_builtin=False
    )
    session.add(row)
    session.flush()
    get_registry().invalidate()
    return ct_row_to_response(row)


def update_concept_type(session: Any, name: str, request: Any) -> dict[str, Any]:
    """Update a concept type."""
    from pycharter.db.models.semantic.ontology_schema import ConceptTypeModel

    row = _get_row(session, ConceptTypeModel, name)
    row.description = request.description
    session.flush()
    get_registry().invalidate()
    return ct_row_to_response(row)


def delete_concept_type(session: Any, name: str) -> dict[str, str]:
    """Delete a custom concept type."""
    from pycharter.db.models.semantic.ontology_schema import ConceptTypeModel

    return _delete_custom(session, ConceptTypeModel, name, "concept types")


# ---------------------------------------------------------------------------
# Tier CRUD
# ---------------------------------------------------------------------------


def list_tiers(session: Any) -> list[dict[str, Any]]:
    """List all tiers, falling back to YAML if DB is empty."""
    from pycharter.db.models.semantic.ontology_schema import TierModel

    try:
        rows = session.query(TierModel).order_by(TierModel.name).all()
        if rows:
            return [tier_row_to_response(r) for r in rows]
    except Exception:
        logger.debug("DB query for tiers failed, falling back to YAML", exc_info=True)

    tiers = get_tiers()
    return [
        {"id": None, "name": name, "description": desc, "is_builtin": True}
        for name, desc in tiers.items()
    ]


def create_tier(session: Any, request: Any) -> dict[str, Any]:
    """Create a custom governance tier."""
    from pycharter.db.models.semantic.ontology_schema import TierModel

    _ensure_unique(session, TierModel, request.name, "Tier")
    row = TierModel(
        name=request.name, description=request.description, is_builtin=False
    )
    session.add(row)
    session.flush()
    get_registry().invalidate()
    return tier_row_to_response(row)


def update_tier(session: Any, name: str, request: Any) -> dict[str, Any]:
    """Update a tier."""
    from pycharter.db.models.semantic.ontology_schema import TierModel

    row = _get_row(session, TierModel, name)
    row.description = request.description
    session.flush()
    get_registry().invalidate()
    return tier_row_to_response(row)


def delete_tier(session: Any, name: str) -> dict[str, str]:
    """Delete a custom tier."""
    from pycharter.db.models.semantic.ontology_schema import TierModel

    return _delete_custom(session, TierModel, name, "tiers")
