"""Service layer for settings, database testing, and DLQ operations.

Encapsulates business logic extracted from the settings route handlers,
keeping route handlers thin and focused on HTTP concerns.

Connection testing, DLQ operations, and connection string building live in
``_db_testing`` and are re-exported here for a single import path.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from sqlalchemy.orm import Session

from pycharter import __version__ as pycharter_version

# Re-export DB testing operations for a single import path.
from pycharter.api.services._db_testing import (  # noqa: F401
    ConnectionBuildError,
    ConnectionTestResult,
    DlqStats,
    build_connection_string,
    get_dlq_stats,
    test_database_connection,
    test_dlq_connection,
)
from pycharter.config import get_database_url, get_ui_app_name, get_ui_theme

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class AppConfig:
    """Application configuration values for the UI."""

    theme: str
    app_name: str
    version: str


@dataclass(frozen=True, slots=True)
class DatabaseConfig:
    """Current database configuration info."""

    configured_url: str | None
    actual_url: str
    database_type: str
    is_default: bool
    contract_count: int
    message: str


# ---------------------------------------------------------------------------
# In-memory settings store
# ---------------------------------------------------------------------------

_settings_store: dict[str, dict[str, Any]] = {}

_DEFAULT_QUALITY_CONFIG: dict[str, Any] = {
    "default_check_preset": "basic",
    "metric_retention_days": 90,
    "scoring_weights": {
        "accuracy": 0.4,
        "completeness": 0.3,
        "violation_rate": 0.3,
    },
    "data_sources": [],
}

_DEFAULT_NOTIFICATION_CONFIG: dict[str, Any] = {
    "enabled": False,
    "channels": {
        "email": {
            "enabled": False,
            "smtp_host": "",
            "smtp_port": 587,
            "recipients": [],
        },
        "slack": {"enabled": False, "webhook_url": "", "channel": ""},
        "webhook": {"enabled": False, "url": "", "headers": {}},
    },
    "alert_rules": {
        "on_critical": True,
        "on_warning": False,
        "on_info": False,
    },
    "frequency": "immediate",
}


# ---------------------------------------------------------------------------
# App config
# ---------------------------------------------------------------------------


def get_app_config() -> AppConfig:
    """Build the application config for the UI.

    Returns:
        AppConfig with theme, app name, and version.
    """
    return AppConfig(
        theme=get_ui_theme(),
        app_name=get_ui_app_name(),
        version=pycharter_version or "",
    )


# ---------------------------------------------------------------------------
# Database config
# ---------------------------------------------------------------------------


def get_database_config(db: Session) -> DatabaseConfig:
    """Inspect the current database session and return configuration info.

    Args:
        db: Active SQLAlchemy session.

    Returns:
        DatabaseConfig describing the current connection.
    """
    from pycharter.db.models import DataContractModel

    configured_url = get_database_url()
    actual_url = str(db.bind.url) if hasattr(db, "bind") and db.bind else "unknown"

    database_type, is_default = _classify_database(actual_url, configured_url)

    try:
        contract_count = db.query(DataContractModel).count()
    except Exception:
        contract_count = -1

    message = _build_config_message(is_default, database_type, configured_url)
    masked_url = _mask_password(configured_url) if not is_default else configured_url
    display_actual = actual_url.split("@")[-1] if "@" in actual_url else actual_url

    return DatabaseConfig(
        configured_url=masked_url,
        actual_url=display_actual,
        database_type=database_type,
        is_default=is_default,
        contract_count=contract_count,
        message=message,
    )


# ---------------------------------------------------------------------------
# Quality / notification config
# ---------------------------------------------------------------------------


def get_quality_config() -> dict[str, Any]:
    """Return the current quality monitoring configuration.

    Returns:
        Quality config dictionary.
    """
    return _settings_store.get("quality", _DEFAULT_QUALITY_CONFIG.copy())


def update_quality_config(config: dict[str, Any]) -> dict[str, Any]:
    """Merge updates into the quality monitoring configuration.

    Args:
        config: Partial config dict to merge.

    Returns:
        Dict with ``updated`` flag and the merged config.
    """
    current = _settings_store.get("quality", _DEFAULT_QUALITY_CONFIG.copy())
    current.update(config)
    _settings_store["quality"] = current
    return {"updated": True, "config": current}


def get_notification_config() -> dict[str, Any]:
    """Return the current notification configuration.

    Returns:
        Notification config dictionary.
    """
    return _settings_store.get("notifications", _DEFAULT_NOTIFICATION_CONFIG.copy())


def update_notification_config(config: dict[str, Any]) -> dict[str, Any]:
    """Merge updates into the notification configuration.

    Args:
        config: Partial config dict to merge.

    Returns:
        Dict with ``updated`` flag and the merged config.
    """
    current = _settings_store.get("notifications", _DEFAULT_NOTIFICATION_CONFIG.copy())
    current.update(config)
    _settings_store["notifications"] = current
    return {"updated": True, "config": current}


def send_test_notification(channel: str) -> dict[str, Any]:
    """Validate notification config and send a test message.

    Args:
        channel: Channel name (email, slack, webhook).

    Returns:
        Dict with ``success`` flag and ``message``.
    """
    config = _settings_store.get("notifications", _DEFAULT_NOTIFICATION_CONFIG.copy())

    if not config.get("enabled"):
        return {"success": False, "message": "Notifications are disabled"}

    channel_config = config.get("channels", {}).get(channel)
    if not channel_config or not channel_config.get("enabled"):
        return {
            "success": False,
            "message": f"Channel '{channel}' is not configured",
        }

    logger.info("Test notification requested for channel: %s", channel)
    return {
        "success": True,
        "message": f"Test notification sent via {channel}",
    }


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _classify_database(actual_url: str, configured_url: str | None) -> tuple[str, bool]:
    """Determine database type and whether it is the default SQLite."""
    if actual_url.startswith("sqlite"):
        return "SQLite", configured_url is None
    if actual_url.startswith(("postgresql", "postgres")):
        return "PostgreSQL", False
    return "Unknown", False


def _mask_password(url: str | None) -> str | None:
    """Mask password in a connection URL."""
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" not in parts[0] or "://" not in parts[0]:
        return url
    scheme_user = parts[0].split("://", 1)[0]
    user_pass = parts[0].split("://", 1)[1]
    if ":" in user_pass:
        user, _ = user_pass.split(":", 1)
        return f"{scheme_user}://{user}:****@{parts[1]}"
    return url


def _build_config_message(
    is_default: bool,
    database_type: str,
    configured_url: str | None,
) -> str:
    """Build a human-readable message about the database configuration."""
    if is_default:
        return (
            "No database URL configured. Using default SQLite database.\n"
            "To use PostgreSQL, set the PYCHARTER_DATABASE_URL environment "
            "variable:\n"
            "  export PYCHARTER_DATABASE_URL="
            "'postgresql://user:password@localhost:5432/pycharter'"
        )
    return f"Using {database_type} database"
