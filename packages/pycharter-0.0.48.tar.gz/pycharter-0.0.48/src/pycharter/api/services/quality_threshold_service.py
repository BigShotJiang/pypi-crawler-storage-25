"""Quality SLA threshold business logic.

Extracts threshold (SLA) read/update logic from quality route handlers
so that routes remain thin HTTP adapters.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.contract_store import ContractStoreClient

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class ContractMetadataNotFoundError(LookupError):
    """Raised when contract metadata cannot be found in the store."""


class ContractStoreError(RuntimeError):
    """Raised when reading or writing contract metadata fails."""


# ---------------------------------------------------------------------------
# Public service functions
# ---------------------------------------------------------------------------


def get_thresholds(
    name: str,
    version: str,
    store: ContractStoreClient,
) -> dict[str, Any]:
    """Get quality SLA thresholds from a data contract.

    Args:
        name: Contract name.
        version: Contract version.
        store: Metadata store client.

    Returns:
        Dictionary with contract_name, contract_version, sla, and has_sla.

    Raises:
        ContractStoreError: If the store lookup fails.
        ContractMetadataNotFoundError: If the contract is not found.
    """
    try:
        metadata = store.get_metadata(name, version)
    except Exception as exc:
        raise ContractStoreError(
            f"Failed to retrieve contract metadata: {exc}"
        ) from exc

    if not metadata:
        raise ContractMetadataNotFoundError(f"Contract not found: {name}:{version}")

    dq = metadata.get("data_quality") if isinstance(metadata, dict) else {}
    sla = (dq or {}).get("sla") if isinstance(dq, dict) else None

    return {
        "contract_name": name,
        "contract_version": version,
        "sla": sla,
        "has_sla": sla is not None,
    }


def update_thresholds(
    name: str,
    version: str,
    thresholds: dict[str, Any],
    store: ContractStoreClient,
) -> dict[str, Any]:
    """Update quality SLA thresholds in a data contract's metadata.

    Args:
        name: Contract name.
        version: Contract version.
        thresholds: New threshold values (model_dump output).
        store: Metadata store client.

    Returns:
        Dictionary with contract_name, contract_version, sla, and updated flag.

    Raises:
        ContractStoreError: If the store read or write fails.
        ContractMetadataNotFoundError: If the contract is not found.
    """
    try:
        metadata = store.get_metadata(name, version)
    except Exception as exc:
        raise ContractStoreError(
            f"Failed to retrieve contract metadata: {exc}"
        ) from exc

    if not metadata:
        raise ContractMetadataNotFoundError(f"Contract not found: {name}:{version}")

    if not isinstance(metadata, dict):
        metadata = {}

    dq = metadata.get("data_quality", {}) or {}
    dq["sla"] = thresholds
    metadata["data_quality"] = dq

    try:
        store.update_metadata(name, version, metadata)
    except Exception as exc:
        raise ContractStoreError(f"Failed to update contract metadata: {exc}") from exc

    return {
        "contract_name": name,
        "contract_version": version,
        "sla": thresholds,
        "updated": True,
    }
