"""Quality metrics calculation, aggregation, and shared helpers.

Contains domain exceptions, serialization helpers, and service functions
for listing, retrieving, and querying quality metrics and violations.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from sqlalchemy import desc
from sqlalchemy.orm import Session

from pycharter.contract_store import ContractStoreClient
from pycharter.quality import (
    QualityCheck,
    QualityCheckOptions,
    QualityThresholds,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class QualityCheckValidationError(ValueError):
    """Raised when quality check request parameters are invalid."""


class QualityMetricNotFoundError(LookupError):
    """Raised when a quality metric cannot be found."""


class QualityReportNotFoundError(LookupError):
    """Raised when quality reports cannot be found for a schema."""


# ---------------------------------------------------------------------------
# Shared helpers (private)
# ---------------------------------------------------------------------------


def _serialize_metric(metric: Any) -> dict[str, Any]:
    """Serialize a QualityMetricModel to a plain dict.

    Args:
        metric: A QualityMetricModel instance.

    Returns:
        Serialized metric dictionary.
    """
    return {
        "id": str(metric.id),
        "schema_id": metric.schema_id,
        "schema_version": metric.schema_version,
        "data_contract_id": (
            str(metric.data_contract_id) if metric.data_contract_id else None
        ),
        "overall_score": metric.overall_score,
        "violation_rate": metric.violation_rate,
        "completeness": metric.completeness,
        "accuracy": metric.accuracy,
        "record_count": metric.record_count,
        "valid_count": metric.valid_count,
        "invalid_count": metric.invalid_count,
        "violation_count": metric.violation_count,
        "field_scores": metric.field_scores,
        "threshold_breaches": metric.threshold_breaches,
        "passed": metric.passed == "true",
        "data_version": metric.data_version,
        "data_source": metric.data_source,
        "data_fingerprint": metric.data_fingerprint,
        "check_timestamp": (
            metric.check_timestamp.isoformat() if metric.check_timestamp else None
        ),
        "created_at": (metric.created_at.isoformat() if metric.created_at else None),
        "updated_at": (metric.updated_at.isoformat() if metric.updated_at else None),
    }


def _parse_json_field(raw: str, field_name: str) -> dict[str, Any]:
    """Parse a JSON string, raising a domain error on failure.

    Args:
        raw: Raw JSON string.
        field_name: Human-readable field name for error messages.

    Returns:
        Parsed dictionary.

    Raises:
        QualityCheckValidationError: If the JSON is invalid.
    """
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise QualityCheckValidationError(f"Invalid {field_name} JSON format") from exc


def _build_quality_options(
    *,
    record_violations: bool,
    calculate_metrics: bool,
    check_thresholds: bool,
    thresholds: dict[str, Any] | None,
    include_field_metrics: bool,
    sample_size: int | None,
    data_source: str | None,
    data_version: str | None,
) -> QualityCheckOptions:
    """Build a QualityCheckOptions from individual parameters.

    Args:
        record_violations: Whether to record violations.
        calculate_metrics: Whether to calculate quality metrics.
        check_thresholds: Whether to check quality thresholds.
        thresholds: Raw thresholds dict (or None).
        include_field_metrics: Whether to include field-level metrics.
        sample_size: Sample size for large datasets.
        data_source: Data source identifier.
        data_version: Data version identifier.

    Returns:
        Configured QualityCheckOptions instance.
    """
    thresholds_obj = None
    if check_thresholds and thresholds:
        thresholds_obj = QualityThresholds(**thresholds)

    return QualityCheckOptions(
        record_violations=record_violations,
        calculate_metrics=calculate_metrics,
        check_thresholds=check_thresholds,
        thresholds=thresholds_obj,
        include_field_metrics=include_field_metrics,
        sample_size=sample_size,
        data_source=data_source,
        data_version=data_version,
    )


# ---------------------------------------------------------------------------
# Public service functions -- metric queries
# ---------------------------------------------------------------------------


def query_violations(
    *,
    schema_id: str | None,
    start_date: Any,
    end_date: Any,
    severity: str | None,
    violation_status: str | None,
    store: ContractStoreClient,
) -> tuple[list[Any], dict[str, Any]]:
    """Query data quality violations.

    Args:
        schema_id: Filter by schema ID.
        start_date: Filter violations after this date.
        end_date: Filter violations before this date.
        severity: Filter by severity.
        violation_status: Filter by status.
        store: Metadata store client.

    Returns:
        Tuple of (violation records, summary dict).
    """
    quality_check_instance = QualityCheck(store=store)
    tracker = quality_check_instance.violation_tracker

    violations = tracker.get_violations(
        schema_id=schema_id,
        start_date=start_date,
        end_date=end_date,
        severity=severity,
        status=violation_status,
    )

    summary = tracker.get_violation_summary(schema_id=schema_id)
    return violations, summary


def list_quality_metrics(
    *,
    schema_id: str | None,
    limit: int,
    offset: int,
    db: Session,
) -> dict[str, Any]:
    """List quality metrics from the database.

    Args:
        schema_id: Optional filter by schema ID.
        limit: Maximum number of results.
        offset: Offset for pagination.
        db: Database session.

    Returns:
        Dictionary with metrics list, total count, limit, and offset.
    """
    from pycharter.db.models.quality_metric import QualityMetricModel

    query = db.query(QualityMetricModel)

    if schema_id:
        query = query.filter(QualityMetricModel.schema_id == schema_id)

    total = query.count()

    metrics = (
        query.order_by(desc(QualityMetricModel.check_timestamp))
        .offset(offset)
        .limit(limit)
        .all()
    )

    return {
        "metrics": [_serialize_metric(m) for m in metrics],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


def get_quality_metric(
    *,
    metric_id: str,
    db: Session,
) -> dict[str, Any]:
    """Get a specific quality metric by ID.

    Args:
        metric_id: Quality metric ID (UUID string).
        db: Database session.

    Returns:
        Serialized quality metric dictionary.

    Raises:
        QualityCheckValidationError: If the metric_id is not a valid UUID.
        QualityMetricNotFoundError: If no metric with the given ID exists.
    """
    from pycharter.db.models.quality_metric import QualityMetricModel

    try:
        metric_uuid = uuid.UUID(metric_id)
    except ValueError as exc:
        raise QualityCheckValidationError(
            f"Invalid metric ID format: {metric_id}"
        ) from exc

    metric = (
        db.query(QualityMetricModel)
        .filter(QualityMetricModel.id == metric_uuid)
        .first()
    )

    if not metric:
        raise QualityMetricNotFoundError(f"Quality metric not found: {metric_id}")

    result = _serialize_metric(metric)
    result["additional_metadata"] = metric.additional_metadata
    return result
