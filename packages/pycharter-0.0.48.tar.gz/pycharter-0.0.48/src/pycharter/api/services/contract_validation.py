"""Contract validation, artifact resolution, and duplicate-checking logic.

Validation helpers used by contract CRUD operations.  Functions raise
domain exceptions -- callers map them to HTTP responses.

Artifact resolution logic lives in ``_contract_resolution`` and is
re-exported here for backward compatibility.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from sqlalchemy.orm import Session

from pycharter.api.utils import ensure_uuid, safe_uuid_to_str
from pycharter.db.models import DataContractModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


def validate_uuid(value: str) -> None:
    """Validate that *value* is a well-formed UUID string.

    Args:
        value: The string to validate.

    Raises:
        ValueError: If the string is not a valid UUID.
    """
    ensure_uuid(value)


def validate_artifact_ids(
    ids: dict[str, uuid.UUID | None],
) -> None:
    """Validate that all non-None IDs are UUID objects.

    Args:
        ids: Mapping of id_name to id_value.

    Raises:
        ValueError: If any non-None value is not a uuid.UUID.
    """
    for id_name, id_value in ids.items():
        if id_value is not None and not isinstance(id_value, uuid.UUID):
            raise ValueError(
                f"Invalid {id_name} type: {type(id_value)} (value: {id_value}). "
                "Expected uuid.UUID or None."
            )


def verify_artifacts_exist(
    db: Session,
    ids: dict[str, tuple[type, uuid.UUID | None]],
) -> None:
    """Verify that all referenced artifacts exist in the database.

    Args:
        db: Database session.
        ids: Mapping of label to (model_class, uuid_value).

    Raises:
        ArtifactNotFoundError: If an artifact cannot be found.
    """
    from pycharter.api.services.contract_service import ArtifactNotFoundError

    for label, (model, id_value) in ids.items():
        if id_value is None:
            continue
        exists = db.query(model).filter(model.id == id_value).first()
        if not exists:
            raise ArtifactNotFoundError(
                f"{label} with ID '{id_value}' not found in database. "
                "This may indicate the artifact was created in a different "
                "database or was deleted."
            )


# ---------------------------------------------------------------------------
# Duplicate / uniqueness checks
# ---------------------------------------------------------------------------


def check_contract_duplicate(db: Session, name: str, version: str) -> None:
    """Raise ContractConflictError if a contract with *name*/*version* exists.

    Args:
        db: Database session.
        name: Contract name.
        version: Contract version.

    Raises:
        ContractConflictError: If a matching contract exists.
    """
    from pycharter.api.services.contract_service import ContractConflictError

    existing = (
        db.query(DataContractModel)
        .filter(DataContractModel.name == name, DataContractModel.version == version)
        .first()
    )
    if existing:
        total = db.query(DataContractModel).count()
        logger.warning(
            "Contract '%s' v'%s' already exists. Total contracts: %s. ID: %s",
            name,
            version,
            total,
            safe_uuid_to_str(existing.id),
        )
        raise ContractConflictError(
            f"Contract '{name}' with version '{version}' already exists "
            f"(ID: {safe_uuid_to_str(existing.id)})"
        )


def check_update_has_fields(request: Any) -> None:
    """Ensure at least one update field is provided.

    Args:
        request: A ``ContractUpdateRequest`` instance.

    Raises:
        ValueError: If no fields are provided.
    """
    if not any(
        [
            request.name,
            request.version,
            request.status is not None,
            request.description is not None,
        ]
    ):
        raise ValueError("At least one field must be provided for update")


def check_name_version_unique(
    request: Any,
    contract: DataContractModel,
    db: Session,
) -> None:
    """Check that the new name+version combination is unique.

    Args:
        request: Update request.
        contract: Current contract model.
        db: Database session.

    Raises:
        ContractConflictError: If another contract with the same
            name+version exists.
    """
    from pycharter.api.services.contract_service import ContractConflictError

    if not (request.name or request.version):
        return

    new_name = request.name if request.name else contract.name
    new_version = request.version if request.version else contract.version

    existing = (
        db.query(DataContractModel)
        .filter(
            DataContractModel.name == new_name,
            DataContractModel.version == new_version,
            DataContractModel.id != contract.id,
        )
        .first()
    )
    if existing:
        raise ContractConflictError(
            f"Contract with name '{new_name}' and version "
            f"'{new_version}' already exists"
        )


# ---------------------------------------------------------------------------
# Artifact lookup
# ---------------------------------------------------------------------------


def find_artifact(
    db: Session,
    model: type,
    title: str | None,
    version: str | None,
    label: str,
) -> uuid.UUID | None:
    """Look up an artifact by title+version, returning its UUID.

    Args:
        db: Database session.
        model: SQLAlchemy model class with ``title`` and ``version`` columns.
        title: Artifact title (may be None).
        version: Artifact version (may be None).
        label: Human-readable name for error messages.

    Returns:
        UUID of the found artifact, or None if title/version not provided.

    Raises:
        ArtifactNotFoundError: If title+version are given but no match exists.
    """
    from pycharter.api.services.contract_service import ArtifactNotFoundError

    if not title or not version:
        return None
    record = (
        db.query(model).filter(model.title == title, model.version == version).first()
    )
    if not record:
        raise ArtifactNotFoundError(
            f"{label} not found: title='{title}', version='{version}'"
        )
    return ensure_uuid(record.id)


# ---------------------------------------------------------------------------
# Artifact resolution (re-exported from _contract_resolution)
# ---------------------------------------------------------------------------

from pycharter.api.services._contract_resolution import (  # noqa: E402
    create_new_rules,
    resolve_field_mapping,
    resolve_metadata,
    resolve_rules,
    resolve_schema,
)

__all__ = [
    "check_contract_duplicate",
    "check_name_version_unique",
    "check_update_has_fields",
    "create_new_rules",
    "find_artifact",
    "resolve_field_mapping",
    "resolve_metadata",
    "resolve_rules",
    "resolve_schema",
    "validate_artifact_ids",
    "validate_uuid",
    "verify_artifacts_exist",
]
