"""Service layer for template file discovery and archive building.

Encapsulates business logic extracted from the templates route handlers,
keeping route handlers thin and focused on HTTP concerns.
"""

from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class TemplateNotFoundError(FileNotFoundError):
    """Raised when a requested template file or directory cannot be found."""


class InvalidFilenameError(ValueError):
    """Raised when a filename contains path traversal or is not allowed."""


# ---------------------------------------------------------------------------
# Contract template discovery
# ---------------------------------------------------------------------------


def find_contract_template_dir() -> Path:
    """Find the contract template directory across multiple locations.

    Contract templates (schema, metadata, coercion/validation rules, contract)
    live under ``templates/contract/``.

    Priority:
        1. Installed package location (``pycharter/data/templates/contract/``)
        2. Source location (relative to ``api/routes/v1/``)
        3. Legacy location (``data/aviation_examples/template/``)

    Returns:
        Path to the contract template directory.
    """
    pkg_path = _try_package_contract_dir()
    if pkg_path is not None:
        return pkg_path

    possible_paths = [
        Path(__file__).parent.parent.parent / "data" / "templates" / "contract",
        Path(__file__).parent.parent.parent.parent
        / "data"
        / "aviation_examples"
        / "template",
        Path.cwd() / "pycharter" / "data" / "templates" / "contract",
        Path.cwd() / "data" / "aviation_examples" / "template",
    ]

    for template_path in possible_paths:
        if template_path.exists() and (template_path / "template_schema.yaml").exists():
            return template_path

    # Fallback to original location
    return (
        Path(__file__).parent.parent.parent.parent
        / "data"
        / "aviation_examples"
        / "template"
    )


def get_contract_template_path(filename: str) -> Path:
    """Resolve the full path to a contract template file.

    Args:
        filename: Template filename (e.g. ``template_schema.yaml``).

    Returns:
        Absolute path to the template file.

    Raises:
        TemplateNotFoundError: If the file does not exist.
    """
    template_dir = find_contract_template_dir()
    template_path = template_dir / filename
    if not template_path.exists():
        raise TemplateNotFoundError(f"Template file not found: {filename}")
    return template_path


# ---------------------------------------------------------------------------
# Pipeline template discovery
# ---------------------------------------------------------------------------


def find_pipeline_template_dir() -> Path:
    """Find the pipeline template directory (extract/transform/load configs).

    Pipeline templates live under ``pycharter/data/templates/pipeline/``.
    Priority: installed package, then source/dev paths.

    Returns:
        Path to the pipeline template directory.

    Raises:
        TemplateNotFoundError: If the directory cannot be found.
    """
    try:
        import pycharter

        pycharter_path = Path(pycharter.__file__).parent
        pipeline_dir = pycharter_path / "data" / "templates" / "pipeline"
        if (
            pipeline_dir.exists()
            and (pipeline_dir / "extract_http_simple.yaml").exists()
        ):
            return pipeline_dir
    except (ImportError, AttributeError):
        pass

    dev_paths = [
        Path(__file__).parent.parent.parent / "data" / "templates" / "pipeline",
        Path.cwd() / "pycharter" / "data" / "templates" / "pipeline",
    ]
    for path in dev_paths:
        if path.exists() and (path / "extract_http_simple.yaml").exists():
            return path

    raise TemplateNotFoundError("Pipeline template directory not found")


def list_pipeline_template_names() -> list[str]:
    """Return a sorted list of pipeline template filenames (yaml/yml and README.md).

    Returns:
        Sorted list of allowed template filenames.

    Raises:
        TemplateNotFoundError: If the pipeline template directory cannot be found.
    """
    pipeline_dir = find_pipeline_template_dir()
    allowed: list[str] = []
    for item in pipeline_dir.iterdir():
        if not item.is_file():
            continue
        if item.suffix in (".yaml", ".yml") or item.name == "README.md":
            allowed.append(item.name)
    return sorted(allowed)


def get_pipeline_template_path(filename: str) -> Path:
    """Resolve the full path to a pipeline template file with safety checks.

    Args:
        filename: Template filename (must be in the allowlist).

    Returns:
        Absolute path to the pipeline template file.

    Raises:
        InvalidFilenameError: If the filename contains path traversal.
        TemplateNotFoundError: If the file is not in the allowlist.
    """
    safe_name = Path(filename).name
    if safe_name != filename or ".." in filename:
        raise InvalidFilenameError("Invalid filename")

    allowed = list_pipeline_template_names()
    if safe_name not in allowed:
        suffix = "..." if len(allowed) > 10 else ""
        raise TemplateNotFoundError(
            f"Pipeline template not found: {filename}. Available: {allowed[:10]}{suffix}"
        )
    return find_pipeline_template_dir() / safe_name


# ---------------------------------------------------------------------------
# ZIP archive builders
# ---------------------------------------------------------------------------

_CONTRACT_TEMPLATE_FILES = [
    "template_schema.yaml",
    "template_metadata.yaml",
    "template_coercion_rules.yaml",
    "template_validation_rules.yaml",
    "template_contract.yaml",
]


def build_contract_artifacts_zip() -> bytes:
    """Create a ZIP archive containing all contract artifact templates.

    Returns:
        Bytes of the ZIP archive.

    Raises:
        TemplateNotFoundError: If any template file is missing.
    """
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for template_file in _CONTRACT_TEMPLATE_FILES:
            template_path = get_contract_template_path(template_file)
            zf.write(template_path, arcname=template_file)
    zip_buffer.seek(0)
    content = zip_buffer.read()
    zip_buffer.close()
    return content


def build_pipeline_artifacts_zip() -> bytes:
    """Create a ZIP archive containing all pipeline config templates.

    Returns:
        Bytes of the ZIP archive.

    Raises:
        TemplateNotFoundError: If the pipeline template directory cannot be found.
    """
    pipeline_dir = find_pipeline_template_dir()
    names = list_pipeline_template_names()
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            zf.write(pipeline_dir / name, arcname=name)
    zip_buffer.seek(0)
    content = zip_buffer.read()
    zip_buffer.close()
    return content


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _try_package_contract_dir() -> Path | None:
    """Try to find the contract template dir from the installed package."""
    try:
        import pycharter

        pycharter_path = Path(pycharter.__file__).parent
        package_contract = pycharter_path / "data" / "templates" / "contract"
        if (
            package_contract.exists()
            and (package_contract / "template_schema.yaml").exists()
        ):
            return package_contract
    except (ImportError, AttributeError):
        pass
    return None
