"""Contract business logic service.

Extracts domain logic from contract route handlers so that routes remain
thin HTTP adapters.  Functions raise domain exceptions (never FastAPI
``HTTPException``) -- callers map them to HTTP responses.

This module re-exports from the following sub-modules for backward
compatibility:

- ``contract_crud`` -- CRUD operations (create, get, update, delete).
- ``contract_validation`` -- Validation, artifact resolution, duplicate checks.
- ``contract_diff`` -- Diff, evolution, and comparison logic.
"""

from __future__ import annotations

import logging

from pycharter.api.services.contract_crud import (  # noqa: F401
    build_contract_from_db,
    create_from_existing_artifacts,
    create_mixed,
    update_fields,
)
from pycharter.api.services.contract_validation import (  # noqa: F401
    check_contract_duplicate,
    check_name_version_unique,
    check_update_has_fields,
    create_new_rules,
    find_artifact,
    resolve_metadata,
    resolve_rules,
    resolve_schema,
    validate_artifact_ids,
    validate_uuid,
    verify_artifacts_exist,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class ContractNotFoundError(LookupError):
    """Raised when a contract or artifact cannot be found."""


class ContractConflictError(ValueError):
    """Raised when a contract or artifact already exists."""


class ArtifactNotFoundError(LookupError):
    """Raised when a referenced artifact cannot be found."""


class ContractBuildError(RuntimeError):
    """Raised when building a contract from artifacts fails."""


# ---------------------------------------------------------------------------
# Backward-compatible private aliases
# ---------------------------------------------------------------------------
# These aliases preserve the old underscore-prefixed names so that any
# internal callers continue to work without changes.

_validate_uuid = validate_uuid
_find_artifact = find_artifact
_check_contract_duplicate = check_contract_duplicate
_validate_artifact_ids = validate_artifact_ids
_verify_artifacts_exist = verify_artifacts_exist
_check_update_has_fields = check_update_has_fields
_check_name_version_unique = check_name_version_unique
_resolve_schema = resolve_schema
_resolve_rules = resolve_rules
_create_new_rules = create_new_rules
_resolve_metadata = resolve_metadata


__all__ = [
    # Exceptions
    "ArtifactNotFoundError",
    "ContractBuildError",
    "ContractConflictError",
    "ContractNotFoundError",
    # CRUD
    "build_contract_from_db",
    "create_from_existing_artifacts",
    "create_mixed",
    "update_fields",
    # Validation / resolution
    "check_contract_duplicate",
    "check_name_version_unique",
    "check_update_has_fields",
    "create_new_rules",
    "find_artifact",
    "resolve_metadata",
    "resolve_rules",
    "resolve_schema",
    "validate_artifact_ids",
    "validate_uuid",
    "verify_artifacts_exist",
]
