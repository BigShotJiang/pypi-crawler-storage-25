"""Editor diagram layout positions API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.db.models.editor_layout import EditorLayoutModel

router = APIRouter(prefix="/layouts")


class LayoutPosition(BaseModel):
    """Single node position."""

    x: float = Field(..., description="X coordinate")
    y: float = Field(..., description="Y coordinate")


class EditorLayoutsListResponse(BaseModel):
    """All positions for a given contract version."""

    contract_name: str = Field(..., description="Contract name")
    contract_version: str = Field(..., description="Contract version")
    positions: dict[str, LayoutPosition] = Field(
        default_factory=dict,
        description="Positions keyed by node ID",
    )


@router.get(
    "",
    response_model=EditorLayoutsListResponse,
    status_code=status.HTTP_200_OK,
    summary="List layout positions for a contract version",
)
async def list_layouts(
    contract_name: str = Query(..., description="Contract name"),
    contract_version: str = Query(..., description="Contract version"),
    session: Session = Depends(get_db_session),
) -> EditorLayoutsListResponse:
    """Return all saved positions as a dict keyed by node ID."""
    rows = (
        session.query(EditorLayoutModel)
        .filter(
            EditorLayoutModel.contract_name == contract_name,
            EditorLayoutModel.contract_version == contract_version,
        )
        .order_by(EditorLayoutModel.node_id.asc())
        .all()
    )
    positions = {
        r.node_id: LayoutPosition(x=r.position_x, y=r.position_y) for r in rows
    }
    return EditorLayoutsListResponse(
        contract_name=contract_name,
        contract_version=contract_version,
        positions=positions,
    )


@router.put(
    "/{contract_name}/{contract_version}",
    status_code=status.HTTP_200_OK,
    summary="Batch upsert diagram positions",
)
async def batch_upsert_layouts(
    contract_name: str,
    contract_version: str,
    body: dict,
    session: Session = Depends(get_db_session),
) -> dict:
    """Upsert positions for multiple nodes at once.

    Args:
        contract_name: Contract name from path.
        contract_version: Contract version from path.
        body: ``{"positions": {"node_id": {"x": ..., "y": ...}}}``
        session: DB session dependency.

    Returns:
        ``{"ok": True, "upserted": <count>}``
    """
    positions = body.get("positions")
    if not isinstance(positions, dict):
        raise HTTPException(
            status_code=400,
            detail="body.positions must be a dict",
        )

    count = 0
    for node_id, pos in positions.items():
        if not isinstance(pos, dict):
            continue
        x = float(pos.get("x", 0))
        y = float(pos.get("y", 0))

        row = (
            session.query(EditorLayoutModel)
            .filter(
                EditorLayoutModel.contract_name == contract_name,
                EditorLayoutModel.contract_version == contract_version,
                EditorLayoutModel.node_id == node_id,
            )
            .first()
        )
        if row is None:
            row = EditorLayoutModel(
                contract_name=contract_name,
                contract_version=contract_version,
                node_id=node_id,
                position_x=x,
                position_y=y,
            )
            session.add(row)
        else:
            row.position_x = x
            row.position_y = y
        count += 1

    session.commit()
    return {"ok": True, "upserted": count}


@router.delete(
    "/{contract_name}/{contract_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete ALL positions for a contract version",
)
async def delete_all_layouts(
    contract_name: str,
    contract_version: str,
    session: Session = Depends(get_db_session),
) -> None:
    """Delete every saved position for a contract version.

    Used by the Reset Layout button to revert to auto-layout.
    """
    session.query(EditorLayoutModel).filter(
        EditorLayoutModel.contract_name == contract_name,
        EditorLayoutModel.contract_version == contract_version,
    ).delete(synchronize_session="fetch")
    session.commit()


@router.delete(
    "/{contract_name}/{contract_version}/{node_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete position for a single node",
)
async def delete_single_layout(
    contract_name: str,
    contract_version: str,
    node_id: str,
    session: Session = Depends(get_db_session),
) -> None:
    """Delete the saved position for one node."""
    deleted = (
        session.query(EditorLayoutModel)
        .filter(
            EditorLayoutModel.contract_name == contract_name,
            EditorLayoutModel.contract_version == contract_version,
            EditorLayoutModel.node_id == node_id,
        )
        .delete(synchronize_session="fetch")
    )
    session.commit()
    if deleted == 0:
        raise HTTPException(status_code=404, detail="layout position not found")
