"""Server-Sent Events endpoint for real-time change streaming."""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Query, Request
from fastapi.responses import StreamingResponse

from pycharter.events import ChangeBus

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Events"])


async def _event_generator(
    request: Request,
    bus: ChangeBus,
    topic: str,
) -> None:
    """Yield SSE-formatted change events until the client disconnects.

    Args:
        request: The incoming HTTP request (used for disconnect
            detection).
        bus: The application-wide change bus.
        topic: Topic filter (``"*"`` for all).

    Yields:
        SSE ``data:`` frames as UTF-8 strings.
    """
    queue = bus.subscribe(topic)
    try:
        while not await request.is_disconnected():
            try:
                event = await asyncio.wait_for(
                    queue.get(),
                    timeout=15.0,
                )
                payload = json.dumps(event.to_dict())
                yield f"data: {payload}\n\n"
            except TimeoutError:
                yield ": keepalive\n\n"
    finally:
        bus.unsubscribe(queue, topic)


@router.get(
    "/events/stream",
    summary="Stream change events (SSE)",
    description=(
        "Server-Sent Events endpoint that streams real-time "
        "change notifications. Use the `topic` query parameter "
        "to filter events (default: all)."
    ),
    tags=["Events"],
)
async def stream_events(
    request: Request,
    topic: str = Query(
        "*",
        description="Topic filter ('*' for all events)",
    ),
) -> StreamingResponse:
    """Stream change events as Server-Sent Events."""
    bus: ChangeBus = request.app.state.change_bus
    return StreamingResponse(
        _event_generator(request, bus, topic),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
