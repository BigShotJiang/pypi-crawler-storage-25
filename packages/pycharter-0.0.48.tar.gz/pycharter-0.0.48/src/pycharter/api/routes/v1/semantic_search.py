"""Search API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.knowledge.search import ConceptSearch

router = APIRouter(tags=["Semantic"])


@router.get("/concepts")
async def search_concepts(
    q: str = Query(..., min_length=1),
    limit: int = Query(20),
    session=Depends(get_db_session),
):
    """Search concepts by name or description."""
    cs = ConceptSearch(session)
    return cs.search_concepts(q, limit=limit)


@router.get("/fields")
async def search_fields(
    q: str = Query(..., min_length=1),
    contract_id: str | None = Query(None),
    limit: int = Query(20),
    session=Depends(get_db_session),
):
    """Search fields by name or business definition."""
    cs = ConceptSearch(session)
    return cs.search_fields(q, contract_id=contract_id, limit=limit)
