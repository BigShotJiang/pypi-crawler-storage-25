"""
Authentication routes: login, logout, me.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from pycharter.api.dependencies.auth import (
    ACCESS_TOKEN_EXPIRE_SECONDS,
    create_access_token,
    get_current_user,
    verify_credentials,
)
from pycharter.config.auth import (
    get_auth_jwt_secret,
    get_auth_users,
    is_auth_disabled,
)

router = APIRouter(tags=["Auth"])


class LoginRequest(BaseModel):
    """Request body for authentication."""

    username: str
    password: str


class LoginResponse(BaseModel):
    """Response from successful login."""

    access_token: str
    token_type: str = "bearer"
    expires_in: int = ACCESS_TOKEN_EXPIRE_SECONDS


class UserResponse(BaseModel):
    """Response for current user query."""

    username: str
    role: str = "User"
    auth_disabled: bool = False


@router.post(
    "/auth/login",
    response_model=LoginResponse,
    status_code=status.HTTP_200_OK,
    summary="Login",
    description="Exchange username and password for an access token.",
)
def login(request: LoginRequest) -> LoginResponse:
    if is_auth_disabled():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication is disabled",
        )
    if not get_auth_users():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication not configured (set credentials or auth service)",
        )
    if not get_auth_jwt_secret():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="JWT secret not configured (set PYCHARTER_AUTH_JWT_SECRET in env or pycharter.cfg [auth])",
        )
    matched = verify_credentials(request.username, request.password)
    if not matched:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )
    token = create_access_token(matched["username"], role=matched["role"])
    return LoginResponse(
        access_token=token,
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_SECONDS,
    )


@router.post(
    "/auth/logout",
    status_code=status.HTTP_200_OK,
    summary="Logout",
    description="Client should discard the token. Server-side invalidation can be added later.",
)
def logout() -> dict:
    return {"message": "OK"}


@router.get(
    "/auth/me",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="Current user",
    description="Return the current user from the Bearer token. Protected.",
)
def me(current_user: dict = Depends(get_current_user)) -> UserResponse:
    return UserResponse(
        username=current_user["username"],
        role=current_user.get("role", "User"),
        auth_disabled=current_user.get("auth_disabled", False),
    )
