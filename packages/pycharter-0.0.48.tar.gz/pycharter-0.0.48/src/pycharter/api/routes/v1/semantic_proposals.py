"""Proposals API routes."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query

from pycharter.api.dependencies import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.semantic_proposals import (
    CreateProposalRequest,
    CreateProposalResponse,
    ProposalResponse,
    ProposalSummaryResponse,
    UpdateProposalStatusRequest,
    ValidateProposalRequest,
    ValidateProposalResponse,
)
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.domain import DomainModel
from pycharter.db.models.metadata_record import MetadataRecordDomain
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.proposal import ProposalModel
from pycharter.semantic.collaboration.gates import run_proposal_gates
from pycharter.semantic.collaboration.proposals import ProposalManager
from pycharter.semantic.shared.errors import CollaborationError

router = APIRouter(tags=["Semantic"])


@router.post("/", response_model=CreateProposalResponse)
async def create_proposal(
    request: CreateProposalRequest, session=Depends(get_db_session)
):
    """Create a new proposal."""
    try:
        pm = ProposalManager(session)
        proposal_id = pm.create_proposal(
            contract_id=request.contract_id,
            title=request.title,
            author=request.author,
            description=request.description,
            source_branch_id=request.source_branch_id,
            target_branch_id=request.target_branch_id,
            proposal_type=request.proposal_type,
            affected_tiers=request.affected_tiers,
        )
        return {"proposal_id": proposal_id}
    except CollaborationError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/", response_model=list[ProposalSummaryResponse])
async def list_all_proposals(
    status: str | None = Query(None),
    scope: str = Query("all", pattern="^(all|core|non_core)$"),
    domain: str | None = Query(None),
    limit: int = Query(200, ge=1, le=500),
    session=Depends(get_db_session),
) -> list[ProposalSummaryResponse]:
    """List proposals across all contracts with optional scope/domain filters."""
    selected_domain = (
        domain.strip() if isinstance(domain, str) and domain.strip() else None
    )
    domain_contract_names: set[str] | None = None
    domain_contract_ids: set[str] | None = None
    if selected_domain:
        scoped_contract_rows = (
            session.query(DataContractModel.id, DataContractModel.name)
            .join(
                MetadataRecordDomain,
                MetadataRecordDomain.metadata_record_id
                == DataContractModel.metadata_record_id,
            )
            .join(DomainModel, DomainModel.id == MetadataRecordDomain.domain_id)
            .filter(DomainModel.name == selected_domain)
            .all()
        )
        domain_contract_ids = {
            str(contract_id) for contract_id, _ in scoped_contract_rows
        }
        domain_contract_names = {
            contract_name.lower()
            for _contract_id, contract_name in scoped_contract_rows
            if isinstance(contract_name, str) and contract_name
        }

    def _proposal_in_scope(contract_id: str) -> bool:
        if not selected_domain:
            return True
        if domain_contract_ids is None or domain_contract_names is None:
            return False
        contract_id_lower = contract_id.lower()
        return (
            contract_id in domain_contract_ids
            or contract_id_lower in domain_contract_names
        )

    query = session.query(ProposalModel).order_by(
        ProposalModel.updated_at.desc(), ProposalModel.created_at.desc()
    )
    if status:
        query = query.filter(ProposalModel.status == status)

    proposals: list[ProposalSummaryResponse] = []
    for row in query.limit(limit * 3).all():
        if not _proposal_in_scope(row.contract_id):
            continue
        if scope == "core" and not bool(row.enforce_gates):
            continue
        if scope == "non_core" and bool(row.enforce_gates):
            continue

        gate_overall = (
            (row.gate_status or {}).get("overall")
            if isinstance(row.gate_status, dict)
            else None
        )
        proposals.append(
            ProposalSummaryResponse(
                id=str(row.id),
                contract_id=row.contract_id,
                title=row.title,
                description=row.description,
                status=row.status,
                author=row.author,
                proposal_type=row.proposal_type,
                required_approvals=row.required_approvals,
                enforce_gates=bool(row.enforce_gates),
                gate_overall=gate_overall,
                created_at=str(row.created_at) if row.created_at else None,
                updated_at=str(row.updated_at) if row.updated_at else None,
            )
        )
        if len(proposals) >= limit:
            break
    return proposals


@router.get("/{proposal_id}", response_model=ProposalResponse)
async def get_proposal(proposal_id: str, session=Depends(get_db_session)):
    """Get a proposal by ID."""
    pm = ProposalManager(session)
    proposal = pm.get_proposal(proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="Proposal not found")
    return proposal


@router.get("/contract/{contract_id}")
async def list_proposals(
    contract_id: str,
    status: str | None = Query(None),
    session=Depends(get_db_session),
) -> list[ProposalSummaryResponse]:
    """List proposals for a contract."""
    pm = ProposalManager(session)
    return pm.list_proposals(contract_id, status=status)


@router.put("/{proposal_id}/status")
async def update_status(
    proposal_id: str,
    request: UpdateProposalStatusRequest,
    session=Depends(get_db_session),
):
    """Update a proposal's status."""
    try:
        pm = ProposalManager(session)
        pm.update_status(proposal_id, request.status, updated_by=request.updated_by)
        return {"status": "updated"}
    except CollaborationError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/{proposal_id}/merge")
async def merge_proposal(
    proposal_id: str,
    merged_by: str = Query(...),
    session=Depends(get_db_session),
):
    """Merge a proposal."""
    try:
        pm = ProposalManager(session)
        pm.merge_proposal(proposal_id, merged_by)
        return {"status": "merged"}
    except CollaborationError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/{proposal_id}/validate", response_model=ValidateProposalResponse)
async def validate_proposal(
    proposal_id: str,
    request: ValidateProposalRequest,
    session=Depends(get_db_session),
    store: ContractStoreClient = Depends(get_contract_store),
):
    """Run ontology validation gates for a proposal and persist gate status."""
    pm = ProposalManager(session)
    proposal = pm.get_proposal(proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="Proposal not found")

    try:
        contract_uuid = uuid.UUID(proposal["contract_id"])
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail="Proposal contract_id is not a UUID; cannot run contract-based gates.",
        ) from exc

    contract = (
        session.query(DataContractModel)
        .filter(DataContractModel.id == contract_uuid)
        .first()
    )
    if contract is None:
        raise HTTPException(status_code=404, detail="Contract not found")
    if contract.schema is None or not contract.schema.schema_data:
        raise HTTPException(status_code=404, detail="Contract schema not found")

    baseline_field_mapping = request.baseline_ontology
    if baseline_field_mapping is None:
        baseline_field_mapping = store.get_field_mapping(
            contract.name, contract.version
        )
    proposed_field_mapping = request.proposed_ontology or baseline_field_mapping

    concept_rows = session.query(
        ConceptModel.concept_key, ConceptModel.name, ConceptModel.deprecated
    ).all()
    known_concepts = {
        (concept_key or name)
        for concept_key, name, _deprecated in concept_rows
        if (concept_key or name)
    }
    deprecated_concepts = {
        (concept_key or name)
        for concept_key, name, deprecated in concept_rows
        if deprecated and (concept_key or name)
    }

    gate_status = run_proposal_gates(
        schema=dict(contract.schema.schema_data),
        baseline_field_mapping=baseline_field_mapping,
        proposed_field_mapping=proposed_field_mapping,
        known_concepts=known_concepts,
        deprecated_concepts=deprecated_concepts,
        enforce_gates=bool(proposal.get("enforce_gates", False)),
    )
    pm.set_gate_status(proposal_id, gate_status)
    return gate_status
