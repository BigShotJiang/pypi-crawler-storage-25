"""Semantic (ontology) dashboard summary routes."""

from __future__ import annotations

import json
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Query

from pycharter.api.dependencies import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.semantic_dashboard import (
    ProposalStatsResponse,
    RecentProposalResponse,
    SemanticDashboardSummaryResponse,
    SemanticHealthOverviewResponse,
)
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.domain import DomainModel
from pycharter.db.models.metadata_record import MetadataRecordDomain
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.proposal import ProposalModel
from pycharter.semantic.knowledge.semantic_health import calculate_semantic_health
from pycharter.semantic.ontology.schema_loader import load_ontology_schema

router = APIRouter(tags=["Semantic"])


@router.get("/summary", response_model=SemanticDashboardSummaryResponse)
async def get_semantic_dashboard_summary(
    scope: str = Query("all", pattern="^(all|core|non_core)$"),
    domain: str | None = Query(None),
    contract_sample_limit: int = Query(30, ge=1, le=200),
    window_days: int = Query(30, ge=7, le=90),
    coverage_threshold: float = Query(70.0, ge=0.0, le=100.0),
    session=Depends(get_db_session),
    store: ContractStoreClient = Depends(get_contract_store),
):
    """Return command-center summary metrics for the semantic landing page."""
    available_domains = sorted(
        {
            name
            for (name,) in session.query(DomainModel.name).all()
            if isinstance(name, str) and name.strip()
        }
    )
    selected_domain = (
        domain.strip() if isinstance(domain, str) and domain.strip() else None
    )
    domain_contract_names: set[str] | None = None
    domain_contract_ids: set[str] | None = None
    domain_contract_db_ids = None
    if selected_domain:
        scoped_contract_rows = (
            session.query(DataContractModel.id, DataContractModel.name)
            .join(
                MetadataRecordDomain,
                MetadataRecordDomain.metadata_record_id
                == DataContractModel.metadata_record_id,
            )
            .join(DomainModel, DomainModel.id == MetadataRecordDomain.domain_id)
            .filter(DomainModel.name == selected_domain)
            .all()
        )
        domain_contract_db_ids = {
            contract_id for contract_id, _ in scoped_contract_rows
        }
        domain_contract_ids = {
            str(contract_id) for contract_id, _ in scoped_contract_rows
        }
        domain_contract_names = {
            contract_name.lower()
            for _contract_id, contract_name in scoped_contract_rows
            if isinstance(contract_name, str) and contract_name
        }

    def _proposal_in_scope(contract_id: str) -> bool:
        if not selected_domain:
            return True
        if domain_contract_ids is None or domain_contract_names is None:
            return False
        contract_id_lower = contract_id.lower()
        return (
            contract_id in domain_contract_ids
            or contract_id_lower in domain_contract_names
        )

    concept_rows = session.query(ConceptModel).all()
    concepts_count = len(concept_rows)
    known_concepts = {
        (row.concept_key or row.name)
        for row in concept_rows
        if (row.concept_key or row.name)
    }
    deprecated_concepts = {
        (row.concept_key or row.name)
        for row in concept_rows
        if row.deprecated and (row.concept_key or row.name)
    }

    ontology_schema = load_ontology_schema()
    relationship_types_count = len(ontology_schema.relationship_types)
    concept_types_count = len(ontology_schema.concept_types)

    proposal_rows_all = [
        row
        for row in session.query(ProposalModel).all()
        if _proposal_in_scope(row.contract_id)
    ]
    if scope == "core":
        proposal_rows = [p for p in proposal_rows_all if bool(p.enforce_gates)]
    elif scope == "non_core":
        proposal_rows = [p for p in proposal_rows_all if not bool(p.enforce_gates)]
    else:
        proposal_rows = proposal_rows_all
    total = len(proposal_rows)
    open_count = sum(1 for p in proposal_rows if str(p.status).lower() == "open")
    merged_count = sum(1 for p in proposal_rows if str(p.status).lower() == "merged")
    closed_count = sum(1 for p in proposal_rows if str(p.status).lower() == "closed")
    core_blocked = 0
    for proposal in proposal_rows:
        if str(proposal.status).lower() != "open" or not proposal.enforce_gates:
            continue
        gate = proposal.gate_status or {}
        if gate.get("overall") not in {"pass"}:
            core_blocked += 1

    proposal_stats = ProposalStatsResponse(
        total=total,
        open=open_count,
        merged=merged_count,
        closed=closed_count,
        core_blocked=core_blocked,
    )

    contract_query = session.query(DataContractModel).order_by(
        DataContractModel.updated_at.desc()
    )
    if selected_domain:
        if domain_contract_db_ids:
            contract_query = contract_query.filter(
                DataContractModel.id.in_(list(domain_contract_db_ids))
            )
        else:
            contract_query = contract_query.filter(DataContractModel.id.in_([]))
    contract_rows = contract_query.limit(contract_sample_limit).all()
    coverages: list[float] = []
    for contract in contract_rows:
        if contract.schema is None or not contract.schema.schema_data:
            continue
        field_mapping = store.get_field_mapping(contract.name, contract.version)
        health = calculate_semantic_health(
            schema=dict(contract.schema.schema_data),
            field_mapping=field_mapping,
            known_concepts=known_concepts,
            deprecated_concepts=deprecated_concepts,
        )
        coverages.append(float(health.get("coverage_pct", 0.0)))
    sampled = len(coverages)
    avg_coverage = round((sum(coverages) / sampled), 2) if sampled else 0.0
    below_threshold = sum(1 for c in coverages if c < coverage_threshold)
    semantic_health = SemanticHealthOverviewResponse(
        sampled_contracts=sampled,
        average_coverage_pct=avg_coverage,
        below_threshold_count=below_threshold,
    )

    recent_rows = (
        session.query(ProposalModel)
        .order_by(ProposalModel.updated_at.desc(), ProposalModel.created_at.desc())
        .limit(120)
        .all()
    )
    recent: list[RecentProposalResponse] = []
    for row in recent_rows:
        if not _proposal_in_scope(row.contract_id):
            continue
        if scope == "core" and not bool(row.enforce_gates):
            continue
        if scope == "non_core" and bool(row.enforce_gates):
            continue
        gate_status = row.gate_status if isinstance(row.gate_status, dict) else None
        if gate_status is None and isinstance(row.gate_status, str):
            try:
                gate_status = json.loads(row.gate_status)
            except Exception:
                gate_status = None
        recent.append(
            RecentProposalResponse(
                id=str(row.id),
                title=row.title,
                status=row.status,
                proposal_type=row.proposal_type or "mapping_change",
                enforce_gates=bool(row.enforce_gates),
                gate_overall=(gate_status or {}).get("overall"),
                updated_at=str(row.updated_at) if row.updated_at else None,
            )
        )
        if len(recent) >= 8:
            break

    trend_start = date.today() - timedelta(days=window_days - 1)
    trend_dates = [trend_start + timedelta(days=i) for i in range(window_days)]
    trend_map: dict[str, dict[str, int]] = {
        d.isoformat(): {"created": 0, "merged": 0, "blocked": 0} for d in trend_dates
    }
    for row in proposal_rows:
        created_at = row.created_at
        if created_at is not None:
            created_key = created_at.date().isoformat()
            if created_key in trend_map:
                trend_map[created_key]["created"] += 1

        if str(row.status).lower() == "merged":
            merged_at = row.updated_at or row.created_at
            if merged_at is not None:
                merged_key = merged_at.date().isoformat()
                if merged_key in trend_map:
                    trend_map[merged_key]["merged"] += 1

        gate = row.gate_status if isinstance(row.gate_status, dict) else None
        if row.enforce_gates and (gate or {}).get("overall") not in {"pass"}:
            blocker_at = row.updated_at or row.created_at
            if blocker_at is not None:
                blocked_key = blocker_at.date().isoformat()
                if blocked_key in trend_map:
                    trend_map[blocked_key]["blocked"] += 1

    proposal_trend = [
        {
            "date": d.isoformat(),
            "created": trend_map[d.isoformat()]["created"],
            "merged": trend_map[d.isoformat()]["merged"],
            "blocked": trend_map[d.isoformat()]["blocked"],
        }
        for d in trend_dates
    ]

    return SemanticDashboardSummaryResponse(
        scope=scope,
        window_days=window_days,
        selected_domain=selected_domain,
        available_domains=available_domains,
        concepts_count=concepts_count,
        relationship_types_count=relationship_types_count,
        concept_types_count=concept_types_count,
        proposal_stats=proposal_stats,
        semantic_health=semantic_health,
        recent_proposals=recent,
        proposal_trend=proposal_trend,
    )
