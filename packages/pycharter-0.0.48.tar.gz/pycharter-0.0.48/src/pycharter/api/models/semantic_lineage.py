"""Pydantic models for lineage API routes."""

from __future__ import annotations

from pydantic import BaseModel


class FieldLineageRequest(BaseModel):
    field_id: str


class LineagePathRequest(BaseModel):
    source_field_id: str
    target_field_id: str
