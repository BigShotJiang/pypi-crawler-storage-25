"""Pydantic models for proposals API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class CreateProposalRequest(BaseModel):
    """Request to create a proposal."""

    contract_id: str
    title: str
    author: str
    description: str | None = None
    source_branch_id: str | None = None
    target_branch_id: str | None = None
    proposal_type: str = "mapping_change"
    affected_tiers: list[str] | None = None


class UpdateProposalStatusRequest(BaseModel):
    """Request to update proposal status."""

    status: str
    updated_by: str | None = None


class ValidateProposalRequest(BaseModel):
    """Request to run proposal validation gates."""

    proposed_ontology: dict[str, Any] | None = None
    baseline_ontology: dict[str, Any] | None = None


class CreateProposalResponse(BaseModel):
    """Response for proposal creation."""

    proposal_id: str


class ProposalSummaryResponse(BaseModel):
    """Summary representation for proposal listing."""

    id: str
    contract_id: str
    title: str
    status: str
    author: str
    description: str | None = None
    proposal_type: str | None = None
    required_approvals: int | None = None
    enforce_gates: bool | None = None
    gate_overall: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ProposalResponse(BaseModel):
    """Detailed proposal representation."""

    id: str
    contract_id: str
    title: str
    description: str | None = None
    source_branch_id: str | None = None
    target_branch_id: str | None = None
    status: str
    author: str
    proposal_type: str | None = None
    required_approvals: int | None = None
    enforce_gates: bool | None = None
    gate_status: dict[str, Any] | None = None
    created_at: str | None = None


class GateResultResponse(BaseModel):
    """Single gate result in proposal validation."""

    name: str
    status: str
    errors: list[str]
    warnings: list[str]
    metrics: dict[str, Any]


class ValidateProposalResponse(BaseModel):
    """Response payload for proposal gate validation."""

    validated_at: str
    overall: str
    enforce_gates: bool
    gates: list[GateResultResponse]
    coverage: dict[str, Any]
    warnings: list[str]
