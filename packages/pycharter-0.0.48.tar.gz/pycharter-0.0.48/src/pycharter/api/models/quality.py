"""
Pydantic models for quality assurance API.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class QualityCheckRequest(BaseModel):
    """Request model for quality check (contract-centric when using store)."""

    contract_name: str | None = Field(
        None, description="Data contract name (for store-based validation)"
    )
    contract_version: str | None = Field(
        None, description="Data contract version (for store-based validation)"
    )
    contract: dict[str, Any] | None = Field(
        None, description="Contract dictionary (for contract-based validation)"
    )
    data: list[dict[str, Any]] = Field(..., description="Data records to validate")
    record_violations: bool = Field(True, description="Record violations")
    calculate_metrics: bool = Field(True, description="Calculate quality metrics")
    check_thresholds: bool = Field(False, description="Check quality thresholds")
    thresholds: dict[str, Any] | None = Field(None, description="Quality thresholds")
    include_field_metrics: bool = Field(True, description="Include field-level metrics")
    sample_size: int | None = Field(None, description="Sample size for large datasets")
    data_source: str | None = Field(
        None, description="Data source identifier (e.g., file name, table name)"
    )
    data_version: str | None = Field(
        None, description="Data version identifier for tracking"
    )


class QualityScoreResponse(BaseModel):
    """Quality score response model."""

    overall_score: float
    violation_rate: float
    completeness: float
    accuracy: float
    field_scores: dict[str, float | None] = Field(default_factory=dict)
    record_count: int
    valid_count: int
    invalid_count: int


class FieldQualityMetricsResponse(BaseModel):
    """Field quality metrics response model."""

    field_name: str
    null_count: int
    violation_count: int
    total_count: int
    violation_rate: float
    completeness: float
    error_types: dict[str, int] | None = Field(default_factory=dict)


class QualityReportResponse(BaseModel):
    """Quality report response model."""

    schema_id: str
    schema_version: str | None = None
    check_timestamp: datetime
    quality_score: QualityScoreResponse | None = None
    field_metrics: dict[str, FieldQualityMetricsResponse] = Field(default_factory=dict)
    violation_count: int
    record_count: int
    valid_count: int
    invalid_count: int
    threshold_breaches: list[str] = Field(default_factory=list)
    passed: bool
    metadata: dict[str, Any] = Field(default_factory=dict)


class ViolationQueryRequest(BaseModel):
    """Request model for querying violations."""

    schema_id: str | None = Field(None, description="Filter by schema ID")
    status: str | None = Field(
        None, description="Filter by status (open, resolved, ignored)"
    )
    severity: str | None = Field(
        None, description="Filter by severity (critical, warning, info)"
    )
    start_date: datetime | None = Field(
        None, description="Filter violations after this date"
    )
    end_date: datetime | None = Field(
        None, description="Filter violations before this date"
    )


class ViolationRecordResponse(BaseModel):
    """Violation record response model."""

    id: str
    schema_id: str
    record_id: str
    severity: str
    status: str
    field_violations: list[dict[str, Any]] = Field(default_factory=list)
    error_count: int
    timestamp: datetime
    resolved_at: datetime | None = None
    resolved_by: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ViolationsResponse(BaseModel):
    """Violations query response model."""

    violations: list[ViolationRecordResponse]
    total: int
    summary: dict[str, Any] = Field(default_factory=dict)
