"""Pydantic models for reviews API endpoints."""

from __future__ import annotations

from pydantic import BaseModel


class SubmitReviewRequest(BaseModel):
    """Request to submit a review."""

    proposal_id: str
    reviewer: str
    decision: str
    comment: str | None = None
