"""Request/Response models for ontology configuration endpoints.

Pydantic models for storing, listing, retrieving, and managing versioned
ontology configurations backed by LinkML YAML.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class OntologyConfigStatus(StrEnum):
    """Valid lifecycle statuses for an ontology config."""

    ACTIVE = "active"
    DEPRECATED = "deprecated"
    DRAFT = "draft"


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------


class OntologyConfigStoreRequest(BaseModel):
    """Request body for storing a new ontology configuration (raw YAML)."""

    ontology_name: str = Field(
        ...,
        description="Ontology identifier",
        min_length=1,
        max_length=255,
    )
    ontology_version: str = Field(
        ...,
        description="Ontology version string",
        min_length=1,
        max_length=50,
    )
    linkml_yaml: str = Field(..., description="Raw LinkML YAML string")
    description: str | None = Field(None, description="Human-readable description")
    scheme_key: str | None = Field(
        None, description="Optional concept scheme reference"
    )
    created_by: str | None = Field(None, description="Optional creator identifier")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )


class OntologyConfigStoreFromEditorRequest(BaseModel):
    """Request body for storing from unified editor JSON."""

    ontology_name: str = Field(
        ...,
        description="Ontology identifier",
        min_length=1,
        max_length=255,
    )
    ontology_version: str = Field(
        ...,
        description="Ontology version string",
        min_length=1,
        max_length=50,
    )
    editor_json: dict[str, Any] = Field(
        ...,
        description=("Editor JSON with entities and relationships arrays"),
    )
    description: str | None = Field(None, description="Human-readable description")
    scheme_key: str | None = Field(
        None, description="Optional concept scheme reference"
    )
    created_by: str | None = Field(None, description="Optional creator identifier")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )


class OntologyConfigStatusUpdateRequest(BaseModel):
    """Request body for updating an ontology config status."""

    status: OntologyConfigStatus = Field(
        ...,
        description="New status (active, deprecated, draft)",
    )
    updated_by: str | None = Field(None, description="Optional updater identifier")


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------


class OntologyConfigStoreResponse(BaseModel):
    """Response after storing a new ontology configuration."""

    id: str = Field(..., description="Config ID")
    ontology_name: str = Field(..., description="Ontology name")
    ontology_version: str = Field(..., description="Ontology version")


class OntologyConfigSummary(BaseModel):
    """Summary of a stored ontology configuration."""

    ontology_name: str = Field(..., description="Ontology name")
    ontology_version: str = Field(..., description="Ontology version")
    status: str | None = Field(None, description="Lifecycle status")
    description: str | None = Field(None, description="Description")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )
    schema_id: str | None = Field(None, description="Schema IRI")
    scheme_key: str | None = Field(None, description="Concept scheme key")
    created_at: str | None = Field(None, description="ISO creation timestamp")


class OntologyConfigListResponse(BaseModel):
    """Response for listing ontology configurations."""

    configs: list[OntologyConfigSummary] = Field(
        default_factory=list,
        description="List of config summaries",
    )
    total: int = Field(0, description="Total number of configs")


class OntologyConfigResponse(BaseModel):
    """Full ontology configuration response."""

    id: str = Field(..., description="Config ID")
    ontology_name: str = Field(..., description="Ontology name")
    ontology_version: str = Field(..., description="Ontology version")
    linkml_yaml: str = Field(..., description="Raw LinkML YAML string")
    description: str | None = Field(None, description="Description")
    schema_id: str | None = Field(None, description="Schema IRI")
    scheme_key: str | None = Field(None, description="Concept scheme key")
    status: str | None = Field(None, description="Lifecycle status")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )
    created_at: str | None = Field(None, description="ISO creation timestamp")
    updated_at: str | None = Field(None, description="ISO update timestamp")
    created_by: str | None = Field(None, description="Creator identifier")
    updated_by: str | None = Field(None, description="Updater identifier")


class OntologyConfigVersionsResponse(BaseModel):
    """Response for listing versions of an ontology."""

    ontology_name: str = Field(..., description="Ontology name")
    versions: list[str] = Field(
        default_factory=list,
        description="Sorted list of version strings",
    )
