"""Request/Response models for pipeline configuration endpoints.

Steps-native: all pipeline configs are represented as a list of step dicts.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class PipelineConfigStatus(StrEnum):
    """Valid lifecycle statuses for a pipeline config."""

    ACTIVE = "active"
    DEPRECATED = "deprecated"
    DRAFT = "draft"


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------


class PipelineConfigStoreRequest(BaseModel):
    """Request body for storing a new pipeline configuration."""

    pipeline_name: str = Field(
        ..., description="Pipeline identifier", min_length=1, max_length=255
    )
    pipeline_version: str = Field(
        ..., description="Pipeline version string", min_length=1, max_length=50
    )
    steps: list[dict[str, Any]] = Field(
        ..., description="Pipeline steps (DAG definition)", min_length=1
    )
    settings: dict[str, Any] | None = Field(
        None, description="Optional pipeline settings"
    )
    variables: dict[str, Any] | None = Field(
        None, description="Optional variable substitution dict"
    )
    description: str | None = Field(None, description="Human-readable description")
    contract_name: str | None = Field(
        None, description="Optional associated data contract name"
    )
    contract_version: str | None = Field(
        None, description="Optional associated data contract version"
    )
    created_by: str | None = Field(None, description="Optional creator identifier")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )


class PipelineConfigUpdateRequest(BaseModel):
    """Request body for patching a stored pipeline config."""

    steps: list[dict[str, Any]] | None = Field(None, description="Updated steps list")
    settings: dict[str, Any] | None = Field(
        None, description="Updated pipeline settings"
    )
    variables: dict[str, Any] | None = Field(None, description="Updated variables")
    description: str | None = Field(None, description="Updated description")
    updated_by: str | None = Field(None, description="Optional updater identifier")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )


class PipelineConfigStatusUpdateRequest(BaseModel):
    """Request body for updating a pipeline config status."""

    status: PipelineConfigStatus = Field(
        ..., description="New status (active, deprecated, draft)"
    )
    updated_by: str | None = Field(None, description="Optional updater identifier")


class PipelineConfigRunRequest(BaseModel):
    """Request body for running a stored pipeline config."""

    dry_run: bool = Field(
        False,
        description="If True, extract and transform only (no load)",
    )
    variable_overrides: dict[str, Any] | None = Field(
        None,
        description="Variable overrides applied on top of stored variables",
    )


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------


class PipelineConfigStoreResponse(BaseModel):
    """Response after storing a new pipeline configuration."""

    id: str = Field(..., description="Config ID")
    pipeline_name: str = Field(..., description="Pipeline name")
    pipeline_version: str = Field(..., description="Pipeline version")


class PipelineConfigSummary(BaseModel):
    """Summary of a stored pipeline configuration."""

    pipeline_name: str = Field(..., description="Pipeline name")
    pipeline_version: str = Field(..., description="Pipeline version")
    status: str | None = Field(None, description="Lifecycle status")
    description: str | None = Field(None, description="Description")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )
    contract_name: str | None = Field(None, description="Contract name")
    contract_version: str | None = Field(None, description="Contract version")
    created_at: str | None = Field(None, description="ISO creation timestamp")


class PipelineConfigListResponse(BaseModel):
    """Response for listing pipeline configurations."""

    configs: list[PipelineConfigSummary] = Field(
        default_factory=list, description="List of config summaries"
    )
    total: int = Field(0, description="Total number of configs")


class PipelineConfigResponse(BaseModel):
    """Full pipeline configuration response."""

    id: str = Field(..., description="Config ID")
    pipeline_name: str = Field(..., description="Pipeline name")
    pipeline_version: str = Field(..., description="Pipeline version")
    steps: list[dict[str, Any]] = Field(..., description="Pipeline steps")
    settings: dict[str, Any] | None = Field(None, description="Pipeline settings")
    variables: dict[str, Any] | None = Field(
        None, description="Variable substitution dict"
    )
    description: str | None = Field(None, description="Description")
    status: str | None = Field(None, description="Lifecycle status")
    namespace: str | None = Field(
        None,
        description="Optional virtual folder namespace (slash-delimited)",
    )
    contract_name: str | None = Field(None, description="Contract name")
    contract_version: str | None = Field(None, description="Contract version")
    created_at: str | None = Field(None, description="ISO creation timestamp")
    updated_at: str | None = Field(None, description="ISO update timestamp")
    created_by: str | None = Field(None, description="Creator identifier")
    updated_by: str | None = Field(None, description="Updater identifier")


class PipelineConfigVersionsResponse(BaseModel):
    """Response for listing versions of a pipeline."""

    pipeline_name: str = Field(..., description="Pipeline name")
    versions: list[str] = Field(
        default_factory=list, description="Sorted list of version strings"
    )
