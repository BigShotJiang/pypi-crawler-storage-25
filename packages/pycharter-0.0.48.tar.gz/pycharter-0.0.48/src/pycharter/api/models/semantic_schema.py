"""Pydantic request/response models for ontology schema CRUD endpoints."""

from __future__ import annotations

from pydantic import BaseModel, Field

# ── Relationship types ───────────────────────────────────────────────────────


class CreateRelationshipTypeRequest(BaseModel):
    """Request to create a custom relationship type."""

    name: str = Field(..., min_length=1, max_length=100)
    meaning: str = Field(default="", max_length=500)
    graph_shape: str = Field(default="generic", max_length=50)
    inverse: str = Field(default="", max_length=100)
    symmetric: bool = Field(default=False)
    predicate: str | None = Field(default=None, max_length=255)
    domain_types: list[str] = Field(default_factory=list)
    range_types: list[str] = Field(default_factory=list)


class UpdateRelationshipTypeRequest(BaseModel):
    """Request to update a relationship type.  All fields optional."""

    meaning: str | None = None
    graph_shape: str | None = None
    inverse: str | None = None
    symmetric: bool | None = None
    predicate: str | None = None
    domain_types: list[str] | None = None
    range_types: list[str] | None = None


class RelationshipTypeResponse(BaseModel):
    """Response model for a relationship type."""

    id: str
    name: str
    meaning: str
    graph_shape: str
    inverse: str
    symmetric: bool
    predicate: str | None
    domain_types: list[str]
    range_types: list[str]
    is_builtin: bool


# ── Concept types ────────────────────────────────────────────────────────────


class CreateConceptTypeRequest(BaseModel):
    """Request to create a custom concept type."""

    name: str = Field(..., min_length=1, max_length=100)
    description: str = Field(default="", max_length=500)


class UpdateConceptTypeRequest(BaseModel):
    """Request to update a concept type description."""

    description: str = Field(..., max_length=500)


class ConceptTypeResponse(BaseModel):
    """Response model for a concept type."""

    id: str
    name: str
    description: str
    is_builtin: bool


# ── Tiers ────────────────────────────────────────────────────────────────────


class CreateTierRequest(BaseModel):
    """Request to create a custom governance tier."""

    name: str = Field(..., min_length=1, max_length=100)
    description: str = Field(default="", max_length=500)


class UpdateTierRequest(BaseModel):
    """Request to update a tier description."""

    description: str = Field(..., max_length=500)


class TierResponse(BaseModel):
    """Response model for a tier."""

    id: str
    name: str
    description: str
    is_builtin: bool


# ── Cardinality ──────────────────────────────────────────────────────────────


class CardinalityRuleResponse(BaseModel):
    """Response model for a cardinality rule."""

    concept_type: str
    relationship_type: str
    direction: str
    min: int
    message: str


# ── Schema export ────────────────────────────────────────────────────────────


class SchemaExportResponse(BaseModel):
    """Full schema export as a structured object."""

    version: int
    relationship_type_count: int
    concept_type_count: int
    tier_count: int
    cardinality_rule_count: int
