"""FastAPI application entry point for PyCharter API.

Sets up the FastAPI application with all routes, middleware, and dependencies.
Router registration is delegated to ``_routers.register_routers``.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pycharter import __version__ as pycharter_version
from pycharter.api._routers import API_VERSION, register_routers
from pycharter.config.ports import API_PORT, UI_PORT


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager — runs pending PostgreSQL migrations on startup."""
    import asyncio
    import logging

    from pycharter.config import get_database_url

    logger = logging.getLogger(__name__)
    db_url = get_database_url()
    if db_url and (
        db_url.startswith("postgresql://") or db_url.startswith("postgres://")
    ):
        try:
            from alembic import command

            from pycharter.db.config import get_alembic_config

            def run_upgrade() -> None:
                config = get_alembic_config(db_url)
                command.upgrade(config, "head")

            await asyncio.to_thread(run_upgrade)
            logger.info("PostgreSQL migrations applied (up to head)")
        except Exception as e:
            logger.warning(
                "Could not run PostgreSQL migrations at startup: %s. "
                "Run 'pycharter db upgrade' manually if you see missing table/column errors.",
                e,
                exc_info=True,
            )
    yield


def _configure_cors(app: FastAPI) -> None:
    """Add CORS middleware based on environment variables."""
    import os

    cors_origins_env = os.getenv("CORS_ORIGINS", "").strip()
    cors_origins = (
        [origin.strip() for origin in cors_origins_env.split(",") if origin.strip()]
        if cors_origins_env
        else []
    )

    is_production = os.getenv("ENVIRONMENT") == "production"

    if not cors_origins and not is_production:
        cors_origins = [
            "http://localhost:3000",
            "http://localhost:3001",
            f"http://localhost:{UI_PORT}",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:3001",
            f"http://127.0.0.1:{UI_PORT}",
        ]

    use_credentials = bool(cors_origins and "*" not in cors_origins)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins if cors_origins else ["*"],
        allow_credentials=use_credentials,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=["*"],
    )


def _register_exception_handlers(app: FastAPI) -> None:
    """Add global exception handlers to *app*."""

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """Handle request validation errors."""

        def serialize_error(error: dict) -> dict:
            """Recursively serialize error dict, converting exceptions to strings."""
            serialized = {}
            for key, value in error.items():
                if isinstance(value, Exception):
                    serialized[key] = str(value)
                elif isinstance(value, dict):
                    serialized[key] = serialize_error(value)
                elif isinstance(value, list | tuple):
                    serialized[key] = [
                        (
                            serialize_error(item)
                            if isinstance(item, dict)
                            else str(item)
                            if isinstance(item, Exception)
                            else item
                        )
                        for item in value
                    ]
                else:
                    serialized[key] = value
            return serialized

        errors = [serialize_error(err) for err in exc.errors()]

        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"error": "Validation error", "details": errors},
        )

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        """Global exception handler for unhandled errors."""
        import logging
        import os

        logger = logging.getLogger(__name__)
        logger.error("Unhandled exception: %s", exc, exc_info=True)

        is_development = os.getenv("ENVIRONMENT") == "development"
        error_detail: dict = {"error": "Internal server error"}

        if is_development:
            error_detail.update({"message": str(exc), "type": type(exc).__name__})

        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=error_detail,
        )


def _patch_openapi(app: FastAPI) -> None:
    """Override ``app.openapi()`` to handle unhashable-type errors gracefully."""
    original_openapi = app.openapi

    def openapi_with_error_handling():
        """OpenAPI schema with error handling for unhashable types."""
        try:
            return original_openapi()
        except TypeError as e:
            if "unhashable type" in str(e):
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(
                    "OpenAPI schema generation encountered an issue: %s. "
                    "Returning minimal schema.",
                    e,
                )
                return {
                    "openapi": "3.1.0",
                    "info": {
                        "title": app.title,
                        "version": app.version,
                        "description": app.description,
                    },
                    "paths": {},
                    "components": {"schemas": {}},
                }
            raise

    app.openapi = openapi_with_error_handling


def _mount_collab(app: FastAPI) -> None:
    """Optionally mount the collaboration relay at /collab."""
    import logging

    logger = logging.getLogger(__name__)
    try:
        from pycharter.collab import create_collab_app

        collab_app = create_collab_app()
        app.mount("/collab", collab_app)
        logger.info("Collaboration module mounted at /collab")
    except ImportError:
        logger.debug(
            "Collaboration module not installed (pip install pycharter[collab])"
        )


def create_application() -> FastAPI:
    """Create and configure the FastAPI application.

    Returns:
        Configured FastAPI application instance.
    """
    app = FastAPI(
        title="PyCharter API",
        description="REST API for PyCharter data contract management and validation",
        version=pycharter_version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    from pycharter.events import ChangeBus

    app.state.change_bus = ChangeBus()

    _configure_cors(app)
    register_routers(app)
    _register_exception_handlers(app)
    _patch_openapi(app)
    _mount_collab(app)

    @app.get(
        "/",
        summary="API Information",
        description="Get API information and version",
        tags=["General"],
    )
    async def root() -> dict:
        """Root endpoint with API information."""
        return {
            "name": "PyCharter API",
            "version": pycharter_version,
            "api_version": API_VERSION,
            "docs": "/docs",
            "redoc": "/redoc",
        }

    @app.get(
        "/health",
        summary="Health Check",
        description="Check API health status",
        tags=["General"],
    )
    async def health_check() -> dict:
        """Health check endpoint."""
        return {"status": "healthy", "version": pycharter_version}

    return app


# Create application instance
app = create_application()


def main():
    """Main entry point for running the API server."""
    from pathlib import Path

    import uvicorn

    pkg_root = Path(__file__).resolve().parent.parent
    reload_dirs = [
        str(d) for d in sorted(pkg_root.iterdir()) if d.is_dir() and d.name != "ui"
    ]

    uvicorn.run(
        "pycharter.api.main:app",
        host="0.0.0.0",
        port=API_PORT,
        reload=True,
        reload_dirs=reload_dirs,
    )


if __name__ == "__main__":
    main()
