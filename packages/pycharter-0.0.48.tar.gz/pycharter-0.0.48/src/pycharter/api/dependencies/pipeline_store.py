"""Dependencies for pipeline config store connections.

This module provides FastAPI dependency injection for pipeline store instances.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from fastapi import HTTPException, status
from pydantic_settings import BaseSettings

from pycharter.config import get_database_url
from pycharter.pipeline_store import (
    InMemoryPipelineStore,
    MongoDBPipelineStore,
    PipelineStoreClient,
    PostgresPipelineStore,
    RedisPipelineStore,
    SQLitePipelineStore,
)


class PipelineStoreSettings(BaseSettings):
    """Settings for pipeline config store configuration."""

    model_config = {"env_prefix": "PYCHARTER_API_", "case_sensitive": False}

    store_type: str = "sqlite"
    connection_string: str | None = None


@lru_cache
def get_pipeline_store_settings() -> PipelineStoreSettings:
    """Get pipeline store settings from environment variables (cached)."""
    return PipelineStoreSettings()


# Global store instance (singleton pattern)
_pipeline_store_instance: PipelineStoreClient | None = None


def get_pipeline_store() -> PipelineStoreClient:
    """FastAPI dependency to get pipeline store instance (singleton).

    Auto-detects store type from PYCHARTER_DATABASE_URL or uses configured
    settings.  Defaults to SQLite if nothing is configured.
    """
    global _pipeline_store_instance  # noqa: PLW0603

    if _pipeline_store_instance is None:
        settings = get_pipeline_store_settings()
        store_type = settings.store_type.lower()
        connection_string = settings.connection_string

        # Auto-detect from database URL if available
        db_url = get_database_url()
        if db_url and not connection_string:
            if db_url.startswith(("postgresql://", "postgres://")):
                store_type = "postgres"
                connection_string = db_url
            elif db_url.startswith("sqlite://"):
                store_type = "sqlite"
                connection_string = db_url

        # Create store instance
        if store_type == "sqlite":
            if not connection_string:
                connection_string = f"sqlite:///{Path.cwd() / 'pycharter.db'}"
            _pipeline_store_instance = SQLitePipelineStore(
                connection_string=connection_string,
            )
        elif store_type == "in_memory":
            _pipeline_store_instance = InMemoryPipelineStore()
        elif store_type == "postgres":
            connection_string = connection_string or get_database_url()
            if not connection_string:
                raise ValueError(
                    "connection_string required for PostgreSQL pipeline store"
                )
            _pipeline_store_instance = PostgresPipelineStore(
                connection_string=connection_string,
            )
        elif store_type == "mongodb":
            if not connection_string:
                raise ValueError(
                    "connection_string required for MongoDB pipeline store"
                )
            _pipeline_store_instance = MongoDBPipelineStore(
                connection_string=connection_string,
            )
        elif store_type == "redis":
            if not connection_string:
                raise ValueError("connection_string required for Redis pipeline store")
            _pipeline_store_instance = RedisPipelineStore(
                connection_string=connection_string,
            )
        else:
            raise ValueError(f"Unsupported pipeline store type: {store_type}")

        try:
            _pipeline_store_instance.connect()
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to initialize pipeline store: {exc!s}",
            ) from exc

    return _pipeline_store_instance
