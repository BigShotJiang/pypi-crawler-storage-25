"""Dependencies for semantic store connections.

This module provides FastAPI dependency injection for semantic store instances.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from fastapi import HTTPException, status
from pydantic_settings import BaseSettings

from pycharter.config import get_database_url
from pycharter.semantic_store import (
    InMemorySemanticStore,
    PostgresSemanticStore,
    SemanticStoreClient,
    SQLiteSemanticStore,
)


class SemanticStoreSettings(BaseSettings):
    """Settings for semantic store configuration."""

    model_config = {"env_prefix": "PYCHARTER_API_", "case_sensitive": False}

    semantic_store_type: str = "sqlite"
    semantic_store_connection_string: str | None = None


@lru_cache
def get_semantic_store_settings() -> SemanticStoreSettings:
    """Get semantic store settings from environment variables (cached)."""
    return SemanticStoreSettings()


# Global store instance (singleton pattern)
_semantic_store_instance: SemanticStoreClient | None = None


def get_semantic_store() -> SemanticStoreClient:
    """FastAPI dependency to get semantic store instance (singleton).

    Auto-detects store type from PYCHARTER_DATABASE_URL or uses configured
    settings.  Defaults to SQLite if nothing is configured.
    """
    global _semantic_store_instance  # noqa: PLW0603

    if _semantic_store_instance is None:
        settings = get_semantic_store_settings()
        store_type = settings.semantic_store_type.lower()
        connection_string = settings.semantic_store_connection_string

        # Auto-detect from database URL if available
        db_url = get_database_url()
        if db_url and not connection_string:
            if db_url.startswith(("postgresql://", "postgres://")):
                store_type = "postgres"
                connection_string = db_url
            elif db_url.startswith("sqlite://"):
                store_type = "sqlite"
                connection_string = db_url

        # Create store instance
        if store_type == "sqlite":
            if not connection_string:
                connection_string = f"sqlite:///{Path.cwd() / 'pycharter.db'}"
            _semantic_store_instance = SQLiteSemanticStore(
                connection_string=connection_string,
            )
        elif store_type == "in_memory":
            _semantic_store_instance = InMemorySemanticStore()
        elif store_type == "postgres":
            connection_string = connection_string or get_database_url()
            if not connection_string:
                raise ValueError(
                    "connection_string required for PostgreSQL semantic store"
                )
            _semantic_store_instance = PostgresSemanticStore(
                connection_string=connection_string,
            )
        else:
            raise ValueError(f"Unsupported semantic store type: {store_type}")

        try:
            _semantic_store_instance.connect()
        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to initialize semantic store: {exc!s}",
            ) from exc

    return _semantic_store_instance
