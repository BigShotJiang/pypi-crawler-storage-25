"""Apache Kafka extractor for streaming ETL pipelines.

Re-export shim -- the actual implementation lives in
``_kafka_extractor``.

All public names are re-exported here so that existing
``from pycharter.pipeline_generator.extractors.kafka import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.pipeline_generator.extractors._kafka_extractor import (
    _HAS_AIOKAFKA,
    AIOKafkaConsumer,
    KafkaExtractor,
    OffsetAndMetadata,
    TopicPartition,
)

__all__ = [
    "AIOKafkaConsumer",
    "KafkaExtractor",
    "OffsetAndMetadata",
    "TopicPartition",
    "_HAS_AIOKAFKA",
]
