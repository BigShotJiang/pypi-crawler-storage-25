"""
Extractors module for ETL orchestrator.

This module provides a modular architecture for data extraction from various sources:
- HTTP/API extraction
- File-based extraction (CSV, JSON, Parquet, Excel, TSV, XML)
- Database extraction (PostgreSQL, MySQL, SQLite, MSSQL, Oracle)
- MongoDB extraction (queries and aggregation pipelines)
- Cloud storage extraction (S3, GCS, Azure Blob)

Entry point for orchestration: extract_with_pagination_streaming().
"""

from __future__ import annotations

from pycharter.pipeline_generator.extractors.base import BaseExtractor
from pycharter.pipeline_generator.extractors.cloud_storage import CloudStorageExtractor
from pycharter.pipeline_generator.extractors.database import DatabaseExtractor
from pycharter.pipeline_generator.extractors.factory import ExtractorFactory
from pycharter.pipeline_generator.extractors.file import FileExtractor
from pycharter.pipeline_generator.extractors.http import (
    HTTPExtractor,
    get_path_param_names,
)
from pycharter.pipeline_generator.extractors.streaming import (
    extract_with_pagination_streaming,
)

__all__ = [
    "BaseExtractor",
    "ExtractorFactory",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "MongoDBExtractor",
    "CloudStorageExtractor",
    "SSEExtractor",
    "WebSocketExtractor",
    "FileWatcherExtractor",
    "KafkaExtractor",
    "RabbitMQExtractor",
    "SQSExtractor",
    "extract_with_pagination_streaming",
    "get_path_param_names",
]

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "MongoDBExtractor": (
        "pycharter.pipeline_generator.extractors.mongodb",
        "MongoDBExtractor",
    ),
    "SSEExtractor": (
        "pycharter.pipeline_generator.extractors.sse",
        "SSEExtractor",
    ),
    "WebSocketExtractor": (
        "pycharter.pipeline_generator.extractors.websocket",
        "WebSocketExtractor",
    ),
    "FileWatcherExtractor": (
        "pycharter.pipeline_generator.extractors.file_watcher",
        "FileWatcherExtractor",
    ),
    "KafkaExtractor": (
        "pycharter.pipeline_generator.extractors.kafka",
        "KafkaExtractor",
    ),
    "RabbitMQExtractor": (
        "pycharter.pipeline_generator.extractors.rabbitmq",
        "RabbitMQExtractor",
    ),
    "SQSExtractor": (
        "pycharter.pipeline_generator.extractors.sqs",
        "SQSExtractor",
    ),
}


def __getattr__(name: str):
    """Lazy-load optional extractors on first access."""
    if name in _LAZY_IMPORTS:
        module_path, class_name = _LAZY_IMPORTS[name]
        import importlib

        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
