"""Azure Blob Storage extraction logic for the cloud storage extractor.

Provides ``extract_from_azure`` -- an async generator that downloads blobs
from an Azure container and yields record batches via ``FileExtractor``.

This module is internal.  Use ``CloudStorageExtractor`` from
``pycharter.pipeline_generator.extractors.cloud_storage``.
"""

from __future__ import annotations

import logging
import os
import tempfile
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator.extractors.file import FileExtractor

logger = logging.getLogger(__name__)

# Try to import Azure dependencies
try:
    from azure.storage.blob import BlobServiceClient

    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False
    BlobServiceClient = None  # type: ignore[assignment,misc]


async def extract_from_azure(
    container: str,
    path: str,
    credentials: dict[str, Any] | None,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
    source_file: str | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from Azure Blob Storage.

    Downloads blobs from *container*/*path* to temporary files and delegates
    parsing to ``FileExtractor``.  Supports single-blob and prefix downloads.

    Args:
        container: Azure container name.
        path: Blob name or prefix (ending with ``/`` or containing ``*``).
        credentials: Optional dict with ``connection_string`` or
            ``account_name`` + ``account_key``.
        file_format: Explicit file format (csv, json, parquet, ...).
        batch_size: Number of records per yielded batch.
        max_records: Stop after this many records (``None`` = unlimited).
        config_context: Variable-resolution context.
        source_file: Path used for variable resolution.

    Yields:
        Batches of parsed records.
    """
    if not AZURE_AVAILABLE:
        raise ImportError(
            "azure-storage-blob is required for Azure extraction. "
            "Install with: pip install azure-storage-blob"
        )

    blob_service_client = _build_azure_client(credentials)
    container_client = blob_service_client.get_container_client(container)

    if path.endswith("/") or "*" in path:
        async for batch in _extract_azure_prefix(
            container,
            container_client,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch
    else:
        async for batch in _extract_azure_single(
            container_client,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch


def _build_azure_client(credentials: dict[str, Any] | None) -> Any:
    """Build and return an Azure BlobServiceClient."""
    if credentials:
        connection_string = credentials.get("connection_string")
        account_name = credentials.get("account_name")
        account_key = credentials.get("account_key")

        if connection_string:
            return BlobServiceClient.from_connection_string(connection_string)
        if account_name and account_key:
            account_url = f"https://{account_name}.blob.core.windows.net"
            return BlobServiceClient(account_url, credential=account_key)
        raise ValueError(
            "Azure credentials must include 'connection_string' "
            "or ('account_name', 'account_key')"
        )

    # Use default credentials (environment variables)
    return BlobServiceClient.from_connection_string(
        os.environ.get("AZURE_STORAGE_CONNECTION_STRING", "")
    )


async def _extract_azure_prefix(
    container_name: str,
    container_client: Any,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from all blobs under an Azure prefix."""
    prefix = path.rstrip("/")
    if "*" in prefix:
        prefix = prefix.split("*")[0]

    blobs = container_client.list_blobs(name_starts_with=prefix)

    total_extracted = 0
    for blob in blobs:
        if max_records and total_extracted >= max_records:
            return

        logger.info("Processing Azure blob: %s/%s", container_name, blob.name)

        blob_client = container_client.get_blob_client(blob.name)
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=Path(blob.name).suffix
        ) as tmp_file:
            tmp_path = Path(tmp_file.name)
            try:
                blob_data = blob_client.download_blob()
                blob_data.download_to_stream(tmp_file)

                file_extractor = FileExtractor()
                file_config = {
                    "type": "file",
                    "file_path": str(tmp_path),
                    "format": file_format,
                }

                async for batch in file_extractor.extract_streaming(
                    file_config,
                    {},
                    {},
                    None,
                    batch_size,
                    max_records,
                    config_context,
                ):
                    total_extracted += len(batch)
                    yield batch
                    if max_records and total_extracted >= max_records:
                        return
            finally:
                if tmp_path.exists():
                    tmp_path.unlink()


async def _extract_azure_single(
    container_client: Any,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from a single Azure blob."""
    blob_client = container_client.get_blob_client(path)
    with tempfile.NamedTemporaryFile(
        delete=False, suffix=Path(path).suffix
    ) as tmp_file:
        tmp_path = Path(tmp_file.name)
        try:
            blob_data = blob_client.download_blob()
            blob_data.download_to_stream(tmp_file)

            file_extractor = FileExtractor()
            file_config = {
                "type": "file",
                "file_path": str(tmp_path),
                "format": file_format,
            }

            async for batch in file_extractor.extract_streaming(
                file_config,
                {},
                {},
                None,
                batch_size,
                max_records,
                config_context,
            ):
                yield batch
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
