"""JSON and JSONL (newline-delimited) extraction helpers.

Async generator functions for extracting records from JSON-based
file formats.
"""

from __future__ import annotations

import gzip
import json
import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


async def extract_json(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from a JSON file.

    Handles both gzip-compressed and plain JSON files, and supports
    top-level lists, dicts with common data keys, or single objects.

    Args:
        file_path: Path to the JSON file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial records to skip.

    Yields:
        Batches of records as list of dicts.
    """
    try:
        # Handle gzip compressed JSON
        if file_path.suffix == ".gz":
            with gzip.open(file_path, "rt", encoding="utf-8") as fh:
                data = json.load(fh)
        else:
            with open(file_path, encoding="utf-8") as fh:
                data = json.load(fh)

        # Handle different JSON structures
        if isinstance(data, list):
            records = data
        elif isinstance(data, dict):
            # Try to find array in common keys
            for key in ("data", "results", "items", "records", "values"):
                if key in data and isinstance(data[key], list):
                    records = data[key]
                    break
            else:
                # Single object
                records = [data]
        else:
            raise ValueError(f"JSON file must contain a list or dict, got {type(data)}")

        # Apply offset and max_records
        if offset > 0:
            records = records[offset:]
        if max_records:
            records = records[:max_records]

        # Yield in batches
        for idx in range(0, len(records), batch_size):
            yield records[idx : idx + batch_size]
    except Exception as exc:
        raise RuntimeError(f"Error reading JSON file {file_path}: {exc}") from exc


async def extract_jsonl(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from a newline-delimited JSON file.

    Args:
        file_path: Path to the JSONL/NDJSON file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial lines to skip.

    Yields:
        Batches of records as list of dicts.
    """
    try:
        current_batch: list[dict[str, Any]] = []
        total_read = 0
        skipped = 0

        # Handle gzip compressed JSONL
        if file_path.suffix == ".gz":
            file_handle = gzip.open(file_path, "rt", encoding="utf-8")
        else:
            file_handle = open(file_path, encoding="utf-8")  # noqa: SIM115

        with file_handle as fh:
            for line in fh:
                # Skip lines until offset
                if skipped < offset:
                    skipped += 1
                    continue

                if max_records and total_read >= max_records:
                    break

                line = line.strip()
                if not line:
                    continue

                try:
                    record = json.loads(line)
                    current_batch.append(record)
                    total_read += 1

                    if len(current_batch) >= batch_size:
                        yield current_batch
                        current_batch = []
                except json.JSONDecodeError as exc:
                    logger.warning(
                        "Skipping invalid JSON line in %s: %s", file_path, exc
                    )
                    continue

            # Yield remaining records
            if current_batch:
                yield current_batch
    except Exception as exc:
        raise RuntimeError(f"Error reading JSONL file {file_path}: {exc}") from exc
