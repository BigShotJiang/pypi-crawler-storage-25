"""MongoDB extractor for ETL orchestrator.

Re-export shim -- the actual implementation lives in
``_mongodb_extractor``.

All public names are re-exported here so that existing
``from pycharter.pipeline_generator.extractors.mongodb import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.pipeline_generator.extractors._mongodb_extractor import (
    DEFAULT_MONGODB_PORT,
    MongoDBExtractor,
    _modify_mongodb_url_for_tunnel,
    _serialize_document,
)

__all__ = [
    "DEFAULT_MONGODB_PORT",
    "MongoDBExtractor",
    "_modify_mongodb_url_for_tunnel",
    "_serialize_document",
]
