"""StrEnum definitions for ETL pipeline configuration types."""

from __future__ import annotations

from enum import StrEnum


class ExtractType(StrEnum):
    """Extract source types."""

    HTTP = "http"
    FILE = "file"
    DATABASE = "database"
    CLOUD_STORAGE = "cloud_storage"


class LoadType(StrEnum):
    """Load destination types."""

    POSTGRES = "postgres"
    POSTGRESQL = "postgresql"
    DATABASE = "database"
    SQLITE = "sqlite"
    FILE = "file"
    CLOUD_STORAGE = "cloud_storage"


class CloudProvider(StrEnum):
    """Cloud storage providers."""

    S3 = "s3"
    GCS = "gcs"
    AZURE = "azure"


class WriteMethod(StrEnum):
    """Database write methods."""

    INSERT = "insert"
    UPSERT = "upsert"
    REPLACE = "replace"
    UPDATE = "update"
    DELETE = "delete"
    TRUNCATE_AND_LOAD = "truncate_and_load"


class FileFormat(StrEnum):
    """File formats."""

    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"
    TSV = "tsv"
    PARQUET = "parquet"
    EXCEL = "excel"
    XML = "xml"


class WriteMode(StrEnum):
    """File write modes."""

    OVERWRITE = "overwrite"
    APPEND = "append"


class OnErrorAction(StrEnum):
    """Actions on validation error."""

    FAIL = "fail"
    WARN = "warn"
    SKIP = "skip"
    QUARANTINE = "quarantine"


class DLQBackend(StrEnum):
    """DLQ storage backends."""

    FILE = "file"
    DATABASE = "database"
    MEMORY = "memory"


class ContractStoreType(StrEnum):
    """Contract store types."""

    POSTGRES = "postgres"
    SQLITE = "sqlite"
    MONGODB = "mongodb"
    REDIS = "redis"
    MEMORY = "memory"


class FilterOperator(StrEnum):
    """Filter comparison operators."""

    EQ = "eq"
    NE = "ne"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    IN = "in"
    NOT_IN = "not_in"
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    IS_NULL = "is_null"
    IS_NOT_NULL = "is_not_null"


class PaginationStrategy(StrEnum):
    """HTTP pagination strategies."""

    PAGE = "page"
    OFFSET = "offset"
    CURSOR = "cursor"
    LINK = "link"


class HTTPMethod(StrEnum):
    """HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class ResponseFormat(StrEnum):
    """HTTP response formats."""

    JSON = "json"
    TEXT = "text"
    XML = "xml"


class ConvertType(StrEnum):
    """Type conversion targets."""

    INT = "int"
    INTEGER = "integer"
    FLOAT = "float"
    NUMBER = "number"
    STR = "str"
    STRING = "string"
    BOOL = "bool"
    BOOLEAN = "boolean"
    DATETIME = "datetime"
    DATE = "date"


class JSONataMode(StrEnum):
    """JSONata application mode."""

    RECORD = "record"
    BATCH = "batch"
