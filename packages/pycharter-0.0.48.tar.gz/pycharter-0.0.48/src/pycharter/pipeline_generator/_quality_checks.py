"""Quality check implementations for ETL pipelines.

Provides built-in quality checks (row count, null rate, uniqueness,
expression) and the check registry used by QualityChecker.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.pipeline_generator._quality_metrics import (
    QualityCheckResult,
    QualityCheckStatus,
    parse_severity,
)
from pycharter.pipeline_generator.result import LoadResult

logger = logging.getLogger(__name__)


# =============================================================================
# BUILT-IN CHECKS
# =============================================================================

_SAFE_BUILTINS = {
    "len": len,
    "sum": sum,
    "min": min,
    "max": max,
    "any": any,
    "all": all,
    "abs": abs,
}


def check_row_count(
    loaded_records: list[dict[str, Any]],
    load_result: LoadResult,
    config: dict[str, Any],
) -> QualityCheckResult:
    """Check that the row count meets configured constraints.

    Config keys:
        min: Minimum row count.
        max: Maximum row count.
        exact: Exact expected count.
        expected: Expected count with tolerance.
        tolerance_percent: Allowed deviation from expected (default 0).
    """
    severity = parse_severity(config)
    count = len(loaded_records)
    details: dict[str, Any] = {"actual_count": count}

    # Exact count
    if "exact" in config:
        expected = config["exact"]
        details["exact"] = expected
        if count != expected:
            return QualityCheckResult(
                check_name="row_count",
                check_type="row_count",
                status=QualityCheckStatus.FAILED,
                severity=severity,
                message=f"Row count {count} != expected {expected}",
                details=details,
            )

    # Expected with tolerance
    if "expected" in config:
        expected = config["expected"]
        tolerance = config.get("tolerance_percent", 0)
        delta = expected * tolerance / 100.0
        lower = expected - delta
        upper = expected + delta
        details["expected"] = expected
        details["tolerance_percent"] = tolerance
        if not (lower <= count <= upper):
            return QualityCheckResult(
                check_name="row_count",
                check_type="row_count",
                status=QualityCheckStatus.FAILED,
                severity=severity,
                message=(
                    f"Row count {count} outside expected range "
                    f"[{lower:.0f}, {upper:.0f}]"
                ),
                details=details,
            )

    # Min
    if "min" in config:
        min_val = config["min"]
        details["min"] = min_val
        if count < min_val:
            return QualityCheckResult(
                check_name="row_count",
                check_type="row_count",
                status=QualityCheckStatus.FAILED,
                severity=severity,
                message=f"Row count {count} < minimum {min_val}",
                details=details,
            )

    # Max
    if "max" in config:
        max_val = config["max"]
        details["max"] = max_val
        if count > max_val:
            return QualityCheckResult(
                check_name="row_count",
                check_type="row_count",
                status=QualityCheckStatus.FAILED,
                severity=severity,
                message=f"Row count {count} > maximum {max_val}",
                details=details,
            )

    return QualityCheckResult(
        check_name="row_count",
        check_type="row_count",
        status=QualityCheckStatus.PASSED,
        severity=severity,
        message=f"Row count {count} within constraints",
        details=details,
    )


def check_null_rate(
    loaded_records: list[dict[str, Any]],
    load_result: LoadResult,
    config: dict[str, Any],
) -> QualityCheckResult:
    """Check that null rates for specified fields are within limits.

    Config keys:
        fields: List of field names to check.
        max_null_percent: Maximum allowed null percentage (default 0.0).
    """
    severity = parse_severity(config)
    fields = config.get("fields", [])
    max_null_pct = config.get("max_null_percent", 0.0)
    total = len(loaded_records)
    details: dict[str, Any] = {"max_null_percent": max_null_pct, "fields": {}}
    violations: list[str] = []

    if total == 0:
        return QualityCheckResult(
            check_name="null_rate",
            check_type="null_rate",
            status=QualityCheckStatus.PASSED,
            severity=severity,
            message="No records to check",
            details=details,
        )

    for fld in fields:
        null_count = sum(1 for r in loaded_records if r.get(fld) is None)
        null_pct = (null_count / total) * 100.0
        details["fields"][fld] = {"null_count": null_count, "null_percent": null_pct}
        if null_pct > max_null_pct:
            violations.append(
                f"'{fld}' has {null_pct:.1f}% nulls (max {max_null_pct}%)"
            )

    if violations:
        return QualityCheckResult(
            check_name="null_rate",
            check_type="null_rate",
            status=QualityCheckStatus.FAILED,
            severity=severity,
            message=f"Null rate violations: {'; '.join(violations)}",
            details=details,
        )

    return QualityCheckResult(
        check_name="null_rate",
        check_type="null_rate",
        status=QualityCheckStatus.PASSED,
        severity=severity,
        message="All fields within null rate limits",
        details=details,
    )


def check_uniqueness(
    loaded_records: list[dict[str, Any]],
    load_result: LoadResult,
    config: dict[str, Any],
) -> QualityCheckResult:
    """Check that specified fields have unique values.

    Config keys:
        fields: List of field names that must be unique (individually).
    """
    severity = parse_severity(config)
    fields = config.get("fields", [])
    details: dict[str, Any] = {"fields": {}}
    violations: list[str] = []

    for fld in fields:
        values = [r.get(fld) for r in loaded_records]
        # Filter out None values for uniqueness check
        non_null = [v for v in values if v is not None]
        unique_count = len(set(non_null))
        total_non_null = len(non_null)
        duplicate_count = total_non_null - unique_count
        details["fields"][fld] = {
            "total": total_non_null,
            "unique": unique_count,
            "duplicates": duplicate_count,
        }
        if duplicate_count > 0:
            violations.append(f"'{fld}' has {duplicate_count} duplicate(s)")

    if violations:
        return QualityCheckResult(
            check_name="uniqueness",
            check_type="uniqueness",
            status=QualityCheckStatus.FAILED,
            severity=severity,
            message=f"Uniqueness violations: {'; '.join(violations)}",
            details=details,
        )

    return QualityCheckResult(
        check_name="uniqueness",
        check_type="uniqueness",
        status=QualityCheckStatus.PASSED,
        severity=severity,
        message="All fields have unique values",
        details=details,
    )


def check_expression(
    loaded_records: list[dict[str, Any]],
    load_result: LoadResult,
    config: dict[str, Any],
) -> QualityCheckResult:
    """Evaluate a custom expression against loaded data.

    Config keys:
        expression: Python expression string to evaluate.
        description: Human-readable description of the check.

    Available variables in scope:
        row_count, loaded_count, failed_count, fields, records.
    Safe builtins: len, sum, min, max, any, all, abs.
    """
    severity = parse_severity(config)
    expression = config.get("expression", "")
    description = config.get("description", expression)

    if not expression:
        return QualityCheckResult(
            check_name=description,
            check_type="expression",
            status=QualityCheckStatus.SKIPPED,
            severity=severity,
            message="No expression provided",
        )

    # Build safe evaluation scope
    scope: dict[str, Any] = {
        "__builtins__": _SAFE_BUILTINS,
        "row_count": len(loaded_records),
        "loaded_count": load_result.rows_loaded,
        "failed_count": load_result.rows_failed,
        "records": loaded_records,
        "fields": list(loaded_records[0].keys()) if loaded_records else [],
    }

    try:
        result = eval(expression, scope)  # noqa: S307
    except Exception as exc:
        logger.warning("Quality check expression failed: %s — %s", expression, exc)
        return QualityCheckResult(
            check_name=description,
            check_type="expression",
            status=QualityCheckStatus.SKIPPED,
            severity=severity,
            message=f"Expression evaluation error: {exc}",
            details={"expression": expression},
        )

    if result:
        return QualityCheckResult(
            check_name=description,
            check_type="expression",
            status=QualityCheckStatus.PASSED,
            severity=severity,
            message=f"Expression passed: {description}",
            details={"expression": expression},
        )

    return QualityCheckResult(
        check_name=description,
        check_type="expression",
        status=QualityCheckStatus.FAILED,
        severity=severity,
        message=f"Expression failed: {description}",
        details={"expression": expression},
    )


# =============================================================================
# QUALITY CHECKER
# =============================================================================

_CHECK_REGISTRY: dict[str, Any] = {
    "row_count": check_row_count,
    "null_rate": check_null_rate,
    "uniqueness": check_uniqueness,
    "expression": check_expression,
}
