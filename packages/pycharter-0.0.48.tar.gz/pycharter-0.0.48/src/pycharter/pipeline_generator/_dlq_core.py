"""Core DLQ data types: reason enum and dead-letter record.

Extracted from :mod:`dlq` so that both the ``DeadLetterQueue`` class and
the database persistence module can reference the types without pulling in
the full queue implementation.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any


class DLQReason(Enum):
    """Reasons for DLQ placement."""

    EXTRACTION_ERROR = "extraction_error"
    TRANSFORMATION_ERROR = "transformation_error"
    VALIDATION_ERROR = "validation_error"
    LOAD_ERROR = "load_error"
    CONNECTION_ERROR = "connection_error"
    SCHEMA_MISMATCH = "schema_mismatch"
    UNKNOWN = "unknown"


def _generate_record_id() -> str:
    """Generate a unique DLQ record ID."""
    return uuid.uuid4().hex[:16]


def _generate_content_hash(
    pipeline_name: str,
    reason: DLQReason,
    stage: str,
    record_data: dict[str, Any],
) -> str:
    """Generate a deterministic hash-based ID from record content.

    Args:
        pipeline_name: Name of the pipeline that failed.
        reason: Reason for DLQ placement.
        stage: ETL stage where failure occurred.
        record_data: The actual record data that failed.

    Returns:
        A 16-character hex digest uniquely identifying the content.
    """
    data_str = json.dumps(record_data, sort_keys=True, default=str)
    hash_input = f"{pipeline_name}:{reason.value}:{stage}:{data_str}"
    return hashlib.sha256(hash_input.encode()).hexdigest()[:16]


@dataclass(frozen=True, slots=True)
class DeadLetterRecord:
    """Immutable record of a dead-lettered pipeline event.

    Attributes:
        pipeline_name: Name of the pipeline that failed.
        record_data: The actual record data that failed.
        reason: Reason for DLQ placement.
        error_message: Error message.
        error_type: Type of error (exception class name).
        stage: ETL stage where failure occurred ('extract', 'transform', 'load').
        metadata: Additional metadata (batch_num, run_id, etc.).
        id: Unique record identifier (auto-generated if not provided).
        timestamp: UTC timestamp when the record was created.
        retry_count: Number of retry attempts.
        status: Record status (pending, retrying, resolved, ignored).
    """

    pipeline_name: str
    record_data: dict[str, Any]
    reason: DLQReason
    error_message: str
    error_type: str
    stage: str
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=_generate_record_id)
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    retry_count: int = 0
    status: str = "pending"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "pipeline_name": self.pipeline_name,
            "record_data": self.record_data,
            "reason": self.reason.value,
            "error_message": self.error_message,
            "error_type": self.error_type,
            "stage": self.stage,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
            "retry_count": self.retry_count,
            "status": self.status,
        }
