"""DAG execution engine for step-based pipelines.

Executes a topologically sorted list of steps, threading intermediate
data through the graph and collecting per-step results.
"""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any

from pycharter.pipeline_generator._dag import DAGError
from pycharter.pipeline_generator.result import PipelineResult, StepResult
from pycharter.pipeline_generator.steps._base import (
    ExtractStepConfig,
    JoinStepConfig,
    LoadStepConfig,
    StepConfig,
    TransformStepConfig,
    UnionStepConfig,
)
from pycharter.pipeline_generator.steps.extract import run_extract
from pycharter.pipeline_generator.steps.join import run_join
from pycharter.pipeline_generator.steps.load import run_load
from pycharter.pipeline_generator.steps.transform import run_transform
from pycharter.pipeline_generator.steps.union import run_union

logger = logging.getLogger(__name__)


async def run_dag(
    steps: list[StepConfig],
    *,
    pipeline_name: str = "unnamed",
    run_id: str | None = None,
    variables: dict[str, str] | None = None,
    fail_fast: bool = True,
) -> PipelineResult:
    """Execute a DAG of pipeline steps.

    Steps must already be in topological order (use ``resolve_dag``
    first).

    Args:
        steps: Steps in execution order.
        pipeline_name: Human-readable pipeline name for logging.
        run_id: Optional run identifier.
        variables: Resolved pipeline variables.
        fail_fast: If True, abort on the first step failure.

    Returns:
        Aggregated pipeline result with per-step results.
    """
    import uuid

    if run_id is None:
        run_id = uuid.uuid4().hex[:12]

    vars_ = variables or {}
    result = PipelineResult(
        pipeline_name=pipeline_name,
        run_id=run_id,
        start_time=datetime.now(UTC),
    )

    # Intermediate data store: step_id → list[dict].
    data_store: dict[str, list[dict[str, Any]]] = {}

    logger.info(
        "[%s] Starting pipeline '%s' with %d steps",
        run_id,
        pipeline_name,
        len(steps),
    )

    pipeline_start = time.monotonic()

    for step in steps:
        step_start = time.monotonic()
        step_result = StepResult(step_id=step.id, step_type=step.type)

        try:
            if isinstance(step, ExtractStepConfig):
                records = await run_extract(step, vars_)
                data_store[step.id] = records
                step_result.rows_out = len(records)
                result.rows_extracted += len(records)

            elif isinstance(step, TransformStepConfig):
                input_data = _get_input(data_store, step.input, step.id)
                step_result.rows_in = len(input_data)
                records = run_transform(step, input_data)
                data_store[step.id] = records
                step_result.rows_out = len(records)
                result.rows_transformed += len(records)

            elif isinstance(step, JoinStepConfig):
                left_data = _get_input(data_store, step.left, step.id)
                right_data = _get_input(data_store, step.right, step.id)
                step_result.rows_in = len(left_data) + len(right_data)
                records = run_join(step, left_data, right_data)
                data_store[step.id] = records
                step_result.rows_out = len(records)

            elif isinstance(step, UnionStepConfig):
                datasets = [_get_input(data_store, sid, step.id) for sid in step.inputs]
                step_result.rows_in = sum(len(d) for d in datasets)
                records = run_union(step, datasets)
                data_store[step.id] = records
                step_result.rows_out = len(records)

            elif isinstance(step, LoadStepConfig):
                input_data = _get_input(data_store, step.input, step.id)
                step_result.rows_in = len(input_data)
                load_result = await run_load(step, input_data, pipeline_name)
                step_result.rows_out = load_result.rows_loaded
                result.rows_loaded += load_result.rows_loaded
                result.rows_failed += load_result.rows_failed
                if not load_result.success:
                    step_result.success = False
                    err = load_result.error or "Load failed"
                    step_result.errors.append(err)

        except Exception as exc:
            step_result.success = False
            step_result.errors.append(str(exc))
            logger.error(
                "[%s] Step '%s' failed: %s", run_id, step.id, exc, exc_info=True
            )
            if fail_fast:
                result.step_results.append(step_result)
                result.success = False
                result.errors.append(f"Step '{step.id}' failed: {exc}")
                break

        step_result.duration_seconds = time.monotonic() - step_start
        result.step_results.append(step_result)

        if not step_result.success:
            result.success = False
            result.errors.extend(step_result.errors)
            if fail_fast:
                break

    result.end_time = datetime.now(UTC)
    result.duration_seconds = time.monotonic() - pipeline_start

    logger.info(
        "[%s] Pipeline '%s' %s in %.2fs — extracted=%d, loaded=%d, failed=%d",
        run_id,
        pipeline_name,
        "completed" if result.success else "FAILED",
        result.duration_seconds,
        result.rows_extracted,
        result.rows_loaded,
        result.rows_failed,
    )
    return result


def _get_input(
    data_store: dict[str, list[dict[str, Any]]],
    step_id: str,
    consumer_id: str,
) -> list[dict[str, Any]]:
    """Retrieve upstream step output from the data store."""
    if step_id not in data_store:
        raise DAGError(
            f"Step '{consumer_id}' references step '{step_id}' whose output "
            "is not available. This indicates a topological sort error."
        )
    return data_store[step_id]
