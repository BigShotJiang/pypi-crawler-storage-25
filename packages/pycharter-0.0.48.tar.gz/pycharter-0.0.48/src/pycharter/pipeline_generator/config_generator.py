"""ETL Configuration Generator - Generate YAML configs from data contracts.

Re-exports core generation helpers from :mod:`_config_gen_core` and provides
higher-level convenience functions that build on top of them.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator._config_gen_core import (
    _camel_to_snake,
    _extract_field_definitions,
    _extract_primary_key,
    _extract_unique_constraints,
    _json_type_to_etl_type,
    generate_etl_config,
)

# Re-export everything so existing ``from config_generator import X`` works.
__all__ = [
    "_json_type_to_etl_type",
    "_camel_to_snake",
    "_extract_field_definitions",
    "_extract_primary_key",
    "_extract_unique_constraints",
    "generate_etl_config",
    "generate_etl_config_from_contract",
    "generate_etl_config_from_store",
]


def generate_etl_config_from_contract(
    contract: dict[str, Any],
    contract_name: str | None = None,
    extraction_config: dict[str, Any] | None = None,
    loading_config: dict[str, Any] | None = None,
    api_field_naming: str = "camelCase",
    db_field_naming: str = "snake_case",
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Generate ETL configuration from a complete data contract.

    This is a helper utility function for generating ETL config files.  For
    executing ETL pipelines, use the ETLOrchestrator class.

    Args:
        contract: Complete data contract dictionary.
        contract_name: Optional contract name (extracted from contract if not provided).
        extraction_config: Optional extraction configuration.
        loading_config: Optional loading configuration.
        api_field_naming: Naming convention for API fields.
        db_field_naming: Naming convention for DB fields.
        output_path: Optional path to write YAML file.

    Returns:
        ETL configuration dictionary.
    """
    # Extract schema
    schema = contract.get("schema", {})
    if not schema:
        raise ValueError("Contract must have a 'schema' field")

    # Extract contract name
    if contract_name is None:
        contract_name = schema.get("title") or schema.get("name") or "etl_pipeline"
        # Sanitize name
        contract_name = re.sub(r"[^a-zA-Z0-9_]", "_", contract_name).lower()

    # Extract metadata for extraction/loading config hints
    metadata = contract.get("metadata", {})

    # Try to extract extraction hints from metadata
    if extraction_config is None and metadata:
        # Look for source information in metadata
        source_info = metadata.get("source") or metadata.get("extraction")
        if source_info:
            if isinstance(source_info, dict):
                extraction_config = {
                    "provider_name": source_info.get("provider"),
                    "api_endpoint": source_info.get(
                        "endpoint", f"/api/v3/{contract_name}"
                    ),
                    "method": source_info.get("method", "GET"),
                    "params": source_info.get("params", {}),
                    "rate_limit_delay": source_info.get("rate_limit_delay", 0.2),
                    "batch_size": source_info.get("batch_size", 1000),
                }

    # Try to extract loading hints from metadata
    if loading_config is None and metadata:
        target_info = metadata.get("target") or metadata.get("loading")
        if target_info:
            if isinstance(target_info, dict):
                primary_key = _extract_primary_key(schema)
                loading_config = {
                    "target_table": target_info.get(
                        "table", _camel_to_snake(contract_name)
                    ),
                    "schema_name": target_info.get("schema"),
                    "write_method": target_info.get("write_method", "upsert"),
                    "primary_key": target_info.get("primary_key", primary_key),
                    "unique_constraints": target_info.get("unique_constraints", []),
                }

    return generate_etl_config(
        contract_name=contract_name,
        schema=schema,
        extraction_config=extraction_config,
        loading_config=loading_config,
        api_field_naming=api_field_naming,
        db_field_naming=db_field_naming,
        output_path=output_path,
    )


def generate_etl_config_from_store(
    contract_name: str,
    version: str | None = None,
    store: Any = None,  # ContractStoreClient
    extraction_config: dict[str, Any] | None = None,
    loading_config: dict[str, Any] | None = None,
    api_field_naming: str = "camelCase",
    db_field_naming: str = "snake_case",
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Generate ETL configuration from a contract stored in contract store.

    This is a helper utility function for generating ETL config files.  For
    executing ETL pipelines, use the ETLOrchestrator class.

    Args:
        contract_name: Name of the contract.
        version: Optional contract version (uses latest if not provided).
        store: ContractStoreClient instance.
        extraction_config: Optional extraction configuration.
        loading_config: Optional loading configuration.
        api_field_naming: Naming convention for API fields.
        db_field_naming: Naming convention for DB fields.
        output_path: Optional path to write YAML file.

    Returns:
        ETL configuration dictionary.
    """
    if store is None:
        raise ValueError("ContractStoreClient instance is required")

    # Retrieve contract from store
    if version:
        contract = store.get_contract(contract_name, version)
    else:
        # Resolve latest version
        contracts = [
            c for c in store.list_contracts() if c.get("name") == contract_name
        ]
        if not contracts:
            raise ValueError(f"Contract {contract_name!r} not found in store")
        from pycharter.utils.version import get_latest_version

        versions = [c.get("version") for c in contracts if c.get("version")]
        latest = get_latest_version(versions) or (versions[0] if versions else "1.0")
        contract = store.get_contract(contract_name, latest)

    if not contract:
        raise ValueError(f"Contract '{contract_name}' not found in store")

    return generate_etl_config_from_contract(
        contract=contract,
        contract_name=contract_name,
        extraction_config=extraction_config,
        loading_config=loading_config,
        api_field_naming=api_field_naming,
        db_field_naming=db_field_naming,
        output_path=output_path,
    )
