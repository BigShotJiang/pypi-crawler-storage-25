"""Pipeline testing framework for ETL pipelines.

Provides mock components, assertion helpers, fixture loading, and a test harness
for testing pipelines without real I/O.

This module re-exports from ``_testing_runner`` and ``_testing_fixtures``.

Usage:
    from pycharter.pipeline_generator.testing import (
        MockExtractor, MockLoader, PipelineTestHarness,
        assert_records_match, assert_record_count, load_fixture,
    )

    harness = PipelineTestHarness(pipeline, fixture_data=[{"id": 1}])
    result = await harness.run()
    assert_record_count(result, expected=1)
"""

from __future__ import annotations

from pycharter.pipeline_generator._testing_fixtures import (
    TestFixture,
    load_fixture,
    load_test_fixture,
    validate_pipeline_config,
)
from pycharter.pipeline_generator._testing_runner import (
    MockExtractor,
    MockLoader,
    PipelineTestHarness,
    assert_field_values,
    assert_fields_present,
    assert_no_field,
    assert_record_count,
    assert_records_match,
    assert_schema_shape,
)

__all__ = [
    "MockExtractor",
    "MockLoader",
    "PipelineTestHarness",
    "TestFixture",
    "assert_field_values",
    "assert_fields_present",
    "assert_no_field",
    "assert_record_count",
    "assert_records_match",
    "assert_schema_shape",
    "load_fixture",
    "load_test_fixture",
    "validate_pipeline_config",
]
