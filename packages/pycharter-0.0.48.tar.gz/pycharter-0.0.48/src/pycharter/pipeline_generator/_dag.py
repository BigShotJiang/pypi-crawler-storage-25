"""DAG resolution and validation for step-based pipelines.

Resolves a flat list of step configs into topological execution order
and validates structural constraints (no cycles, no dangling references,
type-specific rules).
"""

from __future__ import annotations

import logging
from collections import defaultdict

from pycharter.pipeline_generator.steps._base import (
    ExtractStepConfig,
    LoadStepConfig,
    StepConfig,
    StepType,
    input_step_ids,
)

logger = logging.getLogger(__name__)


class DAGError(Exception):
    """Raised when the step graph fails structural validation."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def resolve_dag(steps: list[StepConfig]) -> list[StepConfig]:
    """Sort steps into topological execution order and validate the DAG.

    Args:
        steps: Flat list of step configs (any order).

    Returns:
        Steps reordered so that every step appears after all of its
        dependencies.

    Raises:
        DAGError: If validation fails (cycles, missing refs, etc.).
    """
    validate_dag(steps)

    step_map = {s.id: s for s in steps}
    sorted_ids = _topological_sort(steps)

    logger.debug(
        "DAG resolved: %d steps in execution order %s",
        len(sorted_ids),
        sorted_ids,
    )
    return [step_map[sid] for sid in sorted_ids]


def validate_dag(steps: list[StepConfig]) -> None:
    """Validate structural constraints on a list of step configs.

    Checks performed:
    - No duplicate step IDs.
    - All input references resolve to existing step IDs.
    - No dependency cycles.
    - At least one extract step exists.
    - At least one load step exists.
    - Extract steps have no inputs (DAG roots).
    - Type-specific input count rules (load=1, join=2, union≥2).

    Args:
        steps: Flat list of step configs.

    Raises:
        DAGError: On the first validation failure encountered.
    """
    if not steps:
        raise DAGError("Pipeline must contain at least one step.")

    _check_duplicate_ids(steps)
    _check_references(steps)
    _check_cycles(steps)
    _check_step_type_rules(steps)


# ---------------------------------------------------------------------------
# Topological sort (Kahn's algorithm)
# ---------------------------------------------------------------------------


def _topological_sort(steps: list[StepConfig]) -> list[str]:
    """Return step IDs in topological (dependency-first) order.

    Uses Kahn's algorithm.  Assumes the graph has already been validated
    (no cycles, all references valid).

    Args:
        steps: Validated list of step configs.

    Returns:
        List of step IDs in execution order.
    """
    step_ids = {s.id for s in steps}

    # Build adjacency list and in-degree map.
    in_degree: dict[str, int] = dict.fromkeys(step_ids, 0)
    dependents: dict[str, list[str]] = defaultdict(list)

    for step in steps:
        for dep_id in input_step_ids(step):
            dependents[dep_id].append(step.id)
            in_degree[step.id] += 1

    # Seed the queue with root nodes (in-degree 0).
    queue: list[str] = sorted(sid for sid, deg in in_degree.items() if deg == 0)
    result: list[str] = []

    while queue:
        current = queue.pop(0)
        result.append(current)
        for child in sorted(dependents[current]):
            in_degree[child] -= 1
            if in_degree[child] == 0:
                queue.append(child)

    # Unreachable if validate_dag was called first, but guard anyway.
    if len(result) != len(step_ids):
        remaining = step_ids - set(result)
        raise DAGError(f"Cycle detected involving steps: {sorted(remaining)}")

    return result


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------


def _check_duplicate_ids(steps: list[StepConfig]) -> None:
    """Raise if any step IDs are duplicated."""
    seen: set[str] = set()
    for step in steps:
        if step.id in seen:
            raise DAGError(
                f"Duplicate step ID '{step.id}'; each step must have a "
                "unique identifier."
            )
        seen.add(step.id)


def _check_references(steps: list[StepConfig]) -> None:
    """Raise if any step references a non-existent step ID."""
    known_ids = {s.id for s in steps}
    for step in steps:
        for ref_id in input_step_ids(step):
            if ref_id not in known_ids:
                raise DAGError(f"Step '{step.id}' references unknown step '{ref_id}'.")


def _check_cycles(steps: list[StepConfig]) -> None:
    """Raise if the dependency graph contains a cycle.

    Uses DFS-based cycle detection with three-color marking.
    """
    adj: dict[str, list[str]] = defaultdict(list)
    for step in steps:
        for dep_id in input_step_ids(step):
            adj[dep_id].append(step.id)

    white = {s.id for s in steps}  # unvisited
    gray: set[str] = set()  # in current DFS path
    black: set[str] = set()  # fully processed

    def _dfs(node: str) -> str | None:
        white.discard(node)
        gray.add(node)
        for neighbour in adj[node]:
            if neighbour in gray:
                return neighbour
            if neighbour in white:
                cycle_node = _dfs(neighbour)
                if cycle_node is not None:
                    return cycle_node
        gray.discard(node)
        black.add(node)
        return None

    for sid in sorted(s.id for s in steps):
        if sid in white:
            cycle_node = _dfs(sid)
            if cycle_node is not None:
                raise DAGError(
                    f"Cycle detected in pipeline involving step '{cycle_node}'."
                )


def _check_step_type_rules(steps: list[StepConfig]) -> None:
    """Validate type-specific structural rules."""
    type_counts: dict[StepType, int] = defaultdict(int)
    for step in steps:
        type_counts[StepType(step.type)] += 1

    # Must have at least one extract and one load.
    if type_counts[StepType.EXTRACT] == 0:
        raise DAGError("Pipeline must contain at least one extract step (DAG root).")
    if type_counts[StepType.LOAD] == 0:
        raise DAGError("Pipeline must contain at least one load step (DAG sink).")

    # Type-specific input validation.
    for step in steps:
        deps = input_step_ids(step)

        if isinstance(step, ExtractStepConfig) and deps:
            raise DAGError(
                f"Extract step '{step.id}' must not have inputs; "
                "extract steps are DAG roots."
            )

        if isinstance(step, LoadStepConfig) and len(deps) != 1:
            raise DAGError(
                f"Load step '{step.id}' must have exactly one input, got {len(deps)}."
            )
