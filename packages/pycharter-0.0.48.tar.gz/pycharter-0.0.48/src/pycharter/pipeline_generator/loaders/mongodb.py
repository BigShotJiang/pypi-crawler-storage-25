"""MongoDB loader for ETL orchestrator.

Re-export shim -- the actual implementation lives in
``_mongodb_loader``.

All public names are re-exported here so that existing
``from pycharter.pipeline_generator.loaders.mongodb import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.pipeline_generator.loaders._mongodb_loader import (
    DEFAULT_MONGODB_PORT,
    MongoDBLoader,
    _convert_id_field,
    _modify_mongodb_url_for_tunnel,
)

__all__ = [
    "DEFAULT_MONGODB_PORT",
    "MongoDBLoader",
    "_convert_id_field",
    "_modify_mongodb_url_for_tunnel",
]
