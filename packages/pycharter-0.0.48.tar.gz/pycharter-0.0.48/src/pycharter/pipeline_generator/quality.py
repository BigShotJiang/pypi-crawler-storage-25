"""Post-load quality checks for ETL pipelines.

Validates loaded data against configurable quality rules including
row count, null rate, uniqueness, and custom expressions.

This module re-exports from ``_quality_metrics`` and ``_quality_checks``.

Usage:
    checker = QualityChecker([
        {"type": "row_count", "min": 100, "severity": "fail"},
        {"type": "null_rate", "fields": ["id"], "max_null_percent": 0},
    ])
    report = checker.run(loaded_records, load_result)
    if not report.passed:
        for failure in report.failures:
            print(failure.message)
"""

from __future__ import annotations

from pycharter.pipeline_generator._quality_checks import (
    check_expression,
    check_null_rate,
    check_row_count,
    check_uniqueness,
)
from pycharter.pipeline_generator._quality_metrics import (
    PostLoadChecker,
    QualityChecker,
    QualityCheckResult,
    QualityCheckSeverity,
    QualityCheckStatus,
    QualityReport,
    create_quality_checker,
)

__all__ = [
    "PostLoadChecker",
    "QualityChecker",
    "QualityCheckResult",
    "QualityCheckSeverity",
    "QualityCheckStatus",
    "QualityReport",
    "check_expression",
    "check_null_rate",
    "check_row_count",
    "check_uniqueness",
    "create_quality_checker",
]
