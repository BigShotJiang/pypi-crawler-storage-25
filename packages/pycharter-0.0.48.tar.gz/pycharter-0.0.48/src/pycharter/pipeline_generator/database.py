"""Database connection and loading utilities for ETL orchestrator.

This module re-exports all symbols from ``database_connection`` and
``database_operations`` for backward compatibility. New code should import
directly from the submodules.
"""

from __future__ import annotations

from pycharter.pipeline_generator.database_connection import (
    DB_MONGODB,
    DB_MSSQL,
    DB_MYSQL,
    DB_ORACLE,
    DB_POSTGRESQL,
    DB_SQLITE,
    DEFAULT_MYSQL_PORT,
    DEFAULT_POSTGRES_PORT,
    DEFAULT_SSH_PORT,
    DEFAULT_TUNNEL_LOCAL_PORT,
    SSH_TUNNEL_AVAILABLE,
    create_ssh_tunnel,
    detect_database_type,
    get_database_connection,
    modify_url_for_tunnel,
)
from pycharter.pipeline_generator.database_operations import (
    LOAD_FUNCTIONS,
    build_column_list,
    build_placeholder_list,
    build_table_name,
    load_data,
    load_data_generic,
    load_data_mssql,
    load_data_mysql,
    load_data_postgresql,
    load_data_raw_sql,
    load_data_sqlite,
    process_batch_for_db,
    process_record_for_db,
)

__all__ = [
    # Connection constants
    "DB_MONGODB",
    "DB_MSSQL",
    "DB_MYSQL",
    "DB_ORACLE",
    "DB_POSTGRESQL",
    "DB_SQLITE",
    "DEFAULT_MYSQL_PORT",
    "DEFAULT_POSTGRES_PORT",
    "DEFAULT_SSH_PORT",
    "DEFAULT_TUNNEL_LOCAL_PORT",
    "SSH_TUNNEL_AVAILABLE",
    # Connection functions
    "create_ssh_tunnel",
    "detect_database_type",
    "get_database_connection",
    "modify_url_for_tunnel",
    # Operations: SQL building
    "build_column_list",
    "build_placeholder_list",
    "build_table_name",
    # Operations: record processing
    "process_batch_for_db",
    "process_record_for_db",
    # Operations: load functions
    "LOAD_FUNCTIONS",
    "load_data",
    "load_data_generic",
    "load_data_mssql",
    "load_data_mysql",
    "load_data_postgresql",
    "load_data_raw_sql",
    "load_data_sqlite",
]
