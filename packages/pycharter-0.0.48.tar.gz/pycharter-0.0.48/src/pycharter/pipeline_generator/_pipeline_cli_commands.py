"""CLI command implementations for ``pycharter etl list`` and ``pycharter etl inspect``.

Extracted from :mod:`etl_cli` to keep module sizes under 400 lines.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import yaml

# =========================================================================
# pycharter etl list
# =========================================================================


def cmd_etl_list(path: str = ".") -> int:
    """List pipeline config directories discovered under *path*.

    A directory is considered a pipeline if it contains either
    ``pipeline.yaml`` or ``extract.yaml`` + ``load.yaml``.

    Args:
        path: Root directory to scan.

    Returns:
        Exit code (0 on success, 1 on failure).
    """
    target = Path(path).resolve()
    if not target.is_dir():
        print(f"Not a directory: {path}", file=sys.stderr)
        return 1

    found: list[tuple[str, str]] = []

    def _is_pipeline_dir(d: Path) -> bool:
        if (d / "pipeline.yaml").exists() or (d / "pipeline.yml").exists():
            return True
        return ((d / "extract.yaml").exists() or (d / "extract.yml").exists()) and (
            (d / "load.yaml").exists() or (d / "load.yml").exists()
        )

    if _is_pipeline_dir(target):
        found.append((target.name, str(target)))

    for child in sorted(target.rglob("*")):
        if child.is_dir() and _is_pipeline_dir(child):
            found.append((child.name, str(child)))

    if not found:
        print("No pipelines found.")
        return 0

    print(f"{'Name':<30} {'Path'}")
    print("-" * 70)
    for name, pdir in found:
        print(f"{name:<30} {pdir}")

    print(f"\n{len(found)} pipeline(s) found.")
    return 0


# =========================================================================
# pycharter etl inspect
# =========================================================================


def cmd_etl_inspect(path: str) -> int:
    """Show parsed config summary for a pipeline.

    Args:
        path: Pipeline directory or config file.

    Returns:
        Exit code (0 on success, 1 on failure).
    """
    target = Path(path)

    try:
        config = _load_inspect_config(target)
    except Exception as exc:
        print(f"Error loading config: {exc}", file=sys.stderr)
        return 1

    _print_inspect_summary(config, target)
    return 0


def _load_inspect_config(target: Path) -> dict[str, Any]:
    """Load configs from a pipeline path into a summary dict."""
    config: dict[str, Any] = {}

    if target.is_dir():
        config["name"] = target.name
        for fname in ("extract.yaml", "transform.yaml", "load.yaml", "settings.yaml"):
            fpath = target / fname
            if fpath.exists():
                with open(fpath) as f:
                    config[fname.replace(".yaml", "")] = yaml.safe_load(f) or {}
    elif target.is_file():
        with open(target) as f:
            raw = yaml.safe_load(f) or {}
        config["name"] = raw.get("name", target.stem)
        config["extract"] = raw.get("extract", {})
        config["transform"] = raw.get("transform")
        config["load"] = raw.get("load", {})
        config["settings"] = {
            k: v
            for k, v in raw.items()
            if k not in ("name", "extract", "transform", "load", "variables")
        }
    else:
        raise FileNotFoundError(f"Path not found: {target}")

    return config


def _print_inspect_summary(config: dict[str, Any], target: Path) -> None:
    """Print a human-readable pipeline config summary."""
    print(f"Pipeline: {config.get('name', 'unnamed')}")
    print(f"Path:     {target.resolve()}")
    print()

    # Extract
    extract = config.get("extract", {})
    if extract:
        print("Extract:")
        print(f"  Type: {extract.get('type', 'unknown')}")
        if extract.get("url"):
            print(f"  URL:  {extract['url']}")
        if extract.get("query"):
            query = extract["query"].strip()
            if len(query) > 80:
                query = query[:77] + "..."
            print(f"  Query: {query}")
        if extract.get("path"):
            print(f"  Path: {extract['path']}")
        inc = extract.get("incremental")
        if inc:
            print(
                f"  Incremental: field={inc.get('watermark_field')}, "
                f"initial={inc.get('initial_value', 'none')}"
            )
        print()

    # Transform
    _print_transform_section(config.get("transform"))

    # Load
    load = config.get("load", {})
    if load:
        print("Load:")
        print(f"  Type:  {load.get('type', 'unknown')}")
        if load.get("table"):
            print(f"  Table: {load['table']}")
        if load.get("path"):
            print(f"  Path:  {load['path']}")
        if load.get("write_method"):
            print(f"  Write: {load['write_method']}")
        print()

    # Settings
    _print_settings_section(config.get("settings", {}))


def _print_transform_section(transform: Any) -> None:
    """Print the transform section of an inspect summary."""
    if not transform:
        return

    print("Transform:")
    if isinstance(transform, list):
        for op in transform:
            if isinstance(op, dict):
                print(f"  - {', '.join(op.keys())}")
            else:
                print(f"  - {op}")
    elif isinstance(transform, dict):
        inner = transform.get("transform", transform)
        if isinstance(inner, dict):
            for key in inner:
                print(f"  - {key}")
        elif isinstance(inner, list):
            for op in inner:
                if isinstance(op, dict):
                    print(f"  - {', '.join(op.keys())}")
    print()


def _print_settings_section(settings: dict[str, Any]) -> None:
    """Print the settings section of an inspect summary."""
    if not settings:
        return

    print("Settings:")
    if settings.get("state_store"):
        ss = settings["state_store"]
        print(
            f"  State Store: backend={ss.get('backend', 'file')}, "
            f"path={ss.get('path', './.state')}"
        )
    if settings.get("dlq"):
        dlq_cfg = settings["dlq"]
        print(
            f"  DLQ: backend={dlq_cfg.get('backend', 'file')}, "
            f"enabled={dlq_cfg.get('enabled', True)}"
        )
    if settings.get("plugins"):
        plugins = settings["plugins"]
        ext_count = len(plugins.get("extractors") or {})
        ldr_count = len(plugins.get("loaders") or {})
        print(f"  Plugins: {ext_count} extractor(s), {ldr_count} loader(s)")
