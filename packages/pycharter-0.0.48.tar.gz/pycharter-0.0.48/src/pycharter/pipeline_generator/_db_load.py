"""Async data loading for PostgreSQL and the top-level load dispatcher.

This module provides the async PostgreSQL load function, the
``LOAD_FUNCTIONS`` registry mapping database types to their load
functions, and the ``load_data`` async entry-point used by the ETL
orchestrator.  Synchronous loaders live in ``_db_load_sync`` (MySQL,
SQLite) and ``_db_load_fallback`` (MSSQL, generic, raw SQL).
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from pycharter.pipeline_generator._db_load_fallback import (
    load_data_generic,
    load_data_mssql,
    load_data_raw_sql,
)
from pycharter.pipeline_generator._db_load_sync import (
    load_data_mysql,
    load_data_sqlite,
)
from pycharter.pipeline_generator._db_query import (
    _build_bulk_upsert_sql_and_params,
    _short_error,
    build_table_name,
    process_batch_for_db,
    process_record_for_db,
)
from pycharter.pipeline_generator.database_connection import (
    DB_MSSQL,
    DB_MYSQL,
    DB_POSTGRESQL,
    DB_SQLITE,
)

logger = logging.getLogger(__name__)

# Re-export sync loaders so ``_db_load`` remains the single import source
# for ``database_operations.py``.
__all__ = [
    "LOAD_FUNCTIONS",
    "load_data",
    "load_data_generic",
    "load_data_mssql",
    "load_data_mysql",
    "load_data_postgresql",
    "load_data_raw_sql",
    "load_data_sqlite",
]


# ============================================================================
# PostgreSQL (async)
# ============================================================================


async def load_data_postgresql(
    data: list[dict[str, Any]],
    session: AsyncSession,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | list[str] | None,
    batch_size: int,
    update_columns: list[str] | None = None,
) -> dict[str, Any]:
    """Load data into PostgreSQL using database-specific optimizations (async).

    Uses bulk operations for upserts to minimize database round trips.
    """
    if not isinstance(session, AsyncSession):
        raise ValueError("load_data_postgresql requires an AsyncSession")

    full_table_name = build_table_name(schema_name, table_name, DB_POSTGRESQL)
    inserted = 0
    updated = 0

    if not data:
        return {"inserted": 0, "updated": 0, "total": 0}

    columns = list(data[0].keys())

    # Normalize primary_key to list
    if primary_key:
        if isinstance(primary_key, str):
            primary_key_list = [primary_key]
        else:
            primary_key_list = primary_key
    else:
        primary_key_list = []

    # Add UUID 'id' when data doesn't provide it so new rows have a PK.
    needs_id = "id" not in columns
    if needs_id:
        columns.append("id")

    # Ensure update_columns that are missing from data get a value
    if update_columns:
        for col in update_columns:
            if col not in columns:
                columns.append(col)

    columns_str = ", ".join([f'"{col}"' for col in columns])
    values_placeholders = ", ".join([f":{col}" for col in columns])

    # Handle truncate_and_load first (before processing data)
    if write_method == "truncate_and_load":
        await session.execute(text(f"TRUNCATE TABLE {full_table_name}"))
        await session.commit()
        write_method = "insert"

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method == "upsert" and primary_key_list:
            inserted += await _pg_upsert_batch(
                session,
                full_table_name,
                columns,
                primary_key_list,
                batch,
                needs_id,
                update_columns,
            )
        elif write_method in ("insert", "append"):
            for record in batch:
                processed_record = process_record_for_db(record, needs_id=needs_id)
                sql = f"""
                    INSERT INTO {full_table_name} ({columns_str})
                    VALUES ({values_placeholders})
                """
                await session.execute(text(sql), processed_record)
            inserted += len(batch)
        elif write_method == "replace":
            for record in batch:
                if primary_key and primary_key in record:
                    await session.execute(
                        text(
                            f'DELETE FROM {full_table_name} WHERE "{primary_key}" = :pk'
                        ),
                        {"pk": record[primary_key]},
                    )
                sql = f"""
                    INSERT INTO {full_table_name} ({columns_str})
                    VALUES ({values_placeholders})
                """
                await session.execute(text(sql), record)
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                set_clause = ", ".join(
                    [f'"{k}" = :{k}' for k in columns if k != primary_key]
                )
                sql = f"""
                    UPDATE {full_table_name}
                    SET {set_clause}
                    WHERE "{primary_key}" = :{primary_key}
                """
                await session.execute(text(sql), record)
                updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                sql = f'DELETE FROM {full_table_name} WHERE "{primary_key}" = :pk'
                await session.execute(text(sql), {"pk": record[primary_key]})
                updated += 1

        await session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}


async def _pg_upsert_batch(
    session: AsyncSession,
    full_table_name: str,
    columns: list[str],
    primary_key_list: list[str],
    batch: list[dict[str, Any]],
    needs_id: bool,
    update_columns: list[str] | None,
) -> int:
    """Execute a PostgreSQL bulk upsert for a single batch.

    Returns:
        Number of records processed.
    """
    processed_batch = process_batch_for_db(batch, needs_id=needs_id)

    # Fill in missing update_columns values (e.g. updated_at = now())
    if update_columns:
        for record in processed_batch:
            for col in update_columns:
                if record.get(col) is None and col == "updated_at":
                    record[col] = datetime.now(UTC)

    # Calculate max safe chunk size to stay below database parameter limits.
    # Conservative limit: 30,000 (below PostgreSQL's 32,767 limit).
    max_params = 30000
    num_columns = len(columns)
    max_per_chunk = max(1, max_params // num_columns if num_columns > 0 else 1000)

    count = 0
    for chunk_start in range(0, len(processed_batch), max_per_chunk):
        chunk = processed_batch[chunk_start : chunk_start + max_per_chunk]
        if not chunk:
            continue

        sql, params = _build_bulk_upsert_sql_and_params(
            full_table_name,
            columns,
            primary_key_list,
            chunk,
            update_columns=update_columns,
        )

        try:
            await session.execute(text(sql), params)
            count += len(chunk)
        except Exception as exc:
            extra: dict[str, Any] = {
                "table": full_table_name,
                "batch_size": len(chunk),
                "total_batch_size": len(processed_batch),
                "chunk_start": chunk_start,
                "max_records_per_chunk": max_per_chunk,
                "num_columns": num_columns,
                "primary_key": primary_key_list,
            }
            if hasattr(exc, "orig"):
                extra["pgcode"] = getattr(exc.orig, "pgcode", None)
                pgerror = getattr(exc.orig, "pgerror", None)
                extra["pgerror"] = (
                    _short_error(Exception(str(pgerror))) if pgerror else None
                )
            logger.error(
                "Database bulk upsert failed: %s",
                _short_error(exc),
                extra=extra,
                exc_info=False,
            )
            raise

    return count


# ============================================================================
# Load Function Registry & Async Dispatcher
# ============================================================================

# Database-specific load function mapping
LOAD_FUNCTIONS = {
    DB_POSTGRESQL: load_data_postgresql,
    DB_MYSQL: load_data_mysql,
    DB_SQLITE: load_data_sqlite,
    DB_MSSQL: load_data_mssql,
}


async def load_data(
    data: list[dict[str, Any]],
    session: Any,  # AsyncSession or Session
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
    db_type: str,
) -> dict[str, Any]:
    """Load data using database-specific methods (async).

    Args:
        data: Data to load.
        session: Database session (AsyncSession for async, Session for sync).
        schema_name: Database schema name.
        table_name: Target table name.
        write_method: Write method (insert, upsert, replace, merge).
        primary_key: Primary key column name.
        batch_size: Batch size for loading.
        db_type: Database type (postgresql, mysql, sqlite, mssql).

    Returns:
        Loading statistics dictionary.
    """
    from sqlalchemy.ext.asyncio import AsyncSession as _AsyncSession

    if db_type == DB_POSTGRESQL:
        if isinstance(session, _AsyncSession):
            return await load_data_postgresql(
                data,
                session,
                schema_name,
                table_name,
                write_method,
                primary_key,
                batch_size,
            )
        raise ValueError(
            "PostgreSQL load requires AsyncSession. "
            "Use sync load functions for sync sessions."
        )

    raise NotImplementedError(
        f"Async load not yet implemented for {db_type}. Only PostgreSQL is supported."
    )
