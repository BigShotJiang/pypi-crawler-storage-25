"""ETL Validation Module.

Provides validation for ETL pipelines:
- ETLValidator: Validates data against schemas/contracts with DLQ support
- resolve_contract: Resolves contract references (file or database)
- resolve_schema: Resolves schema file paths

This module re-exports from ``_validation_core`` and ``_validation_rules``.
"""

from __future__ import annotations

from pycharter.pipeline_generator._validation_core import (
    ETLValidationError,
    ETLValidator,
)
from pycharter.pipeline_generator._validation_rules import (
    create_dlq,
    create_etl_validator,
    resolve_contract,
    resolve_schema,
)

__all__ = [
    "ETLValidationError",
    "ETLValidator",
    "create_dlq",
    "create_etl_validator",
    "resolve_contract",
    "resolve_schema",
]
