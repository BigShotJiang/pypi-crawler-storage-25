"""Pydantic models for ETL pipeline configuration.

Central module that defines (or re-exports) every Pydantic config model
used by the pipeline system: extract, transform, load, settings, and
shared building blocks. Also re-exports :class:`PipelineConfig` (dataclass)
for backward compatibility with ``pipeline_generator.schemas``.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

# Parsed pipeline envelope (dataclass; lives in _config with parse/load helpers)
from pycharter.pipeline_generator._config import PipelineConfig  # noqa: F401

# Enums
from pycharter.pipeline_generator._config_enums import (  # noqa: F401
    CloudProvider,
    ContractStoreType,
    ConvertType,
    DLQBackend,
    ExtractType,
    FileFormat,
    FilterOperator,
    HTTPMethod,
    JSONataMode,
    LoadType,
    OnErrorAction,
    PaginationStrategy,
    ResponseFormat,
    WriteMethod,
    WriteMode,
)

# Extract configs
from pycharter.pipeline_generator._config_extract import (  # noqa: F401
    CloudStorageExtractConfig,
    DatabaseExtractConfig,
    ExtractConfig,
    FileExtractConfig,
    FileWatcherExtractConfig,
    HTTPExtractConfig,
    InputParamConfig,
    KafkaExtractConfig,
    PaginationConfig,
    RabbitMQExtractConfig,
    RetryConfig,
    SQSExtractConfig,
    SSEExtractConfig,
    TimeoutConfig,
    WebSocketExtractConfig,
)

# Settings
from pycharter.pipeline_generator._config_settings import (  # noqa: F401
    LineageConfig,
    PluginConfig,
    SettingsConfig,
    StateStoreConfig,
)

# Shared config models
from pycharter.pipeline_generator._config_shared import (  # noqa: F401
    CloudStorageConfig,
    ContractRef,
    ContractStoreConfig,
    CSVOptions,
    DatabaseConfig,
    DLQConfig,
    ExtractValidationConfig,
    IncrementalConfig,
    JSONOptions,
    LoadValidationConfig,
    SSHTunnelConfig,
)

# =============================================================================
# LOAD CONFIGS
# =============================================================================


class PostgresLoadConfig(BaseModel):
    """PostgreSQL load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["postgres", "postgresql", "database"]
    table: str
    schema_name: str | None = "public"
    write_method: WriteMethod = WriteMethod.INSERT
    primary_key: str | list[str] | None = None
    update_columns: list[str] | None = None
    connection_string: str | None = None
    database: DatabaseConfig | None = None
    ssh_tunnel: SSHTunnelConfig | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class SQLiteLoadConfig(BaseModel):
    """SQLite load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["sqlite"] = "sqlite"
    table: str
    path: str
    write_method: WriteMethod = WriteMethod.INSERT
    primary_key: str | list[str] | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class FileLoadConfig(BaseModel):
    """File load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["file"] = "file"
    path: str
    format: FileFormat = FileFormat.JSON
    write_mode: WriteMode = WriteMode.OVERWRITE
    csv_options: CSVOptions | None = None
    json_options: JSONOptions | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class CloudStorageLoadConfig(BaseModel):
    """Cloud storage load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["cloud_storage"] = "cloud_storage"
    storage: CloudStorageConfig
    format: FileFormat = FileFormat.JSON
    write_mode: WriteMode = WriteMode.OVERWRITE
    partition_by: list[str] | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


LoadConfig = (
    PostgresLoadConfig | SQLiteLoadConfig | FileLoadConfig | CloudStorageLoadConfig
)

# =============================================================================
# TRANSFORM CONFIGS
# =============================================================================


class FilterConfig(BaseModel):
    """Filter operation configuration."""

    model_config = ConfigDict(extra="forbid")

    expression: str | None = None
    field: str | None = None
    operator: FilterOperator | None = None
    value: Any | None = None


class MapConfig(BaseModel):
    """Map (lookup) operation configuration."""

    model_config = ConfigDict(extra="forbid")

    field: str
    mapping: dict[str, Any] | None
    default: Any | None = None


class JSONataConfig(BaseModel):
    """JSONata transformation configuration."""

    model_config = ConfigDict(extra="forbid")

    expression: str
    mode: JSONataMode = JSONataMode.RECORD


class CustomFunctionConfig(BaseModel):
    """Custom Python function configuration."""

    model_config = ConfigDict(extra="forbid")

    module: str
    function: str
    kwargs: dict[str, Any] | None = None
    mode: JSONataMode = JSONataMode.BATCH


class SimpleOpsConfig(BaseModel):
    """Simple transform operations (object format)."""

    model_config = ConfigDict(extra="forbid")

    rename: dict[str, str] | None = None
    convert: dict[str, ConvertType] | None = None
    defaults: dict[str, Any] | None = None
    add: dict[str, Any] | None = None
    select: list[str] | None = None
    drop: list[str] | None = None
    filter: FilterConfig | None = None


class TransformConfig(BaseModel):
    """Transform configuration (simple ops, JSONata, custom function)."""

    model_config = ConfigDict(extra="forbid")

    transform: SimpleOpsConfig | list[dict[str, Any]] | None = None
    jsonata: JSONataConfig | None = None
    custom_function: CustomFunctionConfig | None = None


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def parse_extract_config(config: dict[str, Any]) -> ExtractConfig:
    """Parse extract config dict into typed model based on 'type' field."""
    extract_type = config.get("type", "").lower()

    type_map: dict[str, type[ExtractConfig]] = {
        "http": HTTPExtractConfig,
        "file": FileExtractConfig,
        "database": DatabaseExtractConfig,
        "cloud_storage": CloudStorageExtractConfig,
        "sse": SSEExtractConfig,
        "websocket": WebSocketExtractConfig,
        "file_watcher": FileWatcherExtractConfig,
        "kafka": KafkaExtractConfig,
        "rabbitmq": RabbitMQExtractConfig,
        "sqs": SQSExtractConfig,
    }

    cls = type_map.get(extract_type)
    if cls is None:
        raise ValueError(
            f"Unknown extract type: '{extract_type}'. "
            f"Supported types: {', '.join(sorted(type_map))}"
        )
    return cls(**config)


def parse_load_config(config: dict[str, Any]) -> LoadConfig:
    """Parse load config dict into typed model based on 'type' field."""
    load_type = config.get("type", "").lower()

    type_map: dict[str, type] = {
        "postgres": PostgresLoadConfig,
        "postgresql": PostgresLoadConfig,
        "database": PostgresLoadConfig,
        "sqlite": SQLiteLoadConfig,
        "file": FileLoadConfig,
        "cloud_storage": CloudStorageLoadConfig,
    }

    cls = type_map.get(load_type)
    if cls is None:
        raise ValueError(
            f"Unknown load type: '{load_type}'. "
            f"Supported types: {', '.join(sorted(type_map))}"
        )
    return cls(**config)


def parse_transform_config(
    config: dict[str, Any] | list[dict[str, Any]] | None,
) -> TransformConfig | None:
    """Parse transform config into typed model."""
    if config is None:
        return None
    if isinstance(config, list):
        return TransformConfig(transform=config)
    return TransformConfig(**config)


def parse_settings_config(config: dict[str, Any]) -> SettingsConfig:
    """Parse settings config into typed model."""
    return SettingsConfig(**config)


__all__ = [
    # Enums
    "ExtractType",
    "LoadType",
    "CloudProvider",
    "WriteMethod",
    "FileFormat",
    "WriteMode",
    "OnErrorAction",
    "DLQBackend",
    "ContractStoreType",
    "FilterOperator",
    "PaginationStrategy",
    "HTTPMethod",
    "ResponseFormat",
    "ConvertType",
    "JSONataMode",
    # Shared config models
    "SSHTunnelConfig",
    "DatabaseConfig",
    "CSVOptions",
    "JSONOptions",
    "CloudStorageConfig",
    "DLQConfig",
    "ContractRef",
    "ContractStoreConfig",
    "ExtractValidationConfig",
    "LoadValidationConfig",
    "IncrementalConfig",
    # Settings models
    "LineageConfig",
    "PluginConfig",
    "StateStoreConfig",
    "SettingsConfig",
    "PipelineConfig",
    # Extract configs
    "PaginationConfig",
    "RetryConfig",
    "TimeoutConfig",
    "InputParamConfig",
    "HTTPExtractConfig",
    "FileExtractConfig",
    "DatabaseExtractConfig",
    "CloudStorageExtractConfig",
    "SSEExtractConfig",
    "WebSocketExtractConfig",
    "FileWatcherExtractConfig",
    "KafkaExtractConfig",
    "RabbitMQExtractConfig",
    "SQSExtractConfig",
    "ExtractConfig",
    # Load configs
    "PostgresLoadConfig",
    "SQLiteLoadConfig",
    "FileLoadConfig",
    "CloudStorageLoadConfig",
    "LoadConfig",
    # Transform configs
    "FilterConfig",
    "MapConfig",
    "JSONataConfig",
    "CustomFunctionConfig",
    "SimpleOpsConfig",
    "TransformConfig",
    # Helper functions
    "parse_extract_config",
    "parse_load_config",
    "parse_transform_config",
    "parse_settings_config",
]
