"""Union step — concatenates records from multiple input steps."""

from __future__ import annotations

import logging
import time
from typing import Any

from pycharter.pipeline_generator.steps._base import UnionStepConfig

logger = logging.getLogger(__name__)


def run_union(
    config: UnionStepConfig,
    datasets: list[list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Execute a union step.

    Concatenates records from all input datasets.  If ``tag_field`` is
    set, injects the originating step ID into each record.

    Args:
        config: Union step configuration.
        datasets: List of record lists, one per input step (same order
            as ``config.inputs``).

    Returns:
        Concatenated records.
    """
    start = time.monotonic()
    result: list[dict[str, Any]] = []

    for step_id, data in zip(config.inputs, datasets, strict=True):
        if config.tag_field:
            for record in data:
                tagged = {**record, config.tag_field: step_id}
                result.append(tagged)
        else:
            result.extend(data)

    elapsed = time.monotonic() - start
    input_counts = [len(d) for d in datasets]
    logger.info(
        "Union step '%s': %s → %d records in %.2fs",
        config.id,
        input_counts,
        len(result),
        elapsed,
    )
    return result
