"""Step configuration models for DAG-based pipelines.

Defines the Pydantic config models for each step type (extract, transform,
join, union, load) and the discriminated union that parses raw dicts into
the correct typed config.
"""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, model_validator

# Step IDs must be lowercase alphanumeric with hyphens/underscores.
_STEP_ID_PATTERN = re.compile(r"^[a-z][a-z0-9_-]*$")


class StepType(StrEnum):
    """Pipeline step types."""

    EXTRACT = "extract"
    TRANSFORM = "transform"
    JOIN = "join"
    UNION = "union"
    LOAD = "load"


# ---------------------------------------------------------------------------
# Shared sub-models
# ---------------------------------------------------------------------------


class JoinOn(BaseModel):
    """Join key specification."""

    left_key: str | list[str] = Field(
        ..., description="Field name(s) from the left dataset."
    )
    right_key: str | list[str] = Field(
        ..., description="Field name(s) from the right dataset."
    )

    model_config = {"frozen": True}

    @model_validator(mode="after")
    def _keys_same_length(self) -> JoinOn:
        left = [self.left_key] if isinstance(self.left_key, str) else self.left_key
        right = [self.right_key] if isinstance(self.right_key, str) else self.right_key
        if len(left) != len(right):
            msg = (
                f"left_key has {len(left)} fields but right_key has {len(right)}; "
                "composite join keys must have the same number of fields"
            )
            raise ValueError(msg)
        return self


class JoinHow(StrEnum):
    """Join strategies."""

    INNER = "inner"
    LEFT = "left"
    RIGHT = "right"
    OUTER = "outer"


class JoinPrefix(BaseModel):
    """Field-name prefix for conflict resolution in joins."""

    left: str = Field("", description="Prefix for left-side fields on conflict.")
    right: str = Field("", description="Prefix for right-side fields on conflict.")

    model_config = {"frozen": True}


# ---------------------------------------------------------------------------
# Step config models
# ---------------------------------------------------------------------------


class _StepConfigBase(BaseModel):
    """Shared fields for all step configs."""

    id: str = Field(
        ..., description="Unique identifier for this step within the pipeline."
    )

    model_config = {"frozen": True}

    @model_validator(mode="after")
    def _validate_id(self) -> _StepConfigBase:
        if not _STEP_ID_PATTERN.match(self.id):
            msg = (
                f"Step id '{self.id}' is invalid; must start with a lowercase letter "
                "and contain only lowercase alphanumeric characters, hyphens, or "
                "underscores."
            )
            raise ValueError(msg)
        return self


class ExtractStepConfig(_StepConfigBase):
    """Configuration for an extract step.

    Extract steps are DAG roots that pull data from an external source.
    The ``source`` dict is passed directly to the extractor factory.
    """

    type: Literal[StepType.EXTRACT] = StepType.EXTRACT
    source: dict[str, Any] = Field(
        ..., description="Source configuration (type, url, query, etc.)."
    )


class TransformStepConfig(_StepConfigBase):
    """Configuration for a transform step.

    Applies a three-stage transformation pipeline: simple operations,
    then JSONata, then a custom Python function.  All three stages are
    optional but at least one must be provided.
    """

    type: Literal[StepType.TRANSFORM] = StepType.TRANSFORM
    input: str = Field(..., description="Step ID to read data from.")
    operations: dict[str, Any] | None = Field(
        None, description="Simple operations (rename, convert, filter, etc.)."
    )
    jsonata: dict[str, Any] | None = Field(
        None, description="JSONata expression config (mode + expression)."
    )
    custom_function: dict[str, Any] | None = Field(
        None, description="Custom Python function config."
    )

    @model_validator(mode="after")
    def _at_least_one_stage(self) -> TransformStepConfig:
        if not any([self.operations, self.jsonata, self.custom_function]):
            msg = (
                f"Transform step '{self.id}' must define at least one of: "
                "operations, jsonata, or custom_function."
            )
            raise ValueError(msg)
        return self


class JoinStepConfig(_StepConfigBase):
    """Configuration for a join step.

    Combines records from two input steps using a hash-join on the
    specified keys.
    """

    type: Literal[StepType.JOIN] = StepType.JOIN
    left: str = Field(..., description="Step ID for the left dataset.")
    right: str = Field(..., description="Step ID for the right dataset.")
    on: JoinOn = Field(..., description="Join key mapping.")
    how: JoinHow = Field(JoinHow.INNER, description="Join strategy.")
    prefix: JoinPrefix | None = Field(
        None, description="Field-name prefix for conflict resolution."
    )


class UnionStepConfig(_StepConfigBase):
    """Configuration for a union step.

    Concatenates records from two or more input steps.
    """

    type: Literal[StepType.UNION] = StepType.UNION
    inputs: list[str] = Field(..., min_length=2, description="Step IDs to concatenate.")
    tag_field: str | None = Field(
        None,
        description="If set, adds a field with the originating step ID.",
    )


class LoadStepConfig(_StepConfigBase):
    """Configuration for a load step.

    Load steps are DAG sinks that write data to a destination.  The
    ``target`` dict is passed directly to the loader factory.
    """

    type: Literal[StepType.LOAD] = StepType.LOAD
    input: str = Field(..., description="Step ID to read data from.")
    target: dict[str, Any] = Field(
        ..., description="Target configuration (type, table, path, etc.)."
    )
    validation: dict[str, Any] | None = Field(
        None, description="Validation rules applied before loading."
    )
    quality_checks: list[dict[str, Any]] | None = Field(
        None, description="Post-load quality checks."
    )


# Discriminated union of all step configs.
StepConfig = Annotated[
    ExtractStepConfig
    | TransformStepConfig
    | JoinStepConfig
    | UnionStepConfig
    | LoadStepConfig,
    Field(discriminator="type"),
]


def parse_step_config(raw: dict[str, Any]) -> StepConfig:
    """Parse a raw dictionary into a typed StepConfig.

    Args:
        raw: Dictionary with at least ``id`` and ``type`` keys.

    Returns:
        A typed step config (extract, transform, join, union, or load).

    Raises:
        ValueError: If the step type is unknown or validation fails.
    """
    step_type = raw.get("type")
    if step_type is None:
        msg = f"Step is missing required 'type' field: {raw}"
        raise ValueError(msg)

    _type_to_model: dict[str, type[_StepConfigBase]] = {
        StepType.EXTRACT: ExtractStepConfig,
        StepType.TRANSFORM: TransformStepConfig,
        StepType.JOIN: JoinStepConfig,
        StepType.UNION: UnionStepConfig,
        StepType.LOAD: LoadStepConfig,
    }

    model_cls = _type_to_model.get(step_type)
    if model_cls is None:
        msg = f"Unknown step type '{step_type}' in step '{raw.get('id', '?')}'"
        raise ValueError(msg)

    return model_cls.model_validate(raw)


def input_step_ids(step: StepConfig) -> list[str]:
    """Return the step IDs that a given step depends on.

    Args:
        step: A typed step config.

    Returns:
        List of upstream step IDs (empty for extract steps).
    """
    if isinstance(step, ExtractStepConfig):
        return []
    if isinstance(step, TransformStepConfig | LoadStepConfig):
        return [step.input]
    if isinstance(step, JoinStepConfig):
        return [step.left, step.right]
    if isinstance(step, UnionStepConfig):
        return list(step.inputs)
    return []
