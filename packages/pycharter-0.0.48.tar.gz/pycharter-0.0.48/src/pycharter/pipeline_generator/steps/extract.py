"""Extract step — wraps an extractor to pull data from an external source."""

from __future__ import annotations

import logging
import time
from typing import Any

from pycharter.pipeline_generator.extractors.factory import ExtractorFactory
from pycharter.pipeline_generator.steps._base import ExtractStepConfig

logger = logging.getLogger(__name__)


async def run_extract(
    config: ExtractStepConfig,
    variables: dict[str, str],
) -> list[dict[str, Any]]:
    """Execute an extract step.

    Creates an extractor via the factory, iterates all batches, and
    returns the accumulated records.

    Args:
        config: Extract step configuration.
        variables: Resolved pipeline variables (already substituted).

    Returns:
        Flat list of all extracted records.
    """
    source = dict(config.source)
    extractor = ExtractorFactory.create(source)

    records: list[dict[str, Any]] = []
    start = time.monotonic()

    async for batch in extractor.extract():
        records.extend(batch)

    elapsed = time.monotonic() - start
    logger.info(
        "Extract step '%s': %d records in %.2fs",
        config.id,
        len(records),
        elapsed,
    )
    return records
