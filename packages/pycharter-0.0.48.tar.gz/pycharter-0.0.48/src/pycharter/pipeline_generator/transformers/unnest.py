"""Unnest (explode) transformer for nested array fields.

Turns a single record with an array field into multiple records,
one per element.  For example::

    {"flight": "LH123", "legs": [{"ap": "FRA"}, {"ap": "JFK"}]}

becomes two records when unnested on ``legs``::

    {"flight": "LH123", "leg_ap": "FRA"}
    {"flight": "LH123", "leg_ap": "JFK"}
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.pipeline_generator.transformers.base import BaseTransformer

logger = logging.getLogger(__name__)


class Unnest(BaseTransformer):
    """Explode a nested array field into one row per element.

    Args:
        field: Name of the array field to unnest.
        prefix: Prefix to prepend to child-dict keys (default ``""``).
        preserve_empty: If ``True``, keep the parent row when the array
            is missing or empty (with the array field removed).
    """

    def __init__(
        self,
        field: str,
        prefix: str = "",
        preserve_empty: bool = False,
    ) -> None:
        self.field = field
        self.prefix = prefix
        self.preserve_empty = preserve_empty

    def transform(self, data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Explode *field* in every record, returning expanded rows."""
        result: list[dict[str, Any]] = []
        for record in data:
            items = record.get(self.field)

            if not isinstance(items, list) or len(items) == 0:
                if self.preserve_empty:
                    row = {k: v for k, v in record.items() if k != self.field}
                    result.append(row)
                continue

            base = {k: v for k, v in record.items() if k != self.field}
            for item in items:
                row = dict(base)
                if isinstance(item, dict):
                    for k, v in item.items():
                        row[f"{self.prefix}{k}"] = v
                else:
                    # Scalar list element — store with a simple key
                    row[f"{self.prefix}{self.field}"] = item
                result.append(row)

        return result

    def __repr__(self) -> str:
        parts = [f"field={self.field!r}"]
        if self.prefix:
            parts.append(f"prefix={self.prefix!r}")
        if self.preserve_empty:
            parts.append("preserve_empty=True")
        return f"Unnest({', '.join(parts)})"
