"""Synchronous data loading for MySQL and SQLite.

Provides database-specific load functions for MySQL (using
``ON DUPLICATE KEY UPDATE``) and SQLite (using ``INSERT OR REPLACE``).
All functions accept a synchronous ``sqlalchemy.orm.Session``.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from pycharter.pipeline_generator._db_query import (
    build_column_list,
    build_placeholder_list,
    build_table_name,
)
from pycharter.pipeline_generator.database_connection import (
    DB_MYSQL,
    DB_SQLITE,
)

# ============================================================================
# MySQL
# ============================================================================


def load_data_mysql(
    data: list[dict[str, Any]],
    session: Session,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
) -> dict[str, Any]:
    """Load data into MySQL using database-specific optimizations."""
    full_table_name = build_table_name(schema_name, table_name, DB_MYSQL)
    inserted = 0
    updated = 0

    if write_method == "truncate_and_load":
        session.execute(text(f"TRUNCATE TABLE {full_table_name}"))
        session.commit()
        write_method = "insert"

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method == "upsert" and primary_key:
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MYSQL)
                placeholders = build_placeholder_list(cols)
                updates = ", ".join(
                    [f"`{k}` = VALUES(`{k}`)" for k in cols if k != primary_key]
                )
                sql = (
                    f"INSERT INTO {full_table_name} ({cols_str})"
                    f" VALUES ({placeholders})"
                    f" ON DUPLICATE KEY UPDATE {updates}"
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method in ("insert", "append"):
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MYSQL)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name} ({cols_str})"
                    f" VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "replace":
            for record in batch:
                if primary_key and primary_key in record:
                    session.execute(
                        text(
                            f"DELETE FROM {full_table_name} WHERE `{primary_key}` = :pk"
                        ),
                        {"pk": record[primary_key]},
                    )
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MYSQL)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name} ({cols_str})"
                    f" VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                cols = list(record.keys())
                set_clause = ", ".join(
                    [f"`{k}` = :{k}" for k in cols if k != primary_key]
                )
                sql = (
                    f"UPDATE {full_table_name} SET {set_clause}"
                    f" WHERE `{primary_key}` = :{primary_key}"
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                sql = f"DELETE FROM {full_table_name} WHERE `{primary_key}` = :pk"
                session.execute(text(sql), {"pk": record[primary_key]})
                updated += 1

        session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}


# ============================================================================
# SQLite
# ============================================================================


def load_data_sqlite(
    data: list[dict[str, Any]],
    session: Session,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
) -> dict[str, Any]:
    """Load data into SQLite using database-specific optimizations."""
    full_table_name = build_table_name("", table_name, DB_SQLITE)
    inserted = 0
    updated = 0

    if write_method == "truncate_and_load":
        session.execute(text(f"DELETE FROM {full_table_name}"))
        session.commit()
        write_method = "insert"

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method == "upsert" and primary_key:
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_SQLITE)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT OR REPLACE INTO {full_table_name}"
                    f" ({cols_str}) VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method in ("insert", "append"):
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_SQLITE)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name}"
                    f" ({cols_str}) VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "replace":
            for record in batch:
                if primary_key and primary_key in record:
                    session.execute(
                        text(
                            f'DELETE FROM {full_table_name} WHERE "{primary_key}" = :pk'
                        ),
                        {"pk": record[primary_key]},
                    )
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_SQLITE)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name}"
                    f" ({cols_str}) VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                cols = list(record.keys())
                set_clause = ", ".join(
                    [f'"{k}" = :{k}' for k in cols if k != primary_key]
                )
                sql = (
                    f"UPDATE {full_table_name} SET {set_clause}"
                    f' WHERE "{primary_key}" = :{primary_key}'
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                sql = f'DELETE FROM {full_table_name} WHERE "{primary_key}" = :pk'
                session.execute(text(sql), {"pk": record[primary_key]})
                updated += 1

        session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}
