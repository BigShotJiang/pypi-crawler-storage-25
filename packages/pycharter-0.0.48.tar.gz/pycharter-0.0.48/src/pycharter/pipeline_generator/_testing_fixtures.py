"""Test data generation and fixtures for ETL pipeline testing.

Provides fixture loading from YAML/JSON files, the TestFixture dataclass,
and pipeline configuration validation helpers.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

# =============================================================================
# FIXTURE LOADING
# =============================================================================


@dataclass(frozen=True, slots=True)
class TestFixture:
    """Container for loaded test fixture data.

    Attributes:
        name: Optional fixture name from metadata.
        records: Flat list of records.
        batches: Pre-batched records (empty if data was flat).
        metadata: Additional metadata from the fixture file.
    """

    name: str = ""
    records: tuple[dict[str, Any], ...] = ()
    batches: tuple[tuple[dict[str, Any], ...], ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


def load_fixture(path: str | Path) -> list[dict[str, Any]]:
    """Load fixture data from a YAML or JSON file.

    Supported formats:
        - Top-level list: ``[{id: 1}, ...]``
        - Dict with ``records`` key: ``{records: [{id: 1}, ...]}``
        - Dict with ``batches`` key: flattened into a single list.

    Args:
        path: Path to the fixture file (.yaml, .yml, or .json).

    Returns:
        Flat list of records.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the format is unrecognized.
    """
    fixture = load_test_fixture(path)
    return list(fixture.records)


def load_test_fixture(path: str | Path) -> TestFixture:
    """Load a test fixture with full metadata.

    Args:
        path: Path to the fixture file (.yaml, .yml, or .json).

    Returns:
        TestFixture with records, batches, and metadata.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the format is unrecognized.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Fixture file not found: {path}")

    data = _read_fixture_file(path)
    return _parse_fixture_data(data)


def _read_fixture_file(path: Path) -> Any:
    """Read and parse a fixture file."""
    suffix = path.suffix.lower()
    with open(path) as f:
        if suffix == ".json":
            return json.load(f)
        return yaml.safe_load(f)


def _parse_fixture_data(data: Any) -> TestFixture:
    """Parse raw fixture data into a TestFixture."""
    if isinstance(data, list):
        return TestFixture(records=tuple(data))

    if isinstance(data, dict):
        name = data.get("name", "")
        metadata = {
            k: v for k, v in data.items() if k not in ("name", "records", "batches")
        }

        if "batches" in data:
            batches = tuple(tuple(b) for b in data["batches"])
            flat = [record for batch in data["batches"] for record in batch]
            return TestFixture(
                name=name,
                records=tuple(flat),
                batches=batches,
                metadata=metadata,
            )

        if "records" in data:
            return TestFixture(
                name=name,
                records=tuple(data["records"]),
                metadata=metadata,
            )

    raise ValueError(
        f"Unrecognized fixture format. Expected a list, or a dict with "
        f"'records' or 'batches' key. Got: {type(data).__name__}"
    )


# =============================================================================
# CONFIG VALIDATION HELPER
# =============================================================================


def validate_pipeline_config(
    config: dict[str, Any] | str | Path,
    *,
    variables: dict[str, str] | None = None,
) -> tuple[bool, list[dict[str, Any]]]:
    """Validate a pipeline configuration by attempting to parse it.

    Args:
        config: Pipeline config as a dict, file path string, or Path object.
        variables: Optional variables for ``${VAR}`` substitution.

    Returns:
        Tuple of (is_valid, errors) where errors is a list of dicts
        with 'section' and 'message' keys.
    """
    from pycharter.pipeline_generator._config import parse_pipeline_config
    from pycharter.pipeline_generator.pipeline import Pipeline

    if isinstance(config, str | Path):
        path = Path(config)
        if not path.exists():
            return False, [{"section": "file", "message": f"File not found: {path}"}]
        try:
            if path.is_dir():
                Pipeline.from_config_dir(path, extra_variables=variables)
            else:
                Pipeline.from_file(path, extra_variables=variables)
            return True, []
        except Exception as exc:
            return False, [{"section": "pipeline", "message": str(exc)}]

    if not isinstance(config, dict):
        return False, [{"section": "config", "message": "Config must be a dict"}]

    try:
        parse_pipeline_config(config, extra_variables=variables)
        return True, []
    except Exception as exc:
        return False, [{"section": "pipeline", "message": str(exc)}]
