"""CLI command implementations for ``pycharter pipeline`` subcommands.

Each public function corresponds to one CLI sub-command and returns an
``int`` exit code (0 = success, 1 = failure).

``cmd_etl_list`` and ``cmd_etl_inspect`` are implemented in
:mod:`_pipeline_cli_commands` and re-exported here.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# Mapping from --template preset to (dest filename -> source template filename).
# settings.yaml and variables.yaml are always included.
_INIT_PRESETS: dict[str, dict[str, str]] = {
    "http-to-postgres": {
        "extract.yaml": "extract_http_simple.yaml",
        "transform.yaml": "transform_simple.yaml",
        "load.yaml": "load_postgresql.yaml",
    },
    "database-incremental": {
        "extract.yaml": "extract_database_incremental.yaml",
        "transform.yaml": "transform_simple.yaml",
        "load.yaml": "load_postgresql.yaml",
    },
    "file-to-file": {
        "extract.yaml": "extract_file_csv.yaml",
        "transform.yaml": "transform_simple.yaml",
        "load.yaml": "load_file.yaml",
    },
}


def _parse_key_values(items: list[str]) -> dict[str, str]:
    """Parse ``KEY=VALUE`` pairs from a list of strings."""
    out: dict[str, str] = {}
    for item in items:
        if "=" not in item:
            print(f"Invalid KEY=VALUE pair: {item}", file=sys.stderr)
            continue
        key, value = item.split("=", 1)
        out[key.strip()] = value.strip()
    return out


def _templates_dir() -> Path:
    """Return the path to the bundled pipeline templates directory.

    Resolves from the pycharter package root (``pycharter/__init__.py``).
    """
    import pycharter

    pkg_root = Path(pycharter.__file__).resolve().parent
    return pkg_root / "data" / "templates" / "pipeline"


# =========================================================================
# pycharter pipeline run
# =========================================================================


def cmd_etl_run(
    path: str,
    variables: list[str] | None = None,
    params: list[str] | None = None,
    dry_run: bool = False,
    validate: bool = True,
) -> int:
    """Run a pipeline from a directory or file.

    Args:
        path: Pipeline directory or config file.
        variables: ``KEY=VALUE`` pairs for ``${VAR}`` substitution.
        params: ``KEY=VALUE`` pairs passed to extractor/loader.
        dry_run: Extract and transform only (skip loading).
        validate: Validate config before running.

    Returns:
        Exit code (0 on success, 1 on failure).
    """
    from pycharter.pipeline_generator.pipeline import Pipeline

    target = Path(path)
    vars_dict = _parse_key_values(variables or [])
    _ = _parse_key_values(
        params or []
    )  # params parsed for validation; pipeline uses extra_variables

    try:
        if target.is_dir():
            pipeline = Pipeline.from_config_dir(
                target, extra_variables=vars_dict or None
            )
        elif target.is_file():
            pipeline = Pipeline.from_file(target, extra_variables=vars_dict or None)
        else:
            print(f"Path not found: {path}", file=sys.stderr)
            return 1

        result = asyncio.run(pipeline.run())
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    # Print result summary
    print(f"Pipeline: {result.pipeline_name or 'unnamed'}")
    print(f"Run ID:   {result.run_id}")
    print(f"Status:   {'SUCCESS' if result.success else 'FAILED'}")
    print(f"Duration: {result.duration_seconds:.2f}s")
    print(f"Rows extracted:   {result.rows_extracted}")
    print(f"Rows transformed: {result.rows_transformed}")
    print(f"Rows loaded:      {result.rows_loaded}")
    if result.rows_failed:
        print(f"Rows failed:      {result.rows_failed}")
    if result.errors:
        print("Errors:")
        for err in result.errors:
            print(f"  - {err}")

    return 0 if result.success else 1


# =========================================================================
# pycharter pipeline validate
# =========================================================================


def cmd_etl_validate(path: str) -> int:
    """Validate pipeline config files without running.

    Args:
        path: Pipeline directory or config file.

    Returns:
        Exit code (0 if valid, 1 if invalid).
    """
    from pycharter.pipeline_generator.pipeline import Pipeline

    target = Path(path)

    try:
        if target.is_dir():
            Pipeline.from_config_dir(target)
        elif target.is_file():
            Pipeline.from_file(target)
        else:
            print(f"Path not found: {path}", file=sys.stderr)
            return 1
    except Exception as exc:
        print(f"Validation FAILED: {exc}", file=sys.stderr)
        return 1

    print("Validation OK")
    return 0


# =========================================================================
# pycharter pipeline init
# =========================================================================


def cmd_etl_init(path: str, template: str = "http-to-postgres") -> int:
    """Scaffold a new pipeline directory from a template preset.

    Args:
        path: Directory to create.
        template: Preset name (see ``_INIT_PRESETS``).

    Returns:
        Exit code (0 on success, 1 on failure).
    """
    preset = _INIT_PRESETS.get(template)
    if not preset:
        print(
            f"Unknown template: {template}. Available: {', '.join(_INIT_PRESETS)}",
            file=sys.stderr,
        )
        return 1

    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)

    templates = _templates_dir()

    created: list[str] = []

    # Copy preset files
    for dest_name, src_name in preset.items():
        src = templates / src_name
        dst = target / dest_name
        if not src.exists():
            print(f"Warning: template {src_name} not found, skipping", file=sys.stderr)
            continue
        shutil.copy2(src, dst)
        created.append(str(dst))

    # Always copy settings.yaml and variables.yaml
    for shared in ("settings.yaml", "variables.yaml"):
        src = templates / shared
        dst = target / shared
        if src.exists():
            shutil.copy2(src, dst)
            created.append(str(dst))

    print(f"Created pipeline from '{template}' template:")
    for f in created:
        print(f"  {f}")

    return 0


# ---------------------------------------------------------------------------
# Re-exports from _pipeline_cli_commands
# ---------------------------------------------------------------------------

from pycharter.pipeline_generator._pipeline_cli_commands import (  # noqa: E402, F401
    cmd_etl_inspect,
    cmd_etl_list,
)
