"""Synchronous data loading for MSSQL, generic reflection, and raw SQL.

Provides load functions for Microsoft SQL Server (using ``MERGE``),
a generic SQLAlchemy Table reflection fallback, and a raw-SQL fallback.
All functions accept a synchronous ``sqlalchemy.orm.Session``.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from pycharter.pipeline_generator._db_query import (
    build_column_list,
    build_placeholder_list,
    build_table_name,
)
from pycharter.pipeline_generator.database_connection import (
    DB_MSSQL,
    DB_POSTGRESQL,
)

# ============================================================================
# MSSQL
# ============================================================================


def load_data_mssql(
    data: list[dict[str, Any]],
    session: Session,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
) -> dict[str, Any]:
    """Load data into Microsoft SQL Server using database-specific optimizations."""
    full_table_name = build_table_name(schema_name, table_name, DB_MSSQL)
    inserted = 0
    updated = 0

    if write_method == "truncate_and_load":
        session.execute(text(f"TRUNCATE TABLE {full_table_name}"))
        session.commit()
        write_method = "insert"

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method == "upsert" and primary_key:
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MSSQL)
                placeholders = build_placeholder_list(cols)
                updates = ", ".join(
                    [f"[{k}] = source.[{k}]" for k in cols if k != primary_key]
                )
                sql = (
                    f"MERGE {full_table_name} AS target"
                    f" USING (SELECT {placeholders}) AS source ({cols_str})"
                    f" ON target.[{primary_key}] = source.[{primary_key}]"
                    f" WHEN MATCHED THEN UPDATE SET {updates}"
                    f" WHEN NOT MATCHED THEN"
                    f" INSERT ({cols_str}) VALUES ({placeholders});"
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method in ("insert", "append"):
            for record in batch:
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MSSQL)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name} ({cols_str})"
                    f" VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "replace":
            for record in batch:
                if primary_key and primary_key in record:
                    session.execute(
                        text(
                            f"DELETE FROM {full_table_name} WHERE [{primary_key}] = :pk"
                        ),
                        {"pk": record[primary_key]},
                    )
                cols = list(record.keys())
                cols_str = build_column_list(cols, DB_MSSQL)
                placeholders = build_placeholder_list(cols)
                sql = (
                    f"INSERT INTO {full_table_name} ({cols_str})"
                    f" VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                cols = list(record.keys())
                set_clause = ", ".join(
                    [f"[{k}] = :{k}" for k in cols if k != primary_key]
                )
                sql = (
                    f"UPDATE {full_table_name} SET {set_clause}"
                    f" WHERE [{primary_key}] = :{primary_key}"
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                sql = f"DELETE FROM {full_table_name} WHERE [{primary_key}] = :pk"
                session.execute(text(sql), {"pk": record[primary_key]})
                updated += 1

        session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}


# ============================================================================
# Generic / Raw-SQL Fallbacks
# ============================================================================


def load_data_generic(
    data: list[dict[str, Any]],
    session: Session,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
) -> dict[str, Any]:
    """Generic load data using SQLAlchemy Table reflection (fallback)."""
    from sqlalchemy import MetaData, Table

    metadata = MetaData()
    try:
        table = Table(
            table_name,
            metadata,
            schema=schema_name,
            autoload_with=session.bind if hasattr(session, "bind") else None,
        )
    except Exception:
        return load_data_raw_sql(
            data,
            session,
            schema_name,
            table_name,
            write_method,
            primary_key,
            batch_size,
        )

    inserted = 0
    updated = 0
    full_table_name = (
        f'"{schema_name}"."{table_name}"' if schema_name else f'"{table_name}"'
    )

    if write_method == "truncate_and_load":
        session.execute(text(f"TRUNCATE TABLE {full_table_name}"))
        session.commit()
        write_method = "insert"

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method == "upsert" and primary_key:
            for record in batch:
                existing = (
                    session.query(table)
                    .filter(getattr(table.c, primary_key) == record[primary_key])
                    .first()
                )
                if existing:
                    for key, value in record.items():
                        setattr(existing, key, value)
                    updated += 1
                else:
                    session.add(table(**record))
                    inserted += 1
        elif write_method in ("insert", "append"):
            for record in batch:
                session.add(table(**record))
                inserted += 1
        elif write_method == "replace":
            for record in batch:
                if primary_key and primary_key in record:
                    existing = (
                        session.query(table)
                        .filter(getattr(table.c, primary_key) == record[primary_key])
                        .first()
                    )
                    if existing:
                        session.delete(existing)
                session.add(table(**record))
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                existing = (
                    session.query(table)
                    .filter(getattr(table.c, primary_key) == record[primary_key])
                    .first()
                )
                if existing:
                    for key, value in record.items():
                        setattr(existing, key, value)
                    updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                existing = (
                    session.query(table)
                    .filter(getattr(table.c, primary_key) == record[primary_key])
                    .first()
                )
                if existing:
                    session.delete(existing)
                    updated += 1

        session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}


def load_data_raw_sql(
    data: list[dict[str, Any]],
    session: Session,
    schema_name: str,
    table_name: str,
    write_method: str,
    primary_key: str | None,
    batch_size: int,
) -> dict[str, Any]:
    """Load data using raw SQL (fallback when table can't be autoloaded)."""
    full_table_name = (
        f'"{schema_name}"."{table_name}"' if schema_name else f'"{table_name}"'
    )
    inserted = 0
    updated = 0

    if write_method == "truncate_and_load":
        session.execute(text(f"TRUNCATE TABLE {full_table_name}"))
        session.commit()
        write_method = "insert"

    if not data:
        return {"inserted": 0, "updated": 0, "total": 0}

    columns = list(data[0].keys())
    columns_str = build_column_list(columns, DB_POSTGRESQL)
    placeholders = build_placeholder_list(columns)

    for i in range(0, len(data), batch_size):
        batch = data[i : i + batch_size]

        if write_method in ("insert", "append"):
            for record in batch:
                sql = (
                    f"INSERT INTO {full_table_name} ({columns_str})"
                    f" VALUES ({placeholders})"
                )
                session.execute(text(sql), record)
                inserted += 1
        elif write_method == "update" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                set_clause = ", ".join(
                    [f'"{k}" = :{k}' for k in columns if k != primary_key]
                )
                sql = (
                    f"UPDATE {full_table_name} SET {set_clause}"
                    f' WHERE "{primary_key}" = :{primary_key}'
                )
                session.execute(text(sql), record)
                updated += 1
        elif write_method == "delete" and primary_key:
            for record in batch:
                if primary_key not in record:
                    continue
                sql = f'DELETE FROM {full_table_name} WHERE "{primary_key}" = :pk'
                session.execute(text(sql), {"pk": record[primary_key]})
                updated += 1

        session.commit()

    return {"inserted": inserted, "updated": updated, "total": len(data)}
