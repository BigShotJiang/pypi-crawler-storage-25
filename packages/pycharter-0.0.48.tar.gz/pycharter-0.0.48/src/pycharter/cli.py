"""Main CLI entry point for pycharter commands.

Commands: db (init, upgrade, downgrade, seed, ...), api, ui (serve, dev, build),
docs (serve, build), worker, pipeline (run, validate, init, list, inspect),
quality (check, violations).
"""

from __future__ import annotations

import argparse
import sys

from pycharter._cli_commands import (
    handle_api,
    handle_db,
    handle_docs,
    handle_pipeline,
    handle_quality,
    handle_ui,
    handle_worker,
)
from pycharter._cli_parsers import (
    register_api,
    register_db,
    register_docs,
    register_pipeline,
    register_quality,
    register_ui,
    register_worker,
)


def main() -> int | None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="PyCharter - Data Contract Management and Validation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Register every subcommand group and keep references for help display.
    db_parser, _db_sub = register_db(subparsers)
    register_api(subparsers)
    ui_parser, _ui_sub = register_ui(subparsers)
    worker_parser, _worker_sub = register_worker(subparsers)
    pipeline_parser, _pipeline_sub = register_pipeline(subparsers)
    docs_parser, _docs_sub = register_docs(subparsers)
    quality_parser, _quality_sub = register_quality(subparsers)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    dispatch = {
        "db": lambda: handle_db(args, db_parser),
        "api": lambda: handle_api(args),
        "ui": lambda: handle_ui(args, ui_parser),
        "worker": lambda: handle_worker(args, worker_parser),
        "pipeline": lambda: handle_pipeline(args, pipeline_parser),
        "docs": lambda: handle_docs(args, docs_parser),
        "quality": lambda: handle_quality(args, quality_parser),
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 1

    return handler()


if __name__ == "__main__":
    sys.exit(main())
