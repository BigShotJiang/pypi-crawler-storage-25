"""Semantic layer seeding: concepts, concept relationships, field graph, proposals, and ontologies."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    pass

from pycharter.db._seed_core import _set_sqlite_timestamps
from pycharter.db._seed_semantic_fields import (
    _iter_mapping_bindings as _iter_mapping_bindings,  # noqa: F401 — re-export
)
from pycharter.db._seed_semantic_fields import (
    _seed_semantic_field_graph as _seed_semantic_field_graph,  # noqa: F401 — re-export
)
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.concept_relationship import ConceptRelationshipModel
from pycharter.db.models.semantic.proposal import ProposalModel

logger = logging.getLogger(__name__)


def _seed_concepts(seed_path: Path, session: Any) -> int:
    """
    Seed concept vocabulary from ontologies.yaml (or ontologies.jsonld) into
    the semantic concepts table.  Returns the number of concepts seeded.
    """
    for name in ("ontologies.yaml", "ontologies.jsonld"):
        candidate = seed_path / name
        if candidate.exists():
            break
    else:
        return 0

    try:
        from pycharter.semantic.rdf.vocabulary import ingest_vocabulary, load_vocabulary
    except Exception:
        logger.warning("Skipping concept seed (vocabulary loader not available)")
        return 0

    logger.info("Loading concepts...")
    try:
        scheme = load_vocabulary(str(candidate))
        result = ingest_vocabulary(scheme, session, author="seed")
        total = result["total"]
        logger.info(
            "Loaded %d concept(s) (%d created, %d updated)",
            total,
            result["created"],
            result["updated"],
        )
        return total
    except Exception as exc:
        logger.warning("Failed to seed concepts: %s", exc)
        return 0


def _seed_concept_relationships(seed_path: Path, session: Any) -> int:
    """
    Seed concept-to-concept relationships from concept_relationships.yaml.

    Idempotent by (source_concept_id, target_concept_id, relationship_type).
    """
    relationships_file = seed_path / "concept_relationships.yaml"
    if not relationships_file.exists():
        return 0

    with open(relationships_file) as f:
        data = yaml.safe_load(f) or {}
    rels = data.get("relationships", []) if isinstance(data, dict) else []
    if not isinstance(rels, list) or not rels:
        return 0

    concept_rows = session.query(
        ConceptModel.id, ConceptModel.name, ConceptModel.concept_key
    ).all()
    by_name = {name: cid for cid, name, _key in concept_rows if isinstance(name, str)}
    by_key = {key: cid for cid, _name, key in concept_rows if isinstance(key, str)}

    created = 0
    skipped = 0
    for rel in rels:
        if not isinstance(rel, dict):
            skipped += 1
            continue
        source_name = rel.get("source")
        target_name = rel.get("target")
        rel_type = rel.get("type")
        if not isinstance(source_name, str) or not isinstance(target_name, str):
            skipped += 1
            continue
        if not isinstance(rel_type, str) or not rel_type.strip():
            rel_type = "related_to"
        source_id = by_name.get(source_name) or by_key.get(source_name)
        target_id = by_name.get(target_name) or by_key.get(target_name)
        if source_id is None or target_id is None:
            skipped += 1
            continue

        existing = (
            session.query(ConceptRelationshipModel)
            .filter_by(
                source_concept_id=source_id,
                target_concept_id=target_id,
                relationship_type=rel_type,
            )
            .first()
        )
        if existing:
            skipped += 1
            continue

        session.add(
            ConceptRelationshipModel(
                source_concept_id=source_id,
                target_concept_id=target_id,
                relationship_type=rel_type,
                created_by="seed",
            )
        )
        created += 1

    session.commit()
    if created or skipped:
        logger.info(
            "Loaded concept relationships (%d created, %d skipped)", created, skipped
        )
    return created


def _parse_seed_datetime(value: Any) -> datetime | None:
    """Parse ISO datetime from seed values."""
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value.strip():
        normalized = value.replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            return None
    return None


def _seed_semantic_proposals(seed_path: Path, session: Any) -> int:
    """
    Seed proposal activity for semantic dashboard/gov UI from semantic_proposals.yaml.

    Idempotent by (contract_id, title).
    """
    proposals_file = seed_path / "semantic_proposals.yaml"
    if not proposals_file.exists():
        return 0
    with open(proposals_file) as f:
        data = yaml.safe_load(f) or []
    if not isinstance(data, list) or not data:
        return 0

    created = 0
    updated = 0
    for entry in data:
        if not isinstance(entry, dict):
            continue
        contract_id = entry.get("contract_id")
        title = entry.get("title")
        author = entry.get("author")
        if (
            not isinstance(contract_id, str)
            or not isinstance(title, str)
            or not isinstance(author, str)
        ):
            continue
        existing = (
            session.query(ProposalModel)
            .filter_by(contract_id=contract_id, title=title)
            .first()
        )
        payload = {
            "description": entry.get("description"),
            "status": entry.get("status") or "open",
            "author": author,
            "proposal_type": entry.get("proposal_type") or "mapping_change",
            "required_approvals": int(entry.get("required_approvals") or 1),
            "enforce_gates": bool(entry.get("enforce_gates")),
            "gate_status": entry.get("gate_status")
            if isinstance(entry.get("gate_status"), dict)
            else None,
            "created_by": "seed",
            "updated_by": "seed",
        }
        created_at = _parse_seed_datetime(entry.get("created_at"))
        updated_at = _parse_seed_datetime(entry.get("updated_at"))
        if created_at is not None:
            payload["created_at"] = created_at
        if updated_at is not None:
            payload["updated_at"] = updated_at

        if existing is None:
            proposal = ProposalModel(contract_id=contract_id, title=title, **payload)
            _set_sqlite_timestamps(session, proposal)
            session.add(proposal)
            created += 1
        else:
            for key, value in payload.items():
                setattr(existing, key, value)
            updated += 1

    session.commit()
    if created or updated:
        logger.info(
            "Loaded semantic proposals (%d created, %d updated)", created, updated
        )
    return created + updated


def _seed_ontologies(seed_path: Path, db_url: str) -> int:
    """
    Seed ontology records from ontology_mappings.yaml into contract_versions (semantic layer).

    Only runs for PostgreSQL; requires semantic tables (contract_versions) to exist.
    Returns the number of ontologies seeded.
    """
    if not db_url or "postgres" not in db_url.lower():
        return 0
    mappings_file = seed_path / "ontology_mappings.yaml"
    if not mappings_file.exists():
        return 0
    try:
        from pycharter.contract_store.postgres import PostgresContractStore
    except ImportError:
        logger.warning("Skipping ontology seed (contract_store not available)")
        return 0
    with open(mappings_file) as f:
        data = yaml.safe_load(f) or []
    if not data:
        return 0
    logger.info("Loading ontologies...")
    client = PostgresContractStore(db_url)
    count = 0
    try:
        client.connect()
        for record in data:
            contract_name = record.get("contract_name")
            contract_version = record.get("contract_version")
            if not contract_name or not contract_version:
                logger.warning(
                    "Skipping ontology entry missing contract_name or contract_version"
                )
                continue
            if client.get_field_mapping(contract_name, contract_version) is not None:
                logger.debug(
                    "Field mapping already exists for %s@%s, skipping",
                    contract_name,
                    contract_version,
                )
                continue
            ontology = {
                k: v
                for k, v in record.items()
                if k not in ("contract_name", "contract_version")
            }
            if not ontology:
                continue
            ontology.setdefault("version", contract_version)
            try:
                client.store_field_mapping(contract_name, contract_version, ontology)
                count += 1
                logger.debug("Stored ontology: %s@%s", contract_name, contract_version)
            except Exception as exc:
                logger.warning(
                    "Failed to store ontology %s@%s: %s",
                    contract_name,
                    contract_version,
                    exc,
                )
        if count:
            logger.info("Loaded %d ontology/ontologies", count)
    finally:
        client.disconnect()
    return count
