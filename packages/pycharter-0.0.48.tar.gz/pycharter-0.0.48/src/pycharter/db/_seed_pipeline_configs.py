"""Pipeline config seeding from pipeline_configs.yaml."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    pass

from pycharter.db._seed_core import _set_sqlite_timestamps
from pycharter.db.models import DataContractModel
from pycharter.db.models.pipeline_config import PipelineConfigModel

logger = logging.getLogger(__name__)


def _seed_pipeline_configs(seed_path: Path, session: Any) -> int:
    """Seed pipeline configs from pipeline_configs.yaml.

    Each YAML entry maps to a PipelineConfigModel row. The
    ``contract_name`` / ``contract_version`` keys are resolved to
    ``data_contract_id`` if a matching contract exists. Idempotent by
    ``(pipeline_name, pipeline_version)``.

    Args:
        seed_path: Directory containing seed YAML files.
        session: SQLAlchemy session.

    Returns:
        Number of configs seeded.
    """
    configs_file = seed_path / "pipeline_configs.yaml"
    if not configs_file.exists():
        return 0

    with open(configs_file) as f:
        data = yaml.safe_load(f) or []
    if not isinstance(data, list) or not data:
        return 0

    logger.info("Loading pipeline configs...")
    created = 0
    updated = 0

    for entry in data:
        if not isinstance(entry, dict):
            continue

        pipeline_name = entry.get("pipeline_name")
        pipeline_version = entry.get("pipeline_version")
        if not isinstance(pipeline_name, str) or not isinstance(pipeline_version, str):
            logger.warning(
                "Skipping pipeline config entry missing pipeline_name or pipeline_version"
            )
            continue

        # Resolve optional contract reference
        data_contract_id = _resolve_contract_id(
            session,
            entry.get("contract_name"),
            entry.get("contract_version"),
        )

        steps = entry.get("steps")
        if not steps:
            from pycharter.pipeline_generator._sections_bridge import sections_to_steps

            extract_cfg = entry.get("extract_config", {})
            load_cfg = entry.get("load_config", {})
            transform_cfg = entry.get("transform_config")
            steps = sections_to_steps(
                extract_cfg,
                load_cfg,
                transform=transform_cfg,
            )

        row_data = {
            "pipeline_name": pipeline_name,
            "pipeline_version": pipeline_version,
            "status": entry.get("status") or "active",
            "description": entry.get("description"),
            "data_contract_id": data_contract_id,
            "steps": steps,
            "settings": entry.get("settings"),
            "variables": entry.get("variables"),
            "created_by": entry.get("created_by") or "seed",
        }

        existing = (
            session.query(PipelineConfigModel)
            .filter_by(
                pipeline_name=pipeline_name,
                pipeline_version=pipeline_version,
            )
            .first()
        )

        if existing:
            for key, value in row_data.items():
                if hasattr(existing, key):
                    setattr(existing, key, value)
            _set_sqlite_timestamps(session, existing)
            updated += 1
            logger.debug(
                "Updated pipeline config: %s@%s", pipeline_name, pipeline_version
            )
        else:
            item = PipelineConfigModel(**row_data)
            _set_sqlite_timestamps(session, item)
            session.add(item)
            created += 1
            logger.debug(
                "Created pipeline config: %s@%s", pipeline_name, pipeline_version
            )

    session.commit()
    total = created + updated
    if total:
        logger.info(
            "Loaded %d pipeline config(s) (%d created, %d updated)",
            total,
            created,
            updated,
        )
    return total


def _resolve_contract_id(
    session: Any,
    contract_name: str | None,
    contract_version: str | None,
) -> Any:
    """Resolve contract_name + contract_version to data_contract_id, or None."""
    if not contract_name or not contract_version:
        return None
    contract = (
        session.query(DataContractModel)
        .filter_by(name=contract_name, version=contract_version)
        .first()
    )
    if contract is None:
        logger.debug(
            "Contract %s@%s not found, skipping FK link",
            contract_name,
            contract_version,
        )
        return None
    return contract.id
