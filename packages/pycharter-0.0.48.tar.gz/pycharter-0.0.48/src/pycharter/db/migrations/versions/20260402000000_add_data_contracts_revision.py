"""Add data_contracts.revision for optimistic concurrency.

Revision ID: add_dc_revision
Revises: rename_etl_to_pipeline
Create Date: 2026-04-02

The SQLAlchemy model ``DataContractModel`` defines ``revision`` (Integer, default 1).
Databases created before that field existed, or created via ``create_all()`` when the
table already existed, will not have this column—``create_all`` does not ALTER tables.

This migration adds the column idempotently.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

# revision identifiers, used by Alembic.
revision: str = "add_dc_revision"
down_revision: str | None = "rename_etl_to_pipeline"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "pycharter"
TABLE = "data_contracts"
COLUMN = "revision"


def _contract_schema(bind) -> str | None:
    url = str(bind.engine.url)
    return None if "sqlite" in url else SCHEMA


def upgrade() -> None:
    bind = op.get_bind()
    schema = _contract_schema(bind)
    insp = inspect(bind)
    cols = {c["name"] for c in insp.get_columns(TABLE, schema=schema)}
    if COLUMN in cols:
        return
    op.add_column(
        TABLE,
        sa.Column(
            COLUMN,
            sa.Integer(),
            nullable=False,
            server_default=sa.text("1"),
        ),
        schema=schema,
    )


def downgrade() -> None:
    bind = op.get_bind()
    schema = _contract_schema(bind)
    insp = inspect(bind)
    cols = {c["name"] for c in insp.get_columns(TABLE, schema=schema)}
    if COLUMN not in cols:
        return
    op.drop_column(TABLE, COLUMN, schema=schema)
