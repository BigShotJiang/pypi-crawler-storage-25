"""Rename etl_pipeline_configs to pipeline_configs.

Revision ID: rename_etl_to_pipeline
Revises: squashed_root
Create Date: 2026-03-08

Renames table etl_pipeline_configs to pipeline_configs and the unique
constraint uq_etl_pipeline_configs_name_version to uq_pipeline_configs_name_version.

**Idempotent:** If ``pipeline_configs`` already exists (e.g. squashed_root used
``create_all()`` with current models), this revision is a no-op. If only
``etl_pipeline_configs`` exists (legacy DB), the rename runs.
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op
from sqlalchemy import inspect, text

# revision identifiers, used by Alembic.
revision: str = "rename_etl_to_pipeline"
down_revision: str | None = "squashed_root"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "pycharter"
OLD_TABLE = "etl_pipeline_configs"
NEW_TABLE = "pipeline_configs"
OLD_CONSTRAINT = "uq_etl_pipeline_configs_name_version"
NEW_CONSTRAINT = "uq_pipeline_configs_name_version"


def _existing_tables(bind, schema: str | None) -> set[str]:
    """Return base table names in the given schema (or unqualified for SQLite)."""
    insp = inspect(bind)
    if schema:
        return set(insp.get_table_names(schema=schema))
    return set(insp.get_table_names())


def upgrade() -> None:
    bind = op.get_bind()
    url = str(bind.engine.url)
    schema = None if "sqlite" in url else SCHEMA
    tables = _existing_tables(bind, schema)

    if NEW_TABLE in tables:
        # Fresh install: squashed_root already created pipeline_configs.
        return
    if OLD_TABLE not in tables:
        # Neither table present; squashed_root should have created pipeline_configs.
        raise RuntimeError(
            f"Alembic {revision}: expected '{NEW_TABLE}' after squashed_root, or "
            f"legacy '{OLD_TABLE}' to rename; found neither. "
            "Check that squashed_root completed successfully."
        )

    op.rename_table(OLD_TABLE, NEW_TABLE, schema=schema)

    if "sqlite" not in url:
        qual_new = f'"{schema}"."{NEW_TABLE}"'
        bind.execute(
            text(
                f'ALTER TABLE {qual_new} RENAME CONSTRAINT "{OLD_CONSTRAINT}" TO "{NEW_CONSTRAINT}"'
            )
        )


def downgrade() -> None:
    bind = op.get_bind()
    url = str(bind.engine.url)
    schema = None if "sqlite" in url else SCHEMA
    tables = _existing_tables(bind, schema)

    if OLD_TABLE in tables:
        # Already using legacy table name.
        return
    if NEW_TABLE not in tables:
        return

    if "sqlite" not in url:
        qual_new = f'"{schema}"."{NEW_TABLE}"'
        bind.execute(
            text(
                f'ALTER TABLE {qual_new} RENAME CONSTRAINT "{NEW_CONSTRAINT}" TO "{OLD_CONSTRAINT}"'
            )
        )

    op.rename_table(NEW_TABLE, OLD_TABLE, schema=schema)
