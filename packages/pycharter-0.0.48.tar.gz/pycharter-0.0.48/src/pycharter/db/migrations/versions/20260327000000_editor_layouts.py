"""Add editor_layouts table for diagram node positions.

Revision ID: 20260327000000
Revises: add_dc_revision
Create Date: 2026-03-27
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = "20260327000000"
down_revision: str | None = "add_dc_revision"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pycharter"


def upgrade() -> None:
    schema_name = _schema()
    op.create_table(
        "editor_layouts",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("contract_name", sa.String(length=255), nullable=False),
        sa.Column("contract_version", sa.String(length=50), nullable=False),
        sa.Column("node_id", sa.String(length=255), nullable=False),
        sa.Column(
            "position_x",
            sa.Float(),
            nullable=False,
            server_default="0",
        ),
        sa.Column(
            "position_y",
            sa.Float(),
            nullable=False,
            server_default="0",
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(length=255), nullable=True),
        sa.Column("updated_by", sa.String(length=255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "contract_name",
            "contract_version",
            "node_id",
            name="uq_editor_layouts_contract_version_node",
        ),
        sa.Index(
            "ix_editor_layouts_contract_name",
            "contract_name",
        ),
        sa.Index(
            "ix_editor_layouts_contract_version",
            "contract_version",
        ),
        sa.Index(
            "ix_editor_layouts_node_id",
            "node_id",
        ),
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_table("editor_layouts", schema=schema_name)
