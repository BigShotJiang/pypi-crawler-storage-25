"""SQLAlchemy model for pipeline_configs table.

Stores versioned pipeline configurations as first-class artifacts.
Each record represents a frozen (pipeline_name, pipeline_version) pair
containing a steps-based DAG config, optional settings, and variables.
Optionally links to a data contract via foreign key.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class PipelineConfigModel(Base):
    """SQLAlchemy model for pipeline_configs table."""

    __tablename__ = "pipeline_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Pipeline identity
    pipeline_name = Column(String(255), nullable=False, index=True)
    pipeline_version = Column(String(50), nullable=False)

    # Lifecycle
    status = Column(String(50), nullable=True, default="active")
    description = Column(Text, nullable=True)

    # Optional link to a data contract
    data_contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.data_contracts.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Steps-native pipeline config (list of step dicts)
    steps = Column(JSON, nullable=False)
    settings = Column(JSON, nullable=True)
    variables = Column(JSON, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "pipeline_name",
            "pipeline_version",
            name="uq_pipeline_configs_name_version",
        ),
        {"schema": "pycharter"},
    )

    # Relationship to data contract (optional)
    data_contract = relationship("DataContractModel", foreign_keys=[data_contract_id])
