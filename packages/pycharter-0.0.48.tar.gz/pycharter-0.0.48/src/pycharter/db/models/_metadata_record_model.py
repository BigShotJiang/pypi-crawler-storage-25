"""SQLAlchemy model for the metadata_records table.

Defines the primary MetadataRecordModel with all column definitions
and relationship declarations.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class MetadataRecordModel(Base):
    """SQLAlchemy model for metadata_records table."""

    __tablename__ = "metadata_records"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Basic Information
    title = Column(String(255), nullable=False)
    data_contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.data_contracts.id", ondelete="CASCADE"),
        nullable=False,
    )
    version = Column(String(50), nullable=False)
    status = Column(String(50), nullable=True)  # e.g., "active", "deprecated", "draft"
    type = Column(String(50), nullable=True)  # e.g., "object"
    description = Column(Text, nullable=True)

    # Audit Information
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    # Governance Rules (stored as JSON)
    governance_rules = Column(JSON, nullable=True)  # Full governance rules object

    # Full metadata document (new template shape). Source of truth for flexible evolution.
    # When set, preferred over reconstructing from columns + join tables on read.
    payload = Column(JSON, nullable=True)

    __table_args__ = (
        UniqueConstraint("title", "version", name="uq_metadata_records_title_version"),
        {"schema": "pycharter"},
    )

    # Relationships
    data_contract = relationship("DataContractModel", foreign_keys=[data_contract_id])

    # Relationships to systems (via join tables)
    system_pulls = relationship(
        "MetadataRecordSystemPull",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    system_pushes = relationship(
        "MetadataRecordSystemPush",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    system_sources_rel = relationship(
        "MetadataRecordSystemSource",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to domains (via join table)
    domains_rel = relationship(
        "MetadataRecordDomain",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to owners (via join tables)
    business_owners_rel = relationship(
        "MetadataRecordBusinessOwner",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    bu_sme_rel = relationship(
        "MetadataRecordBUSME",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    it_application_owners_rel = relationship(
        "MetadataRecordITApplicationOwner",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    it_sme_rel = relationship(
        "MetadataRecordITSME",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )
    support_lead_rel = relationship(
        "MetadataRecordSupportLead",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to environments (via join table)
    environments_rel = relationship(
        "MetadataRecordEnvironment",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to data feeds (via join table)
    data_feeds_rel = relationship(
        "MetadataRecordDataFeed",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to storage locations (via join table)
    storage_locations_rel = relationship(
        "MetadataRecordStorageLocation",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to compliance frameworks (via join table)
    compliance_frameworks_rel = relationship(
        "MetadataRecordComplianceFramework",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )

    # Relationships to API endpoints (one-to-many)
    api_endpoints = relationship(
        "APIEndpointModel",
        back_populates="metadata_record",
        cascade="all, delete-orphan",
    )


class MetadataRecordStorageLocation(Base):
    """Join table for metadata_records and storage_locations."""

    __tablename__ = "metadata_record_storage_locations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    storage_location_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.storage_locations.id", ondelete="CASCADE"),
        nullable=False,
    )
    usage_type = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "metadata_record_id", "storage_location_id", name="uq_mr_storage_location"
        ),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="storage_locations_rel"
    )
    storage_location = relationship(
        "StorageLocationModel", back_populates="metadata_records"
    )


class MetadataRecordComplianceFramework(Base):
    """Join table for metadata_records and compliance_frameworks."""

    __tablename__ = "metadata_record_compliance_frameworks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    compliance_framework_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.compliance_frameworks.id", ondelete="CASCADE"),
        nullable=False,
    )
    compliance_status = Column(String(50), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "metadata_record_id", "compliance_framework_id", name="uq_mr_compliance"
        ),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="compliance_frameworks_rel"
    )
    compliance_framework = relationship(
        "ComplianceFrameworkModel", back_populates="metadata_records"
    )
