"""
SQLAlchemy model for concept_schemes table.

Each concept scheme represents a separate ontology vocabulary
(e.g. trading domain, risk domain, compliance domain).
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ConceptSchemeModel(Base):
    """SQLAlchemy model for concept_schemes table."""

    __tablename__ = "concept_schemes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scheme_key = Column(String(255), nullable=False, unique=True, index=True)
    title = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False, default="0.0.0")
    description = Column(Text, nullable=True)
    base_uri = Column(String(512), nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = ({"schema": "pycharter"},)
