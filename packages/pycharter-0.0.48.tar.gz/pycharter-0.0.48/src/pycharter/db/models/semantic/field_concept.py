"""
SQLAlchemy model for field_concepts join table.

Many-to-many relationship between fields and concepts.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class FieldConceptModel(Base):
    """SQLAlchemy model for field_concepts join table."""

    __tablename__ = "field_concepts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    field_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.fields.id", ondelete="CASCADE"),
        nullable=False,
    )
    concept_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concepts.id", ondelete="CASCADE"),
        nullable=False,
    )

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("field_id", "concept_id", name="uq_field_concept"),
        {"schema": "pycharter"},
    )
