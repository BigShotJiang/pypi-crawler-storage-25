"""
SQLAlchemy model for reviews table.

Reviews are approvals/rejections on proposals, supporting
the tiered governance workflow.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ReviewModel(Base):
    """SQLAlchemy model for reviews table."""

    __tablename__ = "reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    proposal_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.proposals.id", ondelete="CASCADE"),
        nullable=False,
    )
    reviewer = Column(String(255), nullable=False)
    decision = Column(String(50), nullable=False)  # approve, request_changes, reject
    comment = Column(Text, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = ({"schema": "pycharter"},)
