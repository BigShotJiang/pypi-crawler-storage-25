"""
SQLAlchemy model for concept_relationships table.

Tracks typed edges between concepts in the knowledge graph
(e.g. is_a, depends_on, causes).
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ConceptRelationshipModel(Base):
    """SQLAlchemy model for concept_relationships table."""

    __tablename__ = "concept_relationships"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_concept_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concepts.id", ondelete="CASCADE"),
        nullable=False,
    )
    target_concept_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concepts.id", ondelete="CASCADE"),
        nullable=False,
    )
    relationship_type = Column(String(50), nullable=False)
    scheme_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concept_schemes.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    metadata_ = Column("metadata", JSONB, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)

    __table_args__ = ({"schema": "pycharter"},)
