"""Editor diagram layout positions (stored separately from config).

Positions are visual/presentation data and do not belong in the
data contract config.  This mirrors the pystator WorkspaceLayoutModel
pattern.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, Float, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pycharter.db.models.base import Base


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class EditorLayoutModel(Base):
    """Per-node diagram position for the unified editor.

    Positions are visual/presentation data and are stored
    separately from the contract/ontology/pipeline config.
    """

    __tablename__ = "editor_layouts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    contract_name = Column(String(255), nullable=False, index=True)
    contract_version = Column(String(50), nullable=False, index=True)
    node_id = Column(String(255), nullable=False, index=True)

    position_x = Column(Float, nullable=False, default=0.0)
    position_y = Column(Float, nullable=False, default=0.0)

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "contract_name",
            "contract_version",
            "node_id",
            name="uq_editor_layouts_contract_version_node",
        ),
        {"schema": "pycharter"},
    )
