"""In-process event bus for broadcasting config change events.

Provides a lightweight pub/sub mechanism so that SSE endpoints can
stream real-time updates to connected clients.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)

_MAX_BUFFER = 100


@dataclass(frozen=True, slots=True)
class ChangeEvent:
    """Immutable record of a single resource change.

    Attributes:
        topic: Dot-separated topic string (e.g. ``contract.updated``).
        action: Short verb describing what happened (``created``,
            ``updated``, ``deleted``).
        resource_id: Identifier of the affected resource.
        revision: Monotonically increasing revision counter for
            optimistic concurrency.
        actor: Identity of the user or system that triggered the
            change.
        timestamp: UTC datetime when the event was produced.
        metadata: Arbitrary extra context for consumers.
    """

    topic: str
    action: str
    resource_id: str
    revision: int
    actor: str = "system"
    timestamp: datetime = field(
        default_factory=lambda: datetime.now(UTC),
    )
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the event to a plain dictionary.

        Returns:
            Dictionary suitable for JSON serialization.
        """
        return {
            "topic": self.topic,
            "action": self.action,
            "resource_id": self.resource_id,
            "revision": self.revision,
            "actor": self.actor,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


class ChangeBus:
    """Thread-safe, in-process pub/sub bus for change events.

    Subscribers receive events on an ``asyncio.Queue``.  A wildcard
    topic (``"*"``) receives every event.  The bus retains the last
    ``_MAX_BUFFER`` events for late joiners.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subscribers: dict[str, list[asyncio.Queue[ChangeEvent]]] = {}
        self._buffer: deque[ChangeEvent] = deque(
            maxlen=_MAX_BUFFER,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def publish(self, event: ChangeEvent) -> None:
        """Broadcast *event* to all matching subscribers.

        Args:
            event: The change event to publish.
        """
        with self._lock:
            self._buffer.append(event)
            queues = list(self._subscribers.get(event.topic, []))
            queues += list(self._subscribers.get("*", []))

        for queue in queues:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning(
                    "Subscriber queue full, dropping event %s",
                    event.topic,
                )

    def subscribe(
        self,
        topic: str = "*",
    ) -> asyncio.Queue[ChangeEvent]:
        """Create a new subscription for *topic*.

        Args:
            topic: Dot-separated topic string or ``"*"`` for
                all events.

        Returns:
            An asyncio queue that will receive matching events.
        """
        queue: asyncio.Queue[ChangeEvent] = asyncio.Queue(
            maxsize=256,
        )
        with self._lock:
            self._subscribers.setdefault(topic, []).append(
                queue,
            )
        return queue

    def unsubscribe(
        self,
        queue: asyncio.Queue[ChangeEvent],
        topic: str = "*",
    ) -> None:
        """Remove *queue* from the subscriber list for *topic*.

        Args:
            queue: The queue previously returned by
                :meth:`subscribe`.
            topic: The topic the queue was subscribed to.
        """
        with self._lock:
            subscribers = self._subscribers.get(topic, [])
            try:
                subscribers.remove(queue)
            except ValueError:
                pass

    def recent(
        self,
        limit: int = _MAX_BUFFER,
    ) -> list[ChangeEvent]:
        """Return up to *limit* most recent events.

        Args:
            limit: Maximum number of events to return.

        Returns:
            List of recent events, oldest first.
        """
        with self._lock:
            items = list(self._buffer)
        return items[-limit:]
