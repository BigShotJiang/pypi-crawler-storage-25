"""MongoDB Contract Store Implementation.

Stores contracts in MongoDB collections. The implementation
is split across:

- ``_mongodb_connection``: connection management, client setup, indexes
- ``_mongodb_operations``: schema/metadata CRUD operations
- ``_mongodb_queries``: coercion/validation rules operations, schema info
"""

from __future__ import annotations

from pycharter.contract_store._mongodb_queries import MongoDBQueriesMixin


class MongoDBContractStore(MongoDBQueriesMixin):
    """MongoDB contract store implementation.

    Stores contracts in MongoDB collections:
    - data_contracts: Central collection that links all components together
    - schemas: JSON Schema definitions (linked via data_contract_id)
    - metadata_records: Metadata including governance rules (linked via data_contract_id)
    - coercion_rules: Coercion rules for data transformation (linked via data_contract_id)
    - validation_rules: Validation rules for data validation (linked via data_contract_id)

    Connection string format: mongodb://[username:password@]host[:port][/database]

    The structure mirrors PostgreSQL's data_contracts table, where all components
    are linked via data_contract_id. This ensures consistency across both storage backends.

    Example:
        >>> store = MongoDBContractStore("mongodb://localhost:27017/pycharter")
        >>> store.connect()  # Indexes are created automatically on first connection
        >>> store.store_schema("user", "1.0", {"type": "object"})
        >>> store.store_coercion_rules("user", "1.0", {"age": "coerce_to_integer"})
        >>> store.store_validation_rules("user", "1.0", {"age": {"is_positive": {}}})

    Note:
        Indexes are created automatically on connect() by default. The implementation
        checks if indexes exist before creating them to avoid unnecessary overhead.
        To skip index creation (e.g., if indexes are managed externally), use:
        >>> store.connect(ensure_indexes=False)
    """


__all__ = ["MongoDBContractStore"]
