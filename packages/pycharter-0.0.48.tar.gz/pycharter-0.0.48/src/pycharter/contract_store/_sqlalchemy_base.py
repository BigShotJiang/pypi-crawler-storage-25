"""Private shared SQLAlchemy base for SQLite and PostgreSQL contract stores.

The implementation is split into:
- ``_sqlalchemy_connection`` -- engine setup, session lifecycle, schema helpers
- ``_sqlalchemy_crud`` -- CRUD operations (store, get, list, delete)

Import ``_SQLAlchemyContractStoreBase`` from here; it re-exports
the concrete class from ``_sqlalchemy_crud``.
"""

from __future__ import annotations

from pycharter.contract_store._sqlalchemy_crud import (
    _SQLAlchemyContractStoreBase,
)

__all__ = ["_SQLAlchemyContractStoreBase"]
