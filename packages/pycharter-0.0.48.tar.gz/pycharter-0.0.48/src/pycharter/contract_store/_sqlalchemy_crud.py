"""SQLAlchemy CRUD operations for schemas and contracts in the contract store.

Artifact operations (metadata, coercion/validation rules, field mappings) live
in ``_sqlalchemy_artifacts``.  This module composes both mixins into
``_SQLAlchemyContractStoreBase``.

Internal module -- import the public stores from ``pycharter.contract_store``.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from pycharter.contract_store._sqlalchemy_artifacts import _SQLAlchemyArtifactsMixin
from pycharter.contract_store._sqlalchemy_connection import _SQLAlchemyConnectionMixin
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.schema import SchemaModel

logger = logging.getLogger(__name__)


class _SQLAlchemyContractStoreBase(
    _SQLAlchemyArtifactsMixin,
    _SQLAlchemyConnectionMixin,
):
    """Shared SQLAlchemy CRUD logic for SQLite and PostgreSQL contract stores.

    Inherits engine/session lifecycle from ``_SQLAlchemyConnectionMixin`` and
    artifact operations from ``_SQLAlchemyArtifactsMixin``.
    Subclasses must validate the connection string in ``__init__`` and
    implement ``connect()`` calling ``_connect_engine()``.
    """

    def store_schema(
        self,
        contract_name: str,
        contract_version: str,
        schema: dict[str, Any],
    ) -> str:
        """Store a schema for the given data contract. Returns contract ID."""
        session = self._get_session()

        schema_artifact_version = schema.get("version")
        if not schema_artifact_version:
            schema = dict(schema)
            schema["version"] = contract_version
            schema_artifact_version = contract_version
        elif "version" not in schema:
            schema = dict(schema)
            schema["version"] = schema_artifact_version

        data_contract_id = self._get_or_create_data_contract(
            contract_name=contract_name,
            version=contract_version,
            description=schema.get("description"),
        )

        from pycharter.shared.name_validator import (
            validate_name,
            validate_schema_table_names,
        )

        _name = validate_name(contract_name, field_name="contract_name")
        title = schema.get("title") or _name
        if title:
            title = validate_name(str(title), field_name="schema.title")

        validate_schema_table_names(schema)

        # Check for duplicate
        existing = (
            session.query(SchemaModel)
            .filter(
                SchemaModel.title == title,
                SchemaModel.version == schema_artifact_version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Schema with title '{title}' and version "
                f"'{schema_artifact_version}' already exists."
            )

        schema_obj = SchemaModel(
            title=title,
            data_contract_id=uuid.UUID(data_contract_id),
            version=schema_artifact_version,
            schema_data=schema,
        )
        session.add(schema_obj)
        session.flush()

        # Update data_contract.schema_id
        dc = session.query(DataContractModel).get(uuid.UUID(data_contract_id))
        if dc:
            dc.schema_id = schema_obj.id
        session.commit()
        return data_contract_id

    def get_schema(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve the schema for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("schema_id"):
            return None
        return self._get_schema_by_id(row["schema_id"])

    def _get_schema_by_id(self, schema_id: str) -> dict[str, Any] | None:
        """Load schema by id."""
        session = self._get_session()
        row = session.query(SchemaModel).get(uuid.UUID(schema_id))
        if not row:
            return None
        schema_data = row.schema_data
        if isinstance(schema_data, str):
            schema_data = json.loads(schema_data)
        if schema_data and "version" not in schema_data:
            schema_data = dict(schema_data)
            schema_data["version"] = row.version or "1.0.0"
        return schema_data

    def list_contracts(self) -> list[dict[str, Any]]:
        """List all data contracts."""
        session = self._get_session()
        rows = (
            session.query(DataContractModel)
            .order_by(DataContractModel.name, DataContractModel.version)
            .all()
        )
        return [
            {
                "id": str(r.id),
                "name": r.name,
                "version": r.version,
                "schema_id": str(r.schema_id) if r.schema_id else None,
            }
            for r in rows
        ]
