"""MongoDB CRUD operations for schemas and metadata records.

Implements contract helpers, schema store/get, list_contracts,
and contract store get/store backed by MongoDB collections.
"""

from __future__ import annotations

from typing import Any

from pycharter.contract_store._mongodb_connection import MongoDBConnectionMixin


class MongoDBOperationsMixin(MongoDBConnectionMixin):
    """Mixin providing core MongoDB operations for the contract store.

    Builds on ``MongoDBConnectionMixin`` (connection lifecycle) and implements
    contract helpers, schema operations, list_contracts, and metadata operations.

    This is not meant to be instantiated directly. Use
    ``MongoDBContractStore`` from ``pycharter.contract_store.mongodb``.
    """

    # ------------------------------------------------------------------
    # Data contract helpers
    # ------------------------------------------------------------------

    def _get_or_create_data_contract(
        self,
        contract_name: str,
        version: str,
        status: str = "active",
        description: str | None = None,
    ) -> str:
        """Get or create a data_contract record.

        Returns:
            Data contract ID as string.
        """
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        from pycharter.shared.name_validator import validate_name

        contract_name = validate_name(contract_name, field_name="contract_name")

        existing = self._db.data_contracts.find_one(
            {"name": contract_name, "version": version}
        )
        if existing:
            return str(existing["_id"])

        from bson import ObjectId

        data_contract_id = ObjectId()
        doc = {
            "_id": data_contract_id,
            "name": contract_name,
            "version": version,
            "status": status,
            "description": description,
        }
        self._db.data_contracts.insert_one(doc)
        return str(data_contract_id)

    def _resolve_data_contract(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Resolve (contract_name, contract_version) to a data_contract doc.

        Returns:
            Dict with id, schema_id, etc. or None if not found.
        """
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        doc = self._db.data_contracts.find_one(
            {"name": contract_name, "version": contract_version}
        )
        if not doc:
            return None
        return {
            "id": doc["_id"],
            "schema_id": doc.get("schema_id"),
            "coercion_rules_id": doc.get("coercion_rules_id"),
            "validation_rules_id": doc.get("validation_rules_id"),
            "metadata_record_id": doc.get("metadata_record_id"),
        }

    # ------------------------------------------------------------------
    # Schema operations
    # ------------------------------------------------------------------

    def _get_schema_by_id(self, schema_id: Any) -> dict[str, Any] | None:
        """Load schema by _id (internal use)."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        doc = self._db.schemas.find_one({"_id": schema_id})
        if not doc:
            return None
        schema_data = doc.get("schema_data") or doc.get("schema")
        if not schema_data:
            return None
        if "version" not in schema_data:
            schema_data = dict(schema_data)
            schema_data["version"] = doc.get("version") or "1.0.0"
        return schema_data

    def store_schema(
        self,
        contract_name: str,
        contract_version: str,
        schema: dict[str, Any],
    ) -> str:
        """Store a schema for the given data contract.

        Returns:
            Contract ID (string).
        """
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")

        schema_artifact_version = schema.get("version")
        if not schema_artifact_version:
            schema = dict(schema)
            schema["version"] = contract_version
            schema_artifact_version = contract_version
        elif "version" not in schema:
            schema = dict(schema)
            schema["version"] = schema_artifact_version

        from bson import ObjectId

        data_contract_id_str = self._get_or_create_data_contract(
            contract_name=contract_name,
            version=contract_version,
            description=schema.get("description"),
        )
        data_contract_id: Any = ObjectId(data_contract_id_str)

        from pycharter.shared.name_validator import (
            validate_name,
            validate_schema_table_names,
        )

        title = schema.get("title") or contract_name
        if title:
            title = validate_name(str(title), field_name="schema.title")

        validate_schema_table_names(schema)

        existing = self._db.schemas.find_one(
            {"title": title, "version": schema_artifact_version}
        )
        if existing:
            raise ValueError(
                f"Schema with title '{title}' and version "
                f"'{schema_artifact_version}' already exists."
            )
        schema_id = ObjectId()
        doc = {
            "_id": schema_id,
            "title": title,
            "data_contract_id": data_contract_id,
            "version": schema_artifact_version,
            "schema_data": schema,
        }
        self._db.schemas.insert_one(doc)
        self._db.data_contracts.update_one(
            {"_id": data_contract_id},
            {"$set": {"schema_id": schema_id}},
        )
        return data_contract_id_str

    def get_schema(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve the schema for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("schema_id"):
            return None
        return self._get_schema_by_id(row["schema_id"])

    def list_contracts(self) -> list[dict[str, Any]]:
        """List all data contracts with name, version, and optional id/schema_id."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        result = []
        for doc in self._db.data_contracts.find(
            {}, {"_id": 1, "name": 1, "version": 1, "schema_id": 1}
        ):
            result.append(
                {
                    "id": str(doc["_id"]),
                    "name": doc["name"],
                    "version": doc["version"],
                    "schema_id": (
                        str(doc["schema_id"]) if doc.get("schema_id") else None
                    ),
                }
            )
        return result

    # ------------------------------------------------------------------
    # Metadata operations
    # ------------------------------------------------------------------

    def store_metadata(
        self,
        contract_name: str,
        contract_version: str,
        metadata: dict[str, Any],
    ) -> str:
        """Store metadata for the given data contract. Contract must exist."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ "
                f"{contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = metadata.get("title")
        if not title:
            title = (
                normalize_name(f"metadata_for_{contract_name}_{contract_version}")
                or "metadata"
            )
        normalized_title = normalize_name(str(title))
        if not normalized_title:
            raise ValueError(
                f"metadata.title '{title}' cannot be normalized to a valid name."
            )
        title = validate_name(normalized_title, field_name="metadata.title")
        version = contract_version
        status = metadata.get("status", "active")
        description = metadata.get("description")
        governance_rules = metadata.get("governance_rules")

        from bson import ObjectId

        existing = self._db.metadata_records.find_one(
            {"title": title, "version": version}
        )
        if existing:
            metadata_id = existing["_id"]
            self._db.metadata_records.update_one(
                {"_id": metadata_id},
                {
                    "$set": {
                        "title": title,
                        "status": status,
                        "description": description,
                        "governance_rules": governance_rules,
                    }
                },
            )
        else:
            metadata_id = ObjectId()
            self._db.metadata_records.insert_one(
                {
                    "_id": metadata_id,
                    "title": title,
                    "data_contract_id": data_contract_id,
                    "version": version,
                    "status": status,
                    "description": description,
                    "governance_rules": governance_rules,
                }
            )
        self._db.data_contracts.update_one(
            {"_id": data_contract_id},
            {"$set": {"metadata_record_id": metadata_id}},
        )
        return str(metadata_id)

    def get_metadata(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve metadata for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("metadata_record_id"):
            return None
        return self._get_metadata_by_id(row["metadata_record_id"])

    def _get_metadata_by_id(self, metadata_id: Any) -> dict[str, Any] | None:
        """Load metadata by _id (internal use)."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")

        from bson import ObjectId

        try:
            metadata_obj_id: Any = ObjectId(metadata_id)
        except Exception:
            metadata_obj_id = metadata_id

        doc = self._db.metadata_records.find_one({"_id": metadata_obj_id})
        if not doc:
            return None

        # Reconstruct metadata dictionary
        result: dict[str, Any] = {
            "title": doc.get("title"),
            "status": doc.get("status"),
            "type": doc.get("type"),
            "description": doc.get("description"),
            "version": doc.get("version"),
        }

        # Add JSON fields
        if doc.get("governance_rules"):
            result["governance_rules"] = doc.get("governance_rules")

        # Add relationship fields if present
        relationship_fields = [
            "business_owners",
            "bu_sme",
            "it_application_owners",
            "it_sme",
            "support_lead",
            "domains",
            "system_sources",
            "system_pulls",
            "system_pushes",
        ]
        for field in relationship_fields:
            if field in doc:
                result[field] = doc[field]

        return result
