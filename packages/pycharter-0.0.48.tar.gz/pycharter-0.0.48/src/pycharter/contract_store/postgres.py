"""PostgreSQL contract store implementation.

Thin wrapper around ``_SQLAlchemyContractStoreBase`` that validates the
connection string and sets the ``pycharter`` schema.
"""

from __future__ import annotations

import copy
import logging
from typing import Any

from sqlalchemy import inspect

from pycharter.contract_store._sqlalchemy_base import _SQLAlchemyContractStoreBase

logger = logging.getLogger(__name__)

try:
    from pycharter.config import get_database_url
except ImportError:

    def get_database_url() -> str | None:  # type: ignore[misc]
        """Stub when config module is unavailable."""
        return None


class PostgresContractStore(_SQLAlchemyContractStoreBase):
    """PostgreSQL-backed contract store.

    Stores contracts in PostgreSQL tables within the ``pycharter`` schema.

    Usage::

        store = PostgresContractStore("postgresql://user:pass@localhost/pycharter")
        store.connect()

    If *connection_string* is ``None``, resolves from env / config.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        schema_name: str = "pycharter",
    ) -> None:
        resolved = connection_string or get_database_url()
        if not resolved:
            raise ValueError(
                "connection_string is required. Provide it directly, or configure it via:\n"
                "  - Environment variable: PYCHARTER_DATABASE_URL\n"
                "  - Config file: pycharter.cfg [database] PYCHARTER_DATABASE_URL\n"
                "  - Config file: alembic.ini sqlalchemy.url"
            )
        if not resolved.startswith(("postgresql://", "postgres://")):
            raise ValueError(
                f"PostgresContractStore requires a postgresql:// URL, got: {resolved!r}"
            )
        super().__init__(resolved)
        self._pg_schema_name = schema_name

    def connect(
        self,
        validate_schema_on_connect: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Connect to the PostgreSQL database.

        Args:
            validate_schema_on_connect: Check that required tables exist.
            auto_initialize: Create tables if missing (default ``False`` —
                use ``pycharter db init`` for production PostgreSQL).
        """
        self._connect_engine(
            schema_name=self._pg_schema_name,
            validate_schema=validate_schema_on_connect,
            auto_initialize=auto_initialize,
        )

    def _has_contract_versions_table(self) -> bool:
        """Return True if the semantic table contract_versions exists."""
        if self._engine is None:
            return False
        try:
            insp = inspect(self._engine)
            tables = insp.get_table_names(schema=self._schema_name)
            return "contract_versions" in tables
        except Exception:
            return False

    def store_field_mapping(
        self,
        contract_name: str,
        contract_version: str,
        field_mapping: dict[str, Any],
    ) -> str:
        """Store field mapping in the semantic contract_versions table."""
        if not self._has_contract_versions_table():
            raise RuntimeError(
                "Field mapping storage requires semantic tables. "
                "Run 'pycharter db upgrade' to add the contract_versions table."
            )
        from pycharter.db.models.semantic.contract_version import ContractVersionModel

        contract_id = f"{contract_name}@{contract_version}"
        session = self._get_session()
        version = ContractVersionModel(
            contract_id=contract_id,
            content=field_mapping,
            message="Stored via contract store",
            author="pycharter",
            created_by="pycharter",
        )
        session.add(version)
        session.flush()
        return str(version.id)

    def get_field_mapping(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve field mapping from the semantic contract_versions table."""
        if not self._has_contract_versions_table():
            return None
        from pycharter.db.models.semantic.contract_version import ContractVersionModel

        contract_id = f"{contract_name}@{contract_version}"
        session = self._get_session()
        row = (
            session.query(ContractVersionModel)
            .filter(ContractVersionModel.contract_id == contract_id)
            .order_by(ContractVersionModel.created_at.desc())
            .first()
        )
        if row is None:
            return None
        return copy.deepcopy(row.content)
