"""Protocol definitions for pluggable contract store backends.

Protocols define the duck-typed interface for contract persistence.
The ABC ``ContractStoreClient`` remains the primary base class for
concrete backends; these protocols enable structural subtyping and
dependency injection without requiring inheritance.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SchemaStore(Protocol):
    """Protocol for schema persistence."""

    def store_schema(
        self,
        contract_name: str,
        contract_version: str,
        schema: dict[str, Any],
    ) -> str:
        """Store a JSON Schema for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.
            schema: JSON Schema dictionary.

        Returns:
            Contract ID or identifier.
        """
        ...

    def get_schema(
        self,
        contract_name: str,
        contract_version: str,
    ) -> dict[str, Any] | None:
        """Retrieve the schema for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            Schema dictionary or None if not found.
        """
        ...


@runtime_checkable
class ValidationRuleStore(Protocol):
    """Protocol for validation rule persistence."""

    def store_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
        rules: dict[str, Any],
    ) -> str:
        """Store validation rules for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.
            rules: Validation rules dictionary.

        Returns:
            Validation rules ID or identifier.
        """
        ...

    def get_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
    ) -> dict[str, Any] | None:
        """Retrieve validation rules for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            Validation rules dictionary or None if not found.
        """
        ...


@runtime_checkable
class CoercionRuleStore(Protocol):
    """Protocol for coercion rule persistence."""

    def store_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
        rules: dict[str, Any],
    ) -> str:
        """Store coercion rules for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.
            rules: Coercion rules dictionary.

        Returns:
            Coercion rules ID or identifier.
        """
        ...

    def get_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
    ) -> dict[str, Any] | None:
        """Retrieve coercion rules for the given data contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            Coercion rules dictionary or None if not found.
        """
        ...


@runtime_checkable
class ContractStore(Protocol):
    """Full contract persistence protocol.

    Covers the core read/list/delete operations for contracts.
    """

    def get_contract(
        self,
        contract_name: str,
        contract_version: str,
    ) -> dict[str, Any] | None:
        """Retrieve the full contract for the given name and version.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            Contract dictionary or None if not found.
        """
        ...

    def list_contracts(self) -> list[dict[str, Any]]:
        """List all stored data contracts.

        Returns:
            List of contract summary dicts.
        """
        ...

    def delete_contract(
        self,
        contract_name: str,
        contract_version: str,
    ) -> bool:
        """Delete a contract by name and version.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            True if the contract was deleted, False if not found.
        """
        ...


@runtime_checkable
class VersionedContractStore(Protocol):
    """Contract store with optimistic locking.

    Tracks a monotonically increasing revision per contract.
    ``save_contract_versioned`` raises on revision mismatch.
    """

    def get_contract_versioned(
        self,
        contract_name: str,
        contract_version: str,
    ) -> tuple[dict[str, Any] | None, int | None]:
        """Return ``(contract, revision)`` for the contract.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.

        Returns:
            Tuple of (contract dict or None, revision or None).
        """
        ...

    def save_contract_versioned(
        self,
        contract_name: str,
        contract_version: str,
        contract: dict[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> int:
        """Save contract with optimistic locking.

        Args:
            contract_name: Data contract name.
            contract_version: Data contract version.
            contract: Contract dict to persist.
            expected_revision: Expected current revision.

        Returns:
            The new revision number.
        """
        ...
