# 02 — Single source (HTTP API)

Extract from a REST API (GET), apply a simple transform, load to JSON file.

## What it demonstrates

- Single source extraction (HTTP/API)
- Simple transformation (rename, select)
- File load (JSON)

## Files

| File | Purpose |
|------|---------|
| `extract.yaml` | GET request to mock API (jsonplaceholder) |
| `transform.yaml` | Rename and select fields |
| `load.yaml` | Write to JSON |
| `pipeline.yaml` | Single-file section-based pipeline |

## How to run

From the **pycharter repo root**:

```bash
pycharter etl run data/etl_examples/02_single_source_http
```

Requires network access. Output is written to `output.json` in this directory (or `OUTPUT_PATH`). Set `API_URL` to use a different endpoint.
