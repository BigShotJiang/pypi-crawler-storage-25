# Quality SLA Check Example

Demonstrates how `data_quality.sla` thresholds in a data contract flow into quality checks and ETL pipeline validation.

## Data Flow

```
input.csv (8 aircraft records, 3 with intentional errors)
    │
    ├─ ETL Pipeline (Path 1)
    │   ├─ Extract → read CSV
    │   ├─ Transform → coerce types (int conversions)
    │   ├─ Validate against contract schema (pre-load)
    │   │   ├─ Valid records → load to output.csv
    │   │   └─ Invalid records → DLQ (with linked violation IDs)
    │   └─ Post-load quality checks (row_count, null_rate, uniqueness)
    │
    └─ QualityCheck.run() (Path 2)
        ├─ Validate all records against contract schema
        ├─ Calculate quality scores (overall, accuracy, completeness)
        ├─ Auto-resolve SLA from contract.metadata.data_quality.sla
        └─ Report threshold breaches
```

## How SLA Thresholds Work

The contract's `metadata.data_quality.sla` section defines quality thresholds:

```yaml
# contract.yaml → metadata → data_quality → sla
sla:
  min_overall_score: 90.0     # overall quality score must be >= 90
  max_violation_rate: 0.10    # at most 10% of records may have violations
  min_completeness: 0.95      # 95% of required fields must be present
  min_accuracy: 0.90          # 90% of records must pass schema validation
```

When `QualityCheck.run()` is called with `check_thresholds=True`:

1. It calls `QualityThresholds.from_contract(contract)` to extract the SLA
2. After validation, it compares quality scores against the thresholds
3. Any score below its threshold is reported as a **breach** in the `QualityReport`

This happens automatically — no need to pass thresholds explicitly.

## Intentional Data Errors

The input CSV has 8 records with 3 that violate the contract:

| Row | Registration | Error | Impact |
|-----|-------------|-------|--------|
| 4 | BLXI | Missing `VALID_SINCE` (required) | Quarantined to DLQ |
| 6 | BPCA | `AC_STATE='X'` (not in enum `[R, O]`) | Quarantined to DLQ |
| 7 | *(empty)* | Missing `REGISTRATION` (required) | Quarantined to DLQ |

With 3/8 records invalid (37.5% violation rate), the SLA breaches will include:
- `max_violation_rate`: 0.375 > 0.10
- `min_accuracy`: 0.625 < 0.90
- `min_overall_score`: likely < 90.0

## Files

| File | Purpose |
|------|---------|
| `contract.yaml` | Data contract with schema + SLA thresholds |
| `input.csv` | 8 aircraft records (3 intentionally invalid) |
| `extract.yaml` | ETL extract config |
| `transform.yaml` | ETL transform config (type coercion) |
| `load.yaml` | ETL load config with contract validation + quality checks |
| `run_quality_check.py` | Script demonstrating both ETL and QualityCheck paths |

## Running

From the pycharter repo root:

```bash
# Run the demo script (shows both ETL pipeline and QualityCheck paths)
python data/etl_examples/06_quality_sla_check/run_quality_check.py

# Or run just the ETL pipeline via config directory
python -c "
import asyncio
from pycharter.pipeline_generator import Pipeline
async def main():
    p = Pipeline.from_config_dir('data/etl_examples/06_quality_sla_check')
    r = await p.run()
    print(r)
asyncio.run(main())
"
```

## Two Quality Systems

pycharter has two complementary quality systems:

| System | Module | When | What it checks |
|--------|--------|------|----------------|
| **Post-load checks** | `pycharter.pipeline_generator.quality` | After pipeline load | Row count, null rate, uniqueness, expressions |
| **Contract quality checks** | `pycharter.quality.check` | Standalone or API | Schema validation, quality scores, SLA thresholds |

The **post-load checks** are configured in `load.yaml` under `quality_checks` and run as part of the ETL pipeline.

The **contract quality checks** use `QualityCheck.run()` and are orchestrator-agnostic — they can be called from CLI, API, Airflow, or any Python code. This is where SLA threshold resolution from the contract happens.
