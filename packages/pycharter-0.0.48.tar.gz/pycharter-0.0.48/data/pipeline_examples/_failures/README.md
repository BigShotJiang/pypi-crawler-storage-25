# Failure examples

These subdirectories contain **section-based** ETL configs that are intended to **fail** when run. They are useful for testing error handling in the dashboard, API, or CLI.

| Directory | Purpose |
|-----------|---------|
| `missing_file/` | Extract points to a non-existent file |
| `invalid_write_mode/` | Load uses an invalid write mode |
| `invalid_extract_type/` | Extract uses an unsupported type |

## How to run

Run via API/UI (paste extract/transform/load from the example dir) or CLI; expect a failure. For example:

```bash
pycharter etl run data/etl_examples/_failures/missing_file
```

(Exit code will be non-zero.)
