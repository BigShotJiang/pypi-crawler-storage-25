# 05 — Multiple load destinations (step-based)

One CSV extract, simple transform, load to **two** destinations (CSV and JSON).

## What it demonstrates

- Single source extraction
- Simple transformation
- **Multiple load** steps (fan-out: same data to CSV and JSON)

This example uses the **step-based** pipeline format.

## Files

| File | Purpose |
|------|---------|
| `pipeline.yaml` | Step-based config (extract, transform, load x2) |
| `input.csv` | Mock products data |

## How to run

From the **pycharter repo root**:

```python
import asyncio
from pycharter import Pipeline

pipeline = Pipeline.from_file("data/etl_examples/05_multi_load/pipeline.yaml")
result = asyncio.run(pipeline.run())
print(f"Rows loaded: {result.rows_loaded}")
```

Output is written to `output.csv` and `output.json` in this directory.
