from telebot import types,util
from telebot.async_telebot import AsyncTeleBot

bot = AsyncTeleBot('TOKEN')

#chat_member_handler. When status changes, telegram gives update. check status from old_chat_member and new_chat_member.
@bot.chat_member_handler()
async def chat_m(message: types.ChatMemberUpdated):
    old = message.old_chat_member
    new = message.new_chat_member
    if new.status == "member":
        await bot.send_message(message.chat.id,"Hello {name}!".format(name=new.user.first_name)) # Welcome message

#if bot is added to group, this handler will work
@bot.my_chat_member_handler()
async def my_chat_m(message: types.ChatMemberUpdated):
    old = message.old_chat_member
    new = message.new_chat_member
    if new.status == "member":
        await bot.send_message(message.chat.id,"Somebody added me to group") # Welcome message, if bot was added to group
        await bot.leave_chat(message.chat.id)

#content_Type_service is:
#'new_chat_members', 'left_chat_member', 'new_chat_title', 'new_chat_photo', 'delete_chat_photo', 'group_chat_created',
#'supergroup_chat_created', 'channel_chat_created', 'migrate_to_chat_id', 'migrate_from_chat_id', 'pinned_message',
#'proximity_alert_triggered', 'video_chat_scheduled', 'video_chat_started', 'video_chat_ended', 
#'video_chat_participants_invited', 'message_auto_delete_timer_changed'
# this handler deletes service messages

@bot.message_handler(content_types=util.content_type_service)
async def delall(message: types.Message):
    await bot.delete_message(message.chat.id,message.message_id)


@bot.message_handler(commands=['set_tag'])
async def set_tag(message: types.Message):
    tag = util.extract_arguments(message.text)
    if not tag:
        await bot.reply_to(message, "Usage: /set_tag your_tag")
        return
    await bot.set_chat_member_tag(message.chat.id, message.from_user.id, tag=tag)
    await bot.reply_to(message, f"Tag updated: {tag}")


import asyncio
asyncio.run(bot.polling(allowed_updates=util.update_types))
