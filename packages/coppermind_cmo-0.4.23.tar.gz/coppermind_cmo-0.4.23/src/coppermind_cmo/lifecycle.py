"""Centralized lifecycle state machines for EOS entities.

Defines allowed status transitions and field-reset rules for agenda items
and issues. Rocks and deliverables are free-form (any->any).
"""

from __future__ import annotations

# ---------- Entity type constants ----------
ENTITY_AGENDA = "agenda"
ENTITY_ISSUE = "issue"
ENTITY_ROCK = "rock"
ENTITY_DELIVERABLE = "deliverable"

# ---------- Sentinel for "use SQL now()" ----------
_NOW = object()

# ---------- Transition maps ----------
# {from_status: {allowed_to_statuses}}

AGENDA_TRANSITIONS: dict[str, set[str]] = {
    "proposed": {"scheduled", "resolved", "deferred"},
    "scheduled": {"discussed", "resolved", "deferred"},
    "discussed": {"resolved", "deferred", "scheduled"},
    "resolved": {"scheduled"},
    "deferred": {"scheduled"},
}

ISSUE_TRANSITIONS: dict[str, set[str]] = {
    "identified": {"discussed", "solved", "deferred"},
    "discussed": {"solved", "deferred"},
    "solved": {"discussed"},
    "deferred": {"discussed"},
}

_TRANSITIONS: dict[str, dict[str, set[str]] | None] = {
    ENTITY_AGENDA: AGENDA_TRANSITIONS,
    ENTITY_ISSUE: ISSUE_TRANSITIONS,
    ENTITY_ROCK: None,       # free-form
    ENTITY_DELIVERABLE: None,  # free-form
}

# ---------- Field reset rules ----------
# Per target status: {"set": {field: value}, "clear": [field, ...]}
# _NOW sentinel: caller replaces with SQL now() or Python datetime

AGENDA_FIELD_RULES: dict[str, dict] = {
    "resolved": {"set": {"resolved_at": _NOW}, "clear": []},
    "deferred": {"set": {"resolved_at": _NOW}, "clear": []},
    "scheduled": {"set": {}, "clear": ["resolved_at"]},
    "discussed": {"set": {}, "clear": []},
    "proposed": {"set": {}, "clear": ["resolved_at", "meeting_date"]},
}

ISSUE_FIELD_RULES: dict[str, dict] = {
    "solved": {"set": {"resolved_at": _NOW}, "clear": []},
    "deferred": {"set": {}, "clear": ["resolved_at", "resolution", "commitment_id"]},
    "discussed": {"set": {}, "clear": ["resolved_at", "resolution", "commitment_id"]},
    "identified": {"set": {}, "clear": ["resolved_at", "resolution", "commitment_id"]},
}

_FIELD_RULES: dict[str, dict[str, dict]] = {
    ENTITY_AGENDA: AGENDA_FIELD_RULES,
    ENTITY_ISSUE: ISSUE_FIELD_RULES,
    ENTITY_ROCK: {},
    ENTITY_DELIVERABLE: {},
}


class InvalidTransition(Exception):
    """Raised when a status transition is not allowed."""
    def __init__(self, entity_type: str, from_status: str, to_status: str):
        self.entity_type = entity_type
        self.from_status = from_status
        self.to_status = to_status
        super().__init__(f"Invalid {entity_type} transition: {from_status} -> {to_status}")


def validate_transition(entity_type: str, from_status: str, to_status: str) -> None:
    """Raise InvalidTransition if the transition is not allowed.
    Free-form entities (rocks, deliverables) always pass.
    """
    transitions = _TRANSITIONS.get(entity_type)
    if transitions is None:
        return
    allowed = transitions.get(from_status)
    if allowed is None or to_status not in allowed:
        raise InvalidTransition(entity_type, from_status, to_status)


def get_transition_fields(entity_type: str, to_status: str) -> dict:
    """Return field rules for entering to_status.
    Returns: {"set": {field: value}, "clear": [field, ...]}
    Values of _NOW should be replaced by caller with SQL now().
    """
    rules = _FIELD_RULES.get(entity_type, {})
    entry = rules.get(to_status)
    if entry is None:
        return {"set": {}, "clear": []}
    return {"set": dict(entry.get("set", {})), "clear": list(entry.get("clear", []))}


def is_now_sentinel(value) -> bool:
    """Check if a field value is the NOW sentinel."""
    return value is _NOW
