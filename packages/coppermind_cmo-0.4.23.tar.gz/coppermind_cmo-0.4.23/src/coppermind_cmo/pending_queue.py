"""Local fallback queue for failed DB writes.

Saves payloads as JSON files under ~/.coppermind/pending/ so they can be
replayed when the database becomes reachable again.

Design decisions:
- Content hash in filename for O(1) dedup (no need to read files)
- fsync + rename for atomic writes (no partial files on crash)
- Directory mode 0o700 for security (only owner can read pending data)
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

from coppermind_cmo.log import ToolLogger

_log = ToolLogger("pending_queue")

PENDING_DIR = Path.home() / ".coppermind" / "pending"
MAX_PENDING = 500
MAX_AGE_DAYS = 30


def _ensure_dir() -> None:
    """Create PENDING_DIR with mode 0o700 if it doesn't exist."""
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(PENDING_DIR, 0o700)


def _dedup_key(mind_id: str, content: str) -> str:
    """Full SHA-256 of mind_id + content for dedup."""
    h = hashlib.sha256()
    h.update(mind_id.encode("utf-8"))
    h.update(content.encode("utf-8"))
    return h.hexdigest()


def enqueue(payload: dict[str, Any]) -> Path | None:
    """Save a payload to the pending queue.

    Returns the Path to the written file, or None if the queue is full
    or a duplicate already exists.
    """
    _ensure_dir()

    # Check queue capacity
    existing = list(PENDING_DIR.glob("*.json"))
    if len(existing) >= MAX_PENDING:
        _log.warn("Pending queue full", count=len(existing), max=MAX_PENDING)
        return None

    mind_id = payload.get("mind_id", "")
    content = payload.get("content", "")
    digest = _dedup_key(mind_id, content)
    short_hash = digest[:16]

    # Dedup: check if any existing file has the same content hash
    for f in existing:
        if short_hash in f.name:
            _log.info("Dedup hit, skipping enqueue", mind_id=mind_id)
            return None

    # Convert numpy-like embeddings to plain list
    embedding = payload.get("embedding")
    if embedding is not None and hasattr(embedding, "tolist"):
        payload = dict(payload)  # shallow copy to avoid mutating caller
        payload["embedding"] = embedding.tolist()

    # Add metadata
    payload_with_meta = dict(payload)
    payload_with_meta["_meta"] = {
        "enqueued_at": time.time(),
        "dedup_key": digest,
    }

    # Atomic write: write to .tmp, fsync, rename
    timestamp = str(int(time.time() * 1000))
    filename = f"{timestamp}_{short_hash}.json"
    final_path = PENDING_DIR / filename
    tmp_path = PENDING_DIR / f"{filename}.tmp"

    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload_with_meta, f)
            f.flush()
            os.fsync(f.fileno())
        tmp_path.rename(final_path)
        _log.info("Enqueued pending write", mind_id=mind_id, path=str(final_path))
        return str(final_path)
    except OSError as exc:
        _log.error("Failed to enqueue", mind_id=mind_id, error=str(exc))
        # Clean up tmp file if rename failed
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
        return None


def count() -> int:
    """Return the number of pending items."""
    if not PENDING_DIR.exists():
        return 0
    return len(list(PENDING_DIR.glob("*.json")))


def clear() -> None:
    """Remove all pending items and stale tmp files."""
    if not PENDING_DIR.exists():
        return
    for f in PENDING_DIR.iterdir():
        if f.is_file():
            f.unlink()
    _log.info("Cleared pending queue")


def list_pending() -> list[dict[str, Any]]:
    """Return summaries of all pending items.

    Each summary contains mind_id, enqueued_at, and summary.
    Corrupt files are returned as {"error": "corrupt"}.
    """
    if not PENDING_DIR.exists():
        return []

    items: list[dict[str, Any]] = []
    for f in sorted(PENDING_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            meta = data.get("_meta", {})
            items.append({
                "mind_id": data.get("mind_id", "unknown"),
                "enqueued_at": meta.get("enqueued_at"),
                "summary": data.get("summary", ""),
                "filename": f.name,
            })
        except (json.JSONDecodeError, OSError):
            items.append({"error": "corrupt", "filename": f.name})
    return items


def drain(db: Any, config: Any) -> dict[str, Any]:
    """Replay all pending JSON files through store_memory_core().

    Uses a circuit breaker: after the first replay failure (exception or
    error return), stop draining immediately. Remaining files are counted
    as "skipped" to avoid blowing the 25-second startup watchdog.

    Returns {"recovered": int, "failed": int, "expired": int, "skipped": int, "details": list[dict]}
    """
    # Late import to avoid circular dependency at module level
    from coppermind_cmo.tools.memories import store_memory_core

    result: dict[str, Any] = {
        "recovered": 0,
        "failed": 0,
        "expired": 0,
        "skipped": 0,
        "details": [],
    }

    if not PENDING_DIR.exists():
        return result

    files = sorted(PENDING_DIR.glob("*.json"))
    if not files:
        return result

    circuit_broken = False
    now = time.time()
    max_age_seconds = MAX_AGE_DAYS * 86400

    for f in files:
        if circuit_broken:
            result["skipped"] += 1
            continue

        # -- Parse file --
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            _log.warn("Corrupt pending file, deleting", filename=f.name)
            f.unlink(missing_ok=True)
            result["failed"] += 1
            continue

        meta = data.get("_meta", {})
        enqueued_at = meta.get("enqueued_at", 0)

        # -- Check age --
        if (now - enqueued_at) > max_age_seconds:
            _log.info("Expired pending file", filename=f.name, age_days=(now - enqueued_at) / 86400)
            f.unlink(missing_ok=True)
            result["expired"] += 1
            continue

        # -- Resolve mind --
        mind_id = data.get("mind_id", "")
        row = db.fetch_one(
            "SELECT id, name FROM client_minds WHERE id = %s", [mind_id]
        )
        if row is None:
            _log.info("Mind no longer exists, expiring", mind_id=mind_id, filename=f.name)
            f.unlink(missing_ok=True)
            result["expired"] += 1
            continue

        active_mind = (row[0], row[1])

        # -- Replay through store_memory_core --
        try:
            resp = store_memory_core(
                content=data.get("content", ""),
                memory_type=data.get("memory_type"),
                tags=data.get("tags", []),
                db=db,
                config=config,
                active_mind=active_mind,
                source_tool="pending_queue_drain",
                summary=data.get("summary"),
                embedding=data.get("embedding"),
                confidence=data.get("confidence"),
                source_type=data.get("source_type", "manual"),
                source_ref=data.get("source_ref"),
                is_private=data.get("is_private", False),
                sensitivity=data.get("sensitivity"),
                _skip_enqueue=True,
            )
        except Exception as exc:
            _log.error("Drain replay failed", filename=f.name, error=str(exc))
            result["failed"] += 1
            circuit_broken = True
            continue

        # Check for error return from store_memory_core
        if "error" in resp:
            _log.error("Drain replay returned error", filename=f.name, error=resp)
            result["failed"] += 1
            circuit_broken = True
            continue

        # -- Success --
        f.unlink(missing_ok=True)
        result["recovered"] += 1
        result["details"].append({
            "mind_id": mind_id,
            "mind_name": active_mind[1],
            "content_preview": data.get("content", "")[:60],
            "memory_id": resp.get("memory_id"),
        })
        _log.info("Recovered pending memory", mind_id=mind_id, memory_id=resp.get("memory_id"))

    return result


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "count"
    if cmd == "count":
        print(f"Pending items: {count()}")
    elif cmd == "list":
        items = list_pending()
        if not items:
            print("No pending items.")
        for item in items:
            if "error" in item:
                print(f"  {item['filename']}: CORRUPT")
            else:
                print(f"  {item['filename']}: {item['summary']} ({item['enqueued_at']})")
    elif cmd == "clear":
        n = count()
        clear()
        print(f"Cleared {n} pending items.")
    elif cmd == "drain":
        print("Drain requires a DB connection. Use MCP server startup or:")
        print("  python -c 'from coppermind_cmo.pending_queue import drain; ...'")
    else:
        print(f"Usage: python -m coppermind_cmo.pending_queue [count|list|clear|drain]")
