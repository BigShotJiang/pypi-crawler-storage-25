"""Hex color to ANSI 256-color conversion for terminal rendering."""

import re

HEX_COLOR_RE = re.compile(r'^#[0-9A-Fa-f]{6}$')


def is_valid_hex_color(color: str) -> bool:
    """Check if string is a valid #RRGGBB hex color."""
    return bool(HEX_COLOR_RE.match(color))


def hex_to_ansi256(hex_color: str) -> int:
    """Convert #RRGGBB to nearest ANSI 256-color code using RGB distance."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    # Map to 6x6x6 color cube (codes 16-231)
    ri = round(r / 255 * 5)
    gi = round(g / 255 * 5)
    bi = round(b / 255 * 5)
    return 16 + 36 * ri + 6 * gi + bi


def ansi_colored(text: str, hex_color: str) -> str:
    """Wrap text in ANSI 256-color escape codes."""
    if not is_valid_hex_color(hex_color):
        return text
    code = hex_to_ansi256(hex_color)
    return f"\033[38;5;{code}m{text}\033[0m"
