"""Structured JSON logging to stderr per SERVER_SPEC.md.

Also provides crash logging to ~/.coppermind/server.log — a persistent
log file that survives MCP transport disconnects.
"""

import json
import os
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Persistent log file — always available for crash diagnosis
# ---------------------------------------------------------------------------

_COPPERMIND_DIR = Path.home() / ".coppermind"
_LOG_FILE = _COPPERMIND_DIR / "server.log"
_MAX_LOG_BYTES = 2 * 1024 * 1024  # 2 MB — rotate when exceeded


def _ensure_log_dir():
    _COPPERMIND_DIR.mkdir(parents=True, exist_ok=True)


def _rotate_log_if_needed():
    """Simple size-based rotation: rename to .log.1, start fresh."""
    try:
        if _LOG_FILE.exists() and _LOG_FILE.stat().st_size > _MAX_LOG_BYTES:
            rotated = _LOG_FILE.with_suffix(".log.1")
            _LOG_FILE.replace(rotated)
    except OSError:
        pass


def _write_to_log_file(line: str):
    """Append a line to the persistent log. Never raises."""
    try:
        _ensure_log_dir()
        _rotate_log_if_needed()
        with open(_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()
    except Exception:
        pass  # Logging must never crash the server


def write_crash_log(exc_type, exc_value, exc_tb):
    """Write a crash entry to both stderr and the persistent log file.

    Install as sys.excepthook to capture unhandled exceptions.
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    tb_lines = traceback.format_exception(exc_type, exc_value, exc_tb)
    tb_str = "".join(tb_lines).rstrip()

    crash_entry = {
        "timestamp": timestamp,
        "level": "fatal",
        "tool": "server",
        "message": f"Unhandled {exc_type.__name__}: {exc_value}",
        "traceback": tb_str,
        "pid": os.getpid(),
    }
    json_line = json.dumps(crash_entry)

    # Write to stderr (may reach Claude Desktop log)
    try:
        print("COPPERMIND-CMO: " + json_line, file=sys.stderr, flush=True)
    except Exception:
        pass

    # Write to persistent log file (always readable)
    _write_to_log_file("COPPERMIND-CMO: " + json_line)


class ToolLogger:
    """Emits structured JSON log entries to stderr and the persistent log file."""

    def __init__(self, tool: str):
        self._tool = tool

    def _emit(self, level: str, message: str, *, mind_id: str | None = None,
              duration_ms: float | None = None, **extra):
        entry = {"timestamp": datetime.now(timezone.utc).isoformat()}
        entry.update(extra)
        entry["level"] = level
        entry["tool"] = self._tool
        entry["message"] = message
        entry["mind_id"] = mind_id
        entry["duration_ms"] = duration_ms
        line = "COPPERMIND-CMO: " + json.dumps(entry)
        print(line, file=sys.stderr, flush=True)
        # Also write errors and warnings to the persistent log
        if level in ("error", "warn", "fatal"):
            _write_to_log_file(line)

    # Reserved field names that callers must not override via extra kwargs.
    _RESERVED = frozenset({"timestamp", "level", "tool", "message", "mind_id", "duration_ms"})

    def _sanitize_extra(self, kwargs: dict) -> dict:
        """Strip keys that map to base log fields so they cannot be overridden."""
        return {k: v for k, v in kwargs.items() if k not in self._RESERVED}

    def info(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("info", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def warn(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("warn", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def error(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("error", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)

    def debug(self, message: str, **kwargs):
        extra = self._sanitize_extra(kwargs)
        self._emit("debug", message,
                   mind_id=kwargs.get("mind_id"),
                   duration_ms=kwargs.get("duration_ms"),
                   **extra)
