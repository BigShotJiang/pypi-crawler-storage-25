"""Error response helpers per SERVER_SPEC.md error format."""

from typing import Any


# ---------------------------------------------------------------------------
# Generic error helpers (memory-layer core)
# ---------------------------------------------------------------------------
# These functions are layer-agnostic and will move into the memory-layer
# package unchanged.

def tool_error(code: str, message: str, retryable: bool = False) -> dict[str, Any]:
    result = {"error": True, "code": code, "message": message}
    if retryable:
        result["retryable"] = True
    return result


def NO_ACTIVE_MIND() -> dict[str, Any]:
    return tool_error("NO_ACTIVE_MIND", "No active client. Call switch_client first, then retry.")


def MIND_NOT_FOUND() -> dict[str, Any]:
    return tool_error("MIND_NOT_FOUND", "Mind not found. Use list_minds to see available clients.")


def INVALID_INPUT(message: str) -> dict[str, Any]:
    return tool_error("INVALID_INPUT", message)


# NOTE: INVALID_MEMORY_TYPE hardcodes CMO-specific types in the valid list,
# but the function itself is generic. The valid types string should come from
# config (e.g. memory_types.VALID_MEMORY_TYPES) in a future refactor.
def INVALID_MEMORY_TYPE(value: str) -> dict[str, Any]:
    valid = "decision, preference, campaign_outcome, commitment, stakeholder, fact, question"
    return tool_error("INVALID_MEMORY_TYPE", f"Invalid memory_type '{value}'. Valid types: {valid}")


def SERVICE_UNAVAILABLE(service: str) -> dict[str, Any]:
    return tool_error("SERVICE_UNAVAILABLE", f"{service} is temporarily unavailable — semantic search won't work until it recovers. Try again in a moment, or check your network connection.")


def MEMORY_NOT_FOUND(memory_id: str) -> dict[str, Any]:
    return tool_error("MEMORY_NOT_FOUND", f"Memory '{memory_id}' not found or belongs to a different mind.")


def INVALID_QUERY() -> dict[str, Any]:
    return tool_error("INVALID_QUERY", "Query cannot be empty.")


# NOTE: ACCESS_DENIED has a product-specific default message (references
# coppermind@volacci.com), but the error concept is generic. The default
# message should be configurable when extracted to the memory-layer package.
def ACCESS_DENIED(detail: str = "You do not have access to this client mind. Contact coppermind@volacci.com if this is unexpected.") -> dict[str, Any]:
    return tool_error("ACCESS_DENIED", detail)


# ---------------------------------------------------------------------------
# Product-specific errors (CMO layer)
# ---------------------------------------------------------------------------
# These functions reference CMO-specific concepts and will stay in the
# product package after Level 2 extraction.

def MIND_ARCHIVED(name: str) -> dict[str, Any]:
    return tool_error("MIND_ARCHIVED", f"Mind '{name}' is archived. Contact coppermind@volacci.com to unarchive.")


def INVALID_BRAND_DNA(message: str) -> dict[str, Any]:
    return tool_error("INVALID_BRAND_DNA", message)


def UPSTREAM_TIMEOUT(service: str) -> dict[str, Any]:
    return tool_error("UPSTREAM_TIMEOUT", f"{service} timed out. Try again in a moment.")


def DEGRADED_RESULT(message: str) -> dict[str, Any]:
    return tool_error("DEGRADED_RESULT", message)


def INTERNAL_ERROR(message: str = "An unexpected error occurred. Please try again.") -> dict[str, Any]:
    return tool_error("INTERNAL_ERROR", message)
