#!/bin/bash
# Coppermind CMO status line for Claude Code
# Reads ~/.coppermind/active-client.json and outputs a one-line summary
CLIENT_FILE="$HOME/.coppermind/active-client.json"
if [ -f "$CLIENT_FILE" ]; then
    CLIENT=$(python3 -c "
import json, sys
try:
    d = json.load(open('$CLIENT_FILE'))
    parts = [d['client_name']]
    if d.get('cadence'):
        parts.append(d['cadence'])
    parts.append(str(d['memory_count']) + ' memories')
    print(' | '.join(parts))
except Exception:
    sys.exit(1)
" 2>/dev/null)
    if [ -n "$CLIENT" ]; then
        echo "$CLIENT"
    fi
fi
