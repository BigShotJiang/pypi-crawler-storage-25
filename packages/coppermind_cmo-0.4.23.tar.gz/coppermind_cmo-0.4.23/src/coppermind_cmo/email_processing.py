"""Email processing utilities for Coppermind CMO.

Source-agnostic email attribution, filtering, and cleaning logic.
Extracted from email_poller.py during the Gmail MCP pivot.
"""

from __future__ import annotations

import json
import re
from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("email_processing")

# Constants
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")

SKIP_PREFIXES = frozenset({
    "no-reply", "noreply", "do-not-reply", "mailer-daemon",
    "notifications", "alerts", "support", "info",
})
SKIP_TLDS = frozenset({".internal", ".local", ".localhost"})


def build_known_contacts(minds: list[dict[str, Any]]) -> tuple[set[str], set[str]]:
    """Build sets of known domains and email addresses from client minds.

    Returns (domains, emails) -- both lowercased.
    """
    domains: set[str] = set()
    emails: set[str] = set()

    for mind in minds:
        # Domain from company_info
        company_info = mind.get("company_info") or {}
        domain = company_info.get("domain")
        if domain:
            domains.add(domain.lower())

        # Email contacts
        email_contacts = mind.get("email_contacts") or {}
        for addr in email_contacts:
            emails.add(addr.lower())

    return domains, emails


def matches_known_contacts(
    from_addr: str,
    to_addrs: list[str],
    cc_addrs: list[str],
    domains: set[str],
    emails: set[str],
) -> bool:
    """Check if any address in the email matches known contacts."""
    all_addrs = [from_addr] + to_addrs + cc_addrs
    for addr in all_addrs:
        addr_lower = addr.lower()
        if addr_lower in emails:
            return True
        # Check domain
        parts = addr_lower.split("@")
        if len(parts) == 2 and parts[1] in domains:
            return True
    return False


def attribute_email(
    from_addr: str,
    to_addrs: list[str],
    cc_addrs: list[str],
    minds: list[dict[str, Any]],
) -> list[str]:
    """Return list of mind_ids that match this email's participants.

    Returns empty list if no match, single item for clean match,
    multiple items for multi-match.
    """
    all_addrs = {a.lower() for a in [from_addr] + to_addrs + cc_addrs}
    matched_minds: list[str] = []

    for mind in minds:
        mind_id = str(mind["id"])
        email_contacts = mind.get("email_contacts") or {}
        company_info = mind.get("company_info") or {}
        domain = (company_info.get("domain") or "").lower()
        contact_emails = {k.lower() for k in email_contacts}

        for addr in all_addrs:
            if addr in contact_emails:
                if mind_id not in matched_minds:
                    matched_minds.append(mind_id)
                break
            parts = addr.split("@")
            if len(parts) == 2 and domain and parts[1] == domain:
                if mind_id not in matched_minds:
                    matched_minds.append(mind_id)
                break

    return matched_minds


def should_skip_message(
    subject: str,
    from_address: str,
    metadata: dict[str, Any] | None = None,
) -> bool:
    """Check whether an email should be skipped (source-agnostic).

    Checks subject patterns, from-address patterns, and optional metadata
    for auto-reply headers, newsletter indicators, and calendar content.
    """
    subject_lower = subject.lower().strip()

    # Auto-reply subjects
    auto_reply_prefixes = (
        "out of office",
        "automatic reply",
        "auto:",
        "delivery status notification",
    )
    if any(subject_lower.startswith(p) for p in auto_reply_prefixes):
        return True

    # From-address patterns (noreply, mailer-daemon, etc.)
    from_lower = from_address.lower()
    local_part = from_lower.split("@")[0] if "@" in from_lower else from_lower
    skip_from_prefixes = (
        "noreply", "no-reply", "do-not-reply",
        "mailer-daemon", "notifications", "alerts",
    )
    if any(local_part.startswith(p) for p in skip_from_prefixes):
        return True

    # Metadata checks (headers, mime_type)
    if metadata:
        headers = metadata.get("headers") or {}
        if "Auto-Submitted" in headers:
            return True
        if "List-Unsubscribe" in headers:
            return True

        mime_type = metadata.get("mime_type") or ""
        if "calendar" in mime_type.lower():
            return True

    return False


def clean_email_body(text: str) -> str:
    """Remove quoted replies, signatures, and disclaimers. Idempotent."""
    lines = text.split("\n")
    cleaned: list[str] = []
    for line in lines:
        stripped = line.strip()
        # Skip quoted reply lines
        if stripped.startswith(">"):
            continue
        # Stop at reply attribution
        if re.match(r"^On .+ wrote:$", stripped):
            break
        # Signature delimiter
        if re.match(r"^-{2,}\s*$", stripped):
            break
        # Footer delimiter
        if re.match(r"^_{3,}$", stripped):
            break
        cleaned.append(line)
    return "\n".join(cleaned).strip()


def extract_emails_from_content(content: str) -> list[str]:
    """Extract email addresses from text, filtering out infrastructure addresses."""
    raw_emails = EMAIL_RE.findall(content)
    filtered: list[str] = []
    for email in raw_emails:
        email_lower = email.lower()
        local_part = email_lower.split("@")[0] if "@" in email_lower else ""
        domain = email_lower.split("@")[1] if "@" in email_lower else ""

        # Skip infrastructure prefixes
        if local_part in SKIP_PREFIXES or any(local_part.startswith(p + ".") for p in SKIP_PREFIXES):
            continue

        # Skip non-public TLDs
        if any(domain.endswith(tld) for tld in SKIP_TLDS):
            continue

        filtered.append(email)
    return filtered


def auto_populate_email_contacts(
    db: Database,
    mind_id: str,
    content: str,
) -> int:
    """Extract email addresses from content and add to mind's email_contacts.

    Called as a post-store hook when memory_type == 'stakeholder'.
    Returns number of new contacts added.
    """
    # Guard against excessively large content to prevent slow regex scans
    if len(content) > 50_000:
        return 0

    found_emails = extract_emails_from_content(content)
    if not found_emails:
        return 0

    added = 0
    for email in found_emails:
        # Try to extract name from surrounding text
        name = "Unknown"

        # Safe name extraction -- no backtracking
        idx = content.find(f"<{email}>")
        if idx > 0:
            prefix = content[max(0, idx - 60):idx].strip()
            # Validate prefix is a plausible name
            if prefix and len(prefix) < 60 and re.fullmatch(r"[\w .'-]+", prefix):
                candidate = prefix.split("\n")[-1].strip()
                if candidate:
                    name = candidate

        try:
            # Check if email already exists before writing
            existing = db.fetch_one(
                "SELECT 1 FROM client_minds WHERE id = %s AND (COALESCE(email_contacts, '{}'::jsonb) ? %s)",
                [mind_id, email],
            )
            if existing:
                continue  # Already known
            db.execute(
                "UPDATE client_minds "
                "SET email_contacts = COALESCE(email_contacts, '{}'::jsonb) || %s::jsonb "
                "WHERE id = %s",
                (json.dumps({email: name}), mind_id),
            )
            added += 1
        except Exception as e:
            logger.debug("Failed to add email contact", email=email, error=str(e))

    if added:
        logger.info("auto_populated_contacts", mind_id=mind_id, contacts_added=added)
    return added
