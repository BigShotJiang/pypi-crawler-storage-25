"""Resilience utilities: error classification, retry, and tool safety.

Provides:
- classify_error(): categorize exceptions for retry/fail decisions
- resilient_call(): wrap a callable with retry and error classification
- safe_tool_call(): decorator for MCP tool handlers to catch all exceptions
"""

import time
import traceback
from functools import wraps
from typing import Any, Callable

import httpx
import psycopg2
from psycopg2.pool import PoolError

from coppermind_cmo.errors import tool_error
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("resilience")


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------

def classify_error(exc: Exception) -> str:
    """Classify an exception into a retry/fail category.

    Returns one of: transient, rate_limit, auth, input, server, unknown.
    """
    # httpx HTTP status errors
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        if status == 429:
            return "rate_limit"
        if status in (401, 403):
            return "auth"
        if status in (400, 404, 422):
            return "input"
        if status in (502, 503, 504):
            return "transient"
        if status >= 500:
            return "server"
        return "unknown"

    # Connection and timeout errors are transient
    if isinstance(exc, (
        ConnectionError,
        TimeoutError,
        httpx.ConnectError,
        httpx.TimeoutException,
        httpx.RemoteProtocolError,
    )):
        return "transient"

    # OSError subclasses for network issues
    if isinstance(exc, OSError) and exc.errno in (
        111,  # Connection refused
        110,  # Connection timed out
        104,  # Connection reset by peer
    ):
        return "transient"

    # psycopg2 database errors
    # Connection-level errors are transient (connection lost, pool exhausted)
    if isinstance(exc, (psycopg2.OperationalError, psycopg2.InterfaceError)):
        return "transient"
    # Data conflicts are input errors
    if isinstance(exc, (psycopg2.IntegrityError, psycopg2.DataError)):
        return "input"
    # Programming errors (bad SQL) — not retriable
    if isinstance(exc, psycopg2.ProgrammingError):
        return "unknown"
    # Pool errors are transient (exhaustion, closed pool)
    if isinstance(exc, PoolError):
        return "transient"

    # ValueError/TypeError are typically input problems
    if isinstance(exc, (ValueError, TypeError)):
        return "input"

    # KeyError is usually a programming error, not transient
    if isinstance(exc, KeyError):
        return "input"

    return "unknown"


def _is_retryable(category: str) -> bool:
    """Whether an error category should be retried."""
    return category in ("transient", "rate_limit", "server")


# ---------------------------------------------------------------------------
# Retry wrapper
# ---------------------------------------------------------------------------

def resilient_call(
    func: Callable,
    *args,
    service_name: str = "unknown",
    max_attempts: int = 3,
    backoff_base: float = 1.0,
    max_elapsed: float = 0,
    **kwargs,
) -> Any:
    """Call func with retry on transient failures.

    Args:
        func: The callable to invoke.
        service_name: Name for logging (e.g. "gateway", "database").
        max_attempts: Maximum number of attempts (default 3).
        backoff_base: Base delay in seconds (doubles each retry: 1s, 2s, 4s).
        max_elapsed: Wall-clock cap in seconds. 0 = no cap. If elapsed time
            exceeds this before a retry attempt, the last exception is raised
            immediately instead of retrying.
        *args, **kwargs: Passed through to func.

    Returns:
        The return value of func on success.

    Raises:
        The last exception if all retries are exhausted or error is non-retryable.
    """
    last_exc = None
    start = time.monotonic()

    for attempt in range(1, max_attempts + 1):
        # Wall-clock cap: abort if elapsed time exceeds limit
        if max_elapsed > 0 and attempt > 1:
            elapsed = time.monotonic() - start
            if elapsed >= max_elapsed:
                logger.warn(
                    f"{service_name} call aborted — wall-clock cap exceeded "
                    f"({elapsed:.1f}s >= {max_elapsed}s)",
                    service=service_name,
                    elapsed_seconds=round(elapsed, 1),
                    max_elapsed=max_elapsed,
                )
                raise last_exc  # type: ignore[misc]

        try:
            result = func(*args, **kwargs)
            if attempt > 1:
                logger.info(
                    f"{service_name} call recovered on attempt {attempt}/{max_attempts}",
                    service=service_name,
                    attempt=attempt,
                    recovered=True,
                )
            return result
        except Exception as exc:
            last_exc = exc
            category = classify_error(exc)

            if not _is_retryable(category) or attempt == max_attempts:
                logger.warn(
                    f"{service_name} call failed (attempt {attempt}/{max_attempts}, "
                    f"category={category})",
                    service=service_name,
                    attempt=attempt,
                    error_category=category,
                    error=str(exc),
                )
                raise

            # Calculate backoff
            delay = backoff_base * (2 ** (attempt - 1))

            # For rate limits, respect Retry-After header if available
            if category == "rate_limit" and isinstance(exc, httpx.HTTPStatusError):
                retry_after = exc.response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = max(delay, float(retry_after))
                    except (ValueError, TypeError):
                        pass

            logger.info(
                f"{service_name} call failed, retrying in {delay:.1f}s "
                f"(attempt {attempt}/{max_attempts})",
                service=service_name,
                attempt=attempt,
                error_category=category,
                error=str(exc),
                backoff_seconds=delay,
            )
            time.sleep(delay)

    # Should not reach here, but just in case
    raise last_exc  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Tool-level exception safety decorator
# ---------------------------------------------------------------------------

def safe_tool_call(tool_name: str):
    """Decorator that catches all exceptions in an MCP tool handler and returns
    a structured error dict instead of crashing.

    Usage:
        @safe_tool_call("store_memory")
        def store_memory(...) -> dict:
            ...

    Any unhandled exception is logged and returned as:
        {"error": True, "code": "INTERNAL_ERROR", "message": "...user-friendly..."}
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            try:
                return func(*args, **kwargs)
            except SystemExit:
                raise  # never swallow SystemExit
            except Exception as exc:
                category = classify_error(exc)
                logger.error(
                    f"Unhandled exception in tool '{tool_name}'",
                    tool=tool_name,
                    error_category=category,
                    error_type=type(exc).__name__,
                    error=str(exc),
                    traceback=traceback.format_exc(),
                )

                # Map category to user-friendly message
                if category == "transient":
                    return tool_error(
                        "SERVICE_UNAVAILABLE",
                        "A service is temporarily unavailable. Please try again in a moment.",
                        retryable=True,
                    )
                elif category == "rate_limit":
                    return tool_error(
                        "RATE_LIMITED",
                        "Too many requests. Please wait a moment and try again.",
                        retryable=True,
                    )
                elif category == "auth":
                    return tool_error(
                        "ACCESS_DENIED",
                        "Authentication failed. Check your API key or contact coppermind@volacci.com.",
                    )
                elif category == "input":
                    # psycopg2 DB errors can leak schema details — use generic message
                    if isinstance(exc, (psycopg2.IntegrityError, psycopg2.DataError)):
                        return tool_error(
                            "INVALID_INPUT",
                            "A data conflict occurred — this record may already exist. If the problem persists, contact coppermind@volacci.com.",
                        )
                    # For ValueError/TypeError, the message is usually safe and helpful
                    if isinstance(exc, (ValueError, TypeError)):
                        return tool_error(
                            "INVALID_INPUT",
                            f"Invalid input: {exc}",
                        )
                    # For KeyError and other "input" errors, sanitize
                    return tool_error(
                        "INVALID_INPUT",
                        "Invalid input. If the problem persists, contact coppermind@volacci.com.",
                    )
                else:
                    return tool_error(
                        "INTERNAL_ERROR",
                        "An unexpected error occurred. If the problem persists, contact coppermind@volacci.com.",
                    )
        return wrapper
    return decorator
