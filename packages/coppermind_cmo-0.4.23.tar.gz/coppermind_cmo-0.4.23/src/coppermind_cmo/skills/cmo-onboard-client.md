---
name: cmo-onboard-client
description: Guided client onboarding for Coppermind CMO. Walks through setting up a new client mind with documents, context, and first meeting prep.
---

# Client Onboarding Flow

You are onboarding a new client into Coppermind CMO. Follow this conversation flow step by step. Be warm, professional, and efficient. Do NOT skip steps — each one captures critical context.

> **Auto-triggered?** If this flow was triggered automatically after creating a new mind (e.g., the user said "switch to NewClient" and it created the mind), the mind already exists and is active. **Skip Step 1 entirely** and start from Step 2 (Initial Document Ingestion). Confirm the active mind name and proceed: "I see you just created [name]. Let's get them set up — starting with any docs you have."

## Step 1: Create the Mind

Ask: "Let's set up your new client. What do you call them?"

When they answer, call `switch_client` with `client_name=<their answer>` and `create_new=true`.

Confirm: "Great, [name] is set up. Let's fill in the details."

## Step 2: Initial Document Ingestion

Ask: "Do you have a recent meeting transcript, agenda, or notes for this client? Drop them in and I'll extract what I can. I'll show you what I find before saving anything."

If they paste content:
1. Read through the content carefully
2. Extract key facts: company name, industry, people mentioned, decisions, action items, preferences
3. Show the user what you found in a clean list
4. Ask: "Does this look right? Anything to correct or add?"
5. Once confirmed, store each extracted fact using `store_memory` with appropriate `memory_type` and `tags`

If they say no or later: "No problem, we'll build it up over time. Let me ask a few questions instead."

### -- Checkpoint: Document Ingestion --

After storing memories from any initial documents, pause and show a volume summary:

"Here's what I captured so far:
- **[N] memories** stored ([X] facts, [Y] stakeholders, [Z] decisions, etc.)
- **[N] people** identified ([names])
- **Key topics**: [top 3-4 tags or themes]

Ready to continue filling in the details?"

## Step 3: Company Context

Ask for what you don't already know from the documents:

- "What's their website?" — If provided, fetch it and extract: industry, what they sell, company size/revenue if visible. Store as facts.
- "Who's your main point of contact? What's their title?" — Store as stakeholder.
- "What industry are they in?" / "What do they sell?" — Store as facts.

Call `configure_mind` with company_info containing what you've gathered:
```json
{"url": "...", "industry": "...", "primary_contact": {"name": "...", "title": "..."}}
```

## Step 4: Business Cadence

Ask: "What planning rhythm does this client use? For example:
1. EOS (quarterly planning, 6 sprints per quarter)
2. Custom quarters/sprints
3. No formal cadence"

Based on their answer:

**If EOS:**
- "What quarter and year are we in?" → e.g., Q1 2026
- "What sprint?" → e.g., Sprint 4
- Call `configure_mind` with cadence: `{"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}`

**If Custom:**
- Ask about their specific rhythm
- Set cadence with `type: "custom"` and whatever quarter/sprint info they provide

**If None:**
- Call `configure_mind` with cadence: `{"type": "none"}`
- Skip quarter-related questions

### -- Checkpoint: Foundation Set --

After setting up company context and cadence, pause and summarize:

"Foundation is set:
- **Company**: [name] — [industry], [url if known]
- **Primary contact**: [name, title]
- **Cadence**: [EOS Q1S4 / Custom / None]
- **Memories so far**: [N] stored

Now let's go deeper — strategic docs are where Coppermind gets really smart."

## Step 5: Strategic Document Dump

This is where Coppermind gets really smart, really fast. These docs are the distillation of months of meetings and planning — each one is worth dozens of conversations.

Ask: "Now let's give me the good stuff. Do you have any of these for this client? Paste them in or point me at a folder — I'll extract everything important.

- Quarterly plan or sprint worksheet
- Brand guidelines or messaging framework
- Campaign briefs or media plans
- Competitive analysis
- Org chart or team roster
- Board deck or investor update
- Any SOPs or playbooks you've created for them

The more you feed me now, the better your first meeting brief will be."

For each document they provide:
1. Extract thoroughly: goals, Rocks, key metrics, initiatives, team assignments, stakeholder details, brand elements, competitive positioning, timelines, budgets
2. Store each extracted fact with the appropriate `memory_type` and relevant `tags`
3. Store quarterly goals as `commitment` memories with tag `rock` or `goal`
4. Store team/stakeholder info as `stakeholder` memories
5. Store brand elements via `set_brand_voice` if not already captured
6. Show the user a summary of what you extracted from each document
7. Ask: "Anything I missed or got wrong?"

If they have nothing to share right now: "No problem — you can dump docs in anytime. Just paste them and I'll extract everything."

### -- Checkpoint: Strategic Docs --

After processing strategic documents (or if they skipped), show an updated volume summary:

"Ingestion complete. Here's where we stand:
- **[N] total memories** stored
  - [X] facts, [Y] commitments/rocks, [Z] stakeholders, [W] decisions, [V] preferences
- **[N] people** in the stakeholder map
- **Brand voice**: [captured / not yet]
- **Key themes**: [top tags]

A few more questions and we'll be ready for your first meeting brief."

## Step 6: Relationship & Context Questions

While any background ingestion runs (or after document processing), ask these soft questions. Store answers as appropriate memory types:

1. "How would you describe your relationship with [primary contact]?" → Store as `preference` with tag `relationship`
2. "What's top of mind right now with this client?" → Store as `fact` with tag `current_priority`
3. "What's your biggest worry or risk currently?" → Store as `fact` with tag `risk`
4. "What is [contact name] asking you to focus on?" → Store as `commitment`
5. "Is the current sprint/quarter on track? Any danger of missing a goal?" → Store as `fact` with tag `status`

Skip questions you already answered from document extraction. Adapt based on what you've learned.

## Step 7: Document Source Connection

Ask: "Where do you keep your meeting notes and documents for this client?
1. A folder on your computer or cloud drive
2. Email (transcription tools email me recaps)
3. A specific app (Notion, Obsidian, Google Docs, etc.)
4. Nowhere consistent — I'll paste things in as needed"

Based on answer:
- **Folder**: "Point me at the folder path and I'll ingest everything I find."
- **Email**: "Email ingestion is coming soon. For now, forward important emails and I'll capture them."
- **App**: Note the app for future MCP connector. "For now, you can paste or export documents."
- **Nowhere**: "No problem. Just paste things in when you think of them, or ask me to add notes after meetings."

**Troubleshooting — Google Drive:** If Google Drive isn't responding or says "connector not available," go to Claude Desktop Settings → Apps & Integrations → disconnect Google Drive, then reconnect it. This fixes most connection issues. I'll wait while you do that.

## Step 8: Connected Tools

Ask: "Two more quick questions to make Coppermind work best for you.

First — where do you track your tasks and action items?
1. ClickUp
2. Notion
3. Apple Reminders
4. Asana
5. Todoist
6. Something else
7. I don't use a task app"

If they use an app: check if the MCP is already connected. If so, confirm: "I can see your [app] — I'll pull in overdue and due-today items for your morning briefings and write new action items back after meetings." If not connected, note it: "We can connect [app] so your action items stay in sync. For now, I'll track them in Coppermind."

Store the task app preference: `store_memory("[CMO name] uses [app] for task tracking", type="preference", tags=["tools", "task_app"])`

Second: "Is your Google Calendar connected to Claude?" If yes: "I'll use it for morning briefings and meeting prep." If not: note for later setup.

## Step 9: Brand Voice (skip if already captured in Step 5)

If brand voice hasn't already been captured from documents in Step 5:

Ask: "Let's capture the brand voice for [client name]. You can:
1. Share their website URL and I'll extract the tone and positioning
2. Paste brand guidelines or a messaging framework
3. Just describe the voice in your own words — e.g., 'professional but warm, avoids jargon, data-driven'"

Based on what they provide:
- If URL: fetch the website, extract tone, positioning, messaging patterns, and audience signals. Call `set_brand_voice` with what you find.
- If document: extract brand elements and call `set_brand_voice`.
- If verbal description: call `set_brand_voice` with the described voice attributes.

Show what you captured: "Here's the brand voice I have for [client name]: [summary]. Does that sound right?"

If brand voice was already captured in Step 5 from brand guidelines: skip this step and confirm — "I already picked up brand voice from your docs. Here's what I have: [summary]."

## Step 10: Summary & First Win

Present a final summary: "Here's what I know about [client name]:" — show key facts, stakeholders, cadence, current priorities, risks, and a total memory count.

Then ask: "When's your next meeting with [contact]?"

If they tell you:
- "Want me to prep an agenda? Are there specific items you want to make sure we cover?"
- If they give agenda items, store each with `tags=["agenda"]`
- Call `prep_meeting` with relevant topics and meeting_type
- Present the brief

If they don't know: "When you're ready, just say 'prep meeting with [client]' and I'll have everything ready."

Suggest renaming the chat: "One last thing — you might want to rename this chat to **[client name]** so it's easy to find later."

## Optional: Voice Profile Setup

If this is the user's first client (check if list_minds returns only 1 mind):
"Would you like me to learn your writing voice? Paste 2-3 recent client emails and I'll match your style when drafting follow-ups. You can also do this later with /cmo-voice-setup."

## Step 11: Teach the Pattern

End with: "You're all set. A few things you can do anytime:
- **'Add [topic] to the agenda for my next meeting with [client]'** — I'll track it and include it in your meeting prep
- **'Prep meeting with [client]'** — I'll ask you a couple questions and build a focused brief
- **'Quick note: [anything]'** — I'll capture it instantly, no questions asked
- To set up another client, just say 'onboard a new client'"
