"""Second-pass extraction: full-document synthesis over raw documents.

Analyzes complete documents against existing memory context to find
patterns, trends, contradictions, and insights the chunk-by-chunk
first pass missed.
"""

from __future__ import annotations

import json
import os
import re
import time
from typing import Any, Callable

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("synthesis")

# Configurable limits
MAX_DOCUMENT_CHARS = 100_000
MAX_PROMPT_CHARS = 200_000
MIN_WORD_COUNT_AUTO = 1000
MIN_CONFIDENCE = 0.7
DEFAULT_DAILY_CAP_PER_MIND = 10
DEFAULT_DAILY_CAP_PER_CUSTOMER = 30
MAX_INSIGHTS_PER_DOC = 10

# Fallback prompt template (used when gateway config is unreachable)
_FALLBACK_SYNTHESIS_PROMPT = """You are analyzing a full document for a client named $client_name$ to find patterns, trends, and insights that individual excerpts missed.

Below you will find:
1. The full document (meeting transcript, email thread, or client document)
2. The memories already extracted from this document and recent history

Your task: identify HIGH-LEVEL INSIGHTS that span multiple parts of this document or connect to existing memories in ways the excerpt-by-excerpt extraction missed.

Look specifically for:
- Behavioral patterns: How does this client/stakeholder consistently behave?
- Trend lines: What is changing over time?
- Contradictions: Does anything in this document conflict with existing memories?
- Implicit shifts: What is NOT being said that used to be said?
- Relationship dynamics: Power shifts, trust changes, new alliances
- Strategic undercurrents: What's the meta-narrative?

Rules:
1. Do NOT re-extract facts already captured in the existing memories below. Your job is to find what they MISSED, not to duplicate them.
2. Every insight must reference specific evidence from the document. No speculation without textual support.
3. Use certainty markers: "pattern suggests," "evidence indicates," "appears to be shifting" for uncertain observations.
4. If the document reveals nothing beyond what's already captured, return an empty array. This is the correct answer most of the time.
5. Focus on insights a CMO would act on: staffing changes, budget pressure, strategic drift, relationship dynamics, competitive anxiety.
6. Keep each evidence field under 100 words.
7. Return at most 10 insights per document.

Return ONLY valid JSON in this format:
[{"content": "The insight as a standalone statement using the client's name", "memory_type": "decision|commitment|preference|campaign_outcome|stakeholder|fact|question", "confidence": 0.0-1.0, "evidence": "Brief quote or reference from the document supporting this insight"}]

Existing memories for $client_name$ (most recent first):
<existing_memories>
$existing_memories$
</existing_memories>

Full document:
<document>
$document_text$
</document>

Insights (JSON array):"""


def _default_llm_call(config: Config, prompt: str) -> str | None:
    """Call the gateway /v1/synthesize endpoint. Returns text or None on failure."""
    try:
        resp = httpx.post(
            f"{config.gateway_url}/v1/synthesize",
            json={"prompt": prompt},
            headers={"Authorization": f"Bearer {config.api_key}",
                     "Content-Type": "application/json"},
            timeout=120,
        )
        if resp.status_code != 200:
            logger.error("Gateway synthesis call failed",
                         status=resp.status_code)
            return None
        data = resp.json()
        return data.get("text")
    except Exception as e:
        logger.error(f"Gateway synthesis request failed: {e}")
        return None


def _get_synthesis_prompt_template(config: Config) -> str:
    """Fetch the synthesis prompt template from gateway config, with fallback."""
    try:
        resp = httpx.get(
            f"{config.gateway_url}/v1/config",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            prompts = data.get("prompts", {})
            if "synthesis" in prompts:
                return prompts["synthesis"]
    except Exception as e:
        logger.warn(f"Failed to fetch synthesis prompt from gateway: {e}")
    return _FALLBACK_SYNTHESIS_PROMPT


def _parse_insights(raw_text: str) -> list[dict]:
    """Parse LLM response into structured insights. Handles markdown fences and preamble.

    Same robust parsing approach as extract_memories_from_chunk in ingest.py.
    """
    if not raw_text or not raw_text.strip():
        return []

    text = raw_text.strip()

    # Strip markdown code fences
    text = re.sub(r'^```(?:json)?\s*\n?', '', text, flags=re.MULTILINE)
    text = re.sub(r'\n?```\s*$', '', text, flags=re.MULTILINE)
    text = text.strip()

    # Try direct JSON parse
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return [i for i in parsed if isinstance(i, dict) and "content" in i]
        if isinstance(parsed, dict) and "content" in parsed:
            return [parsed]
        return []
    except json.JSONDecodeError:
        pass

    # Try to find JSON array in the text
    match = re.search(r'\[.*\]', text, re.DOTALL)
    if match:
        try:
            parsed = json.loads(match.group())
            if isinstance(parsed, list):
                return [i for i in parsed if isinstance(i, dict) and "content" in i]
        except json.JSONDecodeError:
            pass

    logger.warn("Could not parse synthesis response as JSON", raw_text=text[:200])
    return []


class SynthesisEngine:
    """Second-pass extraction: full-document synthesis over raw documents."""

    def __init__(
        self,
        db: Database,
        config: Config,
        active_mind: tuple[str, str],
        store_fn: Callable | None = None,
        llm_fn: Callable | None = None,
    ):
        self.db = db
        self.config = config
        self.mind_id = active_mind[0]
        self.mind_name = active_mind[1]
        self.active_mind = active_mind
        # Injectable for test isolation
        self.store_fn = store_fn or self._default_store
        self.llm_fn = llm_fn or _default_llm_call
        self._prompt_template: str | None = None

    def _default_store(self, **kwargs):
        from coppermind_cmo.tools.memories import store_memory_core
        return store_memory_core(**kwargs)

    def _get_prompt_template(self) -> str:
        """Cache the prompt template for the lifetime of this engine instance."""
        if self._prompt_template is None:
            self._prompt_template = _get_synthesis_prompt_template(self.config)
        return self._prompt_template

    def synthesize_document(self, doc_id: str, force: bool = False) -> dict:
        """Run synthesis on a single raw document. Returns results dict."""
        # Fetch the document
        row = self.db.fetch_one(
            "SELECT id, content, source_ref, word_count, extraction_passes "
            "FROM raw_documents WHERE id = %s::uuid AND mind_id = %s",
            [doc_id, self.mind_id],
        )
        if not row:
            return {"error": "NO_DOCUMENTS", "message": f"Document {doc_id} not found for this mind"}

        doc_uuid, doc_content, source_ref, word_count, extraction_passes = row

        # Check minimum word count for auto synthesis (manual/force bypasses)
        if not force and word_count and word_count < MIN_WORD_COUNT_AUTO:
            logger.info("Document too short for auto synthesis",
                        doc_id=doc_id, word_count=word_count)
            return {"skipped": True, "reason": "document_too_short", "word_count": word_count}

        # Check daily cap (unless force)
        if not force and not self._check_daily_cap():
            return {"error": "DAILY_CAP_REACHED",
                    "message": "Daily synthesis cap reached for this mind. Use force=true to override."}

        logger.info("synthesis_started", mind_id=self.mind_id, doc_id=doc_id,
                     word_count=word_count or len(doc_content.split()))

        # Fetch existing memories for context
        existing_memories = self._fetch_existing_memories()

        # Build prompt
        prompt = self._build_synthesis_prompt(doc_content, existing_memories)
        if prompt is None:
            return {"error": "PROMPT_TOO_LARGE", "message": "Document + context exceeds maximum prompt size"}

        # Call LLM
        t0 = time.monotonic()
        raw_response = self.llm_fn(self.config, prompt)
        duration_ms = int((time.monotonic() - t0) * 1000)

        if raw_response is None:
            return {"error": "LLM_UNAVAILABLE", "message": "Gateway synthesis call failed"}

        # Parse insights
        insights = _parse_insights(raw_response)

        # Filter by minimum confidence
        insights = [i for i in insights if i.get("confidence", 0) >= MIN_CONFIDENCE]

        # Cap at max insights
        insights = insights[:MAX_INSIGHTS_PER_DOC]

        # Log evidence for debugging (not stored in memories)
        for i, insight in enumerate(insights):
            evidence = insight.get("evidence", "")
            if evidence:
                logger.info(f"Synthesis insight {i+1} evidence", doc_id=doc_id,
                            evidence=evidence[:200])

        # Count contradictions
        contradictions = sum(1 for i in insights
                            if "contradict" in i.get("content", "").lower()
                            or i.get("memory_type") == "contradiction")

        # Store insights — each store_fn call auto-commits independently via db.execute().
        # store_memory_core manages its own connection, so no wrapping transaction is possible.
        memories_created = 0
        for insight in insights:
            tags = ["synthesis"]
            if "contradict" in insight.get("content", "").lower():
                tags.append("contradiction")

            result = self.store_fn(
                content=insight["content"],
                memory_type=insight.get("memory_type", "fact"),
                tags=tags,
                db=self.db,
                config=self.config,
                active_mind=self.active_mind,
                source_type="synthesis",
                source_ref=f"synthesis:{doc_id}",
                confidence=insight.get("confidence", 0.8),
            )
            if isinstance(result, dict) and "memory_id" in result:
                memories_created += 1

        # Mark extraction pass complete after all stores succeed.
        # If this fails after stores succeeded, the document may be re-synthesized
        # but store_memory_core's reconsolidation dedup will prevent duplicates.
        self.db.execute(
            "UPDATE raw_documents SET extraction_passes = extraction_passes + 1, "
            "last_extracted_at = now() WHERE id = %s::uuid",
            [doc_id],
        )

        logger.info("synthesis_completed", mind_id=self.mind_id, doc_id=doc_id,
                     insights_found=len(insights), contradictions=contradictions,
                     memories_created=memories_created, duration_ms=duration_ms)

        return {
            "document": source_ref or str(doc_id),
            "word_count": word_count or len(doc_content.split()),
            "insights": len(insights),
            "memories_created": memories_created,
            "contradictions": contradictions,
            "insights_list": [i["content"] for i in insights],
            "duration_ms": duration_ms,
        }

    def process_queue(self, max_docs: int = 10) -> dict:
        """Process pending synthesis queue entries. Returns aggregate results."""
        # Check if synthesis is enabled
        if os.environ.get("COPPERMIND_SYNTHESIS_ENABLED", "true").lower() == "false":
            logger.info("synthesis_paused")
            return {"paused": True, "documents_processed": 0}

        # Claim pending queue items atomically with FOR UPDATE SKIP LOCKED.
        # Must use db.connection() directly to hold the lock through the status update.
        claimed_rows = []
        with self.db.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT sq.id, sq.raw_document_id, sq.attempts "
                    "FROM synthesis_queue sq "
                    "WHERE sq.mind_id = %s AND sq.status = 'pending' "
                    "AND sq.run_after <= now() AND sq.attempts < sq.max_attempts "
                    "ORDER BY sq.created_at ASC LIMIT %s "
                    "FOR UPDATE SKIP LOCKED",
                    [self.mind_id, max_docs],
                )
                claimed_rows = cur.fetchall()
                if claimed_rows:
                    ids = [r[0] for r in claimed_rows]
                    cur.execute(
                        "UPDATE synthesis_queue SET status = 'processing' "
                        "WHERE id = ANY(%s)",
                        [ids],
                    )
            conn.commit()

        if not claimed_rows:
            return {"documents_processed": 0, "insights_found": 0}

        total_insights = 0
        total_contradictions = 0
        processed = 0
        details = []

        for queue_id, raw_doc_id, attempts in claimed_rows:

            try:
                result = self.synthesize_document(str(raw_doc_id))

                if "error" in result:
                    # Increment attempts, back to pending for retry
                    self.db.execute(
                        "UPDATE synthesis_queue SET status = 'pending', "
                        "attempts = attempts + 1, error_message = %s WHERE id = %s",
                        [result.get("message", result["error"]), queue_id],
                    )
                    if attempts + 1 >= 3:
                        self.db.execute(
                            "UPDATE synthesis_queue SET status = 'failed' WHERE id = %s",
                            [queue_id],
                        )
                elif result.get("skipped"):
                    self.db.execute(
                        "UPDATE synthesis_queue SET status = 'skipped', completed_at = now() WHERE id = %s",
                        [queue_id],
                    )
                else:
                    self.db.execute(
                        "UPDATE synthesis_queue SET status = 'completed', "
                        "completed_at = now(), memories_created = %s WHERE id = %s",
                        [result.get("memories_created", 0), queue_id],
                    )
                    total_insights += result.get("insights", 0)
                    total_contradictions += result.get("contradictions", 0)
                    processed += 1
                    details.append(result)

            except Exception as e:
                logger.error(f"Synthesis queue processing failed: {e}",
                             queue_id=str(queue_id), doc_id=str(raw_doc_id))
                self.db.execute(
                    "UPDATE synthesis_queue SET status = 'pending', "
                    "attempts = attempts + 1, error_message = %s WHERE id = %s",
                    [str(e)[:500], queue_id],
                )

        logger.info("synthesis_cycle_done",
                     documents_processed=processed,
                     total_insights=total_insights)

        return {
            "documents_processed": processed,
            "insights_found": total_insights,
            "contradictions_found": total_contradictions,
            "detail": details,
        }

    def _build_synthesis_prompt(self, document: str, existing_memories: list[dict]) -> str | None:
        """Build the synthesis prompt with document and context. Returns None if too large."""
        template = self._get_prompt_template()

        # Sanitize client name (prevent $variable$ interference)
        safe_name = self.mind_name.replace('$', '').strip()[:100]

        # Truncate document if needed
        doc_text = document
        if len(doc_text) > MAX_DOCUMENT_CHARS:
            doc_text = doc_text[-MAX_DOCUMENT_CHARS:]  # Keep most recent part
            doc_text = f"[Document truncated to last {MAX_DOCUMENT_CHARS:,} characters]\n\n{doc_text}"

        # Sanitize closing XML tags in document to prevent prompt injection
        safe_doc = doc_text.replace('</document>', '&lt;/document&gt;')
        safe_doc = safe_doc.replace('</existing_memories>', '&lt;/existing_memories&gt;')

        # Format existing memories with sanitization
        mem_lines = []
        for m in existing_memories:
            content = m.get('content', '')
            # Sanitize XML closing tags to prevent prompt injection
            content = content.replace('</existing_memories>', '&lt;/existing_memories&gt;')
            content = content.replace('</document>', '&lt;/document&gt;')
            # Sanitize $variable$ patterns to prevent template substitution interference
            content = content.replace('$', '')
            mem_lines.append(f"[{m.get('memory_type', 'fact')}] {content} ({m.get('date', '')})")
        memories_text = "\n".join(mem_lines)

        # Substitute variables
        prompt = template.replace("$client_name$", safe_name)
        prompt = prompt.replace("$existing_memories$", memories_text)
        prompt = prompt.replace("$document_text$", safe_doc)

        # Check total size
        if len(prompt) > MAX_PROMPT_CHARS:
            # Truncate memories first
            available = MAX_PROMPT_CHARS - (len(prompt) - len(memories_text))
            if available < 0:
                # Even without memories, document is too large -- truncate further
                return None
            memories_text = memories_text[:available]
            prompt = template.replace("$client_name$", safe_name)
            prompt = prompt.replace("$existing_memories$", memories_text)
            prompt = prompt.replace("$document_text$", safe_doc)

        # Final check against gateway body limit (1MB JSON)
        if len(json.dumps({"prompt": prompt})) > 1_048_576:
            logger.warn("Prompt exceeds 1MB JSON body limit after construction")
            return None

        return prompt

    def _fetch_existing_memories(self, limit: int = 100) -> list[dict]:
        """Fetch recent memories for context."""
        rows = self.db.fetch_all(
            "SELECT memory_type, content, created_at "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true "
            "ORDER BY created_at DESC LIMIT %s",
            [self.mind_id, limit],
        )
        return [
            {
                "memory_type": r[0],
                "content": r[1],
                "date": r[2].strftime("%Y-%m-%d") if r[2] else "",
            }
            for r in rows
        ]

    def _check_daily_cap(self) -> bool:
        """Check if the daily synthesis cap has been reached for this mind."""
        cap = int(os.environ.get("COPPERMIND_SYNTHESIS_DAILY_CAP", str(DEFAULT_DAILY_CAP_PER_MIND)))
        row = self.db.fetch_one(
            "SELECT COUNT(*) FROM synthesis_queue "
            "WHERE mind_id = %s AND status = 'completed' "
            "AND completed_at >= now() - interval '24 hours'",
            [self.mind_id],
        )
        count = row[0] if row else 0
        if count >= cap:
            logger.warn("synthesis_cap_reached", mind_id=self.mind_id, runs_today=count)
            return False
        return True
