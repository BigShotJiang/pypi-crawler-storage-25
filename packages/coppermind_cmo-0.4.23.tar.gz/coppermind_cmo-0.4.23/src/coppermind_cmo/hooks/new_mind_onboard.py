"""Claude PostToolUse hook for auto-onboarding after new mind creation.

When switch_client creates a new mind (is_new: true in the tool response),
this hook injects additionalContext telling Claude to run the onboarding flow
via /cmo-onboard-client, skipping Step 1 (mind already created).
"""

from __future__ import annotations

import json
import sys


def _log(level: str, message: str, **extra) -> None:
    """Structured JSON log to stderr (hooks run as standalone scripts)."""
    entry = {"level": level, "hook": "new-mind-onboard", "message": message}
    entry.update(extra)
    print("COPPERMIND-HOOK: " + json.dumps(entry), file=sys.stderr, flush=True)


def _parse_tool_output(raw_output: str) -> dict | None:
    """Parse tool output string into dict. Returns None on failure."""
    if not raw_output:
        return None
    try:
        return json.loads(raw_output)
    except (json.JSONDecodeError, TypeError):
        return None


def build_hook_output(tool_name: str, tool_input: dict, tool_output: str) -> dict | None:
    """Return hook JSON payload when a new mind was just created.

    Returns None if:
    - The tool is not switch_client
    - The tool output doesn't contain is_new: true
    - The tool output can't be parsed
    """
    # Only care about switch_client calls
    if not tool_name.endswith("switch_client"):
        return None

    parsed = _parse_tool_output(tool_output)
    if parsed is None:
        _log("debug", "Could not parse tool output", tool_name=tool_name)
        return None

    # Handle both direct dict and MCP content wrapper formats
    result = parsed
    if isinstance(parsed, list):
        # MCP sometimes wraps in [{"type": "text", "text": "..."}]
        for item in parsed:
            if isinstance(item, dict) and item.get("type") == "text":
                try:
                    result = json.loads(item["text"])
                except (json.JSONDecodeError, KeyError, TypeError):
                    pass
                break

    if not isinstance(result, dict):
        return None

    is_new = result.get("is_new")
    if is_new is not True:
        return None

    client_name = result.get("name", "this client")
    mind_id = result.get("mind_id", "")

    _log("info", "New mind detected, triggering onboarding", name=client_name, mind_id=mind_id)

    context = (
        f"COPPERMIND AUTO-ONBOARD:\n"
        f"A new client mind was just created for \"{client_name}\" (mind_id: {mind_id}).\n"
        f"The mind already exists and is active — skip Step 1 of the onboarding flow.\n"
        f"Invoke /cmo-onboard-client using the Skill tool and pass the following as args:\n"
        f"  \"Mind already created for {client_name}. Start from Step 2 (document ingestion).\"\n"
        f"This triggers the guided onboarding conversation to configure the new client."
    )

    return {
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": context,
        }
    }


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    tool_name = event.get("tool_name", "")
    tool_input = event.get("tool_input", {})
    tool_output = event.get("tool_output", "")

    output = build_hook_output(tool_name, tool_input, tool_output)
    if output:
        print(json.dumps(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
