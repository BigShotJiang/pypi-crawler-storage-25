"""Claude UserPromptSubmit hook for natural language skill routing.

Detects intent from user prompts and suggests the appropriate /cmo-* skill.
Supports optional assistant name prefix (e.g., "Julie, catch me up").
"""

from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


def _log(level: str, message: str, **extra) -> None:
    """Structured JSON log to stderr (hooks run as standalone scripts)."""
    import json as _json
    entry = {"level": level, "hook": "skill-router", "message": message}
    entry.update(extra)
    print("COPPERMIND-HOOK: " + _json.dumps(entry), file=sys.stderr, flush=True)


DEFAULT_STATE_PATH = Path.home() / ".coppermind" / "skill-router-state.json"
DEFAULT_CONFIG_PATH = Path.home() / ".coppermind" / "config.json"
DEFAULT_SESSION_KEY = "global"

# Prompts that already contain a skill invocation — skip routing
EXPLICIT_SKILL_RE = re.compile(r"/cmo-\w+", re.IGNORECASE)

# Routing table: (skill, description, compiled patterns)
# Priority order — most specific first. First match wins.
_ROUTES: list[tuple[str, str, list[re.Pattern]]] = []


def _compile_routes() -> list[tuple[str, str, list[re.Pattern]]]:
    """Build the routing table. Called once at import time."""
    table = [
        ("/cmo-prep", "meeting preparation", [
            r"prep\b.*\bmeeting",
            r"prepare\b.*\bmeeting",
            r"meeting\b.*\bprep",
            r"get\s+me\s+ready\b.*\b(for|before)",
            r"before\s+my\s+(meeting|call|sync)",
            r"brief\s+me\b.*\b(for|before|on)\b.*\b(meeting|call|sync)",
            r"agenda\s+for\b.*\bmeeting",
            r"talking\s+points\b.*\b(for|before)",
            r"what\s+should\s+i\s+(cover|bring|discuss)\b.*\bmeeting",
            r"ready\s+for\b.*\b(meeting|call|sync)",
            r"meeting\s+with\b(?!.*follow)",
        ]),
        ("/cmo-followup", "post-meeting follow-up", [
            r"follow[\s\-]?up\s+(email|note|message)",
            r"recap\s+(email|note|message)",
            r"post[\s\-]?meeting\b",
            r"after\s+(the\s+)?meeting\b.*\b(email|note|summary|recap|message)",
            r"draft\b.*\bsummary\b.*\b(email|note|message)",
            r"send\b.*\brecap",
            r"meeting\s+summary\s+(email|note|message)",
            r"thank\s+you\s+(email|note)\b.*\b(meeting|call)",
            r"write\b.*\bfollow[\s\-]?up",
            r"debrief\s+(email|note|message)",
            r"what\s+did\s+we\b.*\bdecide",
            r"capture\b.*\bmeeting\b.*\b(notes|takeaways|decisions)",
        ]),
        ("/cmo-act", "action items review", [
            r"action\s+items?\b",
            r"overdue\b.*\b(task|item|action)",
            r"open\s+tasks?\b",
            r"what\s+needs\s+doing",
            r"what('s|\s+is)\s+overdue",
            r"outstanding\b.*\b(task|item|action)",
            r"task\s+(list|review|status)",
            r"to[\s\-]?do\s+(list|review|status)",
            r"what\b.*\bpending\b",
            r"unfinished\b.*\b(task|item|work)",
            r"who\s+owes\s+(me|us)\b",
            r"deadlines?\b.*\b(coming|upcoming|this\s+week)",
        ]),
        ("/cmo-quarterly", "quarterly review", [
            r"quarterly\s+review",
            r"\bqbr\b",
            r"\bq[1-4]\s+review",
            r"90[\s\-]?day\s+review",
            r"quarter(ly)?\s+report",
            r"end\s+of\s+quarter",
            r"quarterly\s+(planning|retro|retrospective)",
            r"quarter\s+(wrap|recap|summary)",
            r"rock\s+(review|status|progress)",
            r"eos\s+review",
            r"scorecard\s+review",
            r"quarterly\s+health\b",
        ]),
        ("/cmo-weekly", "weekly review", [
            r"weekly\s+review\b",
            r"weekly\s+summary\b",
            r"weekly\s+report\b",
            r"this\s+week('s)?\s+(summary|review|report|recap)\b",
            r"last\s+week('s)?\s+(summary|review|report|recap)\b",
            r"week\s+in\s+review\b",
            r"how\b.*\bweek\b.*\bgo\b",
            r"wrap\s+up\b.*\bweek\b",
            r"end\s+of\s+week\b.*\b(review|summary|report)",
        ]),
        ("/cmo-retro", "sprint or quarter retrospective", [
            r"(sprint|retro)\s+(review|retro|retrospective)",
            r"retrospective\b",
            r"what\s+went\s+(well|wrong)\b",
            r"sprint\s+(wrap|recap|end|close)",
            r"end\s+of\s+sprint\b",
            r"how\s+did\s+(the|this|last)\s+sprint\s+go",
        ]),
        ("/cmo-handoff", "client handoff", [
            r"\bhandoff\b",
            r"transition\b.*\bclient",
            r"wrap\s+up\b.*\bengagement",
            r"\boffboard\b",
            r"hand\s+over\b.*\bclient",
            r"client\s+transition\b",
            r"end(ing)?\s+(the\s+)?engagement",
            r"leaving\b.*\bclient",
            r"transfer\b.*\bclient\b.*\b(knowledge|info|data)",
            r"exit\s+(package|document|brief)",
            r"closing\b.*\bclient\b",
            r"final\s+deliverable",
        ]),
        ("/cmo-ingest", "data ingestion", [
            r"pull\b.*\bfrom\b.*\b(granola|notion|drive|email|folder|transcript|document)",
            r"import\s+from\b",
            r"sync\b.*\bgranola",
            r"feed\s+in\b",
            r"ingest\b.*\b(from|data|transcript|notes)",
            r"grab\b.*\b(from|my)\b.*\b(granola|notion|drive|email)",
            r"load\b.*\b(transcript|notes|meeting)",
            r"bring\s+in\b.*\b(data|notes|transcript)",
            r"connect\b.*\b(granola|notion|drive)",
            r"fetch\b.*\b(from|my)\b.*\b(granola|notion|drive|email)",
            r"get\b.*\b(data|notes|transcript)\b.*\bfrom\b",
            r"search\b.*\bgranola\b",
        ]),
        ("/cmo-batch", "batch content creation", [
            r"batch\s+content\b",
            r"content\s+sprint\b",
            r"write\b.*\bfor\s+all\b.*\bclient",
            r"mass\s+content\b",
            r"bulk\s+(write|create|draft|content)",
            r"content\s+for\s+(every|all|each)\b",
            r"create\s+content\b.*\b(across|all|every)",
            r"social\s+(posts?|content)\b.*\b(all|every|each)\b.*\bclient",
            r"newsletter\b.*\b(all|every|each)\b.*\bclient",
            r"blog\s+(posts?|content)\b.*\b(all|every|each)\b.*\bclient",
            r"batch\s+(write|create|draft|produce)",
            r"content\s+blitz\b",
        ]),
        ("/cmo-audit", "marketing audit", [
            r"(marketing|digital)\s+audit\b",
            r"audit\b.*\b(marketing|tech|stack|budget|funnel)",
            r"(tech|tool|martech)\s+stack\s+(review|audit|assessment)",
            r"what('s|\s+is)\b.*\b(working|broken|missing)\b.*\bmarketing",
            r"detective\s+(mode|work|phase)",
            r"first\s+30\s+days\b",
            r"marketing\s+(assessment|diagnostic|scan)",
            r"r(ed|\.)\s*/?\s*y(ellow|\.)\s*/?\s*g(reen|\.)\b",
        ]),
        ("/cmo-strategy", "strategy deck review", [
            r"strategy\s+(deck|presentation|preso|slides?)\b",
            r"quarterly\s+(strategy|planning)\s+(deck|presentation|preso)",
            r"build\b.*\b(deck|presentation|preso|slides?)",
            r"(qbr|quarterly)\s+(deck|presentation|preso|slides?)",
            r"present(ation|ing)?\b.*\b(to|for)\b.*\b(board|ceo|leadership|exec)",
            r"strategy\s+presentation\b",
        ]),
        ("/cmo-report", "client performance report", [
            r"(monthly|quarterly|weekly)\s+report\b",
            r"(client|performance|campaign)\s+report\b",
            r"write\b.*\breport\b.*\b(for|about)\b",
            r"reporting\b.*\b(for|about|on)\b",
            r"how\s+did\b.*\b(do|perform|go)\b.*\b(this|last)\s+(month|quarter)",
            r"(month|quarter)\s+in\s+review\b",
            r"results\s+report\b",
        ]),
        ("/cmo-budget", "budget review", [
            r"(marketing|ad|advertising)\s+budget\b",
            r"budget\s+(review|audit|analysis|allocation|optimization)",
            r"(cut|reduce|trim|optimize)\b.*\bspend(ing)?\b",
            r"where\b.*\b(spending|money)\b.*\bgoing\b",
            r"vendor\b.*\b(review|evaluation|audit|cost)",
            r"(reallocate|redistribute)\b.*\bbudget\b",
            r"marketing\s+spend\b",
            r"roi\b.*\b(analysis|review|check)\b",
        ]),
        ("/cmo-campaign", "campaign planning", [
            r"plan\b.*\bcampaign\b",
            r"campaign\s+(plan|strategy|brief|idea)\b",
            r"launch\b.*\bcampaign\b",
            r"new\s+campaign\b",
            r"campaign\s+for\b",
            r"multi[\s\-]?channel\b.*\b(plan|strategy|campaign)",
            r"channel\s+(mix|strategy|plan)\b",
            r"marketing\s+(plan|strategy|initiative)\b",
        ]),
        ("/cmo-proposal", "proposal and SOW", [
            r"\bproposal\b",
            r"\bsow\b",
            r"scope\s+of\s+work\b",
            r"(new|next)\s+engagement\b",
            r"pitch\b.*\b(client|engagement|project)",
            r"write\b.*\b(proposal|sow|scope)\b",
            r"pricing\b.*\bengagement\b",
            r"renew(al)?\b.*\bengagement\b",
            r"extend\b.*\b(engagement|contract|scope)\b",
        ]),
        ("/cmo-positioning", "positioning strategy", [
            r"positioning\b.*\b(strategy|protocol|work|exercise)",
            r"brand\s+(positioning|strategy|identity)",
            r"(unique|value)\s+prop(osition)?\b",
            r"competitive\s+(positioning|differentiation|advantage)",
            r"messaging\s+(pillars?|framework|architecture)",
            r"avatar\b.*\b(exercise|worksheet|work)",
            r"care\s+(exercise|worksheet|framework)",
            r"target\s+audience\s+(definition|profile|work)",
        ]),
        ("/cmo-kickoff", "client kick-off", [
            r"kick[\s\-]?off\b",
            r"first\s+(meeting|call|session)\b.*\b(with|for)\b.*\bclient",
            r"start(ing)?\s+(the\s+)?engagement\b",
            r"engagement\s+(kick[\s\-]?off|start|launch)",
            r"day\s+one\s+plan\b",
            r"first\s+30\s+days\s+(plan|agenda|timeline)",
            r"onboarding\s+(agenda|plan|call|session)\b",
        ]),
        ("/cmo-nurture", "email nurture sequence", [
            r"(email|lead)\s+nurture\b",
            r"nurture\s+(sequence|campaign|flow|series|drip)",
            r"drip\s+(campaign|sequence|email|series)",
            r"email\s+(sequence|series|flow|automation|funnel)",
            r"welcome\s+(series|sequence|email)",
            r"automated\s+email\b",
            r"(30|60|90|180)\s*[\-]?\s*day\s+(email|nurture|sequence)",
        ]),
        ("/cmo-seo", "SEO strategy", [
            r"\bseo\s+(strategy|plan|audit|review|analysis)",
            r"\bseo\b.*\b(keyword|content|backlink|technical)",
            r"keyword\s+(strategy|research|plan|targeting)",
            r"(organic|search)\s+(traffic|ranking|visibility|strategy)",
            r"content\s+strategy\b.*\b(seo|organic|search)",
            r"backlink\s+(strategy|building|plan|audit)",
            r"local\s+seo\b",
            r"(google|search)\s+ranking\b",
            r"domain\s+(rating|authority)\b",
        ]),
        ("/cmo-team", "team assessment", [
            r"(marketing\s+)?team\s+(assessment|review|structure|evaluation)",
            r"(hire|hiring)\b.*\b(marketing|team|role)",
            r"head\s+(vs|versus|and|&)\s+hands\b",
            r"(marketing\s+)?org\s+chart\b",
            r"skill\s+gaps?\b",
            r"marketing\s+technician\b",
            r"team\s+(restructure|reorganize|rebuild)",
            r"who\s+should\s+(i|we)\s+hire\b",
            r"need\b.*\b(hire|contractor|agency|freelancer)\b",
        ]),
        ("/cmo-write", "write and review content", [
            # Formal / explicit
            r"panel\s+review\b",
            r"expert\s+(review|panel|critique)",
            r"review\b.*\b(content|copy|post|email|draft)",
            r"critique\b.*\b(content|copy|post|email|draft)",
            r"improve\b.*\b(content|copy|post|email|draft)",
            r"content\s+panel\b",
            # Create mode — natural phrasing
            r"(write|draft)\s+me\s+a\b",
            r"help\s+me\s+(write|draft)\b",
            # Review mode — informal / CMO voice
            r"punch\s+(up|this)\b",
            r"make\s+this\b.*\b(better|stronger|shorter|punchier|tighter)",
            r"tighten\s+(this|up)\b",
            r"polish\b.*\b(this|the|my)\b",
            r"what('s|\s+is)\s+wrong\s+with\b.*\b(this|the|my)\b",
            r"how\s+can\s+i\s+improve\b",
            r"is\s+this\s+any\s+good\b",
            r"does\s+this\b.*\b(work|sound)\b",
            r"too\s+(wordy|long|generic|boring|weak|vague|stiff|salesy)\b",
        ]),
        ("/cmo-brief", "daily briefing", [
            r"catch\b.*\bup\b(?!.*\b(on|about|with)\s+(?-i:[A-Z]))",
            r"what\b.*\bmiss(?!.*\b(on|about|with)\s+(?-i:[A-Z]))",
            r"morning\s+brief(ing)?",
            r"status\s+across\b",
            r"daily\s+brief(ing)?",
            r"bring\s+me\s+up\s+to\s+speed(?!.*\b(on|about|with)\s+(?-i:[A-Z]))",
            r"what('s|\s+is)\s+(going\s+on|happening)(?!.*\b(with|at)\s+(?-i:[A-Z]))",
            r"update\s+me\b(?!.*\b(on|about|with)\s+(?-i:[A-Z]))",
            r"give\s+me\b.*\b(rundown|overview|summary)(?!.*\b(on|about|of|for)\s+(?-i:[A-Z]))",
            r"what\b.*\bneed\s+to\s+know",
            r"across\s+all\b.*\bclient",
            r"how\b.*\b(my\s+)?clients?\b.*\bdoing",
        ]),
        ("/cmo-onboard", "client onboarding", [
            r"\bnew\s+client\b",
            r"\bonboard\b",
            r"set\s+up\b.*\bclient",
            r"add\s+a\s+client\b",
            r"signed?\s+a\s+new\b",
            r"client\s+onboarding\b",
            r"starting\b.*\bnew\b.*\bengagement",
        ]),
        ("/cmo-help", "help and tutorial", [
            r"what\s+can\s+you\s+do\b",
            r"how\s+does\b.*\bwork\b",
            r"\bi('m|\s+am)\s+lost\b",
            r"\btutorial\b",
            r"show\s+me\b.*\b(commands?|tools?|features?)",
            r"help\s+me\b.*\b(understand|learn|get\s+started)",
            r"what\b.*\b(commands?|tools?|features?)\b.*\b(available|have|can)",
            r"how\s+do\s+i\b.*\b(use|start|begin)",
            r"getting\s+started\b",
            r"new\s+here\b",
            r"what\s+should\s+i\b.*\b(know|learn)\b",
            r"teach\s+me\b",
        ]),
    ]
    return [
        (skill, desc, [re.compile(p, re.IGNORECASE) for p in patterns])
        for skill, desc, patterns in table
    ]


_ROUTES = _compile_routes()


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save_state(path: Path, state: dict) -> None:
    import tempfile

    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    fd, tmp_path = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        os.fchmod(fd, 0o600)
    except OSError:
        pass
    try:
        f = os.fdopen(fd, "w")
    except BaseException:
        os.close(fd)
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    try:
        with f:
            json.dump(state, f, indent=2, sort_keys=True)
        os.replace(tmp_path, str(path))
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _load_assistant_name(config_path: Path) -> str | None:
    """Load the assistant name from local config file.

    Validates: max 20 chars, alpha + spaces only. Returns None if invalid.
    """
    data = _load_json(config_path)
    name = data.get("assistant_name")
    if isinstance(name, str) and name.strip():
        name = name.strip()
        if len(name) > 20:
            return None
        if not re.match(r'^[a-zA-Z][a-zA-Z ]*$', name):
            return None
        return name
    return None


def _strip_name_prefix(prompt: str, name: str) -> str:
    """Strip assistant name prefix from prompt.

    Handles: "Julie, catch me up", "Julie: catch me up",
    "hey Julie catch me up", "Hey Julie, catch me up"
    """
    escaped = re.escape(name)
    # "Julie, ...", "Julie: ...", "Julie ..."
    pattern = re.compile(
        rf"^(?:hey\s+)?{escaped}[\s,:!\-]+",
        re.IGNORECASE,
    )
    return pattern.sub("", prompt).strip()


def _match_skill(prompt: str) -> tuple[str, str] | None:
    """Match prompt against routing table. Returns (skill, description) or None."""
    for skill, desc, patterns in _ROUTES:
        for pattern in patterns:
            if pattern.search(prompt):
                return (skill, desc)
    return None


def _already_suggested(state: dict, session_key: str, skill: str) -> bool:
    """Check if this skill was already suggested in this session."""
    session_data = state.get("sessions", {})
    if not isinstance(session_data, dict):
        return False
    suggested = session_data.get(session_key, [])
    if not isinstance(suggested, list):
        return False
    return skill in suggested


def _record_suggestion(state: dict, session_key: str, skill: str) -> dict:
    """Record that a skill was suggested in this session."""
    sessions = state.get("sessions", {})
    if not isinstance(sessions, dict):
        sessions = {}
    suggested = sessions.get(session_key, [])
    if not isinstance(suggested, list):
        suggested = []
    suggested.append(skill)
    sessions[session_key] = suggested
    timestamps = state.get("session_timestamps", {})
    if not isinstance(timestamps, dict):
        timestamps = {}
    if session_key not in timestamps:
        timestamps[session_key] = _utc_now().isoformat()
    return {"sessions": sessions, "session_timestamps": timestamps}


def _prune_stale_sessions(state: dict, max_age_hours: int = 24) -> dict:
    """Remove session entries older than max_age_hours."""
    sessions = state.get("sessions", {})
    if not isinstance(sessions, dict):
        return state
    timestamps = state.get("session_timestamps", {})
    if not isinstance(timestamps, dict):
        return state
    from coppermind_cmo.parsing import parse_datetime
    now = _utc_now()
    pruned_sessions = {}
    pruned_timestamps = {}
    for key, val in sessions.items():
        ts = timestamps.get(key)
        if not ts:
            continue  # no timestamp → prune (old format)
        parsed = parse_datetime(ts, coerce_utc=True)
        if parsed is None:
            continue  # unparseable → prune
        age = (now - parsed).total_seconds()
        if age > max_age_hours * 3600:
            continue  # expired
        pruned_sessions[key] = val
        pruned_timestamps[key] = ts
    return {"sessions": pruned_sessions, "session_timestamps": pruned_timestamps}


# Map skills to human-friendly descriptions for the context message
_SKILL_DESCRIPTIONS = {
    "/cmo-prep": "meeting preparation",
    "/cmo-followup": "a post-meeting follow-up",
    "/cmo-act": "an action items review",
    "/cmo-quarterly": "a quarterly review",
    "/cmo-handoff": "a client handoff document",
    "/cmo-ingest": "data ingestion",
    "/cmo-batch": "batch content creation",
    "/cmo-weekly": "a weekly review",
    "/cmo-retro": "a sprint or quarter retrospective",
    "/cmo-audit": "a marketing audit",
    "/cmo-strategy": "a strategy deck review",
    "/cmo-report": "a client performance report",
    "/cmo-budget": "a budget review",
    "/cmo-campaign": "campaign planning",
    "/cmo-proposal": "a proposal or SOW review",
    "/cmo-positioning": "positioning strategy work",
    "/cmo-kickoff": "client kick-off planning",
    "/cmo-nurture": "an email nurture sequence",
    "/cmo-seo": "SEO strategy",
    "/cmo-team": "a team assessment",
    "/cmo-write": "a content write & review panel",
    "/cmo-brief": "a daily briefing",
    "/cmo-onboard": "client onboarding",
    "/cmo-help": "help with Coppermind",
}


def build_hook_output(
    prompt: str,
    *,
    session_id: str | None = None,
    state_path: Path | None = None,
    config_path: Path | None = None,
) -> dict | None:
    """Return hook JSON payload when a skill should be suggested."""
    state_path = state_path or DEFAULT_STATE_PATH
    config_path = config_path or DEFAULT_CONFIG_PATH
    session_key = session_id or DEFAULT_SESSION_KEY

    if not prompt.strip():
        return None

    # Skip if user already typed a /cmo-* command
    if EXPLICIT_SKILL_RE.search(prompt):
        return None

    # Strip assistant name prefix if configured
    cleaned = prompt
    name = _load_assistant_name(config_path)
    if name:
        cleaned = _strip_name_prefix(prompt, name)

    # Match against routing table
    match = _match_skill(cleaned)
    if match is None:
        _log("debug", "No skill match", prompt_length=len(cleaned))
        return None

    skill, desc = match

    # Check rate limiting — don't suggest same skill twice per session
    state = _load_json(state_path)
    if _already_suggested(state, session_key, skill):
        _log("info", "Rate-limited", skill=skill)
        return None

    # Record this suggestion
    new_state = _record_suggestion(state, session_key, skill)
    new_state = _prune_stale_sessions(new_state)
    try:
        _save_state(state_path, new_state)
    except OSError as e:
        _log("error", "State write failed", error=str(e))
        return None

    friendly = _SKILL_DESCRIPTIONS.get(skill, desc)
    context = (
        f"COPPERMIND SKILL ROUTER:\n"
        f"The user's message looks like it might be asking for {friendly}. "
        f"If that seems right based on the full context, invoke {skill} using the Skill tool. "
        f"Pass the user's original prompt as args. "
        f"If the match seems wrong (e.g., the user is asking about something unrelated), "
        f"ignore this suggestion and respond normally."
    )

    _log("info", "Skill matched", skill=skill)
    return {
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": context,
        }
    }


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    prompt = event.get("prompt", "")
    output = build_hook_output(prompt, session_id=event.get("session_id"))
    if output:
        print(json.dumps(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
