"""Brand DNA tools: get_brand_voice, set_brand_voice.

Reference: docs/MCP_TOOLS.md and docs/SCHEMA.md Brand DNA section.
"""

import json
import re
from typing import Any

from psycopg2 import sql as pgsql

from coppermind_cmo.db import Database
from coppermind_cmo.errors import NO_ACTIVE_MIND, INVALID_INPUT, INVALID_BRAND_DNA, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb

_HEX_COLOR_RE = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")

logger = ToolLogger("brand")

BRAND_DNA_FIELDS = [
    "brand_voice", "brand_positioning", "approved_messaging",
    "stakeholders", "content_themes",
]


def _is_valid_hex_color(value: str) -> bool:
    """Return True if value is a valid 3- or 6-digit hex color (e.g. '#f00', '#ff0000')."""
    return bool(_HEX_COLOR_RE.match(value))


def _validate_visual_identity(vi: Any) -> str | None:
    """Validate the optional visual_identity section of brand_voice."""
    if not isinstance(vi, dict):
        return "visual_identity must be an object"

    string_keys = ("logo_usage", "photography_style", "graphic_treatments")
    for key in string_keys:
        if key in vi and not isinstance(vi[key], str):
            return f"visual_identity.{key} must be a string"

    if "typography" in vi:
        typo = vi["typography"]
        if not isinstance(typo, dict):
            return "visual_identity.typography must be an object"
        for k, v in typo.items():
            if not isinstance(v, str):
                return f"visual_identity.typography.{k} must be a string"

    if "color_palette" in vi:
        palette = vi["color_palette"]
        if not isinstance(palette, dict):
            return "visual_identity.color_palette must be an object"
        for k, v in palette.items():
            if not isinstance(v, str):
                return f"visual_identity.color_palette.{k} must be a string"
            if not _is_valid_hex_color(v):
                return f"visual_identity.color_palette.{k} must be a hex color (e.g. '#ff0000'), got '{v}'"

    return None


def _validate_anti_patterns(data: Any) -> tuple[str | None, list[str]]:
    """Validate anti_patterns. Returns (error, warnings)."""
    warnings: list[str] = []
    if not isinstance(data, list):
        return "anti_patterns must be a list of strings", warnings
    for i, item in enumerate(data):
        if not isinstance(item, str):
            return f"anti_patterns[{i}] must be a string", warnings
    if len(data) > 20:
        warnings.append(
            f"anti_patterns has {len(data)} items (recommended max 20). "
            "Consider consolidating related patterns."
        )
    return None, warnings


def _validate_platform_guidance(data: Any) -> str | None:
    """Validate platform_guidance section."""
    if not isinstance(data, dict):
        return "platform_guidance must be an object"
    for platform, guidance in data.items():
        if not isinstance(platform, str):
            return "platform_guidance keys must be strings"
        if not isinstance(guidance, dict):
            return f"platform_guidance.{platform} must be an object"
        for k, v in guidance.items():
            if not isinstance(v, str):
                return f"platform_guidance.{platform}.{k} must be a string"
    return None


def _validate_brand_voice(data: dict) -> tuple[str | None, list[str]]:
    """Validate brand_voice data. Returns (error, warnings).

    The caller must unpack both values.  Legacy callers that only checked
    for ``str | None`` need to be updated.
    """
    warnings: list[str] = []
    if not isinstance(data, dict):
        return "brand_voice must be an object", warnings
    if "tone" not in data or not isinstance(data["tone"], list):
        return "brand_voice requires 'tone' (list of strings)", warnings

    # --- brand_colors (from client-colored-mind-indicator) ---
    brand_colors = data.get("brand_colors", {})
    if brand_colors:
        from coppermind_cmo.colors import is_valid_hex_color
        for key, value in brand_colors.items():
            if key in ("primary", "secondary", "accent") and not is_valid_hex_color(value):
                return f"Invalid hex color for {key}: {value}. Use #RRGGBB format.", warnings

    # --- new optional sections ---
    if "visual_identity" in data:
        err = _validate_visual_identity(data["visual_identity"])
        if err:
            return err, warnings

    if "anti_patterns" in data:
        err, ap_warnings = _validate_anti_patterns(data["anti_patterns"])
        if err:
            return err, warnings
        warnings.extend(ap_warnings)

    if "platform_guidance" in data:
        err = _validate_platform_guidance(data["platform_guidance"])
        if err:
            return err, warnings

    return None, warnings


def _validate_brand_positioning(data: dict) -> str | None:
    if not isinstance(data, dict):
        return "brand_positioning must be an object"
    if "category" not in data or not isinstance(data["category"], str):
        return "brand_positioning requires 'category' (string)"
    return None


def _validate_stakeholders(data: list) -> str | None:
    if not isinstance(data, list):
        return "stakeholders must be an array"
    if len(data) > 50:
        return "stakeholders limited to 50 entries"
    for i, s in enumerate(data):
        if not isinstance(s, dict) or "name" not in s:
            return f"stakeholders[{i}] requires 'name'"
    return None


def _get_brand_voice(
    db: Database,
    active_mind: tuple[str, str] | None,
    mind_id_override: str | None = None,
) -> dict[str, Any]:
    if mind_id_override:
        mind_id = mind_id_override
    elif active_mind is not None:
        mind_id, _ = active_mind
    else:
        return NO_ACTIVE_MIND()

    row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not row:
        return tool_error("INTERNAL_ERROR", "Something went wrong loading client data. Try switching to the client again with switch_client.")

    return {
        "name": row[0],
        "brand_voice": parse_jsonb(row[1]),
        "brand_positioning": parse_jsonb(row[2]),
        "approved_messaging": parse_jsonb(row[3]),
        "stakeholders": parse_jsonb(row[4]) if row[4] else [],
        "content_themes": row[5] if row[5] else [],
    }


def _deep_merge(base: dict, overlay: dict) -> dict:
    """Recursively merge *overlay* into *base*, returning a new dict.

    - Dict values are merged recursively.
    - All other types (lists, scalars) in *overlay* replace the base value.
    """
    result = dict(base)
    for key, value in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _set_brand_voice(
    fields: dict[str, Any],
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    # Filter to valid brand DNA fields only
    updates = {k: v for k, v in fields.items() if k in BRAND_DNA_FIELDS}
    if not updates:
        return INVALID_INPUT("At least one brand DNA field is required")

    validation_warnings: list[str] = []

    # Validate shapes
    if "brand_voice" in updates:
        err, warnings = _validate_brand_voice(updates["brand_voice"])
        if err:
            return INVALID_BRAND_DNA(err)
        validation_warnings.extend(warnings)

    if "brand_positioning" in updates:
        err = _validate_brand_positioning(updates["brand_positioning"])
        if err:
            return INVALID_BRAND_DNA(err)

    if "stakeholders" in updates:
        err = _validate_stakeholders(updates["stakeholders"])
        if err:
            return INVALID_BRAND_DNA(err)

    if "content_themes" in updates:
        themes = updates["content_themes"]
        if not isinstance(themes, list):
            return INVALID_INPUT("content_themes must be a list")
        if len(themes) > 20:
            return INVALID_INPUT("Maximum 20 content_themes allowed")
        if any(len(str(t)) > 100 for t in themes):
            return INVALID_INPUT("Each content_theme must be 100 characters or fewer")

    previous = {}
    cautions = []

    # Build UPDATE and history inserts — read + write in same transaction
    try:
        with db.connection() as conn:
            with conn.cursor() as cur:
                # Read current values inside the transaction
                cur.execute(
                    "SELECT name, brand_voice, brand_positioning, approved_messaging, "
                    "stakeholders, content_themes FROM client_minds WHERE id = %s",
                    [mind_id],
                )
                row = cur.fetchone()
                if not row:
                    return tool_error("INTERNAL_ERROR", "Something went wrong loading client data. Try switching to the client again with switch_client.")
                current = {
                    "brand_voice": parse_jsonb(row[1]),
                    "brand_positioning": parse_jsonb(row[2]),
                    "approved_messaging": parse_jsonb(row[3]),
                    "stakeholders": parse_jsonb(row[4]) if row[4] else [],
                    "content_themes": row[5] if row[5] else [],
                }

                for field_name, new_value in updates.items():
                    previous[field_name] = current.get(field_name, {})

                    # Deep merge JSONB dict fields so nested keys are preserved
                    cur_val = current.get(field_name, {})
                    if (
                        field_name not in ("content_themes", "stakeholders")
                        and isinstance(cur_val, dict)
                        and isinstance(new_value, dict)
                    ):
                        merged_value = _deep_merge(cur_val, new_value)
                    else:
                        merged_value = new_value

                    # Update the field (use sql.Identifier for safe column interpolation)
                    if field_name == "content_themes":
                        # Cast Python list to text[] explicitly for psycopg2
                        cur.execute(
                            pgsql.SQL("UPDATE client_minds SET {} = %s::text[] WHERE id = %s").format(
                                pgsql.Identifier(field_name)
                            ),
                            [merged_value, mind_id],
                        )
                        prev_jsonb = json.dumps(current.get(field_name, []))
                        new_jsonb = json.dumps(merged_value)
                    else:
                        cur.execute(
                            pgsql.SQL("UPDATE client_minds SET {} = %s::jsonb WHERE id = %s").format(
                                pgsql.Identifier(field_name)
                            ),
                            [json.dumps(merged_value), mind_id],
                        )
                        prev_jsonb = json.dumps(current.get(field_name, {}))
                        new_jsonb = json.dumps(merged_value)

                    # Insert history row
                    cur.execute(
                        "INSERT INTO brand_dna_history "
                        "(mind_id, field_name, previous_value, new_value, changed_by) "
                        "VALUES (%s, %s, %s::jsonb, %s::jsonb, 'set_brand_voice')",
                        [mind_id, field_name, prev_jsonb, new_jsonb],
                    )

                conn.commit()
    except Exception as e:
        logger.error(f"Failed to update brand DNA: {e}", mind_id=mind_id)
        return tool_error("DB_ERROR", "Failed to save brand settings — the database rejected the update. Try again, and if it keeps failing contact coppermind@volacci.com.")

    # Wipe detection: warn if a populated field was cleared
    for fname, new_val in updates.items():
        cur_val = current.get(fname)
        is_new_empty = (new_val == [] or new_val == {} or new_val is None)
        if is_new_empty and bool(cur_val):
            count = len(cur_val) if isinstance(cur_val, (list, dict)) else 1
            cautions.append(
                f"{fname} was cleared (had {count} "
                f"{'entries' if isinstance(cur_val, list) else 'fields'}). "
                f"Previous value saved in 'previous'. Use set_brand_voice to restore if unintended."
            )

    logger.info(f"Updated brand DNA: {list(updates.keys())}", mind_id=mind_id)

    # Read updated values
    updated_row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not updated_row:
        return tool_error("INTERNAL_ERROR", "Brand settings were saved but couldn't be reloaded. Try get_brand_voice to confirm the update took.")

    result = {
        "name": updated_row[0],
        "brand_voice": parse_jsonb(updated_row[1]),
        "brand_positioning": parse_jsonb(updated_row[2]),
        "approved_messaging": parse_jsonb(updated_row[3]),
        "stakeholders": parse_jsonb(updated_row[4]) if updated_row[4] else [],
        "content_themes": updated_row[5] if updated_row[5] else [],
        "previous": previous,
    }
    if validation_warnings:
        cautions.extend(validation_warnings)
    if cautions:
        result["caution"] = cautions
    return result


def register(mcp_server):
    """Register brand DNA tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("get_brand_voice")
    def get_brand_voice(mind_id: str | None = None) -> dict:
        """Retrieve brand DNA. Uses the active client's mind by default, or a specific mind_id if provided."""
        set_last_tool_call("get_brand_voice")
        if mind_id:
            if not _verify_mind_access(mind_id, get_customer_id(), get_db()):
                return ACCESS_DENIED()
            result = _get_brand_voice(get_db(), get_active_mind(), mind_id_override=mind_id)
            # Warn if reading brand voice from a different mind than active
            active_mind = get_active_mind()
            if active_mind and mind_id != active_mind[0] and isinstance(result, dict) and "error" not in result:
                result["_warning"] = (
                    f"Reading brand voice from a different mind than the active client "
                    f"[{active_mind[1]}]. This is fine for CMO personal voice lookups, "
                    f"but if you meant to read {active_mind[1]}'s voice, omit the mind_id parameter."
                )
        else:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
                return ACCESS_DENIED()
            result = _get_brand_voice(get_db(), active_mind)
        # Strip stakeholders for non-owners (viewers need brand voice but not stakeholder data)
        if isinstance(result, dict) and "error" not in result:
            mind_id_to_use = mind_id if mind_id else (get_active_mind()[0] if get_active_mind() else None)
            if mind_id_to_use:
                access_level = _get_access_level(mind_id_to_use, get_customer_id(), get_db())
                if access_level != "owner":
                    result.pop("stakeholders", None)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("set_brand_voice")
    def set_brand_voice(
        brand_voice: dict | None = None,
        brand_positioning: dict | None = None,
        approved_messaging: dict | None = None,
        stakeholders: list[dict] | None = None,
        content_themes: list[str] | None = None,
    ) -> dict:
        """Update the active client's brand DNA fields."""
        set_last_tool_call("set_brand_voice")
        fields = {}
        if brand_voice is not None:
            fields["brand_voice"] = brand_voice
        if brand_positioning is not None:
            fields["brand_positioning"] = brand_positioning
        if approved_messaging is not None:
            fields["approved_messaging"] = approved_messaging
        if stakeholders is not None:
            fields["stakeholders"] = stakeholders
        if content_themes is not None:
            fields["content_themes"] = content_themes
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
        if access_level != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _set_brand_voice(fields, get_db(), active_mind)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())
