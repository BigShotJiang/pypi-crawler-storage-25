"""Update Coppermind CMO to the latest version."""

import re
import subprocess
import sys

from coppermind_cmo import __version__
from coppermind_cmo.resilience import safe_tool_call
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("update")


def register(mcp_server):
    """Register update tools on the MCP server."""

    @mcp_server.tool()
    @safe_tool_call("update_coppermind")
    def update_coppermind() -> dict:
        """Update Coppermind CMO to the latest version.

        When the user says "update Coppermind", "upgrade Coppermind",
        "please update Coppermind", or "check for updates", call this tool.

        After updating, tell the user to restart Claude Desktop or
        Claude Code for the new version to take effect.
        """
        current = __version__

        # Step 1: Check what's available on PyPI before installing anything
        latest = _check_pypi_version()

        if latest and latest == current:
            return {
                "status": "current",
                "version": current,
                "message": f"Coppermind CMO v{current} is already the latest version.",
            }

        # Step 2: Try uv tool upgrade (most common install method)
        result = _try_uv_upgrade()
        if result:
            return result

        # Step 3: Fallback to pip
        result = _try_pip_upgrade()
        if result:
            return result

        return {
            "status": "error",
            "version": current,
            "message": "Could not update automatically. Try running 'uv tool upgrade coppermind-cmo' in your terminal.",
        }


def _check_pypi_version() -> str | None:
    """Check the latest version on PyPI without installing anything."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "coppermind-cmo"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            # Output format: "coppermind-cmo (0.4.22)"
            match = re.search(r'coppermind-cmo \(([^)]+)\)', result.stdout)
            if match:
                return match.group(1)
    except Exception:
        pass

    # Fallback: check PyPI JSON API
    try:
        import httpx
        resp = httpx.get("https://pypi.org/pypi/coppermind-cmo/json", timeout=10)
        if resp.status_code == 200:
            return resp.json().get("info", {}).get("version")
    except Exception:
        pass

    return None


def _try_uv_upgrade() -> dict | None:
    """Try upgrading via uv tool. Returns result dict or None."""
    try:
        # First try normal upgrade
        result = subprocess.run(
            ["uv", "tool", "upgrade", "coppermind-cmo"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            output = result.stdout.strip()
            if "Nothing to upgrade" in output or "already" in output.lower():
                # Cache issue -- try force reinstall
                result2 = subprocess.run(
                    ["uv", "tool", "install", "--force", "--upgrade", "coppermind-cmo"],
                    capture_output=True, text=True, timeout=120,
                )
                if result2.returncode == 0:
                    new_version = _get_installed_version()
                    if new_version and new_version != __version__:
                        logger.info(f"Updated via uv --force: {__version__} -> {new_version}")
                        return {
                            "status": "updated",
                            "previous_version": __version__,
                            "new_version": new_version,
                            "message": f"Updated from v{__version__} to v{new_version}. Restart Claude to use the new version.",
                        }
                    else:
                        return {
                            "status": "current",
                            "version": __version__,
                            "message": f"Coppermind CMO v{__version__} is already the latest version.",
                        }
                return None  # Force install failed, fall through to pip
            else:
                new_version = _get_installed_version()
                logger.info(f"Updated via uv: {__version__} -> {new_version}")
                return {
                    "status": "updated",
                    "previous_version": __version__,
                    "new_version": new_version or "unknown",
                    "message": f"Updated from v{__version__} to v{new_version or 'latest'}. Restart Claude to use the new version.",
                }
    except FileNotFoundError:
        pass  # uv not found
    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "version": __version__,
            "message": "Update timed out after 2 minutes. Try running 'uv tool upgrade coppermind-cmo' manually.",
        }
    return None


def _try_pip_upgrade() -> dict | None:
    """Try upgrading via pip. Returns result dict or None."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "coppermind-cmo"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            new_version = _get_installed_version()
            logger.info(f"Updated via pip: {__version__} -> {new_version}")
            return {
                "status": "updated",
                "previous_version": __version__,
                "new_version": new_version or "unknown",
                "message": f"Updated from v{__version__} to v{new_version or 'latest'}. Restart Claude to use the new version.",
            }
    except Exception:
        pass
    return None


def _get_installed_version() -> str | None:
    """Get the currently installed version (after upgrade)."""
    try:
        result = subprocess.run(
            [sys.executable, "-c", "from coppermind_cmo import __version__; print(__version__)"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None
