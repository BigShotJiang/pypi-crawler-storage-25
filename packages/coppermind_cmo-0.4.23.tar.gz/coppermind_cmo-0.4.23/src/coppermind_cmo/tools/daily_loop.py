"""Daily loop tools: log_meeting_event, get_cross_client_summary,
get_meeting_context, mark_followup_sent, mark_transcript_ingested,
get_weekly_summary.

Reference: Sprint 2 Track 1 — Core Daily Loop.
"""

import json as _json
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.errors import NO_ACTIVE_MIND, INVALID_INPUT, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import secure_write
import coppermind_cmo.tools.memories as _memories_mod
from coppermind_cmo.tools.minds import _has_is_internal

logger = ToolLogger("daily_loop")

MAX_TITLE_CHARS = 500
VALID_CONFIDENCE_VALUES = {"confident", "ambiguous", "none"}

# ---------------------------------------------------------------------------
# Table detection cache — same pattern as memories._has_is_completed
# ---------------------------------------------------------------------------

_has_meeting_log: bool | None = None


def _has_meeting_log_table(db: Database) -> bool:
    """Check if meeting_log table exists (migration 017). Only caches True."""
    global _has_meeting_log
    if _has_meeting_log is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'meeting_log' AND table_schema = current_schema()"
            )
            if row is not None:
                _has_meeting_log = True
            return row is not None
        except Exception:
            return False
    return _has_meeting_log


# ---------------------------------------------------------------------------
# File-persisted dedup for notifications
# ---------------------------------------------------------------------------

_NOTIFICATION_STATE_FILE = Path.home() / ".coppermind" / "notification-state.json"
_notification_state: dict[str, str] | None = None


def _load_notification_state() -> dict[str, str]:
    global _notification_state
    if _notification_state is not None:
        return _notification_state
    try:
        if _NOTIFICATION_STATE_FILE.exists():
            _notification_state = _json.loads(_NOTIFICATION_STATE_FILE.read_text())
        else:
            _notification_state = {}
    except Exception:
        _notification_state = {}
    return _notification_state


def _save_notification_state():
    global _notification_state
    if _notification_state is None:
        return
    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    _notification_state = {k: v for k, v in _notification_state.items() if v > cutoff}
    try:
        secure_write(_NOTIFICATION_STATE_FILE, _json.dumps(_notification_state))
    except Exception:
        pass


def _mark_notified(key: str):
    state = _load_notification_state()
    state[key] = datetime.now(timezone.utc).isoformat()
    _save_notification_state()


def _already_notified(key: str) -> bool:
    return key in _load_notification_state()


# ---------------------------------------------------------------------------
# Tool 1: log_meeting_event
# ---------------------------------------------------------------------------

def _log_meeting_event(
    title: str,
    start_time: str,
    calendar_event_id: str | None,
    end_time: str | None,
    attendees: list[dict] | None,
    mind_id: str | None,
    match_confidence: str | None,
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Core logic for log_meeting_event tool."""
    # Validate title
    if not title or not title.strip():
        return INVALID_INPUT("title cannot be empty")
    if len(title) > MAX_TITLE_CHARS:
        return INVALID_INPUT(f"title exceeds {MAX_TITLE_CHARS} characters")

    # Validate start_time (must include timezone)
    from coppermind_cmo.parsing import parse_datetime
    parsed_start = parse_datetime(start_time, require_tz=True)
    if parsed_start is None:
        return INVALID_INPUT("start_time must be a valid ISO 8601 datetime with timezone (e.g. 2026-03-21T10:00:00-05:00 or 2026-03-21T15:00:00Z)")

    # Validate end_time if provided (must include timezone)
    parsed_end = None
    if end_time:
        parsed_end = parse_datetime(end_time, require_tz=True)
        if parsed_end is None:
            return INVALID_INPUT("end_time must be a valid ISO 8601 datetime with timezone (e.g. 2026-03-21T11:00:00-05:00 or 2026-03-21T16:00:00Z)")

    # Validate match_confidence
    confidence = match_confidence or "none"
    if confidence not in VALID_CONFIDENCE_VALUES:
        return INVALID_INPUT(
            f"match_confidence must be one of: {', '.join(sorted(VALID_CONFIDENCE_VALUES))}"
        )

    # Check if meeting_log table exists
    if not _has_meeting_log_table(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 017_meeting_log.sql to enable meeting logging.",
        )

    attendees_json = attendees or []

    if calendar_event_id:
        # Upsert on (customer_id, calendar_event_id)
        row = db.execute_returning(
            "INSERT INTO meeting_log "
            "(customer_id, mind_id, calendar_event_id, title, start_time, end_time, "
            "attendees, match_confidence) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb, %s) "
            "ON CONFLICT (customer_id, calendar_event_id) "
            "WHERE calendar_event_id IS NOT NULL "
            "DO UPDATE SET "
            "title = EXCLUDED.title, "
            "start_time = EXCLUDED.start_time, "
            "end_time = EXCLUDED.end_time, "
            "attendees = EXCLUDED.attendees, "
            "match_confidence = EXCLUDED.match_confidence, "
            "mind_id = COALESCE(EXCLUDED.mind_id, meeting_log.mind_id), "
            "updated_at = now() "
            "RETURNING id, (xmax = 0) AS is_new",
            [
                customer_id, mind_id, calendar_event_id, title.strip(),
                parsed_start.isoformat(), parsed_end.isoformat() if parsed_end else None,
                _json_dumps(attendees_json), confidence,
            ],
        )
    else:
        # Plain INSERT (no calendar_event_id for upsert)
        row = db.execute_returning(
            "INSERT INTO meeting_log "
            "(customer_id, mind_id, title, start_time, end_time, "
            "attendees, match_confidence) "
            "VALUES (%s, %s, %s, %s, %s, %s::jsonb, %s) "
            "RETURNING id, true AS is_new",
            [
                customer_id, mind_id, title.strip(),
                parsed_start.isoformat(), parsed_end.isoformat() if parsed_end else None,
                _json_dumps(attendees_json), confidence,
            ],
        )

    if not row:
        return tool_error("INTERNAL_ERROR", "Failed to insert meeting log entry")

    meeting_log_id = str(row[0])
    is_new = bool(row[1])

    logger.info(
        "Meeting logged",
        meeting_log_id=meeting_log_id,
        is_new=is_new,
        title=title.strip(),
    )

    return {
        "meeting_log_id": meeting_log_id,
        "title": title.strip(),
        "start_time": parsed_start.isoformat(),
        "mind_id": mind_id,
        "is_new": is_new,
        "match_confidence": confidence,
    }


def _json_dumps(obj: Any) -> str:
    """Serialize to JSON string for JSONB parameters."""
    import json
    return json.dumps(obj)


# ---------------------------------------------------------------------------
# Tool 2: get_cross_client_summary
# ---------------------------------------------------------------------------

def _get_cross_client_summary(
    lookback_hours: int,
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Core logic for get_cross_client_summary tool."""
    lookback_hours = max(1, lookback_hours)

    # Get all non-archived minds for this customer (owner or explicit access)
    internal_filter = "AND cm.is_internal = false " if _has_is_internal(db) else ""
    minds = db.fetch_all(
        "SELECT id, name FROM client_minds cm "
        "WHERE archived_at IS NULL "
        + internal_filter +
        "AND (cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
        ")) "
        "ORDER BY name",
        [customer_id, customer_id],
    )

    if not minds:
        return {
            "summaries": [],
            "message": "No active client minds found.",
        }

    mind_ids = [str(r[0]) for r in minds]
    mind_names = {str(r[0]): r[1] for r in minds}

    # Bulk query: memory stats (open commitments, recent memories, last activity)
    has_completed = _memories_mod._has_is_completed(db)
    if has_completed:
        completed_filter = "AND (is_completed IS NULL OR is_completed = false)"
    else:
        completed_filter = ""
    stats_rows = db.fetch_all(
        "SELECT mind_id, "
        f"COUNT(*) FILTER (WHERE memory_type = 'commitment' AND is_current = true {completed_filter}) AS open_commitments, "
        "COUNT(*) FILTER (WHERE created_at > now() - (%s * interval '1 hour') AND is_current = true) AS recent_memories, "
        "MAX(created_at) AS last_activity "
        "FROM memories "
        "WHERE mind_id = ANY(%s::uuid[]) "
        "GROUP BY mind_id",
        [lookback_hours, mind_ids],
    )
    stats_by_mind: dict[str, tuple] = {}
    for row in stats_rows:
        stats_by_mind[str(row[0])] = (row[1], row[2], row[3])

    # Bulk query: today's meetings (if meeting_log exists)
    has_meeting = _has_meeting_log_table(db)
    meetings_by_mind: dict[str, list[dict]] = {mid: [] for mid in mind_ids}
    if has_meeting:
        meeting_rows = db.fetch_all(
            "SELECT mind_id, id, title, start_time, followup_sent "
            "FROM meeting_log "
            "WHERE mind_id = ANY(%s::uuid[]) AND customer_id = %s "
            "AND start_time >= CURRENT_DATE AND start_time < CURRENT_DATE + interval '1 day' "
            "ORDER BY mind_id, start_time",
            [mind_ids, customer_id],
        )
        for mr in meeting_rows:
            mid = str(mr[0])
            if mid in meetings_by_mind:
                meetings_by_mind[mid].append({
                    "meeting_log_id": str(mr[1]),
                    "title": mr[2],
                    "start_time": mr[3].isoformat() if mr[3] else None,
                    "followup_sent": bool(mr[4]),
                })

    # Assemble summaries
    summaries = []
    for mid in mind_ids:
        stats = stats_by_mind.get(mid, (0, 0, None))
        last_activity = stats[2].isoformat() if stats[2] else None
        summaries.append({
            "mind_id": mid,
            "mind_name": mind_names[mid],
            "open_commitments": stats[0],
            "recent_memories": stats[1],
            "last_activity": last_activity,
            "todays_meetings": meetings_by_mind.get(mid, []),
        })

    # Sort by urgency: open commitments DESC, then recent activity DESC
    summaries.sort(
        key=lambda s: (s["open_commitments"], s["recent_memories"]),
        reverse=True,
    )

    return {
        "summaries": summaries,
        "lookback_hours": lookback_hours,
        "client_count": len(summaries),
    }


# ---------------------------------------------------------------------------
# Tool 3: get_meeting_context
# ---------------------------------------------------------------------------

def _get_meeting_context(
    meeting_log_id: str | None,
    mind_id: str | None,
    hours_ago: int,
    db: Database,
    customer_id: str,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    """Core logic for get_meeting_context tool."""
    # Resolve mind_id: explicit parameter > active mind
    resolved_mind_id = mind_id
    if resolved_mind_id is None:
        if active_mind is not None:
            resolved_mind_id = active_mind[0]
        else:
            return NO_ACTIVE_MIND()

    hours_ago = max(1, hours_ago)

    # Get recent memories for the mind (with tenant isolation via owner or access mapping)
    memories_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        "AND mind_id IN ("
        "    SELECT id FROM client_minds WHERE customer_id = %s "
        "    UNION SELECT mind_id FROM customer_mind_access WHERE customer_id = %s AND revoked_at IS NULL"
        ") "
        "AND created_at > now() - (%s * interval '1 hour') "
        "ORDER BY created_at DESC LIMIT 50",
        [resolved_mind_id, customer_id, customer_id, hours_ago],
    )

    recent_memories = [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "memory_type": r[3],
            "created_at": r[4].isoformat() if r[4] else None,
        }
        for r in memories_rows
    ]

    # Get the meeting brief if saved (graceful if meeting_briefs table missing)
    brief = None
    try:
        brief_row = db.fetch_one(
            "SELECT mb.id, mb.brief_markdown, mb.created_at "
            "FROM meeting_briefs mb "
            "JOIN client_minds cm ON mb.mind_id = cm.id "
            "WHERE mb.mind_id = %s "
            "AND (cm.customer_id = %s OR EXISTS ("
            "    SELECT 1 FROM customer_mind_access cma "
            "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
            ")) "
            "ORDER BY mb.created_at DESC LIMIT 1",
            [resolved_mind_id, customer_id, customer_id],
        )
        if brief_row:
            brief = {
                "brief_id": str(brief_row[0]),
                "brief_markdown": brief_row[1],
                "created_at": brief_row[2].isoformat() if brief_row[2] else None,
            }
    except Exception:
        brief = None

    # Get meeting_log entry if found
    meeting_entry = None
    has_meeting = _has_meeting_log_table(db)
    if has_meeting and meeting_log_id:
        ml_row = db.fetch_one(
            "SELECT id, title, start_time, end_time, attendees, "
            "match_confidence, transcript_ingested, followup_sent "
            "FROM meeting_log "
            "WHERE id = %s AND customer_id = %s AND mind_id = %s",
            [meeting_log_id, customer_id, resolved_mind_id],
        )
        if ml_row:
            import json
            attendees_val = ml_row[4]
            if isinstance(attendees_val, str):
                try:
                    attendees_val = json.loads(attendees_val)
                except (json.JSONDecodeError, TypeError):
                    attendees_val = []
            meeting_entry = {
                "meeting_log_id": str(ml_row[0]),
                "title": ml_row[1],
                "start_time": ml_row[2].isoformat() if ml_row[2] else None,
                "end_time": ml_row[3].isoformat() if ml_row[3] else None,
                "attendees": attendees_val if attendees_val else [],
                "match_confidence": ml_row[5],
                "transcript_ingested": bool(ml_row[6]),
                "followup_sent": bool(ml_row[7]),
            }

    return {
        "mind_id": resolved_mind_id,
        "recent_memories": recent_memories,
        "memory_count": len(recent_memories),
        "hours_ago": hours_ago,
        "brief": brief,
        "meeting_entry": meeting_entry,
    }


# ---------------------------------------------------------------------------
# Tool 4: mark_followup_sent
# ---------------------------------------------------------------------------

def _mark_followup_sent(
    meeting_log_id: str,
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Core logic for mark_followup_sent tool."""
    if not meeting_log_id or not meeting_log_id.strip():
        return INVALID_INPUT("meeting_log_id cannot be empty")

    if not _has_meeting_log_table(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 017_meeting_log.sql to enable meeting logging.",
        )

    row = db.execute_returning(
        "UPDATE meeting_log "
        "SET followup_sent = true, updated_at = now() "
        "WHERE id = %s AND customer_id = %s "
        "RETURNING id",
        [meeting_log_id, customer_id],
    )

    if not row:
        return tool_error("NOT_FOUND", "Meeting log entry not found or access denied.")

    logger.info("Follow-up marked sent", meeting_log_id=meeting_log_id)

    return {
        "meeting_log_id": meeting_log_id,
        "followup_sent": True,
    }


# ---------------------------------------------------------------------------
# Tool 5: mark_transcript_ingested
# ---------------------------------------------------------------------------

def _mark_transcript_ingested(
    meeting_log_id: str,
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Core logic for mark_transcript_ingested tool."""
    if not meeting_log_id or not meeting_log_id.strip():
        return INVALID_INPUT("meeting_log_id cannot be empty")

    if not _has_meeting_log_table(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 017_meeting_log.sql to enable meeting logging.",
        )

    row = db.execute_returning(
        "UPDATE meeting_log "
        "SET transcript_ingested = true, updated_at = now() "
        "WHERE id = %s AND customer_id = %s "
        "RETURNING id",
        [meeting_log_id, customer_id],
    )

    if not row:
        return tool_error("NOT_FOUND", "Meeting log entry not found or access denied.")

    logger.info("Transcript marked ingested", meeting_log_id=meeting_log_id)

    return {
        "meeting_log_id": meeting_log_id,
        "transcript_ingested": True,
    }


# ---------------------------------------------------------------------------
# Tool 6: get_weekly_summary
# ---------------------------------------------------------------------------

def _get_weekly_summary(
    week_start: str | None,
    week_end: str | None,
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Core logic for get_weekly_summary tool."""
    today = date.today()

    # Default: current workweek (Mon-Fri). On weekends, use the week just ended.
    from coppermind_cmo.parsing import parse_date
    if week_start:
        start_date = parse_date(week_start, strict_iso=True)
        if start_date is None:
            return INVALID_INPUT("week_start must be a valid ISO date (YYYY-MM-DD)")
    else:
        # Monday of the current workweek (weekdays 0-4).
        # On Sat/Sun (5/6), look back to the Monday that just passed.
        days_since_monday = today.weekday()
        if days_since_monday > 4:  # weekend
            days_since_monday = days_since_monday  # Sat=5, Sun=6 → back 5 or 6 days
        start_date = today - timedelta(days=days_since_monday)

    if week_end:
        end_date = parse_date(week_end, strict_iso=True)
        if end_date is None:
            return INVALID_INPUT("week_end must be a valid ISO date (YYYY-MM-DD)")
    else:
        # Friday of the same workweek as start_date
        end_date = start_date + timedelta(days=4)

    has_meeting = _has_meeting_log_table(db)

    # Get all non-archived minds for this customer (owner or explicit access)
    internal_filter = "AND cm.is_internal = false " if _has_is_internal(db) else ""
    minds = db.fetch_all(
        "SELECT id, name FROM client_minds cm "
        "WHERE archived_at IS NULL "
        + internal_filter +
        "AND (cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
        ")) "
        "ORDER BY name",
        [customer_id, customer_id],
    )

    if not minds:
        return {
            "summaries": [],
            "week_start": start_date.isoformat(),
            "week_end": end_date.isoformat(),
            "message": "No active client minds found.",
        }

    mind_ids = [str(r[0]) for r in minds]
    mind_names = {str(r[0]): r[1] for r in minds}

    # Bulk query: meeting stats per mind
    meeting_stats_by_mind: dict[str, tuple] = {}
    if has_meeting:
        meeting_stats_rows = db.fetch_all(
            "SELECT mind_id, "
            "COUNT(*), "
            "COUNT(*) FILTER (WHERE followup_sent = true), "
            "COUNT(*) FILTER (WHERE followup_sent = false) "
            "FROM meeting_log "
            "WHERE mind_id = ANY(%s::uuid[]) AND customer_id = %s "
            "AND start_time >= %s::date AND start_time < (%s::date + interval '1 day') "
            "GROUP BY mind_id",
            [mind_ids, customer_id, start_date.isoformat(), end_date.isoformat()],
        )
        for row in meeting_stats_rows:
            meeting_stats_by_mind[str(row[0])] = (row[1] or 0, row[2] or 0, row[3] or 0)

    # Bulk query: memories by type per mind (created this week)
    type_rows = db.fetch_all(
        "SELECT mind_id, memory_type, COUNT(*) "
        "FROM memories "
        "WHERE mind_id = ANY(%s::uuid[]) AND is_current = true "
        "AND created_at::date >= %s AND created_at::date <= %s "
        "GROUP BY mind_id, memory_type",
        [mind_ids, start_date.isoformat(), end_date.isoformat()],
    )
    types_by_mind: dict[str, dict[str, int]] = {mid: {} for mid in mind_ids}
    for row in type_rows:
        mid = str(row[0])
        if mid in types_by_mind:
            types_by_mind[mid][row[1]] = row[2]

    # Bulk query: open commitments per mind
    has_completed = _memories_mod._has_is_completed(db)
    if has_completed:
        completed_filter = "AND (is_completed IS NULL OR is_completed = false)"
    else:
        completed_filter = ""
    commitment_rows = db.fetch_all(
        "SELECT mind_id, COUNT(*) FROM memories "
        "WHERE mind_id = ANY(%s::uuid[]) AND memory_type = 'commitment' "
        f"AND is_current = true {completed_filter} "
        "GROUP BY mind_id",
        [mind_ids],
    )
    commitments_by_mind: dict[str, int] = {}
    for row in commitment_rows:
        commitments_by_mind[str(row[0])] = row[1]

    # Assemble summaries
    summaries = []
    for mid in mind_ids:
        ms = meeting_stats_by_mind.get(mid, (0, 0, 0))
        summaries.append({
            "mind_id": mid,
            "mind_name": mind_names[mid],
            "meetings_held": ms[0],
            "followups_sent": ms[1],
            "followups_pending": ms[2],
            "memories_by_type": types_by_mind.get(mid, {}),
            "open_commitments": commitments_by_mind.get(mid, 0),
        })

    return {
        "summaries": summaries,
        "week_start": start_date.isoformat(),
        "week_end": end_date.isoformat(),
        "client_count": len(summaries),
    }


# ---------------------------------------------------------------------------
# Notification helper
# ---------------------------------------------------------------------------

def get_daily_loop_notifications(
    db: Database,
    customer_id: str,
) -> list[dict]:
    """Check meeting_log for actionable notifications.

    Returns list of notification dicts. Session-scoped dedup via module-level set.
    Graceful: returns [] if meeting_log table doesn't exist.
    """
    if not _has_meeting_log_table(db):
        return []

    now = datetime.now(timezone.utc)
    notifications: list[dict] = []

    # 1. Meetings >4 hours old with followup_sent=false → "follow-up nag"
    nag_rows = db.fetch_all(
        "SELECT id, title, start_time "
        "FROM meeting_log "
        "WHERE customer_id = %s "
        "AND followup_sent = false "
        "AND start_time < now() - interval '4 hours' "
        "AND start_time > now() - interval '7 days' "
        "ORDER BY start_time DESC",
        [customer_id],
    )
    for r in nag_rows:
        mid = str(r[0])
        key = f"nag-{customer_id}-{mid}"
        if not _already_notified(key):
            _mark_notified(key)
            hours_ago = int((now - r[2].astimezone(timezone.utc)).total_seconds() / 3600) if r[2] else 0
            notifications.append({
                "type": "followup_nag",
                "meeting_log_id": mid,
                "title": r[1],
                "hours_ago": hours_ago,
                "message": (
                    f"Reminder: You haven't sent a follow-up for '{r[1]}' "
                    f"({hours_ago}h ago). Use /cmo-followup or call mark_followup_sent "
                    f"when done."
                ),
            })

    # 2. Meetings >1 hour old with transcript_ingested=false → "ingest suggestion"
    ingest_rows = db.fetch_all(
        "SELECT id, title, start_time "
        "FROM meeting_log "
        "WHERE customer_id = %s "
        "AND transcript_ingested = false "
        "AND start_time < now() - interval '1 hour' "
        "AND start_time > now() - interval '2 days' "
        "ORDER BY start_time DESC",
        [customer_id],
    )
    for r in ingest_rows:
        mid = str(r[0])
        key = f"ingest-{customer_id}-{mid}"
        if not _already_notified(key):
            _mark_notified(key)
            notifications.append({
                "type": "ingest_suggestion",
                "meeting_log_id": mid,
                "title": r[1],
                "message": (
                    f"Tip: Meeting '{r[1]}' doesn't have a transcript yet. "
                    f"Paste the transcript or notes to capture memories."
                ),
            })

    # 3. Friday after 3pm → weekly review reminder
    if now.weekday() == 4 and now.hour >= 15:
        week_key = f"weekly-{customer_id}-{now.year}-{now.isocalendar()[1]}"
        if not _already_notified(week_key):
            _mark_notified(week_key)
            notifications.append({
                "type": "weekly_review_reminder",
                "message": (
                    "It's Friday afternoon — good time for a weekly review. "
                    "Use /cmo-weekly to see your cross-client summary."
                ),
            })

    return notifications


# Register daily loop notifications with the global provider registry.
from coppermind_cmo.background import register_notification_provider
register_notification_provider(get_daily_loop_notifications)


def _attach_all_notifications(result: dict | list, db: Database, customer_id: str) -> dict | list:
    """Attach all notifications (background + daily loop) to a result.

    Delegates to background.attach_notifications which now calls registered providers.
    """
    from coppermind_cmo.background import attach_notifications
    return attach_notifications(result, customer_id=customer_id, db=db)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(mcp_server):  # pragma: no cover
    """Register daily loop tools on the MCP server."""
    from coppermind_cmo.server import (
        get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id,
    )
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("log_meeting_event")
    def log_meeting_event(
        title: str,
        start_time: str,
        calendar_event_id: str | None = None,
        end_time: str | None = None,
        attendees: list[dict] | None = None,
        mind_id: str | None = None,
        match_confidence: str | None = None,
    ) -> dict:
        """Log a meeting from the calendar into the daily loop tracker.

        Upserts when calendar_event_id is provided (same event updates existing record).

        Parameters:
        - title: Meeting title (required, max 500 chars)
        - start_time: ISO 8601 datetime string (required)
        - calendar_event_id: Calendar provider event ID for upsert (optional)
        - end_time: ISO 8601 datetime string (optional)
        - attendees: List of attendee dicts (optional)
        - mind_id: Client mind UUID to associate (optional)
        - match_confidence: confident, ambiguous, or none (optional, default none)
        """
        set_last_tool_call("log_meeting_event")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        active_mind = get_active_mind()
        if active_mind:
            if _get_access_level(active_mind[0], customer_id, get_db()) != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _log_meeting_event(
            title, start_time, calendar_event_id, end_time,
            attendees, mind_id, match_confidence, get_db(), customer_id,
        )
        return _attach_all_notifications(result, get_db(), customer_id)

    @mcp_server.tool()
    @safe_tool_call("get_cross_client_summary")
    def get_cross_client_summary(lookback_hours: int = 48) -> dict:
        """Get a cross-client summary of all minds — meetings, commitments, recent activity.

        Does NOT require an active mind. Shows all clients for this customer.

        Parameters:
        - lookback_hours: How far back to count recent memories (default 48)
        """
        set_last_tool_call("get_cross_client_summary")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        active_mind = get_active_mind()
        if active_mind:
            access_level = _get_access_level(active_mind[0], customer_id, get_db())
            if access_level != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _get_cross_client_summary(lookback_hours, get_db(), customer_id)
        return _attach_all_notifications(result, get_db(), customer_id)

    @mcp_server.tool()
    @safe_tool_call("get_meeting_context")
    def get_meeting_context(
        meeting_log_id: str | None = None,
        mind_id: str | None = None,
        hours_ago: int = 6,
    ) -> dict:
        """Get context for a meeting — recent memories, brief, and meeting log entry.

        Requires an active mind or explicit mind_id.

        Parameters:
        - meeting_log_id: UUID of a meeting_log entry (optional)
        - mind_id: Client mind UUID (optional, uses active mind if not provided)
        - hours_ago: How far back to look for memories (default 6)
        """
        set_last_tool_call("get_meeting_context")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        resolved_mind_id = mind_id or (get_active_mind() or (None,))[0]
        if resolved_mind_id:
            if not _verify_mind_access(resolved_mind_id, customer_id, get_db()):
                return ACCESS_DENIED()
            if _get_access_level(resolved_mind_id, customer_id, get_db()) != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _get_meeting_context(
            meeting_log_id, mind_id, hours_ago,
            get_db(), customer_id, get_active_mind(),
        )
        return _attach_all_notifications(result, get_db(), customer_id)

    @mcp_server.tool()
    @safe_tool_call("mark_followup_sent")
    def mark_followup_sent(meeting_log_id: str) -> dict:
        """Mark a meeting's follow-up as sent.

        Parameters:
        - meeting_log_id: UUID of the meeting_log entry (required)
        """
        set_last_tool_call("mark_followup_sent")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        active_mind = get_active_mind()
        if active_mind:
            if _get_access_level(active_mind[0], customer_id, get_db()) != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _mark_followup_sent(meeting_log_id, get_db(), customer_id)
        return _attach_all_notifications(result, get_db(), customer_id)

    @mcp_server.tool()
    @safe_tool_call("mark_transcript_ingested")
    def mark_transcript_ingested(meeting_log_id: str) -> dict:
        """Mark a meeting's transcript as ingested.

        Call after ingesting a meeting transcript. Stops the ingest suggestion notification.

        Parameters:
        - meeting_log_id: UUID of the meeting_log entry (required)
        """
        set_last_tool_call("mark_transcript_ingested")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        active_mind = get_active_mind()
        if active_mind:
            if _get_access_level(active_mind[0], customer_id, get_db()) != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _mark_transcript_ingested(meeting_log_id, get_db(), customer_id)
        return _attach_all_notifications(result, get_db(), customer_id)

    @mcp_server.tool()
    @safe_tool_call("get_weekly_summary")
    def get_weekly_summary(
        week_start: str | None = None,
        week_end: str | None = None,
    ) -> dict:
        """Get a cross-client weekly summary — meetings, memories, commitments, follow-ups.

        Does NOT require an active mind. Covers all clients.

        Parameters:
        - week_start: ISO date (default: last Monday)
        - week_end: ISO date (default: this Friday)
        """
        set_last_tool_call("get_weekly_summary")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        active_mind = get_active_mind()
        if active_mind:
            access_level = _get_access_level(active_mind[0], customer_id, get_db())
            if access_level != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _get_weekly_summary(week_start, week_end, get_db(), customer_id)
        return _attach_all_notifications(result, get_db(), customer_id)
