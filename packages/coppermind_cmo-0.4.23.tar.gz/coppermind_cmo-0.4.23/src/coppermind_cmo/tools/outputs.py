"""Save generated outputs to the client's local Coppermind folder.

Reference: docs/MCP_TOOLS.md -- save_output (write markdown outputs to disk).
"""

import os
import tempfile
from datetime import datetime, timezone

from coppermind_cmo.db import Database
from coppermind_cmo.errors import NO_ACTIVE_MIND, INVALID_INPUT, tool_error
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("outputs")

VALID_OUTPUT_TYPES = {
    "brief": "Briefs",
    "content": "Content",
    "meeting": "Meetings",
    "report": "Reports",
    "strategy": "Strategy",
    "handoff": "Handoff",
}


def _save_output(
    content: str,
    output_type: str,
    filename: str | None,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    # Validate output_type
    if output_type not in VALID_OUTPUT_TYPES:
        return INVALID_INPUT(
            f"Invalid output_type '{output_type}'. "
            f"Valid types: {', '.join(sorted(VALID_OUTPUT_TYPES.keys()))}"
        )

    # Validate content
    if not content or not content.strip():
        return INVALID_INPUT("content cannot be empty")

    # Query local_path and slug for the active mind
    row = db.fetch_one(
        "SELECT local_path, slug FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not row:
        return tool_error("INTERNAL_ERROR", "Active mind not found in database")

    local_path, slug = row

    if not local_path:
        return {
            "status": "skipped",
            "reason": "No local_path configured for this client. Use configure_mind to set one.",
        }

    # Map output_type to subfolder
    subfolder = VALID_OUTPUT_TYPES[output_type]

    # Generate filename if not provided
    if not filename:
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        filename = f"{date_str}-{output_type}.md"

    # Sanitize filename — strip path separators to prevent traversal
    filename = os.path.basename(filename)

    # Build full path
    subfolder_path = os.path.join(local_path, "Coppermind", subfolder)
    full_path = os.path.join(subfolder_path, filename)

    # Ensure the resolved path stays within the intended subfolder
    if not os.path.realpath(full_path).startswith(os.path.realpath(subfolder_path) + os.sep):
        return INVALID_INPUT("Filename must not contain path traversal characters")

    # Ensure subfolder exists (in case it was deleted)
    try:
        os.makedirs(subfolder_path, exist_ok=True)
    except OSError as e:
        logger.warn(f"Failed to create subfolder: {e}", mind_id=mind_id)
        return {"status": "error", "reason": str(e)}

    # Write atomically: write to .tmp then rename
    try:
        fd, tmp_path = tempfile.mkstemp(dir=subfolder_path, suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                f.write(content)
            os.replace(tmp_path, full_path)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except OSError as e:
        logger.warn(f"Failed to write output file: {e}", mind_id=mind_id)
        return {"status": "error", "reason": str(e)}

    logger.info(
        f"Saved {output_type} output to {full_path}",
        mind_id=mind_id,
        subfolder=subfolder,
        filename=filename,
    )

    return {
        "status": "saved",
        "path": full_path,
        "subfolder": subfolder,
        "filename": filename,
    }


def register(mcp_server):
    """Register output tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_active_mind, set_last_tool_call, get_customer_id, stamp_active_client
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("save_output")
    def save_output(
        content: str,
        output_type: str,
        filename: str | None = None,
    ) -> dict:
        """Save generated markdown output to the client's local Coppermind folder.

        Writes content to the appropriate subfolder based on output_type.
        Requires local_path to be configured via configure_mind.

        Parameters:
        - content: The markdown content to save
        - output_type: One of "brief", "content", "meeting", "report", "strategy", "handoff"
        - filename: Custom filename (optional). Auto-generates as YYYY-MM-DD-{type}.md if not provided.
        """
        set_last_tool_call("save_output")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if active_mind and _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_save_output(content, output_type, filename, get_db(), active_mind))
