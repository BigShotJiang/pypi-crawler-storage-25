"""Access enforcement helpers for team sharing.

Provides access level resolution, query filter generation, and helpers for
owner-only access enforcement.
"""

from __future__ import annotations

from coppermind_cmo.db import Database


VIEWER_DEFAULT_ALLOWED_TYPES: tuple[str, ...] = (
    "commitment", "campaign_outcome", "fact", "question",
)


def _get_access_level(mind_id: str, customer_id: str | None, db: Database) -> str | None:
    """Return 'owner', 'viewer', 'editor', or None.

    Checks direct ownership first (client_minds), then customer_mind_access
    grant (excluding revoked).
    """
    if customer_id is None:
        return None

    # Check direct ownership via client_minds table
    row = db.fetch_one(
        "SELECT 1 FROM client_minds WHERE id = %s AND customer_id = %s",
        (mind_id, customer_id),
    )
    if row is not None:
        return "owner"

    # Check access grant in customer_mind_access, excluding revoked rows
    row = db.fetch_one(
        "SELECT access_level FROM customer_mind_access "
        "WHERE mind_id = %s AND customer_id = %s AND revoked_at IS NULL",
        (mind_id, customer_id),
    )
    if row is not None:
        return row[0]

    return None


def _access_filters(
    access_level: str,
    caller_id: str,
    allowed_types: list[str] | None = None,
) -> tuple[str, list]:
    """Return (sql_fragment, params) for memory query WHERE clause.

    Owner: AND status != 'pending'
    Viewer: AND memory_type IN (...) AND sensitivity = 'open'
            AND (status = 'active' OR (status = 'pending' AND created_by = %s))
    """
    if access_level == "owner":
        return "AND status != 'pending'", []

    # Viewer (and editor for now uses same rules)
    types = list(allowed_types) if allowed_types is not None else list(VIEWER_DEFAULT_ALLOWED_TYPES)
    if not types:
        # Empty list means the owner configured viewer_allowed_types: [] — block all viewer access
        return "AND false", []
    placeholders = ", ".join(["%s"] * len(types))
    sql = (
        f"AND memory_type IN ({placeholders}) "
        "AND sensitivity = 'open' "
        "AND (status = 'active' OR (status = 'pending' AND created_by = %s))"
    )
    params = types + [caller_id]
    return sql, params


def get_viewer_allowed_types(sharing_config: dict | None) -> list[str] | None:
    """Extract viewer_allowed_types from mind's sharing_config, or None for defaults."""
    if not sharing_config:
        return None
    return sharing_config.get("viewer_allowed_types", None)


