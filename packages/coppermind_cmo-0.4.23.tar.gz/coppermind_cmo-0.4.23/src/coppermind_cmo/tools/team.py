"""Team management and pending review tools.

Provides 7 MCP tools for team sharing (Phase 2.5):
- add_team_member, remove_team_member, list_team
- list_pending, promote_pending, dismiss_pending, rollback_pending

All tools require owner access. Viewers cannot manage team or pending memories.
"""

from __future__ import annotations

from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.errors import (
    ACCESS_DENIED,
    INVALID_INPUT,
    NO_ACTIVE_MIND,
    tool_error,
)
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("team")

# Phase 2.5: only viewer access can be granted to team members
_VALID_GRANT_LEVELS = ("viewer",)


# ---------------------------------------------------------------------------
# Team management helpers
# ---------------------------------------------------------------------------

def _add_team_member(
    customer_id: str,
    access_level: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    owner_id: str,
    mind_name: str | None = None,
) -> dict[str, Any]:
    """UPSERT a team member into customer_mind_access.

    - Validates access_level is 'viewer' (only valid level in Phase 2.5).
    - Rejects self-add (customer_id == owner_id).
    - Rejects empty customer_id.
    - ON CONFLICT: resets revoked_at=NULL, updates access_level and granted_at.
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    if not customer_id or not customer_id.strip():
        return INVALID_INPUT("customer_id cannot be empty")

    if customer_id == owner_id:
        return INVALID_INPUT("Cannot add yourself as a team member — you are already the owner")

    if access_level not in _VALID_GRANT_LEVELS:
        valid = ", ".join(_VALID_GRANT_LEVELS)
        return INVALID_INPUT(
            f"Invalid access_level '{access_level}'. Valid levels in Phase 2.5: {valid}"
        )

    db.execute(
        "INSERT INTO customer_mind_access (customer_id, mind_id, access_level, granted_at) "
        "VALUES (%s, %s, %s, now()) "
        "ON CONFLICT (customer_id, mind_id) DO UPDATE SET "
        "access_level = EXCLUDED.access_level, "
        "granted_at = now(), "
        "revoked_at = NULL, "
        "revoked_by = NULL",
        [customer_id, mind_id, access_level],
    )

    logger.info("Team member added", mind_id=mind_id, customer_id=customer_id, access_level=access_level)

    return {
        "customer_id": customer_id,
        "mind_id": mind_id,
        "access_level": access_level,
        "granted": True,
    }


def _remove_team_member(
    customer_id: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    owner_id: str,
) -> dict[str, Any]:
    """Soft-delete: SET revoked_at=now(), revoked_by=owner_id.

    Returns NOT_FOUND if no active grant exists.
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    row = db.execute_returning(
        "UPDATE customer_mind_access "
        "SET revoked_at = now(), revoked_by = %s "
        "WHERE mind_id = %s AND customer_id = %s AND revoked_at IS NULL "
        "RETURNING customer_id",
        [owner_id, mind_id, customer_id],
    )

    if row is None:
        return tool_error("NOT_FOUND", f"No active grant found for customer '{customer_id}' on this mind")

    logger.info("Team member removed", mind_id=mind_id, customer_id=customer_id, removed_by=owner_id)

    return {
        "customer_id": row[0],
        "mind_id": mind_id,
        "revoked": True,
    }


def _list_team(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """List active team members (excludes owner and revoked entries)."""
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    rows = db.fetch_all(
        "SELECT customer_id, access_level, granted_at "
        "FROM customer_mind_access "
        "WHERE mind_id = %s AND access_level != 'owner' AND revoked_at IS NULL "
        "ORDER BY granted_at DESC",
        [mind_id],
    )

    return [
        {
            "customer_id": r[0],
            "access_level": r[1],
            "granted_at": r[2].isoformat() if r[2] else None,
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Pending review helpers
# ---------------------------------------------------------------------------

def _build_pending_filters(
    created_by: str | None,
    since: str | None,
    base_params: list,
) -> tuple[str, list]:
    """Return (additional_sql_clauses, extended_params) for pending memory filters."""
    extra_clauses = ""
    params = list(base_params)

    if created_by is not None:
        extra_clauses += " AND created_by = %s"
        params.append(created_by)

    if since is not None:
        extra_clauses += " AND created_at >= %s"
        params.append(since)

    return extra_clauses, params


def _list_pending(
    db: Database,
    active_mind: tuple[str, str] | None,
    created_by: str | None = None,
    since: str | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """List pending memories awaiting owner review.

    Optional filters:
    - created_by: filter by memory author
    - since: filter by created_at >= value
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    extra_clauses, params = _build_pending_filters(created_by, since, [mind_id])

    rows = db.fetch_all(
        "SELECT id, content, memory_type, created_by, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND status = 'pending'"
        + extra_clauses
        + " ORDER BY created_at DESC",
        params,
    )

    return [
        {
            "id": str(r[0]),
            "content": r[1][:200] if r[1] else "",
            "memory_type": r[2],
            "created_by": r[3],
            "created_at": r[4].isoformat() if r[4] else None,
        }
        for r in rows
    ]


def _promote_pending(
    created_by: str | None,
    since: str | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    owner_id: str,
) -> dict[str, Any]:
    """Batch-promote pending memories to active.

    Requires at least one of created_by or since.
    Sets status='active', promoted_by=owner_id, promoted_at=now().
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    if created_by is None and since is None:
        return INVALID_INPUT("At least one filter is required: created_by or since")

    mind_id, _ = active_mind

    extra_clauses, params = _build_pending_filters(created_by, since, [owner_id, mind_id])

    rows = db.fetch_all(
        "UPDATE memories "
        "SET status = 'active', promoted_by = %s, promoted_at = now() "
        "WHERE mind_id = %s AND status = 'pending'"
        + extra_clauses
        + " RETURNING id",
        params,
    )
    count = len(rows)

    logger.info("Pending memories promoted", mind_id=mind_id, promoted_by=owner_id, count=count)

    return {
        "promoted": count,
        "mind_id": mind_id,
        "promoted_by": owner_id,
    }


def _dismiss_pending(
    created_by: str | None,
    since: str | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    owner_id: str,
) -> dict[str, Any]:
    """Batch-dismiss pending memories.

    Requires at least one of created_by or since.
    Sets status='dismissed', dismissed_by=owner_id, dismissed_at=now().
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    if created_by is None and since is None:
        return INVALID_INPUT("At least one filter is required: created_by or since")

    mind_id, _ = active_mind

    extra_clauses, params = _build_pending_filters(created_by, since, [owner_id, mind_id])

    rows = db.fetch_all(
        "UPDATE memories "
        "SET status = 'dismissed', dismissed_by = %s, dismissed_at = now() "
        "WHERE mind_id = %s AND status = 'pending'"
        + extra_clauses
        + " RETURNING id",
        params,
    )
    count = len(rows)

    logger.info("Pending memories dismissed", mind_id=mind_id, dismissed_by=owner_id, count=count)

    return {
        "dismissed": count,
        "mind_id": mind_id,
        "dismissed_by": owner_id,
    }


def _rollback_pending(
    created_by: str | None,
    since: str | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    owner_id: str,
) -> dict[str, Any]:
    """Revert previously promoted memories back to dismissed.

    Targets status='active' AND promoted_at IS NOT NULL (i.e., promoted via promote_pending).
    Requires at least one of created_by or since.
    Sets status='dismissed', dismissed_by=owner_id, dismissed_at=now().
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    if created_by is None and since is None:
        return INVALID_INPUT("At least one filter is required: created_by or since")

    mind_id, _ = active_mind

    extra_clauses, params = _build_pending_filters(created_by, since, [owner_id, mind_id])

    rows = db.fetch_all(
        "UPDATE memories "
        "SET status = 'dismissed', dismissed_by = %s, dismissed_at = now() "
        "WHERE mind_id = %s AND status = 'active' AND promoted_at IS NOT NULL"
        + extra_clauses
        + " RETURNING id",
        params,
    )
    count = len(rows)

    logger.info("Promoted memories rolled back", mind_id=mind_id, rolled_back_by=owner_id, count=count)

    return {
        "rolled_back": count,
        "mind_id": mind_id,
        "rolled_back_by": owner_id,
    }


# ---------------------------------------------------------------------------
# MCP tool registration
# ---------------------------------------------------------------------------

def register(mcp):
    """Register all 7 team management MCP tools."""
    from coppermind_cmo.server import get_active_mind, get_customer_id
    from coppermind_cmo.db import Database as _Database
    from coppermind_cmo.tools.access import _get_access_level
    from coppermind_cmo.resilience import safe_tool_call

    @mcp.tool()
    @safe_tool_call("add_team_member")
    def add_team_member(
        customer_id: str,
        mind_name: str | None = None,
        access_level: str = "viewer",
    ) -> dict:
        """Add a team member (like a VA) to the active client mind.

        They get viewer access: search memories, prep meetings, read brand
        voice, write on-brand content. Notes they add go to a pending queue
        for owner review. They cannot modify existing memories or config.

        IMPORTANT — present the user with TWO clear paths. Do not ramble.
        Ask "Do they already have a Coppermind account?" then show:

        If they already have an account:
          1. Ask them to open Claude and say "list my minds"
          2. Their customer ID will be in the response
          3. Give me that ID and I'll connect them right away

        If they don't have an account yet:
          1. Email coppermind@volacci.com with their name and email
          2. We'll send them install instructions
          3. Once they're set up, come back here and we'll connect them

        Do NOT call this tool until you have a customer_id.
        """
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Adding team members requires owner access.")
            return _add_team_member(
                customer_id, access_level, db, active_mind, caller_id, mind_name=mind_name
            )

    @mcp.tool()
    @safe_tool_call("remove_team_member")
    def remove_team_member(customer_id: str) -> dict:
        """Revoke a team member's access to the active mind (soft-delete)."""
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Removing team members requires owner access.")
            return _remove_team_member(customer_id, db, active_mind, caller_id)

    @mcp.tool()
    @safe_tool_call("list_team")
    def list_team() -> dict:
        """List team members with access to the active mind."""
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Listing team members requires owner access.")
            return _list_team(db, active_mind)

    @mcp.tool()
    @safe_tool_call("list_pending")
    def list_pending(
        created_by: str | None = None,
        since: str | None = None,
    ) -> dict:
        """List pending memories awaiting review.

        Optional filters:
        - created_by: show only memories from this team member's customer_id
        - since: show only memories created on or after this ISO date (e.g. '2025-01-01')
        """
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Reviewing pending memories requires owner access.")
            return _list_pending(db, active_mind, created_by=created_by, since=since)

    @mcp.tool()
    @safe_tool_call("promote_pending")
    def promote_pending(
        created_by: str | None = None,
        since: str | None = None,
    ) -> dict:
        """Batch-promote pending memories to active. At least one filter required.

        - created_by: promote all pending memories from this team member
        - since: promote all pending memories created on or after this ISO date
        """
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Promoting memories requires owner access.")
            return _promote_pending(created_by, since, db, active_mind, caller_id)

    @mcp.tool()
    @safe_tool_call("dismiss_pending")
    def dismiss_pending(
        created_by: str | None = None,
        since: str | None = None,
    ) -> dict:
        """Batch-dismiss pending memories. At least one filter required.

        - created_by: dismiss all pending memories from this team member
        - since: dismiss all pending memories created on or after this ISO date
        """
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Dismissing memories requires owner access.")
            return _dismiss_pending(created_by, since, db, active_mind, caller_id)

    @mcp.tool()
    @safe_tool_call("rollback_pending")
    def rollback_pending(
        created_by: str | None = None,
        since: str | None = None,
    ) -> dict:
        """Revert promoted memories to dismissed. At least one filter required.

        Undoes a previous promote_pending action. Only affects memories that
        were promoted (status='active' AND promoted_at IS NOT NULL).
        """
        caller_id = get_customer_id()
        with _Database() as db:
            active_mind = get_active_mind()
            if active_mind is None:
                return NO_ACTIVE_MIND()
            level = _get_access_level(active_mind[0], caller_id, db)
            if level != "owner":
                return ACCESS_DENIED("Rolling back memories requires owner access.")
            return _rollback_pending(created_by, since, db, active_mind, caller_id)
