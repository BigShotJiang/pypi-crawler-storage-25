"""switch_client and list_minds tool implementations.

Reference: docs/MCP_TOOLS.md switch_client and list_minds sections.
"""

import os
import re
from datetime import datetime, timezone
from pathlib import Path as _Path
from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.active_client import update_active_client
import json

from coppermind_cmo.errors import (
    INVALID_INPUT, NO_ACTIVE_MIND, MIND_NOT_FOUND, MIND_ARCHIVED, ACCESS_DENIED,
    tool_error,
)
from coppermind_cmo.utils import parse_jsonb
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.tips import get_next_tip

logger = ToolLogger("minds")

STALE_THRESHOLD_DAYS = 30  # Flag "Last activity: X days ago" when older than this

# Dangerous system directories that should never be used as local_path
# Includes /private/etc for macOS where /etc -> /private/etc.
_FORBIDDEN_PREFIXES = (
    "/etc", "/usr", "/sys", "/proc", "/dev", "/sbin", "/bin",
    "/private/etc",
)
_FORBIDDEN_PATHS = (
    os.path.expanduser("~/.ssh"),
    os.path.expanduser("~/.claude"),
    os.path.expanduser("~/.gnupg"),
    os.path.expanduser("~/.aws"),
    os.path.expanduser("~/.config"),
)


def _get_tip_for_switch(mind_id: str, mind_name: str, company_info: dict, db: Database) -> dict | None:
    """Get personalized tip for this session. Returns None if no tip to show."""
    try:
        from coppermind_cmo.server import get_config
        config = get_config()
        customer_id = getattr(config, 'customer_id', None)
        return get_next_tip(customer_id, mind_id, mind_name, company_info, db)
    except Exception as e:
        logger.warn("Tip lookup failed", error=str(e))
        return None

_has_internal_col: bool | None = None
_has_local_path_col: bool | None = None
_has_revoked_at_col: bool | None = None


def _has_is_internal(db: Database) -> bool:
    """Check if is_internal column exists (migration 007). Only caches True."""
    global _has_internal_col
    if _has_internal_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'client_minds' AND column_name = 'is_internal' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_internal_col = True
            return row is not None
        except Exception:
            return False
    return _has_internal_col


def _has_local_path(db: Database) -> bool:
    """Check if local_path column exists (migration 016). Only caches True."""
    global _has_local_path_col
    if _has_local_path_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'client_minds' AND column_name = 'local_path' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_local_path_col = True
            return row is not None
        except Exception:
            return False
    return _has_local_path_col


def _has_revoked_at(db: Database) -> bool:
    """Check if revoked_at column exists on customer_mind_access (team sharing migration). Only caches True."""
    global _has_revoked_at_col
    if _has_revoked_at_col is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_name = 'customer_mind_access' AND column_name = 'revoked_at' "
                "AND table_schema = current_schema()"
            )
            if row is not None:
                _has_revoked_at_col = True
            return row is not None
        except Exception:
            return False
    return _has_revoked_at_col


def _extract_text(obj: Any) -> str:
    """Recursively extract string values from a nested dict/list."""
    if isinstance(obj, str):
        return obj
    if isinstance(obj, list):
        return " ".join(_extract_text(i) for i in obj)
    if isinstance(obj, dict):
        return " ".join(_extract_text(v) for v in obj.values())
    return ""


def _collect_mind_stats(
    mind_id: str,
    db: Database,
    brand_voice: dict | None = None,
    cadence: dict | None = None,
) -> dict[str, Any]:
    """Collect lightweight stats for a mind after switch.

    Accepts pre-fetched brand_voice and cadence to avoid re-querying
    client_minds (already fetched during switch resolution).
    """
    from coppermind_cmo.tools.daily_loop import _has_meeting_log_table

    stats: dict[str, Any] = {}

    # Brand voice status (use pre-fetched value)
    try:
        if brand_voice and brand_voice != {}:
            word_count = len(_extract_text(brand_voice).split())
            stats["brand_voice"] = f"set ({word_count:,} words)"
        else:
            stats["brand_voice"] = "not set"
    except Exception:
        stats["brand_voice"] = "unknown"

    # EOS / cadence status (use pre-fetched value)
    try:
        if cadence:
            quarter = cadence.get("quarter")
            year = cadence.get("year")
            if quarter and year:
                quarter_end = cadence.get("quarter_end")
                eos_str = f"Q{quarter} {year} active"
                if quarter_end:
                    try:
                        if isinstance(quarter_end, str):
                            from coppermind_cmo.parsing import parse_datetime
                            end_dt = parse_datetime(quarter_end)
                        else:
                            end_dt = quarter_end
                        if end_dt:
                            days_left = (end_dt - datetime.now(timezone.utc)).days
                            if days_left == 0:
                                eos_str = f"Q{quarter} {year} (ends today)"
                            elif 0 < days_left <= 14:
                                eos_str = f"Q{quarter} {year} (ends in {days_left} days)"
                    except Exception:
                        pass
                stats["eos"] = eos_str
            else:
                stats["eos"] = "not configured"
        else:
            stats["eos"] = "not configured"
    except Exception:
        stats["eos"] = "unknown"

    # Last meeting date from meeting_log
    try:
        if _has_meeting_log_table(db):
            mtg_row = db.fetch_one(
                "SELECT start_time FROM meeting_log "
                "WHERE mind_id = %s ORDER BY start_time DESC LIMIT 1",
                [mind_id],
            )
            if mtg_row and mtg_row[0]:
                mtg_dt = mtg_row[0]
                now = datetime.now(timezone.utc)
                if hasattr(mtg_dt, 'date'):
                    if mtg_dt.date() == now.date():
                        stats["last_meeting"] = "today"
                    else:
                        stats["last_meeting"] = f"{mtg_dt.strftime('%b')} {mtg_dt.day}"
                else:
                    stats["last_meeting"] = str(mtg_dt)
            else:
                stats["last_meeting"] = "no meetings yet"
        else:
            stats["last_meeting"] = "no meetings yet"
    except Exception:
        stats["last_meeting"] = "unknown"

    # Last activity (most recent memory created_at)
    try:
        act_row = db.fetch_one(
            "SELECT MAX(created_at) FROM memories "
            "WHERE mind_id = %s AND is_current = true",
            [mind_id],
        )
        if act_row and act_row[0]:
            last_dt = act_row[0]
            now = datetime.now(timezone.utc)
            if hasattr(last_dt, 'timestamp'):
                days_ago = (now - last_dt).days
                if days_ago >= STALE_THRESHOLD_DAYS:
                    stats["last_activity"] = f"{days_ago} days ago"
    except Exception:
        pass

    return stats


def _format_confirmation(name: str, memory_count: int, stats: dict) -> str:
    """Format the one-line confirmation string for switch_client.

    Per spec: missing data shows gracefully ("not set", "not configured", "no meetings yet").
    """
    parts = [f"Switched to {name}. {memory_count:,} memories"]

    last_mtg = stats.get("last_meeting")
    if last_mtg:
        parts.append(f"last meeting {last_mtg}")

    bv = stats.get("brand_voice")
    if bv:
        parts.append(f"brand voice: {bv}")

    eos = stats.get("eos")
    if eos:
        parts.append(f"EOS: {eos}")

    line = ", ".join(parts) + "."

    last_act = stats.get("last_activity")
    if last_act:
        line += f" Last activity: {last_act}."

    return line


def _ensure_personal_mind(customer_id: str, db: Database) -> dict[str, Any]:
    """Find or create the personal mind for this customer.

    Uses a deterministic slug derived from customer_id so all commands
    resolve to the same mind without needing to know the customer_id
    at prompt time.

    Returns: {"mind_id": str, "name": str, "slug": str, "created": bool}
             or an error dict on failure.
    """
    if not customer_id:
        from coppermind_cmo.errors import tool_error
        return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")

    slug = _make_slug(f"personal-{customer_id}")

    # Check if already exists
    row = db.fetch_one(
        "SELECT id, name, slug FROM client_minds WHERE slug = %s AND customer_id = %s",
        [slug, customer_id],
    )
    if row:
        logger.info("Personal mind ensured", result="exists",
                     customer_id=customer_id, mind_id=str(row[0]))
        return {"mind_id": str(row[0]), "name": row[1], "slug": row[2], "created": False}

    # Derive display name from customer_id
    if re.match(r'^[0-9a-f]{8}-', customer_id) or len(customer_id) > 40:
        display_name = "My Notes"
    elif '@' in customer_id:
        display_name = customer_id.split('@')[0].replace('.', ' ').replace('_', ' ').replace('-', ' ').title()
    else:
        display_name = customer_id.replace('_', ' ').replace('-', ' ').title()

    local_path = str(_Path.home())

    try:
        has_lp = _has_local_path(db)
        has_internal = _has_is_internal(db)

        # Build column list and values based on available schema
        cols = ["name", "slug", "customer_id"]
        vals = [display_name, slug, customer_id]
        if has_internal:
            cols.append("is_internal")
            vals.append(True)
        if has_lp:
            cols.append("local_path")
            vals.append(local_path)

        placeholders = ", ".join(["%s"] * len(vals))
        col_names = ", ".join(cols)
        new_row = db.execute_returning(
            f"INSERT INTO client_minds ({col_names}) "
            f"VALUES ({placeholders}) "
            "ON CONFLICT (slug) DO NOTHING "
            "RETURNING id, name, slug",
            vals,
        )
        if new_row:
            mind_id = str(new_row[0])
            logger.info("Personal mind ensured", result="created",
                         customer_id=customer_id, mind_id=mind_id)
            # Create access mapping
            db.execute(
                "INSERT INTO customer_mind_access (customer_id, mind_id, access_level) "
                "VALUES (%s, %s, 'owner') ON CONFLICT (customer_id, mind_id) DO NOTHING",
                [customer_id, mind_id],
            )
            # Migrate legacy "CMO Profile" brand voice data if it exists
            try:
                legacy = db.fetch_one(
                    "SELECT id, brand_voice, brand_positioning FROM client_minds "
                    "WHERE LOWER(name) = 'cmo profile' AND customer_id = %s "
                    "AND brand_voice IS NOT NULL AND brand_voice != '{}'::jsonb",
                    [customer_id],
                )
                if legacy:
                    db.execute(
                        "UPDATE client_minds SET brand_voice = %s, brand_positioning = %s "
                        "WHERE id = %s",
                        [legacy[1], legacy[2], mind_id],
                    )
                    logger.info("Migrated legacy CMO Profile voice data",
                                 legacy_mind_id=str(legacy[0]), personal_mind_id=mind_id)
            except Exception as e:
                logger.warn(f"Legacy voice migration skipped: {e}", mind_id=mind_id)

            return {"mind_id": mind_id, "name": new_row[1], "slug": new_row[2], "created": True}

        # ON CONFLICT — race condition, re-query with customer_id to prevent cross-tenant leak
        row = db.fetch_one(
            "SELECT id, name, slug FROM client_minds WHERE slug = %s AND customer_id = %s",
            [slug, customer_id],
        )
        if row:
            logger.info("Personal mind ensured", result="exists",
                         customer_id=customer_id, mind_id=str(row[0]))
            return {"mind_id": str(row[0]), "name": row[1], "slug": row[2], "created": False}

        from coppermind_cmo.errors import tool_error
        return tool_error("INTERNAL_ERROR", "Failed to create or find personal mind.")
    except Exception as e:
        logger.warn(f"Personal mind creation failed: {e}", customer_id=customer_id)
        from coppermind_cmo.errors import tool_error
        return tool_error("INTERNAL_ERROR", f"Personal mind creation failed. Try again later.")


def _verify_mind_access(mind_id: str, customer_id: str | None, db: Database) -> bool:
    """Verify the customer has access to this mind. Returns True if allowed.

    Default-deny: customer_id must be set (hosted mode always provides it).
    The customer must own the mind OR have an explicit access mapping.
    """
    if not customer_id:
        logger.warn("Access denied — no customer_id", mind_id=mind_id)
        return False
    row = db.fetch_one(
        "SELECT 1 FROM client_minds WHERE id = %s AND customer_id = %s",
        [mind_id, customer_id],
    )
    if row:
        return True
    # When team sharing migration adds revoked_at, exclude revoked access rows.
    # Other locations querying customer_mind_access (switch_client, list_minds,
    # daily_loop, memory_store) will need the same filter when the migration ships.
    revoked_filter = " AND revoked_at IS NULL" if _has_revoked_at(db) else ""
    row = db.fetch_one(
        "SELECT 1 FROM customer_mind_access WHERE mind_id = %s AND customer_id = %s"
        + revoked_filter,
        [mind_id, customer_id],
    )
    if row is not None:
        return True
    logger.warn("Access denied", mind_id=mind_id, customer_id=customer_id)
    return False


def _make_slug(name: str) -> str:
    """Generate URL-safe slug from client name."""
    slug = name.lower()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    slug = re.sub(r'-+', '-', slug)
    return slug


def _switch_client(
    client_name: str,
    create_new: bool,
    db: Database,
    set_mind_fn,
    is_internal: bool = False,
    customer_id: str | None = None,
) -> dict[str, Any]:
    if not client_name or not client_name.strip():
        return INVALID_INPUT("client_name cannot be empty")

    client_name = client_name.strip()
    if len(client_name) > 200:
        return INVALID_INPUT("client_name exceeds 200 character limit")

    if not customer_id:
        return tool_error("PROVISIONING_ERROR",
                          "Your account could not be identified. "
                          "This usually means your API key is misconfigured. "
                          "Contact coppermind@volacci.com for help.")

    slug = _make_slug(client_name)
    has_internal = _has_is_internal(db)

    # Filter by customer_id: owner or explicit access mapping
    access_filter = (
        "AND (cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
        "))"
    )
    access_params = [customer_id, customer_id]

    has_lp = _has_local_path(db)
    lp_col = ", cm.local_path" if has_lp else ""

    if has_internal:
        row = db.fetch_one(
            f"SELECT cm.id, cm.name, cm.slug, cm.archived_at, cm.is_internal, cm.cadence, cm.company_info, cm.brand_voice{lp_col} "
            "FROM client_minds cm "
            "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
            + access_filter,
            [client_name, slug] + access_params,
        )
    else:
        row = db.fetch_one(
            f"SELECT cm.id, cm.name, cm.slug, cm.archived_at, cm.cadence, cm.company_info, cm.brand_voice{lp_col} "
            "FROM client_minds cm "
            "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
            + access_filter,
            [client_name, slug] + access_params,
        )

    if row:
        if has_internal:
            if has_lp:
                mind_id, name, slug, archived_at, row_is_internal, raw_cadence, raw_company_info, raw_brand_voice, row_local_path = row
            else:
                mind_id, name, slug, archived_at, row_is_internal, raw_cadence, raw_company_info, raw_brand_voice = row
                row_local_path = None
        else:
            if has_lp:
                mind_id, name, slug, archived_at, raw_cadence, raw_company_info, raw_brand_voice, row_local_path = row
            else:
                mind_id, name, slug, archived_at, raw_cadence, raw_company_info, raw_brand_voice = row
                row_local_path = None
            row_is_internal = False
        if archived_at is not None:
            return MIND_ARCHIVED(name)

        cadence = raw_cadence if isinstance(raw_cadence, dict) else {}

        count_row = db.fetch_one(
            "SELECT COUNT(*) FROM memories WHERE mind_id = %s AND is_current = true",
            [mind_id],
        )
        memory_count = count_row[0] if count_row else 0

        # Extract brand_color from brand_voice JSONB
        brand_voice = parse_jsonb(raw_brand_voice) if raw_brand_voice else {}
        brand_colors = brand_voice.get("brand_colors", {}) if isinstance(brand_voice, dict) else {}
        primary_color = brand_colors.get("primary")

        set_mind_fn(str(mind_id), name, brand_color=primary_color)
        logger.info(f"Switched to {name}", mind_id=str(mind_id))
        update_active_client(name, str(mind_id), memory_count, cadence, brand_color=primary_color)

        result = {
            "mind_id": str(mind_id),
            "name": name,
            "slug": slug,
            "is_new": False,
            "memory_count": memory_count,
        }
        if row_is_internal:
            result["is_internal"] = True
        if row_local_path:
            result["local_path"] = row_local_path
            result["coppermind_folder"] = os.path.join(row_local_path, "Coppermind")
        if primary_color:
            result["brand_color"] = primary_color

        company_info = parse_jsonb(raw_company_info) if raw_company_info else {}
        tip = _get_tip_for_switch(str(mind_id), name, company_info, db)
        if tip:
            result["daily_tip"] = tip

        # Include pending memory count for owners so they know what needs review
        try:
            from coppermind_cmo.tools.access import _get_access_level
            access_level = _get_access_level(str(mind_id), customer_id, db)
            if access_level == "owner":
                pending_row = db.fetch_one(
                    "SELECT COUNT(*) FROM memories WHERE mind_id = %s AND status = 'pending'",
                    [str(mind_id)],
                )
                pending_count = pending_row[0] if pending_row else 0
                if pending_count > 0:
                    result["pending_memories"] = pending_count
        except Exception as e:
            logger.warn("Failed to fetch pending count", error=str(e))

        # Collect stats and build confirmation line
        try:
            brand_voice = parse_jsonb(raw_brand_voice) if raw_brand_voice else {}
            stats = _collect_mind_stats(
                str(mind_id), db,
                brand_voice=brand_voice,
                cadence=cadence,
            )
            result["stats"] = stats
            result["confirmation"] = _format_confirmation(name, memory_count, stats)
        except Exception as e:
            logger.warn("Failed to collect mind stats", error=str(e))

        return result

    if not create_new:
        return MIND_NOT_FOUND()

    # --- CREATE ---
    existing_slug = db.fetch_one(
        "SELECT 1 FROM client_minds WHERE slug = %s", [slug]
    )
    if existing_slug:
        suffix = 2
        while db.fetch_one(
            "SELECT 1 FROM client_minds WHERE slug = %s", [f"{slug}-{suffix}"]
        ):
            suffix += 1
            if suffix > 100:
                return INVALID_INPUT("Too many clients with similar names. Use a more specific name.")
        slug = f"{slug}-{suffix}"

    try:
        if has_internal:
            new_row = db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id, is_internal) "
                "VALUES (%s, %s, %s, %s) RETURNING id, name, slug",
                [client_name, slug, customer_id, is_internal],
            )
        else:
            new_row = db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id) "
                "VALUES (%s, %s, %s) RETURNING id, name, slug",
                [client_name, slug, customer_id],
            )
    except Exception as e:
        if "unique" in str(e).lower() or "duplicate" in str(e).lower():
            return INVALID_INPUT("A client with a similar name already exists. Try a more specific name.")
        raise

    mind_id, name, slug = new_row

    # Create access mapping for the owner
    db.execute(
        "INSERT INTO customer_mind_access (customer_id, mind_id, access_level) "
        "VALUES (%s, %s, 'owner') ON CONFLICT (customer_id, mind_id) DO NOTHING",
        [customer_id, str(mind_id)],
    )

    set_mind_fn(str(mind_id), name)
    logger.info(f"Created new mind: {name}", mind_id=str(mind_id))
    update_active_client(name, str(mind_id), 0)

    result = {
        "mind_id": str(mind_id),
        "name": name,
        "slug": slug,
        "is_new": True,
        "memory_count": 0,
    }
    if is_internal:
        result["is_internal"] = True

    tip = _get_tip_for_switch(str(mind_id), name, {}, db)
    if tip:
        result["daily_tip"] = tip

    new_stats = {
        "brand_voice": "not set",
        "eos": "not configured",
        "last_meeting": "no meetings yet",
    }
    result["stats"] = new_stats
    result["confirmation"] = _format_confirmation(name, 0, new_stats)

    return result


def _list_minds(limit: int, offset: int, db: Database, include_internal: bool = False,
                customer_id: str | None = None) -> list[dict[str, Any]]:
    limit = min(max(1, limit), 200)
    offset = max(0, offset)

    if not customer_id:
        logger.warn("list_minds called without customer_id — returning empty list")
        return []

    where_clauses = [
        "(cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
        "))"
    ]
    params: list = [customer_id, customer_id]

    if not include_internal and _has_is_internal(db):
        where_clauses.append("cm.is_internal = false")

    base_sql = (
        "SELECT cm.id, cm.name, cm.slug, cm.archived_at, "
        "COUNT(m.id) AS memory_count, cm.created_at, cm.updated_at "
        "FROM client_minds cm "
        "LEFT JOIN memories m ON m.mind_id = cm.id AND m.is_current = true "
        "WHERE " + " AND ".join(where_clauses) + " "
        "GROUP BY cm.id "
        "ORDER BY cm.updated_at DESC "
        "LIMIT %s OFFSET %s"
    )
    params.extend([limit, offset])
    rows = db.fetch_all(base_sql, params)

    return [
        {
            "mind_id": str(r[0]),
            "name": r[1],
            "slug": r[2],
            "archived_at": r[3].isoformat() if r[3] else None,
            "memory_count": r[4],
            "created_at": r[5].isoformat() if r[5] else None,
            "updated_at": r[6].isoformat() if r[6] else None,
        }
        for r in rows
    ]


VALID_CADENCE_TYPES = {"eos", "custom", "none"}


def _configure_mind(
    cadence: dict | None,
    company_info: dict | None,
    db: Database,
    active_mind: tuple[str, str] | None,
    local_path: str | None = None,
    sharing_config: dict | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    if not cadence and not company_info and not local_path and sharing_config is None:
        return INVALID_INPUT("Provide cadence, company_info, local_path, and/or sharing_config")

    # Validate local_path
    if local_path is not None:
        if not isinstance(local_path, str) or not local_path.strip():
            return INVALID_INPUT("local_path must be a non-empty string")
        local_path = local_path.strip()
        if len(local_path) > 1000:
            return INVALID_INPUT("local_path must be <= 1000 characters")

        # Canonicalize: expand ~ and resolve to absolute path
        local_path = str(_Path(local_path).expanduser().resolve())

        # Reject dangerous system directories
        lp_lower = local_path.lower()
        for prefix in _FORBIDDEN_PREFIXES:
            if lp_lower.startswith(prefix):
                return INVALID_INPUT(f"local_path cannot point to system directory: {prefix}")
        for forbidden in _FORBIDDEN_PATHS:
            if local_path.startswith(forbidden):
                return INVALID_INPUT("local_path cannot point to sensitive directory")

        # Must be a directory (or not exist yet -- configure_mind creates it)
        if os.path.exists(local_path) and not os.path.isdir(local_path):
            return INVALID_INPUT("local_path must be a directory, not a file")

    # Validate cadence
    if cadence:
        if not isinstance(cadence, dict):
            return INVALID_INPUT("cadence must be a dict")

        ctype = cadence.get("type")
        if ctype is not None and ctype not in VALID_CADENCE_TYPES:
            return INVALID_INPUT(f"cadence.type must be one of: {', '.join(VALID_CADENCE_TYPES)}")

        q = cadence.get("quarter")
        if q is not None and (not isinstance(q, int) or q < 1 or q > 4):
            return INVALID_INPUT("cadence.quarter must be an integer 1-4")

        y = cadence.get("year")
        if y is not None and (not isinstance(y, int) or y < 2020 or y > 2100):
            return INVALID_INPUT("cadence.year must be an integer 2020-2100")

        s = cadence.get("sprint")
        if s is not None and (not isinstance(s, int) or s < 1):
            return INVALID_INPUT("cadence.sprint must be an integer >= 1")

        spq = cadence.get("sprints_per_quarter")
        if spq is not None and (not isinstance(spq, int) or spq < 1 or spq > 12):
            return INVALID_INPUT("cadence.sprints_per_quarter must be an integer 1-12")

    # Validate company_info
    if company_info:
        if not isinstance(company_info, dict):
            return INVALID_INPUT("company_info must be a dict")

        url = company_info.get("url")
        if url is not None and (not isinstance(url, str) or len(url) > 500):
            return INVALID_INPUT("company_info.url must be a string <= 500 chars")

        industry = company_info.get("industry")
        if industry is not None and (not isinstance(industry, str) or len(industry) > 200):
            return INVALID_INPUT("company_info.industry must be a string <= 200 chars")

    # Validate sharing_config
    if sharing_config is not None:
        if not isinstance(sharing_config, dict):
            return INVALID_INPUT("sharing_config must be a dict.")
        valid_keys = {"viewer_allowed_types"}
        unknown = set(sharing_config.keys()) - valid_keys
        if unknown:
            return INVALID_INPUT(f"Unknown sharing_config keys: {unknown}")
        vat = sharing_config.get("viewer_allowed_types")
        if vat is not None:
            if not isinstance(vat, list):
                return INVALID_INPUT("viewer_allowed_types must be a list.")
            from coppermind_cmo.memory_types import VALID_MEMORY_TYPES
            for t in vat:
                if t not in VALID_MEMORY_TYPES:
                    return INVALID_INPUT(f"Invalid memory type: {t}")

    # Build UPDATE query based on what's provided
    set_clauses = []
    params: list = []
    updated_fields = []

    if cadence:
        set_clauses.append("cadence = COALESCE(cadence, '{}'::jsonb) || %s::jsonb")
        params.append(json.dumps(cadence))
        updated_fields.append("cadence")

    if company_info:
        set_clauses.append("company_info = COALESCE(company_info, '{}'::jsonb) || %s::jsonb")
        params.append(json.dumps(company_info))
        updated_fields.append("company_info")

    has_lp = _has_local_path(db)
    if local_path is not None and has_lp:
        set_clauses.append("local_path = %s")
        params.append(local_path)
        updated_fields.append("local_path")

    if sharing_config is not None:
        set_clauses.append("sharing_config = COALESCE(sharing_config, '{}') || %s::jsonb")
        params.append(json.dumps(sharing_config))
        updated_fields.append("sharing_config")

    set_clauses.append("updated_at = now()")
    params.append(mind_id)

    returning_cols = "RETURNING cadence, company_info" + (", local_path" if has_lp else "")
    row = db.execute_returning(
        "UPDATE client_minds "
        "SET " + ", ".join(set_clauses) + " "
        "WHERE id = %s "
        + returning_cols,
        params,
    )

    if not row:
        from coppermind_cmo.errors import tool_error
        return tool_error("INTERNAL_ERROR", "Something went wrong updating the client settings. Try switching to the client again with switch_client first.")

    result_cadence = parse_jsonb(row[0])
    result_company_info = parse_jsonb(row[1])
    result_local_path = row[2] if has_lp else None

    # Create Coppermind subfolder structure if local_path was provided
    if local_path:
        try:
            coppermind_root = os.path.join(local_path, "Coppermind")
            subfolders = ["Briefs", "Content", "Meetings", "Reports", "Strategy", "Handoff"]
            for folder in subfolders:
                os.makedirs(os.path.join(coppermind_root, folder), exist_ok=True)
            logger.info(f"Created Coppermind folder structure at {coppermind_root}", mind_id=mind_id)
        except OSError as e:
            logger.warn(f"Failed to create Coppermind folder structure: {e}", mind_id=mind_id)

    logger.info(f"Configured mind: {mind_name}", mind_id=mind_id)

    result = {
        "mind_id": mind_id,
        "name": mind_name,
        "cadence": result_cadence,
        "company_info": result_company_info,
        "updated_fields": updated_fields,
    }

    if result_local_path:
        result["local_path"] = result_local_path
        result["coppermind_folder"] = os.path.join(result_local_path, "Coppermind")

    return result


def _list_documents(
    limit: int,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> list[dict] | dict:
    """List stored raw documents for the active client."""
    if active_mind is None:
        return NO_ACTIVE_MIND()
    mind_id, mind_name = active_mind

    from coppermind_cmo.ingest import _has_raw_documents_table
    if not _has_raw_documents_table(db):
        return {"message": "Document storage isn't set up yet for this account. Contact coppermind@volacci.com to enable it."}

    limit = min(max(1, limit), 50)
    rows = db.fetch_all(
        "SELECT id, source_type, source_ref, word_count, extraction_passes, "
        "last_extracted_at, created_at "
        "FROM raw_documents WHERE mind_id = %s ORDER BY created_at DESC LIMIT %s",
        [mind_id, limit],
    )
    return [
        {
            "doc_id": str(r[0]),
            "source_type": r[1],
            "source_ref": r[2],
            "word_count": r[3],
            "extraction_passes": r[4],
            "last_extracted_at": r[5].isoformat() if r[5] else None,
            "created_at": r[6].isoformat() if r[6] else None,
        }
        for r in rows
    ]


def register(mcp_server):
    from coppermind_cmo.server import get_db, get_active_mind, set_active_mind, set_last_tool_call, get_customer_id, stamp_active_client
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("switch_client")
    def switch_client(client_name: str, create_new: bool = False, is_internal: bool = False) -> dict:
        """Switch to a client. When the user says "switch to [name]", call this immediately.

        This is the most common Coppermind command. Do not hesitate or interpret
        — "switch to proven" means switch_client(client_name="proven").

        All subsequent operations are scoped to this client.
        Fuzzy matches partial names (e.g. "proven" matches "Proven Plumbing").

        If the response includes `notifications`, share them casually.
        """
        set_last_tool_call("switch_client")
        result = _switch_client(client_name, create_new, get_db(), set_active_mind,
                                is_internal=is_internal, customer_id=get_customer_id())
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("list_minds")
    def list_minds(limit: int = 50, offset: int = 0, include_internal: bool = False) -> list[dict]:
        """List all client minds with memory counts. Internal minds are excluded by default."""
        set_last_tool_call("list_minds")
        return _list_minds(limit, offset, get_db(), include_internal=include_internal,
                           customer_id=get_customer_id())

    @mcp_server.tool()
    @safe_tool_call("configure_mind")
    def configure_mind(
        cadence: dict | None = None,
        company_info: dict | None = None,
        local_path: str | None = None,
        sharing_config: dict | None = None,
    ) -> dict:
        """Configure the active client's business context — cadence (EOS quarter/sprint tracking), company information, local folder path, and sharing configuration.

        Call this during client onboarding to set up the business rhythm. Both cadence and company_info use JSONB merge — you can update incrementally.

        cadence example: {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        company_info example: {"url": "https://acme.com", "industry": "SaaS", "primary_contact": {"name": "Jane", "title": "CEO"}}
        local_path example: "/Users/ben/Clients/Acme Corp" — sets the client's local folder. A Coppermind/ subfolder structure (Briefs, Content, Meetings, Reports, Strategy, Handoff) is created automatically.
        sharing_config example: {"viewer_allowed_types": ["fact", "decision"]} — restrict which memory types viewers can see.
        """
        set_last_tool_call("configure_mind")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
        if access_level != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _configure_mind(cadence, company_info, get_db(), active_mind, local_path=local_path, sharing_config=sharing_config)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("list_documents")
    def list_documents(limit: int = 10) -> list[dict] | dict:
        """List stored documents for the active client. Shows what's been ingested and extraction status."""
        set_last_tool_call("list_documents")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
        if access_level != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_list_documents(limit, get_db(), active_mind))

    @mcp_server.tool()
    @safe_tool_call("ensure_personal_mind")
    def ensure_personal_mind() -> dict:
        """Find or create the CMO's personal mind. Returns the mind_id and slug.

        The personal mind stores the CMO's professional voice and style preferences.
        It is identified by a deterministic slug derived from the customer's account ID,
        so all commands resolve to the same mind. Does not switch the active mind.

        Call this before get_brand_voice(mind_id=...) when you need the CMO's voice
        but don't know their personal mind's ID.
        """
        set_last_tool_call("ensure_personal_mind")
        customer_id = get_customer_id()
        return stamp_active_client(_ensure_personal_mind(customer_id, get_db()))
