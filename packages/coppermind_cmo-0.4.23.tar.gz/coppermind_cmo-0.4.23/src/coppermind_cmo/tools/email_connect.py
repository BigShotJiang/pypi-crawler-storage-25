"""Email ingestion status tool.

Reports on email ingestion health: last check time, weekly memory count,
unattributed emails, and per-provider source breakdown.
"""

from __future__ import annotations

from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("email_connect")


def _email_status(db: Database, config: Config, customer_id: str) -> dict[str, Any]:
    """Core logic for the email_status tool (testable without MCP server)."""

    result: dict[str, Any] = {}

    # Last successful email ingestion timestamp (source_type='email' on memories table)
    last_check = db.fetch_one(
        "SELECT MAX(created_at) FROM memories "
        "WHERE mind_id IN (SELECT id FROM client_minds WHERE customer_id = %s) "
        "AND source_type = 'email'",
        [customer_id],
    )
    result["last_email_check"] = str(last_check[0]) if last_check and last_check[0] else None

    # Email-sourced memories stored in the last 7 days
    memory_count = db.fetch_one(
        "SELECT COUNT(*) FROM memories "
        "WHERE mind_id IN (SELECT id FROM client_minds WHERE customer_id = %s) "
        "AND source_type = 'email' "
        "AND created_at > now() - interval '7 days'",
        [customer_id],
    )
    result["memories_this_week"] = memory_count[0] if memory_count else 0

    # Emails awaiting attribution resolution
    pending = db.fetch_one(
        "SELECT COUNT(*) FROM email_attribution_log "
        "WHERE customer_id = %s AND status = 'multi_match'",
        [customer_id],
    )
    result["unattributed_count"] = pending[0] if pending else 0

    # Breakdown by source provider (from source_ref prefix on memories)
    breakdown_rows = db.fetch_all(
        "SELECT split_part(source_ref, ':', 1), COUNT(*) "
        "FROM memories "
        "WHERE mind_id IN (SELECT id FROM client_minds WHERE customer_id = %s) "
        "AND source_type = 'email' "
        "AND source_ref IS NOT NULL "
        "GROUP BY split_part(source_ref, ':', 1)",
        [customer_id],
    )
    result["source_breakdown"] = {row[0]: row[1] for row in breakdown_rows} if breakdown_rows else {}

    return result


def register(mcp_server):
    """Register email status tool on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.errors import tool_error
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("email_status")
    def email_status() -> dict:
        """Check the status of email ingestion.

        Shows when emails were last ingested, how many email-sourced memories
        exist this week, any unattributed emails, and a breakdown by source.
        """
        set_last_tool_call("email_status")
        db = get_db()
        config = get_config()
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")

        result = _email_status(db, config, customer_id)
        return attach_notifications(result, customer_id=customer_id, db=db)
