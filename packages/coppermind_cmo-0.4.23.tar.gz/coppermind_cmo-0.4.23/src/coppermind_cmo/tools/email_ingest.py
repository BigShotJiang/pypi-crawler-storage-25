"""ingest_emails tool: batch email ingestion via MCP.

Accepts normalized email objects from any source (Gmail MCP, Outlook MCP, etc.),
runs dedup/skip/attribution/ingestion, and returns a summary.

Reference: docs/specs/2026-03-28-email-ingestion-gmail-mcp-pivot.review.md
"""

from __future__ import annotations

import re
from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.email_processing import (
    attribute_email,
    clean_email_body,
    should_skip_message,
)
from coppermind_cmo.errors import INVALID_INPUT, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb

logger = ToolLogger("email_ingest")

# Maximum emails per batch call
MAX_BATCH_SIZE = 25

# Allowed source values
VALID_SOURCES = frozenset({"gmail", "outlook", "imap", "other"})

# Known prompt-injection prefixes to strip from email bodies
INJECTION_PREFIXES = [
    "[SYSTEM",
    "<SYSTEM>",
    "IGNORE PREVIOUS",
    "INSTRUCTION:",
    "ASSISTANT:",
    "Human:",
]

# Required fields on each normalized email object
_REQUIRED_EMAIL_FIELDS = ("thread_id", "subject", "from_address", "date", "body", "source")


# ---------------------------------------------------------------------------
# Core logic (testable, no server dependency)
# ---------------------------------------------------------------------------


def _ingest_emails(
    emails: list[dict[str, Any]],
    mind_id: str | None,
    lookback_days: int,
    db: Database,
    config: Config,
    customer_id: str,
) -> dict[str, Any]:
    """Process a batch of normalized email objects.

    Returns a summary dict with counts for each outcome category.
    """
    # --- Validate batch size ---
    if not emails:
        return INVALID_INPUT("emails list cannot be empty")
    if len(emails) > MAX_BATCH_SIZE:
        return INVALID_INPUT(f"Batch too large: {len(emails)} emails (max {MAX_BATCH_SIZE})")

    # --- Validate each email object ---
    errors: list[str] = []
    for i, email in enumerate(emails):
        if not isinstance(email, dict):
            errors.append(f"emails[{i}]: must be an object")
            continue
        for field in _REQUIRED_EMAIL_FIELDS:
            if not email.get(field):
                errors.append(f"emails[{i}]: missing required field '{field}'")

        # Validate source
        source = email.get("source", "")
        if source and source not in VALID_SOURCES:
            errors.append(
                f"emails[{i}]: invalid source '{source}'. "
                f"Allowed: {', '.join(sorted(VALID_SOURCES))}"
            )

        # Validate thread_id format and length
        thread_id = email.get("thread_id", "")
        if thread_id:
            if len(thread_id) > 256:
                errors.append(f"emails[{i}]: thread_id exceeds 256 chars")
            # Strip control characters
            email["thread_id"] = re.sub(r"[\x00-\x1f\x7f]", "", thread_id)
        if source and thread_id:
            expected_prefix = f"{source}:"
            if not thread_id.startswith(expected_prefix):
                errors.append(
                    f"emails[{i}]: thread_id must start with '{expected_prefix}' "
                    f"(got '{thread_id[:30]}')"
                )

        # Validate body length (100KB cap)
        body = email.get("body", "")
        if body and len(body) > 100_000:
            errors.append(f"emails[{i}]: body exceeds 100KB ({len(body)} bytes)")

    if errors:
        return INVALID_INPUT("Validation errors:\n" + "\n".join(errors))

    # --- Resolve mind if mind_id provided ---
    resolved_mind: tuple[str, str] | None = None  # (mind_id, mind_name)
    if mind_id:
        row = db.fetch_one(
            "SELECT name FROM client_minds WHERE id = %s AND customer_id = %s",
            [mind_id, customer_id],
        )
        if not row:
            return tool_error("MIND_NOT_FOUND", "Mind not found or access denied.")
        resolved_mind = (mind_id, row[0])

    # --- Fetch all minds for attribution (only if mind_id not provided) ---
    all_minds: list[dict[str, Any]] = []
    if not mind_id:
        mind_rows = db.fetch_all(
            "SELECT id, name, email_contacts, company_info "
            "FROM client_minds WHERE customer_id = %s AND archived_at IS NULL",
            [customer_id],
        )
        for r in mind_rows:
            all_minds.append({
                "id": str(r[0]),
                "name": r[1],
                "email_contacts": parse_jsonb(r[2]),
                "company_info": parse_jsonb(r[3]),
            })

    # --- Process each email ---
    ingested = 0
    skipped_duplicate = 0
    skipped_no_match = 0
    multi_match = 0
    skipped_auto = 0
    result_errors: list[str] = []

    for email in emails:
        thread_id = email["thread_id"]
        subject = email["subject"]
        from_address = email["from_address"]
        to_addrs = email.get("to") or []
        cc_addrs = email.get("cc") or []
        body = email["body"]
        source = email["source"]
        metadata = email.get("metadata") or {}

        try:
            outcome = _process_single_email(
                thread_id=thread_id,
                subject=subject,
                from_address=from_address,
                to_addrs=to_addrs,
                cc_addrs=cc_addrs,
                body=body,
                source=source,
                metadata=metadata,
                resolved_mind=resolved_mind,
                all_minds=all_minds,
                db=db,
                config=config,
                customer_id=customer_id,
            )
        except Exception as exc:
            logger.warn(
                "Email processing failed",
                thread_id=thread_id,
                error=str(exc),
            )
            result_errors.append(f"{thread_id}: {exc}")
            continue

        if outcome == "ingested":
            ingested += 1
        elif outcome == "duplicate":
            skipped_duplicate += 1
        elif outcome == "no_match":
            skipped_no_match += 1
        elif outcome == "multi_match":
            multi_match += 1
        elif outcome == "auto_skip":
            skipped_auto += 1

    logger.info(
        "Batch complete",
        total=len(emails),
        ingested=ingested,
        skipped_duplicate=skipped_duplicate,
        skipped_no_match=skipped_no_match,
        multi_match=multi_match,
        skipped_auto=skipped_auto,
        errors=len(result_errors),
        lookback_days=lookback_days,
    )

    return {
        "ingested": ingested,
        "skipped_duplicate": skipped_duplicate,
        "skipped_no_match": skipped_no_match,
        "multi_match": multi_match,
        "skipped_auto": skipped_auto,
        "has_more": False,
        "errors": result_errors,
    }


def _process_single_email(
    *,
    thread_id: str,
    subject: str,
    from_address: str,
    to_addrs: list[str],
    cc_addrs: list[str],
    body: str,
    source: str,
    metadata: dict[str, Any],
    resolved_mind: tuple[str, str] | None,
    all_minds: list[dict[str, Any]],
    db: Database,
    config: Config,
    customer_id: str,
) -> str:
    """Process one email. Returns an outcome string.

    Outcomes: 'ingested', 'duplicate', 'no_match', 'multi_match', 'auto_skip'
    """
    # 1. Skip detection
    if should_skip_message(subject, from_address, metadata):
        logger.info("Auto-skipped email", thread_id=thread_id, subject=subject)
        return "auto_skip"

    # 2. Attribution
    if resolved_mind:
        target_mind_id, target_mind_name = resolved_mind
        mind_ids = [target_mind_id]
    else:
        mind_ids = attribute_email(from_address, to_addrs, cc_addrs, all_minds)

    if not mind_ids:
        return "no_match"

    if len(mind_ids) > 1:
        # Multi-match: log to email_attribution_log
        _log_multi_match(
            db=db,
            customer_id=customer_id,
            thread_id=thread_id,
            subject=subject,
            from_address=from_address,
            recipients=to_addrs + cc_addrs,
            mind_ids=mind_ids,
        )
        return "multi_match"

    # Single match
    target_mind_id = mind_ids[0]

    # Resolve mind name if we don't have it already
    if resolved_mind:
        target_mind_name = resolved_mind[1]
    else:
        target_mind_name = _resolve_mind_name(target_mind_id, all_minds)

    # 3. Dedup check: has this thread_id been ingested for this mind?
    existing = db.fetch_one(
        "SELECT id FROM ingest_log "
        "WHERE mind_id = %s AND source_ref = %s",
        [target_mind_id, thread_id],
    )
    if existing:
        return "duplicate"

    # 4. Clean and fence the body
    cleaned_body = clean_email_body(body)
    if not cleaned_body.strip():
        logger.info("Empty body after cleaning", thread_id=thread_id)
        return "auto_skip"

    # Strip injection prefixes (case-insensitive; fencing is the primary defense)
    sanitized = cleaned_body
    for prefix in INJECTION_PREFIXES:
        sanitized = re.sub(re.escape(prefix), "", sanitized, flags=re.IGNORECASE)

    # Fence the content
    fenced_body = (
        f"[EMAIL CONTENT — external, unverified]\n"
        f"{sanitized}\n"
        f"[END EMAIL CONTENT]"
    )

    # 5. Ingest via IngestEngine
    # Lazy import to avoid circular deps
    from coppermind_cmo.ingest import IngestEngine

    engine = IngestEngine(
        db,
        config,
        active_mind=(target_mind_id, target_mind_name),
        auto_ingest=True,
        memory_source_type="email",
    )
    engine.process_source(
        source_type="email",
        source_ref=thread_id,
        content=fenced_body,
    )

    logger.info(
        "Ingested email",
        thread_id=thread_id,
        mind_id=target_mind_id,
        mind_name=target_mind_name,
    )
    return "ingested"


def _resolve_mind_name(mind_id: str, minds: list[dict[str, Any]]) -> str:
    """Look up mind name from the pre-fetched minds list."""
    for m in minds:
        if m["id"] == mind_id:
            return m["name"]
    return "Unknown"


def _log_multi_match(
    *,
    db: Database,
    customer_id: str,
    thread_id: str,
    subject: str,
    from_address: str,
    recipients: list[str],
    mind_ids: list[str],
) -> None:
    """Log a multi-match email to email_attribution_log for manual resolution."""
    try:
        db.execute(
            "INSERT INTO email_attribution_log "
            "(customer_id, message_id, thread_id, subject, sender, recipients, candidate_mind_ids) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (message_id) DO NOTHING",
            [customer_id, thread_id, thread_id, subject, from_address, recipients, mind_ids],
        )
    except Exception as exc:
        logger.warn(
            "Failed to log multi-match",
            thread_id=thread_id,
            error=str(exc),
        )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(mcp_server):  # pragma: no cover
    """Register ingest_emails tool on the MCP server."""
    from coppermind_cmo.server import (
        get_db, get_config, set_last_tool_call, get_customer_id,
    )
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("ingest_emails")
    def ingest_emails(
        emails: list[dict[str, Any]],
        mind_id: str | None = None,
        lookback_days: int = 14,
    ) -> dict:
        """Ingest a batch of normalized email objects into client minds.

        Accepts up to 25 emails per call. Each email is deduplicated, checked for
        skip patterns (auto-replies, newsletters), attributed to a client mind,
        cleaned, and ingested via IngestEngine.

        Parameters:
        - emails: List of normalized email objects (required). Each must have:
            thread_id, subject, from_address, date, body, source.
            Optional: to, cc, metadata, from_name.
        - mind_id: UUID of target mind (optional). If provided, skips attribution
            and stores all emails directly to this mind.
        - lookback_days: Metadata/logging only (default 14).

        Returns a summary: {ingested, skipped_duplicate, skipped_no_match,
        multi_match, skipped_auto, has_more, errors}
        """
        set_last_tool_call("ingest_emails")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        result = _ingest_emails(
            emails, mind_id, lookback_days,
            get_db(), get_config(), customer_id,
        )
        return attach_notifications(result, customer_id=customer_id, db=get_db())
