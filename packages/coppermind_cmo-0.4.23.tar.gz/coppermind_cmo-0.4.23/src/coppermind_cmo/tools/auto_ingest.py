"""Auto-ingest tools: find_uningested_meetings, auto_ingest_transcript.

Enables session-driven transcript ingestion from connected sources (Granola MCP).
Claude orchestrates the flow: finds uningested meetings, fetches transcripts via
Granola MCP, then calls auto_ingest_transcript to run IngestEngine.
"""

from typing import Any, Callable

from coppermind_cmo.db import Database
from coppermind_cmo.config import Config
from coppermind_cmo.errors import INVALID_INPUT, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.tools.daily_loop import _has_meeting_log_table

logger = ToolLogger("auto_ingest")


# ---------------------------------------------------------------------------
# Core logic (testable, no server dependency)
# ---------------------------------------------------------------------------


def _find_uningested_meetings(
    db: Database,
    customer_id: str,
) -> dict[str, Any]:
    """Find meetings with confident mind matches that haven't been ingested yet."""
    if not _has_meeting_log_table(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 017_meeting_log.sql to enable meeting logging.",
        )

    rows = db.fetch_all(
        "SELECT ml.id, ml.mind_id, ml.title, ml.start_time, "
        "ml.calendar_event_id, ml.match_confidence, cm.name AS mind_name "
        "FROM meeting_log ml "
        "LEFT JOIN client_minds cm ON cm.id = ml.mind_id "
        "WHERE ml.customer_id = %s "
        "AND ml.transcript_ingested = false "
        "AND ml.match_confidence = 'confident' "
        "AND ml.mind_id IS NOT NULL "
        "ORDER BY ml.start_time DESC",
        [customer_id],
    )

    meetings = []
    for row in rows:
        meetings.append({
            "meeting_log_id": str(row[0]),
            "mind_id": str(row[1]),
            "title": row[2],
            "start_time": str(row[3]) if row[3] else None,
            "calendar_event_id": row[4],
            "match_confidence": row[5],
            "mind_name": row[6],
        })

    logger.info(
        "Found uningested meetings",
        count=len(meetings),
    )

    return {
        "meetings": meetings,
        "count": len(meetings),
    }


def _auto_ingest_transcript(
    mind_id: str,
    mind_name: str,
    meeting_log_id: str,
    transcript_text: str,
    source_ref: str,
    db: Database,
    config: Config,
    customer_id: str,
    db_factory: Callable | None = None,
    session_id: str | None = None,
) -> dict[str, Any]:
    """Ingest a meeting transcript via non-blocking background dispatch.

    Validates inputs and mind access synchronously, then dispatches to
    start_background_ingestion(). The meeting_log entry is marked as ingested
    via a post_process callback after successful background completion.
    """
    if not mind_id or not mind_id.strip():
        return INVALID_INPUT("mind_id cannot be empty")
    if not meeting_log_id or not meeting_log_id.strip():
        return INVALID_INPUT("meeting_log_id cannot be empty")
    if not transcript_text or not transcript_text.strip():
        return INVALID_INPUT("transcript_text cannot be empty")
    if not source_ref or not source_ref.strip():
        return INVALID_INPUT("source_ref cannot be empty")

    if not _has_meeting_log_table(db):
        return tool_error(
            "MIGRATION_REQUIRED",
            "Run migration 017_meeting_log.sql to enable meeting logging.",
        )

    # Verify mind access
    row = db.fetch_one(
        "SELECT name FROM client_minds WHERE id = %s AND customer_id = %s",
        [mind_id, customer_id],
    )
    if not row:
        return tool_error("MIND_NOT_FOUND", "Mind not found or access denied.")

    # Use mind_name from DB if not provided
    resolved_name = mind_name or row[0]

    # Verify meeting_log exists and hasn't already been ingested
    ml_row = db.fetch_one(
        "SELECT id FROM meeting_log "
        "WHERE id = %s AND customer_id = %s AND mind_id = %s "
        "AND transcript_ingested = false",
        [meeting_log_id, customer_id, mind_id],
    )
    if not ml_row:
        return tool_error(
            "MEETING_LOG_NOT_FOUND",
            "Meeting log entry not found, already ingested, or access denied.",
        )

    from coppermind_cmo.background import start_background_ingestion

    def _on_complete(ingest_result: dict, bg_db_factory):
        """Mark meeting_log after successful background ingestion."""
        extracted = ingest_result.get("new", 0) + ingest_result.get("updated", 0)
        if extracted == 0:
            logger.warn(
                "Transcript ingested but no memories extracted",
                mind_id=mind_id,
                meeting_log_id=meeting_log_id,
                source_ref=source_ref,
                skipped=ingest_result.get("skipped", 0),
            )
            return  # Don't mark as ingested — will retry next cycle

        bg_db = bg_db_factory()
        updated = bg_db.execute_returning(
            "UPDATE meeting_log "
            "SET transcript_ingested = true, updated_at = now() "
            "WHERE id = %s AND customer_id = %s AND mind_id = %s "
            "AND transcript_ingested = false "
            "RETURNING id",
            [meeting_log_id, customer_id, mind_id],
        )
        if updated:
            logger.info(
                "Auto-ingested transcript (background)",
                mind_id=mind_id,
                mind_name=resolved_name,
                meeting_log_id=meeting_log_id,
                source_ref=source_ref,
                new=ingest_result.get("new", 0),
                updated=ingest_result.get("updated", 0),
            )
        else:
            logger.warn(
                "meeting_log UPDATE matched no rows — already ingested or deleted",
                meeting_log_id=meeting_log_id,
                mind_id=mind_id,
            )

    # Default db_factory for backward compatibility (tests that pass db directly)
    if db_factory is None:
        db_factory = lambda: db

    return start_background_ingestion(
        text=transcript_text,
        mind_id=mind_id,
        mind_name=resolved_name,
        db_factory=db_factory,
        config=config,
        source_type="meeting",
        source_ref=source_ref,
        post_process=_on_complete,
        auto_ingest=True,
        session_id=session_id,
    )


# ---------------------------------------------------------------------------
# Skip/fail remediation mapping
# ---------------------------------------------------------------------------

SKIP_REMEDIATION = {
    "unsupported_format": {
        "action": "Download and share directly",
        "message": "Download from Drive and share directly in chat.",
        "tip": "Spreadsheets: copy key data into a Google Doc first for best results.",
        "applies_to": {".pdf", ".docx", ".xlsx", ".pptx", ".doc", ".xls"},
    },
    "image_file": {
        "action": "Describe in chat",
        "message": "Images can't be ingested as text. If this contains important info, describe it in chat and I'll store it.",
        "applies_to": {".jpg", ".jpeg", ".png", ".gif", ".svg", ".webp", ".bmp"},
    },
    "audio_video": {
        "action": "Share transcript",
        "message": "Audio/video can't be ingested directly. Share a transcript instead.",
        "applies_to": {".mp3", ".mp4", ".wav", ".mov", ".avi", ".m4a", ".webm"},
    },
    "too_large": {
        "action": "Split into sections",
        "message": "This file is very large. Try sharing the most important sections separately.",
    },
    "duplicate": {
        "action": "No action needed",
        "message": "Already ingested. No action needed.",
    },
    "empty": {
        "action": "No action needed",
        "message": "File is empty. Skipped.",
    },
    "api_error": {
        "action": "Retry or fix access",
        "message": "Download failed — check that the file is accessible, then try again.",
    },
    "extraction_empty": {
        "action": "No action needed",
        "message": "Section contained no extractable memories (chit-chat, administrative, or off-topic content).",
    },
}


def classify_skip_reason(
    reason: str = "",
    filename: str = "",
    file_ext: str = "",
) -> str:
    """Classify a skip/fail reason into a remediation category.

    Returns a key from SKIP_REMEDIATION.
    """
    reason_lower = reason.lower() if reason else ""
    ext = file_ext.lower() if file_ext else ""

    if "duplicate" in reason_lower or "already" in reason_lower:
        return "duplicate"
    if "empty" in reason_lower and "extract" not in reason_lower:
        return "empty"
    if "too large" in reason_lower or "size" in reason_lower:
        return "too_large"
    if "timeout" in reason_lower or "permission" in reason_lower or "api" in reason_lower:
        return "api_error"
    if "no extract" in reason_lower or "no memories" in reason_lower or "extraction" in reason_lower:
        return "extraction_empty"

    # Check by file extension
    for category, info in SKIP_REMEDIATION.items():
        if "applies_to" in info and ext in info["applies_to"]:
            return category

    if ext in {".jpg", ".jpeg", ".png", ".gif", ".svg"}:
        return "image_file"

    return "extraction_empty"  # default fallback


def _format_skip_report(
    skipped_items: list[dict] | None = None,
    chunks_skipped: int = 0,
    chunks_failed: int = 0,
) -> str:
    """Format actionable next steps for skipped/failed items.

    Args:
        skipped_items: List of dicts with 'filename', 'reason', 'ext' keys.
                       Used for file-level skip reporting (folder ingestion).
        chunks_skipped: Number of chunks skipped (transcript ingestion).
        chunks_failed: Number of chunks that failed (transcript ingestion).

    Returns:
        Markdown string with grouped remediation actions, or empty string if nothing skipped.
    """
    lines: list[str] = []

    # File-level skip report (for folder/batch ingestion)
    if skipped_items:
        # Group by remediation category
        grouped: dict[str, list[dict]] = {}
        for item in skipped_items:
            category = classify_skip_reason(
                reason=item.get("reason", ""),
                filename=item.get("filename", ""),
                file_ext=item.get("ext", ""),
            )
            if category not in grouped:
                grouped[category] = []
            grouped[category].append(item)

        lines.append("")
        lines.append("### Next Steps for Skipped Files")
        lines.append("")

        for category, items in grouped.items():
            info = SKIP_REMEDIATION.get(category, SKIP_REMEDIATION["extraction_empty"])
            action = info["action"]
            message = info["message"]

            lines.append(f"**{action}** ({len(items)} file{'s' if len(items) != 1 else ''}):")
            lines.append(message)
            for item in items:
                fname = item.get("filename", "unknown")
                reason = item.get("reason", "")
                if reason and category != "duplicate":
                    lines.append(f"- `{fname}` — {reason}")
                else:
                    lines.append(f"- `{fname}`")

            tip = info.get("tip")
            if tip:
                lines.append(f"> Tip: {tip}")
            lines.append("")

    # Chunk-level skip info (for transcript ingestion)
    elif chunks_skipped > 0 or chunks_failed > 0:
        has_content = False
        if chunks_skipped > 0:
            info = SKIP_REMEDIATION["extraction_empty"]
            lines.append("")
            lines.append(f"### Skipped Sections ({chunks_skipped})")
            lines.append(info["message"])
            has_content = True

        if chunks_failed > 0:
            lines.append("")
            lines.append(f"### Failed Sections ({chunks_failed})")
            lines.append("Some sections failed during extraction. These will be retried on the next ingestion cycle.")
            has_content = True

        if not has_content:
            return ""

    return "\n".join(lines)


def _format_ingestion_receipt(
    mind_name: str,
    source_ref: str,
    result: dict,
    is_meeting: bool = True,
    skipped_items: list[dict] | None = None,
) -> str:
    """Format a human-readable ingestion receipt.

    Args:
        mind_name: Name of the client mind.
        source_ref: Source reference (e.g. meeting ID, folder path).
        result: Dict from IngestEngine.process_source() with keys:
                new, updated, skipped, chunks_succeeded, chunks_failed,
                by_type, dedup_removed, estimate.
        is_meeting: Whether this is a meeting transcript (vs folder/batch).
        skipped_items: List of dicts with 'filename', 'reason', 'ext' keys
                       for file-level skip reporting.

    Returns:
        Markdown-formatted receipt string.
    """
    new = result.get("new", 0)
    updated = result.get("updated", 0)
    skipped = result.get("skipped", 0)
    chunks_succeeded = result.get("chunks_succeeded", 0)
    chunks_failed = result.get("chunks_failed", 0)
    by_type = result.get("by_type", {})
    dedup_removed = result.get("dedup_removed", 0)

    total_memories = new + updated
    source_label = "Meeting transcript" if is_meeting else "Document batch"

    lines: list[str] = []
    lines.append(f"## Ingestion Complete: {mind_name}")
    lines.append("")
    lines.append(f"**Source:** {source_label} — `{source_ref}`")
    lines.append(f"**Memories extracted:** {total_memories} ({new} new, {updated} updated)")

    if skipped:
        lines.append(f"**Sections skipped:** {skipped}")

    if dedup_removed:
        lines.append(f"**Duplicates removed:** {dedup_removed}")

    # Memory type breakdown
    if by_type:
        type_parts = [f"{count} {mtype}" for mtype, count in sorted(by_type.items())]
        lines.append(f"**By type:** {', '.join(type_parts)}")

    # Chunk processing stats
    total_chunks = chunks_succeeded + chunks_failed + skipped
    if total_chunks > 0:
        lines.append(f"**Chunks:** {chunks_succeeded}/{total_chunks} succeeded")

    # Append skip report if there are skipped/failed items
    skip_report = _format_skip_report(
        skipped_items=skipped_items,
        chunks_skipped=skipped,
        chunks_failed=chunks_failed,
    )
    if skip_report:
        lines.append(skip_report)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(mcp_server):  # pragma: no cover
    """Register auto-ingest tools on the MCP server."""
    from coppermind_cmo.server import (
        get_db, get_config, set_last_tool_call, get_customer_id,
        get_session_id,
    )
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("find_uningested_meetings")
    def find_uningested_meetings() -> dict:
        """Find meetings with confident mind matches whose transcripts haven't been ingested.

        Returns a list of meetings ready for auto-ingestion. Each entry includes
        the meeting_log_id, mind_id, mind_name, title, and start_time needed to
        fetch the transcript (via Granola MCP) and call auto_ingest_transcript.

        Does NOT require an active mind — scans across all client minds.
        """
        set_last_tool_call("find_uningested_meetings")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        result = _find_uningested_meetings(get_db(), customer_id)
        return attach_notifications(result, customer_id=customer_id, db=get_db())

    @mcp_server.tool()
    @safe_tool_call("auto_ingest_transcript")
    def auto_ingest_transcript(
        mind_id: str,
        meeting_log_id: str,
        transcript_text: str,
        source_ref: str,
        mind_name: str = "",
    ) -> dict:
        """Ingest a meeting transcript into a client mind (non-blocking).

        Dispatches ingestion to a background thread and returns immediately
        with a processing status and time estimate. The meeting_log entry is
        marked as ingested automatically after successful background completion.
        Results are delivered as notifications on the next tool call.

        Parameters:
        - mind_id: UUID of the target client mind (required)
        - meeting_log_id: UUID of the meeting_log entry (required)
        - transcript_text: Full meeting transcript text (required)
        - source_ref: Unique identifier for the transcript source, e.g. Granola meeting ID (required)
        - mind_name: Name of the client mind (optional, resolved from DB if empty)
        """
        set_last_tool_call("auto_ingest_transcript")
        customer_id = get_customer_id()
        if not customer_id:
            return tool_error("NO_CUSTOMER", "No customer context. Check your API key.")
        result = _auto_ingest_transcript(
            mind_id, mind_name, meeting_log_id, transcript_text,
            source_ref, get_db(), get_config(), customer_id,
            db_factory=get_db,
            session_id=get_session_id(),
        )
        return attach_notifications(result, customer_id=customer_id, db=get_db())
