"""EOS Layer tools: rocks, sprint plans, agenda items, issues.

Implements the EOS (Entrepreneurial Operating System) management layer
for quarterly rocks, sprint planning, meeting agendas, and issue tracking.
"""

import csv
import io
import json
from datetime import date, datetime, timezone
from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.errors import NO_ACTIVE_MIND, INVALID_INPUT, tool_error
from coppermind_cmo.lifecycle import (
    validate_transition, get_transition_fields, InvalidTransition,
    is_now_sentinel, ENTITY_AGENDA, ENTITY_ISSUE,
)
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import get_mind_cadence
from coppermind_cmo.cadence_utils import get_current_sprint as compute_current_sprint

logger = ToolLogger("eos")


from coppermind_cmo.parsing import escape_like as _escape_like

# Valid status values
ROCK_STATUSES = {"on_track", "off_track", "at_risk", "complete", "dropped"}
DELIVERABLE_STATUSES = {"not_started", "in_progress", "complete", "blocked", "cut"}
AGENDA_STATUSES = {"proposed", "scheduled", "discussed", "resolved", "deferred"}
ISSUE_STATUSES = {"identified", "discussed", "solved", "deferred"}

# CSV safety
from coppermind_cmo.parsing import sanitize_csv_cell as _sanitize_csv_cell
from coppermind_cmo.parsing import _MAX_CELL_CHARS
_MAX_INITIATIVES = 100

# ---------- Lifecycle action → status maps ----------

_AGENDA_ACTION_STATUS = {"resolve": "resolved", "defer": "deferred", "schedule": "scheduled"}
_ISSUE_ACTION_STATUS = {"solve": "solved", "defer": "deferred", "discuss": "discussed"}


def _build_transition_clauses(entity_type: str, to_status: str) -> tuple[list[str], list]:
    """Convert lifecycle field rules to SQL SET clause fragments.
    Returns (set_clauses, params).
    """
    fields = get_transition_fields(entity_type, to_status)
    clauses = []
    params = []
    for field, value in fields["set"].items():
        if is_now_sentinel(value):
            clauses.append(f"{field} = now()")
        else:
            clauses.append(f"{field} = %s")
            params.append(value)
    for field in fields["clear"]:
        clauses.append(f"{field} = NULL")
    return clauses, params


# ---------- Table detection caching ----------

_rocks_table_exists: bool | None = None
_sprint_plans_table_exists: bool | None = None
_agenda_items_table_exists: bool | None = None
_eos_issues_table_exists: bool | None = None


def _has_rocks(db: Database) -> bool:
    """Check if rocks table exists. Only caches True."""
    global _rocks_table_exists
    if _rocks_table_exists is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'rocks' AND table_schema = current_schema()"
            )
            if row is not None:
                _rocks_table_exists = True
            return row is not None
        except Exception:
            return False
    return _rocks_table_exists


def _has_sprint_plans(db: Database) -> bool:
    """Check if sprint_plans table exists. Only caches True."""
    global _sprint_plans_table_exists
    if _sprint_plans_table_exists is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'sprint_plans' AND table_schema = current_schema()"
            )
            if row is not None:
                _sprint_plans_table_exists = True
            return row is not None
        except Exception:
            return False
    return _sprint_plans_table_exists


def _has_agenda_items(db: Database) -> bool:
    """Check if agenda_items table exists. Only caches True."""
    global _agenda_items_table_exists
    if _agenda_items_table_exists is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'agenda_items' AND table_schema = current_schema()"
            )
            if row is not None:
                _agenda_items_table_exists = True
            return row is not None
        except Exception:
            return False
    return _agenda_items_table_exists


def _has_eos_issues(db: Database) -> bool:
    """Check if eos_issues table exists. Only caches True."""
    global _eos_issues_table_exists
    if _eos_issues_table_exists is None:
        try:
            row = db.fetch_one(
                "SELECT 1 FROM information_schema.tables WHERE table_name = 'eos_issues' AND table_schema = current_schema()"
            )
            if row is not None:
                _eos_issues_table_exists = True
            return row is not None
        except Exception:
            return False
    return _eos_issues_table_exists


def _table_not_ready(name: str) -> dict:
    """Standard response when an EOS table doesn't exist yet."""
    return tool_error(
        "MIGRATION_REQUIRED",
        f"Run the EOS migrations to enable the {name} feature.",
    )


# ============================================================
# Core functions (underscore-prefixed, testable without MCP)
# ============================================================


def _manage_rock(
    title: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    description: str | None = None,
    owner: str | None = None,
    status: str | None = None,
    progress_pct: int | None = None,
    quarter_year: int | None = None,
    quarter: int | None = None,
    rock_id: str | None = None,
    update_title: bool = False,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_rocks(db):
        return _table_not_ready("rocks")

    mind_id, _ = active_mind

    if not title or not title.strip():
        return INVALID_INPUT("title cannot be empty")
    title = title.strip()
    if len(title) > 500:
        return INVALID_INPUT("title exceeds 500 character limit")

    if status is not None and status not in ROCK_STATUSES:
        return INVALID_INPUT(f"status must be one of: {', '.join(sorted(ROCK_STATUSES))}")

    if progress_pct is not None and (progress_pct < 0 or progress_pct > 100):
        return INVALID_INPUT("progress_pct must be between 0 and 100")

    # Default quarter from cadence
    cadence = get_mind_cadence(mind_id, db)
    if quarter_year is None:
        quarter_year = cadence.get("year")
    if quarter is None:
        quarter = cadence.get("quarter")
    if quarter_year is None or quarter is None:
        return INVALID_INPUT(
            "quarter_year and quarter are required. Set them here or configure the mind's cadence first."
        )
    if quarter < 1 or quarter > 4:
        return INVALID_INPUT("quarter must be between 1 and 4")

    # If rock_id provided, update directly
    if rock_id:
        set_clauses = []
        params: list[Any] = []
        if update_title:
            set_clauses.append("title = %s")
            params.append(title)
        if description is not None:
            set_clauses.append("description = %s")
            params.append(description)
        if owner is not None:
            set_clauses.append("owner = %s")
            params.append(owner)
        if status is not None:
            set_clauses.append("status = %s")
            params.append(status)
        if progress_pct is not None:
            set_clauses.append("progress_pct = %s")
            params.append(progress_pct)
        if not set_clauses:
            return INVALID_INPUT("Nothing to update")
        params.extend([rock_id, mind_id])
        row = db.execute_returning(
            f"UPDATE rocks SET {', '.join(set_clauses)} "
            "WHERE id = %s AND mind_id = %s "
            "RETURNING id, title, status, progress_pct",
            params,
        )
        if not row:
            return tool_error("NOT_FOUND", "Rock not found or belongs to a different client.")
        return {
            "rock_id": str(row[0]),
            "title": row[1],
            "status": row[2],
            "progress_pct": row[3],
            "is_new": False,
        }

    # Upsert by title (case-insensitive, same quarter)
    set_parts = ["description = COALESCE(EXCLUDED.description, rocks.description)"]
    if owner is not None:
        set_parts.append("owner = EXCLUDED.owner")
    else:
        set_parts.append("owner = COALESCE(EXCLUDED.owner, rocks.owner)")
    if status is not None:
        set_parts.append("status = EXCLUDED.status")
    if progress_pct is not None:
        set_parts.append("progress_pct = EXCLUDED.progress_pct")
    set_parts.append("updated_at = now()")

    upsert_sql = (
        "INSERT INTO rocks (mind_id, quarter_year, quarter, title, description, owner, status, progress_pct) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
        f"ON CONFLICT (mind_id, quarter_year, quarter, LOWER(title)) DO UPDATE SET {', '.join(set_parts)} "
        "RETURNING id, title, status, progress_pct, "
        "(xmax = 0) AS is_new"
    )
    upsert_params = [
        mind_id, quarter_year, quarter, title,
        description, owner,
        status or "on_track",
        progress_pct if progress_pct is not None else 0,
    ]
    row = db.execute_returning(upsert_sql, upsert_params)
    if not row:
        return tool_error("DB_ERROR", "Failed to save rock. Try again.")

    logger.info(f"Managed rock: {row[1]}", mind_id=mind_id)
    return {
        "rock_id": str(row[0]),
        "title": row[1],
        "status": row[2],
        "progress_pct": row[3],
        "is_new": row[4],
    }


def _get_rocks(
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
    status: str | None = None,
) -> list[dict] | dict:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_rocks(db):
        return _table_not_ready("rocks")

    mind_id, _ = active_mind

    # Default quarter from cadence
    cadence = get_mind_cadence(mind_id, db)
    if quarter_year is None:
        quarter_year = cadence.get("year")
    if quarter is None:
        quarter = cadence.get("quarter")

    where = ["r.mind_id = %s"]
    params: list[Any] = [mind_id]

    if quarter_year is not None:
        where.append("r.quarter_year = %s")
        params.append(quarter_year)
    if quarter is not None:
        where.append("r.quarter = %s")
        params.append(quarter)
    if status is not None:
        if status not in ROCK_STATUSES:
            return INVALID_INPUT(f"status must be one of: {', '.join(sorted(ROCK_STATUSES))}")
        where.append("r.status = %s")
        params.append(status)

    # LEFT JOIN sprint_deliverables for counts
    has_deliverables = _has_sprint_plans(db)
    if has_deliverables:
        sql = (
            "SELECT r.id, r.title, r.description, r.owner, r.status, r.progress_pct, "
            "r.quarter_year, r.quarter, r.created_at, r.updated_at, "
            "COUNT(sd.id) AS deliverable_count, "
            "CASE WHEN COUNT(sd.id) > 0 "
            "THEN ROUND(100.0 * COUNT(CASE WHEN sd.status = 'complete' THEN 1 END) / COUNT(sd.id)) "
            "ELSE 0 END AS deliverable_completion_pct "
            "FROM rocks r "
            "LEFT JOIN sprint_deliverables sd ON sd.rock_id = r.id "
            f"WHERE {' AND '.join(where)} "
            "GROUP BY r.id "
            "ORDER BY r.status = 'complete' ASC, r.progress_pct DESC, r.title ASC"
        )
    else:
        sql = (
            "SELECT r.id, r.title, r.description, r.owner, r.status, r.progress_pct, "
            "r.quarter_year, r.quarter, r.created_at, r.updated_at "
            "FROM rocks r "
            f"WHERE {' AND '.join(where)} "
            "ORDER BY r.status = 'complete' ASC, r.progress_pct DESC, r.title ASC"
        )

    rows = db.fetch_all(sql, params)

    results = []
    for r in rows:
        rock = {
            "rock_id": str(r[0]),
            "title": r[1],
            "description": r[2],
            "owner": r[3],
            "status": r[4],
            "progress_pct": r[5],
            "quarter_year": r[6],
            "quarter": r[7],
            "created_at": r[8].isoformat() if r[8] else None,
            "updated_at": r[9].isoformat() if r[9] else None,
        }
        if has_deliverables:
            rock["deliverable_count"] = r[10]
            rock["deliverable_completion_pct"] = int(r[11]) if r[11] is not None else 0
        results.append(rock)
    return results


def _get_or_create_sprint_plan(
    mind_id: str, quarter_year: int, quarter: int, db: Database,
) -> str:
    """Get or create a sprint_plan row, returning its id."""
    row = db.fetch_one(
        "SELECT id FROM sprint_plans WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
        [mind_id, quarter_year, quarter],
    )
    if row:
        return str(row[0])
    new_row = db.execute_returning(
        "INSERT INTO sprint_plans (mind_id, quarter_year, quarter) "
        "VALUES (%s, %s, %s) "
        "ON CONFLICT (mind_id, quarter_year, quarter) DO UPDATE SET updated_at = now() "
        "RETURNING id",
        [mind_id, quarter_year, quarter],
    )
    return str(new_row[0])


def _parse_csv_data(data: str) -> list[dict]:
    """Parse long-format CSV sprint plan data into list of dicts.

    Expected columns: initiative_name, owner, quarterly_goal, sprint_number, deliverable, notes
    All cells are sanitized for CSV injection and length.
    """
    reader = csv.DictReader(io.StringIO(data.strip()))
    rows = []
    for i, row in enumerate(reader):
        if i >= _MAX_INITIATIVES:
            break
        cleaned = {}
        for k, v in row.items():
            if k is None or v is None:
                continue
            clean_key = k.strip().lower().replace(" ", "_")
            clean_val = v.strip() if v else ""
            cleaned[clean_key] = clean_val
        for key in cleaned:
            if isinstance(cleaned[key], str):
                cleaned[key] = _sanitize_csv_cell(cleaned[key])
        if cleaned.get("initiative_name"):
            rows.append(cleaned)
    return rows


def _is_wide_csv(data: str) -> bool:
    """Detect if CSV data is in wide format (header row contains 'Sprint N' columns).

    Wide format headers look like: Owner, Sprint 1, Sprint 2, ..., Goal/Target
    Long format headers look like: initiative_name, sprint_number, deliverable
    We distinguish by checking for 'Sprint' followed by a space and digit.
    """
    import re
    reader = csv.reader(io.StringIO(data.strip()))
    try:
        headers = next(reader)
    except StopIteration:
        return False
    sprint_col_pattern = re.compile(r"^\s*sprint\s+\d", re.IGNORECASE)
    return any(sprint_col_pattern.match(h) for h in headers[1:])


def _parse_wide_csv_data(data: str) -> tuple[list[dict], list[str]]:
    """Parse wide-format CSV sprint plan data.

    Wide format:
      Row 0: headers — Owner, Sprint 1, Sprint 2, ..., Goal/Target
      Row 1: end dates — (empty), 10/17/2025, 10/31/2025, ...
      Row 2+: initiatives — owner, deliverable-per-sprint, quarterly_goal

    Returns (items, sprint_end_dates) where items is a list of dicts
    with keys: initiative_name (= owner), owner, quarterly_goal,
    sprint_number, deliverable.
    sprint_end_dates is a list of ISO date strings.
    """
    reader = csv.reader(io.StringIO(data.strip()))
    rows_raw = list(reader)
    if len(rows_raw) < 2:
        return [], []

    headers = [h.strip() for h in rows_raw[0]]

    # Identify sprint column indices and goal column index
    sprint_cols: list[tuple[int, int]] = []  # (col_index, sprint_number)
    goal_col: int | None = None
    for idx, h in enumerate(headers):
        hl = h.lower()
        if hl.startswith("sprint"):
            # Extract sprint number: "Sprint 1" -> 1
            parts = h.split()
            try:
                snum = int(parts[-1])
            except (ValueError, IndexError):
                snum = len(sprint_cols) + 1
            sprint_cols.append((idx, snum))
        elif hl in ("goal/target", "goal", "target", "quarterly_goal"):
            goal_col = idx

    if not sprint_cols:
        return [], []

    # Parse row 1 for sprint end dates
    from coppermind_cmo.parsing import parse_date as _parse_date_fn
    date_row = rows_raw[1] if len(rows_raw) > 1 else []
    sprint_end_dates: list[str] = []
    for col_idx, snum in sprint_cols:
        raw_date = date_row[col_idx].strip() if col_idx < len(date_row) else ""
        if raw_date:
            parsed = _parse_date_fn(raw_date)  # strict_iso=False, tries all formats
            if parsed:
                sprint_end_dates.append(parsed.isoformat())
        # If date is empty or unparseable, skip (don't add to list)

    # Parse initiative rows (row 2+)
    items: list[dict] = []
    initiative_count = 0
    for row in rows_raw[2:]:
        if not row or not any(cell.strip() for cell in row):
            continue
        initiative_count += 1
        if initiative_count > _MAX_INITIATIVES:
            break

        owner = _sanitize_csv_cell(row[0].strip()) if row[0].strip() else None
        quarterly_goal = None
        if goal_col is not None and goal_col < len(row):
            qg = row[goal_col].strip()
            if qg:
                quarterly_goal = _sanitize_csv_cell(qg)

        # Use quarterly_goal as initiative_name, fallback to owner
        initiative_name = quarterly_goal or owner or ""
        if not initiative_name:
            continue

        for col_idx, snum in sprint_cols:
            deliverable = row[col_idx].strip() if col_idx < len(row) else ""
            if not deliverable:
                continue  # skip empty cells
            items.append({
                "initiative_name": _sanitize_csv_cell(initiative_name),
                "owner": owner,
                "quarterly_goal": quarterly_goal,
                "sprint_number": str(snum),
                "deliverable": _sanitize_csv_cell(deliverable),
            })

    return items, sprint_end_dates


def _import_sprint_plan(
    data: str,
    fmt: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_sprint_plans(db):
        return _table_not_ready("sprint plans")

    mind_id, _ = active_mind

    if not data or not data.strip():
        return INVALID_INPUT("data cannot be empty")

    # Default quarter from cadence
    cadence = get_mind_cadence(mind_id, db)
    if quarter_year is None:
        quarter_year = cadence.get("year")
    if quarter is None:
        quarter = cadence.get("quarter")
    if quarter_year is None or quarter is None:
        return INVALID_INPUT(
            "quarter_year and quarter are required. Set them here or configure the mind's cadence first."
        )

    # Parse data
    sprint_end_dates: list[str] = []
    if fmt == "json":
        try:
            items = json.loads(data)
            if not isinstance(items, list):
                return INVALID_INPUT("JSON data must be a list of objects")
            for item in items:
                if not isinstance(item, dict):
                    return INVALID_INPUT("Each JSON element must be an object with initiative_name, sprint_number, etc.")
        except json.JSONDecodeError as e:
            return INVALID_INPUT(f"Invalid JSON: {e}")
    elif fmt == "csv":
        try:
            # Auto-detect wide vs long format
            if _is_wide_csv(data):
                items, sprint_end_dates = _parse_wide_csv_data(data)
            else:
                items = _parse_csv_data(data)
        except Exception as e:
            return INVALID_INPUT(f"Invalid CSV: {e}")
    else:
        return INVALID_INPUT("format must be 'csv' or 'json'")

    if not items:
        return INVALID_INPUT("No valid initiatives found in data")
    # CSV parsers enforce _MAX_INITIATIVES internally (by initiative row,
    # not flattened deliverable). For JSON, cap here since it has no parser.
    if fmt == "json" and len(items) > _MAX_INITIATIVES:
        items = items[:_MAX_INITIATIVES]

    # All writes in a single transaction
    imported = 0
    updated = 0
    plan_id = None

    with db.connection() as conn:
        with conn.cursor() as cur:
            # Get or create sprint plan
            cur.execute(
                "SELECT id FROM sprint_plans WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
                [mind_id, quarter_year, quarter],
            )
            row = cur.fetchone()
            if row:
                plan_id = str(row[0])
            else:
                cur.execute(
                    "INSERT INTO sprint_plans (mind_id, quarter_year, quarter) "
                    "VALUES (%s, %s, %s) "
                    "ON CONFLICT (mind_id, quarter_year, quarter) DO UPDATE SET updated_at = now() "
                    "RETURNING id",
                    [mind_id, quarter_year, quarter],
                )
                plan_id = str(cur.fetchone()[0])

            # Update sprint end dates if parsed from wide CSV
            if sprint_end_dates:
                end_dates_json = json.dumps(sprint_end_dates)
                cur.execute(
                    "UPDATE sprint_plans SET sprint_end_dates = %s::jsonb, "
                    "updated_at = now() "
                    "WHERE id = %s",
                    [end_dates_json, plan_id],
                )

            # Upsert all deliverables
            for item in items:
                initiative_name = item.get("initiative_name", "").strip()
                if not initiative_name:
                    continue

                try:
                    sprint_number = int(item.get("sprint_number", 1))
                    if sprint_number < 1:
                        sprint_number = 1
                except (ValueError, TypeError):
                    sprint_number = 1

                deliverable = item.get("deliverable", "").strip() or initiative_name
                item_owner = item.get("owner", "").strip() if item.get("owner") else None
                quarterly_goal = item.get("quarterly_goal", "").strip() if item.get("quarterly_goal") else None
                notes = item.get("notes", "").strip() if item.get("notes") else None

                # Sanitize and enforce length limits
                initiative_name = _sanitize_csv_cell(initiative_name)
                deliverable = _sanitize_csv_cell(deliverable)
                if item_owner:
                    item_owner = _sanitize_csv_cell(item_owner)
                if notes:
                    notes = _sanitize_csv_cell(notes)

                cur.execute(
                    "INSERT INTO sprint_deliverables "
                    "(sprint_plan_id, mind_id, initiative_name, owner, quarterly_goal, "
                    "sprint_number, deliverable, notes) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
                    "ON CONFLICT (sprint_plan_id, LOWER(initiative_name), sprint_number) "
                    "DO UPDATE SET deliverable = EXCLUDED.deliverable, "
                    "owner = COALESCE(EXCLUDED.owner, sprint_deliverables.owner), "
                    "quarterly_goal = COALESCE(EXCLUDED.quarterly_goal, sprint_deliverables.quarterly_goal), "
                    "notes = COALESCE(EXCLUDED.notes, sprint_deliverables.notes), "
                    "updated_at = now() "
                    "RETURNING id, (xmax = 0) AS is_new",
                    [plan_id, mind_id, initiative_name, item_owner, quarterly_goal,
                     sprint_number, deliverable, notes],
                )
                upsert_row = cur.fetchone()
                if upsert_row:
                    if upsert_row[1]:  # is_new
                        imported += 1
                    else:
                        updated += 1

            conn.commit()

    logger.info(
        f"Imported sprint plan: {imported} new, {updated} updated",
        mind_id=mind_id,
    )
    return {
        "sprint_plan_id": plan_id,
        "imported_count": imported,
        "updated_count": updated,
        "quarter_year": quarter_year,
        "quarter": quarter,
    }


def _get_sprint_plan(
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_sprint_plans(db):
        return _table_not_ready("sprint plans")

    mind_id, _ = active_mind

    cadence = get_mind_cadence(mind_id, db)
    if quarter_year is None:
        quarter_year = cadence.get("year")
    if quarter is None:
        quarter = cadence.get("quarter")

    if quarter_year is None or quarter is None:
        return INVALID_INPUT(
            "quarter_year and quarter are required. Configure the mind's cadence first."
        )

    plan_row = db.fetch_one(
        "SELECT id, sprint_end_dates FROM sprint_plans "
        "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
        [mind_id, quarter_year, quarter],
    )
    if not plan_row:
        return {
            "quarter_year": quarter_year,
            "quarter": quarter,
            "sprint_plan_id": None,
            "deliverables": [],
            "message": "No sprint plan found for this quarter.",
        }

    plan_id = str(plan_row[0])
    sprint_end_dates = plan_row[1] if isinstance(plan_row[1], list) else []

    # Get current sprint
    plan_dict = {"sprint_end_dates": sprint_end_dates}
    current_sprint = compute_current_sprint(cadence, plan_dict)

    # Fetch deliverables with optional rock data
    has_rocks_tbl = _has_rocks(db)
    if has_rocks_tbl:
        sql = (
            "SELECT sd.id, sd.initiative_name, sd.owner, sd.quarterly_goal, "
            "sd.sprint_number, sd.deliverable, sd.status, sd.notes, sd.rock_id, "
            "r.title AS rock_title, r.status AS rock_status, r.progress_pct AS rock_progress "
            "FROM sprint_deliverables sd "
            "LEFT JOIN rocks r ON r.id = sd.rock_id "
            "WHERE sd.sprint_plan_id = %s "
            "ORDER BY sd.initiative_name, sd.sprint_number"
        )
    else:
        sql = (
            "SELECT sd.id, sd.initiative_name, sd.owner, sd.quarterly_goal, "
            "sd.sprint_number, sd.deliverable, sd.status, sd.notes, sd.rock_id "
            "FROM sprint_deliverables sd "
            "WHERE sd.sprint_plan_id = %s "
            "ORDER BY sd.initiative_name, sd.sprint_number"
        )

    rows = db.fetch_all(sql, [plan_id])

    deliverables = []
    for r in rows:
        d = {
            "deliverable_id": str(r[0]),
            "initiative_name": r[1],
            "owner": r[2],
            "quarterly_goal": r[3],
            "sprint_number": r[4],
            "deliverable": r[5],
            "status": r[6],
            "notes": r[7],
            "rock_id": str(r[8]) if r[8] else None,
            "is_current_sprint": r[4] == current_sprint if current_sprint else False,
        }
        if has_rocks_tbl and len(r) > 9:
            d["rock_title"] = r[9]
            d["rock_status"] = r[10]
            d["rock_progress"] = r[11]
        deliverables.append(d)

    return {
        "sprint_plan_id": plan_id,
        "quarter_year": quarter_year,
        "quarter": quarter,
        "current_sprint": current_sprint,
        "sprint_end_dates": sprint_end_dates,
        "deliverables": deliverables,
    }


def _update_sprint_status(
    initiative_name: str,
    status: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    sprint_number: int | None = None,
    notes: str | None = None,
    rock_id: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_sprint_plans(db):
        return _table_not_ready("sprint plans")

    mind_id, _ = active_mind

    if not initiative_name or not initiative_name.strip():
        return INVALID_INPUT("initiative_name cannot be empty")
    if status not in DELIVERABLE_STATUSES:
        return INVALID_INPUT(f"status must be one of: {', '.join(sorted(DELIVERABLE_STATUSES))}")

    # Default sprint_number from cadence
    sprint_resolved_via = "explicit"
    if sprint_number is None:
        cadence = get_mind_cadence(mind_id, db)
        plan_row = db.fetch_one(
            "SELECT sprint_end_dates FROM sprint_plans "
            "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
            [mind_id, cadence.get("year"), cadence.get("quarter")],
        )
        plan_dict = {"sprint_end_dates": plan_row[0]} if plan_row and plan_row[0] else None
        sprint_number = compute_current_sprint(cadence, plan_dict)
        if sprint_number is not None and plan_dict is not None:
            sprint_resolved_via = "sprint_plan"
        elif sprint_number is not None:
            sprint_resolved_via = "cadence_fallback"
        else:
            sprint_number = cadence.get("sprint", 1)
            sprint_resolved_via = "cadence_fallback"

    # Fuzzy match: case-insensitive substring
    search_term = _escape_like(initiative_name.strip().lower())
    rows = db.fetch_all(
        "SELECT id, initiative_name, status, sprint_number "
        "FROM sprint_deliverables "
        "WHERE mind_id = %s AND sprint_number = %s "
        "AND LOWER(initiative_name) LIKE %s ESCAPE '\\'",
        [mind_id, sprint_number, f"%{search_term}%"],
    )

    if not rows:
        return tool_error(
            "NOT_FOUND",
            f"No deliverable matching '{initiative_name}' found for sprint {sprint_number}.",
        )

    if len(rows) > 1:
        matches = [{"deliverable_id": str(r[0]), "initiative_name": r[1]} for r in rows]
        return tool_error(
            "AMBIGUOUS_MATCH",
            f"Multiple deliverables match '{initiative_name}'. "
            f"Be more specific or use the deliverable_id.",
        ) | {"matches": matches}

    match = rows[0]
    deliverable_id = str(match[0])
    previous_status = match[2]

    set_clauses = ["status = %s"]
    params: list[Any] = [status]
    if notes is not None:
        set_clauses.append("notes = %s")
        params.append(notes)
    if rock_id is not None:
        # Validate rock belongs to the same mind
        rock_check = db.fetch_one(
            "SELECT 1 FROM rocks WHERE id = %s AND mind_id = %s",
            [rock_id, mind_id],
        )
        if not rock_check:
            return INVALID_INPUT("rock_id not found or belongs to a different client")
        set_clauses.append("rock_id = %s")
        params.append(rock_id)
    params.extend([deliverable_id, mind_id])

    db.execute(
        f"UPDATE sprint_deliverables SET {', '.join(set_clauses)} "
        "WHERE id = %s AND mind_id = %s",
        params,
    )

    logger.info(
        f"Updated sprint status: {match[1]} {previous_status} -> {status}",
        mind_id=mind_id,
    )
    return {
        "deliverable_id": deliverable_id,
        "initiative_name": match[1],
        "status": status,
        "previous_status": previous_status,
        "sprint_resolved_via": sprint_resolved_via,
    }


def _get_current_sprint(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind
    cadence = get_mind_cadence(mind_id, db)

    if not cadence:
        return INVALID_INPUT("No cadence configured. Use configure_mind to set up EOS cadence.")

    qy = cadence.get("year")
    q = cadence.get("quarter")
    spq = cadence.get("sprints_per_quarter")

    plan_dict = None
    sprint_end_dates = []
    if _has_sprint_plans(db) and qy and q:
        plan_row = db.fetch_one(
            "SELECT sprint_end_dates FROM sprint_plans "
            "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
            [mind_id, qy, q],
        )
        if plan_row and plan_row[0]:
            sprint_end_dates = plan_row[0] if isinstance(plan_row[0], list) else []
            plan_dict = {"sprint_end_dates": sprint_end_dates}

    current = compute_current_sprint(cadence, plan_dict)

    result: dict[str, Any] = {
        "current_sprint": current,
        "sprint_number": current,  # backward compat
        "total_sprints": spq,
        "quarter_year": qy,
        "quarter": q,
    }

    # Compute sprint end date and days remaining
    if current and sprint_end_dates and current <= len(sprint_end_dates):
        from coppermind_cmo.parsing import parse_date as _parse_date_fn
        try:
            end_str = sprint_end_dates[current - 1]
            end_date = _parse_date_fn(end_str, strict_iso=True)
            if end_date is not None:
                result["sprint_ends"] = end_str
                result["days_remaining"] = max(0, (end_date - date.today()).days)
        except (IndexError,):
            pass

    return result


def _start_quarter(
    quarter_year: int,
    quarter: int,
    db: Database,
    active_mind: tuple[str, str] | None,
    rocks: list[dict] | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_rocks(db):
        return _table_not_ready("rocks")

    mind_id, _ = active_mind

    if quarter < 1 or quarter > 4:
        return INVALID_INPUT("quarter must be between 1 and 4")
    if quarter_year < 2020 or quarter_year > 2100:
        return INVALID_INPUT("quarter_year must be between 2020 and 2100")

    # Read existing cadence (don't write to it)
    cadence = get_mind_cadence(mind_id, db)
    if not cadence:
        return INVALID_INPUT("No cadence configured. Use configure_mind to set up EOS cadence first.")

    rocks_created = 0
    rock_ids = []
    if rocks:
        for rock_data in rocks:
            rock_title = rock_data.get("title", "").strip()
            if not rock_title:
                continue
            result = _manage_rock(
                title=rock_title,
                db=db,
                active_mind=active_mind,
                description=rock_data.get("description"),
                owner=rock_data.get("owner"),
                quarter_year=quarter_year,
                quarter=quarter,
            )
            if not result.get("error"):
                rocks_created += 1
                rock_ids.append(result["rock_id"])

    logger.info(
        f"Started Q{quarter} {quarter_year}: {rocks_created} rocks",
        mind_id=mind_id,
    )
    return {
        "quarter_year": quarter_year,
        "quarter": quarter,
        "rocks_created": rocks_created,
        "rock_ids": rock_ids,
    }


def _quarterly_pacing(
    db: Database,
    active_mind: tuple[str, str] | None,
    quarter_year: int | None = None,
    quarter: int | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_rocks(db):
        return _table_not_ready("rocks")

    mind_id, _ = active_mind
    cadence = get_mind_cadence(mind_id, db)

    if quarter_year is None:
        quarter_year = cadence.get("year")
    if quarter is None:
        quarter = cadence.get("quarter")
    if quarter_year is None or quarter is None:
        return INVALID_INPUT(
            "quarter_year and quarter are required. Configure the mind's cadence first."
        )

    # Get sprint plan for current sprint info
    plan_dict = None
    sprint_end_dates = []
    if _has_sprint_plans(db):
        plan_row = db.fetch_one(
            "SELECT sprint_end_dates FROM sprint_plans "
            "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s",
            [mind_id, quarter_year, quarter],
        )
        if plan_row and plan_row[0]:
            sprint_end_dates = plan_row[0] if isinstance(plan_row[0], list) else []
            plan_dict = {"sprint_end_dates": sprint_end_dates}

    current_sprint = compute_current_sprint(cadence, plan_dict)

    # Compute expected progress from time elapsed in quarter
    today = date.today()
    # Quarter start: first day of quarter month
    quarter_start_month = (quarter - 1) * 3 + 1
    quarter_start = date(quarter_year, quarter_start_month, 1)
    from calendar import monthrange
    quarter_end_month = quarter * 3
    last_day = monthrange(quarter_year, quarter_end_month)[1]
    quarter_end = date(quarter_year, quarter_end_month, last_day)

    total_days = (quarter_end - quarter_start).days
    elapsed_days = max(0, (today - quarter_start).days)
    days_remaining = max(0, (quarter_end - today).days)
    expected_pct = min(100, round(100 * elapsed_days / total_days)) if total_days > 0 else 0

    # Fetch rocks for this quarter
    rocks_rows = db.fetch_all(
        "SELECT id, title, status, progress_pct FROM rocks "
        "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s "
        "ORDER BY title",
        [mind_id, quarter_year, quarter],
    )

    rocks_data = []
    at_risk_count = 0
    for r in rocks_rows:
        actual = r[3] or 0
        behind = actual < (expected_pct - 15)
        pacing = "behind" if behind else "on_track"
        if r[2] == "complete":
            pacing = "complete"
        elif r[2] == "dropped":
            pacing = "dropped"
        elif r[2] == "at_risk":
            pacing = "at_risk"
        if pacing in ("behind", "at_risk"):
            at_risk_count += 1
        rocks_data.append({
            "rock_id": str(r[0]),
            "title": r[1],
            "status": r[2],
            "progress_pct": actual,
            "expected_pct": expected_pct,
            "pacing": pacing,
        })

    return {
        "quarter_year": quarter_year,
        "quarter": quarter,
        "current_sprint": current_sprint,
        "days_remaining": days_remaining,
        "expected_pct": expected_pct,
        "rocks": rocks_data,
        "at_risk_count": at_risk_count,
    }


def _manage_agenda(
    title: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    action: str = "add",
    description: str | None = None,
    priority: int | None = None,
    meeting_date: str | None = None,
    agenda_id: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_agenda_items(db):
        return _table_not_ready("agenda items")

    mind_id, _ = active_mind

    if not title or not title.strip():
        return INVALID_INPUT("title cannot be empty")
    title = title.strip()

    valid_actions = {"add", "resolve", "defer", "schedule"}
    if action not in valid_actions:
        return INVALID_INPUT(f"action must be one of: {', '.join(sorted(valid_actions))}")

    if priority is not None and (priority < 0 or priority > 3):
        return INVALID_INPUT("priority must be between 0 and 3")

    if action == "add":
        parsed_date = None
        if meeting_date:
            from coppermind_cmo.parsing import parse_date
            parsed_date = parse_date(meeting_date, strict_iso=True)
            if parsed_date is None:
                return INVALID_INPUT("meeting_date must be in YYYY-MM-DD format")

        status = "scheduled" if parsed_date else "proposed"
        row = db.execute_returning(
            "INSERT INTO agenda_items (mind_id, title, description, status, priority, meeting_date) "
            "VALUES (%s, %s, %s, %s, %s, %s) RETURNING id, title, status",
            [mind_id, title, description, status, priority or 0, parsed_date],
        )
        if not row:
            return tool_error("DB_ERROR", "Failed to create agenda item.")
        return {
            "agenda_id": str(row[0]),
            "title": row[1],
            "status": row[2],
            "action_taken": "added",
        }

    # For update actions, find the item
    if agenda_id:
        match = db.fetch_one(
            "SELECT id, title, status FROM agenda_items WHERE id = %s AND mind_id = %s",
            [agenda_id, mind_id],
        )
    else:
        # Fuzzy match on title
        search_term = _escape_like(title.lower())
        matches = db.fetch_all(
            "SELECT id, title, status FROM agenda_items "
            "WHERE mind_id = %s AND LOWER(title) LIKE %s ESCAPE '\\' "
            "AND status NOT IN ('resolved', 'deferred') "
            "ORDER BY created_at DESC",
            [mind_id, f"%{search_term}%"],
        )
        if not matches:
            return tool_error("NOT_FOUND", f"No agenda item matching '{title}' found.")
        if len(matches) > 1:
            return tool_error(
                "AMBIGUOUS_MATCH",
                f"Multiple agenda items match '{title}'. Be more specific or provide agenda_id.",
            )
        match = matches[0]

    if not match:
        return tool_error("NOT_FOUND", "Agenda item not found.")

    item_id = str(match[0])

    # Validate lifecycle transition
    target_status = _AGENDA_ACTION_STATUS.get(action)
    if target_status:
        current_status = match[2]
        try:
            validate_transition(ENTITY_AGENDA, current_status, target_status)
        except InvalidTransition as e:
            return INVALID_INPUT(str(e))

    if action == "resolve":
        transition_clauses, transition_params = _build_transition_clauses(ENTITY_AGENDA, "resolved")
        set_parts = ["status = 'resolved'"] + transition_clauses
        params = transition_params + [item_id, mind_id]
        db.execute(
            f"UPDATE agenda_items SET {', '.join(set_parts)} "
            "WHERE id = %s AND mind_id = %s",
            params,
        )
        return {
            "agenda_id": item_id,
            "title": match[1],
            "status": "resolved",
            "action_taken": "resolved",
        }
    elif action == "defer":
        transition_clauses, transition_params = _build_transition_clauses(ENTITY_AGENDA, "deferred")
        set_parts = ["status = 'deferred'"] + transition_clauses
        params = transition_params + [item_id, mind_id]
        db.execute(
            f"UPDATE agenda_items SET {', '.join(set_parts)} "
            "WHERE id = %s AND mind_id = %s",
            params,
        )
        return {
            "agenda_id": item_id,
            "title": match[1],
            "status": "deferred",
            "action_taken": "deferred",
        }
    elif action == "schedule":
        if not meeting_date:
            return INVALID_INPUT("meeting_date is required for schedule action")
        from coppermind_cmo.parsing import parse_date as _parse_date_fn
        parsed_date = _parse_date_fn(meeting_date, strict_iso=True)
        if parsed_date is None:
            return INVALID_INPUT("meeting_date must be in YYYY-MM-DD format")
        transition_clauses, transition_params = _build_transition_clauses(ENTITY_AGENDA, "scheduled")
        set_parts = ["status = 'scheduled'", "meeting_date = %s"] + transition_clauses
        params = [parsed_date] + transition_params + [item_id, mind_id]
        db.execute(
            f"UPDATE agenda_items SET {', '.join(set_parts)} "
            "WHERE id = %s AND mind_id = %s",
            params,
        )
        return {
            "agenda_id": item_id,
            "title": match[1],
            "status": "scheduled",
            "action_taken": "scheduled",
            "meeting_date": meeting_date,
        }

    return INVALID_INPUT(f"Unknown action: {action}")  # pragma: no cover


def _get_agenda(
    db: Database,
    active_mind: tuple[str, str] | None,
    status: str | None = None,
    meeting_date: str | None = None,
) -> list[dict] | dict:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_agenda_items(db):
        return _table_not_ready("agenda items")

    mind_id, _ = active_mind

    where = ["mind_id = %s"]
    params: list[Any] = [mind_id]

    if status is not None:
        if status not in AGENDA_STATUSES:
            return INVALID_INPUT(f"status must be one of: {', '.join(sorted(AGENDA_STATUSES))}")
        where.append("status = %s")
        params.append(status)

    if meeting_date is not None:
        from coppermind_cmo.parsing import parse_date as _parse_date_fn
        parsed = _parse_date_fn(meeting_date, strict_iso=True)
        if parsed is None:
            return INVALID_INPUT("meeting_date must be in YYYY-MM-DD format")
        where.append("meeting_date = %s")
        params.append(parsed)

    rows = db.fetch_all(
        "SELECT id, title, description, status, priority, meeting_date, "
        "resolved_at, created_at "
        f"FROM agenda_items WHERE {' AND '.join(where)} "
        "ORDER BY priority DESC, created_at DESC",
        params,
    )

    return [
        {
            "agenda_id": str(r[0]),
            "title": r[1],
            "description": r[2],
            "status": r[3],
            "priority": r[4],
            "meeting_date": r[5].isoformat() if r[5] else None,
            "resolved_at": r[6].isoformat() if r[6] else None,
            "created_at": r[7].isoformat() if r[7] else None,
        }
        for r in rows
    ]


def _manage_issue(
    title: str,
    db: Database,
    active_mind: tuple[str, str] | None,
    config: Any = None,
    action: str = "add",
    description: str | None = None,
    raised_by: str | None = None,
    priority: int | None = None,
    resolution: str | None = None,
    todo_text: str | None = None,
    time_discussed_minutes: int | None = None,
    source_agenda_title: str | None = None,
    issue_id: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_eos_issues(db):
        return _table_not_ready("EOS issues")

    mind_id, _ = active_mind

    if not title or not title.strip():
        return INVALID_INPUT("title cannot be empty")
    title = title.strip()

    valid_actions = {"add", "solve", "defer", "discuss"}
    if action not in valid_actions:
        return INVALID_INPUT(f"action must be one of: {', '.join(sorted(valid_actions))}")

    if priority is not None and (priority < 0 or priority > 3):
        return INVALID_INPUT("priority must be between 0 and 3")

    # Get quarter info from cadence
    cadence = get_mind_cadence(mind_id, db)
    qy = cadence.get("year")
    q = cadence.get("quarter")

    # Resolve source agenda item if provided
    source_agenda_id = None
    if source_agenda_title and _has_agenda_items(db):
        escaped_agenda = _escape_like(source_agenda_title.lower())
        agenda_match = db.fetch_one(
            "SELECT id FROM agenda_items "
            "WHERE mind_id = %s AND LOWER(title) LIKE %s ESCAPE '\\' "
            "ORDER BY created_at DESC LIMIT 1",
            [mind_id, f"%{escaped_agenda}%"],
        )
        if agenda_match:
            source_agenda_id = str(agenda_match[0])

    if action == "add":
        row = db.execute_returning(
            "INSERT INTO eos_issues "
            "(mind_id, title, description, raised_by, priority, status, "
            "source_agenda_id, quarter_year, quarter) "
            "VALUES (%s, %s, %s, %s, %s, 'identified', %s, %s, %s) "
            "RETURNING id, title, status",
            [mind_id, title, description, raised_by, priority or 0,
             source_agenda_id, qy, q],
        )
        if not row:
            return tool_error("DB_ERROR", "Failed to create issue.")
        return {
            "issue_id": str(row[0]),
            "title": row[1],
            "status": row[2],
            "action_taken": "added",
        }

    # For update actions, find the issue
    if issue_id:
        match = db.fetch_one(
            "SELECT id, title, status FROM eos_issues WHERE id = %s AND mind_id = %s",
            [issue_id, mind_id],
        )
    else:
        search_term = _escape_like(title.lower())
        matches = db.fetch_all(
            "SELECT id, title, status FROM eos_issues "
            "WHERE mind_id = %s AND LOWER(title) LIKE %s ESCAPE '\\' "
            "AND status NOT IN ('solved', 'deferred') "
            "ORDER BY created_at DESC",
            [mind_id, f"%{search_term}%"],
        )
        if not matches:
            return tool_error("NOT_FOUND", f"No issue matching '{title}' found.")
        if len(matches) > 1:
            return tool_error(
                "AMBIGUOUS_MATCH",
                f"Multiple issues match '{title}'. Be more specific or provide issue_id.",
            )
        match = matches[0]

    if not match:
        return tool_error("NOT_FOUND", "Issue not found.")

    matched_id = str(match[0])

    # Validate lifecycle transition
    target_status = _ISSUE_ACTION_STATUS.get(action)
    if target_status:
        current_status = match[2]
        try:
            validate_transition(ENTITY_ISSUE, current_status, target_status)
        except InvalidTransition as e:
            return INVALID_INPUT(str(e))

    if action == "solve":
        if not resolution:
            return INVALID_INPUT("resolution is required when solving an issue")

        # Create commitment memory if todo_text provided
        commitment_id = None
        if todo_text and config:
            from coppermind_cmo.tools.memories import store_memory_core
            mem_result = store_memory_core(
                content=todo_text,
                memory_type="commitment",
                tags=["eos", "issue-resolution"],
                db=db,
                config=config,
                active_mind=active_mind,
                source_type="manual",
                source_tool="manage_issue",
                summary=f"Issue resolution: {title[:80]}",
            )
            if not mem_result.get("error"):
                commitment_id = mem_result.get("memory_id")

        transition_clauses, transition_params = _build_transition_clauses(ENTITY_ISSUE, "solved")
        set_clauses = [
            "status = 'solved'",
            "resolution = %s",
        ] + transition_clauses
        params: list[Any] = [resolution] + transition_params
        if commitment_id:
            set_clauses.append("commitment_id = %s")
            params.append(commitment_id)
        if time_discussed_minutes is not None:
            set_clauses.append("time_discussed_minutes = %s")
            params.append(time_discussed_minutes)
        if source_agenda_id:
            set_clauses.append("source_agenda_id = %s")
            params.append(source_agenda_id)
        params.extend([matched_id, mind_id])

        db.execute(
            f"UPDATE eos_issues SET {', '.join(set_clauses)} "
            "WHERE id = %s AND mind_id = %s",
            params,
        )
        result = {
            "issue_id": matched_id,
            "title": match[1],
            "status": "solved",
            "action_taken": "solved",
        }
        if commitment_id:
            result["commitment_id"] = commitment_id
        return result

    elif action == "defer":
        transition_clauses, transition_params = _build_transition_clauses(ENTITY_ISSUE, "deferred")
        set_clauses_d = ["status = 'deferred'"] + transition_clauses
        params_d: list[Any] = list(transition_params)
        if time_discussed_minutes is not None:
            set_clauses_d.append("time_discussed_minutes = %s")
            params_d.append(time_discussed_minutes)
        params_d.extend([matched_id, mind_id])

        db.execute(
            f"UPDATE eos_issues SET {', '.join(set_clauses_d)} "
            "WHERE id = %s AND mind_id = %s",
            params_d,
        )
        return {
            "issue_id": matched_id,
            "title": match[1],
            "status": "deferred",
            "action_taken": "deferred",
        }

    elif action == "discuss":
        transition_clauses, transition_params = _build_transition_clauses(ENTITY_ISSUE, "discussed")
        set_clauses_disc = ["status = 'discussed'"] + transition_clauses
        params_disc: list[Any] = list(transition_params)
        if time_discussed_minutes is not None:
            set_clauses_disc.append("time_discussed_minutes = %s")
            params_disc.append(time_discussed_minutes)
        if description is not None:
            set_clauses_disc.append("description = %s")
            params_disc.append(description)
        params_disc.extend([matched_id, mind_id])

        db.execute(
            f"UPDATE eos_issues SET {', '.join(set_clauses_disc)} "
            "WHERE id = %s AND mind_id = %s",
            params_disc,
        )
        return {
            "issue_id": matched_id,
            "title": match[1],
            "status": "discussed",
            "action_taken": "discussed",
        }

    return INVALID_INPUT(f"Unknown action: {action}")  # pragma: no cover


def _get_issues(
    db: Database,
    active_mind: tuple[str, str] | None,
    status: str | None = None,
    quarter_year: int | None = None,
    quarter: int | None = None,
) -> list[dict] | dict:
    if active_mind is None:
        return NO_ACTIVE_MIND()
    if not _has_eos_issues(db):
        return _table_not_ready("EOS issues")

    mind_id, _ = active_mind

    where = ["mind_id = %s"]
    params: list[Any] = [mind_id]

    if status is not None:
        if status not in ISSUE_STATUSES:
            return INVALID_INPUT(f"status must be one of: {', '.join(sorted(ISSUE_STATUSES))}")
        where.append("status = %s")
        params.append(status)

    if quarter_year is not None:
        where.append("quarter_year = %s")
        params.append(quarter_year)
    if quarter is not None:
        where.append("quarter = %s")
        params.append(quarter)

    rows = db.fetch_all(
        "SELECT id, title, description, raised_by, priority, status, "
        "resolution, commitment_id, source_agenda_id, time_discussed_minutes, "
        "quarter_year, quarter, created_at, resolved_at "
        f"FROM eos_issues WHERE {' AND '.join(where)} "
        "ORDER BY priority DESC, created_at DESC",
        params,
    )

    return [
        {
            "issue_id": str(r[0]),
            "title": r[1],
            "description": r[2],
            "raised_by": r[3],
            "priority": r[4],
            "status": r[5],
            "resolution": r[6],
            "commitment_id": str(r[7]) if r[7] else None,
            "source_agenda_id": str(r[8]) if r[8] else None,
            "time_discussed_minutes": r[9],
            "quarter_year": r[10],
            "quarter": r[11],
            "created_at": r[12].isoformat() if r[12] else None,
            "resolved_at": r[13].isoformat() if r[13] else None,
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# L10 Meeting Prep
# ---------------------------------------------------------------------------

def _prep_l10(
    db: Database,
    active_mind: tuple[str, str] | None,
    customer_id: str,
    quarter_year: int | None = None,
    quarter: int | None = None,
) -> dict[str, Any]:
    """Prepare an EOS Level 10 meeting agenda from existing data.

    Aggregates rocks, issues, agenda items, and commitments into the
    standard L10 format: Segue, Scorecard, Rock Review, Headlines,
    To-Do List, IDS, Conclude.
    """
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    # Resolve quarter
    cadence = get_mind_cadence(mind_id, db) or {}
    if quarter_year is None:
        quarter_year = cadence.get("year", datetime.now().year)
    if quarter is None:
        quarter = cadence.get("quarter", (datetime.now().month - 1) // 3 + 1)

    sections = []

    # 1. Segue (5 min) — prompt only, no data needed
    sections.append({
        "name": "segue",
        "duration_minutes": 5,
        "description": "Share one personal and one professional best from the past week.",
        "items": [],
    })

    # 2. Scorecard (5 min) — recent campaign outcomes
    campaign_items = []
    try:
        campaign_rows = db.fetch_all(
            "SELECT id, summary, content, created_at FROM memories "
            "WHERE mind_id = %s AND memory_type = 'campaign_outcome' AND is_current = true "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id],
        )
        for r in campaign_rows:
            campaign_items.append({
                "memory_id": str(r[0]),
                "summary": r[1] or r[2][:200],
                "created_at": r[3].isoformat() if r[3] else None,
            })
    except Exception:
        pass
    sections.append({
        "name": "scorecard",
        "duration_minutes": 5,
        "description": "Review key metrics and campaign outcomes.",
        "items": campaign_items,
    })

    # 3. Rock Review (5 min)
    rock_items = []
    if _has_rocks(db):
        try:
            rock_rows = db.fetch_all(
                "SELECT id, title, description, status, progress_pct, owner "
                "FROM rocks "
                "WHERE mind_id = %s AND quarter_year = %s AND quarter = %s "
                "AND status NOT IN ('dropped') "
                "ORDER BY status, title",
                [mind_id, quarter_year, quarter],
            )
            for r in rock_rows:
                rock_items.append({
                    "rock_id": str(r[0]),
                    "title": r[1],
                    "status": r[3],
                    "progress_pct": r[4] or 0,
                    "owner": r[5],
                    "on_track": r[3] in ("on_track", "complete"),
                })
        except Exception:
            pass
    sections.append({
        "name": "rock_review",
        "duration_minutes": 5,
        "description": "Quick on/off track status for each rock.",
        "items": rock_items,
    })

    # 4. Headlines (5 min) — recent stakeholder/fact memories
    headline_items = []
    try:
        headline_rows = db.fetch_all(
            "SELECT id, summary, content, memory_type, created_at FROM memories "
            "WHERE mind_id = %s AND memory_type IN ('stakeholder', 'fact') "
            "AND is_current = true AND created_at > now() - interval '14 days' "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id],
        )
        for r in headline_rows:
            headline_items.append({
                "memory_id": str(r[0]),
                "summary": r[1] or r[2][:200],
                "type": r[3],
                "created_at": r[4].isoformat() if r[4] else None,
            })
    except Exception:
        pass
    sections.append({
        "name": "headlines",
        "duration_minutes": 5,
        "description": "Customer and employee headlines from the past two weeks.",
        "items": headline_items,
    })

    # 5. To-Do List (5 min) — open commitments from recent weeks
    todo_items = []
    try:
        from coppermind_cmo.memory_store import _has_is_completed
        completed_filter = ""
        if _has_is_completed(db):
            completed_filter = "AND (is_completed IS NULL OR is_completed = false)"
        todo_rows = db.fetch_all(
            "SELECT id, summary, content, created_at FROM memories "
            "WHERE mind_id = %s AND memory_type = 'commitment' AND is_current = true "
            f"{completed_filter} "
            "ORDER BY created_at DESC LIMIT 20",
            [mind_id],
        )
        for r in todo_rows:
            todo_items.append({
                "memory_id": str(r[0]),
                "summary": r[1] or r[2][:200],
                "created_at": r[3].isoformat() if r[3] else None,
            })
    except Exception:
        pass
    sections.append({
        "name": "todo_list",
        "duration_minutes": 5,
        "description": "Review open to-dos and commitments.",
        "items": todo_items,
    })

    # 6. IDS (60 min) — open issues
    ids_items = []
    if _has_eos_issues(db):
        try:
            issue_rows = db.fetch_all(
                "SELECT id, title, description, status, resolution "
                "FROM eos_issues "
                "WHERE mind_id = %s AND status IN ('open', 'discussing') "
                "ORDER BY created_at ASC",
                [mind_id],
            )
            for r in issue_rows:
                ids_items.append({
                    "issue_id": str(r[0]),
                    "title": r[1],
                    "description": r[2],
                    "status": r[3],
                })
        except Exception:
            pass

    # Also include open/scheduled agenda items
    if _has_agenda_items(db):
        try:
            agenda_rows = db.fetch_all(
                "SELECT id, title, owner, status "
                "FROM agenda_items "
                "WHERE mind_id = %s AND status IN ('open', 'scheduled') "
                "ORDER BY created_at ASC",
                [mind_id],
            )
            for r in agenda_rows:
                ids_items.append({
                    "agenda_item_id": str(r[0]),
                    "title": r[1],
                    "owner": r[2],
                    "status": r[3],
                    "source": "agenda",
                })
        except Exception:
            pass

    sections.append({
        "name": "ids",
        "duration_minutes": 60,
        "description": "Identify, Discuss, Solve. Work through issues and agenda items.",
        "items": ids_items,
    })

    # 7. Conclude (5 min)
    sections.append({
        "name": "conclude",
        "duration_minutes": 5,
        "description": "Recap new to-dos, rate the meeting 1-10, and confirm action items.",
        "items": [],
    })

    return {
        "mind_name": mind_name,
        "quarter": f"Q{quarter} {quarter_year}",
        "sections": sections,
        "total_duration_minutes": sum(s["duration_minutes"] for s in sections),
    }


# ============================================================
# MCP Registration
# ============================================================


def register(mcp_server):  # pragma: no cover
    """Register EOS tools on the MCP server."""
    from coppermind_cmo.server import (
        get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id,
        stamp_active_client,
    )
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("manage_rock")
    def manage_rock(
        title: str,
        description: str | None = None,
        owner: str | None = None,
        status: str | None = None,
        progress_pct: int | None = None,
        quarter_year: int | None = None,
        quarter: int | None = None,
        rock_id: str | None = None,
        update_title: bool = False,
    ) -> dict:
        """Create or update an EOS Rock (quarterly goal).

        If rock_id is provided, updates that rock. If a rock with the same title
        exists in the same quarter, updates it. Otherwise creates a new rock.

        When using rock_id, the title is used for identification only unless
        update_title=True, in which case the rock is renamed.

        status: on_track, off_track, at_risk, complete, dropped
        progress_pct: 0-100
        """
        set_last_tool_call("manage_rock")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _manage_rock(
            title, get_db(), active_mind,
            description=description, owner=owner, status=status,
            progress_pct=progress_pct, quarter_year=quarter_year,
            quarter=quarter, rock_id=rock_id, update_title=update_title,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_rocks")
    def get_rocks(
        quarter_year: int | None = None,
        quarter: int | None = None,
        status: str | None = None,
    ) -> list | dict:
        """Get EOS Rocks for a quarter. Defaults to current quarter from cadence.

        Includes deliverable counts and completion percentages when sprint plans exist.
        """
        set_last_tool_call("get_rocks")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_get_rocks(
            get_db(), active_mind,
            quarter_year=quarter_year, quarter=quarter, status=status,
        ))

    @mcp_server.tool()
    @safe_tool_call("import_sprint_plan")
    def import_sprint_plan(
        data: str,
        format: str = "csv",
        quarter_year: int | None = None,
        quarter: int | None = None,
    ) -> dict:
        """Import a sprint plan from CSV or JSON data.

        CSV columns: initiative_name, owner, quarterly_goal, sprint_number, deliverable, notes
        Merge behavior: existing deliverables are updated (status is preserved), new ones are added.
        """
        set_last_tool_call("import_sprint_plan")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _import_sprint_plan(
            data, format, get_db(), active_mind,
            quarter_year=quarter_year, quarter=quarter,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_sprint_plan")
    def get_sprint_plan(
        quarter_year: int | None = None,
        quarter: int | None = None,
    ) -> dict:
        """Get the sprint plan for a quarter with deliverables and rock status."""
        set_last_tool_call("get_sprint_plan")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_get_sprint_plan(get_db(), active_mind, quarter_year=quarter_year, quarter=quarter))

    @mcp_server.tool()
    @safe_tool_call("update_sprint_status")
    def update_sprint_status(
        initiative_name: str,
        status: str,
        sprint_number: int | None = None,
        notes: str | None = None,
        rock_id: str | None = None,
    ) -> dict:
        """Update a sprint deliverable's status. Fuzzy-matches on initiative name.

        status: not_started, in_progress, complete, blocked, cut
        """
        set_last_tool_call("update_sprint_status")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _update_sprint_status(
            initiative_name, status, get_db(), active_mind,
            sprint_number=sprint_number, notes=notes, rock_id=rock_id,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_current_sprint")
    def get_current_sprint() -> dict:
        """Get current sprint number, end date, and days remaining."""
        set_last_tool_call("get_current_sprint")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_get_current_sprint(get_db(), active_mind))

    @mcp_server.tool()
    @safe_tool_call("start_quarter")
    def start_quarter(
        quarter_year: int,
        quarter: int,
        rocks: list[dict] | None = None,
    ) -> dict:
        """Start a new EOS quarter. Creates rock rows for provided rocks.

        Does NOT update cadence — use configure_mind for that.
        """
        set_last_tool_call("start_quarter")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _start_quarter(
            quarter_year, quarter, get_db(), active_mind, rocks=rocks,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("quarterly_pacing")
    def quarterly_pacing(
        quarter_year: int | None = None,
        quarter: int | None = None,
    ) -> dict:
        """Check quarterly rock pacing — expected vs actual progress.

        Flags rocks behind pace (actual < expected - 15%).
        """
        set_last_tool_call("quarterly_pacing")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_quarterly_pacing(
            get_db(), active_mind,
            quarter_year=quarter_year, quarter=quarter,
        ))

    @mcp_server.tool()
    @safe_tool_call("manage_agenda")
    def manage_agenda(
        title: str,
        action: str = "add",
        description: str | None = None,
        priority: int | None = None,
        meeting_date: str | None = None,
        agenda_id: str | None = None,
    ) -> dict:
        """Manage meeting agenda items. Actions: add, resolve, defer, schedule.

        priority: 0 (low) to 3 (critical)
        For resolve/defer/schedule: fuzzy-matches on title if agenda_id not provided.
        """
        set_last_tool_call("manage_agenda")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _manage_agenda(
            title, get_db(), active_mind,
            action=action, description=description, priority=priority,
            meeting_date=meeting_date, agenda_id=agenda_id,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_agenda")
    def get_agenda(
        status: str | None = None,
        meeting_date: str | None = None,
    ) -> list | dict:
        """Get agenda items, optionally filtered by status or meeting date."""
        set_last_tool_call("get_agenda")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_get_agenda(get_db(), active_mind, status=status, meeting_date=meeting_date))

    @mcp_server.tool()
    @safe_tool_call("manage_issue")
    def manage_issue(
        title: str,
        action: str = "add",
        description: str | None = None,
        raised_by: str | None = None,
        priority: int | None = None,
        resolution: str | None = None,
        todo_text: str | None = None,
        time_discussed_minutes: int | None = None,
        source_agenda_title: str | None = None,
        issue_id: str | None = None,
    ) -> dict:
        """Manage EOS Issues (IDS — Identify, Discuss, Solve). Actions: add, solve, defer, discuss.

        When solving: resolution is required. Optionally provide todo_text to create a commitment memory.
        source_agenda_title: fuzzy-matches to link this issue to an agenda item.
        """
        set_last_tool_call("manage_issue")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _manage_issue(
            title, get_db(), active_mind, config=get_config(),
            action=action, description=description, raised_by=raised_by,
            priority=priority, resolution=resolution, todo_text=todo_text,
            time_discussed_minutes=time_discussed_minutes,
            source_agenda_title=source_agenda_title, issue_id=issue_id,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_issues")
    def get_issues(
        status: str | None = None,
        quarter_year: int | None = None,
        quarter: int | None = None,
    ) -> list | dict:
        """Get EOS issues, optionally filtered by status and quarter."""
        set_last_tool_call("get_issues")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        return stamp_active_client(_get_issues(
            get_db(), active_mind,
            status=status, quarter_year=quarter_year, quarter=quarter,
        ))

    @mcp_server.tool()
    @safe_tool_call("prep_l10")
    def prep_l10(
        quarter_year: int | None = None,
        quarter: int | None = None,
    ) -> dict:
        """Prepare an EOS Level 10 (L10) meeting agenda.

        Aggregates rocks, issues, agenda items, and open commitments into the
        standard L10 format with 7 sections and time allocations.

        Parameters:
        - quarter_year: Year (default: from cadence)
        - quarter: Quarter number 1-4 (default: from cadence)
        """
        set_last_tool_call("prep_l10")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if _get_access_level(active_mind[0], get_customer_id(), get_db()) != "owner":
            return ACCESS_DENIED("This action requires owner access.")
        result = _prep_l10(
            db=get_db(),
            active_mind=active_mind,
            customer_id=get_customer_id(),
            quarter_year=quarter_year,
            quarter=quarter,
        )
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())
