"""Synthesis tools — second-pass document analysis for deep insights."""

from __future__ import annotations

from coppermind_cmo.log import ToolLogger

logger = ToolLogger("tools.synthesis")


def register(mcp_server):
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("synthesize_document")
    def synthesize_document(
        scope: str = "latest",
        source_ref: str | None = None,
        mind_name: str | None = None,
        force: bool = False,
    ) -> dict:
        """Run deep analysis on raw documents to find patterns, trends, contradictions, and insights the first-pass extraction missed.

        Args:
            scope: "latest" (most recent document), "recent" (last 5), or "all" (all un-synthesized)
            source_ref: Specific document by its source_ref value (overrides scope)
            mind_name: Target mind name (defaults to active mind)
            force: Bypass daily cap and minimum thresholds
        """
        set_last_tool_call("synthesize_document")
        db = get_db()
        config = get_config()
        customer_id = get_customer_id()

        # Resolve mind
        if mind_name:
            row = db.fetch_one(
                "SELECT cm.id, cm.name FROM client_minds cm "
                "WHERE LOWER(cm.name) = LOWER(%s) "
                "AND (cm.customer_id = %s OR EXISTS ("
                "    SELECT 1 FROM customer_mind_access cma "
                "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s AND cma.revoked_at IS NULL"
                ")) AND cm.archived_at IS NULL",
                [mind_name, customer_id, customer_id],
            )
            if not row:
                return {"error": "MIND_NOT_FOUND", "message": f"No mind found matching '{mind_name}'"}
            active_mind = (str(row[0]), row[1])
        else:
            active_mind = get_active_mind()
            if not active_mind:
                return {"error": "NO_ACTIVE_MIND", "message": "No active mind. Switch to a client first."}

        from coppermind_cmo.synthesis import SynthesisEngine
        engine = SynthesisEngine(db=db, config=config, active_mind=active_mind)

        mind_id = active_mind[0]

        # Log force override for audit
        if force:
            logger.info("synthesis_force_override", mind_id=mind_id,
                        customer_id=customer_id)

        # Find documents to synthesize
        if source_ref:
            rows = db.fetch_all(
                "SELECT id FROM raw_documents WHERE mind_id = %s AND source_ref = %s "
                "ORDER BY created_at DESC",
                [mind_id, source_ref],
            )
        elif scope == "latest":
            rows = db.fetch_all(
                "SELECT id FROM raw_documents WHERE mind_id = %s "
                "ORDER BY created_at DESC LIMIT 1",
                [mind_id],
            )
        elif scope == "recent":
            rows = db.fetch_all(
                "SELECT id FROM raw_documents WHERE mind_id = %s "
                "ORDER BY created_at DESC LIMIT 5",
                [mind_id],
            )
        elif scope == "all":
            rows = db.fetch_all(
                "SELECT id FROM raw_documents WHERE mind_id = %s AND extraction_passes < 2 "
                "ORDER BY created_at ASC",
                [mind_id],
            )
        else:
            return {"error": "INVALID_SCOPE", "message": f"Invalid scope '{scope}'. Use 'latest', 'recent', or 'all'."}

        if not rows:
            return {"error": "NO_DOCUMENTS", "message": "No raw documents found for this mind."}

        # Process each document
        total_insights = 0
        total_contradictions = 0
        total_skipped = 0
        detail = []

        for (doc_id,) in rows:
            result = engine.synthesize_document(str(doc_id), force=force)

            if result.get("skipped"):
                total_skipped += 1
                continue
            if "error" in result:
                if result["error"] == "DAILY_CAP_REACHED":
                    # Stop processing — cap hit
                    detail.append({"document": str(doc_id), "status": "cap_reached"})
                    break
                detail.append({"document": str(doc_id), "status": "error", "message": result.get("message")})
                continue

            total_insights += result.get("insights", 0)
            total_contradictions += result.get("contradictions", 0)

            detail.append({
                "document": result.get("document", str(doc_id)),
                "word_count": result.get("word_count", 0),
                "insights": result.get("insights", 0),
                "insights_list": result.get("insights_list", []),
            })

        response = {
            "documents_processed": len(detail),
            "insights_found": total_insights,
            "contradictions_found": total_contradictions,
            "skipped": total_skipped,
            "detail": detail,
        }
        return attach_notifications(response, customer_id=customer_id, db=db)
