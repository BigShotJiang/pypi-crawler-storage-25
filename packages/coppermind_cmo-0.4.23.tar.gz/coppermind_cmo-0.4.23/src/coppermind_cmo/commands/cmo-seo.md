# /cmo-seo — SEO Strategy Panel

Run a multi-expert SEO strategy, audit, or review session using the active client's organic performance, content, competitive landscape, and brand positioning.

## Usage

- `/cmo-seo build an SEO strategy for Acme`
- `/cmo-seo audit our current SEO performance`
- `/cmo-seo review this keyword strategy: [paste content]`
- `/cmo-seo local SEO plan for the new location`

## Detect Mode

- **Plan mode**: prompt contains "build", "create", "plan", "strategy", or references SEO without pasted content
- **Audit mode**: prompt contains "audit", "assess", "analyze", or references current performance
- **Review mode**: prompt contains "review", "critique", "improve", or pasted SEO content without a plan verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — positioning, Positioning Protocol (Promise, Unique Mechanism), messaging pillars, industry terminology
2. `search_memory` — existing SEO data (keyword positions, domain rating, backlinks), competitor intel, content inventory, buyer questions
3. `get_campaign_history` — organic traffic trends, content performance, Past Campaign Snapshot data for SEO campaigns
4. `configure_mind` — business type (local vs. national vs. e-commerce), locations, products/services

If no SEO data is stored, warn:
> "[Client] doesn't have SEO data stored. I'll build the strategy framework, but you'll need to pull current keyword positions, domain rating, and organic traffic data. Tools: Ahrefs, SEMrush, or Google Search Console."

## Step 2: Expert Panel (5 fixed)

1. **Keyword Strategist** — Identifies target keywords by buyer intent stage: informational ("how to..."), commercial ("best..."), transactional ("buy...", "[service] near me"). Groups by topic clusters. Follows the CMOx priority: answer the questions buyers actually ask. "You're targeting 'marketing agency' (29K searches, impossible to rank) when 'fractional CMO for manufacturing' (320 searches, low competition) is your actual buyer query. Chase the long tail first."
2. **Content Planner** — Maps Core Content (evergreen, buyer-question-driven) to keyword clusters. Prioritizes content that supports the EARR Loop: Educate (blog posts answering buyer questions), Acquire (landing pages with clear CTAs), Retain (resources and guides for existing customers). "Your blog has 47 posts about industry news nobody searches for and zero posts answering 'how much does a fractional CMO cost' — which is your #1 buyer question."
3. **Technical Auditor** — Site speed (GTmetrix/Lighthouse), mobile responsiveness, indexing, schema markup, Core Web Vitals. Uses the Pre-Flight Checklist mentality for every page. "Your time-to-interactive is 5.6 seconds — that's about 2 seconds too much. Page 3 of Google until that's fixed." Checks HTML validation, broken links, crawl errors, sitemap, robots.txt.
4. **Authority Builder** — Backlink strategy, domain rating improvement, digital PR, partnerships with non-competitive companies serving the same customers. Follows the CMOx partnership approach. "Your domain rating is 28 vs. competitors at 45-55. Guest posting on 5 industry publications and 3 partnership co-marketing pieces would close half that gap in 6 months."
5. **Local SEO Specialist** — Google Business Profile optimization, review generation strategy (contests, QR codes, multi-review per customer, EDDM), local citations, Google Maps ranking, LSA ads. "You have 12 Google reviews vs. competitors' 80+. Run a 30-day review generation campaign — contest with QR code table tents — before investing in local ads. Reviews are free trust signals."

## Step 3: Execute (mode-dependent)

### Plan Mode

1. **Keyword Strategist leads** — builds the keyword strategy by intent stage and topic cluster.
2. **Other experts contribute** — Content Planner maps content to keywords, Technical Auditor identifies site issues, Authority Builder plans backlink growth, Local SEO Specialist adds local strategy (if applicable).
3. **Converge**: Merge into a single SEO strategy. Keyword Strategist has veto on keyword targeting; Technical Auditor has veto on technical priorities (fix foundation before building content).
4. **Present**:
```
SEO PANEL — Strategy for [Client Name]

CURRENT STATE
- Domain Rating: [current]
- Monthly Organic Traffic: [current]
- Keyword Positions: [# in top 3 / top 10 / top 20]
- Key Competitors: [who and their DR]
— Technical Auditor

KEYWORD STRATEGY
| Topic Cluster | Target Keywords | Intent | Search Volume | Difficulty | Priority |
|--------------|----------------|--------|---------------|------------|----------|
| [cluster] | [keywords] | [info/commercial/transactional] | [volume] | [low/med/high] | [1-5] |
— Keyword Strategist

CONTENT PLAN
| Priority | Content Piece | Target Keyword | EARR Phase | Format |
|----------|--------------|---------------|------------|--------|
| 1 | [title] | [keyword] | [educate/acquire] | [blog/landing/guide] |
— Content Planner

TECHNICAL FIXES
1. [Issue] — [impact on rankings] — [fix] — Technical Auditor
2. ...

AUTHORITY BUILDING
- [Strategy 1] — [expected DR impact] — [timeline] — Authority Builder
- ...

LOCAL SEO (if applicable)
- Google Business Profile: [status and recommendations]
- Reviews: [current count vs. competitors, generation strategy]
- Local Citations: [status]
— Local SEO Specialist

90-DAY SEO ROADMAP
| Month | Focus | Key Deliverables | Expected Impact |
|-------|-------|-----------------|-----------------|
| 1 | [technical + foundation] | [items] | [outcome] |
| 2 | [content + authority] | [items] | [outcome] |
| 3 | [scale + optimize] | [items] | [outcome] |

PANEL FLAGS
- Technical Auditor: [blocking issue to fix first]
- Keyword Strategist: [biggest keyword opportunity]
- Local SEO: [review generation urgency]
```

### Audit/Review Mode

Standard findings format (MUST-FIX / SHOULD-FIX / POLISH) with revised strategy.

## Rules

- **Use real client context.** Reference actual domain metrics, keyword positions, competitor data, and content inventory from memories. Never invent SEO data.
- **Technical foundation first.** Technical Auditor's fixes come before content strategy. A slow, broken site won't rank regardless of content quality. This follows the Priority of Marketing Campaigns: Foundation before Growth.
- **Buyer questions drive content.** Content Planner must prioritize answers to questions actual buyers ask, not industry news or thought leadership. "What does it cost?" and "How does it work?" outperform "5 Trends in 2026" every time.
- **Long tail before head terms.** Keyword Strategist targets achievable keywords first (low difficulty, high intent), not vanity terms. Win the long tail, then expand.
- **Reviews before local ads.** Local SEO Specialist must recommend review generation before paid local campaigns. Reviews are free trust signals that improve both Maps ranking and ad conversion.
- **90-day roadmap is mandatory.** Every SEO plan must have a phased 90-day roadmap aligned to the client's Rocks. SEO is a long game — set expectations.
- **EARR Loop alignment.** Content Planner maps every content piece to an EARR phase. Most SEO content serves Educate (top-of-funnel) — make sure there's also Acquire content (landing pages with CTAs).
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
