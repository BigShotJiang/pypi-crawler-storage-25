# /cmo-morning — Daily Briefing

When Coppermind tool responses include `_active_client`, always prefix your reply with that value in bold. Example: **[Joulica]** — Here are the SEO keywords...

Build a morning briefing across all clients.

## Steps

1. Call `get_cross_client_summary(lookback_hours=48)` to get all client data in one call. This replaces the N+1 pattern of switching to each client individually.
2. If Google Calendar MCP is connected, check today's meetings and match attendees to client minds.
3. Present a unified briefing:

```
GOOD MORNING — [Date]

TODAY'S MEETINGS
- 10:00 Acme Corp (Sarah Chen) — prep available, say "prep my meeting with Acme"
- 2:30 5 Star Charleston (Stephen Graham) — no recent notes, consider catching up

NEEDS ATTENTION
- [Acme] 2 action items overdue from Sprint 3
- [Bluebell] No interaction in 18 days — consider a check-in
- [5 Star] Stephen waiting on van wrap designs (committed 3/10)

THIS WEEK'S SPRINT DELIVERABLES
- [Acme] Publish 4 SEO pages, launch outbound calling
- [5 Star] Finalize hiring reqs, evaluate RP1 platform
```

4. End with: "Want me to prep any of these meetings?"

## Rules
- Process clients in parallel if possible.
- Only show clients that have something to report — skip clients with no open items and no recent activity.
- Keep it scannable. No paragraphs. Bullets and short lines only.
- Don't show the raw switch_client responses. Just present the final briefing.
