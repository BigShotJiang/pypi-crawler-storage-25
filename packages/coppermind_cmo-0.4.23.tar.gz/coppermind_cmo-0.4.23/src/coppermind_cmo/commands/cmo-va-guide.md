# /cmo-va-guide -- VA Onboarding Guide

When Coppermind tool responses include `_active_client`, always prefix your reply with that value in bold. Example: **[Joulica]** — Here's the VA guide...

Generate a personalized setup and usage guide for a VA joining the active client mind. The output is a complete, copy-pasteable document the CMO can hand to their VA.

## Steps

1. **Confirm active mind.** If no mind is active, ask the CMO to switch first. Do not proceed without an active mind.

2. **Ask for VA name.** Say: "What's your VA's name? I'll personalize the guide for them." Wait for the answer. If the CMO already mentioned the name in their request (e.g., "create a VA guide for Alex"), use that name without asking.

3. **Gather context.** Call these tools in parallel — do not display raw tool output to the user, use the data to fill the template:
   - `get_brand_voice` — derive client name, voice summary, and industry from the returned brand DNA fields
   - `search_memory` with query "company overview services" limit 5, include_private=false — get key business facts (exclude sensitive/private data)
   - `list_team` — check if the team has any members (note: returns customer_ids, not names, so you cannot match by VA name — just check if the team is populated)
   - Get the CMO's first name from conversation context. If unknown, ask — do not call `ensure_personal_mind()` just for name resolution.

4. **Generate the guide.** Use the template below, filling in client-specific details. Keep the generated guide under 800 words. The guide should be warm and practical — written for a non-technical person who wants to help their CMO.

5. **Present the guide.** Output the complete document. Then:
   - If `list_team` returned an empty team or failed, say: "[VA name] may not have access to [Client Name] yet. You can add them with 'add [VA name] to [Client Name]' — you'll need their Coppermind account email."
   - Say: "Review the guide, make any edits, and send it to [VA name]. Run /cmo-va-guide again anytime to generate an updated guide with the latest client data."

## Guide Template

Fill in all [bracketed] placeholders with real data from the tools above. Keep the tone warm and practical.

---

**[Client Name] -- Coppermind Quick Start for [VA Name]**

Welcome, [VA name]. [CMO first name] has set you up with Coppermind for [Client Name]. This guide covers everything you need to know.

**What is Coppermind?**
Coppermind is an AI memory layer that remembers everything about [Client Name] -- brand voice, campaign history, meeting notes, action items, and more. It works inside Claude (the AI assistant you're already using). Think of it as a shared brain for the [Client Name] account.

**Key Facts About [Client Name]**
[Insert 3-5 key facts from search_memory results -- company overview, industry, services, any notable details. Format as bullet points. If no memories exist yet, say "This is a new mind -- memories will build up as [CMO first name] uses Coppermind with [Client Name]."]

**Brand Voice Summary**
[Insert 2-3 sentence brand voice summary from get_brand_voice -- tone, personality, key phrases. If no brand voice is set, say "Brand voice hasn't been configured yet. Ask [CMO first name] to set it up."]

**What You Can Do**
- **Search memories:** Ask "what do we know about [topic]?" to find stored knowledge
- **Add notes:** Use "remember: [something]" to suggest new information. Your notes go to [CMO first name] for review before they become permanent -- this is called "pending" status. For example, if you say "remember: client mentioned new product launch in Q3," [CMO first name] will see it in their review queue and approve it.
- **Prep for meetings:** If you attend client calls, ask "prep for my meeting with [person]" to get a briefing
- **Check brand voice:** Ask "what's the brand voice for [Client Name]?" before writing any content

<!-- Viewer role permissions below are based on docs/specs/completed/2.5-team-sharing-design.md. Update when editor role ships. -->
**What You Can't Do (and why)**
Your access is guided — you can search and suggest, but changes go through [CMO first name]:
- You cannot edit or delete existing memories
- You cannot change brand voice or client settings
- You cannot see sensitive notes (stakeholder relationships, strategic decisions)

This isn't a limitation -- it's a safety net. You can explore freely without worrying about breaking anything.

**Setup**

1. Make sure you have Claude Desktop or Claude Code installed (this guide assumes one of these)
2. If you haven't installed Coppermind yet, [CMO first name] will send you separate install instructions
3. Open Claude and say: `switch to [Client Name]`

**Try It Now**

1. Brand voice: `what's the brand voice?`
2. Recent work: `what campaigns are running right now?`
3. Search: `what do we know about [topic relevant to client's industry]?`
4. Add a note: `remember: [something you know about this client]`

**Tips for Getting the Most Out of Coppermind**

1. **Search before you write.** Before drafting any content, search for brand voice and recent campaign context. This saves revision rounds.
2. **Use natural language.** Don't worry about exact commands -- just talk to it like a colleague. "What's the latest on the email campaign?" works great.
3. **Add context when you find it.** If you learn something important from a client call or email, say "remember: [what you learned]". It'll go to [CMO first name] for review.
4. **A typical workflow:** Search brand voice -> search recent campaigns -> draft your content -> add a note about what you created.
5. **Don't worry about:** breaking anything (you can't), asking too many questions (Claude doesn't judge), or searching too much (it's fast and free).

**If something doesn't work**, just tell Claude what you're trying to do -- it'll help you troubleshoot.

**Questions?**
Ask [CMO first name], or just ask Claude -- Coppermind knows a lot already. Try it now: switch to [Client Name] and ask "what should I know about this client?"

---

## Rules

- Always require an active mind before generating
- Ask for the VA's name if not provided -- the guide should feel personal
- Pull real data from tools -- never make up client details
- Use include_private=false on search_memory -- never include private/sensitive memories in the guide
- If brand voice isn't set, note it in the guide instead of omitting the section
- If no memories exist yet, say "This is a new mind -- memories will build up as [CMO first name] uses it"
- Keep the guide under 800 words -- it should be a quick read, not a manual
- Do not include stakeholder information, sensitive memories, or strategic decisions
- Do not include the API key or any credentials in the guide
- Review the generated guide before presenting — exclude any business-sensitive details (pricing, internal roadmap, financial data) even if they appear in non-private memories
