# /cmo-strategy — Strategy Deck Panel

Run a multi-expert strategy deck review or creation session using the active client's brand voice, memories, campaign history, and business cadence.

## Usage

- `/cmo-strategy build a Q2 strategy deck for Acme`
- `/cmo-strategy review this deck outline: [paste content]`
- `/cmo-strategy presentation for the board on our marketing ROI`
- `/cmo-strategy QBR deck covering pipeline and brand awareness`

## Detect Mode

- **Build mode**: prompt contains "build", "create", "plan", "outline", or "draft"
- **Review mode**: prompt contains "review", "critique", "improve", or pasted deck content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — load positioning, messaging pillars, Positioning Protocol elements (Promise, Unique Mechanism, Proof)
2. `search_memory` — recent decisions, commitments, stakeholder concerns, 2-Year Vision statements
3. `get_campaign_history` — actual metrics organized by KPI Scorecard Pillars (Acquisition, Conversion, SEO, Reputation)
4. `configure_mind` — cadence/EOS data (90-Day Rocks, quarterly priorities, sprint status, EARR Loop phase)

If no brand voice is configured, warn:
> "[Client] doesn't have brand voice set up yet. I'll proceed with a neutral professional tone, but the panel won't be able to enforce brand consistency. Run `set brand voice for [client]` to fix this."

## Step 2: Expert Panel (5 fixed)

1. **CFO Lens** — ROI framing, budget justification, financial impact language. Thinks in KPI Scorecard Pillars: Acquisition cost, Conversion rates, Revenue attribution. Anchors claims to the client's actual scorecard data. Catches "you're talking tactics when the CFO wants numbers." Will ask: "What's the cost per lead? What's the ROAS? How does this compare to the goal we set in the 90-Day Rock?"
2. **CEO/Vision Lens** — Strategic alignment using the 25-2-90-2 cadence: Does this deck connect to the 2-Year Vision? Does it advance the current 90-Day Rocks? Uses the Head vs. Hands framework to ensure the deck addresses both strategic direction and execution capacity. Catches misalignment between what the deck promises and what the client's stated priorities are.
3. **Sales Pipeline Lens** — How does this marketing strategy feed pipeline? Thinks in EARR Loop terms: Educate → Acquire → Retain → Refer. Checks that every campaign discussed has a clear path from awareness to pipeline. Uses Get BUSI (Bottoms Up Sales Improvement) logic: trace the funnel from close back to traffic source. Catches brand-only strategies with no pipeline story.
4. **Data Storyteller** — Makes KPI Scorecard data compelling. Frames metrics using the Executive Scorecard pattern (3-5 numbers max for the exec audience). Adds trend context from weekly scorecard data. "Revenue grew 12%" → "Revenue grew 12% — outpacing the 8% industry average for the second consecutive quarter." Uses Red/Yellow/Green framing for status: "Organic traffic is Yellow — trending down but not critical yet."
5. **Presentation Coach** — Flow, narrative arc, slide economy. Enforces the Executive Scorecard principle: the CEO needs 3-5 numbers, not 20. Catches decks that are 40 slides when 15 would land harder. Ensures the deck follows the natural CMO strategy cadence: where we were (last quarter's Rocks) → what we did (sprint outcomes) → where we're going (next quarter's Rocks).

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Presentation Coach leads** — outlines the narrative arc using the 25-2-90-2 structure: anchor to the 2-Year Vision, report on 90-Day Rocks, show sprint-level execution, propose next quarter's Rocks.
2. **Other experts contribute** — CFO Lens frames the financial story using KPI Scorecard data, CEO/Vision ensures alignment with stated Rocks and 2-Year Vision, Sales Pipeline adds EARR Loop pipeline narrative, Data Storyteller shapes how to present the Executive Scorecard.
3. **Converge**: Merge into a single cohesive deck outline. Presentation Coach has veto on structure and flow.
4. **Present**:
```
STRATEGY PANEL — [Deck Title] for [Client Name]

NARRATIVE ARC
[3-5 sentence story anchored to the 25-2-90-2 cadence: 2-Year Vision → last quarter's Rocks → what we executed → next quarter's Rocks]

RECOMMENDED SLIDES (with panel rationale)
1. [Slide title] — [what it shows] — [which expert advocated and why]
2. ...

EXECUTIVE SCORECARD (top 3-5 metrics)
- [KPI] — [result vs. goal] — [Red/Yellow/Green] — Data Storyteller
- ...

ROCK STATUS
- [90-Day Rock] — [On Track / Needs Attention / Off Track] — CEO/Vision Lens
- ...

PANEL FLAGS
- CFO Lens: [concern or suggestion]
- Sales Pipeline: [EARR Loop gap or pipeline concern]
- Presentation Coach: [structural feedback]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — misalignment with 90-Day Rocks, missing financial story, factual errors, no Executive Scorecard
   - `SHOULD-FIX` — weak narrative arc, missing pipeline connection, buried data, no forward-looking Rocks
   - `POLISH` — slide ordering, framing improvements, Red/Yellow/Green consistency

2. **Converge**: Merge duplicates, sort by severity. Presentation Coach has final say on structure.

3. **Present**:
```
STRATEGY PANEL — Review for [Client Name]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED OUTLINE
[Updated deck structure with all fixes applied]
```

4. Ask: "Want me to expand any section, or adjust the panel's recommendations?"

## Rules

- **Use real client context.** Reference actual campaigns, KPI Scorecard metrics, decisions, and stakeholder names from memories. Never use generic filler.
- **EOS alignment is mandatory.** If `configure_mind` returns 90-Day Rocks, the deck MUST report on Rock status and propose next quarter's Rocks. CFO Lens and CEO/Vision Lens enforce this.
- **Executive Scorecard pattern.** Top-level audience gets 3-5 metrics max. Full team gets Pillar-level detail. Data Storyteller and Presentation Coach enforce this.
- **25-2-90-2 cadence.** Every strategy deck should anchor to the 2-Year Vision, report on the current 90-Day Rocks, and propose the next quarter's Rocks. This is the natural CMO rhythm.
- **Scale depth to scope.** A 5-slide internal update gets lighter treatment than a 20-slide board presentation.
- **Experts must be specific.** Not "add ROI data" but "Add a slide showing $47K pipeline from the email campaign at $38 CPL — CFO will ask about this since the Rock target was $40 CPL."
- **One convergence round only.** Strategy is subjective — multiple debate rounds produce diminishing returns. Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
