# /cmo-retro — Sprint/Quarter Retrospective Panel

Run a multi-expert retrospective at the end of a 2-week sprint or 90-day quarter. Structured review of what happened, why, and what's next.

## Usage

- `/cmo-retro sprint retro for Acme`
- `/cmo-retro Q1 retrospective — how did we do?`
- `/cmo-retro what went well this sprint?`
- `/cmo-retro end of sprint review`

## Detect Mode

- **Sprint mode**: prompt references "sprint" or a short time period (2 weeks, this week)
- **Quarter mode**: prompt references "quarter", "Q1-Q4", "90-day", "rock review", or a quarterly time period

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `search_memory` — sprint goals, Rock status, team feedback, decisions made this period, commitments, blockers encountered
2. `get_campaign_history` — campaign performance data for the period
3. `configure_mind` — current 90-Day Rocks, sprint cadence, team structure, EARR Loop phase

If no sprint goals or Rocks are stored, warn:
> "[Client] doesn't have sprint goals or 90-Day Rocks stored. I'll structure the retro, but it will be lighter without tracked goals. Store sprint goals and Rocks for more actionable retrospectives."

## Step 2: Expert Panel (5 fixed)

1. **Rock Scorekeeper** — Tracks 90-Day Rock status: On Track / Needs Attention / Off Track. Cross-references sprint goal outcomes against Rock targets. Uses the CMOx scorecard methodology: "The Rock was 'Generate 200 Qualified Leads at $40 CPL.' We generated 187 at $38 CPL. Volume: Needs Attention. Efficiency: On Track. Net: the Rock is achievable if we increase volume 7% in the final sprint."
2. **Process Optimizer** — Identifies workflow bottlenecks, handoff failures, and process improvements. Looks for patterns across sprints: "Three sprints in a row, content approval has been the blocker. The process needs a Delegation Filter with a 48-hour approval SLA." Checks if the sprint cadence itself is working (are 2-week sprints too short or too long for this team?).
3. **Team Dynamics Reader** — Reads team performance patterns. Who's consistently delivering sprint goals? Who's struggling? Are sprint goals realistic given capacity? "Sarah has hit every sprint goal for 6 weeks — she's ready for more ownership. Tom has missed 3 of 4 — is his workload realistic, or does he need support?" Applies the LMA (Lead, Manage, Accountable) framework.
4. **Data Analyst** — Analyzes KPI Scorecard trends for the period by Pillar (Acquisition, Conversion, SEO, Reputation). Identifies which metrics moved and which didn't. Uses Get BUSI funnel analysis to trace cause and effect. "Acquisition metrics are up 15% but Conversion dropped 8% — you're driving more unqualified traffic. The landing page needs CRO work."
5. **Forward Planner** — Translates retro insights into next sprint/quarter priorities. For sprint retros, proposes next sprint goals aligned to current Rocks. For quarter retros, proposes next quarter's Rocks aligned to the 2-Year Vision. Uses the Priority of Marketing Campaigns framework to sequence actions. "Based on the conversion drop, next sprint should focus on landing page CRO before adding more traffic budget."

## Step 3: Execute (mode-dependent)

### Sprint Mode

1. **Rock Scorekeeper leads** — reports sprint goal outcomes and Rock trajectory.
2. **Other experts contribute** — Process Optimizer identifies blockers, Team Dynamics Reader assesses people, Data Analyst reviews KPI movement, Forward Planner proposes next sprint.
3. **Converge**: Use the CMOx retrospective format: What went well? What needs improvement? What actions? Forward Planner has veto on next sprint priorities.
4. **Present**:
```
RETRO PANEL — Sprint [N] for [Client Name]

SPRINT GOAL OUTCOMES
- [Goal 1] → [Delivered / Missed / Partial] — [detail]
- [Goal 2] → [Delivered / Missed / Partial] — [detail]
— Rock Scorekeeper

ROCK TRAJECTORY
- [Rock 1]: [On Track / Needs Attention / Off Track] — [progress vs. target]
— Rock Scorekeeper

WHAT WENT WELL
- [observation] — [Expert]
- ...

WHAT NEEDS IMPROVEMENT
- [observation] — [Expert]
- ...

ACTIONS FOR NEXT SPRINT
1. [Action] — [owner suggestion] — [tied to which Rock] — Forward Planner
2. ...

KPI MOVEMENT
| Pillar | Trend | Key Change |
|--------|-------|------------|
| Acquisition | [↑/↓/→] | [what moved and why] |
| Conversion | [↑/↓/→] | [what moved and why] |
— Data Analyst

PANEL FLAGS
- Process Optimizer: [recurring blocker to fix]
- Team Dynamics: [capacity or skill concern]
```

### Quarter Mode

1. **Rock Scorekeeper leads** — delivers the full 90-Day Rock scorecard.
2. **Other experts contribute** — deeper analysis across all dimensions: process maturity, team growth, KPI trends across the full quarter, proposed Rocks for next quarter.
3. **Converge**: Full quarter retrospective. Forward Planner has veto on next quarter's Rock proposals.
4. **Present**:
```
RETRO PANEL — Q[N] Retrospective for [Client Name]

90-DAY ROCK SCORECARD
| Rock | Target | Actual | Status |
|------|--------|--------|--------|
| [Rock 1] | [target] | [actual] | [On Track / Achieved / Missed] |
— Rock Scorekeeper

QUARTER IN REVIEW
What Went Well: [top 3 wins]
What Needs Improvement: [top 3 areas]
Key Decisions Made: [significant choices this quarter]

KPI TRENDS (full quarter)
[Pillar-by-Pillar analysis with trend lines]
— Data Analyst

PROCESS MATURITY
- [What processes improved this quarter]
- [What processes are still broken]
— Process Optimizer

TEAM ASSESSMENT
- [Head vs. Hands balance assessment]
- [Capacity and skill observations]
— Team Dynamics Reader

PROPOSED ROCKS — NEXT QUARTER
1. [Rock] — [target metric] — [rationale tied to 2-Year Vision] — Forward Planner
2. ...

PANEL FLAGS
- [Any concerns from experts]
```

5. Ask: "Want to adjust the proposed Rocks, or deep-dive on any area?"

## Rules

- **Psychological safety.** Follow the CMOx retro principle: "No matter what happened, we acknowledge we did the best we could with what we knew." The retro is for learning, not blame.
- **Use real client context.** Reference actual sprint goals, Rock targets, KPI Scorecard data, team names, and decisions from memories. Never use generic filler.
- **Rocks are the anchor.** Every sprint retro must reference how sprint outcomes moved (or didn't move) the 90-Day Rocks. Sprint goals without Rock alignment are busywork.
- **Forward-looking is mandatory.** Every retro MUST produce next sprint/quarter priorities. A retro without forward actions is just complaining.
- **Data over opinion.** Data Analyst must ground observations in actual KPI Scorecard trends. "It felt slow" is not analysis — "Conversion dropped 8% week-over-week" is.
- **Scale depth to period.** Sprint retros are 1-page: goals, outcomes, next. Quarter retros are deeper: full Rock scorecard, Pillar trends, team assessment, next Rocks.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
