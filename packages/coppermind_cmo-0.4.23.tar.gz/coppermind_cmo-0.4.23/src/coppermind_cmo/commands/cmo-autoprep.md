# /cmo-autoprep — Check Calendar And Prep

Silently check for the next client meeting and save a prep brief if there is a confident match.

## Steps

1. Check whether Google Calendar MCP tools are available. If not, say that calendar access is not connected and stop.
2. Look for meetings starting in the next 20 minutes or already in progress.
3. If there is no qualifying meeting, say so briefly and stop.
4. Call `list_minds` once and fuzzy-match event title, attendees, and attendee email domains to client minds.
5. If exactly one client is a confident match:
   - switch to that client
   - call `prep_meeting(save=true)`
   - return a short confirmation with the matched meeting and client
6. After running prep_meeting, also call `log_meeting_event` to record this meeting was detected and prepped. Pass the calendar event ID if available, the mind_id, and match_confidence='confident'.
7. If the match is ambiguous, explain the top options briefly and ask which client to prep.

## Rules
- Prefer attendee names and company email domains over loose title matches.
- Do not create a new client mind from calendar data alone.
- Save the prep brief when you generate it.
- Keep the response short and operational.
