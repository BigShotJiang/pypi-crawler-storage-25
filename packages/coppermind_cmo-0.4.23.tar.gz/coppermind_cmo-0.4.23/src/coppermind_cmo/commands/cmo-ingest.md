# /cmo-ingest — Auto-Ingest Meeting Transcripts

Scan for uningested meetings and pull transcripts from connected sources (Granola, etc.).

## Usage

- `/cmo-ingest` — Check for uningested meetings and ingest them
- `/cmo-ingest last 3 meetings` — Ingest the 3 most recent uningested meetings
- `/cmo-ingest from Granola` — Pull specifically from Granola

## Steps

1. **Find uningested meetings.** Call `get_cross_client_summary` or check for `ingest_suggestion` notifications in recent tool responses. If no meeting_log entries exist, ask the user to log meetings first (via auto-prep hook or manual `log_meeting_event`).

2. **Check Granola availability.** Look for `mcp__granola__search_meetings` in available tools.
   - **If not connected:** Tell them: "Granola isn't connected. Run `claude mcp add granola -- uvx granola-mcp-server` and restart Claude."
   - **If connected:** Proceed.

3. **For each uningested meeting:**
   a. Search Granola for a matching transcript: `mcp__granola__search_meetings` with the meeting title or date range.
   b. If found, fetch the full transcript: `mcp__granola__get_meeting_transcript`.
   c. Confirm which client mind it belongs to. If the meeting is already linked to a mind in meeting_log, use that. Otherwise, match by participant names/company and ask the user to confirm.
   d. Switch to that client mind: `switch_client`.
   e. Store the transcript as a memory. Use `store_memory` with the full transcript — Coppermind's extraction pipeline handles the rest (decisions, commitments, stakeholders, etc.).
   f. Mark as ingested: `mark_transcript_ingested` with the meeting_log_id.
   g. Brief the user: "Ingested [meeting title] → [N] memories stored for [client name]."

4. **If no Granola match found:** Ask the user to paste the transcript manually, then store it and mark as ingested.

5. **Summary:** "Ingested [N] meetings. [M] memories created across [K] clients."

## No Meetings in Log?

If there are no meetings in meeting_log at all, the auto-prep hook may not be configured. Guide the user:
- "No meetings found in the log. The auto-prep hook logs meetings automatically before they start. Check that it's installed with `/cmo-help`."
- "Or log a meeting manually: just tell me about a recent meeting and I'll log it."

## Rules

- Maximum 10 meetings per invocation. If more exist, do the 10 most recent and offer to continue.
- Always confirm the client mind before ingesting. Don't guess.
- Full transcripts go through extraction — don't just dump raw text as a single memory.
- After ingesting, mention any follow-up nags: "You also haven't sent follow-ups for [meeting]. Use /cmo-followup."
