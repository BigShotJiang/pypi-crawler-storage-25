# /cmo-batch — Batch Content Creation

Write content for multiple clients in one session.

## Usage

User says something like:
- "Write this week's social posts for all my clients"
- "Draft newsletters for Acme and 5 Star"
- "Write a blog post for each client about spring topics"

## Steps

1. Parse which clients and what content type.
   - If "all clients": use `list_minds` to get the full list.
   - If specific clients named: use those.
2. For each client:
   a. Switch to the client
   b. Pull brand voice, content themes, and recent memories
   c. Write the requested content using the client's voice and themes
   d. Label it clearly with the client name
3. Present all content together with clear separators:

```
---
ACME CORP — Social Post (Instagram)
[content in Acme's brand voice]
---
5 STAR CHARLESTON — Social Post (Instagram)
[content in 5 Star's brand voice]
---
XSCAPE — Social Post (Instagram)
[content in XSCAPE's brand voice]
---
```

4. Ask: "Want me to adjust any of these, or copy them all to clipboard?"

## Rules
- Each piece of content MUST use that client's brand voice. This is the whole point — don't use a generic voice.
- Reference recent events/memories when relevant ("Just launched our rebrand!" for XSCAPE, "Spring tune-up season is here" for 5 Star).
- Match the content type to the platform (short for social, longer for blogs, professional for newsletters).
- If a client has no brand voice set, mention it: "[Client] doesn't have brand voice configured yet. Want me to set it up?"
- Don't show the switch_client responses. Just present the final content.
