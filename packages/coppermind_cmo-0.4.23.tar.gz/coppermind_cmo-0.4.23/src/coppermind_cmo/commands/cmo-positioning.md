# /cmo-positioning — Positioning & Brand Strategy Panel

Run a multi-expert positioning strategy session using the Positioning Protocol: avatars, competitive mapping, promise, unique mechanism, proof, and messaging.

## Usage

- `/cmo-positioning develop positioning for Acme`
- `/cmo-positioning review this positioning: [paste content]`
- `/cmo-positioning refine our value proposition`
- `/cmo-positioning CARE exercise for Acme's target audience`

## Detect Mode

- **Build mode**: prompt contains "develop", "build", "create", "define", or references positioning work without pasted content
- **Review mode**: prompt contains "review", "critique", "improve", "refine", or pasted positioning content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — existing positioning, messaging pillars, tone, vocabulary
2. `search_memory` — CARE avatar data, competitive intel, testimonials, customer feedback, pain points from MSS/Triage Call
3. `get_campaign_history` — which messages and campaigns performed (proof of what resonates)
4. `configure_mind` — company info, industry, product/service details

If no brand voice or avatar data exists, that's expected — this command is often used to CREATE positioning from scratch.

## Step 2: Expert Panel (5 fixed)

1. **Avatar Specialist** — CARE framework expert (Compassionate Avatar Realization Exercise). Builds the avatar across four dimensions: Head (negative thoughts, fears, frustrations, urgency, pain), Heart (dreams, longings, basic needs), Home (demographics, lifestyle, media consumption, hangouts), Description (named biography synthesizing all three). Maps the avatar to awareness levels: don't know they have a problem → know the problem → know solutions exist → know YOUR solution. "Your messaging targets CTOs but your actual buyers are VP Marketing — different Head, different Heart, different copy."
2. **Competitive Mapper** — Plots the client on a 2-axis Positioning Map against competitors. Identifies white space using the three evaluation lenses: Operational Efficiency (price), Product Leadership (market position), Customer Intimacy (care quality). "Every competitor leads with 'affordable' — there's white space in 'premium + fast.' You can own that quadrant."
3. **Promise Crafter** — Executes the Positioning Protocol: distill 10-20 features → associated benefits → 1-3 core benefits for the main avatar → the Promise (transformation statement). The Promise must be specific, believable, and differentiated. "Your current promise is 'we help businesses grow' — that's everyone. What specific transformation do you deliver in 90 days?"
4. **Proof Collector** — Identifies and organizes irrefutable proof: testimonials, case studies, data points, awards, media mentions, before/after results. Checks that every claim in the positioning has supporting proof. "You claim 'fastest turnaround in the industry' but have zero proof on the website. Where's the data? We need 3 case studies minimum."
5. **Messaging Architect** — Synthesizes Promise + Proof + Unique Mechanism (actual, process-based, or transubstantiated) into 5+ headlines and messaging pillars. Tests messaging against each awareness level. Ensures messaging works across the EARR Loop — different messaging for Educate vs. Acquire vs. Retain vs. Refer. "This headline works for product-aware prospects but you need top-of-funnel messaging for the unaware segment."

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Avatar Specialist leads** — builds the CARE avatar(s), establishing who the positioning speaks to.
2. **Other experts contribute** — Competitive Mapper plots the positioning landscape, Promise Crafter distills the transformation statement, Proof Collector inventories available proof, Messaging Architect synthesizes into headlines and pillars.
3. **Converge**: Merge into a complete Positioning Protocol document. Avatar Specialist has veto on audience fit; Promise Crafter has veto on clarity.
4. **Present**:
```
POSITIONING PANEL — [Client Name]

CARE AVATAR
Name: [avatar name]
Head: [fears, pain, urgency — what keeps them up at night]
Heart: [dreams, needs — what they really want]
Home: [demographics, lifestyle, media, where they hang out]
Awareness Level: [unaware / problem-aware / solution-aware / product-aware]
— Avatar Specialist

POSITIONING MAP
[2-axis description: what X axis measures, what Y axis measures]
- [Client]: [position]
- [Competitor 1]: [position]
- [Competitor 2]: [position]
White Space: [opportunity]
— Competitive Mapper

POSITIONING PROTOCOL
Promise: [the transformation statement]
Unique Mechanism: [what makes your approach different — actual/process/transubstantiated]
Core Benefits: [1-3 benefits for the main avatar]
Proof Points:
- [proof 1] — Proof Collector
- [proof 2] — Proof Collector
— Promise Crafter

MESSAGING PILLARS
1. [Pillar]: [key message] — [which awareness level it targets]
2. ...

HEADLINES (5+)
1. [headline] — [awareness level] — Messaging Architect
2. ...

PANEL FLAGS
- Avatar Specialist: [audience gap or assumption to validate]
- Proof Collector: [missing proof that needs to be gathered]
- Competitive Mapper: [positioning risk or opportunity]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — avatar mismatch with actual buyers, promise too generic, zero proof for claims
   - `SHOULD-FIX` — incomplete awareness-level coverage, missing competitive differentiation, weak unique mechanism
   - `POLISH` — headline refinement, messaging consistency, tone alignment

2. **Converge**: Merge duplicates, sort by severity. Promise Crafter has final say on positioning clarity.

3. **Present**: Standard findings format with revised Positioning Protocol.

4. Ask: "Want me to develop messaging for a specific channel, or refine the avatar further?"

## Rules

- **Use real client context.** Reference actual customer data, testimonials, competitive intel, and campaign performance from memories. Never invent customer quotes or fabricate proof.
- **CARE is the foundation.** No positioning work happens without the avatar. Avatar Specialist must complete Head/Heart/Home before other experts can meaningfully contribute.
- **The Promise must be specific.** "We help businesses grow" is not a promise. "We generate 200+ qualified leads per quarter for B2B manufacturers" is. Promise Crafter enforces this ruthlessly.
- **Proof must be irrefutable.** Testimonials, case studies, and data points — not "we believe" or "we strive." If proof doesn't exist, Proof Collector flags what needs to be gathered.
- **Awareness levels matter.** Messaging Architect must ensure messaging covers at least problem-aware and product-aware levels. Top-of-funnel and bottom-of-funnel require different language.
- **Test against the Positioning Map.** Every positioning claim must differentiate from competitors on the map. If two companies occupy the same quadrant, the positioning isn't working.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
