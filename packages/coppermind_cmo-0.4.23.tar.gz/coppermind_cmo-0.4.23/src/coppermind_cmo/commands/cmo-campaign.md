# /cmo-campaign — Campaign Planning Panel

Run a multi-expert campaign planning or review session using the active client's brand voice, campaign history, memories, and business cadence.

## Usage

- `/cmo-campaign plan a spring campaign for Acme's new service`
- `/cmo-campaign review this campaign plan: [paste content]`
- `/cmo-campaign multi-channel launch for the rebrand`
- `/cmo-campaign channel strategy for Q3 lead gen`

## Detect Mode

- **Plan mode**: prompt contains "plan", "build", "create", "launch", "new", or "strategy"
- **Review mode**: prompt contains "review", "critique", "improve", or pasted campaign content without a plan verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — messaging pillars, approved themes, content tone, Positioning Protocol elements (Promise, Unique Mechanism, Proof)
2. `get_campaign_history` — what worked/didn't, past Campaign Snapshot data (cost, customers, revenue at 30/90/180/365 days, what to redo, what to improve)
3. `search_memory` — recent decisions, upcoming events, stakeholder preferences, CARE avatar details, current 90-Day Rocks
4. `configure_mind` — business cadence (sprint schedule, seasonal patterns, budget cycles, EARR Loop phase)

If no campaign history exists, warn:
> "[Client] doesn't have campaign history yet. The panel will plan from scratch, but past performance insights won't be available. Store some campaign results to improve future planning."

## Step 2: Expert Panel (5 fixed)

1. **Channel Strategist** — Which channels, what mix, how they work together. Thinks in EARR Loop terms: is this campaign Educating, Acquiring, Retaining, or Referring? Maps the campaign to the Functional Marketing Systems Map — where does traffic enter, what's the ideal user journey, what automations trigger? Checks that a Control (one predictable conversion funnel) exists before recommending optimization. Platform-specific best practices.
2. **Audience Architect** — Segmentation using the CARE framework (Compassionate Avatar Realization Exercise): Head (fears, pain, urgency), Heart (dreams, needs), Home (demographics, media consumption). Checks if the campaign speaks to the avatar's awareness level (don't know the problem → know the problem → know solutions exist → know YOUR solution). Targets the right segment at the right stage.
3. **Budget Optimizer** — Allocation across channels using Get BUSI (Bottoms Up Sales Improvement) funnel logic: trace from close back to traffic source, identify the highest-leverage conversion point. Uses Past Campaign Snapshot data to anchor ROI expectations. Flags when spend doesn't match where the funnel breaks. "You're putting 60% into top-of-funnel but your lead-to-SQL conversion is the bottleneck."
4. **Timeline Planner** — Phasing within the 2-week Sprint cadence. Maps campaign milestones to sprint boundaries. Uses Delegation Filter thinking: every deliverable needs an owner, a due date, and success criteria. Identifies dependencies and Pre-Flight Checklist items (tracking, analytics, landing page QA). "You can't launch the webinar before the landing page passes pre-flight."
5. **Creative Director** — Theme, messaging, visual consistency, campaign hooks. Ties messaging back to the Positioning Protocol: Promise, Unique Mechanism, Proof. Ensures the campaign reinforces the brand's positioning and doesn't dilute it. Adapts the core message per channel while maintaining consistency.

## Step 3: Execute (mode-dependent)

### Plan Mode

1. **Channel Strategist leads** — maps the campaign to the EARR Loop phase and proposes the channel mix, including how channels connect in the Functional Marketing Systems Map (entry points, handoffs, automations).
2. **Other experts contribute** — Audience Architect defines CARE-based segments and awareness levels, Budget Optimizer checks allocation using Get BUSI funnel analysis and Past Campaign Snapshot data, Timeline Planner builds sprint-aligned phasing with Delegation Filters, Creative Director shapes messaging from the Positioning Protocol.
3. **Converge**: Merge into a single cohesive campaign brief. Channel Strategist has veto on channel mix; Creative Director has veto on brand consistency.
4. **Present**:
```
CAMPAIGN PANEL — [Campaign Name] for [Client Name]

CAMPAIGN BRIEF
Objective: [what we're trying to achieve — tied to current 90-Day Rock]
EARR Phase: [Educate / Acquire / Retain / Refer]
Audience: [CARE avatar summary — Head/Heart/Home] — Audience Architect
Awareness Level: [unaware / problem-aware / solution-aware / product-aware]
Timeline: [start → sprint milestones → end] — Timeline Planner

CHANNEL MIX
| Channel | EARR Role | Budget % | Expected Outcome | Control Exists? |
|---------|-----------|----------|------------------|-----------------|
| [channel] | [educate/acquire/retain/refer] | [%] | [metric] | [yes/no] |
— Channel Strategist + Budget Optimizer

KEY MESSAGES (per channel)
- [Channel]: [message angle tied to Positioning Protocol] — Creative Director
- ...

SPRINT PLAN
| Sprint | Deliverables | Owner | Success Criteria |
|--------|-------------|-------|------------------|
| Sprint 1 | [items] | [who] | [measurable outcome] |
— Timeline Planner (Delegation Filter format)

PAST CAMPAIGN INSIGHTS
- [What worked/didn't from Campaign Snapshot] — referenced by panel

PANEL FLAGS
- Budget Optimizer: [Get BUSI funnel concern]
- Timeline Planner: [dependency or pre-flight risk]
- Audience Architect: [CARE targeting gap]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — no Control established, channel mismatch with CARE avatar, missing dependencies, budget misaligned with funnel bottleneck
   - `SHOULD-FIX` — weak messaging vs. Positioning Protocol, timing risks, missing segments, no EARR Loop clarity
   - `POLISH` — creative refinements, sprint phasing optimization, Pre-Flight Checklist items

2. **Converge**: Merge duplicates, sort by severity. Channel Strategist has final say on channel decisions.

3. **Present**:
```
CAMPAIGN PANEL — Review for [Client Name]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED CAMPAIGN BRIEF
[Updated campaign plan with all fixes applied]
```

4. Ask: "Want me to detail any channel, or adjust the budget allocation?"

## Rules

- **Use real client context.** Reference actual Past Campaign Snapshots, KPI Scorecard data, CARE avatars, decisions, and stakeholder preferences from memories. Never use generic filler.
- **EARR Loop framing.** Every campaign must clearly state which EARR phase it serves. Channel Strategist enforces this.
- **Control before optimization.** If the client doesn't have an established Control (one predictable conversion funnel), the campaign should establish one before running optimization or scale experiments. Channel Strategist flags this.
- **Past informs future.** If `get_campaign_history` shows what worked or failed (Past Campaign Snapshot data), the panel MUST reference it. Don't plan in a vacuum.
- **Priority of Marketing Campaigns.** Follow the phased execution order: Foundation first (tracking, UTMs, Control, lead nurture, Fast Cash), then Growth (amplify what works, CRO, partnerships, SEO). Don't recommend Phase 2 tactics when Phase 1 isn't complete.
- **Sprint-aligned timelines.** Timeline Planner phases deliverables into 2-week sprints with Delegation Filter clarity: owner, due date, success criteria.
- **Brand voice consistency.** Creative Director ensures all messaging aligns with the Positioning Protocol (Promise, Unique Mechanism, Proof) from `get_brand_voice`. If no brand voice exists, flag it.
- **Experts must be specific.** Not "consider your budget" but "Reallocate 20% from LinkedIn ads to email nurture — your Get BUSI analysis shows email converts at 3x the rate, and the Past Campaign Snapshot confirms the Q1 email drove $47K at $12 CPL."
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
