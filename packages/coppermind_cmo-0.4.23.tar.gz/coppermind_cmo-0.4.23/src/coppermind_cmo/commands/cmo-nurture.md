# /cmo-nurture — Email Nurture Sequence Panel

Run a multi-expert email nurture sequence creation or review session using the active client's brand voice, avatar data, campaign history, and product/service context.

## Usage

- `/cmo-nurture build a lead nurture sequence for Acme`
- `/cmo-nurture review this email sequence: [paste content]`
- `/cmo-nurture 30-day drip campaign for new leads`
- `/cmo-nurture welcome series for webinar signups`

## Detect Mode

- **Build mode**: prompt contains "build", "create", "write", "draft", or references a new sequence without pasted content
- **Review mode**: prompt contains "review", "critique", "improve", or pasted email content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — tone, vocabulary, messaging pillars, Positioning Protocol (Promise, Unique Mechanism, Proof)
2. `search_memory` — CARE avatar data (Head/Heart/Home), common objections, testimonials, product/service details, competitive differentiators
3. `get_campaign_history` — existing email performance (open rates, CTR, conversion), Past Campaign Snapshot data
4. `configure_mind` — product/service info, sales process, funnel structure

If no avatar data exists, warn:
> "[Client] doesn't have CARE avatar data stored. I'll build the sequence with general assumptions, but it won't be as targeted. Run `/cmo-positioning` first to develop the avatar."

## Step 2: Expert Panel (5 fixed)

1. **Sequence Architect** — Structures the overall nurture flow following the CMOx Priority of Marketing Campaigns framework. Progression: 30-day starter sequence → extend to 90 days → extend to 180+ days. Maps emails to awareness levels: Email 1-2 education (problem-aware), Email 3 proof (solution-aware), Email 4 objection handling, Email 5 hard push (product-aware). Determines optimal send frequency (every 3-4 days minimum to avoid spam flags). "Start with 5 emails over 30 days. Once that Control converts, extend to 90 days with 12 emails."
2. **Subject Line Optimizer** — Crafts subject lines optimized for open rates. Tests approaches: curiosity-based, direct-benefit, personal, question-based, urgency. "Your open rates drop 40% after email 3 — the subject lines switch from curiosity to salesy. The transition needs to be gradual, not a cliff."
3. **Conversion Copywriter** — Writes persuasive email body copy tied to the CARE avatar's Head (pain, fears) and Heart (dreams, needs). Each email has ONE clear CTA. Uses the Positioning Protocol: Promise as the through-line, Unique Mechanism as the differentiator, Proof as the closer. "This email talks about features for 300 words before mentioning the reader's problem. Flip it — lead with the pain, then present the solution."
4. **Deliverability Guardian** — Checks for spam triggers, sending frequency, list hygiene, authentication (SPF/DKIM/DMARC). Monitors the CMOx email deliverability best practices. "You're sending 3 emails in 48 hours — that'll get flagged. Space them to every 3-4 days minimum. Also, plain text emails outperform HTML templates for nurture."
5. **Analytics Coach** — Sets up per-email tracking: open rate, CTR, conversion, unsubscribe rate. Establishes benchmarks by email position. Identifies which emails perform and which need replacement. "Email 4 has a 2% CTR vs. your 8% sequence average — that's the weak link. Rewrite or replace it. Also set up split testing on email 2 since it's your highest-traffic email."

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Sequence Architect leads** — maps the sequence structure, timing, and awareness-level progression.
2. **Other experts contribute** — Subject Line Optimizer crafts subject lines, Conversion Copywriter writes email briefs, Deliverability Guardian sets sending rules, Analytics Coach defines per-email KPI targets.
3. **Converge**: Merge into a complete sequence plan. Sequence Architect has veto on structure; Deliverability Guardian has veto on sending frequency.
4. **Present**:
```
NURTURE PANEL — [Sequence Name] for [Client Name]

SEQUENCE OVERVIEW
Target: [CARE avatar summary — who receives this sequence]
Trigger: [what action enrolls someone — opt-in, webinar signup, etc.]
Duration: [30/60/90/180 days]
Total Emails: [N]
Send Frequency: [every X days]
Goal: [what conversion action ends the sequence]
— Sequence Architect

EMAIL MAP
| # | Day | Subject Line | Purpose | Awareness Level | CTA |
|---|-----|-------------|---------|-----------------|-----|
| 1 | 0 | [subject] | Welcome + education | Problem-aware | [CTA] |
| 2 | 3 | [subject] | Deeper education | Problem-aware | [CTA] |
| 3 | 7 | [subject] | Proof / case study | Solution-aware | [CTA] |
| 4 | 11 | [subject] | Objection handling | Solution-aware | [CTA] |
| 5 | 14 | [subject] | Hard push + offer | Product-aware | [CTA] |
— Sequence Architect + Subject Line Optimizer

EMAIL BRIEFS
Email 1: [2-3 sentence brief — key message, emotional hook, CTA]
Email 2: [brief]
...
— Conversion Copywriter

PER-EMAIL KPI TARGETS
| Email | Open Rate Target | CTR Target | Unsub Ceiling |
|-------|-----------------|------------|---------------|
| 1 | [%] | [%] | [%] |
— Analytics Coach

DELIVERABILITY CHECKLIST
□ SPF/DKIM/DMARC configured
□ Sending domain reputation checked
□ Plain text preferred over heavy HTML
□ Minimum 3-day spacing between emails
□ Unsubscribe link in every email
□ List hygiene (remove 90-day inactive)
— Deliverability Guardian

PANEL FLAGS
- Subject Line Optimizer: [subject line risk or pattern]
- Deliverability Guardian: [deliverability concern]
- Analytics Coach: [measurement gap]
```

### Review Mode

Standard findings format (MUST-FIX / SHOULD-FIX / POLISH) with revised sequence.

## Rules

- **Use real client context.** Reference actual CARE avatar data, testimonials, product/service details, and competitive differentiators from memories. Never use generic filler in email copy.
- **Awareness level progression is mandatory.** Every sequence must move the reader through awareness levels: problem-aware → solution-aware → product-aware. Sequence Architect enforces this.
- **One CTA per email.** Conversion Copywriter must ensure each email has exactly one clear call-to-action. Multiple CTAs dilute conversion.
- **Start with 30 days, then extend.** Don't build a 180-day sequence from scratch. Build 30 days, establish the Control, then extend to 90, then 180. This is the CMOx phased approach.
- **Plain text over HTML.** For nurture sequences, plain-text emails outperform heavy HTML templates. Deliverability Guardian enforces this.
- **CARE avatar drives copy.** Every email must speak to the avatar's Head (pain/fears) or Heart (dreams/needs). Features without emotional connection don't convert.
- **Proof is the multiplier.** At least one email in every sequence must be dedicated to irrefutable proof: testimonials, case studies, data points.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
