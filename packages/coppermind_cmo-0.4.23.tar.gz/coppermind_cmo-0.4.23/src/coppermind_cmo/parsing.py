"""Shared input validation and parsing helpers.

Pure functions — no DB access, no side effects, no logging.
Callers decide fallback policy (log warning, return error, ignore).
"""

from __future__ import annotations

from datetime import date, datetime, timezone


# ---------- SQL LIKE escaping ----------

def escape_like(s: str) -> str:
    """Escape SQL LIKE special characters (\\, %, _) for safe use in LIKE patterns."""
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


# ---------- memory_type normalization ----------

def normalize_memory_type(raw: str, valid_types: set[str] | None = None) -> str | None:
    """Normalize a memory_type string.

    Returns the cleaned type if valid, or None if invalid.
    Caller decides fallback policy.

    Cleaning: strip whitespace, lowercase, strip trailing punctuation,
    replace spaces with underscores.
    """
    if valid_types is None:
        from coppermind_cmo.memory_types import VALID_MEMORY_TYPES
        valid_types = VALID_MEMORY_TYPES
    cleaned = raw.strip().lower().rstrip(".,;:!?").replace(" ", "_")
    if cleaned in valid_types:
        return cleaned
    return None


# ---------- Date parsing ----------

_DATE_FORMATS = ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y")


def parse_date(s: str, *, strict_iso: bool = False) -> date | None:
    """Parse a date string. Returns date or None if unparseable.

    strict_iso=True: only accepts YYYY-MM-DD format.
    strict_iso=False: tries ISO, then US date formats.
    """
    if not s or not isinstance(s, str):
        return None
    s = s.strip()
    if strict_iso:
        try:
            return datetime.strptime(s, "%Y-%m-%d").date()
        except (ValueError, TypeError):
            return None
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except (ValueError, TypeError):
            continue
    return None


def parse_datetime(s: str, *, require_tz: bool = False, coerce_utc: bool = False) -> datetime | None:
    """Parse an ISO-8601 datetime string. Returns datetime or None.

    require_tz=True: returns None if parsed datetime has no tzinfo.
    coerce_utc=True: if no tzinfo, assumes UTC. require_tz takes precedence.
    """
    if not s or not isinstance(s, str):
        return None
    try:
        dt = datetime.fromisoformat(s)
    except (ValueError, TypeError):
        return None
    if require_tz and dt.tzinfo is None:
        return None
    if coerce_utc and dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# ---------- CSV cell sanitization ----------

_CSV_INJECTION_CHARS = set("=+-@\t\r")
_MAX_CELL_CHARS = 500


def sanitize_csv_cell(value: str, max_chars: int = _MAX_CELL_CHARS) -> str:
    """Strip CSV injection characters from the front and enforce length limit."""
    cleaned = value.lstrip()
    while cleaned and cleaned[0] in _CSV_INJECTION_CHARS:
        cleaned = cleaned[1:].lstrip()
    return cleaned[:max_chars]
