"""Database connection pool and query helpers.

Adapted from old Coppermind lib/database.py. Simplified for CMO use case:
- Single config source (COPPERMIND_PG_* env vars via Config)
- psycopg2 ThreadedConnectionPool
"""

# RETRY ARCHITECTURE
# Two retry layers protect DB operations:
# 1. connection() retries once on pool errors (rebuilds the pool)
# 2. resilient_call() retries 3x on transient errors (OperationalError, etc.)
# Combined worst case: 6 pool-get attempts (3 outer x 2 inner).
# The outer layer adds up to 0.6s backoff (0.2s + 0.4s).

from __future__ import annotations

import os
import threading
from contextlib import contextmanager
from typing import Any

import psycopg2
from psycopg2.extensions import STATUS_READY
from psycopg2.pool import PoolError, ThreadedConnectionPool

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.resilience import resilient_call

logger = ToolLogger("db")


class TenantIsolationError(RuntimeError):
    """Raised when RLS isolation cannot be applied in hosted mode.

    In hosted mode (customer_id is set), queries MUST NOT proceed without
    tenant isolation. This exception prevents unscoped data access.
    """
    pass

def _pool_config():
    """Read pool config from env with validation."""
    pool_min = int(os.environ.get("COPPERMIND_POOL_MIN", "1"))
    pool_max = int(os.environ.get("COPPERMIND_POOL_MAX", "3"))
    if pool_min < 1:
        raise ValueError(f"COPPERMIND_POOL_MIN must be >= 1, got {pool_min}")
    if pool_max < pool_min:
        raise ValueError(f"COPPERMIND_POOL_MAX ({pool_max}) must be >= COPPERMIND_POOL_MIN ({pool_min})")
    return pool_min, pool_max


POOL_MIN, POOL_MAX = _pool_config()

# Retry config for DB operations: 3 attempts with 0.2s exponential backoff, 15s wall-clock cap.
# Supabase PgBouncer typically reconnects in under 100ms, so 0.2s base is generous.
# All four query methods use this. Change here to adjust globally.
_DB_RETRY = dict(service_name="database", max_attempts=3, backoff_base=0.2, max_elapsed=15.0)

_rls_degraded_warned = False  # warn once per process — suppress repeated log spam


class Database:
    """PostgreSQL connection pool wrapper."""

    def __init__(self, config: Config):
        self._config = config
        self._pool: ThreadedConnectionPool | None = None
        self._pool_lock = threading.Lock()

    def _ensure_pool(self):
        if self._pool is not None:
            return
        with self._pool_lock:
            if self._pool is None:
                ssl_kwargs = {}
                if self._config.api_key:
                    ca_path = os.path.join(
                        os.path.dirname(__file__), "supabase-ca.pem"
                    )
                    ssl_kwargs = {
                        "sslmode": "verify-ca",
                        "sslrootcert": ca_path,
                    }
                self._pool = ThreadedConnectionPool(
                    POOL_MIN, POOL_MAX,
                    host=self._config.pg_host,
                    port=self._config.pg_port,
                    dbname=self._config.pg_db,
                    user=self._config.pg_user,
                    password=self._config.pg_password,
                    connect_timeout=10,
                    options="-c statement_timeout=30000",  # 30s query timeout
                    keepalives=1,
                    keepalives_idle=30,
                    keepalives_interval=10,
                    keepalives_count=5,
                    **ssl_kwargs,
                )

    def _apply_isolation(self, conn) -> bool:
        """Apply per-transaction RLS via SET LOCAL ROLE + SET LOCAL app.customer_id.

        SET LOCAL is transaction-scoped — both settings expire on COMMIT/ROLLBACK,
        so pooled connections are never left in a contaminated state.
        No-op in self-hosted mode (customer_id is empty).
        Returns False on failure — caller (connection()) raises TenantIsolationError
        in hosted mode to fail closed. Warns once per process for diagnostics.
        """
        global _rls_degraded_warned
        customer_id = getattr(self._config, 'customer_id', '')
        if not customer_id:
            return False
        try:
            with conn.cursor() as cur:
                # SET LOCAL app.customer_id enables RLS policies that filter on
                # current_setting('app.customer_id', true). The ROLE SET is
                # skipped — Supabase pooled connections don't support SET ROLE
                # and the GUC variable alone is sufficient for RLS enforcement.
                cur.execute("SET LOCAL app.customer_id = %s", [customer_id])
            return True
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            if not _rls_degraded_warned:
                _rls_degraded_warned = True
                logger.warn(
                    "RLS isolation not applied — coppermind_app role missing or migration pending",
                    error=str(e),
                )
            return False

    @contextmanager
    def connection(self):
        """Borrow a connection from the pool. Auto-returned on exit.

        On pool or connection errors, rebuilds the pool once and retries.
        """
        for attempt in range(2):
            try:
                self._ensure_pool()
                conn = self._pool.getconn()
            except (PoolError, psycopg2.OperationalError) as e:
                if attempt == 0:
                    logger.warn(f"Pool error, rebuilding: {e}")
                    with self._pool_lock:
                        if self._pool is not None:
                            try:
                                self._pool.closeall()
                            except Exception:
                                pass
                            self._pool = None
                    continue
                raise
            break
        _force_close = False
        try:
            isolated = self._apply_isolation(conn)
            # Fail closed: if customer_id is set (hosted mode) but RLS could
            # not be applied, refuse to proceed — never allow unscoped queries.
            if not isolated and self._config.customer_id:
                raise TenantIsolationError(
                    "RLS isolation required but could not be applied. "
                    "Refusing to execute queries without tenant isolation."
                )
            yield conn
        except Exception:
            try:
                conn.rollback()
            except Exception:
                _force_close = True  # rollback failed — connection is dead
            else:
                # Rollback succeeded, but check if connection is in a usable state
                try:
                    if conn.status != STATUS_READY:
                        _force_close = True
                except Exception:
                    _force_close = True
            raise
        finally:
            if conn.closed or _force_close:
                self._pool.putconn(conn, close=True)
            else:
                self._pool.putconn(conn)

    def fetch_all(self, sql: str, params: list[Any] | None = None) -> list[tuple]:
        # Closure wraps the full operation so resilient_call can retry it on transient errors
        def _do():
            with self.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    result = cur.fetchall()
                conn.commit()
                return result
        return resilient_call(_do, **_DB_RETRY)

    def fetch_one(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        def _do():
            with self.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    result = cur.fetchone()
                conn.commit()
                return result
        return resilient_call(_do, **_DB_RETRY)

    def execute(self, sql: str, params: list[Any] | None = None):
        """Execute a SQL statement with automatic retry on transient errors.

        WARNING: Retries are enabled. Callers MUST use idempotent SQL for write
        operations (e.g., ON CONFLICT DO NOTHING, soft-delete with WHERE guard).
        If the DB executes the write but the connection drops before ack,
        the write will be retried.
        """
        def _do():
            with self.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                conn.commit()
        return resilient_call(_do, **_DB_RETRY)

    def execute_returning(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        """Execute a SQL statement and return one row, with automatic retry.

        WARNING: Retries are enabled. Callers MUST use idempotent SQL for write
        operations (e.g., INSERT ... ON CONFLICT, UPDATE ... WHERE guard).
        If the DB executes the write but the connection drops before ack,
        the write will be retried.
        """
        def _do():
            with self.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    row = cur.fetchone()
                conn.commit()
                return row
        return resilient_call(_do, **_DB_RETRY)

    def close(self):
        with self._pool_lock:
            if self._pool is not None:
                self._pool.closeall()
                self._pool = None
