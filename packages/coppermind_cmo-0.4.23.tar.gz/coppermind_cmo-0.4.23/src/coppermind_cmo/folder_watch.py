"""Folder watcher daemon for Coppermind CMO.

Monitors configured directories for new or modified documents and
automatically ingests them into the appropriate client minds.

Uses polling (os.walk + mtime comparison) on each scan cycle — the
same proven pattern as the session watcher.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.ingest import IngestEngine
from coppermind_cmo.ingest_folder import (
    AUTO_MAX_FILE_SIZE,
    SUPPORTED_EXTENSIONS,
    _file_sha256,
    _check_file_already_ingested,
    _record_file_hash,
    _is_hidden,
    safe_extract,
    collect_files,
    SKIP_DIRS,
)
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("folder_watch")

# Max files to process per scan cycle
MAX_FILES_PER_CYCLE = 50

# Max consecutive failures before marking a file as "poison"
MAX_FAILURES = 3

# Default debounce interval (seconds) between file size checks
DEFAULT_DEBOUNCE_SECONDS = 15
MIN_DEBOUNCE_SECONDS = 5

# Status file location
_STATUS_DIR = Path.home() / ".coppermind"
_STATUS_FILE = _STATUS_DIR / "folder_watch_status.json"


def check_path_overlap(
    new_path: str,
    existing_paths: dict[str, tuple[str, str]],
    exclude_mind_id: str | None = None,
) -> str | None:
    """Check if new_path overlaps (parent/child) with any existing watched path.

    Args:
        new_path: Canonicalized path to check.
        existing_paths: {path: (mind_id, mind_name)} of all watched paths.
        exclude_mind_id: Skip paths belonging to this mind (for self-updates).

    Returns:
        Error message string if overlap found, None if clean.
    """
    new_resolved = os.path.realpath(new_path)
    for existing, (mid, mname) in existing_paths.items():
        if exclude_mind_id and mid == exclude_mind_id:
            continue
        existing_resolved = os.path.realpath(existing)
        if new_resolved == existing_resolved:
            # Exact duplicate — warn but allow
            continue
        # Check containment (parent/child)
        if new_resolved.startswith(existing_resolved + os.sep):
            return f"This path overlaps with {mname}'s watched folder: {existing}"
        if existing_resolved.startswith(new_resolved + os.sep):
            return f"This path overlaps with {mname}'s watched folder: {existing}"
    return None


class FolderWatcher:
    """Watches directories for new/modified documents and auto-ingests them.

    The watcher is testable:
    - ``_load_watched_paths()`` queries the DB for watched paths
    - ``scan_once()`` walks directories and returns changed file Paths
    - ``process_files()`` extracts text and runs IngestEngine
    - ``run()`` is the main loop tying everything together
    """

    def __init__(
        self,
        db: Database,
        config: Config,
        customer_id: str = "",
    ):
        self.db = db
        self.config = config
        self.customer_id = customer_id

        # {absolute_path_str: mtime} — tracks last-seen mtime per file
        self._mtime_cache: dict[str, float] = {}

        # {mind_id: (mind_name, [list_of_paths])} — watched paths per mind
        self._watched: dict[str, tuple[str, list[str]]] = {}

        # {absolute_path_str: failure_count} — poison file tracking
        self._failure_counts: dict[str, int] = {}

        # Directories to exclude (e.g. Coppermind/ output folders to prevent self-ingestion)
        self._excluded_dirs: set[str] = set()

        # {absolute_path_str: (size, timestamp)} — debounce stability tracking
        self._pending_stability: dict[str, tuple[int, float]] = {}

        # Debounce interval from env or default
        try:
            debounce = int(os.environ.get(
                "COPPERMIND_WATCH_DEBOUNCE_SECONDS",
                str(DEFAULT_DEBOUNCE_SECONDS),
            ))
        except (ValueError, TypeError):
            debounce = DEFAULT_DEBOUNCE_SECONDS
        self.debounce_seconds = max(MIN_DEBOUNCE_SECONDS, debounce)

    # ------------------------------------------------------------------
    # Path loading
    # ------------------------------------------------------------------

    def _load_watched_paths(self) -> dict[str, tuple[str, list[str]]]:
        """Query DB for current local_path + watch_paths per mind.

        Returns {mind_id: (mind_name, [path, ...])}.
        """
        rows = self.db.fetch_all(
            "SELECT id, name, local_path, watch_paths FROM client_minds "
            "WHERE archived_at IS NULL AND customer_id = %s",
            [self.customer_id],
        )
        result: dict[str, tuple[str, list[str]]] = {}
        for row in rows or []:
            mind_id = str(row[0])
            mind_name = row[1]
            paths: list[str] = []
            if row[2]:  # local_path
                paths.append(row[2])
                # Exclude Coppermind/ output folder to prevent self-ingestion
                self._excluded_dirs.add(os.path.join(row[2], "Coppermind"))
            if row[3]:  # watch_paths (text[])
                paths.extend(row[3])
            if paths:
                result[mind_id] = (mind_name, paths)
        return result

    def _refresh_watched_paths(self):
        """Reload watched paths from DB, log changes."""
        old_paths = set()
        for _, (_, ps) in self._watched.items():
            old_paths.update(ps)

        self._watched = self._load_watched_paths()

        new_paths = set()
        for _, (_, ps) in self._watched.items():
            new_paths.update(ps)

        added = new_paths - old_paths
        removed = old_paths - new_paths
        if added or removed:
            logger.info(
                "Watch paths updated",
                paths_added=len(added),
                paths_removed=len(removed),
                total_paths=len(new_paths),
            )

    # ------------------------------------------------------------------
    # File scanning
    # ------------------------------------------------------------------

    def scan_once(self) -> list[tuple[str, str, Path]]:
        """Walk all watched directories, return list of (mind_id, mind_name, path) for new/modified files.

        Skips:
        - Symlinks (files and directories)
        - Files > AUTO_MAX_FILE_SIZE
        - Hidden files/dirs
        - Unsupported extensions
        - Unchanged files (same mtime)
        - Poison files (too many failures)
        """
        results: list[tuple[str, str, Path]] = []

        for mind_id, (mind_name, watch_dirs) in self._watched.items():
            for watch_dir in watch_dirs:
                root = Path(watch_dir)
                if not root.is_dir():
                    continue

                for dirpath, dirnames, filenames in os.walk(root):
                    # Prune hidden dirs, skip dirs, symlinked dirs,
                    # and Coppermind output folders (avoid self-ingestion)
                    dirnames[:] = [
                        d for d in dirnames
                        if not _is_hidden(d) and d not in SKIP_DIRS
                        and not (Path(dirpath) / d).is_symlink()
                        and os.path.join(dirpath, d) not in self._excluded_dirs
                    ]

                    for fname in filenames:
                        if _is_hidden(fname):
                            continue
                        fpath = Path(dirpath) / fname
                        if fpath.is_symlink():
                            logger.debug(
                                "File skipped",
                                path=str(fpath),
                                reason="symlink",
                            )
                            continue
                        if fpath.suffix.lower() not in SUPPORTED_EXTENSIONS:
                            continue

                        try:
                            stat = fpath.stat()
                        except OSError:
                            continue

                        if stat.st_size > AUTO_MAX_FILE_SIZE:
                            logger.debug(
                                "File skipped",
                                path=str(fpath),
                                reason="too_large",
                                size_bytes=stat.st_size,
                            )
                            continue

                        path_str = str(fpath)

                        # Poison file check
                        if self._failure_counts.get(path_str, 0) >= MAX_FAILURES:
                            logger.debug(
                                "File skipped",
                                path=path_str,
                                reason="poison_file",
                            )
                            continue

                        # Mtime change detection
                        cached_mtime = self._mtime_cache.get(path_str)
                        if cached_mtime is not None and stat.st_mtime == cached_mtime:
                            continue  # Unchanged

                        event_type = "new" if cached_mtime is None else "modified"
                        logger.info(
                            "File detected",
                            path=path_str,
                            size_bytes=stat.st_size,
                            mind_id=mind_id,
                            event_type=event_type,
                        )

                        results.append((mind_id, mind_name, fpath))

                        if len(results) >= MAX_FILES_PER_CYCLE:
                            return results

        return results

    # ------------------------------------------------------------------
    # Stability (debounce) check
    # ------------------------------------------------------------------

    def check_stability(self, fpath: Path) -> bool:
        """Check if a file's size is stable (debounce for cloud sync).

        Returns True if the file size has been unchanged across two
        readings separated by the debounce interval.
        """
        path_str = str(fpath)
        try:
            current_size = fpath.stat().st_size
        except OSError:
            # File disappeared
            self._pending_stability.pop(path_str, None)
            return False

        prev = self._pending_stability.get(path_str)
        now = time.time()

        if prev is None:
            # First reading — record and return not-stable
            self._pending_stability[path_str] = (current_size, now)
            return False

        prev_size, prev_time = prev
        if current_size != prev_size:
            # Size changed — reset timer
            self._pending_stability[path_str] = (current_size, now)
            return False

        if (now - prev_time) < self.debounce_seconds:
            # Same size but not enough time elapsed
            return False

        # Stable — two consecutive readings match with enough time between
        self._pending_stability.pop(path_str, None)
        return True

    # ------------------------------------------------------------------
    # File processing
    # ------------------------------------------------------------------

    def process_files(
        self,
        files: list[tuple[str, str, Path]],
    ) -> dict[str, int]:
        """Extract text and ingest via IngestEngine.

        Returns summary dict: {processed, skipped, errors}.
        """
        counts = {"processed": 0, "skipped": 0, "errors": 0}

        for mind_id, mind_name, fpath in files:
            path_str = str(fpath)

            # Extract text using the safe wrapper
            logger.info(
                "Extraction started",
                path=path_str,
                extension=fpath.suffix.lower(),
                mind_id=mind_id,
            )

            start_time = time.time()
            text = safe_extract(fpath)
            if text is None:
                counts["skipped"] += 1
                logger.debug(
                    "File skipped",
                    path=path_str,
                    reason="extraction_failed_or_empty",
                )
                continue

            # SHA-256 dedup check
            try:
                file_hash = _file_sha256(fpath)
            except OSError as e:
                counts["errors"] += 1
                self._record_failure(path_str, mind_id)
                logger.error(
                    "Extraction error",
                    path=path_str,
                    mind_id=mind_id,
                    error=str(e),
                    retry_count=self._failure_counts.get(path_str, 0),
                )
                continue

            # Check if already ingested (content hasn't changed)
            if _check_file_already_ingested(self.db, mind_id, file_hash, ingest_type="folder_watch"):
                # Update mtime cache even if content is same
                try:
                    self._mtime_cache[path_str] = fpath.stat().st_mtime
                except OSError:
                    pass
                counts["skipped"] += 1
                logger.debug(
                    "File skipped",
                    path=path_str,
                    reason="unchanged",
                )
                continue

            # Determine if this is a re-ingestion (modified file)
            is_modified = self._mtime_cache.get(path_str) is not None

            # Ingest via engine
            try:
                active_mind = (mind_id, mind_name)
                engine = IngestEngine(
                    self.db, self.config, active_mind,
                    auto_ingest=True,
                    memory_source_type="folder_watch",
                )
                result = engine.process_source(
                    source_type="folder_watch",
                    source_ref=f"file:{path_str}",
                    content=text,
                    supersede_old=is_modified,
                )

                # Record file hash for dedup
                _record_file_hash(self.db, mind_id, path_str, file_hash, ingest_type="folder_watch")

                duration = time.time() - start_time
                logger.info(
                    "Extraction completed",
                    path=path_str,
                    mind_id=mind_id,
                    memories_extracted=result.get("new", 0) + result.get("updated", 0),
                    duration_seconds=round(duration, 2),
                )
                counts["processed"] += 1

                # Update mtime cache
                try:
                    self._mtime_cache[path_str] = fpath.stat().st_mtime
                except OSError:
                    pass

            except Exception as e:
                counts["errors"] += 1
                self._record_failure(path_str, mind_id)
                logger.error(
                    "Extraction error",
                    path=path_str,
                    mind_id=mind_id,
                    error=str(e),
                    retry_count=self._failure_counts.get(path_str, 0),
                )

        return counts

    def _record_failure(self, path_str: str, mind_id: str):
        """Increment failure count for a file and log poison status."""
        self._failure_counts[path_str] = self._failure_counts.get(path_str, 0) + 1
        if self._failure_counts[path_str] >= MAX_FAILURES:
            logger.warn(
                "Poison file quarantined",
                path=path_str,
                mind_id=mind_id,
                total_failures=self._failure_counts[path_str],
            )

    # ------------------------------------------------------------------
    # Status reporting
    # ------------------------------------------------------------------

    def write_status(self, cycle_counts: dict[str, int] | None = None):
        """Write a JSON status file for /cmo-connect status to read."""
        try:
            _STATUS_DIR.mkdir(parents=True, exist_ok=True)
            total_paths = sum(len(ps) for _, (_, ps) in self._watched.items())
            status = {
                "timestamp": time.time(),
                "paths_watched": total_paths,
                "minds_watched": len(self._watched),
                "poison_files": len(
                    {k for k, v in self._failure_counts.items() if v >= MAX_FAILURES}
                ),
                "cached_files": len(self._mtime_cache),
            }
            if cycle_counts:
                status["last_cycle"] = cycle_counts
            _STATUS_FILE.write_text(json.dumps(status, indent=2))
        except Exception as e:
            logger.warn("Failed to write status file", error=str(e))

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self, poll_interval: float = 60.0):
        """Main polling loop. Runs until the process is killed."""
        logger.info("Folder watcher starting", debounce_seconds=self.debounce_seconds)

        while True:
            try:
                self._refresh_watched_paths()

                if not self._watched:
                    time.sleep(poll_interval)
                    continue

                start = time.time()
                candidates = self.scan_once()

                # Filter by stability check
                stable_files: list[tuple[str, str, Path]] = []
                for mind_id, mind_name, fpath in candidates:
                    if self.check_stability(fpath):
                        stable_files.append((mind_id, mind_name, fpath))

                cycle_counts: dict[str, int] = {
                    "files_scanned": len(candidates),
                    "files_processed": 0,
                    "files_skipped": 0,
                    "errors": 0,
                }

                if stable_files:
                    result = self.process_files(stable_files)
                    cycle_counts["files_processed"] = result["processed"]
                    cycle_counts["files_skipped"] = result["skipped"]
                    cycle_counts["errors"] = result["errors"]

                duration = time.time() - start
                total_paths = sum(len(ps) for _, (_, ps) in self._watched.items())
                logger.info(
                    "Scan cycle summary",
                    paths_watched=total_paths,
                    files_scanned=cycle_counts["files_scanned"],
                    files_processed=cycle_counts["files_processed"],
                    files_skipped=cycle_counts["files_skipped"],
                    errors=cycle_counts["errors"],
                    duration_seconds=round(duration, 2),
                )

                cycle_counts["duration_seconds"] = round(duration, 2)
                self.write_status(cycle_counts)

            except Exception as e:
                logger.error("Folder watcher cycle failed", error=str(e))

            time.sleep(poll_interval)


def main():
    """Entry point for the folder watcher daemon.

    Launched by server.py as: python -m coppermind_cmo.folder_watch --interval 60
    """
    import argparse
    import logging

    logging.basicConfig(
        level=logging.INFO,
        format="COPPERMIND-CMO: %(asctime)s %(name)s %(levelname)s %(message)s",
    )

    parser = argparse.ArgumentParser(description="Coppermind folder watcher")
    parser.add_argument(
        "--interval", type=int, default=60,
        help="Poll interval in seconds (default: 60)",
    )
    args = parser.parse_args()

    config = Config()

    if config.api_key:
        from coppermind_cmo.server import _provision_from_gateway
        _provision_from_gateway(config)

    db = Database(config)

    try:
        db.fetch_one("SELECT 1")
    except Exception as e:
        logger.error(f"Cannot connect to database: {e}")
        raise SystemExit(1)

    watcher = FolderWatcher(db, config, customer_id=config.customer_id or "")
    logger.info("Starting folder watcher daemon")
    watcher.run(poll_interval=args.interval)


if __name__ == "__main__":
    main()
