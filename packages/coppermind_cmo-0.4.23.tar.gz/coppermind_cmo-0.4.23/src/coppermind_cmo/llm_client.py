"""LLM client for classification and summarization.

Routes through the Coppermind gateway \u2192 Claude API.
"""

from coppermind_cmo.config import Config
from coppermind_cmo.gateway_http import gateway_post
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.memory_types import (
    VALID_MEMORY_TYPES,
    CLASSIFY_PROMPT,
    SUMMARIZE_PROMPT,
)

logger = ToolLogger("llm_client")


# ---------------------------------------------------------------------------
# Gateway provider \u2014 delegates to shared gateway_http module
# ---------------------------------------------------------------------------

def call_gateway_llm(
    endpoint: str,
    body: dict,
    config: Config,
    timeout: float = 30,
    session_id: str = "",
) -> dict | None:
    """Call a gateway LLM endpoint. Returns parsed JSON response or None on failure."""
    return gateway_post(endpoint, body, config, timeout=timeout, session_id=session_id)


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def call_llm(
    prompt: str,
    config: Config,
    use_synthesis_model: bool = False,
) -> str | None:
    """Call the gateway LLM. Returns response text or None on failure."""
    result = call_gateway_llm("synthesize", {"prompt": prompt}, config)
    if result is not None:
        return result.get("text")
    return None


# ---------------------------------------------------------------------------
# High-level functions
# ---------------------------------------------------------------------------

def classify_memory_type(content: str, config: Config) -> tuple[str, str]:
    """Classify content into a memory type.

    Returns (memory_type, classified_by) where classified_by is
    'llm' or 'fallback'.
    """
    from coppermind_cmo.parsing import normalize_memory_type
    result = call_gateway_llm("classify", {"content": content}, config)
    if result is None:
        return ("fact", "fallback")
    memory_type = result.get("memory_type", "fact")
    cleaned = normalize_memory_type(memory_type)
    if cleaned is not None:
        return (cleaned, "llm")
    return ("fact", "llm")


def summarize(content: str, config: Config) -> str:
    """Generate a one-line summary. Falls back to truncation if gateway is down."""
    result = call_gateway_llm("summarize", {"content": content}, config)
    if result is not None:
        summary = result.get("summary", "")
        return summary.strip()[:200]
    return content[:100]
