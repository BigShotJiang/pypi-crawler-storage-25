"""Entry point: python -m coppermind_cmo runs the MCP server."""

import sys

from coppermind_cmo import __version__

if __name__ == "__main__":
    if "--version" in sys.argv or "-V" in sys.argv:
        print(f"coppermind-cmo {__version__}")
        raise SystemExit(0)
    from coppermind_cmo.server import main
    main()
