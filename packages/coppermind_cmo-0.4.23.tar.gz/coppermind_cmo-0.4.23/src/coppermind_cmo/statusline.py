"""Cross-platform status line for Claude Code.

Usage: python -m coppermind_cmo.statusline

Reads ~/.coppermind/active-client.json and prints a one-line summary.
Works on all platforms (Mac, Linux, Windows).
"""

import json
import os
import sys


def main():
    state_file = os.path.join(os.path.expanduser("~"), ".coppermind", "active-client.json")
    if not os.path.isfile(state_file):
        return
    try:
        with open(state_file) as f:
            d = json.load(f)
        parts = [d["client_name"]]
        if d.get("cadence"):
            parts.append(d["cadence"])
        parts.append(f"{d['memory_count']} memories")
        print(" | ".join(parts))
    except Exception:
        pass


if __name__ == "__main__":
    main()
