"""Shared HTTP client for the Coppermind gateway.

Both llm_client.py and embedding_client.py need to make authenticated
HTTP requests to the gateway with session tracking.  This module
consolidates the duplicated header-building and request logic.

Includes retry with exponential backoff for transient failures:
- Retries on: ConnectionError, TimeoutError, HTTP 503, HTTP 429
- Does NOT retry on: HTTP 401, 403, 400, 404
- Max 3 attempts with backoff: 1s, 2s, 4s
- Respects Retry-After header for 429 responses
"""

import time

import httpx
from httpx import ConnectError, TimeoutException, RemoteProtocolError, HTTPStatusError

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("gateway_http")

# Status codes that should be retried
_RETRYABLE_STATUS_CODES = {429, 502, 503, 504}

# Status codes that should NOT be retried (client errors, auth failures)
_NON_RETRYABLE_STATUS_CODES = {400, 401, 403, 404, 422}

# Default retry settings
_MAX_ATTEMPTS = 3
_BACKOFF_BASE = 1.0  # seconds: 1s, 2s, 4s


def gateway_headers(config: Config, session_id: str = "") -> dict:
    """Build headers for gateway requests including auth and session tracking."""
    return {
        "Authorization": f"Bearer {config.api_key}",
        "X-Session-Id": session_id,
    }


def _should_retry(exc: Exception) -> bool:
    """Determine if an exception is retryable."""
    # Connection and timeout errors are always retryable
    if isinstance(exc, (ConnectError, TimeoutException, RemoteProtocolError,
                        ConnectionError, TimeoutError)):
        return True

    # HTTP status errors: check the status code
    if isinstance(exc, HTTPStatusError):
        return exc.response.status_code in _RETRYABLE_STATUS_CODES

    return False


def _get_retry_delay(attempt: int, exc: Exception) -> float:
    """Calculate retry delay, respecting Retry-After header for 429s."""
    base_delay = _BACKOFF_BASE * (2 ** attempt)

    # For 429 responses, respect Retry-After header
    if isinstance(exc, HTTPStatusError) and exc.response.status_code == 429:
        retry_after = exc.response.headers.get("Retry-After")
        if retry_after:
            try:
                return max(base_delay, float(retry_after))
            except (ValueError, TypeError):
                pass

    return base_delay


def gateway_post(
    endpoint: str,
    body: dict,
    config: Config,
    timeout: float = 30,
    session_id: str = "",
) -> dict | None:
    """POST to a gateway endpoint. Returns parsed JSON or None on failure.

    Retries transient failures (connection errors, timeouts, 503, 429) up to
    3 times with exponential backoff. Non-retryable errors (401, 403, 400, 404)
    fail immediately.

    Args:
        endpoint: Path segment after /v1/ (e.g. "embed", "synthesize", "classify").
        body: JSON request body.
        config: Server config with gateway_url and api_key.
        timeout: Request timeout in seconds.
        session_id: Session ID for tracking (empty string if unavailable).
    """
    url = f"{config.gateway_url.rstrip('/')}/v1/{endpoint}"

    for attempt in range(_MAX_ATTEMPTS):
        try:
            resp = httpx.post(
                url,
                json=body,
                headers=gateway_headers(config, session_id=session_id),
                timeout=timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            is_last_attempt = attempt == _MAX_ATTEMPTS - 1

            if not is_last_attempt and _should_retry(e):
                delay = _get_retry_delay(attempt, e)
                logger.info(
                    f"Gateway POST {endpoint} failed, retrying in {delay:.1f}s "
                    f"(attempt {attempt + 1}/{_MAX_ATTEMPTS})",
                    service="gateway",
                    endpoint=endpoint,
                    attempt=attempt + 1,
                    error=str(e),
                    backoff_seconds=delay,
                )
                time.sleep(delay)
                continue

            logger.warn(
                f"Gateway request failed ({endpoint}): {e}",
                service="gateway",
                endpoint=endpoint,
                attempt=attempt + 1,
            )
            return None

    return None  # unreachable, but satisfies type checker


def gateway_get(
    endpoint: str,
    config: Config,
    timeout: float = 5,
    session_id: str = "",
) -> httpx.Response | None:
    """GET from a gateway endpoint. Returns the raw Response or None on failure.

    Retries transient connection failures up to 3 times with exponential backoff.
    """
    url = f"{config.gateway_url.rstrip('/')}/v1/{endpoint}"

    for attempt in range(_MAX_ATTEMPTS):
        try:
            resp = httpx.get(
                url,
                headers=gateway_headers(config, session_id=session_id),
                timeout=timeout,
            )
            return resp
        except Exception as e:
            is_last_attempt = attempt == _MAX_ATTEMPTS - 1

            if not is_last_attempt and _should_retry(e):
                delay = _get_retry_delay(attempt, e)
                logger.info(
                    f"Gateway GET {endpoint} failed, retrying in {delay:.1f}s "
                    f"(attempt {attempt + 1}/{_MAX_ATTEMPTS})",
                    service="gateway",
                    endpoint=endpoint,
                    attempt=attempt + 1,
                    error=str(e),
                    backoff_seconds=delay,
                )
                time.sleep(delay)
                continue

            return None

    return None  # unreachable, but satisfies type checker
