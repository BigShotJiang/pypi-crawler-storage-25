"""Configuration from COPPERMIND_* environment variables.

Hosted only: COPPERMIND_API_KEY is required. All database connection
params are provisioned via the gateway at startup.

All numeric env vars are validated as integers at parse time (not on first use).
"""

import os


def _int_env(name: str, default: int) -> int:
    val = os.environ.get(name)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        raise ValueError(f"{name} must be an integer, got: {val!r}")


class Config:
    """Parsed configuration from environment variables."""

    def __init__(self):
        # --- Customer identity (set during provisioning) ---
        self.customer_id: str = os.environ.get("COPPERMIND_CUSTOMER_ID", "")

        # --- Hosted mode ---
        self.api_key: str = os.environ.get("COPPERMIND_API_KEY", "")
        self.gateway_url: str = os.environ.get(
            "COPPERMIND_GATEWAY_URL",
            "https://api.coppermind.app",
        )

        # --- PostgreSQL (populated by gateway provisioning at startup) ---
        self.pg_host: str = os.environ.get("COPPERMIND_PG_HOST", "")
        self.pg_port: int = _int_env("COPPERMIND_PG_PORT", 5432)
        self.pg_db: str = os.environ.get("COPPERMIND_PG_DB", "")
        self.pg_user: str = os.environ.get("COPPERMIND_PG_USER", "")
        self.pg_password: str = os.environ.get("COPPERMIND_PG_PASSWORD", "")

        # --- Claude model configuration ---
        self.claude_fast_model: str = os.environ.get(
            "COPPERMIND_CLAUDE_FAST_MODEL", "claude-haiku-4-5-20251001"
        )
        self.claude_synthesis_model: str = os.environ.get(
            "COPPERMIND_CLAUDE_SYNTHESIS_MODEL", "claude-sonnet-4-20250514"
        )

        # --- Hosted-only provider settings ---
        self.llm_provider: str = "gateway"
        self.embedding_provider: str = "gateway"
        self.embedding_dims: int = 512
        self.max_prompt_chars: int = 40000

        # --- Chunking parameters ---
        self.chunk_overlap_chars: int = _int_env("COPPERMIND_CHUNK_OVERLAP_CHARS", 200)
        self.min_chunk_chars: int = _int_env("COPPERMIND_MIN_CHUNK_CHARS", 500)
        self.max_chunk_chars: int = _int_env("COPPERMIND_MAX_CHUNK_CHARS", 4000)


from dataclasses import dataclass, field


@dataclass
class ServerConfig:
    """Config fetched from the gateway on startup."""
    min_client_version: str = ""
    upgrade_message: str = ""
    latest_version: str = ""
    upgrade_urgency: str = "none"  # "none" | "recommended" | "required"
    changelog_url: str = ""
    prompts: dict = field(default_factory=dict)
    fetched: bool = False

_server_config: ServerConfig | None = None


def get_server_config() -> ServerConfig:
    """Return cached server config. Call fetch_server_config() first."""
    global _server_config
    if _server_config is None:
        _server_config = ServerConfig()
    return _server_config


def fetch_server_config(config: 'Config') -> ServerConfig:
    """Fetch config from gateway. Cache result. Returns defaults on failure."""
    global _server_config
    import httpx
    try:
        resp = httpx.get(
            f"{config.gateway_url.rstrip('/')}/v1/config",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=5.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            _server_config = ServerConfig(
                min_client_version=data.get("min_client_version", ""),
                upgrade_message=data.get("upgrade_message", ""),
                latest_version=data.get("latest_version", ""),
                upgrade_urgency=data.get("upgrade_urgency", "none"),
                changelog_url=data.get("changelog_url", ""),
                prompts=data.get("prompts", {}) if isinstance(data.get("prompts"), dict) else {},
                fetched=True,
            )
        else:
            _server_config = ServerConfig()
    except Exception:
        _server_config = ServerConfig()

    return _server_config
