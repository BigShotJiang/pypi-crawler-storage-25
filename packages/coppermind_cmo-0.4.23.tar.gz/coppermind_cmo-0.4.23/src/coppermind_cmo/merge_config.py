"""Shared module for merging/removing coppermind-cmo from Claude Desktop config.

Used by installers as: python -m coppermind_cmo.merge_config --merge CONFIG CMD ARGS_JSON API_KEY
                    or: python -m coppermind_cmo.merge_config --remove CONFIG

Falls back to inline heredoc in installers if this module is not importable.
"""

import json
import os
import sys
import tempfile


def merge(config_path: str, command: str, args_json: str, api_key: str) -> None:
    """Add or update the coppermind-cmo entry in a Claude Desktop config file.

    Uses atomic temp-file-then-rename to avoid partial writes.
    """
    config: dict = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    config.setdefault("mcpServers", {})
    config["mcpServers"]["coppermind-cmo"] = {
        "command": command,
        "args": json.loads(args_json),
        "env": {"COPPERMIND_API_KEY": api_key},
    }

    _atomic_write(config_path, config)


def remove(config_path: str) -> None:
    """Remove the coppermind-cmo entry from a Claude Desktop config file.

    Uses atomic temp-file-then-rename to avoid partial writes.
    """
    if not os.path.exists(config_path):
        return

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
    except (json.JSONDecodeError, OSError):
        return  # corrupt config, nothing to remove

    servers = config.get("mcpServers", {})
    if "coppermind-cmo" not in servers:
        return

    del servers["coppermind-cmo"]
    _atomic_write(config_path, config)


def _atomic_write(config_path: str, config: dict) -> None:
    """Write JSON config atomically via temp file + os.replace."""
    tmp_dir = os.path.dirname(os.path.abspath(config_path))
    fd, tmp_path = tempfile.mkstemp(dir=tmp_dir, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        os.replace(tmp_path, config_path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def main() -> None:
    """CLI entry point for installer usage."""
    if len(sys.argv) < 3:
        print("Usage: python -m coppermind_cmo.merge_config --merge CONFIG CMD ARGS_JSON API_KEY", file=sys.stderr)
        print("       python -m coppermind_cmo.merge_config --remove CONFIG", file=sys.stderr)
        sys.exit(1)

    action = sys.argv[1]

    if action == "--merge":
        if len(sys.argv) != 6:
            print("--merge requires: CONFIG COMMAND ARGS_JSON API_KEY", file=sys.stderr)
            sys.exit(1)
        merge(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        print("ok")
    elif action == "--remove":
        if len(sys.argv) != 3:
            print("--remove requires: CONFIG", file=sys.stderr)
            sys.exit(1)
        remove(sys.argv[2])
        print("removed")
    else:
        print(f"Unknown action: {action}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
