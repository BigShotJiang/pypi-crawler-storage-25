"""Tests for auto-capture of shared URLs."""

from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.memories import (
    _extract_urls, _extract_url_domain, _tag_urls_post_store, _quick_note,
)


class TestExtractUrls:
    def test_basic_url(self):
        urls = _extract_urls("Check this: https://example.com/page")
        assert urls == ["https://example.com/page"]

    def test_multiple_urls(self):
        text = "Links: https://a.com and https://b.com/path"
        urls = _extract_urls(text)
        assert len(urls) == 2
        assert "https://a.com" in urls
        assert "https://b.com/path" in urls

    def test_no_urls(self):
        assert _extract_urls("Just plain text") == []

    def test_empty_text(self):
        assert _extract_urls("") == []
        assert _extract_urls(None) == []

    def test_skips_code_blocks(self):
        text = "Normal https://keep.com\n```\nhttps://skip.com\n```"
        urls = _extract_urls(text)
        assert "https://keep.com" in urls
        assert "https://skip.com" not in urls

    def test_skips_inline_code(self):
        text = "Use `https://skip.com` but also https://keep.com"
        urls = _extract_urls(text)
        assert "https://keep.com" in urls
        assert "https://skip.com" not in urls

    def test_skips_localhost(self):
        urls = _extract_urls("http://localhost:3000/api")
        assert urls == []

    def test_skips_coppermind_gateway(self):
        urls = _extract_urls("https://api.coppermind.app/v1/config")
        assert urls == []

    def test_strips_trailing_punctuation(self):
        urls = _extract_urls("See https://example.com/page.")
        assert urls == ["https://example.com/page"]

        urls = _extract_urls("Link: https://example.com/page,")
        assert urls == ["https://example.com/page"]

    def test_deduplicates(self):
        text = "https://same.com and again https://same.com"
        urls = _extract_urls(text)
        assert len(urls) == 1

    def test_truncates_long_urls(self):
        long_url = "https://example.com/" + "a" * 600
        urls = _extract_urls(f"Link: {long_url}")
        assert len(urls) == 1
        assert len(urls[0]) == 500

    def test_real_world_drive_url(self):
        text = "Here's the brand folder: https://drive.google.com/drive/folders/1abc2def3ghi"
        urls = _extract_urls(text)
        assert len(urls) == 1
        assert "drive.google.com" in urls[0]

    def test_http_and_https(self):
        text = "http://old.com and https://new.com"
        urls = _extract_urls(text)
        assert len(urls) == 2


class TestTagUrlsPostStore:
    """Tests for the _tag_urls_post_store helper."""

    def test_tags_memory_with_urls(self):
        db = MagicMock()
        result = _tag_urls_post_store(
            "Check https://example.com/doc", [], "mem-1", "mind-1", db
        )
        assert result["urls_captured"] == 1
        assert "https://example.com/doc" in result["urls"]
        db.execute.assert_called_once()
        args = db.execute.call_args[0]
        assert ["url", "shared_resource"] == args[1][0]
        assert args[1][1] == "mem-1"
        assert args[1][2] == "mind-1"

    def test_returns_empty_when_no_urls(self):
        db = MagicMock()
        result = _tag_urls_post_store("No links here", [], "mem-1", "mind-1", db)
        assert result == {}
        db.execute.assert_not_called()

    def test_skips_when_url_tag_already_present(self):
        db = MagicMock()
        result = _tag_urls_post_store(
            "https://example.com", ["url", "existing"], "mem-1", "mind-1", db
        )
        assert result == {}
        db.execute.assert_not_called()

    def test_handles_db_error_gracefully(self):
        db = MagicMock()
        db.execute.side_effect = Exception("DB down")
        result = _tag_urls_post_store(
            "https://example.com", [], "mem-1", "mind-1", db
        )
        assert result == {}

    def test_returns_empty_for_empty_content(self):
        db = MagicMock()
        result = _tag_urls_post_store("", [], "mem-1", "mind-1", db)
        assert result == {}
        db.execute.assert_not_called()

    def test_returns_max_5_urls(self):
        urls = " ".join(f"https://site{i}.com" for i in range(10))
        db = MagicMock()
        result = _tag_urls_post_store(urls, [], "mem-1", "mind-1", db)
        assert result["urls_captured"] == 10
        assert len(result["urls"]) == 5


class TestQuickNoteUrlCapture:
    """Tests that quick_note auto-tags URLs."""

    def _make_config(self):
        config = MagicMock()
        config.embedding_provider = "local"
        config.embedding_url = "http://localhost:8400"
        config.embedding_dims = 384
        config.llm_provider = "ollama"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return config

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_tags_urls(self, mock_emb):
        db = MagicMock()
        config = self._make_config()
        db.execute_returning.return_value = ("note-url-1",)
        result = _quick_note(
            "Brand folder: https://drive.google.com/drive/folders/abc123",
            db, config, ("mind-1", "Acme"),
        )
        assert result["memory_id"] == "note-url-1"
        assert result["urls_captured"] == 1
        assert "drive.google.com" in result["urls"][0]

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_no_urls_no_extra_keys(self, mock_emb):
        db = MagicMock()
        config = self._make_config()
        db.execute_returning.return_value = ("note-plain",)
        result = _quick_note("Just a plain note", db, config, ("mind-1", "Acme"))
        assert result["memory_id"] == "note-plain"
        assert "urls_captured" not in result

    @patch("coppermind_cmo.tools.memories.MemoryStore")
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_skips_url_tagging_when_queued_locally(self, mock_emb, mock_store_cls):
        db = MagicMock()
        config = self._make_config()
        mock_store_cls.return_value.store.return_value = {
            "id": "pending", "status": "queued_locally",
            "message": "Saved locally — will sync when DB is back",
        }
        result = _quick_note(
            "Brand folder: https://drive.google.com/drive/folders/abc123",
            db, config, ("mind-1", "Acme"),
        )
        assert result["memory_id"] == "pending"
        assert "urls_captured" not in result
        # db.execute should NOT be called for URL tagging
        db.execute.assert_not_called()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_multiple_urls(self, mock_emb):
        db = MagicMock()
        config = self._make_config()
        db.execute_returning.return_value = ("note-multi",)
        result = _quick_note(
            "Links: https://a.com and https://b.com/page",
            db, config, ("mind-1", "Acme"),
        )
        assert result["urls_captured"] == 2


class TestExtractUrlDomain:
    def test_simple_domain(self):
        assert _extract_url_domain("https://example.com/path") == "example.com"

    def test_subdomain(self):
        assert _extract_url_domain("https://drive.google.com/folder") == "drive.google.com"

    def test_invalid_url(self):
        assert _extract_url_domain("not-a-url") == ""
