"""Tests for database resilience: retry wrapping, pool config, and connection management.

Note: psycopg2 error classification tests live in test_resilience.py (TestClassifyPsycopg2Errors).
"""

from unittest.mock import MagicMock, patch, call

import psycopg2
import pytest
from psycopg2.pool import PoolError

from coppermind_cmo.resilience import classify_error


# ---------------------------------------------------------------------------
# DB query method retry behavior
# ---------------------------------------------------------------------------

class TestDbRetryOnTransientError:
    """Verify fetch_all/fetch_one/execute/execute_returning retry via resilient_call."""

    def _make_db_with_cursor_side_effects(self, side_effects):
        """Create a Database with a mock pool where cursor.execute has given side_effects.

        side_effects is passed directly to MagicMock.side_effect on cursor.execute.
        For example: [psycopg2.OperationalError("fail"), None] means first call raises,
        second call succeeds (returns None, the default for execute).
        """
        from coppermind_cmo.db import Database
        config = MagicMock()
        config.customer_id = ""
        db = Database(config)

        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = side_effects
        mock_cursor.fetchall.return_value = [("row1",)]
        mock_cursor.fetchone.return_value = ("row1",)
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        return db, mock_pool, mock_conn, mock_cursor

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_fetch_all_retries_on_operational_error(self, mock_sleep):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [psycopg2.OperationalError("connection reset"), None]  # fail once, then succeed
        )
        result = db.fetch_all("SELECT 1")
        assert result == [("row1",)]
        mock_sleep.assert_called_once()
        assert cursor.execute.call_count == 2

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_fetch_one_retries_on_operational_error(self, mock_sleep):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [psycopg2.OperationalError("connection reset"), None]
        )
        result = db.fetch_one("SELECT 1")
        assert result == ("row1",)
        mock_sleep.assert_called_once()
        assert cursor.execute.call_count == 2

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_execute_retries_on_operational_error(self, mock_sleep):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [psycopg2.OperationalError("connection reset"), None]
        )
        db.execute("UPDATE t SET x = 1")
        mock_sleep.assert_called_once()
        assert cursor.execute.call_count == 2

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_execute_returning_retries_on_operational_error(self, mock_sleep):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [psycopg2.OperationalError("connection reset"), None]
        )
        result = db.execute_returning("INSERT INTO t RETURNING id")
        assert result == ("row1",)
        mock_sleep.assert_called_once()
        assert cursor.execute.call_count == 2

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_retry_gives_up_after_3_attempts(self, mock_sleep):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [
                psycopg2.OperationalError("fail 1"),
                psycopg2.OperationalError("fail 2"),
                psycopg2.OperationalError("fail 3"),
            ]
        )
        with pytest.raises(psycopg2.OperationalError):
            db.fetch_all("SELECT 1")
        # 2 sleeps (between attempt 1-2 and 2-3), fails on 3rd
        assert mock_sleep.call_count == 2
        assert cursor.execute.call_count == 3

    def test_no_retry_on_programming_error(self):
        db, pool, conn, cursor = self._make_db_with_cursor_side_effects(
            [psycopg2.ProgrammingError("syntax error at or near 'SELEC'")]
        )
        with pytest.raises(psycopg2.ProgrammingError):
            db.fetch_all("SELEC 1")
        # Only one attempt, no retry
        assert cursor.execute.call_count == 1


# ---------------------------------------------------------------------------
# Pool config from environment
# ---------------------------------------------------------------------------

class TestPoolConfig:
    def test_pool_config_defaults(self):
        from coppermind_cmo.db import _pool_config
        import os
        env = os.environ.copy()
        env.pop("COPPERMIND_POOL_MIN", None)
        env.pop("COPPERMIND_POOL_MAX", None)
        with patch.dict("os.environ", env, clear=True):
            pmin, pmax = _pool_config()
            assert pmin == 1
            assert pmax == 3

    def test_pool_config_from_env(self):
        from coppermind_cmo.db import _pool_config
        with patch.dict("os.environ", {
            "COPPERMIND_POOL_MIN": "2",
            "COPPERMIND_POOL_MAX": "5",
        }):
            pmin, pmax = _pool_config()
            assert pmin == 2
            assert pmax == 5

    def test_pool_config_rejects_min_zero(self):
        from coppermind_cmo.db import _pool_config
        with patch.dict("os.environ", {
            "COPPERMIND_POOL_MIN": "0",
            "COPPERMIND_POOL_MAX": "3",
        }):
            with pytest.raises(ValueError, match="COPPERMIND_POOL_MIN must be >= 1"):
                _pool_config()

    def test_pool_config_rejects_max_less_than_min(self):
        from coppermind_cmo.db import _pool_config
        with patch.dict("os.environ", {
            "COPPERMIND_POOL_MIN": "5",
            "COPPERMIND_POOL_MAX": "2",
        }):
            with pytest.raises(ValueError, match="COPPERMIND_POOL_MAX"):
                _pool_config()

    def test_pool_config_rejects_negative_min(self):
        from coppermind_cmo.db import _pool_config
        with patch.dict("os.environ", {
            "COPPERMIND_POOL_MIN": "-1",
            "COPPERMIND_POOL_MAX": "3",
        }):
            with pytest.raises(ValueError, match="COPPERMIND_POOL_MIN must be >= 1"):
                _pool_config()


# ---------------------------------------------------------------------------
# Pool rebuild closes old connections (B2 fix)
# ---------------------------------------------------------------------------

class TestPoolRebuildClosesConnections:
    def test_pool_rebuild_calls_closeall(self):
        """When pool rebuild is triggered, the old pool's closeall() must be called."""
        from coppermind_cmo.db import Database
        config = MagicMock()
        config.customer_id = ""
        db = Database(config)

        # Set up old pool that fails on getconn
        old_pool = MagicMock()
        old_pool.getconn.side_effect = PoolError("connection pool exhausted")
        db._pool = old_pool

        # Set up new pool that succeeds
        new_pool = MagicMock()
        new_conn = MagicMock()
        new_conn.closed = 0
        new_pool.getconn.return_value = new_conn

        with patch("coppermind_cmo.db.ThreadedConnectionPool", return_value=new_pool):
            config.api_key = ""
            config.pg_host = "localhost"
            config.pg_port = 5432
            config.pg_db = "test"
            config.pg_user = "user"
            config.pg_password = "pass"

            with db.connection() as conn:
                assert conn is new_conn

        # The old pool should have been closed
        old_pool.closeall.assert_called_once()
