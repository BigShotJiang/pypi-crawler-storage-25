"""Tests for sensitivity auto-detection."""
import pytest
from coppermind_cmo.memory_types import classify_sensitivity, SENSITIVE_PATTERNS


class TestClassifySensitivity:
    # Financial
    def test_dollar_amount(self):
        assert classify_sensitivity("Their retainer is $5,000/month") == "sensitive"

    def test_revenue(self):
        assert classify_sensitivity("Revenue hit $2M this quarter") == "sensitive"

    def test_budget_mention(self):
        assert classify_sensitivity("The marketing budget is tight") == "sensitive"

    def test_pricing(self):
        assert classify_sensitivity("We need to revisit pricing for Q2") == "sensitive"

    # HR
    def test_hiring(self):
        assert classify_sensitivity("We're hiring a new CMO") == "sensitive"

    def test_firing(self):
        assert classify_sensitivity("They're firing the agency") == "sensitive"

    def test_compensation(self):
        assert classify_sensitivity("Compensation package needs review") == "sensitive"

    def test_salary(self):
        assert classify_sensitivity("Her salary is competitive") == "sensitive"

    # Competitive
    def test_competitor(self):
        assert classify_sensitivity("Our main competitor is Acme Corp") == "sensitive"

    def test_market_share(self):
        assert classify_sensitivity("We're losing market share to them") == "sensitive"

    # Contractual
    def test_contract(self):
        assert classify_sensitivity("The contract expires in June") == "sensitive"

    def test_nda(self):
        assert classify_sensitivity("They signed an NDA with us") == "sensitive"

    def test_sla(self):
        assert classify_sensitivity("SLA requires 99.9% uptime") == "sensitive"

    # Explicit markers
    def test_confidential(self):
        assert classify_sensitivity("This is confidential information") == "sensitive"

    def test_cmo_only(self):
        assert classify_sensitivity("Mark this as cmo-only") == "sensitive"

    # Open content
    def test_normal_content(self):
        assert classify_sensitivity("Published a new blog post about SEO") == "open"

    def test_campaign_result(self):
        assert classify_sensitivity("Email open rate was 24%") == "open"

    def test_meeting_note(self):
        assert classify_sensitivity("Met with the team to discuss Q2 goals") == "open"

    # False positive awareness
    def test_retain_false_positive(self):
        result = classify_sensitivity("We want to retain this customer")
        assert result in ("open", "sensitive")


class TestStoreMemorySensitivity:
    """Test that store_memory_core accepts and passes sensitivity."""

    def test_store_memory_core_has_sensitivity_param(self):
        from coppermind_cmo.tools.memories import store_memory_core
        import inspect
        sig = inspect.signature(store_memory_core)
        assert "sensitivity" in sig.parameters

    def test_memory_store_store_has_sensitivity_param(self):
        from coppermind_cmo.memory_store import MemoryStore
        import inspect
        sig = inspect.signature(MemoryStore.store)
        assert "sensitivity" in sig.parameters

    def test_classify_sensitivity_called_when_none(self):
        """When sensitivity is None, auto-detection should run."""
        from coppermind_cmo.memory_types import classify_sensitivity
        assert classify_sensitivity("Their retainer is $5,000") == "sensitive"
        assert classify_sensitivity("Published a blog post") == "open"
