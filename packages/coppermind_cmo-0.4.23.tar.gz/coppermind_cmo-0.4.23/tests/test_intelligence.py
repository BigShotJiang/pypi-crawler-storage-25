"""Tests for prep_meeting and get_campaign_history tools."""

import json
import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.intelligence import (
    _prep_meeting, _get_campaign_history, _get_last_brief,
    _rerank_by_topic, MemoryRow,
    _collect_type_balanced,
    _quarter_weight, _collect_meeting_memories,
    _build_structured_brief,
    MemoryRow,
    PERMANENT_TYPES, TEMPORAL_TYPES,
)


def _dt(day: int) -> datetime:
    """Helper to create a timezone-aware datetime for March 2026."""
    return datetime(2026, 3, day, 10, 0, 0, tzinfo=timezone.utc)


def _make_config():
    config = MagicMock()
    config.llm_provider = "ollama"
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.max_prompt_chars = 13000
    return config


class TestConstantValues:
    def test_max_prompt_chars_is_13000(self):
        """Fix 4.4: Must be 13000 for SentencePiece tokenizer, not 16000."""
        from coppermind_cmo.tools.intelligence import MAX_PROMPT_CHARS
        assert MAX_PROMPT_CHARS == 13000

    def test_recency_and_similarity_weights_sum_to_one(self):
        from coppermind_cmo.tools.intelligence import RECENCY_WEIGHT, SIMILARITY_WEIGHT
        assert RECENCY_WEIGHT + SIMILARITY_WEIGHT == 1.0


class TestGetCampaignHistory:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_campaign_history(10, 0, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_campaign_outcomes(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "Q1 email: 34% open rate", "Q1 email results",
             ["email"], _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert len(result) == 1
        assert result[0]["memory_id"] == "mem-1"
        assert result[0]["content"] == "Q1 email: 34% open rate"
        assert "2026-03-05" in result[0]["created_at"]

    def test_empty_result(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result == []
        db.execute.assert_not_called()

    def test_none_tags_returns_empty_list(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", None, _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["tags"] == []

    def test_none_created_at_returns_none(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", ["tag"], None),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["created_at"] is None


def _context_row(cadence=None, company_info=None, stakeholders=None):
    """Helper to build a context_row tuple for prep_meeting mocks.

    Format: (name, brand_voice, brand_positioning, approved_messaging,
             stakeholders, content_themes, cadence, company_info)
    """
    return (
        "Acme",
        json.dumps({}),
        json.dumps({}),
        json.dumps({}),
        json.dumps(stakeholders or []),
        [],
        cadence or {},
        company_info or {},
    )


def _mem_row(mid, content, summary, mem_type, day, embedding=None, qy=None, q=None, s=None):
    """Helper to build a memory row from _collect_meeting_memories DB queries.

    Format: (id, content, summary, memory_type, created_at, embedding,
             quarter_year, quarter, sprint)
    """
    return (mid, content, summary, mem_type, _dt(day), embedding, qy, q, s)


class TestPrepMeeting:
    def test_requires_active_mind(self):
        db = MagicMock()
        config = _make_config()
        result = _prep_meeting(None, None, 20, db, config, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_insufficient_data_returns_raw(self):
        db = MagicMock()
        config = _make_config()

        # _collect_meeting_memories: cadence lookup, agenda, commitments, permanent, backfill
        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments (no cadence fallback)
            [],  # questions
            [_mem_row("m1", "c1", "s1", "fact", 1)],  # permanent
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 20, db, config, mind)
        assert result["mode"] == "raw"
        assert result["reason"] == "insufficient_data"
        assert result["brief_markdown"] is None
        assert result["memory_count"] == 1

    def test_no_memories_returns_raw(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 20, db, config, mind)
        assert result["mode"] == "raw"
        assert result["reason"] == "insufficient_data"
        assert result["memory_count"] == 0

    def test_synthesized_brief(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments
                _mem_row("m3", "c3", "s3", "commitment", 3),
                _mem_row("m4", "c4", "s4", "commitment", 4),
            ],
            [],  # questions
            [  # permanent
                _mem_row("m5", "c5", "s5", "fact", 5),
            ],
            [  # backfill
                _mem_row("m1", "c1", "s1", "decision", 1),
                _mem_row("m2", "c2", "s2", "decision", 2),
            ],
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert "# Meeting Brief" in result["brief_markdown"]
        assert result["client_name"] == "Acme"
        assert result["memory_count"] == 5

    def test_structured_with_enough_memories(self):
        """With >=3 memories, returns structured mode (no LLM needed)."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "stakeholder", 3),
            ],
            [_mem_row("m4", "c4", "s4", "decision", 4)],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["reason"] is None
        assert result["brief_markdown"] is not None
        assert result["memory_count"] == 4

    def test_memories_by_type_structure(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(stakeholders=[{"name": "Sarah", "title": "VP"}]),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m3", "c3", "s3", "stakeholder", 3),
            ],
            [  # backfill
                _mem_row("m1", "c1", "s1", "decision", 1),
                _mem_row("m2", "c2", "s2", "decision", 2),
            ],
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert "decision" in result["memories_by_type"]
        assert "stakeholder" in result["memories_by_type"]
        assert len(result["memories_by_type"]["decision"]) == 2
        assert len(result["memories_by_type"]["stakeholder"]) == 1
        assert result["stakeholders"] == [{"name": "Sarah", "title": "VP"}]


class TestTopicReranking:
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=None)
    def test_skips_reranking_when_embedding_unavailable(self, mock_emb):
        config = _make_config()
        memories = [
            MemoryRow("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            MemoryRow("m2", "c2", "s2", "fact", _dt(2), "fill", None),
        ]
        result, degraded = _rerank_by_topic(memories, "Q2 planning", config)
        assert len(result) == 2
        assert result[0][0] == "m1"
        assert degraded is True

    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_preserves_type_balanced_order(self, mock_emb):
        config = _make_config()
        memories = [
            MemoryRow("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            MemoryRow("m2", "c2", "s2", "decision", _dt(2), "type_balanced", None),
            MemoryRow("m3", "c3", "s3", "fact", _dt(3), "fill", None),
        ]
        result, degraded = _rerank_by_topic(memories, "ads", config)
        assert result[0][0] == "m1"
        assert result[1][0] == "m2"
        assert result[0][5] == "type_balanced"
        assert degraded is False



class TestCollectTypeBalanced:
    def test_no_populated_types_returns_empty(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        result = _collect_type_balanced("mind-1", 20, db)
        assert result == []

    def test_single_type_gets_full_allocation(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",)],
            [
                ("m1", "c1", "s1", "decision", _dt(1), None),
                ("m2", "c2", "s2", "decision", _dt(2), None),
            ],
            [],
        ]
        result = _collect_type_balanced("mind-1", 20, db)
        assert len(result) == 2
        for m in result:
            assert m[5] == "type_balanced"

    def test_deduplication_across_fill(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",)],
            [("m1", "c1", "s1", "decision", _dt(1), None)],
            [("m2", "c2", "s2", "fact", _dt(2), None)],
        ]
        result = _collect_type_balanced("mind-1", 20, db)
        ids = [m[0] for m in result]
        assert ids.count("m1") == 1
        assert ids.count("m2") == 1
        assert len(result) == 2
        fill_call = db.fetch_all.call_args_list[2]
        assert "m1" in fill_call[0][1][1]

    def test_limit_less_than_populated_types_uses_fill_only(self):
        db = MagicMock()
        db.fetch_all.side_effect = [
            [("decision",), ("commitment",), ("fact",), ("preference",)],
            [],
            [],
            [],
            [],
            [
                ("m1", "c1", "s1", "decision", _dt(1), None),
                ("m2", "c2", "s2", "fact", _dt(2), None),
            ],
        ]
        result = _collect_type_balanced("mind-1", 2, db)
        assert len(result) == 2
        assert all(m[5] == "fill" for m in result)


class TestRerankAdditions:
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_no_fill_memories_returns_unchanged(self, mock_emb):
        config = _make_config()
        memories = [
            MemoryRow("m1", "c1", "s1", "decision", _dt(1), "type_balanced", None),
            MemoryRow("m2", "c2", "s2", "fact", _dt(2), "type_balanced", None),
        ]
        result, degraded = _rerank_by_topic(memories, "Q2 planning", config)
        assert len(result) == 2
        assert result[0][0] == "m1"
        assert result[1][0] == "m2"
        assert degraded is False

    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_identical_timestamps_handled(self, mock_emb):
        mock_emb.return_value = [0.5, 0.5]
        config = _make_config()
        same_time = _dt(5)
        memories = [
            MemoryRow("m1", "c1", "s1", "fact", same_time, "fill", None),
            MemoryRow("m2", "c2", "s2", "fact", same_time, "fill", None),
            MemoryRow("m3", "c3", "s3", "fact", same_time, "fill", None),
        ]
        result, degraded = _rerank_by_topic(memories, "ads", config)
        assert len(result) == 3
        assert degraded is False

    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_mixed_embedding_availability(self, mock_emb):
        import json
        mock_emb.return_value = [1.0, 0.0]
        config = _make_config()
        stored_emb = json.dumps([0.8, 0.2])
        memories = [
            MemoryRow("m1", "c1", "s1", "fact", _dt(1), "fill", stored_emb),
            MemoryRow("m2", "c2", "s2", "fact", _dt(2), "fill", None),
        ]
        result, degraded = _rerank_by_topic(memories, "ads", config)
        assert len(result) == 2
        mock_emb.assert_called_once()
        assert degraded is False


class TestPrepMeetingAdditions:
    def test_boundary_exactly_3_memories_returns_structured(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row (first fetch_one in _prep_meeting)
            (None,),  # cadence (second fetch_one via _get_mind_cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["memory_count"] == 3

    def test_brand_row_none_returns_error(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            None,  # context_row (not found — error path)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "fact", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


class TestStoredEmbeddingReranking:
    def test_rerank_uses_stored_embeddings_not_http_calls(self, mock_config):
        from coppermind_cmo.tools.intelligence import _rerank_by_topic
        from unittest.mock import patch
        import json

        topic_embedding = [0.1] * 384
        stored_embedding = json.dumps([0.2] * 384)

        memories = [
            MemoryRow("id1", "content1", "summary1", "fact", _dt(1), "fill", stored_embedding),
            MemoryRow("id2", "content2", "summary2", "fact", _dt(2), "fill", stored_embedding),
        ]

        with patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=topic_embedding) as mock_get_emb:
            result, degraded = _rerank_by_topic(memories, "test topic", mock_config)

        mock_get_emb.assert_called_once_with("test topic", mock_config)
        assert len(result) == 2
        assert degraded is False


class TestQuarterWeight:
    def test_quarter_weight_current(self):
        assert _quarter_weight(2026, 1, 2026, 1) == 1.0

    def test_quarter_weight_previous(self):
        assert _quarter_weight(2025, 4, 2026, 1) == 0.7

    def test_quarter_weight_old(self):
        assert _quarter_weight(2024, 4, 2026, 1) == 0.1

    def test_quarter_weight_untagged(self):
        assert _quarter_weight(None, None, 2026, 1) == 0.5

    def test_quarter_weight_future(self):
        assert _quarter_weight(2026, 2, 2026, 1) == 1.0


class TestCollectMeetingMemories:
    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_collect_meeting_memories_with_topics(self, mock_emb):
        mock_emb.return_value = [0.5, 0.5]
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence (no cadence)
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            # topic search returns 2 results
            [
                _mem_row("t1", "topic content 1", "topic summary 1", "decision", 1, None, 2026, 1, 1),
                _mem_row("t2", "topic content 2", "topic summary 2", "fact", 2, None, 2026, 1, 2),
            ],
            [],  # commitments (no cadence fallback)
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", ["Q1 results"], 50, db, config)
        ids = [m[0] for m in result]
        assert "t1" in ids
        assert "t2" in ids
        assert degraded is False

    def test_collect_meeting_memories_agenda_items(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [  # agenda returns 2 items
                _mem_row("a1", "agenda item 1", "agenda summary 1", "commitment", 5),
                _mem_row("a2", "agenda item 2", "agenda summary 2", "decision", 6),
            ],
            [],  # commitments (no cadence fallback)
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", None, 50, db, config)
        assert len(result) >= 2
        # Agenda items should be first
        assert result[0][5] == "agenda"
        assert result[1][5] == "agenda"
        assert result[0][0] == "a1"
        assert degraded is False

    def test_collect_meeting_memories_commitments(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            ({"type": "eos", "year": 2026, "quarter": 1},),  # cadence with year/quarter
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments
                _mem_row("c1", "commitment 1", "commit summary 1", "commitment", 3, None, 2026, 1, 2),
            ],
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", None, 50, db, config)
        commitment_mems = [m for m in result if m[5] == "commitment"]
        assert len(commitment_mems) == 1
        assert commitment_mems[0][0] == "c1"
        assert degraded is False

    def test_collect_meeting_memories_permanent(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # no cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments (no cadence fallback)
            [],  # questions
            [  # permanent
                _mem_row("p1", "stakeholder info", "stakeholder summary", "stakeholder", 1),
                _mem_row("p2", "some fact", "fact summary", "fact", 2),
            ],
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", None, 50, db, config)
        permanent_mems = [m for m in result if m[5] == "permanent"]
        assert len(permanent_mems) == 2
        perm_ids = [m[0] for m in permanent_mems]
        assert "p1" in perm_ids
        assert "p2" in perm_ids
        assert degraded is False

    def test_collect_meeting_memories_no_cadence(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence empty
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [  # commitments (recency fallback since no cadence)
                _mem_row("c1", "commitment 1", "commit summary", "commitment", 4),
            ],
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", None, 50, db, config)
        # Function should work without cadence (no quarter weighting applied)
        assert len(result) >= 1
        commitment_mems = [m for m in result if m[5] == "commitment"]
        assert len(commitment_mems) == 1
        assert degraded is False


class TestPrepMeetingEnhanced:
    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=[0.5, 0.5])
    def test_prep_meeting_with_topics(self, mock_emb):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence via _get_mind_cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            # topic search for "Q1 results"
            [
                _mem_row("t1", "Q1 revenue up", "Q1 summary", "decision", 1, None, 2026, 1, 1),
                _mem_row("t2", "Q1 costs down", "costs summary", "fact", 2, None, 2026, 1, 2),
            ],
            # topic search for "ad budget"
            [
                _mem_row("t3", "ad spend info", "ad summary", "decision", 3, None, 2026, 1, 3),
            ],
            [],  # commitments (no cadence fallback)
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(["Q1 results", "ad budget"], None, 50, db, config, mind)
        assert result["mode"] == "structured"

    def test_prep_meeting_with_meeting_type(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "fact", 3),
            ],
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, "review", 50, db, config, mind)
        assert result["mode"] == "structured"

    def test_prep_meeting_invalid_meeting_type(self):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, "invalid", 50, db, config, mind)
        assert result["code"] == "INVALID_INPUT"

    def test_prep_meeting_backward_compatible(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]

        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["client_name"] == "Acme"


class TestPrepMeetingSave:
    """Fix #5: prep_meeting with save=True persists the brief."""

    def test_save_true_stores_brief(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence via _get_mind_cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        db.execute_returning.return_value = ("brief-uuid",)
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=True)
        assert result["mode"] == "structured"
        assert result.get("brief_id") == "brief-uuid"
        assert result["saved"] is True
        # Verify INSERT was called
        db.execute_returning.assert_called_once()
        insert_sql = db.execute_returning.call_args[0][0]
        assert "meeting_briefs" in insert_sql

    def test_save_false_does_not_store(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=False)
        assert result["mode"] == "structured"
        assert "brief_id" not in result
        db.execute_returning.assert_not_called()

    def test_save_true_raw_mode_does_not_store(self):
        """With <3 memories, mode is raw and save=True does not persist."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent — only 2 memories (below threshold)
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind, save=True)
        assert result["mode"] == "raw"
        assert "brief_id" not in result
        assert result["saved"] is False
        db.execute_returning.assert_not_called()


class TestGetLastBrief:
    """Fix #5: get_last_brief retrieves the most recent saved brief."""

    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_last_brief(db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_last_brief(self):
        db = MagicMock()
        created = _dt(5)
        db.fetch_one.return_value = (
            "brief-uuid", "## Brief\nContent", "review", ["topic1"], 10, created
        )
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert result["brief_id"] == "brief-uuid"
        assert result["brief_markdown"] == "## Brief\nContent"
        assert result["meeting_type"] == "review"
        assert result["topics"] == ["topic1"]

    def test_no_brief_found(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert result["brief_markdown"] is None
        assert result["message"] is not None

    def test_age_warning_when_brief_older_than_7_days(self):
        """Brief older than 7 days should include age_warning."""
        db = MagicMock()
        from datetime import timedelta
        old_date = datetime.now(timezone.utc) - timedelta(days=30)
        db.fetch_one.return_value = (
            "brief-uuid", "## Brief\nOld content", "review", ["topic1"], 10, old_date
        )
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert "age_warning" in result
        assert "days old" in result["age_warning"]
        assert "prep_meeting" in result["age_warning"]

    def test_no_age_warning_when_brief_is_recent(self):
        """Brief <= 7 days old should NOT include age_warning."""
        db = MagicMock()
        from datetime import timedelta
        recent_date = datetime.now(timezone.utc) - timedelta(days=2)
        db.fetch_one.return_value = (
            "brief-uuid", "## Brief\nRecent", "review", [], 5, recent_date
        )
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert "age_warning" not in result

    def test_no_age_warning_when_created_at_is_none(self):
        """Brief with NULL created_at should NOT include age_warning."""
        db = MagicMock()
        db.fetch_one.return_value = (
            "brief-uuid", "## Brief\nContent", "review", [], 5, None
        )
        mind = ("mind-1", "Acme")
        result = _get_last_brief(db, mind)
        assert "age_warning" not in result


class TestFallbackBrief:
    """Fix #2: template-based brief when LLM is unavailable."""

    def test_basic_fallback_structure(self):
        """Fallback brief has headers and content."""
        memories = [
            MemoryRow("m1", "Ben will send proposal by Friday", "Ben sends proposal", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            MemoryRow("m2", "Pausing LinkedIn ads", "Pause LinkedIn", "decision", _dt(2), "permanent", None, 2026, 1, 1),
            MemoryRow("m3", "Sarah Chen is VP Marketing", "Sarah is VP", "stakeholder", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brand_dna = {
            "brand_voice": {},
            "stakeholders": [{"name": "Sarah Chen", "title": "VP Marketing", "role": "primary contact"}],
        }
        brief = _build_structured_brief(memories, brand_dna, "Acme")
        assert "# Meeting Brief: Acme" in brief
        assert "## Key Stakeholders" in brief
        assert "Sarah Chen" in brief
        assert "## Action Items" in brief
        assert "- [ ]" in brief
        assert "## Last Meeting Takeaways" in brief
        assert brief.rstrip().endswith("---")

    def test_fallback_with_no_memories(self):
        """Fallback brief with zero memories shows message."""
        brief = _build_structured_brief([], {"stakeholders": []}, "Empty Client")
        assert "No memories available" in brief

    def test_fallback_with_cadence(self):
        """Fallback includes EOS position when cadence is set."""
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        brief = _build_structured_brief([], {"stakeholders": []}, "Acme", cadence=cadence)
        assert "Sprint 4 of 6" in brief


class TestPrepMeetingFallback:
    """prep_meeting returns fallback brief instead of null when LLM is down."""

    def test_structured_brief_returned(self):
        """With >=3 memories, returns structured mode with template brief."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(stakeholders=[{"name": "Sarah", "title": "VP"}]),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result["reason"] is None
        assert result["brief_markdown"] is not None
        assert "# Meeting Brief: Acme" in result["brief_markdown"]

    def test_insufficient_data_has_message(self):
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [_mem_row("m1", "c1", "s1", "fact", 1)],  # permanent (only 1)
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "raw"
        assert result["message"] is not None
        assert "memories" in result["message"].lower()


# ---------------------------------------------------------------------------
# Commitment completion rendering in briefs
# ---------------------------------------------------------------------------

class TestCommitmentRendering:
    """Completed commitments render as [x] in briefs, open as [ ]."""

    def test_open_commitment_renders_unchecked(self):
        memories = [
            MemoryRow("m1", "Send proposal", "Send proposal", "commitment", _dt(1), "commitment", None, 2026, 1, 1, is_completed=False),
            MemoryRow("m2", "Q1 results", "Q1 results", "decision", _dt(2), "permanent", None, 2026, 1, 1),
            MemoryRow("m3", "Some fact", "Some fact", "fact", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brief = _build_structured_brief(memories, {"stakeholders": []}, "Acme")
        assert "- [ ] Send proposal" in brief
        assert "- [x]" not in brief

    def test_completed_commitment_renders_checked(self):
        memories = [
            MemoryRow("m1", "Send proposal", "Send proposal", "commitment", _dt(1), "commitment", None, 2026, 1, 1, is_completed=True),
            MemoryRow("m2", "Q1 results", "Q1 results", "decision", _dt(2), "permanent", None, 2026, 1, 1),
            MemoryRow("m3", "Some fact", "Some fact", "fact", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brief = _build_structured_brief(memories, {"stakeholders": []}, "Acme")
        assert "- [x] Send proposal" in brief

    def test_mixed_commitments_open_first(self):
        """Open commitments render before completed ones."""
        memories = [
            MemoryRow("m1", "Done task", "Done task", "commitment", _dt(1), "commitment", None, 2026, 1, 1, is_completed=True),
            MemoryRow("m2", "Open task", "Open task", "commitment", _dt(2), "commitment", None, 2026, 1, 1, is_completed=False),
            MemoryRow("m3", "Some fact", "Some fact", "fact", _dt(3), "permanent", None, 2026, 1, 1),
        ]
        brief = _build_structured_brief(memories, {"stakeholders": []}, "Acme")
        open_pos = brief.index("- [ ] Open task")
        done_pos = brief.index("- [x] Done task")
        assert open_pos < done_pos, "Open commitments should render before completed ones"

    def test_section_header_is_action_items(self):
        """Section header should be 'Action Items' (not 'Open Action Items')."""
        memories = [
            MemoryRow("m1", "A task", "A task", "commitment", _dt(1), "commitment", None, 2026, 1, 1),
            MemoryRow("m2", "fact1", "fact1", "fact", _dt(2), "permanent"),
            MemoryRow("m3", "fact2", "fact2", "fact", _dt(3), "permanent"),
        ]
        brief = _build_structured_brief(memories, {"stakeholders": []}, "Acme")
        assert "## Action Items" in brief
        assert "## Open Action Items" not in brief

    def test_question_type_renders_unresolved_questions(self):
        """Question-type memories render under '## Unresolved Questions'."""
        memories = [
            MemoryRow("m1", "What is the rebrand timeline?", "Rebrand timeline?", "question", _dt(1), "question"),
            MemoryRow("m2", "Pausing LinkedIn ads", "Pause LinkedIn", "decision", _dt(2), "permanent"),
        ]
        brief = _build_structured_brief(memories, {"stakeholders": []}, "Acme")
        assert "## Unresolved Questions" in brief
        assert "Rebrand timeline?" in brief
        # Verify section order: takeaways before questions
        takeaways_pos = brief.index("## Last Meeting Takeaways")
        questions_pos = brief.index("## Unresolved Questions")
        assert takeaways_pos < questions_pos


# ---------------------------------------------------------------------------
# Degraded behavior tests for intelligence tools
# ---------------------------------------------------------------------------

class TestPrepMeetingDegraded:
    """Tests for graceful degradation when topic embeddings fail."""

    @patch("coppermind_cmo.tools.intelligence.get_embedding", return_value=None)
    def test_prep_meeting_degraded_when_topic_embeddings_fail(self, mock_emb):
        """When embedding service is down for topics, prep_meeting returns degraded flag."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(["Q1 results", "ad budget"], None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert result.get("degraded") is True
        assert "topic" in result["degraded_reason"].lower()

    def test_prep_meeting_no_degraded_without_topics(self):
        """When no topics provided, prep_meeting should not have degraded flag."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "structured"
        assert "degraded" not in result


class TestCollectMeetingMemoriesDegraded:
    """Tests for partial topic degradation in _collect_meeting_memories."""

    @patch("coppermind_cmo.tools.intelligence.get_embedding")
    def test_partial_topic_degradation(self, mock_emb):
        """First topic succeeds, second fails -- still returns results with degraded=True."""
        # First call succeeds, second returns None
        mock_emb.side_effect = [[0.5, 0.5], None]
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            # topic search for first topic returns results
            [
                _mem_row("t1", "topic content", "topic summary", "decision", 1, None, 2026, 1, 1),
            ],
            # second topic skipped (embedding None)
            [],  # commitments
            [],  # questions
            [],  # permanent
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", ["topic1", "topic2"], 50, db, config)
        assert degraded is True
        ids = [m[0] for m in result]
        assert "t1" in ids

    def test_no_topics_no_degradation(self):
        """Without topics, topics_degraded should be False."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("p1", "fact content", "fact summary", "fact", 1),
            ],
            [],  # backfill
        ]

        result, degraded = _collect_meeting_memories("mind-1", None, 50, db, config)
        assert degraded is False
        assert len(result) == 1


# ---------------------------------------------------------------------------
# Privacy filter tests for client-facing outputs
# ---------------------------------------------------------------------------


class TestPrivacyInPrepMeeting:
    """Private memories should be excluded from prep_meeting queries."""

    def test_prep_meeting_excludes_private(self):
        """All queries in _collect_meeting_memories include is_private filter."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.side_effect = [
            _context_row(),  # context_row
            (None,),  # cadence
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [],  # questions
            [  # permanent
                _mem_row("m1", "c1", "s1", "fact", 1),
                _mem_row("m2", "c2", "s2", "stakeholder", 2),
                _mem_row("m3", "c3", "s3", "preference", 3),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        _prep_meeting(None, None, 50, db, config, mind)

        # Verify all fetch_all calls in _collect_meeting_memories include is_private filter
        # The first fetch_one is for context_row, second for cadence
        # fetch_all calls: agenda, commitments, questions, permanent, backfill
        for call in db.fetch_all.call_args_list:
            sql = call[0][0]
            if "FROM memories" in sql:
                assert "is_private" in sql, f"Missing is_private filter in SQL: {sql[:80]}..."


class TestPrivacyInCampaignHistory:
    """Private memories should be excluded from get_campaign_history."""

    def test_campaign_history_excludes_private(self):
        """get_campaign_history SQL includes is_private filter."""
        db = MagicMock()
        db.fetch_all.return_value = []
        mind = ("mind-1", "Acme")
        _get_campaign_history(10, 0, db, mind)

        sql = db.fetch_all.call_args[0][0]
        assert "is_private = false" in sql
