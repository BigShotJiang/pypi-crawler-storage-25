"""Tests for pending_queue — local fallback queue for failed DB writes."""

import json
import os
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import coppermind_cmo.pending_queue as pq


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def temp_pending_dir(tmp_path, monkeypatch):
    """Redirect pending queue to a temp directory for all tests."""
    pending_dir = tmp_path / "pending"
    monkeypatch.setattr("coppermind_cmo.pending_queue.PENDING_DIR", pending_dir)
    return pending_dir


def _make_payload(**overrides):
    base = {
        "mind_id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        "content": "Acme Corp prefers email over Slack for approvals.",
        "memory_type": "preference",
        "summary": "Acme prefers email for approvals",
        "embedding": [0.1] * 10,
        "source_type": "manual",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# TestEnqueue
# ---------------------------------------------------------------------------

class TestEnqueue:
    """Tests for pq.enqueue()."""

    def test_enqueue_creates_file(self, temp_pending_dir):
        """Verify JSON file created with _meta structure."""
        result = pq.enqueue(_make_payload())
        assert result is not None
        path = Path(result)
        assert path.exists()

        data = json.loads(path.read_text())
        assert "_meta" in data
        assert "enqueued_at" in data["_meta"]
        assert data["mind_id"] == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

    def test_enqueue_dedup(self, temp_pending_dir):
        """Same mind_id + content twice = only 1 file."""
        pq.enqueue(_make_payload())
        pq.enqueue(_make_payload())

        files = list(temp_pending_dir.glob("*.json"))
        assert len(files) == 1

    def test_enqueue_different_content(self, temp_pending_dir):
        """Different content = 2 files."""
        pq.enqueue(_make_payload(content="Alpha"))
        pq.enqueue(_make_payload(content="Beta"))

        files = list(temp_pending_dir.glob("*.json"))
        assert len(files) == 2

    def test_enqueue_full_queue(self, temp_pending_dir):
        """MAX_PENDING files exist, returns None."""
        temp_pending_dir.mkdir(parents=True, exist_ok=True)
        for i in range(pq.MAX_PENDING):
            (temp_pending_dir / f"dummy_{i:04d}.json").write_text("{}")

        result = pq.enqueue(_make_payload())
        assert result is None

    def test_enqueue_preserves_embedding(self, temp_pending_dir):
        """Embedding preserved exactly."""
        embedding = [0.123, 0.456, 0.789]
        result = pq.enqueue(_make_payload(embedding=embedding))
        data = json.loads(Path(result).read_text())
        assert data["embedding"] == [0.123, 0.456, 0.789]

    def test_enqueue_numpy_conversion(self, temp_pending_dir):
        """numpy-like .tolist() converted to list."""

        class FakeNdarray:
            """Mimics numpy ndarray with .tolist()."""

            def __init__(self, values):
                self._values = values

            def tolist(self):
                return self._values

        fake = FakeNdarray([0.1, 0.2, 0.3])
        result = pq.enqueue(_make_payload(embedding=fake))
        data = json.loads(Path(result).read_text())
        assert data["embedding"] == [0.1, 0.2, 0.3]
        assert isinstance(data["embedding"], list)

    def test_enqueue_file_permissions(self, temp_pending_dir):
        """PENDING_DIR created with mode 0o700."""
        pq.enqueue(_make_payload())
        mode = temp_pending_dir.stat().st_mode & 0o777
        assert mode == 0o700

    def test_enqueue_filename_is_timestamp_prefixed(self, temp_pending_dir):
        """Filename starts with timestamp."""
        result = pq.enqueue(_make_payload())
        name = Path(result).name
        # Format: {timestamp}_{hash[:16]}.json
        parts = name.replace(".json", "").split("_", 1)
        assert len(parts) == 2
        # First part should be a numeric timestamp
        assert parts[0].isdigit()

    def test_atomic_write_no_tmp_files(self, temp_pending_dir):
        """No .tmp files after enqueue."""
        pq.enqueue(_make_payload())
        tmp_files = list(temp_pending_dir.glob("*.tmp"))
        assert len(tmp_files) == 0


# ---------------------------------------------------------------------------
# TestUtilities
# ---------------------------------------------------------------------------

class TestUtilities:
    """Tests for count, clear, list_pending."""

    def test_count(self, temp_pending_dir):
        """Create 3 files, count() returns 3."""
        pq.enqueue(_make_payload(content="one"))
        pq.enqueue(_make_payload(content="two"))
        pq.enqueue(_make_payload(content="three"))
        assert pq.count() == 3

    def test_clear(self, temp_pending_dir):
        """Create 2, clear(), count() returns 0."""
        pq.enqueue(_make_payload(content="alpha"))
        pq.enqueue(_make_payload(content="beta"))
        pq.clear()
        assert pq.count() == 0

    def test_clear_also_removes_tmp_files(self, temp_pending_dir):
        """tmp files cleaned up by clear."""
        pq.enqueue(_make_payload())
        # Manually create a stale .tmp file
        (temp_pending_dir / "stale.tmp").write_text("junk")
        pq.clear()
        assert list(temp_pending_dir.iterdir()) == []

    def test_list_pending(self, temp_pending_dir):
        """Returns summaries with mind_id, enqueued_at, summary."""
        pq.enqueue(_make_payload(
            content="First note",
            summary="First summary",
        ))
        pq.enqueue(_make_payload(
            content="Second note",
            summary="Second summary",
        ))

        items = pq.list_pending()
        assert len(items) == 2
        for item in items:
            assert "mind_id" in item
            assert "enqueued_at" in item
            assert "summary" in item

    def test_list_pending_handles_corrupt_file(self, temp_pending_dir):
        """Corrupt JSON = {"error": "corrupt"}."""
        temp_pending_dir.mkdir(parents=True, exist_ok=True)
        (temp_pending_dir / "corrupt.json").write_text("NOT JSON{{{")

        items = pq.list_pending()
        assert len(items) == 1
        assert items[0]["error"] == "corrupt"


# ---------------------------------------------------------------------------
# TestDrain
# ---------------------------------------------------------------------------

class TestDrain:
    """Tests for pq.drain() — replay pending files through store_memory_core."""

    MIND_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    MIND_NAME = "Acme Corp"

    def _write_pending_file(
        self,
        temp_pending_dir,
        content="Test memory",
        mind_id=None,
        age_days=0,
    ):
        if mind_id is None:
            mind_id = self.MIND_ID
        pq._ensure_dir()
        dedup = pq._dedup_key(mind_id, content)
        ts = int(time.time()) - (age_days * 86400)
        file_path = temp_pending_dir / f"{ts}_{dedup[:16]}.json"
        record = {
            "_meta": {
                "dedup_key": dedup,
                "enqueued_at": time.time() - (age_days * 86400),
                "enqueued_iso": "2026-03-27T00:00:00Z",
            },
            "mind_id": mind_id,
            "content": content,
            "memory_type": "fact",
            "summary": content[:60],
            "embedding": [0.1] * 10,
            "source_type": "manual",
        }
        file_path.write_text(json.dumps(record))
        return file_path

    def _mock_db(self, mind_exists=True):
        db = MagicMock()
        if mind_exists:
            db.fetch_one.return_value = (self.MIND_ID, self.MIND_NAME)
        else:
            db.fetch_one.return_value = None
        return db

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_empty_queue(self, mock_smc, temp_pending_dir):
        """No files, returns all zeros."""
        db = self._mock_db()
        config = MagicMock()
        result = pq.drain(db, config)
        assert result["recovered"] == 0
        assert result["failed"] == 0
        assert result["expired"] == 0
        assert result["skipped"] == 0
        mock_smc.assert_not_called()

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_recovers_via_store_memory_core(self, mock_smc, temp_pending_dir):
        """1 file, mock succeeds, file deleted, store_memory_core called with correct args."""
        mock_smc.return_value = {"memory_id": "abc123"}
        db = self._mock_db()
        config = MagicMock()
        fp = self._write_pending_file(temp_pending_dir)

        result = pq.drain(db, config)

        assert result["recovered"] == 1
        assert result["failed"] == 0
        assert not fp.exists()
        mock_smc.assert_called_once()
        call_kwargs = mock_smc.call_args[1] if mock_smc.call_args[1] else {}
        if not call_kwargs:
            # positional+keyword mix — check kwargs from the call
            call_kwargs = mock_smc.call_args.kwargs
        assert call_kwargs.get("_skip_enqueue") is True
        assert call_kwargs.get("source_tool") == "pending_queue_drain"

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_circuit_breaker(self, mock_smc, temp_pending_dir):
        """5 files, 1st succeeds, 2nd raises, verify: 1 recovered, 1 failed, 3 skipped."""
        call_count = [0]

        def side_effect(**kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                return {"memory_id": "ok1"}
            raise RuntimeError("DB down")

        mock_smc.side_effect = side_effect
        db = self._mock_db()
        config = MagicMock()

        for i in range(5):
            self._write_pending_file(temp_pending_dir, content=f"Memory {i}")

        result = pq.drain(db, config)

        assert result["recovered"] == 1
        assert result["failed"] == 1
        assert result["skipped"] == 3

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_expires_old(self, mock_smc, temp_pending_dir):
        """File with age_days=31 expires, not recovered, store_memory_core not called."""
        db = self._mock_db()
        config = MagicMock()
        fp = self._write_pending_file(temp_pending_dir, age_days=31)

        result = pq.drain(db, config)

        assert result["expired"] == 1
        assert result["recovered"] == 0
        assert not fp.exists()
        mock_smc.assert_not_called()

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_handles_corrupt_file(self, mock_smc, temp_pending_dir):
        """Corrupt JSON file deleted, counted as failed."""
        temp_pending_dir.mkdir(parents=True, exist_ok=True)
        corrupt = temp_pending_dir / "1234567890_abcdef1234567890.json"
        corrupt.write_text("NOT JSON{{{")
        db = self._mock_db()
        config = MagicMock()

        result = pq.drain(db, config)

        assert result["failed"] == 1
        assert not corrupt.exists()
        mock_smc.assert_not_called()

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_expires_deleted_mind(self, mock_smc, temp_pending_dir):
        """db.fetch_one returns None, file deleted, counted as expired."""
        db = self._mock_db(mind_exists=False)
        config = MagicMock()
        fp = self._write_pending_file(temp_pending_dir)

        result = pq.drain(db, config)

        assert result["expired"] == 1
        assert not fp.exists()
        mock_smc.assert_not_called()

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_resolves_mind_from_db(self, mock_smc, temp_pending_dir):
        """active_mind tuple passed to store_memory_core matches db row."""
        mock_smc.return_value = {"memory_id": "xyz"}
        db = self._mock_db()
        config = MagicMock()
        self._write_pending_file(temp_pending_dir)

        pq.drain(db, config)

        call_kwargs = mock_smc.call_args.kwargs
        assert call_kwargs["active_mind"] == (self.MIND_ID, self.MIND_NAME)

    @patch("coppermind_cmo.tools.memories.store_memory_core")
    def test_drain_returns_details_by_mind(self, mock_smc, temp_pending_dir):
        """2 files, both succeed, details list has 2 entries with mind_name."""
        mock_smc.return_value = {"memory_id": "ok"}
        db = self._mock_db()
        config = MagicMock()
        self._write_pending_file(temp_pending_dir, content="Alpha")
        self._write_pending_file(temp_pending_dir, content="Beta")

        result = pq.drain(db, config)

        assert result["recovered"] == 2
        assert len(result["details"]) == 2
        for detail in result["details"]:
            assert detail["mind_name"] == self.MIND_NAME


# ---------------------------------------------------------------------------
# TestStoreMemoryFallback
# ---------------------------------------------------------------------------

class TestStoreMemoryFallback:
    """Tests for MemoryStore.store() enqueue-on-failure behavior."""

    def _make_store(self, db_side_effect=None):
        from coppermind_cmo.memory_store import MemoryStore
        mock_db = MagicMock()
        mock_config = MagicMock()
        mock_config.embedding_dim = 1024
        if db_side_effect:
            mock_db.execute_returning.side_effect = db_side_effect
        else:
            mock_db.execute_returning.return_value = {"id": "new-uuid"}
        mock_db.fetch_one.return_value = (1,)  # Column existence checks
        return MemoryStore(mock_db, mock_config)

    def test_store_enqueues_on_operational_error(self, temp_pending_dir):
        import psycopg2
        store = self._make_store(db_side_effect=psycopg2.OperationalError("connection refused"))
        result = store.store(
            mind_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            content="Test fallback", memory_type="fact", summary="Test",
            embedding=[0.1] * 10, source_type="manual",
        )
        assert result is not None
        assert result["status"] == "queued_locally"
        assert result["id"] == "pending"
        files = list(temp_pending_dir.glob("*.json"))
        assert len(files) == 1

    def test_store_does_not_enqueue_on_integrity_error(self, temp_pending_dir):
        import psycopg2
        store = self._make_store(db_side_effect=psycopg2.IntegrityError("unique violation"))
        with pytest.raises(psycopg2.IntegrityError):
            store.store(
                mind_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
                content="Test no-enqueue", memory_type="fact", source_type="manual",
            )
        files = list(temp_pending_dir.glob("*.json"))
        assert len(files) == 0

    def test_store_skip_enqueue_flag(self, temp_pending_dir):
        import psycopg2
        store = self._make_store(db_side_effect=psycopg2.OperationalError("connection refused"))
        with pytest.raises(psycopg2.OperationalError):
            store.store(
                mind_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
                content="Skip enqueue test", memory_type="fact", source_type="manual",
                _skip_enqueue=True,
            )
        files = list(temp_pending_dir.glob("*.json"))
        assert len(files) == 0


# ---------------------------------------------------------------------------
# TestStoreMemoryCoreQueuedReturn
# ---------------------------------------------------------------------------

class TestStoreMemoryCoreQueuedReturn:
    """Test store_memory_core handles queued_locally return and new params."""

    @patch("coppermind_cmo.tools.memories.MemoryStore")
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1] * 10)
    @patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={"year": 2026, "quarter": 1, "sprint": None})
    @patch("coppermind_cmo.server.get_last_tool_call", return_value=None)
    def test_handles_queued_return(self, mock_gtc, mock_cadence, mock_embed, mock_store_cls):
        from coppermind_cmo.tools.memories import store_memory_core
        mock_inst = MagicMock()
        mock_inst.store.return_value = {
            "id": "pending", "status": "queued_locally",
            "message": "Memory saved locally.", "pending_file": "/tmp/fake.json",
        }
        mock_store_cls.return_value = mock_inst
        result = store_memory_core(
            content="Queued test", memory_type="fact", tags=[],
            db=MagicMock(), config=MagicMock(),
            active_mind=("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "Acme Corp"),
        )
        assert result["status"] == "queued_locally"
        assert result["memory_id"] == "pending"
        assert not result.get("error")

    @patch("coppermind_cmo.tools.memories.MemoryStore")
    @patch("coppermind_cmo.tools.memories.get_embedding")
    @patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={"year": 2026, "quarter": 1, "sprint": None})
    @patch("coppermind_cmo.server.get_last_tool_call", return_value=None)
    def test_skips_embedding_when_provided(self, mock_gtc, mock_cadence, mock_embed, mock_store_cls):
        from coppermind_cmo.tools.memories import store_memory_core
        pre_computed = [0.5] * 10
        mock_inst = MagicMock()
        mock_inst.store.return_value = {"id": "new-uuid"}
        mock_store_cls.return_value = mock_inst
        store_memory_core(
            content="Pre-embedded", memory_type="fact", tags=[],
            db=MagicMock(), config=MagicMock(),
            active_mind=("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "Acme Corp"),
            embedding=pre_computed,
        )
        mock_embed.assert_not_called()
        call_kwargs = mock_inst.store.call_args[1]
        assert call_kwargs["embedding"] == pre_computed

    @patch("coppermind_cmo.tools.memories.MemoryStore")
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.9] * 10)
    @patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={"year": 2026, "quarter": 1, "sprint": None})
    @patch("coppermind_cmo.server.get_last_tool_call", return_value=None)
    def test_computes_embedding_when_not_provided(self, mock_gtc, mock_cadence, mock_embed, mock_store_cls):
        from coppermind_cmo.tools.memories import store_memory_core
        mock_inst = MagicMock()
        mock_inst.store.return_value = {"id": "new-uuid"}
        mock_store_cls.return_value = mock_inst
        store_memory_core(
            content="Compute embedding", memory_type="fact", tags=[],
            db=MagicMock(), config=MagicMock(),
            active_mind=("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee", "Acme Corp"),
        )
        mock_embed.assert_called_once()


# ---------------------------------------------------------------------------
# TestStartupDrain
# ---------------------------------------------------------------------------

class TestStartupDrain:
    """Tests for the server.py startup drain wrapper pattern."""

    def test_startup_drain_failure_does_not_block(self):
        """If drain() raises, the server startup pattern should continue."""
        from coppermind_cmo import pending_queue
        with patch.object(pending_queue, "count", return_value=3):
            with patch.object(pending_queue, "drain", side_effect=Exception("Queue corruption")):
                # Simulate the server.py wrapper pattern
                try:
                    pc = pending_queue.count()
                    if pc > 0:
                        pending_queue.drain(MagicMock(), MagicMock())
                except Exception:
                    pass  # Server continues
                assert True  # No unhandled exception


# ---------------------------------------------------------------------------
# TestRecoveryNotification
# ---------------------------------------------------------------------------

class TestRecoveryNotification:
    """Tests for the one-shot recovery notification provider."""

    def test_recovery_notification_one_shot(self):
        """Notification fires once then returns empty."""
        drain_result = {
            "recovered": 3,
            "details": [
                {"mind_id": "a", "mind_name": "Acme Corp", "summary": "m1"},
                {"mind_id": "a", "mind_name": "Acme Corp", "summary": "m2"},
                {"mind_id": "b", "mind_name": "Widget Co", "summary": "m3"},
            ],
        }
        # Build the provider the same way server.py does
        details = drain_result.get("details", [])
        recovered = drain_result["recovered"]
        by_mind = {}
        for d in details:
            name = d.get("mind_name", "unknown")
            by_mind.setdefault(name, 0)
            by_mind[name] += 1
        breakdown = ", ".join(f"{n} for {name}" for name, n in by_mind.items())
        message = f"Recovered {recovered} memories from a previous session ({breakdown})."

        fired = [False]

        def provider(db=None, customer_id=None):
            if not fired[0]:
                fired[0] = True
                return [{"type": "recovery", "message": message}]
            return []

        result1 = provider()
        assert len(result1) == 1
        assert "Recovered 3 memories" in result1[0]["message"]
        assert "Acme Corp" in result1[0]["message"]

        result2 = provider()
        assert len(result2) == 0


# ---------------------------------------------------------------------------
# TestCheckHealthPendingCount
# ---------------------------------------------------------------------------

class TestCheckHealthPendingCount:
    """Tests for pending_queue count in check_health output."""

    def test_check_health_includes_pending_count(self, temp_pending_dir):
        from coppermind_cmo.pending_queue import enqueue, count
        enqueue(_make_payload(content="Stuck memory 1"))
        enqueue(_make_payload(content="Stuck memory 2"))
        assert count() == 2
