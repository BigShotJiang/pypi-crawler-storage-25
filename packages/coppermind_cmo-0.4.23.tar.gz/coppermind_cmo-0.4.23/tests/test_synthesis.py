"""Tests for synthesis.py — second-pass document analysis engine."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from unittest.mock import MagicMock, patch, call

import pytest

from coppermind_cmo.synthesis import (
    SynthesisEngine,
    _parse_insights,
    _get_synthesis_prompt_template,
    _default_llm_call,
    _FALLBACK_SYNTHESIS_PROMPT,
    MAX_DOCUMENT_CHARS,
    MAX_PROMPT_CHARS,
    MIN_WORD_COUNT_AUTO,
    MIN_CONFIDENCE,
    MAX_INSIGHTS_PER_DOC,
    DEFAULT_DAILY_CAP_PER_MIND,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_LLM_RESPONSE = json.dumps([
    {
        "content": "Acme's budget has shifted from growth to cost optimization over the last 2 meetings",
        "memory_type": "fact",
        "confidence": 0.85,
        "evidence": "March meeting: 'invest in new channels'. April meeting: 'cut non-performing spend'",
    },
    {
        "content": "Previous memory states budget is $50K but April transcript says $30K",
        "memory_type": "fact",
        "confidence": 0.9,
        "evidence": "Direct contradiction between January and April budget references",
    },
])


@pytest.fixture
def active_mind():
    return ("test-mind-uuid", "Acme Corp")


@pytest.fixture
def mock_db():
    db = MagicMock()
    # Default: document found with sufficient word count
    doc_id = str(uuid.uuid4())
    db.fetch_one.return_value = (
        doc_id,
        "Meeting content with enough words to pass threshold " * 200,
        "source.txt",
        5000,
        1,
    )
    db.fetch_all.return_value = [
        ("fact", "Budget is $50K", datetime(2026, 3, 1)),
    ]
    db.execute.return_value = None

    # connection() context manager
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
    mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
    db.connection.return_value.__enter__ = lambda s: mock_conn
    db.connection.return_value.__exit__ = MagicMock(return_value=False)

    return db


@pytest.fixture
def mock_config():
    config = MagicMock()
    config.gateway_url = "https://api.coppermind.dev"
    config.api_key = "test-api-key"
    return config


@pytest.fixture
def mock_llm_fn():
    """LLM function that returns a valid JSON response."""
    def _llm_fn(config, prompt):
        return SAMPLE_LLM_RESPONSE
    return _llm_fn


@pytest.fixture
def mock_store_fn():
    """Store function that returns a successful memory_id."""
    call_log = []

    def _store_fn(**kwargs):
        call_log.append(kwargs)
        return {"memory_id": str(uuid.uuid4()), "status": "created"}

    _store_fn.calls = call_log
    return _store_fn


@pytest.fixture
def engine(mock_db, mock_config, active_mind, mock_llm_fn, mock_store_fn):
    """Pre-configured SynthesisEngine with all deps mocked."""
    eng = SynthesisEngine(
        db=mock_db,
        config=mock_config,
        active_mind=active_mind,
        store_fn=mock_store_fn,
        llm_fn=mock_llm_fn,
    )
    # Pre-cache the prompt template to avoid gateway calls
    eng._prompt_template = _FALLBACK_SYNTHESIS_PROMPT
    return eng


# ===========================================================================
# TestParseInsights
# ===========================================================================

class TestParseInsights:
    def test_parse_valid_json_array(self):
        raw = json.dumps([
            {"content": "Insight A", "memory_type": "fact", "confidence": 0.9},
            {"content": "Insight B", "memory_type": "decision", "confidence": 0.8},
        ])
        result = _parse_insights(raw)
        assert len(result) == 2
        assert result[0]["content"] == "Insight A"
        assert result[1]["content"] == "Insight B"

    def test_parse_empty_array(self):
        result = _parse_insights("[]")
        assert result == []

    def test_parse_empty_string(self):
        result = _parse_insights("")
        assert result == []

    def test_parse_none(self):
        result = _parse_insights(None)
        assert result == []

    def test_parse_whitespace_only(self):
        result = _parse_insights("   \n\t  ")
        assert result == []

    def test_parse_markdown_fenced_json(self):
        raw = '```json\n[{"content": "Fenced insight", "confidence": 0.9}]\n```'
        result = _parse_insights(raw)
        assert len(result) == 1
        assert result[0]["content"] == "Fenced insight"

    def test_parse_with_preamble(self):
        raw = (
            "Here are the insights I found:\n\n"
            '[{"content": "Preamble insight", "memory_type": "fact", "confidence": 0.8}]'
        )
        result = _parse_insights(raw)
        assert len(result) == 1
        assert result[0]["content"] == "Preamble insight"

    def test_parse_single_object(self):
        raw = json.dumps({"content": "Solo insight", "memory_type": "fact", "confidence": 0.85})
        result = _parse_insights(raw)
        assert len(result) == 1
        assert result[0]["content"] == "Solo insight"

    def test_parse_filters_missing_content(self):
        raw = json.dumps([
            {"content": "Valid", "confidence": 0.9},
            {"memory_type": "fact", "confidence": 0.8},  # no content
            {"content": "Also valid", "confidence": 0.7},
        ])
        result = _parse_insights(raw)
        assert len(result) == 2
        assert result[0]["content"] == "Valid"
        assert result[1]["content"] == "Also valid"

    def test_parse_invalid_json(self):
        result = _parse_insights("not json at all {broken")
        assert result == []

    def test_parse_dict_without_content_key(self):
        raw = json.dumps({"memory_type": "fact", "confidence": 0.8})
        result = _parse_insights(raw)
        assert result == []

    def test_parse_nested_json_in_text(self):
        """JSON array embedded after non-JSON text with other brackets."""
        raw = (
            'I found some patterns.\n'
            '[{"content": "Nested find", "memory_type": "fact", "confidence": 0.85}]'
        )
        result = _parse_insights(raw)
        assert len(result) == 1
        assert result[0]["content"] == "Nested find"


# ===========================================================================
# TestGetSynthesisPromptTemplate
# ===========================================================================

class TestGetSynthesisPromptTemplate:
    @patch("coppermind_cmo.synthesis.httpx.get")
    def test_returns_gateway_prompt_when_available(self, mock_get, mock_config):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "prompts": {"synthesis": "Custom gateway prompt for $client_name$"}
        }
        mock_get.return_value = mock_resp

        result = _get_synthesis_prompt_template(mock_config)
        assert result == "Custom gateway prompt for $client_name$"

    @patch("coppermind_cmo.synthesis.httpx.get")
    def test_fallback_on_non_200(self, mock_get, mock_config):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_get.return_value = mock_resp

        result = _get_synthesis_prompt_template(mock_config)
        assert result == _FALLBACK_SYNTHESIS_PROMPT

    @patch("coppermind_cmo.synthesis.httpx.get")
    def test_fallback_on_network_error(self, mock_get, mock_config):
        mock_get.side_effect = ConnectionError("network down")

        result = _get_synthesis_prompt_template(mock_config)
        assert result == _FALLBACK_SYNTHESIS_PROMPT

    @patch("coppermind_cmo.synthesis.httpx.get")
    def test_fallback_when_no_synthesis_key_in_prompts(self, mock_get, mock_config):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"prompts": {"other": "something"}}
        mock_get.return_value = mock_resp

        result = _get_synthesis_prompt_template(mock_config)
        assert result == _FALLBACK_SYNTHESIS_PROMPT


# ===========================================================================
# TestDefaultLlmCall
# ===========================================================================

class TestDefaultLlmCall:
    @patch("coppermind_cmo.synthesis.httpx.post")
    def test_success_returns_text(self, mock_post, mock_config):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"text": "LLM response text"}
        mock_post.return_value = mock_resp

        result = _default_llm_call(mock_config, "test prompt")
        assert result == "LLM response text"

        mock_post.assert_called_once_with(
            f"{mock_config.gateway_url}/v1/synthesize",
            json={"prompt": "test prompt"},
            headers={
                "Authorization": f"Bearer {mock_config.api_key}",
                "Content-Type": "application/json",
            },
            timeout=120,
        )

    @patch("coppermind_cmo.synthesis.httpx.post")
    def test_non_200_returns_none(self, mock_post, mock_config):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text = "Internal Server Error"
        mock_post.return_value = mock_resp

        result = _default_llm_call(mock_config, "test prompt")
        assert result is None

    @patch("coppermind_cmo.synthesis.httpx.post")
    def test_exception_returns_none(self, mock_post, mock_config):
        mock_post.side_effect = ConnectionError("timeout")

        result = _default_llm_call(mock_config, "test prompt")
        assert result is None


# ===========================================================================
# TestBuildSynthesisPrompt
# ===========================================================================

class TestBuildSynthesisPrompt:
    def test_basic_substitution(self, engine):
        prompt = engine._build_synthesis_prompt(
            "Document content here",
            [{"memory_type": "fact", "content": "Budget is 50K", "date": "2026-03-01"}],
        )
        assert prompt is not None
        assert "Acme Corp" in prompt
        assert "Document content here" in prompt
        assert "[fact] Budget is 50K (2026-03-01)" in prompt

    def test_client_name_sanitization(self, mock_db, mock_config, mock_llm_fn, mock_store_fn):
        """Dollar signs in client name are stripped to prevent $variable$ interference."""
        eng = SynthesisEngine(
            db=mock_db,
            config=mock_config,
            active_mind=("id", "$Money$ Corp"),
            store_fn=mock_store_fn,
            llm_fn=mock_llm_fn,
        )
        eng._prompt_template = _FALLBACK_SYNTHESIS_PROMPT

        prompt = eng._build_synthesis_prompt("Doc text", [])
        assert prompt is not None
        assert "Money Corp" in prompt
        assert "$Money$" not in prompt

    def test_document_truncation(self, engine):
        """Long documents get truncated to MAX_DOCUMENT_CHARS (kept from the end)."""
        long_doc = "x" * (MAX_DOCUMENT_CHARS + 5000)
        prompt = engine._build_synthesis_prompt(long_doc, [])
        assert prompt is not None
        assert f"[Document truncated to last {MAX_DOCUMENT_CHARS:,} characters]" in prompt

    def test_xml_tag_sanitization(self, engine):
        """Closing XML tags in document content are escaped to prevent prompt injection."""
        dangerous_doc = "Content with </document> and </existing_memories> tags"
        prompt = engine._build_synthesis_prompt(dangerous_doc, [])
        assert prompt is not None
        assert "</document>" not in prompt.split("<document>")[1].split("</document>")[0] if "<document>" in prompt else True
        assert "&lt;/document&gt;" in prompt
        assert "&lt;/existing_memories&gt;" in prompt

    def test_existing_memories_formatting(self, engine):
        memories = [
            {"memory_type": "fact", "content": "Budget is 50K", "date": "2026-03-01"},
            {"memory_type": "decision", "content": "Hired new CMO", "date": "2026-02-15"},
        ]
        prompt = engine._build_synthesis_prompt("Doc text", memories)
        assert "[fact] Budget is 50K (2026-03-01)" in prompt
        assert "[decision] Hired new CMO (2026-02-15)" in prompt

    def test_returns_none_when_too_large(self, engine):
        """Returns None when prompt exceeds MAX_PROMPT_CHARS even after memory truncation."""
        # Make a document that is just barely under MAX_DOCUMENT_CHARS but combined
        # with template exceeds MAX_PROMPT_CHARS
        huge_doc = "A" * (MAX_PROMPT_CHARS + 10000)
        result = engine._build_synthesis_prompt(huge_doc, [])
        # The document is truncated to MAX_DOCUMENT_CHARS first, so it should still fit
        # unless we make both huge. Let's use a huge template instead.
        engine._prompt_template = "X" * (MAX_PROMPT_CHARS + 1) + "$client_name$$document_text$$existing_memories$"
        result = engine._build_synthesis_prompt("doc", [])
        assert result is None

    def test_missing_date_in_memory(self, engine):
        """Memories with empty date fields still format correctly."""
        memories = [
            {"memory_type": "fact", "content": "Some fact", "date": ""},
        ]
        prompt = engine._build_synthesis_prompt("Doc text", memories)
        assert "[fact] Some fact ()" in prompt

    def test_missing_fields_in_memory_use_defaults(self, engine):
        """Memories with missing keys use 'fact' and empty string defaults."""
        memories = [{}]
        prompt = engine._build_synthesis_prompt("Doc text", memories)
        assert "[fact]  ()" in prompt


# ===========================================================================
# TestFetchExistingMemories
# ===========================================================================

class TestFetchExistingMemories:
    def test_returns_formatted_list(self, engine, mock_db):
        mock_db.fetch_all.return_value = [
            ("fact", "Budget is $50K", datetime(2026, 3, 1)),
            ("decision", "Hired new CMO", datetime(2026, 2, 15)),
        ]
        result = engine._fetch_existing_memories()
        assert len(result) == 2
        assert result[0]["memory_type"] == "fact"
        assert result[0]["content"] == "Budget is $50K"
        assert result[0]["date"] == "2026-03-01"
        assert result[1]["memory_type"] == "decision"
        assert result[1]["date"] == "2026-02-15"

    def test_empty_results(self, engine, mock_db):
        mock_db.fetch_all.return_value = []
        result = engine._fetch_existing_memories()
        assert result == []

    def test_queries_with_correct_mind_id(self, engine, mock_db):
        mock_db.fetch_all.return_value = []
        engine._fetch_existing_memories(limit=50)
        mock_db.fetch_all.assert_called_once()
        args = mock_db.fetch_all.call_args
        assert engine.mind_id in args[0][1]
        assert 50 in args[0][1]

    def test_handles_none_date(self, engine, mock_db):
        mock_db.fetch_all.return_value = [
            ("fact", "No date memory", None),
        ]
        result = engine._fetch_existing_memories()
        assert len(result) == 1
        assert result[0]["date"] == ""


# ===========================================================================
# TestCheckDailyCap
# ===========================================================================

class TestCheckDailyCap:
    def test_under_cap_returns_true(self, engine, mock_db):
        mock_db.fetch_one.return_value = (5,)
        assert engine._check_daily_cap() is True

    def test_at_cap_returns_false(self, engine, mock_db):
        mock_db.fetch_one.return_value = (DEFAULT_DAILY_CAP_PER_MIND,)
        assert engine._check_daily_cap() is False

    def test_over_cap_returns_false(self, engine, mock_db):
        mock_db.fetch_one.return_value = (DEFAULT_DAILY_CAP_PER_MIND + 5,)
        assert engine._check_daily_cap() is False

    def test_none_row_returns_true(self, engine, mock_db):
        mock_db.fetch_one.return_value = None
        assert engine._check_daily_cap() is True

    def test_custom_cap_env_var(self, engine, mock_db, monkeypatch):
        monkeypatch.setenv("COPPERMIND_SYNTHESIS_DAILY_CAP", "3")
        mock_db.fetch_one.return_value = (3,)
        assert engine._check_daily_cap() is False

        mock_db.fetch_one.return_value = (2,)
        assert engine._check_daily_cap() is True


# ===========================================================================
# TestSynthesizeDocument
# ===========================================================================

class TestSynthesizeDocument:
    def test_successful_synthesis(self, engine, mock_db, mock_store_fn):
        """Full happy path: doc found, LLM returns insights, memories stored."""
        # Set up daily cap check to return under cap
        mock_db.fetch_one.side_effect = [
            # First call: fetch document
            (
                str(uuid.uuid4()),
                "Long meeting content " * 500,
                "source.txt",
                5000,
                1,
            ),
            # Second call: daily cap check
            (0,),
        ]

        result = engine.synthesize_document("test-doc-id")

        assert "error" not in result
        assert result["insights"] == 2
        assert result["memories_created"] == 2
        assert result["document"] == "source.txt"
        assert len(result["insights_list"]) == 2
        assert "duration_ms" in result

    def test_document_not_found(self, engine, mock_db):
        mock_db.fetch_one.return_value = None
        result = engine.synthesize_document("nonexistent-doc")
        assert result["error"] == "NO_DOCUMENTS"

    def test_short_document_skipped(self, engine, mock_db):
        """Documents under MIN_WORD_COUNT_AUTO are skipped when not forced."""
        mock_db.fetch_one.return_value = (
            str(uuid.uuid4()),
            "Short doc",
            "short.txt",
            500,  # under MIN_WORD_COUNT_AUTO
            0,
        )
        result = engine.synthesize_document("short-doc-id")
        assert result.get("skipped") is True
        assert result["reason"] == "document_too_short"
        assert result["word_count"] == 500

    def test_short_document_with_force(self, engine, mock_db, mock_store_fn):
        """force=True bypasses minimum word count check."""
        mock_db.fetch_one.side_effect = [
            # Document fetch (short)
            (str(uuid.uuid4()), "Short doc", "short.txt", 500, 0),
            # No daily cap check when force=True
        ]

        result = engine.synthesize_document("short-doc-id", force=True)
        assert result.get("skipped") is not True
        assert "error" not in result or result.get("error") != "document_too_short"

    def test_daily_cap_reached(self, engine, mock_db):
        """Returns DAILY_CAP_REACHED when cap is hit."""
        mock_db.fetch_one.side_effect = [
            # Document fetch
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            # Daily cap check: at cap
            (DEFAULT_DAILY_CAP_PER_MIND,),
        ]

        result = engine.synthesize_document("doc-id")
        assert result["error"] == "DAILY_CAP_REACHED"

    def test_daily_cap_bypassed_with_force(self, engine, mock_db, mock_store_fn):
        """force=True bypasses the daily cap check entirely."""
        mock_db.fetch_one.side_effect = [
            # Document fetch
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            # Daily cap would be checked but force=True skips it
        ]

        result = engine.synthesize_document("doc-id", force=True)
        assert result.get("error") != "DAILY_CAP_REACHED"

    def test_llm_unavailable(self, engine, mock_db):
        """llm_fn returning None results in LLM_UNAVAILABLE error."""
        mock_db.fetch_one.side_effect = [
            # Document fetch
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            # Daily cap check: under cap
            (0,),
        ]
        engine.llm_fn = lambda config, prompt: None

        result = engine.synthesize_document("doc-id")
        assert result["error"] == "LLM_UNAVAILABLE"

    def test_no_insights_found(self, engine, mock_db, mock_store_fn):
        """LLM returns empty array -- 0 memories created."""
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]
        engine.llm_fn = lambda config, prompt: "[]"

        result = engine.synthesize_document("doc-id")
        assert result["insights"] == 0
        assert result["memories_created"] == 0
        assert len(mock_store_fn.calls) == 0

    def test_confidence_filtering(self, engine, mock_db, mock_store_fn):
        """Insights below MIN_CONFIDENCE (0.7) are filtered out."""
        low_confidence_response = json.dumps([
            {"content": "High confidence", "memory_type": "fact", "confidence": 0.9},
            {"content": "Low confidence", "memory_type": "fact", "confidence": 0.5},
            {"content": "Borderline low", "memory_type": "fact", "confidence": 0.69},
            {"content": "Borderline high", "memory_type": "fact", "confidence": 0.7},
        ])
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]
        engine.llm_fn = lambda config, prompt: low_confidence_response

        result = engine.synthesize_document("doc-id")
        # Only the 0.9 and 0.7 pass (>= MIN_CONFIDENCE)
        assert result["insights"] == 2
        assert result["memories_created"] == 2

    def test_contradiction_tagging(self, engine, mock_db, mock_store_fn):
        """Insights containing 'contradict' in content get a contradiction tag."""
        contradiction_response = json.dumps([
            {
                "content": "This contradicts the previous budget statement",
                "memory_type": "fact",
                "confidence": 0.9,
            },
            {
                "content": "Normal insight without the keyword",
                "memory_type": "fact",
                "confidence": 0.85,
            },
        ])
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]
        engine.llm_fn = lambda config, prompt: contradiction_response

        result = engine.synthesize_document("doc-id")
        assert result["contradictions"] == 1

        # Check the store_fn was called with correct tags
        contradiction_call = mock_store_fn.calls[0]
        assert "contradiction" in contradiction_call["tags"]
        assert "synthesis" in contradiction_call["tags"]

        normal_call = mock_store_fn.calls[1]
        assert "synthesis" in normal_call["tags"]
        assert "contradiction" not in normal_call["tags"]

    def test_store_fn_called_with_correct_args(self, engine, mock_db, mock_store_fn):
        """Verify store_fn receives correct source_type and source_ref."""
        doc_id = "test-doc-123"
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]

        result = engine.synthesize_document(doc_id)
        assert len(mock_store_fn.calls) == 2  # 2 insights from SAMPLE_LLM_RESPONSE

        for stored_call in mock_store_fn.calls:
            assert stored_call["source_type"] == "synthesis"
            assert stored_call["source_ref"] == f"synthesis:{doc_id}"
            assert stored_call["db"] is mock_db
            assert stored_call["config"] is engine.config
            assert stored_call["active_mind"] == engine.active_mind
            assert "tags" in stored_call
            assert "synthesis" in stored_call["tags"]

    def test_max_insights_cap(self, engine, mock_db, mock_store_fn):
        """Only MAX_INSIGHTS_PER_DOC insights are stored even if LLM returns more."""
        many_insights = json.dumps([
            {"content": f"Insight {i}", "memory_type": "fact", "confidence": 0.9}
            for i in range(MAX_INSIGHTS_PER_DOC + 5)
        ])
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]
        engine.llm_fn = lambda config, prompt: many_insights

        result = engine.synthesize_document("doc-id")
        assert result["insights"] == MAX_INSIGHTS_PER_DOC
        assert len(mock_store_fn.calls) == MAX_INSIGHTS_PER_DOC

    def test_null_word_count_uses_content_split(self, engine, mock_db, mock_store_fn):
        """When word_count is None, the result falls back to len(content.split())."""
        content = "word " * 2000
        mock_db.fetch_one.side_effect = [
            (str(uuid.uuid4()), content, "doc.txt", None, 0),
            (0,),
        ]

        result = engine.synthesize_document("doc-id")
        # word_count=None does not trigger short-doc skip (None < 1000 is False in Python)
        # but the result should use len(content.split()) as fallback
        assert result.get("word_count") == len(content.split())

    def test_extraction_pass_incremented(self, mock_config, mock_store_fn):
        """After synthesis, extraction_passes is incremented via db.execute()."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            (str(uuid.uuid4()), "Content " * 500, "doc.txt", 5000, 1),
            (0,),
        ]
        db.fetch_all.return_value = []

        eng = SynthesisEngine(
            db=db, config=mock_config,
            active_mind=("test-mind-uuid", "Acme Corp"),
            store_fn=mock_store_fn,
            llm_fn=lambda config, prompt: SAMPLE_LLM_RESPONSE,
        )
        eng._prompt_template = _FALLBACK_SYNTHESIS_PROMPT

        eng.synthesize_document("doc-id")

        # db.execute should have been called with UPDATE raw_documents
        execute_calls = db.execute.call_args_list
        update_calls = [c for c in execute_calls
                        if "extraction_passes" in str(c)]
        assert len(update_calls) == 1
        update_sql = update_calls[0][0][0]
        assert "UPDATE raw_documents" in update_sql


# ===========================================================================
# TestProcessQueue
# ===========================================================================

class TestProcessQueue:
    @staticmethod
    def _setup_queue_mock(mock_db, queue_rows):
        """Set up db.connection() mock for FOR UPDATE SKIP LOCKED queue claiming."""
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = queue_rows
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_db.connection.return_value.__exit__ = MagicMock(return_value=False)
        return mock_cursor

    def test_empty_queue(self, engine, mock_db):
        self._setup_queue_mock(mock_db, [])
        result = engine.process_queue()
        assert result["documents_processed"] == 0
        assert result["insights_found"] == 0

    def test_processes_pending_items(self, engine, mock_db, mock_store_fn):
        """Queue items are claimed with FOR UPDATE SKIP LOCKED, synthesized, then completed."""
        queue_id = str(uuid.uuid4())
        raw_doc_id = str(uuid.uuid4())

        self._setup_queue_mock(mock_db, [(queue_id, raw_doc_id, 0)])

        # fetch_one calls: document fetch + daily cap check (from synthesize_document)
        mock_db.fetch_one.side_effect = [
            (raw_doc_id, "Content " * 500, "doc.txt", 5000, 1),  # document fetch
            (0,),  # daily cap check
        ]
        # fetch_all: existing memories (from synthesize_document)
        mock_db.fetch_all.return_value = [("fact", "Existing memory", datetime(2026, 3, 1))]

        result = engine.process_queue()

        assert result["documents_processed"] == 1
        assert result["insights_found"] == 2  # from SAMPLE_LLM_RESPONSE

    def test_synthesis_disabled(self, engine, mock_db, monkeypatch):
        """COPPERMIND_SYNTHESIS_ENABLED=false returns paused."""
        monkeypatch.setenv("COPPERMIND_SYNTHESIS_ENABLED", "false")

        result = engine.process_queue()
        assert result["paused"] is True
        assert result["documents_processed"] == 0

    def test_synthesis_disabled_case_insensitive(self, engine, mock_db, monkeypatch):
        monkeypatch.setenv("COPPERMIND_SYNTHESIS_ENABLED", "False")

        result = engine.process_queue()
        assert result["paused"] is True

    def test_failed_item_retries(self, engine, mock_db):
        """Error increments attempts and keeps item pending."""
        queue_id = str(uuid.uuid4())
        raw_doc_id = str(uuid.uuid4())

        self._setup_queue_mock(mock_db, [(queue_id, raw_doc_id, 0)])

        mock_db.fetch_one.return_value = None  # document not found -> error
        mock_db.fetch_all.return_value = []  # no existing memories

        result = engine.process_queue()

        # Should have set status back to pending with incremented attempts
        execute_calls = mock_db.execute.call_args_list
        retry_calls = [c for c in execute_calls if "pending" in str(c) and "attempts" in str(c)]
        assert len(retry_calls) >= 1

    def test_max_retries_marks_failed(self, engine, mock_db):
        """After 3 attempts, item is marked as failed."""
        queue_id = str(uuid.uuid4())
        raw_doc_id = str(uuid.uuid4())

        self._setup_queue_mock(mock_db, [(queue_id, raw_doc_id, 2)])  # attempts=2

        mock_db.fetch_one.return_value = None  # document not found -> error
        mock_db.fetch_all.return_value = []

        result = engine.process_queue()

        # Should have a call marking as 'failed'
        execute_calls = mock_db.execute.call_args_list
        failed_calls = [c for c in execute_calls if "failed" in str(c)]
        assert len(failed_calls) >= 1

    def test_skipped_items_marked_correctly(self, engine, mock_db):
        """Skipped documents (too short) get status='skipped' in queue."""
        queue_id = str(uuid.uuid4())
        raw_doc_id = str(uuid.uuid4())

        self._setup_queue_mock(mock_db, [(queue_id, raw_doc_id, 0)])

        mock_db.fetch_one.return_value = (
            raw_doc_id, "Short", "short.txt", 100, 0,
        )
        mock_db.fetch_all.return_value = []

        result = engine.process_queue()

        execute_calls = mock_db.execute.call_args_list
        skipped_calls = [c for c in execute_calls if "skipped" in str(c)]
        assert len(skipped_calls) >= 1

    def test_exception_during_synthesis_increments_attempts(self, engine, mock_db):
        """Exceptions during synthesis increment attempts without crashing the queue."""
        queue_id = str(uuid.uuid4())
        raw_doc_id = str(uuid.uuid4())

        self._setup_queue_mock(mock_db, [(queue_id, raw_doc_id, 0)])

        # Make synthesize_document raise by having fetch_one raise
        mock_db.fetch_one.side_effect = RuntimeError("DB connection lost")
        mock_db.fetch_all.return_value = []

        # Should not raise
        result = engine.process_queue()

        execute_calls = mock_db.execute.call_args_list
        retry_calls = [c for c in execute_calls if "attempts" in str(c)]
        assert len(retry_calls) >= 1


# ===========================================================================
# TestSynthesizeDocumentTool
# ===========================================================================

class TestSynthesizeDocumentTool:
    """Tests for the MCP tool wrapper in tools/synthesis.py.

    The tool function imports get_db, get_config, etc. inside register(),
    so we patch at the source module (coppermind_cmo.server) and call
    register() inside each patch context to capture the inner function.
    """

    def _register_and_capture(self):
        """Helper: call register() with a mock server, return the captured tool fn."""
        from coppermind_cmo.tools.synthesis import register

        mock_server = MagicMock()
        captured = {}

        def capture_tool():
            def decorator(fn):
                captured["fn"] = fn
                return fn
            return decorator

        mock_server.tool = capture_tool
        with patch("coppermind_cmo.resilience.safe_tool_call", lambda name: lambda fn: fn):
            register(mock_server)

        return captured["fn"]

    @patch("coppermind_cmo.background.attach_notifications", side_effect=lambda r, **kw: r)
    @patch("coppermind_cmo.server.get_customer_id", return_value="cust-123")
    @patch("coppermind_cmo.server.get_active_mind", return_value=("mind-id", "Acme Corp"))
    @patch("coppermind_cmo.server.get_config")
    @patch("coppermind_cmo.server.get_db")
    @patch("coppermind_cmo.server.set_last_tool_call")
    def test_latest_scope_queries_one_doc(
        self, mock_set, mock_get_db, mock_get_config, mock_get_mind,
        mock_get_cust, mock_attach,
    ):
        db = MagicMock()
        db.fetch_all.return_value = [("doc-id-1",)]
        mock_get_db.return_value = db
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.dev"
        config.api_key = "key"
        mock_get_config.return_value = config

        with patch("coppermind_cmo.synthesis.SynthesisEngine") as MockEngine:
            mock_engine = MagicMock()
            mock_engine.synthesize_document.return_value = {
                "document": "doc.txt",
                "word_count": 5000,
                "insights": 2,
                "memories_created": 2,
                "contradictions": 0,
                "insights_list": ["A", "B"],
                "duration_ms": 100,
            }
            MockEngine.return_value = mock_engine

            tool_fn = self._register_and_capture()
            result = tool_fn(scope="latest")

            assert result["documents_processed"] == 1
            assert result["insights_found"] == 2

    @patch("coppermind_cmo.background.attach_notifications", side_effect=lambda r, **kw: r)
    @patch("coppermind_cmo.server.get_customer_id", return_value="cust-123")
    @patch("coppermind_cmo.server.get_active_mind", return_value=None)
    @patch("coppermind_cmo.server.get_config")
    @patch("coppermind_cmo.server.get_db")
    @patch("coppermind_cmo.server.set_last_tool_call")
    def test_no_active_mind_returns_error(
        self, mock_set, mock_get_db, mock_get_config, mock_get_mind,
        mock_get_cust, mock_attach,
    ):
        tool_fn = self._register_and_capture()
        result = tool_fn()
        assert result["error"] == "NO_ACTIVE_MIND"

    @patch("coppermind_cmo.background.attach_notifications", side_effect=lambda r, **kw: r)
    @patch("coppermind_cmo.server.get_customer_id", return_value="cust-123")
    @patch("coppermind_cmo.server.get_active_mind", return_value=("mind-id", "Acme Corp"))
    @patch("coppermind_cmo.server.get_config")
    @patch("coppermind_cmo.server.get_db")
    @patch("coppermind_cmo.server.set_last_tool_call")
    def test_invalid_scope_returns_error(
        self, mock_set, mock_get_db, mock_get_config, mock_get_mind,
        mock_get_cust, mock_attach,
    ):
        db = MagicMock()
        mock_get_db.return_value = db

        tool_fn = self._register_and_capture()
        result = tool_fn(scope="bogus")
        assert result["error"] == "INVALID_SCOPE"

    @patch("coppermind_cmo.background.attach_notifications", side_effect=lambda r, **kw: r)
    @patch("coppermind_cmo.server.get_customer_id", return_value="cust-123")
    @patch("coppermind_cmo.server.get_active_mind", return_value=("mind-id", "Acme Corp"))
    @patch("coppermind_cmo.server.get_config")
    @patch("coppermind_cmo.server.get_db")
    @patch("coppermind_cmo.server.set_last_tool_call")
    def test_no_documents_returns_error(
        self, mock_set, mock_get_db, mock_get_config, mock_get_mind,
        mock_get_cust, mock_attach,
    ):
        db = MagicMock()
        db.fetch_all.return_value = []  # no documents
        mock_get_db.return_value = db

        tool_fn = self._register_and_capture()
        result = tool_fn(scope="latest")
        assert result["error"] == "NO_DOCUMENTS"

    @patch("coppermind_cmo.background.attach_notifications", side_effect=lambda r, **kw: r)
    @patch("coppermind_cmo.server.get_customer_id", return_value="cust-123")
    @patch("coppermind_cmo.server.get_active_mind")
    @patch("coppermind_cmo.server.get_config")
    @patch("coppermind_cmo.server.get_db")
    @patch("coppermind_cmo.server.set_last_tool_call")
    def test_mind_name_resolution(
        self, mock_set, mock_get_db, mock_get_config, mock_get_mind,
        mock_get_cust, mock_attach,
    ):
        """When mind_name is provided, it resolves via DB lookup."""
        db = MagicMock()
        # First fetch_one: mind resolution
        db.fetch_one.return_value = ("resolved-mind-id", "Custom Mind")
        # fetch_all: no documents to simplify
        db.fetch_all.return_value = []
        mock_get_db.return_value = db
        config = MagicMock()
        mock_get_config.return_value = config

        tool_fn = self._register_and_capture()
        result = tool_fn(mind_name="Custom Mind")
        # Should have attempted mind resolution
        assert db.fetch_one.called


# ===========================================================================
# TestSynthesisEngineInit
# ===========================================================================

class TestSynthesisEngineInit:
    def test_stores_mind_info(self, mock_db, mock_config):
        eng = SynthesisEngine(
            db=mock_db, config=mock_config,
            active_mind=("mind-123", "Test Corp"),
        )
        assert eng.mind_id == "mind-123"
        assert eng.mind_name == "Test Corp"
        assert eng.active_mind == ("mind-123", "Test Corp")

    def test_injectable_llm_fn(self, mock_db, mock_config):
        custom_llm = lambda config, prompt: "custom"
        eng = SynthesisEngine(
            db=mock_db, config=mock_config,
            active_mind=("id", "name"),
            llm_fn=custom_llm,
        )
        assert eng.llm_fn is custom_llm

    def test_injectable_store_fn(self, mock_db, mock_config):
        custom_store = lambda **kwargs: {"memory_id": "x"}
        eng = SynthesisEngine(
            db=mock_db, config=mock_config,
            active_mind=("id", "name"),
            store_fn=custom_store,
        )
        assert eng.store_fn is custom_store

    def test_default_llm_fn_is_module_default(self, mock_db, mock_config):
        eng = SynthesisEngine(
            db=mock_db, config=mock_config,
            active_mind=("id", "name"),
        )
        assert eng.llm_fn is _default_llm_call

    def test_prompt_template_caching(self, engine):
        """_get_prompt_template caches after first call."""
        template1 = engine._get_prompt_template()
        template2 = engine._get_prompt_template()
        assert template1 is template2
