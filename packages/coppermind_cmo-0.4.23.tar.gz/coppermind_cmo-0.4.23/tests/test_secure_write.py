"""Tests for secure_write atomic write behavior."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from coppermind_cmo.utils import secure_write


def test_secure_write_creates_file(tmp_path):
    target = tmp_path / "test.json"
    secure_write(target, '{"key": "value"}')
    assert target.read_text() == '{"key": "value"}'


def test_secure_write_sets_permissions(tmp_path):
    target = tmp_path / "secret.json"
    secure_write(target, "data")
    mode = oct(target.stat().st_mode & 0o777)
    assert mode == "0o600"


def test_secure_write_creates_parent_dirs(tmp_path):
    target = tmp_path / "a" / "b" / "file.txt"
    secure_write(target, "nested")
    assert target.read_text() == "nested"


def test_secure_write_overwrites_existing(tmp_path):
    target = tmp_path / "overwrite.json"
    secure_write(target, "old")
    secure_write(target, "new")
    assert target.read_text() == "new"


def test_secure_write_no_temp_file_left_on_success(tmp_path):
    target = tmp_path / "clean.json"
    secure_write(target, "data")
    files = list(tmp_path.iterdir())
    assert files == [target], f"Unexpected files: {files}"


def test_secure_write_no_corruption_on_replace_failure(tmp_path):
    """If os.replace fails, original file should be intact."""
    target = tmp_path / "safe.json"
    secure_write(target, "original")

    with patch("coppermind_cmo.utils.os.replace", side_effect=OSError("disk full")):
        with pytest.raises(OSError, match="disk full"):
            secure_write(target, "corrupted")

    # Original content must survive
    assert target.read_text() == "original"
    # No temp files left behind
    files = list(tmp_path.iterdir())
    assert files == [target]
