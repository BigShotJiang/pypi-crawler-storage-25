"""Tests for per-type memory decay tuning."""

import pytest
from datetime import datetime, timedelta, timezone

from coppermind_cmo.memory_types import (
    DEFAULT_DECAY_RATES,
    get_decay_config,
    _DEFAULT_DECAY,
)
from coppermind_cmo.tools.memories import _apply_recency_bias


class TestGetDecayConfig:
    """Tests for get_decay_config()."""

    def test_known_types_return_correct_rates(self):
        rate, floor = get_decay_config("decision")
        assert rate == 0.3
        assert floor == 0.7

    def test_commitment_decays_fast(self):
        rate, floor = get_decay_config("commitment")
        assert rate == 2.0
        assert floor == 0.3

    def test_preference_decays_slow(self):
        rate, floor = get_decay_config("preference")
        assert rate == 0.2
        assert floor == 0.8

    def test_unknown_type_falls_back_to_fact(self):
        rate, floor = get_decay_config("unknown_type")
        assert rate == _DEFAULT_DECAY["rate"]
        assert floor == _DEFAULT_DECAY["floor"]

    def test_override_takes_priority(self):
        overrides = {"decision": {"rate": 0.1, "floor": 0.9}}
        rate, floor = get_decay_config("decision", decay_overrides=overrides)
        assert rate == 0.1
        assert floor == 0.9

    def test_override_doesnt_affect_other_types(self):
        overrides = {"decision": {"rate": 0.1, "floor": 0.9}}
        rate, floor = get_decay_config("commitment", decay_overrides=overrides)
        assert rate == 2.0  # default, not overridden

    def test_all_valid_types_have_decay_rates(self):
        from coppermind_cmo.memory_types import VALID_MEMORY_TYPES
        for t in VALID_MEMORY_TYPES:
            assert t in DEFAULT_DECAY_RATES, f"Missing decay rate for type: {t}"

    def test_partial_override_fills_defaults(self):
        """Override with only rate still gets default floor."""
        overrides = {"fact": {"rate": 0.5}}
        rate, floor = get_decay_config("fact", decay_overrides=overrides)
        assert rate == 0.5
        assert floor == 0.5  # default floor


class TestApplyRecencyBiasPerType:
    """Tests for per-type decay in _apply_recency_bias()."""

    def _make_result(self, memory_type, age_days, similarity=0.8):
        created_at = (datetime.now(timezone.utc) - timedelta(days=age_days)).isoformat()
        return {
            "similarity": similarity,
            "created_at": created_at,
            "memory_type": memory_type,
        }

    def test_decision_retains_more_than_fact_at_same_age(self):
        """A 6-month-old decision should score higher than a 6-month-old fact."""
        results = [
            self._make_result("fact", 180),
            self._make_result("decision", 180),
        ]
        _apply_recency_bias(results)

        decision = next(r for r in results if r["memory_type"] == "decision")
        fact = next(r for r in results if r["memory_type"] == "fact")
        assert decision["adjusted_similarity"] > fact["adjusted_similarity"]

    def test_commitment_decays_faster_than_decision(self):
        """A 3-month-old commitment should score lower than a 3-month-old decision."""
        results = [
            self._make_result("commitment", 90),
            self._make_result("decision", 90),
        ]
        _apply_recency_bias(results)

        commitment = next(r for r in results if r["memory_type"] == "commitment")
        decision = next(r for r in results if r["memory_type"] == "decision")
        assert decision["adjusted_similarity"] > commitment["adjusted_similarity"]

    def test_preference_decays_slowest(self):
        """Preferences have the slowest decay rate (0.2/year)."""
        results = [
            self._make_result("preference", 365),
            self._make_result("fact", 365),
        ]
        _apply_recency_bias(results)

        preference = next(r for r in results if r["memory_type"] == "preference")
        fact = next(r for r in results if r["memory_type"] == "fact")
        assert preference["adjusted_similarity"] > fact["adjusted_similarity"]

    def test_very_old_memory_hits_floor(self):
        """A 5-year-old decision floors at 0.7, not zero."""
        results = [self._make_result("decision", 1825)]  # 5 years
        _apply_recency_bias(results)

        # decision floor = 0.7, similarity = 0.8 -> adjusted = 0.8 * 0.7 = 0.56
        assert results[0]["adjusted_similarity"] == round(0.8 * 0.7, 4)

    def test_commitment_floor(self):
        """Very old commitment floors at 0.3."""
        results = [self._make_result("commitment", 1000)]
        _apply_recency_bias(results)
        assert results[0]["adjusted_similarity"] == round(0.8 * 0.3, 4)

    def test_new_memory_no_decay(self):
        """A brand new memory (0 days) has no decay regardless of type."""
        for mem_type in ["decision", "commitment", "fact", "preference"]:
            results = [self._make_result(mem_type, 0)]
            _apply_recency_bias(results)
            assert results[0]["adjusted_similarity"] == 0.8

    def test_override_changes_decay(self):
        """Per-client overrides change the decay behavior."""
        overrides = {"commitment": {"rate": 0.5, "floor": 0.7}}  # much slower decay
        results = [
            self._make_result("commitment", 180),
        ]
        _apply_recency_bias(results, decay_overrides=overrides)

        # With rate=0.5: decay = max(0.7, 1.0 - (180/365 * 0.5)) = max(0.7, 0.7534) = 0.7534
        # adjusted = 0.8 * 0.7534 = 0.6027
        assert results[0]["adjusted_similarity"] > 0.55  # much higher than default commitment decay

    def test_sorts_by_adjusted_similarity(self):
        """Results are re-sorted by adjusted_similarity descending."""
        results = [
            self._make_result("commitment", 200, similarity=0.9),  # decays fast
            self._make_result("preference", 200, similarity=0.7),   # decays slow
        ]
        _apply_recency_bias(results)

        # Despite lower original similarity, preference may rank higher due to slow decay
        # preference: 0.7 * max(0.8, 1-200/365*0.2) = 0.7 * max(0.8, 0.8904) = 0.7 * 0.8904 = 0.6233
        # commitment: 0.9 * max(0.3, 1-200/365*2.0) = 0.9 * max(0.3, -0.0959) = 0.9 * 0.3 = 0.27
        assert results[0]["memory_type"] == "preference"

    def test_missing_memory_type_uses_fact_default(self):
        """Results without memory_type use fact decay rate."""
        created_at = (datetime.now(timezone.utc) - timedelta(days=365)).isoformat()
        results = [{"similarity": 0.8, "created_at": created_at}]  # no memory_type
        _apply_recency_bias(results)
        # fact: rate=1.0, floor=0.5 -> max(0.5, 1.0 - 1.0) = 0.5
        assert results[0]["adjusted_similarity"] == round(0.8 * 0.5, 4)

    def test_backward_compatible_no_args(self):
        """Calling without decay_overrides still works (backward compat)."""
        results = [self._make_result("fact", 100)]
        _apply_recency_bias(results)
        assert "adjusted_similarity" in results[0]
        assert "age_days" in results[0]

    def test_empty_list(self):
        """Empty list returns empty list."""
        assert _apply_recency_bias([]) == []
