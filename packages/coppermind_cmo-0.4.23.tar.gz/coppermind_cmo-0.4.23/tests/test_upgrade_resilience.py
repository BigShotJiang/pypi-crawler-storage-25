"""Tests for upgrade resilience: server config, version check, server-side prompts, skill install."""

import hashlib
import importlib.resources
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, PropertyMock

import pytest

from coppermind_cmo.config import (
    Config, ServerConfig, fetch_server_config, get_server_config,
)

# Grab a reference to the REAL _install_skills before conftest can monkeypatch it
import coppermind_cmo.server as _server_mod
_real_install_skills = _server_mod._install_skills


class TestFetchServerConfig:
    def setup_method(self):
        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

    @patch("httpx.get")
    def test_fetch_server_config_success(self, mock_get):
        """Mock httpx GET, verify ServerConfig populated."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "min_client_version": "0.2.0",
            "upgrade_message": "Run: pip install --upgrade coppermind-cmo",
            "prompts": {
                "extraction": "Extract from $client_name$: $chunk_text$",
                "merge": "Merge $existing$ and $new$",
                "brief_instructions": "Be concise.",
            },
        }
        mock_get.return_value = mock_resp

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is True
        assert result.min_client_version == "0.2.0"
        assert "extraction" in result.prompts
        assert "$client_name$" in result.prompts["extraction"]

    @patch("httpx.get")
    def test_fetch_server_config_gateway_down(self, mock_get):
        """Mock timeout, verify defaults returned."""
        mock_get.side_effect = Exception("Connection timeout")

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is False
        assert result.prompts == {}

    @patch("httpx.get")
    def test_fetch_server_config_malformed_prompts(self, mock_get):
        """Malformed prompts (non-dict) should default to empty dict, not crash."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "min_client_version": "0.2.0",
            "prompts": "this is a string, not a dict",
        }
        mock_get.return_value = mock_resp

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is True
        assert result.prompts == {}
        assert isinstance(result.prompts, dict)


class TestVersionCheck:
    def test_version_check_current(self):
        """Current >= minimum, no warning."""
        import coppermind_cmo.config as config_mod
        config_mod._server_config = ServerConfig(
            min_client_version="0.1.0",
            fetched=True,
        )
        # The version check logic is in server.py startup -- test the comparison directly
        from packaging.version import Version
        current = Version("0.2.0")
        minimum = Version("0.1.0")
        assert not (current < minimum)

    def test_version_check_outdated(self):
        """Current < minimum, should be detected."""
        from packaging.version import Version
        current = Version("0.1.3")
        minimum = Version("0.2.0")
        assert current < minimum


class TestExtractionPrompt:
    def setup_method(self):
        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

    def test_extraction_prompt_server_side(self):
        """Server config has extraction prompt, used instead of local."""
        import coppermind_cmo.config as config_mod
        config_mod._server_config = ServerConfig(
            prompts={"extraction": "Server prompt for $client_name$: $chunk_text$"},
            fetched=True,
        )
        from coppermind_cmo.ingest import _build_extraction_prompt
        result = _build_extraction_prompt("Acme", "some text here")
        assert "Server prompt for Acme" in result
        assert "some text here" in result

    def test_extraction_prompt_fallback(self):
        """Server config empty, falls back to local prompt."""
        import coppermind_cmo.config as config_mod
        config_mod._server_config = ServerConfig(fetched=False)
        from coppermind_cmo.ingest import _build_extraction_prompt
        result = _build_extraction_prompt("Acme", "some text here")
        assert "extracting structured knowledge" in result.lower()
        assert "Acme" in result



def _make_skills_mock(files):
    """Helper to build a mock for importlib.resources.files that returns given skill files."""
    mock_pkg_dir = MagicMock()
    mock_pkg_dir.is_dir.return_value = True
    mock_pkg_dir.iterdir.return_value = files

    mock_files_root = MagicMock()
    mock_files_root.__truediv__ = MagicMock(return_value=mock_pkg_dir)
    return mock_files_root


class TestInstallSkills:
    def _call_real_install_skills(self, monkeypatch):
        """Call the real _install_skills, bypassing conftest monkeypatch."""
        # monkeypatch.setattr in conftest replaces coppermind_cmo.server._install_skills
        # with a lambda. We use the reference we captured at import time.
        _real_install_skills()

    def test_install_skills_creates_dir(self, tmp_path, monkeypatch):
        """Skills dir created if missing."""
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        mock_file = MagicMock()
        mock_file.name = "test-skill.md"
        mock_file.read_text.return_value = "# Test Skill"

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        self._call_real_install_skills(monkeypatch)

        assert skills_dir.exists()

    def test_install_skills_copies_file(self, tmp_path, monkeypatch):
        """Skill file copied to ~/.claude/skills/."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"

        mock_file = MagicMock()
        mock_file.name = "test-skill.md"
        mock_file.read_text.return_value = "# Test Skill Content"

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        self._call_real_install_skills(monkeypatch)

        assert (skills_dir / "test-skill.md").read_text() == "# Test Skill Content"

    def test_install_skills_skips_identical(self, tmp_path, monkeypatch):
        """No overwrite if hash matches."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"
        skills_dir.mkdir(parents=True)
        content = "# Identical Skill"
        (skills_dir / "test-skill.md").write_text(content)

        mock_file = MagicMock()
        mock_file.name = "test-skill.md"
        mock_file.read_text.return_value = content  # same content

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        self._call_real_install_skills(monkeypatch)

        # File should not be rewritten (content unchanged)
        assert (skills_dir / "test-skill.md").read_text() == content

    def test_install_skills_updates_changed(self, tmp_path, monkeypatch):
        """Overwrites if hash differs."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"
        skills_dir.mkdir(parents=True)
        (skills_dir / "test-skill.md").write_text("# Old Version")

        mock_file = MagicMock()
        mock_file.name = "test-skill.md"
        mock_file.read_text.return_value = "# New Version"

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        self._call_real_install_skills(monkeypatch)

        assert (skills_dir / "test-skill.md").read_text() == "# New Version"


# ---------------------------------------------------------------------------
# Gateway config resilience tests (Part 5)
# ---------------------------------------------------------------------------

class TestFetchConfigErrorCodes:
    """Verify fetch_server_config handles HTTP error codes gracefully."""

    def setup_method(self):
        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

    @patch("httpx.get")
    def test_fetch_config_404(self, mock_get):
        """HTTP 404 should return defaults with fetched=False."""
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_get.return_value = mock_resp

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is False
        assert result.prompts == {}
        assert result.min_client_version == ""

    @patch("httpx.get")
    def test_fetch_config_500(self, mock_get):
        """HTTP 500 should return defaults."""
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_get.return_value = mock_resp

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is False
        assert result.prompts == {}

    @patch("httpx.get")
    def test_fetch_config_timeout(self, mock_get):
        """Timeout should return defaults."""
        mock_get.side_effect = TimeoutError("Connection timed out")

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        assert result.fetched is False
        assert result.prompts == {}

    @patch("httpx.get")
    def test_fetch_config_malformed_json(self, mock_get):
        """When resp.json() raises JSONDecodeError, return defaults."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.side_effect = json.JSONDecodeError("bad json", "", 0)
        mock_get.return_value = mock_resp

        config = MagicMock()
        config.llm_provider = "gateway"
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        result = fetch_server_config(config)
        # JSONDecodeError is caught by the general except clause
        assert result.fetched is False
        assert result.prompts == {}
