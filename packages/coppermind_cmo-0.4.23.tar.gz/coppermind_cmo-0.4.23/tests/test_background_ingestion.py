"""Tests for background ingestion: time estimates, progress tracking, and async processing."""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.ingest import estimate_ingestion_time, IngestProgress
from coppermind_cmo.background import (
    BackgroundResult,
    start_background_ingestion,
    get_completed_notifications,
    _background_results,
    _background_lock,
    _classify_ingest_error,
    _persist_job,
    _load_jobs_file,
    recover_orphaned_jobs,
    _JOBS_FILE,
)


def _poll_notifications(timeout=5.0, session_id=None):
    """Poll for completed notifications instead of sleep-based sync."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        notifications = get_completed_notifications(session_id)
        if notifications:
            return notifications
        time.sleep(0.01)
    return []


@pytest.fixture(autouse=True)
def clear_background_results():
    """Clear background results between tests."""
    with _background_lock:
        _background_results.clear()
    yield
    with _background_lock:
        _background_results.clear()


class TestEstimateIngestionTime:
    def test_estimate_word_count(self):
        """1000 words -> correct word_count."""
        text = " ".join(["word"] * 1000)
        estimate = estimate_ingestion_time(text)
        assert estimate["word_count"] == 1000

    def test_estimate_chunks(self):
        """10000 chars -> 5 chunks."""
        text = "x" * 10000
        estimate = estimate_ingestion_time(text)
        assert estimate["chunks"] == 5

    def test_estimate_seconds(self):
        """5 chunks -> ~15 seconds."""
        text = "x" * 10000
        estimate = estimate_ingestion_time(text)
        assert estimate["estimated_seconds"] == 15

    def test_estimate_minimum_one_chunk(self):
        """Short text -> at least 1 chunk."""
        estimate = estimate_ingestion_time("hello")
        assert estimate["chunks"] == 1
        assert estimate["estimated_seconds"] == 3


class TestIngestProgress:
    def test_initial_state(self):
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)
        assert progress.completed_chunks == 0
        assert progress.memories_found == 0
        assert progress.by_type == {}

    def test_update_increments(self):
        """IngestProgress.update increments correctly, summary string looks right."""
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)

        progress.update(1, [{"memory_type": "decision"}, {"memory_type": "fact"}])
        assert progress.completed_chunks == 1
        assert progress.memories_found == 2
        assert progress.by_type == {"decision": 1, "fact": 1}

        progress.update(2, [{"memory_type": "decision"}])
        assert progress.completed_chunks == 2
        assert progress.memories_found == 3
        assert progress.by_type == {"decision": 2, "fact": 1}

    def test_summary_with_memories(self):
        estimate = {"word_count": 100, "chunks": 5, "estimated_seconds": 15}
        progress = IngestProgress(total_chunks=5, estimate=estimate)
        progress.update(3, [{"memory_type": "fact"}, {"memory_type": "decision"}])
        summary = progress.summary
        assert "3/5" in summary
        assert "2 memories" in summary

    def test_summary_no_memories(self):
        estimate = {"word_count": 100, "chunks": 5, "estimated_seconds": 15}
        progress = IngestProgress(total_chunks=5, estimate=estimate)
        progress.update(1, [])
        assert "1/5" in progress.summary
        assert "memories" not in progress.summary

    def test_as_dict(self):
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)
        progress.update(2, [{"memory_type": "commitment"}])
        d = progress.as_dict
        assert d["completed"] == 2
        assert d["total"] == 3
        assert d["memories_found"] == 1
        assert d["by_type"] == {"commitment": 1}


class TestBackgroundIngestion:
    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_returns_immediately(self, MockEngine):
        """start_background_ingestion returns without waiting for completion.

        Uses a threading.Event to block the mock instead of time.sleep,
        eliminating flakiness from real sleeps (Issue 22).
        """
        text = "word " * 5000  # Long enough

        # Block the ingestion until we release it (no real sleep)
        blocker = threading.Event()

        def slow_process(*a, **kw):
            blocker.wait(timeout=10)
            return {"new": 0, "updated": 0}
        MockEngine.return_value.process_source = slow_process

        start = time.monotonic()
        result = start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test Client",
            db_factory=MagicMock,
            config=MagicMock(),
        )
        elapsed = time.monotonic() - start

        # Release the blocked thread so it doesn't leak
        blocker.set()

        assert elapsed < 1.0  # Should return nearly instantly
        assert result["status"] == "processing"
        assert "task_id" in result
        assert result["estimate"]["word_count"] == 5000

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_result_appears_in_notifications(self, MockEngine):
        """Start ingestion with mock, wait for thread, check get_completed_notifications."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 5, "updated": 2}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Acme Corp",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        # Poll with tighter timeout (Issue 22)
        deadline = time.monotonic() + 3.0
        n = None
        while time.monotonic() < deadline:
            for note in get_completed_notifications():
                if note.get("mind_name") == "Acme Corp":
                    n = note
                    break
            if n is not None:
                break
            time.sleep(0.01)

        assert n is not None, "Acme Corp notification never arrived"
        assert n["type"] == "ingestion_complete"
        assert n["mind_name"] == "Acme Corp"
        assert n["memories_created"] == 7

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_shown_once(self, MockEngine):
        """get_completed_notifications returns result first time, empty second time."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 3, "updated": 0}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        first = _poll_notifications(timeout=3.0)
        second = get_completed_notifications()
        assert len(first) == 1
        assert len(second) == 0

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_includes_error_on_failure(self, MockEngine):
        """Mock ingestion to fail, verify error in notification."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            raise RuntimeError("mysterious internal failure")
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Broken Client",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        notifications = _poll_notifications(timeout=3.0)
        assert len(notifications) == 1
        assert notifications[0]["type"] == "ingestion_error"
        assert "task ID" in notifications[0]["error"]  # sanitized, not raw exception

    def test_estimate_in_return(self):
        """start_background_ingestion returns estimate dict."""
        text = "x " * 2000
        result = start_background_ingestion(
            text=text,
            mind_id="m",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
        )
        assert "estimate" in result
        assert result["estimate"]["word_count"] == 2000
        assert result["estimate"]["chunks"] >= 1
        assert result["estimate"]["estimated_seconds"] >= 3

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_includes_memory_count(self, MockEngine):
        """Verify memories_created and by_type in notification."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 10, "updated": 3}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="CountTest",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        # Poll with tighter timeout (Issue 22)
        deadline = time.monotonic() + 3.0
        n = None
        while time.monotonic() < deadline:
            for note in get_completed_notifications():
                if note.get("mind_name") == "CountTest":
                    n = note
                    break
            if n is not None:
                break
            time.sleep(0.01)

        assert n is not None, "CountTest notification never arrived"
        assert n["memories_created"] == 13
        assert "13 new memories extracted" in n["message"]


class TestStoreMemoryBackgroundFlag:
    """Test the actual decision logic that determines when background ingestion
    triggers, rather than just testing that start_background_ingestion was
    called (Issue 19)."""

    def test_long_content_triggers_raw_document_storage(self):
        """Content > 4000 chars stores a raw document (prerequisite for background)."""
        content = "word " * 5000  # > 4000 chars
        assert len(content) > 4000, "Test content must exceed 4000 chars"

    def test_short_content_does_not_trigger_background(self):
        """Content <= 4000 chars should never enter the background path."""
        content = "short note"
        assert len(content) <= 4000

    def test_decision_logic_requires_active_mind(self):
        """Background ingestion requires an active mind to be set."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        result = _store_memory(
            content="x" * 5000,
            memory_type="fact",
            tags=[],
            db=MagicMock(),
            config=MagicMock(),
            active_mind=None,
        )
        assert result.get("error") is not None

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={})
    @patch("coppermind_cmo.tools.memories._find_similar_memory", return_value=None)
    @patch("coppermind_cmo.ingest._store_raw_document")
    def test_long_content_stores_raw_document(self, mock_raw_doc, mock_similar, mock_cadence, mock_embed):
        """Content > 4000 chars calls _store_raw_document during store_memory."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        mock_db = MagicMock()
        mock_db.execute_returning.return_value = ("fake-uuid",)

        _store_memory(
            content="x" * 5000,
            memory_type="fact",
            tags=[],
            db=mock_db,
            config=MagicMock(),
            active_mind=("mind-id", "Test Client"),
        )
        mock_raw_doc.assert_called_once()

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={})
    @patch("coppermind_cmo.tools.memories._find_similar_memory", return_value=None)
    @patch("coppermind_cmo.ingest._store_raw_document")
    def test_short_content_skips_raw_document(self, mock_raw_doc, mock_similar, mock_cadence, mock_embed):
        """Content <= 4000 chars does NOT call _store_raw_document."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        mock_db = MagicMock()
        mock_db.execute_returning.return_value = ("fake-uuid",)

        _store_memory(
            content="short note",
            memory_type="fact",
            tags=[],
            db=mock_db,
            config=MagicMock(),
            active_mind=("mind-id", "Test Client"),
        )
        mock_raw_doc.assert_not_called()


class TestSessionScopedNotifications:
    """Verify notifications are scoped to session_id (Issue 11)."""

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notifications_filtered_by_session(self, MockEngine):
        """Results from session A should not appear for session B."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 1, "updated": 0}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="mind-1",
            mind_name="SessionA",
            db_factory=MagicMock,
            config=MagicMock(),
            session_id="session-A",
        )

        # Wait for completion
        notes = _poll_notifications(timeout=3.0, session_id="session-A")
        assert len(notes) == 1
        assert notes[0]["mind_name"] == "SessionA"

        # Second call for different session should be empty
        assert get_completed_notifications("session-B") == []


class TestDurableBackgroundJobs:
    """Test job persistence and orphan recovery (Issue 8)."""

    def test_persist_and_load_job(self, tmp_path, monkeypatch):
        """_persist_job writes to JSON file, _load_jobs_file reads it back."""
        jobs_file = tmp_path / "background_jobs.json"
        monkeypatch.setattr("coppermind_cmo.background._JOBS_FILE", jobs_file)

        _persist_job("task-1", "Acme", "in_progress")
        jobs = _load_jobs_file()
        assert "task-1" in jobs
        assert jobs["task-1"]["status"] == "in_progress"
        assert jobs["task-1"]["mind_name"] == "Acme"

    def test_recover_orphaned_jobs(self, tmp_path, monkeypatch):
        """On startup, in_progress jobs are marked as failed."""
        import json
        jobs_file = tmp_path / "background_jobs.json"
        monkeypatch.setattr("coppermind_cmo.background._JOBS_FILE", jobs_file)

        # Simulate a crashed state
        jobs_file.write_text(json.dumps({
            "task-orphan": {
                "task_id": "task-orphan",
                "mind_name": "Orphan",
                "status": "in_progress",
                "updated_at": "2025-01-01T00:00:00",
            },
            "task-done": {
                "task_id": "task-done",
                "mind_name": "Done",
                "status": "complete",
                "updated_at": "2025-01-01T00:00:00",
            },
        }))

        recover_orphaned_jobs()

        jobs = _load_jobs_file()
        assert jobs["task-orphan"]["status"] == "failed"
        assert "Server restarted" in jobs["task-orphan"]["error"]
        assert jobs["task-done"]["status"] == "complete"

    def test_recover_no_file(self, tmp_path, monkeypatch):
        """recover_orphaned_jobs with no file does not crash."""
        jobs_file = tmp_path / "nonexistent" / "background_jobs.json"
        monkeypatch.setattr("coppermind_cmo.background._JOBS_FILE", jobs_file)
        # Should not raise
        recover_orphaned_jobs()


class TestClassifyIngestError:
    """Gap 3: Exercise all 7 branches of _classify_ingest_error."""

    def test_timeout_error(self):
        msg = _classify_ingest_error(TimeoutError("connection timed out"), "task-1")
        assert "timed out" in msg.lower()

    def test_auth_error_401(self):
        import httpx
        resp = httpx.Response(401, request=httpx.Request("GET", "http://x"))
        exc = httpx.HTTPStatusError("401 Unauthorized", request=resp.request, response=resp)
        msg = _classify_ingest_error(exc, "task-2")
        assert "api key" in msg.lower() or "auth" in msg.lower()

    def test_rate_limit_429(self):
        import httpx
        resp = httpx.Response(429, request=httpx.Request("GET", "http://x"))
        exc = httpx.HTTPStatusError("429 Too Many Requests", request=resp.request, response=resp)
        msg = _classify_ingest_error(exc, "task-3")
        assert "rate" in msg.lower() or "limit" in msg.lower()

    def test_server_error_502(self):
        import httpx
        resp = httpx.Response(502, request=httpx.Request("GET", "http://x"))
        exc = httpx.HTTPStatusError("502 Bad Gateway", request=resp.request, response=resp)
        msg = _classify_ingest_error(exc, "task-4")
        assert "server" in msg.lower() or "try again" in msg.lower()

    def test_db_connection_error(self):
        try:
            import psycopg2
            exc = psycopg2.OperationalError("connection refused")
        except ImportError:
            # psycopg2 not installed — simulate with a class that matches the name check
            class OperationalError(Exception):
                pass
            exc = OperationalError("connection refused")
        msg = _classify_ingest_error(exc, "task-5")
        assert "database" in msg.lower() or "connection" in msg.lower()

    def test_integrity_error(self):
        try:
            import psycopg2
            exc = psycopg2.IntegrityError("check constraint violated")
        except ImportError:
            class IntegrityError(Exception):
                pass
            exc = IntegrityError("check constraint violated")
        msg = _classify_ingest_error(exc, "task-6")
        assert "validation" in msg.lower() or "constraint" in msg.lower() or "upgrade" in msg.lower()


class TestPostProcessCallback:
    """Test the post_process callback parameter of start_background_ingestion."""

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_post_process_called_on_success(self, MockEngine):
        """post_process is called with (ingest_result, db_factory) after success."""
        text = "word " * 1000
        callback_calls = []

        def mock_process(*a, **kw):
            return {"new": 3, "updated": 1}
        MockEngine.return_value.process_source = mock_process

        def my_callback(result, db_factory):
            callback_calls.append((result, db_factory))

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
            post_process=my_callback,
        )

        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and not callback_calls:
            time.sleep(0.01)

        assert len(callback_calls) == 1
        assert callback_calls[0][0]["new"] == 3
        assert callback_calls[0][0]["updated"] == 1

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_post_process_not_called_on_failure(self, MockEngine):
        """post_process is NOT called when ingestion fails."""
        text = "word " * 1000
        callback_calls = []

        def mock_process(*a, **kw):
            raise RuntimeError("boom")
        MockEngine.return_value.process_source = mock_process

        def my_callback(result, db_factory):
            callback_calls.append(result)

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
            post_process=my_callback,
        )

        # Wait for background thread to complete
        notifications = _poll_notifications(timeout=3.0)
        assert len(notifications) == 1
        assert notifications[0]["type"] == "ingestion_error"
        # Callback should not have been called
        assert len(callback_calls) == 0

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_post_process_failure_does_not_fail_job(self, MockEngine):
        """A failing post_process does not mark the ingestion as failed."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 2, "updated": 0}
        MockEngine.return_value.process_source = mock_process

        def bad_callback(result, db_factory):
            raise RuntimeError("callback crashed")

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
            post_process=bad_callback,
        )

        # Despite callback failure, notification should show success
        notifications = _poll_notifications(timeout=3.0)
        assert len(notifications) == 1
        assert notifications[0]["type"] == "ingestion_complete"
        assert notifications[0]["memories_created"] == 2
