"""Tests for email processing: attribution, filtering, content extraction."""

import json
from unittest.mock import MagicMock

import pytest

from coppermind_cmo.email_processing import (
    attribute_email,
    auto_populate_email_contacts,
    build_known_contacts,
    clean_email_body,
    extract_emails_from_content,
    matches_known_contacts,
    should_skip_message,
)


# ---------------------------------------------------------------------------
# extract_emails_from_content
# ---------------------------------------------------------------------------

class TestExtractEmails:
    def test_basic_extraction(self):
        assert extract_emails_from_content("Contact sarah@acme.com for details") == [
            "sarah@acme.com"
        ]

    def test_multiple_emails(self):
        text = "From: sarah@acme.com and josh@betacorp.com"
        result = extract_emails_from_content(text)
        assert "sarah@acme.com" in result
        assert "josh@betacorp.com" in result

    def test_filters_noreply(self):
        text = "Reply to noreply@acme.com or no-reply@acme.com"
        assert extract_emails_from_content(text) == []

    def test_filters_mailer_daemon(self):
        assert extract_emails_from_content("mailer-daemon@acme.com bounced") == []

    def test_filters_notifications(self):
        assert extract_emails_from_content("notifications@github.com") == []

    def test_filters_local_tld(self):
        assert extract_emails_from_content("admin@server.local") == []
        assert extract_emails_from_content("dev@box.localhost") == []

    def test_allows_normal_prefixes(self):
        result = extract_emails_from_content("hello@acme.com and ceo@betacorp.com")
        assert "hello@acme.com" in result
        assert "ceo@betacorp.com" in result

    def test_empty_input(self):
        assert extract_emails_from_content("") == []
        assert extract_emails_from_content("no emails here") == []


# ---------------------------------------------------------------------------
# matches_known_contacts
# ---------------------------------------------------------------------------

class TestMatchesKnownContacts:
    def test_email_match(self):
        assert matches_known_contacts(
            "sarah@acme.com", [], [],
            set(), {"sarah@acme.com"},
        )

    def test_domain_match(self):
        assert matches_known_contacts(
            "unknown@acme.com", [], [],
            {"acme.com"}, set(),
        )

    def test_to_address_match(self):
        assert matches_known_contacts(
            "me@volacci.com", ["sarah@acme.com"], [],
            set(), {"sarah@acme.com"},
        )

    def test_cc_address_match(self):
        assert matches_known_contacts(
            "me@volacci.com", [], ["josh@acme.com"],
            {"acme.com"}, set(),
        )

    def test_no_match(self):
        assert not matches_known_contacts(
            "random@unknown.com", ["other@unknown.com"], [],
            {"acme.com"}, {"sarah@acme.com"},
        )

    def test_case_insensitive(self):
        assert matches_known_contacts(
            "Sarah@ACME.COM", [], [],
            set(), {"sarah@acme.com"},
        )


# ---------------------------------------------------------------------------
# attribute_email
# ---------------------------------------------------------------------------

class TestAttributeEmail:
    MINDS = [
        {
            "id": "mind-1",
            "name": "Acme Corp",
            "email_contacts": {"sarah@acme.com": "Sarah", "josh@acme.com": "Josh"},
            "company_info": {"domain": "acme.com"},
        },
        {
            "id": "mind-2",
            "name": "Beta Corp",
            "email_contacts": {"alice@betacorp.com": "Alice"},
            "company_info": {"domain": "betacorp.com"},
        },
    ]

    def test_single_match_by_email(self):
        result = attribute_email(
            "sarah@acme.com", ["me@volacci.com"], [], self.MINDS,
        )
        assert result == ["mind-1"]

    def test_single_match_by_domain(self):
        result = attribute_email(
            "unknown@acme.com", ["me@volacci.com"], [], self.MINDS,
        )
        assert result == ["mind-1"]

    def test_multi_match(self):
        result = attribute_email(
            "sarah@acme.com",
            ["alice@betacorp.com"],
            [],
            self.MINDS,
        )
        assert len(result) == 2
        assert "mind-1" in result
        assert "mind-2" in result

    def test_no_match(self):
        result = attribute_email(
            "random@unknown.com", ["other@unknown.com"], [], self.MINDS,
        )
        assert result == []

    def test_cc_attribution(self):
        result = attribute_email(
            "me@volacci.com",
            [],
            ["alice@betacorp.com"],
            self.MINDS,
        )
        assert result == ["mind-2"]


# ---------------------------------------------------------------------------
# should_skip_message
# ---------------------------------------------------------------------------

class TestShouldSkipMessage:
    def test_auto_reply_subject(self):
        assert should_skip_message("Out of Office: Ben Finklea", "sarah@acme.com")

    def test_automatic_reply_subject(self):
        assert should_skip_message("Automatic reply: Meeting Follow-up", "sarah@acme.com")

    def test_delivery_status(self):
        assert should_skip_message("Delivery Status Notification (Failure)", "mailer@bounce.com")

    def test_noreply_from(self):
        assert should_skip_message("Your receipt", "noreply@stripe.com")

    def test_no_reply_from(self):
        assert should_skip_message("Your order", "no-reply@amazon.com")

    def test_metadata_auto_submitted(self):
        assert should_skip_message(
            "Re: Q3 budget", "sarah@acme.com",
            metadata={"headers": {"Auto-Submitted": "auto-replied"}},
        )

    def test_metadata_list_unsubscribe(self):
        assert should_skip_message(
            "Weekly newsletter", "news@acme.com",
            metadata={"headers": {"List-Unsubscribe": "<mailto:unsub@list.com>"}},
        )

    def test_metadata_calendar(self):
        assert should_skip_message(
            "Meeting invite", "sarah@acme.com",
            metadata={"mime_type": "text/calendar"},
        )

    def test_normal_email(self):
        assert not should_skip_message("Q3 budget review", "sarah@acme.com")

    def test_normal_email_with_metadata(self):
        assert not should_skip_message(
            "Q3 budget review", "sarah@acme.com",
            metadata={"headers": {}, "mime_type": "text/plain"},
        )


# ---------------------------------------------------------------------------
# clean_email_body
# ---------------------------------------------------------------------------

class TestCleanEmailBody:
    def test_removes_quoted_lines(self):
        text = "Hello\n> This is quoted\n> More quoted\nGoodbye"
        result = clean_email_body(text)
        assert "Hello" in result
        assert "Goodbye" in result
        assert "quoted" not in result

    def test_stops_at_reply_marker(self):
        text = "Main content here\n\nOn Mon, Jan 1, 2026 at 10:00 AM John wrote:\nOld stuff"
        result = clean_email_body(text)
        assert "Main content" in result
        assert "Old stuff" not in result

    def test_stops_at_signature(self):
        text = "Important info\n--\nJohn Smith\nCEO, Acme Corp"
        result = clean_email_body(text)
        assert "Important info" in result
        assert "John Smith" not in result

    def test_stops_at_footer_delimiter(self):
        text = "Real content\n___\nThis email is confidential"
        result = clean_email_body(text)
        assert "Real content" in result
        assert "confidential" not in result

    def test_preserves_clean_email(self):
        text = "Hi Ben,\n\nLet's schedule a call for Thursday.\n\nBest,\nSarah"
        result = clean_email_body(text)
        assert "schedule a call" in result

    def test_idempotent(self):
        text = "Hello there\n--\nSignature"
        first = clean_email_body(text)
        second = clean_email_body(first)
        assert first == second


# ---------------------------------------------------------------------------
# auto_populate_email_contacts
# ---------------------------------------------------------------------------

class TestAutoPopulateContacts:
    def test_adds_contacts(self):
        db = MagicMock()
        db.fetch_one = MagicMock(return_value=None)  # Not found
        db.execute = MagicMock(return_value=None)  # UPDATE

        count = auto_populate_email_contacts(
            db, "mind-123", "Contact Sarah Chen sarah@acme.com for details"
        )
        assert count >= 1
        assert db.fetch_one.call_count >= 1
        assert db.execute.call_count >= 1

    def test_skips_existing_contacts(self):
        db = MagicMock()
        db.fetch_one = MagicMock(return_value=(1,))  # Found

        count = auto_populate_email_contacts(
            db, "mind-123", "Contact Sarah Chen sarah@acme.com for details"
        )
        assert count == 0

    def test_no_emails_found(self):
        db = MagicMock()
        count = auto_populate_email_contacts(db, "mind-123", "No emails here")
        assert count == 0
        assert not db.execute.called

    def test_filters_infrastructure(self):
        db = MagicMock()
        count = auto_populate_email_contacts(
            db, "mind-123", "Contact noreply@acme.com"
        )
        assert count == 0

    def test_large_content_guard(self):
        db = MagicMock()
        count = auto_populate_email_contacts(
            db, "mind-123", "x" * 50_001 + " sarah@acme.com"
        )
        assert count == 0
        assert not db.execute.called


# ---------------------------------------------------------------------------
# build_known_contacts
# ---------------------------------------------------------------------------

class TestBuildKnownContacts:
    def test_builds_sets(self):
        minds = [
            {
                "email_contacts": {"sarah@acme.com": "Sarah"},
                "company_info": {"domain": "acme.com"},
            },
            {
                "email_contacts": {"alice@beta.com": "Alice"},
                "company_info": {},
            },
        ]
        domains, emails = build_known_contacts(minds)
        assert domains == {"acme.com"}
        assert emails == {"sarah@acme.com", "alice@beta.com"}

    def test_empty_minds(self):
        domains, emails = build_known_contacts([])
        assert domains == set()
        assert emails == set()

    def test_missing_fields(self):
        minds = [{"email_contacts": None, "company_info": None}]
        domains, emails = build_known_contacts(minds)
        assert domains == set()
        assert emails == set()
