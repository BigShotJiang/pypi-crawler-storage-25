import io
import json
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from coppermind_cmo.hooks import auto_prep
from coppermind_cmo.hooks.auto_prep import AUTO_PREP_CONTEXT, build_hook_output

_FAKE_MEETING = [
    {"summary": "Acme Sync", "start": {"dateTime": "2026-03-18T15:30:00Z"}, "attendees": [{"email": "ceo@acme.com"}]},
]


def _patch_meetings():
    """Patch _check_upcoming_meetings to return a fake meeting."""
    return patch("coppermind_cmo.hooks.auto_prep._check_upcoming_meetings", return_value=_FAKE_MEETING)


def test_build_hook_output_injects_context_and_writes_state(tmp_path):
    state_path = tmp_path / "state.json"
    now = datetime(2026, 3, 18, 15, 0, tzinfo=timezone.utc)

    with _patch_meetings():
        result = build_hook_output("what's next?", now=now, state_path=state_path)

    assert result is not None
    assert result["hookSpecificOutput"]["hookEventName"] == "UserPromptSubmit"
    context = result["hookSpecificOutput"]["additionalContext"]
    assert context.startswith("COPPERMIND AUTO-PREP:")
    assert "Acme Sync" in context  # meeting info appended
    assert state_path.exists()


def test_build_hook_output_rate_limits_repeated_injection(tmp_path):
    state_path = tmp_path / "state.json"
    now = datetime(2026, 3, 18, 15, 0, tzinfo=timezone.utc)

    with _patch_meetings():
        first = build_hook_output("what's next?", now=now, state_path=state_path)
        second = build_hook_output(
            "what should I work on?",
            now=now + timedelta(minutes=5),
            state_path=state_path,
        )

    assert first is not None
    assert second is None


def test_build_hook_output_rate_limits_per_session_only(tmp_path):
    state_path = tmp_path / "state.json"
    now = datetime(2026, 3, 18, 15, 0, tzinfo=timezone.utc)

    with _patch_meetings():
        first = build_hook_output("what's next?", session_id="session-a", now=now, state_path=state_path)
        second = build_hook_output("what's next?", session_id="session-b", now=now, state_path=state_path)

    assert first is not None
    assert second is not None


def test_build_hook_output_skips_explicit_meeting_prep_prompt(tmp_path):
    state_path = tmp_path / "state.json"

    result = build_hook_output("/cmo-autoprep", state_path=state_path)

    assert result is None
    assert not state_path.exists()


def test_build_hook_output_skips_when_state_cannot_be_written(tmp_path, monkeypatch):
    state_path = tmp_path / "state.json"

    def fail_save(*args, **kwargs):
        raise OSError("disk full")

    monkeypatch.setattr("coppermind_cmo.hooks.auto_prep._save_state", fail_save)

    with _patch_meetings():
        result = build_hook_output("what's next?", state_path=state_path)

    assert result is None


def test_build_hook_output_skips_blank_prompt(tmp_path):
    result = build_hook_output("   ", state_path=tmp_path / "state.json")
    assert result is None


def test_build_hook_output_handles_invalid_timestamp_in_state(tmp_path):
    state_path = tmp_path / "state.json"
    state_path.write_text(json.dumps({"sessions": {"abc": "not-a-timestamp"}}), encoding="utf-8")

    with _patch_meetings():
        result = build_hook_output("what's next?", session_id="abc", state_path=state_path)

    assert result is not None


def test_build_hook_output_handles_naive_timestamp_in_state(tmp_path):
    state_path = tmp_path / "state.json"
    now = datetime(2026, 3, 18, 15, 0, tzinfo=timezone.utc)
    state_path.write_text(json.dumps({"sessions": {"abc": "2026-03-18T14:50:00"}}), encoding="utf-8")

    result = build_hook_output("what's next?", session_id="abc", now=now, state_path=state_path)

    assert result is None


def test_build_hook_output_recovers_from_non_dict_sessions(tmp_path):
    state_path = tmp_path / "state.json"
    state_path.write_text(json.dumps({"sessions": []}), encoding="utf-8")

    with _patch_meetings():
        result = build_hook_output("what's next?", state_path=state_path)

    assert result is not None


def test_main_prints_hook_payload(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(auto_prep, "DEFAULT_STATE_PATH", tmp_path / "state.json")
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps({"prompt": "what's next?", "session_id": "abc"})))

    with _patch_meetings():
        exit_code = auto_prep.main()

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    assert output["hookSpecificOutput"]["hookEventName"] == "UserPromptSubmit"


def test_build_hook_output_skips_when_no_meetings(tmp_path):
    """Calendar gate: no upcoming meetings = no injection."""
    state_path = tmp_path / "state.json"
    with patch("coppermind_cmo.hooks.auto_prep._check_upcoming_meetings", return_value=[]):
        result = build_hook_output("what's next?", state_path=state_path)
    assert result is None
    assert not state_path.exists()


def test_main_ignores_invalid_json(monkeypatch, capsys):
    monkeypatch.setattr("sys.stdin", io.StringIO("{invalid json"))

    exit_code = auto_prep.main()

    assert exit_code == 0
    assert capsys.readouterr().out == ""
