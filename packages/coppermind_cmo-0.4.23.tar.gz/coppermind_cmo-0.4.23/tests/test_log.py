"""Tests for structured JSON logging."""

import json
from coppermind_cmo.log import ToolLogger


class TestToolLogger:
    def test_info_produces_json(self, capfd):
        tl = ToolLogger("test_tool")
        tl.info("hello", mind_id="abc-123", duration_ms=42)
        err = capfd.readouterr().err
        data = json.loads(err.strip().removeprefix("COPPERMIND-CMO: "))
        assert data["level"] == "info"
        assert data["tool"] == "test_tool"
        assert data["message"] == "hello"
        assert data["mind_id"] == "abc-123"
        assert data["duration_ms"] == 42
        assert "timestamp" in data

    def test_warn_level(self, capfd):
        tl = ToolLogger("search_memory")
        tl.warn("embedding service down")
        err = capfd.readouterr().err
        data = json.loads(err.strip().removeprefix("COPPERMIND-CMO: "))
        assert data["level"] == "warn"

    def test_error_level(self, capfd):
        tl = ToolLogger("store_memory")
        tl.error("db connection failed")
        err = capfd.readouterr().err
        data = json.loads(err.strip().removeprefix("COPPERMIND-CMO: "))
        assert data["level"] == "error"

    def test_null_mind_id(self, capfd):
        tl = ToolLogger("list_minds")
        tl.info("listing")
        err = capfd.readouterr().err
        data = json.loads(err.strip().removeprefix("COPPERMIND-CMO: "))
        assert data["mind_id"] is None


class TestToolLoggerExtraKwargs:
    def test_emit_includes_extra_kwargs(self, capfd):
        logger = ToolLogger("test")
        logger.info("test message", pool_size=10, component="db")
        output = json.loads(capfd.readouterr().err.strip().removeprefix("COPPERMIND-CMO: "))
        assert output["pool_size"] == 10
        assert output["component"] == "db"

    def test_emit_extra_does_not_override_base_fields(self, capfd):
        logger = ToolLogger("test")
        logger.info("test message", level="OVERRIDE")
        output = json.loads(capfd.readouterr().err.strip().removeprefix("COPPERMIND-CMO: "))
        assert output["level"] == "info"  # base field wins
