"""Tests for coppermind_cmo.tools.eos — EOS Layer tools."""

import json
from datetime import date, timedelta
from unittest.mock import MagicMock, patch, call

import pytest

import coppermind_cmo.tools.eos as eos_mod
from coppermind_cmo.tools.eos import (
    _manage_rock,
    _get_rocks,
    _import_sprint_plan,
    _get_sprint_plan,
    _update_sprint_status,
    _get_current_sprint,
    _start_quarter,
    _quarterly_pacing,
    _manage_agenda,
    _get_agenda,
    _manage_issue,
    _get_issues,
    _has_rocks,
    _has_sprint_plans,
    _has_agenda_items,
    _has_eos_issues,
    _sanitize_csv_cell,
    _parse_csv_data,
    _parse_wide_csv_data,
    _is_wide_csv,
)


# ---- Autouse fixtures for table detection cache reset ----

@pytest.fixture(autouse=True)
def reset_eos_table_caches():
    """Reset all EOS table detection caches between tests."""
    eos_mod._rocks_table_exists = None
    eos_mod._sprint_plans_table_exists = None
    eos_mod._agenda_items_table_exists = None
    eos_mod._eos_issues_table_exists = None
    yield
    eos_mod._rocks_table_exists = None
    eos_mod._sprint_plans_table_exists = None
    eos_mod._agenda_items_table_exists = None
    eos_mod._eos_issues_table_exists = None


@pytest.fixture(autouse=True)
def assume_eos_tables(monkeypatch):
    """Assume all EOS tables exist by default. Tests can override."""
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: True)


# ---- Helpers ----

def _cadence_row(year=2026, quarter=1, sprint=3, spq=6):
    """Return a mock cadence dict."""
    return {"type": "eos", "year": year, "quarter": quarter, "sprint": sprint, "sprints_per_quarter": spq}


from contextlib import contextmanager


def _setup_import_mocks(mock_db, plan_id, fetchone_results, existing_plan=False):
    """Set up mock_db for _import_sprint_plan transaction tests.

    mock_db.fetch_one is used for cadence lookup (before the transaction).
    mock_db.connection() returns a context manager with a mock cursor
    whose fetchone side_effect drives the transaction flow.

    fetchone_results: list of tuples for cursor.fetchone calls inside the transaction.
      These are the RETURNING results from deliverable upserts.
    """
    mock_cursor = MagicMock()
    mock_conn = MagicMock()

    # Set up cursor context manager properly
    cursor_cm = MagicMock()
    cursor_cm.__enter__ = MagicMock(return_value=mock_cursor)
    cursor_cm.__exit__ = MagicMock(return_value=False)
    mock_conn.cursor.return_value = cursor_cm

    if existing_plan:
        plan_lookup = (plan_id,)
    else:
        plan_lookup = None

    mock_cursor.fetchone.side_effect = [plan_lookup] + (
        [(plan_id,)] if not existing_plan else []
    ) + fetchone_results

    @contextmanager
    def _mock_connection():
        yield mock_conn

    mock_db.connection = _mock_connection
    return mock_cursor, mock_conn


# ============================================================
# Table Detection Caching
# ============================================================


class TestTableDetection:
    """Test _has_* table detection functions."""

    def test_has_rocks_true_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()  # Remove autouse stub
        eos_mod._rocks_table_exists = None
        mock_db.fetch_one.return_value = (1,)
        assert _has_rocks(mock_db) is True
        assert eos_mod._rocks_table_exists is True
        # Second call uses cache, no DB query
        mock_db.fetch_one.reset_mock()
        assert _has_rocks(mock_db) is True
        mock_db.fetch_one.assert_not_called()

    def test_has_rocks_false_not_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._rocks_table_exists = None
        mock_db.fetch_one.return_value = None
        assert _has_rocks(mock_db) is False
        # False is NOT cached — re-checks on next call
        mock_db.fetch_one.return_value = (1,)
        assert _has_rocks(mock_db) is True

    def test_has_sprint_plans_true_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._sprint_plans_table_exists = None
        mock_db.fetch_one.return_value = (1,)
        assert _has_sprint_plans(mock_db) is True
        assert eos_mod._sprint_plans_table_exists is True

    def test_has_agenda_items_exception(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._agenda_items_table_exists = None
        mock_db.fetch_one.side_effect = Exception("connection lost")
        assert _has_agenda_items(mock_db) is False

    def test_has_eos_issues_true(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._eos_issues_table_exists = None
        mock_db.fetch_one.return_value = (1,)
        assert _has_eos_issues(mock_db) is True


# ============================================================
# CSV Sanitization
# ============================================================


class TestCSVSanitation:
    """Test CSV injection prevention and cell limits."""

    def test_strip_equals(self):
        assert _sanitize_csv_cell("=cmd|' /C calc'") == "cmd|' /C calc'"

    def test_strip_plus(self):
        assert _sanitize_csv_cell("+cmd") == "cmd"

    def test_strip_minus(self):
        assert _sanitize_csv_cell("-cmd") == "cmd"

    def test_strip_at(self):
        assert _sanitize_csv_cell("@SUM(A1)") == "SUM(A1)"

    def test_strip_tab(self):
        assert _sanitize_csv_cell("\tcmd") == "cmd"

    def test_strip_cr(self):
        assert _sanitize_csv_cell("\rcmd") == "cmd"

    def test_strip_multiple(self):
        assert _sanitize_csv_cell("=+@evil") == "evil"

    def test_normal_text_unchanged(self):
        assert _sanitize_csv_cell("Normal text") == "Normal text"

    def test_length_limit(self):
        long_text = "a" * 600
        assert len(_sanitize_csv_cell(long_text)) == 500

    def test_empty_string(self):
        assert _sanitize_csv_cell("") == ""


class TestParseCSVData:
    """Test CSV parsing."""

    def test_basic_csv(self):
        csv_data = (
            "initiative_name,owner,sprint_number,deliverable\n"
            "Website Redesign,Alice,1,Design mockups\n"
            "SEO Campaign,Bob,2,Keyword research\n"
        )
        result = _parse_csv_data(csv_data)
        assert len(result) == 2
        assert result[0]["initiative_name"] == "Website Redesign"
        assert result[0]["owner"] == "Alice"
        assert result[1]["sprint_number"] == "2"

    def test_csv_injection_chars_stripped(self):
        csv_data = (
            "initiative_name,owner,sprint_number,deliverable\n"
            "=malicious,+Bob,1,@evil\n"
        )
        result = _parse_csv_data(csv_data)
        assert result[0]["initiative_name"] == "malicious"
        assert result[0]["owner"] == "Bob"
        assert result[0]["deliverable"] == "evil"

    def test_max_initiatives_limit(self):
        lines = ["initiative_name,sprint_number,deliverable"]
        for i in range(120):
            lines.append(f"Initiative {i},1,Deliverable {i}")
        csv_data = "\n".join(lines)
        result = _parse_csv_data(csv_data)
        assert len(result) == 100

    def test_empty_initiative_name_skipped(self):
        csv_data = (
            "initiative_name,sprint_number,deliverable\n"
            ",1,No name\n"
            "Valid,1,Has name\n"
        )
        result = _parse_csv_data(csv_data)
        assert len(result) == 1
        assert result[0]["initiative_name"] == "Valid"


# ============================================================
# manage_rock
# ============================================================


class TestManageRock:
    """Test _manage_rock core function."""

    def test_no_active_mind(self, mock_db):
        result = _manage_rock("Test Rock", mock_db, None)
        assert result["error"] is True
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _manage_rock("Test Rock", mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_empty_title(self, mock_db, active_mind):
        result = _manage_rock("", mock_db, active_mind)
        assert result["error"] is True
        assert "title" in result["message"]

    def test_invalid_status(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({"year": 2026, "quarter": 1},)
        result = _manage_rock("Rock", mock_db, active_mind, status="invalid")
        assert result["error"] is True
        assert "status" in result["message"]

    def test_progress_out_of_range(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({"year": 2026, "quarter": 1},)
        result = _manage_rock("Rock", mock_db, active_mind, progress_pct=101)
        assert result["error"] is True
        assert "progress_pct" in result["message"]

    def test_progress_negative(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({"year": 2026, "quarter": 1},)
        result = _manage_rock("Rock", mock_db, active_mind, progress_pct=-1)
        assert result["error"] is True

    def test_no_quarter_no_cadence(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)  # empty cadence
        result = _manage_rock("Rock", mock_db, active_mind)
        assert result["error"] is True
        assert "quarter" in result["message"].lower()

    def test_create_new_rock_with_cadence(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        # execute_returning for upsert
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rock_id, "Launch Campaign", "on_track", 0, True)
        result = _manage_rock("Launch Campaign", mock_db, active_mind, description="Q1 Rock")
        assert result["rock_id"] == rock_id
        assert result["title"] == "Launch Campaign"
        assert result["is_new"] is True

    def test_update_by_rock_id(self, mock_db, active_mind):
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.execute_returning.return_value = (rock_id, "Updated Rock", "complete", 100)
        result = _manage_rock(
            "Updated Rock", mock_db, active_mind,
            rock_id=rock_id, status="complete", progress_pct=100,
        )
        assert result["rock_id"] == rock_id
        assert result["is_new"] is False

    def test_update_by_rock_id_not_found(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.execute_returning.return_value = None
        result = _manage_rock("Ghost", mock_db, active_mind, rock_id="bad-id", status="complete")
        assert result["error"] is True
        assert result["code"] == "NOT_FOUND"

    def test_update_by_rock_id_nothing_to_update(self, mock_db, active_mind):
        """When rock_id is provided but update_title is False and no other fields, return error."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _manage_rock("Ghost", mock_db, active_mind, rock_id="some-id")
        assert result["error"] is True
        assert "Nothing to update" in result["message"]

    def test_update_by_rock_id_with_update_title(self, mock_db, active_mind):
        """When update_title=True, title is included in SET clauses."""
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.execute_returning.return_value = (rock_id, "New Title", "on_track", 50)
        result = _manage_rock(
            "New Title", mock_db, active_mind,
            rock_id=rock_id, update_title=True,
        )
        assert result["rock_id"] == rock_id
        sql = mock_db.execute_returning.call_args[0][0]
        assert "title = %s" in sql

    def test_upsert_existing_rock(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rock_id, "Existing Rock", "off_track", 30, False)
        result = _manage_rock("Existing Rock", mock_db, active_mind, status="off_track", progress_pct=30)
        assert result["is_new"] is False
        assert result["status"] == "off_track"

    def test_explicit_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)  # no cadence needed
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rock_id, "Q2 Rock", "on_track", 0, True)
        result = _manage_rock("Q2 Rock", mock_db, active_mind, quarter_year=2026, quarter=2)
        assert not result.get("error")
        assert result["is_new"] is True

    def test_invalid_quarter_value(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _manage_rock("Rock", mock_db, active_mind, quarter_year=2026, quarter=5)
        assert result["error"] is True
        assert "quarter" in result["message"].lower()

    def test_title_length_limit(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _manage_rock("x" * 501, mock_db, active_mind)
        assert result["error"] is True
        assert "500" in result["message"]

    def test_update_by_rock_id_with_description_owner(self, mock_db, active_mind):
        """Covers the description/owner branches in rock_id update path."""
        import uuid
        rock_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.execute_returning.return_value = (rock_id, "Rock", "on_track", 50)
        result = _manage_rock(
            "Rock", mock_db, active_mind,
            rock_id=rock_id, description="New desc", owner="Bob",
        )
        assert result["is_new"] is False
        # Verify both description and owner were in SET clause
        sql = mock_db.execute_returning.call_args[0][0]
        assert "description" in sql
        assert "owner" in sql

    def test_upsert_db_error(self, mock_db, active_mind):
        """Covers the DB error path for upsert."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.execute_returning.return_value = None
        result = _manage_rock("Rock", mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "DB_ERROR"


# ============================================================
# get_rocks
# ============================================================


class TestGetRocks:
    """Test _get_rocks core function."""

    def test_no_active_mind(self, mock_db):
        result = _get_rocks(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _get_rocks(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_empty_results(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.fetch_all.return_value = []
        result = _get_rocks(mock_db, active_mind)
        assert result == []

    def test_with_deliverables(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        import uuid
        rid = str(uuid.uuid4())
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        mock_db.fetch_all.return_value = [
            (rid, "Rock 1", "Desc", "Alice", "on_track", 50, 2026, 1, now, now, 3, 67),
        ]
        result = _get_rocks(mock_db, active_mind)
        assert len(result) == 1
        assert result[0]["title"] == "Rock 1"
        assert result[0]["deliverable_count"] == 3
        assert result[0]["deliverable_completion_pct"] == 67

    def test_without_sprint_plans_table(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        mock_db.fetch_one.return_value = (_cadence_row(),)
        import uuid
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        rid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (rid, "Rock 1", None, None, "on_track", 0, 2026, 1, now, now),
        ]
        result = _get_rocks(mock_db, active_mind)
        assert len(result) == 1
        assert "deliverable_count" not in result[0]

    def test_status_filter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.fetch_all.return_value = []
        result = _get_rocks(mock_db, active_mind, status="complete")
        assert result == []
        # Verify the SQL includes status filter
        sql = mock_db.fetch_all.call_args[0][0]
        assert "r.status = %s" in sql

    def test_invalid_status_filter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _get_rocks(mock_db, active_mind, status="invalid")
        assert result["error"] is True


# ============================================================
# import_sprint_plan
# ============================================================


class TestImportSprintPlan:
    """Test _import_sprint_plan core function."""

    def test_no_active_mind(self, mock_db):
        result = _import_sprint_plan("data", "csv", mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        result = _import_sprint_plan("data", "csv", mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_empty_data(self, mock_db, active_mind):
        result = _import_sprint_plan("", "csv", mock_db, active_mind)
        assert result["error"] is True
        assert "empty" in result["message"].lower()

    def test_no_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [({},), None]
        result = _import_sprint_plan("data", "csv", mock_db, active_mind)
        assert result["error"] is True
        assert "quarter" in result["message"].lower()

    def test_invalid_format(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _import_sprint_plan("data", "xml", mock_db, active_mind)
        assert result["error"] is True
        assert "format" in result["message"].lower()

    def test_csv_happy_path(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),   # deliverable 1 (new)
            ("d2", True),   # deliverable 2 (new)
        ])
        csv_data = (
            "initiative_name,owner,sprint_number,deliverable\n"
            "Website Redesign,Alice,1,Design mockups\n"
            "SEO Campaign,Bob,2,Keyword research\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 2
        assert result["updated_count"] == 0
        assert result["sprint_plan_id"] == plan_id

    def test_csv_upsert_preserves_status(self, mock_db, active_mind):
        """Re-import updates deliverables but preserves status."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", False),  # deliverable 1 (updated, not new)
        ])
        csv_data = (
            "initiative_name,sprint_number,deliverable\n"
            "Website Redesign,1,Updated deliverable\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert result["imported_count"] == 0
        assert result["updated_count"] == 1
        # Verify the SQL uses ON CONFLICT and does NOT set status
        calls = mock_cursor.execute.call_args_list
        # Last execute call is the upsert
        sql = calls[-1][0][0]
        assert "ON CONFLICT" in sql
        assert "status = EXCLUDED.status" not in sql

    def test_csv_injection_chars_stripped_on_import(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        csv_data = (
            "initiative_name,sprint_number,deliverable\n"
            "=malicious,1,+evil command\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        # CSV injection characters are stripped by sanitize_csv_cell
        # Find the upsert call (last execute call)
        upsert_args = mock_cursor.execute.call_args_list[-1][0][1]
        assert upsert_args[2] == "malicious"  # injection chars stripped

    def test_json_happy_path(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        json_data = json.dumps([{
            "initiative_name": "API Integration",
            "sprint_number": 1,
            "deliverable": "Build endpoints",
        }])
        result = _import_sprint_plan(json_data, "json", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 1

    def test_json_not_list(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _import_sprint_plan('{"not": "a list"}', "json", mock_db, active_mind)
        assert result["error"] is True

    def test_json_malformed(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _import_sprint_plan("not json at all", "json", mock_db, active_mind)
        assert result["error"] is True

    def test_csv_long_cell_truncated(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        long_name = "a" * 600
        csv_data = f"initiative_name,sprint_number,deliverable\n{long_name},1,Short\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        upsert_args = mock_cursor.execute.call_args_list[-1][0][1]
        assert len(upsert_args[2]) == 500  # truncated to _MAX_CELL_CHARS

    def test_explicit_quarter(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [({},)]  # empty cadence
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        csv_data = "initiative_name,sprint_number,deliverable\nTest,1,Do thing\n"
        result = _import_sprint_plan(
            csv_data, "csv", mock_db, active_mind,
            quarter_year=2026, quarter=2,
        )
        assert not result.get("error")
        assert result["quarter_year"] == 2026
        assert result["quarter"] == 2

    def test_existing_plan_reused(self, mock_db, active_mind):
        """When plan already exists, reuses it."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ], existing_plan=True)
        csv_data = "initiative_name,sprint_number,deliverable\nTest,1,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert result["sprint_plan_id"] == plan_id

    def test_csv_missing_sprint_number_defaults_to_1(self, mock_db, active_mind):
        """Missing sprint_number defaults to 1."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        csv_data = "initiative_name,deliverable\nTest,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        # sprint_number param should be 1
        upsert_args = mock_cursor.execute.call_args_list[-1][0][1]
        assert upsert_args[5] == 1  # sprint_number position

    def test_csv_invalid_sprint_number_defaults_to_1(self, mock_db, active_mind):
        """Non-numeric sprint_number defaults to 1."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
        ])
        csv_data = "initiative_name,sprint_number,deliverable\nTest,abc,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")

    def test_no_valid_initiatives(self, mock_db, active_mind):
        """CSV with only empty initiative names returns error."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        csv_data = "initiative_name,sprint_number,deliverable\n,1,No name\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert result["error"] is True

    # ---- Wide CSV tests ----

    def test_wide_csv_happy_path(self, mock_db, active_mind):
        """Wide CSV format: 2 initiatives x 3 sprints."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        # 2 initiatives x 3 sprints = 6 deliverables, but empty cells skipped
        # Alice has 3 deliverables, Bob has 2 (Sprint 3 is empty)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True), ("d2", True), ("d3", True),  # Alice's 3 sprints
            ("d4", True), ("d5", True),  # Bob's 2 sprints (Sprint 3 empty)
        ])
        csv_data = (
            "Owner,Sprint 1,Sprint 2,Sprint 3,Goal/Target\n"
            ",10/17/2025,10/31/2025,11/14/2025,\n"
            "Alice,Draft v1,Review,Ship,Launch redesign\n"
            "Bob,Research,Prototype,,,New API\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 5
        assert result["sprint_plan_id"] == plan_id

    def test_wide_csv_preserves_status_on_reimport(self, mock_db, active_mind):
        """Wide CSV re-import preserves existing status via ON CONFLICT."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", False),  # updated, not new (status preserved)
        ])
        csv_data = (
            "Owner,Sprint 1,Goal/Target\n"
            ",10/17/2025,\n"
            "Alice,Updated text,Launch redesign\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert result["updated_count"] == 1
        assert result["imported_count"] == 0
        # Verify ON CONFLICT doesn't set status
        sql = mock_cursor.execute.call_args_list[-1][0][0]
        assert "ON CONFLICT" in sql
        assert "status = EXCLUDED.status" not in sql

    def test_wide_csv_date_parsing(self, mock_db, active_mind):
        """Wide CSV parses multiple date formats: MM/DD/YYYY, MM/DD/YY, ISO."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, mock_conn = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True), ("d2", True), ("d3", True),
        ])
        csv_data = (
            "Owner,Sprint 1,Sprint 2,Sprint 3,Goal/Target\n"
            ",10/17/2025,10/31/25,2025-11-14,\n"
            "Alice,Draft,Review,Ship,Goal\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        # Check that sprint_end_dates were set via UPDATE
        update_calls = [c for c in mock_cursor.execute.call_args_list if "sprint_end_dates" in str(c)]
        assert len(update_calls) == 1

    def test_wide_csv_empty_cells_skipped(self, mock_db, active_mind):
        """Empty sprint cells produce no deliverable."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),  # only Sprint 2 has content
        ])
        csv_data = (
            "Owner,Sprint 1,Sprint 2,Sprint 3,Goal/Target\n"
            ",10/17/2025,10/31/2025,11/14/2025,\n"
            "Alice,,Review,,Launch redesign\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 1

    def test_long_csv_still_works(self, mock_db, active_mind):
        """Long-format CSV still parses correctly (no Sprint header = long format)."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [
            ("d1", True),
            ("d2", True),
        ])
        csv_data = (
            "initiative_name,owner,sprint_number,deliverable\n"
            "Website Redesign,Alice,1,Design mockups\n"
            "SEO Campaign,Bob,2,Keyword research\n"
        )
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 2

    def test_transaction_rollback(self, mock_db, active_mind):
        """Mock cursor.execute to raise mid-import, verify rollback."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)

        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        # First fetchone returns None (no existing plan), second returns plan_id,
        # then raise on third call (during deliverable upsert)
        mock_cursor.fetchone.side_effect = [
            None,          # no existing plan
            (plan_id,),    # newly created plan
            Exception("db crashed"),  # simulate failure during deliverable insert
        ]

        # Make execute raise on the third call (upsert deliverable)
        call_count = [0]
        orig_execute = mock_cursor.execute

        def execute_with_error(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] >= 4:  # plan SELECT, plan INSERT, end_dates UPDATE, then fail on deliverable
                raise Exception("db crashed")
            return orig_execute(*args, **kwargs)

        mock_cursor.execute.side_effect = execute_with_error

        @contextmanager
        def _mock_connection():
            yield mock_conn

        mock_db.connection = _mock_connection

        csv_data = (
            "Owner,Sprint 1,Goal/Target\n"
            ",10/17/2025,\n"
            "Alice,Draft v1,Launch redesign\n"
        )
        with pytest.raises(Exception, match="db crashed"):
            _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        # The connection() context manager should trigger rollback via Database.connection()'s except clause
        # In our mock, the exception propagates out


# ============================================================
# get_sprint_plan
# ============================================================


class TestGetSprintPlan:
    """Test _get_sprint_plan core function."""

    def test_no_active_mind(self, mock_db):
        result = _get_sprint_plan(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_no_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _get_sprint_plan(mock_db, active_mind)
        assert result["error"] is True

    def test_no_plan_found(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            None,  # plan not found
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        assert result["sprint_plan_id"] is None
        assert result["deliverables"] == []

    def test_plan_with_deliverables(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, ["2026-03-15", "2026-04-01"]),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "Alice", "Launch site", 1, "Design", "in_progress", None, None, None, None, None),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        assert result["sprint_plan_id"] == plan_id
        assert len(result["deliverables"]) == 1
        assert result["deliverables"][0]["initiative_name"] == "Website"

    def test_plan_with_rock_data(self, mock_db, active_mind):
        import uuid
        plan_id = str(uuid.uuid4())
        rock_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, []),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "Alice", "Launch", 1, "Design", "complete", None,
             rock_id, "Website Redesign", "on_track", 60),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        d = result["deliverables"][0]
        assert d["rock_id"] == rock_id
        assert d["rock_title"] == "Website Redesign"
        assert d["rock_status"] == "on_track"

    def test_plan_without_rocks_table(self, mock_db, active_mind, monkeypatch):
        """When rocks table doesn't exist, deliverables lack rock fields."""
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, []),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "Alice", "Launch", 1, "Design", "in_progress", None, None),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        d = result["deliverables"][0]
        assert "rock_title" not in d
        assert d["rock_id"] is None

    def test_current_sprint_highlighting(self, mock_db, active_mind):
        """Deliverables in current sprint are highlighted."""
        import uuid
        from datetime import date, timedelta
        plan_id = str(uuid.uuid4())
        today = date.today()
        # Sprint 1 ends in the future
        end_dates = [(today + timedelta(days=10)).isoformat(), (today + timedelta(days=24)).isoformat()]
        mock_db.fetch_one.side_effect = [
            (_cadence_row(sprint=1),),
            (plan_id, end_dates),
        ]
        d1 = str(uuid.uuid4())
        d2 = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (d1, "Task A", "Alice", "Goal", 1, "Do A", "not_started", None, None, None, None, None),
            (d2, "Task A", "Alice", "Goal", 2, "Do B", "not_started", None, None, None, None, None),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        assert result["current_sprint"] == 1
        assert result["deliverables"][0]["is_current_sprint"] is True
        assert result["deliverables"][1]["is_current_sprint"] is False


# ============================================================
# update_sprint_status
# ============================================================


class TestUpdateSprintStatus:
    """Test _update_sprint_status core function."""

    def test_no_active_mind(self, mock_db):
        result = _update_sprint_status("init", "complete", mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_initiative_name(self, mock_db, active_mind):
        result = _update_sprint_status("", "complete", mock_db, active_mind)
        assert result["error"] is True

    def test_invalid_status(self, mock_db, active_mind):
        result = _update_sprint_status("init", "bad_status", mock_db, active_mind)
        assert result["error"] is True

    def test_happy_path(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            (["2026-04-15"],),  # sprint_end_dates
        ]
        import uuid
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website Redesign", "in_progress", 3),
        ]
        result = _update_sprint_status("website", "complete", mock_db, active_mind)
        assert result["deliverable_id"] == did
        assert result["status"] == "complete"
        assert result["previous_status"] == "in_progress"
        assert result["sprint_resolved_via"] == "sprint_plan"

    def test_no_match(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,  # no plan
        ]
        mock_db.fetch_all.return_value = []
        result = _update_sprint_status("nonexistent", "complete", mock_db, active_mind)
        assert result["code"] == "NOT_FOUND"

    def test_ambiguous_match(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,
        ]
        mock_db.fetch_all.return_value = [
            ("id1", "Website Design", "not_started", 3),
            ("id2", "Website Dev", "not_started", 3),
        ]
        result = _update_sprint_status("website", "complete", mock_db, active_mind)
        assert result["code"] == "AMBIGUOUS_MATCH"
        assert len(result["matches"]) == 2

    def test_with_rock_id_linking(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence lookup
            None,               # sprint plan lookup
            (1,),               # rock_id validation (rock exists for this mind)
        ]
        import uuid
        did = str(uuid.uuid4())
        rock_id = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "SEO Campaign", "not_started", 3),
        ]
        result = _update_sprint_status(
            "seo", "in_progress", mock_db, active_mind,
            rock_id=rock_id, notes="Starting work",
        )
        assert result["status"] == "in_progress"
        assert result["sprint_resolved_via"] == "cadence_fallback"
        # Verify rock_id was included in UPDATE
        update_call = mock_db.execute.call_args
        assert rock_id in update_call[0][1]

    def test_rock_id_cross_mind_rejected(self, mock_db, active_mind):
        """rock_id belonging to a different mind is rejected."""
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence lookup
            None,               # sprint plan lookup
            None,               # rock_id validation (not found for this mind)
        ]
        import uuid
        did = str(uuid.uuid4())
        rock_id = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "SEO Campaign", "not_started", 3),
        ]
        result = _update_sprint_status(
            "seo", "in_progress", mock_db, active_mind,
            rock_id=rock_id,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "rock_id" in result["message"]

    def test_explicit_sprint_number(self, mock_db, active_mind):
        """Explicit sprint_number skips cadence lookup for sprint."""
        import uuid
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Task", "not_started", 5),
        ]
        result = _update_sprint_status(
            "task", "complete", mock_db, active_mind,
            sprint_number=5,
        )
        assert result["status"] == "complete"
        assert result["sprint_resolved_via"] == "explicit"


# ============================================================
# get_current_sprint
# ============================================================


class TestGetCurrentSprintTool:
    """Test _get_current_sprint tool wrapper."""

    def test_no_active_mind(self, mock_db):
        result = _get_current_sprint(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_no_cadence(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _get_current_sprint(mock_db, active_mind)
        assert result["error"] is True
        assert "cadence" in result["message"].lower()

    def test_with_cadence_no_plan(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            None,  # no plan
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert result["sprint_number"] == 3
        assert result["current_sprint"] == result["sprint_number"]
        assert result["total_sprints"] == 6
        assert result["quarter_year"] == 2026

    def test_with_plan_dates(self, mock_db, active_mind):
        today = date.today()
        end_date = (today + timedelta(days=10)).isoformat()
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            ([end_date, (today + timedelta(days=24)).isoformat()],),
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert result["sprint_number"] == 1
        assert result["current_sprint"] == result["sprint_number"]
        assert result["sprint_ends"] == end_date
        assert result["days_remaining"] == 10

    def test_missing_cadence(self, mock_db, active_mind):
        """Empty cadence dict (no type/year/quarter) returns error."""
        mock_db.fetch_one.return_value = (None,)  # row with None cadence
        result = _get_current_sprint(mock_db, active_mind)
        assert result["error"] is True

    def test_sprint_plans_table_missing(self, mock_db, active_mind, monkeypatch):
        """When sprint_plans table doesn't exist, still returns from cadence."""
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _get_current_sprint(mock_db, active_mind)
        assert result["sprint_number"] == 3
        assert result["current_sprint"] == result["sprint_number"]
        assert "sprint_ends" not in result


# ============================================================
# start_quarter
# ============================================================


class TestStartQuarter:
    """Test _start_quarter core function."""

    def test_no_active_mind(self, mock_db):
        result = _start_quarter(2026, 1, mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_invalid_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 5, mock_db, active_mind)
        assert result["error"] is True

    def test_invalid_year(self, mock_db, active_mind):
        result = _start_quarter(2019, 1, mock_db, active_mind)
        assert result["error"] is True

    def test_no_cadence(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert result["error"] is True
        assert "cadence" in result["message"].lower()

    def test_creates_rocks(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        import uuid
        r1 = str(uuid.uuid4())
        r2 = str(uuid.uuid4())
        mock_db.execute_returning.side_effect = [
            (r1, "Rock A", "on_track", 0, True),
            (r2, "Rock B", "on_track", 0, True),
        ]
        rocks = [
            {"title": "Rock A", "owner": "Alice"},
            {"title": "Rock B", "description": "Second rock"},
        ]
        result = _start_quarter(2026, 2, mock_db, active_mind, rocks=rocks)
        assert not result.get("error")
        assert result["rocks_created"] == 2
        assert len(result["rock_ids"]) == 2

    def test_no_rocks(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert result["rocks_created"] == 0

    def test_empty_title_rock_skipped(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 1, mock_db, active_mind, rocks=[{"title": ""}])
        assert result["rocks_created"] == 0


# ============================================================
# quarterly_pacing
# ============================================================


class TestQuarterlyPacing:
    """Test _quarterly_pacing core function."""

    def test_no_active_mind(self, mock_db):
        result = _quarterly_pacing(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_no_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _quarterly_pacing(mock_db, active_mind)
        assert result["error"] is True

    def test_no_rocks(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,  # no plan
        ]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind)
        assert result["rocks"] == []
        assert result["at_risk_count"] == 0

    def test_pacing_calculations(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,
        ]
        import uuid
        mock_db.fetch_all.return_value = [
            (str(uuid.uuid4()), "On Track Rock", "on_track", 80),
            (str(uuid.uuid4()), "Behind Rock", "on_track", 5),
            (str(uuid.uuid4()), "Complete Rock", "complete", 100),
            (str(uuid.uuid4()), "Dropped Rock", "dropped", 0),
            (str(uuid.uuid4()), "At Risk Rock", "at_risk", 30),
        ]
        result = _quarterly_pacing(mock_db, active_mind)
        assert len(result["rocks"]) == 5

        # Complete and dropped rocks have special pacing
        rock_map = {r["title"]: r for r in result["rocks"]}
        assert rock_map["Complete Rock"]["pacing"] == "complete"
        assert rock_map["Dropped Rock"]["pacing"] == "dropped"
        assert rock_map["At Risk Rock"]["pacing"] == "at_risk"

    def test_explicit_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [({},), None]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind, quarter_year=2026, quarter=2)
        assert result["quarter_year"] == 2026
        assert result["quarter"] == 2


# ============================================================
# manage_agenda
# ============================================================


class TestManageAgenda:
    """Test _manage_agenda core function."""

    def test_no_active_mind(self, mock_db):
        result = _manage_agenda("Item", mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: False)
        result = _manage_agenda("Item", mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_empty_title(self, mock_db, active_mind):
        result = _manage_agenda("", mock_db, active_mind)
        assert result["error"] is True

    def test_invalid_action(self, mock_db, active_mind):
        result = _manage_agenda("Item", mock_db, active_mind, action="destroy")
        assert result["error"] is True

    def test_invalid_priority(self, mock_db, active_mind):
        result = _manage_agenda("Item", mock_db, active_mind, priority=5)
        assert result["error"] is True

    def test_add_proposed(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (aid, "Discuss Budget", "proposed")
        result = _manage_agenda("Discuss Budget", mock_db, active_mind)
        assert result["action_taken"] == "added"
        assert result["status"] == "proposed"

    def test_add_with_meeting_date(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (aid, "Review Deck", "scheduled")
        result = _manage_agenda(
            "Review Deck", mock_db, active_mind,
            meeting_date="2026-04-01",
        )
        assert result["status"] == "scheduled"

    def test_add_invalid_date(self, mock_db, active_mind):
        result = _manage_agenda("Item", mock_db, active_mind, meeting_date="not-a-date")
        assert result["error"] is True

    def test_resolve_by_fuzzy_match(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Budget Discussion", "proposed")]
        result = _manage_agenda("budget", mock_db, active_mind, action="resolve")
        assert result["action_taken"] == "resolved"
        assert result["status"] == "resolved"

    def test_defer(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Low Priority Item", "proposed")]
        result = _manage_agenda("low priority", mock_db, active_mind, action="defer")
        assert result["action_taken"] == "deferred"

    def test_schedule(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Q2 Planning", "proposed")]
        result = _manage_agenda(
            "q2 planning", mock_db, active_mind,
            action="schedule", meeting_date="2026-04-15",
        )
        assert result["action_taken"] == "scheduled"

    def test_schedule_no_date(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Item", "proposed")]
        result = _manage_agenda("item", mock_db, active_mind, action="schedule")
        assert result["error"] is True

    def test_schedule_invalid_date(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Item", "proposed")]
        result = _manage_agenda("item", mock_db, active_mind, action="schedule", meeting_date="bad")
        assert result["error"] is True

    def test_resolve_not_found(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _manage_agenda("nonexistent", mock_db, active_mind, action="resolve")
        assert result["code"] == "NOT_FOUND"

    def test_resolve_ambiguous(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = [
            ("id1", "Budget Q1", "proposed"),
            ("id2", "Budget Q2", "proposed"),
        ]
        result = _manage_agenda("budget", mock_db, active_mind, action="resolve")
        assert result["code"] == "AMBIGUOUS_MATCH"

    def test_resolve_by_agenda_id(self, mock_db, active_mind):
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (aid, "Item", "proposed")
        result = _manage_agenda("Item", mock_db, active_mind, action="resolve", agenda_id=aid)
        assert result["action_taken"] == "resolved"

    def test_resolve_by_agenda_id_not_found(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = None
        result = _manage_agenda("Item", mock_db, active_mind, action="resolve", agenda_id="bad")
        assert result["code"] == "NOT_FOUND"

    def test_add_db_error(self, mock_db, active_mind):
        mock_db.execute_returning.return_value = None
        result = _manage_agenda("Item", mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "DB_ERROR"

    def test_resolve_from_resolved_rejected(self, mock_db, active_mind):
        """Resolving an already-resolved item returns INVALID_INPUT."""
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (aid, "Test item", "resolved")
        result = _manage_agenda("Test item", mock_db, active_mind, action="resolve", agenda_id=aid)
        assert result.get("error") is True
        assert result["code"] == "INVALID_INPUT"

    def test_defer_from_resolved_rejected(self, mock_db, active_mind):
        """Deferring a resolved item returns INVALID_INPUT (resolved can only go to scheduled)."""
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (aid, "Test item", "resolved")
        result = _manage_agenda("Test item", mock_db, active_mind, action="defer", agenda_id=aid)
        assert result.get("error") is True
        assert result["code"] == "INVALID_INPUT"

    def test_schedule_from_resolved_allowed(self, mock_db, active_mind):
        """Scheduling a resolved item is allowed (resolved -> scheduled)."""
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (aid, "Test item", "resolved")
        result = _manage_agenda(
            "Test item", mock_db, active_mind,
            action="schedule", meeting_date="2026-04-15", agenda_id=aid,
        )
        assert result["action_taken"] == "scheduled"

    def test_resolve_from_deferred_rejected(self, mock_db, active_mind):
        """Resolving a deferred item is not allowed (deferred can only go to scheduled)."""
        import uuid
        aid = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (aid, "Test item", "deferred")
        result = _manage_agenda("Test item", mock_db, active_mind, action="resolve", agenda_id=aid)
        assert result.get("error") is True
        assert result["code"] == "INVALID_INPUT"


# ============================================================
# get_agenda
# ============================================================


class TestGetAgenda:
    """Test _get_agenda core function."""

    def test_no_active_mind(self, mock_db):
        result = _get_agenda(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_results(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_agenda(mock_db, active_mind)
        assert result == []

    def test_status_filter(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_agenda(mock_db, active_mind, status="proposed")
        assert result == []
        sql = mock_db.fetch_all.call_args[0][0]
        assert "status = %s" in sql

    def test_invalid_status(self, mock_db, active_mind):
        result = _get_agenda(mock_db, active_mind, status="invalid")
        assert result["error"] is True

    def test_date_filter(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_agenda(mock_db, active_mind, meeting_date="2026-04-01")
        assert result == []

    def test_invalid_date(self, mock_db, active_mind):
        result = _get_agenda(mock_db, active_mind, meeting_date="bad")
        assert result["error"] is True

    def test_priority_ordering(self, mock_db, active_mind):
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        mock_db.fetch_all.return_value = [
            ("id1", "High Priority", None, "proposed", 3, None, None, now),
            ("id2", "Low Priority", None, "proposed", 0, None, None, now),
        ]
        result = _get_agenda(mock_db, active_mind)
        assert len(result) == 2
        assert result[0]["priority"] == 3
        assert result[1]["priority"] == 0


# ============================================================
# manage_issue
# ============================================================


class TestManageIssue:
    """Test _manage_issue core function."""

    def test_no_active_mind(self, mock_db):
        result = _manage_issue("Issue", mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: False)
        result = _manage_issue("Issue", mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_empty_title(self, mock_db, active_mind):
        result = _manage_issue("", mock_db, active_mind)
        assert result["error"] is True

    def test_invalid_action(self, mock_db, active_mind):
        result = _manage_issue("Issue", mock_db, active_mind, action="destroy")
        assert result["error"] is True

    def test_invalid_priority(self, mock_db, active_mind):
        result = _manage_issue("Issue", mock_db, active_mind, priority=5)
        assert result["error"] is True

    def test_add_issue(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
        ]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (iid, "Cash Flow Issue", "identified")
        result = _manage_issue("Cash Flow Issue", mock_db, active_mind, description="Need to fix")
        assert result["action_taken"] == "added"
        assert result["status"] == "identified"

    def test_add_with_source_agenda(self, mock_db, active_mind):
        import uuid
        agenda_id = str(uuid.uuid4())
        iid = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            (agenda_id,),  # agenda match
        ]
        mock_db.execute_returning.return_value = (iid, "Issue", "identified")
        result = _manage_issue(
            "Issue", mock_db, active_mind,
            source_agenda_title="budget",
        )
        assert result["action_taken"] == "added"
        # Verify source_agenda_id was passed to INSERT
        insert_args = mock_db.execute_returning.call_args[0][1]
        assert agenda_id in insert_args

    def test_solve_requires_resolution(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
        ]
        import uuid
        mock_db.fetch_all.return_value = [
            (str(uuid.uuid4()), "Issue", "identified"),
        ]
        result = _manage_issue("Issue", mock_db, active_mind, action="solve")
        assert result["error"] is True
        assert "resolution" in result["message"].lower()

    def test_solve_with_resolution(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
        ]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Cash Issue", "discussed")]
        result = _manage_issue(
            "cash", mock_db, active_mind,
            action="solve", resolution="Reduced expenses by 20%",
        )
        assert result["action_taken"] == "solved"
        assert result["status"] == "solved"

    def test_solve_with_time_and_agenda(self, mock_db, active_mind):
        """Solve with time_discussed_minutes and source_agenda linking."""
        import uuid
        iid = str(uuid.uuid4())
        agenda_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            (agenda_id,),  # agenda match
        ]
        mock_db.fetch_all.return_value = [(iid, "Issue", "identified")]
        result = _manage_issue(
            "issue", mock_db, active_mind,
            action="solve", resolution="Fixed",
            time_discussed_minutes=30,
            source_agenda_title="budget",
        )
        assert result["action_taken"] == "solved"
        # Verify time and agenda_id in UPDATE
        update_args = mock_db.execute.call_args[0][1]
        assert 30 in update_args
        assert agenda_id in update_args

    def test_solve_creates_commitment(self, mock_db, active_mind, mock_config):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
        ]
        import uuid
        iid = str(uuid.uuid4())
        mem_id = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Staffing Issue", "identified")]

        with patch("coppermind_cmo.tools.memories.store_memory_core") as mock_store:
            mock_store.return_value = {"memory_id": mem_id}
            result = _manage_issue(
                "staffing", mock_db, active_mind, config=mock_config,
                action="solve", resolution="Hire contractor",
                todo_text="Find and hire marketing contractor by end of month",
            )
        assert result["action_taken"] == "solved"
        assert result["commitment_id"] == mem_id
        mock_store.assert_called_once()
        call_kwargs = mock_store.call_args
        assert call_kwargs[1]["memory_type"] == "commitment"

    def test_defer_issue(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Low Priority", "identified")]
        result = _manage_issue("low priority", mock_db, active_mind, action="defer")
        assert result["action_taken"] == "deferred"

    def test_defer_with_time(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Issue", "discussed")]
        result = _manage_issue(
            "issue", mock_db, active_mind,
            action="defer", time_discussed_minutes=10,
        )
        assert result["action_taken"] == "deferred"
        # Verify time was set in UPDATE
        update_args = mock_db.execute.call_args[0][1]
        assert 10 in update_args

    def test_discuss_issue(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Team Alignment", "identified")]
        result = _manage_issue(
            "team", mock_db, active_mind,
            action="discuss", time_discussed_minutes=15,
        )

    def test_discuss_with_description(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Topic", "identified")]
        result = _manage_issue(
            "topic", mock_db, active_mind,
            action="discuss", description="We talked about this",
        )
        assert result["action_taken"] == "discussed"

    def test_not_found(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        mock_db.fetch_all.return_value = []
        result = _manage_issue("ghost", mock_db, active_mind, action="solve", resolution="n/a")
        assert result["code"] == "NOT_FOUND"

    def test_ambiguous_match(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        mock_db.fetch_all.return_value = [
            ("id1", "Budget Q1", "identified"),
            ("id2", "Budget Q2", "identified"),
        ]
        result = _manage_issue("budget", mock_db, active_mind, action="solve", resolution="n/a")
        assert result["code"] == "AMBIGUOUS_MATCH"

    def test_update_by_issue_id(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            ("id1", "Issue", "identified"),  # issue by id
        ]
        result = _manage_issue(
            "Issue", mock_db, active_mind,
            action="solve", resolution="Fixed it",
            issue_id="id1",
        )
        assert result["action_taken"] == "solved"

    def test_issue_id_not_found(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,
        ]
        result = _manage_issue(
            "Ghost", mock_db, active_mind,
            action="solve", resolution="n/a", issue_id="bad",
        )
        assert result["code"] == "NOT_FOUND"

    def test_add_db_error(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        mock_db.execute_returning.return_value = None
        result = _manage_issue("Issue", mock_db, active_mind)
        assert result["code"] == "DB_ERROR"

    def test_solve_from_deferred_rejected(self, mock_db, active_mind):
        """Solving a deferred issue fails (must discuss first)."""
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Test issue", "deferred")]
        result = _manage_issue(
            "Test issue", mock_db, active_mind,
            action="solve", resolution="Fixed",
        )
        assert result.get("error") is True
        assert result["code"] == "INVALID_INPUT"

    def test_defer_from_solved_rejected(self, mock_db, active_mind):
        """Deferring a solved issue fails (solved can only go to discussed)."""
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Test issue", "solved")]
        result = _manage_issue(
            "Test issue", mock_db, active_mind,
            action="defer",
        )
        assert result.get("error") is True
        assert result["code"] == "INVALID_INPUT"

    def test_discuss_from_solved_allowed(self, mock_db, active_mind):
        """Discussing a solved issue is allowed (reopen for further discussion)."""
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        import uuid
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Test issue", "solved")]
        result = _manage_issue(
            "Test issue", mock_db, active_mind,
            action="discuss",
        )
        assert result["action_taken"] == "discussed"


# ============================================================
# get_issues
# ============================================================


class TestGetIssues:
    """Test _get_issues core function."""

    def test_no_active_mind(self, mock_db):
        result = _get_issues(mock_db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_empty_results(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_issues(mock_db, active_mind)
        assert result == []

    def test_status_filter(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_issues(mock_db, active_mind, status="identified")
        sql = mock_db.fetch_all.call_args[0][0]
        assert "status = %s" in sql

    def test_invalid_status(self, mock_db, active_mind):
        result = _get_issues(mock_db, active_mind, status="invalid")
        assert result["error"] is True

    def test_quarter_filter(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_issues(mock_db, active_mind, quarter_year=2026, quarter=1)
        sql = mock_db.fetch_all.call_args[0][0]
        assert "quarter_year = %s" in sql
        assert "quarter = %s" in sql

    def test_full_result(self, mock_db, active_mind):
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        import uuid
        iid = str(uuid.uuid4())
        cid = str(uuid.uuid4())
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (iid, "Issue Title", "Description", "Alice", 2, "solved",
             "We fixed it", cid, aid, 15, 2026, 1, now, now),
        ]
        result = _get_issues(mock_db, active_mind)
        assert len(result) == 1
        assert result[0]["issue_id"] == iid
        assert result[0]["commitment_id"] == cid
        assert result[0]["source_agenda_id"] == aid
        assert result[0]["time_discussed_minutes"] == 15

    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: False)
        result = _get_issues(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"


# ============================================================
# Additional coverage tests
# ============================================================


class TestTableDetectionExtended:
    """Test all four _has_* functions for full branch coverage."""

    def test_has_sprint_plans_false_not_cached(self, mock_db, monkeypatch):
        """False is NOT cached for sprint_plans — re-checks on next call."""
        monkeypatch.undo()
        eos_mod._sprint_plans_table_exists = None
        mock_db.fetch_one.return_value = None
        assert _has_sprint_plans(mock_db) is False
        # Second call re-queries
        mock_db.fetch_one.return_value = (1,)
        assert _has_sprint_plans(mock_db) is True
        assert eos_mod._sprint_plans_table_exists is True

    def test_has_sprint_plans_exception(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._sprint_plans_table_exists = None
        mock_db.fetch_one.side_effect = Exception("db down")
        assert _has_sprint_plans(mock_db) is False
        # Cache should still be None (not caching False)
        assert eos_mod._sprint_plans_table_exists is None

    def test_has_sprint_plans_cached_true(self, mock_db, monkeypatch):
        """Cached True path returns immediately without querying."""
        monkeypatch.undo()
        eos_mod._sprint_plans_table_exists = True
        result = _has_sprint_plans(mock_db)
        assert result is True
        mock_db.fetch_one.assert_not_called()

    def test_has_agenda_items_true_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._agenda_items_table_exists = None
        mock_db.fetch_one.return_value = (1,)
        assert _has_agenda_items(mock_db) is True
        assert eos_mod._agenda_items_table_exists is True
        # Cached return path
        mock_db.fetch_one.reset_mock()
        assert _has_agenda_items(mock_db) is True
        mock_db.fetch_one.assert_not_called()

    def test_has_agenda_items_false_not_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._agenda_items_table_exists = None
        mock_db.fetch_one.return_value = None
        assert _has_agenda_items(mock_db) is False

    def test_has_eos_issues_exception(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._eos_issues_table_exists = None
        mock_db.fetch_one.side_effect = Exception("connection lost")
        assert _has_eos_issues(mock_db) is False
        assert eos_mod._eos_issues_table_exists is None

    def test_has_eos_issues_false_not_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._eos_issues_table_exists = None
        mock_db.fetch_one.return_value = None
        assert _has_eos_issues(mock_db) is False

    def test_has_eos_issues_cached_true(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._eos_issues_table_exists = True
        assert _has_eos_issues(mock_db) is True
        mock_db.fetch_one.assert_not_called()

    def test_has_rocks_exception(self, mock_db, monkeypatch):
        """Rocks exception doesn't cache False."""
        monkeypatch.undo()
        eos_mod._rocks_table_exists = None
        mock_db.fetch_one.side_effect = Exception("oops")
        assert _has_rocks(mock_db) is False
        assert eos_mod._rocks_table_exists is None

    def test_has_rocks_false_not_cached(self, mock_db, monkeypatch):
        monkeypatch.undo()
        eos_mod._rocks_table_exists = None
        mock_db.fetch_one.return_value = None
        assert _has_rocks(mock_db) is False
        assert eos_mod._rocks_table_exists is None


class TestEscapeLike:
    """Test _escape_like helper."""

    def test_escapes_percent(self):
        from coppermind_cmo.tools.eos import _escape_like
        assert _escape_like("100% done") == "100\\% done"

    def test_escapes_underscore(self):
        from coppermind_cmo.tools.eos import _escape_like
        assert _escape_like("my_variable") == "my\\_variable"

    def test_escapes_backslash(self):
        from coppermind_cmo.tools.eos import _escape_like
        assert _escape_like("path\\to") == "path\\\\to"

    def test_normal_text_unchanged(self):
        from coppermind_cmo.tools.eos import _escape_like
        assert _escape_like("hello world") == "hello world"

    def test_combined(self):
        from coppermind_cmo.tools.eos import _escape_like
        assert _escape_like("100%_\\done") == "100\\%\\_\\\\done"


class TestCSVParsingEdgeCases:
    """Edge cases for CSV parsing."""

    def test_csv_with_none_key_value(self):
        """CSV row with extra columns produces None keys/values — should skip."""
        # Create CSV with trailing comma which produces a None-keyed column
        csv_data = "initiative_name,sprint_number,\nTest,1,\n"
        result = _parse_csv_data(csv_data)
        assert len(result) == 1
        assert result[0]["initiative_name"] == "Test"

    def test_csv_row_with_extra_fields(self):
        """CSV rows with more columns than headers produce None keys — trigger line 371."""
        # When a row has more values than headers, csv.DictReader sets restkey=None
        csv_data = "initiative_name,sprint_number\nTest,1,extra_value,another_extra\n"
        result = _parse_csv_data(csv_data)
        assert len(result) == 1
        assert result[0]["initiative_name"] == "Test"


class TestImportSprintPlanEdgeCases:
    """Additional import_sprint_plan tests for coverage."""

    def test_csv_exception_during_parse(self, mock_db, active_mind, monkeypatch):
        """CSV parse exception returns error."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        # Monkeypatch _parse_csv_data to raise
        monkeypatch.setattr(
            "coppermind_cmo.tools.eos._parse_csv_data",
            lambda data: (_ for _ in ()).throw(ValueError("bad csv")),
        )
        # Also monkeypatch _is_wide_csv to return False so it hits the long path
        monkeypatch.setattr(
            "coppermind_cmo.tools.eos._is_wide_csv",
            lambda data: False,
        )
        result = _import_sprint_plan("bad-csv", "csv", mock_db, active_mind)
        assert result["error"] is True
        assert "Invalid CSV" in result["message"]

    def test_json_over_max_initiatives(self, mock_db, active_mind):
        """JSON list exceeding _MAX_INITIATIVES gets truncated."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        # Create 110 items
        items = [{"initiative_name": f"Item {i}", "sprint_number": 1, "deliverable": f"D{i}"} for i in range(110)]
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [("d", True)] * 100)
        result = _import_sprint_plan(json.dumps(items), "json", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 100  # truncated

    def test_json_empty_initiative_skipped(self, mock_db, active_mind):
        """JSON items with empty initiative_name are skipped in the import loop."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        items = [
            {"initiative_name": "", "sprint_number": 1, "deliverable": "D1"},
            {"initiative_name": "Valid", "sprint_number": 1, "deliverable": "D2"},
        ]
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [("d1", True)])
        result = _import_sprint_plan(json.dumps(items), "json", mock_db, active_mind)
        assert not result.get("error")
        assert result["imported_count"] == 1


class TestImportSprintPlanMalformedJson:
    """Malformed JSON inputs return INVALID_INPUT, not exceptions."""

    def test_json_list_of_strings_rejected(self, mock_db, active_mind):
        """JSON like '["bad"]' should be rejected, not crash on .get()."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _import_sprint_plan('["bad", "also bad"]', "json", mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "object" in result["message"].lower()

    def test_json_negative_sprint_number_clamped(self, mock_db, active_mind):
        """sprint_number <= 0 should be clamped to 1, not fail at DB level."""
        import uuid
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        items = [{"initiative_name": "Task", "sprint_number": -1, "deliverable": "D1"}]
        mock_cursor, _ = _setup_import_mocks(mock_db, plan_id, [("d1", True)])
        result = _import_sprint_plan(json.dumps(items), "json", mock_db, active_mind)
        assert not result.get("error")
        # Verify sprint_number was clamped to 1 in the INSERT
        insert_call = mock_cursor.execute.call_args_list[-1]
        params = insert_call[0][1]
        sprint_num_idx = 5  # plan_id, mind_id, initiative, owner, quarterly_goal, sprint_number
        assert params[sprint_num_idx] == 1


class TestGetSprintPlanTableNotReady:
    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        result = _get_sprint_plan(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"


class TestUpdateSprintStatusEdgeCases:
    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        result = _update_sprint_status("init", "complete", mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_sprint_number_fallback_to_cadence(self, mock_db, active_mind):
        """When compute_current_sprint returns None, fallback to cadence sprint."""
        # cadence has sprint=3, but compute_current_sprint returns None
        mock_db.fetch_one.side_effect = [
            (_cadence_row(sprint=3),),  # cadence
            None,  # no plan row
        ]
        mock_db.fetch_all.return_value = []
        result = _update_sprint_status("nonexistent", "complete", mock_db, active_mind)
        # Should use sprint 3 from cadence fallback
        assert result["code"] == "NOT_FOUND"
        # Verify the search used sprint_number = 3
        search_params = mock_db.fetch_all.call_args[0][1]
        assert search_params[1] == 3  # sprint_number

    def test_sprint_number_fallback_compute_none(self, mock_db, active_mind, monkeypatch):
        """When compute_current_sprint returns None, fall back to cadence.sprint (line 620)."""
        monkeypatch.setattr(
            "coppermind_cmo.tools.eos.compute_current_sprint",
            lambda cadence, plan_dict: None,
        )
        mock_db.fetch_one.side_effect = [
            (_cadence_row(sprint=5),),  # cadence with sprint=5
            None,  # no plan row
        ]
        mock_db.fetch_all.return_value = []
        result = _update_sprint_status("nonexistent", "complete", mock_db, active_mind)
        assert result["code"] == "NOT_FOUND"
        search_params = mock_db.fetch_all.call_args[0][1]
        assert search_params[1] == 5  # used cadence fallback


class TestGetCurrentSprintEdgeCases:
    def test_invalid_sprint_end_date(self, mock_db, active_mind, monkeypatch):
        """Sprint end date that can't be parsed is silently skipped (lines 723-724)."""
        # Make compute_current_sprint return 1 (from cadence fallback),
        # and have sprint_end_dates[0] be invalid to trigger the except block.
        monkeypatch.setattr(
            "coppermind_cmo.tools.eos.compute_current_sprint",
            lambda cadence, plan_dict: 1,
        )
        mock_db.fetch_one.side_effect = [
            (_cadence_row(sprint=1),),
            (["not-a-date"],),  # invalid date at index 0
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert result["sprint_number"] == 1
        assert result["current_sprint"] == result["sprint_number"]
        # sprint_ends should NOT be set because the date failed to parse
        assert "sprint_ends" not in result


class TestQuarterlyPacingEdgeCases:
    def test_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _quarterly_pacing(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_with_sprint_plan_dates(self, mock_db, active_mind):
        """quarterly_pacing with sprint plan dates sets plan_dict."""
        from datetime import date, timedelta
        today = date.today()
        end_dates = [(today + timedelta(days=10)).isoformat()]
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (end_dates,),  # plan with sprint_end_dates
        ]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind)
        assert result["current_sprint"] == 1  # computed from sprint_end_dates

    def test_q4_uses_december_31(self, mock_db, active_mind):
        """Q4 end date must be Dec 31, not Dec 30 or Jan 1."""
        from datetime import date
        cadence = {"type": "eos", "year": 2026, "quarter": 4, "sprint": 1, "sprints_per_quarter": 6}
        mock_db.fetch_one.side_effect = [
            (cadence,),
            None,  # no sprint plan
        ]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind, quarter_year=2026, quarter=4)
        expected_remaining = max(0, (date(2026, 12, 31) - date.today()).days)
        assert result["days_remaining"] == expected_remaining

    def test_q1_uses_march_31(self, mock_db, active_mind):
        """Q1 end date must be Mar 31, not Apr 1."""
        from datetime import date
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 1, "sprints_per_quarter": 6}
        mock_db.fetch_one.side_effect = [
            (cadence,),
            None,
        ]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind, quarter_year=2026, quarter=1)
        expected_remaining = max(0, (date(2026, 3, 31) - date.today()).days)
        assert result["days_remaining"] == expected_remaining


class TestManageAgendaEdgeCases:
    def test_unknown_action_fallthrough(self, mock_db, active_mind):
        """The final return INVALID_INPUT at line 1005 (dead code, but testable by bypassing validation)."""
        # This line is technically unreachable because of the validation guard,
        # but we can test that validation catches unknown actions
        result = _manage_agenda("Item", mock_db, active_mind, action="invalid_action")
        assert result["error"] is True

    def test_get_agenda_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: False)
        result = _get_agenda(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"


class TestManageIssueEdgeCases:
    def test_unknown_action_fallthrough(self, mock_db, active_mind):
        """Validation catches unknown actions before the fallthrough return."""
        result = _manage_issue("Issue", mock_db, active_mind, action="invalid_action")
        assert result["error"] is True

    def test_get_issues_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: False)
        result = _get_issues(mock_db, active_mind)
        assert result["code"] == "MIGRATION_REQUIRED"


class TestRegistration:
    def test_register_adds_tools(self):
        """Verify register() calls mcp_server.tool() for all EOS tools."""
        mock_server = MagicMock()
        mock_server.tool.return_value = lambda f: f  # decorator passthrough
        eos_mod.register(mock_server)
        # 13 tools: manage_rock, get_rocks, import_sprint_plan, get_sprint_plan,
        # update_sprint_status, get_current_sprint, start_quarter, quarterly_pacing,
        # manage_agenda, get_agenda, manage_issue, get_issues, prep_l10
        assert mock_server.tool.call_count == 13
