"""Tests for save_output tool."""

import os
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.outputs import _save_output


class TestSaveOutput:
    def test_happy_path_saves_file(self, tmp_path):
        """Saves markdown file to correct subfolder and returns path."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Meeting Brief\nSome content here.",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "saved"
        assert result["subfolder"] == "Briefs"
        assert result["filename"].endswith("-brief.md")
        assert os.path.exists(result["path"])

        # Verify file content
        with open(result["path"]) as f:
            assert f.read() == "# Meeting Brief\nSome content here."

    def test_no_local_path_returns_skipped(self):
        """When local_path is not configured, returns skipped status."""
        db = MagicMock()
        db.fetch_one.return_value = (None, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Brief",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "skipped"
        assert "local_path" in result["reason"]

    def test_invalid_output_type_returns_error(self):
        """Invalid output_type returns INVALID_INPUT error."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Brief",
            output_type="invalid_type",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "invalid_type" in result["message"]

    def test_no_active_mind_returns_error(self):
        """No active mind returns NO_ACTIVE_MIND error."""
        db = MagicMock()

        result = _save_output(
            content="# Brief",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=None,
        )

        assert result["error"] is True
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_custom_filename_used(self, tmp_path):
        """Custom filename is used instead of auto-generated one."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Custom",
            output_type="report",
            filename="my-custom-report.md",
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "saved"
        assert result["filename"] == "my-custom-report.md"
        assert result["subfolder"] == "Reports"
        assert result["path"].endswith("my-custom-report.md")
        assert os.path.exists(result["path"])

    def test_all_output_types(self, tmp_path):
        """All valid output types map to correct subfolders."""
        expected = {
            "brief": "Briefs",
            "content": "Content",
            "meeting": "Meetings",
            "report": "Reports",
            "strategy": "Strategy",
            "handoff": "Handoff",
        }
        for output_type, subfolder in expected.items():
            db = MagicMock()
            local_path = str(tmp_path)
            db.fetch_one.return_value = (local_path, "acme-corp")
            mind = ("mind-1", "Acme Corp")

            result = _save_output(
                content=f"# {output_type}",
                output_type=output_type,
                filename=None,
                db=db,
                active_mind=mind,
            )

            assert result["status"] == "saved", f"Failed for {output_type}"
            assert result["subfolder"] == subfolder, f"Wrong subfolder for {output_type}"

    def test_empty_content_returns_error(self):
        """Empty content returns INVALID_INPUT error."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="   ",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_creates_subfolder_if_missing(self, tmp_path):
        """Subfolder is created if it doesn't exist."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        # Subfolder doesn't exist yet
        subfolder_path = os.path.join(local_path, "Coppermind", "Briefs")
        assert not os.path.exists(subfolder_path)

        result = _save_output(
            content="# Brief",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "saved"
        assert os.path.exists(subfolder_path)

    def test_mind_not_in_db_returns_error(self):
        """Mind not found in DB returns INTERNAL_ERROR."""
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Brief",
            output_type="brief",
            filename=None,
            db=db,
            active_mind=mind,
        )

        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"

    def test_path_traversal_filename_sanitized(self, tmp_path):
        """Path traversal in filename is sanitized to just the basename."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Malicious",
            output_type="brief",
            filename="../../etc/passwd",
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "saved"
        # Filename should be sanitized to just "passwd"
        assert result["filename"] == "passwd"
        # File should be inside the correct subfolder, not escaped
        assert "Coppermind/Briefs/passwd" in result["path"]
        assert os.path.exists(result["path"])

    def test_normal_filename_works(self, tmp_path):
        """A normal filename with date prefix works fine."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        result = _save_output(
            content="# Content",
            output_type="content",
            filename="2026-03-24-content.md",
            db=db,
            active_mind=mind,
        )

        assert result["status"] == "saved"
        assert result["filename"] == "2026-03-24-content.md"
        assert os.path.exists(result["path"])

    def test_path_traversal_with_dotdot_and_slashes(self, tmp_path):
        """Various path traversal tricks are all caught by basename stripping."""
        db = MagicMock()
        local_path = str(tmp_path)
        db.fetch_one.return_value = (local_path, "acme-corp")
        mind = ("mind-1", "Acme Corp")

        traversal_filenames = [
            "../secret.md",
            "../../etc/cron.d/backdoor",
            "/tmp/evil.md",
            "subdir/nested.md",
        ]
        for malicious in traversal_filenames:
            result = _save_output(
                content="# Test",
                output_type="brief",
                filename=malicious,
                db=db,
                active_mind=mind,
            )
            assert result["status"] == "saved", f"Failed for {malicious}"
            # The resolved path must be inside the subfolder
            assert os.path.realpath(result["path"]).startswith(
                os.path.realpath(os.path.join(local_path, "Coppermind", "Briefs"))
            ), f"Path escaped subfolder for {malicious}"
