"""Tests for switch_client confirmation stats (spec 2.5-switch-client-confirmation)."""

import json
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.tools.minds import (
    _collect_mind_stats,
    _format_confirmation,
    _switch_client,
)
import coppermind_cmo.tools.minds as minds_mod


@pytest.fixture(autouse=True)
def reset_caches():
    """Reset table caches between tests."""
    import coppermind_cmo.tools.daily_loop as dl_mod
    dl_mod._has_meeting_log = None
    yield
    dl_mod._has_meeting_log = None


class TestCollectMindStats:
    def test_brand_voice_set(self):
        """Reports brand voice as set with word count (counts actual text, not JSON keys)."""
        db = MagicMock()
        db.fetch_one.return_value = None

        bv = {"tone": ["casual", "direct"], "avoid": ["jargon"]}
        stats = _collect_mind_stats("mind-1", db, brand_voice=bv, cadence={})
        assert "set" in stats["brand_voice"]
        assert "words" in stats["brand_voice"]
        # Should count actual words: casual, direct, jargon = 3 words
        assert "3 words" in stats["brand_voice"]

    def test_brand_voice_not_set(self):
        """Reports brand voice as not set when empty."""
        db = MagicMock()
        db.fetch_one.return_value = None

        stats = _collect_mind_stats("mind-1", db, brand_voice={}, cadence={})
        assert stats["brand_voice"] == "not set"

    def test_eos_configured(self):
        """Reports EOS with quarter and year."""
        db = MagicMock()
        db.fetch_one.return_value = None

        stats = _collect_mind_stats("mind-1", db, cadence={"quarter": 2, "year": 2026})
        assert stats["eos"] == "Q2 2026 active"

    def test_eos_not_configured(self):
        """Reports EOS as not configured when cadence is empty."""
        db = MagicMock()
        db.fetch_one.return_value = None

        stats = _collect_mind_stats("mind-1", db, cadence={})
        assert stats["eos"] == "not configured"

    def test_eos_quarter_end_countdown(self):
        """Shows countdown when quarter end is within 14 days."""
        end_dt = datetime.now(timezone.utc) + timedelta(days=5)
        db = MagicMock()
        db.fetch_one.return_value = None

        stats = _collect_mind_stats(
            "mind-1", db,
            cadence={"quarter": 1, "year": 2026, "quarter_end": end_dt.isoformat()},
        )
        assert "ends in" in stats["eos"]
        assert "days)" in stats["eos"]

    def test_last_meeting_today(self):
        """Shows 'today' when last meeting is today."""
        now = datetime.now(timezone.utc)
        db = MagicMock()
        db.fetch_one.side_effect = lambda sql, params=None: (
            (1,) if "information_schema" in sql
            else (now,) if "meeting_log" in sql
            else None
        )

        stats = _collect_mind_stats("mind-1", db)
        assert stats["last_meeting"] == "today"

    def test_last_meeting_past_date(self):
        """Shows portable date format (no %-d) for past meetings."""
        past = datetime(2026, 3, 5, tzinfo=timezone.utc)
        db = MagicMock()
        db.fetch_one.side_effect = lambda sql, params=None: (
            (1,) if "information_schema" in sql
            else (past,) if "meeting_log" in sql
            else None
        )

        stats = _collect_mind_stats("mind-1", db)
        assert stats["last_meeting"] == "Mar 5"

    def test_no_meetings(self):
        """Shows 'no meetings yet' when meeting_log is empty."""
        db = MagicMock()
        db.fetch_one.side_effect = lambda sql, params=None: (
            (1,) if "information_schema" in sql
            else None
        )

        stats = _collect_mind_stats("mind-1", db)
        assert stats["last_meeting"] == "no meetings yet"

    def test_stale_activity_noted(self):
        """Includes last_activity when >30 days ago."""
        stale_dt = datetime.now(timezone.utc) - timedelta(days=45)
        db = MagicMock()
        db.fetch_one.side_effect = lambda sql, params=None: (
            (stale_dt,) if "MAX(created_at)" in sql
            else None
        )

        stats = _collect_mind_stats("mind-1", db)
        assert "last_activity" in stats
        assert "45 days ago" in stats["last_activity"]

    def test_recent_activity_not_noted(self):
        """Does NOT include last_activity when < 30 days ago."""
        recent_dt = datetime.now(timezone.utc) - timedelta(days=5)
        db = MagicMock()
        db.fetch_one.side_effect = lambda sql, params=None: (
            (recent_dt,) if "MAX(created_at)" in sql
            else None
        )

        stats = _collect_mind_stats("mind-1", db)
        assert "last_activity" not in stats


class TestFormatConfirmation:
    def test_full_stats(self):
        """Full confirmation with all stats."""
        stats = {
            "brand_voice": "set (850 words)",
            "eos": "Q2 2026 active",
            "last_meeting": "Mar 20",
        }
        line = _format_confirmation("Julica", 47, stats)
        assert line == "Switched to Julica. 47 memories, last meeting Mar 20, brand voice: set (850 words), EOS: Q2 2026 active."

    def test_new_mind(self):
        """New mind with nothing configured — shows graceful defaults per spec."""
        stats = {
            "brand_voice": "not set",
            "eos": "not configured",
            "last_meeting": "no meetings yet",
        }
        line = _format_confirmation("Acme Corp", 0, stats)
        assert "Switched to Acme Corp" in line
        assert "0 memories" in line
        assert "not set" in line
        assert "not configured" in line
        assert "no meetings yet" in line

    def test_stale_activity_appended(self):
        """Stale activity note appended after the main line."""
        stats = {
            "brand_voice": "set (100 words)",
            "eos": "Q1 2026 active",
            "last_meeting": "Feb 1",
            "last_activity": "45 days ago",
        }
        line = _format_confirmation("OldClient", 10, stats)
        assert line.endswith("Last activity: 45 days ago.")

    def test_exact_count_no_rounding(self):
        """Large memory counts show exact number with comma formatting."""
        stats = {"brand_voice": "set (50 words)", "eos": "Q1 2026 active", "last_meeting": "today"}
        line = _format_confirmation("BigCorp", 1247, stats)
        assert "1,247 memories" in line


class TestSwitchClientReturnsConfirmation:
    def test_existing_mind_has_confirmation(self, mock_db, mock_config):
        """switch_client for existing mind returns confirmation and stats."""
        # Mock existing mind lookup
        # Row: id, name, slug, archived_at, is_internal, cadence, company_info, brand_voice, local_path
        mock_db.fetch_one.side_effect = lambda sql, params=None: (
            ("mind-uuid", "TestClient", "testclient", None, False,
             {"quarter": 2, "year": 2026}, "{}", {"tone": ["casual"]}, None)
            if "FROM client_minds" in sql and "LOWER" in sql
            else (42,) if "COUNT(*)" in sql and "is_current" in sql
            else (1,) if "information_schema" in sql and "is_internal" in sql
            else (1,) if "information_schema" in sql and "local_path" in sql
            else (1,) if "information_schema" in sql and "revoked_at" in sql
            else (1,) if "information_schema" in sql and "meeting_log" in sql
            else None
        )

        set_mind = MagicMock()

        with patch("coppermind_cmo.tools.minds._get_tip_for_switch", return_value=None):
            with patch("coppermind_cmo.tools.minds._has_is_internal", return_value=True):
                with patch("coppermind_cmo.tools.minds._has_local_path", return_value=True):
                    result = _switch_client(
                        "TestClient", False, mock_db, set_mind,
                        customer_id="cust-1",
                    )

        assert "confirmation" in result
        assert "Switched to TestClient" in result["confirmation"]
        assert "42 memories" in result["confirmation"]
        assert "stats" in result
        assert "brand_voice" in result["stats"]

    def test_new_mind_has_confirmation(self, mock_db, mock_config):
        """switch_client for new mind returns confirmation with empty stats."""
        # No existing mind found, create new
        mock_db.fetch_one.side_effect = lambda sql, params=None: (
            (1,) if "information_schema" in sql and "is_internal" in sql
            else (1,) if "information_schema" in sql and "local_path" in sql
            else (1,) if "information_schema" in sql and "revoked_at" in sql
            else None
        )
        mock_db.execute_returning.return_value = ("new-mind-uuid", "NewClient", "newclient")

        set_mind = MagicMock()

        with patch("coppermind_cmo.tools.minds._get_tip_for_switch", return_value=None):
            with patch("coppermind_cmo.tools.minds._has_is_internal", return_value=True):
                with patch("coppermind_cmo.tools.minds._has_local_path", return_value=True):
                    result = _switch_client(
                        "NewClient", True, mock_db, set_mind,
                        customer_id="cust-1",
                    )

        assert result["is_new"] is True
        assert "confirmation" in result
        assert "Switched to NewClient" in result["confirmation"]
        assert "0 memories" in result["confirmation"]
        assert "not set" in result["confirmation"]
        assert "not configured" in result["confirmation"]
