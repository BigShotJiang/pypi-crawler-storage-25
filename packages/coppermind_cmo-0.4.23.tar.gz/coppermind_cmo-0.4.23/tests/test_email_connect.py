"""Tests for email_status tool."""

from unittest.mock import MagicMock

from coppermind_cmo.tools.email_connect import _email_status


class TestEmailStatus:
    def _mock_db(self, last_check=None, memory_count=0, pending_count=0, breakdown=None):
        db = MagicMock()

        def fetch_one_handler(query, params=None):
            if "MAX" in query:
                return (last_check,)
            if "memories" in query.lower() and "count" in query.lower():
                return (memory_count,)
            if "email_attribution_log" in query:
                return (pending_count,)
            return None

        def fetch_all_handler(query, params=None):
            return breakdown or []

        db.fetch_one = MagicMock(side_effect=fetch_one_handler)
        db.fetch_all = MagicMock(side_effect=fetch_all_handler)
        return db

    def test_no_activity(self):
        db = self._mock_db()
        result = _email_status(db, MagicMock(), "cust-1")
        assert result["last_email_check"] is None
        assert result["memories_this_week"] == 0
        assert result["unattributed_count"] == 0
        assert result["source_breakdown"] == {}

    def test_with_activity(self):
        db = self._mock_db(
            last_check="2026-03-28T10:00:00+00:00",
            memory_count=12,
            pending_count=2,
            breakdown=[("gmail", 42), ("outlook", 7)],
        )
        result = _email_status(db, MagicMock(), "cust-1")
        assert result["last_email_check"] == "2026-03-28T10:00:00+00:00"
        assert result["memories_this_week"] == 12
        assert result["unattributed_count"] == 2
        assert result["source_breakdown"] == {"gmail": 42, "outlook": 7}

    def test_returns_all_fields(self):
        db = self._mock_db()
        result = _email_status(db, MagicMock(), "cust-1")
        for key in ("last_email_check", "memories_this_week", "unattributed_count", "source_breakdown"):
            assert key in result
