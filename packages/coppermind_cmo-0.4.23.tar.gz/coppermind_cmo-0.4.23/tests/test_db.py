"""Tests for db.py — connection pool and query helpers."""

import threading
import pytest
from unittest.mock import MagicMock, patch
from psycopg2.pool import PoolError
from coppermind_cmo.db import Database


class TestStructuredLogging:
    def test_db_uses_tool_logger(self):
        """Fix 2.1: db.py must use ToolLogger, not stdlib logging."""
        from coppermind_cmo.db import logger
        from coppermind_cmo.log import ToolLogger
        assert isinstance(logger, ToolLogger)


class TestDatabaseInit:
    def test_creates_with_config(self):
        config = MagicMock()
        db = Database(config)
        assert db._pool is None

    def test_pool_not_created_until_first_use(self):
        config = MagicMock()
        db = Database(config)
        assert db._pool is None


class TestConnection:
    def test_connection_context_manager_returns_conn(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        with db.connection() as conn:
            assert conn is mock_conn
        mock_pool.putconn.assert_called_once_with(mock_conn)

    def test_connection_returns_to_pool_on_exception(self):
        from psycopg2.extensions import STATUS_READY
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_conn.status = STATUS_READY  # healthy after successful rollback
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        with pytest.raises(RuntimeError):
            with db.connection() as conn:
                raise RuntimeError("boom")
        mock_pool.putconn.assert_called_once_with(mock_conn)


class TestExecute:
    def test_execute_returning_returns_row(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = ("uuid-1",)
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        row = db.execute_returning("INSERT INTO t RETURNING id", [])
        assert row == ("uuid-1",)
        mock_conn.commit.assert_called_once()


class TestConnectionRollback:
    def test_connection_rollback_called_on_exception(self):
        from psycopg2.extensions import STATUS_READY
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_conn.status = STATUS_READY  # healthy after successful rollback
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        with pytest.raises(RuntimeError):
            with db.connection() as conn:
                raise RuntimeError("boom")
        mock_conn.rollback.assert_called_once()
        mock_pool.putconn.assert_called_once_with(mock_conn)


class TestFetchAll:
    def test_fetch_all_returns_rows(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        expected_rows = [("a", 1), ("b", 2)]
        mock_cursor.fetchall.return_value = expected_rows
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        result = db.fetch_all("SELECT * FROM t")
        assert result == expected_rows
        mock_cursor.fetchall.assert_called_once()


class TestFetchOne:
    def test_fetch_one_returns_row(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        expected_row = ("uuid-1", "name")
        mock_cursor.fetchone.return_value = expected_row
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        result = db.fetch_one("SELECT * FROM t WHERE id = %s", [1])
        assert result == expected_row
        mock_cursor.fetchone.assert_called_once()

    def test_fetch_one_returns_none_when_no_row(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = None
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        result = db.fetch_one("SELECT * FROM t WHERE id = %s", [999])
        assert result is None


class TestExecuteCommit:
    def test_execute_calls_commit(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        db.execute("UPDATE t SET x = 1")
        mock_conn.commit.assert_called_once()


class TestClose:
    def test_close_when_pool_exists(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        db._pool = mock_pool

        db.close()
        mock_pool.closeall.assert_called_once()
        assert db._pool is None

    def test_close_when_pool_is_none(self):
        config = MagicMock()
        db = Database(config)
        assert db._pool is None
        db.close()  # Should not raise
        assert db._pool is None


class TestEnsurePool:
    @patch("coppermind_cmo.db.ThreadedConnectionPool")
    def test_ensure_pool_creates_pool(self, mock_pool_cls):
        config = MagicMock()
        config.pg_host = "localhost"
        config.pg_port = 5432
        config.pg_db = "test"
        config.pg_user = "user"
        config.pg_password = "pass"
        config.api_key = ""  # self-hosted mode: no SSL kwargs
        db = Database(config)

        mock_pool_instance = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = (1,)
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool_instance.getconn.return_value = mock_conn
        mock_pool_cls.return_value = mock_pool_instance

        db.fetch_one("SELECT 1")
        mock_pool_cls.assert_called_once_with(
            1, 3,
            host="localhost", port=5432, dbname="test",
            user="user", password="pass",
            connect_timeout=10,
            options="-c statement_timeout=30000",
            keepalives=1, keepalives_idle=30,
            keepalives_interval=10, keepalives_count=5,
        )


class TestPoolExhaustion:
    def test_getconn_pool_error_is_raised(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_pool.getconn.side_effect = PoolError("connection pool exhausted")
        db._pool = mock_pool

        # After first PoolError, connection() rebuilds the pool and retries.
        # Patch _ensure_pool to re-set the failing mock pool so the retry also fails.
        def _ensure_with_mock():
            if db._pool is None:
                db._pool = mock_pool
        db._ensure_pool = _ensure_with_mock

        with pytest.raises(PoolError):
            with db.connection() as conn:
                pass


class TestPoolRebuildSuccess:
    """Connection pool rebuild succeeds on retry after initial PoolError."""

    @patch("coppermind_cmo.db.ThreadedConnectionPool")
    def test_pool_rebuild_succeeds_on_retry(self, mock_pool_cls):
        """First getconn raises PoolError, pool rebuilt, second attempt succeeds."""
        config = MagicMock()
        config.pg_host = "localhost"
        config.pg_port = 5432
        config.pg_db = "test"
        config.pg_user = "user"
        config.pg_password = "pass"
        config.api_key = ""
        config.customer_id = ""
        db = Database(config)

        # First pool: getconn raises PoolError
        failing_pool = MagicMock()
        failing_pool.getconn.side_effect = PoolError("connection pool exhausted")

        # Second pool (rebuilt): getconn succeeds
        healthy_conn = MagicMock()
        healthy_conn.closed = 0
        healthy_pool = MagicMock()
        healthy_pool.getconn.return_value = healthy_conn

        mock_pool_cls.side_effect = [failing_pool, healthy_pool]

        with db.connection() as conn:
            assert conn is healthy_conn

        assert mock_pool_cls.call_count == 2
        healthy_pool.putconn.assert_called_once_with(healthy_conn)


class TestReadMethodsCommit:
    def test_fetch_all_commits_after_read(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [("a",)]
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        db.fetch_all("SELECT 1")
        mock_conn.commit.assert_called_once()

    def test_fetch_one_commits_after_read(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = ("a",)
        mock_conn.cursor.return_value.__enter__ = lambda s: mock_cursor
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        db.fetch_one("SELECT 1")
        mock_conn.commit.assert_called_once()


class TestThreadSafeInit:
    @patch("coppermind_cmo.db.ThreadedConnectionPool")
    def test_concurrent_ensure_pool_creates_only_one_pool(self, mock_pool_cls):
        config = MagicMock()
        config.pg_host = "localhost"
        config.pg_port = 5432
        config.pg_db = "test"
        config.pg_user = "user"
        config.pg_password = "pass"
        db = Database(config)

        mock_pool_instance = MagicMock()
        mock_pool_cls.return_value = mock_pool_instance

        barrier = threading.Barrier(5)

        def init_pool():
            barrier.wait()
            db._ensure_pool()

        threads = [threading.Thread(target=init_pool) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        mock_pool_cls.assert_called_once()


class TestDeadConnectionRecycling:
    def test_dead_connection_evicted_on_rollback_failure(self):
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 1
        mock_conn.rollback.side_effect = Exception("connection is closed")
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        with pytest.raises(RuntimeError):
            with db.connection() as conn:
                raise RuntimeError("query failed")

        mock_pool.putconn.assert_called_once_with(mock_conn, close=True)

    def test_healthy_connection_returned_normally(self):
        from psycopg2.extensions import STATUS_READY
        config = MagicMock()
        db = Database(config)
        mock_pool = MagicMock()
        mock_conn = MagicMock()
        mock_conn.closed = 0
        mock_conn.status = STATUS_READY  # healthy after successful rollback
        mock_pool.getconn.return_value = mock_conn
        db._pool = mock_pool

        with pytest.raises(RuntimeError):
            with db.connection() as conn:
                raise RuntimeError("query failed")

        mock_conn.rollback.assert_called_once()
        mock_pool.putconn.assert_called_once_with(mock_conn)


