"""Integration tests for synthesis pipeline: IngestEngine auto-queuing, SynthesisEngine processing, and full flow.

These tests verify the integration between components using mocks -- no live DB.
"""

from __future__ import annotations

import json
import uuid
from unittest.mock import MagicMock, patch, call

import pytest

import coppermind_cmo.ingest as ingest_mod
from coppermind_cmo.ingest import IngestEngine
from coppermind_cmo.synthesis import (
    SynthesisEngine,
    _FALLBACK_SYNTHESIS_PROMPT,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SAMPLE_MEMORIES = [
    {"content": "Acme paused LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9},
    {"content": "Sarah is VP of Marketing at Acme", "memory_type": "stakeholder", "confidence": 0.85},
    {"content": "Budget shifted from growth to optimization", "memory_type": "fact", "confidence": 0.88},
]

SAMPLE_SYNTHESIS_RESPONSE = json.dumps([
    {
        "content": "Acme's strategic posture has shifted from growth to cost optimization over 2 meetings",
        "memory_type": "fact",
        "confidence": 0.85,
        "evidence": "March: 'invest in new channels'. April: 'cut non-performing spend'",
    },
])


def _make_ingest_engine(mock_db, mock_config, store_fn=None):
    """Create an IngestEngine with standard test setup."""
    active_mind = ("mind-uuid", "Acme Corp")
    if store_fn is None:
        store_fn = MagicMock(return_value={"memory_id": str(uuid.uuid4())})
    return IngestEngine(mock_db, mock_config, active_mind, store_fn=store_fn)


def _make_synthesis_engine(mock_db, mock_config, store_fn=None, llm_fn=None):
    """Create a SynthesisEngine with standard test setup."""
    active_mind = ("mind-uuid", "Acme Corp")
    if store_fn is None:
        call_log = []

        def _store_fn(**kwargs):
            call_log.append(kwargs)
            return {"memory_id": str(uuid.uuid4()), "status": "created"}

        _store_fn.calls = call_log
        store_fn = _store_fn

    if llm_fn is None:
        llm_fn = lambda config, prompt: SAMPLE_SYNTHESIS_RESPONSE

    eng = SynthesisEngine(
        db=mock_db,
        config=mock_config,
        active_mind=active_mind,
        store_fn=store_fn,
        llm_fn=llm_fn,
    )
    eng._prompt_template = _FALLBACK_SYNTHESIS_PROMPT
    return eng


# ===========================================================================
# TestIngestAutoQueue: IngestEngine queuing documents for synthesis
# ===========================================================================

class TestIngestAutoQueue:
    """Test that IngestEngine queues documents for synthesis after extraction."""

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_queues_when_3_plus_new_memories(self, mock_extract, mock_db, mock_config):
        """IngestEngine should INSERT into synthesis_queue when 3+ new memories extracted."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> table exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = ("doc-uuid-123",)

        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        engine.process_source(
            source_type="transcript",
            source_ref="/meetings/april.txt",
            content="Short text under chunk size",
        )

        # Find the synthesis_queue INSERT among all db.execute calls
        execute_calls = mock_db.execute.call_args_list
        synthesis_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "synthesis_queue" in c[0][0]
        ]
        assert len(synthesis_calls) >= 1, (
            f"Expected at least one synthesis_queue INSERT, got execute calls: "
            f"{[c[0][0][:80] for c in execute_calls]}"
        )
        # Verify the SQL contains the right INSERT pattern
        sql = synthesis_calls[0][0][0]
        assert "INSERT INTO synthesis_queue" in sql
        assert "mind_id" in sql

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_no_queue_when_fewer_than_3_memories(self, mock_extract, mock_db, mock_config):
        """IngestEngine should NOT queue when fewer than 3 new memories."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> table exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = ("doc-uuid-456",)

        # Only 2 memories -- below the threshold
        mock_extract.return_value = SAMPLE_MEMORIES[:2]

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        engine.process_source(
            source_type="transcript",
            source_ref="/meetings/short.txt",
            content="Short text under chunk size",
        )

        execute_calls = mock_db.execute.call_args_list
        synthesis_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "synthesis_queue" in c[0][0]
        ]
        assert len(synthesis_calls) == 0, (
            "Should NOT insert into synthesis_queue with fewer than 3 new memories"
        )

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_no_queue_when_no_doc_id(self, mock_extract, mock_db, mock_config):
        """IngestEngine should NOT queue when _store_raw_document failed (doc_id=None)."""
        ingest_mod._has_raw_docs_table = None
        # _has_raw_documents_table returns False -> _store_raw_document returns None
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table -> table does NOT exist
            ("source-uuid",),  # _get_or_create_source
            None,              # _check_hash -> not processed
        ]

        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        engine.process_source(
            source_type="transcript",
            source_ref="/meetings/april.txt",
            content="Short text under chunk size",
        )

        execute_calls = mock_db.execute.call_args_list
        synthesis_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "synthesis_queue" in c[0][0]
        ]
        assert len(synthesis_calls) == 0, (
            "Should NOT insert into synthesis_queue when doc_id is None"
        )

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_queue_insert_is_non_fatal(self, mock_extract, mock_db, mock_config):
        """If the synthesis_queue INSERT fails, ingestion should still complete."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> table exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = ("doc-uuid-789",)

        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories

        # Make db.execute raise on synthesis_queue INSERT but succeed otherwise
        original_execute = mock_db.execute
        call_count = [0]

        def _conditional_execute(sql, params=None):
            call_count[0] += 1
            if "synthesis_queue" in sql:
                raise Exception("synthesis_queue table does not exist")
            return original_execute(sql, params)

        mock_db.execute = MagicMock(side_effect=_conditional_execute)

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)

        # Should not raise
        result = engine.process_source(
            source_type="transcript",
            source_ref="/meetings/april.txt",
            content="Short text under chunk size",
        )

        # Ingestion should have completed (memories stored)
        assert result["new"] >= 1 or result["updated"] >= 0

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_no_queue_when_all_memories_are_updates(self, mock_extract, mock_db, mock_config):
        """If store_fn returns reconsolidated (updated) instead of new, count should not reach 3."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> table exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = ("doc-uuid-update",)

        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories

        # store_fn returns reconsolidated (update, not new) for all
        mock_store = MagicMock(return_value={"memory_id": "mem-uuid", "reconsolidated": True})
        engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        result = engine.process_source(
            source_type="transcript",
            source_ref="/meetings/april.txt",
            content="Short text under chunk size",
        )

        # All 3 should be "updated", not "new", so counts["new"] < 3
        assert result["updated"] >= 1
        assert result["new"] == 0

        execute_calls = mock_db.execute.call_args_list
        synthesis_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "synthesis_queue" in c[0][0]
        ]
        assert len(synthesis_calls) == 0, (
            "Should NOT queue for synthesis when all memories are reconsolidated updates"
        )


# ===========================================================================
# TestSynthesisProcessQueue: SynthesisEngine processing queued items
# ===========================================================================

class TestSynthesisProcessQueue:
    """Test that SynthesisEngine.process_queue fetches and processes pending items."""

    @staticmethod
    def _setup_queue_claim_mock(mock_db, queue_rows):
        """Mock db.connection() for FOR UPDATE SKIP LOCKED queue claiming."""
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = queue_rows
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_db.connection.return_value.__exit__ = MagicMock(return_value=False)

    def test_process_queue_calls_synthesize_for_each_pending(self, mock_db, mock_config):
        """process_queue claims pending items with FOR UPDATE SKIP LOCKED and synthesizes each."""
        doc_id_1 = str(uuid.uuid4())
        doc_id_2 = str(uuid.uuid4())
        queue_id_1 = str(uuid.uuid4())
        queue_id_2 = str(uuid.uuid4())

        self._setup_queue_claim_mock(mock_db, [
            (queue_id_1, doc_id_1, 0),
            (queue_id_2, doc_id_2, 0),
        ])

        # fetch_all: existing memories for each synthesize_document call
        mock_db.fetch_all.side_effect = [
            [("fact", "Budget is 50K", None)],
            [("fact", "Budget is 50K", None)],
        ]

        # fetch_one: document fetch + daily cap for each
        mock_db.fetch_one.side_effect = [
            (doc_id_1, "Meeting content " * 500, "meeting1.txt", 5000, 1),
            (0,),
            (doc_id_2, "Meeting content " * 500, "meeting2.txt", 5000, 1),
            (1,),
        ]

        engine = _make_synthesis_engine(mock_db, mock_config)
        result = engine.process_queue()

        assert result["documents_processed"] == 2
        assert result["insights_found"] >= 2

    def test_process_queue_empty_returns_zero(self, mock_db, mock_config):
        """When no pending items exist, process_queue returns 0 processed."""
        self._setup_queue_claim_mock(mock_db, [])

        engine = _make_synthesis_engine(mock_db, mock_config)
        result = engine.process_queue()

        assert result["documents_processed"] == 0
        assert result["insights_found"] == 0

    def test_process_queue_marks_completed(self, mock_db, mock_config):
        """process_queue should UPDATE status to 'completed' after successful synthesis."""
        doc_id = str(uuid.uuid4())
        queue_id = str(uuid.uuid4())

        self._setup_queue_claim_mock(mock_db, [(queue_id, doc_id, 0)])

        mock_db.fetch_all.return_value = [("fact", "Budget is 50K", None)]
        mock_db.fetch_one.side_effect = [
            (doc_id, "Meeting content " * 500, "meeting.txt", 5000, 1),
            (0,),  # daily cap
        ]

        engine = _make_synthesis_engine(mock_db, mock_config)
        engine.process_queue()

        # Check that status was set to 'completed'
        execute_calls = mock_db.execute.call_args_list
        completed_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "status = 'completed'" in c[0][0]
        ]
        assert len(completed_calls) >= 1, (
            f"Expected a 'completed' status UPDATE, got: "
            f"{[c[0][0][:80] for c in execute_calls]}"
        )

    def test_process_queue_paused_via_env(self, mock_db, mock_config, monkeypatch):
        """When COPPERMIND_SYNTHESIS_ENABLED=false, process_queue returns paused."""
        monkeypatch.setenv("COPPERMIND_SYNTHESIS_ENABLED", "false")

        engine = _make_synthesis_engine(mock_db, mock_config)
        result = engine.process_queue()

        assert result["paused"] is True
        assert result["documents_processed"] == 0


# ===========================================================================
# TestFullPipeline: End-to-end ingest -> queue -> synthesize
# ===========================================================================

class TestFullPipeline:
    """End-to-end pipeline: ingest creates queue entry, SynthesisEngine processes it."""

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_ingest_then_synthesize(self, mock_extract, mock_db, mock_config):
        """After ingestion queues a doc, SynthesisEngine.process_queue picks it up."""
        ingest_mod._has_raw_docs_table = None

        # Track all execute calls to capture the synthesis_queue INSERT
        execute_log = []
        original_execute = MagicMock()

        def _tracking_execute(sql, params=None):
            execute_log.append({"sql": sql, "params": params})
            return original_execute(sql, params)

        mock_db.execute = MagicMock(side_effect=_tracking_execute)

        # Phase 1: Ingestion
        doc_id = "doc-uuid-pipeline"
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = (doc_id,)
        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories -> triggers queue

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        ingest_engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        ingest_result = ingest_engine.process_source(
            source_type="transcript",
            source_ref="/meetings/pipeline-test.txt",
            content="Short text under chunk size",
        )

        assert ingest_result["new"] >= 3

        # Verify synthesis_queue INSERT happened during ingestion
        synthesis_inserts = [
            e for e in execute_log if "synthesis_queue" in e["sql"]
        ]
        assert len(synthesis_inserts) >= 1, "Ingestion should have queued a synthesis entry"

        # Phase 2: Synthesis picks it up
        # Reset mock_db side_effects for the synthesis phase

        # Setup connection() mock for FOR UPDATE SKIP LOCKED queue claiming
        mock_claim_cursor = MagicMock()
        mock_claim_cursor.fetchall.return_value = [("queue-id-1", doc_id, 0)]
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_claim_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_db.connection.return_value.__exit__ = MagicMock(return_value=False)

        mock_db.fetch_all.side_effect = [
            # Existing memories for synthesis context
            [("decision", "Acme paused LinkedIn ads through Q2", None)],
        ]
        mock_db.fetch_one.side_effect = [
            # Document fetch for synthesize_document
            (doc_id, "Meeting content with lots of detail " * 200, "pipeline-test.txt", 5000, 1),
            # Daily cap check
            (0,),
        ]

        synthesis_engine = _make_synthesis_engine(mock_db, mock_config)
        synthesis_result = synthesis_engine.process_queue()

        assert synthesis_result["documents_processed"] == 1
        assert synthesis_result["insights_found"] >= 1

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_pipeline_skips_synthesis_for_small_ingestion(self, mock_extract, mock_db, mock_config):
        """When ingestion produces < 3 new memories, no synthesis queue entry and nothing to process."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        mock_db.execute_returning.return_value = ("doc-small",)
        mock_extract.return_value = SAMPLE_MEMORIES[:1]  # only 1 memory

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        ingest_engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        ingest_result = ingest_engine.process_source(
            source_type="transcript",
            source_ref="/meetings/short.txt",
            content="Short text under chunk size",
        )

        assert ingest_result["new"] == 1

        # No synthesis queue entry should exist
        execute_calls = mock_db.execute.call_args_list
        synthesis_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "synthesis_queue" in c[0][0]
        ]
        assert len(synthesis_calls) == 0

        # Synthesis engine finds nothing to process
        mock_claim_cursor = MagicMock()
        mock_claim_cursor.fetchall.return_value = []
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_claim_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_db.connection.return_value.__exit__ = MagicMock(return_value=False)

        synthesis_engine = _make_synthesis_engine(mock_db, mock_config)
        synthesis_result = synthesis_engine.process_queue()
        assert synthesis_result["documents_processed"] == 0

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_pipeline_synthesis_stores_with_correct_source_type(self, mock_extract, mock_db, mock_config):
        """Synthesis-created memories have source_type='synthesis' and tagged 'synthesis'."""
        ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            (1,),              # _has_raw_documents_table -> exists
            ("source-uuid",),  # _get_or_create_source -> existing source
            None,              # _check_hash -> not processed
        ]
        doc_id = "doc-uuid-tags"
        mock_db.execute_returning.return_value = (doc_id,)
        mock_extract.return_value = SAMPLE_MEMORIES  # 3 memories -> triggers queue

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        ingest_engine = _make_ingest_engine(mock_db, mock_config, store_fn=mock_store)
        ingest_engine.process_source(
            source_type="transcript",
            source_ref="/meetings/tags-test.txt",
            content="Short text under chunk size",
        )

        # Phase 2: Synthesis — setup queue claim mock
        mock_claim_cursor = MagicMock()
        mock_claim_cursor.fetchall.return_value = [("queue-id-1", doc_id, 0)]
        mock_conn = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_claim_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        mock_db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_db.connection.return_value.__exit__ = MagicMock(return_value=False)

        mock_db.fetch_all.side_effect = [
            [("fact", "Budget is 50K", None)],
        ]
        mock_db.fetch_one.side_effect = [
            (doc_id, "Meeting content " * 500, "tags-test.txt", 5000, 1),
            (0,),
        ]

        synthesis_call_log = []

        def _tracking_store(**kwargs):
            synthesis_call_log.append(kwargs)
            return {"memory_id": str(uuid.uuid4()), "status": "created"}

        synthesis_engine = _make_synthesis_engine(mock_db, mock_config, store_fn=_tracking_store)
        synthesis_engine.process_queue()

        # Verify synthesis store_fn was called with correct source_type
        assert len(synthesis_call_log) >= 1
        for stored_call in synthesis_call_log:
            assert stored_call["source_type"] == "synthesis"
            assert stored_call["source_ref"].startswith("synthesis:")
            assert "synthesis" in stored_call["tags"]
