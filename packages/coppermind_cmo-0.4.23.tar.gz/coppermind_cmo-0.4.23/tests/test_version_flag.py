"""Tests for --version / -V CLI flag."""

import os
import subprocess
import sys

from coppermind_cmo import __version__

# Ensure subprocess finds *this* checkout's source, not a different editable
# install. This matters when tests run from a git worktree that differs from
# the editable-install location.
_SRC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "src")


def _run_cli(*args: str) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    # Prepend our src so `python -m coppermind_cmo` resolves here
    env["PYTHONPATH"] = _SRC_DIR + os.pathsep + env.get("PYTHONPATH", "")
    return subprocess.run(
        [sys.executable, "-m", "coppermind_cmo", *args],
        capture_output=True, text=True, timeout=10, env=env,
    )


class TestVersionFlag:
    def test_version_flag(self):
        result = _run_cli("--version")
        assert result.returncode == 0
        assert __version__ in result.stdout

    def test_version_short_flag(self):
        result = _run_cli("-V")
        assert result.returncode == 0
        assert __version__ in result.stdout
