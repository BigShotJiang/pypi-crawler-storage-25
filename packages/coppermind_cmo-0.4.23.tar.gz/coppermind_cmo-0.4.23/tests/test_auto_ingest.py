"""Tests for auto_ingest tools: find_uningested_meetings, auto_ingest_transcript."""

from unittest.mock import MagicMock, patch
import pytest

from coppermind_cmo.tools.auto_ingest import (
    _find_uningested_meetings,
    _auto_ingest_transcript,
)
import coppermind_cmo.tools.daily_loop as daily_loop_mod

CUSTOMER_ID = "test-customer-123"


# ---------------------------------------------------------------------------
# find_uningested_meetings
# ---------------------------------------------------------------------------


class TestFindUningestedMeetings:
    def test_returns_uningested_meetings(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.fetch_all.return_value = [
            ("ml-1", "mind-a", "Weekly Sync", "2026-03-25T10:00:00", "cal-1", "confident", "Acme Corp"),
            ("ml-2", "mind-b", "Strategy Review", "2026-03-25T14:00:00", None, "confident", "Beta Inc"),
        ]

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["count"] == 2
        assert len(result["meetings"]) == 2
        assert result["meetings"][0]["meeting_log_id"] == "ml-1"
        assert result["meetings"][0]["mind_id"] == "mind-a"
        assert result["meetings"][0]["mind_name"] == "Acme Corp"
        assert result["meetings"][1]["meeting_log_id"] == "ml-2"
        assert result["meetings"][1]["mind_name"] == "Beta Inc"

    def test_returns_empty_when_none_found(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.fetch_all.return_value = []

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["count"] == 0
        assert result["meetings"] == []

    def test_no_table_returns_migration_error(self, mock_db):
        mock_db.fetch_one.return_value = None  # table doesn't exist

        result = _find_uningested_meetings(mock_db, CUSTOMER_ID)

        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_filters_by_customer_id(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.return_value = []

        _find_uningested_meetings(mock_db, CUSTOMER_ID)

        sql_arg = mock_db.fetch_all.call_args[0][0]
        params = mock_db.fetch_all.call_args[0][1]
        assert "customer_id = %s" in sql_arg
        assert params == [CUSTOMER_ID]

    def test_only_finds_confident_matches(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.return_value = []

        _find_uningested_meetings(mock_db, CUSTOMER_ID)

        sql_arg = mock_db.fetch_all.call_args[0][0]
        assert "match_confidence = 'confident'" in sql_arg
        assert "transcript_ingested = false" in sql_arg
        assert "mind_id IS NOT NULL" in sql_arg


# ---------------------------------------------------------------------------
# auto_ingest_transcript
# ---------------------------------------------------------------------------


class TestAutoIngestTranscript:
    """Tests for background-dispatched auto_ingest_transcript."""

    def test_dispatches_to_background(self, mock_db, mock_config):
        """Successful validation dispatches to start_background_ingestion."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
            ("ml-1",),               # meeting_log exists
        ]

        with patch("coppermind_cmo.background.start_background_ingestion") as mock_bg:
            mock_bg.return_value = {
                "status": "processing",
                "task_id": "abc123",
                "estimate": {"word_count": 50, "chunks": 1, "estimated_seconds": 3},
                "message": "Processing...",
            }
            result = _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Meeting notes about Q2 strategy...",
                source_ref="granola-meeting-123",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert result["status"] == "processing"
        assert "task_id" in result
        mock_bg.assert_called_once()
        call_kwargs = mock_bg.call_args[1]
        assert call_kwargs["text"] == "Meeting notes about Q2 strategy..."
        assert call_kwargs["mind_id"] == "mind-a"
        assert call_kwargs["mind_name"] == "Acme Corp"
        assert call_kwargs["source_type"] == "meeting"
        assert call_kwargs["source_ref"] == "granola-meeting-123"
        assert call_kwargs["post_process"] is not None

    def test_resolves_mind_name_from_db(self, mock_db, mock_config):
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("DB Resolved Name",),   # mind access check returns name
            ("ml-1",),               # meeting_log exists
        ]

        with patch("coppermind_cmo.background.start_background_ingestion") as mock_bg:
            mock_bg.return_value = {"status": "processing", "task_id": "x", "estimate": {}, "message": ""}
            _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="",  # empty — should resolve from DB
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-456",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )

        assert mock_bg.call_args[1]["mind_name"] == "DB Resolved Name"

    def test_callback_marks_ingested_on_success(self, mock_db, mock_config):
        """post_process callback marks meeting_log when memories are extracted."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
            ("ml-1",),               # meeting_log exists
        ]
        captured_callback = {}

        with patch("coppermind_cmo.background.start_background_ingestion") as mock_bg:
            mock_bg.return_value = {"status": "processing", "task_id": "x", "estimate": {}, "message": ""}
            _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-123",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )
            captured_callback["fn"] = mock_bg.call_args[1]["post_process"]

        # Simulate successful background completion
        callback_db = MagicMock()
        captured_callback["fn"](
            {"new": 5, "updated": 1, "skipped": 0},
            lambda: callback_db,
        )

        # Verify meeting_log was marked as ingested with idempotency guard
        callback_db.execute_returning.assert_called_once()
        mark_sql = callback_db.execute_returning.call_args[0][0]
        mark_params = callback_db.execute_returning.call_args[0][1]
        assert "transcript_ingested = true" in mark_sql
        assert "transcript_ingested = false" in mark_sql  # idempotency guard
        assert mark_params == ["ml-1", CUSTOMER_ID, "mind-a"]

    def test_callback_skips_mark_on_zero_memories(self, mock_db, mock_config):
        """post_process callback does NOT mark meeting_log when no memories extracted."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
            ("ml-1",),               # meeting_log exists
        ]
        captured_callback = {}

        with patch("coppermind_cmo.background.start_background_ingestion") as mock_bg:
            mock_bg.return_value = {"status": "processing", "task_id": "x", "estimate": {}, "message": ""}
            _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-789",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )
            captured_callback["fn"] = mock_bg.call_args[1]["post_process"]

        # Simulate background completion with zero memories
        callback_db = MagicMock()
        captured_callback["fn"](
            {"new": 0, "updated": 0, "skipped": 3},
            lambda: callback_db,
        )

        # Should NOT have tried to mark meeting_log
        callback_db.execute_returning.assert_not_called()

    def test_callback_handles_update_no_match(self, mock_db, mock_config):
        """post_process callback logs warning when UPDATE matches no rows (already ingested)."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
            ("ml-1",),               # meeting_log exists
        ]
        captured_callback = {}

        with patch("coppermind_cmo.background.start_background_ingestion") as mock_bg:
            mock_bg.return_value = {"status": "processing", "task_id": "x", "estimate": {}, "message": ""}
            _auto_ingest_transcript(
                mind_id="mind-a",
                mind_name="Acme Corp",
                meeting_log_id="ml-1",
                transcript_text="Some transcript...",
                source_ref="granola-123",
                db=mock_db,
                config=mock_config,
                customer_id=CUSTOMER_ID,
            )
            captured_callback["fn"] = mock_bg.call_args[1]["post_process"]

        # Simulate: UPDATE matched no rows (already ingested by concurrent run)
        callback_db = MagicMock()
        callback_db.execute_returning.return_value = None

        # Should not raise — just logs a warning
        captured_callback["fn"](
            {"new": 3, "updated": 0, "skipped": 0},
            lambda: callback_db,
        )

        # UPDATE was attempted but matched nothing
        callback_db.execute_returning.assert_called_once()

    def test_meeting_log_not_found_returns_error(self, mock_db, mock_config):
        """Invalid meeting_log_id fails synchronously before background dispatch."""
        mock_db.fetch_one.side_effect = [
            (1,),                    # table exists
            ("Acme Corp",),          # mind access check
            None,                    # meeting_log NOT found
        ]

        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Acme Corp",
            meeting_log_id="ml-nonexistent",
            transcript_text="Some transcript...",
            source_ref="granola-999",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )

        assert result["error"] is True
        assert result["code"] == "MEETING_LOG_NOT_FOUND"

    def test_empty_mind_id_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_meeting_log_id_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_transcript_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_empty_source_ref_returns_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_no_table_returns_migration_error(self, mock_db, mock_config):
        mock_db.fetch_one.return_value = None  # table doesn't exist

        result = _auto_ingest_transcript(
            mind_id="mind-a",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_mind_not_found_returns_error(self, mock_db, mock_config):
        mock_db.fetch_one.side_effect = [
            (1,),   # table exists
            None,   # mind not found
        ]

        result = _auto_ingest_transcript(
            mind_id="nonexistent-mind",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "MIND_NOT_FOUND"

    def test_whitespace_only_inputs_return_error(self, mock_db, mock_config):
        result = _auto_ingest_transcript(
            mind_id="   ",
            mind_name="Test",
            meeting_log_id="ml-1",
            transcript_text="Some text",
            source_ref="ref-1",
            db=mock_db,
            config=mock_config,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
