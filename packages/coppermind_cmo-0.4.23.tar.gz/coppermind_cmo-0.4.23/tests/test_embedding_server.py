"""Tests for embedding_server.py hardening changes."""

import sys
import threading
from unittest.mock import patch, MagicMock

# Pre-inject fake modules so the real ones (which import torch / require
# native packages not available in the test environment) are never loaded.
_fake_st_module = MagicMock()
_fake_waitress_module = MagicMock()
sys.modules.setdefault("sentence_transformers", _fake_st_module)
sys.modules.setdefault("waitress", _fake_waitress_module)

import coppermind_cmo.embedding_server as es_mod  # noqa: E402
from coppermind_cmo.embedding_server import _model_lock, app  # noqa: E402


class TestModelLoadingThreadSafety:
    """Fix 4.1: Thread-safe model loading with double-checked locking."""

    def setup_method(self):
        """Reset _model to None before each test."""
        es_mod._model = None

    def teardown_method(self):
        """Reset _model after each test."""
        es_mod._model = None

    def test_model_lock_is_threading_lock(self):
        assert isinstance(_model_lock, type(threading.Lock()))

    def test_get_model_loads_once(self):
        """Calling _get_model twice should only create one model."""
        mock_model = MagicMock()
        _fake_st_module.SentenceTransformer.return_value = mock_model
        _fake_st_module.SentenceTransformer.reset_mock()

        result1 = es_mod._get_model()
        result2 = es_mod._get_model()

        _fake_st_module.SentenceTransformer.assert_called_once()
        assert result1 is result2

    def test_concurrent_get_model_creates_one(self):
        """Multiple threads calling _get_model should create only one model."""
        mock_model = MagicMock()
        _fake_st_module.SentenceTransformer.return_value = mock_model
        _fake_st_module.SentenceTransformer.reset_mock()

        barrier = threading.Barrier(5)
        results = []

        def load():
            barrier.wait()
            results.append(es_mod._get_model())

        threads = [threading.Thread(target=load) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        _fake_st_module.SentenceTransformer.assert_called_once()
        assert all(r is mock_model for r in results)


class TestWaitressServing:
    """Fix 4.1: Flask dev server replaced with waitress."""

    def setup_method(self):
        es_mod._model = None

    def teardown_method(self):
        es_mod._model = None

    def test_main_uses_waitress(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        _fake_st_module.SentenceTransformer.reset_mock()
        _fake_waitress_module.serve.reset_mock()
        es_mod.main()
        _fake_waitress_module.serve.assert_called_once_with(
            app, host="127.0.0.1", port=8400, threads=4
        )

    @patch.dict("os.environ", {"COPPERMIND_EMBEDDING_PORT": "9999"})
    def test_main_respects_port_env(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        _fake_st_module.SentenceTransformer.reset_mock()
        _fake_waitress_module.serve.reset_mock()
        es_mod.main()
        _fake_waitress_module.serve.assert_called_once_with(
            app, host="127.0.0.1", port=9999, threads=4
        )


class TestEmbedEndpoint:
    """Basic tests for the /embed endpoint."""

    def setup_method(self):
        es_mod._model = None

    def teardown_method(self):
        es_mod._model = None

    def test_embed_missing_text_returns_400(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        with app.test_client() as client:
            resp = client.post("/embed", json={})
            assert resp.status_code == 400

    def test_embed_empty_text_returns_400(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        with app.test_client() as client:
            resp = client.post("/embed", json={"text": ""})
            assert resp.status_code == 400

    def test_embed_text_too_long_returns_400(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        with app.test_client() as client:
            resp = client.post("/embed", json={"text": "x" * 50001})
            assert resp.status_code == 400

    def test_health_returns_ok(self):
        _fake_st_module.SentenceTransformer.return_value = MagicMock()
        with app.test_client() as client:
            resp = client.get("/health")
            assert resp.status_code == 200
            data = resp.get_json()
            assert data["status"] == "ok"
            assert data["dimensions"] == 384
