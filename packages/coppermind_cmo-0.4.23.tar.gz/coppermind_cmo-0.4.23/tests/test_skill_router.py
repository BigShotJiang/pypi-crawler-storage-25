import io
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from coppermind_cmo.hooks import skill_router
from coppermind_cmo.hooks.skill_router import (
    build_hook_output,
    _strip_name_prefix,
    _match_skill,
    _load_assistant_name,
)


# --- Pattern matching: /cmo-prep ---

def test_match_prep_meeting(tmp_path):
    result = build_hook_output("prep my meeting with Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-prep" in result["hookSpecificOutput"]["additionalContext"]


def test_match_get_me_ready_for(tmp_path):
    result = build_hook_output("get me ready for my call with Sarah", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-prep" in result["hookSpecificOutput"]["additionalContext"]


def test_match_before_my_meeting(tmp_path):
    result = build_hook_output("before my meeting with Bluebell", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-prep" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-followup ---

def test_match_followup_email(tmp_path):
    result = build_hook_output("draft a follow-up email from today's meeting", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-followup" in result["hookSpecificOutput"]["additionalContext"]


def test_match_post_meeting(tmp_path):
    result = build_hook_output("post-meeting recap and action items", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-followup" in result["hookSpecificOutput"]["additionalContext"]


def test_match_recap_email(tmp_path):
    result = build_hook_output("send a recap email to the team", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-followup" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-act ---

def test_match_action_items(tmp_path):
    result = build_hook_output("what are my action items?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-act" in result["hookSpecificOutput"]["additionalContext"]


def test_match_overdue_tasks(tmp_path):
    result = build_hook_output("show me overdue tasks", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-act" in result["hookSpecificOutput"]["additionalContext"]


def test_match_what_needs_doing(tmp_path):
    result = build_hook_output("what needs doing today?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-act" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-quarterly ---

def test_match_quarterly_review(tmp_path):
    result = build_hook_output("let's do the quarterly review for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-quarterly" in result["hookSpecificOutput"]["additionalContext"]


def test_match_qbr(tmp_path):
    result = build_hook_output("time for the QBR", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-quarterly" in result["hookSpecificOutput"]["additionalContext"]


def test_match_q1_review(tmp_path):
    result = build_hook_output("Q1 review for Bluebell", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-quarterly" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-handoff ---

def test_match_handoff(tmp_path):
    result = build_hook_output("create a handoff document for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-handoff" in result["hookSpecificOutput"]["additionalContext"]


def test_match_transition_client(tmp_path):
    result = build_hook_output("we need to transition this client to the new CMO", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-handoff" in result["hookSpecificOutput"]["additionalContext"]


def test_match_wrap_up_engagement(tmp_path):
    result = build_hook_output("wrap up the engagement with Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-handoff" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-ingest ---

def test_match_pull_from_granola(tmp_path):
    result = build_hook_output("pull my recent notes from Granola", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-ingest" in result["hookSpecificOutput"]["additionalContext"]


def test_match_sync_granola(tmp_path):
    result = build_hook_output("sync my Granola meetings", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-ingest" in result["hookSpecificOutput"]["additionalContext"]


def test_match_import_from(tmp_path):
    result = build_hook_output("import from my Google Drive", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-ingest" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-batch ---

def test_match_batch_content(tmp_path):
    result = build_hook_output("let's do a batch content sprint", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-batch" in result["hookSpecificOutput"]["additionalContext"]


def test_match_write_for_all_clients(tmp_path):
    result = build_hook_output("write social posts for all clients", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-batch" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-retro ---

def test_match_sprint_retrospective(tmp_path):
    result = build_hook_output("let's do the sprint retrospective", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-retro" in result["hookSpecificOutput"]["additionalContext"]


def test_match_what_went_well(tmp_path):
    result = build_hook_output("what went well this sprint?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-retro" in result["hookSpecificOutput"]["additionalContext"]


def test_match_end_of_sprint(tmp_path):
    result = build_hook_output("end of sprint review for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-retro" in result["hookSpecificOutput"]["additionalContext"]


def test_match_how_did_sprint_go(tmp_path):
    result = build_hook_output("how did this sprint go?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-retro" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-audit ---

def test_match_marketing_audit(tmp_path):
    result = build_hook_output("run a marketing audit for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-audit" in result["hookSpecificOutput"]["additionalContext"]


def test_match_tech_stack_review(tmp_path):
    result = build_hook_output("let's do a tech stack review", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-audit" in result["hookSpecificOutput"]["additionalContext"]


def test_match_detective_mode(tmp_path):
    result = build_hook_output("time for detective mode", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-audit" in result["hookSpecificOutput"]["additionalContext"]


def test_match_whats_broken_marketing(tmp_path):
    result = build_hook_output("what's broken in our marketing?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-audit" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-strategy ---

def test_match_strategy_deck(tmp_path):
    result = build_hook_output("build a strategy deck for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-strategy" in result["hookSpecificOutput"]["additionalContext"]


def test_match_strategy_presentation(tmp_path):
    result = build_hook_output("strategy presentation for the board", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-strategy" in result["hookSpecificOutput"]["additionalContext"]


def test_match_build_slides(tmp_path):
    result = build_hook_output("build slides for the marketing strategy review", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-strategy" in result["hookSpecificOutput"]["additionalContext"]


def test_match_presenting_to_leadership(tmp_path):
    result = build_hook_output("I'm presenting to the exec team next week", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-strategy" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-report ---

def test_match_monthly_report(tmp_path):
    result = build_hook_output("write a monthly report for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-report" in result["hookSpecificOutput"]["additionalContext"]


def test_match_performance_report(tmp_path):
    result = build_hook_output("client performance report for March", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-report" in result["hookSpecificOutput"]["additionalContext"]


def test_match_how_did_we_do(tmp_path):
    result = build_hook_output("how did we do this month?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-report" in result["hookSpecificOutput"]["additionalContext"]


def test_match_results_report(tmp_path):
    result = build_hook_output("put together a results report for the team", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-report" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-budget ---

def test_match_marketing_budget(tmp_path):
    result = build_hook_output("let's review the marketing budget", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-budget" in result["hookSpecificOutput"]["additionalContext"]


def test_match_cut_spending(tmp_path):
    result = build_hook_output("we need to cut spending on ads", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-budget" in result["hookSpecificOutput"]["additionalContext"]


def test_match_vendor_review(tmp_path):
    result = build_hook_output("vendor review — are we getting value?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-budget" in result["hookSpecificOutput"]["additionalContext"]


def test_match_reallocate_budget(tmp_path):
    result = build_hook_output("reallocate the budget across channels", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-budget" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-campaign ---

def test_match_plan_campaign(tmp_path):
    result = build_hook_output("plan a campaign for Acme's new service", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-campaign" in result["hookSpecificOutput"]["additionalContext"]


def test_match_campaign_strategy(tmp_path):
    result = build_hook_output("campaign strategy for the spring launch", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-campaign" in result["hookSpecificOutput"]["additionalContext"]


def test_match_new_campaign(tmp_path):
    result = build_hook_output("let's build a new campaign", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-campaign" in result["hookSpecificOutput"]["additionalContext"]


def test_match_channel_mix(tmp_path):
    result = build_hook_output("what should the channel mix look like?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-campaign" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-proposal ---

def test_match_proposal(tmp_path):
    result = build_hook_output("write a proposal for Acme's Q3 engagement", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-proposal" in result["hookSpecificOutput"]["additionalContext"]


def test_match_sow(tmp_path):
    result = build_hook_output("draft a SOW for the new project", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-proposal" in result["hookSpecificOutput"]["additionalContext"]


def test_match_scope_of_work(tmp_path):
    result = build_hook_output("scope of work for the content retainer", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-proposal" in result["hookSpecificOutput"]["additionalContext"]


def test_match_new_engagement(tmp_path):
    result = build_hook_output("pitch for the next engagement with Bluebell", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-proposal" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-positioning ---

def test_match_positioning_strategy(tmp_path):
    result = build_hook_output("let's do the positioning strategy for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-positioning" in result["hookSpecificOutput"]["additionalContext"]


def test_match_value_proposition(tmp_path):
    result = build_hook_output("we need to define our value proposition", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-positioning" in result["hookSpecificOutput"]["additionalContext"]


def test_match_care_exercise(tmp_path):
    result = build_hook_output("run the CARE exercise for our avatar", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-positioning" in result["hookSpecificOutput"]["additionalContext"]


def test_match_messaging_pillars(tmp_path):
    result = build_hook_output("develop messaging pillars for the brand", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-positioning" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-kickoff ---

def test_match_kickoff(tmp_path):
    result = build_hook_output("plan the kick-off for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-kickoff" in result["hookSpecificOutput"]["additionalContext"]


def test_match_starting_engagement(tmp_path):
    result = build_hook_output("starting the engagement with Bluebell", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-kickoff" in result["hookSpecificOutput"]["additionalContext"]


def test_match_day_one_plan(tmp_path):
    result = build_hook_output("let's build a day one plan", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-kickoff" in result["hookSpecificOutput"]["additionalContext"]


def test_match_onboarding_agenda(tmp_path):
    result = build_hook_output("onboarding agenda for the new client", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-kickoff" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-nurture ---

def test_match_lead_nurture(tmp_path):
    result = build_hook_output("build a lead nurture sequence", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-nurture" in result["hookSpecificOutput"]["additionalContext"]


def test_match_drip_sequence(tmp_path):
    result = build_hook_output("build a drip sequence for new leads", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-nurture" in result["hookSpecificOutput"]["additionalContext"]


def test_match_welcome_series(tmp_path):
    result = build_hook_output("write a welcome series for webinar signups", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-nurture" in result["hookSpecificOutput"]["additionalContext"]


def test_match_email_sequence(tmp_path):
    result = build_hook_output("design an email sequence for the funnel", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-nurture" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-seo ---

def test_match_seo_strategy(tmp_path):
    result = build_hook_output("build an SEO strategy for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-seo" in result["hookSpecificOutput"]["additionalContext"]


def test_match_keyword_strategy(tmp_path):
    result = build_hook_output("keyword strategy for our new service", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-seo" in result["hookSpecificOutput"]["additionalContext"]


def test_match_local_seo(tmp_path):
    result = build_hook_output("local SEO plan for the Austin location", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-seo" in result["hookSpecificOutput"]["additionalContext"]


def test_match_backlink_strategy(tmp_path):
    result = build_hook_output("backlink strategy to improve domain authority", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-seo" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-team ---

def test_match_team_assessment(tmp_path):
    result = build_hook_output("team assessment for the marketing department", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-team" in result["hookSpecificOutput"]["additionalContext"]


def test_match_who_should_we_hire(tmp_path):
    result = build_hook_output("who should we hire next?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-team" in result["hookSpecificOutput"]["additionalContext"]


def test_match_head_vs_hands(tmp_path):
    result = build_hook_output("head vs hands assessment", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-team" in result["hookSpecificOutput"]["additionalContext"]


def test_match_org_chart(tmp_path):
    result = build_hook_output("let's review the marketing org chart", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-team" in result["hookSpecificOutput"]["additionalContext"]


# --- Conflict avoidance: new commands vs. existing ---

def test_quarterly_retro_stays_quarterly(tmp_path):
    """'quarterly retrospective' should match /cmo-quarterly, NOT /cmo-retro."""
    result = build_hook_output("quarterly retrospective for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-quarterly" in result["hookSpecificOutput"]["additionalContext"]


def test_new_client_stays_onboard(tmp_path):
    """'new client' should match /cmo-onboard, NOT /cmo-kickoff."""
    result = build_hook_output("I just signed a new client", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-onboard" in result["hookSpecificOutput"]["additionalContext"]


def test_review_blog_post_stays_write(tmp_path):
    """'review my blog post' should match /cmo-write, NOT /cmo-audit."""
    result = build_hook_output("review my blog post draft", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-write ---

def test_match_panel_review(tmp_path):
    result = build_hook_output("panel review this LinkedIn post", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_review_content(tmp_path):
    result = build_hook_output("review my blog post draft", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_critique_email(tmp_path):
    result = build_hook_output("critique this email copy before I send it", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_improve_draft(tmp_path):
    result = build_hook_output("improve this draft post for LinkedIn", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_write_me_a(tmp_path):
    result = build_hook_output("write me a LinkedIn post about spring HVAC tips", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_draft_me_a(tmp_path):
    result = build_hook_output("draft me a blog post about spring cleaning tips", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_help_me_write(tmp_path):
    result = build_hook_output("help me write this newsletter", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_punch_up(tmp_path):
    result = build_hook_output("punch up this email before I send it", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_make_this_better(tmp_path):
    result = build_hook_output("make this better", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_tighten_this_up(tmp_path):
    result = build_hook_output("tighten this up", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_polish_my(tmp_path):
    result = build_hook_output("polish my blog post intro", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_too_wordy(tmp_path):
    result = build_hook_output("this is too wordy", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_too_generic(tmp_path):
    result = build_hook_output("this feels too generic", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_is_this_any_good(tmp_path):
    result = build_hook_output("is this any good?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


def test_match_does_this_sound_right(tmp_path):
    result = build_hook_output("does this sound right for a LinkedIn post?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-write" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-brief ---

def test_match_catch_me_up(tmp_path):
    result = build_hook_output("catch me up", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


def test_match_what_did_i_miss(tmp_path):
    result = build_hook_output("what did I miss this week?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


def test_match_morning_briefing(tmp_path):
    result = build_hook_output("morning briefing please", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


def test_match_update_me(tmp_path):
    result = build_hook_output("update me on everything", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


# --- Pattern matching: /cmo-help ---

def test_match_what_can_you_do(tmp_path):
    result = build_hook_output("what can you do?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-help" in result["hookSpecificOutput"]["additionalContext"]


def test_match_im_lost(tmp_path):
    result = build_hook_output("I'm lost, help me out", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-help" in result["hookSpecificOutput"]["additionalContext"]


def test_match_tutorial(tmp_path):
    result = build_hook_output("show me a tutorial", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-help" in result["hookSpecificOutput"]["additionalContext"]


# --- Negative cases (no match) ---

def test_no_match_python_function(tmp_path):
    result = build_hook_output("write a Python function to parse JSON", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_no_match_generic_question(tmp_path):
    result = build_hook_output("what's the weather today?", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_no_match_switch_client(tmp_path):
    result = build_hook_output("switch to Acme Corp", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


# --- Name stripping ---

def test_strip_name_comma():
    assert _strip_name_prefix("Julie, catch me up", "Julie") == "catch me up"


def test_strip_name_colon():
    assert _strip_name_prefix("Julie: catch me up", "Julie") == "catch me up"


def test_strip_name_hey():
    assert _strip_name_prefix("hey Julie, what did I miss?", "Julie") == "what did I miss?"


def test_strip_name_case_insensitive():
    assert _strip_name_prefix("JULIE, catch me up", "Julie") == "catch me up"


def test_strip_name_no_match_leaves_prompt():
    assert _strip_name_prefix("catch me up", "Julie") == "catch me up"


def test_strip_name_partial_no_match():
    """Don't strip 'Jul' from 'Julie' if name is 'Julia'."""
    result = _strip_name_prefix("Julie, catch me up", "Julia")
    assert "Julie" in result


def test_strip_name_with_exclamation():
    assert _strip_name_prefix("Julie! catch me up", "Julie") == "catch me up"


def test_named_prompt_routes_correctly(tmp_path):
    """Full integration: name prefix stripped, then skill matched."""
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({"assistant_name": "Sage"}), encoding="utf-8")

    result = build_hook_output(
        "Sage, catch me up on everything",
        state_path=tmp_path / "s.json",
        config_path=config_path,
    )
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


# --- Hook behavior ---

def test_skip_explicit_slash_command(tmp_path):
    result = build_hook_output("/cmo-brief", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_skip_embedded_slash_command(tmp_path):
    result = build_hook_output("run /cmo-prep for Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_skip_blank_prompt(tmp_path):
    result = build_hook_output("   ", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_rate_limits_same_skill_same_session(tmp_path):
    state_path = tmp_path / "s.json"
    config_path = tmp_path / "c.json"

    first = build_hook_output("catch me up", session_id="s1", state_path=state_path, config_path=config_path)
    second = build_hook_output("catch me up again", session_id="s1", state_path=state_path, config_path=config_path)

    assert first is not None
    assert second is None


def test_different_skills_same_session_both_fire(tmp_path):
    state_path = tmp_path / "s.json"
    config_path = tmp_path / "c.json"

    first = build_hook_output("catch me up", session_id="s1", state_path=state_path, config_path=config_path)
    second = build_hook_output("what's overdue?", session_id="s1", state_path=state_path, config_path=config_path)

    assert first is not None
    assert second is not None
    assert "/cmo-brief" in first["hookSpecificOutput"]["additionalContext"]
    assert "/cmo-act" in second["hookSpecificOutput"]["additionalContext"]


def test_same_skill_different_sessions_both_fire(tmp_path):
    state_path = tmp_path / "s.json"
    config_path = tmp_path / "c.json"

    first = build_hook_output("catch me up", session_id="s1", state_path=state_path, config_path=config_path)
    second = build_hook_output("catch me up", session_id="s2", state_path=state_path, config_path=config_path)

    assert first is not None
    assert second is not None


def test_corrupted_state_file_recovers(tmp_path):
    state_path = tmp_path / "s.json"
    state_path.write_text("NOT JSON!!!", encoding="utf-8")

    result = build_hook_output("catch me up", state_path=state_path, config_path=tmp_path / "c.json")
    assert result is not None


def test_corrupted_config_file_still_routes(tmp_path):
    config_path = tmp_path / "c.json"
    config_path.write_text("{invalid", encoding="utf-8")

    result = build_hook_output("catch me up", state_path=tmp_path / "s.json", config_path=config_path)
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


def test_state_write_failure_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr("coppermind_cmo.hooks.skill_router._save_state", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    result = build_hook_output("catch me up", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_main_prints_hook_payload(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(skill_router, "DEFAULT_STATE_PATH", tmp_path / "s.json")
    monkeypatch.setattr(skill_router, "DEFAULT_CONFIG_PATH", tmp_path / "c.json")
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps({"prompt": "catch me up", "session_id": "abc"})))

    exit_code = skill_router.main()

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    assert output["hookSpecificOutput"]["hookEventName"] == "UserPromptSubmit"
    assert "/cmo-brief" in output["hookSpecificOutput"]["additionalContext"]


def test_main_ignores_invalid_json(monkeypatch, capsys):
    monkeypatch.setattr("sys.stdin", io.StringIO("{bad json"))
    assert skill_router.main() == 0
    assert capsys.readouterr().out == ""


def test_main_no_output_on_no_match(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(skill_router, "DEFAULT_STATE_PATH", tmp_path / "s.json")
    monkeypatch.setattr(skill_router, "DEFAULT_CONFIG_PATH", tmp_path / "c.json")
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps({"prompt": "hello world"})))

    assert skill_router.main() == 0
    assert capsys.readouterr().out == ""


# --- _load_assistant_name ---

def test_load_assistant_name_returns_name(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": "Sage"}), encoding="utf-8")
    assert _load_assistant_name(config) == "Sage"


def test_load_assistant_name_strips_whitespace(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": "  Sage  "}), encoding="utf-8")
    assert _load_assistant_name(config) == "Sage"


def test_load_assistant_name_returns_none_on_missing(tmp_path):
    assert _load_assistant_name(tmp_path / "nope.json") is None


def test_load_assistant_name_returns_none_on_empty(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": ""}), encoding="utf-8")
    assert _load_assistant_name(config) is None


# --- _match_skill unit tests ---

def test_match_skill_returns_none_for_garbage():
    assert _match_skill("asdfghjkl") is None


def test_match_skill_returns_tuple():
    result = _match_skill("prep my meeting")
    assert result is not None
    assert result[0] == "/cmo-prep"


# --- False positive guards ---

def test_no_match_call_with_vendor(tmp_path):
    result = build_hook_output("I had a call with the vendor about pricing", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None

def test_no_match_pull_from_generic(tmp_path):
    result = build_hook_output("pull the latest data from the database", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None

def test_match_pull_from_email(tmp_path):
    result = build_hook_output("pull my meeting notes from email", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-ingest" in result["hookSpecificOutput"]["additionalContext"]

def test_no_match_after_meeting_vague(tmp_path):
    result = build_hook_output("after the meeting we went to lunch", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None

def test_match_after_meeting_email(tmp_path):
    result = build_hook_output("after the meeting send a summary email", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-followup" in result["hookSpecificOutput"]["additionalContext"]

# --- /cmo-onboard ---

def test_match_new_client(tmp_path):
    result = build_hook_output("I just signed a new client", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-onboard" in result["hookSpecificOutput"]["additionalContext"]

def test_match_onboard(tmp_path):
    result = build_hook_output("let's onboard Acme Corp", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-onboard" in result["hookSpecificOutput"]["additionalContext"]

def test_match_set_up_client(tmp_path):
    result = build_hook_output("I need to set up a new client", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-onboard" in result["hookSpecificOutput"]["additionalContext"]

# --- Validation ---

def test_load_assistant_name_rejects_too_long(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": "A" * 21}), encoding="utf-8")
    assert _load_assistant_name(config) is None

def test_load_assistant_name_rejects_special_chars(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": "Julie<script>"}), encoding="utf-8")
    assert _load_assistant_name(config) is None

def test_load_assistant_name_allows_spaces(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"assistant_name": "My Sage"}), encoding="utf-8")
    assert _load_assistant_name(config) == "My Sage"

# --- Context message ---

def test_context_message_is_suggestion_not_directive(tmp_path):
    result = build_hook_output("catch me up", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    ctx = result["hookSpecificOutput"]["additionalContext"]
    assert "might be asking" in ctx
    assert "ignore this suggestion" in ctx

def test_context_includes_skill_name_with_named_prompt(tmp_path):
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({"assistant_name": "Sage"}), encoding="utf-8")
    result = build_hook_output("Sage, catch me up on everything", state_path=tmp_path / "s.json", config_path=config_path)
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]

# --- Session pruning ---

def test_stale_sessions_pruned(tmp_path):
    from coppermind_cmo.hooks.skill_router import _prune_stale_sessions
    from datetime import timedelta
    old_ts = (datetime.now(timezone.utc) - timedelta(hours=25)).isoformat()
    fresh_ts = datetime.now(timezone.utc).isoformat()
    state = {
        "sessions": {"old_session": ["/cmo-brief"], "fresh_session": ["/cmo-act"]},
        "session_timestamps": {"old_session": old_ts, "fresh_session": fresh_ts},
    }
    pruned = _prune_stale_sessions(state)
    assert "old_session" not in pruned["sessions"]
    assert "fresh_session" in pruned["sessions"]


def test_prune_removes_sessions_without_timestamp(tmp_path):
    from coppermind_cmo.hooks.skill_router import _prune_stale_sessions
    state = {
        "sessions": {"no_ts_session": ["/cmo-brief"], "has_ts": ["/cmo-act"]},
        "session_timestamps": {"has_ts": datetime.now(timezone.utc).isoformat()},
    }
    pruned = _prune_stale_sessions(state)
    assert "no_ts_session" not in pruned["sessions"]
    assert "has_ts" in pruned["sessions"]


# --- /cmo-brief negative lookahead tests ---

def test_no_match_catch_up_on_client(tmp_path):
    """'catch me up on Acme' should NOT trigger /cmo-brief (client-specific)."""
    result = build_hook_output("catch me up on Acme", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_match_catch_up_generic(tmp_path):
    """'catch me up on everything' should still trigger /cmo-brief."""
    result = build_hook_output("catch me up on everything", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]


def test_no_match_update_me_about_client(tmp_path):
    """'update me about Bluebell' should NOT trigger /cmo-brief."""
    result = build_hook_output("update me about Bluebell", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is None


def test_match_update_me_generic(tmp_path):
    """'update me' alone should trigger /cmo-brief."""
    result = build_hook_output("update me", state_path=tmp_path / "s.json", config_path=tmp_path / "c.json")
    assert result is not None
    assert "/cmo-brief" in result["hookSpecificOutput"]["additionalContext"]
