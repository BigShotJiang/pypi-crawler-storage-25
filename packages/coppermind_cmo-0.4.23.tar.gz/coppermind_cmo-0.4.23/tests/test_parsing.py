import pytest
from datetime import date, datetime, timezone
from coppermind_cmo.parsing import (
    escape_like, normalize_memory_type, parse_date, parse_datetime, sanitize_csv_cell,
)


class TestEscapeLike:
    def test_escapes_percent(self):
        assert escape_like("100%") == "100\\%"

    def test_escapes_underscore(self):
        assert escape_like("a_b") == "a\\_b"

    def test_escapes_backslash(self):
        assert escape_like("a\\b") == "a\\\\b"

    def test_passthrough(self):
        assert escape_like("hello") == "hello"

    def test_all_special(self):
        assert escape_like("\\%_") == "\\\\\\%\\_"

    def test_empty_string(self):
        assert escape_like("") == ""


class TestNormalizeMemoryType:
    def test_valid_type(self):
        assert normalize_memory_type("decision") == "decision"

    def test_strips_whitespace(self):
        assert normalize_memory_type("  fact  ") == "fact"

    def test_lowercases(self):
        assert normalize_memory_type("DECISION") == "decision"

    def test_replaces_spaces(self):
        assert normalize_memory_type("campaign outcome") == "campaign_outcome"

    def test_strips_trailing_punctuation(self):
        assert normalize_memory_type("fact.") == "fact"
        assert normalize_memory_type("decision,") == "decision"

    def test_invalid_returns_none(self):
        assert normalize_memory_type("bogus") is None

    def test_custom_valid_types(self):
        assert normalize_memory_type("custom", valid_types={"custom"}) == "custom"

    def test_empty_string(self):
        assert normalize_memory_type("") is None


class TestParseDate:
    def test_iso_format(self):
        assert parse_date("2026-03-22") == date(2026, 3, 22)

    def test_us_slash_4digit(self):
        assert parse_date("03/22/2026") == date(2026, 3, 22)

    def test_us_slash_2digit(self):
        assert parse_date("03/22/26") == date(2026, 3, 22)

    def test_strict_iso_rejects_us(self):
        assert parse_date("03/22/2026", strict_iso=True) is None

    def test_strict_iso_accepts_iso(self):
        assert parse_date("2026-03-22", strict_iso=True) == date(2026, 3, 22)

    def test_garbage_returns_none(self):
        assert parse_date("not-a-date") is None

    def test_empty_returns_none(self):
        assert parse_date("") is None

    def test_strips_whitespace(self):
        assert parse_date("  2026-03-22  ") == date(2026, 3, 22)


class TestParseDatetime:
    def test_iso_with_tz(self):
        result = parse_datetime("2026-03-22T10:00:00-05:00")
        assert result is not None
        assert result.tzinfo is not None

    def test_iso_naive(self):
        result = parse_datetime("2026-03-22T10:00:00")
        assert result is not None
        assert result.tzinfo is None

    def test_require_tz_rejects_naive(self):
        assert parse_datetime("2026-03-22T10:00:00", require_tz=True) is None

    def test_require_tz_accepts_utc(self):
        result = parse_datetime("2026-03-22T10:00:00+00:00", require_tz=True)
        assert result is not None

    def test_coerce_utc_adds_tz(self):
        result = parse_datetime("2026-03-22T10:00:00", coerce_utc=True)
        assert result is not None
        assert result.tzinfo == timezone.utc

    def test_coerce_utc_preserves_existing_tz(self):
        result = parse_datetime("2026-03-22T10:00:00-05:00", coerce_utc=True)
        assert result is not None
        assert result.tzinfo != timezone.utc  # preserves original

    def test_garbage_returns_none(self):
        assert parse_datetime("not-a-datetime") is None

    def test_empty_returns_none(self):
        assert parse_datetime("") is None


class TestSanitizeCsvCell:
    def test_strips_equals(self):
        assert sanitize_csv_cell("=cmd()") == "cmd()"

    def test_strips_plus(self):
        assert sanitize_csv_cell("+cmd()") == "cmd()"

    def test_strips_multiple_injection_chars(self):
        assert sanitize_csv_cell("=+@evil") == "evil"

    def test_truncates_at_default(self):
        assert len(sanitize_csv_cell("x" * 600)) == 500

    def test_custom_max(self):
        assert len(sanitize_csv_cell("x" * 200, max_chars=100)) == 100

    def test_clean_passthrough(self):
        assert sanitize_csv_cell("hello world") == "hello world"

    def test_strips_tab(self):
        assert sanitize_csv_cell("\tcmd") == "cmd"
