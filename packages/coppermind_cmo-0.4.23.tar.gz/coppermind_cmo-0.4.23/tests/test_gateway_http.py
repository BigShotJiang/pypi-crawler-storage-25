"""Tests for gateway_http.py — shared HTTP client for the Coppermind gateway."""

import httpx
from unittest.mock import patch, MagicMock, call

from coppermind_cmo.gateway_http import (
    gateway_headers, gateway_post, gateway_get,
    _should_retry, _get_retry_delay,
)


def _make_config(api_key="test-key", gateway_url="https://api.coppermind.dev"):
    config = MagicMock()
    config.api_key = api_key
    config.gateway_url = gateway_url
    return config


class TestGatewayHeaders:
    def test_authorization_bearer_token(self):
        headers = gateway_headers(_make_config(api_key="my-secret"), session_id="s1")
        assert headers["Authorization"] == "Bearer my-secret"

    def test_session_id_included(self):
        headers = gateway_headers(_make_config(), session_id="sess-abc")
        assert headers["X-Session-Id"] == "sess-abc"

    def test_exactly_two_keys(self):
        headers = gateway_headers(_make_config(), session_id="x")
        assert set(headers.keys()) == {"Authorization", "X-Session-Id"}


class TestGatewayPost:
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_success_returns_parsed_json(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"result": "ok"}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp

        result = gateway_post("embed", {"text": "hi"}, _make_config(), session_id="s1")

        assert result == {"result": "ok"}
        call_kwargs = mock_httpx.post.call_args
        assert call_kwargs.args[0] == "https://api.coppermind.dev/v1/embed"
        assert call_kwargs.kwargs["json"] == {"text": "hi"}
        assert call_kwargs.kwargs["headers"]["Authorization"] == "Bearer test-key"

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_url_strips_trailing_slash(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp

        gateway_post("embed", {}, _make_config(gateway_url="https://x.dev/"))
        url = mock_httpx.post.call_args.args[0]
        assert url == "https://x.dev/v1/embed"

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_passes_body_as_json_kwarg(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp

        body = {"model": "llama3", "prompt": "hello"}
        gateway_post("synthesize", body, _make_config())
        assert mock_httpx.post.call_args.kwargs["json"] is body

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_custom_timeout(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp

        gateway_post("embed", {}, _make_config(), timeout=60)
        assert mock_httpx.post.call_args.kwargs["timeout"] == 60

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_http_401_returns_none(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        )
        mock_httpx.post.return_value = mock_resp

        assert gateway_post("embed", {}, _make_config()) is None

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_http_500_returns_none(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "500", request=MagicMock(), response=MagicMock(status_code=500)
        )
        mock_httpx.post.return_value = mock_resp

        assert gateway_post("synthesize", {}, _make_config()) is None

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_connection_timeout_returns_none(self, mock_httpx):
        mock_httpx.post.side_effect = httpx.TimeoutException("timed out")
        assert gateway_post("embed", {}, _make_config()) is None

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_connection_refused_returns_none(self, mock_httpx):
        mock_httpx.post.side_effect = httpx.ConnectError("refused")
        assert gateway_post("embed", {}, _make_config()) is None

    @patch("coppermind_cmo.gateway_http.logger")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_failure_logs_warning_with_endpoint(self, mock_httpx, mock_logger):
        mock_httpx.post.side_effect = httpx.ConnectError("refused")
        gateway_post("classify", {}, _make_config())
        mock_logger.warn.assert_called_once()
        assert "classify" in mock_logger.warn.call_args.args[0]

    @patch("coppermind_cmo.gateway_http.logger")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_success_does_not_log(self, mock_httpx, mock_logger):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp

        gateway_post("embed", {}, _make_config())
        mock_logger.warn.assert_not_called()


class TestGatewayGet:
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_success_returns_response_object(self, mock_httpx):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_httpx.get.return_value = mock_resp

        result = gateway_get("health", _make_config())
        assert result is mock_resp

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_url_strips_trailing_slash(self, mock_httpx):
        mock_httpx.get.return_value = MagicMock()
        gateway_get("health", _make_config(gateway_url="https://x.dev/"))
        url = mock_httpx.get.call_args.args[0]
        assert url == "https://x.dev/v1/health"

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_default_timeout_is_five(self, mock_httpx):
        mock_httpx.get.return_value = MagicMock()
        gateway_get("health", _make_config())
        assert mock_httpx.get.call_args.kwargs["timeout"] == 5

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_custom_timeout(self, mock_httpx):
        mock_httpx.get.return_value = MagicMock()
        gateway_get("health", _make_config(), timeout=15)
        assert mock_httpx.get.call_args.kwargs["timeout"] == 15

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_connection_error_returns_none(self, mock_httpx):
        mock_httpx.get.side_effect = httpx.ConnectError("refused")
        assert gateway_get("health", _make_config()) is None

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_does_not_call_raise_for_status(self, mock_httpx):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 503
        mock_httpx.get.return_value = mock_resp

        result = gateway_get("health", _make_config())
        assert result is mock_resp
        mock_resp.raise_for_status.assert_not_called()


class TestShouldRetry:
    def test_connect_error_is_retryable(self):
        assert _should_retry(httpx.ConnectError("refused")) is True

    def test_timeout_is_retryable(self):
        assert _should_retry(httpx.TimeoutException("timed out")) is True

    def test_remote_protocol_error_is_retryable(self):
        assert _should_retry(httpx.RemoteProtocolError("protocol error")) is True

    def test_builtin_connection_error_is_retryable(self):
        assert _should_retry(ConnectionError("refused")) is True

    def test_builtin_timeout_is_retryable(self):
        assert _should_retry(TimeoutError("timed out")) is True

    def test_503_is_retryable(self):
        exc = httpx.HTTPStatusError(
            "503", request=MagicMock(), response=MagicMock(status_code=503)
        )
        assert _should_retry(exc) is True

    def test_429_is_retryable(self):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(), response=MagicMock(status_code=429)
        )
        assert _should_retry(exc) is True

    def test_401_is_not_retryable(self):
        exc = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        )
        assert _should_retry(exc) is False

    def test_403_is_not_retryable(self):
        exc = httpx.HTTPStatusError(
            "403", request=MagicMock(), response=MagicMock(status_code=403)
        )
        assert _should_retry(exc) is False

    def test_400_is_not_retryable(self):
        exc = httpx.HTTPStatusError(
            "400", request=MagicMock(), response=MagicMock(status_code=400)
        )
        assert _should_retry(exc) is False

    def test_404_is_not_retryable(self):
        exc = httpx.HTTPStatusError(
            "404", request=MagicMock(), response=MagicMock(status_code=404)
        )
        assert _should_retry(exc) is False

    def test_unknown_error_is_not_retryable(self):
        assert _should_retry(RuntimeError("oops")) is False


class TestGetRetryDelay:
    def test_exponential_backoff(self):
        exc = httpx.ConnectError("fail")
        assert _get_retry_delay(0, exc) == 1.0
        assert _get_retry_delay(1, exc) == 2.0
        assert _get_retry_delay(2, exc) == 4.0

    def test_respects_retry_after_header(self):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(),
            response=MagicMock(status_code=429, headers={"Retry-After": "10"}),
        )
        # max(base_delay=1.0, Retry-After=10) = 10
        assert _get_retry_delay(0, exc) == 10.0

    def test_retry_after_uses_max_with_backoff(self):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(),
            response=MagicMock(status_code=429, headers={"Retry-After": "1"}),
        )
        # attempt=2: base_delay=4.0, max(4.0, 1.0) = 4.0
        assert _get_retry_delay(2, exc) == 4.0

    def test_invalid_retry_after_uses_backoff(self):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(),
            response=MagicMock(status_code=429, headers={"Retry-After": "invalid"}),
        )
        assert _get_retry_delay(0, exc) == 1.0


class TestGatewayPostRetry:
    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_retries_on_connect_error_then_succeeds(self, mock_httpx, mock_sleep):
        mock_success_resp = MagicMock()
        mock_success_resp.raise_for_status = MagicMock()
        mock_success_resp.json.return_value = {"ok": True}

        mock_httpx.post.side_effect = [
            httpx.ConnectError("refused"),
            mock_success_resp,
        ]

        result = gateway_post("embed", {}, _make_config())
        assert result == {"ok": True}
        assert mock_httpx.post.call_count == 2
        mock_sleep.assert_called_once()

    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_retries_on_503_then_succeeds(self, mock_httpx, mock_sleep):
        mock_fail_resp = MagicMock()
        mock_fail_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "503", request=MagicMock(), response=MagicMock(status_code=503)
        )
        mock_success_resp = MagicMock()
        mock_success_resp.raise_for_status = MagicMock()
        mock_success_resp.json.return_value = {"ok": True}

        mock_httpx.post.side_effect = [mock_fail_resp, mock_success_resp]

        result = gateway_post("embed", {}, _make_config())
        assert result == {"ok": True}
        assert mock_httpx.post.call_count == 2

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_does_not_retry_on_401(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        )
        mock_httpx.post.return_value = mock_resp

        result = gateway_post("embed", {}, _make_config())
        assert result is None
        assert mock_httpx.post.call_count == 1  # no retry

    @patch("coppermind_cmo.gateway_http.httpx")
    def test_does_not_retry_on_400(self, mock_httpx):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "400", request=MagicMock(), response=MagicMock(status_code=400)
        )
        mock_httpx.post.return_value = mock_resp

        result = gateway_post("embed", {}, _make_config())
        assert result is None
        assert mock_httpx.post.call_count == 1

    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_returns_none_after_all_retries_exhausted(self, mock_httpx, mock_sleep):
        mock_httpx.post.side_effect = httpx.ConnectError("refused")

        result = gateway_post("embed", {}, _make_config())
        assert result is None
        assert mock_httpx.post.call_count == 3  # 3 attempts

    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_retries_on_timeout_exception(self, mock_httpx, mock_sleep):
        mock_success_resp = MagicMock()
        mock_success_resp.raise_for_status = MagicMock()
        mock_success_resp.json.return_value = {"ok": True}

        mock_httpx.post.side_effect = [
            httpx.TimeoutException("timed out"),
            mock_success_resp,
        ]

        result = gateway_post("embed", {}, _make_config())
        assert result == {"ok": True}


class TestGatewayGetRetry:
    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_retries_on_connect_error_then_succeeds(self, mock_httpx, mock_sleep):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200

        mock_httpx.get.side_effect = [
            httpx.ConnectError("refused"),
            mock_resp,
        ]

        result = gateway_get("health", _make_config())
        assert result is mock_resp
        assert mock_httpx.get.call_count == 2

    @patch("coppermind_cmo.gateway_http.time.sleep")
    @patch("coppermind_cmo.gateway_http.httpx")
    def test_returns_none_after_all_retries_exhausted(self, mock_httpx, mock_sleep):
        mock_httpx.get.side_effect = httpx.ConnectError("refused")

        result = gateway_get("health", _make_config())
        assert result is None
        assert mock_httpx.get.call_count == 3
