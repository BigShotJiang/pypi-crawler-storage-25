"""Tests for the MemoryStore repository class."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.memory_store import MemoryStore


def _make_store():
    """Create a MemoryStore with mocked db and config."""
    db = MagicMock()
    config = MagicMock()
    config.embedding_dims = 384
    return MemoryStore(db, config), db, config


# -----------------------------------------------------------------------
# Memory operations
# -----------------------------------------------------------------------

class TestStore:
    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_store_returns_dict(self, _priv):
        store, db, _ = _make_store()
        db.execute_returning.return_value = ("new-uuid-1",)
        result = store.store(
            mind_id="mind-1",
            content="We decided to pause ads",
            memory_type="decision",
            summary="Pausing ads",
        )
        assert isinstance(result, dict)
        assert result["id"] == "new-uuid-1"
        assert result["mind_id"] == "mind-1"
        assert result["content"] == "We decided to pause ads"
        assert result["memory_type"] == "decision"
        db.execute_returning.assert_called_once()

    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_store_with_embedding(self, _priv):
        store, db, _ = _make_store()
        db.execute_returning.return_value = ("emb-uuid",)
        result = store.store(
            mind_id="mind-1",
            content="Content with embedding",
            memory_type="fact",
            embedding=[0.1, 0.2, 0.3],
        )
        assert result is not None
        assert result["id"] == "emb-uuid"
        # Verify execute_returning was called and the SQL includes vector cast
        call_args = db.execute_returning.call_args
        assert "::vector" in call_args[0][0]

    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_store_returns_none_on_failure(self, _priv):
        store, db, _ = _make_store()
        db.execute_returning.return_value = None
        result = store.store(mind_id="mind-1", content="text", memory_type="fact")
        assert result is None


class TestSearch:
    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_search_returns_list(self, _priv):
        store, db, _ = _make_store()
        ts = datetime(2026, 1, 15, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("id-1", "content one", "summary one", "decision", 0.9, 0.85, ["tag1"], "manual", ts),
        ]
        results = store.search(mind_id="mind-1", query_embedding=[0.1, 0.2])
        assert isinstance(results, list)
        assert len(results) == 1
        assert results[0]["memory_id"] == "id-1"
        assert results[0]["similarity"] == 0.85
        assert results[0]["created_at"] == ts.isoformat()
        db.fetch_all.assert_called_once()

    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_keyword_search_returns_list(self, _priv):
        store, db, _ = _make_store()
        ts = datetime(2026, 2, 10, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("id-2", "keyword content", "keyword summary", "fact", 0.8, ["t"], "manual", ts),
        ]
        results = store.keyword_search(mind_id="mind-1", query="keyword")
        assert isinstance(results, list)
        assert len(results) == 1
        assert results[0]["memory_id"] == "id-2"
        assert results[0]["similarity"] == 0.0  # keyword search has no similarity
        db.fetch_all.assert_called_once()

    @patch("coppermind_cmo.memory_store._has_is_private", return_value=False)
    def test_keyword_search_empty_query(self, _priv):
        store, db, _ = _make_store()
        results = store.keyword_search(mind_id="mind-1", query="   ")
        assert results == []
        db.fetch_all.assert_not_called()


class TestHide:
    def test_hide_returns_true(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = ("id-1",)
        result = store.hide(mind_id="mind-1", memory_id="id-1")
        assert result is True
        db.execute.assert_called_once()

    def test_hide_returns_false_no_match(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = None
        result = store.hide(mind_id="mind-1", memory_id="no-such-id")
        assert result is False
        db.execute.assert_not_called()


class TestGetById:
    def test_get_by_id_returns_dict(self):
        store, db, _ = _make_store()
        ts = datetime(2026, 3, 1, tzinfo=timezone.utc)
        db.fetch_one.return_value = (
            "id-1", "content", "summary", "fact", 0.95, ["tag"], "manual", ts, True,
        )
        result = store.get_by_id(mind_id="mind-1", memory_id="id-1")
        assert isinstance(result, dict)
        assert result["memory_id"] == "id-1"
        assert result["content"] == "content"
        assert result["is_current"] is True

    def test_get_by_id_wrong_mind_returns_none(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = None
        result = store.get_by_id(mind_id="wrong-mind", memory_id="id-1")
        assert result is None


# -----------------------------------------------------------------------
# Mind operations
# -----------------------------------------------------------------------

class TestGetMind:
    @patch("coppermind_cmo.memory_store._has_is_internal", return_value=True)
    def test_get_mind_returns_dict(self, _int):
        store, db, _ = _make_store()
        # No customer_id check path
        db.fetch_one.return_value = (
            "mind-1", "Acme Corp", "acme-corp", None, False,
            '{"weekly": "Monday"}', '{"size": "50"}', "/path", "cust-1",
        )
        result = store.get_mind(mind_id="mind-1")
        assert isinstance(result, dict)
        assert result["id"] == "mind-1"
        assert result["name"] == "Acme Corp"
        assert result["slug"] == "acme-corp"

    @patch("coppermind_cmo.memory_store._has_is_internal", return_value=True)
    def test_get_mind_access_denied(self, _int):
        store, db, _ = _make_store()
        # Both access checks return None
        db.fetch_one.return_value = None
        result = store.get_mind(mind_id="mind-1", customer_id="wrong-cust")
        assert result is None


class TestCreateMind:
    @patch("coppermind_cmo.memory_store._has_is_internal", return_value=True)
    def test_create_mind_returns_dict(self, _int):
        store, db, _ = _make_store()
        db.execute_returning.return_value = ("new-mind-id", "New Client", "new-client")
        result = store.create_mind(
            name="New Client", slug="new-client", customer_id="cust-1",
        )
        assert isinstance(result, dict)
        assert result["id"] == "new-mind-id"
        assert result["name"] == "New Client"
        assert result["slug"] == "new-client"
        # Verify both INSERT (mind) and INSERT (access mapping) were called
        db.execute_returning.assert_called_once()
        db.execute.assert_called_once()


class TestListMinds:
    @patch("coppermind_cmo.memory_store._has_is_internal", return_value=True)
    def test_list_minds_returns_list(self, _int):
        store, db, _ = _make_store()
        ts = datetime(2026, 1, 1, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("mind-1", "Acme", "acme", None, 5, ts, ts),
            ("mind-2", "Beta", "beta", None, 3, ts, ts),
        ]
        results = store.list_minds(customer_id="cust-1")
        assert isinstance(results, list)
        assert len(results) == 2
        assert results[0]["mind_id"] == "mind-1"
        assert results[0]["memory_count"] == 5

    @patch("coppermind_cmo.memory_store._has_is_internal", return_value=True)
    def test_list_minds_excludes_internal_by_default(self, _int):
        store, db, _ = _make_store()
        db.fetch_all.return_value = []
        store.list_minds(customer_id="cust-1", include_internal=False)
        call_args = db.fetch_all.call_args
        assert "is_internal" in call_args[0][0]

    def test_list_minds_empty_customer_id(self):
        store, db, _ = _make_store()
        results = store.list_minds(customer_id="")
        assert results == []
        db.fetch_all.assert_not_called()


class TestSlugExists:
    def test_slug_exists_true(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = (1,)
        assert store.slug_exists("acme-corp") is True

    def test_slug_exists_false(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = None
        assert store.slug_exists("no-such-slug") is False


# -----------------------------------------------------------------------
# Ingest operations
# -----------------------------------------------------------------------

class TestCheckContentHash:
    def test_check_content_hash_true(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = ("log-id",)
        assert store.check_content_hash("mind-1", "abc123") is True

    def test_check_content_hash_false(self):
        store, db, _ = _make_store()
        db.fetch_one.return_value = None
        assert store.check_content_hash("mind-1", "xyz789") is False


class TestLogIngest:
    def test_log_ingest(self):
        store, db, _ = _make_store()
        store.log_ingest(
            mind_id="mind-1",
            source_id="src-1",
            content_hash="hash123",
            raw_content="raw text",
            memories_extracted=3,
        )
        db.execute.assert_called_once()
        call_args = db.execute.call_args
        assert "ingest_log" in call_args[0][0]
