"""Tests for session watcher — JSONL parsing, segmentation, file watching."""

import json
import os
import tempfile
import pytest
from unittest.mock import patch, MagicMock


def _make_jsonl_line(msg_type, content=None, tool_name=None, tool_input=None):
    """Helper to create a JSONL line matching Claude Code format."""
    obj = {"type": msg_type}
    if msg_type == "user":
        obj["message"] = {"role": "user", "content": [{"type": "text", "text": content}]}
    elif msg_type == "assistant":
        blocks = []
        if content:
            blocks.append({"type": "text", "text": content})
        if tool_name:
            blocks.append({"type": "tool_use", "name": tool_name, "input": tool_input or {}})
        obj["message"] = {"role": "assistant", "content": blocks}
    return json.dumps(obj)


class TestParseSessionSegments:
    def test_single_client_segment(self):
        from coppermind_cmo.watch import parse_session_segments
        lines = [
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme Corp"}),
            _make_jsonl_line("user", content="What's our ad strategy?"),
            _make_jsonl_line("assistant", content="Based on what I know, Acme paused LinkedIn ads."),
        ]
        segments = parse_session_segments(lines)
        assert len(segments) == 1
        assert segments[0]["client_name"] == "Acme Corp"
        assert len(segments[0]["messages"]) == 2  # user + assistant after switch

    def test_multiple_client_segments(self):
        from coppermind_cmo.watch import parse_session_segments
        lines = [
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme Corp"}),
            _make_jsonl_line("user", content="Acme discussion"),
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Bluebell"}),
            _make_jsonl_line("user", content="Bluebell discussion"),
        ]
        segments = parse_session_segments(lines)
        assert len(segments) == 2
        assert segments[0]["client_name"] == "Acme Corp"
        assert segments[1]["client_name"] == "Bluebell"

    def test_skips_messages_before_switch(self):
        from coppermind_cmo.watch import parse_session_segments
        lines = [
            _make_jsonl_line("user", content="Hello, general chat"),
            _make_jsonl_line("assistant", content="Hi there"),
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme Corp"}),
            _make_jsonl_line("user", content="Acme stuff"),
        ]
        segments = parse_session_segments(lines)
        assert len(segments) == 1
        assert segments[0]["client_name"] == "Acme Corp"

    def test_empty_lines_returns_empty(self):
        from coppermind_cmo.watch import parse_session_segments
        segments = parse_session_segments([])
        assert segments == []

    def test_no_switch_client_returns_empty(self):
        from coppermind_cmo.watch import parse_session_segments
        lines = [
            _make_jsonl_line("user", content="Just chatting"),
            _make_jsonl_line("assistant", content="Sure thing"),
        ]
        segments = parse_session_segments(lines)
        assert segments == []


class TestSessionWatcher:
    @patch("coppermind_cmo.watch.IngestEngine")
    def test_processes_new_jsonl_file(self, mock_engine_cls, mock_db, mock_config, tmp_path):
        from coppermind_cmo.watch import SessionWatcher

        # Create a fake JSONL file
        session_file = tmp_path / "test-session.jsonl"
        lines = [
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme Corp"}),
            _make_jsonl_line("user", content="Acme decided to pause LinkedIn ads"),
            _make_jsonl_line("assistant", content="I'll remember that."),
        ]
        session_file.write_text("\n".join(lines))

        mock_engine = MagicMock()
        mock_engine.process_source.return_value = {"new": 1, "updated": 0, "skipped": 0}
        mock_engine_cls.return_value = mock_engine

        # Mock _resolve_mind to return a mind tuple
        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        with patch.object(watcher, "_resolve_mind", return_value=("mind-uuid", "Acme Corp")):
            watcher.process_file(str(session_file))

        mock_engine.process_source.assert_called_once()

    def test_tracks_file_offset(self, mock_db, mock_config, tmp_path):
        from coppermind_cmo.watch import SessionWatcher

        session_file = tmp_path / "test-session.jsonl"
        session_file.write_text("")

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        assert watcher._get_offset(str(session_file)) == 0

        watcher._set_offset(str(session_file), 500)
        assert watcher._get_offset(str(session_file)) == 500

    @patch("coppermind_cmo.watch.IngestEngine")
    def test_skips_file_with_no_switch_client(self, mock_engine_cls, mock_db, mock_config, tmp_path):
        from coppermind_cmo.watch import SessionWatcher

        session_file = tmp_path / "test-session.jsonl"
        lines = [
            _make_jsonl_line("user", content="General chat"),
            _make_jsonl_line("assistant", content="Sure thing"),
        ]
        session_file.write_text("\n".join(lines))

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        watcher.process_file(str(session_file))

        mock_engine_cls.assert_not_called()

    @patch("coppermind_cmo.watch.IngestEngine")
    def test_process_file_with_empty_content(self, mock_engine_cls, mock_db, mock_config, tmp_path):
        """File exists but is empty/whitespace. Should return without calling IngestEngine."""
        from coppermind_cmo.watch import SessionWatcher

        session_file = tmp_path / "empty.jsonl"
        session_file.write_text("   \n\n  ")

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        watcher.process_file(str(session_file))

        mock_engine_cls.assert_not_called()

    @patch("coppermind_cmo.watch.IngestEngine")
    def test_process_file_unreadable(self, mock_engine_cls, mock_db, mock_config, tmp_path):
        """File doesn't exist. Should log warning, not crash."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        # Should not raise
        watcher.process_file(str(tmp_path / "nonexistent.jsonl"))

        mock_engine_cls.assert_not_called()

    @patch("coppermind_cmo.watch.IngestEngine")
    def test_process_file_unknown_client(self, mock_engine_cls, mock_db, mock_config, tmp_path):
        """Segments parsed but _resolve_mind returns None. IngestEngine should not be called."""
        from coppermind_cmo.watch import SessionWatcher

        session_file = tmp_path / "unknown-client.jsonl"
        lines = [
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "NoSuchClient"}),
            _make_jsonl_line("user", content="Some discussion"),
        ]
        session_file.write_text("\n".join(lines))

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        with patch.object(watcher, "_resolve_mind", return_value=None):
            watcher.process_file(str(session_file))

        mock_engine_cls.assert_not_called()

    def test_scan_once_finds_files(self, mock_db, mock_config, tmp_path):
        """Create a .jsonl file in an allowed project dir, verify process_file is called."""
        from coppermind_cmo.watch import SessionWatcher

        project_dir = tmp_path / "-test-project"
        project_dir.mkdir()
        session_file = project_dir / "session.jsonl"
        session_file.write_text('{"some": "data"}\n')

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/test/project"])
        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        mock_pf.assert_called_once_with(str(session_file))

    def test_scan_once_skips_unchanged_files(self, mock_db, mock_config, tmp_path):
        """Set offset to file size, verify process_file is NOT called."""
        from coppermind_cmo.watch import SessionWatcher

        project_dir = tmp_path / "-test-project"
        project_dir.mkdir()
        session_file = project_dir / "session.jsonl"
        session_file.write_text('{"some": "data"}\n')
        file_size = session_file.stat().st_size

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/test/project"])
        watcher._offsets[str(session_file)] = file_size

        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        mock_pf.assert_not_called()

    def test_load_offsets_from_db(self, mock_db, mock_config, tmp_path):
        """Mock db.fetch_all to return rows, verify offsets are loaded."""
        from coppermind_cmo.watch import SessionWatcher

        mock_db.fetch_all.return_value = [
            ("/path/to/a.jsonl", 100),
            ("/path/to/b.jsonl", 200),
        ]

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))

        assert watcher._offsets["/path/to/a.jsonl"] == 100
        assert watcher._offsets["/path/to/b.jsonl"] == 200

    def test_load_offsets_db_error(self, mock_db, mock_config, tmp_path):
        """Mock db.fetch_all to raise, verify no crash."""
        from coppermind_cmo.watch import SessionWatcher

        mock_db.fetch_all.side_effect = RuntimeError("DB down")

        # Should not raise
        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        assert watcher._offsets == {}

    def test_set_offset_db_error(self, mock_db, mock_config, tmp_path):
        """Mock db.execute to raise, verify in-memory offset still set."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        mock_db.execute.side_effect = RuntimeError("DB write failed")

        watcher._set_offset("/some/file.jsonl", 999)

        # In-memory offset should still be updated
        assert watcher._offsets["/some/file.jsonl"] == 999

    def test_resolve_mind_found(self, mock_db, mock_config, tmp_path):
        """Mock db.fetch_one returns row, returns tuple."""
        from coppermind_cmo.watch import SessionWatcher

        mock_db.fetch_one.return_value = ("uuid-123", "Acme Corp")

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        result = watcher._resolve_mind("Acme Corp")

        assert result == ("uuid-123", "Acme Corp")

    def test_resolve_mind_not_found(self, mock_db, mock_config, tmp_path):
        """Mock db.fetch_one returns None, returns None."""
        from coppermind_cmo.watch import SessionWatcher

        # fetch_all for __init__ load offsets, then fetch_one for _resolve_mind
        mock_db.fetch_one.return_value = None

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))
        result = watcher._resolve_mind("NoSuchClient")

        assert result is None


class TestParseSessionSegmentsEdgeCases:
    def test_content_as_string(self):
        """parse_session_segments with content as string (not list), should handle gracefully."""
        from coppermind_cmo.watch import parse_session_segments

        # Manually construct a line where content is a string, not a list
        obj = {
            "message": {
                "role": "assistant",
                "content": "This is a plain string content",
            }
        }
        lines_before_switch = [json.dumps(obj)]

        # First we need a switch_client to start a segment
        switch_line = _make_jsonl_line(
            "assistant", tool_name="switch_client", tool_input={"client_name": "Acme"}
        )
        # Then a line with string content (not list)
        string_content_obj = {
            "message": {
                "role": "assistant",
                "content": "Plain string message after switch",
            }
        }
        lines = [switch_line, json.dumps(string_content_obj)]

        segments = parse_session_segments(lines)
        assert len(segments) == 1
        assert segments[0]["client_name"] == "Acme"
        assert "Plain string message after switch" in segments[0]["messages"]

    def test_invalid_json_lines_skipped(self):
        """parse_session_segments with malformed JSON lines, should skip them."""
        from coppermind_cmo.watch import parse_session_segments

        lines = [
            "this is not valid json",
            "{broken json",
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme"}),
            "another bad line",
            _make_jsonl_line("user", content="Valid message"),
        ]
        segments = parse_session_segments(lines)
        assert len(segments) == 1
        assert segments[0]["client_name"] == "Acme"
        assert len(segments[0]["messages"]) == 1


    def test_default_watch_dir_unix(self, mock_db, mock_config):
        """No watch_dir passed on non-win32, uses ~/.claude/projects."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config)
        expected = os.path.expanduser("~/.claude/projects")
        assert watcher.watch_dir == expected

    def test_scan_once_oserror_getsize(self, mock_db, mock_config, tmp_path):
        """os.path.getsize raises OSError, scan_once skips file without crashing."""
        from coppermind_cmo.watch import SessionWatcher

        project_dir = tmp_path / "-test-project"
        project_dir.mkdir()
        session_file = project_dir / "session.jsonl"
        session_file.write_text('{"data": true}\n')

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/test/project"])

        with patch("os.path.getsize", side_effect=OSError("permission denied")):
            with patch.object(watcher, "process_file") as mock_pf:
                watcher.scan_once()

        mock_pf.assert_not_called()

    def test_run_calls_scan_once(self, mock_db, mock_config, tmp_path):
        """run() calls scan_once in a loop. Break after first iteration via side_effect."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))

        call_count = 0

        def scan_and_break():
            nonlocal call_count
            call_count += 1
            if call_count >= 1:
                raise KeyboardInterrupt("stop the loop")

        with patch.object(watcher, "scan_once", side_effect=scan_and_break):
            with patch("coppermind_cmo.watch.time.sleep", side_effect=KeyboardInterrupt):
                with pytest.raises(KeyboardInterrupt):
                    watcher.run(poll_interval=1)

        assert call_count >= 1

    def test_run_handles_scan_error(self, mock_db, mock_config, tmp_path):
        """run() catches exceptions from scan_once without crashing."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path))

        with patch.object(watcher, "scan_once", side_effect=RuntimeError("boom")):
            with patch("coppermind_cmo.watch.time.sleep", side_effect=KeyboardInterrupt):
                with pytest.raises(KeyboardInterrupt):
                    watcher.run(poll_interval=1)


class TestParseSessionSegmentsBlankLines:
    def test_blank_lines_between_valid_lines(self):
        """Blank lines in the input are skipped (line 33 coverage)."""
        from coppermind_cmo.watch import parse_session_segments

        lines = [
            _make_jsonl_line("assistant", tool_name="switch_client", tool_input={"client_name": "Acme"}),
            "",
            "   ",
            _make_jsonl_line("user", content="Hello"),
            "",
        ]
        segments = parse_session_segments(lines)
        assert len(segments) == 1
        assert segments[0]["client_name"] == "Acme"
        assert len(segments[0]["messages"]) == 1


class TestProjectScoping:
    """Tests for directory-level session watcher scoping (Issue 4)."""

    def test_encode_project_path_unix(self):
        from coppermind_cmo.watch import _encode_project_path
        with patch("os.path.realpath", side_effect=lambda p: p):
            assert _encode_project_path("/Volumes/Dev/coppermind-cmo") == "-Volumes-Dev-coppermind-cmo"

    def test_encode_project_path_strips_trailing_slash(self):
        from coppermind_cmo.watch import _encode_project_path
        with patch("os.path.realpath", side_effect=lambda p: p):
            assert _encode_project_path("/Volumes/Dev/coppermind-cmo/") == "-Volumes-Dev-coppermind-cmo"

    def test_build_allowed_prefixes_explicit(self):
        from coppermind_cmo.watch import _build_allowed_prefixes
        with patch("os.path.realpath", side_effect=lambda p: p):
            prefixes = _build_allowed_prefixes(["/Volumes/Dev/coppermind-cmo"])
        assert "-Volumes-Dev-coppermind-cmo" in prefixes

    def test_build_allowed_prefixes_from_env(self, monkeypatch):
        from coppermind_cmo.watch import _build_allowed_prefixes
        monkeypatch.setenv("COPPERMIND_WATCH_PATHS", "/a/b:/c/d")
        with patch("os.path.realpath", side_effect=lambda p: p):
            prefixes = _build_allowed_prefixes()
        assert "-a-b" in prefixes
        assert "-c-d" in prefixes

    def test_build_allowed_prefixes_from_project_root(self, monkeypatch):
        from coppermind_cmo.watch import _build_allowed_prefixes
        monkeypatch.setenv("COPPERMIND_PROJECT_ROOT", "/my/project")
        with patch("os.path.realpath", side_effect=lambda p: p):
            prefixes = _build_allowed_prefixes()
        assert "-my-project" in prefixes

    def test_build_allowed_prefixes_falls_back_to_cwd(self, monkeypatch):
        from coppermind_cmo.watch import _build_allowed_prefixes
        with patch("os.getcwd", return_value="/fallback/dir"):
            with patch("os.path.realpath", side_effect=lambda p: p):
                prefixes = _build_allowed_prefixes()
        assert "-fallback-dir" in prefixes

    def test_scan_once_skips_unrelated_project_dirs(self, mock_db, mock_config, tmp_path):
        """Files in unrelated project directories are never processed."""
        from coppermind_cmo.watch import SessionWatcher

        # Create two project dirs: one allowed, one not
        allowed_dir = tmp_path / "-my-project"
        allowed_dir.mkdir()
        (allowed_dir / "session.jsonl").write_text('{"data": true}\n')

        unrelated_dir = tmp_path / "-other-personal-project"
        unrelated_dir.mkdir()
        (unrelated_dir / "private.jsonl").write_text('{"private": "data"}\n')

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/my/project"])
        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        # Only the allowed file should be processed
        mock_pf.assert_called_once_with(str(allowed_dir / "session.jsonl"))

    def test_scan_once_allows_worktree_dirs(self, mock_db, mock_config, tmp_path):
        """Worktree directories (same prefix + suffix) are allowed."""
        from coppermind_cmo.watch import SessionWatcher

        # Main project dir
        main_dir = tmp_path / "-Volumes-Dev-coppermind-cmo"
        main_dir.mkdir()
        (main_dir / "main.jsonl").write_text('{"data": true}\n')

        # Worktree dir (same prefix, dash-separated suffix)
        wt_dir = tmp_path / "-Volumes-Dev-coppermind-cmo-worktrees-fix-something"
        wt_dir.mkdir()
        (wt_dir / "worktree.jsonl").write_text('{"data": true}\n')

        watcher = SessionWatcher(
            mock_db, mock_config,
            watch_dir=str(tmp_path),
            project_paths=["/Volumes/Dev/coppermind-cmo"],
        )
        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        processed_files = {call.args[0] for call in mock_pf.call_args_list}
        assert str(main_dir / "main.jsonl") in processed_files
        assert str(wt_dir / "worktree.jsonl") in processed_files

    def test_scan_once_blocks_all_when_no_prefixes(self, mock_db, mock_config, tmp_path):
        """Empty allowed prefixes means nothing is scanned (fail closed)."""
        from coppermind_cmo.watch import SessionWatcher

        project_dir = tmp_path / "-some-project"
        project_dir.mkdir()
        (project_dir / "session.jsonl").write_text('{"data": true}\n')

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=[])
        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        mock_pf.assert_not_called()

    def test_is_allowed_path_exact_match(self, mock_db, mock_config, tmp_path):
        """Exact encoded project path matches."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/test/project"])
        file_path = os.path.join(str(tmp_path), "-test-project", "session.jsonl")
        assert watcher._is_allowed_path(file_path) is True

    def test_is_allowed_path_rejects_partial_name_overlap(self, mock_db, mock_config, tmp_path):
        """A project whose encoded name is a strict substring (not dash-delimited) is rejected."""
        from coppermind_cmo.watch import SessionWatcher

        # Allowed: /test/project -> -test-project
        # Candidate: -test-projectx (no dash before 'x')
        watcher = SessionWatcher(mock_db, mock_config, watch_dir=str(tmp_path), project_paths=["/test/project"])
        file_path = os.path.join(str(tmp_path), "-test-projectx", "session.jsonl")
        assert watcher._is_allowed_path(file_path) is False

    def test_multiple_project_paths(self, mock_db, mock_config, tmp_path):
        """Multiple allowed project paths all pass filtering."""
        from coppermind_cmo.watch import SessionWatcher

        dir_a = tmp_path / "-project-a"
        dir_a.mkdir()
        (dir_a / "a.jsonl").write_text('{"data": true}\n')

        dir_b = tmp_path / "-project-b"
        dir_b.mkdir()
        (dir_b / "b.jsonl").write_text('{"data": true}\n')

        watcher = SessionWatcher(
            mock_db, mock_config,
            watch_dir=str(tmp_path),
            project_paths=["/project/a", "/project/b"],
        )
        with patch.object(watcher, "process_file") as mock_pf:
            watcher.scan_once()

        assert mock_pf.call_count == 2

    def test_server_passes_project_root_env(self):
        """_start_watcher sets COPPERMIND_PROJECT_ROOT in subprocess environment."""
        import coppermind_cmo.server as server_mod
        from unittest.mock import call

        mock_popen = MagicMock()
        mock_popen.pid = 12345

        with patch("subprocess.Popen", return_value=mock_popen) as popen_mock:
            with patch("builtins.open", MagicMock()):
                with patch("os.chmod"):
                    with patch.object(server_mod, "secure_mkdir"):
                        with patch.object(server_mod, "secure_write"):
                            # Re-enable _start_watcher for this test
                            server_mod._server.watcher_process = None
                            orig = server_mod._start_watcher.__wrapped__ if hasattr(server_mod._start_watcher, '__wrapped__') else None

                            # Directly call the real function
                            from coppermind_cmo.server import _start_watcher as real_start_watcher
                            with patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"}):
                                real_start_watcher()

        if popen_mock.called:
            env = popen_mock.call_args.kwargs.get("env", {})
            assert "COPPERMIND_PROJECT_ROOT" in env


class TestWindowsWatchDir:
    @patch("sys.platform", "win32")
    @patch.dict(os.environ, {"APPDATA": "C:\\Users\\TestUser\\AppData\\Roaming"})
    def test_windows_watch_dir(self, mock_db, mock_config):
        """Mock sys.platform as win32, verify APPDATA-based path."""
        from coppermind_cmo.watch import SessionWatcher

        watcher = SessionWatcher(mock_db, mock_config)
        expected = os.path.join(
            "C:\\Users\\TestUser\\AppData\\Roaming", "Claude", "projects"
        )
        assert watcher.watch_dir == expected
