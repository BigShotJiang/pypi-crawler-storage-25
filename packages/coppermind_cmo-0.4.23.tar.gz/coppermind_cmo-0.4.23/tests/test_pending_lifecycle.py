"""Tests for VA pending memory lifecycle."""
import pytest
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.memories import store_memory_core
import inspect


class TestPendingLifecycleParams:
    def test_store_memory_core_has_access_level_param(self):
        sig = inspect.signature(store_memory_core)
        assert "access_level" in sig.parameters

    def test_store_memory_core_has_caller_id_param(self):
        sig = inspect.signature(store_memory_core)
        assert "caller_id" in sig.parameters

    def test_memory_store_has_status_param(self):
        from coppermind_cmo.memory_store import MemoryStore
        sig = inspect.signature(MemoryStore.store)
        assert "status" in sig.parameters

    def test_memory_store_has_created_by_param(self):
        from coppermind_cmo.memory_store import MemoryStore
        sig = inspect.signature(MemoryStore.store)
        assert "created_by" in sig.parameters


class TestViewerPendingBehavior:
    """Verify that viewer stores create pending memories."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_viewer_store_sets_pending_status(self, mock_embed, mock_db, mock_config, active_mind):
        """When access_level='viewer', MemoryStore.store() should receive status='pending'."""
        mock_db.execute_returning.return_value = ("new-id",)

        with patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={}), \
             patch("coppermind_cmo.server.get_last_tool_call", return_value=None), \
             patch("coppermind_cmo.memory_store._has_is_private", return_value=True), \
             patch("coppermind_cmo.memory_store._has_sensitivity", return_value=True):
            result = store_memory_core(
                content="Test content from VA",
                memory_type="fact",
                tags=[],
                db=mock_db,
                config=mock_config,
                active_mind=active_mind,
                access_level="viewer",
                caller_id="va-user-123",
            )

        assert result["memory_id"] == "new-id"
        # Verify the INSERT was called with status='pending' and created_by
        call_args = mock_db.execute_returning.call_args
        sql = call_args[0][0]
        params = call_args[0][1]
        assert "status" in sql
        assert "created_by" in sql
        assert "pending" in params
        assert "va-user-123" in params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_owner_store_sets_active_status(self, mock_embed, mock_db, mock_config, active_mind):
        """When access_level='owner' (default), status should be 'active'."""
        mock_db.execute_returning.return_value = ("new-id",)

        with patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={}), \
             patch("coppermind_cmo.server.get_last_tool_call", return_value=None), \
             patch("coppermind_cmo.memory_store._has_is_private", return_value=True), \
             patch("coppermind_cmo.memory_store._has_sensitivity", return_value=True):
            result = store_memory_core(
                content="Test content from owner",
                memory_type="fact",
                tags=[],
                db=mock_db,
                config=mock_config,
                active_mind=active_mind,
                access_level="owner",
                caller_id="owner-123",
            )

        assert result["memory_id"] == "new-id"
        call_args = mock_db.execute_returning.call_args
        sql = call_args[0][0]
        params = call_args[0][1]
        assert "status" in sql
        assert "created_by" in sql
        assert "active" in params
        assert "owner-123" in params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1] * 384)
    def test_viewer_store_skips_reconsolidation(self, mock_embed, mock_db, mock_config, active_mind):
        """Viewer stores should never reconsolidate into active memories."""
        mock_db.execute_returning.return_value = ("new-id",)

        with patch("coppermind_cmo.tools.memories._find_similar_memory") as mock_similar, \
             patch("coppermind_cmo.tools.memories.get_mind_cadence", return_value={}), \
             patch("coppermind_cmo.server.get_last_tool_call", return_value=None), \
             patch("coppermind_cmo.memory_store._has_is_private", return_value=True), \
             patch("coppermind_cmo.memory_store._has_sensitivity", return_value=True):
            result = store_memory_core(
                content="Test content from VA",
                memory_type="fact",
                tags=[],
                db=mock_db,
                config=mock_config,
                active_mind=active_mind,
                access_level="viewer",
                caller_id="va-user-123",
            )

        # _find_similar_memory should NOT be called for viewer stores
        mock_similar.assert_not_called()
        assert result.get("reconsolidated") is not True
