"""Tests for hex-to-ANSI color conversion utilities."""

from coppermind_cmo.colors import is_valid_hex_color, hex_to_ansi256, ansi_colored


class TestIsValidHexColor:
    def test_valid_lowercase(self):
        assert is_valid_hex_color("#ff00aa") is True

    def test_valid_uppercase(self):
        assert is_valid_hex_color("#FF00AA") is True

    def test_valid_mixed_case(self):
        assert is_valid_hex_color("#Ff00aA") is True

    def test_black(self):
        assert is_valid_hex_color("#000000") is True

    def test_white(self):
        assert is_valid_hex_color("#ffffff") is True

    def test_missing_hash(self):
        assert is_valid_hex_color("ff00aa") is False

    def test_too_short(self):
        assert is_valid_hex_color("#fff") is False

    def test_too_long(self):
        assert is_valid_hex_color("#ff00aa00") is False

    def test_invalid_chars(self):
        assert is_valid_hex_color("#gggggg") is False

    def test_empty_string(self):
        assert is_valid_hex_color("") is False

    def test_not_a_color(self):
        assert is_valid_hex_color("red") is False


class TestHexToAnsi256:
    def test_black(self):
        # Black: r=0, g=0, b=0 -> cube index 16 + 0 + 0 + 0 = 16
        assert hex_to_ansi256("#000000") == 16

    def test_white(self):
        # White: r=255, g=255, b=255 -> 16 + 36*5 + 6*5 + 5 = 231
        assert hex_to_ansi256("#ffffff") == 231

    def test_pure_red(self):
        # Pure red: r=255, g=0, b=0 -> 16 + 36*5 + 0 + 0 = 196
        assert hex_to_ansi256("#ff0000") == 196

    def test_pure_green(self):
        # Pure green: r=0, g=255, b=0 -> 16 + 0 + 6*5 + 0 = 46
        assert hex_to_ansi256("#00ff00") == 46

    def test_pure_blue(self):
        # Pure blue: r=0, g=0, b=255 -> 16 + 0 + 0 + 5 = 21
        assert hex_to_ansi256("#0000ff") == 21


class TestAnsiColored:
    def test_wraps_text_with_escape_codes(self):
        result = ansi_colored("hello", "#ff0000")
        assert result.startswith("\033[38;5;")
        assert result.endswith("\033[0m")
        assert "hello" in result

    def test_invalid_color_returns_plain_text(self):
        assert ansi_colored("hello", "not-a-color") == "hello"

    def test_empty_color_returns_plain_text(self):
        assert ansi_colored("hello", "") == "hello"

    def test_correct_code_for_red(self):
        result = ansi_colored("[Acme]", "#ff0000")
        assert result == "\033[38;5;196m[Acme]\033[0m"
