"""Tests for the memory_types module — taxonomy, prompts, and backwards compat."""

from coppermind_cmo.memory_types import (
    DEFAULT_MEMORY_TYPES,
    VALID_MEMORY_TYPES,
    CLASSIFY_DESCRIPTIONS,
    CLASSIFY_PROMPT,
    SUMMARIZE_PROMPT,
    get_memory_types,
    get_classify_prompt,
    get_summarize_prompt,
)
from unittest.mock import MagicMock


def test_default_types_has_seven():
    assert len(DEFAULT_MEMORY_TYPES) == 7


def test_valid_types_alias():
    assert VALID_MEMORY_TYPES is DEFAULT_MEMORY_TYPES


def test_get_memory_types_no_config():
    result = get_memory_types(None)
    assert result == DEFAULT_MEMORY_TYPES


def test_get_memory_types_with_config():
    config = MagicMock()
    config.memory_types = ["alpha", "beta"]
    result = get_memory_types(config)
    assert result == {"alpha", "beta"}


def test_get_classify_prompt_contains_all_types():
    prompt = get_classify_prompt()
    for t in DEFAULT_MEMORY_TYPES:
        assert t in prompt, f"Expected type '{t}' in classify prompt"


def test_get_classify_prompt_custom_types():
    config = MagicMock()
    config.memory_types = ["custom_type_a", "custom_type_b"]
    prompt = get_classify_prompt(config)
    assert "custom_type_a" in prompt
    assert "custom_type_b" in prompt
    # Default types should NOT appear (custom set replaces defaults)
    assert "stakeholder" not in prompt


def test_get_summarize_prompt():
    result = get_summarize_prompt()
    assert isinstance(result, str)
    assert len(result) > 0


def test_classify_descriptions_complete():
    for t in DEFAULT_MEMORY_TYPES:
        assert t in CLASSIFY_DESCRIPTIONS, f"Missing description for type '{t}'"
        assert len(CLASSIFY_DESCRIPTIONS[t]) > 0


def test_backwards_compat_imports():
    # CLASSIFY_PROMPT and SUMMARIZE_PROMPT should be importable strings
    assert isinstance(CLASSIFY_PROMPT, str)
    assert len(CLASSIFY_PROMPT) > 0
    assert isinstance(SUMMARIZE_PROMPT, str)
    assert len(SUMMARIZE_PROMPT) > 0
