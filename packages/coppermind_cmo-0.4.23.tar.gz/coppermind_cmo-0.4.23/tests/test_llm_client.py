"""Tests for llm_client.py — gateway-only LLM client."""

from unittest.mock import patch, MagicMock
from coppermind_cmo.llm_client import (
    classify_memory_type, summarize,
    call_llm, call_gateway_llm, SUMMARIZE_PROMPT,
)


class TestSummarizePrompt:
    """SUMMARIZE_PROMPT must instruct the LLM to preserve searchable specifics."""

    def test_prompt_mentions_proper_nouns(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve proper nouns."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "proper noun" in prompt_lower or "names" in prompt_lower or "identifiers" in prompt_lower

    def test_prompt_mentions_dollar_amounts(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve dollar amounts."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "dollar" in prompt_lower or "amount" in prompt_lower or "number" in prompt_lower

    def test_prompt_mentions_dates(self):
        """SUMMARIZE_PROMPT must instruct LLM to preserve dates."""
        prompt_lower = SUMMARIZE_PROMPT.lower()
        assert "date" in prompt_lower

    def test_prompt_max_length_still_specified(self):
        """Summary should still have a max length constraint."""
        assert "100" in SUMMARIZE_PROMPT or "max" in SUMMARIZE_PROMPT.lower()


class TestClassifyMemoryType:
    def _gateway_config(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.dev"
        return config

    def test_gateway_classify_success(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "decision", "classified_by": "llm"}):
            result = classify_memory_type("We decided X", config)
            assert result == ("decision", "llm")

    def test_gateway_classify_failure_returns_fallback(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = classify_memory_type("something", config)
            assert result == ("fact", "fallback")

    def test_valid_type_returned(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "preference"}):
            result = classify_memory_type("They prefer short reports", config)
            assert result == ("preference", "llm")

    def test_strips_whitespace_and_lowercases(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "  Campaign_Outcome  "}):
            result = classify_memory_type("open rate 34%", config)
            assert result == ("campaign_outcome", "llm")

    def test_invalid_type_defaults_to_fact(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "garbage"}):
            result = classify_memory_type("something", config)
            assert result == ("fact", "llm")

    def test_classify_strips_trailing_punctuation(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"memory_type": "decision."}):
            result = classify_memory_type("We decided X", config)
            assert result == ("decision", "llm")


class TestSummarize:
    def _gateway_config(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.dev"
        return config

    def test_gateway_summarize_success(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"summary": "Short gateway summary"}):
            result = summarize("Long content here", config)
            assert result == "Short gateway summary"

    def test_gateway_summarize_failure_truncates(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = summarize("x" * 200, config)
            assert len(result) == 100

    def test_summarize_strips_whitespace(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"summary": "  summary with spaces  "}):
            result = summarize("content", config)
            assert result == "summary with spaces"

    def test_summarize_truncates_long_response(self):
        config = self._gateway_config()
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"summary": "A" * 300}):
            result = summarize("content", config)
            assert len(result) <= 200

    def test_gateway_down_truncates_content(self):
        config = self._gateway_config()
        content = "x" * 200
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = summarize(content, config)
            assert len(result) == 100


class TestCallLlmDispatcher:
    def test_routes_to_gateway(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "key"
        config.gateway_url = "https://api.coppermind.dev"
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"text": "response"}) as mock_gw:
            result = call_llm("prompt", config)
            assert result == "response"
            mock_gw.assert_called_once()

    def test_gateway_failure_returns_none(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "key"
        config.gateway_url = "https://api.coppermind.dev"
        with patch("coppermind_cmo.llm_client.call_gateway_llm", return_value=None):
            result = call_llm("prompt", config)
            assert result is None

    def test_synthesis_model_flag(self):
        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "key"
        config.gateway_url = "https://api.coppermind.dev"
        with patch("coppermind_cmo.llm_client.call_gateway_llm",
                    return_value={"text": "synthesized"}) as mock_gw:
            result = call_llm("prompt", config, use_synthesis_model=True)
            assert result == "synthesized"
            mock_gw.assert_called_once_with("synthesize", {"prompt": "prompt"}, config)


class TestCallGatewayLlm:
    def test_success(self):
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.dev"
        config.api_key = "test-key"
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"text": "result"}
        mock_resp.raise_for_status = MagicMock()
        with patch("coppermind_cmo.gateway_http.httpx") as mock_httpx:
            mock_httpx.post.return_value = mock_resp
            result = call_gateway_llm("synthesize", {"prompt": "test"}, config)
            assert result == {"text": "result"}

    def test_failure_returns_none(self):
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.dev"
        config.api_key = "test-key"
        with patch("coppermind_cmo.gateway_http.httpx") as mock_httpx:
            mock_httpx.post.side_effect = Exception("timeout")
            result = call_gateway_llm("synthesize", {"prompt": "test"}, config)
            assert result is None
