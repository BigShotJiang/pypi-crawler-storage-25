# tests/test_prep_l10.py
"""Tests for the prep_l10 tool."""

import pytest
from unittest.mock import MagicMock, patch
from datetime import date


@pytest.fixture
def mock_db():
    db = MagicMock()
    db.fetch_all = MagicMock(return_value=[])
    db.fetch_one = MagicMock(return_value=None)
    return db


def test_prep_l10_returns_all_sections(mock_db):
    """L10 prep returns all 7 EOS sections."""
    from coppermind_cmo.tools.eos import _prep_l10

    result = _prep_l10(
        db=mock_db,
        active_mind=("mind-1", "Acme Corp"),
        customer_id="cust-1",
    )

    assert "sections" in result
    section_names = [s["name"] for s in result["sections"]]
    assert "segue" in section_names
    assert "scorecard" in section_names
    assert "rock_review" in section_names
    assert "headlines" in section_names
    assert "todo_list" in section_names
    assert "ids" in section_names
    assert "conclude" in section_names


def test_prep_l10_no_active_mind():
    """Returns NO_ACTIVE_MIND when no mind is set."""
    from coppermind_cmo.tools.eos import _prep_l10

    result = _prep_l10(db=MagicMock(), active_mind=None, customer_id="c1")
    assert result.get("error") is not None


def test_prep_l10_rock_review_includes_status(mock_db):
    """Rock review section includes each rock with status."""
    from coppermind_cmo.tools.eos import _prep_l10

    # All _has_* checks return True via fetch_one
    mock_db.fetch_one.return_value = (1,)
    # fetch_all calls in order: scorecard, rocks, headlines, todos, issues, agenda
    mock_db.fetch_all.side_effect = [
        [],  # scorecard (campaign_outcome memories)
        [("r1", "Launch website", "Rewrite the site", "on_track", 60, "Sarah")],  # rocks
        [],  # headlines
        [],  # todos (commitments)
        [],  # issues
        [],  # agenda items
    ]

    result = _prep_l10(
        db=mock_db,
        active_mind=("mind-1", "Acme"),
        customer_id="c1",
    )

    rock_section = next(s for s in result["sections"] if s["name"] == "rock_review")
    assert len(rock_section["items"]) >= 1


def test_prep_l10_ids_section_has_open_issues(mock_db):
    """IDS section lists open issues sorted by priority."""
    from coppermind_cmo.tools.eos import _prep_l10

    mock_db.fetch_one.return_value = (1,)  # all tables exist
    # fetch_all calls in order: scorecard, rocks, headlines, todos, issues, agenda
    mock_db.fetch_all.side_effect = [
        [],  # scorecard
        [],  # rocks
        [],  # headlines
        [],  # todos
        [("i1", "Fix pricing page", "Revenue drop", "open", None)],  # issues
        [],  # agenda items
    ]

    result = _prep_l10(
        db=mock_db,
        active_mind=("mind-1", "Acme"),
        customer_id="c1",
    )

    ids_section = next(s for s in result["sections"] if s["name"] == "ids")
    assert len(ids_section["items"]) >= 1
