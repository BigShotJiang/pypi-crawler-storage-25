"""Tests for switch_client, list_minds, configure_mind, and ensure_personal_mind tools."""

import os
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch
from coppermind_cmo.tools.minds import _switch_client, _list_minds, _make_slug, _configure_mind, _ensure_personal_mind


class TestSwitchClient:
    def test_finds_existing_mind_by_name(self):
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme Corp", "acme-corp", None, False, None, None, None, None),  # includes cadence + company_info + brand_voice + local_path
            (47,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="test-customer")
        assert result["name"] == "Acme Corp"
        assert result["mind_id"] == "uuid-1"
        assert result["is_new"] is False
        assert result["memory_count"] == 47
        set_mind.assert_called_once_with("uuid-1", "Acme Corp", brand_color=None)

    def test_creates_new_mind(self):
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]
        db.execute_returning.return_value = ("uuid-new", "NewClient", "newclient")
        set_mind = MagicMock()
        result = _switch_client("NewClient", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        set_mind.assert_called_once()

    def test_not_found_and_no_create(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        db.fetch_all.return_value = [("Acme Corp",), ("Bluebell",)]
        set_mind = MagicMock()
        result = _switch_client("Typo", False, db, set_mind, customer_id="test-customer")
        assert result["error"] is True
        assert result["code"] == "MIND_NOT_FOUND"
        set_mind.assert_not_called()

    def test_archived_mind_returns_error(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "uuid-1", "Old Client", "old-client", "2026-01-01T00:00:00Z", False, None, None, None, None,
        )
        set_mind = MagicMock()
        result = _switch_client("Old Client", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "MIND_ARCHIVED"

    def test_empty_name_returns_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "INVALID_INPUT"

    def test_whitespace_name_returns_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("   ", False, db, set_mind, customer_id="test-customer")
        assert result["code"] == "INVALID_INPUT"

    def test_no_customer_id_returns_provisioning_error(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("Acme", False, db, set_mind, customer_id=None)
        assert result["code"] == "PROVISIONING_ERROR"
        set_mind.assert_not_called()


class TestMakeSlug:
    def test_basic_slug(self):
        assert _make_slug("Acme Corp") == "acme-corp"

    def test_multiple_spaces(self):
        assert _make_slug("Hello   World") == "hello-world"

    def test_leading_trailing_hyphens(self):
        assert _make_slug("--leading--") == "leading"

    def test_special_chars(self):
        assert _make_slug("Special!@#Chars") == "special-chars"


class TestListMinds:
    def test_returns_all_minds(self):
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert len(result) == 1
        assert result[0]["name"] == "Acme Corp"
        assert result[0]["memory_count"] == 47

    def test_no_customer_id_returns_empty(self):
        db = MagicMock()
        result = _list_minds(50, 0, db, customer_id=None)
        assert result == []
        db.fetch_all.assert_not_called()


class TestConfigureMind:
    def test_configure_mind_cadence(self):
        """Sets cadence JSONB correctly."""
        db = MagicMock()
        cadence = {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        db.execute_returning.return_value = (cadence, {}, None)
        mind = ("mind-1", "Acme")

        result = _configure_mind(cadence, None, db, mind)
        assert result["mind_id"] == "mind-1"
        assert result["name"] == "Acme"
        assert result["cadence"] == cadence
        assert "cadence" in result["updated_fields"]
        assert "company_info" not in result["updated_fields"]

    def test_configure_mind_company_info(self):
        """Sets company_info JSONB correctly."""
        db = MagicMock()
        company_info = {"url": "https://acme.com", "industry": "SaaS"}
        db.execute_returning.return_value = ({}, company_info, None)
        mind = ("mind-1", "Acme")

        result = _configure_mind(None, company_info, db, mind)
        assert result["company_info"] == company_info
        assert "company_info" in result["updated_fields"]
        assert "cadence" not in result["updated_fields"]

    def test_configure_mind_merge(self):
        """Calling twice merges (doesn't replace) — verified by checking SQL uses || operator."""
        db = MagicMock()
        cadence1 = {"type": "eos", "year": 2026}
        db.execute_returning.return_value = ({"type": "eos", "year": 2026, "quarter": 1}, {}, None)
        mind = ("mind-1", "Acme")

        _configure_mind(cadence1, None, db, mind)

        # Verify SQL uses JSONB merge operator
        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        assert "||" in sql, "SQL should use || for JSONB merge"
        assert "COALESCE" in sql, "SQL should use COALESCE for NULL handling"

    def test_configure_mind_validation_quarter(self):
        """Quarter outside 1-4 returns error."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind({"quarter": 5}, None, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "quarter" in result["message"]

    def test_configure_mind_validation_year(self):
        """Year outside 2020-2100 returns error."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind({"year": 2019}, None, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "year" in result["message"]

    def test_configure_mind_no_active_mind(self):
        """Returns NO_ACTIVE_MIND."""
        db = MagicMock()
        result = _configure_mind({"type": "eos"}, None, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_configure_mind_nothing_provided(self):
        """Returns INVALID_INPUT when both None."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind(None, None, db, mind)
        assert result["code"] == "INVALID_INPUT"
        assert "Provide" in result["message"]


class TestInternalMinds:
    """Fix #6: Internal minds for non-client notes."""

    def test_create_internal_mind(self):
        """switch_client with is_internal=True creates mind with is_internal flag."""
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]  # not found, no slug conflict
        db.execute_returning.return_value = ("uuid-internal", "Product Feedback", "product-feedback")
        set_mind = MagicMock()
        result = _switch_client("Product Feedback", True, db, set_mind,
                                is_internal=True, customer_id="test-customer")
        assert result["is_new"] is True
        assert result.get("is_internal") is True
        # Verify INSERT includes is_internal
        insert_sql = db.execute_returning.call_args[0][0]
        assert "is_internal" in insert_sql

    def test_create_normal_mind_not_internal(self):
        """Normal mind creation should not set is_internal."""
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]
        db.execute_returning.return_value = ("uuid-normal", "Acme", "acme")
        set_mind = MagicMock()
        result = _switch_client("Acme", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        assert result.get("is_internal") is not True

    def test_list_minds_excludes_internal_by_default(self):
        """list_minds should exclude internal minds by default."""
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        # Verify SQL includes is_internal filter
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal" in sql

    def test_list_minds_includes_internal_when_requested(self):
        """list_minds with include_internal=True should not filter."""
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, created, updated),
            ("uuid-2", "Product Notes", "product-notes", None, 10, created, updated),
        ]
        result = _list_minds(50, 0, db, include_internal=True, customer_id="test-customer")
        assert len(result) == 2
        # Verify SQL does NOT filter by is_internal
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal = false" not in sql

    def test_switch_to_existing_internal_mind(self):
        """switch_client to an existing internal mind should work and return is_internal."""
        db = MagicMock()
        # Row returns: id, name, slug, archived_at, is_internal, cadence, company_info, brand_voice, local_path
        db.fetch_one.side_effect = [
            ("uuid-int", "Product Feedback", "product-feedback", None, True, None, None, None, None),
            (5,),  # memory count
        ]
        set_mind = MagicMock()
        result = _switch_client("Product Feedback", False, db, set_mind,
                                customer_id="test-customer")
        assert result["mind_id"] == "uuid-int"
        assert result["is_internal"] is True


class TestSchemaDegradation:
    """Graceful degradation when migration 007 (is_internal column) hasn't been run."""

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_switch_client_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme", "acme", None, None, None, None, None),  # 8 columns (no is_internal, has cadence + company_info + brand_voice + local_path)
            (10,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme", False, db, set_mind, customer_id="test-customer")
        assert result["mind_id"] == "uuid-1"
        assert result.get("is_internal") is None  # not present

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_list_minds_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        created = datetime(2026, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        updated = datetime(2026, 3, 8, 16, 0, 0, tzinfo=timezone.utc)
        db.fetch_all.return_value = [
            ("uuid-1", "Acme", "acme", None, 5, created, updated),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert len(result) == 1
        sql = db.fetch_all.call_args[0][0]
        assert "is_internal" not in sql

    @patch("coppermind_cmo.tools.minds._has_is_internal", return_value=False)
    def test_create_mind_works_without_is_internal_column(self, mock_check):
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]  # not found, no slug conflict
        db.execute_returning.return_value = ("uuid-new", "New", "new")
        set_mind = MagicMock()
        result = _switch_client("New", True, db, set_mind, customer_id="test-customer")
        assert result["is_new"] is True
        insert_sql = db.execute_returning.call_args[0][0]
        assert "is_internal" not in insert_sql


class TestConfigureMindPathValidation:
    """Finding 1: Canonicalize and validate local_path."""

    def test_rejects_system_directory_etc(self):
        """local_path pointing to /etc should be rejected."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind(None, None, db, mind, local_path="/etc/passwd")
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "system directory" in result["message"]

    def test_rejects_sensitive_directory_ssh(self):
        """local_path pointing to ~/.ssh should be rejected."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        ssh_path = os.path.expanduser("~/.ssh")
        result = _configure_mind(None, None, db, mind, local_path=ssh_path)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "sensitive directory" in result["message"]

    def test_accepts_valid_path(self, tmp_path):
        """A valid directory path should be accepted."""
        db = MagicMock()
        db.execute_returning.return_value = ({}, {}, str(tmp_path))
        mind = ("mind-1", "Acme")
        result = _configure_mind(None, None, db, mind, local_path=str(tmp_path))
        assert result.get("error") is not True
        assert "local_path" in result.get("updated_fields", [])

    def test_rejects_file_path(self, tmp_path):
        """local_path pointing to a file (not directory) should be rejected."""
        f = tmp_path / "some_file.txt"
        f.write_text("content")
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _configure_mind(None, None, db, mind, local_path=str(f))
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "directory" in result["message"]

    def test_canonicalizes_tilde_path(self, tmp_path):
        """Paths with ~ should be expanded before validation."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        # ~/.ssh should get expanded and then rejected
        result = _configure_mind(None, None, db, mind, local_path="~/.ssh")
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"


class TestEnsurePersonalMind:
    """Tests for _ensure_personal_mind — lazy find-or-create."""

    def test_returns_existing_mind(self):
        """If personal mind already exists, return it without INSERT."""
        db = MagicMock()
        db.fetch_one.return_value = ("uuid-personal", "Ben Finklea", "personal-ben-finklea")
        result = _ensure_personal_mind("ben_finklea", db)
        assert result["mind_id"] == "uuid-personal"
        assert result["slug"] == "personal-ben-finklea"
        assert result["created"] is False
        db.execute_returning.assert_not_called()

    def test_creates_new_mind(self):
        """If personal mind doesn't exist, create it with deterministic slug."""
        db = MagicMock()
        db.fetch_one.return_value = None  # not found
        db.execute_returning.return_value = ("uuid-new", "Ben Finklea", "personal-ben-finklea")
        result = _ensure_personal_mind("ben_finklea", db)
        assert result["mind_id"] == "uuid-new"
        assert result["slug"] == "personal-ben-finklea"
        assert result["created"] is True
        # Verify slug in INSERT call
        insert_call = db.execute_returning.call_args
        assert "personal-ben-finklea" in insert_call[0][1]

    def test_slug_derived_from_customer_id(self):
        """Slug must be _make_slug(f'personal-{customer_id}'), not from display name."""
        db = MagicMock()
        db.fetch_one.return_value = None
        db.execute_returning.return_value = ("uuid-new", "My Notes", "personal-bf-volacci-com")
        result = _ensure_personal_mind("bf@volacci.com", db)
        insert_call = db.execute_returning.call_args
        assert "personal-bf-volacci-com" in insert_call[0][1]

    def test_email_customer_id_uses_local_part_as_name(self):
        """Email-style customer_id should derive name from local part, not 'My Notes'."""
        db = MagicMock()
        db.fetch_one.return_value = None
        db.execute_returning.return_value = ("uuid-new", "Bf", "personal-bf-volacci-com")
        _ensure_personal_mind("bf@volacci.com", db)
        insert_call = db.execute_returning.call_args
        # Should use title-cased local part "Bf", not "My Notes"
        assert "Bf" in insert_call[0][1]
        assert "My Notes" not in insert_call[0][1]

    def test_dotted_email_customer_id(self):
        """Email like ben.finklea@volacci.com should produce 'Ben Finklea'."""
        db = MagicMock()
        db.fetch_one.return_value = None
        db.execute_returning.return_value = ("uuid-new", "Ben Finklea", "personal-ben-finklea-volacci-com")
        _ensure_personal_mind("ben.finklea@volacci.com", db)
        insert_call = db.execute_returning.call_args
        assert "Ben Finklea" in insert_call[0][1]

    def test_no_customer_id_returns_error(self):
        """Empty customer_id should return an error, not attempt creation."""
        db = MagicMock()
        result = _ensure_personal_mind("", db)
        assert result.get("error") is True
        db.fetch_one.assert_not_called()

    def test_race_condition_re_queries(self):
        """If ON CONFLICT fires (concurrent creation), re-query to find it."""
        db = MagicMock()
        # fetch_one calls: (1) initial lookup=None, (2) re-query=found
        # Note: _has_local_path_col is pre-cached True by the conftest fixture,
        # so no schema check query is issued.
        db.fetch_one.side_effect = [
            None,  # initial slug lookup: not found
            ("uuid-raced", "Ben Finklea", "personal-ben-finklea"),  # re-query after conflict
        ]
        db.execute_returning.return_value = None  # ON CONFLICT — no row returned
        result = _ensure_personal_mind("ben_finklea", db)
        assert result["mind_id"] == "uuid-raced"
        assert result["created"] is False

    def test_creates_without_is_internal_column(self, monkeypatch):
        """When is_internal column doesn't exist (pre-migration 007), INSERT omits it."""
        monkeypatch.setattr("coppermind_cmo.tools.minds._has_is_internal", lambda db: False)
        monkeypatch.setattr("coppermind_cmo.tools.minds._has_local_path", lambda db: False)
        db = MagicMock()
        db.fetch_one.return_value = None  # not found
        db.execute_returning.return_value = ("uuid-new", "Ben Finklea", "personal-ben-finklea")
        result = _ensure_personal_mind("ben_finklea", db)
        assert result["mind_id"] == "uuid-new"
        assert result["created"] is True
        # Verify INSERT does NOT contain is_internal
        insert_sql = db.execute_returning.call_args[0][0]
        assert "is_internal" not in insert_sql
        # Verify INSERT does NOT contain local_path
        assert "local_path" not in insert_sql

    def test_cross_customer_slug_collision_returns_error(self):
        """If another customer owns the slug, re-query must NOT return their mind."""
        db = MagicMock()
        # fetch_one calls: (1) initial lookup=None (scoped by customer_id),
        # (2) _has_is_internal check, (3) _has_local_path check,
        # (4) re-query after ON CONFLICT=None (different customer owns slug)
        db.fetch_one.side_effect = [
            None,   # initial lookup: not found for THIS customer
            (1,),   # _has_is_internal: column exists
            (1,),   # _has_local_path: column exists
            None,   # re-query with customer_id filter: no match (other customer's mind)
        ]
        db.execute_returning.return_value = None  # ON CONFLICT — slug taken
        result = _ensure_personal_mind("customer_b", db)
        assert result.get("error") is True
        # Verify re-query included customer_id
        requery_call = db.fetch_one.call_args_list[-1]
        assert "customer_id" in requery_call[0][0] or "customer_b" in requery_call[0][1]


# ---------------------------------------------------------------------------
# Brand color in switch_client response
# ---------------------------------------------------------------------------

class TestSwitchClientBrandColor:
    def test_includes_brand_color_when_configured(self):
        """switch_client includes brand_color when brand_voice has brand_colors.primary."""
        import json
        db = MagicMock()
        brand_voice_json = json.dumps({"tone": ["casual"], "brand_colors": {"primary": "#FF5733"}})
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme Corp", "acme-corp", None, False, None, None, brand_voice_json, None),
            (10,),  # memory count
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="test-customer")
        assert result["brand_color"] == "#FF5733"
        set_mind.assert_called_once_with("uuid-1", "Acme Corp", brand_color="#FF5733")

    def test_omits_brand_color_when_no_colors(self):
        """switch_client omits brand_color when brand_voice has no brand_colors."""
        import json
        db = MagicMock()
        brand_voice_json = json.dumps({"tone": ["formal"]})
        db.fetch_one.side_effect = [
            ("uuid-2", "Beta Inc", "beta-inc", None, False, None, None, brand_voice_json, None),
            (5,),  # memory count
        ]
        set_mind = MagicMock()
        result = _switch_client("Beta Inc", False, db, set_mind, customer_id="test-customer")
        assert "brand_color" not in result

    def test_omits_brand_color_when_brand_voice_null(self):
        """switch_client omits brand_color when brand_voice is NULL in DB."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-3", "Gamma LLC", "gamma-llc", None, False, None, None, None, None),
            (3,),  # memory count
        ]
        set_mind = MagicMock()
        result = _switch_client("Gamma LLC", False, db, set_mind, customer_id="test-customer")
        assert "brand_color" not in result
