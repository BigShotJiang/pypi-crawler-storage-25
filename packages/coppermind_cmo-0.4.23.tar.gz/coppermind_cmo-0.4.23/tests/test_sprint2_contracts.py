"""Sprint 2 API contract tests for Daily Loop and EOS tool interfaces.

Verifies response shapes (required keys, correct types) and error codes
match the documented contracts. These complement behavioral tests in
test_daily_loop.py and test_eos.py by focusing exclusively on the *shape*
of return values.

Pattern follows test_api_contracts.py:
  - Each tool gets a test class
  - EXPECTED_KEYS set defines required keys
  - test_success_has_all_expected_keys — check keys present
  - test_success_has_only_expected_keys — check no unexpected keys
  - Error case tests for NO_ACTIVE_MIND, INVALID_INPUT, MIGRATION_REQUIRED
"""

import json
import uuid
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

import coppermind_cmo.tools.daily_loop as daily_loop_mod
import coppermind_cmo.tools.eos as eos_mod
from coppermind_cmo.tools.daily_loop import (
    _get_cross_client_summary,
    _get_meeting_context,
    _get_weekly_summary,
    _log_meeting_event,
    _mark_followup_sent,
)
from coppermind_cmo.tools.eos import (
    _get_agenda,
    _get_current_sprint,
    _get_issues,
    _get_rocks,
    _get_sprint_plan,
    _import_sprint_plan,
    _manage_agenda,
    _manage_issue,
    _manage_rock,
    _quarterly_pacing,
    _start_quarter,
    _update_sprint_status,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CUSTOMER_ID = "test-customer-uuid"


def _dt(day: int = 1, hour: int = 10) -> datetime:
    """Create a timezone-aware datetime for March 2026."""
    return datetime(2026, 3, day, hour, 0, 0, tzinfo=timezone.utc)


def _cadence_row(year=2026, quarter=1, sprint=3, spq=6):
    """Return a mock cadence dict."""
    return {
        "type": "eos",
        "year": year,
        "quarter": quarter,
        "sprint": sprint,
        "sprints_per_quarter": spq,
    }


def assert_has_keys(result, expected_keys):
    """Verify result dict has all expected keys."""
    for key in expected_keys:
        assert key in result, f"Missing key: {key}"


def assert_error_shape(result, expected_code):
    """Verify result is a valid error response."""
    assert isinstance(result, dict), f"Error must be dict, got {type(result).__name__}"
    assert result["error"] is True, "error field must be True"
    assert result["code"] == expected_code, (
        f"Expected code '{expected_code}', got '{result.get('code')}'"
    )
    assert isinstance(result["message"], str), "message must be a string"
    assert len(result["message"]) > 0, "message must not be empty"


def _setup_import_mocks(mock_db, plan_id, fetchone_results, existing_plan=False):
    """Set up mock_db for _import_sprint_plan transaction tests."""
    mock_cursor = MagicMock()
    mock_conn = MagicMock()

    cursor_cm = MagicMock()
    cursor_cm.__enter__ = MagicMock(return_value=mock_cursor)
    cursor_cm.__exit__ = MagicMock(return_value=False)
    mock_conn.cursor.return_value = cursor_cm

    if existing_plan:
        plan_lookup = (plan_id,)
    else:
        plan_lookup = None

    mock_cursor.fetchone.side_effect = [plan_lookup] + (
        [(plan_id,)] if not existing_plan else []
    ) + fetchone_results

    @contextmanager
    def _mock_connection():
        yield mock_conn

    mock_db.connection = _mock_connection
    return mock_cursor, mock_conn


# ---------------------------------------------------------------------------
# Autouse fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_daily_loop_cache(tmp_path, monkeypatch):
    """Reset meeting_log table cache between tests."""
    daily_loop_mod._has_meeting_log = None
    daily_loop_mod._notification_state = None
    monkeypatch.setattr(
        daily_loop_mod, "_NOTIFICATION_STATE_FILE", tmp_path / "notification-state.json"
    )
    yield
    daily_loop_mod._has_meeting_log = None
    daily_loop_mod._notification_state = None


@pytest.fixture(autouse=True)
def reset_eos_caches():
    """Reset EOS table detection caches between tests."""
    eos_mod._rocks_table_exists = None
    eos_mod._sprint_plans_table_exists = None
    eos_mod._agenda_items_table_exists = None
    eos_mod._eos_issues_table_exists = None
    yield
    eos_mod._rocks_table_exists = None
    eos_mod._sprint_plans_table_exists = None
    eos_mod._agenda_items_table_exists = None
    eos_mod._eos_issues_table_exists = None


@pytest.fixture(autouse=True)
def assume_eos_tables(monkeypatch):
    """Assume all EOS tables exist by default."""
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: True)
    monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: True)


@pytest.fixture(autouse=True)
def assume_meeting_log_table(monkeypatch):
    """Assume meeting_log table exists by default."""
    monkeypatch.setattr(
        "coppermind_cmo.tools.daily_loop._has_meeting_log_table", lambda db: True
    )


# ===========================================================================
# DAILY LOOP CONTRACT TESTS
# ===========================================================================


# ---------------------------------------------------------------------------
# 1. log_meeting_event
# ---------------------------------------------------------------------------

class TestLogMeetingEventContract:
    """Verify _log_meeting_event response shape."""

    EXPECTED_KEYS = {"meeting_log_id", "title", "start_time", "mind_id", "is_new", "match_confidence"}

    def test_success_has_all_expected_keys(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1", True)
        result = _log_meeting_event(
            title="Weekly Sync",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id="mind-1",
            match_confidence="confident",
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1", True)
        result = _log_meeting_event(
            title="Sync",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id="mind-1",
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1", True)
        result = _log_meeting_event(
            title="Sync",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id="gcal-abc",
            end_time="2026-03-21T11:00:00+00:00",
            attendees=[{"email": "a@b.com"}],
            mind_id="mind-1",
            match_confidence="confident",
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert isinstance(result["meeting_log_id"], str)
        assert isinstance(result["title"], str)
        assert isinstance(result["start_time"], str)
        assert isinstance(result["is_new"], bool)
        assert isinstance(result["match_confidence"], str)

    def test_error_empty_title(self, mock_db):
        result = _log_meeting_event(
            title="",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None, end_time=None, attendees=None,
            mind_id=None, match_confidence=None,
            db=mock_db, customer_id=CUSTOMER_ID,
        )
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_bad_start_time(self, mock_db):
        result = _log_meeting_event(
            title="Meeting",
            start_time="not-a-date",
            calendar_event_id=None, end_time=None, attendees=None,
            mind_id=None, match_confidence=None,
            db=mock_db, customer_id=CUSTOMER_ID,
        )
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_naive_datetime(self, mock_db):
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00",
            calendar_event_id=None, end_time=None, attendees=None,
            mind_id=None, match_confidence=None,
            db=mock_db, customer_id=CUSTOMER_ID,
        )
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_table_missing(self, mock_db, monkeypatch):
        monkeypatch.setattr(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table", lambda db: False
        )
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None, end_time=None, attendees=None,
            mind_id=None, match_confidence=None,
            db=mock_db, customer_id=CUSTOMER_ID,
        )
        assert_error_shape(result, "MIGRATION_REQUIRED")


# ---------------------------------------------------------------------------
# 2. get_cross_client_summary
# ---------------------------------------------------------------------------

class TestGetCrossClientSummaryContract:
    """Verify _get_cross_client_summary response shape."""

    EXPECTED_KEYS = {"summaries", "lookback_hours", "client_count"}
    SUMMARY_ITEM_KEYS = {
        "mind_id", "mind_name", "open_commitments",
        "recent_memories", "last_activity", "todays_meetings",
    }

    def test_success_has_all_expected_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme Corp")],  # minds
            [("mind-1", 2, 5, _dt(21))],  # stats
            [],  # meetings
        ]
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme Corp")],
            [("mind-1", 2, 5, _dt(21))],
            [],
        ]
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_summary_item_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme Corp")],
            [("mind-1", 2, 5, _dt(21))],
            [],
        ]
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert len(result["summaries"]) == 1
        assert_has_keys(result["summaries"][0], self.SUMMARY_ITEM_KEYS)

    def test_no_minds_returns_message(self, mock_db):
        mock_db.fetch_all.return_value = []
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert "summaries" in result
        assert result["summaries"] == []
        assert "message" in result

    def test_key_types(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme Corp")],
            [("mind-1", 2, 5, _dt(21))],
            [],
        ]
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert isinstance(result["summaries"], list)
        assert isinstance(result["lookback_hours"], int)
        assert isinstance(result["client_count"], int)


# ---------------------------------------------------------------------------
# 3. get_meeting_context
# ---------------------------------------------------------------------------

class TestGetMeetingContextContract:
    """Verify _get_meeting_context response shape."""

    EXPECTED_KEYS = {"mind_id", "recent_memories", "memory_count", "hours_ago", "brief", "meeting_entry"}

    def test_success_has_all_expected_keys(self, mock_db):
        mock_db.fetch_all.return_value = []  # no recent memories
        mock_db.fetch_one.return_value = None  # no brief
        active = ("mind-1", "Acme")
        result = _get_meeting_context(
            meeting_log_id=None, mind_id=None, hours_ago=6,
            db=mock_db, customer_id=CUSTOMER_ID, active_mind=active,
        )
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db):
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.return_value = None
        active = ("mind-1", "Acme")
        result = _get_meeting_context(
            meeting_log_id=None, mind_id=None, hours_ago=6,
            db=mock_db, customer_id=CUSTOMER_ID, active_mind=active,
        )
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db):
        mock_db.fetch_all.return_value = [
            ("m1", "content", "summary", "fact", _dt(21)),
        ]
        mock_db.fetch_one.return_value = None
        active = ("mind-1", "Acme")
        result = _get_meeting_context(
            meeting_log_id=None, mind_id=None, hours_ago=6,
            db=mock_db, customer_id=CUSTOMER_ID, active_mind=active,
        )
        assert isinstance(result["mind_id"], str)
        assert isinstance(result["recent_memories"], list)
        assert isinstance(result["memory_count"], int)
        assert isinstance(result["hours_ago"], int)
        assert result["memory_count"] == len(result["recent_memories"])

    def test_memory_item_keys(self, mock_db):
        mock_db.fetch_all.return_value = [
            ("m1", "content text", "summary text", "fact", _dt(21)),
        ]
        mock_db.fetch_one.return_value = None
        active = ("mind-1", "Acme")
        result = _get_meeting_context(
            meeting_log_id=None, mind_id=None, hours_ago=6,
            db=mock_db, customer_id=CUSTOMER_ID, active_mind=active,
        )
        mem = result["recent_memories"][0]
        assert_has_keys(mem, {"memory_id", "content", "summary", "memory_type", "created_at"})

    def test_error_no_active_mind(self, mock_db):
        result = _get_meeting_context(
            meeting_log_id=None, mind_id=None, hours_ago=6,
            db=mock_db, customer_id=CUSTOMER_ID, active_mind=None,
        )
        assert_error_shape(result, "NO_ACTIVE_MIND")


# ---------------------------------------------------------------------------
# 4. mark_followup_sent
# ---------------------------------------------------------------------------

class TestMarkFollowupSentContract:
    """Verify _mark_followup_sent response shape."""

    EXPECTED_KEYS = {"meeting_log_id", "followup_sent"}

    def test_success_has_all_expected_keys(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1",)
        result = _mark_followup_sent("meeting-uuid-1", mock_db, CUSTOMER_ID)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1",)
        result = _mark_followup_sent("meeting-uuid-1", mock_db, CUSTOMER_ID)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db):
        mock_db.execute_returning.return_value = ("meeting-uuid-1",)
        result = _mark_followup_sent("meeting-uuid-1", mock_db, CUSTOMER_ID)
        assert isinstance(result["meeting_log_id"], str)
        assert isinstance(result["followup_sent"], bool)
        assert result["followup_sent"] is True

    def test_error_empty_id(self, mock_db):
        result = _mark_followup_sent("", mock_db, CUSTOMER_ID)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_not_found(self, mock_db):
        mock_db.execute_returning.return_value = None
        result = _mark_followup_sent("no-such-id", mock_db, CUSTOMER_ID)
        assert_error_shape(result, "NOT_FOUND")

    def test_error_table_missing(self, mock_db, monkeypatch):
        monkeypatch.setattr(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table", lambda db: False
        )
        result = _mark_followup_sent("id", mock_db, CUSTOMER_ID)
        assert_error_shape(result, "MIGRATION_REQUIRED")


# ---------------------------------------------------------------------------
# 5. get_weekly_summary
# ---------------------------------------------------------------------------

class TestGetWeeklySummaryContract:
    """Verify _get_weekly_summary response shape."""

    EXPECTED_KEYS = {"summaries", "week_start", "week_end", "client_count"}
    SUMMARY_ITEM_KEYS = {
        "mind_id", "mind_name", "meetings_held", "followups_sent",
        "followups_pending", "memories_by_type", "open_commitments",
    }

    def test_success_has_all_expected_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],  # minds
            [],  # meeting stats
            [],  # type stats
            [],  # commitments
        ]
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],  # meeting stats
            [],  # type stats
            [],  # commitments
        ]
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_summary_item_keys(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],
            [],
            [],
        ]
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert len(result["summaries"]) == 1
        assert_has_keys(result["summaries"][0], self.SUMMARY_ITEM_KEYS)

    def test_key_types(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],
            [],
            [],
        ]
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert isinstance(result["summaries"], list)
        assert isinstance(result["week_start"], str)
        assert isinstance(result["week_end"], str)
        assert isinstance(result["client_count"], int)

    def test_no_minds_returns_message(self, mock_db):
        mock_db.fetch_all.return_value = []
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert result["summaries"] == []
        assert "message" in result

    def test_error_invalid_week_start(self, mock_db):
        result = _get_weekly_summary("not-a-date", None, mock_db, CUSTOMER_ID)
        assert_error_shape(result, "INVALID_INPUT")


# ===========================================================================
# EOS CONTRACT TESTS
# ===========================================================================


# ---------------------------------------------------------------------------
# 6. manage_rock
# ---------------------------------------------------------------------------

class TestManageRockContract:
    """Verify _manage_rock response shape."""

    EXPECTED_KEYS = {"rock_id", "title", "status", "progress_pct", "is_new"}

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        rid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rid, "Rock A", "on_track", 0, True)
        result = _manage_rock("Rock A", mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        rid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rid, "Rock A", "on_track", 0, True)
        result = _manage_rock("Rock A", mock_db, active_mind)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        rid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rid, "Rock A", "on_track", 25, True)
        result = _manage_rock("Rock A", mock_db, active_mind)
        assert isinstance(result["rock_id"], str)
        assert isinstance(result["title"], str)
        assert isinstance(result["status"], str)
        assert isinstance(result["progress_pct"], int)
        assert isinstance(result["is_new"], bool)

    def test_update_by_id_returns_same_keys(self, mock_db, active_mind):
        """Update path (rock_id provided) returns the same key set."""
        mock_db.fetch_one.return_value = (_cadence_row(),)
        rid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (rid, "Rock A", "complete", 100)
        result = _manage_rock("Rock A", mock_db, active_mind, rock_id=rid, status="complete")
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["is_new"] is False

    def test_error_no_active_mind(self, mock_db):
        result = _manage_rock("Rock", mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _manage_rock("Rock", mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_empty_title(self, mock_db, active_mind):
        result = _manage_rock("", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 7. get_rocks
# ---------------------------------------------------------------------------

class TestGetRocksContract:
    """Verify _get_rocks response shape."""

    BASE_ITEM_KEYS = {
        "rock_id", "title", "description", "owner", "status",
        "progress_pct", "quarter_year", "quarter", "created_at", "updated_at",
    }
    DELIVERABLE_EXTRA_KEYS = {"deliverable_count", "deliverable_completion_pct"}

    def test_success_returns_list(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        mock_db.fetch_all.return_value = []
        result = _get_rocks(mock_db, active_mind)
        assert isinstance(result, list)

    def test_item_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        now = _dt(21)
        rid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (rid, "Rock 1", "Desc", "Alice", "on_track", 50, 2026, 1, now, now, 3, 67),
        ]
        result = _get_rocks(mock_db, active_mind)
        assert len(result) == 1
        assert_has_keys(result[0], self.BASE_ITEM_KEYS | self.DELIVERABLE_EXTRA_KEYS)

    def test_item_without_sprint_plans_table(self, mock_db, active_mind, monkeypatch):
        """Without sprint_plans table, deliverable_count/completion_pct are absent."""
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        mock_db.fetch_one.return_value = (_cadence_row(),)
        now = _dt(21)
        rid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (rid, "Rock 1", None, None, "on_track", 0, 2026, 1, now, now),
        ]
        result = _get_rocks(mock_db, active_mind)
        assert_has_keys(result[0], self.BASE_ITEM_KEYS)
        assert "deliverable_count" not in result[0]

    def test_error_no_active_mind(self, mock_db):
        result = _get_rocks(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _get_rocks(mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")


# ---------------------------------------------------------------------------
# 8. import_sprint_plan
# ---------------------------------------------------------------------------

class TestImportSprintPlanContract:
    """Verify _import_sprint_plan response shape."""

    EXPECTED_KEYS = {"sprint_plan_id", "imported_count", "updated_count", "quarter_year", "quarter"}

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        _, _ = _setup_import_mocks(mock_db, plan_id, [("d1", True)])
        csv_data = "initiative_name,sprint_number,deliverable\nTest,1,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        _, _ = _setup_import_mocks(mock_db, plan_id, [("d1", True)])
        csv_data = "initiative_name,sprint_number,deliverable\nTest,1,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.return_value = (_cadence_row(),)
        _, _ = _setup_import_mocks(mock_db, plan_id, [("d1", True)])
        csv_data = "initiative_name,sprint_number,deliverable\nTest,1,Do thing\n"
        result = _import_sprint_plan(csv_data, "csv", mock_db, active_mind)
        assert isinstance(result["sprint_plan_id"], str)
        assert isinstance(result["imported_count"], int)
        assert isinstance(result["updated_count"], int)
        assert isinstance(result["quarter_year"], int)
        assert isinstance(result["quarter"], int)

    def test_error_no_active_mind(self, mock_db):
        result = _import_sprint_plan("data", "csv", mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        result = _import_sprint_plan("data", "csv", mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_empty_data(self, mock_db, active_mind):
        result = _import_sprint_plan("", "csv", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_invalid_format(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _import_sprint_plan("data", "xml", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 9. get_sprint_plan
# ---------------------------------------------------------------------------

class TestGetSprintPlanContract:
    """Verify _get_sprint_plan response shape."""

    EXPECTED_KEYS = {"sprint_plan_id", "quarter_year", "quarter", "current_sprint", "sprint_end_dates", "deliverables"}
    NO_PLAN_KEYS = {"quarter_year", "quarter", "sprint_plan_id", "deliverables", "message"}
    DELIVERABLE_ITEM_KEYS = {
        "deliverable_id", "initiative_name", "owner", "quarterly_goal",
        "sprint_number", "deliverable", "status", "notes", "rock_id",
        "is_current_sprint",
    }

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, ["2026-03-15"]),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "Alice", "Launch site", 1, "Design",
             "in_progress", None, None, None, None, None),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_no_plan_returns_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,  # no plan
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        assert_has_keys(result, self.NO_PLAN_KEYS)
        assert result["sprint_plan_id"] is None
        assert result["deliverables"] == []

    def test_deliverable_item_keys(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, []),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "Alice", "Launch", 1, "Design",
             "in_progress", None, None, None, None, None),
        ]
        result = _get_sprint_plan(mock_db, active_mind)
        d = result["deliverables"][0]
        assert_has_keys(d, self.DELIVERABLE_ITEM_KEYS)

    def test_key_types(self, mock_db, active_mind):
        plan_id = str(uuid.uuid4())
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (plan_id, ["2026-03-15"]),
        ]
        mock_db.fetch_all.return_value = []
        result = _get_sprint_plan(mock_db, active_mind)
        assert isinstance(result["sprint_plan_id"], str)
        assert isinstance(result["quarter_year"], int)
        assert isinstance(result["quarter"], int)
        assert isinstance(result["sprint_end_dates"], list)
        assert isinstance(result["deliverables"], list)

    def test_error_no_active_mind(self, mock_db):
        result = _get_sprint_plan(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_sprint_plans", lambda db: False)
        result = _get_sprint_plan(mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")


# ---------------------------------------------------------------------------
# 10. update_sprint_status
# ---------------------------------------------------------------------------

class TestUpdateSprintStatusContract:
    """Verify _update_sprint_status response shape."""

    EXPECTED_KEYS = {"deliverable_id", "initiative_name", "status", "previous_status", "sprint_resolved_via"}

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),  # cadence
            (["2026-04-15"],),  # sprint_end_dates
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website Redesign", "in_progress", 3),
        ]
        result = _update_sprint_status("website", "complete", mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (["2026-04-15"],),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website Redesign", "not_started", 3),
        ]
        result = _update_sprint_status("website", "complete", mock_db, active_mind)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            (["2026-04-15"],),
        ]
        did = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (did, "Website", "not_started", 3),
        ]
        result = _update_sprint_status("website", "in_progress", mock_db, active_mind)
        assert isinstance(result["deliverable_id"], str)
        assert isinstance(result["initiative_name"], str)
        assert isinstance(result["status"], str)
        assert isinstance(result["previous_status"], str)
        assert isinstance(result["sprint_resolved_via"], str)

    def test_error_no_active_mind(self, mock_db):
        result = _update_sprint_status("init", "complete", mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_empty_initiative(self, mock_db, active_mind):
        result = _update_sprint_status("", "complete", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_invalid_status(self, mock_db, active_mind):
        result = _update_sprint_status("init", "invalid_status", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_not_found(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),), None]
        mock_db.fetch_all.return_value = []
        result = _update_sprint_status("ghost", "complete", mock_db, active_mind)
        assert_error_shape(result, "NOT_FOUND")


# ---------------------------------------------------------------------------
# 11. get_current_sprint
# ---------------------------------------------------------------------------

class TestGetCurrentSprintContract:
    """Verify _get_current_sprint response shape."""

    BASE_KEYS = {"current_sprint", "sprint_number", "total_sprints", "quarter_year", "quarter"}
    EXTRA_KEYS_WITH_DATES = {"sprint_ends", "days_remaining"}

    def test_success_has_all_base_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,  # no plan
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert_has_keys(result, self.BASE_KEYS)

    def test_success_has_only_base_keys_without_dates(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,  # no plan
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert set(result.keys()) == self.BASE_KEYS

    def test_with_dates_has_extra_keys(self, mock_db, active_mind):
        today = date.today()
        end_date = (today + timedelta(days=10)).isoformat()
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            ([end_date, (today + timedelta(days=24)).isoformat()],),
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert_has_keys(result, self.BASE_KEYS | self.EXTRA_KEYS_WITH_DATES)

    def test_current_sprint_equals_sprint_number(self, mock_db, active_mind):
        """Both keys must hold the same value for backward compatibility."""
        mock_db.fetch_one.side_effect = [
            (_cadence_row(),),
            None,
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert result["current_sprint"] == result["sprint_number"]

    def test_key_types(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [
            (_cadence_row(sprint=3, spq=6),),
            None,
        ]
        result = _get_current_sprint(mock_db, active_mind)
        assert isinstance(result["sprint_number"], int)
        assert isinstance(result["current_sprint"], int)
        assert isinstance(result["total_sprints"], int)
        assert isinstance(result["quarter_year"], int)
        assert isinstance(result["quarter"], int)

    def test_error_no_active_mind(self, mock_db):
        result = _get_current_sprint(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_no_cadence(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _get_current_sprint(mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 12. start_quarter
# ---------------------------------------------------------------------------

class TestStartQuarterContract:
    """Verify _start_quarter response shape."""

    EXPECTED_KEYS = {"quarter_year", "quarter", "rocks_created", "rock_ids"}

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_key_types(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert isinstance(result["quarter_year"], int)
        assert isinstance(result["quarter"], int)
        assert isinstance(result["rocks_created"], int)
        assert isinstance(result["rock_ids"], list)

    def test_with_rocks_creates_ids(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        r1 = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (r1, "Rock A", "on_track", 0, True)
        result = _start_quarter(2026, 2, mock_db, active_mind, rocks=[{"title": "Rock A"}])
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["rocks_created"] >= 1
        assert isinstance(result["rock_ids"], list)
        assert len(result["rock_ids"]) == result["rocks_created"]

    def test_error_no_active_mind(self, mock_db):
        result = _start_quarter(2026, 1, mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _start_quarter(2026, 1, mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_invalid_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = (_cadence_row(),)
        result = _start_quarter(2026, 5, mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 13. quarterly_pacing
# ---------------------------------------------------------------------------

class TestQuarterlyPacingContract:
    """Verify _quarterly_pacing response shape."""

    EXPECTED_KEYS = {
        "quarter_year", "quarter", "current_sprint",
        "days_remaining", "expected_pct", "rocks", "at_risk_count",
    }
    ROCK_ITEM_KEYS = {"rock_id", "title", "status", "progress_pct", "expected_pct", "pacing"}

    def test_success_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),), None]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind)
        assert_has_keys(result, self.EXPECTED_KEYS)

    def test_success_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),), None]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind)
        assert set(result.keys()) == self.EXPECTED_KEYS

    def test_rock_item_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),), None]
        rid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (rid, "Rock A", "on_track", 50),
        ]
        result = _quarterly_pacing(mock_db, active_mind)
        assert len(result["rocks"]) == 1
        assert_has_keys(result["rocks"][0], self.ROCK_ITEM_KEYS)

    def test_key_types(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),), None]
        mock_db.fetch_all.return_value = []
        result = _quarterly_pacing(mock_db, active_mind)
        assert isinstance(result["quarter_year"], int)
        assert isinstance(result["quarter"], int)
        assert isinstance(result["days_remaining"], int)
        assert isinstance(result["expected_pct"], int)
        assert isinstance(result["rocks"], list)
        assert isinstance(result["at_risk_count"], int)

    def test_error_no_active_mind(self, mock_db):
        result = _quarterly_pacing(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_no_quarter(self, mock_db, active_mind):
        mock_db.fetch_one.return_value = ({},)
        result = _quarterly_pacing(mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_rocks", lambda db: False)
        result = _quarterly_pacing(mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")


# ---------------------------------------------------------------------------
# 14. manage_agenda — "add" action
# ---------------------------------------------------------------------------

class TestManageAgendaContract:
    """Verify _manage_agenda response shape for all actions."""

    ADD_KEYS = {"agenda_id", "title", "status", "action_taken"}
    RESOLVE_KEYS = {"agenda_id", "title", "status", "action_taken"}
    DEFER_KEYS = {"agenda_id", "title", "status", "action_taken"}
    SCHEDULE_KEYS = {"agenda_id", "title", "status", "action_taken", "meeting_date"}

    def test_add_has_all_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (aid, "Budget Review", "proposed")
        result = _manage_agenda("Budget Review", mock_db, active_mind)
        assert_has_keys(result, self.ADD_KEYS)
        assert result["action_taken"] == "added"

    def test_add_has_only_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (aid, "Budget Review", "proposed")
        result = _manage_agenda("Budget Review", mock_db, active_mind)
        assert set(result.keys()) == self.ADD_KEYS

    def test_resolve_has_all_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Budget", "proposed")]
        result = _manage_agenda("budget", mock_db, active_mind, action="resolve")
        assert_has_keys(result, self.RESOLVE_KEYS)
        assert result["action_taken"] == "resolved"

    def test_resolve_has_only_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Budget", "proposed")]
        result = _manage_agenda("budget", mock_db, active_mind, action="resolve")
        assert set(result.keys()) == self.RESOLVE_KEYS

    def test_defer_has_all_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Low Item", "proposed")]
        result = _manage_agenda("low item", mock_db, active_mind, action="defer")
        assert_has_keys(result, self.DEFER_KEYS)
        assert result["action_taken"] == "deferred"

    def test_schedule_has_all_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Q2 Planning", "proposed")]
        result = _manage_agenda(
            "q2 planning", mock_db, active_mind,
            action="schedule", meeting_date="2026-04-15",
        )
        assert_has_keys(result, self.SCHEDULE_KEYS)
        assert result["action_taken"] == "scheduled"

    def test_schedule_has_only_expected_keys(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(aid, "Q2 Planning", "proposed")]
        result = _manage_agenda(
            "q2 planning", mock_db, active_mind,
            action="schedule", meeting_date="2026-04-15",
        )
        assert set(result.keys()) == self.SCHEDULE_KEYS

    def test_key_types_add(self, mock_db, active_mind):
        aid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (aid, "Item", "proposed")
        result = _manage_agenda("Item", mock_db, active_mind)
        assert isinstance(result["agenda_id"], str)
        assert isinstance(result["title"], str)
        assert isinstance(result["status"], str)
        assert isinstance(result["action_taken"], str)

    def test_error_no_active_mind(self, mock_db):
        result = _manage_agenda("Item", mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: False)
        result = _manage_agenda("Item", mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_empty_title(self, mock_db, active_mind):
        result = _manage_agenda("", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_invalid_action(self, mock_db, active_mind):
        result = _manage_agenda("Item", mock_db, active_mind, action="destroy")
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 15. get_agenda
# ---------------------------------------------------------------------------

class TestGetAgendaContract:
    """Verify _get_agenda response shape."""

    ITEM_KEYS = {
        "agenda_id", "title", "description", "status", "priority",
        "meeting_date", "resolved_at", "created_at",
    }

    def test_success_returns_list(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_agenda(mock_db, active_mind)
        assert isinstance(result, list)

    def test_item_has_all_expected_keys(self, mock_db, active_mind):
        now = _dt(21)
        mock_db.fetch_all.return_value = [
            ("id1", "High Priority", "Desc", "proposed", 3, now.date(), None, now),
        ]
        result = _get_agenda(mock_db, active_mind)
        assert len(result) == 1
        assert_has_keys(result[0], self.ITEM_KEYS)

    def test_item_has_only_expected_keys(self, mock_db, active_mind):
        now = _dt(21)
        mock_db.fetch_all.return_value = [
            ("id1", "Item", None, "proposed", 0, None, None, now),
        ]
        result = _get_agenda(mock_db, active_mind)
        assert set(result[0].keys()) == self.ITEM_KEYS

    def test_key_types(self, mock_db, active_mind):
        now = _dt(21)
        mock_db.fetch_all.return_value = [
            ("id1", "Item", "Desc", "proposed", 2, now.date(), now, now),
        ]
        result = _get_agenda(mock_db, active_mind)
        item = result[0]
        assert isinstance(item["agenda_id"], str)
        assert isinstance(item["title"], str)
        assert isinstance(item["status"], str)
        assert isinstance(item["priority"], int)

    def test_error_no_active_mind(self, mock_db):
        result = _get_agenda(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_agenda_items", lambda db: False)
        result = _get_agenda(mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_invalid_status(self, mock_db, active_mind):
        result = _get_agenda(mock_db, active_mind, status="invalid")
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 16. manage_issue
# ---------------------------------------------------------------------------

class TestManageIssueContract:
    """Verify _manage_issue response shape for all actions."""

    ADD_KEYS = {"issue_id", "title", "status", "action_taken"}
    SOLVE_KEYS = {"issue_id", "title", "status", "action_taken"}
    SOLVE_WITH_COMMITMENT_KEYS = {"issue_id", "title", "status", "action_taken", "commitment_id"}
    DEFER_KEYS = {"issue_id", "title", "status", "action_taken"}
    DISCUSS_KEYS = {"issue_id", "title", "status", "action_taken"}

    def test_add_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (iid, "Cash Flow Issue", "identified")
        result = _manage_issue("Cash Flow Issue", mock_db, active_mind)
        assert_has_keys(result, self.ADD_KEYS)
        assert result["action_taken"] == "added"

    def test_add_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (iid, "Issue", "identified")
        result = _manage_issue("Issue", mock_db, active_mind)
        assert set(result.keys()) == self.ADD_KEYS

    def test_solve_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Cash Issue", "discussed")]
        result = _manage_issue(
            "cash", mock_db, active_mind,
            action="solve", resolution="Cut costs",
        )
        assert_has_keys(result, self.SOLVE_KEYS)
        assert result["action_taken"] == "solved"

    def test_solve_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Issue", "discussed")]
        result = _manage_issue(
            "issue", mock_db, active_mind,
            action="solve", resolution="Fixed",
        )
        assert set(result.keys()) == self.SOLVE_KEYS

    def test_solve_with_commitment_has_extra_key(self, mock_db, active_mind, mock_config):
        """When todo_text is provided and config exists, solve adds commitment_id."""
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mem_id = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Staffing", "identified")]
        with patch("coppermind_cmo.tools.memories.store_memory_core") as mock_store:
            mock_store.return_value = {"memory_id": mem_id}
            result = _manage_issue(
                "staffing", mock_db, active_mind, config=mock_config,
                action="solve", resolution="Hire contractor",
                todo_text="Find contractor",
            )
        assert_has_keys(result, self.SOLVE_WITH_COMMITMENT_KEYS)
        assert result["commitment_id"] == mem_id

    def test_defer_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Low Priority", "identified")]
        result = _manage_issue("low priority", mock_db, active_mind, action="defer")
        assert_has_keys(result, self.DEFER_KEYS)
        assert result["action_taken"] == "deferred"

    def test_defer_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Item", "identified")]
        result = _manage_issue("item", mock_db, active_mind, action="defer")
        assert set(result.keys()) == self.DEFER_KEYS

    def test_discuss_has_all_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Team Alignment", "identified")]
        result = _manage_issue("team", mock_db, active_mind, action="discuss")
        assert_has_keys(result, self.DISCUSS_KEYS)
        assert result["action_taken"] == "discussed"

    def test_discuss_has_only_expected_keys(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Topic", "identified")]
        result = _manage_issue("topic", mock_db, active_mind, action="discuss")
        assert set(result.keys()) == self.DISCUSS_KEYS

    def test_key_types_add(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.execute_returning.return_value = (iid, "Issue", "identified")
        result = _manage_issue("Issue", mock_db, active_mind)
        assert isinstance(result["issue_id"], str)
        assert isinstance(result["title"], str)
        assert isinstance(result["status"], str)
        assert isinstance(result["action_taken"], str)

    def test_error_no_active_mind(self, mock_db):
        result = _manage_issue("Issue", mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: False)
        result = _manage_issue("Issue", mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_empty_title(self, mock_db, active_mind):
        result = _manage_issue("", mock_db, active_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_invalid_action(self, mock_db, active_mind):
        result = _manage_issue("Issue", mock_db, active_mind, action="destroy")
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_solve_without_resolution(self, mock_db, active_mind):
        mock_db.fetch_one.side_effect = [(_cadence_row(),)]
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [(iid, "Issue", "identified")]
        result = _manage_issue("issue", mock_db, active_mind, action="solve")
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 17. get_issues
# ---------------------------------------------------------------------------

class TestGetIssuesContract:
    """Verify _get_issues response shape."""

    ITEM_KEYS = {
        "issue_id", "title", "description", "raised_by", "priority",
        "status", "resolution", "commitment_id", "source_agenda_id",
        "time_discussed_minutes", "quarter_year", "quarter",
        "created_at", "resolved_at",
    }

    def test_success_returns_list(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        result = _get_issues(mock_db, active_mind)
        assert isinstance(result, list)

    def test_item_has_all_expected_keys(self, mock_db, active_mind):
        now = _dt(21)
        iid = str(uuid.uuid4())
        cid = str(uuid.uuid4())
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (iid, "Issue Title", "Description", "Alice", 2, "solved",
             "We fixed it", cid, aid, 15, 2026, 1, now, now),
        ]
        result = _get_issues(mock_db, active_mind)
        assert len(result) == 1
        assert_has_keys(result[0], self.ITEM_KEYS)

    def test_item_has_only_expected_keys(self, mock_db, active_mind):
        now = _dt(21)
        iid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (iid, "Issue", None, None, 0, "identified",
             None, None, None, None, 2026, 1, now, None),
        ]
        result = _get_issues(mock_db, active_mind)
        assert set(result[0].keys()) == self.ITEM_KEYS

    def test_key_types(self, mock_db, active_mind):
        now = _dt(21)
        iid = str(uuid.uuid4())
        cid = str(uuid.uuid4())
        aid = str(uuid.uuid4())
        mock_db.fetch_all.return_value = [
            (iid, "Issue", "Desc", "Alice", 2, "solved",
             "Fixed", cid, aid, 15, 2026, 1, now, now),
        ]
        result = _get_issues(mock_db, active_mind)
        item = result[0]
        assert isinstance(item["issue_id"], str)
        assert isinstance(item["title"], str)
        assert isinstance(item["priority"], int)
        assert isinstance(item["status"], str)
        assert isinstance(item["commitment_id"], str)
        assert isinstance(item["source_agenda_id"], str)

    def test_error_no_active_mind(self, mock_db):
        result = _get_issues(mock_db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_table_not_ready(self, mock_db, active_mind, monkeypatch):
        monkeypatch.setattr("coppermind_cmo.tools.eos._has_eos_issues", lambda db: False)
        result = _get_issues(mock_db, active_mind)
        assert_error_shape(result, "MIGRATION_REQUIRED")

    def test_error_invalid_status(self, mock_db, active_mind):
        result = _get_issues(mock_db, active_mind, status="invalid")
        assert_error_shape(result, "INVALID_INPUT")
