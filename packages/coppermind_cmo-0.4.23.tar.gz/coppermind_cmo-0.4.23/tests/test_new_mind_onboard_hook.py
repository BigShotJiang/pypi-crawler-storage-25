import io
import json

from coppermind_cmo.hooks import new_mind_onboard
from coppermind_cmo.hooks.new_mind_onboard import build_hook_output


# --- Positive cases: new mind detected ---

def test_detects_new_mind_from_switch_client():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {"client_name": "Acme Corp", "create_new": True},
        json.dumps({"mind_id": "abc-123", "name": "Acme Corp", "slug": "acme-corp", "is_new": True, "memory_count": 0}),
    )
    assert result is not None
    ctx = result["hookSpecificOutput"]["additionalContext"]
    assert "AUTO-ONBOARD" in ctx
    assert "Acme Corp" in ctx
    assert "abc-123" in ctx
    assert "Step 1" in ctx or "Step 2" in ctx


def test_context_says_skip_step_1():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Test Client", "slug": "test-client", "is_new": True, "memory_count": 0}),
    )
    assert result is not None
    ctx = result["hookSpecificOutput"]["additionalContext"]
    assert "skip step 1" in ctx.lower()


def test_hook_event_name_is_post_tool_use():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0}),
    )
    assert result is not None
    assert result["hookSpecificOutput"]["hookEventName"] == "PostToolUse"


def test_includes_onboard_skill_reference():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0}),
    )
    assert result is not None
    ctx = result["hookSpecificOutput"]["additionalContext"]
    assert "/cmo-onboard-client" in ctx


# --- Negative cases: no trigger ---

def test_ignores_existing_mind_switch():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {"client_name": "Acme Corp"},
        json.dumps({"mind_id": "abc-123", "name": "Acme Corp", "slug": "acme-corp", "is_new": False, "memory_count": 42}),
    )
    assert result is None


def test_ignores_non_switch_client_tools():
    result = build_hook_output(
        "mcp__coppermind_cmo__store_memory",
        {"content": "Some note"},
        json.dumps({"id": "mem-123", "status": "stored"}),
    )
    assert result is None


def test_ignores_non_mcp_tools():
    result = build_hook_output(
        "Bash",
        {},
        "some output",
    )
    assert result is None


def test_ignores_unparseable_output():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        "this is not json",
    )
    assert result is None


def test_ignores_empty_output():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        "",
    )
    assert result is None


def test_ignores_is_new_false_string():
    """is_new must be boolean True, not truthy string."""
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": "true", "memory_count": 0}),
    )
    assert result is None


def test_ignores_missing_is_new():
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "memory_count": 0}),
    )
    assert result is None


# --- MCP content wrapper format ---

def test_handles_mcp_text_wrapper():
    """MCP sometimes wraps output as [{"type": "text", "text": "..."}]."""
    inner = json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0})
    wrapped = json.dumps([{"type": "text", "text": inner}])
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        wrapped,
    )
    assert result is not None
    assert "Acme" in result["hookSpecificOutput"]["additionalContext"]


def test_handles_mcp_wrapper_with_non_json_text():
    """MCP text wrapper with non-JSON text should not crash."""
    wrapped = json.dumps([{"type": "text", "text": "not json inside"}])
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client",
        {},
        wrapped,
    )
    assert result is None


# --- Tool name matching ---

def test_matches_tool_name_with_different_server_prefix():
    """Should match any tool ending in switch_client."""
    result = build_hook_output(
        "mcp__some_other_server__switch_client",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0}),
    )
    assert result is not None


def test_does_not_match_partial_tool_name():
    """switch_client_v2 should not match."""
    result = build_hook_output(
        "mcp__coppermind_cmo__switch_client_v2",
        {},
        json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0}),
    )
    assert result is None


# --- Main entrypoint ---

def test_main_prints_hook_payload_for_new_mind(monkeypatch, capsys):
    event = {
        "tool_name": "mcp__coppermind_cmo__switch_client",
        "tool_input": {"client_name": "Acme", "create_new": True},
        "tool_output": json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": True, "memory_count": 0}),
    }
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps(event)))

    exit_code = new_mind_onboard.main()

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    assert output["hookSpecificOutput"]["hookEventName"] == "PostToolUse"
    assert "Acme" in output["hookSpecificOutput"]["additionalContext"]


def test_main_no_output_for_existing_mind(monkeypatch, capsys):
    event = {
        "tool_name": "mcp__coppermind_cmo__switch_client",
        "tool_input": {"client_name": "Acme"},
        "tool_output": json.dumps({"mind_id": "abc-123", "name": "Acme", "slug": "acme", "is_new": False, "memory_count": 42}),
    }
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps(event)))

    exit_code = new_mind_onboard.main()

    assert exit_code == 0
    assert capsys.readouterr().out == ""


def test_main_ignores_invalid_json(monkeypatch, capsys):
    monkeypatch.setattr("sys.stdin", io.StringIO("{bad json"))

    exit_code = new_mind_onboard.main()

    assert exit_code == 0
    assert capsys.readouterr().out == ""


def test_main_handles_missing_fields(monkeypatch, capsys):
    event = {"tool_name": "mcp__coppermind_cmo__switch_client"}
    monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps(event)))

    exit_code = new_mind_onboard.main()

    assert exit_code == 0
    assert capsys.readouterr().out == ""
