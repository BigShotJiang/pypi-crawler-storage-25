"""Tests for update_coppermind tool."""

import subprocess
from unittest.mock import patch, MagicMock

import pytest

from coppermind_cmo.tools.update import (
    _check_pypi_version,
    _try_uv_upgrade,
    _try_pip_upgrade,
)


class TestCheckPypiVersion:
    def test_check_pypi_version_returns_string(self):
        """Mock httpx.get to return a fake PyPI response. Verify it returns the version string."""
        # Make pip index fail so we fall through to httpx
        mock_pip_result = MagicMock()
        mock_pip_result.returncode = 1
        mock_pip_result.stdout = ""

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"info": {"version": "1.2.3"}}

        with patch("subprocess.run", return_value=mock_pip_result):
            with patch("httpx.get", return_value=mock_response) as mock_get:
                result = _check_pypi_version()

        assert result == "1.2.3"
        mock_get.assert_called_once()


class TestUvUpgrade:
    def test_uv_upgrade_success(self):
        """Mock subprocess.run to simulate successful uv upgrade. Verify return dict has status='updated'."""
        mock_uv_result = MagicMock()
        mock_uv_result.returncode = 0
        mock_uv_result.stdout = "Updated coppermind-cmo v0.4.22 -> v0.5.0"

        mock_version_result = MagicMock()
        mock_version_result.returncode = 0
        mock_version_result.stdout = "0.5.0\n"

        def side_effect(cmd, **kwargs):
            if cmd[0] == "uv":
                return mock_uv_result
            # _get_installed_version subprocess call
            return mock_version_result

        with patch("subprocess.run", side_effect=side_effect):
            result = _try_uv_upgrade()

        assert result is not None
        assert result["status"] == "updated"
        assert result["new_version"] == "0.5.0"

    def test_uv_nothing_to_upgrade_tries_force(self):
        """Mock subprocess.run: first call returns 'Nothing to upgrade', second call (--force) succeeds."""
        call_count = 0

        def side_effect(cmd, **kwargs):
            nonlocal call_count
            call_count += 1
            mock = MagicMock()
            mock.returncode = 0

            if call_count == 1:
                # First call: uv tool upgrade
                mock.stdout = "Nothing to upgrade"
                return mock
            elif call_count == 2:
                # Second call: uv tool install --force --upgrade
                mock.stdout = "Installed coppermind-cmo v0.5.0"
                return mock
            else:
                # Third call: _get_installed_version
                mock.stdout = "0.5.0\n"
                return mock

        with patch("subprocess.run", side_effect=side_effect):
            with patch("coppermind_cmo.tools.update.__version__", "0.4.22"):
                result = _try_uv_upgrade()

        assert call_count >= 2, "Should have called subprocess.run at least twice (upgrade + force install)"
        assert result is not None
        assert result["status"] == "updated"

    def test_uv_not_found_falls_to_pip(self):
        """Mock subprocess.run to raise FileNotFoundError for uv, then succeed for pip."""
        def uv_side_effect(cmd, **kwargs):
            if cmd[0] == "uv":
                raise FileNotFoundError("uv not found")
            mock = MagicMock()
            mock.returncode = 0
            mock.stdout = "0.5.0\n"
            return mock

        # uv should return None (not found)
        with patch("subprocess.run", side_effect=uv_side_effect):
            uv_result = _try_uv_upgrade()

        assert uv_result is None  # uv failed, should return None

        # Now pip should succeed
        def pip_side_effect(cmd, **kwargs):
            mock = MagicMock()
            mock.returncode = 0
            mock.stdout = "0.5.0\n"
            return mock

        with patch("subprocess.run", side_effect=pip_side_effect):
            pip_result = _try_pip_upgrade()

        assert pip_result is not None
        assert pip_result["status"] == "updated"

    def test_timeout_returns_error(self):
        """Mock subprocess.run to raise TimeoutExpired. Verify status='error' with helpful message."""
        def side_effect(cmd, **kwargs):
            raise subprocess.TimeoutExpired(cmd=cmd, timeout=120)

        with patch("subprocess.run", side_effect=side_effect):
            result = _try_uv_upgrade()

        assert result is not None
        assert result["status"] == "error"
        assert "timed out" in result["message"].lower()
        assert "manually" in result["message"].lower()


class TestUpdateCoppermind:
    def test_already_latest_version(self):
        """Mock _check_pypi_version to return same as __version__. Verify status='current'."""
        with patch("coppermind_cmo.tools.update._check_pypi_version", return_value="0.4.22"):
            with patch("coppermind_cmo.tools.update.__version__", "0.4.22"):
                # Import the inner function by registering on a mock MCP
                from coppermind_cmo.tools.update import register
                mock_mcp = MagicMock()
                registered_funcs = {}

                def capture_tool():
                    def decorator(func):
                        registered_funcs[func.__name__] = func
                        return func
                    return decorator

                mock_mcp.tool = capture_tool
                register(mock_mcp)

                result = registered_funcs["update_coppermind"]()

        assert result["status"] == "current"
        assert "already the latest" in result["message"]

    def test_all_methods_fail(self):
        """Mock everything to fail. Verify status='error' with manual instruction."""
        with patch("coppermind_cmo.tools.update._check_pypi_version", return_value="999.0.0"):
            with patch("coppermind_cmo.tools.update._try_uv_upgrade", return_value=None):
                with patch("coppermind_cmo.tools.update._try_pip_upgrade", return_value=None):
                    from coppermind_cmo.tools.update import register
                    mock_mcp = MagicMock()
                    registered_funcs = {}

                    def capture_tool():
                        def decorator(func):
                            registered_funcs[func.__name__] = func
                            return func
                        return decorator

                    mock_mcp.tool = capture_tool
                    register(mock_mcp)

                    result = registered_funcs["update_coppermind"]()

        assert result["status"] == "error"
        assert "uv tool upgrade" in result["message"]
