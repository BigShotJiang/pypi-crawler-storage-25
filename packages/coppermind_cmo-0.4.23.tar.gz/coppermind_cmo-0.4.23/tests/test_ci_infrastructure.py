"""Tests for cross-platform CI infrastructure.

Tests the --skip-verify flag, CI non-interactive mode, and release gate.
These tests run locally without GitHub Actions.
"""

import os
import subprocess
import sys

import pytest

# Project root — all paths relative to this
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


class TestInstallShSkipVerify:
    """Test install.sh --skip-verify and CI=true behavior."""

    @pytest.fixture
    def install_sh(self):
        return os.path.join(PROJECT_ROOT, "installer", "unix", "install.sh")

    def test_skip_verify_accepted_as_argument(self, install_sh):
        """install.sh accepts --skip-verify without error in the arg parser."""
        result = subprocess.run(
            ["bash", install_sh, "--skip-verify", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "Usage:" in result.stdout

    def test_skip_verify_flag_in_source(self, install_sh):
        """install.sh source contains --skip-verify handling."""
        with open(install_sh) as f:
            content = f.read()
        assert "--skip-verify" in content
        assert "SKIP_VERIFY" in content

    def test_noninteractive_mode_in_source(self, install_sh):
        """install.sh sets NONINTERACTIVE from CI env var."""
        with open(install_sh) as f:
            content = f.read()
        assert "NONINTERACTIVE" in content
        assert 'CI' in content


class TestInstallPs1SkipVerify:
    """Test install.ps1 -SkipVerify and CI behavior."""

    @pytest.fixture
    def install_ps1(self):
        return os.path.join(PROJECT_ROOT, "installer", "windows", "install.ps1")

    def test_skip_verify_param_exists(self, install_ps1):
        """install.ps1 has a -SkipVerify parameter."""
        with open(install_ps1) as f:
            content = f.read()
        assert "[switch]$SkipVerify" in content

    def test_noninteractive_variable_exists(self, install_ps1):
        """install.ps1 sets $NonInteractive from CI env var."""
        with open(install_ps1) as f:
            content = f.read()
        assert "$NonInteractive" in content
        assert '$env:CI' in content

    def test_read_host_guarded_by_noninteractive(self, install_ps1):
        """All Read-Host calls have NonInteractive guards nearby."""
        with open(install_ps1) as f:
            lines = f.readlines()
        read_host_lines = [
            i for i, line in enumerate(lines) if "Read-Host" in line
        ]
        # Should have at least one Read-Host still (for non-CI mode)
        assert len(read_host_lines) > 0
        # The NonInteractive guard should appear in the file
        noninteractive_lines = [
            i for i, line in enumerate(lines) if "$NonInteractive" in line
        ]
        assert len(noninteractive_lines) >= 2  # At least the definition + usage


class TestReleaseGate:
    """Test the check_ci_status function in release.sh."""

    @pytest.fixture
    def release_sh(self):
        return os.path.join(PROJECT_ROOT, "scripts", "release.sh")

    def test_check_ci_status_function_exists(self, release_sh):
        """release.sh defines the check_ci_status function."""
        with open(release_sh) as f:
            content = f.read()
        assert "check_ci_status()" in content

    def test_check_ci_status_called_in_both_paths(self, release_sh):
        """check_ci_status is called in both RC and stable paths."""
        with open(release_sh) as f:
            content = f.read()
        # definition (1) + RC call (1) + stable call (1) = at least 3
        assert content.count("check_ci_status") >= 3

    def test_release_gate_checks_workflow_names(self, release_sh):
        """Release gate filters on the correct workflow names."""
        with open(release_sh) as f:
            content = f.read()
        assert '"Installer Smoke Test"' in content
        assert '"Integration Tests"' in content
        assert '"Benchmark & Tests"' in content

    def test_release_gate_blocks_on_fail(self, release_sh):
        """Release gate exits 1 when CI status is 'fail'."""
        with open(release_sh) as f:
            content = f.read()
        assert "CI FAILED" in content

    def test_release_sh_valid_syntax(self, release_sh):
        """release.sh has valid bash syntax."""
        result = subprocess.run(
            ["bash", "-n", release_sh],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0, f"Syntax error: {result.stderr}"


class TestWorkflowYAML:
    """Validate workflow YAML files are syntactically correct."""

    @pytest.fixture(params=["install-test.yml", "integration-test.yml"])
    def workflow_path(self, request):
        return os.path.join(
            PROJECT_ROOT, ".github", "workflows", request.param
        )

    def test_yaml_is_valid(self, workflow_path):
        """Workflow YAML parses without error."""
        import yaml

        with open(workflow_path) as f:
            data = yaml.safe_load(f)
        assert "name" in data
        # YAML parses `on:` as boolean True, not string "on"
        assert True in data or "on" in data
        assert "jobs" in data

    def test_workflow_has_checkout_step(self, workflow_path):
        """Every job starts with actions/checkout."""
        import yaml

        with open(workflow_path) as f:
            data = yaml.safe_load(f)
        for job_name, job in data["jobs"].items():
            steps = job.get("steps", [])
            checkout_steps = [
                s for s in steps if s.get("uses", "").startswith("actions/checkout")
            ]
            assert checkout_steps, f"Job {job_name} missing checkout step"


class TestMCPProtocolTestFile:
    """Verify the MCP protocol test file is properly structured."""

    def test_file_exists(self):
        """MCP protocol test file exists."""
        path = os.path.join(
            PROJECT_ROOT, "tests", "integration", "test_mcp_protocol.py"
        )
        assert os.path.exists(path)

    def test_skips_without_api_key(self):
        """MCP protocol tests skip gracefully without COPPERMIND_API_KEY."""
        test_path = os.path.join(
            PROJECT_ROOT, "tests", "integration", "test_mcp_protocol.py"
        )
        result = subprocess.run(
            [sys.executable, "-m", "pytest", test_path, "-v", "--tb=short"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT,
            env={k: v for k, v in os.environ.items() if k != "COPPERMIND_API_KEY"},
            timeout=30,
        )
        assert "skipped" in result.stdout
        assert result.returncode == 0
