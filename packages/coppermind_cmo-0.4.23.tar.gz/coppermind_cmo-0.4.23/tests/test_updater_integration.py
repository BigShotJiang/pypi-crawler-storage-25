"""Integration tests for the auto-update system.

Tests the real code paths without mocking internal functions — only
external dependencies (HTTP, subprocess, importlib.metadata) are mocked.
"""

import threading
import time
from unittest.mock import patch, MagicMock

import pytest

import coppermind_cmo.updater as updater_mod
import coppermind_cmo.background as background_mod


# ---------------------------------------------------------------------------
# Fixture: reset all update + notification state between tests
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _clean_updater_state():
    """Reset updater state and notification provider list."""
    updater_mod._update_state.update({
        "status": "idle",
        "current_version": "",
        "latest_version": "",
        "error": None,
        "notified": False,
    })
    yield
    updater_mod._update_state.update({
        "status": "idle",
        "current_version": "",
        "latest_version": "",
        "error": None,
        "notified": False,
    })


# ---------------------------------------------------------------------------
# Integration: config fetch → updater → notification in tool response
# ---------------------------------------------------------------------------
class TestConfigToNotificationFlow:
    """End-to-end: gateway returns latest_version → updater runs → notification
    appears in a tool response via attach_notifications."""

    def test_outdated_version_produces_notification(self):
        """Full flow: fetch config, run updater, check notification surfaces."""
        # 1. Fetch server config with a newer latest_version
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "min_client_version": "0.2.0",
            "latest_version": "0.5.0",
            "upgrade_urgency": "recommended",
            "upgrade_message": "Run: coppermind-update",
            "changelog_url": "",
            "prompts": {},
        }

        mock_config = MagicMock()
        mock_config.gateway_url = "https://api.coppermind.dev"
        mock_config.api_key = "test-key"

        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

        with patch("httpx.get", return_value=mock_response):
            server_cfg = config_mod.fetch_server_config(mock_config)

        assert server_cfg.latest_version == "0.5.0"

        # 2. Run the updater synchronously (simulating what server startup does)
        mock_uv_result = MagicMock()
        mock_uv_result.returncode = 0
        mock_uv_result.stdout = ""
        mock_uv_result.stderr = ""

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.5"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/bin/uv"),
            patch("coppermind_cmo.updater._find_pipx", return_value=None),
            patch("subprocess.run", return_value=mock_uv_result),
        ):
            updater_mod._do_upgrade(server_cfg.latest_version, server_cfg.upgrade_urgency)

        state = updater_mod.get_update_state()
        assert state["status"] == "ready"
        assert state["latest_version"] == "0.5.0"

        # 3. Simulate a tool response going through attach_notifications
        tool_result = {"status": "ok", "data": "some tool output"}
        returned = background_mod.attach_notifications(
            tool_result, session_id="test", customer_id="cust1", db="fake_db"
        )

        # The update notification should appear in the result
        assert "notifications" in returned
        notifs = returned["notifications"]
        update_notifs = [n for n in notifs if n.get("type") == "update_available"]
        assert len(update_notifs) == 1
        assert "0.5.0" in update_notifs[0]["message"]
        assert "Restart" in update_notifs[0]["message"]

    def test_current_version_produces_no_notification(self):
        """When already up to date, no notification surfaces."""
        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.5.0"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/bin/uv"),
        ):
            updater_mod._do_upgrade("0.5.0", "none")

        tool_result = {"status": "ok"}
        returned = background_mod.attach_notifications(
            tool_result, session_id="test", customer_id="cust1", db="fake_db"
        )

        update_notifs = [
            n for n in returned.get("notifications", [])
            if n.get("type") in ("update_available", "update_failed")
        ]
        assert len(update_notifs) == 0


# ---------------------------------------------------------------------------
# Integration: hard gate blocks startup
# ---------------------------------------------------------------------------
class TestHardGateIntegration:
    """Server refuses to start when below min_client_version."""

    def test_outdated_server_exits(self):
        """_run_startup_checks exits when version is below minimum."""
        from coppermind_cmo.server import _run_startup_checks

        mock_config = MagicMock()
        mock_config.api_key = "test-key"
        mock_config.gateway_url = "https://api.test"
        mock_config.pg_host = "localhost"
        mock_config.pg_port = 5432
        mock_config.pg_db = "test"
        mock_config.pg_user = "user"
        mock_config.pg_password = "pass"
        mock_config.customer_id = ""
        mock_config.llm_provider = "none"
        mock_config.embedding_provider = "none"
        mock_config.embedding_dims = 512

        # Mock the gateway config to require a version higher than installed
        mock_server_cfg = MagicMock()
        mock_server_cfg.fetched = True
        mock_server_cfg.min_client_version = "99.0.0"  # impossibly high
        mock_server_cfg.latest_version = "99.0.0"
        mock_server_cfg.upgrade_message = "Run: coppermind-update"

        mock_db = MagicMock()
        mock_db.fetch_one.return_value = (1,)

        with (
            patch("coppermind_cmo.server.get_config", return_value=mock_config),
            patch("coppermind_cmo.server.get_db", return_value=mock_db),
            patch("coppermind_cmo.server.get_session_id", return_value="test"),
            patch("coppermind_cmo.server.embedding_client") as mock_embed,
            patch("coppermind_cmo.server.fetch_server_config", return_value=mock_server_cfg),
            patch("coppermind_cmo.server._provision_from_gateway"),
            patch("coppermind_cmo.server._install_statusline"),
            patch("coppermind_cmo.server._install_skills"),
            patch("coppermind_cmo.server._install_commands"),
            patch("coppermind_cmo.server._install_hooks"),
            patch("coppermind_cmo.server._start_watcher"),
            patch("coppermind_cmo.background.recover_orphaned_jobs"),
        ):
            mock_embed.check_health.return_value = True

            with pytest.raises(SystemExit) as exc_info:
                _run_startup_checks()

            assert exc_info.value.code == 1


# ---------------------------------------------------------------------------
# Integration: notification only fires once per session across tool calls
# ---------------------------------------------------------------------------
class TestNotificationOncePerSession:
    """The update notification surfaces exactly once, then never again."""

    def test_notification_appears_once_across_multiple_tool_calls(self):
        """Simulates multiple tool calls — notification only in the first."""
        # Set up: update is ready
        updater_mod._update_state.update({
            "status": "ready",
            "current_version": "0.4.0",
            "latest_version": "0.5.0",
            "notified": False,
        })

        # First tool call
        result1 = {"status": "ok"}
        background_mod.attach_notifications(result1, session_id="s1", customer_id="c1", db="db")
        update_notifs_1 = [n for n in result1.get("notifications", []) if n.get("type") == "update_available"]
        assert len(update_notifs_1) == 1

        # Second tool call — should NOT get the notification again
        result2 = {"status": "ok"}
        background_mod.attach_notifications(result2, session_id="s1", customer_id="c1", db="db")
        update_notifs_2 = [n for n in result2.get("notifications", []) if n.get("type") == "update_available"]
        assert len(update_notifs_2) == 0

        # Third tool call — still empty
        result3 = {"status": "ok"}
        background_mod.attach_notifications(result3, session_id="s1", customer_id="c1", db="db")
        update_notifs_3 = [n for n in result3.get("notifications", []) if n.get("type") == "update_available"]
        assert len(update_notifs_3) == 0


# ---------------------------------------------------------------------------
# Integration: check_and_update runs asynchronously
# ---------------------------------------------------------------------------
class TestAsyncUpdateFlow:
    """The updater runs in a background thread and doesn't block."""

    def test_check_and_update_completes_in_background(self):
        """Spawned thread completes and updates state without blocking caller."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/bin/uv"),
            patch("coppermind_cmo.updater._find_pipx", return_value=None),
            patch("subprocess.run", return_value=mock_result),
        ):
            # This should return immediately
            start = time.monotonic()
            updater_mod.check_and_update("0.5.0", "recommended")
            elapsed = time.monotonic() - start
            assert elapsed < 1.0, "check_and_update should return immediately"

            # Wait for the background thread to finish
            time.sleep(0.5)

        state = updater_mod.get_update_state()
        assert state["status"] == "ready"
        assert state["latest_version"] == "0.5.0"


# ---------------------------------------------------------------------------
# Integration: failed update notification includes actionable message
# ---------------------------------------------------------------------------
class TestFailedUpdateNotification:
    """When auto-update fails, the notification tells the user what to do."""

    def test_failed_update_tells_user_to_run_manual_command(self):
        """Failed update notification includes 'coppermind-update' command."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "error: no matching distribution"

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/bin/uv"),
            patch("coppermind_cmo.updater._find_pipx", return_value=None),
            patch("subprocess.run", return_value=mock_result),
        ):
            updater_mod._do_upgrade("0.5.0", "none")

        result = {"status": "ok"}
        background_mod.attach_notifications(result, session_id="s1", customer_id="c1", db="db")

        failed_notifs = [n for n in result.get("notifications", []) if n.get("type") == "update_failed"]
        assert len(failed_notifs) == 1
        assert "coppermind-update" in failed_notifs[0]["message"]


# ---------------------------------------------------------------------------
# Integration: coppermind-update CLI
# ---------------------------------------------------------------------------
class TestUpdateCli:
    """The coppermind-update CLI entry point works end-to-end."""

    def test_cli_reports_already_up_to_date(self, capsys):
        """When uv upgrade reports same version, CLI says up to date."""
        mock_result = MagicMock()
        mock_result.returncode = 0

        mock_ver_check = MagicMock()
        mock_ver_check.returncode = 0
        mock_ver_check.stdout = "0.4.5\n"

        with (
            patch("shutil.which", return_value="/usr/bin/uv"),
            patch("importlib.metadata.version", return_value="0.4.5"),
            patch("subprocess.run", side_effect=[mock_result, mock_ver_check]),
        ):
            from coppermind_cmo.update_cli import main
            main()

        output = capsys.readouterr().out
        assert "0.4.5" in output
        assert "up to date" in output.lower()

    def test_cli_reports_update_applied(self, capsys):
        """When version changes after upgrade, CLI reports the new version."""
        mock_result = MagicMock()
        mock_result.returncode = 0

        mock_ver_check = MagicMock()
        mock_ver_check.returncode = 0
        mock_ver_check.stdout = "0.5.0\n"

        with (
            patch("shutil.which", return_value="/usr/bin/uv"),
            patch("importlib.metadata.version", return_value="0.4.5"),
            patch("subprocess.run", side_effect=[mock_result, mock_ver_check]),
        ):
            from coppermind_cmo.update_cli import main
            main()

        output = capsys.readouterr().out
        assert "0.4.5" in output
        assert "0.5.0" in output
        assert "Restart" in output

    def test_cli_exits_when_no_uv(self):
        """When uv is not found, CLI exits with error."""
        with (
            patch("coppermind_cmo.update_cli._find_uv", return_value=None),
            patch("coppermind_cmo.update_cli._find_pipx", return_value=None),
            patch("importlib.metadata.version", return_value="0.4.5"),
        ):
            from coppermind_cmo.update_cli import main
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 1
