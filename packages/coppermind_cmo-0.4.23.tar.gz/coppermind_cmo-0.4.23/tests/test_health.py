"""Tests for health diagnostic tools."""

import pytest
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.health import (
    _check_db_health,
    _check_gateway_health,
    _check_health,
    CONNECTOR_RECOVERY,
)


class TestCheckDbHealth:
    def test_healthy(self):
        db = MagicMock()
        db.fetch_one.return_value = (1,)
        result = _check_db_health(db)
        assert result["status"] == "healthy"

    def test_disconnected(self):
        db = MagicMock()
        db.fetch_one.side_effect = Exception("connection refused")
        result = _check_db_health(db)
        assert result["status"] == "disconnected"
        assert "connection refused" in result["message"]

    def test_degraded(self):
        db = MagicMock()
        db.fetch_one.return_value = (None,)
        result = _check_db_health(db)
        assert result["status"] == "degraded"


class TestCheckHealth:
    def test_all_healthy(self):
        db = MagicMock()
        db.fetch_one.return_value = (1,)
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"

        with patch("coppermind_cmo.tools.health._check_gateway_health", return_value={"status": "healthy", "message": "OK"}):
            with patch("coppermind_cmo.tools.health._check_embedding_health", return_value={"status": "healthy", "message": "OK"}):
                result = _check_health(db, config)

        assert result["status"] == "healthy"
        assert "All Coppermind services healthy" in result["message"]
        assert "connector_recovery_guide" in result

    def test_db_disconnected(self):
        db = MagicMock()
        db.fetch_one.side_effect = Exception("connection refused")
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test"

        with patch("coppermind_cmo.tools.health._check_gateway_health", return_value={"status": "healthy", "message": "OK"}):
            with patch("coppermind_cmo.tools.health._check_embedding_health", return_value={"status": "healthy", "message": "OK"}):
                result = _check_health(db, config)

        assert result["status"] == "disconnected"
        assert len(result["recovery_steps"]) > 0
        assert "Database" in result["recovery_steps"][0]

    def test_gateway_degraded(self):
        db = MagicMock()
        db.fetch_one.return_value = (1,)
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test"

        with patch("coppermind_cmo.tools.health._check_gateway_health", return_value={"status": "degraded", "message": "status 502"}):
            with patch("coppermind_cmo.tools.health._check_embedding_health", return_value={"status": "healthy", "message": "OK"}):
                result = _check_health(db, config)

        assert result["status"] == "degraded"
        assert len(result["recovery_steps"]) > 0
        assert "Gateway" in result["recovery_steps"][0]

    def test_embedding_disconnected(self):
        db = MagicMock()
        db.fetch_one.return_value = (1,)
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test"

        with patch("coppermind_cmo.tools.health._check_gateway_health", return_value={"status": "healthy", "message": "OK"}):
            with patch("coppermind_cmo.tools.health._check_embedding_health", return_value={"status": "disconnected", "message": "unreachable"}):
                result = _check_health(db, config)

        assert result["status"] == "disconnected"
        assert any("Embedding" in s for s in result["recovery_steps"])

    def test_includes_connector_recovery_guide(self):
        db = MagicMock()
        db.fetch_one.return_value = (1,)
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test"

        with patch("coppermind_cmo.tools.health._check_gateway_health", return_value={"status": "healthy", "message": "OK"}):
            with patch("coppermind_cmo.tools.health._check_embedding_health", return_value={"status": "healthy", "message": "OK"}):
                result = _check_health(db, config)

        guide = result["connector_recovery_guide"]
        assert "google_calendar" in guide
        assert "granola" in guide
        assert "slack" in guide
        assert len(guide["google_calendar"]["recovery"]) > 0


class TestConnectorRecovery:
    def test_all_entries_have_required_fields(self):
        for key, entry in CONNECTOR_RECOVERY.items():
            assert "name" in entry, f"Missing 'name' in {key}"
            assert "probe_hint" in entry, f"Missing 'probe_hint' in {key}"
            assert "recovery" in entry, f"Missing 'recovery' in {key}"
            assert isinstance(entry["recovery"], list), f"'recovery' must be a list in {key}"
            assert len(entry["recovery"]) > 0, f"'recovery' must not be empty in {key}"

    def test_known_connectors_present(self):
        expected = {"google_calendar", "google_drive", "granola", "slack"}
        assert expected.issubset(set(CONNECTOR_RECOVERY.keys()))
