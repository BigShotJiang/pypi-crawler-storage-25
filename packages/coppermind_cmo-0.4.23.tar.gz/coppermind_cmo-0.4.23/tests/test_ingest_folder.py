"""Tests for folder ingestion — file collection, text extraction, dedup, mind resolution."""

import hashlib
import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.ingest_folder import (
    _extract_text_plain,
    _file_sha256,
    _is_hidden,
    _check_file_already_ingested,
    _record_file_hash,
    collect_files,
    resolve_mind,
    safe_extract,
)


class TestExtractTextPlain:
    def test_extract_text_plain(self, tmp_path):
        """Create a .txt file, verify content returned."""
        f = tmp_path / "hello.txt"
        f.write_text("Hello, world!", encoding="utf-8")
        result = _extract_text_plain(f)
        assert result == "Hello, world!"

    def test_extract_text_plain_md(self, tmp_path):
        """Create a .md file, verify content returned."""
        f = tmp_path / "readme.md"
        f.write_text("# Heading\n\nSome markdown content.", encoding="utf-8")
        result = _extract_text_plain(f)
        assert "# Heading" in result
        assert "Some markdown content." in result


class TestIsHidden:
    def test_is_hidden_dotfile(self):
        """.hidden returns True."""
        assert _is_hidden(".hidden") is True

    def test_is_hidden_word_temp(self):
        """~$document.docx returns True."""
        assert _is_hidden("~$document.docx") is True

    def test_is_hidden_normal(self):
        """report.txt returns False."""
        assert _is_hidden("report.txt") is False

    def test_is_hidden_dotdir(self):
        """.git returns True."""
        assert _is_hidden(".git") is True


class TestFileSha256:
    def test_file_sha256(self, tmp_path):
        """Write known content, verify hash."""
        f = tmp_path / "test.txt"
        content = b"deterministic content"
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert _file_sha256(f) == expected

    def test_file_sha256_deterministic(self, tmp_path):
        """Same content = same hash."""
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        content = b"identical"
        f1.write_bytes(content)
        f2.write_bytes(content)
        assert _file_sha256(f1) == _file_sha256(f2)


class TestCollectFiles:
    def test_collect_files_txt_and_md(self, tmp_path):
        """Create tmp folder with .txt, .md, .jpg. Only .txt and .md returned."""
        (tmp_path / "doc.txt").write_text("text")
        (tmp_path / "notes.md").write_text("markdown")
        (tmp_path / "photo.jpg").write_bytes(b"\xff\xd8\xff")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "doc.txt" in names
        assert "notes.md" in names
        assert "photo.jpg" not in names

    def test_collect_files_skips_hidden(self, tmp_path):
        """Create .hidden file, verify not collected."""
        (tmp_path / ".hidden.txt").write_text("secret")
        (tmp_path / "visible.txt").write_text("public")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "visible.txt" in names
        assert ".hidden.txt" not in names

    def test_collect_files_skips_dot_dirs(self, tmp_path):
        """Create .git/ subdir with .txt, verify not collected."""
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "config.txt").write_text("git config")
        (tmp_path / "real.txt").write_text("real file")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "real.txt" in names
        assert "config.txt" not in names

    def test_collect_files_skips_large_files(self, tmp_path):
        """Create a file and mock stat to return large size, verify skipped."""
        large = tmp_path / "huge.txt"
        large.write_text("content")

        # We patch MAX_FILE_SIZE to a tiny value instead of mocking stat
        with patch("coppermind_cmo.ingest_folder.MAX_FILE_SIZE", 1):
            files = collect_files([str(tmp_path)])

        names = {f.name for f in files}
        assert "huge.txt" not in names

    def test_collect_files_not_a_directory(self, tmp_path):
        """Pass a file path, verify skipped with warning."""
        f = tmp_path / "afile.txt"
        f.write_text("not a dir")

        files = collect_files([str(f)])
        assert files == []

    def test_collect_files_skip_dirs(self, tmp_path):
        """Create node_modules/ subdir, verify not traversed."""
        nm = tmp_path / "node_modules"
        nm.mkdir()
        (nm / "package.txt").write_text("module stuff")
        (tmp_path / "app.txt").write_text("application")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "app.txt" in names
        assert "package.txt" not in names

    def test_collect_files_sorted(self, tmp_path):
        """Create files in random order, verify returned sorted."""
        for name in ["charlie.txt", "alpha.txt", "bravo.txt"]:
            (tmp_path / name).write_text(name)

        files = collect_files([str(tmp_path)])
        names = [f.name for f in files]
        assert names == sorted(names)


class TestCheckFileAlreadyIngested:
    def test_check_file_already_ingested_true(self):
        """Mock db returns row, returns True."""
        db = MagicMock()
        db.fetch_one.return_value = ("some-uuid",)
        assert _check_file_already_ingested(db, "mind-1", "abc123") is True

    def test_check_file_already_ingested_false(self):
        """Mock db returns None, returns False."""
        db = MagicMock()
        db.fetch_one.return_value = None
        assert _check_file_already_ingested(db, "mind-1", "abc123") is False

    def test_check_uses_custom_ingest_type(self):
        """The ingest_type parameter is passed to the SQL query."""
        db = MagicMock()
        db.fetch_one.return_value = ("some-uuid",)
        _check_file_already_ingested(db, "mind-1", "abc123", ingest_type="folder_watch")
        sql = db.fetch_one.call_args[0][0]
        params = db.fetch_one.call_args[0][1]
        assert "ingest_type = %s" in sql
        assert params[1] == "folder_watch"


class TestRecordFileHash:
    def test_record_file_hash(self):
        """Verify db.execute called with correct params."""
        db = MagicMock()
        _record_file_hash(db, "mind-1", "/path/to/file.txt", "hash123")

        db.execute.assert_called_once()
        call_args = db.execute.call_args
        # First positional arg is the SQL
        assert "UPDATE ingest_sources" in call_args[0][0]
        # Second positional arg is the params list
        params = call_args[0][1]
        assert json.loads(params[0]) == {"file_hash": "hash123"}
        assert params[1] == "mind-1"
        assert params[2] == "folder_ingest"  # default ingest_type
        assert params[3] == "/path/to/file.txt"

    def test_record_uses_custom_ingest_type(self):
        """The ingest_type parameter is passed to the SQL query."""
        db = MagicMock()
        _record_file_hash(db, "mind-1", "/path/to/file.txt", "hash123", ingest_type="folder_watch")
        params = db.execute.call_args[0][1]
        assert params[2] == "folder_watch"


class TestResolveMind:
    def test_resolve_mind_found(self):
        """Mock db, returns tuple."""
        db = MagicMock()
        db.fetch_one.return_value = ("uuid-abc", "Xscape")
        result = resolve_mind(db, "Xscape")
        assert result == ("uuid-abc", "Xscape")

    def test_resolve_mind_not_found(self):
        """Mock db returns None, returns None."""
        db = MagicMock()
        db.fetch_one.return_value = None
        result = resolve_mind(db, "NoSuchMind")
        assert result is None


class TestExtractTextImportErrors:
    def test_extract_text_docx_import_error(self, tmp_path):
        """Mock docx import missing, verify ImportError raised."""
        from coppermind_cmo.ingest_folder import _extract_text_docx

        f = tmp_path / "doc.docx"
        f.write_bytes(b"fake docx content")

        with patch.dict("sys.modules", {"docx": None}):
            with pytest.raises(ImportError, match="python-docx is required"):
                _extract_text_docx(f)

    def test_extract_text_pdf_import_error(self, tmp_path):
        """Mock pypdf import missing, verify ImportError raised."""
        from coppermind_cmo.ingest_folder import _extract_text_pdf

        f = tmp_path / "doc.pdf"
        f.write_bytes(b"fake pdf content")

        with patch.dict("sys.modules", {"pypdf": None}):
            with pytest.raises(ImportError, match="pypdf is required"):
                _extract_text_pdf(f)


class TestExtractTextDocxSuccess:
    def test_extract_text_docx_with_mock(self, tmp_path):
        """Mock docx.Document to test actual extraction logic (lines 57-59)."""
        from coppermind_cmo.ingest_folder import _extract_text_docx

        f = tmp_path / "doc.docx"
        f.write_bytes(b"fake")

        mock_para1 = MagicMock()
        mock_para1.text = "First paragraph"
        mock_para2 = MagicMock()
        mock_para2.text = ""  # empty paragraph should be filtered
        mock_para3 = MagicMock()
        mock_para3.text = "Third paragraph"

        mock_doc = MagicMock()
        mock_doc.paragraphs = [mock_para1, mock_para2, mock_para3]

        mock_docx_module = MagicMock()
        mock_docx_module.Document.return_value = mock_doc

        with patch.dict("sys.modules", {"docx": mock_docx_module}):
            result = _extract_text_docx(f)

        assert result == "First paragraph\n\nThird paragraph"


class TestExtractTextPdfSuccess:
    def test_extract_text_pdf_with_mock(self, tmp_path):
        """Mock pypdf.PdfReader to test actual extraction logic (lines 71-77)."""
        from coppermind_cmo.ingest_folder import _extract_text_pdf

        f = tmp_path / "doc.pdf"
        f.write_bytes(b"fake")

        mock_page1 = MagicMock()
        mock_page1.extract_text.return_value = "Page one content"
        mock_page2 = MagicMock()
        mock_page2.extract_text.return_value = "  "  # whitespace-only should be skipped
        mock_page3 = MagicMock()
        mock_page3.extract_text.return_value = "Page three content"

        mock_reader = MagicMock()
        mock_reader.pages = [mock_page1, mock_page2, mock_page3]

        mock_pypdf_module = MagicMock()
        mock_pypdf_module.PdfReader.return_value = mock_reader

        with patch.dict("sys.modules", {"pypdf": mock_pypdf_module}):
            result = _extract_text_pdf(f)

        assert result == "Page one content\n\nPage three content"

    def test_extract_text_pdf_empty_page(self, tmp_path):
        """Page returns None for extract_text, should be skipped."""
        from coppermind_cmo.ingest_folder import _extract_text_pdf

        f = tmp_path / "doc.pdf"
        f.write_bytes(b"fake")

        mock_page = MagicMock()
        mock_page.extract_text.return_value = None

        mock_reader = MagicMock()
        mock_reader.pages = [mock_page]

        mock_pypdf_module = MagicMock()
        mock_pypdf_module.PdfReader.return_value = mock_reader

        with patch.dict("sys.modules", {"pypdf": mock_pypdf_module}):
            result = _extract_text_pdf(f)

        assert result == ""


class TestCollectFilesStatError:
    def test_collect_files_stat_oserror(self, tmp_path):
        """stat() raises OSError for a file, file is silently skipped (lines 129-130)."""
        (tmp_path / "good.txt").write_text("good content")
        (tmp_path / "bad.txt").write_text("bad content")

        original_stat = Path.stat

        def patched_stat(self, *args, **kwargs):
            if self.name == "bad.txt":
                raise OSError("Permission denied")
            return original_stat(self, *args, **kwargs)

        with patch.object(Path, "stat", patched_stat):
            files = collect_files([str(tmp_path)])

        names = {f.name for f in files}
        assert "good.txt" in names
        assert "bad.txt" not in names

    def test_collect_files_skips_ds_store(self, tmp_path):
        """Verify .DS_Store in SKIP_FILES is skipped."""
        (tmp_path / ".DS_Store").write_text("apple metadata")
        (tmp_path / "real.txt").write_text("real file")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "real.txt" in names
        assert ".DS_Store" not in names

    def test_collect_files_pycache_skipped(self, tmp_path):
        """__pycache__ is in SKIP_DIRS, should be skipped."""
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "module.txt").write_text("bytecode")
        (tmp_path / "source.txt").write_text("source")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "source.txt" in names
        assert "module.txt" not in names

    def test_collect_files_obsidian_skipped(self, tmp_path):
        """.obsidian is in SKIP_DIRS, should be skipped."""
        obs = tmp_path / ".obsidian"
        obs.mkdir()
        (obs / "config.txt").write_text("obsidian config")
        (tmp_path / "notes.md").write_text("my notes")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "notes.md" in names
        assert "config.txt" not in names


class TestCollectFilesSymlinks:
    """Finding 2: Symlink checks in file traversal."""

    def test_collect_files_skips_symlinked_file(self, tmp_path):
        """Symlinked files should be skipped."""
        real = tmp_path / "real.txt"
        real.write_text("real content")
        link = tmp_path / "link.txt"
        link.symlink_to(real)
        (tmp_path / "normal.txt").write_text("normal content")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "normal.txt" in names
        assert "real.txt" in names
        assert "link.txt" not in names

    def test_collect_files_skips_symlinked_directory(self, tmp_path):
        """Symlinked directories should not be traversed."""
        real_dir = tmp_path / "real_dir"
        real_dir.mkdir()
        (real_dir / "secret.txt").write_text("secret")
        link_dir = tmp_path / "link_dir"
        link_dir.symlink_to(real_dir)
        (tmp_path / "normal.txt").write_text("normal content")

        files = collect_files([str(tmp_path)])
        names = {f.name for f in files}
        assert "normal.txt" in names
        # Files from real_dir should appear (it's a real directory)
        assert "secret.txt" in names
        # But link_dir should not be traversed
        paths_str = [str(f) for f in files]
        assert not any("link_dir" in p for p in paths_str)


class TestSafeExtract:
    """Finding 8: safe_extract wrapper for daemon use."""

    def test_returns_text_for_valid_txt(self, tmp_path):
        """Valid .txt file returns its text content."""
        f = tmp_path / "doc.txt"
        f.write_text("This is valid content for extraction purposes.")
        result = safe_extract(f)
        assert result is not None
        assert "valid content" in result

    def test_returns_none_for_unsupported_extension(self, tmp_path):
        """Unsupported extension returns None."""
        f = tmp_path / "image.png"
        f.write_bytes(b"\x89PNG\r\n")
        result = safe_extract(f)
        assert result is None

    def test_returns_none_when_extractor_raises(self, tmp_path):
        """When the extractor raises an exception, returns None."""
        f = tmp_path / "bad.txt"
        f.write_text("This is enough content for the minimum length check.")

        def boom(path):
            raise RuntimeError("boom")

        with patch.dict("coppermind_cmo.ingest_folder._EXTRACTORS", {".txt": boom}):
            result = safe_extract(f)
        assert result is None

    def test_returns_none_for_short_text(self, tmp_path):
        """Text shorter than MIN_TEXT_LENGTH returns None."""
        f = tmp_path / "tiny.txt"
        f.write_text("short")
        result = safe_extract(f)
        assert result is None

    def test_returns_none_for_empty_text(self, tmp_path):
        """Empty text returns None."""
        f = tmp_path / "empty.txt"
        f.write_text("")
        result = safe_extract(f)
        assert result is None
