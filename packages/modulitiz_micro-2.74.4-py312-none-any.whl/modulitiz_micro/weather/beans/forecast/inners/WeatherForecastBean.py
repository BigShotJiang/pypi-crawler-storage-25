from datetime import datetime

from modulitiz_micro.weather.beans.AbstractWeatherDataBean import AbstractWeatherDataBean
from modulitiz_micro.weather.beans.commons.WeatherCloudsBean import WeatherCloudsBean
from modulitiz_micro.weather.beans.commons.WeatherRainBean import WeatherRainBean
from modulitiz_micro.weather.beans.commons.WeatherWindBean import WeatherWindBean
from modulitiz_micro.weather.beans.forecast.inners.WeatherMainForecastBean import WeatherMainForecastBean
from modulitiz_micro.weather.beans.forecast.inners.WeatherSysBean import WeatherSysBean
from modulitiz_nano.ModuloDate import ModuloDate


class WeatherForecastBean(AbstractWeatherDataBean):
	def __init__(self,*args,**kwargs):
		super().__init__(*args,**kwargs)
		dtUtc=ModuloDate.timestampUtcToDate(self._data["dt"])
		dtLocal=ModuloDate.setTimezoneLocal(dtUtc)
		self.dt: datetime=ModuloDate.removeTimezoneInfo(dtLocal)
		self.main = WeatherMainForecastBean(**self._data["main"])
		self.clouds=WeatherCloudsBean(**self._data["clouds"])
		self.wind=WeatherWindBean(**self._data["wind"])
		self.visibility: int=self._data["visibility"]
		
		self.pop: float=self._data["pop"]
		"""
		Probability of precipitation.
		Vary between 0 and 1, where 0 is equal to 0%, 1 is equal to 100%
		"""
		
		self.rain=WeatherRainBean(self._data.get("rain",{}))
		self.sys=WeatherSysBean(**self._data["sys"])
		self.dt_txt: str=self._data["dt_txt"]
