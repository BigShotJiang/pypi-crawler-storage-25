from abc import ABC


class AbstractWeatherBean(ABC):
	def __init__(self, data: dict):
		self._data=data
