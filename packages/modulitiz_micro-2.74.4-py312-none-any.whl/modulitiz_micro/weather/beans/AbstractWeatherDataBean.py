from modulitiz_micro.weather.beans.AbstractWeatherBean import AbstractWeatherBean
from modulitiz_micro.weather.beans.commons.WeatherBean import WeatherBean
from modulitiz_micro.weather.enums.IdWeatherEnum import IdWeatherEnum


class AbstractWeatherDataBean(AbstractWeatherBean):
	__CLOUDY_SKY_MULTIPLIER=100//(IdWeatherEnum.OVERCAST_CLOUDS_85_100_PERC-IdWeatherEnum.CLEAR_SKY)
	
	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self.weather=[WeatherBean(**w) for w in self._data.get("weather",[])]
	
	def isClearSky(self) -> bool:
		return self.getFirstId()==IdWeatherEnum.CLEAR_SKY
	
	def getCloudyPercentage(self) -> int:
		return (self.getFirstId()-IdWeatherEnum.CLEAR_SKY)*self.__CLOUDY_SKY_MULTIPLIER
	
	def getFirstId(self) -> IdWeatherEnum:
		return self.weather[0].id

