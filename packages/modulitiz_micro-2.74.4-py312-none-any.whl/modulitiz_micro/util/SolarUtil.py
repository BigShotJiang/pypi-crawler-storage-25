import math


class SolarUtil:
	@staticmethod
	def solarFactor(cloudPerc: int|float) -> float:
		"""
		0 -> clear -> 1.0
		100 -> cloudy-> 0.0
		"""
		factor=1-(cloudPerc*0.01)
		# clamp sicurezza
		return max(0.0,min(1.0,factor))
	
	@staticmethod
	def solarDecay(dayProgress:float) -> float:
		decay=math.sin(math.pi*dayProgress)
		return max(0.15,decay)
