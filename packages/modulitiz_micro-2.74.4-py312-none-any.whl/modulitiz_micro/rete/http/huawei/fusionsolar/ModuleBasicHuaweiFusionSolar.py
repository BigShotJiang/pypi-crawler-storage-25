from datetime import datetime

from modulitiz_micro.rete.http.huawei.fusionsolar.ModuleHuaweiFusionSolar import ModuleHuaweiFusionSolar
from modulitiz_micro.rete.http.huawei.fusionsolar.beans.device.DeviceDataBattery import DeviceDataBattery
from modulitiz_micro.rete.http.huawei.fusionsolar.enums.BatteryStatusEnum import BatteryStatusEnum
from modulitiz_micro.util.SolarUtil import SolarUtil
from modulitiz_micro.weather.beans.current.WeatherCurrentDataBean import WeatherCurrentDataBean
from modulitiz_micro.weather.beans.forecast.WeatherForecastDataBean import WeatherForecastDataBean
from modulitiz_nano.ModuloDate import ModuloDate
from modulitiz_nano.exceptions.ExceptionNoData import ExceptionNoData


class ModuleBasicHuaweiFusionSolar(ModuleHuaweiFusionSolar):
	DEVICE_MARGIN_KWH=0.1
	
	def __init__(self,*args,**kwargs):
		super().__init__(*args,**kwargs)
		self.__countExcNoData=0
	
	@staticmethod
	def hasBattery(info:DeviceDataBattery)->bool:
		return info.run_state and info.battery_status!=BatteryStatusEnum.FAULTY
	
	def shouldTurnDeviceOn(self,sunriseDateTime:datetime,sunsetDateTime:datetime,
			weatherNow:WeatherCurrentDataBean,weatherForecast:WeatherForecastDataBean,
			deviceEstimatedWattConsumption:int,batteryPercTarget:int) -> bool:
		self._logger.info("%s",(sunriseDateTime,sunsetDateTime,
			weatherNow.__dict__,weatherForecast.__dict__,
			deviceEstimatedWattConsumption,batteryPercTarget))#TODO
		# tempo residuo di produzione
		now=ModuloDate.now()
		if now<sunriseDateTime or now>=sunsetDateTime:
			return False
		
		try:
			pvKwNow=self.getRealtimeProductionKwh()
		except ExceptionNoData as ex:
			self.__countExcNoData+=1
			if self.__countExcNoData>=3:
				# reset counter and raise error
				self.__countExcNoData=0
				raise ex
			self._logger.warning("PV has no data")
			return False
		realtimeBatteryData=self.getRealtimeDataBattery()
		batteryCapacityKwh=realtimeBatteryData.rated_capacity
		batteryPerc=realtimeBatteryData.battery_soc
		# energia mancante reale
		missingBatteryKwh=max(0,batteryCapacityKwh*(batteryPercTarget-batteryPerc)*0.01)
		
		remainingHours=(sunsetDateTime-now).total_seconds()/3600
		remainingHours=max(0.25,remainingHours)
		requiredBatteryKw=missingBatteryKwh/remainingHours
		
		batteryChDischargeKwh=realtimeBatteryData.ch_discharge_power
		batteryDischargeKwh=batteryChDischargeKwh if batteryChDischargeKwh<0 else 0
		homeKw=self.getRealtimeHomeConsumption(pvKwNow,batteryDischargeKwh)
		surplusKw=pvKwNow-homeKw
		if surplusKw<=0:
			return False
		
		wfNow=SolarUtil.solarFactor(weatherNow.getCloudyPercentage())
		wf3h=SolarUtil.solarFactor(weatherForecast.list[0].getCloudyPercentage())
		weatherFactor=wfNow*0.6+wf3h*0.4
		weatherPenalty=1-weatherFactor
		requiredBatteryKw*=weatherPenalty
		
		requiredSurplus=deviceEstimatedWattConsumption*0.001+requiredBatteryKw
		# margine anti prelievo rete
		requiredSurplus+=self.DEVICE_MARGIN_KWH
		return surplusKw>=requiredSurplus
	
	def getRealtimeHomeConsumption(self,pvKw:int|float,batteryChDischargeKw:int|float)->float:
		activePower=self.getRealtimeDataPowerSensor().active_power
		return pvKw-activePower-batteryChDischargeKw
