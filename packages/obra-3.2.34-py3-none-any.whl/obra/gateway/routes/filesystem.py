"""Local filesystem browsing for the gateway.

Provides a directory listing endpoint so the Studio frontend can offer a
folder-picker UI without requiring Tauri-specific APIs.  Only directories
are returned — no file contents are exposed.
"""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import APIRouter, Query, status

from obra.gateway.errors import GatewayAPIError

router = APIRouter(prefix="/api/filesystem", tags=["filesystem"])

_DEFAULT_PROJECTS_BASE = "~/obra-projects"


def _resolve_home(raw: str) -> Path:
    return Path(os.path.expanduser(raw)).resolve()


@router.get("/browse")
async def browse_directory(
    path: str | None = Query(default=None),
) -> dict[str, object]:
    """List immediate subdirectories of *path*.

    If *path* is omitted the user's home directory is used.  Returns the
    resolved absolute path, its parent (for "go up" navigation), and
    a sorted list of child directory names.
    """
    base = path or "~"
    resolved = _resolve_home(base)

    if not resolved.is_dir():
        raise GatewayAPIError(
            error_code="not_a_directory",
            message=f"Path is not a directory: {resolved}",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    children: list[str] = []
    try:
        for entry in sorted(resolved.iterdir()):
            if entry.name.startswith("."):
                continue
            if entry.is_dir():
                children.append(entry.name)
    except PermissionError:
        pass

    parent = str(resolved.parent) if resolved.parent != resolved else None

    return {
        "path": str(resolved),
        "parent": parent,
        "directories": children,
    }


@router.post("/mkdir")
async def create_directory(
    path: str = Query(),
    parents: bool = Query(default=False),
) -> dict[str, object]:
    """Create a directory on the local filesystem.

    **Default (``parents=false``)** — leaf-only mode.  Only the final path
    segment may be new; all ancestor directories must already exist.  This
    prevents typos in manually entered paths from silently creating
    unintended directory trees (e.g. ``~/siumtions/…`` instead of
    ``~/simulations/…``).  The Studio GUI always uses this mode.

    **``parents=true``** — deep-create mode (``mkdir -p`` semantics).
    Creates the target directory *and* any missing intermediate parents.
    Intended for headless / programmatic callers (CLI, CI/CD pipelines,
    remote API scripts, desktop onboarding) where the full path is
    generated or validated upstream and there is no human browse step.

    Returns the resolved absolute path, its parent, and whether the
    directory was newly created.
    """
    if not path or not path.strip():
        raise GatewayAPIError(
            error_code="invalid_path",
            message="A non-empty path is required.",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    resolved = _resolve_home(path.strip())

    if resolved.is_file():
        raise GatewayAPIError(
            error_code="path_is_file",
            message=f"A file already exists at: {resolved}",
            status_code=status.HTTP_409_CONFLICT,
        )

    if resolved.is_dir():
        # Already exists — idempotent success.
        result_parent = str(resolved.parent) if resolved.parent != resolved else None
        return {"path": str(resolved), "parent": result_parent, "created": False}

    # In leaf-only mode, the parent directory MUST already exist.
    if not parents and not resolved.parent.is_dir():
        raise GatewayAPIError(
            error_code="parent_not_found",
            message=(
                f"Parent directory does not exist: {resolved.parent}  — "
                f"only the final folder can be new. "
                f"Browse to the correct location first, or pass "
                f"parents=true for headless/programmatic use."
            ),
            status_code=status.HTTP_400_BAD_REQUEST,
            hint=(
                "Studio UI: use Browse to navigate to the parent, then New Folder. "
                "CLI/API: add ?parents=true to create intermediate directories."
            ),
        )

    try:
        resolved.mkdir(parents=parents, exist_ok=True)
    except PermissionError:
        raise GatewayAPIError(
            error_code="permission_denied",
            message=f"Permission denied creating directory: {resolved}",
            status_code=status.HTTP_403_FORBIDDEN,
        )
    except OSError as exc:
        raise GatewayAPIError(
            error_code="mkdir_failed",
            message=f"Could not create directory: {exc}",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )

    result_parent = str(resolved.parent) if resolved.parent != resolved else None
    return {"path": str(resolved), "parent": result_parent, "created": True}


@router.get("/validate-path")
async def validate_path(
    path: str = Query(),
) -> dict[str, object]:
    """Check whether a path exists and characterize what is missing.

    Returns a status that the frontend uses to display inline hints:
    - ``exists``          — directory already exists, ready to use.
    - ``leaf_missing``    — parent exists but the last segment does not;
                            safe to create with the New Folder action.
    - ``parent_missing``  — one or more ancestor directories are missing;
                            likely a typo.  The response includes the
                            deepest ancestor that *does* exist so the
                            frontend can highlight where the path diverges.
    - ``is_file``         — a regular file exists at that path.
    """
    if not path or not path.strip():
        return {"status": "invalid", "message": "Path is empty."}

    resolved = _resolve_home(path.strip())

    if resolved.is_file():
        return {"status": "is_file", "path": str(resolved)}

    if resolved.is_dir():
        return {"status": "exists", "path": str(resolved)}

    # Walk up to find the deepest existing ancestor.
    deepest_existing: Path | None = None
    ancestor = resolved.parent
    depth = 0
    while ancestor != ancestor.parent:
        depth += 1
        if ancestor.is_dir():
            deepest_existing = ancestor
            break
        ancestor = ancestor.parent
    else:
        if ancestor.is_dir():
            deepest_existing = ancestor

    if deepest_existing == resolved.parent:
        return {
            "status": "leaf_missing",
            "path": str(resolved),
            "parent": str(resolved.parent),
            "leaf": resolved.name,
        }

    return {
        "status": "parent_missing",
        "path": str(resolved),
        "deepest_existing": str(deepest_existing) if deepest_existing else None,
        "missing_from": str(resolved.parent),
    }


@router.get("/defaults")
async def filesystem_defaults() -> dict[str, str]:
    """Return the default projects base directory and home directory."""
    projects_base = _resolve_home(_DEFAULT_PROJECTS_BASE)
    home = _resolve_home("~")
    return {
        "projects_base": str(projects_base),
        "home": str(home),
    }
