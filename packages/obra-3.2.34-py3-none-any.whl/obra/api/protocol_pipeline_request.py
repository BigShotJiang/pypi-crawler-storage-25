"""Request pipeline types for stage runner orchestration.

This module is part of the protocol*.py family and is kept byte-for-byte
in sync between:
- functions/src/orchestration/protocol_pipeline_request.py
- obra/api/protocol_pipeline_request.py

Contains StageRunnerContext, PipelineStageRequest, and all request-specific
helper functions, extracted from protocol_pipeline.py to reduce cognitive
load for LLM-led development.
"""

from dataclasses import dataclass, field
from typing import Any

from obra.workflow.stage_artifacts import (
    collect_artifact_contract_issues,
    normalize_stage_output_artifacts,
    normalize_workflow_accumulation_artifact,
)

from .protocol_core import _coerce_lifecycle_payload, _coerce_optional_dict
from .protocol_pipeline import (
    ArtifactReferencePayload,
    LoopResumePayload,
    PendingManualPayload,
    ProducedArtifactPayload,
    ResolvedStageAssetBindingPayload,
    RunnerDiagnosticPayload,
    StageLoopSignal,
    StageRoutingSignal,
    WaitPayload,
    _parse_artifact_refs,
    _parse_produced_artifacts,
    _parse_resolved_stage_asset_bindings,
    _raise_artifact_contract_issues,
)


@dataclass
class StageRunnerContext:
    """Typed runtime context passed to a stage runner."""

    stage_name: str = ""
    stage_execution_id: str = ""
    trigger: str = ""
    input_type: str = ""
    domain_id: str = ""
    workflow_refs: dict[str, Any] = field(default_factory=dict)
    stage_refs: dict[str, Any] = field(default_factory=dict)
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)
    loop_state: dict[str, Any] = field(default_factory=dict)
    loop_verdict: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    working_directory: str = ""
    timeout_s: int = 600
    runtime_metadata: dict[str, Any] = field(default_factory=dict)
    runner_config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "trigger": self.trigger,
            "input_type": self.input_type,
            "domain_id": self.domain_id,
            "workflow_refs": self.workflow_refs,
            "stage_refs": self.stage_refs,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "payload": self.payload,
            "history": self.history,
            "loop_state": self.loop_state,
            "loop_verdict": self.loop_verdict,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "working_directory": self.working_directory,
            "timeout_s": self.timeout_s,
            "runtime_metadata": self.runtime_metadata,
            "runner_config": self.runner_config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRunnerContext":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return cls()
        artifact_fields = {
            "workflow_artifact_refs": _parse_artifact_refs(data.get("workflow_artifact_refs") or []),
            "execution_input_artifact_refs": _parse_artifact_refs(
                data.get("execution_input_artifact_refs") or []
            ),
            "stage_asset_artifact_refs": _parse_artifact_refs(
                data.get("stage_asset_artifact_refs") or []
            ),
            "resolved_stage_asset_bindings": _parse_resolved_stage_asset_bindings(
                data.get("resolved_stage_asset_bindings") or []
            ),
            "prior_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("prior_stage_output_artifact_refs") or []
            ),
            "accepted_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("accepted_stage_output_artifact_refs") or []
            ),
            "candidate_stage_output_artifacts": _parse_produced_artifacts(
                data.get("candidate_stage_output_artifacts") or []
            ),
        }
        core_fields = _build_runner_context_core_fields(data)
        loop_and_runtime_fields = _build_runner_context_loop_and_runtime_fields(data)
        return cls(
            **core_fields,
            **loop_and_runtime_fields,
            **artifact_fields,
        )


def _build_runner_context_core_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build the non-artifact StageRunnerContext fields with simple coercions."""
    return {
        "stage_name": str(data.get("stage_name", "") or ""),
        "stage_execution_id": str(data.get("stage_execution_id", "") or ""),
        "trigger": str(data.get("trigger", "") or ""),
        "input_type": str(data.get("input_type", "") or ""),
        "domain_id": str(data.get("domain_id", "") or ""),
        "workflow_refs": (
            data.get("workflow_refs", {}) if isinstance(data.get("workflow_refs"), dict) else {}
        ),
        "stage_refs": data.get("stage_refs", {}) if isinstance(data.get("stage_refs"), dict) else {},
        "payload": data.get("payload", {}) if isinstance(data.get("payload"), dict) else {},
        "history": data.get("history", []) if isinstance(data.get("history"), list) else [],
        "working_directory": str(data.get("working_directory", "") or ""),
        "timeout_s": int(data.get("timeout_s", 600) or 600),
        "runtime_metadata": (
            data.get("runtime_metadata", {})
            if isinstance(data.get("runtime_metadata"), dict)
            else {}
        ),
        "runner_config": (
            data.get("runner_config", {}) if isinstance(data.get("runner_config"), dict) else {}
        ),
    }


def _build_runner_context_loop_and_runtime_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build loop-related and optional runtime fields for StageRunnerContext."""
    return {
        "loop_state": data.get("loop_state", {}) if isinstance(data.get("loop_state"), dict) else {},
        "loop_verdict": str(data.get("loop_verdict", "") or ""),
        "pending_manual": PendingManualPayload.from_dict(data.get("pending_manual")),
        "resume": LoopResumePayload.from_dict(data.get("resume")),
        "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
            data.get("accepted_workflow_accumulation_artifact_ref")
        ),
        "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
            data.get("candidate_workflow_accumulation_artifact")
        ),
        "workflow_lifecycle": _coerce_lifecycle_payload(data.get("workflow_lifecycle")),
        "lifecycle_decisions": _coerce_optional_dict(data.get("lifecycle_decisions")),
        "legacy_phase_normalization": _coerce_optional_dict(
            data.get("legacy_phase_normalization")
        ),
    }


def _hydrate_stage_request_fields(req: "PipelineStageRequest") -> None:
    """Parse raw dicts into typed dataclass fields on a PipelineStageRequest."""
    if isinstance(req.context, dict):
        req.context = StageRunnerContext.from_dict(req.context)
    if isinstance(req.runner_diagnostic, dict):
        req.runner_diagnostic = RunnerDiagnosticPayload.from_dict(req.runner_diagnostic)
    req.workflow_artifact_refs = _parse_artifact_refs(req.workflow_artifact_refs)
    req.execution_input_artifact_refs = _parse_artifact_refs(req.execution_input_artifact_refs)
    req.stage_asset_artifact_refs = _parse_artifact_refs(req.stage_asset_artifact_refs)
    req.resolved_stage_asset_bindings = _parse_resolved_stage_asset_bindings(
        req.resolved_stage_asset_bindings
    )
    req.prior_stage_output_artifact_refs = _parse_artifact_refs(
        req.prior_stage_output_artifact_refs
    )
    req.accepted_stage_output_artifact_refs = _parse_artifact_refs(
        req.accepted_stage_output_artifact_refs
    )
    req.candidate_stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(req.candidate_stage_output_artifacts)
    )
    if isinstance(req.accepted_workflow_accumulation_artifact_ref, dict):
        req.accepted_workflow_accumulation_artifact_ref = ArtifactReferencePayload.from_dict(
            req.accepted_workflow_accumulation_artifact_ref
        )
    if isinstance(req.candidate_workflow_accumulation_artifact, dict):
        req.candidate_workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(req.candidate_workflow_accumulation_artifact)
        )
    if isinstance(req.pending_manual, dict):
        req.pending_manual = PendingManualPayload.from_dict(req.pending_manual)
    if isinstance(req.resume, dict):
        req.resume = LoopResumePayload.from_dict(req.resume)


def _resolve_stage_artifact_fallbacks(
    req: "PipelineStageRequest",
) -> tuple[list[ProducedArtifactPayload] | list[dict[str, Any]], ProducedArtifactPayload | dict[str, Any] | None]:
    """Resolve stage-output and accumulation artifacts from request, content, or context."""
    content_payload = req.content if isinstance(req.content, dict) else {}
    context_payload = req.context.payload if isinstance(req.context.payload, dict) else {}

    stage_output_payloads: list[ProducedArtifactPayload] | list[dict[str, Any]] = (
        req.stage_output_artifacts
    )
    if not stage_output_payloads and isinstance(content_payload.get("stage_output_artifacts"), list):
        stage_output_payloads = content_payload.get("stage_output_artifacts", [])
    if not stage_output_payloads and isinstance(context_payload.get("stage_output_artifacts"), list):
        stage_output_payloads = context_payload.get("stage_output_artifacts", [])

    workflow_accumulation_payload: ProducedArtifactPayload | dict[str, Any] | None = (
        req.workflow_accumulation_artifact
    )
    if workflow_accumulation_payload is None and isinstance(
        content_payload.get("workflow_accumulation_artifact"), dict
    ):
        workflow_accumulation_payload = content_payload.get("workflow_accumulation_artifact")
    if workflow_accumulation_payload is None and isinstance(
        context_payload.get("workflow_accumulation_artifact"), dict
    ):
        workflow_accumulation_payload = context_payload.get("workflow_accumulation_artifact")

    return stage_output_payloads, workflow_accumulation_payload


def _normalize_stage_request_artifacts(req: "PipelineStageRequest") -> None:
    """Resolve and validate stage-output and accumulation artifacts."""
    content_payload = req.content if isinstance(req.content, dict) else {}
    context_payload = req.context.payload if isinstance(req.context.payload, dict) else {}
    stage_output_payloads, workflow_accumulation_payload = _resolve_stage_artifact_fallbacks(req)

    issues = collect_artifact_contract_issues(
        payload=content_payload,
        stage_output_artifacts=stage_output_payloads,
        candidate_stage_output_artifacts=req.candidate_stage_output_artifacts,
        accepted_stage_output_artifact_refs=req.accepted_stage_output_artifact_refs,
        workflow_accumulation_artifact=workflow_accumulation_payload,
        candidate_workflow_accumulation_artifact=(req.candidate_workflow_accumulation_artifact),
        accepted_workflow_accumulation_artifact_ref=(
            req.accepted_workflow_accumulation_artifact_ref
        ),
    )
    issues.extend(
        collect_artifact_contract_issues(
            payload=context_payload,
            stage_output_artifacts=(
                context_payload.get("stage_output_artifacts", [])
                if isinstance(context_payload.get("stage_output_artifacts"), list)
                else None
            ),
            candidate_stage_output_artifacts=(
                context_payload.get("candidate_stage_output_artifacts", [])
                if isinstance(context_payload.get("candidate_stage_output_artifacts"), list)
                else None
            ),
            accepted_stage_output_artifact_refs=(
                context_payload.get("accepted_stage_output_artifact_refs", [])
                if isinstance(context_payload.get("accepted_stage_output_artifact_refs"), list)
                else None
            ),
            workflow_accumulation_artifact=context_payload.get("workflow_accumulation_artifact"),
            candidate_workflow_accumulation_artifact=context_payload.get(
                "candidate_workflow_accumulation_artifact"
            ),
            accepted_workflow_accumulation_artifact_ref=context_payload.get(
                "accepted_workflow_accumulation_artifact_ref"
            ),
        )
    )
    _raise_artifact_contract_issues(issues)

    req.stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(stage_output_payloads)
    )
    if workflow_accumulation_payload is not None:
        req.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(workflow_accumulation_payload)
        )
    else:
        req.workflow_accumulation_artifact = None


_BIDI_LIST_FIELDS = (
    "workflow_artifact_refs",
    "execution_input_artifact_refs",
    "stage_asset_artifact_refs",
    "resolved_stage_asset_bindings",
    "prior_stage_output_artifact_refs",
    "accepted_stage_output_artifact_refs",
    "candidate_stage_output_artifacts",
)

_BIDI_OPTIONAL_FIELDS = (
    "accepted_workflow_accumulation_artifact_ref",
    "candidate_workflow_accumulation_artifact",
)


def _sync_request_identity_fields(req: "PipelineStageRequest") -> None:
    """Synchronize identity, content, and timeout fields between request and context."""
    if not req.stage_execution_id:
        runner_fragment = req.runner_id or "runner"
        req.stage_execution_id = f"{req.stage_name}:{runner_fragment}:{req.runner_position}"
    if not req.content and req.context.payload:
        req.content = dict(req.context.payload)
    if not req.context.stage_name:
        req.context.stage_name = req.stage_name
    if not req.context.stage_execution_id:
        req.context.stage_execution_id = req.stage_execution_id
    if not req.context.trigger:
        req.context.trigger = req.trigger
    if not req.context.input_type:
        req.context.input_type = req.input_type
    if not req.context.payload and req.content:
        req.context.payload = dict(req.content)
    if not req.context.timeout_s:
        req.context.timeout_s = req.timeout_s


def _sync_bidirectional_list_fields(req: "PipelineStageRequest") -> None:
    """Mirror list and optional artifact fields between the request and context."""
    for field_name in _BIDI_LIST_FIELDS:
        req_value = getattr(req, field_name)
        context_value = getattr(req.context, field_name)
        if not req_value and context_value:
            setattr(req, field_name, list(context_value))
        elif not context_value and req_value:
            setattr(req.context, field_name, list(req_value))
    for field_name in _BIDI_OPTIONAL_FIELDS:
        req_value = getattr(req, field_name)
        context_value = getattr(req.context, field_name)
        if req_value is None and context_value is not None:
            setattr(req, field_name, context_value)
        elif context_value is None and req_value is not None:
            setattr(req.context, field_name, req_value)


def _inject_artifacts_into_content(req: "PipelineStageRequest") -> None:
    """Backfill canonical artifact payloads into content and context payloads."""
    if isinstance(req.content, dict):
        if req.stage_output_artifacts and "stage_output_artifacts" not in req.content:
            req.content["stage_output_artifacts"] = [
                artifact.to_dict() for artifact in req.stage_output_artifacts
            ]
        if (
            req.workflow_accumulation_artifact is not None
            and "workflow_accumulation_artifact" not in req.content
        ):
            req.content["workflow_accumulation_artifact"] = (
                req.workflow_accumulation_artifact.to_dict()
            )

    if isinstance(req.context.payload, dict):
        if req.stage_output_artifacts and "stage_output_artifacts" not in req.context.payload:
            req.context.payload["stage_output_artifacts"] = [
                artifact.to_dict() for artifact in req.stage_output_artifacts
            ]
        if (
            req.workflow_accumulation_artifact is not None
            and "workflow_accumulation_artifact" not in req.context.payload
        ):
            req.context.payload["workflow_accumulation_artifact"] = (
                req.workflow_accumulation_artifact.to_dict()
            )


def _sync_loop_state(req: "PipelineStageRequest") -> None:
    """Synchronize loop metadata between the request and its embedded context."""
    if isinstance(req.pending_manual, dict):
        req.pending_manual = PendingManualPayload.from_dict(req.pending_manual)

    loop_state = req.context.loop_state if isinstance(req.context.loop_state, dict) else {}
    if not req.iteration and "current_iteration" in loop_state:
        req.iteration = int(loop_state.get("current_iteration", 0) or 0)
    if (
        req.max_iterations == 3
        and "max_iterations" in loop_state
        and loop_state.get("max_iterations") is not None
    ):
        req.max_iterations = int(loop_state.get("max_iterations", 3) or 3)

    if not loop_state:
        req.context.loop_state = {
            "current_iteration": req.iteration,
            "max_iterations": req.max_iterations,
        }
    else:
        req.context.loop_state.setdefault("current_iteration", req.iteration)
        req.context.loop_state.setdefault("max_iterations", req.max_iterations)

    if req.loop_state:
        req.context.loop_state["state"] = req.loop_state
    if req.loop_verdict and not req.context.loop_verdict:
        req.context.loop_verdict = req.loop_verdict
    if req.pending_manual is not None and req.context.pending_manual is None:
        req.context.pending_manual = req.pending_manual
    if req.resume is not None and req.context.resume is None:
        req.context.resume = req.resume


def _sync_stage_request_context(req: "PipelineStageRequest") -> None:
    """Synchronize fields bidirectionally between request and context, and handle loop state."""
    _sync_request_identity_fields(req)
    _sync_bidirectional_list_fields(req)
    _inject_artifacts_into_content(req)
    _sync_loop_state(req)


def _parse_payload_artifact_refs(payload: dict[str, Any]) -> dict[str, Any]:
    """Parse artifact reference fields from a stage-request payload."""
    return {
        "workflow_artifact_refs": _parse_artifact_refs(payload.get("workflow_artifact_refs") or []),
        "execution_input_artifact_refs": _parse_artifact_refs(
            payload.get("execution_input_artifact_refs") or []
        ),
        "stage_asset_artifact_refs": _parse_artifact_refs(
            payload.get("stage_asset_artifact_refs") or []
        ),
        "resolved_stage_asset_bindings": _parse_resolved_stage_asset_bindings(
            payload.get("resolved_stage_asset_bindings") or []
        ),
        "prior_stage_output_artifact_refs": _parse_artifact_refs(
            payload.get("prior_stage_output_artifact_refs") or []
        ),
        "accepted_stage_output_artifact_refs": _parse_artifact_refs(
            payload.get("accepted_stage_output_artifact_refs") or []
        ),
        "candidate_stage_output_artifacts": _parse_produced_artifacts(
            payload.get("candidate_stage_output_artifacts") or []
        ),
        "stage_output_artifacts": _parse_produced_artifacts(
            payload.get("stage_output_artifacts") or []
        ),
        "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
            payload.get("accepted_workflow_accumulation_artifact_ref")
        ),
        "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
            payload.get("candidate_workflow_accumulation_artifact")
        ),
    }


def _build_stage_request_identity_fields(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, Any]:
    """Build the identity and runner fields for PipelineStageRequest.from_payload."""
    runner_id = str(payload.get("runner_id") or "")
    runner_position = int(payload.get("runner_position", 0) or 0)
    stage_name = str(payload.get("stage_name") or context.stage_name or "")
    stage_execution_id = str(
        payload.get("stage_execution_id")
        or context.stage_execution_id
        or (f"{stage_name}:{runner_id or 'runner'}:{runner_position}" if stage_name else "")
    )
    return {
        "stage_name": stage_name,
        "trigger": str(payload.get("trigger") or context.trigger or ""),
        "input_type": str(payload.get("input_type") or context.input_type or ""),
        "runner_id": runner_id,
        "runner_version": str(payload.get("runner_version", "") or ""),
        "runner_selector": str(payload.get("runner_selector", "") or ""),
        "runner_kind": str(payload.get("runner_kind") or "extension_runner"),
        "runner_diagnostic": RunnerDiagnosticPayload.from_dict(payload.get("runner_diagnostic")),
        "stage_execution_id": stage_execution_id,
        "runner_position": runner_position,
        "runner_count": int(payload.get("runner_count", 1) or 1),
        "timeout_s": int(payload.get("timeout_s") or context.timeout_s or 600),
    }


def _build_stage_request_iteration_fields(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, int]:
    """Build iteration counters for PipelineStageRequest.from_payload."""
    loop_state = context.loop_state if isinstance(context.loop_state, dict) else {}
    return {
        "iteration": int(
            payload.get("iteration")
            if payload.get("iteration") is not None
            else loop_state.get("current_iteration", 0)
        ),
        "max_iterations": int(
            payload.get("max_iterations")
            if payload.get("max_iterations") is not None
            else loop_state.get("max_iterations", 3)
        ),
    }


def _resolve_stage_request_content(
    payload: dict[str, Any],
    context: StageRunnerContext,
) -> dict[str, Any]:
    """Resolve request content from the payload or embedded context."""
    if isinstance(payload.get("content"), dict):
        return payload.get("content", {})
    return dict(context.payload)


@dataclass
class PipelineStageRequest:
    """Request to run a custom pipeline stage."""

    stage_name: str
    trigger: str
    input_type: str
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_kind: str = "extension_runner"
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    stage_execution_id: str = ""
    runner_position: int = 0
    runner_count: int = 1
    context: StageRunnerContext = field(default_factory=StageRunnerContext)
    timeout_s: int = 600
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    content: dict[str, Any] = field(default_factory=dict)
    iteration: int = 0
    max_iterations: int = 3

    def __post_init__(self) -> None:
        """Hydrate canonical request fields from whichever shape was provided."""
        _hydrate_stage_request_fields(self)
        _normalize_stage_request_artifacts(self)
        _sync_stage_request_context(self)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "PipelineStageRequest":
        """Create from ServerAction payload."""
        context = StageRunnerContext.from_dict(payload.get("context"))
        artifact_fields = _parse_payload_artifact_refs(payload)
        identity_fields = _build_stage_request_identity_fields(payload, context)
        iteration_fields = _build_stage_request_iteration_fields(payload, context)
        return cls(
            context=context,
            loop_verdict=str(payload.get("loop_verdict") or ""),
            loop_state=str(payload.get("loop_state") or ""),
            pending_manual=PendingManualPayload.from_dict(payload.get("pending_manual")),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                payload.get("workflow_accumulation_artifact")
            ),
            content=_resolve_stage_request_content(payload, context),
            **identity_fields,
            **iteration_fields,
            **artifact_fields,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "trigger": self.trigger,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_kind": self.runner_kind,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict() if self.runner_diagnostic is not None else None
            ),
            "stage_execution_id": self.stage_execution_id,
            "runner_position": self.runner_position,
            "runner_count": self.runner_count,
            "context": self.context.to_dict(),
            "timeout_s": self.timeout_s,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "input_type": self.input_type,
            "content": self.content,
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
        }
