"""Gateway config getter owners."""

from __future__ import annotations

import os

from obra.exceptions import ConfigurationError
from obra.gateway.automation.profile import (
    GATEWAY_PROFILE_STANDARD,
    OBRA_GATEWAY_AUTH_TOKEN_ENV,
    OBRA_GATEWAY_PROFILE_ENV,
)

from .. import _core, _defaults
from ._helpers import resolve_bool_config, resolve_float_config, resolve_int_config

__all__ = [
    "get_phase_detection_draft_instruction_threshold",
    "get_phase_detection_entry_point_defaults",
    "get_phase_detection_enabled",
    "get_gateway_session_timeout",
    "get_phase_detection_min_stages_for_full_model",
    "get_phase_detection_stable_run_threshold",
    "get_phase_detection_validate_min_run_count",
    "get_readiness_next_action_priorities",
    "get_readiness_first_use_intro_enabled",
    "get_readiness_prompt_section_max_tokens",
    "get_readiness_prompt_section_priority",
    "get_readiness_recap_enabled",
    "get_readiness_seed_alignment_min_keyword_matches",
    "get_gateway_assistant_config",
    "get_gateway_config",
    "get_gateway_desktop_config",
    "get_gateway_onboarding_config",
    "get_gateway_transcription_config",
]

_WORKFLOW_STORAGE_ENV = "OBRA_GATEWAY_WORKFLOW_STORAGE"
_SESSION_TIMEOUT_ENV = "OBRA_GATEWAY_SESSION_TIMEOUT_S"
_VALID_WORKFLOW_STORAGE_VALUES = {"cloud", "local"}

_PHASE_DETECTION_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_PHASE_DETECTION_"
_READINESS_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_READINESS_"
_PROMPT_SECTIONS_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_PROMPT_SECTIONS_"


def _resolve_workflow_storage(gateway_section: dict) -> str:
    raw_value = os.getenv(_WORKFLOW_STORAGE_ENV, gateway_section.get("workflow_storage", "cloud"))
    normalized = str(raw_value or "").strip().lower()
    if normalized in _VALID_WORKFLOW_STORAGE_VALUES:
        return normalized
    raise ConfigurationError(
        "gateway.workflow_storage must be one of: cloud, local"
    )


def get_gateway_config() -> dict:
    """Get gateway server configuration.

    Returns dict with host, port, max_sessions, auth_token, escalation_timeout_s,
    enable_cors, cors_origins, allowed_working_dir_base, max_event_queue_size,
    session_eviction_ttl_seconds, max_objective_length, max_project_id_length,
    max_working_dir_length, cors_allow_credentials, allow_public_bind,
    public_bind_tls_terminated, trusted_proxy_cidrs, ws_auth_timeout_s,
    max_ws_connections_total, max_ws_connections_per_ip, ws_max_message_bytes,
    enable_app_rate_limit, rest_rate_limit_per_minute, rest_rate_limit_burst,
    ws_rate_limit_per_minute, ws_rate_limit_burst, logs_session_cookie_name,
    logs_session_ttl_s, logs_session_cookie_secure, studio_session_cookie_name,
    studio_session_ttl_s, studio_session_cookie_secure, studio_launch_token_ttl_s,
    logs_stream_max_clients_total, logs_stream_max_clients_per_ip,
    logs_stream_idle_timeout_s, logs_expose_absolute_paths, pagination_default_limit,
    pagination_max_limit, webhooks_max_per_owner, webhooks_failure_threshold_failing,
    webhooks_failure_threshold_disabled, webhooks_delivery_timeout_s,
    webhooks_retry_backoff_schedule, webhooks_retention_seconds,
    webhooks_cleanup_interval_s from gateway section.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        gw = config["gateway"]
        return {
            "profile": str(
                gw.get("profile") or os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD)
            ),
            "host": gw["host"],
            "port": gw["port"],
            "max_sessions": gw["max_sessions"],
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV, gw.get("auth_token")),
            "escalation_timeout_s": float(gw["escalation_timeout_s"]),
            "enable_cors": gw["enable_cors"],
            "cors_origins": gw["cors_origins"],
            "workflow_storage": _resolve_workflow_storage(gw),
            "allowed_working_dir_base": gw.get("allowed_working_dir_base", "~/obra-projects"),
            "max_event_queue_size": int(gw.get("max_event_queue_size", 1000)),
            "session_eviction_ttl_seconds": int(gw.get("session_eviction_ttl_seconds", 3600)),
            "session_timeout_s": int(gw.get("session_timeout_s", 7200)),
            "max_objective_length": int(gw.get("max_objective_length", 10000)),
            "max_project_id_length": int(gw.get("max_project_id_length", 256)),
            "max_working_dir_length": int(gw.get("max_working_dir_length", 4096)),
            "cors_allow_credentials": gw.get("cors_allow_credentials", True),
            "allow_public_bind": gw.get("allow_public_bind", False),
            "public_bind_tls_terminated": gw.get("public_bind_tls_terminated", False),
            "trusted_proxy_cidrs": list(gw.get("trusted_proxy_cidrs", [])),
            "ws_auth_timeout_s": float(gw.get("ws_auth_timeout_s", 5)),
            "max_ws_connections_total": int(gw.get("max_ws_connections_total", 200)),
            "max_ws_connections_per_ip": int(gw.get("max_ws_connections_per_ip", 20)),
            "ws_max_message_bytes": int(gw.get("ws_max_message_bytes", 1_048_576)),
            "enable_app_rate_limit": gw.get("enable_app_rate_limit", True),
            "rest_rate_limit_per_minute": int(gw.get("rest_rate_limit_per_minute", 120)),
            "rest_rate_limit_burst": int(gw.get("rest_rate_limit_burst", 60)),
            "ws_rate_limit_per_minute": int(gw.get("ws_rate_limit_per_minute", 240)),
            "ws_rate_limit_burst": int(gw.get("ws_rate_limit_burst", 120)),
            "pagination_default_limit": int(gw["pagination_default_limit"]),
            "pagination_max_limit": int(gw["pagination_max_limit"]),
            "logs_session_cookie_name": gw["logs_session_cookie_name"],
            "logs_session_ttl_s": int(gw["logs_session_ttl_s"]),
            "logs_session_cookie_secure": bool(gw["logs_session_cookie_secure"]),
            "studio_session_cookie_name": str(
                gw.get("studio_session_cookie_name", "obra_studio_session")
            ),
            "studio_session_ttl_s": int(gw.get("studio_session_ttl_s", 43_200)),
            "studio_session_cookie_secure": bool(gw.get("studio_session_cookie_secure", False)),
            "studio_launch_token_ttl_s": int(gw.get("studio_launch_token_ttl_s", 120)),
            "logs_stream_max_clients_total": int(gw["logs_stream_max_clients_total"]),
            "logs_stream_max_clients_per_ip": int(gw["logs_stream_max_clients_per_ip"]),
            "logs_stream_idle_timeout_s": float(gw["logs_stream_idle_timeout_s"]),
            "logs_expose_absolute_paths": bool(gw["logs_expose_absolute_paths"]),
            "webhooks_max_per_owner": int(gw["webhooks_max_per_owner"]),
            "webhooks_failure_threshold_failing": int(gw["webhooks_failure_threshold_failing"]),
            "webhooks_failure_threshold_disabled": int(gw["webhooks_failure_threshold_disabled"]),
            "webhooks_delivery_timeout_s": float(gw["webhooks_delivery_timeout_s"]),
            "webhooks_retry_backoff_schedule": tuple(float(item) for item in gw["webhooks_retry_backoff_schedule"]),
            "webhooks_retention_seconds": int(gw["webhooks_retention_seconds"]),
            "webhooks_cleanup_interval_s": float(gw["webhooks_cleanup_interval_s"]),
            "workspace_isolation": str(gw.get("workspace_isolation", "off")),
            "session_isolation": str(gw.get("session_isolation", "thread")),
            "workspace_cleanup": str(gw.get("workspace_cleanup", "retain")),
        }
    except (KeyError, TypeError):
        return {
            "profile": os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD),
            "host": _defaults.DEFAULT_GATEWAY_HOST,
            "port": _defaults.DEFAULT_GATEWAY_PORT,
            "max_sessions": _defaults.DEFAULT_GATEWAY_MAX_SESSIONS,
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV),
            "escalation_timeout_s": _defaults.DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S,
            "enable_cors": _defaults.DEFAULT_GATEWAY_ENABLE_CORS,
            "cors_origins": _defaults.DEFAULT_GATEWAY_CORS_ORIGINS,
            "workflow_storage": _resolve_workflow_storage({}),
            "allowed_working_dir_base": "~/obra-projects",
            "max_event_queue_size": 1000,
            "session_eviction_ttl_seconds": 3600,
            "session_timeout_s": 7200,
            "max_objective_length": 10000,
            "max_project_id_length": 256,
            "max_working_dir_length": 4096,
            "cors_allow_credentials": True,
            "allow_public_bind": False,
            "public_bind_tls_terminated": False,
            "trusted_proxy_cidrs": [],
            "ws_auth_timeout_s": 5.0,
            "max_ws_connections_total": 200,
            "max_ws_connections_per_ip": 20,
            "ws_max_message_bytes": 1_048_576,
            "enable_app_rate_limit": True,
            "rest_rate_limit_per_minute": 120,
            "rest_rate_limit_burst": 60,
            "ws_rate_limit_per_minute": 240,
            "ws_rate_limit_burst": 120,
            "pagination_default_limit": 50,
            "pagination_max_limit": 200,
            "logs_session_cookie_name": "obra_logs_session",
            "logs_session_ttl_s": 900,
            "logs_session_cookie_secure": False,
            "studio_session_cookie_name": "obra_studio_session",
            "studio_session_ttl_s": 43_200,
            "studio_session_cookie_secure": False,
            "studio_launch_token_ttl_s": 120,
            "logs_stream_max_clients_total": 100,
            "logs_stream_max_clients_per_ip": 20,
            "logs_stream_idle_timeout_s": 900.0,
            "logs_expose_absolute_paths": False,
            "webhooks_max_per_owner": 50,
            "webhooks_failure_threshold_failing": 5,
            "webhooks_failure_threshold_disabled": 20,
            "webhooks_delivery_timeout_s": 10.0,
            "webhooks_retry_backoff_schedule": (1.0, 5.0, 30.0),
            "webhooks_retention_seconds": 86400,
            "webhooks_cleanup_interval_s": 60.0,
            "workspace_isolation": "off",
            "session_isolation": "thread",
            "workspace_cleanup": "retain",
        }


def get_gateway_session_timeout() -> int:
    """Return the gateway session timeout in seconds."""
    return resolve_int_config(
        _SESSION_TIMEOUT_ENV,
        "gateway.session_timeout_s",
        default=7200,
        min_val=60,
        include_defaults=True,
        label="Gateway session timeout",
    )


def get_gateway_assistant_config() -> dict:
    """Get gateway assistant context pipeline configuration.

    Returns a flat dict with all assistant operational parameters from
    gateway.assistant config section plus orchestration.content.chars_per_token.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        assistant = config["gateway"]["assistant"]
    except (KeyError, TypeError):
        assistant = {}

    # Also pull chars_per_token from orchestration.content for token estimation
    try:
        chars_per_token = int(config["orchestration"]["content"]["chars_per_token"])
    except (KeyError, TypeError, ValueError):
        chars_per_token = 4

    section_priorities = assistant.get("section_priorities", {})
    conv_history = assistant.get("conversation_history", {})
    memory = assistant.get("memory", {})
    persistence = assistant.get("persistence", {})
    retention = assistant.get("retention", {})
    strategy = assistant.get("strategy", {})
    revision_history = assistant.get("revision_history", {})
    knowledge = assistant.get("knowledge", {})
    screenshot = assistant.get("screenshot", {})
    run_timeline = assistant.get("run_timeline", {})
    stage_detail = assistant.get("stage_detail", {})
    prompt_sections = assistant.get("prompt_sections", {})
    model = assistant.get("model", {})
    logging_section = assistant.get("logging", {})
    pipelines = assistant.get("pipelines", {})

    return {
        "prompt_budget_tokens": int(assistant.get("prompt_budget_tokens", 16000)),
        "chars_per_token": chars_per_token,
        "section_priorities": {
            "preamble": int(section_priorities.get("preamble", 1)),
            "selected_stage": int(section_priorities.get("selected_stage", 2)),
            "workflow_definition": int(section_priorities.get("workflow_definition", 3)),
            "workflow_readiness": int(
                prompt_sections.get(
                    "workflow_readiness_priority",
                    section_priorities.get("workflow_readiness", 3),
                )
            ),
            "knowledge_docs": int(section_priorities.get("knowledge_docs", 4)),
            "recent_transcript": int(section_priorities.get("recent_transcript", 4)),
            "thread_summary": int(section_priorities.get("thread_summary", 4)),
            "carry_forward_context": int(section_priorities.get("carry_forward_context", 4)),
            "conversation_history": int(section_priorities.get("conversation_history", 5)),
            "run_comparison": int(section_priorities.get("run_comparison", 5)),
            "latest_run": int(section_priorities.get("latest_run", 6)),
            "ui_state": int(section_priorities.get("ui_state", 7)),
            "graph_structure": int(section_priorities.get("graph_structure", 7)),
            "proactive_guidance": int(section_priorities.get("proactive_guidance", 7)),
            "recent_changes": int(section_priorities.get("recent_changes", 8)),
            "interaction_log": int(section_priorities.get("interaction_log", 9)),
            "revision_history": int(section_priorities.get("revision_history", 10)),
        },
        "conversation_history_max_proposal_turns": int(conv_history.get("max_proposal_turns", 10)),
        "conversation_history_message_preview_chars": int(
            conv_history.get("message_preview_chars", 80)
        ),
        "memory_recent_turns": int(memory.get("recent_turns", 6)),
        "memory_summary_turns": int(memory.get("summary_turns", 12)),
        "memory_summary_message_chars": int(memory.get("summary_message_chars", 160)),
        "memory_mode_event_limit": int(memory.get("mode_event_limit", 6)),
        "persistence_storage_path": str(persistence.get("storage_path", "assistant/threads.json")),
        "retention": {
            "max_active_threads": int(retention.get("max_active_threads", 20)),
            "archive_after_days": int(retention.get("archive_after_days", 30)),
            "delete_after_days": int(retention.get("delete_after_days", 180)),
        },
        "strategy_design_guidance_max_stages": int(strategy.get("design_guidance_max_stages", 3)),
        "revision_history_max_revisions": int(revision_history.get("max_revisions", 5)),
        "knowledge_max_document_bytes": int(knowledge.get("max_document_bytes", 102400)),
        "knowledge_max_total_bytes": int(knowledge.get("max_total_bytes", 2097152)),
        "knowledge_token_budget": int(knowledge.get("token_budget", 2000)),
        "screenshot_max_bytes": int(screenshot.get("max_bytes", 204800)),
        "screenshot_initial_scale": float(screenshot.get("initial_scale", 0.5)),
        "screenshot_jpeg_quality": float(screenshot.get("jpeg_quality", 0.7)),
        "screenshot_fallback_scale": float(screenshot.get("fallback_scale", 0.3)),
        "screenshot_fallback_quality": float(screenshot.get("fallback_quality", 0.5)),
        "workflow_readiness_max_tokens": int(prompt_sections.get("workflow_readiness_max_tokens", 800)),
        "run_timeline_max_events": int(run_timeline.get("max_events", 10)),
        "stage_detail_max_dependency_chain_stages": int(
            stage_detail.get("max_dependency_chain_stages", 20)
        ),
        "model_default_model": str(model.get("default_model", "sonnet")),
        "model_default_provider": str(model.get("default_provider", "anthropic")),
        "model_health_check_on_startup": bool(model.get("health_check_on_startup", True)),
        "model_health_check_cache_ttl_s": int(model.get("health_check_cache_ttl_s", 300)),
        "auth_method": str(model.get("auth_method", "oauth")),
        "logging": dict(logging_section),
        "pipelines": {
            "default_timeout_s": int(pipelines.get("default_timeout_s", 600)),
            "per_step_timeout_budget_s": int(pipelines["per_step_timeout_budget_s"]),
            "sse_heartbeat_interval_s": int(pipelines["sse_heartbeat_interval_s"]),
            "bulk_template_timeout_s": int(pipelines.get("bulk_template_timeout_s", 600)),
            "self_review_timeout_s": int(pipelines.get("self_review_timeout_s", 600)),
            "self_review_auto_min_stage_count": int(
                pipelines.get("self_review_auto_min_stage_count", 5)
            ),
            "diagnostic_timeout_s": int(pipelines.get("diagnostic_timeout_s", 600)),
            "compliance_audit_timeout_s": int(pipelines.get("compliance_audit_timeout_s", 600)),
            "llm_model_tier": str(pipelines.get("llm_model_tier", "fast")),
            "llm_reasoning_level": str(pipelines.get("llm_reasoning_level", "default")),
            "max_pipeline_sessions": int(pipelines["max_pipeline_sessions"]),
            "pipeline_session_eviction_ttl_seconds": int(
                pipelines["pipeline_session_eviction_ttl_seconds"]
            ),
        },
    }


def get_phase_detection_enabled() -> bool:
    """Get gateway assistant phase-detection enabled flag with env override support."""
    return resolve_bool_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}ENABLED",
        "gateway.assistant.phase_detection.enabled",
        default=True,
        include_defaults=True,
    )


def get_phase_detection_draft_instruction_threshold() -> float:
    """Get draft-phase instruction threshold with env override support."""
    return resolve_float_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}DRAFT_INSTRUCTION_THRESHOLD",
        "gateway.assistant.phase_detection.draft_instruction_threshold",
        default=0.5,
        min_val=0.0,
        max_val=1.0,
        include_defaults=True,
    )


def get_phase_detection_validate_min_run_count() -> int:
    """Get minimum persisted workflow runs needed to enter validate phase."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}VALIDATE_MIN_RUN_COUNT",
        "gateway.assistant.phase_detection.validate_min_run_count",
        default=1,
        min_val=0,
        include_defaults=True,
    )


def get_phase_detection_min_stages_for_full_model() -> int:
    """Get minimum stage count before full readiness phase model applies."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}MIN_STAGES_FOR_FULL_MODEL",
        "gateway.assistant.phase_detection.min_stages_for_full_model",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_phase_detection_stable_run_threshold() -> int:
    """Get run-count threshold for stable-workflow guidance."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}STABLE_RUN_THRESHOLD",
        "gateway.assistant.phase_detection.stable_run_threshold",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_phase_detection_entry_point_defaults() -> dict[str, str]:
    """Get phase overrides for guided-development entry points."""
    env_keys = {
        "clone": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_CLONE",
        "starter": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_STARTER",
        "import": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_IMPORT",
    }
    config, _, _ = _core.load_layered_config(include_defaults=True)
    configured_defaults = (
        config.get("gateway", {})
        .get("assistant", {})
        .get("phase_detection", {})
        .get("entry_point_defaults", {})
    )
    normalized: dict[str, str] = {}
    for entry_point, env_key in env_keys.items():
        raw_value = os.getenv(
            env_key,
            (
                configured_defaults.get(entry_point)
                if isinstance(configured_defaults, dict)
                else None
            ),
        )
        value = str(raw_value or "").strip().lower()
        normalized[entry_point] = value or "computed"
    return normalized


def get_readiness_recap_enabled() -> bool:
    """Get readiness recap toggle with env override support."""
    return resolve_bool_config(
        f"{_READINESS_ENV_PREFIX}RECAP_ENABLED",
        "gateway.assistant.readiness.recap_enabled",
        default=True,
        include_defaults=True,
    )


def get_readiness_seed_alignment_min_keyword_matches() -> int:
    """Get deterministic seed-alignment overlap threshold."""
    return resolve_int_config(
        f"{_READINESS_ENV_PREFIX}SEED_ALIGNMENT_MIN_KEYWORD_MATCHES",
        "gateway.assistant.readiness.seed_alignment_min_keyword_matches",
        default=2,
        min_val=1,
        include_defaults=True,
    )


def get_readiness_first_use_intro_enabled() -> bool:
    """Get first-use introduction toggle with env override support."""
    return resolve_bool_config(
        f"{_READINESS_ENV_PREFIX}FIRST_USE_INTRO_ENABLED",
        "gateway.assistant.readiness.first_use_intro_enabled",
        default=True,
        include_defaults=True,
    )


def get_readiness_next_action_priorities() -> list[str]:
    """Get readiness next-action priority list with env override support."""
    env_value = os.environ.get(f"{_READINESS_ENV_PREFIX}NEXT_ACTION_PRIORITIES")
    if env_value is not None:
        return [item.strip() for item in env_value.split(",") if item.strip()]

    config, _, _ = _core.load_layered_config(include_defaults=True)
    priorities = (
        config.get("gateway", {}).get("assistant", {}).get("readiness", {}).get("next_action_priorities")
    )
    if isinstance(priorities, list):
        return [str(item).strip() for item in priorities if str(item).strip()]
    return [
        "fix_blocking_issues",
        "fix_improvement_issues",
        "enrich_least_complete_stage",
        "add_missing_quality_gates",
        "review_against_seed",
        "run_with_test_data",
        "iterate_on_results",
        "stable_workflow_guidance",
    ]


def get_readiness_prompt_section_priority() -> int:
    """Get workflow-readiness prompt section priority."""
    return resolve_int_config(
        f"{_PROMPT_SECTIONS_ENV_PREFIX}WORKFLOW_READINESS_PRIORITY",
        "gateway.assistant.prompt_sections.workflow_readiness_priority",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_readiness_prompt_section_max_tokens() -> int:
    """Get workflow-readiness prompt section max token budget."""
    return resolve_int_config(
        f"{_PROMPT_SECTIONS_ENV_PREFIX}WORKFLOW_READINESS_MAX_TOKENS",
        "gateway.assistant.prompt_sections.workflow_readiness_max_tokens",
        default=800,
        min_val=1,
        include_defaults=True,
    )


def get_gateway_transcription_config() -> dict:
    """Get gateway transcription configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    transcription = config["gateway"]["transcription"]
    return {
        "provider": str(transcription["provider"]),
        "model_size": str(transcription["model_size"]),
        "max_audio_bytes": int(transcription["max_audio_bytes"]),
    }


def get_gateway_desktop_config() -> dict:
    """Get gateway desktop app operational configuration.

    Returns dict with shutdown_timeout_s, port_scan_start, port_scan_end,
    monitor_interval_s, restart_backoff_s, restart_max_attempts,
    restart_failure_window_s, stable_window_s.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        desktop = config["gateway"]["desktop"]
    except (KeyError, TypeError):
        desktop = {}
    return {
        "shutdown_timeout_s": int(desktop.get("shutdown_timeout_s", 5)),
        "port_scan_start": int(desktop.get("port_scan_start", 18790)),
        "port_scan_end": int(desktop.get("port_scan_end", 18800)),
        "monitor_interval_s": int(desktop.get("monitor_interval_s", 3)),
        "restart_backoff_s": int(desktop.get("restart_backoff_s", 2)),
        "restart_max_attempts": int(desktop.get("restart_max_attempts", 3)),
        "restart_failure_window_s": int(desktop.get("restart_failure_window_s", 60)),
        "stable_window_s": int(desktop.get("stable_window_s", 30)),
    }


def get_gateway_onboarding_config() -> dict:
    """Get gateway provider onboarding configuration.

    Returns dict with detection_timeout_s, auth_check_timeout_s, auth_timeout_s,
    ready_retry_interval_s, status_poll_interval_s, banner_poll_interval_s,
    success_dwell_s, health_cache_ttl_s, and providers list.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        onboarding = config["gateway"]["onboarding"]
    except (KeyError, TypeError):
        onboarding = {}
    return {
        "detection_timeout_s": int(onboarding.get("detection_timeout_s", 5)),
        "auth_check_timeout_s": int(onboarding.get("auth_check_timeout_s", 5)),
        "auth_timeout_s": int(onboarding.get("auth_timeout_s", 300)),
        "ready_retry_interval_s": int(onboarding.get("ready_retry_interval_s", 2)),
        "status_poll_interval_s": int(onboarding.get("status_poll_interval_s", 3)),
        "banner_poll_interval_s": int(onboarding.get("banner_poll_interval_s", 60)),
        "success_dwell_s": int(onboarding.get("success_dwell_s", 2)),
        "health_cache_ttl_s": int(onboarding.get("health_cache_ttl_s", 30)),
        "providers": list(onboarding.get("providers", [])),
    }
