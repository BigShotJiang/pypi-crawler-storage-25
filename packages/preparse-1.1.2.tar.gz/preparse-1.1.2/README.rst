========
preparse
========

Each minor version has its own documentation.
These docs can be found as rst-files in the ``docs/`` directory of this project.
They can also be viewed on the website `https://preparse.johannes-programming.online/ <https://preparse.johannes-programming.online/>`_.
