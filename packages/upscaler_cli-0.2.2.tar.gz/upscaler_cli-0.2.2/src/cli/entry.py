"""Entry management CLI commands (records/items)."""

import asyncio
import sys

import click

from src.cli.context import Context, pass_context
from src.cli.helpers import handle_error


@click.group("entry")
def entry_group():
    """Manage record/item entries: create, update, complete-task, delete.

    Examples:
        upscaler entry create --definition-id rg_123 --data '{"title": "New item"}'
        upscaler entry update --entry-id i_456 --data '{"values": {"status": "done"}}'
        upscaler entry complete-task --task-id t_789
        upscaler entry create --definition-id rg_123 --data @payload.json --dry-run
    """
    pass


@entry_group.command("create")
@click.option("--definition-id", required=True, help="Definition ID (rd_ = record, rg_ = register).")
@click.option("--data", "data_input", required=True, help="JSON data (value, - for stdin, @file).")
@click.option("--dry-run", is_flag=True, help="Preview without creating.")
@pass_context
def entry_create(ctx, definition_id, data_input, dry_run):
    """Create a new entry."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_entry(ctx, "create", definition_id=definition_id, data=data, dry_run=dry_run)


@entry_group.command("update")
@click.option("--entry-id", required=True, help="Entry ID to update.")
@click.option("--data", "data_input", required=True, help="JSON data.")
@click.option("--dry-run", is_flag=True, help="Preview without updating.")
@pass_context
def entry_update(ctx, entry_id, data_input, dry_run):
    """Update an existing entry."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_entry(ctx, "update", entry_id=entry_id, data=data, dry_run=dry_run)


@entry_group.command("complete-task")
@click.option("--entry-id", default=None, help="Record ID (auto-detected from task if omitted).")
@click.option("--task-id", required=True, help="Task ID to complete.")
@click.option("--data", "data_input", default=None, help="Optional JSON data.")
@click.option("--dry-run", is_flag=True, help="Preview task fields without completing.")
@pass_context
def entry_complete_task(ctx, entry_id, task_id, data_input, dry_run):
    """Complete a task within a record.

    Use --dry-run to see the task's form fields before completing.
    The --entry-id is auto-detected from the task if not provided.

    Examples:
        upscaler entry complete-task --task-id t_xyz --dry-run
        upscaler entry complete-task --task-id t_xyz --data '{"values": {...}}'
        upscaler entry complete-task --entry-id r_abc --task-id t_xyz --data '{"values": {...}}'
    """
    from src.cli.helpers import parse_data

    data = None
    if data_input:
        try:
            data = parse_data(data_input)
        except Exception as e:
            click.echo(str(e), err=True)
            sys.exit(1)
            return

    _execute_entry(ctx, "complete_task", entry_id=entry_id, task_id=task_id, data=data, dry_run=dry_run)


@entry_group.command("delete")
@click.option("--entry-id", required=True, help="Entry ID to delete.")
@click.option("--dry-run", is_flag=True, help="Preview without deleting.")
@pass_context
def entry_delete(ctx, entry_id, dry_run):
    """Delete an entry."""
    from src.cli.helpers import confirm_destructive

    if not dry_run and not confirm_destructive("delete", entry_id, ctx.json_mode):
        click.echo("Cancelled.", err=True)
        return

    _execute_entry(ctx, "delete", entry_id=entry_id, dry_run=dry_run)


def _execute_entry(
    ctx, operation, definition_id=None, entry_id=None, task_id=None, data=None, dry_run=False
):
    """Execute an entry operation."""
    from src.cli.helpers import make_client
    from src.formatters.json_fmt import format_json

    payload = {"operation": operation}
    if definition_id:
        payload["definition_id"] = definition_id
    if entry_id:
        payload["entry_id"] = entry_id
    if task_id:
        payload["task_id"] = task_id
    if data:
        payload["data"] = data

    if dry_run:
        dry_run_data = {"dry_run": True, "payload": payload}

        # For complete_task, fetch and show the task's form fields
        if operation == "complete_task" and task_id:
            try:
                client = make_client(ctx)
                task_result = asyncio.run(
                    client.request("GET", f"/api/v1/tasks/{task_id}")
                )
                task_data = task_result.get("data", {})
                definition = task_data.get("definition", [])
                fields = []
                if isinstance(definition, list):
                    for block in definition:
                        if block.get("type", "").startswith("form-"):
                            opts = block.get("options", {})
                            if opts.get("name"):
                                fields.append({
                                    "key": opts["name"],
                                    "label": opts.get("title", opts["name"]),
                                    "type": block["type"],
                                    "required": opts.get("required", False),
                                })
                if fields:
                    dry_run_data["task_fields"] = fields
                current_values = task_data.get("values", {})
                if current_values:
                    dry_run_data["current_values"] = current_values
            except Exception:
                pass  # Non-critical — still show the dry-run payload

        if ctx.json_mode:
            click.echo(format_json(dry_run_data, compact=True))
        else:
            click.echo(f"[dry-run] Would {operation} entry:")
            click.echo(format_json(dry_run_data))
        return

    client = make_client(ctx)

    try:
        result = asyncio.run(client.request("POST", "/api/v1/entries", json=payload))
    except Exception as e:
        handle_error(ctx, e)
        return

    # After record creation, enrich tasks with their form field definitions
    if operation == "create" and result.get("data", {}).get("tasks"):
        try:
            for task in result["data"]["tasks"]:
                task_detail = asyncio.run(
                    client.request("GET", f"/api/v1/tasks/{task['id']}")
                )
                task_def = task_detail.get("data", {}).get("definition", [])
                if isinstance(task_def, list):
                    fields = []
                    for block in task_def:
                        if block.get("type", "").startswith("form-"):
                            opts = block.get("options", {})
                            if opts.get("name"):
                                fields.append({
                                    "key": opts["name"],
                                    "label": opts.get("title", opts["name"]),
                                    "type": block["type"],
                                    "required": opts.get("required", False),
                                })
                    if fields:
                        task["fields"] = fields
        except Exception:
            pass  # Non-critical enrichment

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    else:
        d = result.get("data", {})
        click.echo(f"Entry {operation}: {d.get('id', d.get('entryId', ''))}")
