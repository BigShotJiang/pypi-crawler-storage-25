"""Root Click group for the Upscaler CLI.

Entry point: upscaler = src.cli.main:cli

Global flags:
    --json      Output structured JSON (for agent consumption)
    --verbose   Log HTTP request/response to stderr
    --server    Override REST API server URL
    --version   Print package version
"""

import importlib
import os
import sys
from typing import Optional

import click

import src


from src.cli.context import Context, pass_context  # noqa: F401


@click.group()
@click.option("--json", "json_mode", is_flag=True, help="Output structured JSON to stdout.")
@click.option("--verbose", "-v", is_flag=True, help="Log HTTP details to stderr.")
@click.option("--server", default=None, help="Override REST API server URL.")
@click.version_option(version=src.__version__, prog_name="upscaler")
@click.pass_context
def cli(ctx, json_mode, verbose, server):
    """Upscaler CLI — search, retrieve, and manage documents, records, and workflows."""
    ctx.ensure_object(Context)
    ctx.obj.json_mode = json_mode
    ctx.obj.verbose = verbose
    ctx.obj.server_url = server


@cli.command("health")
@click.pass_context
def health(ctx):
    """Check if the Upscaler API server is reachable.

    Examples:
        upscaler health
        upscaler --json health
        upscaler --server https://custom.example.com health
    """
    import asyncio
    import json
    import httpx

    from src.config import CLIConfig

    config = CLIConfig()
    server_url = config.resolve_server_url(ctx.obj.server_url)
    verify_ssl = config.resolve_verify_ssl()
    if not server_url:
        click.echo("Server URL not configured. Use --server or: upscaler config set server_url <url>",
                    err=True)
        sys.exit(1)

    try:
        response = asyncio.run(
            httpx.AsyncClient(verify=verify_ssl, timeout=5.0).get(f"{server_url}/health")
        )
        data = response.json()
        if ctx.obj.json_mode:
            click.echo(json.dumps({"success": True, "status": data.get("status"), "server": server_url}))
        else:
            click.echo(f"Server: {server_url}")
            click.echo(f"Status: {data.get('status', 'unknown')}")
    except Exception as e:
        if ctx.obj.json_mode:
            click.echo(json.dumps({"success": False, "error": str(e), "server": server_url}), err=True)
        else:
            click.echo(f"Server: {server_url}")
            click.echo(f"Status: unreachable ({e})", err=True)
        sys.exit(1)


@cli.command("skill-path")
def skill_path():
    """Print the absolute path to the bundled SKILL.md file."""
    skill_file = os.path.join(os.path.dirname(src.__file__), "SKILL.md")
    if os.path.exists(skill_file):
        click.echo(skill_file)
    else:
        click.echo("SKILL.md not found in package.", err=True)
        sys.exit(1)


# Register subcommands
from src.cli.asset import asset_group  # noqa: E402
from src.cli.auth import login, logout, refresh, status  # noqa: E402
from src.cli.completions import completions  # noqa: E402
from src.cli.config_cmd import config_group  # noqa: E402
from src.cli.entry import entry_group  # noqa: E402
from src.cli.get import get_asset  # noqa: E402
from src.cli.hierarchy import hierarchy  # noqa: E402
from src.cli.list_cmd import list_group  # noqa: E402
from src.cli.search import search  # noqa: E402
from src.cli.todo import todo_group  # noqa: E402

cli.add_command(login)
cli.add_command(refresh)
cli.add_command(status)
cli.add_command(logout)
cli.add_command(search)
cli.add_command(get_asset)
cli.add_command(hierarchy)
cli.add_command(list_group)
cli.add_command(todo_group)
cli.add_command(entry_group)
cli.add_command(asset_group)
cli.add_command(config_group)
cli.add_command(completions)
