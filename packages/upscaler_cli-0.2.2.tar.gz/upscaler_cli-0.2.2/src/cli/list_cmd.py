"""List command for definitions, entries, todos, field options."""

import asyncio

import click

from src.cli.context import Context, pass_context
from src.cli.helpers import handle_error


@click.group("list")
def list_group():
    """List definitions, entries, todos, or field options.

    Examples:
        upscaler list definitions
        upscaler list entries --definition-id rg_123
        upscaler --json list todos
        upscaler list field-options --definition-id rg_123 --field-key status
    """
    pass


@list_group.command("definitions")
@pass_context
def list_definitions(ctx):
    """List all definitions (registers, records)."""
    _do_list(ctx, type_name="definitions")


@list_group.command("entries")
@click.option("--definition-id", required=True, help="Definition ID to list entries for.")
@pass_context
def list_entries(ctx, definition_id):
    """List entries for a definition."""
    _do_list(ctx, type_name="entries", definition_id=definition_id)


@list_group.command("todos")
@pass_context
def list_todos(ctx):
    """List your todos."""
    _do_list(ctx, type_name="todos")


@list_group.command("field-options")
@click.option("--definition-id", required=True, help="Definition ID.")
@click.option("--field-key", required=True, help="Field key to get options for.")
@pass_context
def list_field_options(ctx, definition_id, field_key):
    """List field options for a definition field."""
    _do_list(ctx, type_name="field_options", definition_id=definition_id, field_key=field_key)


def _do_list(ctx, type_name, definition_id=None, field_key=None):
    """Shared list implementation."""
    from src.cli.helpers import make_client
    from src.formatters.json_fmt import format_json
    from src.formatters.table import format_table

    client = make_client(ctx)

    params = {"type": type_name}
    if definition_id:
        params["definition_id"] = definition_id
    if field_key:
        params["field_key"] = field_key

    try:
        result = asyncio.run(client.request("GET", "/api/v1/list", params=params))
    except Exception as e:
        handle_error(ctx, e)
        return

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    else:
        data = result.get("data", [])
        if isinstance(data, dict):
            data = data.get("items", [data])
        if not data:
            click.echo("No results.")
            return
        click.echo(format_table(data))
