"""Search command for document search."""

import asyncio

import click

from src.cli.context import Context, pass_context
from src.cli.helpers import handle_error


@click.command()
@click.argument("query")
@click.option("--limit", default=10, help="Number of results to return.")
@click.option("--type", "asset_type", default=None, help="Filter by asset type.")
@pass_context
def search(ctx, query, limit, asset_type):
    """Search Upscaler documents.

    Examples:
        upscaler search "safety procedures"
        upscaler search "compliance" --limit 5 --type policy
        upscaler --json search "audit"
    """
    from src.cli.helpers import make_client
    from src.formatters.json_fmt import format_json
    from src.formatters.table import format_table

    client = make_client(ctx)

    try:
        result = asyncio.run(client.request(
            "POST", "/api/v1/search",
            json={"query": query, "limit": limit, "asset_type": asset_type},
        ))
    except Exception as e:
        handle_error(ctx, e)
        return

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    else:
        data = result.get("data", [])
        if not data:
            click.echo("No results found.")
            return
        click.echo(format_table(
            data,
            columns=["score", "asset_id", "asset_title", "asset_type"],
        ))
