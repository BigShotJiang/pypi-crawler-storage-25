"""Asset management CLI commands."""

import asyncio
import sys

import click

from src.cli.context import Context, pass_context
from src.cli.helpers import handle_error


@click.group("asset")
def asset_group():
    """Manage assets: create, update, update-content, delete, set-permissions, add-to-release.

    Examples:
        upscaler asset create --type register_definition --data '{"title": "My Register"}'
        upscaler asset update --asset-id rg_123 --data '{"title": "New Title"}'
        upscaler asset delete --asset-id rg_123 --dry-run
    """
    pass


@asset_group.command("create")
@click.option("--type", "asset_type", required=True, help="Asset type to create.")
@click.option("--data", "data_input", required=True, help="JSON data (value, - for stdin, @file).")
@click.option("--dry-run", is_flag=True, help="Preview without creating.")
@pass_context
def asset_create(ctx, asset_type, data_input, dry_run):
    """Create a new asset."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_asset(ctx, "create", asset_type=asset_type, data=data, dry_run=dry_run)


@asset_group.command("update")
@click.option("--asset-id", required=True, help="Asset ID to update.")
@click.option("--data", "data_input", required=True, help="JSON data.")
@click.option("--dry-run", is_flag=True, help="Preview without updating.")
@pass_context
def asset_update(ctx, asset_id, data_input, dry_run):
    """Update asset metadata (title, description, icon)."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_asset(ctx, "update", asset_id=asset_id, data=data, dry_run=dry_run)


@asset_group.command("update-content")
@click.option("--asset-id", required=True, help="Asset ID to update content for.")
@click.option("--data", "data_input", required=True, help="JSON data with 'values' key.")
@click.option("--dry-run", is_flag=True, help="Preview without updating.")
@pass_context
def asset_update_content(ctx, asset_id, data_input, dry_run):
    """Update asset content (Slate JSON values)."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_asset(ctx, "update_content", asset_id=asset_id, data=data, dry_run=dry_run)


@asset_group.command("delete")
@click.option("--asset-id", required=True, help="Asset ID to delete.")
@click.option("--dry-run", is_flag=True, help="Preview without deleting.")
@pass_context
def asset_delete(ctx, asset_id, dry_run):
    """Delete an asset."""
    from src.cli.helpers import confirm_destructive

    if not dry_run and not confirm_destructive("delete", asset_id, ctx.json_mode):
        click.echo("Cancelled.", err=True)
        return

    _execute_asset(ctx, "delete", asset_id=asset_id, dry_run=dry_run)


@asset_group.command("set-permissions")
@click.option("--asset-id", required=True, help="Asset ID.")
@click.option("--data", "data_input", required=True, help="JSON permissions data.")
@pass_context
def asset_set_permissions(ctx, asset_id, data_input):
    """Set permissions on an asset."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_asset(ctx, "set_permissions", asset_id=asset_id, data=data)


@asset_group.command("add-to-release")
@click.option("--asset-id", required=True, help="Asset ID.")
@click.option("--data", "data_input", required=True, help="JSON release data.")
@pass_context
def asset_add_to_release(ctx, asset_id, data_input):
    """Add an asset to a release."""
    from src.cli.helpers import parse_data

    try:
        data = parse_data(data_input)
    except Exception as e:
        click.echo(str(e), err=True)
        sys.exit(1)
        return

    _execute_asset(ctx, "add_to_release", asset_id=asset_id, data=data)


def _execute_asset(ctx, operation, asset_id=None, asset_type=None, data=None, dry_run=False):
    """Execute an asset operation."""
    from src.cli.helpers import make_client
    from src.formatters.json_fmt import format_json

    payload = {"operation": operation}
    if asset_id:
        payload["asset_id"] = asset_id
    if asset_type:
        payload["asset_type"] = asset_type
    if data:
        payload["data"] = data

    if dry_run:
        if ctx.json_mode:
            click.echo(format_json({"dry_run": True, "payload": payload}, compact=True))
        else:
            click.echo(f"[dry-run] Would {operation} asset:")
            click.echo(format_json(payload))
        return

    client = make_client(ctx)

    try:
        result = asyncio.run(client.request("POST", "/api/v1/assets", json=payload))
    except Exception as e:
        handle_error(ctx, e)
        return

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    else:
        d = result.get("data", {})
        click.echo(f"Asset {operation}: {d.get('assetId', d.get('asset_id', ''))}")
