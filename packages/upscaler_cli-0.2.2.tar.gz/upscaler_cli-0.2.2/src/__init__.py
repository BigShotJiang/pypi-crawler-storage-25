"""Upscaler CLI — search, retrieve, and manage Upscaler content."""

__version__ = "0.2.2"
