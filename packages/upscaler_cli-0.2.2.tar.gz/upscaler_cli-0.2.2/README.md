# Upscaler CLI

Command-line tool for searching, retrieving, and managing Upscaler documents, records, and workflows.

## Install

```bash
pip install upscaler-cli
```

## Setup

```bash
upscaler config set server_url https://your-upscaler-api.com
upscaler login
```

For dev/staging with self-signed certificates:

```bash
upscaler config set verify_ssl false
```

## Quick Start

```bash
# Check connection
upscaler health

# Search documents
upscaler search "safety procedures"

# Get an asset
upscaler get rg_abc123
upscaler get rg_abc123 --format schema
upscaler get rg_abc123 --format markdown

# List data
upscaler list definitions
upscaler list entries --definition-id rg_abc123
upscaler list todos

# View hierarchy
upscaler hierarchy d_abc123

# Manage todos
upscaler todo create --title "Review document"
upscaler todo close to_abc123

# Manage entries
upscaler entry create --definition-id rg_abc123 --data '{"title": "New item"}'
upscaler entry create --definition-id rg_abc123 --data @payload.json

# Get members and groups
upscaler get <firebase_uid> --type member
upscaler get g_abc123
```

## Global Flags

Global flags go **before** the command:

```bash
upscaler --json list todos          # JSON output
upscaler --verbose search "audit"   # show HTTP details
upscaler --server https://... health  # override server URL
upscaler --version                  # print version
```

## Write Safety

Preview changes before committing:

```bash
upscaler entry create --definition-id rg_123 --data @payload.json --dry-run
upscaler asset delete --asset-id rg_123 --dry-run
```

## Data Input

Write commands accept `--data` in three forms:

```bash
--data '{"key": "value"}'          # inline JSON
--data @payload.json               # from file (recommended)
--data -                           # from stdin
```

## Configuration

```bash
upscaler config set server_url https://api.example.com
upscaler config set verify_ssl false
upscaler config get server_url
```

Settings stored at `~/.upscaler/config.json`. Overridden by environment variables (`UPSCALER_SERVER`, `UPSCALER_VERIFY_SSL`) and flags (`--server`).

## Auth Commands

```bash
upscaler login       # browser-based OAuth2 login
upscaler status      # check auth state + token expiry
upscaler refresh     # refresh expired token
upscaler logout      # revoke and clear tokens
```

## All Commands

Run `upscaler --help` for the full command list, or `upscaler <command> --help` for details on any command.
