"""Utility functions (internal)."""
