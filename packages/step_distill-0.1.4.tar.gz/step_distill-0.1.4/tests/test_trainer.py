import os
import shutil
import pytest
import torch

from step_distill.config import StepDistillConfig
from step_distill.core.trainer import StepAwareTrainer

class DummyDataset(torch.utils.data.Dataset):
    def __init__(self, size=5, seq_len=64):
        self.size = size
        self.seq_len = seq_len
        self.vocab_size = 100

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        input_ids = torch.randint(0, self.vocab_size, (self.seq_len,))
        attention_mask = torch.ones(self.seq_len)
        labels = input_ids.clone()
        
        # Valid input format required by Trainer and Loss
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels,
            "mask_understand": torch.ones(self.seq_len, dtype=torch.bool),
            "mask_plan": torch.zeros(self.seq_len, dtype=torch.bool),
            "mask_execute": torch.zeros(self.seq_len, dtype=torch.bool),
            "mask_verify": torch.zeros(self.seq_len, dtype=torch.bool),
        }

def test_trainer_smoke(tmp_path):
    """10-step smoke test. TrainingResult has fields, checkpoint saved, no OOM on CPU."""
    # Use PyTorch dummy config
    import yaml
    config_dict = {
        "student_model": "HuggingFaceM4/tiny-random-LlamaForCausalLM", 
        "loss_weights": {
            "alpha": 0.15,
            "beta": 0.35,
            "gamma": 0.35,
            "delta": 0.15,
            "epsilon": 0.10
        },
        "lora": {
            "rank": 8,
            "alpha": 16,
            "dropout": 0.05
        },
        "training": {
            "batch_size": 1,
            "gradient_accumulation_steps": 1,
            "learning_rate": 1e-4,
            "weight_decay": 0.01,
            "epochs": 2
        }
    }
    
    # Write to a tmp yaml and load
    config_path = tmp_path / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config_dict, f)
        
    config = StepDistillConfig.from_yaml(config_path)
    
    dataset = DummyDataset(size=5, seq_len=64)
    trainer = StepAwareTrainer(config=config, train_data=dataset)
    
    output_dir = str(tmp_path / "checkpoints")
    result = trainer.train(output_dir)
    
    # Assert fields 
    assert hasattr(result, "final_loss")
    assert hasattr(result, "best_checkpoint")
    assert hasattr(result, "per_step_accuracy")
    assert hasattr(result, "training_time_minutes")
    assert isinstance(result.per_step_accuracy, dict)
    assert result.training_time_minutes > 0.0
    
    # Assert checkpoint saved
    checkpoint_dirs = [d for d in os.listdir(output_dir) if "checkpoint" in d]
    assert len(checkpoint_dirs) > 0
    
    # Cleanup 
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
