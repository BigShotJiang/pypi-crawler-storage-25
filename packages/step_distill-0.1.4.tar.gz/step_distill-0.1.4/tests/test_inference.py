"""Tests for Phase 9 — NanoReason Inference Wrapper."""

import os
import pytest
from unittest.mock import MagicMock, patch, PropertyMock

from step_distill.core.inference import NanoReason, ReasoningResult, _extract_boxed_answer


# ── Unit: answer extraction ─────────────────────────────────────────────

class TestExtractBoxedAnswer:
    def test_boxed(self):
        assert _extract_boxed_answer("The answer is \\boxed{18}.") == "18"

    def test_boxed_nested(self):
        assert _extract_boxed_answer("\\boxed{\\frac{1}{2}}") == "\\frac{1}{2}"

    def test_the_answer_is(self):
        assert _extract_boxed_answer("The answer is 42.") == "42"

    def test_last_number_fallback(self):
        assert _extract_boxed_answer("result equals 99") == "99"

    def test_empty(self):
        assert _extract_boxed_answer("") == ""


# ── Unit: step extraction ───────────────────────────────────────────────

def test_extract_steps():
    nano = NanoReason(model=None, tokenizer=None)

    response = (
        "Some intro text.\n"
        "#### UNDERSTAND ####\nI need to add 2 and 2.\n"
        "#### PLAN ####\n1. add 2 and 2\n"
        "#### EXECUTE ####\n2+2=4\n"
        "#### VERIFY ####\n4 is correct."
    )

    steps = nano._extract_steps(response)

    assert steps["understand"] == "I need to add 2 and 2."
    assert steps["plan"] == "1. add 2 and 2"
    assert steps["execute"] == "2+2=4"
    assert steps["verify"] == "4 is correct."


# ── Unit: ReasoningResult repr ──────────────────────────────────────────

def test_reasoning_result_repr():
    """repr shows all 4 boxes."""
    result = ReasoningResult(
        answer="18",
        steps={
            "understand": "Janet has 16 eggs per day",
            "plan": "Compute eggs remaining after eating and baking",
            "execute": "16 - 3 - 4 = 9 eggs, 9 * 2 = 18",
            "verify": "Check: 9 eggs at $2 = $18",
        },
        rfs=1.0,
        raw_output="...",
        generation_time_s=1.23,
    )
    text = repr(result)
    assert "UNDERSTAND" in text
    assert "PLAN" in text
    assert "EXECUTE" in text
    assert "VERIFY" in text
    assert "Answer: 18" in text
    assert "100%" in text


# ── Integration: from_pretrained ────────────────────────────────────────

@patch("step_distill.core.inference.AutoModelForCausalLM")
@patch("step_distill.core.inference.AutoTokenizer")
def test_from_pretrained_non_peft(mock_tokenizer, mock_model):
    mock_model.from_pretrained.return_value = MagicMock()
    mock_tokenizer.from_pretrained.return_value = MagicMock()

    with patch("os.path.exists", return_value=False):
        reasoner = NanoReason.from_pretrained("dummy-model")

        assert reasoner.model is not None
        assert reasoner.tokenizer is not None
        mock_model.from_pretrained.assert_called_once()
        mock_tokenizer.from_pretrained.assert_called_once()


# ── Integration: solve with mocked model ────────────────────────────────

@patch("step_distill.core.inference.AutoModelForCausalLM")
@patch("step_distill.core.inference.AutoTokenizer")
def test_solve_rfs_calculation(mock_tokenizer, mock_model):
    reasoner = NanoReason(model=MagicMock(), tokenizer=MagicMock())

    response = (
        "#### UNDERSTAND ####\nSome understanding with more than ten chars.\n"
        "#### EXECUTE ####\nSome execution with more than ten chars."
    )

    mock_outputs = [[0, 1, 2]]
    reasoner.model.generate.return_value = mock_outputs
    reasoner.tokenizer.decode.return_value = response

    mock_inputs = MagicMock()
    mock_inputs.input_ids.shape = (1, 1)
    reasoner.tokenizer.return_value.to.return_value = mock_inputs

    result = reasoner.solve("test")

    # Only 2 out of 4 stages => rfs = 0.5
    assert result.rfs == 0.5
    assert result.raw_output == response
    assert result.generation_time_s >= 0


# ── Integration: solve_batch ────────────────────────────────────────────

@patch("step_distill.core.inference.AutoModelForCausalLM")
@patch("step_distill.core.inference.AutoTokenizer")
def test_solve_batch(mock_tokenizer, mock_model):
    reasoner = NanoReason(model=MagicMock(), tokenizer=MagicMock())

    response = (
        "#### UNDERSTAND ####\nSome understanding with more than ten chars.\n"
        "#### PLAN ####\nSome planning with more than ten chars.\n"
        "#### EXECUTE ####\n2+2=4 with more than ten chars of working.\n"
        "#### VERIFY ####\nVerification with more than ten chars.\n"
        "The answer is \\boxed{4}"
    )

    mock_outputs = [[0, 1, 2]]
    reasoner.model.generate.return_value = mock_outputs
    reasoner.tokenizer.decode.return_value = response

    mock_inputs = MagicMock()
    mock_inputs.input_ids.shape = (1, 1)
    reasoner.tokenizer.return_value.to.return_value = mock_inputs

    results = reasoner.solve_batch(["q1", "q2"])
    assert len(results) == 2
    assert all(isinstance(r, ReasoningResult) for r in results)
    assert results[0].answer == "4"


# ── E2E: Quick Start (requires real weights) ────────────────────────────

MODEL_AVAILABLE = os.path.exists("NanoReason-3B") or os.environ.get("NANOREASON_WEIGHTS")


@pytest.mark.skipif(not MODEL_AVAILABLE, reason="Requires NanoReason-3B weights")
def test_quick_start():
    """The exact Quick Start code from README must run end-to-end."""
    model = NanoReason.from_pretrained("ductaiphan/NanoReason-3B")
    result = model.solve(
        "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast "
        "and bakes muffins with 4. She sells the rest at $2/egg. "
        "How much does she make daily?"
    )
    assert result.answer == "18"
    assert result.rfs == 1.0
    assert all(k in result.steps for k in ["understand", "plan", "execute", "verify"])


@pytest.mark.skipif(not MODEL_AVAILABLE, reason="Requires NanoReason-3B weights")
@pytest.mark.asyncio
async def test_stream_yields_stage_names():
    """solve_stream yields correct stage names."""
    model = NanoReason.from_pretrained("ductaiphan/NanoReason-3B")
    stages_seen = set()
    async for token, stage in model.solve_stream("What is 2+2?"):
        stages_seen.add(stage)
    assert "understand" in stages_seen
    assert "execute" in stages_seen
