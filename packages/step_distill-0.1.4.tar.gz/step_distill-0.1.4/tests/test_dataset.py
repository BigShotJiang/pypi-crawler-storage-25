"""Tests for StepAwareDataset."""

import json
import pytest
import torch
import numpy as np

from step_distill.core.dataset import StepAwareDataset
from step_distill.core.parser import LabelMatrixParser


class MockTokenizer:
    """Mock fast tokenizer for dataset testing."""

    def __init__(self, vocab_size=1000):
        self.vocab_size = vocab_size
        self.pad_token = "[PAD]"
        self.pad_token_id = 0
        self.eos_token = "[EOS]"
        self.eos_token_id = 1
        self.padding_side = "right"

    def __call__(self, text, max_length=None, truncation=False, padding=False, return_tensors=None, return_offsets_mapping=False, add_special_tokens=True):
        length = len(text)
        original_length = length // 4
        
        if return_offsets_mapping:
            offsets = [(i*4, (i+1)*4) for i in range(original_length)]
            return {
                "input_ids": [10] * original_length,
                "attention_mask": [1] * original_length,
                "offset_mapping": offsets,
            }

        input_ids = [10] * original_length
        attention_mask = [1] * original_length

        if truncation and max_length is not None and len(input_ids) > max_length:
            input_ids = input_ids[:max_length]
            attention_mask = attention_mask[:max_length]
            
        if padding == "max_length" and max_length is not None and len(input_ids) < max_length:
            pad_len = max_length - len(input_ids)
            input_ids = input_ids + [self.pad_token_id] * pad_len
            attention_mask = attention_mask + [0] * pad_len

        if return_tensors == "pt":
            return {
                "input_ids": torch.tensor([input_ids]),
                "attention_mask": torch.tensor([attention_mask]),
            }

        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }

@pytest.fixture
def sample_jsonl(tmp_path):
    """Creates a temporary sample .jsonl file."""
    data = [
        {
            "question": "What is 2+2?",
            "ground_truth": "4",
            "is_correct": True,
            "cot_4steps": {
                "understand": "I need to add 2 and 2.",
                "plan": "Use addition.",
                "execute": "2 + 2 = 4.",
                "verify": "Yes, 4 is correct."
            }
        },
        {
            "question": "Invalid item",
            "ground_truth": "0",
            "is_correct": False,
            "cot_4steps": {
                "understand": "Missing plan"
            }
        }
    ]
    file_path = tmp_path / "sample.jsonl"
    with open(file_path, "w", encoding="utf-8") as f:
        for item in data:
            f.write(json.dumps(item) + "\n")
    return file_path


def test_dataset_loading_and_filtering(sample_jsonl):
    """Test that dataset properly filters invalid and incorrect entries."""
    tokenizer = MockTokenizer()
    dataset = StepAwareDataset(sample_jsonl, tokenizer, filter_correct_only=True)
    
    # Second item must be filtered out
    assert len(dataset) == 1
    assert dataset.samples[0]["ground_truth"] == "4"


def test_dataset_gets_full_text(sample_jsonl):
    """Test full text formatting."""
    tokenizer = MockTokenizer()
    dataset = StepAwareDataset(sample_jsonl, tokenizer)
    
    full_text = dataset.get_full_text(dataset.samples[0])
    assert "Question: What is 2+2?" in full_text
    assert "#### UNDERSTAND ####" in full_text
    assert "#### PLAN ####" in full_text
    assert "#### EXECUTE ####" in full_text
    assert "#### VERIFY ####" in full_text
    assert "Final Answer: 4" in full_text


def test_dataset_getitem_padding_and_truncation(sample_jsonl):
    """Test that dataset tensors match max_length properly padded."""
    tokenizer = MockTokenizer()
    max_length = 128
    dataset = StepAwareDataset(sample_jsonl, tokenizer, max_length=max_length)
    
    item = dataset[0]
    
    assert item["input_ids"].shape == (max_length,)
    assert item["attention_mask"].shape == (max_length,)
    assert item["labels"].shape == (max_length,)
    
    for key in LabelMatrixParser.STAGE_KEYS:
        mask_key = f"mask_{key}"
        assert mask_key in item
        assert item[mask_key].shape == (max_length,)
        assert item[mask_key].dtype == torch.bool
        
    # Test labels padding
    # Where attention_mask is 0, labels should be -100
    pad_mask = item["attention_mask"] == 0
    assert torch.all(item["labels"][pad_mask] == -100)
    
    # Labels where attention mask is 1 should match input_ids
    valid_mask = item["attention_mask"] == 1
    assert torch.all(item["labels"][valid_mask] == item["input_ids"][valid_mask])
