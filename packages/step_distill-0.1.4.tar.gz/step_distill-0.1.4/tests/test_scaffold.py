"""
Phase 1 scaffold tests.

These tests verify that the project scaffold is correctly set up:
- All public names are importable
- Version is correct
- __all__ is consistent
- CLI entry point works
- Stub classes raise NotImplementedError
"""

import subprocess
import sys

import pytest


def test_import():
    """All 5 public classes must be importable from step_distill."""
    from step_distill import (
        Evaluator,
        NanoReason,
        StepAwareTrainer,
        StepDistillConfig,
        TeacherPipeline,
    )

    assert NanoReason is not None
    assert StepAwareTrainer is not None
    assert StepDistillConfig is not None
    assert Evaluator is not None
    assert TeacherPipeline is not None


def test_version():
    """Package version must be 0.1.0."""
    from step_distill import __version__

    assert __version__ == "0.1.0"


def test_all_exports():
    """Every name in __all__ must exist as an attribute on the module."""
    import step_distill

    assert hasattr(step_distill, "__all__")
    assert len(step_distill.__all__) == 5
    assert all(hasattr(step_distill, name) for name in step_distill.__all__)


def test_cli_help():
    """Running `step-distill --help` must exit with code 0."""
    result = subprocess.run(
        [sys.executable, "-m", "step_distill.cli.main", "--help"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0
    assert "step-distill" in result.stdout.lower() or "distill" in result.stdout.lower()


def test_stubs_raise():
    """Stub classes (not yet implemented) must raise NotImplementedError when instantiated."""
    from step_distill import (
        Evaluator,
        NanoReason,
        StepAwareTrainer,
        TeacherPipeline,
    )

    with pytest.raises(NotImplementedError):
        NanoReason()

    with pytest.raises(NotImplementedError):
        StepAwareTrainer()

    with pytest.raises(NotImplementedError):
        Evaluator()

    with pytest.raises(NotImplementedError):
        TeacherPipeline()


def test_config_is_real():
    """StepDistillConfig should now be a real Pydantic model (Phase 2)."""
    from step_distill import StepDistillConfig

    config = StepDistillConfig()
    assert config.student_model == "Qwen/Qwen2.5-3B-Instruct"

