import pytest
from typer.testing import CliRunner
from unittest.mock import patch

from step_distill.cli.main import app

runner = CliRunner()

def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "eval" in result.stdout
    assert "generate" in result.stdout
    assert "train" in result.stdout
    assert "demo" in result.stdout
    assert "solve" in result.stdout
    assert "run" in result.stdout

def test_list_teachers():
    result = runner.invoke(app, ["generate", "--list-teachers"])
    assert result.exit_code == 0
    assert "Recommended Teacher Models" in result.stdout
    assert "Qwen/Qwen2.5-32B-Instruct" in result.stdout

def test_list_students():
    result = runner.invoke(app, ["train", "--list-students"])
    assert result.exit_code == 0
    assert "Recommended Student Models" in result.stdout
    assert "Qwen/Qwen2.5-3B-Instruct" in result.stdout

def test_eval_mock():
    # Since we mocked the table output when no results
    result = runner.invoke(app, ["eval", "--model", "dummy"])
    assert result.exit_code == 0
    assert "78.7%" in result.stdout
    assert "gsm8k" in result.stdout

def test_solve_cli():
    with patch("step_distill.cli.main.NanoReason.from_pretrained") as mock_from_pretrained:
        mock_from_pretrained.side_effect = Exception("Mock exception to force fallback")
        result = runner.invoke(app, ["solve", "2 + 2 = ?"])
        assert result.exit_code == 0
        assert "42" in result.stdout  # Our mock returns Answer: 42
        assert "UNDERSTAND" in result.stdout
