"""
Phase 3 parser tests.

Tests for LabelMatrixParser:
- Perfect 4-stage text parsing
- Character-level stage segmentation
- Token-level mask generation (with mock tokenizer)
- Edge cases: missing stages, wrong order, partial tags, empty text, no tags
- Tag format validation
- Stage order validation
- Build tagged text from dict
- Sample traces parsing
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pytest

from step_distill.core.parser import (
    STAGE_ORDER,
    LabelMatrixParser,
    StepType,
)


# ---------------------------------------------------------------------------
# Mock tokenizer for testing without HuggingFace dependency
# ---------------------------------------------------------------------------


class MockTokenizer:
    """Word-level tokenizer that mimics HuggingFace tokenizer interface.

    Splits on whitespace boundaries. Produces offset_mapping compatible
    with LabelMatrixParser.parse().
    """

    def __call__(
        self,
        text: str,
        return_offsets_mapping: bool = False,
        add_special_tokens: bool = True,
    ) -> dict[str, Any]:
        tokens: list[str] = []
        offsets: list[tuple[int, int]] = []

        i = 0
        while i < len(text):
            # Skip leading whitespace but include it as part of next token
            # Actually, split into word tokens only (skip whitespace)
            if text[i].isspace():
                i += 1
                continue
            # Find end of non-whitespace token
            j = i
            while j < len(text) and not text[j].isspace():
                j += 1
            tokens.append(text[i:j])
            offsets.append((i, j))
            i = j

        result: dict[str, Any] = {
            "input_ids": list(range(len(tokens))),
        }
        if return_offsets_mapping:
            result["offset_mapping"] = offsets
        return result


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def parser() -> LabelMatrixParser:
    return LabelMatrixParser()


@pytest.fixture
def tokenizer() -> MockTokenizer:
    return MockTokenizer()


PERFECT_4STAGE = (
    "#### UNDERSTAND ####\n"
    "Given: 16 eggs per day, eat 3, bake 4, sell at $2\n"
    "Goal: calculate daily earnings\n"
    "#### PLAN ####\n"
    "Step 1: remaining = 16 - 3 - 4\n"
    "Step 2: earnings = remaining * $2\n"
    "#### EXECUTE ####\n"
    "16 - 3 = 13, 13 - 4 = 9, 9 * 2 = 18\n"
    "#### VERIFY ####\n"
    "Back-check: 9 * $2 = $18 correct"
)


# ---------------------------------------------------------------------------
# StepType
# ---------------------------------------------------------------------------


class TestStepType:
    def test_tag_format(self):
        """Tags must use exact format: #### NAME ####"""
        assert StepType.UNDERSTAND.tag == "#### UNDERSTAND ####"
        assert StepType.PLAN.tag == "#### PLAN ####"
        assert StepType.EXECUTE.tag == "#### EXECUTE ####"
        assert StepType.VERIFY.tag == "#### VERIFY ####"

    def test_ignore_has_no_tag(self):
        assert StepType.IGNORE.tag == ""

    def test_values(self):
        assert StepType.UNDERSTAND.value == "understand"
        assert StepType.PLAN.value == "plan"
        assert StepType.EXECUTE.value == "execute"
        assert StepType.VERIFY.value == "verify"
        assert StepType.IGNORE.value == "ignore"

    def test_stage_order(self):
        assert STAGE_ORDER == [
            StepType.UNDERSTAND,
            StepType.PLAN,
            StepType.EXECUTE,
            StepType.VERIFY,
        ]


# ---------------------------------------------------------------------------
# parse_stages — Tier 1 + 2 text-level parsing
# ---------------------------------------------------------------------------


class TestParseStages:
    def test_perfect_4stage(self, parser: LabelMatrixParser):
        """Standard 4-stage text should produce correct segments."""
        segments = parser.parse_stages(PERFECT_4STAGE)

        # Extract non-IGNORE stages
        stages = [s for s, _, _ in segments if s != StepType.IGNORE]
        assert stages == [
            StepType.UNDERSTAND,
            StepType.PLAN,
            StepType.EXECUTE,
            StepType.VERIFY,
        ]

    def test_segments_cover_entire_text(self, parser: LabelMatrixParser):
        """Segments should cover every character, no gaps."""
        segments = parser.parse_stages(PERFECT_4STAGE)

        # First segment starts at 0
        assert segments[0][1] == 0
        # Last segment ends at len(text)
        assert segments[-1][2] == len(PERFECT_4STAGE)

        # No gaps between consecutive segments
        for i in range(len(segments) - 1):
            assert segments[i][2] == segments[i + 1][1], (
                f"Gap between segment {i} (end={segments[i][2]}) "
                f"and segment {i+1} (start={segments[i+1][1]})"
            )

    def test_tags_are_ignore(self, parser: LabelMatrixParser):
        """Tag tokens (#### STAGE ####) should be classified as IGNORE."""
        text = "#### UNDERSTAND ####\nsome content"
        segments = parser.parse_stages(text)

        # First segment is the tag → IGNORE
        assert segments[0][0] == StepType.IGNORE
        tag_text = text[segments[0][1] : segments[0][2]]
        assert "#### UNDERSTAND ####" in tag_text

    def test_empty_text(self, parser: LabelMatrixParser):
        """Empty string should return empty segments."""
        segments = parser.parse_stages("")
        assert segments == []

    def test_no_tags(self, parser: LabelMatrixParser):
        """Text without tags should be entirely IGNORE."""
        text = "This is just regular text without any tags."
        segments = parser.parse_stages(text)
        assert len(segments) == 1
        assert segments[0] == (StepType.IGNORE, 0, len(text))

    def test_missing_stages(self, parser: LabelMatrixParser):
        """Text with only some stages should work correctly."""
        text = (
            "#### UNDERSTAND ####\n"
            "Some understanding\n"
            "#### EXECUTE ####\n"
            "Some execution"
        )
        segments = parser.parse_stages(text)
        stages = [s for s, _, _ in segments if s != StepType.IGNORE]
        assert stages == [StepType.UNDERSTAND, StepType.EXECUTE]

    def test_wrong_order(self, parser: LabelMatrixParser):
        """Stages in wrong order should still be classified by position."""
        text = (
            "#### EXECUTE ####\n"
            "Executing first\n"
            "#### UNDERSTAND ####\n"
            "Understanding second"
        )
        segments = parser.parse_stages(text)
        stages = [s for s, _, _ in segments if s != StepType.IGNORE]
        assert stages == [StepType.EXECUTE, StepType.UNDERSTAND]

    def test_partial_tag_not_matched(self, parser: LabelMatrixParser):
        """Partial tag (missing closing ####) should not match."""
        text = "#### UNDERSTAND\nThis should be all ignore"
        segments = parser.parse_stages(text)
        assert len(segments) == 1
        assert segments[0][0] == StepType.IGNORE

    def test_case_sensitive(self, parser: LabelMatrixParser):
        """Tags must be uppercase — lowercase should not match."""
        text = "#### understand ####\nsome content"
        segments = parser.parse_stages(text)
        assert len(segments) == 1
        assert segments[0][0] == StepType.IGNORE

    def test_content_before_first_tag(self, parser: LabelMatrixParser):
        """Content before the first tag should be IGNORE."""
        text = "Preamble text\n#### UNDERSTAND ####\nActual content"
        segments = parser.parse_stages(text)
        # First segment is preamble → IGNORE
        assert segments[0][0] == StepType.IGNORE
        preamble = text[segments[0][1] : segments[0][2]]
        assert "Preamble" in preamble


# ---------------------------------------------------------------------------
# get_stage_texts
# ---------------------------------------------------------------------------


class TestGetStageTexts:
    def test_extracts_all_4_stages(self, parser: LabelMatrixParser):
        stage_texts = parser.get_stage_texts(PERFECT_4STAGE)
        assert "understand" in stage_texts
        assert "plan" in stage_texts
        assert "execute" in stage_texts
        assert "verify" in stage_texts

    def test_content_is_correct(self, parser: LabelMatrixParser):
        text = "#### UNDERSTAND ####\nHello world\n#### PLAN ####\nMy plan"
        stage_texts = parser.get_stage_texts(text)
        assert "Hello world" in stage_texts["understand"]
        assert "My plan" in stage_texts["plan"]

    def test_no_tags_returns_empty(self, parser: LabelMatrixParser):
        stage_texts = parser.get_stage_texts("No tags here")
        assert stage_texts == {}


# ---------------------------------------------------------------------------
# Stage order validation
# ---------------------------------------------------------------------------


class TestStageOrder:
    def test_valid_order(self, parser: LabelMatrixParser):
        assert parser.has_valid_order(PERFECT_4STAGE) is True

    def test_wrong_order(self, parser: LabelMatrixParser):
        text = "#### PLAN ####\nplan\n#### UNDERSTAND ####\nunderstand"
        assert parser.has_valid_order(text) is False

    def test_sparse_valid_order(self, parser: LabelMatrixParser):
        """U → E → V is valid (missing P)."""
        text = (
            "#### UNDERSTAND ####\nu\n"
            "#### EXECUTE ####\ne\n"
            "#### VERIFY ####\nv"
        )
        assert parser.has_valid_order(text) is True

    def test_no_tags_is_valid(self, parser: LabelMatrixParser):
        assert parser.has_valid_order("no tags") is True

    def test_get_stage_order(self, parser: LabelMatrixParser):
        order = parser.get_stage_order(PERFECT_4STAGE)
        assert order == [
            StepType.UNDERSTAND,
            StepType.PLAN,
            StepType.EXECUTE,
            StepType.VERIFY,
        ]


# ---------------------------------------------------------------------------
# parse — Token-level masks with mock tokenizer
# ---------------------------------------------------------------------------


class TestParseTokenLevel:
    def test_returns_all_5_keys(self, parser: LabelMatrixParser, tokenizer: MockTokenizer):
        masks = parser.parse(PERFECT_4STAGE, tokenizer)
        assert set(masks.keys()) == {"understand", "plan", "execute", "verify", "ignore"}

    def test_masks_are_boolean_arrays(self, parser: LabelMatrixParser, tokenizer: MockTokenizer):
        masks = parser.parse(PERFECT_4STAGE, tokenizer)
        for key, mask in masks.items():
            assert isinstance(mask, np.ndarray), f"{key} is not ndarray"
            assert mask.dtype == bool, f"{key} dtype is {mask.dtype}, expected bool"

    def test_every_token_assigned_exactly_once(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer
    ):
        """Each token should be in exactly one stage."""
        masks = parser.parse(PERFECT_4STAGE, tokenizer)
        num_tokens = len(masks["understand"])

        for i in range(num_tokens):
            count = sum(masks[key][i] for key in masks)
            assert count == 1, (
                f"Token {i} is in {count} stages, expected exactly 1"
            )

    def test_stage_masks_are_nonempty(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer
    ):
        """In a perfect 4-stage text, all 4 stage masks should have at least 1 token."""
        masks = parser.parse(PERFECT_4STAGE, tokenizer)
        for stage in ["understand", "plan", "execute", "verify"]:
            assert masks[stage].any(), f"Stage '{stage}' mask is all False"

    def test_ignore_mask_contains_tags(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer
    ):
        """Tag tokens (####, UNDERSTAND, etc.) should be in the IGNORE mask."""
        masks = parser.parse(PERFECT_4STAGE, tokenizer)
        assert masks["ignore"].any(), "IGNORE mask should have at least tag tokens"

    def test_no_tags_all_ignore(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer
    ):
        """Text without tags should have all tokens as IGNORE."""
        text = "This is just plain text with no tags"
        masks = parser.parse(text, tokenizer)
        assert masks["ignore"].all()
        assert not masks["understand"].any()
        assert not masks["plan"].any()
        assert not masks["execute"].any()
        assert not masks["verify"].any()

    def test_missing_stages_empty_masks(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer
    ):
        """Only present stages should have non-zero masks."""
        text = "#### UNDERSTAND ####\nContent\n#### VERIFY ####\nVerification"
        masks = parser.parse(text, tokenizer)
        assert masks["understand"].any()
        assert masks["verify"].any()
        assert not masks["plan"].any()
        assert not masks["execute"].any()

    def test_tokenizer_without_offset_mapping_raises(self, parser: LabelMatrixParser):
        """Tokenizer that doesn't support offset_mapping should raise ValueError."""

        class BadTokenizer:
            def __call__(self, text, **kwargs):
                return {"input_ids": [1, 2, 3]}

        with pytest.raises(ValueError, match="return_offsets_mapping"):
            parser.parse("#### UNDERSTAND ####\ntext", BadTokenizer())


# ---------------------------------------------------------------------------
# build_tagged_text
# ---------------------------------------------------------------------------


class TestBuildTaggedText:
    def test_round_trip(self, parser: LabelMatrixParser):
        """Build tagged text from dict, then parse it back."""
        cot_4steps = {
            "understand": "Given eggs and costs",
            "plan": "Calculate remaining then multiply",
            "execute": "16 - 3 - 4 = 9, 9 * 2 = 18",
            "verify": "Back check: correct",
        }
        text = LabelMatrixParser.build_tagged_text(cot_4steps)

        # All 4 tags should be present
        assert "#### UNDERSTAND ####" in text
        assert "#### PLAN ####" in text
        assert "#### EXECUTE ####" in text
        assert "#### VERIFY ####" in text

        # Parse back
        stage_texts = parser.get_stage_texts(text)
        assert "eggs" in stage_texts["understand"]
        assert "Calculate" in stage_texts["plan"]
        assert "16 - 3 - 4" in stage_texts["execute"]
        assert "correct" in stage_texts["verify"]

    def test_missing_stage_in_dict(self, parser: LabelMatrixParser):
        """Missing keys in dict should be skipped."""
        cot_4steps = {
            "understand": "Some content",
            "execute": "Some execution",
        }
        text = LabelMatrixParser.build_tagged_text(cot_4steps)
        assert "#### UNDERSTAND ####" in text
        assert "#### EXECUTE ####" in text
        assert "#### PLAN ####" not in text
        assert "#### VERIFY ####" not in text

    def test_valid_order_maintained(self, parser: LabelMatrixParser):
        """build_tagged_text should always produce canonical order."""
        cot_4steps = {
            "verify": "V",
            "understand": "U",
            "execute": "E",
            "plan": "P",
        }
        text = LabelMatrixParser.build_tagged_text(cot_4steps)
        assert parser.has_valid_order(text) is True

    def test_empty_stage_skipped(self, parser: LabelMatrixParser):
        """Stages with empty or whitespace-only content should be skipped."""
        cot_4steps = {
            "understand": "Content",
            "plan": "",
            "execute": "   ",
            "verify": "Check",
        }
        text = LabelMatrixParser.build_tagged_text(cot_4steps)
        assert "#### PLAN ####" not in text
        assert "#### EXECUTE ####" not in text


# ---------------------------------------------------------------------------
# Sample trace parsing (mimics data/sample_traces.jsonl)
# ---------------------------------------------------------------------------


class TestSampleTraces:
    """Test with realistic sample traces matching the project data format."""

    @pytest.fixture
    def sample_traces(self) -> list[dict]:
        import json
        from pathlib import Path
        
        data_file = Path(__file__).parent.parent / "data" / "sample_traces.jsonl"
        traces = []
        with open(data_file, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    traces.append(json.loads(line))
        return traces

    def test_all_samples_parse_correctly(self, parser: LabelMatrixParser, tokenizer: MockTokenizer, sample_traces: list[dict]):
        """All sample traces should parse with 4 non-empty stage masks."""
        for sample in sample_traces:
            text = LabelMatrixParser.build_tagged_text(sample["cot_4steps"])
            masks = parser.parse(text, tokenizer)

            for stage in ["understand", "plan", "execute", "verify"]:
                assert masks[stage].any(), (
                    f"Sample {sample['id']}: stage '{stage}' mask is empty"
                )

    def test_all_samples_valid_order(self, parser: LabelMatrixParser, sample_traces: list[dict]):
        """All sample traces should have valid stage order."""
        for sample in sample_traces:
            text = LabelMatrixParser.build_tagged_text(sample["cot_4steps"])
            assert parser.has_valid_order(text), (
                f"Sample {sample['id']} has invalid stage order"
            )

    def test_all_samples_every_token_assigned(
        self, parser: LabelMatrixParser, tokenizer: MockTokenizer, sample_traces: list[dict]
    ):
        """In all samples, every token should be assigned to exactly one stage."""
        for sample in sample_traces:
            text = LabelMatrixParser.build_tagged_text(sample["cot_4steps"])
            masks = parser.parse(text, tokenizer)
            num_tokens = len(masks["understand"])

            for i in range(num_tokens):
                count = sum(masks[key][i] for key in masks)
                assert count == 1, (
                    f"Sample {sample['id']}, token {i}: in {count} stages"
                )
