"""
Phase 2 config tests.

Tests for StepDistillConfig:
- Round-trip: YAML → Pydantic → dict → YAML without data loss
- Validator raises on weight sum ≠ 1.10
- Validator raises on non-power-of-2 rank
- Default values match paper exactly
- from_yaml loads defaults.yaml correctly
- Flat kwarg construction works
"""

import tempfile
from pathlib import Path

import pytest
import yaml

from step_distill.config.config import (
    EfficiencyConfig,
    LoRAConfig,
    LossWeightsConfig,
    StepDistillConfig,
    TrainingConfig,
)


# ---------------------------------------------------------------------------
# Default values match paper
# ---------------------------------------------------------------------------


class TestDefaultValues:
    """Verify all defaults match the paper exactly."""

    def test_loss_weights_defaults(self):
        config = StepDistillConfig()
        assert config.loss_weights.alpha == 0.15
        assert config.loss_weights.beta == 0.35
        assert config.loss_weights.gamma == 0.35
        assert config.loss_weights.delta == 0.15
        assert config.loss_weights.epsilon == 0.10

    def test_loss_weight_sum(self):
        config = StepDistillConfig()
        weight_sum = (
            config.loss_weights.alpha
            + config.loss_weights.beta
            + config.loss_weights.gamma
            + config.loss_weights.delta
            + config.loss_weights.epsilon
        )
        assert abs(weight_sum - 1.10) < 0.001

    def test_beta_alpha_ratio(self):
        """β/α = γ/α = 2.33 — asymmetric gradient pressure."""
        config = StepDistillConfig()
        ratio_beta = config.loss_weights.beta / config.loss_weights.alpha
        ratio_gamma = config.loss_weights.gamma / config.loss_weights.alpha
        assert abs(ratio_beta - 2.333) < 0.01
        assert abs(ratio_gamma - 2.333) < 0.01

    def test_lora_defaults(self):
        config = StepDistillConfig()
        assert config.lora.rank == 16
        assert config.lora.alpha == 32
        assert config.lora.dropout == 0.05
        assert config.lora.target_modules == [
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ]

    def test_training_defaults(self):
        config = StepDistillConfig()
        assert config.training.epochs == 2
        assert config.training.learning_rate == 1e-4
        assert config.training.min_lr == 1e-6
        assert config.training.scheduler == "cosine_with_warmup"
        assert config.training.warmup_steps == 300
        assert config.training.batch_size == 1
        assert config.training.gradient_accumulation_steps == 4
        assert config.training.max_seq_length == 1024
        assert config.training.weight_decay == 0.01
        assert config.training.max_grad_norm == 1.0
        assert config.training.label_smoothing == 0.1
        assert config.training.seed == 42

    def test_efficiency_defaults(self):
        config = StepDistillConfig()
        assert config.efficiency.use_sdpa is True
        assert config.efficiency.mixed_precision == "fp16"
        assert config.efficiency.gradient_checkpointing is True

    def test_model_defaults(self):
        config = StepDistillConfig()
        assert config.student_model == "Qwen/Qwen2.5-3B-Instruct"
        assert config.teacher_model == "Qwen/Qwen2.5-32B-Instruct"


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------


class TestValidators:
    """Test that validators correctly reject invalid configs."""

    def test_weight_sum_too_high(self):
        with pytest.raises(ValueError, match="must sum to ~1.10"):
            StepDistillConfig(alpha=0.50, beta=0.50, gamma=0.50, delta=0.50, epsilon=0.50)

    def test_weight_sum_too_low(self):
        with pytest.raises(ValueError, match="must sum to ~1.10"):
            StepDistillConfig(alpha=0.01, beta=0.01, gamma=0.01, delta=0.01, epsilon=0.01)

    def test_weight_sum_just_outside_tolerance(self):
        """Sum = 1.12 (0.02 away from 1.10) should fail."""
        with pytest.raises(ValueError, match="must sum to ~1.10"):
            StepDistillConfig(alpha=0.17, beta=0.35, gamma=0.35, delta=0.15, epsilon=0.10)

    def test_weight_sum_within_tolerance(self):
        """Sum = 1.105 (within 0.01 of 1.10) should pass."""
        config = StepDistillConfig(
            alpha=0.155, beta=0.35, gamma=0.35, delta=0.15, epsilon=0.10
        )
        assert config.loss_weights.alpha == 0.155

    def test_lora_rank_not_power_of_2(self):
        with pytest.raises(ValueError, match="must be a power of 2"):
            StepDistillConfig(lora_rank=12)

    def test_lora_rank_zero(self):
        with pytest.raises(ValueError, match="must be a power of 2"):
            StepDistillConfig(lora_rank=0)

    def test_lora_rank_negative(self):
        with pytest.raises(ValueError, match="must be a power of 2"):
            StepDistillConfig(lora_rank=-4)

    def test_lora_rank_valid_powers(self):
        """All valid powers of 2 should pass."""
        for rank in [2, 4, 8, 16, 32, 64]:
            config = StepDistillConfig(lora_rank=rank)
            assert config.lora.rank == rank


# ---------------------------------------------------------------------------
# from_yaml / from_dict
# ---------------------------------------------------------------------------


class TestFromYaml:
    """Test YAML loading and from_dict construction."""

    def test_from_defaults_yaml(self):
        """Load the bundled defaults.yaml and verify it produces valid config."""
        defaults_path = Path(__file__).parent.parent / "step_distill" / "config" / "defaults.yaml"
        config = StepDistillConfig.from_yaml(defaults_path)
        assert config.student_model == "Qwen/Qwen2.5-3B-Instruct"
        assert config.loss_weights.alpha == 0.15
        assert config.lora.rank == 16
        assert config.training.epochs == 2
        assert config.efficiency.use_sdpa is True

    def test_from_yaml_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            StepDistillConfig.from_yaml("/nonexistent/path/config.yaml")

    def test_from_yaml_custom_values(self):
        """Write a custom YAML and load it."""
        custom = {
            "student_model": "meta-llama/Llama-3.1-8B-Instruct",
            "loss_weights": {
                "alpha": 0.20,
                "beta": 0.30,
                "gamma": 0.30,
                "delta": 0.20,
                "epsilon": 0.10,
            },
            "lora": {"rank": 32},
        }
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(custom, f)
            f.flush()
            config = StepDistillConfig.from_yaml(f.name)

        assert config.student_model == "meta-llama/Llama-3.1-8B-Instruct"
        assert config.loss_weights.alpha == 0.20
        assert config.lora.rank == 32
        # Non-specified fields should use defaults
        assert config.training.epochs == 2
        assert config.efficiency.use_sdpa is True

    def test_from_dict_nested(self):
        config = StepDistillConfig.from_dict({
            "student_model": "custom/model",
            "loss_weights": {"alpha": 0.20, "beta": 0.30, "gamma": 0.30, "delta": 0.20, "epsilon": 0.10},
        })
        assert config.student_model == "custom/model"
        assert config.loss_weights.alpha == 0.20

    def test_from_dict_flat(self):
        """Flat kwargs should be remapped to nested structure."""
        config = StepDistillConfig.from_dict({
            "student_model": "custom/model",
            "alpha": 0.20,
            "beta": 0.30,
            "gamma": 0.30,
            "delta": 0.20,
            "epsilon": 0.10,
            "lora_rank": 32,
            "num_epochs": 5,
        })
        assert config.loss_weights.alpha == 0.20
        assert config.lora.rank == 32
        assert config.training.epochs == 5


# ---------------------------------------------------------------------------
# Round-trip: YAML → Pydantic → dict → YAML
# ---------------------------------------------------------------------------


class TestRoundTrip:
    """Verify config survives YAML → Pydantic → dict → YAML without data loss."""

    def test_round_trip_defaults(self):
        """Default config should round-trip perfectly."""
        config1 = StepDistillConfig()
        dict1 = config1.to_dict()

        # dict → YAML string → dict → config
        yaml_str = yaml.dump(dict1, default_flow_style=False)
        dict2 = yaml.safe_load(yaml_str)
        config2 = StepDistillConfig.from_dict(dict2)
        dict3 = config2.to_dict()

        assert dict1 == dict3

    def test_round_trip_custom(self):
        """Custom config with non-default values should round-trip."""
        config1 = StepDistillConfig(
            student_model="meta-llama/Llama-3.1-8B-Instruct",
            alpha=0.20,
            beta=0.30,
            gamma=0.30,
            delta=0.20,
            epsilon=0.10,
            lora_rank=32,
            num_epochs=5,
            learning_rate=2e-4,
        )
        dict1 = config1.to_dict()
        yaml_str = config1.to_yaml()
        dict2 = yaml.safe_load(yaml_str)
        config2 = StepDistillConfig.from_dict(dict2)
        dict3 = config2.to_dict()

        assert dict1 == dict3

    def test_round_trip_via_file(self):
        """Write to file, read back, verify identical."""
        config1 = StepDistillConfig()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            config1.to_yaml(f.name)
            config2 = StepDistillConfig.from_yaml(f.name)

        assert config1.to_dict() == config2.to_dict()


# ---------------------------------------------------------------------------
# Flat constructor
# ---------------------------------------------------------------------------


class TestFlatConstructor:
    """Test flat kwargs construction matching the README Python API."""

    def test_flat_loss_weights(self):
        config = StepDistillConfig(
            alpha=0.20, beta=0.30, gamma=0.30, delta=0.20, epsilon=0.10
        )
        assert config.loss_weights.alpha == 0.20
        assert config.loss_weights.beta == 0.30

    def test_flat_lora(self):
        config = StepDistillConfig(lora_rank=32, lora_alpha=64, lora_dropout=0.1)
        assert config.lora.rank == 32
        assert config.lora.alpha == 64
        assert config.lora.dropout == 0.1

    def test_flat_training(self):
        config = StepDistillConfig(num_epochs=5, learning_rate=2e-4, warmup_steps=500)
        assert config.training.epochs == 5
        assert config.training.learning_rate == 2e-4
        assert config.training.warmup_steps == 500

    def test_flat_efficiency(self):
        config = StepDistillConfig(
            use_sdpa=False, mixed_precision="bf16", gradient_checkpointing=False
        )
        assert config.efficiency.use_sdpa is False
        assert config.efficiency.mixed_precision == "bf16"
        assert config.efficiency.gradient_checkpointing is False

    def test_full_readme_api(self):
        """Exact constructor call from README 'Train Your Own' section."""
        config = StepDistillConfig(
            student_model="Qwen/Qwen2.5-3B-Instruct",
            alpha=0.15,
            beta=0.35,
            gamma=0.35,
            delta=0.15,
            epsilon=0.10,
            lora_rank=16,
            lora_alpha=32,
            lora_dropout=0.05,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj",
            ],
            num_epochs=2,
            learning_rate=1e-4,
            warmup_steps=300,
            batch_size=1,
            gradient_accumulation_steps=4,
            max_seq_length=1024,
            label_smoothing=0.1,
            use_sdpa=True,
            mixed_precision="fp16",
            gradient_checkpointing=True,
        )
        assert config.student_model == "Qwen/Qwen2.5-3B-Instruct"
        assert config.loss_weights.alpha == 0.15
        assert config.lora.rank == 16
        assert config.training.epochs == 2
        assert config.efficiency.use_sdpa is True


# ---------------------------------------------------------------------------
# Repr
# ---------------------------------------------------------------------------


class TestRepr:
    """Test string representation."""

    def test_repr_does_not_crash(self):
        config = StepDistillConfig()
        r = repr(config)
        assert "StepDistillConfig" in r
        assert "Qwen" in r
