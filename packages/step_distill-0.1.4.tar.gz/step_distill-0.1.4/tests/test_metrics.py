import pytest

from step_distill.core.metrics import AccuracyMetric, RFSMetric, SVRMetric

def test_accuracy_metric_normalization():
    acc = AccuracyMetric()
    
    # AccuracyMetric: "18" == "$18" == "18.0" == "\boxed{18}"
    assert acc._is_match("18", "$18")
    assert acc._is_match("18", "18.0")
    assert acc._is_match("18", "\\boxed{18}")
    
    # AccuracyMetric: "1/2" == "0.5"
    assert acc._is_match("1/2", "0.5")
    
    # AccuracyMetric: "24 cm" == "24"
    assert acc._is_match("24 cm", "24")
    assert acc._is_match("10 kg", "10")

def test_rfs_metric():
    rfs = RFSMetric()
    
    # all 4 tags + content -> rfs=1.0
    full_response = (
        "#### UNDERSTAND ####\nThis is more than ten characters.\n"
        "#### PLAN ####\nThis is more than ten characters.\n"
        "#### EXECUTE ####\nThis is more than ten characters.\n"
        "#### VERIFY ####\nThis is more than ten characters."
    )
    assert rfs.compute_single(full_response) == 1.0
    
    # missing VERIFY -> rfs=0.75
    missing_verify = (
        "#### UNDERSTAND ####\nThis is more than ten characters.\n"
        "#### PLAN ####\nThis is more than ten characters.\n"
        "#### EXECUTE ####\nThis is more than ten characters."
    )
    assert rfs.compute_single(missing_verify) == 0.75
    
    # tag present but empty (< 10 chars) -> doesn't count
    empty_verify = (
        "#### UNDERSTAND ####\nThis is more than ten characters.\n"
        "#### PLAN ####\nThis is more than ten characters.\n"
        "#### EXECUTE ####\nThis is more than ten characters.\n"
        "#### VERIFY ####\ntiny"
    )
    assert rfs.compute_single(empty_verify) == 0.75

def test_svr_metric_reversal():
    svr = SVRMetric()
    
    # SVR contribution = 1
    # execute="20", final="24", gt="24"
    resp1 = (
        "#### EXECUTE ####\nThe answer might be 20.\n"
        "#### VERIFY ####\nWait, I made a mistake. It is 24.\n"
        "The answer is \\boxed{24}"
    )
    assert svr.compute([resp1], ["24"]) == 1.0
    
    # SVR contribution = 0 (no reversal needed)
    # execute="24", final="24", gt="24"
    resp2 = (
        "#### EXECUTE ####\nThe answer is 24.\n"
        "#### VERIFY ####\nYes, 24 is correct.\n"
        "The answer is \\boxed{24}"
    )
    assert svr.compute([resp2], ["24"]) == 0.0

@pytest.mark.skipif(True, reason="requires model weights")
def test_reproduce_paper_results():
    """
    This test requires NanoReason-3B weights to be available.
    Skip if model not downloaded, but document expected values:
    gsm8k accuracy: 78.7% ± 0.1pp
    rfs_full: 100.0%
    svr: 0.0%
    """
    pass
