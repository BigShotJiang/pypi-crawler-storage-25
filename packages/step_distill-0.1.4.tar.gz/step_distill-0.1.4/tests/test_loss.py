import pytest
import torch
import torch.nn.functional as F

from step_distill.core.loss import StepAwareLoss

def test_loss_single_stage():
    """Single-stage input (only PLAN tokens) -> total_loss ≈ beta * CE(logits, labels)"""
    batch_size, seq_len, vocab_size = 2, 10, 50
    loss_fn = StepAwareLoss(beta=0.35, label_smoothing=0.0)
    
    logits = torch.randn(batch_size, seq_len, vocab_size, requires_grad=True)
    labels = torch.randint(0, vocab_size, (batch_size, seq_len))
    attention_mask = torch.ones(batch_size, seq_len)
    
    mask_dict = {
        "plan": torch.ones(batch_size, seq_len, dtype=torch.bool),
    }
    
    outputs = loss_fn(logits, labels, mask_dict, attention_mask)
    
    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = labels[..., 1:].contiguous()
    
    expected_ce = F.cross_entropy(
        shift_logits.view(-1, vocab_size),
        shift_labels.view(-1)
    )
    
    assert torch.isclose(outputs["total_loss"], 0.35 * expected_ce, rtol=1e-3)
    assert outputs["understand_loss"].item() == 0.0


def test_loss_all_zeros_mask():
    """All zeros mask_dict -> total_loss == 0.0"""
    batch_size, seq_len, vocab_size = 2, 10, 50
    loss_fn = StepAwareLoss()
    
    logits = torch.randn(batch_size, seq_len, vocab_size, requires_grad=True)
    labels = torch.randint(0, vocab_size, (batch_size, seq_len))
    attention_mask = torch.ones(batch_size, seq_len)
    
    mask_dict = {
        "understand": torch.zeros(batch_size, seq_len, dtype=torch.bool),
        "plan": torch.zeros(batch_size, seq_len, dtype=torch.bool),
    }
    
    outputs = loss_fn(logits, labels, mask_dict, attention_mask)
    assert outputs["total_loss"].item() == 0.0


def test_loss_no_transition_violations():
    """No transition violations -> transition_loss == 0.0"""
    batch_size, seq_len, vocab_size = 1, 5, 10
    loss_fn = StepAwareLoss()
    
    logits = torch.randn(batch_size, seq_len, vocab_size, requires_grad=True)
    labels = torch.randint(0, vocab_size, (batch_size, seq_len))
    attention_mask = torch.ones(batch_size, seq_len)
    
    # Valid forward sequence: understand -> plan -> execute -> verify
    # Remember Step_labels matching masks shifts inside loss:
    mask_dict = {
        "understand": torch.tensor([[True, False, False, False, False]]),
        "plan": torch.tensor([[False, True, False, False, False]]),
        "execute": torch.tensor([[False, False, True, False, False]]),
        "verify": torch.tensor([[False, False, False, True, True]]),
    }
    
    outputs = loss_fn(logits, labels, mask_dict, attention_mask)
    assert outputs["transition_loss"].item() == 0.0


def test_loss_gradient_flow_and_stability():
    """Gradient flows: total_loss.backward() does not error. Values are numerically stable."""
    batch_size, seq_len, vocab_size = 2, 10, 50
    loss_fn = StepAwareLoss()
    
    logits = torch.randn(batch_size, seq_len, vocab_size, requires_grad=True)
    labels = torch.randint(0, vocab_size, (batch_size, seq_len))
    attention_mask = torch.ones(batch_size, seq_len)
    
    # Introduce a backward jump (plan -> understand to trigger penalty)
    # 5 ones + 5 ones
    mask_dict = {
        "plan": torch.cat([torch.ones(2, 5, dtype=torch.bool), torch.zeros(2, 5, dtype=torch.bool)], dim=-1),
        "understand": torch.cat([torch.zeros(2, 5, dtype=torch.bool), torch.ones(2, 5, dtype=torch.bool)], dim=-1) 
    }
    
    outputs = loss_fn(logits, labels, mask_dict, attention_mask)
    total_loss = outputs["total_loss"]
    
    assert not torch.isnan(total_loss)
    assert not torch.isinf(total_loss)
    
    total_loss.backward()
    
    assert logits.grad is not None
    assert not torch.isnan(logits.grad).any()
    
def test_loss_backward_jump_penalty():
    """Ensure backward jump assigns penalty > 0"""
    batch_size, seq_len, vocab_size = 1, 5, 10
    loss_fn = StepAwareLoss(epsilon=0.10)
    
    logits = torch.randn(batch_size, seq_len, vocab_size, requires_grad=True)
    labels = torch.randint(0, vocab_size, (batch_size, seq_len))
    attention_mask = torch.ones(batch_size, seq_len)
    
    mask_dict = {
        "plan": torch.tensor([[True, True, False, False, False]]),
        "understand": torch.tensor([[False, False, True, True, True]]),
    }
    outputs = loss_fn(logits, labels, mask_dict, attention_mask)
    assert outputs["transition_loss"].item() > 0.0
