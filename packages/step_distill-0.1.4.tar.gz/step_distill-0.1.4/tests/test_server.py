import os
import asyncio
import pytest
from httpx import AsyncClient, ASGITransport
from unittest.mock import patch, MagicMock

# We must set TEST_ENV before importing server
os.environ["TEST_ENV"] = "1"
from step_distill.app.server import app, PROBLEM_BANK
from step_distill.core.inference import ReasoningResult

@pytest.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

def test_problem_bank_size():
    assert len(PROBLEM_BANK) == 15

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"

@pytest.mark.asyncio
async def test_get_problems(async_client):
    response = await async_client.get("/api/problems")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 15
    assert data[0]["level"] == "easy"

@pytest.mark.asyncio
async def test_solve_endpoint(async_client):
    # Mock the app.state.model so we don't need real weights
    mock_model = MagicMock()
    mock_result = ReasoningResult(
        answer="18",
        steps={"understand": "Janet has 16 eggs", "plan": "calculate", "execute": "math", "verify": "done"},
        rfs=1.0,
        raw_output="...",
        generation_time_s=1.2
    )
    mock_model.solve.return_value = mock_result
    app.state.model = mock_model

    req_data = {
        "question": "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast and bakes muffins with 4. She sells the rest at $2/egg. How much does she make daily?"
    }
    response = await async_client.post("/api/solve", json=req_data)
    assert response.status_code == 200
    data = response.json()
    assert data["answer"] == "18"
    assert data["rfs"] == 1.0

@pytest.mark.asyncio
async def test_websocket_stream():
    from fastapi.testclient import TestClient
    
    # We mock solve_stream for the websocket
    async def mock_solve_stream(question):
        yield "I understand", "understand"
        yield "I will plan", "plan"
        yield "I will calculate", "execute"
        yield "I will verify", "verify"
        
    # httpx AsyncClient doesn't support WebSockets natively yet, so we use starlette TestClient
    with TestClient(app) as client:
        # Assign mock model AFTER TestClient triggers the lifespan to avoid override
        mock_model = MagicMock()
        mock_model.solve_stream = mock_solve_stream
        app.state.model = mock_model

        with client.websocket_connect("/api/stream") as websocket:
            websocket.send_json({"question": "Solve this equation"})
            
            stages_seen = set()
            while True:
                data = websocket.receive_json()
                if data.get("stage") == "error":
                    pytest.fail(f"Websocket error received: {data.get('error')}")
                if data.get("stage") == "done":
                    break
                stages_seen.add(data["stage"])
                
            assert "understand" in stages_seen
            assert "plan" in stages_seen
            assert "execute" in stages_seen
            assert "verify" in stages_seen
