import json
import os
import pytest

from step_distill.data.sources import GSM8KSource, MATHSource, VNHSGESource
from step_distill.data.pipeline import TeacherPipeline, _filter_syntax, _filter_math, _filter_consistency


def test_gsm8k_source():
    source = GSM8KSource()
    data = source.load()
    assert len(data) >= 7000
    assert "question" in data[0]
    assert "answer" in data[0]


def test_math_source():
    source = MATHSource()
    data = source.load()
    assert len(data) >= 7000
    assert "question" in data[0]
    assert "answer" in data[0]
    assert "\\boxed" not in data[0]["answer"]  # Extracted


def test_vnhsge_source():
    source = VNHSGESource()
    data = source.load()
    assert len(data) > 0
    assert "question" in data[0]
    assert "answer" in data[0]


def test_filter_syntax():
    valid = "#### UNDERSTAND #### a #### PLAN #### b #### EXECUTE #### c #### VERIFY #### d"
    assert _filter_syntax(valid) is True

    missing = "#### UNDERSTAND #### a #### EXECUTE #### b #### VERIFY #### c"
    assert _filter_syntax(missing) is False

    wrong_order = "#### PLAN #### a #### UNDERSTAND #### b #### EXECUTE #### c #### VERIFY #### d"
    assert _filter_syntax(wrong_order) is False


def test_filter_math():
    response = "Something something. The answer is \\boxed{42}."
    assert _filter_math(response, ground_truth="42") is True
    assert _filter_math(response, ground_truth="43") is False


def test_filter_consistency():
    valid = "#### PLAN #### Use formula 3+x. #### EXECUTE #### 3+4=7"
    assert _filter_consistency(valid) is True

    invalid = "#### PLAN #### Use formula 3+x. #### EXECUTE #### 8+4=12"
    assert _filter_consistency(invalid) is False

    empty_plan = "#### PLAN #### No numbers here. #### EXECUTE #### 3+4=7"
    assert _filter_consistency(empty_plan) is True


def test_teacher_pipeline_resume(tmp_path):
    output_path = tmp_path / "output.jsonl"
    
    # Create an initial output with some IDs
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(json.dumps({"id": "sample_0"}) + "\n")
        f.write(json.dumps({"id": "sample_1"}) + "\n")

    # Create dummy source jsonl
    source_path = tmp_path / "source.jsonl"
    with open(source_path, "w", encoding="utf-8") as f:
        f.write(json.dumps({"id": "sample_0", "question": "", "answer": ""}) + "\n")
        f.write(json.dumps({"id": "sample_1", "question": "", "answer": ""}) + "\n")
        f.write(json.dumps({"id": "sample_2", "question": "", "answer": ""}) + "\n")

    # This won't actually trigger the model if max_samples covers everything already done
    pipeline = TeacherPipeline(teacher_model="dummy", api_key="test", api_base="http://test")
    # Patch generator to avoid network test
    pipeline._generate_batch = lambda x: ["#### UNDERSTAND #### P #### PLAN #### P #### EXECUTE #### 42 #### VERIFY ####"] * len(x)

    results = pipeline.generate(
        sources=[str(source_path)],
        output_path=str(output_path),
        quality_filters=[],
        resume=True
    )
    
    # Total samples = 3, existing = 2 (sample_0, sample_1), so 1 remaining to generate
    assert len(results) == 1
    assert results[0]["id"] == "sample_2"
    
    # Check the file contains 3 lines total
    with open(output_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 3
