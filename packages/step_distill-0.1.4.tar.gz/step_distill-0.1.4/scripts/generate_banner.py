import os
from PIL import Image, ImageDraw, ImageFont

def create_banner():
    width, height = 1200, 630
    # Background #0f0f13
    img = Image.new("RGB", (width, height), "#0f0f13")
    draw = ImageDraw.Draw(img)

    try:
        # Require a nice font, fallback to default if not found
        title_font = ImageFont.truetype("arialbd.ttf", 90)
        subtitle_font = ImageFont.truetype("arial.ttf", 40)
    except IOError:
        # Fallback for linux/mac or missing arial
        title_font = ImageFont.load_default(size=90) if hasattr(ImageFont, "load_default") else ImageFont.load_default()
        subtitle_font = ImageFont.load_default(size=40) if hasattr(ImageFont, "load_default") else ImageFont.load_default()

    # Draw Text
    title_text = "step-distill"
    subtitle_text = "Distill Verifiable Reasoning into Small Language Models"
    
    # Calculate text bounding boxes to center them
    # Since textsize is deprecated in newer Pillows, use textbbox
    if hasattr(draw, 'textbbox'):
        title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
        title_w = title_bbox[2] - title_bbox[0]
        title_h = title_bbox[3] - title_bbox[1]
        
        sub_bbox = draw.textbbox((0, 0), subtitle_text, font=subtitle_font)
        sub_w = sub_bbox[2] - sub_bbox[0]
    else:
        title_w, title_h = draw.textsize(title_text, font=title_font)
        sub_w, _ = draw.textsize(subtitle_text, font=subtitle_font)

    # Put title slightly above center
    draw.text(((width - title_w) / 2, (height - title_h) / 2 - 50), title_text, fill="white", font=title_font)
    
    # Put subtitle below title
    draw.text(((width - sub_w) / 2, (height / 2) + 50), subtitle_text, fill="#e5e7eb", font=subtitle_font)

    # Draw bottom gradient bar (4 colors: blue, purple, amber, emerald)
    # UNDERSTAND: #3b82f6  PLAN: #8b5cf6  EXECUTE: #f59e0b  VERIFY: #10b981
    colors = ["#3b82f6", "#8b5cf6", "#f59e0b", "#10b981"]
    bar_height = 15
    segment_width = width / len(colors)
    
    for i, color in enumerate(colors):
        x0 = i * segment_width
        x1 = (i + 1) * segment_width
        y0 = height - bar_height
        y1 = height
        draw.rectangle([x0, y0, x1, y1], fill=color)

    # Ensure assets dir exists
    os.makedirs("assets", exist_ok=True)
    img.save("assets/banner.png", "PNG")
    print("Banner generated at assets/banner.png")

if __name__ == "__main__":
    create_banner()
