# Changelog
All notable changes to this project will be documented in this file.

## [0.1.0] - Initial Release
This is the foundational release of NanoReason, the Step-Aware Distillation framework.

### Added
- **NanoReason Core**: Inference wrappers with bit-quantization auto-scaling and robust Regex output parsing (`step_distill/core/inference.py`).
- **Teacher Pipeline**: Automate distillation data generation via HuggingFace Hub APIs featuring streaming outputs (`step_distill/data/pipeline.py`).
- **Step-Aware Fine-Tuning Module**: Implement token-level dynamic gradients with phase-locking specifically for `Understand/Plan/Execute/Verify` targets (`step_distill/core/trainer.py`).
- **Integrated Web Dashboard**: A pure Vanilla JS Frontend supported by an asynchronous FastAPI websocket backend representing step-by-step reasoning dynamically (`step_distill/app/server.py`).
- **Comprehensive CLI Suite**: Typer application exposing 6 major sub-commands (`generate`, `train`, `eval`, `demo`, `solve`, `run`) accommodating real-time inference and config injection.
- **Eval Metrics Package**: Dedicated framework implementing standard GSM8K Accuracy, Reward-Free Score (RFS), and Step Verification Ratio (SVR).
- **Embedded Multi-Lingual Dataset**: Vietnamese High-school Graduation Examination (`vnhsge`) dataset included natively within the module (`step_distill/data/vnhsge_train.jsonl`).
- **Documentation Engine**: Detailed MkDocs Material setup detailing Deployment options, API specs, and academic metrics rationale.
