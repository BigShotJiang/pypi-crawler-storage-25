# Contributing to NanoReason

First off, thank you for considering contributing to NanoReason! It's people like you that make the open source community such an amazing place to learn, inspire, and create.

## Priority Contributions
The project is especially looking for contributions in these areas:
- New high-quality reasoning datasets across multiple languages.
- Optimized distillation techniques for smaller architectures (< 1B parameters).
- Web Dashboard enhancements and visualizations.
- Benchmarks focusing on logical inconsistencies and hallucinations.

## Developer Setup
To set up your local environment for development:
```bash
git clone https://github.com/ductaiphan/step-distill.git
cd nanoreason
make install-dev
```

## Running Tests
We enforce rigorous testing to maintain high model and infrastructure quality:
```bash
make test
```
All new features must include appropriate tests. Coverage must remain above 80%.

## Code Style
This project uses `black` for formatting, `isort` for import sorting, and `ruff` for linting.
Run the formatter before committing:
```bash
make format
make lint
```

## Pull Request Process
1. Base your branch off `main` and create a dedicated feature branch.
2. Ensure your code satisfies `make test` and `make lint`.
3. Create the PR describing the rationale, changes, and tests.
4. Wait for at least 1 maintainer review before merging.
