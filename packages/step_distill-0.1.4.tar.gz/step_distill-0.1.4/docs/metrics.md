# Metrics Deep Dive

Understanding our Evaluation framework.

## Accuracy
Traditional boxed accuracy utilizing robust regex strategies.

## RFS (Reward-Free Score)
Checks verification state flags embedded in model tokens.

## SVR (Step Verification Ratio)
Ensures alignment of chain-of-thought progression.
