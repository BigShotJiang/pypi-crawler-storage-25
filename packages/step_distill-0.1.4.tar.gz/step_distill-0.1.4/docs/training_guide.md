# Training Guide

## Launching a Training Session
```bash
step-distill train --config config.yaml --data data/traces.jsonl
```

## Step-Aware Loss
Under the hood, NanoReason uses a highly specialized loss calculation algorithm.
Read more about configuring loss weights in the `config.yaml` file.
