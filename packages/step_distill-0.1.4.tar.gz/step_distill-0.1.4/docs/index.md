# Welcome to NanoReason

Step-Aware Distillation framework for distilling robust reasoning chains into small, efficient language models.

## Core Features
1. **Teacher Pipeline**: Automate data generation using leading models like Qwen-32B or Llama-70B.
2. **Step-Aware Fine-Tuning**: Custom loss function weighting Understand, Plan, Execute, and Verify stages dynamically.
3. **Robust Metrics**: Calculate standard Accuracy alongside Reward-Free Score (RFS) and Step Verification Ratio (SVR).
4. **End-to-End Orchestration**: From datasets generation to training scripts, to an integrated Web Dashboard UI.

Get started by visiting the [Quick Start](quickstart.md) guide.
