# School Deployment Guide

Deploying NanoReason across educational institutions is streamlined to work with typical academic network configurations and hardware.

## Quick Installation
NanoReason is fully bundled with its core backend, CLI tools, and web interface. Perform a one-line install:
```bash
pip install "step-distill[all]"
```

## Hardware & Model Selection

Selecting the perfect Teacher and Student model depends on your hardware capabilities. The below tables reflect the top-rated open-source models for reasoning capabilities:

### Recommended Teacher Models
These models generate the high-quality reasoning traces used for distillation.

| Model ID | Notes |
|---------|-------|
| `Qwen/Qwen2.5-32B-Instruct` | 32B • Best quality • Needs A100 |
| `Qwen/Qwen2.5-14B-Instruct` | 14B • Good quality • Needs 2×T4 |
| `Qwen/Qwen2.5-7B-Instruct` | 7B • Fast • Single T4 |
| `meta-llama/Llama-3.1-70B-Instruct` | 70B • Best Llama • Needs 4×A100 |
| `google/gemma-2-27b-it` | 27B • Alternative • Needs A100 |

### Recommended Student Models
These models are deployed for actual student inference and solve math endpoints efficiently.

| Student Model | VRAM | Device | Notes |
|--------------|------|--------|-------|
| `1.5B (Qwen2.5)` | 4GB | GTX 1650 | Very fast • 8GB System RAM |
| `3B` | 6GB | RTX 3060 | Validated • Single T4 or lower |
| `7B` | 14GB | RTX 3080/4090 | Better accuracy |
| `meta-llama/Llama-3.2-3B-Instruct` | 6GB | RTX 3060 | Llama family |
| `microsoft/Phi-3.5-mini-instruct` | 6GB | RTX 3060 | Efficient |

## Custom Dataset Registration
You can inject localized academic context or specific school subjects utilizing a simple data format.
Any JSONL with a `'question'` and `'answer'` field is a valid dataset for NanoReason.

**Example format (`physics_train.jsonl`):**
```json
{"question": "Một ô tô đang chuyển động với vận tốc 36 km/h thì hãm phanh chuyển động chậm dần đều với gia tốc 2 m/s2. Tính quãng đường ô tô đi được đến khi dừng hẳn.", "answer": "Để giải thích, ta đổi v = 36 km/h = 10 m/s. Quãng đường s = -v^2 / (2a) = -(10^2) / (2 * -2) = 25m. Vậy \\boxed{25}."}
{"question": "What is the molar mass of H2O?", "answer": "Hydrogen is 1, Oxygen is 16. Total 18 g/mol. \\boxed{18}."}
```
*Note: This utilizes the exact same verification format as the standard GSM8K configuration.*

## Local Area Network (LAN) Deployment
For classroom environments, run NanoReason centrally on the school server workstation.

```bash
step-distill demo --model ductaiphan/NanoReason-3B --port 8000 --no-browser
```

If leveraging a raw backend execution:
```bash
uvicorn step_distill.app.server:app --host 0.0.0.0 --port 8000
```
*Students can now connect directly to `http://<server-ip>:8000` via Chrome or Safari on iPads and Chromebooks.*
