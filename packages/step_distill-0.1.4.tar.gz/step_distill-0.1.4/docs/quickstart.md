# Quick Start

## Installation
```bash
pip install step-distill[all]
```

## Running the Demo
Launch the real-time reasoning web app locally:
```bash
step-distill demo --model ductaiphan/NanoReason-3B
```

## Generate Distillation Traces
```bash
step-distill generate --sources gsm8k --max-samples 100
```
