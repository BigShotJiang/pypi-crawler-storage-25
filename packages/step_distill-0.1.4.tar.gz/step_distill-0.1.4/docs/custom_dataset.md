# Custom Dataset Integration

Learn how to integrate your own specialized benchmarks and custom pipelines into NanoReason.

See the [Deployment Guide](deployment.md) for a quick JSONL schema example.
