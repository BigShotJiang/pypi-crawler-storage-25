import sys
import typer
from typing import List

app = typer.Typer()

@app.command()
def test(
    benchmarks: List[str] = typer.Option(["gsm8k", "math", "vnhsge"]),
    # Is there a click_kwargs ?
    metrics: List[str] = typer.Option([], click_kwargs={"nargs": -1})
):
    print("Benchmarks:", benchmarks)
    print("Metrics:", metrics)

if __name__ == "__main__":
    app()
