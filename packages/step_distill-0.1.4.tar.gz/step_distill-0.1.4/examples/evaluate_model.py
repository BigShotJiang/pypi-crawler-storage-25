from step_distill.core.metrics import Evaluator

def main():
    model_path = "./my-trained-model"
    print(f"Loading Evaluator for model: {model_path}")
    
    try:
        evaluator = Evaluator(model_path=model_path)
        
        benchmarks = ["gsm8k", "math", "vnhsge"]
        metrics = ["accuracy", "rfs", "svr"]
        
        print(f"Running evaluation on {benchmarks} tracking {metrics}...")
        results = evaluator.evaluate(benchmarks=benchmarks, metrics=metrics)
        
        for res in results:
            print(f"Benchmark: {res.benchmark}")
            print(f"  Accuracy:  {res.accuracy * 100:.1f}%")
            print(f"  RFS Full:  {res.rfs_full * 100:.1f}%")
            print(f"  SVR Score: {res.svr * 100:.1f}%")
            print("-" * 30)
            
    except Exception as e:
        print(f"Evaluation encountered an error: {e}")

if __name__ == "__main__":
    main()
