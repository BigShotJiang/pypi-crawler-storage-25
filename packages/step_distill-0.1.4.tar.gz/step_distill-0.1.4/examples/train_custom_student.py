from step_distill import StepAwareTrainer
from step_distill.config import StepDistillConfig, TrainingConfig, LossWeights

def main():
    print("Setting up training configuration...")
    config = StepDistillConfig(
        student_model="Qwen/Qwen2.5-7B-Instruct",
        training=TrainingConfig(
            batch_size=2,
            learning_rate=2e-5,
            epochs=3,
        ),
        loss_weights=LossWeights(
            alpha=1.0,  # Understand weight
            beta=1.5,   # Plan weight
            gamma=2.0,  # Execute weight
            delta=2.0,  # Verify weight
            epsilon=3.0 # Final answer weight
        )
    )

    print("Initializing StepAwareTrainer...")
    # NOTE: Normally you pass train_dataset from the pipeline outputs
    trainer = StepAwareTrainer(
        config=config,
    )
    
    print("Starting distillation training...")
    trainer.train()

if __name__ == "__main__":
    main()
