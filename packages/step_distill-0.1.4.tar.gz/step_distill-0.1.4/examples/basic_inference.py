import asyncio
from step_distill import NanoReason

def main():
    print("Loading NanoReason-3B...")
    model = NanoReason.from_pretrained("ductaiphan/NanoReason-3B")
    
    question = "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast and bakes muffins with 4. She sells the rest at $2/egg. How much does she make daily?"
    print(f"Question: {question}\n")
    
    # Run inference
    result = model.solve(question)
    
    # Print the output visually
    print(repr(result))

if __name__ == "__main__":
    main()
