import os
import uvicorn
from fastapi import FastAPI
from step_distill.app.server import app

# This script demonstrates how a school administrator would 
# wrap the NanoReason web UI natively for their internal servers.

if __name__ == "__main__":
    # School configuration defaults
    os.environ["NANOREASON_MODEL_PATH"] = "ductaiphan/NanoReason-3B"
    HOST = "0.0.0.0" # Listen on all LAN IP addresses
    PORT = 8000
    
    print("===================================================")
    print("  🏫 NanoReason School Deployment Server Starting  ")
    print("===================================================")
    print(f"Model ID: {os.environ.get('NANOREASON_MODEL_PATH')}")
    print(f"Students can connect via their tablets at: http://<server-ip>:{PORT}")
    print("Press Ctrl+C to shutdown.")
    print("===================================================")
    
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
