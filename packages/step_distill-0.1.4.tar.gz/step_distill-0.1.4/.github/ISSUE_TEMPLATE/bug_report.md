---
name: Bug report
about: Create a report to help us improve NanoReason
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Ran command: '...'
2. With configuration '{...}'
3. Input string '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Environment info:**
 - OS: [e.g. Ubuntu 22.04]
 - CUDA version: [e.g. 12.1]
 - model ID: [e.g. ductaiphan/NanoReason-3B]
 - Package version: [e.g. 0.1.0]

**Additional context**
Add any other context about the problem here.
