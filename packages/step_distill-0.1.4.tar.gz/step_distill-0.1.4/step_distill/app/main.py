import os
import json
import logging
from contextlib import asynccontextmanager
from typing import Dict, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from step_distill import NanoReason

logger = logging.getLogger(__name__)

# Global model state
app_state: Dict[str, Any] = {"model": None}

PROBLEM_BANK = [
  { "id":1, "lang":"en", "level":"easy",
    "text":"Janet's ducks lay 16 eggs per day. She eats 3 for breakfast and bakes muffins with 4. She sells the rest at $2/egg. How much does she make daily?" },
  { "id":2, "lang":"en", "level":"easy",
    "text":"Tom has 5 apples. He gives 2 to his sister and buys 3 more. How many apples does Tom have now?" },
  { "id":3, "lang":"en", "level":"easy",
    "text":"A store sells notebooks for $3 each. A student buys 4 notebooks and pays with a $20 bill. How much change does she get?" },
  { "id":4, "lang":"en", "level":"easy",
    "text":"A train travels at 60 km/h for 2.5 hours. How far does it travel?" },
  { "id":5, "lang":"en", "level":"easy",
    "text":"Maria earns $12 per hour. She worked 8 hours Monday and 6 hours Tuesday. How much did she earn total?" },
  { "id":6, "lang":"en", "level":"medium",
    "text":"A rectangle has perimeter 28 cm. Its length is 3 cm more than its width. Find its area." },
  { "id":7, "lang":"en", "level":"medium",
    "text":"John completes a job in 4 hours, Mary in 6 hours. Working together, how long does it take?" },
  { "id":8, "lang":"en", "level":"medium",
    "text":"A car depreciates 15% per year. If it costs $20,000 new, what is its value after 2 years?" },
  { "id":9, "lang":"en", "level":"medium",
    "text":"A solution is 25% alcohol. How many liters of pure alcohol must be added to 12 liters to get 40% alcohol?" },
  { "id":10, "lang":"en", "level":"medium",
    "text":"Find all values of x satisfying 3x² - 7x + 2 = 0." },
  { "id":11, "lang":"vi", "level":"medium",
    "text":"Tính giá trị của biểu thức A = 3x² + 2x - 1 khi x = 2." },
  { "id":12, "lang":"vi", "level":"medium",
    "text":"Một bể nước hình hộp chữ nhật có chiều dài 5m, chiều rộng 3m, chiều cao 2m. Tính thể tích và thời gian bơm đầy nếu mỗi phút bơm 0.5m³." },
  { "id":13, "lang":"vi", "level":"medium",
    "text":"Cho phương trình x² - 5x + 6 = 0. Tìm tất cả nghiệm và tính tổng bình phương các nghiệm." },
  { "id":14, "lang":"vi", "level":"hard",
    "text":"Đoàn tàu dài 200m chạy qua cầu dài 800m ở vận tốc 72 km/h. Tính thời gian từ khi đầu tàu vào cầu đến khi đuôi tàu ra khỏi cầu." },
  { "id":15, "lang":"vi", "level":"hard",
    "text":"Lãi suất ngân hàng 8%/năm ghép lãi. Gửi 100 triệu đồng. Sau bao nhiêu năm tổng tiền vượt 150 triệu?" },
]

@asynccontextmanager
async def lifespan(app: FastAPI):
    model_id = os.getenv("MODEL_ID")
    if model_id:
        logger.info(f"Loading NanoReason model from {model_id}...")
        try:
            device = "cuda" if torch.cuda.is_available() else "cpu"
            import torch
            app_state["model"] = NanoReason.from_pretrained(model_id, device=device)
            logger.info("NanoReason model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
    else:
        logger.warning("No MODEL_ID specified. Running in stub mode.")
    yield
    app_state["model"] = None
    logger.info("NanoReason model unloaded.")

app = FastAPI(title="NanoReason Demo API", lifespan=lifespan)

class SolveRequest(BaseModel):
    question: str

@app.get("/api/health")
async def health_check():
    return {
        "status": "ok",
        "model": os.getenv("MODEL_ID", "none_configured"),
        "model_loaded": app_state["model"] is not None
    }

@app.get("/api/problems")
async def get_problems():
    return PROBLEM_BANK

@app.post("/api/solve")
async def solve(request: SolveRequest):
    model = app_state.get("model")
    if not model:
        raise HTTPException(status_code=503, detail="NanoReason model is not loaded.")
        
    try:
        result = model.solve(request.question)
        return {
            "answer": result.answer,
            "steps": result.steps,
            "rfs": result.rfs,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/api/stream")
async def websocket_stream(websocket: WebSocket):
    await websocket.accept()
    
    try:
        # First message expected is the question
        data = await websocket.receive_text()
        req = json.loads(data)
        question = req.get("question")
        
        if not question:
            await websocket.send_json({"error": "No question provided"})
            await websocket.close(code=1003)
            return
            
        model = app_state.get("model")
        if not model:
            await websocket.send_json({"error": "NanoReason model is not loaded", "stage": "error", "token": ""})
            await websocket.close(code=1011)
            return

        async for chunk, stage in model.solve_stream(question):
            await websocket.send_json({"token": chunk, "stage": stage})
            
        await websocket.send_json({"token": "", "stage": "done"})
        await websocket.close(code=1000)
        
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.send_json({"error": str(e), "stage": "error", "token": ""})
            await websocket.close(code=1011)
        except:
            pass

# Mount static files
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
if not os.path.exists(STATIC_DIR):
    os.makedirs(STATIC_DIR)

app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

@app.get("/")
async def root():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))
