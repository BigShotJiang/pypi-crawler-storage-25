// DOM Elements
const problemList = document.getElementById('problemList');
const promptInput = document.getElementById('promptInput');
const solveBtn = document.getElementById('solveBtn');
const modeToggle = document.getElementById('modeToggle');
const modeLabel = document.getElementById('modeLabel');
const statusText = document.getElementById('statusText');

const stepsContainer = document.getElementById('stepsContainer');
const answerBox = document.getElementById('answerBox');
const finalAnswerText = document.getElementById('finalAnswerText');
const copyBtn = document.getElementById('copyAnswerBtn');

const directAnswerBox = document.getElementById('directAnswerBox');
const directLoader = document.getElementById('directLoader');
const directAnswerText = document.getElementById('directAnswerText');

let activeWebsocket = null;

// Problem Bank Initialization
async function loadProblemBank() {
    try {
        const response = await fetch('/api/problems');
        const problems = await response.json();
        
        // Group problems
        const groups = {
            'Easy': problems.filter(p => p.level === 'easy' && p.lang === 'en'),
            'Medium': problems.filter(p => p.level === 'medium' && p.lang === 'en'),
            'Vietnamese': problems.filter(p => p.lang === 'vi')
        };

        problemList.innerHTML = '';
        
        for (const [groupName, items] of Object.entries(groups)) {
            if (items.length === 0) continue;
            
            const title = document.createElement('div');
            title.className = 'group-title';
            title.textContent = groupName;
            problemList.appendChild(title);

            items.forEach(p => {
                const item = document.createElement('div');
                item.className = 'problem-item';
                item.innerHTML = `<div class="p-text">${p.text}</div>`;
                item.onclick = () => {
                    document.querySelectorAll('.problem-item').forEach(el => el.classList.remove('active'));
                    item.classList.add('active');
                    promptInput.value = p.text;
                    promptInput.scrollIntoView({ behavior: 'smooth' });
                };
                problemList.appendChild(item);
            });
        }
    } catch (e) {
        console.error("Failed to load problem bank", e);
    }
}

// UI State Management
modeToggle.addEventListener('change', (e) => {
    modeLabel.textContent = e.target.checked ? "Show Steps" : "Answer Only";
});

function resetUI() {
    ['understand', 'plan', 'execute', 'verify'].forEach(stage => {
        const card = document.getElementById(`card-${stage}`);
        const content = document.getElementById(`content-${stage}`);
        card.classList.add('hidden');
        card.classList.remove('active');
        content.textContent = '';
    });
    
    answerBox.classList.add('hidden');
    finalAnswerText.textContent = '';
    
    directAnswerBox.classList.add('hidden');
    directAnswerText.textContent = '';
    directLoader.style.display = 'block';
    
    statusText.classList.remove('hidden');
    statusText.textContent = 'Processing...';
    solveBtn.disabled = true;
    solveBtn.style.opacity = '0.5';
}

// Staggered reveal for stage cards
async function revealCard(stage, delayMs) {
    return new Promise(resolve => {
        setTimeout(() => {
            const card = document.getElementById(`card-${stage}`);
            card.classList.remove('hidden');
            resolve();
        }, delayMs);
    });
}

function setActiveCard(activeStage) {
    ['understand', 'plan', 'execute', 'verify'].forEach(stage => {
        const card = document.getElementById(`card-${stage}`);
        if(stage === activeStage) {
            card.classList.add('active');
            card.scrollIntoView({ behavior: 'smooth', block: 'end' });
        } else {
            card.classList.remove('active');
        }
    });
}

async function extractAnswer(rawText) {
    // Attempt basic extraction mirroring Python backend
    if (rawText.includes("\\boxed{")) {
        const parts = rawText.split("\\boxed{");
        const match = parts[parts.length - 1];
        let stack = 1;
        let ans = "";
        for (let char of match) {
            if (char === '{') stack++;
            else if (char === '}') stack--;
            if (stack === 0) break;
            ans += char;
        }
        return ans.trim();
    }
    const fallback = rawText.match(/####\s*(.+)/);
    if(fallback) return fallback[1].trim();
    return "See steps";
}

// Solvers
async function startDirectSolve(question) {
    directAnswerBox.classList.remove('hidden');
    
    try {
        const response = await fetch('/api/solve', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ question })
        });
        const data = await response.json();
        
        directLoader.style.display = 'none';
        directAnswerText.textContent = data.answer;
        
        statusText.textContent = `Done in ${data.generation_time_s.toFixed(2)}s (RFS: ${(data.rfs*100).toFixed(0)}%)`;
    } catch (e) {
        directLoader.style.display = 'none';
        directAnswerText.textContent = "Error occurred.";
        statusText.textContent = "Failed";
    } finally {
        solveBtn.disabled = false;
        solveBtn.style.opacity = '1';
    }
}

async function startStreamSolve(question) {
    if (activeWebsocket) activeWebsocket.close();
    
    // Stagger show the cards
    stepsContainer.style.display = 'flex';
    revealCard('understand', 0);
    revealCard('plan', 200);
    revealCard('execute', 400);
    revealCard('verify', 600);
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/stream`;
    activeWebsocket = new WebSocket(wsUrl);
    
    let currentRawBuffer = "";
    let extractedAns = "";

    activeWebsocket.onopen = () => {
        activeWebsocket.send(JSON.stringify({ question }));
    };

    activeWebsocket.onmessage = async (event) => {
        const data = JSON.parse(event.data);
        
        if (data.stage === "done" || data.stage === "error") {
            activeWebsocket.close();
            setActiveCard(null);
            
            if (data.stage === "done") {
                statusText.textContent = "Complete!";
                extractedAns = await extractAnswer(currentRawBuffer);
                finalAnswerText.textContent = extractedAns;
                answerBox.classList.remove('hidden');
                answerBox.scrollIntoView({ behavior: 'smooth', block: 'end' });
            } else {
                statusText.textContent = "Error: " + data.error;
            }
            
            solveBtn.disabled = false;
            solveBtn.style.opacity = '1';
            return;
        }

        const validStages = ['understand', 'plan', 'execute', 'verify'];
        if (validStages.includes(data.stage)) {
            setActiveCard(data.stage);
            const contentBox = document.getElementById(`content-${data.stage}`);
            contentBox.textContent += data.token;
        }
        
        currentRawBuffer += data.token;
    };

    activeWebsocket.onerror = () => {
        statusText.textContent = "WebSocket Error";
        solveBtn.disabled = false;
        solveBtn.style.opacity = '1';
        setActiveCard(null);
    };
}

// Execution Bindings
solveBtn.addEventListener('click', () => {
    const q = promptInput.value.trim();
    if (!q) return;
    
    resetUI();
    if (modeToggle.checked) {
        startStreamSolve(q);
    } else {
        startDirectSolve(q);
    }
});

copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(finalAnswerText.textContent);
    copyBtn.textContent = "Copied!";
    setTimeout(() => copyBtn.textContent = "Copy", 2000);
});

// Boot
loadProblemBank();
