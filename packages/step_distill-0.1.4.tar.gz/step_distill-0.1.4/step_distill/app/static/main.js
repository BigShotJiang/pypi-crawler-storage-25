const problemList = document.getElementById('problem-list');
const questionInput = document.getElementById('question-input');
const solveBtn = document.getElementById('solve-btn');
const reasoningBox = document.getElementById('reasoning-box');
const stepsToggle = document.getElementById('steps-toggle');
const statusIndicator = document.getElementById('connection-status');

let showSteps = true;
let ws = null;
let currentStageCard = null;
let currentStageContent = null;
let cardDelayCounter = 0;

// Load problems
async function loadProblems() {
  try {
    const res = await fetch('/api/problems');
    const problems = await res.json();
    
    problems.forEach(p => {
      const el = document.createElement('div');
      el.className = 'problem-item';
      
      const badgeLang = `<span class="problem-badge badge-${p.lang}">${p.lang}</span>`;
      const badgeLevel = `<span class="problem-badge badge-${p.level}">${p.level}</span>`;
      
      el.innerHTML = `<div>${badgeLang}${badgeLevel}</div>${p.text}`;
      el.onclick = () => questionInput.value = p.text;
      problemList.appendChild(el);
    });
  } catch (e) {
    console.error('Failed to load problems', e);
  }
}

// Toggle steps
stepsToggle.addEventListener('click', () => {
    showSteps = !showSteps;
    stepsToggle.classList.toggle('active', showSteps);
    applyStepsVisibility();
});

function applyStepsVisibility() {
    const cards = reasoningBox.querySelectorAll('.stage-card');
    cards.forEach(card => {
        if (!showSteps && card.dataset.stage !== 'verify' && card.dataset.stage !== 'error' && card.dataset.stage !== 'execute') {
            card.style.display = 'none';
        } else {
            card.style.display = 'block';
        }
    });
}

function createStageCard(stageName) {
    const card = document.createElement('div');
    card.className = 'stage-card';
    card.dataset.stage = stageName;
    
    const header = document.createElement('div');
    header.className = 'stage-header';
    header.innerText = stageName.toUpperCase() + (stageName === 'error' ? '' : ' STAGE');
    
    const content = document.createElement('div');
    content.className = 'stage-content active-cursor';
    
    card.appendChild(header);
    card.appendChild(content);
    reasoningBox.appendChild(card);
    
    if (!showSteps && stageName !== 'verify' && stageName !== 'error' && stageName !== 'execute') {
        card.style.display = 'none';
    }
    
    // Staggered slide-in animation
    setTimeout(() => {
        card.classList.add('show');
    }, cardDelayCounter * 200 + 10);
    cardDelayCounter++;
    
    return {card, content};
}

// Map logical stages to display stages
function mapLogicalStage(logicalStage) {
    const s = logicalStage.toLowerCase();
    if (s.includes('understand')) return 'understand';
    if (s.includes('plan')) return 'plan';
    if (s.includes('execute')) return 'execute';
    if (s.includes('verify')) return 'verify';
    if (s === 'error') return 'error';
    return 'understand'; // fallback
}

// Solve
solveBtn.addEventListener('click', () => {
    const question = questionInput.value.trim();
    if (!question) return;
    
    // Reset UI
    reasoningBox.innerHTML = '';
    cardDelayCounter = 0;
    currentStageCard = null;
    currentStageContent = null;
    solveBtn.disabled = true;
    solveBtn.innerText = 'Solving...';
    questionInput.disabled = true;
    
    // Setup WS
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${protocol}//${window.location.host}/api/stream`);
    
    ws.onopen = () => {
        statusIndicator.innerText = "● Generating";
        statusIndicator.style.color = "#f59e0b";
        ws.send(JSON.stringify({question}));
    };
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        const stage = mapLogicalStage(data.stage || 'understand');
        
        if (stage === 'done') {
            onComplete();
            return;
        }
        
        // If stage changed, create new card
        if (!currentStageCard || currentStageCard.dataset.stage !== stage) {
            if (currentStageContent) {
                currentStageContent.classList.remove('active-cursor');
            }
            const elems = createStageCard(stage);
            currentStageCard = elems.card;
            currentStageContent = elems.content;
            
            // Immediately show but without animation if missing tags logic
        }
        
        // Ensure the token text is appended
        let token = data.token;
        // Strip markdown stage representations if any accidentaly leaked
        token = token.replace(/\[(?:UNDERSTAND|PLAN|EXECUTE|VERIFY)\]\n?/g, '');
        
        currentStageContent.innerText += token;
        reasoningBox.scrollTop = reasoningBox.scrollHeight;
    };
    
    ws.onclose = () => {
        onComplete();
    };
    
    ws.onerror = (e) => {
        console.error(e);
        statusIndicator.innerText = "● Error";
        statusIndicator.style.color = "#ef4444";
        onComplete();
    };
});

function onComplete() {
    solveBtn.disabled = false;
    solveBtn.innerText = 'Solve';
    questionInput.disabled = false;
    statusIndicator.innerText = "● Ready";
    statusIndicator.style.color = "#10b981";
    
    if (currentStageContent) {
        currentStageContent.classList.remove('active-cursor');
    }
}

// Init
loadProblems();
