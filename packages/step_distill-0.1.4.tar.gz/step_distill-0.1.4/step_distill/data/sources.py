"""
Data sources for Step-Distill training pipeline.

Provides abstract DataSource base class and concrete implementations
for GSM8K, MATH, and VNHSGE datasets.
"""

from __future__ import annotations

import json
import os
import random
import re
from abc import ABC, abstractmethod
from typing import Any


class DataSource(ABC):
    """Abstract base class for dataset sources."""

    @abstractmethod
    def load(self) -> list[dict]:
        """Load all items from the source.

        Returns:
            List of dicts, each containing at minimum:
                - "question": str
                - "answer": str
        """
        ...

    def sample(self, n: int) -> list[dict]:
        """Return a random sample of *n* items."""
        data = self.load()
        return random.sample(data, min(n, len(data)))


class GSM8KSource(DataSource):
    """GSM8K dataset via HuggingFace ``datasets``.

    HuggingFace path: ``"gsm8k"``, config ``"main"``, split ``"train"``.
    Ground truth extraction: ``answer.split("####")[-1].strip()``.
    """

    def __init__(self, split: str = "train"):
        self.split = split

    def load(self) -> list[dict]:
        from datasets import load_dataset

        ds = load_dataset("gsm8k", "main", split=self.split)
        items: list[dict] = []
        for row in ds:
            question = row["question"]
            raw_answer = row["answer"]
            # GSM8K ground truth is after "####"
            answer = raw_answer.split("####")[-1].strip()
            items.append({"question": question, "answer": answer})
        return items


class MATHSource(DataSource):
    """MATH dataset via HuggingFace ``datasets``.

    HuggingFace path: ``"lighteval/MATH"``, split ``"train"``.
    Fields are ``"problem"`` and ``"solution"`` — we normalize to
    ``"question"`` and ``"answer"``.

    Ground truth is extracted via ``\\boxed{}`` (last match).
    """

    def __init__(self, split: str = "train"):
        self.split = split

    @staticmethod
    def extract_boxed(text: str) -> str:
        """Extract the last ``\\boxed{...}`` content from *text*."""
        if not text:
            return ""
        # Find all \boxed{...} occurrences, handle nested braces
        pattern = r"\\boxed\{"
        matches = list(re.finditer(pattern, text))
        if not matches:
            return ""

        # Take the last match and manually extract balanced braces
        last = matches[-1]
        start = last.end()  # right after "{"
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
            i += 1
        return text[start : i - 1]

    def load(self) -> list[dict]:
        from datasets import load_dataset

        ds = load_dataset("DigitalLearningGmbH/MATH-lighteval", split=self.split)
        items: list[dict] = []
        for row in ds:
            question = row["problem"]
            solution = row["solution"]
            answer = self.extract_boxed(solution)
            items.append({
                "question": question,
                "answer": answer,
                "level": row.get("level", ""),
                "type": row.get("type", ""),
            })
        return items


class VNHSGESource(DataSource):
    """VNHSGE dataset bundled inside the package.

    Located at ``step_distill/data/vnhsge/vnhsge_train.jsonl``.
    Fields: ``{"question": str, "answer": str, "options": list[str]}``.
    """

    def __init__(self):
        self._data_path = os.path.join(
            os.path.dirname(__file__), "vnhsge", "vnhsge_train.jsonl"
        )

    def load(self) -> list[dict]:
        import importlib.resources as pkg_resources
        
        try:
            data_file = pkg_resources.files("step_distill.data.vnhsge") / "vnhsge_train.jsonl"
            content = data_file.read_text(encoding="utf-8")
        except Exception as e:
            raise FileNotFoundError(
                "VNHSGE data file not found in package. "
                f"Error: {e}"
            )
            
        items: list[dict] = []
        for line in content.splitlines():
            line = line.strip()
            if line:
                items.append(json.loads(line))
        return items
