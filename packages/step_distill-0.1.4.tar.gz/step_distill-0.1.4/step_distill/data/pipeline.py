"""
TeacherPipeline — Generates structured 4-step reasoning traces using a large
teacher model and applies quality filters.

Architecture follows the validated Kaggle notebook
(``.claude/nckh-gendata-math.ipynb``):

    Teacher LLM (vLLM / OpenAI-compatible)
        -> batch generate with temperature=0.6, top_p=0.95
        -> 3-layer quality filters (syntax -> math -> consistency)
        -> JSONL output with 8-field schema
        -> Resume support via existing output IDs
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "Given a problem, structure your reasoning clearly using the required four tags:\n"
    "#### UNDERSTAND ####, #### PLAN ####, #### EXECUTE ####, #### VERIFY ####\n"
    "Detail your process within each tag to provide a transparent and verifiable final answer."
)

PROMPT_TEMPLATE = (
    "You are an expert mathematics problem solver. Your goal is to provide a clear, logical solution.\n"
    "**Problem**: {question}\n"
    "**Reference Solution**: {original_solution}\n"
    "**CRITICAL RULES**:\n"
    "1. Follow the Reference Solution's numerical results and final answer EXACTLY\n"
    "2. Preserve all LaTeX formatting (\\frac{{}}, \\sqrt{{}}, etc.)\n"
    "3. Use the exact 4-step structure below\n"
    "4. Verify your final answer independently (do NOT copy from reference)\n"
    "#### UNDERSTAND ####\n"
    "- Domain: [e.g., Algebra, Geometry, Number Theory]\n"
    "- Given: [Key variables, equations, constraints]\n"
    "- Goal: [What we need to find or prove]\n"
    "#### PLAN ####\n"
    "- Key formulas/Theorems: [List relevant theorems or formulas]\n"
    "- Approach: [2-3 sentence high-level strategy]\n"
    "#### EXECUTE ####\n"
    "[Step-by-step calculations with full LaTeX]\n"
    "#### VERIFY ####\n"
    "**Mandatory independent checks (perform without looking at reference)**:\n"
    "1. Substitution Test: Plug answer back into original equation/constraints\n"
    "2. Sanity/Bounds Check: Does it satisfy mathematical constraints?\n"
    "3. Alternative Method (if applicable): Quick check with another approach\n"
    "Now solve the problem. Always end with: The answer is \\boxed{{final_answer}}"
)


# ---------------------------------------------------------------------------
# Quality Filters
# ---------------------------------------------------------------------------

def _filter_syntax(response: str, **kwargs: Any) -> bool:
    """Check that all 4 stage tags appear in the correct order.

    Tags: ``#### UNDERSTAND ####``, ``#### PLAN ####``,
    ``#### EXECUTE ####``, ``#### VERIFY ####``
    """
    tags = ["UNDERSTAND", "PLAN", "EXECUTE", "VERIFY"]
    last_pos = -1
    for tag in tags:
        pattern = re.compile(
            rf"(?:####|###|##|\*\*)\s*{tag}\s*(?:####|###|##|\*\*)?",
            re.IGNORECASE,
        )
        match = pattern.search(response)
        if match is None:
            return False
        if match.start() <= last_pos:
            return False
        last_pos = match.start()
    return True


def _extract_answer(text: str) -> str:
    """Extract the last ``\\boxed{...}`` answer from *text*.

    Falls back to ``#### N`` pattern or last number.
    """
    if not text:
        return ""
    tail = text[-800:]
    if "\\boxed{" in tail:
        idx = tail.rfind("\\boxed{")
        i = idx + 7
        stack = 1
        content: list[str] = []
        while i < len(tail) and stack > 0:
            if tail[i] == "{":
                stack += 1
            elif tail[i] == "}":
                stack -= 1
            if stack > 0:
                content.append(tail[i])
            i += 1
        return "".join(content).strip()
    m = re.search(r"####\s*(.+?)$", text, re.MULTILINE)
    if m:
        return m.group(1).strip()
    nums = re.findall(r"[-+]?\d*\.?\d+", text)
    return nums[-1] if nums else ""


def _normalize_latex(text: str) -> str:
    """Lightweight LaTeX normalisation for answer comparison."""
    if not text:
        return ""
    text = str(text).strip()
    text = re.sub(r"\\(displaystyle|mathrm|text|bf|it|left|right|big|Big)\b\s*", "", text)
    text = text.replace("\\ ", " ").replace("{ ", "{").replace(" }", "}").replace("$", "")
    return re.sub(r"\s+", " ", text).strip()


def _filter_math(response: str, ground_truth: str = "", **kwargs: Any) -> bool:
    """Verify that the model's extracted answer matches *ground_truth*."""
    pred = _normalize_latex(_extract_answer(response))
    gt = _normalize_latex(ground_truth)
    if not gt or not pred:
        return False
    return pred == gt


def _extract_cot_steps(text: str) -> dict[str, str]:
    """Extract structured 4-step content from *text*."""
    steps: dict[str, str] = {"understand": "", "plan": "", "execute": "", "verify": ""}
    patterns = {
        "understand": r"(?:####|###|##|\*\*)\s*UNDERSTAND\s*(?:####|###|##|\*\*)?\s*(.*?)(?=(?:####|###|##|\*\*)\s*PLAN|$)",
        "plan": r"(?:####|###|##|\*\*)\s*PLAN\s*(?:####|###|##|\*\*)?\s*(.*?)(?=(?:####|###|##|\*\*)\s*EXECUTE|$)",
        "execute": r"(?:####|###|##|\*\*)\s*EXECUTE\s*(?:####|###|##|\*\*)?\s*(.*?)(?=(?:####|###|##|\*\*)\s*VERIFY|$)",
        "verify": r"(?:####|###|##|\*\*)\s*VERIFY\s*(?:####|###|##|\*\*)?\s*(.*?)(?=$)",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        if match:
            steps[key] = match.group(1).strip()
    return steps


def _filter_consistency(response: str, **kwargs: Any) -> bool:
    """Check that numbers in EXECUTE are compatible with formulas in PLAN.

    Heuristic: at least one number from PLAN appears in EXECUTE.
    """
    steps = _extract_cot_steps(response)
    plan = steps.get("plan", "")
    execute = steps.get("execute", "")
    if not plan or not execute:
        return False
    plan_numbers = set(re.findall(r"[-+]?\d+\.?\d*", plan))
    if not plan_numbers:
        return True
    execute_numbers = set(re.findall(r"[-+]?\d+\.?\d*", execute))
    overlap = plan_numbers & execute_numbers
    return len(overlap) > 0


QUALITY_FILTERS: dict[str, Any] = {
    "syntax": _filter_syntax,
    "math": _filter_math,
    "consistency": _filter_consistency,
}


# ---------------------------------------------------------------------------
# TeacherPipeline
# ---------------------------------------------------------------------------

class TeacherPipeline:
    """Async teacher generation pipeline with quality filtering.

    Generates structured 4-step reasoning traces from a large teacher model
    and applies syntax, math, and consistency filters.

    Parameters
    ----------
    teacher_model : str
        Any HF model ID or OpenAI-compatible endpoint.
    temperature : float
        Sampling temperature (default 0.6, from notebook).
    top_p : float
        Nucleus sampling threshold (default 0.95, from notebook).
    max_tokens : int
        Maximum generation length (default 2048).
    api_key : str | None
        API key for OpenAI-compatible APIs.
    api_base : str | None
        Base URL for OpenAI-compatible APIs.
    """

    def __init__(
        self,
        teacher_model: str,
        temperature: float = 0.6,
        top_p: float = 0.95,
        max_tokens: int = 2048,
        api_key: str | None = None,
        api_base: str | None = None,
    ):
        self.teacher_model = teacher_model
        self.temperature = temperature
        self.top_p = top_p
        self.max_tokens = max_tokens
        self.api_key = api_key
        self.api_base = api_base

    # ------------------------------------------------------------------
    # Resume support
    # ------------------------------------------------------------------

    @staticmethod
    def _load_existing_ids(output_path: str) -> set[str]:
        """Read existing output JSONL and collect all ``"id"`` values."""
        ids: set[str] = set()
        if os.path.exists(output_path):
            with open(output_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            obj = json.loads(line)
                            if "id" in obj:
                                ids.add(obj["id"])
                        except json.JSONDecodeError:
                            continue
        return ids

    # ------------------------------------------------------------------
    # Generation backends
    # ------------------------------------------------------------------

    def _generate_openai(self, prompts: list[str]) -> list[str]:
        """Generate via OpenAI-compatible API (e.g., vLLM served model)."""
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError(
                "openai package is required for API-based generation. "
                "pip install openai"
            )

        client = OpenAI(
            api_key=self.api_key or os.environ.get("OPENAI_API_KEY", "dummy"),
            base_url=self.api_base,
        )

        responses: list[str] = []
        for prompt in prompts:
            try:
                completion = client.chat.completions.create(
                    model=self.teacher_model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=self.temperature,
                    top_p=self.top_p,
                    max_tokens=self.max_tokens,
                )
                responses.append(completion.choices[0].message.content or "")
            except Exception as e:
                logger.warning(f"OpenAI API error: {e}")
                responses.append("")
        return responses

    def _generate_vllm(self, prompts: list[str]) -> list[str]:
        """Generate via local vLLM engine."""
        try:
            from vllm import LLM, SamplingParams
        except ImportError:
            raise ImportError(
                "vllm package is required for local generation. pip install vllm"
            )

        stop_tokens = ["\x3c|endoftext|\x3e", "\x3c|im_end|\x3e"]
        sampling_params = SamplingParams(
            temperature=self.temperature,
            top_p=self.top_p,
            max_tokens=self.max_tokens,
            stop=stop_tokens,
        )

        llm = LLM(
            model=self.teacher_model,
            dtype="half",
            gpu_memory_utilization=0.90,
            max_model_len=4096,
            trust_remote_code=True,
            enforce_eager=True,
        )

        outputs = llm.generate(prompts, sampling_params)
        return [o.outputs[0].text for o in outputs]

    def _generate_batch(self, prompts: list[str]) -> list[str]:
        """Route to the appropriate backend."""
        if self.api_base:
            return self._generate_openai(prompts)
        else:
            return self._generate_vllm(prompts)

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def generate(
        self,
        sources: list[str],
        output_path: str,
        quality_filters: list[str] | None = None,
        max_samples: int | None = None,
        resume: bool = True,
        batch_size: int = 50,
    ) -> list[dict]:
        """Generate structured reasoning traces.

        Parameters
        ----------
        sources : list[str]
            Dataset source names: ``["gsm8k", "math", "vnhsge"]`` or paths
            to JSONL files with ``{"question", "answer"}`` rows.
        output_path : str
            Path to the output JSONL file.
        quality_filters : list[str] | None
            Which filters to apply. Defaults to all three:
            ``["syntax", "math", "consistency"]``.
        max_samples : int | None
            Cap on total samples to process. ``None`` = all.
        resume : bool
            If True, skip IDs already in *output_path*.
        batch_size : int
            Number of prompts per generation batch.

        Returns
        -------
        list[dict]
            All generated (and filtered) records.
        """
        if quality_filters is None:
            quality_filters = ["syntax", "math", "consistency"]

        # -- Load source data -----------------------------------------------
        from step_distill.data.sources import GSM8KSource, MATHSource, VNHSGESource

        source_map = {
            "gsm8k": GSM8KSource,
            "math": MATHSource,
            "vnhsge": VNHSGESource,
        }

        all_items: list[dict] = []
        for src_name in sources:
            if src_name.lower() in source_map:
                src = source_map[src_name.lower()]()
                all_items.extend(src.load())
            elif os.path.exists(src_name):
                # Custom JSONL file
                with open(src_name, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            all_items.append(json.loads(line))
            else:
                logger.warning(f"Unknown source: {src_name}, skipping.")

        if max_samples:
            all_items = all_items[:max_samples]

        logger.info(f"Loaded {len(all_items)} items from {sources}")

        # -- Resume logic ---------------------------------------------------
        existing_ids: set[str] = set()
        if resume:
            existing_ids = self._load_existing_ids(output_path)
            logger.info(f"Resume: found {len(existing_ids)} existing IDs, skipping them.")

        # -- Assign IDs & filter already-done --------------------------------
        items_to_process: list[tuple[str, dict]] = []
        for idx, item in enumerate(all_items):
            item_id = item.get("id", f"sample_{idx}")
            if item_id not in existing_ids:
                items_to_process.append((item_id, item))

        logger.info(f"Items to generate: {len(items_to_process)}")
        if not items_to_process:
            logger.info("Nothing to generate — all items already processed.")
            return []

        # -- Batch generation loop ------------------------------------------
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        results: list[dict] = []

        with open(output_path, "a", encoding="utf-8") as f_out:
            for batch_start in range(0, len(items_to_process), batch_size):
                batch = items_to_process[batch_start : batch_start + batch_size]

                prompts = []
                for _, item in batch:
                    q = item.get("question", "")
                    sol = item.get("answer") or item.get("solution") or item.get("original_solution") or ""
                    prompts.append(PROMPT_TEMPLATE.format(
                        question=q, original_solution=sol,
                    ))

                logger.info(
                    f"Generating batch {batch_start // batch_size + 1} "
                    f"({len(prompts)} items)..."
                )
                responses = self._generate_batch(prompts)

                for j, (item_id, item) in enumerate(batch):
                    response = responses[j] if j < len(responses) else ""
                    gt = item.get("answer") or item.get("solution") or ""

                    # -- Apply quality filters ------------------------------
                    passed = True
                    for filt_name in quality_filters:
                        filt_fn = QUALITY_FILTERS.get(filt_name)
                        if filt_fn is None:
                            continue
                        if filt_name == "math":
                            if not filt_fn(response, ground_truth=gt):
                                passed = False
                                break
                        else:
                            if not filt_fn(response):
                                passed = False
                                break

                    if not passed:
                        continue

                    pred = _normalize_latex(_extract_answer(response))
                    gt_norm = _normalize_latex(_extract_answer(gt)) if gt else ""

                    record = {
                        "id": item_id,
                        "question": item.get("question", ""),
                        "original_solution": gt,
                        "cot_4steps": _extract_cot_steps(response),
                        "model_prediction": pred,
                        "ground_truth": gt_norm,
                        "is_correct": pred == gt_norm if gt_norm else False,
                        "full_response": response,
                    }
                    f_out.write(json.dumps(record, ensure_ascii=False) + "\n")
                    results.append(record)

                f_out.flush()
                logger.info(
                    f"Batch {batch_start // batch_size + 1} done. "
                    f"Total passed: {len(results)}"
                )

        logger.info(
            f"Generation complete. {len(results)} samples passed filters "
            f"out of {len(items_to_process)} processed."
        )
        return results
