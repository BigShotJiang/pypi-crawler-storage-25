"""
StepDistillConfig — Pydantic v2 configuration for the step-distill training pipeline.

Supports two construction patterns:

1. Nested (from YAML):
    config = StepDistillConfig.from_yaml("config.yaml")

2. Flat (from Python):
    config = StepDistillConfig(
        student_model="Qwen/Qwen2.5-3B-Instruct",
        alpha=0.15, beta=0.35, gamma=0.35, delta=0.15, epsilon=0.10,
        lora_rank=16, lora_alpha=32, ...
    )

All default values match the paper exactly:
    α=0.15, β=0.35, γ=0.35, δ=0.15, ε=0.10
    LoRA rank=16, alpha=32, dropout=0.05
    LR=1e-4, warmup=300, batch_size=1, grad_accum=4, max_seq=1024
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------


class LossWeightsConfig(BaseModel):
    """Loss weights for the 4-stage Step-Aware Loss.

    Weights sum to 1.10 — importance multipliers, not a probability simplex.
    β/α = γ/α = 2.33 — PLAN/EXECUTE penalized 2.33× heavier than UNDERSTAND.
    """

    alpha: float = Field(default=0.15, description="UNDERSTAND stage weight")
    beta: float = Field(default=0.35, description="PLAN stage weight")
    gamma: float = Field(default=0.35, description="EXECUTE stage weight")
    delta: float = Field(default=0.15, description="VERIFY stage weight")
    epsilon: float = Field(default=0.10, description="Transition penalty weight")

    @model_validator(mode="after")
    def validate_weight_sum(self) -> "LossWeightsConfig":
        """Validate that weights sum to approximately 1.10 (within 0.01 tolerance)."""
        weight_sum = self.alpha + self.beta + self.gamma + self.delta + self.epsilon
        if abs(weight_sum - 1.10) > 0.01:
            raise ValueError(
                f"Loss weights must sum to ~1.10 (within ±0.01), "
                f"got {weight_sum:.4f}. "
                f"Current weights: α={self.alpha}, β={self.beta}, γ={self.gamma}, "
                f"δ={self.delta}, ε={self.epsilon}"
            )
        return self


class LoRAConfig(BaseModel):
    """LoRA (Low-Rank Adaptation) configuration.

    Paper uses fixed rank=16. Do not implement adaptive rank.
    """

    rank: int = Field(default=16, description="LoRA rank (must be power of 2)")
    alpha: int = Field(default=32, description="LoRA alpha scaling factor")
    dropout: float = Field(default=0.05, description="LoRA dropout rate")
    target_modules: list[str] = Field(
        default=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
        description="Model modules to apply LoRA to",
    )

    @model_validator(mode="after")
    def validate_rank_power_of_2(self) -> "LoRAConfig":
        """Validate that LoRA rank is a power of 2."""
        if self.rank <= 0 or (self.rank & (self.rank - 1)) != 0:
            raise ValueError(
                f"lora_rank must be a power of 2 (2, 4, 8, 16, 32, 64, ...), "
                f"got {self.rank}"
            )
        return self


class TrainingConfig(BaseModel):
    """Training hyperparameters — all defaults match the paper exactly."""

    epochs: int = Field(default=2, description="Number of training epochs")
    learning_rate: float = Field(default=1e-4, description="Peak learning rate")
    min_lr: float = Field(default=1e-6, description="Minimum learning rate for cosine decay")
    scheduler: str = Field(
        default="cosine_with_warmup", description="LR scheduler type"
    )
    warmup_steps: int = Field(default=300, description="Number of warmup steps")
    batch_size: int = Field(default=1, description="Per-device batch size")
    gradient_accumulation_steps: int = Field(
        default=4, description="Gradient accumulation steps"
    )
    max_seq_length: int = Field(default=1024, description="Maximum sequence length")
    weight_decay: float = Field(default=0.01, description="Weight decay")
    max_grad_norm: float = Field(default=1.0, description="Maximum gradient norm for clipping")
    label_smoothing: float = Field(default=0.1, description="Label smoothing factor")
    seed: int = Field(default=42, description="Random seed for reproducibility")


class EfficiencyConfig(BaseModel):
    """Hardware efficiency settings — optimized for T4 GPUs."""

    use_sdpa: bool = Field(
        default=True,
        description="Use Scaled Dot-Product Attention (PyTorch 2.0+)",
    )
    mixed_precision: Literal["fp16", "bf16", "no"] = Field(
        default="fp16", description="Mixed precision mode"
    )
    gradient_checkpointing: bool = Field(
        default=True, description="Enable gradient checkpointing to reduce VRAM"
    )


# ---------------------------------------------------------------------------
# Flat-to-nested field mapping
# ---------------------------------------------------------------------------

_FLAT_TO_NESTED: dict[str, tuple[str, str]] = {
    # loss_weights
    "alpha": ("loss_weights", "alpha"),
    "beta": ("loss_weights", "beta"),
    "gamma": ("loss_weights", "gamma"),
    "delta": ("loss_weights", "delta"),
    "epsilon": ("loss_weights", "epsilon"),
    # lora
    "lora_rank": ("lora", "rank"),
    "lora_alpha": ("lora", "alpha"),
    "lora_dropout": ("lora", "dropout"),
    "target_modules": ("lora", "target_modules"),
    # training
    "num_epochs": ("training", "epochs"),
    "learning_rate": ("training", "learning_rate"),
    "min_lr": ("training", "min_lr"),
    "scheduler": ("training", "scheduler"),
    "warmup_steps": ("training", "warmup_steps"),
    "batch_size": ("training", "batch_size"),
    "gradient_accumulation_steps": ("training", "gradient_accumulation_steps"),
    "max_seq_length": ("training", "max_seq_length"),
    "weight_decay": ("training", "weight_decay"),
    "max_grad_norm": ("training", "max_grad_norm"),
    "label_smoothing": ("training", "label_smoothing"),
    "seed": ("training", "seed"),
    # efficiency
    "use_sdpa": ("efficiency", "use_sdpa"),
    "mixed_precision": ("efficiency", "mixed_precision"),
    "gradient_checkpointing": ("efficiency", "gradient_checkpointing"),
}


# ---------------------------------------------------------------------------
# Main config
# ---------------------------------------------------------------------------


class StepDistillConfig(BaseModel):
    """Full configuration for the step-distill training pipeline.

    Supports both nested construction (from YAML) and flat construction
    (from Python kwargs). All defaults match the paper exactly.

    Example (flat):
        config = StepDistillConfig(
            student_model="Qwen/Qwen2.5-3B-Instruct",
            alpha=0.15, beta=0.35, gamma=0.35, delta=0.15, epsilon=0.10,
            lora_rank=16, lora_alpha=32, lora_dropout=0.05,
        )

    Example (nested / YAML):
        config = StepDistillConfig.from_yaml("config.yaml")
    """

    student_model: str = Field(
        default="Qwen/Qwen2.5-3B-Instruct",
        description="HuggingFace model ID or local path for the student model",
    )
    teacher_model: str = Field(
        default="Qwen/Qwen2.5-32B-Instruct",
        description="HuggingFace model ID or OpenAI-compatible API endpoint for teacher",
    )

    loss_weights: LossWeightsConfig = Field(
        default_factory=LossWeightsConfig,
        description="Step-Aware Loss weights (α, β, γ, δ, ε)",
    )
    lora: LoRAConfig = Field(
        default_factory=LoRAConfig,
        description="LoRA adapter configuration",
    )
    training: TrainingConfig = Field(
        default_factory=TrainingConfig,
        description="Training hyperparameters",
    )
    efficiency: EfficiencyConfig = Field(
        default_factory=EfficiencyConfig,
        description="Hardware efficiency settings",
    )

    @model_validator(mode="before")
    @classmethod
    def remap_flat_kwargs(cls, data: Any) -> Any:
        """Remap flat keyword arguments to nested structure.

        This allows constructing StepDistillConfig with flat kwargs like:
            StepDistillConfig(alpha=0.15, lora_rank=16, num_epochs=2)
        which get remapped to:
            StepDistillConfig(
                loss_weights={"alpha": 0.15},
                lora={"rank": 16},
                training={"epochs": 2},
            )
        """
        if not isinstance(data, dict):
            return data

        remapped = dict(data)
        nested_updates: dict[str, dict[str, Any]] = {}

        for flat_key, (section, field_name) in _FLAT_TO_NESTED.items():
            if flat_key in remapped:
                value = remapped.pop(flat_key)
                nested_updates.setdefault(section, {})[field_name] = value

        # Merge nested updates with any existing nested dicts
        for section, fields in nested_updates.items():
            if section in remapped and isinstance(remapped[section], dict):
                remapped[section].update(fields)
            elif section not in remapped:
                remapped[section] = fields

        return remapped

    # -------------------------------------------------------------------
    # Class methods
    # -------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, path: str | Path) -> "StepDistillConfig":
        """Load configuration from a YAML file.

        Args:
            path: Path to the YAML configuration file.

        Returns:
            A validated StepDistillConfig instance.

        Raises:
            FileNotFoundError: If the YAML file does not exist.
            ValueError: If validation fails (weight sum, rank, etc.)
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)

        if raw is None:
            raw = {}

        return cls.model_validate(raw)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "StepDistillConfig":
        """Create configuration from a dictionary.

        Supports both flat and nested dictionary formats.

        Args:
            d: Configuration dictionary (flat or nested).

        Returns:
            A validated StepDistillConfig instance.
        """
        return cls.model_validate(d)

    # -------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a nested dictionary matching the YAML structure."""
        return self.model_dump()

    def to_yaml(self, path: str | Path | None = None) -> str:
        """Serialize to YAML string, optionally writing to a file.

        Args:
            path: If provided, write the YAML to this file path.

        Returns:
            The YAML string representation.
        """
        data = self.to_dict()
        yaml_str = yaml.dump(data, default_flow_style=False, sort_keys=False)

        if path is not None:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(yaml_str)

        return yaml_str

    @classmethod
    def defaults(cls) -> "StepDistillConfig":
        """Return a config with all paper-default values."""
        return cls()

    def __repr__(self) -> str:
        return (
            f"StepDistillConfig(\n"
            f"  student={self.student_model},\n"
            f"  teacher={self.teacher_model},\n"
            f"  loss_weights=[α={self.loss_weights.alpha}, β={self.loss_weights.beta}, "
            f"γ={self.loss_weights.gamma}, δ={self.loss_weights.delta}, "
            f"ε={self.loss_weights.epsilon}],\n"
            f"  lora=rank{self.lora.rank}/α{self.lora.alpha},\n"
            f"  training={self.training.epochs}ep@lr{self.training.learning_rate},\n"
            f"  efficiency={'fp16' if self.efficiency.mixed_precision == 'fp16' else self.efficiency.mixed_precision}"
            f"+{'sdpa' if self.efficiency.use_sdpa else 'eager'}"
            f"+{'ckpt' if self.efficiency.gradient_checkpointing else 'no-ckpt'}\n"
            f")"
        )
