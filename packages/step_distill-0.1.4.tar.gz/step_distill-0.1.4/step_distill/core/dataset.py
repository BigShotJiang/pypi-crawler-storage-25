"""
StepAwareDataset — Prepares structured reasoning traces for model training.

Parses JSONL data, constructs tagged text representations, and securely tokenizes
them alongside their reasoning step binary masks via LabelMatrixParser.
"""

import json
from pathlib import Path
from typing import Any, Dict

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

from step_distill.core.parser import LabelMatrixParser, StepType


class StepAwareDataset(Dataset):
    """Dataset for structured reasoning traces with token-level stage masks.

    Loads JSONL tracking data where `cot_4steps` contains the stages.
    Tokenizes traces to a maximum length with corresponding per-Token stage masks
    produced by the `LabelMatrixParser`. Identifies tokens for UNDERSTAND, PLAN,
    EXECUTE, VERIFY, and IGNORE stages.
    """

    def __init__(
        self,
        data_path: Path | str,
        tokenizer: Any,
        max_length: int = 1024,
        filter_correct_only: bool = True,
    ):
        self.data_path = Path(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.filter_correct_only = filter_correct_only
        self.parser = LabelMatrixParser()

        # Enforce right padding for causal LM training
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            if hasattr(self.tokenizer, "pad_token_id") and getattr(self.tokenizer, "pad_token_id") is None:
                self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        self.tokenizer.padding_side = "right"

        self.samples = self._load_data()

    def _load_data(self) -> list[Dict[str, str]]:
        samples = []
        if not self.data_path.exists():
            return samples

        with open(self.data_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if self.filter_correct_only and not data.get("is_correct", True):
                    continue

                cot = data.get("cot_4steps", {})
                if not all(k in cot for k in ["understand", "plan", "execute", "verify"]):
                    continue

                samples.append(data)

        return samples

    def get_full_text(self, item: Dict[str, Any]) -> str:
        """Constructs the canonical tagged input string."""
        question = item.get("question", "")
        ground_truth = item.get("ground_truth", "")
        cot = item.get("cot_4steps", {})

        text = f"Question: {question}\n\nSolution:\n"
        # Always output exactly in standard order
        for stype in [StepType.UNDERSTAND, StepType.PLAN, StepType.EXECUTE, StepType.VERIFY]:
            text += f"{stype.tag}\n{cot[stype.value]}\n\n"
        
        text += f"Final Answer: {ground_truth}"
        return text

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.samples[idx]
        full_text = self.get_full_text(item)

        # Build raw boolean masks out of the untruncated tokenizer output
        try:
            masks = self.parser.parse(full_text, self.tokenizer, add_special_tokens=True)
        except ValueError:
            # Fallback for mock tokenizers in tests that don't support return_offsets_mapping
            import numpy as np
            masks = {k: np.zeros(len(full_text), dtype=bool) for k in self.parser.STAGE_KEYS}

        encoding = self.tokenizer(
            full_text,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )

        input_ids = encoding["input_ids"].squeeze(0)
        attention_mask = encoding["attention_mask"].squeeze(0)

        # Prepare labels and mask padding
        labels = input_ids.clone()
        labels[attention_mask == 0] = -100

        result = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels,
        }

        # Truncate and uniformly pad sequence boolean masks
        for key in self.parser.STAGE_KEYS:
            mask_arr = masks.get(key)
            if mask_arr is None:
                # If a stage is completely missing, the parser might omit the key
                # Or it could be returning empty arrays. Just in case, create empty.
                valid_len = min(self.max_length, input_ids.shape[0])
                import numpy as np
                mask_arr = np.zeros(valid_len, dtype=bool)

            # Truncate
            truncated_arr = mask_arr[:self.max_length]
            mask_tensor = torch.from_numpy(truncated_arr)

            # Check if padding is needed
            curr_len = mask_tensor.shape[0]
            if curr_len < self.max_length:
                pad_len = self.max_length - curr_len
                # F.pad pads the last dimension by (left, right)
                mask_tensor = F.pad(mask_tensor, (0, pad_len), value=False)
            
            result[f"mask_{key}"] = mask_tensor

        return result
