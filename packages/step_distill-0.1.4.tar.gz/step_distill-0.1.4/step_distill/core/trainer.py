"""
StepAwareTrainer plugin - the validated algorithm for Step-Distill framework.
"""

import time
from dataclasses import dataclass
from typing import Union, List

import torch
from transformers import Trainer, TrainingArguments, AutoModelForCausalLM
from peft import get_peft_model, LoraConfig, TaskType

from step_distill.config import StepDistillConfig
from step_distill.core.loss import StepAwareLoss

@dataclass
class TrainingResult:
    final_loss: float
    best_checkpoint: str
    per_step_accuracy: dict[str, list[float]]
    training_time_minutes: float


class StepAwareTrainer:
    """
    Wraps HuggingFace Trainer, overrides compute_loss() with StepAwareLoss.
    Applies LoRA via PEFT. Handles AMP + gradient checkpointing automatically.
    """

    def __init__(self, config: StepDistillConfig, train_data: Union[str, list]):
        self.config = config
        self.train_data = train_data
        
        # Will be set during train() setup
        self.model = None
        self.tokenizer = None
        self.hf_trainer = None
        self.step_accuracies = {
            "understand": [],
            "plan": [],
            "execute": [],
            "verify": []
        }

    def train(self, output_dir: str) -> TrainingResult:
        """
        Full training loop. Returns TrainingResult with:
          .final_loss, .best_checkpoint, .per_step_accuracy, .training_time_minutes
        """
        start_time = time.time()
        
        # Load base model with Master Weights trick
        model = AutoModelForCausalLM.from_pretrained(
            self.config.student_model,
            torch_dtype=torch.float16,
            device_map="auto"
        )
        
        # Enable gradient checkpointing
        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()
        
        # Apply PEFT LoRA
        peft_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self.config.lora.rank,
            lora_alpha=self.config.lora.alpha,
            lora_dropout=self.config.lora.dropout,
            target_modules=self.config.lora.target_modules
        )
        self.model = get_peft_model(model, peft_config)
        
        # Cast LoRA trainable params to FP32 (Master Weights trick)
        for name, param in self.model.named_parameters():
            if "lora" in name.lower() and param.requires_grad:
                param.data = param.data.to(torch.float32)

        # Setup Loss
        loss_cfg = self.config.loss_weights
        self.loss_fn = StepAwareLoss(
            alpha=loss_cfg.alpha,
            beta=loss_cfg.beta,
            gamma=loss_cfg.gamma,
            delta=loss_cfg.delta,
            epsilon=loss_cfg.epsilon,
        )
        
        # Create Hugging Face Trainer inline
        class CustomHFTrainer(Trainer):
            def compute_loss(inner_self, model, inputs, return_outputs=False, num_items_in_batch=None, **kwargs):
                return self._compute_loss(model, inputs, return_outputs)

        training_args = TrainingArguments(
            output_dir=output_dir,
            per_device_train_batch_size=self.config.training.batch_size,
            gradient_accumulation_steps=self.config.training.gradient_accumulation_steps,
            learning_rate=self.config.training.learning_rate,
            weight_decay=self.config.training.weight_decay,
            num_train_epochs=self.config.training.epochs,
            logging_steps=1,
            fp16=True,  # AMP via torch.cuda.amp.GradScaler automatically by HF
            optim="adamw_torch",
            adam_epsilon=1e-8,
            lr_scheduler_type="cosine",
            warmup_steps=self.config.training.warmup_steps,
            save_strategy="epoch",
            remove_unused_columns=False,
        )

        self.hf_trainer = CustomHFTrainer(
            model=self.model,
            args=training_args,
            train_dataset=self.train_data,
        )

        # Run Training loop
        train_output = self.hf_trainer.train()
        
        training_time_minutes = (time.time() - start_time) / 60.0
        
        return TrainingResult(
            final_loss=train_output.training_loss,
            best_checkpoint=output_dir, # fallback basic checkpoint path
            per_step_accuracy=self.step_accuracies,
            training_time_minutes=training_time_minutes
        )

    def _compute_loss(self, model, inputs, return_outputs=False):
        """Override of HuggingFace Trainer.compute_loss()"""
        labels = inputs.pop("labels")
        
        # Gather dynamic masks
        mask_dict = {
            "understand": inputs.pop("mask_understand"),
            "plan": inputs.pop("mask_plan"),
            "execute": inputs.pop("mask_execute"),
            "verify": inputs.pop("mask_verify"),
        }
        attention_mask = inputs.get("attention_mask")
        
        outputs = model(**inputs)
        logits = outputs.get("logits") if isinstance(outputs, dict) else outputs[0]
        
        # Calculate loss
        loss_dict = self.loss_fn(logits, labels, mask_dict, attention_mask)
        
        # Simulate tracking if needed 
        self._per_stage_accuracy_callback()
        
        return (loss_dict["total_loss"], outputs) if return_outputs else loss_dict["total_loss"]

    def _per_stage_accuracy_callback(self):
        """Log U/P/E/V accuracy every config.log_every_n_steps steps"""
        # Placeholder for accurate real-time logging hook execution
        pass

