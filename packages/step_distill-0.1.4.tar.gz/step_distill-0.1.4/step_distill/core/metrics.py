"""
Evaluation Metrics for NanoReason validation logic.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from step_distill.data.pipeline import _extract_cot_steps, _extract_answer


class AccuracyMetric:
    def compute(self, predictions: list[str], ground_truths: list[str]) -> float:
        """Exact match with normalization:
        - Strip $, \boxed{}, commas, trailing units (cm, kg, etc.)
        - Float comparison within 1e-3 tolerance
        - Fraction normalization: "1/2" == "0.5"
        """
        if not predictions or len(predictions) != len(ground_truths):
            return 0.0

        correct = 0
        for p, g in zip(predictions, ground_truths):
            if self._is_match(p, g):
                correct += 1

        return correct / len(predictions)

    def _normalize(self, text: str) -> str:
        if not text:
            return ""
        # Handle if it contains \boxed{}
        if "\\boxed{" in text:
            # We reuse internal extractor if the prediction is full text
            text = _extract_answer(text)
        
        text = str(text).strip()
        text = text.replace("$", "").replace(",", "")
        # Remove common units (very basic)
        text = re.sub(r"\s*(?:cm|kg|m|g|s|hz)\b", "", text, flags=re.IGNORECASE).strip()

        # Try to convert fraction string to float representation
        if bool(re.match(r"^-?\d+/\d+$", text)):
            try:
                num, den = text.split("/")
                text = str(float(num) / float(den))
            except ValueError:
                pass
        return text

    def _is_match(self, pred: str, gt: str) -> bool:
        norm_pred = self._normalize(pred)
        norm_gt = self._normalize(gt)

        if norm_pred == norm_gt:
            return True

        # Float comparison fallback
        try:
            fp = float(norm_pred)
            fg = float(norm_gt)
            return abs(fp - fg) <= 1e-3
        except ValueError:
            pass

        return False


class RFSMetric:
    """Reasoning Format Score — measures Form Competence.
    RFS(g) = (1/4) * sum(1_s(g) for s in {U,P,E,V})
    1_s(g) = 1 if stage s present with >= 10 chars of content
    """
    
    def compute_single(self, response: str) -> float:
        steps = _extract_cot_steps(response)
        score = 0.0
        for stage in ["understand", "plan", "execute", "verify"]:
            if len(steps.get(stage, "").strip()) >= 10:
                score += 0.25
        return score

    def compute(self, responses: list[str]) -> dict[str, Any]:
        if not responses:
            return {"rfs_mean": 0.0, "rfs_full": 0.0, "per_stage": {}}

        scores = [self.compute_single(r) for r in responses]
        rfs_mean = sum(scores) / len(scores)
        rfs_full = sum(1.0 for s in scores if s == 1.0) / len(scores)

        # compute per-stage averages
        per_stage_counts = {"understand": 0, "plan": 0, "execute": 0, "verify": 0}
        for r in responses:
            steps = _extract_cot_steps(r)
            for stage in per_stage_counts:
                if len(steps.get(stage, "").strip()) >= 10:
                    per_stage_counts[stage] += 1
                    
        per_stage = {k: v / len(responses) for k, v in per_stage_counts.items()}

        return {
            "rfs_mean": rfs_mean,
            "rfs_full": rfs_full,
            "per_stage": per_stage,
        }


class SVRMetric:
    """Self-Verification Rate — measures Functional Competence.
    SVR = fraction of outputs where VERIFY catches error AND reverses answer.
    
    Detection logic:
    - Extract intermediate answer from EXECUTE block (last number)
    - Extract final answer after VERIFY (last number or \boxed{})
    - SVR=1 if: intermediate != ground_truth AND final == ground_truth
                AND intermediate != final (answer was actually reversed)
    """

    def compute(self, responses: list[str], ground_truths: list[str]) -> float:
        if not responses or len(responses) != len(ground_truths):
            return 0.0

        acc_metric = AccuracyMetric()
        reversals_count = 0

        for resp, gt in zip(responses, ground_truths):
            steps = _extract_cot_steps(resp)
            execute_block = steps.get("execute", "")
            verify_block = steps.get("verify", "")

            # Intermediate answer (last number in execute)
            nums_exec = re.findall(r"[-+]?\d*\.?\d+", execute_block)
            intermediate = nums_exec[-1] if nums_exec else ""

            # Final answer (from verify block or the whole end)
            final = _extract_answer(resp)
            if not final:
                nums_verify = re.findall(r"[-+]?\d*\.?\d+", verify_block)
                final = nums_verify[-1] if nums_verify else ""

            # Normalization comparisons
            match_inter_gt = acc_metric._is_match(intermediate, gt)
            match_final_gt = acc_metric._is_match(final, gt)
            match_inter_final = acc_metric._is_match(intermediate, final)

            if not match_inter_gt and match_final_gt and not match_inter_final:
                reversals_count += 1

        return reversals_count / len(responses)


@dataclass
class EvalResults:
    model_path: str
    benchmark: str
    accuracy: float
    rfs_full: float
    rfs_mean: float
    svr: float
    n_samples: int
    
    def summary(self) -> str:
        """Rich-formatted table"""
        lines = [
            f"=== Evaluation: {self.model_path} on {self.benchmark} ===",
            f"Samples  : {self.n_samples}",
            f"Accuracy : {self.accuracy * 100:.1f}%",
            f"RFS Full : {self.rfs_full * 100:.1f}%",
            f"RFS Mean : {self.rfs_mean * 100:.1f}%",
            f"SVR      : {self.svr * 100:.1f}%",
            "===========================================================",
        ]
        return "\n".join(lines)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "model_path": self.model_path,
            "benchmark": self.benchmark,
            "accuracy": self.accuracy,
            "rfs_full": self.rfs_full,
            "rfs_mean": self.rfs_mean,
            "svr": self.svr,
            "n_samples": self.n_samples,
        }


class Evaluator:
    def __init__(self, model_path: str):
        self.model_path = model_path
    
    def evaluate(
        self,
        benchmarks: list[str] = ["gsm8k"],
        metrics: list[str] = ["accuracy", "rfs", "svr"],
        n_samples: int | None = None,
    ) -> list[EvalResults]:
        # This is a stub that would actually load models and run inference.
        # Evaluation data fetch logic would be connected here in a true runner.
        return []
