"""
LabelMatrixParser — Two-tier parser for extracting step labels from structured reasoning traces.

Architecture:
    Raw text with #### TAGS ####
        → Tier 1 (Regex): locate tag boundaries
        → Tier 2 (Rules): classify each token → {U, P, E, V, IGNORE}
        → Output: M_U, M_P, M_E, M_V ∈ {0,1}^L (binary mask matrices)

Tag format (case-sensitive, exact spacing):
    #### UNDERSTAND ####
    #### PLAN ####
    #### EXECUTE ####
    #### VERIFY ####
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Any

import numpy as np


class StepType(Enum):
    """Cognitive reasoning stages from Pólya's framework."""

    UNDERSTAND = "understand"
    PLAN = "plan"
    EXECUTE = "execute"
    VERIFY = "verify"
    IGNORE = "ignore"

    @property
    def tag(self) -> str:
        """Return the exact tag string used in training data.

        Format: #### STAGE_NAME #### (4 hashtags, uppercase name, 4 hashtags)
        """
        if self == StepType.IGNORE:
            return ""
        return f"#### {self.name} ####"


# Canonical stage order for transition penalty computation
STAGE_ORDER: list[StepType] = [
    StepType.UNDERSTAND,
    StepType.PLAN,
    StepType.EXECUTE,
    StepType.VERIFY,
]

# Maps stage name (uppercase) → StepType for regex match groups
_NAME_TO_STAGE: dict[str, StepType] = {
    "UNDERSTAND": StepType.UNDERSTAND,
    "PLAN": StepType.PLAN,
    "EXECUTE": StepType.EXECUTE,
    "VERIFY": StepType.VERIFY,
}


class LabelMatrixParser:
    """Two-tier parser for extracting per-token step labels from reasoning traces.

    Tier 1 (Regex): Locate ``#### STAGE ####`` tag boundaries in raw text.
    Tier 2 (Rules): Classify each token into {understand, plan, execute, verify, ignore}.

    The parser produces binary mask matrices where each token belongs to exactly
    one stage. Tag tokens themselves are classified as ``ignore``.

    Example::

        parser = LabelMatrixParser()
        masks = parser.parse(text, tokenizer)
        # masks["plan"] → np.ndarray[bool] of shape (num_tokens,)

    Attributes:
        TAG_PATTERN: Compiled regex for matching ``#### STAGE ####`` tags.
            Matches exactly: 4 hashtags, 1+ spaces, stage name, 1+ spaces, 4 hashtags.
    """

    TAG_PATTERN: re.Pattern = re.compile(
        r"####\s+(UNDERSTAND|PLAN|EXECUTE|VERIFY)\s+####"
    )

    STAGE_KEYS: list[str] = ["understand", "plan", "execute", "verify", "ignore"]

    # ------------------------------------------------------------------
    # Tier 1 + Tier 2: Text-level stage classification
    # ------------------------------------------------------------------

    def parse_stages(self, text: str) -> list[tuple[StepType, int, int]]:
        """Parse text into stage segments with character-level spans.

        Tier 1: Regex locates all ``#### STAGE ####`` tag boundaries.
        Tier 2: Rules assign each character range to the appropriate stage.

        - Content before the first tag → IGNORE
        - Tag tokens themselves → IGNORE
        - Content between tags → stage of the preceding tag
        - Content after the last tag → stage of the last tag

        Args:
            text: Raw text potentially containing ``#### STAGE ####`` tags.

        Returns:
            List of ``(stage, start_char, end_char)`` tuples covering the
            entire text. Segments are non-overlapping and contiguous.

        Edge cases handled:
            - No tags at all → entire text is IGNORE
            - Missing stages → only present stages produce non-IGNORE segments
            - Wrong order → stages classified by actual tag position, not canonical order
            - Partial tags (e.g., ``#### UNDERSTAND`` without closing ``####``) → not matched
        """
        segments: list[tuple[StepType, int, int]] = []
        tags = list(self.TAG_PATTERN.finditer(text))

        if not tags:
            # No tags found — entire text is IGNORE
            if text:
                segments.append((StepType.IGNORE, 0, len(text)))
            return segments

        # Content before first tag → IGNORE
        if tags[0].start() > 0:
            segments.append((StepType.IGNORE, 0, tags[0].start()))

        for i, match in enumerate(tags):
            # The tag itself → IGNORE
            segments.append((StepType.IGNORE, match.start(), match.end()))

            # Content after this tag until next tag (or end of text)
            stage = _NAME_TO_STAGE[match.group(1)]
            content_start = match.end()
            content_end = tags[i + 1].start() if i + 1 < len(tags) else len(text)

            if content_start < content_end:
                segments.append((stage, content_start, content_end))

        return segments

    def get_stage_texts(self, text: str) -> dict[str, str]:
        """Extract the text content for each stage (excluding tags).

        Convenience method for inspection and debugging.

        Args:
            text: Raw text with ``#### STAGE ####`` tags.

        Returns:
            Dict mapping stage name → concatenated content for that stage.
            Only includes stages that are present in the text.
        """
        result: dict[str, str] = {}
        for stage, start, end in self.parse_stages(text):
            if stage != StepType.IGNORE:
                key = stage.value
                if key in result:
                    result[key] += text[start:end]
                else:
                    result[key] = text[start:end]
        return result

    def get_stage_order(self, text: str) -> list[StepType]:
        """Return the order of stages as they appear in the text.

        Useful for transition penalty computation — detects violations
        of the canonical UNDERSTAND → PLAN → EXECUTE → VERIFY order.

        Args:
            text: Raw text with ``#### STAGE ####`` tags.

        Returns:
            List of StepType values in order of appearance (no duplicates,
            no IGNORE).
        """
        seen: set[StepType] = set()
        order: list[StepType] = []
        for match in self.TAG_PATTERN.finditer(text):
            stage = _NAME_TO_STAGE[match.group(1)]
            if stage not in seen:
                seen.add(stage)
                order.append(stage)
        return order

    def has_valid_order(self, text: str) -> bool:
        """Check if stages appear in the canonical order.

        The canonical order is: UNDERSTAND → PLAN → EXECUTE → VERIFY.
        Missing stages are allowed (e.g., U → E → V is valid),
        but reversed order is not (e.g., P → U is invalid).

        Args:
            text: Raw text with ``#### STAGE ####`` tags.

        Returns:
            True if stages are in valid (possibly sparse) canonical order.
        """
        order = self.get_stage_order(text)
        if not order:
            return True

        indices = [STAGE_ORDER.index(s) for s in order]
        return all(indices[i] < indices[i + 1] for i in range(len(indices) - 1))

    # ------------------------------------------------------------------
    # Token-level parsing (requires tokenizer)
    # ------------------------------------------------------------------

    def parse(
        self, text: str, tokenizer: Any, add_special_tokens: bool = False
    ) -> dict[str, np.ndarray]:
        """Parse text and produce per-token binary masks for each stage.

        This is the primary interface used by the training pipeline to create
        label matrices for the Step-Aware Loss.

        Args:
            text: Raw text containing ``#### STAGE ####`` tags.
            tokenizer: HuggingFace tokenizer (must support ``return_offsets_mapping``).
            add_special_tokens: Whether to include special tokens (BOS/EOS).
                Defaults to False for training mask generation.

        Returns:
            Dict with keys ``"understand"``, ``"plan"``, ``"execute"``,
            ``"verify"``, ``"ignore"``. Each value is a boolean numpy array
            of shape ``(num_tokens,)`` where exactly one mask is True per token.

        Raises:
            ValueError: If tokenizer does not support offset mapping.
        """
        # Tokenize with offset mapping
        encoding = tokenizer(
            text,
            return_offsets_mapping=True,
            add_special_tokens=add_special_tokens,
        )

        offsets = encoding.get("offset_mapping")
        if offsets is None:
            raise ValueError(
                "Tokenizer must support return_offsets_mapping=True. "
                "Use a fast tokenizer (e.g., AutoTokenizer with use_fast=True)."
            )

        num_tokens = len(offsets)

        # Get character-level stage assignments
        segments = self.parse_stages(text)

        # Build character → stage lookup using segments
        # For efficiency, we don't build a full char array — instead we do
        # binary search on segment boundaries for each token
        seg_starts = [s for _, s, _ in segments]
        seg_ends = [e for _, _, e in segments]
        seg_stages = [stage for stage, _, _ in segments]

        # Initialize masks
        masks: dict[str, np.ndarray] = {
            key: np.zeros(num_tokens, dtype=bool) for key in self.STAGE_KEYS
        }

        for idx, (tok_start, tok_end) in enumerate(offsets):
            if tok_start == tok_end:
                # Special tokens or zero-width tokens → IGNORE
                masks["ignore"][idx] = True
                continue

            # Find which segment this token's start character falls in
            stage = self._lookup_stage(tok_start, seg_starts, seg_ends, seg_stages)
            masks[stage.value][idx] = True

        return masks

    @staticmethod
    def _lookup_stage(
        char_pos: int,
        seg_starts: list[int],
        seg_ends: list[int],
        seg_stages: list[StepType],
    ) -> StepType:
        """Find which stage a character position belongs to.

        Uses linear scan (segments are typically few: ~9 for a full 4-stage trace).
        """
        for i in range(len(seg_starts)):
            if seg_starts[i] <= char_pos < seg_ends[i]:
                return seg_stages[i]
        return StepType.IGNORE

    # ------------------------------------------------------------------
    # Convenience: build from structured data
    # ------------------------------------------------------------------

    @staticmethod
    def build_tagged_text(cot_4steps: dict[str, str]) -> str:
        """Build tagged text from a structured cot_4steps dict.

        This reconstructs the raw text format used in training from the
        parsed JSON format used in data files.

        Args:
            cot_4steps: Dict with keys "understand", "plan", "execute", "verify"
                mapping to the content of each stage.

        Returns:
            Tagged text with ``#### STAGE ####`` markers.

        Example::

            text = LabelMatrixParser.build_tagged_text({
                "understand": "Given: 16 eggs...",
                "plan": "Step 1: ...",
                "execute": "16 - 3 = 13...",
                "verify": "Back-check: ...",
            })
        """
        parts: list[str] = []
        for stage in STAGE_ORDER:
            key = stage.value
            if key in cot_4steps and cot_4steps[key].strip():
                parts.append(stage.tag)
                content = cot_4steps[key].strip()
                parts.append(content)
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return "LabelMatrixParser(tags=[UNDERSTAND, PLAN, EXECUTE, VERIFY])"
