from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class StepAwareLoss(nn.Module):
    """
    Asymmetric weighted cross-entropy over 4 cognitive stages.

    L_step = α·L_U + β·L_P + γ·L_E + δ·L_V + ε·L_tr

    Key properties:
    - Each L_s normalized by |M_s| (tokens in that stage), NOT total length
    - Causal shift: logits[:-1] vs labels[1:] applied BEFORE masking
    - Transition penalty: penalize stage-order violations
    - Weights sum to 1.10 — importance multipliers, not probability simplex
    """

    def __init__(
        self,
        alpha: float = 0.15,   # UNDERSTAND
        beta: float = 0.35,    # PLAN
        gamma: float = 0.35,   # EXECUTE
        delta: float = 0.15,   # VERIFY
        epsilon: float = 0.10, # Transition penalty
        label_smoothing: float = 0.0,
    ):
        super().__init__()
        self.weights = {
            "understand": alpha,
            "plan": beta,
            "execute": gamma,
            "verify": delta,
        }
        self.epsilon = epsilon
        self.label_smoothing = label_smoothing

    def forward(
        self,
        logits: torch.Tensor,               # (batch, seq_len, vocab_size)
        labels: torch.Tensor,               # (batch, seq_len)
        mask_dict: dict[str, torch.Tensor], # from LabelMatrixParser
        attention_mask: torch.Tensor,       # (batch, seq_len)
    ) -> dict[str, torch.Tensor]:
        """
        Returns dict with keys:
          total_loss, understand_loss, plan_loss, execute_loss,
          verify_loss, transition_loss
        All are scalar tensors. total_loss has grad_fn.
        """
        # Apply causal shift BEFORE masking
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        shift_attention_mask = attention_mask[..., 1:].contiguous()
        
        batch_size, seq_len = shift_labels.shape
        step_losses = {}
        total_loss = torch.tensor(0.0, device=logits.device)
        
        # Flatten for CE computation
        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        
        # Compute raw unreduced Cross Entropy loss
        ce_loss = F.cross_entropy(
            logits_flat, 
            labels_flat, 
            reduction="none", 
            label_smoothing=self.label_smoothing
        )
        ce_loss = ce_loss.view(batch_size, seq_len)

        # To compute transition penalty, we need step_labels representing stage order.
        # Since we use mask_dict, we can build a numerical tensor:
        # Default to -1 (ignore)
        step_labels = torch.full((batch_size, seq_len + 1), -1, dtype=torch.long, device=logits.device)
        stage_mapping = {"understand": 0, "plan": 1, "execute": 2, "verify": 3}
        for stage, mask in mask_dict.items():
            if stage in stage_mapping:
                step_labels[mask] = stage_mapping[stage]
                
        # Fill in ignoring tags with the previous valid stage if needed or just skip transition on them.
        # Simplest way matching Kaggle test: just use their raw valid stage values.
        # But from test requirements: "No transition violations → transition_loss == 0.0"
        shift_step_labels = step_labels[..., 1:].contiguous()

        # Compute step losses
        for stage, w in self.weights.items():
            if stage in mask_dict:
                stage_mask = mask_dict[stage][..., 1:].contiguous().float()
                # Ensure we only consider valid attention_mask tokens
                valid_mask = stage_mask * shift_attention_mask.float()
                mask_sum = valid_mask.sum()
                
                if mask_sum > 0:
                    l_s = (ce_loss * valid_mask).sum() / mask_sum
                else:
                    l_s = torch.tensor(0.0, device=logits.device)
            else:
                l_s = torch.tensor(0.0, device=logits.device)
                
            step_losses[f"{stage}_loss"] = l_s
            total_loss = total_loss + w * l_s

        # Transition penalty computation
        # For consecutive tokens t and t+1, penalize if stage[t+1] < stage[t]
        s_t = shift_step_labels[..., :-1]
        s_next = shift_step_labels[..., 1:]
        m_t = shift_attention_mask[..., :-1]
        m_next = shift_attention_mask[..., 1:]
        
        # Both tokens must be valid stages and not padding
        valid_transitions = (s_t != -1) & (s_next != -1) & (m_t == 1) & (m_next == 1)
        backward_jump = (s_next < s_t)
        
        penalty_mask = (backward_jump & valid_transitions).float()
        
        if penalty_mask.sum() > 0:
            transition_loss = penalty_mask.sum() / valid_transitions.float().sum()
        else:
            transition_loss = torch.tensor(0.0, device=logits.device)
            
        step_losses["transition_loss"] = transition_loss
        total_loss = total_loss + self.epsilon * transition_loss

        step_losses["total_loss"] = total_loss
        
        return step_losses
