#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Created on Tue May 12 23:47:52 2020
# @author: Ajit Johnson Nirmal
"""
!!! abstract "Short Description"
    `sm.pl.napariGater()`: This function leverages Napari to display OME-TIFF images, 
    overlaying points that assist in manually determining gating thresholds for specific markers. 
    By visualizing marker expression spatially, users can more accurately define gates. 
    Subsequently, the identified gating parameters can be applied to the dataset using `sm.pp.rescale`, 
    enabling precise control over data segmentation and analysis based on marker expression levels.

    Replacement for `sm.pl.gate_finder()`
"""

import warnings
import json

try:
    import napari
    from magicgui import magicgui
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from qtpy.QtWidgets import QWidget, QVBoxLayout, QLabel
    from qtpy.QtCore import Qt
except ImportError:
    pass

import pandas as pd
import tifffile as tiff
import numpy as np

import dask.array as da
from dask import delayed
#from dask.cache import Cache
import zarr
import os
from tqdm.auto import tqdm

from matplotlib.figure import Figure

import time

try:
    from spatialdata import SpatialData as _SpatialData
except Exception:
    _SpatialData = None


try:
    import anndata as _ad
except Exception:
    _ad = None


def _pick_table_key(keys, table_key=None):
    if table_key is not None:
        k = str(table_key)
        if k in keys:
            return k
    pref = [k for k in keys if "mIF_cells" in str(k)]
    if len(pref) > 0:
        return str(pref[0])
    return str(keys[0]) if len(keys) > 0 else None


def _load_anndata_from_sdata_path(sdata_path: str, table_key: str):
    if _ad is None:
        raise RuntimeError("anndata is required to read SpatialData tables.")
    table_path = os.path.join(str(sdata_path), "tables", str(table_key))
    if hasattr(_ad, "read_zarr"):
        adata = _ad.read_zarr(table_path)
        try:
            # Detach from the on-disk Zarr store immediately so long-lived UI sessions
            # do not keep Windows file handles on the table directory we later replace.
            return adata.copy()
        except Exception:
            return adata
    raise RuntimeError("anndata.read_zarr not available.")


def _resolve_adata_from_input(obj, sdata_path=None, table_key=None):
    resolved_path = sdata_path
    resolved_key = table_key
    if isinstance(obj, str):
        resolved_path = obj
        store = zarr.open_group(resolved_path, mode="r")
        if "tables" not in store:
            raise ValueError("Provided SpatialData path has no 'tables' group.")
        tables_grp = store["tables"]
        try:
            keys = list(tables_grp.group_keys())
        except Exception:
            keys = list(tables_grp.keys())
        resolved_key = _pick_table_key(keys, resolved_key)
        if resolved_key is None:
            raise ValueError("No tables available in the provided SpatialData.")
        adata = _load_anndata_from_sdata_path(resolved_path, resolved_key)
        return adata, resolved_path, resolved_key
    if _SpatialData is not None and isinstance(obj, _SpatialData):
        tables = getattr(obj, "tables", {}) or {}
        keys = list(tables.keys())
        resolved_key = _pick_table_key(keys, resolved_key)
        if resolved_key is None:
            raise ValueError("No tables available in the provided SpatialData.")
        if resolved_path is None:
            resolved_path = getattr(obj, "path", None)
        try:
            return tables[resolved_key].copy(), resolved_path, resolved_key
        except Exception:
            return tables[resolved_key], resolved_path, resolved_key
    return obj, resolved_path, resolved_key


def _persist_table_to_sdata_zarr(adata, sdata_path: str, table_key: str) -> None:
    try:
        from histotuner.spatial_writer import append_table_group, update_table_uns_in_place
    except Exception as e:
        raise RuntimeError(
            "histotuner.spatial_writer persistence helpers are required to persist gates."
        ) from e
    uns_updates = _build_napari_uns_updates_for_persistence(adata)
    if uns_updates:
        if update_table_uns_in_place(str(sdata_path), str(table_key), uns_updates, raise_on_error=False):
            return
    try:
        # Detach from any live Zarr-backed state before writing back to the same table.
        # This is especially important for Napari close events on Windows, where open
        # handles during Qt teardown can interfere with staged table replacement.
        adata_to_save = adata.copy()
    except Exception:
        adata_to_save = adata
    if not append_table_group(adata_to_save, str(sdata_path), str(table_key), raise_on_error=True):
        raise RuntimeError("Failed to write updated table back to the SpatialData store.")


def _json_default(obj):
    try:
        import numpy as _np
        import pandas as _pd
        if isinstance(obj, (_np.generic,)):
            return obj.item()
        if isinstance(obj, (_np.ndarray,)):
            return obj.tolist()
        if isinstance(obj, (_pd.Timestamp,)):
            return obj.isoformat()
    except Exception:
        pass
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _restore_napari_uns_from_persistence(adata) -> None:
    uns = getattr(adata, "uns", None)
    if uns is None:
        return

    if "napariGaterProvenance_json" in uns:
        try:
            val = uns["napariGaterProvenance_json"]
            if isinstance(val, bytes):
                val = val.decode("utf-8")
            if isinstance(val, str):
                uns["napariGaterProvenance"] = json.loads(val)
        except Exception:
            pass

    if "image_contrast_settings_json" in uns:
        try:
            val = uns["image_contrast_settings_json"]
            if isinstance(val, bytes):
                val = val.decode("utf-8")
            if isinstance(val, str):
                uns["image_contrast_settings"] = json.loads(val)
        except Exception:
            pass


def _build_napari_uns_updates_for_persistence(adata):
    uns = getattr(adata, "uns", None)
    if uns is None:
        return {}

    updates = {}
    if "gates" in uns:
        updates["gates"] = uns["gates"]
    if "napariGaterProvenance" in uns:
        updates["napariGaterProvenance_json"] = json.dumps(
            uns["napariGaterProvenance"], default=_json_default
        )
    if "image_contrast_settings" in uns:
        updates["image_contrast_settings_json"] = json.dumps(
            uns["image_contrast_settings"], default=_json_default
        )
    return updates

# cache = Cache(2e9)  # Leverage two gigabytes of memory
# cache.register()


def _ensure_log_layer(adata) -> None:
    try:
        layers = getattr(adata, "layers", None)
        if layers is None:
            return
        if "log" in layers:
            return
        X = adata.X
        try:
            import scipy.sparse as sp  # type: ignore
            if sp.issparse(X):
                X_log = X.copy()
                X_log.data = np.log1p(X_log.data)
                adata.layers["log"] = X_log
                return
        except Exception:
            pass
        adata.layers["log"] = np.log1p(X)
    except Exception:
        return


def get_marker_data(marker, adata, layer, log, verbose):
    layer_key = None if layer is None else str(layer)
    layer_key_norm = None if layer_key is None else layer_key.strip().lower()

    apply_log = bool(log)
    source = None
    source_label = ""

    if layer_key_norm in (None, "x", "adata.x"):
        if apply_log and hasattr(adata, "layers") and "log" in adata.layers:
            source = adata.layers["log"]
            source_label = "layer 'log'"
            apply_log = False
        else:
            source = adata.X
            source_label = "adata.X"
    elif layer_key_norm == "log":
        source = adata.layers["log"]
        source_label = "layer 'log'"
        apply_log = False
    elif layer_key_norm == "raw":
        source = adata.raw.X
        source_label = "raw"
    else:
        source = adata.layers[layer_key]
        source_label = f"layer '{layer_key}'"

    data = pd.DataFrame(source, index=adata.obs.index, columns=adata.var.index)[[marker]]
    if verbose:
        print(
            f"{source_label} data range - min: {float(data.min().iloc[0])}, max: {float(data.max().iloc[0])}"
        )

    if apply_log:
        data = np.log1p(data)
        if verbose:
            print(
                f"After log transform - min: {float(data.min().iloc[0])}, max: {float(data.max().iloc[0])}"
            )

    return data


def initialize_gates(adata, imageid, layer, log, verbose):
    from sklearn.mixture import GaussianMixture
    from sklearn.preprocessing import StandardScaler

    if 'gates' not in adata.uns:
        print("Initializing gates with GMM (per image)...")
        image_ids = adata.obs[imageid].unique()
        markers = list(adata.var.index)

        # Create gates matrix
        adata.uns['gates'] = pd.DataFrame(index=markers, columns=image_ids, dtype=float)

        with tqdm(total=len(markers) * len(image_ids), desc="Computing gates", leave=False) as pbar:
            for img_id in image_ids:
                mask = adata.obs[imageid] == img_id
                for marker in markers:
                    try:
                        data = get_marker_data(marker, adata[mask], layer, log, verbose)
                        values = data.values.flatten()
                        values = values[~np.isnan(values)]

                        # Robust percentile clipping
                        p01, p99 = np.percentile(values, [0.1, 99.9])
                        values = values[(values >= p01) & (values <= p99)]

                        # Scale and fit GMM
                        scaler = StandardScaler()
                        values_scaled = scaler.fit_transform(values.reshape(-1, 1))
                        gmm = GaussianMixture(n_components=3, random_state=42)
                        gmm.fit(values_scaled)
                        means = scaler.inverse_transform(gmm.means_)
                        sorted_means = np.sort(means.flatten())

                        # Use average of top 2 components for gate
                        gate_value = np.mean([sorted_means[1], sorted_means[2]])

                        # Clip to valid range
                        min_val = float(data.min().iloc[0])
                        max_val = float(data.max().iloc[0])
                        gate_value = np.clip(gate_value, min_val, max_val)

                        adata.uns['gates'].loc[marker, img_id] = gate_value
                    except Exception as e:
                        if verbose:
                            print(f"GMM failed for marker {marker} in {img_id}: {str(e)}")
                        adata.uns['gates'].loc[marker, img_id] = np.nan
                    pbar.update(1)

    # Track provenance
    if 'napariGaterProvenance' not in adata.uns:
        adata.uns['napariGaterProvenance'] = {
            'manually_adjusted': {},
            'timestamp': {},
            'original_values': {},
        }

    # Initialize tracking for each image/marker pair
    for img_id in adata.obs[imageid].unique():
        if img_id not in adata.uns['napariGaterProvenance']['manually_adjusted']:
            adata.uns['napariGaterProvenance']['manually_adjusted'][img_id] = {}
            adata.uns['napariGaterProvenance']['timestamp'][img_id] = {}
            adata.uns['napariGaterProvenance']['original_values'][img_id] = {}
        for marker in adata.var.index:
            adata.uns['napariGaterProvenance']['original_values'][img_id][marker] = \
                float(adata.uns['gates'].loc[marker, img_id])

    return adata



def calculate_auto_contrast(img, percentile_low=1, percentile_high=99, padding=0.4, sample_size=100000):
    if isinstance(img, (da.Array, zarr.Array)):
        if hasattr(img, 'shape') and len(img.shape) > 2:
            img = img[-1]
        total_pixels = np.prod(img.shape[-2:])
        stride = max(1, int(np.sqrt(total_pixels / sample_size)))
        sample = img[..., ::stride, ::stride]
        if hasattr(sample, 'compute'):
            sample = sample.compute()
    else:
        total_pixels = np.prod(img.shape[-2:])
        stride = max(1, int(np.sqrt(total_pixels / sample_size)))
        sample = img[..., ::stride, ::stride]

    sample_flat = sample[np.isfinite(sample)].ravel()
    low = np.percentile(sample_flat, percentile_low)
    high = np.percentile(sample_flat, percentile_high)
    range_val = high - low
    low = max(0, low - (range_val * padding))
    high = high + (range_val * padding)
    if high == low:
        high = low + 1

    return float(low), float(high)


def initialize_contrast_settings(adata, img_data, channel_names, imageid='imageid', subset=None):
    if 'image_contrast_settings' not in adata.uns:
        adata.uns['image_contrast_settings'] = {}

    current_image = adata.obs[imageid].iloc[0] if subset is None else subset

    should_initialize = False
    if current_image not in adata.uns['image_contrast_settings']:
        should_initialize = True
    else:
        existing_channels = set(adata.uns['image_contrast_settings'][current_image].keys())
        new_channels = set(channel_names)
        if existing_channels != new_channels:
            print(f"New channel configuration detected for {current_image}. Updating contrast settings.")
            should_initialize = True

    if should_initialize:
        contrast_settings = {}
        with tqdm(total=len(channel_names), desc=f"Calculating contrast for {current_image}", leave=False) as pbar:
            for i, channel in enumerate(channel_names):
                try:
                    if isinstance(img_data, list):
                        channel_data = img_data[-1][i]
                    else:
                        channel_data = img_data[i]
                    low, high = calculate_auto_contrast(
                        channel_data,
                        percentile_low=1,
                        percentile_high=99,
                        sample_size=100000
                    )
                    contrast_settings[channel] = {
                        'low': low,
                        'high': high,
                    }
                except Exception as e:
                    print(f"Warning: Failed to calculate contrast for {channel} in {current_image}: {str(e)}")
                    contrast_settings[channel] = {'low': 0.0, 'high': 100}
                finally:
                    pbar.update(1)

        adata.uns['image_contrast_settings'][current_image] = contrast_settings
        print(f"Saved contrast settings for {current_image} with {len(channel_names)} channels")

    return adata


def load_image_efficiently(image_path):
    if isinstance(image_path, str):
        if image_path.endswith(('.tiff', '.tif')):
            image = tiff.TiffFile(image_path, is_ome=False)
            try:
                z = zarr.open(image.aszarr(), mode='r')
                n_levels = len(image.series[0].levels)
                if n_levels > 1:
                    data = [da.from_zarr(z[i]) for i in range(n_levels)]
                    multiscale = True
                else:
                    data = da.from_zarr(z)
                    multiscale = False
                return data, image, multiscale
            except Exception:
                try:
                    series0 = image.series[0]
                    level0 = series0.levels[0] if hasattr(series0, "levels") and len(series0.levels) > 0 else series0
                    try:
                        arr = level0.asarray(out="memmap")
                    except Exception:
                        arr = level0.asarray()
                    data = da.from_array(arr, chunks="auto")
                    return data, image, False
                except Exception:
                    return None, None, False
    return None, None, False


def add_channels_to_viewer(viewer, img_data, channel_names, contrast_settings, colormaps):
    n_channels = len(channel_names)
    extended_colormaps = [colormaps[i % len(colormaps)] for i in range(n_channels)]
    contrast_limits = []
    for channel in channel_names:
        if channel in contrast_settings:
            contrast_limits.append(
                (contrast_settings[channel]['low'], contrast_settings[channel]['high'])
            )
        else:
            print(f"Warning: Missing contrast settings for channel {channel}. Using defaults.")
            contrast_limits.append((0.0, 100))
    viewer.add_image(
        img_data,
        channel_axis=0,
        name=channel_names,
        visible=False,
        colormap=extended_colormaps,
        blending='additive',
        contrast_limits=contrast_limits,
        multiscale=isinstance(img_data, list),
        rendering='mip',
        interpolation2d='nearest'
    )


def _default_contrast_for_dtype(img_data):
    try:
        arr = img_data[-1] if isinstance(img_data, list) and len(img_data) > 0 else img_data
        dt = getattr(arr, "dtype", None)
        if dt is None:
            return 0.0, 1.0
        if np.issubdtype(dt, np.integer):
            return 0.0, float(np.iinfo(dt).max)
        if np.issubdtype(dt, np.floating):
            return 0.0, 1.0
    except Exception:
        pass
    return 0.0, 1.0


def napariGater(
    image_path,
    sdata,
    layer='X',
    log=True,
    x_coordinate='X_centroid',
    y_coordinate='Y_centroid',
    imageid='imageid',
    subset=None,
    flip_y=True,
    channel_names='default',
    point_size=10,
    calculate_contrast=True,
    verbose=False,
    sdata_path=None,
    table_key=None,
    write_to_disk=True,
    autosave_on_confirm=False,
    autosave_on_close=True,
    **kwargs
):
    
    """    
    Parameters:
        image_path (str):
            Path to the high-resolution multi-channel image (TIFF or OME-TIFF supported).
    
        sdata:
            Either an `anndata.AnnData`, a `spatialdata.SpatialData`, or a string path to a SpatialData Zarr store.
    
        layer (str, optional):
            Specifies which layer in `adata` to use for expression data (e.g., 'X', 'raw' or a named layer). Defaults to 'X'.
    
        log (bool, optional):
            If True, applies a log1p transformation to expression values before visualization. Defaults to True.
    
        x_coordinate, y_coordinate (str, optional):
            Keys in `adata.obs` specifying X and Y spatial coordinates of cells. Defaults are 'X_centroid' and 'Y_centroid'.
    
        imageid (str, optional):
            Column name in `adata.obs` indicating the image source (used for filtering and metadata grouping). Defaults to 'imageid'.
    
        subset (str, optional):
            Specific image ID or sample name to filter and visualize. If None, uses the first available entry in `adata.obs[imageid]`.
    
        flip_y (bool, optional):
            If True, inverts the Y-axis to match image coordinate system. Defaults to True.
    
        channel_names (list or str, optional):
            List of marker/channel names corresponding to the order in the image. 
            Defaults to 'default', which uses `adata.uns['all_markers']`.
    
        point_size (int, optional):
            Size of the points representing gated cells. Defaults to 10.
    
        calculate_contrast (bool, optional):
            If True, contrast settings are estimated automatically for each channel. If False, existing settings in `adata.uns` are reused or defaulted. Defaults to False.
    
        verbose (bool, optional):
            If True, prints detailed information about data ranges and transformations.
    
    Returns:
        None:
            Launches an interactive napari viewer for manual gate threshold adjustment.
            The gating values are stored in `adata.uns['gates']`, and user edits are tracked under `adata.uns['napariGaterProvenance']`.
    
    Example:
        ```python
        # Launch napariGater with default settings
        sm.pl.napariGater('/path/to/image.ome.tif', sdata=adata)
    
        # Use expression layer, flip Y-axis off, and focus on a specific sample
        sm.pl.napariGater('/path/to/image.tif', sdata=adata, layer='expression',
                          flip_y=False, subset='Sample_A')
    
        # Specify custom channels and disable contrast calculation
        sm.pl.napariGater('/path/to/image.tif', sdata=adata,
                          channel_names=['DAPI', 'CD45', 'CD3'], calculate_contrast=False)
        ```
"""

    os.environ['QT_MAC_WANTS_LAYER'] = '1'

    warnings.warn(
        "NOTE: napariGater() is currently in beta testing. "
        "If you encounter any issues, please report them at: "
        "https://github.com/labsyspharm/scimap/issues",
        UserWarning,
        stacklevel=2,
    )

    print("Initializing...")
    start_time = time.time()

    if sdata is None and "adata" in kwargs:
        sdata = kwargs["adata"]
    adata, sdata_path, table_key = _resolve_adata_from_input(sdata, sdata_path=sdata_path, table_key=table_key)
    _restore_napari_uns_from_persistence(adata)
    if log and (layer is None or str(layer).strip().lower() in ("x", "adata.x")):
        _ensure_log_layer(adata)
    # Initialize gates with the chosen layer and log settings.
    adata = initialize_gates(adata, imageid, layer, log, verbose)

    if channel_names == 'default':
        channel_names = adata.uns['all_markers']
    else:
        channel_names = channel_names 

    print("Loading image data...")
    img_data, tiff_file, multiscale = load_image_efficiently(image_path)
    if img_data is None:
        raise ValueError("Failed to load image data")
    
    current_image = adata.obs[imageid].iloc[0] if subset is None else subset
    
    if calculate_contrast:
        print("Calculating contrast settings...")
        adata = initialize_contrast_settings(
            adata,
            img_data,
            channel_names,
            imageid=imageid,
            subset=subset,
        )
    else:
        if 'image_contrast_settings' not in adata.uns:
            adata.uns['image_contrast_settings'] = {}
        current_image = adata.obs[imageid].iloc[0] if subset is None else subset
        should_initialize = False
        if current_image not in adata.uns['image_contrast_settings']:
            should_initialize = True
        else:
            existing_channels = set(adata.uns['image_contrast_settings'][current_image].keys())
            new_channels = set(channel_names)
            missing_channels = new_channels - existing_channels
            if missing_channels:
                print(f"Adding default contrast settings for new channels: {missing_channels}")
                should_initialize = True
        if should_initialize:
            contrast_settings = adata.uns['image_contrast_settings'].get(current_image, {})
            low_default, high_default = _default_contrast_for_dtype(img_data)
            for channel in channel_names:
                if channel not in contrast_settings:
                    contrast_settings[channel] = {'low': low_default, 'high': high_default}
            adata.uns['image_contrast_settings'][current_image] = contrast_settings
            print(f"Initialized contrast settings for {current_image} with {len(channel_names)} channels")

    print(f"Initialization completed in {time.time() - start_time:.2f} seconds")
    print("Opening napari viewer...")
    
    viewer = napari.Viewer()
    has_unsaved_gate_changes = False
    if write_to_disk and autosave_on_close and sdata_path is not None and table_key is not None:
        try:
            qt_win = viewer.window._qt_window
            _orig_close_event = qt_win.closeEvent

            def _close_event_with_save(event):
                nonlocal has_unsaved_gate_changes
                if has_unsaved_gate_changes:
                    try:
                        _persist_table_to_sdata_zarr(adata, str(sdata_path), str(table_key))
                        print(f"Saved gates to: {sdata_path} (table={table_key})")
                        has_unsaved_gate_changes = False
                    except Exception as e:
                        print(f"Warning: failed to save gates to disk on close: {e}")
                return _orig_close_event(event)

            qt_win.closeEvent = _close_event_with_save
        except Exception:
            pass
    
    default_colormaps = [
        'magenta', 'cyan', 'yellow', 'red', 'green', 'blue',
        'magenta', 'cyan', 'yellow', 'red', 'green', 'blue'
    ]

    add_channels_to_viewer(
        viewer,
        img_data,
        channel_names,
        adata.uns['image_contrast_settings'][current_image],
        colormaps=default_colormaps
    )
    
    loaded_channels = [lyr.name for lyr in viewer.layers if isinstance(lyr, napari.layers.Image)]
    if len(loaded_channels) != len(channel_names):
        print(f"\nWarning: Only loaded {len(loaded_channels)}/{len(channel_names)} channels")
        missing = set(channel_names) - set(loaded_channels)
        if missing:
            print(f"Missing channels: {', '.join(missing)}")

    points_layer = viewer.add_points(
        np.zeros((0, 2)),
        size=point_size,
        face_color='white',
        name='gated_points',
        visible=True,
    )

    # Use the chosen layer when creating the initial marker data.
    initial_marker = list(adata.var.index)[0]
    initial_data = get_marker_data(initial_marker, adata, layer, log, verbose)

    # Calculate initial min/max from the specified layer using .iloc[0] for explicit float conversion
    marker_data = get_marker_data(initial_marker, adata, layer, log, verbose=False)
    min_val = round(float(marker_data.min().iloc[0]), 2)
    max_val = round(float(marker_data.max().iloc[0]), 2)
    
    current_image = adata.obs[imageid].iloc[0] if subset is None else subset
    initial_gate = adata.uns['gates'].loc[initial_marker, current_image]
    if pd.isna(initial_gate) or initial_gate < min_val or initial_gate > max_val:
        initial_gate = min_val
    else:
        initial_gate = round(float(initial_gate), 2)

    @magicgui(
        auto_call=True,
        layout='vertical',
        marker={
            'choices': list(adata.var.index), 
            'value': initial_marker,
            'label': 'Select Marker:'
        },
        gate={
            'widget_type': 'FloatSpinBox',
            'min': min_val,
            'max': max_val,
            'value': initial_gate,
            'step': 0.01,
            'label': 'Gate Threshold:'
        },
        marker_status={
            'widget_type': 'Label',
            'value': '⚪ Not adjusted'
        },
        confirm_gate={
            'widget_type': 'PushButton', 
            'text': 'Confirm Gate'
        },
        finish={
            'widget_type': 'PushButton', 
            'text': 'Finish Gating'
        },
    )
    def gate_controls(
        marker: str,
        gate: float = initial_gate,
        marker_status: str = '⚪ Not adjusted',
        confirm_gate=False,
        finish=False,
    ):
        data = get_marker_data(marker, adata, layer, log, verbose)
        if subset is not None:
            mask = adata.obs[imageid] == subset
            data = data[mask]
        mask = data.values >= gate
        cells = data.index[mask.flatten()]
        coordinates = adata[cells]
        if flip_y:
            coordinates = pd.DataFrame(
                {'y': coordinates.obs[y_coordinate], 'x': coordinates.obs[x_coordinate]}
            )
        else:
            coordinates = pd.DataFrame(
                {'x': coordinates.obs[x_coordinate], 'y': coordinates.obs[y_coordinate]}
            )
        points_layer.data = coordinates.values
        
        

    
    # Create the histogram figure and canvas
    hist_fig = Figure()
    hist_canvas = FigureCanvas(hist_fig)
    hist_ax = hist_fig.add_subplot(111)
    
    # QLabel to show the gate threshold outside the plot
    gate_label = QLabel("Gate Threshold: N/A")
    gate_label.setAlignment(Qt.AlignCenter)
    gate_label.setStyleSheet("color: white; font-size: 15pt; padding-top: 1px;")
    
    # Create and configure the Qt layout
    hist_widget = QWidget()
    hist_layout = QVBoxLayout()
    hist_layout.addWidget(hist_canvas)
    hist_layout.addWidget(gate_label)
    hist_widget.setLayout(hist_layout)
    hist_widget.setMinimumHeight(350)
    hist_widget.setMinimumWidth(350)
    
    # Define the histogram update function
    def update_histogram(marker: str, gate_value: float = None):
        hist_ax.clear()
        data = get_marker_data(marker, adata, layer, log, verbose)
        if subset is not None:
            data = data[adata.obs[imageid] == subset]
        flat_data = data.values.flatten()
    
        # Exclude outliers using 0.1–99th percentile
        p_low, p_high = np.percentile(flat_data, [1, 99.99])
        flat_data = flat_data[(flat_data >= p_low) & (flat_data <= p_high)]
    
        # Plot histogram
        hist_ax.hist(flat_data, bins=100, color='#264653', edgecolor='#2a9d8f')
    
        # Gate line
        if gate_value is None:
            gate_value = adata.uns['gates'].loc[marker, current_image]
        if pd.notna(gate_value):
            hist_ax.axvline(gate_value, color='#582f0e', linewidth=0.75)
            gate_label.setText(f"Gate Threshold: {gate_value:.2f}")
        else:
            gate_label.setText("Gate Threshold: N/A")
    
        # Dynamic font scaling (clamped)
        canvas_width = hist_canvas.width() / hist_canvas.devicePixelRatioF()
        font_size = min(10, max(6, int(canvas_width / 45)))
    
        # Axis and title labels
        title = f'{marker} (log scale)' if log else marker
        hist_ax.set_title(title, fontsize=font_size)
        hist_ax.set_xlabel('Expression', fontsize=font_size)
        hist_ax.set_ylabel('Cell Count', fontsize=font_size)
        hist_ax.tick_params(axis='both', labelsize=font_size)
    
        hist_fig.tight_layout()
        hist_canvas.draw()
    
    # Redraw on resize
    def _resize_event(event):
        update_histogram(gate_controls.marker.value, gate_controls.gate.value)
        return super(FigureCanvas, hist_canvas).resizeEvent(event)
    
    hist_canvas.resizeEvent = _resize_event
    
    
    
    
    

    @gate_controls.marker.changed.connect
    def _on_marker_change(marker: str):
        current_state = {
            'zoom': viewer.camera.zoom,
            'center': viewer.camera.center
        }
        marker_data = get_marker_data(marker, adata, layer, log, verbose=False)
        min_val = round(float(marker_data.min().iloc[0]), 2)
        max_val = round(float(marker_data.max().iloc[0]), 2)
        current_image = adata.obs[imageid].iloc[0] if subset is None else subset
        existing_gate = adata.uns['gates'].loc[marker, current_image]
        value = existing_gate if (not pd.isna(existing_gate) and min_val <= existing_gate <= max_val) else min_val
        gate_controls.gate.min = min_val
        gate_controls.gate.max = max_val
        gate_controls.gate.value = round(float(value), 2)
        for lyr in viewer.layers:
            if isinstance(lyr, napari.layers.Image):
                if lyr.name == marker:
                    lyr.visible = True
                    viewer.layers.selection.active = lyr
                    viewer.layers.selection.clear()
                    viewer.layers.selection.add(lyr)
                else:
                    lyr.visible = False
        viewer.camera.zoom = current_state['zoom']
        viewer.camera.center = current_state['center']
        current_image = adata.obs[imageid].iloc[0] if subset is None else subset
        is_adjusted = marker in adata.uns['napariGaterProvenance']['manually_adjusted'].get(current_image, {})
        if is_adjusted:
            status_text = "✓ ADJUSTED"
            timestamp = adata.uns['napariGaterProvenance']['timestamp'][current_image][marker]
            from datetime import datetime
            try:
                dt = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                short_timestamp = dt.strftime("%y-%m-%d %H:%M")
                status_text += f" ({short_timestamp})"
            except:
                status_text += f" ({timestamp})"
        else:
            status_text = "⚪ NOT ADJUSTED"
        gate_controls.marker_status.value = status_text
        update_histogram(marker, gate_controls.gate.value)

    @gate_controls.gate.changed.connect
    def _on_gate_change(gate: float):
        marker = gate_controls.marker.value
        update_histogram(marker, gate)

    @gate_controls.confirm_gate.clicked.connect
    def _on_confirm():
        nonlocal has_unsaved_gate_changes
        marker = gate_controls.marker.value
        gate = gate_controls.gate.value
        current_image = adata.obs[imageid].iloc[0] if subset is None else subset
        adata.uns['gates'].loc[marker, current_image] = float(gate)
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if current_image not in adata.uns['napariGaterProvenance']['manually_adjusted']:
            adata.uns['napariGaterProvenance']['manually_adjusted'][current_image] = {}
        if current_image not in adata.uns['napariGaterProvenance']['timestamp']:
            adata.uns['napariGaterProvenance']['timestamp'][current_image] = {}
        if current_image not in adata.uns['napariGaterProvenance']['original_values']:
            adata.uns['napariGaterProvenance']['original_values'][current_image] = {}
        adata.uns['napariGaterProvenance']['manually_adjusted'][current_image][marker] = float(gate)
        adata.uns['napariGaterProvenance']['timestamp'][current_image][marker] = timestamp
        if marker not in adata.uns['napariGaterProvenance']['original_values'][current_image]:
            original_value = float(adata.uns['gates'].loc[marker, current_image])
            adata.uns['napariGaterProvenance']['original_values'][current_image][marker] = original_value
        short_timestamp = (datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                           .strftime("%y-%m-%d %H:%M"))
        gate_controls.marker_status.value = f"✓ ADJUSTED ({short_timestamp})"
        print(f"Gate confirmed for {marker} at {gate:.2f}")
        has_unsaved_gate_changes = True
        if write_to_disk and autosave_on_confirm and sdata_path is not None and table_key is not None:
            try:
                _persist_table_to_sdata_zarr(adata, str(sdata_path), str(table_key))
                print(f"Saved gates to: {sdata_path} (table={table_key})")
                has_unsaved_gate_changes = False
            except Exception as e:
                print(f"Warning: failed to save gates to disk: {e}")

    @gate_controls.finish.clicked.connect
    def _on_finish():
        nonlocal has_unsaved_gate_changes
        if has_unsaved_gate_changes and write_to_disk and sdata_path is not None and table_key is not None:
            try:
                _persist_table_to_sdata_zarr(adata, str(sdata_path), str(table_key))
                print(f"Saved gates to: {sdata_path} (table={table_key})")
                has_unsaved_gate_changes = False
            except Exception as e:
                print(f"Warning: failed to save gates to disk before close: {e}")
        viewer.close()

    points_layer.data = np.zeros((0, 2))
    viewer.window.add_dock_widget(gate_controls, name='Gate Controls')
    viewer.window.add_dock_widget(hist_widget, name='Marker Histogram')
    napari.run()

    print(f"Napari viewer initialized in {time.time() - start_time:.2f} seconds")
    # Optionally, you can return adata if desired.
