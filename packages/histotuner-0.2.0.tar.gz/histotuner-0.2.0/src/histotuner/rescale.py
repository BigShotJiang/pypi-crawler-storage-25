from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

try:
    import anndata as _ad
except Exception:
    _ad = None

try:
    import zarr as _zarr
except Exception:
    _zarr = None

try:
    import spatialdata as _sdata_mod
    from spatialdata import SpatialData as _SpatialData
except Exception:
    _sdata_mod = None
    _SpatialData = None


def _pick_table_key(keys, table_key: Optional[str] = None) -> Optional[str]:
    if table_key is not None:
        k = str(table_key)
        if k in keys:
            return k
    pref = [k for k in keys if "mif_cells" in str(k).lower()]
    if len(pref) > 0:
        return str(pref[0])
    pref = [k for k in keys if str(k).lower().endswith("_cells")]
    if len(pref) > 0:
        return str(pref[0])
    return str(keys[0]) if len(keys) > 0 else None


def _read_spatialdata(zarr_path: str):
    if _sdata_mod is None:
        raise RuntimeError("spatialdata is required to read SpatialData.")
    if hasattr(_sdata_mod, "read_zarr"):
        return _sdata_mod.read_zarr(zarr_path)  # type: ignore
    if hasattr(_sdata_mod, "io") and hasattr(_sdata_mod.io, "read_zarr"):
        return _sdata_mod.io.read_zarr(zarr_path)  # type: ignore
    raise RuntimeError("No SpatialData reader found in installed spatialdata.")


def _resolve_table_as_anndata(tbl):
    try:
        import anndata as ad  # type: ignore

        if isinstance(tbl, ad.AnnData):
            return tbl
    except Exception:
        pass
    for attr in ("table", "adata", "AnnData", "data"):
        try:
            inner = getattr(tbl, attr)
        except Exception:
            inner = None
        if inner is not None and hasattr(inner, "obs"):
            return inner
    if hasattr(tbl, "obs"):
        return tbl
    raise TypeError("Provided table is not AnnData-like and does not expose `.obs`.")


def _load_anndata_from_sdata_path(sdata_path: str, table_key: str):
    if _ad is None:
        raise RuntimeError("anndata is required to read SpatialData tables.")
    table_path = Path(str(sdata_path)) / "tables" / str(table_key)
    if not table_path.exists():
        raise KeyError(f"Table key '{table_key}' not found at: {table_path}")
    if hasattr(_ad, "read_zarr"):
        adata = _ad.read_zarr(str(table_path))
        try:
            return adata.copy()
        except Exception:
            return adata
    raise RuntimeError("anndata.read_zarr not available.")


def _list_table_keys_from_store(sdata_path: str) -> list[str]:
    if _zarr is None:
        raise RuntimeError("zarr is required to inspect SpatialData table keys from a path.")
    store = _zarr.open_group(str(sdata_path), mode="r")
    if "tables" not in store:
        return []
    tables_grp = store["tables"]
    try:
        return [str(k) for k in tables_grp.group_keys()]
    except Exception:
        try:
            return [str(k) for k in tables_grp.keys()]
        except Exception:
            return []


def _load_gates(gates) -> pd.DataFrame:
    if gates is None:
        raise ValueError("No gates provided.")
    if isinstance(gates, pd.DataFrame):
        df = gates.copy()
    elif isinstance(gates, str):
        df = pd.read_csv(gates, index_col=0)
    else:
        raise ValueError("`gates` must be a pandas DataFrame or a CSV path.")
    if df.index.name is None:
        df.index.name = "marker"
    return df


def _get_source_matrix(adata, layer: str = "log") -> pd.DataFrame:
    layer_key = str(layer).strip()
    layer_key_norm = layer_key.lower()
    if layer_key_norm in ("x", "adata.x"):
        source = adata.X
    else:
        layers = getattr(adata, "layers", None)
        if layers is None or layer_key not in layers:
            if layer_key_norm == "log":
                try:
                    import scipy.sparse as sp  # type: ignore

                    if sp.issparse(adata.X):
                        x = adata.X.copy()
                        x.data = np.log1p(x.data)
                        source = x
                    else:
                        source = np.log1p(np.asarray(adata.X))
                except Exception:
                    source = np.log1p(np.asarray(adata.X))
            else:
                raise KeyError(f"Layer '{layer_key}' not found in AnnData.")
        else:
            source = layers[layer_key]
    return pd.DataFrame(source, columns=adata.var.index, index=adata.obs.index)


def _normalize_gate_table(gates_df: pd.DataFrame, dataset_images: list[str]) -> pd.DataFrame:
    gate = gates_df.copy()
    if gate.index.name != "markers":
        gate.index.name = "markers"
    matching_images = set(map(str, gate.columns)) & set(map(str, dataset_images))
    if len(matching_images) == 0 and gate.shape[1] == 1:
        col = str(gate.columns[0])
        if col != "gates":
            gate = gate.rename(columns={gate.columns[0]: "gates"})
    return gate


def _build_gate_mapping(adata, gates_df: pd.DataFrame, imageid: str = "imageid") -> pd.DataFrame:
    dataset_markers = adata.var.index.tolist()
    dataset_images = adata.obs[imageid].astype(str).unique().tolist()
    gate_norm = _normalize_gate_table(gates_df, dataset_images)

    m = pd.DataFrame(index=dataset_markers, columns=dataset_images).reset_index()
    m = pd.melt(m, id_vars=[m.columns[0]])
    m.columns = ["markers", "imageid", "gate"]

    matching_images = set(map(str, gate_norm.columns)) & set(map(str, dataset_images))
    if len(matching_images) == 0:
        gate_reset = gate_norm.reset_index()
        if "gates" not in gate_reset.columns:
            if gate_reset.shape[1] != 2:
                raise ValueError(
                    "Gate table must either contain imageid-matched columns or a single 'gates' column."
                )
            gate_reset = gate_reset.rename(columns={gate_reset.columns[1]: "gates"})
        gate_mapping = m.copy()
        gate_mapping["gate"] = gate_mapping["markers"].map(
            dict(zip(gate_reset["markers"], gate_reset["gates"]))
        )
    else:
        gate_reset = gate_norm.reset_index()
        manual_m = pd.melt(gate_reset, id_vars=gate_reset[["markers"]])
        manual_m.columns = ["markers", "imageid", "m_gate"]
        gate_mapping = pd.merge(
            m,
            manual_m,
            how="left",
            left_on=["markers", "imageid"],
            right_on=["markers", "imageid"],
        )
        gate_mapping["gate"] = gate_mapping["gate"].where(
            gate_mapping["gate"].notna(), gate_mapping["m_gate"]
        )
        gate_mapping = gate_mapping.drop(columns="m_gate")

    missing = gate_mapping[gate_mapping["gate"].isna()]
    if not missing.empty:
        missing_markers = sorted(set(missing["markers"].astype(str)))
        raise ValueError(
            "Missing gate values for some markers/images. "
            f"First missing markers: {missing_markers[:10]}"
        )
    gate_mapping["imageid"] = gate_mapping["imageid"].astype(str)
    gate_mapping["markers"] = gate_mapping["markers"].astype(str)
    gate_mapping["gate"] = pd.to_numeric(gate_mapping["gate"], errors="coerce")
    if gate_mapping["gate"].isna().any():
        raise ValueError("Gate table contains non-numeric gate values.")
    return gate_mapping


def _ensure_raw_backup(adata) -> None:
    if getattr(adata, "raw", None) is not None:
        return
    try:
        adata.raw = adata.copy()
    except Exception:
        pass


def _rescale_with_gates(adata, gates_df: pd.DataFrame, layer: str = "log", imageid: str = "imageid"):
    if imageid not in adata.obs.columns:
        raise KeyError(f"Image column '{imageid}' not found in adata.obs.")
    _ensure_raw_backup(adata)
    gate_mapping = _build_gate_mapping(adata, gates_df, imageid=imageid)
    source_df = _get_source_matrix(adata, layer=layer)

    scaled_parts = []
    image_series = adata.obs[imageid].astype(str)
    for img_id in image_series.unique():
        data_subset = source_df.loc[image_series == img_id].copy()
        gate_subset = gate_mapping[gate_mapping["imageid"] == str(img_id)].set_index("markers")
        scaled_subset = pd.DataFrame(index=data_subset.index)
        for marker in data_subset.columns:
            gate_value = float(gate_subset.loc[str(marker), "gate"])
            marker_study = data_subset[marker].sort_values(axis=0)
            if marker_study.empty:
                scaled_subset[marker] = np.nan
                continue
            absolute_val_array = np.abs(marker_study.values.astype(float) - gate_value)
            if np.isnan(absolute_val_array).any():
                raise ValueError(f"Marker '{marker}' contains NaN values in source layer '{layer}'.")
            closest_element = marker_study.values[absolute_val_array.argmin()]
            if np.all(marker_study.values == 0):
                gate_index = pd.DataFrame(marker_study).tail(2).index[0]
            else:
                gate_index = marker_study.index[marker_study == closest_element][0]
            high = marker_study.loc[gate_index:]
            low = marker_study.loc[:gate_index]

            def _scale_segment(values, lower, upper):
                if len(values) == 0:
                    return pd.Series(dtype=float)
                arr = values.values.astype(np.float32)
                vmin = float(np.min(arr))
                vmax = float(np.max(arr))
                if vmax == vmin:
                    fill = np.full(arr.shape[0], upper if upper <= 0.5 else lower, dtype=np.float32)
                else:
                    fill = ((arr - vmin) / (vmax - vmin)) * (upper - lower) + lower
                return pd.Series(fill, index=values.index)

            scaled_low = _scale_segment(low, 0.0, 0.5)
            scaled_high = _scale_segment(high, 0.5, 1.0)
            scaled_marker = pd.concat([scaled_low, scaled_high])
            scaled_marker = scaled_marker.loc[~scaled_marker.index.duplicated(keep="first")]
            scaled_subset[marker] = scaled_marker.reindex(data_subset.index).values
        scaled_parts.append(scaled_subset)

    final_result = pd.concat(scaled_parts, join="outer").reindex(adata.obs.index)
    adata.uns["gates"] = gate_mapping.pivot_table(index=["markers"], columns=["imageid"]).droplevel(0, axis=1)
    adata.X = final_result.to_numpy(dtype=np.float32, copy=False)
    return adata


def _save_spatialdata(sd_obj, path: str, overwrite: bool = True) -> None:
    try:
        from .spatial_writer import write_spatialdata as _write_sd  # type: ignore
    except Exception:
        try:
            from histotuner.spatial_writer import write_spatialdata as _write_sd  # type: ignore
        except Exception:
            _write_sd = None
    if _write_sd is not None:
        _write_sd(sd_obj, path, overwrite=overwrite)
        return
    if hasattr(sd_obj, "write"):
        sd_obj.write(path, overwrite=overwrite)
        return
    raise RuntimeError("SpatialData.write(...) not available.")


def _replace_table_in_sdata(sd_obj, table_key: str, adata):
    if _SpatialData is None:
        raise RuntimeError("spatialdata is required to rebuild SpatialData with an updated table.")
    tables = dict(getattr(sd_obj, "tables", {}) or {})
    tables[str(table_key)] = adata
    return _SpatialData(
        shapes=getattr(sd_obj, "shapes", None) or None,
        images=getattr(sd_obj, "images", None) or None,
        labels=getattr(sd_obj, "labels", None) or None,
        points=getattr(sd_obj, "points", None) or None,
        tables=tables,
    )


def rescale(
    sdata=None,
    *,
    gates=None,
    tableKey: Optional[str] = None,
    layer: str = "log",
    imageid: str = "imageid",
    outputDir: Optional[str] = None,
    overwrite: bool = True,
):
    """
    Rescale a SpatialData cell table using manual gates.

    Parameters
    ----------
    sdata
        SpatialData object or path to a SpatialData Zarr store.
    gates
        Optional pandas DataFrame or CSV path. When omitted, existing `adata.uns['gates']`
        is used. When provided, it is stored into `adata.uns['gates']` before rescaling.
    tableKey
        Optional table key to update. Defaults to auto-picking the mIF cells table.
    layer
        Layer used as the source matrix for rescaling. Defaults to ``log``.
    imageid
        obs column containing image IDs for matching per-image gates. Defaults to ``imageid``.
    outputDir
        Optional output SpatialData zarr path. When omitted, writes back to the original backed store.
    overwrite
        Whether to overwrite `outputDir` when provided.
    """
    if sdata is None:
        raise ValueError("Provide `sdata` as a SpatialData object or a Zarr path string.")

    sdata_path = None
    sd_obj = sdata
    table_keys: list[str]
    if isinstance(sdata, str):
        sdata_path = str(sdata)
        table_keys = _list_table_keys_from_store(sdata_path)
        if outputDir is not None:
            sd_obj = _read_spatialdata(sdata_path)
    else:
        table_keys = list(getattr(sdata, "tables", {}).keys())
        if outputDir is None:
            sdata_path = getattr(sdata, "path", None)

    table_key_use = _pick_table_key(table_keys, tableKey)
    if table_key_use is None:
        raise KeyError("No tables found in SpatialData.")

    if isinstance(sdata, str):
        adata = _load_anndata_from_sdata_path(str(sdata_path), str(table_key_use))
    else:
        adata = _resolve_table_as_anndata(sd_obj.tables[table_key_use])
    try:
        adata = adata.copy()
    except Exception:
        pass

    if gates is None:
        if "gates" not in getattr(adata, "uns", {}):
            raise ValueError(
                "No gates provided and `adata.uns['gates']` is missing. "
                "Run napariGater first or pass a CSV/DataFrame via `gates=`."
            )
        gates_df = adata.uns["gates"]
        if not isinstance(gates_df, pd.DataFrame):
            gates_df = pd.DataFrame(gates_df)
    else:
        gates_df = _load_gates(gates)
        adata.uns["gates"] = gates_df

    adata = _rescale_with_gates(adata, gates_df, layer=str(layer), imageid=str(imageid))

    target = outputDir if outputDir is not None else sdata_path
    if target is None:
        raise ValueError("No backed SpatialData path found. Provide `outputDir` to write the updated store.")

    if outputDir is None and sdata_path is not None:
        try:
            from .spatial_writer import append_table_group  # type: ignore
        except Exception:
            try:
                from histotuner.spatial_writer import append_table_group  # type: ignore
            except Exception:
                append_table_group = None
        if append_table_group is not None:
            if append_table_group(adata, str(sdata_path), str(table_key_use), raise_on_error=True):
                return str(sdata_path)

    if isinstance(sdata, str) and outputDir is not None:
        sd_obj = _read_spatialdata(str(sdata_path))
    updated_sd = _replace_table_in_sdata(sd_obj, str(table_key_use), adata)
    _save_spatialdata(updated_sd, str(target), overwrite=overwrite)
    return str(target)


def main() -> None:
    ap = argparse.ArgumentParser(description="Rescale a SpatialData cell table using gates.")
    ap.add_argument("--sdata", required=True, help="SpatialData object path (.zarr)")
    ap.add_argument("--gates", default=None, help="Optional CSV path containing gates; first column is used as marker index")
    ap.add_argument("--tableKey", default=None, help="Optional table key to update (defaults to auto-picking mIF cells)")
    ap.add_argument("--layer", default="log", help="Source layer used for rescaling (default 'log')")
    ap.add_argument("--imageid", default="imageid", help="obs column containing image IDs (default 'imageid')")
    ap.add_argument("--outputDir", default=None, help="Optional output .zarr path; writes there instead of in-place")
    ap.add_argument("--overwrite", dest="overwrite", action="store_true", help="Overwrite outputDir if it exists")
    ap.add_argument("--noOverwrite", dest="overwrite", action="store_false")
    ap.set_defaults(overwrite=True)
    args = ap.parse_args()

    out = rescale(
        sdata=str(args.sdata),
        gates=(None if args.gates in (None, "None") else str(args.gates)),
        tableKey=(None if args.tableKey in (None, "None") else str(args.tableKey)),
        layer=str(args.layer),
        imageid=str(args.imageid),
        outputDir=(None if args.outputDir in (None, "None") else str(args.outputDir)),
        overwrite=bool(args.overwrite),
    )
    print(f"Saved rescaled data to: {out}")


if __name__ == "__main__":
    main()
