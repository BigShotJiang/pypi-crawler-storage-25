// C/C++
#include <array>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// yaml
#include <yaml-cpp/yaml.h>

// torch
#include <torch/torch.h>

// harp
#include <harp/compound.hpp>

// kintera
#include <configure.h>

#include <kintera/utils/vectors.hpp>

#include "species.hpp"

namespace kintera {

std::vector<std::string> species_names;
std::vector<double> species_weights;
std::vector<double> species_cref_R;
std::vector<double> species_uref_R;
std::vector<double> species_sref_R;
bool species_initialized = false;
std::vector<std::array<double, 9>> species_nasa9_low;
std::vector<std::array<double, 9>> species_nasa9_high;
std::vector<double> species_nasa9_Tmid;

struct Nasa9Entry {
  std::array<double, 9> low, high;
};

static std::unordered_map<std::string, Nasa9Entry>& get_nasa9_db() {
  static std::unordered_map<std::string, Nasa9Entry> db;
  if (!db.empty()) return db;

  std::string path = std::string(KINTERA_ROOT_DIR) + "/data/nasa9.dat";
  std::ifstream ifs(path);
  TORCH_CHECK(ifs.good(), "Cannot open NASA-9 data file: ", path);

  std::string line;
  while (std::getline(ifs, line)) {
    if (line.empty() || line[0] == '#') continue;
    // species name line (non-numeric first character)
    if (!std::isdigit(line[0]) && line[0] != '-' && line[0] != ' ') {
      std::string name = line;
      // trim whitespace
      while (!name.empty() && std::isspace(name.back())) name.pop_back();

      // read 4 lines of 5 values = 20 coefficients
      double vals[20];
      int idx = 0;
      for (int row = 0; row < 4 && std::getline(ifs, line); ++row) {
        std::istringstream iss(line);
        double v;
        while (iss >> v && idx < 20) vals[idx++] = v;
      }
      if (idx < 20) continue;

      Nasa9Entry e;
      // low-T range (vals 0..9): a0-a6, a7(=0), a8, a9
      // store 9 coefficients: a0-a6, a8, a9 (skip a7)
      for (int k = 0; k < 7; ++k) e.low[k] = vals[k];
      e.low[7] = vals[8];  // a8
      e.low[8] = vals[9];  // a9

      // high-T range (vals 10..19)
      for (int k = 0; k < 7; ++k) e.high[k] = vals[10 + k];
      e.high[7] = vals[18];  // a8
      e.high[8] = vals[19];  // a9

      db[name] = e;
    }
  }
  return db;
}

void init_species_from_yaml(std::string filename) {
  auto config = YAML::LoadFile(filename);
  init_species_from_yaml(config);
}

void init_species_from_yaml(YAML::Node const& config) {
  // check if species are defined
  TORCH_CHECK(config["species"],
              "'species' is not defined in the kintera configuration file");

  species_names.clear();
  species_weights.clear();
  species_cref_R.clear();
  species_uref_R.clear();
  species_sref_R.clear();
  species_nasa9_low.clear();
  species_nasa9_high.clear();
  species_nasa9_Tmid.clear();

  for (const auto& sp : config["species"]) {
    species_names.push_back(sp["name"].as<std::string>());
    std::map<std::string, double> comp;

    for (const auto& it : sp["composition"]) {
      std::string key = it.first.as<std::string>();
      double value = it.second.as<double>();
      comp[key] = value;
    }
    species_weights.push_back(harp::get_compound_weight(comp));

    if (sp["cv_R"]) {
      species_cref_R.push_back(sp["cv_R"].as<double>());
    } else {
      species_cref_R.push_back(5. / 2.);
    }

    if (sp["u0_R"]) {
      species_uref_R.push_back(sp["u0_R"].as<double>());
    } else {
      species_uref_R.push_back(0.);
    }

    if (sp["s0_R"]) {
      species_sref_R.push_back(sp["u0_R"].as<double>());
    } else {
      species_sref_R.push_back(0.);
    }

    // Look up NASA-9 thermodynamic data from data/nasa9.dat
    std::array<double, 9> low_coeffs = {};
    std::array<double, 9> high_coeffs = {};
    double Tmid = 1000.0;

    auto& nasa9_db = get_nasa9_db();
    auto name = sp["name"].as<std::string>();
    auto it = nasa9_db.find(name);
    if (it != nasa9_db.end()) {
      low_coeffs = it->second.low;
      high_coeffs = it->second.high;
    }

    // Keep the canonical species registry populated so option builders can
    // copy per-species NASA-9 data into SpeciesThermo-owned storage.
    species_nasa9_low.push_back(low_coeffs);
    species_nasa9_high.push_back(high_coeffs);
    species_nasa9_Tmid.push_back(Tmid);
  }

  species_initialized = true;
}

std::vector<std::string> SpeciesThermoImpl::species() const {
  std::vector<std::string> species_list;

  // add vapors
  for (int i = 0; i < vapor_ids().size(); ++i) {
    species_list.push_back(species_names[vapor_ids()[i]]);
  }

  // add clouds
  for (int i = 0; i < cloud_ids().size(); ++i) {
    species_list.push_back(species_names[cloud_ids()[i]]);
  }

  return species_list;
}

at::Tensor SpeciesThermoImpl::narrow_copy(at::Tensor data,
                                          SpeciesThermo const& other) const {
  auto source_ids = merge_vectors(vapor_ids(), cloud_ids());
  auto other_ids = merge_vectors(other->vapor_ids(), other->cloud_ids());
  std::vector<int64_t> indices;
  indices.reserve(source_ids.size());

  for (auto species_id : source_ids) {
    auto it = std::find(other_ids.begin(), other_ids.end(), species_id);
    TORCH_CHECK(it != other_ids.end(),
                "Missing indices for some species in other's thermo data.");
    indices.push_back(std::distance(other_ids.begin(), it));
  }

  auto id =
      torch::tensor(indices, torch::dtype(torch::kInt64).device(data.device()));

  return data.index_select(-1, id);
}

void SpeciesThermoImpl::accumulate(at::Tensor& data,
                                   at::Tensor const& other_data,
                                   SpeciesThermo const& other) const {
  auto source_ids = merge_vectors(vapor_ids(), cloud_ids());
  auto other_ids = merge_vectors(other->vapor_ids(), other->cloud_ids());
  std::vector<int64_t> indices;
  indices.reserve(source_ids.size());

  for (auto species_id : source_ids) {
    auto it = std::find(other_ids.begin(), other_ids.end(), species_id);
    TORCH_CHECK(it != other_ids.end(),
                "Missing indices for some species in other's thermo data.");
    indices.push_back(std::distance(other_ids.begin(), it));
  }

  auto id =
      torch::tensor(indices, torch::dtype(torch::kInt64).device(data.device()));
  data.index_add_(-1, id, other_data);
}

bool SpeciesThermoImpl::has_nasa9() const {
  for (auto const& coeffs : nasa9_low()) {
    for (double v : coeffs) {
      if (v != 0.0) return true;
    }
  }
  for (auto const& coeffs : nasa9_high()) {
    for (double v : coeffs) {
      if (v != 0.0) return true;
    }
  }
  return false;
}

static at::Tensor nasa9_coeffs_to_tensor(
    std::vector<std::array<double, 9>> const& coeffs,
    c10::TensorOptions const& options) {
  auto tensor = torch::empty({static_cast<long>(coeffs.size()), 9},
                             torch::dtype(torch::kFloat64));
  if (!coeffs.empty()) {
    std::memcpy(tensor.data_ptr<double>(), coeffs.data(),
                coeffs.size() * sizeof(coeffs[0]));
  }
  if (options.has_device() || options.has_dtype() || options.has_layout() ||
      options.has_pinned_memory()) {
    return tensor.to(options);
  }
  return tensor;
}

at::Tensor SpeciesThermoImpl::nasa9_coeffs_low_tensor(
    c10::TensorOptions const& options) const {
  return nasa9_coeffs_to_tensor(nasa9_low(), options);
}

at::Tensor SpeciesThermoImpl::nasa9_coeffs_high_tensor(
    c10::TensorOptions const& options) const {
  return nasa9_coeffs_to_tensor(nasa9_high(), options);
}

at::Tensor SpeciesThermoImpl::nasa9_Tmid_tensor(
    c10::TensorOptions const& options) const {
  auto tensor = torch::empty({static_cast<long>(nasa9_Tmid().size())},
                             torch::dtype(torch::kFloat64));
  if (!nasa9_Tmid().empty()) {
    std::memcpy(tensor.data_ptr<double>(), nasa9_Tmid().data(),
                nasa9_Tmid().size() * sizeof(double));
  }
  if (options.has_device() || options.has_dtype() || options.has_layout() ||
      options.has_pinned_memory()) {
    return tensor.to(options);
  }
  return tensor;
}

void populate_thermo(SpeciesThermo thermo) {
  int nspecies = thermo->vapor_ids().size() + thermo->cloud_ids().size();

  // populate higher-order thermodynamic functions
  while (thermo->intEng_R_extra().size() < nspecies) {
    thermo->intEng_R_extra().push_back("");
  }

  while (thermo->entropy_R_extra().size() < nspecies) {
    thermo->entropy_R_extra().push_back("");
  }

  while (thermo->cp_R_extra().size() < nspecies) {
    thermo->cp_R_extra().push_back("");
  }

  while (thermo->czh().size() < nspecies) {
    thermo->czh().push_back("");
  }

  while (thermo->czh_ddC().size() < nspecies) {
    thermo->czh_ddC().push_back("");
  }

  while (thermo->nasa9_low().size() < nspecies) {
    thermo->nasa9_low().push_back({});
  }

  while (thermo->nasa9_high().size() < nspecies) {
    thermo->nasa9_high().push_back({});
  }

  while (thermo->nasa9_Tmid().size() < nspecies) {
    thermo->nasa9_Tmid().push_back(1000.0);
  }
}

void check_dimensions(SpeciesThermo const& thermo) {
  int nspecies = thermo->vapor_ids().size() + thermo->cloud_ids().size();

  TORCH_CHECK(thermo->cref_R().size() == nspecies,
              "cref_R size = ", thermo->cref_R().size(),
              ". Expected = ", nspecies);

  TORCH_CHECK(thermo->uref_R().size() == nspecies,
              "uref_R size = ", thermo->uref_R().size(),
              ". Expected = ", nspecies);

  TORCH_CHECK(thermo->sref_R().size() == nspecies,
              "sref_R size = ", thermo->sref_R().size(),
              ". Expected = ", nspecies);

  TORCH_CHECK(
      thermo->intEng_R_extra().size() == nspecies,
      "Missing non-ideal internal energies. Please call `populate_thermo` "
      "to fill in the missing data.");

  TORCH_CHECK(
      thermo->cp_R_extra().size() == nspecies,
      "Missing non-ideal heat capacities at constant pressure. Please call "
      "`populate_thermo` to fill in the missing data.");

  TORCH_CHECK(thermo->entropy_R_extra().size() == nspecies,
              "Missing non-ideal entropies. Please call `populate_thermo` "
              "to fill in the missing data.");

  TORCH_CHECK(
      thermo->czh().size() == nspecies,
      "Missing non-ideal compressibilities. Please call `populate_thermo` "
      "to fill in the missing data.");

  TORCH_CHECK(thermo->czh_ddC().size() == nspecies,
              "Missing non-ideal compressibility derivatives. Please call "
              "`populate_thermo` to fill in the missing data.");

  TORCH_CHECK(thermo->nasa9_low().size() == nspecies,
              "nasa9_low size = ", thermo->nasa9_low().size(),
              ". Expected = ", nspecies);

  TORCH_CHECK(thermo->nasa9_high().size() == nspecies,
              "nasa9_high size = ", thermo->nasa9_high().size(),
              ". Expected = ", nspecies);

  TORCH_CHECK(thermo->nasa9_Tmid().size() == nspecies,
              "nasa9_Tmid size = ", thermo->nasa9_Tmid().size(),
              ". Expected = ", nspecies);
}

SpeciesThermo merge_thermo(SpeciesThermo const& thermo1,
                           SpeciesThermo const& thermo2) {
  // check dimensions
  check_dimensions(thermo1);
  check_dimensions(thermo2);

  // return a new SpeciesThermo object with merged data
  auto merged = SpeciesThermoImpl::create();

  auto& vapor_ids = merged->vapor_ids();
  auto& cloud_ids = merged->cloud_ids();

  auto& cref_R = merged->cref_R();
  auto& uref_R = merged->uref_R();
  auto& sref_R = merged->sref_R();
  auto& intEng_R_extra = merged->intEng_R_extra();
  auto& cp_R_extra = merged->cp_R_extra();
  auto& entropy_R_extra = merged->entropy_R_extra();
  auto& czh = merged->czh();
  auto& czh_ddC = merged->czh_ddC();
  auto& nasa9_low = merged->nasa9_low();
  auto& nasa9_high = merged->nasa9_high();
  auto& nasa9_Tmid = merged->nasa9_Tmid();

  // concatenate fields
  int nvapor1 = thermo1->vapor_ids().size();
  int nvapor2 = thermo2->vapor_ids().size();

  vapor_ids = merge_vectors(thermo1->vapor_ids(), thermo2->vapor_ids());
  cloud_ids = merge_vectors(thermo1->cloud_ids(), thermo2->cloud_ids());

  cref_R =
      merge_vectors(thermo1->cref_R(), thermo2->cref_R(), nvapor1, nvapor2);

  uref_R =
      merge_vectors(thermo1->uref_R(), thermo2->uref_R(), nvapor1, nvapor2);

  sref_R =
      merge_vectors(thermo1->sref_R(), thermo2->sref_R(), nvapor1, nvapor2);

  intEng_R_extra = merge_vectors(thermo1->intEng_R_extra(),
                                 thermo2->intEng_R_extra(), nvapor1, nvapor2);

  cp_R_extra = merge_vectors(thermo1->cp_R_extra(), thermo2->cp_R_extra(),
                             nvapor1, nvapor2);
  entropy_R_extra = merge_vectors(thermo1->entropy_R_extra(),
                                  thermo2->entropy_R_extra(), nvapor1, nvapor2);

  czh = merge_vectors(thermo1->czh(), thermo2->czh(), nvapor1, nvapor2);

  czh_ddC =
      merge_vectors(thermo1->czh_ddC(), thermo2->czh_ddC(), nvapor1, nvapor2);
  nasa9_low = merge_vectors(thermo1->nasa9_low(), thermo2->nasa9_low(), nvapor1,
                            nvapor2);
  nasa9_high = merge_vectors(thermo1->nasa9_high(), thermo2->nasa9_high(),
                             nvapor1, nvapor2);
  nasa9_Tmid = merge_vectors(thermo1->nasa9_Tmid(), thermo2->nasa9_Tmid(),
                             nvapor1, nvapor2);

  // identify duplicated vapor ids and remove them from all vectors
  int first = 0;
  std::set<int> seen_vapor_ids;
  while (first < vapor_ids.size()) {
    int vapor_id = vapor_ids[first];
    if (seen_vapor_ids.find(vapor_id) != seen_vapor_ids.end()) {
      // duplicate found, remove it from all vectors
      vapor_ids.erase(vapor_ids.begin() + first);
      cref_R.erase(cref_R.begin() + first);
      uref_R.erase(uref_R.begin() + first);
      sref_R.erase(sref_R.begin() + first);
      intEng_R_extra.erase(intEng_R_extra.begin() + first);
      cp_R_extra.erase(cp_R_extra.begin() + first);
      entropy_R_extra.erase(entropy_R_extra.begin() + first);
      czh.erase(czh.begin() + first);
      czh_ddC.erase(czh_ddC.begin() + first);
      nasa9_low.erase(nasa9_low.begin() + first);
      nasa9_high.erase(nasa9_high.begin() + first);
      nasa9_Tmid.erase(nasa9_Tmid.begin() + first);
    } else {
      seen_vapor_ids.insert(vapor_id);
      ++first;
    }
  }

  // argsort vapor ids
  std::vector<size_t> vidx(vapor_ids.size());
  std::iota(vidx.begin(), vidx.end(), 0);
  std::sort(vidx.begin(), vidx.end(), [&vapor_ids](size_t a, size_t b) {
    return vapor_ids[a] < vapor_ids[b];
  });

  // identify duplicated cloud ids and remove them from all vectors
  first = 0;
  int nvapor = vapor_ids.size();
  std::set<int> seen_cloud_ids;

  while (first < cloud_ids.size()) {
    int cloud_id = cloud_ids[first];
    if (seen_cloud_ids.find(cloud_id) != seen_cloud_ids.end()) {
      // duplicate found, remove it from all vectors
      cloud_ids.erase(cloud_ids.begin() + first);
      cref_R.erase(cref_R.begin() + nvapor + first);
      uref_R.erase(uref_R.begin() + nvapor + first);
      sref_R.erase(sref_R.begin() + nvapor + first);
      intEng_R_extra.erase(intEng_R_extra.begin() + nvapor + first);
      cp_R_extra.erase(cp_R_extra.begin() + nvapor + first);
      entropy_R_extra.erase(entropy_R_extra.begin() + nvapor + first);
      czh.erase(czh.begin() + nvapor + first);
      czh_ddC.erase(czh_ddC.begin() + nvapor + first);
      nasa9_low.erase(nasa9_low.begin() + nvapor + first);
      nasa9_high.erase(nasa9_high.begin() + nvapor + first);
      nasa9_Tmid.erase(nasa9_Tmid.begin() + nvapor + first);
    } else {
      seen_cloud_ids.insert(cloud_id);
      ++first;
    }
  }

  // argsort cloud ids
  std::vector<size_t> cidx(cloud_ids.size());
  std::iota(cidx.begin(), cidx.end(), 0);
  std::sort(cidx.begin(), cidx.end(), [&cloud_ids](size_t a, size_t b) {
    return cloud_ids[a] < cloud_ids[b];
  });

  // re-arrange all vectors according to the sorted indices
  vapor_ids = sort_vectors(vapor_ids, vidx);
  cloud_ids = sort_vectors(cloud_ids, cidx);

  // add nvapor to cidx
  for (auto& idx : cidx) idx += nvapor;

  auto sorted = merge_vectors(vidx, cidx);

  cref_R = sort_vectors(cref_R, sorted);
  uref_R = sort_vectors(uref_R, sorted);
  sref_R = sort_vectors(sref_R, sorted);

  intEng_R_extra = sort_vectors(intEng_R_extra, sorted);
  cp_R_extra = sort_vectors(cp_R_extra, sorted);
  entropy_R_extra = sort_vectors(entropy_R_extra, sorted);

  czh = sort_vectors(czh, sorted);
  czh_ddC = sort_vectors(czh_ddC, sorted);
  nasa9_low = sort_vectors(nasa9_low, sorted);
  nasa9_high = sort_vectors(nasa9_high, sorted);
  nasa9_Tmid = sort_vectors(nasa9_Tmid, sorted);

  return merged;
}

}  // namespace kintera
