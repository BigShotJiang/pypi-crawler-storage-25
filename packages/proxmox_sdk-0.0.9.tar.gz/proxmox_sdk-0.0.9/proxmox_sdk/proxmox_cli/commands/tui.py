"""TUI command for proxmox CLI."""

from __future__ import annotations

from typing import Literal

import typer

from proxmox_sdk.proxmox_cli.app import app
from proxmox_sdk.proxmox_cli.decorators import cli_error_handler
from proxmox_sdk.proxmox_cli.exceptions import ProxmoxCLIError
from proxmox_sdk.proxmox_cli.sdk_bridge import ProxmoxSDKBridge
from proxmox_sdk.proxmox_cli.tui_runner import launch_tui
from proxmox_sdk.proxmox_cli.utils import validate_api_path

from ._common import build_backend_config


@app.command("tui")
@cli_error_handler
def tui(
    ctx: typer.Context,
    mode: Literal["mock"] | None = typer.Argument(
        None,
        help="Optional mode. Use 'mock' to run TUI against in-memory mock backend.",
    ),
    path: str = typer.Option(
        "/nodes",
        "--path",
        "-p",
        help="Initial API path to load in the TUI.",
    ),
) -> None:
    """Launch interactive Proxmox TUI for resource navigation and management.

    Opens a full-screen terminal UI for browsing Proxmox API resources
    hierarchically and performing operations. Supports both real backends
    (HTTPS, SSH, local) and mock mode for testing/learning.

    MODE:
        - Omit or use 'mock' to connect to in-memory mock backend
        - Otherwise connects using configured backend credentials

    Key controls:
        - Arrow keys: Navigate resources
        - Enter: Drill into path or edit
        - q: Quit
        - j/k: Jump between entries
        - s: Search
        - /: Filter

    Examples:
        # Launch with configured Proxmox backend
        proxmox tui

        # Launch against mock backend (no credentials needed)
        proxmox tui mock

        # Start at specific path
        proxmox tui -p /nodes/pve1/qemu

        # For PMG/PBS:
        pbx tui          # Proxmox Mail Gateway
        pbs tui          # Proxmox Backup Server
    """
    bridge: ProxmoxSDKBridge | None = None

    try:
        ctx_obj = ctx.obj or {}
        initial_path = validate_api_path(path)
        use_mock = mode == "mock"

        backend_cfg = build_backend_config(ctx_obj, use_mock=use_mock)
        bridge = ProxmoxSDKBridge.create(backend_cfg)

        try:
            launch_tui(
                bridge=bridge,
                mode="mock" if use_mock else "production",
                initial_path=initial_path,
            )
        except RuntimeError as exc:
            raise ProxmoxCLIError(str(exc), exit_code=2) from exc
    finally:
        if bridge is not None:
            bridge.close()
