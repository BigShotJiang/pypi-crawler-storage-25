from __future__ import annotations

import asyncio
import collections.abc
import json
import logging
from typing import Any, AsyncIterable, Sequence

from livekit.agents import llm
from livekit.agents.llm.chat_context import Instructions
from livekit.agents.types import FlushSentinel
from livekit.agents.voice import Agent, ModelSettings

from .config import AgentAdapterConfig
from .response_types import Done, ExternalLLMResponse, TextChunk, ToolCall

logger = logging.getLogger("livekit_agents_adapter")


class _AdapterLLM(llm.LLM):
    """Pass-through LLM stub — actual inference goes through :meth:`AgentAdapter.llm_node`.

    LiveKit Agents 1.4+ checks ``self.llm is not None`` before calling
    ``generate_reply()``. This stub satisfies that guard without performing
    any real inference.  Its :meth:`chat` is never called because the adapter
    overrides :meth:`AgentAdapter.llm_node` entirely.
    """

    @property
    def model(self) -> str:
        return "adapter"

    @property
    def provider(self) -> str:
        return "adapter"

    def chat(self, **kwargs: Any) -> llm.LLMStream:
        raise NotImplementedError(
            "_AdapterLLM is a stub — inference goes through AgentAdapter.llm_node"
        )


class AgentAdapter(Agent):
    """
    A LiveKit :class:`~livekit.agents.voice.Agent` that delegates LLM inference
    to an external framework (LangChain, LangGraph, Strands, ADK, custom, etc.)
    via a :class:`~.config.AgentAdapterConfig`.

    The adapter overrides :meth:`llm_node` to:

    1. Convert LiveKit's :class:`~livekit.agents.llm.ChatContext` to the
       external framework's native format using the configured :attr:`config`'s
       :class:`~.translators.base.Translator`.
    2. Stream responses from the external framework, yielding
       :class:`~livekit.agents.llm.ChatChunk` for text and tool call requests.
    3. Buffer tool calls until the external framework signals ``Done``, then
       flush all accumulated chunks to LiveKit (transcript + TTS).
    4. Sync the external framework's conversation history back into the LiveKit
       ChatContext after each turn (when :attr:`config.sync_chat_history` is ``True``).

    The adapter is a **pure pass-through**: it takes the user's transcription,
    passes it to the external agent, and forwards whatever text the agent streams.
    Tool calls and tool execution are handled entirely within the external agent;
    the adapter only forwards ``FunctionToolCall`` metadata to LiveKit's ChatContext
    for transcript/logging purposes.

    Example::

        from livekit_agents_adapter import AgentAdapter, AgentAdapterConfig
        from my_translator import MyFrameworkTranslator

        config = AgentAdapterConfig(
            translator=MyFrameworkTranslator(my_agent),
            on_enter_hook=my_init,
            on_exit_hook=my_cleanup,
        )

        agent = AgentAdapter(
            config=config,
            instructions="You are a helpful assistant.",
        )
    """

    def __init__(
        self,
        config: AgentAdapterConfig,
        *,
        instructions: str | Instructions,
        **kwargs: Any,
    ) -> None:
        extra = config.extra_instructions or ""
        if extra:
            base = instructions if isinstance(instructions, str) else instructions.text
            instructions = Instructions(f"{base}\n\n{extra}")

        if "llm" not in kwargs:
            kwargs["llm"] = _AdapterLLM()

        super().__init__(instructions=instructions, **kwargs)
        self._config = config
        self._translator = config.translator

    async def on_enter(self) -> None:
        """Called when the agent enters a session.

        Resets the translator state (clearing any prior session's message history),
        then invokes the configured ``on_enter_hook`` and the translator's
        :meth:`~.translators.base.Translator.on_enter`.
        """
        self._translator.reset()
        if self._config.on_enter_hook:
            await self._config.on_enter_hook()
        await self._translator.on_enter()

    async def on_exit(self) -> None:
        """Clean up when the agent leaves a session."""
        if self._config.on_exit_hook:
            await self._config.on_exit_hook()
        await self._translator.on_exit()

    async def llm_node(
        self,
        chat_ctx: llm.ChatContext,
        tools: list[llm.Tool],
        model_settings: ModelSettings,
    ) -> AsyncIterable[llm.ChatChunk | str | FlushSentinel]:
        """
        The main adapter pipeline.

        1. Converts the ChatContext to the external format.
        2. Invokes the translator and buffers all chunks (text + tool calls).
        3. On ``Done``: syncs history and flushes all buffered chunks to LiveKit.

        If the external framework raises an error mid-stream, the adapter
        yields a fallback message and ``FlushSentinel`` so that LiveKit can
        recover gracefully instead of terminating the voice session.
        """
        external_ctx = await self._translator.to_external_chat_ctx(chat_ctx)

        latest_tools = self._translator.get_latest_tools()
        active_tools: Sequence[llm.Tool | llm.Toolset] = (
            latest_tools if latest_tools is not None else tools
        )
        flat_tools = self._flatten_tools(active_tools)

        external_tools = await self._translator.to_external_tools(flat_tools)

        done_emitted = False

        try:
            async for response in self._stream_invoke(external_ctx, external_tools):
                if isinstance(response, TextChunk):
                    yield self._make_chunk(response.content)

                elif isinstance(response, ToolCall):
                    yield self._make_tool_chunk(response)

                elif isinstance(response, Done):
                    done_emitted = True
                    if self._config.sync_chat_history:
                        try:
                            new_items = await self._translator.sync_back_messages(chat_ctx)
                            for item in new_items:
                                chat_ctx.insert(item)
                        except Exception as e:
                            logger.warning(
                                "failed to sync chat history: %s",
                                e,
                                exc_info=True,
                            )

                    yield FlushSentinel()
        except Exception as e:
            logger.error("external agent failed mid-stream: %s", e, exc_info=True)
            yield self._make_chunk("I'm sorry, something went wrong. Please try again.")
            if not done_emitted:
                yield FlushSentinel()

    async def _stream_invoke(
        self, external_ctx: Any, external_tools: Any
    ) -> AsyncIterable[ExternalLLMResponse]:
        """
        Invoke the translator, wrapping sync iterables as async generators.
        """
        raw_result = self._translator.invoke(external_ctx, external_tools)

        if isinstance(raw_result, collections.abc.AsyncIterable):
            async for item in raw_result:
                yield item
        elif isinstance(raw_result, collections.abc.Iterable):
            items = await asyncio.to_thread(_collect_iterable, raw_result)
            for item in items:
                yield item
        else:
            raise TypeError(
                f"translator.invoke() returned unsupported type: "
                f"{type(raw_result).__name__}. Expected an async generator or sync iterable."
            )

    def _flatten_tools(self, tools: Sequence[llm.Tool | llm.Toolset]) -> list[llm.Tool]:
        flat: list[llm.Tool] = []
        for t in tools:
            if isinstance(t, llm.Tool):
                flat.append(t)
            else:
                for inner in t.tools:
                    flat.append(inner)
        return flat

    def _make_chunk(self, content: str) -> llm.ChatChunk:
        return llm.ChatChunk(
            id="",
            delta=llm.ChoiceDelta(content=content),
            usage=None,
        )

    def _make_tool_chunk(self, tool_call: ToolCall) -> llm.ChatChunk:
        args_val = tool_call.arguments
        args_str: str
        if isinstance(args_val, dict):
            args_str = json.dumps(args_val)
        else:
            args_str = str(args_val)

        fc = llm.FunctionToolCall(
            call_id=tool_call.call_id or "",
            name=tool_call.name,
            arguments=args_str,
        )
        return llm.ChatChunk(
            id="",
            delta=llm.ChoiceDelta(
                content=None,
                tool_calls=[fc],
            ),
            usage=None,
        )


def _collect_iterable(sync_obj: Any) -> list[Any]:
    """Collect a sync iterable/generator into a list. Runs in a thread."""
    return list(sync_obj)
