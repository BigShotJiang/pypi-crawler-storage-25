"""LiveKit Agents Adapter — bridge external AI frameworks to LiveKit Agents.

This package provides :class:`AgentAdapter`, a LiveKit Agent subclass that
delegates LLM inference to any external agent framework (LangChain, LangGraph,
Strands, ADK, custom code, etc.) via a pluggable :class:`Translator`.

Example usage::

    from livekit_agents_adapter import AgentAdapter, AgentAdapterConfig
    from my_translator import MyFrameworkTranslator

    config = AgentAdapterConfig(
        translator=MyFrameworkTranslator(my_agent),
    )

    agent = AgentAdapter(
        config=config,
        instructions="You are a helpful assistant.",
    )

    # Use like any LiveKit Agent in AgentSession...
"""

from __future__ import annotations

from .base import AgentAdapter
from .config import AgentAdapterConfig
from .response_types import Done, ExternalLLMResponse, TextChunk, ToolCall
from .translators.base import Translator

__all__ = [
    "AgentAdapter",
    "AgentAdapterConfig",
    "Translator",
    "ExternalLLMResponse",
    "TextChunk",
    "ToolCall",
    "Done",
]
