from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Coroutine

from .translators.base import Translator


@dataclass
class AgentAdapterConfig:
    """
    Configuration for :class:`~.base.AgentAdapter`.

    Note on translator lifecycle: the ``translator`` is reset once per
    :meth:`~.base.AgentAdapter.on_enter` (i.e., once per voice session).
    If you reuse a single ``Translator`` instance across multiple sessions,
    ``reset()`` is called at session start so conversation history does not
    bleed between sessions.

    Args:
        translator: A :class:`~.translators.base.Translator` that bridges
            between LiveKit's ChatContext/llm.Tool format and the external
            agent framework's native format.
        on_enter_hook: Optional async callable invoked in :meth:`~.base.AgentAdapter.on_enter`.
            Use for initializing the external framework (e.g., loading a model,
            establishing a connection). Receives no arguments.
        on_exit_hook: Optional async callable invoked in :meth:`~.base.AgentAdapter.on_exit`.
            Use for cleaning up the external framework.
        sync_chat_history: If ``True`` (default), after each model turn the adapter
            syncs the external framework's conversation history back into
            LiveKit's ChatContext via :meth:`~.translators.base.Translator.sync_back_messages`.
            Disable if the external framework owns chat history exclusively.
        extra_instructions: Additional instruction text appended to the agent's
            base :attr:`instructions` at runtime. Useful for framework-specific
            preamble or runtime prompt adjustments.
    """

    translator: Translator
    """The framework-specific translator instance."""

    on_enter_hook: Callable[[], Coroutine[Any, Any, None]] | None = None
    """Async callable invoked when the agent enters a session."""

    on_exit_hook: Callable[[], Coroutine[Any, Any, None]] | None = None
    """Async callable invoked when the agent exits a session."""

    sync_chat_history: bool = True
    """Whether to sync external chat history back into LiveKit ChatContext."""

    extra_instructions: str | None = None
    """Extra instructions appended to the agent's base instructions."""

    def __post_init__(self) -> None:
        if not isinstance(self.translator, Translator):
            raise TypeError(
                f"translator must be a Translator instance; got {type(self.translator).__name__}"
            )
