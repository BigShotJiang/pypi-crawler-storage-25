from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TextChunk:
    """A text content chunk from the external LLM."""

    content: str
    """The text content of the chunk."""

    is_final: bool = False
    """Whether this is the final chunk for this turn."""


@dataclass
class ToolCall:
    """A tool call request from the external LLM."""

    name: str
    """Name of the tool to call."""

    arguments: dict[str, Any] = field(default_factory=dict)
    """Tool arguments as a dictionary."""

    call_id: str | None = None
    """Optional call ID for tracking."""


@dataclass
class Done:
    """Signals the end of a response turn from the external LLM."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional metadata from the final response (e.g., usage, finish_reason)."""


ExternalLLMResponse = TextChunk | ToolCall | Done
"""Union of possible responses from an external LLM via a Translator."""
