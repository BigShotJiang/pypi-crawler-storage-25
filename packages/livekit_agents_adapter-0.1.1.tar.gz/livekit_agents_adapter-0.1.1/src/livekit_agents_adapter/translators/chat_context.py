from __future__ import annotations

import inspect as _inspect
import json
import typing as _typing
from typing import Any, Iterable

from livekit.agents import llm as _llm
from livekit.agents.llm.chat_context import FunctionCall, FunctionCallOutput


def _append_user_text(chat_ctx: Any, text: str) -> None:
    chat_ctx.insert(_llm.ChatMessage(role="user", content=[text]))


def _append_assistant_text(chat_ctx: Any, text: str) -> None:
    chat_ctx.insert(_llm.ChatMessage(role="assistant", content=[text]))


def _append_system_text(chat_ctx: Any, text: str) -> None:
    chat_ctx.insert(_llm.ChatMessage(role="system", content=[text]))


def _append_function_call(
    chat_ctx: Any,
    call_id: str,
    name: str,
    arguments: dict[str, Any],
) -> None:
    args_str = json.dumps(arguments) if isinstance(arguments, dict) else str(arguments)
    chat_ctx.insert(FunctionCall(call_id=call_id, name=name, arguments=args_str))


def _append_function_call_result(
    chat_ctx: Any,
    call_id: str,
    output: str,
    is_error: bool = False,
) -> None:
    chat_ctx.insert(FunctionCallOutput(call_id=call_id, output=output, is_error=is_error))


def sync_from_list(
    chat_ctx: Any,
    messages: Iterable[dict[str, Any]],
) -> None:
    """
    Sync messages from a list of dicts into ChatContext.

    Expected dict format::

        {"role": "user"|"assistant"|"system", "content": str, ...}
        or
        {"type": "function_call", "call_id": str, "name": str, "arguments": dict, ...}
        or
        {"type": "function_call_output", "call_id": str, "output": str, "is_error": bool}

    Handles common message formats from LangChain, LangGraph, etc.

    Args:
        chat_ctx: The LiveKit ChatContext to update.
        messages: An iterable of message dicts from the external framework.
    """
    for item in sync_from_list_to_items(messages):
        chat_ctx.insert(item)


def sync_from_list_to_items(
    messages: Iterable[dict[str, Any]],
) -> list[Any]:
    """
    Convert an iterable of message dicts into LiveKit ``ChatItem`` objects.

    Expected dict format::

        {"role": "user"|"assistant"|"system", "content": str, ...}
        or
        {"type": "function_call", "call_id": str, "name": str, "arguments": dict, ...}
        or
        {"type": "function_call_output", "call_id": str, "output": str, "is_error": bool}

    Note: ``is_error`` in ``function_call_output`` dicts is optional and
    defaults to ``False``. External frameworks that track tool error status
    should include it so that LiveKit UI components can render errors distinctly.

    Args:
        messages: An iterable of message dicts from the external framework.

    Returns:
        A list of LiveKit ``ChatItem`` objects ready for
        :meth:`~livekit.agents.llm.ChatContext.insert`.
    """
    items: list[Any] = []
    for msg in messages:
        msg_type = msg.get("type", "")
        role = msg.get("role", "").lower()

        if msg_type == "function_call":
            args = msg.get("arguments", {})
            args_str = json.dumps(args) if isinstance(args, dict) else str(args)
            items.append(
                FunctionCall(
                    call_id=msg.get("call_id", ""),
                    name=msg.get("name", ""),
                    arguments=args_str,
                )
            )

        elif msg_type == "function_call_output":
            items.append(
                FunctionCallOutput(
                    call_id=msg.get("call_id", ""),
                    output=str(msg.get("output", "")),
                    is_error=bool(msg.get("is_error", False)),
                )
            )

        elif role in ("user", "human"):
            items.append(_llm.ChatMessage(role="user", content=[str(msg.get("content", ""))]))

        elif role in ("assistant", "ai", "agent"):
            items.append(_llm.ChatMessage(role="assistant", content=[str(msg.get("content", ""))]))

        elif role == "system":
            items.append(_llm.ChatMessage(role="system", content=[str(msg.get("content", ""))]))

    return items


class ChatContextSync:
    """
    Helper utilities for syncing external framework message history
    back into LiveKit's :class:`~livekit.agents.llm.ChatContext`.

    .. deprecated::
        All methods are now module-level functions. Use the module functions
        directly (``sync_from_list(chat_ctx, messages)``) instead of instantiating
        this class.
    """

    append_user_text = staticmethod(_append_user_text)
    append_assistant_text = staticmethod(_append_assistant_text)
    append_system_text = staticmethod(_append_system_text)
    append_function_call = staticmethod(_append_function_call)
    append_function_call_result = staticmethod(_append_function_call_result)
    sync_from_list = staticmethod(sync_from_list)
    sync_from_list_to_items = staticmethod(sync_from_list_to_items)


def build_tools_dict(
    tools: list[_llm.Tool],
) -> list[dict[str, Any]]:
    """
    Convert a list of LiveKit llm.Tool objects to a list of plain dicts.

    For :class:`FunctionTool` and :class:`RawFunctionTool`, extracts the
    name, description, and parameters from the underlying function signature
    and info.

    Useful as a utility when building external framework tool formats.
    """
    result = []
    for tool in tools:
        info = getattr(tool, "_info", None)
        if info is None:
            continue

        name: str = getattr(info, "name", "") or ""
        description: str | None = getattr(info, "description", None)

        params: dict[str, Any] = {"type": "object", "properties": {}, "required": []}
        raw_schema = getattr(info, "raw_schema", None)

        if raw_schema is not None:
            # Prefer explicitly provided schema over signature reflection.
            params = raw_schema
        else:
            _func = getattr(tool, "_func", None)
            if _func is not None:
                sig = _inspect.signature(_func)
                schema_from_sig: dict[str, Any] = {
                    "type": "object",
                    "properties": {},
                    "required": [],
                }
                for pname, param in sig.parameters.items():
                    param_info: dict[str, Any] = {"type": "string"}
                    if param.annotation is not _inspect.Parameter.empty:
                        anno = param.annotation
                        # Unwrap Optional[X] -> X
                        origin = getattr(anno, "__origin__", None)
                        if origin is _typing.Union:
                            args = [a for a in anno.__args__ if a is not type(None)]
                            anno = args[0] if args else anno

                        if anno is int:
                            param_info["type"] = "integer"
                        elif anno is float:
                            param_info["type"] = "number"
                        elif anno is bool:
                            param_info["type"] = "boolean"
                        elif anno is list or origin is list:
                            param_info["type"] = "array"
                        elif anno is dict or origin is dict:
                            param_info["type"] = "object"

                    if param.default is not _inspect.Parameter.empty:
                        schema_from_sig["properties"][pname] = param_info
                        if param.default is not None:
                            param_info["default"] = param.default
                    else:
                        schema_from_sig["properties"][pname] = param_info
                        schema_from_sig["required"].append(pname)
                params = schema_from_sig

        if name:
            result.append(
                {
                    "name": name,
                    "description": description or "",
                    "parameters": params,
                }
            )

    return result
