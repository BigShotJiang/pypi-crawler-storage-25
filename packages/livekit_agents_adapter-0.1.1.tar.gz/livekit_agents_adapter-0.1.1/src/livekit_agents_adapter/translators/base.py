"""Translators for bridging external frameworks to LiveKit Agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, AsyncIterable

from ..response_types import ExternalLLMResponse

if TYPE_CHECKING:
    from livekit.agents import llm


class Translator(ABC):
    """
    Abstract base class for translating between LiveKit's ChatContext/llm.Tool
    format and an external agent framework's native format.

    Subclass this to create adapters for LangChain, LangGraph, Strands, ADK,
    or any other agent framework.
    """

    @abstractmethod
    async def to_external_chat_ctx(self, chat_ctx: "llm.ChatContext") -> Any:
        """
        Convert a LiveKit ChatContext into the external framework's native
        message format (e.g., a list of dicts, a LangChain MessagesSequence,
        a LangGraph state dict, etc.).

        Args:
            chat_ctx: The current LiveKit ChatContext.

        Returns:
            The external framework's representation of the conversation history.
        """

    @abstractmethod
    async def to_external_tools(self, tools: list["llm.Tool"]) -> Any:
        """
        Convert a list of LiveKit llm.Tool definitions into the external
        framework's native tool format.

        Args:
            tools: The list of LiveKit tools available to the agent.

        Returns:
            The external framework's representation of tools.
        """

    @abstractmethod
    async def invoke(self, chat_ctx: Any, tools: Any) -> AsyncIterable["ExternalLLMResponse"]:
        """
        Invoke the external agent with the given chat context and tools,
        yielding streaming responses.

        This method is called once per model inference turn. It must be
        an async generator (using ``async def ... yield``). The adapter
        handles wrapping sync iterables automatically.

        Yield ``TextChunk`` for text content, ``ToolCall`` for tool call requests,
        and ``Done`` to signal end of turn.

        Args:
            chat_ctx: The external-format chat context from :meth:`to_external_chat_ctx`.
            tools: The external-format tools from :meth:`to_external_tools`.
        """

    @abstractmethod
    async def sync_back_messages(self, chat_ctx: "llm.ChatContext") -> list[Any]:
        """
        Sync the external framework's conversation history back into
        LiveKit's ChatContext.

        Called after each turn so that tools, transcript features,
        and other LiveKit-side components see the full conversation
        including the model's output and any tool results.

        Return a list of new :class:`~livekit.agents.llm.chat_context.ChatItem`
        objects (``ChatMessage``, ``FunctionCall``, ``FunctionCallOutput``,
        etc.) that should be appended to the LiveKit ChatContext. The adapter
        will call :meth:`~livekit.agents.llm.ChatContext.insert` on the
        returned items — **do not** mutate ``chat_ctx`` inside this method.

        Args:
            chat_ctx: The LiveKit ChatContext (read-only from the translator's
                perspective).

        Returns:
            A list of items to insert into the ChatContext.
        """

    def get_latest_tools(self) -> list["llm.Tool"] | None:
        """
        Return the current list of tools in the external framework.

        Some agent frameworks (e.g., LangGraph) can update their tool
        schemas dynamically during execution. Return ``None`` to use
        the tools from the initial :meth:`to_external_tools` call.
        """
        return None

    async def on_enter(self) -> None:
        """Called when the agent enters a session. Use for initialization."""
        pass

    async def on_exit(self) -> None:
        """Called when the agent exits a session. Use for cleanup."""
        pass

    def reset(self) -> None:
        """Reset translator state for a new session.

        Subclasses that hold mutable state (e.g., message history) must
        override this method to restore their initial state. The adapter
        calls ``reset()`` in :meth:`AgentAdapter.on_enter`, so every
        new voice session starts with a clean translator.

        The default implementation is a no-op, which is sufficient for
        stateless translators that maintain no internal state.
        """
        pass
