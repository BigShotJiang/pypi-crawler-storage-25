# LiveKit Agents Adapter

Bridge any external AI agent framework to the LiveKit Agent runtime.

## Overview

This package provides `AgentAdapter`, a `livekit.agents.voice.Agent` subclass that delegates
LLM inference to an external framework (LangChain, LangGraph, Strands, ADK, custom code, etc.)
via a pluggable `Translator` interface.

The adapter is a **pure pass-through**:

1. Converts LiveKit's `ChatContext` to the external framework's native format
2. Forwards text and tool calls streamed from the external framework into LiveKit's `llm_node`
3. Syncs conversation history back to the LiveKit `ChatContext` after each turn

**Tool calls are handled entirely within the external framework.** The adapter does not
execute tools. When the external framework streams a `ToolCall`, it is forwarded to
LiveKit's ChatContext for transcript/logging purposes only. The external framework
decides when and how to stream its final text response.

## Quick Start

```python
from livekit_agents_adapter import AgentAdapter, AgentAdapterConfig, Translator, TextChunk, Done


class MyTranslator(Translator):
    async def invoke(self, chat_ctx, tools):
        yield TextChunk(content="Hello!", is_final=True)
        yield Done(metadata={})

    # ... implement to_external_chat_ctx, to_external_tools, sync_back_messages


agent = AgentAdapter(
    config=AgentAdapterConfig(translator=MyTranslator(my_agent)),
    instructions="You are a helpful voice assistant.",
)

# Use like any LiveKit Agent in AgentSession...
await session.start(agent=agent, room=room)
```

## Writing a Translator

Subclass `Translator` (an `abc.ABC`) and implement four required methods:

```python
from livekit_agents_adapter import Translator, TextChunk, ToolCall, Done


class MyTranslator(Translator):
    async def to_external_chat_ctx(self, chat_ctx):
        # Convert LiveKit ChatContext → your framework's format
        return my_framework_messages

    async def to_external_tools(self, tools):
        # Convert LiveKit llm.Tool → your framework's tool format
        return my_framework_tools

    async def invoke(self, chat_ctx, tools):
        # Stream responses from your framework.
        # The adapter forwards TextChunk to TTS, ToolCall to ChatContext.
        # Yield Done to signal end of turn.
        async for chunk in my_framework_stream(chat_ctx, tools):
            yield TextChunk(content=chunk)  # or ToolCall(...)

        yield Done(metadata={})

    async def sync_back_messages(self, chat_ctx):
        # Return new ChatItems for the adapter to insert into ChatContext.
        from livekit_agents_adapter.translators.chat_context import sync_from_list_to_items

        return sync_from_list_to_items(self._messages[self._last_synced_count :])
```

## Installation

```bash
# Core package
pip install livekit-agents-adapter

# With LangChain support
pip install livekit-agents-adapter-langchain
```

## More

- Source: https://github.com/guttume/livekit_agents_adapter
- Examples: see the [`examples/`](../../examples/) directory in the source repo
