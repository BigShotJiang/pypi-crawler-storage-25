import dataclasses

from flowra.agent import AgentRuntime
from flowra.lib.tool_loop.tool_call import ToolCallAgent, ToolCallResult, ToolCallSpec
from flowra.llm import ToolUseBlock
from flowra.tools import ToolRegistry, get_local_tool, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AddParams:
    a: int
    b: int


@tool("add")
def add_tool(params: AddParams) -> int:
    """Add two numbers."""
    return params.a + params.b


class TestToolCallAgent:
    async def test_execute_tool_call(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use),
            )

            assert isinstance(result, ToolCallResult)
            assert result.tool_use == tool_use
            assert result.result.tool_use_id == "call_1"
            assert result.result.content == "5"
            assert result.result.is_error is False

    async def test_denied_by_allowed_tools(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"other_tool"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is True
            assert result.result.content == "Unknown tool: add"

    async def test_denied_by_denied_tools(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, denied_tools={"add"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is True
            assert result.result.content == "Unknown tool: add"

    async def test_allowed_tools_permits_listed_tool(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"add"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is False
            assert result.result.content == "5"

    async def test_allowed_tools_wildcard(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"add*"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is False
            assert result.result.content == "5"

    async def test_allowed_tools_wildcard_no_match(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, allowed_tools={"mcp_*"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is True

    async def test_denied_tools_wildcard(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            tool_use = ToolUseBlock(id="call_1", name="add", input={"a": 2, "b": 3})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use, denied_tools={"a*"}),
            )

            assert isinstance(result, ToolCallResult)
            assert result.result.is_error is True

    async def test_execute_interrupted(self) -> None:
        async with await ToolRegistry.create([get_local_tool(add_tool)]) as registry:
            runtime = AgentRuntime(
                agents={"tool_call": ToolCallAgent},
                services={ToolRegistry: registry},
            )

            runtime.interrupt()

            tool_use = ToolUseBlock(id="call_2", name="add", input={"a": 10, "b": 20})

            result = await runtime.run(
                agent=ToolCallAgent,
                spec=ToolCallSpec(tool_use=tool_use),
            )

            assert isinstance(result, ToolCallResult)
            assert result.tool_use == tool_use
            assert result.result.tool_use_id == "call_2"
            assert result.result.content == "Tool execution interrupted"
            assert result.result.is_error is True
