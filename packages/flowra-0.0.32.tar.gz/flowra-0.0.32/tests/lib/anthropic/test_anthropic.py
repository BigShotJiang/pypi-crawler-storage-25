from typing import Any

import pytest

from flowra.agent import AgentInfo, Event, ExecutionContext, ExecutionFrame, HookSubscription
from flowra.lib.anthropic import (
    ANTHROPIC_CACHE_ALL,
    ANTHROPIC_CACHE_ALL_MESSAGES,
    ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_ALL_TOOLS,
    ANTHROPIC_CACHE_HISTORY_MESSAGES,
    ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES,
    ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES,
    ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS,
    ANTHROPIC_CACHE_SESSION,
    AnthropicToolSearch,
    ToolSearchVariant,
)
from flowra.lib.chat import SaveHistoryEvent
from flowra.lib.tool_loop import PrepareLLMRequestEvent
from flowra.llm import AssistantMessage, LLMRequest, SystemMessage, TextBlock, Tool, ToolUseBlock, UserMessage

_CC = {"anthropic": {"cache_control": {"type": "ephemeral"}}}

_DUMMY_CONTEXT = ExecutionContext(
    frame=ExecutionFrame(agent=AgentInfo(name="test", path="test", source_type=None, parent=None)),
    stack=(ExecutionFrame(agent=AgentInfo(name="test", path="test", source_type=None, parent=None)),),
)


def _sys(text: str, *, transient: bool = False) -> SystemMessage:
    return SystemMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _user(text: str, *, transient: bool = False) -> UserMessage:
    return UserMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _assistant(text: str, *, transient: bool = False) -> AssistantMessage:
    return AssistantMessage(blocks=[TextBlock(text=text, transient=transient)], transient=transient)


def _tool(name: str) -> Tool:
    return Tool(name=name, description="", input_schema=None)


def _request(
    system: list[SystemMessage] | None = None,
    messages: list[UserMessage | AssistantMessage] | None = None,
    tools: list[Tool] | None = None,
) -> LLMRequest:
    return LLMRequest(model="test", system=system or [], messages=messages or [], tools=tools)


def _prepare_event(request: LLMRequest) -> Event[PrepareLLMRequestEvent]:
    return Event(data=PrepareLLMRequestEvent(request=request), context=_DUMMY_CONTEXT)


def _save_history_event(
    messages: list[UserMessage | AssistantMessage],
) -> Event[SaveHistoryEvent]:
    return Event(data=SaveHistoryEvent(messages=list(messages)), context=_DUMMY_CONTEXT)


def _apply(ext: Any, request: LLMRequest) -> LLMRequest:
    """Simulate the hook pipeline."""
    event = _prepare_event(request)
    ext.on_prepare(event)
    return event.data.request


# -- System message caching --


class TestCacheAllSystemMessages:
    def test_caches_last_system_block(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES
        req = _request(system=[_sys("a"), _sys("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra.get("anthropic", {})
        assert result.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_system(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES
        req = _request(system=[])
        result = _apply(ext, req)
        assert result.system == []

    def test_clears_old_cache(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES
        req = _request(
            system=[
                SystemMessage(blocks=[TextBlock(text="a", extra=_CC)]),
                _sys("b"),
            ]
        )
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra.get("anthropic", {})
        assert result.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientSystemMessages:
    def test_caches_last_non_transient(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES
        req = _request(system=[_sys("stable"), _sys("dynamic", transient=True)])
        result = _apply(ext, req)
        assert result.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.system[1].blocks[0].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES
        req = _request(system=[_sys("a"), _sys("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra.get("anthropic", {})
        assert result.system[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_all_transient_no_cache(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES
        req = _request(system=[_sys("a", transient=True)])
        result = _apply(ext, req)
        assert "cache_control" not in result.system[0].blocks[0].extra.get("anthropic", {})

    def test_multi_block_system_message(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES
        req = _request(
            system=[
                SystemMessage(
                    blocks=[
                        TextBlock(text="stable"),
                        TextBlock(text="dynamic", transient=True),
                    ]
                ),
            ]
        )
        result = _apply(ext, req)
        # Non-transient prefix: ["stable"]; stops at "dynamic" (transient)
        assert result.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.system[0].blocks[1].extra.get("anthropic", {})


# -- Tool caching --


class TestCacheAllTools:
    def test_caches_last_tool(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_TOOLS
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra.get("anthropic", {})
        assert result.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_tools(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_TOOLS
        req = _request(tools=None)
        result = _apply(ext, req)
        assert result.tools is None

    def test_clears_old_cache(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_TOOLS
        req = _request(tools=[Tool(name="a", description="", extra=_CC), _tool("b")])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra.get("anthropic", {})
        assert result.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientTools:
    def test_caches_last_non_transient(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS
        req = _request(tools=[_tool("stable"), Tool(name="dynamic", description="", transient=True)])
        result = _apply(ext, req)
        assert result.tools is not None
        assert result.tools[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.tools[1].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra.get("anthropic", {})
        assert result.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_all_transient_no_cache(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS
        req = _request(tools=[Tool(name="a", description="", transient=True)])
        result = _apply(ext, req)
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra.get("anthropic", {})


# -- Message caching --


class TestCacheAllMessages:
    def test_caches_last_message_block(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_MESSAGES
        req = _request(messages=[_user("hello"), _assistant("hi")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra.get("anthropic", {})
        assert result.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_empty_messages(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_MESSAGES
        req = _request(messages=[])
        result = _apply(ext, req)
        assert result.messages == []

    def test_tool_use_block(self) -> None:
        ext = ANTHROPIC_CACHE_ALL_MESSAGES
        req = _request(
            messages=[
                AssistantMessage(blocks=[ToolUseBlock(id="1", name="t", input={})]),
            ]
        )
        result = _apply(ext, req)
        assert result.messages[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestCacheNonTransientMessages:
    def test_caches_last_non_transient(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES
        req = _request(messages=[_user("history"), _user("current", transient=True)])
        result = _apply(ext, req)
        assert result.messages[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert "cache_control" not in result.messages[1].blocks[0].extra.get("anthropic", {})

    def test_all_non_transient_caches_last(self) -> None:
        ext = ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES
        req = _request(messages=[_user("a"), _assistant("b")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra.get("anthropic", {})
        assert result.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


# -- History message caching --


class TestCacheHistoryMessages:
    def test_caches_history_breakpoint(self) -> None:
        ext = ANTHROPIC_CACHE_HISTORY_MESSAGES
        # Simulate: turn 1 messages saved with breakpoint marker
        turn1: list[UserMessage | AssistantMessage] = [_user("q1"), _assistant("a1")]
        event = _save_history_event(turn1)
        ext.on_save_history(event)
        marked = event.data.messages

        # Turn 2: history (marked) + new turn
        req = _request(messages=[marked[0], marked[1], _user("q2")])
        result = _apply(ext, req)

        # Breakpoint message (a1) cached
        assert result.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # New turn message NOT cached
        assert "cache_control" not in result.messages[2].blocks[0].extra.get("anthropic", {})

    def test_no_breakpoint_no_cache(self) -> None:
        ext = ANTHROPIC_CACHE_HISTORY_MESSAGES
        req = _request(messages=[_user("hello"), _assistant("hi")])
        result = _apply(ext, req)
        assert "cache_control" not in result.messages[0].blocks[0].extra.get("anthropic", {})
        assert "cache_control" not in result.messages[1].blocks[0].extra.get("anthropic", {})

    def test_breakpoint_moves_with_each_turn(self) -> None:
        ext = ANTHROPIC_CACHE_HISTORY_MESSAGES
        # Turn 1
        ev1 = _save_history_event([_user("q1"), _assistant("a1")])
        ext.on_save_history(ev1)
        marked1 = ev1.data.messages
        # Turn 2
        ev2 = _save_history_event([_user("q2"), _assistant("a2")])
        ext.on_save_history(ev2)
        marked2 = ev2.data.messages

        # Turn 3: history = marked1 + marked2, new turn = user
        req = _request(messages=[marked1[0], marked1[1], marked2[0], marked2[1], _user("q3")])
        result = _apply(ext, req)

        # Last breakpoint is on marked2's last message (a2)
        assert result.messages[3].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # marked1's last message NOT cached
        assert "cache_control" not in result.messages[1].blocks[0].extra.get("anthropic", {})
        # New turn NOT cached
        assert "cache_control" not in result.messages[4].blocks[0].extra.get("anthropic", {})


# -- Composite --


class TestAnthropicCacheSession:
    def test_caches_system_tools_and_history(self) -> None:
        ext = ANTHROPIC_CACHE_HISTORY_MESSAGES
        ev = _save_history_event([_user("q1"), _assistant("a1")])
        ext.on_save_history(ev)
        marked = ev.data.messages

        req = _request(
            system=[_sys("system")],
            messages=[marked[0], marked[1], _user("q2")],
            tools=[_tool("a")],
        )
        result = _apply_composite(ANTHROPIC_CACHE_SESSION, req)

        # System cached
        assert result.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # Tools cached
        assert result.tools is not None
        assert result.tools[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # History breakpoint cached
        assert result.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # New turn NOT cached
        assert "cache_control" not in result.messages[2].blocks[0].extra.get("anthropic", {})


class TestAnthropicCacheAll:
    def test_caches_system_tools_and_messages(self) -> None:
        req = _request(
            system=[_sys("system")],
            messages=[_user("hello"), _assistant("hi")],
            tools=[_tool("a"), _tool("b")],
        )
        result = _apply_composite(ANTHROPIC_CACHE_ALL, req)

        # System cached
        assert result.system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # Last tool cached
        assert result.tools is not None
        assert "cache_control" not in result.tools[0].extra.get("anthropic", {})
        assert result.tools[1].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        # Last message cached
        assert "cache_control" not in result.messages[0].blocks[0].extra.get("anthropic", {})
        assert result.messages[1].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}

    def test_mutates_extra_in_place(self) -> None:
        system = [_sys("system")]
        tools = [_tool("a")]
        req = _request(system=system, tools=tools)
        _apply_composite(ANTHROPIC_CACHE_ALL, req)
        assert system[0].blocks[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}
        assert tools[0].extra.get("anthropic", {}).get("cache_control") == {"type": "ephemeral"}


class TestInstall:
    def test_install_registers_hooks(self) -> None:
        hooks = HookSubscription()
        ANTHROPIC_CACHE_ALL.install(hooks)
        assert hooks.has_handlers(PrepareLLMRequestEvent)


# -- Tool search --


class TestToolSearch:
    def test_defers_all_tools_by_default(self) -> None:
        ext = AnthropicToolSearch()
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)

        assert result.tools is not None
        # Search tool added at the beginning
        assert result.tools[0].name == "tool_search_tool_bm25"
        assert result.tools[0].extra["anthropic"]["type"] == "tool_search_tool_bm25_20251119"
        # Original tools have defer_loading
        assert result.tools[1].extra.get("anthropic", {}).get("defer_loading") is True
        assert result.tools[2].extra.get("anthropic", {}).get("defer_loading") is True

    def test_regex_variant(self) -> None:
        ext = AnthropicToolSearch(variant=ToolSearchVariant.REGEX)
        req = _request(tools=[_tool("a")])
        result = _apply(ext, req)

        assert result.tools is not None
        assert result.tools[0].name == "tool_search_tool_regex"
        assert result.tools[0].extra["anthropic"]["type"] == "tool_search_tool_regex_20251119"

    def test_predicate_filters_tools(self) -> None:
        ext = AnthropicToolSearch(predicate=lambda t: t.name.startswith("admin_"))
        req = _request(tools=[_tool("search"), _tool("admin_delete"), _tool("admin_ban")])
        result = _apply(ext, req)

        assert result.tools is not None
        # Search tool added
        assert result.tools[0].name == "tool_search_tool_bm25"
        # Non-matching tool NOT deferred
        assert "defer_loading" not in result.tools[1].extra.get("anthropic", {})
        assert result.tools[1].name == "search"
        # Matching tools deferred
        assert result.tools[2].extra.get("anthropic", {}).get("defer_loading") is True
        assert result.tools[3].extra.get("anthropic", {}).get("defer_loading") is True

    def test_no_tools_noop(self) -> None:
        ext = AnthropicToolSearch()
        req = _request(tools=None)
        result = _apply(ext, req)
        assert result.tools is None

    def test_predicate_matches_nothing_noop(self) -> None:
        ext = AnthropicToolSearch(predicate=lambda t: False)
        req = _request(tools=[_tool("a"), _tool("b")])
        result = _apply(ext, req)

        # No tools deferred — no search tool added
        assert result.tools is not None
        assert len(result.tools) == 2
        assert result.tools[0].name == "a"

    def test_invalid_variant_raises(self) -> None:
        with pytest.raises((ValueError, KeyError)):
            AnthropicToolSearch(variant="unknown")  # type: ignore[arg-type]

    def test_preserves_existing_extra(self) -> None:
        ext = AnthropicToolSearch()
        tool = Tool(name="a", description="desc", extra={"custom": "value"})
        req = _request(tools=[tool])
        result = _apply(ext, req)

        assert result.tools is not None
        deferred = result.tools[1]
        assert deferred.extra["custom"] == "value"
        assert deferred.extra["anthropic"]["defer_loading"] is True


def _apply_composite(composite: Any, request: LLMRequest) -> LLMRequest:
    """Apply all extensions in a composite by simulating install + dispatch."""
    hooks = HookSubscription()
    composite.install(hooks)
    event = _prepare_event(request)
    handlers = hooks.get_handlers()
    for handler in handlers.get(PrepareLLMRequestEvent, []):
        handler(event)
    return event.data.request
