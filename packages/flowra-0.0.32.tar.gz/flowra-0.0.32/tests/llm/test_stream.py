from flowra.llm import (
    AssistantMessage,
    ContentComplete,
    LLMProvider,
    LLMRequest,
    LLMResponse,
    StopReason,
    TextBlock,
    UserMessage,
)


class TestDefaultStream:
    async def test_default_stream_yields_content_complete(self) -> None:
        """Default stream() implementation calls call() and yields ContentComplete."""

        class SimpleProvider(LLMProvider):
            async def call(self, request: LLMRequest) -> LLMResponse:
                return LLMResponse(
                    message=AssistantMessage(blocks=[TextBlock(text="hello")]),
                    stop_reason=StopReason.END_TURN,
                )

        provider = SimpleProvider()
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="hi")])],
        )

        events = []
        async for event in provider.stream(request):
            events.append(event)

        assert len(events) == 1
        assert isinstance(events[0], ContentComplete)
        assert events[0].response.stop_reason == StopReason.END_TURN
        assert events[0].response.message.blocks[0].text == "hello"  # type: ignore[union-attr]
