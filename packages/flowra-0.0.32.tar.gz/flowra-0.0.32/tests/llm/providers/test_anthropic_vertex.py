import base64
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from flowra.llm import ContentComplete, LLMRequest, MediaBlock, StopReason, TextBlock, ThinkingBlock, Tool, UserMessage
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider


def _make_anthropic_response(
    text: str = "hello",
    stop_reason: str = "end_turn",
    input_tokens: int = 10,
    output_tokens: int = 20,
) -> MagicMock:
    text_block = MagicMock()
    text_block.type = "text"
    text_block.text = text

    usage = MagicMock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens
    usage.cache_read_input_tokens = 0
    usage.cache_creation_input_tokens = 0
    cache_creation = MagicMock()
    cache_creation.ephemeral_5m_input_tokens = 0
    cache_creation.ephemeral_1h_input_tokens = 0
    usage.cache_creation = cache_creation
    usage.model_dump.return_value = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
    }

    response = MagicMock()
    response.content = [text_block]
    response.stop_reason = stop_reason
    response.stop_sequence = None
    response.usage = usage
    return response


@pytest.fixture
def mock_client() -> AsyncMock:
    client = AsyncMock()
    client.messages.create = AsyncMock(return_value=_make_anthropic_response())
    return client


@pytest.fixture
def provider(mock_client: AsyncMock) -> AnthropicVertexProvider:
    return AnthropicVertexProvider(client=mock_client)


class TestConstructorValidation:
    def test_no_args_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or all of"):
            AnthropicVertexProvider()

    def test_project_and_location_without_credentials_raises(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or all of"):
            AnthropicVertexProvider(project="x", location="y")


class TestToolNameValidation:
    async def test_invalid_tool_name_with_spaces(self, provider: AnthropicVertexProvider) -> None:
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="hi")])],
            tools=[Tool(name="invalid tool!", description="Bad name")],
        )
        with pytest.raises(ValueError, match="Tool name 'invalid tool!'"):
            await provider.call(request)

    async def test_empty_tool_name(self, provider: AnthropicVertexProvider) -> None:
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="hi")])],
            tools=[Tool(name="", description="Empty name")],
        )
        with pytest.raises(ValueError, match="Tool name ''"):
            await provider.call(request)

    async def test_tool_name_too_long(self, provider: AnthropicVertexProvider) -> None:
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="hi")])],
            tools=[Tool(name="a" * 129, description="Too long")],
        )
        with pytest.raises(ValueError, match="Tool name"):
            await provider.call(request)


class TestSchemaRetryLoop:
    async def test_retry_succeeds_after_first_failure(self, mock_client: AsyncMock) -> None:
        """First response fails schema validation, retry succeeds — returns valid response with accumulated usage."""
        provider = AnthropicVertexProvider(client=mock_client)

        invalid_response = _make_anthropic_response(text="not json", input_tokens=5, output_tokens=10)
        valid_response = _make_anthropic_response(text='{"name": "Alice"}', input_tokens=8, output_tokens=12)
        mock_client.messages.create = AsyncMock(side_effect=[invalid_response, valid_response])

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="give me json")])],
            json_schema=schema,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.END_TURN
        assert len(result.message.blocks) == 1
        assert isinstance(result.message.blocks[0], TextBlock)
        assert result.message.blocks[0].text == '{"name": "Alice"}'
        assert result.usage is not None
        assert result.usage.input_tokens == 5 + 8
        assert result.usage.output_tokens == 10 + 12

    async def test_all_retries_fail_returns_schema_validation_failed(self, mock_client: AsyncMock) -> None:
        """All retries fail — stop_reason is SCHEMA_VALIDATION_FAILED, usage accumulated."""
        provider = AnthropicVertexProvider(client=mock_client)

        invalid = _make_anthropic_response(text="bad json", input_tokens=5, output_tokens=10)
        mock_client.messages.create = AsyncMock(return_value=invalid)

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="give me json")])],
            json_schema=schema,
            max_schema_retries=2,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.SCHEMA_VALIDATION_FAILED
        # 1 initial call + 2 retries = 3 calls
        assert mock_client.messages.create.call_count == 3
        assert result.usage is not None
        assert result.usage.input_tokens == 5 * 3
        assert result.usage.output_tokens == 10 * 3

    async def test_strips_markdown_fences_from_valid_response(self, mock_client: AsyncMock) -> None:
        """LLM returns JSON wrapped in markdown fences — provider strips them and returns clean JSON."""
        provider = AnthropicVertexProvider(client=mock_client)

        fenced_response = _make_anthropic_response(text='```json\n{"name": "Alice"}\n```')
        mock_client.messages.create = AsyncMock(return_value=fenced_response)

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="give me json")])],
            json_schema=schema,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.END_TURN
        assert len(result.message.blocks) == 1
        assert isinstance(result.message.blocks[0], TextBlock)
        assert result.message.blocks[0].text == '{"name": "Alice"}'
        assert mock_client.messages.create.call_count == 1

    async def test_schema_response_returns_single_text_block(self, mock_client: AsyncMock) -> None:
        """Schema response strips thinking blocks and returns only a single TextBlock."""
        provider = AnthropicVertexProvider(client=mock_client)

        thinking_block = MagicMock()
        thinking_block.type = "thinking"
        thinking_block.thinking = "Let me think..."

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = '{"name": "Alice"}'

        response = _make_anthropic_response()
        response.content = [thinking_block, text_block]
        mock_client.messages.create = AsyncMock(return_value=response)

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="give me json")])],
            json_schema=schema,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.END_TURN
        assert len(result.message.blocks) == 1
        assert isinstance(result.message.blocks[0], TextBlock)
        assert result.message.blocks[0].text == '{"name": "Alice"}'

    async def test_retry_short_circuits_on_max_tokens(self, mock_client: AsyncMock) -> None:
        """Retry response has MAX_TOKENS stop_reason — short-circuits and returns immediately."""
        provider = AnthropicVertexProvider(client=mock_client)

        invalid_response = _make_anthropic_response(text="bad", input_tokens=5, output_tokens=10)
        max_tokens_response = _make_anthropic_response(
            text="truncated", stop_reason="max_tokens", input_tokens=8, output_tokens=12
        )
        mock_client.messages.create = AsyncMock(side_effect=[invalid_response, max_tokens_response])

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="give me json")])],
            json_schema=schema,
            max_schema_retries=3,
        )
        result = await provider.call(request)

        assert result.stop_reason == StopReason.MAX_TOKENS
        assert mock_client.messages.create.call_count == 2
        assert result.usage is not None
        assert result.usage.input_tokens == 5 + 8


class TestThinkingSupport:
    async def test_thinking_block_in_response(self, mock_client: AsyncMock) -> None:
        """Thinking blocks from Anthropic response are converted to ThinkingBlock."""
        thinking_block = MagicMock()
        thinking_block.type = "thinking"
        thinking_block.thinking = "Let me think..."

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "The answer is 42"

        response = _make_anthropic_response()
        response.content = [thinking_block, text_block]
        mock_client.messages.create = AsyncMock(return_value=response)

        provider = AnthropicVertexProvider(client=mock_client)
        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
            )
        )

        assert len(result.message.blocks) == 2
        assert isinstance(result.message.blocks[0], ThinkingBlock)
        assert result.message.blocks[0].text == "Let me think..."
        assert isinstance(result.message.blocks[1], TextBlock)
        assert result.message.blocks[1].text == "The answer is 42"

    async def test_thinking_budget_tokens_config(self, mock_client: AsyncMock) -> None:
        """additional_config with thinking_budget_tokens passes thinking params to API."""
        mock_client.messages.create = AsyncMock(return_value=_make_anthropic_response())
        provider = AnthropicVertexProvider(client=mock_client)

        await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="think about this")])],
                additional_config={"thinking_budget_tokens": 5000},
                temperature=0.5,  # should be overridden to 1
            )
        )

        call_kwargs = mock_client.messages.create.call_args.kwargs
        assert call_kwargs["thinking"] == {"type": "enabled", "budget_tokens": 5000}
        assert call_kwargs["temperature"] == 1  # forced by thinking


class TestMediaBlockConversion:
    async def test_image_block_converted_to_base64_source(
        self, provider: AnthropicVertexProvider, mock_client: AsyncMock
    ) -> None:
        """MediaBlock in UserMessage is converted to Anthropic base64 image format."""
        image_data = b"\x89PNG\r\n\x1a\n"
        request = LLMRequest(
            model="test",
            messages=[
                UserMessage(
                    blocks=[
                        MediaBlock(data=image_data, media_type="image/png"),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.messages.create.call_args.kwargs
        messages = call_kwargs["messages"]
        assert len(messages) == 1
        content = messages[0]["content"]
        assert len(content) == 1
        img = content[0]
        assert img["type"] == "image"
        assert img["source"]["type"] == "base64"
        assert img["source"]["media_type"] == "image/png"
        assert img["source"]["data"] == base64.b64encode(image_data).decode()
        assert "cache_control" not in img

    async def test_image_block_with_extra(self, provider: AnthropicVertexProvider, mock_client: AsyncMock) -> None:
        """MediaBlock with cache_control in extra includes cache_control."""
        image_data = b"\x89PNG\r\n\x1a\n"
        request = LLMRequest(
            model="test",
            messages=[
                UserMessage(
                    blocks=[
                        MediaBlock(
                            data=image_data,
                            media_type="image/png",
                            extra={"anthropic": {"cache_control": {"type": "ephemeral"}}},
                        ),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_client.messages.create.call_args.kwargs
        img = call_kwargs["messages"][0]["content"][0]
        assert img["cache_control"] == {"type": "ephemeral"}


class TestStreamFallback:
    async def test_json_schema_falls_back_to_call(self, mock_client: AsyncMock) -> None:
        """When json_schema is set, stream() falls back to non-streaming."""
        mock_client.messages.create = AsyncMock(return_value=_make_anthropic_response(text='{"name": "Alice"}'))
        provider = AnthropicVertexProvider(client=mock_client)

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json")])],
            json_schema=schema,
        )

        events = []
        async for event in provider.stream(request):
            events.append(event)

        assert len(events) == 1
        assert isinstance(events[0], ContentComplete)
