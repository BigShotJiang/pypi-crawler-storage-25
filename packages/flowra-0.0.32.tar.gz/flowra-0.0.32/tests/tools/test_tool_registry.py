import dataclasses
import logging
from unittest.mock import MagicMock, patch

import pytest

from flowra.tools import LocalToolGroup, McpToolGroup, ToolDefinition, ToolRegistry, ToolResult, get_local_tool, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Params:
    q: str


@tool("search")
def search_tool(params: Params) -> str:
    """Search."""
    return params.q


@tool("ping")
def ping_tool() -> str:
    """Ping."""
    return "pong"


@tool("dup")
def dup_tool() -> str:
    """Dup."""
    return "dup"


def _mcp_tool(name: str, description: str = "desc") -> ToolDefinition:
    return ToolDefinition(name=name, description=description, input_schema=None, output_schema=None)


def _mock_connection(
    tools: list[ToolDefinition],
    call_tool_result: ToolResult | None = None,
) -> MagicMock:
    conn = MagicMock()
    conn.get_tools.return_value = tools
    conn.close_called = False
    conn._callbacks = {}
    conn._next_token = 0

    async def _close() -> None:
        conn.close_called = True

    async def _call_tool(name: str, arguments: object = None) -> ToolResult:
        if call_tool_result is not None:
            return call_tool_result
        return ToolResult(content=f"mcp:{name}", is_error=False)

    def _add_on_tools_changed(callback: object) -> int:
        token = conn._next_token
        conn._next_token += 1
        conn._callbacks[token] = callback
        return token

    def _remove_on_tools_changed(token: int) -> None:
        conn._callbacks.pop(token, None)

    def _fire_tools_changed() -> None:
        for cb in conn._callbacks.values():
            cb()

    conn.close = _close
    conn.call_tool = _call_tool
    conn.add_on_tools_changed = _add_on_tools_changed
    conn.remove_on_tools_changed = _remove_on_tools_changed
    conn.fire_tools_changed = _fire_tools_changed
    return conn


async def _create_with_mock_mcp(
    sources: list,  # pyright: ignore[reportMissingTypeArgument]
    mcp_connections: dict[str, MagicMock] | None = None,
) -> ToolRegistry:
    """Create ToolRegistry, patching McpConnection.connect for any McpToolGroups."""
    mcp_connections = mcp_connections or {}

    async def fake_connect(url: str, headers: object = None) -> MagicMock:
        conn = mcp_connections.get(url)
        if conn is None:
            raise ValueError(f"No mock connection for url={url}")
        return conn

    with patch("flowra.tools.tool_registry.McpConnection.connect", side_effect=fake_connect):
        return await ToolRegistry.create(sources)


# -- Local tools ---------------------------------------------------------------


class TestLocalTools:
    async def test_no_prefix(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(search_tool), get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            assert [t.name for t in registry.get_tools()] == ["search", "ping"]

    async def test_with_prefix(self) -> None:
        group = LocalToolGroup(prefix="grp", tools=[get_local_tool(search_tool)])
        async with await ToolRegistry.create([group]) as registry:
            assert registry.get_tools()[0].name == "grp__search"

    async def test_duplicate_raises(self) -> None:
        g1 = LocalToolGroup(tools=[get_local_tool(search_tool)])
        g2 = LocalToolGroup(tools=[get_local_tool(search_tool)])
        with pytest.raises(ValueError, match="Duplicate local tool name"):
            await ToolRegistry.create([g1, g2])

    async def test_same_name_different_prefix_ok(self) -> None:
        g1 = LocalToolGroup(prefix="a", tools=[get_local_tool(search_tool)])
        g2 = LocalToolGroup(prefix="b", tools=[get_local_tool(search_tool)])
        async with await ToolRegistry.create([g1, g2]) as registry:
            assert [t.name for t in registry.get_tools()] == ["a__search", "b__search"]

    async def test_bare_local_tool_as_source(self) -> None:
        lt = get_local_tool(search_tool)
        async with await ToolRegistry.create([lt]) as registry:
            assert [t.name for t in registry.get_tools()] == ["search"]

    async def test_bare_local_tool_duplicate_with_group_raises(self) -> None:
        lt = get_local_tool(search_tool)
        group = LocalToolGroup(tools=[get_local_tool(search_tool)])
        with pytest.raises(ValueError, match="Duplicate local tool name"):
            await ToolRegistry.create([lt, group])

    async def test_tool_definition_fields(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(search_tool)])
        async with await ToolRegistry.create([group]) as registry:
            td = registry.get_tools()[0]
            assert td.name == "search"
            assert td.description == "Search."
            assert td.input_schema is not None
            assert "q" in td.input_schema["properties"]


# -- get_llm_tools -------------------------------------------------------------


class TestGetLlmTools:
    async def test_converts_to_llm_tools(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(search_tool), get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            llm_tools = registry.get_llm_tools()
            assert len(llm_tools) == 2
            assert llm_tools[0].name == "search"
            assert llm_tools[0].description == "Search."
            search_schema = llm_tools[0].input_schema
            assert search_schema is not None
            assert "q" in search_schema["properties"]
            assert llm_tools[1].name == "ping"

    async def test_preserves_output_schema(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class Result:
            value: str

        @tool("with_output")
        def with_output(params: Params) -> Result:
            """Has output schema."""
            return Result(value=str(params.q))

        group = LocalToolGroup(tools=[get_local_tool(with_output)])
        async with await ToolRegistry.create([group]) as registry:
            llm_tools = registry.get_llm_tools()
            assert llm_tools[0].output_schema is not None
            assert "value" in llm_tools[0].output_schema["properties"]

    async def test_output_schema_none_for_non_dataclass_return(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            llm_tools = registry.get_llm_tools()
            assert llm_tools[0].output_schema is None

    async def test_with_prefix(self) -> None:
        group = LocalToolGroup(prefix="grp", tools=[get_local_tool(search_tool)])
        async with await ToolRegistry.create([group]) as registry:
            llm_tools = registry.get_llm_tools()
            assert llm_tools[0].name == "grp__search"


# -- Order preservation --------------------------------------------------------


class TestOrder:
    async def test_order_matches_input(self) -> None:
        g1 = LocalToolGroup(prefix="a", tools=[get_local_tool(ping_tool)])
        g2 = LocalToolGroup(prefix="b", tools=[get_local_tool(search_tool)])
        g3 = LocalToolGroup(prefix="c", tools=[get_local_tool(dup_tool)])
        async with await ToolRegistry.create([g1, g2, g3]) as registry:
            assert [t.name for t in registry.get_tools()] == ["a__ping", "b__search", "c__dup"]

    async def test_order_reversed(self) -> None:
        g1 = LocalToolGroup(prefix="c", tools=[get_local_tool(dup_tool)])
        g2 = LocalToolGroup(prefix="b", tools=[get_local_tool(search_tool)])
        g3 = LocalToolGroup(prefix="a", tools=[get_local_tool(ping_tool)])
        async with await ToolRegistry.create([g1, g2, g3]) as registry:
            assert [t.name for t in registry.get_tools()] == ["c__dup", "b__search", "a__ping"]

    async def test_mixed_local_and_mcp_order(self) -> None:
        local = LocalToolGroup(prefix="local", tools=[get_local_tool(ping_tool)])
        mcp_group = McpToolGroup(prefix="mcp", url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp(
            [local, mcp_group], mcp_connections={"http://fake": mock_conn}
        ) as registry:
            assert [t.name for t in registry.get_tools()] == ["local__ping", "mcp__fetch"]


# -- MCP duplicates ------------------------------------------------------------


class TestMcpDuplicates:
    async def test_mcp_duplicate_with_local_ignored(self, caplog: pytest.LogCaptureFixture) -> None:
        local = LocalToolGroup(tools=[get_local_tool(search_tool)])
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("search")])

        with caplog.at_level(logging.ERROR):
            async with await _create_with_mock_mcp(
                [local, mcp_group], mcp_connections={"http://fake": mock_conn}
            ) as registry:
                tools = registry.get_tools()
                assert len(tools) == 1
                assert tools[0].name == "search"
                assert "already exists" in caplog.text

    async def test_mcp_duplicate_with_mcp_ignored(self, caplog: pytest.LogCaptureFixture) -> None:
        mcp1 = McpToolGroup(url="http://fake1")
        mcp2 = McpToolGroup(url="http://fake2")
        mock_conn1 = _mock_connection([_mcp_tool("fetch")])
        mock_conn2 = _mock_connection([_mcp_tool("fetch")])

        with caplog.at_level(logging.ERROR):
            async with await _create_with_mock_mcp(
                [mcp1, mcp2],
                mcp_connections={"http://fake1": mock_conn1, "http://fake2": mock_conn2},
            ) as registry:
                tools = registry.get_tools()
                assert len(tools) == 1
                assert "already exists" in caplog.text

    async def test_mcp_different_prefixes_no_conflict(self) -> None:
        mcp1 = McpToolGroup(prefix="a", url="http://fake1")
        mcp2 = McpToolGroup(prefix="b", url="http://fake2")
        mock_conn1 = _mock_connection([_mcp_tool("fetch")])
        mock_conn2 = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp(
            [mcp1, mcp2],
            mcp_connections={"http://fake1": mock_conn1, "http://fake2": mock_conn2},
        ) as registry:
            assert [t.name for t in registry.get_tools()] == ["a__fetch", "b__fetch"]

    async def test_mcp_same_prefix_different_tools(self) -> None:
        """Two MCP servers with same prefix provide different tools - all should be registered."""
        mcp1 = McpToolGroup(prefix="ai", url="http://fake1")
        mcp2 = McpToolGroup(prefix="ai", url="http://fake2")
        mock_conn1 = _mock_connection([_mcp_tool("search"), _mcp_tool("summarize")])
        mock_conn2 = _mock_connection([_mcp_tool("translate")])

        async with await _create_with_mock_mcp(
            [mcp1, mcp2],
            mcp_connections={"http://fake1": mock_conn1, "http://fake2": mock_conn2},
        ) as registry:
            tools = sorted([t.name for t in registry.get_tools()])
            assert tools == ["ai__search", "ai__summarize", "ai__translate"]

    async def test_mcp_same_prefix_duplicate_tools(self, caplog: pytest.LogCaptureFixture) -> None:
        """Two MCP servers with same prefix provide duplicate tools - first wins."""
        mcp1 = McpToolGroup(prefix="ai", url="http://fake1")
        mcp2 = McpToolGroup(prefix="ai", url="http://fake2")
        mock_conn1 = _mock_connection([_mcp_tool("search")])
        mock_conn2 = _mock_connection([_mcp_tool("search"), _mcp_tool("translate")])

        with caplog.at_level(logging.ERROR):
            async with await _create_with_mock_mcp(
                [mcp1, mcp2],
                mcp_connections={"http://fake1": mock_conn1, "http://fake2": mock_conn2},
            ) as registry:
                tools = sorted([t.name for t in registry.get_tools()])
                assert tools == ["ai__search", "ai__translate"]
                assert "already exists" in caplog.text


# -- MCP callback --------------------------------------------------------------


class TestMcpCallback:
    async def test_callback_rebuilds_registry(self) -> None:
        mcp_group = McpToolGroup(prefix="mcp", url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn}) as registry:
            assert [t.name for t in registry.get_tools()] == ["mcp__fetch"]

            # Simulate MCP tools change
            mock_conn.get_tools.return_value = [_mcp_tool("fetch"), _mcp_tool("submit")]
            mock_conn.fire_tools_changed()

            assert [t.name for t in registry.get_tools()] == ["mcp__fetch", "mcp__submit"]

    async def test_callback_new_duplicate_ignored(self, caplog: pytest.LogCaptureFixture) -> None:
        local = LocalToolGroup(tools=[get_local_tool(ping_tool)])
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp(
            [local, mcp_group], mcp_connections={"http://fake": mock_conn}
        ) as registry:
            assert [t.name for t in registry.get_tools()] == ["ping", "fetch"]

            # MCP adds a tool that conflicts with local
            mock_conn.get_tools.return_value = [_mcp_tool("fetch"), _mcp_tool("ping")]
            with caplog.at_level(logging.ERROR):
                mock_conn.fire_tools_changed()

            assert [t.name for t in registry.get_tools()] == ["ping", "fetch"]
            assert "already exists" in caplog.text


# -- Context manager -----------------------------------------------------------


class TestContextManager:
    async def test_close_called(self) -> None:
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        registry = await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn})
        await registry.close()
        assert mock_conn.close_called

    async def test_async_with(self) -> None:
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn}):
            pass
        assert mock_conn.close_called


# -- Execute -------------------------------------------------------------------


class TestExecute:
    async def test_local_tool(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(search_tool)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("search", {"q": "hello"})
            assert result.content == "hello"
            assert result.is_error is False

    async def test_local_tool_no_args(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("ping")
            assert result.content == "pong"

    async def test_local_tool_with_prefix(self) -> None:
        group = LocalToolGroup(prefix="grp", tools=[get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("grp__ping")
            assert result.content == "pong"

    async def test_unknown_tool(self) -> None:
        group = LocalToolGroup(tools=[get_local_tool(ping_tool)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("nonexistent")
            assert result.is_error is True
            assert "Unknown tool" in result.content

    async def test_local_tool_error(self) -> None:
        @tool("failing")
        def failing() -> str:
            """Fail."""
            raise RuntimeError("boom")

        group = LocalToolGroup(tools=[get_local_tool(failing)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("failing")
            assert result.is_error is True
            assert "boom" in result.content

    async def test_mcp_tool(self) -> None:
        mcp_group = McpToolGroup(prefix="mcp", url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        async with await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn}) as registry:
            result = await registry.execute("mcp__fetch", {"url": "http://example.com"})
            assert result.content == "mcp:fetch"
            assert result.is_error is False

    async def test_mcp_tool_error(self) -> None:
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection(
            [_mcp_tool("fetch")],
            call_tool_result=ToolResult(content="bad request", is_error=True),
        )

        async with await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn}) as registry:
            result = await registry.execute("fetch")
            assert result.content == "bad request"
            assert result.is_error is True

    async def test_local_tool_with_services(self) -> None:
        class MyService:
            def __init__(self, prefix: str) -> None:
                self.prefix = prefix

        @tool("greet")
        def greet(svc: MyService) -> str:
            """Greet."""
            return svc.prefix

        group = LocalToolGroup(tools=[get_local_tool(greet)])
        async with await ToolRegistry.create([group]) as registry:
            result = await registry.execute("greet", services={MyService: MyService("hi")})
            assert result.content == "hi"

    async def test_callbacks_removed_on_close(self) -> None:
        mcp_group = McpToolGroup(url="http://fake")
        mock_conn = _mock_connection([_mcp_tool("fetch")])

        registry = await _create_with_mock_mcp([mcp_group], mcp_connections={"http://fake": mock_conn})
        assert len(mock_conn._callbacks) == 1

        await registry.close()
        assert len(mock_conn._callbacks) == 0
