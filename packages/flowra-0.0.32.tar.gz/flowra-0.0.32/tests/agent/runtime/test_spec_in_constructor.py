import dataclasses
from typing import Annotated, ClassVar

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    CallAgent,
    GotoAgent,
    ServiceLocator,
    Spawn,
    step,
    step_arg,
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MySpec:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyResult:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChildResult:
    from_child: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class OtherSpec:
    data: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class OtherResult:
    data: str


# A service type used for provide pattern tests
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CustomConfig:
    setting: str


class TestSpecInConstructor:
    async def test_spec_in_constructor_by_type(self) -> None:
        """Agent[MySpec, MyResult] with __init__(self, spec: MySpec) receives spec."""

        class MyAgent(Agent[MySpec, MyResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: MySpec) -> None:
                self.__spec = spec

            @step(entry=True)
            def run(self) -> MyResult:
                return MyResult(value=self.__spec.value)

        runtime = AgentRuntime(agents={"a": MyAgent})
        result = await runtime.run(agent="a", spec=MySpec(value="hello"))
        assert isinstance(result, MyResult)
        assert result.value == "hello"

    async def test_no_spec_agent_works_as_before(self) -> None:
        """Agent without spec in constructor still works."""

        class NoSpecAgent(Agent[MySpec, MyResult]):
            @step(entry=True)
            def run(self, spec: MySpec) -> MyResult:
                return MyResult(value=spec.value)

        runtime = AgentRuntime(agents={"a": NoSpecAgent})
        result = await runtime.run(agent="a", spec=MySpec(value="works"))
        assert isinstance(result, MyResult)
        assert result.value == "works"

    async def test_spec_and_provide_pattern(self) -> None:
        """Agent receives spec, overrides a service, child sees override."""

        class Child(Agent[OtherSpec, ChildResult]):
            __slots__ = ("__config",)

            def __init__(self, config: CustomConfig) -> None:
                self.__config = config

            @step(entry=True)
            def run(self) -> ChildResult:
                return ChildResult(from_child=self.__config.setting)

        class Parent(Agent[MySpec, MyResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"child": Child}
            __slots__ = ("__spec",)

            def __init__(self, spec: MySpec, sl: ServiceLocator) -> None:
                self.__spec = spec
                sl.provide(CustomConfig(setting=f"from-{spec.value}"))

            @step(entry=True)
            def start(self) -> Spawn:
                return Spawn(
                    CallAgent(agent=Child, spec=OtherSpec(data="x"), tag="c"),
                    then=self.finish,
                )

            @step
            def finish(self, child: Annotated[ChildResult, step_arg.CHILD("c")]) -> MyResult:
                return MyResult(value=child.from_child)

        runtime = AgentRuntime(agents={"p": Parent})
        result = await runtime.run(agent="p", spec=MySpec(value="parent"))
        assert isinstance(result, MyResult)
        assert result.value == "from-parent"

    async def test_spec_does_not_leak_to_child_agent(self) -> None:
        """Child agent of different type does NOT receive parent's spec."""

        class Child(Agent[OtherSpec, OtherResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: OtherSpec) -> None:
                self.__spec = spec

            @step(entry=True)
            def run(self) -> OtherResult:
                return OtherResult(data=self.__spec.data)

        class Parent(Agent[MySpec, MyResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"child": Child}
            __slots__ = ("__spec",)

            def __init__(self, spec: MySpec) -> None:
                self.__spec = spec

            @step(entry=True)
            def start(self) -> Spawn:
                return Spawn(
                    CallAgent(agent=Child, spec=OtherSpec(data="child-data"), tag="c"),
                    then=self.finish,
                )

            @step
            def finish(self, child: Annotated[OtherResult, step_arg.CHILD("c")]) -> MyResult:
                return MyResult(value=child.data)

        runtime = AgentRuntime(agents={"p": Parent})
        result = await runtime.run(agent="p", spec=MySpec(value="parent"))
        assert isinstance(result, MyResult)
        assert result.value == "child-data"

    async def test_nullable_spec_param(self) -> None:
        """spec: MySpec | None = None gets spec when provided, None otherwise."""

        class MyAgent(Agent[MySpec, MyResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: MySpec | None = None) -> None:
                self.__spec = spec

            @step(entry=True)
            def run(self) -> MyResult:
                if self.__spec is not None:
                    return MyResult(value=self.__spec.value)
                return MyResult(value="no-spec")

        runtime = AgentRuntime(agents={"a": MyAgent})
        result = await runtime.run(agent="a", spec=MySpec(value="given"))
        assert isinstance(result, MyResult)
        assert result.value == "given"

    async def test_goto_agent_with_new_spec(self) -> None:
        """New agent's constructor gets the new spec from GotoAgent."""

        class Second(Agent[OtherSpec, OtherResult]):
            __slots__ = ("__spec",)

            def __init__(self, spec: OtherSpec) -> None:
                self.__spec = spec

            @step(entry=True)
            def run(self) -> OtherResult:
                return OtherResult(data=self.__spec.data)

        class First(Agent[MySpec, OtherResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"second": Second}

            @step(entry=True)
            def run(self, spec: MySpec) -> GotoAgent:
                return GotoAgent(agent=Second, spec=OtherSpec(data=f"from-{spec.value}"))

        runtime = AgentRuntime(agents={"first": First})
        result = await runtime.run(agent="first", spec=MySpec(value="first"))
        assert isinstance(result, OtherResult)
        assert result.data == "from-first"
