"""Tests for span-hooks mechanism."""

import dataclasses

import pytest

from flowra.agent.flow.context import AgentInfo, ExecutionContext, ExecutionFrame
from flowra.agent.flow.hooks import Event, HookEmitter, HookSubscription, SpanExitHandler


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleSpan:
    value: int
    result: str | None = None


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherSpan:
    name: str


def _make_context() -> ExecutionContext:
    agent = AgentInfo(name="test", path="test", source_type=None, parent=None)
    frame = ExecutionFrame(agent=agent, spec=None, tag=None)
    return ExecutionContext(frame=frame, stack=(frame,))


def _emitter(sub: HookSubscription) -> HookEmitter:
    return HookEmitter(sub.get_handlers(), _make_context(), span_handlers=sub.get_span_handlers())


class TestSpanRegistration:
    def test_has_span_handlers_empty(self) -> None:
        sub = HookSubscription()
        assert not sub.has_span_handlers(SampleSpan)

    def test_has_span_handlers_after_registration(self) -> None:
        sub = HookSubscription()
        sub.on_span(SampleSpan, lambda _: None)
        assert sub.has_span_handlers(SampleSpan)
        assert not sub.has_span_handlers(OtherSpan)

    def test_emitter_has_span_handlers(self) -> None:
        sub = HookSubscription()
        sub.on_span(SampleSpan, lambda _: None)
        emitter = _emitter(sub)
        assert emitter.has_span_handlers(SampleSpan)
        assert not emitter.has_span_handlers(OtherSpan)


class TestOpenCloseSpan:
    async def test_open_returns_span(self) -> None:
        sub = HookSubscription()
        emitter = _emitter(sub)
        span = await emitter.open_span(SampleSpan(value=42))
        assert span.value == 42
        assert span.result is None

    async def test_close_calls_exit_handlers(self) -> None:
        calls: list[str] = []

        def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            span = event.data
            calls.append(f"enter:{span.value}")

            def on_end(error: BaseException | None = None) -> None:
                calls.append(f"exit:{span.value}:result={span.result}")

            return on_end

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=7))
        assert calls == ["enter:7"]
        span.result = "ok"
        await emitter.close_span(span)
        assert calls == ["enter:7", "exit:7:result=ok"]

    async def test_async_enter_exit_handlers(self) -> None:
        calls: list[str] = []

        async def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            span = event.data
            calls.append("async_enter")

            async def on_end(error: BaseException | None = None) -> None:
                calls.append(f"async_exit:result={span.result}")

            return on_end

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        assert calls == ["async_enter"]
        span.result = "yes"
        await emitter.close_span(span)
        assert calls == ["async_enter", "async_exit:result=yes"]

    async def test_enter_returns_none_no_exit(self) -> None:
        sub = HookSubscription()
        sub.on_span(SampleSpan, lambda _: None)
        emitter = _emitter(sub)
        span = await emitter.open_span(SampleSpan(value=1))
        await emitter.close_span(span)  # should not crash

    async def test_close_passes_error_to_exit_handler(self) -> None:
        received_error: list[BaseException | None] = []

        def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            def on_end(error: BaseException | None = None) -> None:
                received_error.append(error)

            return on_end

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        err = ValueError("boom")
        await emitter.close_span(span, error=err)
        assert received_error == [err]

    async def test_close_no_error_passes_none(self) -> None:
        received_error: list[BaseException | None] = []

        def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            return lambda error=None: received_error.append(error)

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        await emitter.close_span(span)
        assert received_error == [None]

    async def test_event_contains_context(self) -> None:
        """Span enter handler receives Event with execution context."""
        received_contexts: list[ExecutionContext] = []

        def handler(event: Event[SampleSpan]) -> None:
            received_contexts.append(event.context)

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        await emitter.open_span(SampleSpan(value=1))
        assert len(received_contexts) == 1
        assert received_contexts[0].frame.agent.name == "test"


class TestSpanNesting:
    async def test_later_subscriber_is_outer(self) -> None:
        """B registered after A → B.enter → A.enter → A.exit → B.exit."""
        calls: list[str] = []

        def handler_a(event: Event[SampleSpan]) -> SpanExitHandler:
            calls.append("A.enter")
            return lambda error=None: calls.append("A.exit")

        def handler_b(event: Event[SampleSpan]) -> SpanExitHandler:
            calls.append("B.enter")
            return lambda error=None: calls.append("B.exit")

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler_a)
        sub.on_span(SampleSpan, handler_b)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        assert calls == ["B.enter", "A.enter"]

        await emitter.close_span(span)
        assert calls == ["B.enter", "A.enter", "A.exit", "B.exit"]


class TestSpanContextManager:
    async def test_normal_flow(self) -> None:
        calls: list[str] = []

        def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            span = event.data
            calls.append("enter")
            return lambda error=None: calls.append(f"exit:result={span.result}")

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        async with emitter.span(SampleSpan(value=1)) as span:
            span.result = "hello"

        assert calls == ["enter", "exit:result=hello"]

    async def test_exception_closes_span(self) -> None:
        received_errors: list[BaseException | None] = []

        def handler(event: Event[SampleSpan]) -> SpanExitHandler:
            return lambda error=None: received_errors.append(error)

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler)
        emitter = _emitter(sub)

        with pytest.raises(ValueError, match="boom"):
            async with emitter.span(SampleSpan(value=1)):
                raise ValueError("boom")

        assert len(received_errors) == 1
        assert isinstance(received_errors[0], ValueError)


class TestSpanErrorSafety:
    async def test_enter_handler_exception_does_not_break(self) -> None:
        calls: list[str] = []

        def good_handler(event: Event[SampleSpan]) -> SpanExitHandler:
            calls.append("good_enter")
            return lambda error=None: calls.append("good_exit")

        def bad_handler(event: Event[SampleSpan]) -> SpanExitHandler:
            raise RuntimeError("bad enter")

        sub = HookSubscription()
        sub.on_span(SampleSpan, good_handler)
        sub.on_span(SampleSpan, bad_handler)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        assert calls == ["good_enter"]
        await emitter.close_span(span)
        assert calls == ["good_enter", "good_exit"]

    async def test_exit_handler_exception_does_not_break(self) -> None:
        calls: list[str] = []

        def handler_a(event: Event[SampleSpan]) -> SpanExitHandler:
            calls.append("A.enter")
            return lambda error=None: calls.append("A.exit")

        def handler_b(event: Event[SampleSpan]) -> SpanExitHandler:
            calls.append("B.enter")

            def exit_b(error: BaseException | None = None) -> None:
                raise RuntimeError("bad exit")

            return exit_b

        sub = HookSubscription()
        sub.on_span(SampleSpan, handler_a)
        sub.on_span(SampleSpan, handler_b)
        emitter = _emitter(sub)

        span = await emitter.open_span(SampleSpan(value=1))
        await emitter.close_span(span)
        assert calls == ["B.enter", "A.enter", "A.exit"]


class TestSpanTypeSeparation:
    async def test_different_span_types(self) -> None:
        sample_calls: list[str] = []
        other_calls: list[str] = []

        sub = HookSubscription()
        sub.on_span(SampleSpan, lambda _: sample_calls.append("sample"))
        sub.on_span(OtherSpan, lambda _: other_calls.append("other"))
        emitter = _emitter(sub)

        await emitter.open_span(SampleSpan(value=1))
        assert sample_calls == ["sample"]
        assert other_calls == []

        await emitter.open_span(OtherSpan(name="x"))
        assert other_calls == ["other"]


class TestSpanPropagation:
    async def test_basic_forwarding(self) -> None:
        """Span opened on source emitter triggers span open on target emitter."""
        target_calls: list[str] = []

        def target_handler(event: Event[SampleSpan]) -> None:
            target_calls.append(f"enter:{event.data.value}")

        source_sub = HookSubscription()
        target_sub = HookSubscription()

        # Source must have a span handler registered so propagate_to sees the type
        source_sub.on_span(SampleSpan, lambda _: None)
        target_sub.on_span(SampleSpan, target_handler)

        context = _make_context()
        source_emitter = HookEmitter(source_sub.get_handlers(), context, span_handlers=source_sub.get_span_handlers())
        target_emitter = HookEmitter(target_sub.get_handlers(), context, span_handlers=target_sub.get_span_handlers())

        source_emitter.propagate_to(target_emitter)

        await source_emitter.open_span(SampleSpan(value=1))
        assert target_calls == ["enter:1"]

    async def test_close_forwarding(self) -> None:
        """Target's exit handler is called when source span closes."""
        target_calls: list[str] = []

        def target_handler(event: Event[SampleSpan]) -> SpanExitHandler:
            span = event.data
            target_calls.append(f"enter:{span.value}")

            def on_end(error: BaseException | None = None) -> None:
                target_calls.append(f"exit:{span.value}:result={span.result}")

            return on_end

        source_sub = HookSubscription()
        target_sub = HookSubscription()

        source_sub.on_span(SampleSpan, lambda _: None)
        target_sub.on_span(SampleSpan, target_handler)

        context = _make_context()
        source_emitter = HookEmitter(source_sub.get_handlers(), context, span_handlers=source_sub.get_span_handlers())
        target_emitter = HookEmitter(target_sub.get_handlers(), context, span_handlers=target_sub.get_span_handlers())

        source_emitter.propagate_to(target_emitter)

        span = await source_emitter.open_span(SampleSpan(value=5))
        assert target_calls == ["enter:5"]

        span.result = "done"
        await source_emitter.close_span(span)
        assert target_calls == ["enter:5", "exit:5:result=done"]

    async def test_error_forwarding(self) -> None:
        """Error argument reaches target's exit handler."""
        received_errors: list[BaseException | None] = []

        def target_handler(event: Event[SampleSpan]) -> SpanExitHandler:
            def on_end(error: BaseException | None = None) -> None:
                received_errors.append(error)

            return on_end

        source_sub = HookSubscription()
        target_sub = HookSubscription()

        source_sub.on_span(SampleSpan, lambda _: None)
        target_sub.on_span(SampleSpan, target_handler)

        context = _make_context()
        source_emitter = HookEmitter(source_sub.get_handlers(), context, span_handlers=source_sub.get_span_handlers())
        target_emitter = HookEmitter(target_sub.get_handlers(), context, span_handlers=target_sub.get_span_handlers())

        source_emitter.propagate_to(target_emitter)

        span = await source_emitter.open_span(SampleSpan(value=1))
        err = ValueError("boom")
        await source_emitter.close_span(span, error=err)
        assert received_errors == [err]

    async def test_only_filter(self) -> None:
        """Only specified span types are forwarded."""
        sample_calls: list[str] = []
        other_calls: list[str] = []

        def sample_handler(event: Event[SampleSpan]) -> None:
            sample_calls.append(f"enter:{event.data.value}")

        def other_handler(event: Event[OtherSpan]) -> None:
            other_calls.append(f"enter:{event.data.name}")

        source_sub = HookSubscription()
        target_sub = HookSubscription()

        # Register handlers on source so propagate_to sees the span types
        source_sub.on_span(SampleSpan, lambda _: None)
        source_sub.on_span(OtherSpan, lambda _: None)

        target_sub.on_span(SampleSpan, sample_handler)
        target_sub.on_span(OtherSpan, other_handler)

        context = _make_context()
        source_emitter = HookEmitter(source_sub.get_handlers(), context, span_handlers=source_sub.get_span_handlers())
        target_emitter = HookEmitter(target_sub.get_handlers(), context, span_handlers=target_sub.get_span_handlers())

        source_emitter.propagate_to(target_emitter, only=[SampleSpan])

        await source_emitter.open_span(SampleSpan(value=42))
        await source_emitter.open_span(OtherSpan(name="ignored"))

        assert sample_calls == ["enter:42"]
        assert other_calls == []
