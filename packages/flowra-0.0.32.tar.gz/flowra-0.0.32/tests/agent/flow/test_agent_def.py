import dataclasses

import pytest

from flowra.agent import (
    NEW_SCOPE,
    CallAgent,
    CallStep,
    GotoAgent,
    GotoStep,
    Interrupted,
    Spawn,
    TimeoutExpired,
    WhenAll,
    WhenAny,
    WhenN,
    timeout,
)
from flowra.agent.definition import set_step_tag
from flowra.agent.flow.timeout import TimeoutAgent

# -- Fixtures -----------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyStepSpec:
    topic: str


# -- helpers for step refs ----------------------------------------------------


def _make_step_method(tag: str):  # noqa: ANN202
    def method(self: object) -> None: ...

    set_step_tag(method, tag)
    return method


_step_run = _make_step_method("run")


# -- GotoStep -----------------------------------------------------------------


class TestGotoStep:
    def test_step_string(self) -> None:
        g = GotoStep(step="next")
        assert g.step == "next"
        assert g.spec is None
        assert g.storage_key is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        g = GotoStep(step="next", spec=spec)
        assert g.spec is spec

    def test_frozen(self) -> None:
        g = GotoStep(step="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            g.step = "y"  # type: ignore[misc]

    def test_resolves_step_ref(self) -> None:
        g = GotoStep(step=_step_run)
        assert g.step == "run"

    def test_non_step_method_raises(self) -> None:
        def not_a_step(self: object) -> None: ...

        with pytest.raises(TypeError, match="is not a @step-decorated method"):
            GotoStep(step=not_a_step)

    def test_storage_key_string(self) -> None:
        g = GotoStep(step="next", storage_key="my-key")
        assert g.storage_key == "my-key"

    def test_storage_key_new_scope(self) -> None:
        g = GotoStep(step="next", storage_key=NEW_SCOPE)
        assert g.storage_key is NEW_SCOPE


# -- GotoAgent ----------------------------------------------------------------


class TestGotoAgent:
    def test_basic(self) -> None:
        g = GotoAgent(agent="research")
        assert g.agent == "research"
        assert g.spec is None
        assert g.storage_key is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        g = GotoAgent(agent="research", spec=spec)
        assert g.spec is spec

    def test_with_storage_key(self) -> None:
        g = GotoAgent(agent="research", storage_key="rk")
        assert g.storage_key == "rk"

    def test_with_new_scope(self) -> None:
        g = GotoAgent(agent="research", storage_key=NEW_SCOPE)
        assert g.storage_key is NEW_SCOPE

    def test_frozen(self) -> None:
        g = GotoAgent(agent="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            g.agent = "y"  # type: ignore[misc]


# -- CallStep -----------------------------------------------------------------


class TestCallStep:
    def test_step_string(self) -> None:
        c = CallStep(step="fetch")
        assert c.step == "fetch"
        assert c.spec is None
        assert c.storage_key is None
        assert c.tag is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        c = CallStep(step="fetch", spec=spec)
        assert c.spec is spec

    def test_frozen(self) -> None:
        c = CallStep(step="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            c.step = "y"  # type: ignore[misc]

    def test_resolves_step_ref(self) -> None:
        c = CallStep(step=_step_run)
        assert c.step == "run"

    def test_storage_key(self) -> None:
        c = CallStep(step="fetch", storage_key="k")
        assert c.storage_key == "k"

    def test_tag(self) -> None:
        c = CallStep(step="fetch", tag="my_tag")
        assert c.tag == "my_tag"


# -- CallAgent ----------------------------------------------------------------


class TestCallAgent:
    def test_basic(self) -> None:
        c = CallAgent(agent="sub")
        assert c.agent == "sub"
        assert c.spec is None
        assert c.storage_key is None
        assert c.tag is None

    def test_with_spec(self) -> None:
        spec = MyStepSpec(topic="t")
        c = CallAgent(agent="sub", spec=spec)
        assert c.spec is spec

    def test_with_storage_key(self) -> None:
        c = CallAgent(agent="sub", storage_key="sk")
        assert c.storage_key == "sk"

    def test_with_new_scope(self) -> None:
        c = CallAgent(agent="sub", storage_key=NEW_SCOPE)
        assert c.storage_key is NEW_SCOPE

    def test_frozen(self) -> None:
        c = CallAgent(agent="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            c.agent = "y"  # type: ignore[misc]

    def test_tag(self) -> None:
        c = CallAgent(agent="sub", tag="my_tag")
        assert c.tag == "my_tag"


# -- Spawn --------------------------------------------------------------------


class TestSpawn:
    def test_with_call_steps(self) -> None:
        s = Spawn(children=[CallStep(step="a"), CallStep(step="b")], then="merge")
        assert len(s.children) == 2
        assert s.then == "merge"

    def test_with_call_agents(self) -> None:
        s = Spawn(children=[CallAgent(agent="a"), CallAgent(agent="b")], then="collect")
        assert len(s.children) == 2

    def test_mixed_children(self) -> None:
        s = Spawn(
            children=[CallStep(step="a"), CallAgent(agent="sub")],
            then="join",
        )
        assert isinstance(s.children[0], CallStep)
        assert isinstance(s.children[1], CallAgent)

    def test_frozen(self) -> None:
        s = Spawn(children=[], then="x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            s.then = "y"  # type: ignore[misc]

    def test_then_resolves_step_ref(self) -> None:
        s = Spawn(children=[], then=_step_run)
        assert s.then == "run"


# -- Interrupted --------------------------------------------------------------


class TestInterrupted:
    def test_creates(self) -> None:
        assert isinstance(Interrupted(), Interrupted)

    def test_equality(self) -> None:
        assert Interrupted() == Interrupted()


# -- WhenAll / WhenAny / WhenN -----------------------------------------------


class TestWhenAll:
    def test_basic(self) -> None:
        a, b = CallStep(step="a"), CallAgent(agent="b")
        w = WhenAll(a, b)
        assert w.nodes == (a, b)

    def test_empty(self) -> None:
        w = WhenAll()
        assert w.nodes == ()

    def test_frozen(self) -> None:
        w = WhenAll(CallStep(step="a"))
        with pytest.raises(dataclasses.FrozenInstanceError):
            w.nodes = ()  # type: ignore[misc]


class TestWhenAny:
    def test_basic(self) -> None:
        a, b = CallStep(step="a"), CallAgent(agent="b")
        w = WhenAny(a, b)
        assert w.nodes == (a, b)

    def test_empty_raises(self) -> None:
        with pytest.raises(ValueError, match="at least 1 node"):
            WhenAny()

    def test_frozen(self) -> None:
        w = WhenAny(CallStep(step="a"))
        with pytest.raises(dataclasses.FrozenInstanceError):
            w.nodes = ()  # type: ignore[misc]


class TestWhenN:
    def test_basic(self) -> None:
        a, b, c = CallStep(step="a"), CallStep(step="b"), CallStep(step="c")
        w = WhenN(a, b, c, n=2)
        assert w.nodes == (a, b, c)
        assert w.n == 2

    def test_n_zero(self) -> None:
        w = WhenN(CallStep(step="a"), n=0)
        assert w.n == 0
        assert len(w.nodes) == 1

    def test_n_negative_raises(self) -> None:
        with pytest.raises(ValueError, match="n must be between 0 and"):
            WhenN(CallStep(step="a"), n=-1)

    def test_n_too_large_raises(self) -> None:
        with pytest.raises(ValueError, match="n must be between 0 and"):
            WhenN(CallStep(step="a"), n=2)

    def test_frozen(self) -> None:
        w = WhenN(CallStep(step="a"), n=1)
        with pytest.raises(dataclasses.FrozenInstanceError):
            w.n = 5  # type: ignore[misc]


# -- Spawn (positional args) --------------------------------------------------


class TestSpawnPositionalArgs:
    def test_single_leaf(self) -> None:
        child = CallStep(step="a")
        s = Spawn(child, then="join")
        assert s.root is child
        assert s.children == [child]

    def test_multiple_leaves_wraps_in_when_all(self) -> None:
        a, b = CallStep(step="a"), CallAgent(agent="b")
        s = Spawn(a, b, then="join")
        assert isinstance(s.root, WhenAll)
        assert s.root.nodes == (a, b)
        assert s.children == [a, b]

    def test_single_combinator(self) -> None:
        a, b = CallStep(step="a"), CallStep(step="b")
        w = WhenAny(a, b)
        s = Spawn(w, then="join")
        assert s.root is w
        assert s.children == [a, b]

    def test_nested_combinators_flatten(self) -> None:
        a = CallStep(step="a")
        b = CallAgent(agent="b")
        c = CallStep(step="c")
        s = Spawn(WhenAny(WhenAll(a, b), c), then="join")
        assert s.children == [a, b, c]

    def test_empty_children_kwarg(self) -> None:
        s = Spawn(children=[], then="join")
        assert isinstance(s.root, WhenAll)
        assert s.root.nodes == ()
        assert s.children == []

    def test_no_args_and_no_children_raises(self) -> None:
        with pytest.raises(TypeError, match="at least one child"):
            Spawn(then="join")

    def test_both_args_and_children_raises(self) -> None:
        with pytest.raises(TypeError, match="Cannot specify both"):
            Spawn(CallStep(step="a"), children=[CallStep(step="b")], then="join")


# -- TimeoutExpired / timeout() -----------------------------------------------


class TestTimeoutExpired:
    def test_fields(self) -> None:
        t = TimeoutExpired(seconds=5.0)
        assert t.seconds == 5.0

    def test_frozen(self) -> None:
        t = TimeoutExpired(seconds=1.0)
        with pytest.raises(dataclasses.FrozenInstanceError):
            t.seconds = 2.0  # type: ignore[misc]


class TestTimeout:
    def test_seconds(self) -> None:
        c = timeout(seconds=10)
        assert isinstance(c, CallAgent)
        assert c.agent is TimeoutAgent
        assert c.spec.seconds == 10.0  # type: ignore[union-attr]

    def test_minutes(self) -> None:
        c = timeout(minutes=2)
        assert c.spec.seconds == 120.0  # type: ignore[union-attr]

    def test_combined(self) -> None:
        c = timeout(seconds=30, minutes=1)
        assert c.spec.seconds == 90.0  # type: ignore[union-attr]
