import dataclasses

from flowra.agent import Agent, AgentInfo, Event, ExecutionContext, ExecutionFrame, HookEmitter, HookSubscription


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleEvent:
    value: int
    extra: str = ""


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherEvent:
    name: str


def _test_context() -> ExecutionContext:
    info = AgentInfo(name="test", path="test", source_type=None, parent=None)
    frame = ExecutionFrame(agent=info)
    return ExecutionContext(frame=frame, stack=(frame,))


def _emitter(subscription: HookSubscription | None = None) -> HookEmitter:
    sub = subscription or HookSubscription()
    return HookEmitter(sub.get_handlers(), _test_context())


class TestHookSubscription:
    def test_on_registers_handler(self) -> None:
        sub = HookSubscription()
        assert not sub.has_handlers(SampleEvent)
        sub.on(SampleEvent, lambda e: None)
        assert sub.has_handlers(SampleEvent)
        assert not sub.has_handlers(OtherEvent)

    async def test_prepend_handler(self) -> None:
        order: list[str] = []
        sub = HookSubscription()
        sub.on(SampleEvent, lambda e: order.append("first"))
        sub.on(SampleEvent, lambda e: order.append("prepended"), prepend=True)
        emitter = _emitter(sub)
        await emitter.emit(SampleEvent(value=0))
        assert order == ["prepended", "first"]


class TestHookEmitter:
    async def test_emit_no_handlers(self) -> None:
        emitter = _emitter()
        result = await emitter.emit(SampleEvent(value=42))
        assert result.value == 42

    async def test_sync_handler_called(self) -> None:
        received: list[Event[SampleEvent]] = []

        def handler(event: Event[SampleEvent]) -> None:
            received.append(event)

        sub = HookSubscription()
        sub.on(SampleEvent, handler)
        emitter = _emitter(sub)
        await emitter.emit(SampleEvent(value=7))

        assert len(received) == 1
        assert received[0].data.value == 7

    async def test_async_handler_called(self) -> None:
        received: list[int] = []

        async def handler(event: Event[SampleEvent]) -> None:
            received.append(event.data.value)

        sub = HookSubscription()
        sub.on(SampleEvent, handler)
        emitter = _emitter(sub)
        await emitter.emit(SampleEvent(value=99))

        assert received == [99]

    async def test_multiple_handlers_called_in_order(self) -> None:
        order: list[str] = []

        sub = HookSubscription()
        sub.on(SampleEvent, lambda e: order.append("first"))
        sub.on(SampleEvent, lambda e: order.append("second"))
        sub.on(SampleEvent, lambda e: order.append("third"))
        emitter = _emitter(sub)
        await emitter.emit(SampleEvent(value=0))

        assert order == ["first", "second", "third"]

    async def test_prepend_handler(self) -> None:
        order: list[str] = []

        sub = HookSubscription()
        sub.on(SampleEvent, lambda e: order.append("first"))
        sub.on(SampleEvent, lambda e: order.append("prepended"), prepend=True)
        sub.on(SampleEvent, lambda e: order.append("last"))
        emitter = _emitter(sub)
        await emitter.emit(SampleEvent(value=0))

        assert order == ["prepended", "first", "last"]

    async def test_has_handlers(self) -> None:
        sub = HookSubscription()
        emitter = _emitter(sub)
        assert not emitter.has_handlers(SampleEvent)

        sub.on(SampleEvent, lambda e: None)
        emitter = _emitter(sub)
        assert emitter.has_handlers(SampleEvent)
        assert not emitter.has_handlers(OtherEvent)

    async def test_propagate_to(self) -> None:
        received: list[int] = []

        ctx = _test_context()
        source_sub = HookSubscription()
        target_sub = HookSubscription()
        target_sub.on(SampleEvent, lambda e: received.append(e.data.value))

        # Need a handler on source for the event type to be propagated
        source_sub.on(SampleEvent, lambda e: None)

        source = HookEmitter(source_sub.get_handlers(), ctx)
        target = HookEmitter(target_sub.get_handlers(), ctx)
        source.propagate_to(target)
        await source.emit(SampleEvent(value=42))

        assert received == [42]

    async def test_propagate_to_with_only(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        ctx = _test_context()
        source_sub = HookSubscription()
        target_sub = HookSubscription()
        target_sub.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target_sub.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source_sub.on(SampleEvent, lambda e: None)
        source_sub.on(OtherEvent, lambda e: None)

        source = HookEmitter(source_sub.get_handlers(), ctx)
        target = HookEmitter(target_sub.get_handlers(), ctx)
        source.propagate_to(target, only=[SampleEvent])

        await source.emit(SampleEvent(value=1))
        await source.emit(OtherEvent(name="test"))

        assert sample_received == [1]
        assert other_received == []

    async def test_propagate_to_with_exclude(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        ctx = _test_context()
        source_sub = HookSubscription()
        target_sub = HookSubscription()
        target_sub.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target_sub.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source_sub.on(SampleEvent, lambda e: None)
        source_sub.on(OtherEvent, lambda e: None)

        source = HookEmitter(source_sub.get_handlers(), ctx)
        target = HookEmitter(target_sub.get_handlers(), ctx)
        source.propagate_to(target, exclude=[OtherEvent])

        await source.emit(SampleEvent(value=2))
        await source.emit(OtherEvent(name="excluded"))

        assert sample_received == [2]
        assert other_received == []

    async def test_handler_mutation_visible(self) -> None:
        def mutate(event: Event[SampleEvent]) -> None:
            event.data.extra = "mutated"

        sub = HookSubscription()
        sub.on(SampleEvent, mutate)
        emitter = _emitter(sub)
        result = await emitter.emit(SampleEvent(value=1))

        assert result.extra == "mutated"

    async def test_context_stamped(self) -> None:
        agent_info = AgentInfo(name="test", path="root/test", source_type=Agent, parent=None)
        frame = ExecutionFrame(agent=agent_info, spec=None)
        context = ExecutionContext(frame=frame, stack=(frame,))
        received_contexts: list[ExecutionContext] = []

        def handler(event: Event[SampleEvent]) -> None:
            received_contexts.append(event.context)

        sub = HookSubscription()
        sub.on(SampleEvent, handler)
        emitter = HookEmitter(sub.get_handlers(), context)
        await emitter.emit(SampleEvent(value=1))

        assert len(received_contexts) == 1
        assert received_contexts[0] is context
        assert received_contexts[0].frame.agent.source_type is Agent
        assert received_contexts[0].frame.agent.path == "root/test"
