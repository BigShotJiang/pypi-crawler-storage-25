# Package `flowra.ext`

Optional integrations with external services that require extra dependencies.

- **[Tracing guide](ext/tracing-guide.md)** — how to choose and configure MLflow, OTel, or both
- **[MLflow tracing](ext/mlflow.md)** — span-hook integration for ML experiment tracking
- **[OpenTelemetry tracing](ext/otel.md)** — span-hook integration with GenAI semantic conventions

Provider-specific hook bundles (no extra dependencies) live in `flowra.lib`:

- **[Anthropic extensions](lib/anthropic.md)** — prompt caching and tool search
  via `PrepareLLMRequestEvent`
