# Tool Search — Research

Research date: 2026-03-17, updated 2026-03-27
Implemented: `AnthropicToolSearch` in `flowra.lib.anthropic.tool_search` (Anthropic only)

## Problem

When an agent has 50+ tools, two compounding issues arise:

- **Context bloat.** Tool definitions consume context budget fast. A typical multi-server
  setup (GitHub, Slack, Sentry, Grafana, Splunk) can eat ~55k tokens in definitions alone.
- **Tool selection accuracy.** Model ability to pick the right tool degrades significantly
  beyond 30–50 tools.

Both Anthropic and OpenAI now offer server-side tool search — lazy (on-demand) tool loading
where the model sees only tool names and descriptions upfront, and discovers full definitions
at runtime via a search mechanism.


## Anthropic

### How it works

1. All tools are sent in the request with `defer_loading: true`. Claude sees only names and
   descriptions — no full `input_schema`.
2. A special tool (`tool_search_tool_regex_20251119` or `tool_search_tool_bm25_20251119`)
   is included in the tools list.
3. When Claude needs a tool, it calls the search tool with a query.
4. The API returns 3–5 `tool_reference` content blocks containing fully expanded tool
   definitions.
5. These references are automatically injected into the conversation — Claude can then
   invoke the discovered tools normally.

Two search variants:
- **Regex** (`tool_search_tool_regex_20251119`) — Claude constructs regex patterns to search.
- **BM25** (`tool_search_tool_bm25_20251119`) — Claude uses natural language queries.

Reduces token usage by ~85% while maintaining high selection accuracy.

### API shape

#### Request

Tools list includes the search tool plus deferred tools:

```python
tools = [
    # The search tool itself (no input_schema needed)
    {"type": "tool_search_tool_regex_20251119", "name": "tool_search_tool_regex"},

    # Deferred tools — only name + description visible to Claude
    {
        "name": "get_weather",
        "description": "Get the weather at a specific location",
        "input_schema": {
            "type": "object",
            "properties": {"location": {"type": "string"}},
            "required": ["location"],
        },
        "defer_loading": True,  # <-- key flag
    },
]
```

#### Response

Claude's response includes `tool_reference` blocks alongside normal `tool_use`:

```json
{
  "content": [
    {"type": "tool_reference", "tool_name": "get_weather"},
    {
      "type": "tool_use",
      "name": "get_weather",
      "input": {"location": "San Francisco", "unit": "celsius"}
    }
  ]
}
```

The `tool_reference` block signals that the tool was discovered via search. The full
definition is automatically available for subsequent turns.

#### Client-side implementation

You can also implement tool search client-side by returning `tool_reference` blocks from
your own search handler. This avoids vendor lock-in and works with any model — the client
intercepts the search tool call, performs its own lookup (embedding search, database, etc.),
and returns `tool_reference` blocks in the tool result.


## OpenAI

### How it works

Available in gpt-5.4+ via the Responses API.

1. Tools are sent with `defer_loading: true`. The model sees only names and descriptions.
2. `{"type": "tool_search"}` is added to the tools array.
3. When the model needs a tool, the API performs search over deferred tools.
4. Discovered tool definitions are injected **at the end of the context window** to
   preserve KV cache.
5. The model can then call the discovered tools normally.

Two modes:
- **Hosted** (`execution: "server"`, default) — the API handles discovery automatically
  across deferred tools (functions, namespaces, MCP servers).
- **Client-executed** (`execution: "client"`) — your application performs discovery logic.
  The model emits `tool_search_call` with a `call_id`, your code returns matching
  `tool_search_output` with the same `call_id`.

Reported token savings: 34–64% (Spring AI benchmarks).

### API shape

#### Request (hosted mode)

```python
response = client.responses.create(
    model="gpt-5.4",
    input="List open orders for customer CUST-12345.",
    tools=[
        # Namespace with deferred tools
        {
            "type": "namespace",
            "name": "crm",
            "description": "CRM tools for customer management",
            "functions": [
                {
                    "name": "get_orders",
                    "description": "List orders for a customer",
                    "parameters": {"type": "object", "properties": {...}},
                    "defer_loading": True,
                },
                # ... more deferred functions
            ],
        },
        # The search tool
        {"type": "tool_search"},
    ],
)
```

#### Response

The response includes `tool_search_call` and `tool_search_output` items before
`function_call` items:

```json
[
    {"type": "tool_search_call", "execution": "server", "call_id": null},
    {"type": "tool_search_output", "tools": ["crm.get_orders"]},
    {"type": "function_call", "name": "crm.get_orders", "arguments": "{...}"}
]
```

#### Client-executed mode

```python
tools = [
    {"type": "tool_search", "execution": "client", "schema": {
        "type": "object",
        "properties": {"query": {"type": "string"}},
    }},
    # ... deferred tools
]
```

The model emits `tool_search_call` with `execution: "client"` and a unique `call_id`.
Your app searches for matching tools and returns `tool_search_output` with the found
tool definitions.

### Best practices (from OpenAI docs)

- Group deferred functions into **namespaces** with clear descriptions.
- Keep each namespace to fewer than **10 functions**.
- Keep fewer than **20 functions** immediately available (not deferred) per turn.


## Comparison

| Aspect                  | Anthropic                                          | OpenAI                                         |
|-------------------------|----------------------------------------------------|-------------------------------------------------|
| Models                  | Claude (version TBD)                               | gpt-5.4+                                       |
| Deferred flag           | `defer_loading: true`                              | `defer_loading: true`                           |
| What model sees         | Name + description only                            | Name + description only                         |
| Search tool type        | `tool_search_tool_regex_*` or `tool_search_tool_bm25_*` | `{"type": "tool_search"}`                  |
| Search algorithms       | Regex, BM25 (two separate tool types)              | Single hosted search (algorithm unspecified)     |
| Discovery result        | `tool_reference` blocks in content                 | `tool_search_output` items in response           |
| Client-side option      | Return `tool_reference` from own handler           | `execution: "client"` with custom schema         |
| Namespaces              | Not mentioned                                      | First-class concept                              |
| MCP server deferral     | Not mentioned                                      | Supported (defer entire MCP servers)             |
| Cache preservation      | Not specified                                      | Explicit — injected at end of context window     |
| Token savings           | ~85%                                               | 34–64%                                           |


## Flowra support plan

Currently only Anthropic is supported (`AnthropicToolSearch`). To support OpenAI and
enable provider-agnostic usage:

### Provider-level support

Each provider translates flowra's `Tool` with `defer_loading=True` into the
provider-specific wire format:

- **AnthropicProvider / AnthropicVertexProvider** — already done. Sends `defer_loading`
  flag, includes `tool_search_tool_*` in tools list, handles `tool_reference` blocks in
  response.
- **OpenAIProvider** — needs implementation. Send `defer_loading` flag, add
  `{"type": "tool_search"}` to tools, handle `tool_search_call` / `tool_search_output`
  in response parsing. Decide on hosted vs client-executed (start with hosted).

### flowra.llm model

- `Tool` already has `defer_loading` field (or needs one) — this is the provider-agnostic
  flag.
- Need a way to configure search variant (regex vs BM25 for Anthropic, hosted vs client
  for OpenAI). Could be a provider-level config or part of `LLMRequest`.
- `tool_reference` / `tool_search_output` are provider-specific response artifacts. Decide
  whether to surface them in `LLMResponse` or handle transparently inside providers.

### Client-side tool search (future)

Provider-agnostic tool search implemented in flowra itself: given a large tool catalog,
automatically defer tools and implement search client-side (embedding-based or BM25).
Works with any LLM provider. This is a separate feature from provider-native tool search.
