# Tool Error Signals & Escalation — Research

Research date: 2026-03-23
Implemented: `ToolErrorKind`, `InterruptControl`, `Interrupted` binding

## Problem

When an LLM generates a tool call that fails (unknown tool, schema validation
error, execution error), the system needs to distinguish failure types so hooks
and parent agents can react — switch to a stronger model, or escalate to a
parent agent that re-routes the conversation.

## Scenario

```
Router Agent
  │
  ├─ receives user message
  ├─ classifies → "create invoice" mode
  └─ GotoAgent(InvoiceAgent, model="fast")
       │
       └─ Tool Loop (cheap model)
            ├─ LLM call → tool:ask_customer(question="...")
            ├─ Schema validation fails (wrong params)
            │   → signal: schema_validation_error
            ├─ LLM retry → tool:ask_customer(question="...")
            ├─ Schema validation fails again
            │   → signal: schema_validation_error (2nd)
            │   → observer: threshold reached → interrupt!
            └─ Interrupted
       │
       ├─ Parent sees: interrupted + reason = "model_too_weak"
       └─ GotoAgent(InvoiceAgent, model="strong")
```

## ToolErrorKind enum

`ToolErrorKind` is a `StrEnum` in `flowra/tools/types.py`:

| `ToolErrorKind` | Where set |
|---|---|
| `UNKNOWN_TOOL` | `ToolRegistry.execute()` (unknown tool), `McpConnection.call_tool()` (unknown/removed tool), `ToolCallAgent` (denied by filter) |
| `SCHEMA_VALIDATION` | `ToolRegistry.execute()` (catches `jsonschema.ValidationError`) |
| `EXECUTION` | `ToolRegistry.execute()` (handler exception), `McpConnection` (JSON-RPC error, transport failure) |

Available to consumers through:
- **`ToolCallSpan.error_kind`** — for span-hooks (MLflow, OTel)
- **`AfterToolCallEvent.error_kind`** — for regular hooks

`ToolResultBlock` (LLM layer) intentionally has no `error_kind` — the LLM doesn't need it.

## InterruptControl

Service injected into agents via DI:

```python
class InterruptControl:
    def interrupt(self) -> None:
        """Interrupt this agent and all its children."""

    def interrupt_children(self) -> None:
        """Interrupt only spawned children, not this agent."""
```

Naming convention: `InterruptToken` (observe), `InterruptTokenSource` (own),
`InterruptControl` (act).

## Interrupted binding in steps

Steps that declare `Interrupted` in their union type receive it directly:

```python
@step
async def check_result(
    self,
    result: Annotated[ChatResult | Interrupted, step_arg.CHILD("chat")],
) -> ChatResult | Spawn:
    if isinstance(result, Interrupted):
        # handle escalation
```

If the step doesn't declare `Interrupted` in the type, the binding falls through
to nullable → `None` (backward compatible).

## Recipe: model fallback on schema validation error

```python
class ModelFallbackOnError:
    def __init__(self, fallback_model: str):
        self._fallback_model = fallback_model
        self._use_fallback = False

    def install(self, hooks: HookSubscription):
        hooks.on(AfterToolCallEvent, self._on_after)
        hooks.on(PrepareLLMRequestEvent, self._on_prepare)

    def _on_after(self, event: Event[AfterToolCallEvent]):
        if event.data.error_kind == ToolErrorKind.SCHEMA_VALIDATION:
            self._use_fallback = True

    def _on_prepare(self, event: Event[PrepareLLMRequestEvent]):
        if self._use_fallback:
            event.data.request = dataclasses.replace(
                event.data.request, model=self._fallback_model
            )
            self._use_fallback = False
```

## Recipe: escalation via InterruptControl

See `examples/escalation.py` for the full working example. Key components:

1. **TierService** — shared service with current tier and `InterruptControl`.
   Tools call `request_escalation()` to signal the need for a smarter model.
2. **EscalationAgent** — parent agent that spawns ChatAgent with fast model.
   Catches `Interrupted` from child, switches to smart model, respawns.

## All primitives

| Primitive | Notes |
|---|---|
| `ToolErrorKind` | `StrEnum` in `flowra.tools` |
| `ToolResult.error_kind` | Set on all error paths in `ToolRegistry` and `McpConnection` |
| `ToolCallSpan.error_kind` | For span-hooks (MLflow, OTel) |
| `AfterToolCallEvent.error_kind` | For regular hooks |
| `InterruptControl` | Injected via DI — `interrupt()` and `interrupt_children()` |
| `Interrupted` binding in steps | Steps with `\| Interrupted` in union type receive it directly |
| `PrepareLLMRequestEvent` | Can replace `request.model` |
| `InterruptToken` per child | Per-node tokens via `Spawn` |
