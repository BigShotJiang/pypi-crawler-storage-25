# Model Fallback on Tool Call Failure — Research

Research date: 2026-03-22
Status: not implemented

## Problem

When using a weak/fast model (e.g. Claude Haiku, Gemini Flash Lite) for tool
calling, the model occasionally produces invalid tool calls:
- Malformed JSON in `tool_use.input`
- Wrong argument types or missing required fields
- Calling a non-existent tool name
- Invalid function call structure (Gemini's `MALFORMED_FUNCTION_CALL`)

The cheap model handles 95% of cases correctly, but the 5% failure rate is
unacceptable in production.

## Goal

Automatically escalate to a stronger model when a tool call fails, without
changing the agent's code.

## Design options considered

### Option A: Hook-based (AfterToolCallEvent)

Subscribe to `AfterToolCallEvent`, detect errors, trigger retry with different model.

**Problem:** `AfterToolCallEvent` can modify results and inject messages, but cannot
re-execute the tool call or trigger an immediate retry.

### Option B: Pre-validation in BeforeToolCallEvent

Validate `tool_use.input` against `tool.input_schema` before execution.

**Problem:** can validate and reject, but not fix — no access to a "better model".

### Option C: Provider-level retry (LLMProvider wrapper)

**Problem:** provider doesn't know if a tool call will fail — it only sees
`ToolUseBlock`s. Can't validate against schemas (no tool registry access).

### Option D: New hook — ToolCallValidationFailedEvent

Add schema validation before tool execution + new event. Most targeted approach
but requires core changes (validation in tool path, new event type, retry mechanism).

### Option E: Iteration-level retry via hooks (recommended)

Retry the entire LLM iteration with a stronger model when any tool call fails:

```python
class ModelFallback:
    def __init__(self, fallback_model: str):
        self.__fallback_model = fallback_model
        self.__use_fallback = False

    def install(self, hooks: HookSubscription):
        hooks.on(AfterToolCallEvent, self.on_after_tool_call)
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_after_tool_call(self, event):
        if event.data.result.is_error:
            self.__use_fallback = True

    def on_prepare(self, event):
        if self.__use_fallback:
            request = event.data.request
            event.data.request = dataclasses.replace(request, model=self.__fallback_model)
            self.__use_fallback = False
```

**Why this works:** `PrepareLLMRequestEvent` fires before every LLM call. After
tool errors, the next iteration's request gets the fallback model. After a
successful iteration, it resets to the primary.

**Limitation:** retries the entire LLM call, not just the failed tool. Acceptable
in practice — one extra call on a stronger model vs a failed interaction.

## Recommendation

**Start with Option E.** ~30 lines, composable (`install(hooks)` pattern),
no core changes, works with existing hooks.

**Future:** Option D (schema validation + targeted retry) if E proves insufficient.

## Open questions

1. **Per-tool or per-iteration fallback?** Option E retries the whole iteration.
2. **How many retries?** One? Escalating chain (fast → medium → strong)?
3. **What counts as "retryable"?** Any `is_error=True`? Specific `ToolErrorKind`s?
4. **Tool input validation** — adding `jsonschema.validate()` before execution is
   useful independently of fallback.
5. **State in parallel execution** — `AfterToolCallEvent` fires sequentially in
   `collect_results`, so shared flag works, but needs testing.

## Related

- `tool_error_signals.md` — `ToolErrorKind` for distinguishing failure types
- `llm_retry_backoff.md` — retry for transient LLM errors (complementary)
