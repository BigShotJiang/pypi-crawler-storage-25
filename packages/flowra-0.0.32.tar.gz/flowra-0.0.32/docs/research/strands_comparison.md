# Strands Agents SDK vs Flowra — Comparison

Research date: 2026-03-08

## What Strands has that Flowra doesn't

| Capability | Strands | Flowra | Priority |
|---|---|---|---|
| **Guardrails** | Integration with Amazon Bedrock Guardrails — content filtering, topic blocking, PII protection | None | Medium — depends on use case |
| **A2A (Agent-to-Agent) protocol** | Agents communicate across processes/services via standard protocol | No — agents only within a single runtime | Low for now — relevant for distributed systems |
| **Session management with external stores** | DynamoDB, Bedrock AgentCore Memory, custom | InMemory, File, custom (but no ready-made cloud DB adapters) | Medium |

## What Flowra has that Strands doesn't (or weaker)

| Capability | Flowra | Strands |
|---|---|---|
| **Crash recovery** | Full: persistence after each step, resume after crash | Session persistence exists, but step-level crash recovery — no |
| **Incremental dirty-tracking** | `Scalar[T]` and `AppendOnlyList[T]` save only changes | Saves state entirely |
| **State machine with compile-time checks** | `@step`, `GotoStep`/`GotoAgent`, `Spawn`, `CallStep`/`CallAgent` — compiler checks slots and types at class definition time | Model-driven loop — no explicit state machine |
| **Cooperative interrupts** | `InterruptToken` propagates through entire execution tree, per-node tokens with parent→child cascade | No equivalent |
| **DI into tool handlers** | `tool_arg.SERVICE` marker — services injected into tool functions | Tools receive only tool input |

## Remaining gaps to consider

1. **Guardrails** — content filtering, topic blocking, PII protection. Depends on use case.
2. **A2A protocol** — cross-process agent communication. Low priority now.
3. **Cloud session stores** — ready-made DynamoDB/Redis/etc adapters for session persistence.

## Sources

- [Introducing Strands Agents (AWS Blog)](https://aws.amazon.com/blogs/opensource/introducing-strands-agents-an-open-source-ai-agents-sdk/)
- [Strands Agents Documentation](https://strandsagents.com/latest/documentation/docs/)
- [Multi-Agent Patterns](https://dev.to/aws-builders/understanding-multi-agent-patterns-in-strands-agent-graph-swarm-and-workflow-4nb8)
- [A2A Protocol](https://strandsagents.com/latest/documentation/docs/user-guide/concepts/multi-agent/agent-to-agent/)
- [Guardrails](https://strandsagents.com/latest/documentation/docs/user-guide/safety-security/guardrails/)
- [GitHub - sdk-python](https://github.com/strands-agents/sdk-python)
