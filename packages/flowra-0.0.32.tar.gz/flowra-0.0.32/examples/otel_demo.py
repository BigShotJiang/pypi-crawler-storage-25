"""OpenTelemetry tracing demo — runs a chat request with OTel tracing to Jaeger.

Usage:
    # Start Jaeger (Docker):
    docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one

    # Run demo:
    make otel-demo

    # View traces:
    open http://localhost:16686 → Service "flowra-demo" → Find Traces
"""

import asyncio
import pathlib

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, InMemorySessionStorage
from flowra.ext.otel import OTEL_TRACING
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, get_local_tool

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


# Try OTLP exporter (for Jaeger), fall back to console
def _setup_otel() -> None:
    resource = Resource.create({"service.name": "flowra-demo"})
    provider = TracerProvider(resource=resource)

    try:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://localhost:4317")))
        print("OTel: exporting to Jaeger (localhost:4317)")
    except ImportError:
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
        print("OTel: using console exporter (install opentelemetry-exporter-otlp for Jaeger)")

    trace.set_tracer_provider(provider)


async def main() -> None:
    _setup_otel()
    router = create_router()

    async with await ToolRegistry.create([get_local_tool(calculate), get_local_tool(random_numbers)]) as registry:
        app_config = AppConfig(
            default_model=DEFAULT_MODEL,
            system=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
        )

        runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=InMemorySessionStorage(),
            services={
                ToolRegistry: registry,
                AppConfig: app_config,
                LLMProvider: router,
            },
        )
        OTEL_TRACING.install(runtime)

        print("Sending: What is 2+2? Use the calculator tool.")
        result = await runtime.run(
            agent=AppAgent,
            spec=ChatSpec(user_message="What is 2+2? Use the calculator tool."),
        )

        if isinstance(result, ChatResult):
            print(f"\nAssistant: {result.response}")
            if result.usage:
                print(f"Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
                if result.usage.cost_usd is not None:
                    print(f"Cost: ${result.usage.cost_usd:.4f}")

    # Flush spans
    tp = trace.get_tracer_provider()
    if hasattr(tp, "force_flush"):
        tp.force_flush()  # type: ignore[attr-defined]

    print("\nDone! View traces: open http://localhost:16686")


if __name__ == "__main__":
    asyncio.run(main())
