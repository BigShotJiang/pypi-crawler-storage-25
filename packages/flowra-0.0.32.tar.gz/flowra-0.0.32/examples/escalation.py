"""Escalation example — fast model fails, system escalates to smart model.

Demonstrates the signal/interrupt/escalation pattern:

1. EscalationAgent starts with a fast (cheap) model
2. A tool detects it needs a smarter model and requests escalation
3. EscalationAgent interrupts its children via InterruptControl
4. Parent catches Interrupted, switches to a smart model, and reruns
5. A hook on AfterToolCallEvent logs error_kind signals

The key insight: the framework provides all the primitives (InterruptControl,
DI services, hooks, error_kind) — users compose them into escalation logic.

Usage:
    make escalation
    make escalation fast_model=google/gemini-2.5-flash smart_model=anthropic/sonnet-4-5
"""

import argparse
import asyncio
import dataclasses
import sys
from typing import Annotated, ClassVar

from examples.llm_logging import setup_file_logging
from examples.model_registry import create_router
from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    AgentStore,
    CallAgent,
    Event,
    InterruptControl,
    Interrupted,
    Scalar,
    ServiceLocator,
    Spawn,
    step,
    step_arg,
)
from flowra.ext.mlflow import MLFLOW_TRACING
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.tool_loop import AfterToolCallEvent
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, get_local_tool, tool

setup_file_logging("escalation")

# -- Display ------------------------------------------------------------------

_RESET = "\033[0m"
_DIM = "\033[2m"
_BOLD = "\033[1m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"


def _print(msg: str) -> None:
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()


# -- Tier service -------------------------------------------------------------


class TierService:
    """Shared service: tracks current model tier and can trigger escalation.

    Tools call ``request_escalation()`` when they need a smarter model.
    The service interrupts all children of the parent agent via InterruptControl.
    """

    __slots__ = ("__interrupt_control", "__reason_slot", "tier")

    def __init__(self, tier: str, interrupt_control: InterruptControl, reason_slot: Scalar[str | None]) -> None:
        self.tier = tier
        self.__interrupt_control = interrupt_control
        self.__reason_slot = reason_slot

    @property
    def escalation_reason(self) -> str | None:
        return self.__reason_slot.get(default=None)

    def request_escalation(self, reason: str) -> None:
        """Called by tools that need a smarter model."""
        self.__reason_slot.set(reason)
        _print(f"  {_RED}[escalation]{_RESET} {reason}")
        self.__interrupt_control.interrupt_children()

    def clear_escalation(self) -> None:
        self.__reason_slot.set(None)


# -- Tools --------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are a helpful assistant. You have access to an analyze_document tool \
that can perform deep analysis of documents. When the user asks you to \
analyze something, use the tool."""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AnalyzeInput:
    topic: str
    depth: str = "basic"


@tool("analyze_document", "Analyze a document on a given topic in depth.")
def analyze_document(params: AnalyzeInput, tier_service: TierService) -> str:
    """Simulate a tool that requires a smart model for deep analysis."""
    if params.depth != "basic" and tier_service.tier == "fast":
        tier_service.request_escalation(f"Deep analysis (depth={params.depth}) requires a smart model")
        raise ValueError("deep analysis requires a smart model, current tier is fast")
    return f"Analysis of '{params.topic}' (depth={params.depth}, tier={tier_service.tier}): This is a detailed result."


# -- Hook: log error signals --------------------------------------------------


def on_after_tool_call(event: Event[AfterToolCallEvent]) -> None:
    tool_name = event.data.tool_use.name
    if event.data.error_kind is not None:
        _print(
            f"  {_YELLOW}[signal]{_RESET} tool={tool_name} "
            f"error_kind={_RED}{event.data.error_kind}{_RESET} "
            f"content={event.data.result.content[:80]}"
        )
    elif event.data.result.is_error:
        _print(f"  {_YELLOW}[signal]{_RESET} tool={tool_name} error (no error_kind)")
    else:
        _print(f"  {_GREEN}[ok]{_RESET} tool={tool_name} succeeded")


# -- Escalation agent ---------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class EscalationSpec:
    user_message: str
    fast_model: str
    smart_model: str


class EscalationAgent(Agent[EscalationSpec, ChatResult]):
    __slots__ = ("__current_model", "__spec", "__tier_service")
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "chat": ChatAgent,
    }

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        spec: EscalationSpec,
        interrupt_control: InterruptControl,
    ) -> None:
        self.__spec = spec
        self.__current_model = store.slot(Scalar[str], "current_model")

        escalation_reason = store.slot(Scalar[str | None], "escalation_reason")
        self.__tier_service = TierService(
            tier="fast", interrupt_control=interrupt_control, reason_slot=escalation_reason
        )
        services.provide(self.__tier_service)
        services.provide(
            ChatConfig(
                llm_config=lambda: LLMConfig(model=self.__current_model.get(default=spec.fast_model)),
                system=[SystemMessage(blocks=[TextBlock(text=SYSTEM_PROMPT)])],
                max_llm_calls=5,
            ),
        )

    @step(entry=True)
    async def run_fast(self, spec: EscalationSpec) -> Spawn:
        _print(f"\n{_BLUE}[tier=fast]{_RESET} Starting with {_DIM}{spec.fast_model}{_RESET}")
        self.__current_model.set(spec.fast_model)
        return Spawn(
            CallAgent(agent=ChatAgent, spec=ChatSpec(user_message=spec.user_message), tag="chat"),
            then=self.check_result,
        )

    @step
    async def check_result(
        self,
        result: Annotated[ChatResult | Interrupted, step_arg.CHILD("chat")],
    ) -> ChatResult | Spawn:
        _print(f"  {_DIM}[check_result] got: {type(result).__name__}{_RESET}")
        if not isinstance(result, Interrupted):
            return result

        # Escalation happened — switch to smart model
        reason = self.__tier_service.escalation_reason or "unknown"
        _print(f"\n{_RED}[escalation]{_RESET} Child interrupted (reason: {reason}). Switching to smart model...")
        _print(f"{_BLUE}[tier=smart]{_RESET} Rerunning with {_DIM}{self.__spec.smart_model}{_RESET}")

        self.__current_model.set(self.__spec.smart_model)
        self.__tier_service.tier = "smart"
        self.__tier_service.clear_escalation()

        return Spawn(
            CallAgent(agent=ChatAgent, spec=ChatSpec(user_message=self.__spec.user_message), tag="chat2"),
            then=self.return_result,
        )

    @step
    async def return_result(self, result: Annotated[ChatResult | Interrupted, step_arg.CHILD("chat2")]) -> ChatResult:
        if isinstance(result, Interrupted):
            return ChatResult(response="Failed even with smart model.")
        return result


# -- Main ---------------------------------------------------------------------

DEFAULT_FAST = "google/gemini-2.5-flash"
DEFAULT_SMART = "anthropic/sonnet-4-5"
DEFAULT_MESSAGE = "Please analyze the topic 'quantum computing' with depth='detailed'."


async def main(user_message: str, fast_model: str, smart_model: str) -> None:
    router = create_router()
    tools = await ToolRegistry.create([get_local_tool(analyze_document)])

    runtime = AgentRuntime(
        agents={"escalation": EscalationAgent},
        services={
            LLMProvider: router,
            ToolRegistry: tools,
        },
    )
    runtime.hooks.on(AfterToolCallEvent, on_after_tool_call)
    MLFLOW_TRACING.install(runtime, experiment_name="escalation-demo", trace_steps=True)

    spec = EscalationSpec(
        user_message=user_message,
        fast_model=fast_model,
        smart_model=smart_model,
    )

    _print(f"{_BOLD}Message:{_RESET} {user_message}")
    result = await runtime.run(agent=EscalationAgent, spec=spec)

    _print(f"\n{_BOLD}Result ({type(result).__name__}):{_RESET}")
    if isinstance(result, Interrupted):
        _print(f"{_RED}Interrupted{_RESET}")
    elif isinstance(result, ChatResult) and result.response:
        _print(result.response)
    else:
        _print(f"{_RED}No response: {result!r}{_RESET}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Escalation: fast model → smart model on failure")
    parser.add_argument("--message", default=DEFAULT_MESSAGE)
    parser.add_argument("--fast-model", default=DEFAULT_FAST)
    parser.add_argument("--smart-model", default=DEFAULT_SMART)
    args = parser.parse_args()

    asyncio.run(main(user_message=args.message, fast_model=args.fast_model, smart_model=args.smart_model))
