"""Agent-as-tool example.

Demonstrates how to register agents as tools so the LLM autonomously
decides when to delegate work to a specialist sub-agent.

Two specialist agents are available as tools:
- "poet" — writes a short poem on a given topic (has its own LLM + system prompt)
- "math_tutor" — explains a math concept step by step (has its own LLM + system prompt)

Each specialist is a full ChatAgent with its own system prompt and tool loop.
The main chat agent decides which specialist to call based on the user's request.

Usage:
    uv run python examples/agent_as_tool.py
    uv run python examples/agent_as_tool.py --model anthropic/sonnet-4-5
    uv run python examples/agent_as_tool.py --input "Write a poem about the sea"
"""

import argparse
import asyncio
import dataclasses
import json
from typing import ClassVar

from examples.llm_logging import setup_file_logging
from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.agent import Agent, AgentRuntime, Event, step
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.tool_loop import AfterToolCallEvent, BeforeToolCallEvent, make_agent_tool
from flowra.llm import LLMProvider, LLMRequest, SystemMessage, TextBlock, Usage, UserMessage
from flowra.tools import ToolRegistry

_fh = setup_file_logging("agent_as_tool")


# ---------------------------------------------------------------------------
# Specialist agents — thin wrappers that run ChatAgent with a specific prompt
# ---------------------------------------------------------------------------

POET_PROMPT = (
    "You are a poet. Write a short poem (4-8 lines) on the given topic. Respond with ONLY the poem, nothing else."
)

MATH_TUTOR_PROMPT = (
    "You are a math tutor. Explain the given concept or solve the problem step by step. Be clear and concise."
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpecialistSpec:
    task: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpecialistResult:
    response: str


class _SpecialistAgent(Agent[SpecialistSpec, SpecialistResult]):
    """Base for specialist agents. Calls LLM directly with a system prompt."""

    __slots__ = ("__llm_config", "__provider")

    system_prompt: ClassVar[str] = ""

    def __init__(self, provider: LLMProvider, llm_config: LLMConfig) -> None:
        self.__provider = provider
        self.__llm_config = llm_config

    @step(entry=True)
    async def run(self, spec: SpecialistSpec) -> SpecialistResult:
        response = await self.__provider.call(
            LLMRequest(
                model=self.__llm_config.model,
                system=[SystemMessage(blocks=[TextBlock(text=self.system_prompt)])],
                messages=[UserMessage(blocks=[TextBlock(text=spec.task)])],
            )
        )
        text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
        return SpecialistResult(response=text)


class PoetAgent(_SpecialistAgent):
    system_prompt = POET_PROMPT


class MathTutorAgent(_SpecialistAgent):
    system_prompt = MATH_TUTOR_PROMPT


# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are a helpful assistant with access to specialist agents.

When the user asks for a poem or anything creative/literary, use the "poet" tool.
When the user asks about math, use the "math_tutor" tool.
For anything else, respond directly.

After receiving a specialist's result, present it nicely to the user.
"""


def _format_usage(usage: Usage) -> str:
    parts = [f"{usage.input_tokens} in, {usage.output_tokens} out"]
    if usage.cost_usd is not None:
        parts.append(f"${usage.cost_usd:.4f}")
    return " | ".join(parts)


async def main(model_key: str, single_input: str | None = None) -> None:
    router = create_router()

    poet_tool = make_agent_tool(PoetAgent, name="poet", description="Write a short poem on a given topic")
    math_tool = make_agent_tool(
        MathTutorAgent, name="math_tutor", description="Explain a math concept or solve a problem step by step"
    )

    llm_config = LLMConfig(model=model_key)

    def on_before_tool_call(event: Event[BeforeToolCallEvent]) -> None:
        tool_use = event.data.tool_use
        input_str = json.dumps(tool_use.input, ensure_ascii=False)
        print(f"  \033[36m⚡ calling tool \033[1m{tool_use.name}\033[0m\033[36m({input_str})\033[0m")

    def on_after_tool_call(event: Event[AfterToolCallEvent]) -> None:
        result = event.data.result
        preview = result.content[:200]
        if result.is_error:
            print(f"  \033[31m✗ error: {preview}\033[0m")
        else:
            print(f"  \033[32m✓ result: {preview}\033[0m")

    async with await ToolRegistry.create([poet_tool, math_tool]) as registry:
        config = ChatConfig(
            llm_config=llm_config,
            system=[SystemMessage(blocks=[TextBlock(text=SYSTEM_PROMPT)])],
            max_llm_calls=5,
        )

        runtime = AgentRuntime(
            agents={
                "chat": ChatAgent,
                "poet": PoetAgent,
                "math_tutor": MathTutorAgent,
            },
            services={
                ToolRegistry: registry,
                ChatConfig: config,
                LLMProvider: router,
                LLMConfig: llm_config,
            },
        )
        runtime.hooks.on(BeforeToolCallEvent, on_before_tool_call)
        runtime.hooks.on(AfterToolCallEvent, on_after_tool_call)

        if single_input:
            print(f"\n> {single_input}")
            result = await runtime.run(agent=ChatAgent, spec=ChatSpec(user_message=single_input))
            if isinstance(result, ChatResult) and result.response:
                print(f"\n{result.response}")
                if result.usage:
                    print(f"\n({_format_usage(result.usage)})")
            return

        print("Agent-as-tool demo. Type 'quit' to exit.")
        print("Try: 'Write a poem about autumn' or 'Explain what a derivative is'\n")

        while True:
            try:
                text = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not text or text.lower() in ("quit", "exit"):
                break

            result = await runtime.run(agent=ChatAgent, spec=ChatSpec(user_message=text))
            if isinstance(result, ChatResult) and result.response:
                print(f"\n{result.response}")
                if result.usage:
                    print(f"\n({_format_usage(result.usage)})")
            print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Agent-as-tool demo")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--input", dest="single_input", default=None)
    args = parser.parse_args()

    asyncio.run(main(model_key=args.model, single_input=args.single_input))
