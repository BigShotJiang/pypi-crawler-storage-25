"""LLM observability events — spans and streaming deltas."""

import dataclasses

from ...llm import LLMRequest, LLMResponse, ToolResultBlock, ToolUseBlock
from ...tools import ToolErrorKind

__all__ = [
    "LLMCallSpan",
    "TextDeltaEvent",
    "ThinkingDeltaEvent",
    "ToolCallSpan",
]


# -- Span types (span-hooks: guaranteed enter/exit) --


# Mutable: request set at open, response set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class LLMCallSpan:
    request: LLMRequest
    response: LLMResponse | None = None


# Mutable: tool_use set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class ToolCallSpan:
    tool_use: ToolUseBlock
    result: ToolResultBlock | None = None
    error_kind: ToolErrorKind | None = None


# -- Streaming events (regular hooks: observation-only) --


@dataclasses.dataclass(slots=True, kw_only=True)
class TextDeltaEvent:
    """Emitted during streaming for each text chunk.

    Observation-only — use for real-time text display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


@dataclasses.dataclass(slots=True, kw_only=True)
class ThinkingDeltaEvent:
    """Emitted during streaming for each thinking chunk.

    Observation-only — use for real-time thinking display.
    Registering a handler enables streaming mode automatically.
    """

    text: str
