import dataclasses
from typing import Any

from ...llm import Usage

__all__ = ["ChatResult", "ChatSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatSpec:
    user_message: str
    metadata: dict[str, Any] | None = None

    def __preview__(self) -> str:
        return self.user_message


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChatResult:
    response: str | None = None
    usage: Usage | None = None

    def __preview__(self) -> str:
        return self.response or ""
