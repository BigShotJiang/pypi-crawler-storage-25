# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.

import dataclasses

from ...llm import AssistantMessage, UserMessage

__all__ = [
    "SaveHistoryEvent",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class SaveHistoryEvent:
    """Emitted before messages are saved to conversation history.

    Replace ``messages`` to control what gets persisted — e.g. filter out
    transient messages injected by hooks.
    """

    messages: list[UserMessage | AssistantMessage]
