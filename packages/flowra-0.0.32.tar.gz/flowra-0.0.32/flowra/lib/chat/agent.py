from typing import ClassVar

from ...agent import (
    Agent,
    AgentDefinitionRef,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    HookEmitter,
    ServiceLocator,
    Spawn,
    step,
)
from ...llm import AssistantMessage, TextBlock, UserMessage
from ..tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopResult, ToolLoopSpec
from .config import ChatConfig
from .hook_events import SaveHistoryEvent
from .spec import ChatResult, ChatSpec

__all__ = ["ChatAgent"]


class ChatAgent(Agent[ChatSpec, ChatResult]):
    __slots__ = ("__config", "__emitter", "__history")
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "tool_loop": ToolLoopAgent,
    }

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        config: ChatConfig,
        emitter: HookEmitter,
    ) -> None:
        self.__history = store.slot(AppendOnlyList[UserMessage | AssistantMessage], "history")
        self.__config = config
        self.__emitter = emitter
        services.provide(
            ToolLoopConfig(
                llm_config=config.llm_config,
                system=config.system,
                history=self.__history.get_all,
                json_schema=config.json_schema,
                allowed_tools=config.allowed_tools,
                denied_tools=config.denied_tools,
                max_llm_calls=config.max_llm_calls,
                max_consecutive_errors=config.max_consecutive_errors,
            ),
        )

    @step("process_message", entry=True)
    async def process_message(self, spec: ChatSpec) -> Spawn:
        return Spawn(
            children=[
                CallAgent(
                    agent=ToolLoopAgent,
                    spec=ToolLoopSpec(user_message=spec.user_message, metadata=spec.metadata),
                ),
            ],
            then=self.collect_result,
        )

    @step("collect_result")
    async def collect_result(self, result: ToolLoopResult) -> ChatResult:
        messages = list(result.messages)
        event = await self.__emitter.emit(SaveHistoryEvent(messages=messages))
        self.__history.extend(m for m in event.messages if not m.transient)

        response: str | None = None
        if result.result_message is not None:
            texts = [block.text for block in result.result_message.blocks if isinstance(block, TextBlock)]
            if texts:
                response = "\n".join(texts)

        return ChatResult(response=response, usage=result.usage)
