"""MCP connection - pure httpx + asyncio, no anyio dependency.

Implements MCP Streamable HTTP transport (JSON-RPC 2.0 over HTTP POST)
with background tool list polling and automatic reconnect.
"""

import asyncio
import contextlib
import json
import logging
import random
from collections.abc import Callable
from typing import Any, Self

import httpx

from .types import ToolDefinition, ToolErrorKind, ToolResult

__all__ = ["McpConnection"]

logger = logging.getLogger(__name__)

_PERIODIC_REFRESH_TIMEOUT = 60.0
_UNKNOWN_TOOL_PATTERN = "unknown tool"
_INVALID_PARAMS = -32602
_PROTOCOL_VERSION = "2025-03-26"


class McpConnection:
    """Manages a connection to a remote MCP server via Streamable HTTP.

    Pure httpx + asyncio — no anyio, no mcp SDK.
    Automatically reconnects on connection/HTTP errors.
    """

    __slots__ = (
        "__client",
        "__next_token",
        "__on_tools_changed",
        "__reconnect_lock",
        "__refresh_event",
        "__refresh_task",
        "__removed_tools",
        "__session_id",
        "__tools",
        "__url",
    )

    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        url: str,
        session_id: str | None,
        tools: dict[str, ToolDefinition],
    ) -> None:
        self.__client = client
        self.__url = url
        self.__session_id = session_id
        self.__tools = tools
        self.__on_tools_changed: dict[int, Callable[[], None]] = {}
        self.__next_token = 0
        self.__removed_tools: set[str] = set()
        self.__reconnect_lock = asyncio.Lock()
        self.__refresh_event = asyncio.Event()
        self.__refresh_task = asyncio.create_task(self.__background_refresh_loop())

    def add_on_tools_changed(self, callback: Callable[[], None]) -> int:
        token = self.__next_token
        self.__next_token += 1
        self.__on_tools_changed[token] = callback
        return token

    def remove_on_tools_changed(self, token: int) -> None:
        self.__on_tools_changed.pop(token, None)

    @classmethod
    async def connect(cls, url: str, headers: dict[str, str] | None = None) -> Self:
        logger.info("Connecting to MCP server: %s", url)
        client = httpx.AsyncClient(headers=headers or {}, timeout=httpx.Timeout(30.0))
        try:
            session_id, tools = await cls.__handshake(client, url)
            tool_names = sorted(tools.keys())
            logger.info("MCP connected: url=%s, session_id=%s, %d tools: %s", url, session_id, len(tools), tool_names)
            return cls(client=client, url=url, session_id=session_id, tools=tools)
        except BaseException:
            logger.exception("Failed to connect to MCP server: %s", url)
            await client.aclose()
            raise

    async def close(self) -> None:
        logger.info("Closing MCP connection: url=%s, session_id=%s", self.__url, self.__session_id)
        self.__refresh_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await self.__refresh_task
        try:
            await self.__client.aclose()
        except Exception:
            logger.exception("Failed to close httpx client for %s", self.__url)
        logger.info("MCP connection closed: url=%s", self.__url)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    def get_tools(self) -> list[ToolDefinition]:
        return [tool for tool in self.__tools.values() if tool.name not in self.__removed_tools]

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        if name not in self.__tools or name in self.__removed_tools:
            logger.warning("call_tool called with unknown/removed tool: %s (url=%s)", name, self.__url)
            return ToolResult(content=f"Unknown tool: {name}", is_error=True, error_kind=ToolErrorKind.UNKNOWN_TOOL)

        logger.info("Calling MCP tool: %s (url=%s, session_id=%s)", name, self.__url, self.__session_id)

        result = await self.__try_call_tool(name, arguments)
        if result is not None:
            return result

        # First call failed with HTTP error — try reconnect and retry once
        if not await self.__reconnect():
            return ToolResult(
                content=f"Tool '{name}' is temporarily unavailable, please try again later",
                is_error=True,
                error_kind=ToolErrorKind.EXECUTION,
            )

        logger.info(
            "Retrying MCP tool after reconnect: %s (url=%s, session_id=%s)", name, self.__url, self.__session_id
        )

        result = await self.__try_call_tool(name, arguments)
        if result is not None:
            return result

        return ToolResult(
            content=f"Tool '{name}' is temporarily unavailable, please try again later",
            is_error=True,
            error_kind=ToolErrorKind.EXECUTION,
        )

    async def __reconnect(self) -> bool:
        """Re-establish MCP session. Returns True on success. Serialized by lock."""
        async with self.__reconnect_lock:
            old_session_id = self.__session_id
            logger.info("Attempting MCP reconnect: url=%s, old_session_id=%s", self.__url, old_session_id)
            try:
                session_id, tools = await self.__handshake(self.__client, self.__url)
                self.__session_id = session_id
                self.__tools = tools
                self.__removed_tools.clear()
                tool_names = sorted(tools.keys())
                logger.info(
                    "MCP reconnected: url=%s, new_session_id=%s, %d tools: %s",
                    self.__url,
                    session_id,
                    len(tools),
                    tool_names,
                )
                return True
            except Exception:
                logger.exception("MCP reconnect failed: url=%s", self.__url)
                return False

    async def __try_call_tool(self, name: str, arguments: dict[str, Any] | None) -> ToolResult | None:
        """Returns ToolResult on success/app-level error, None on HTTP/connection error."""
        try:
            _, response = await self.__jsonrpc_post(
                self.__client,
                self.__url,
                self.__session_id,
                "tools/call",
                {"name": name, "arguments": arguments or {}},
            )
        except (httpx.HTTPStatusError, httpx.HTTPError) as e:
            logger.error("HTTP error calling MCP tool %s (url=%s): %s", name, self.__url, e)
            return None

        if "error" in response:
            error = response["error"]
            error_code = error.get("code")
            error_message = error.get("message", error)
            logger.warning(
                "MCP tool %s returned JSON-RPC error: code=%s, message=%s (url=%s)",
                name,
                error_code,
                error_message,
                self.__url,
            )
            if error_code == _INVALID_PARAMS:
                logger.warning("Removing tool %s due to invalid params error (url=%s)", name, self.__url)
                self.__removed_tools.add(name)
                self.__refresh_event.set()
                return ToolResult(content=str(error_message), is_error=True, error_kind=ToolErrorKind.UNKNOWN_TOOL)

            return ToolResult(content=str(error_message), is_error=True, error_kind=ToolErrorKind.EXECUTION)

        result = response.get("result", {})
        content_parts: list[str] = []
        for block in result.get("content", []):
            if block.get("type") == "text":
                content_parts.append(block.get("text", ""))
            else:
                content_parts.append(str(block))

        content = "\n".join(content_parts)
        is_error = bool(result.get("isError", False))

        if is_error and _UNKNOWN_TOOL_PATTERN in content.lower():
            logger.warning("Removing tool %s due to 'unknown tool' response (url=%s)", name, self.__url)
            self.__removed_tools.add(name)
            self.__refresh_event.set()

        if is_error:
            logger.warning("MCP tool %s returned error result: %s (url=%s)", name, content[:500], self.__url)
        else:
            logger.info("MCP tool %s succeeded (url=%s, response_length=%d)", name, self.__url, len(content))

        error_kind: ToolErrorKind | None = None
        if is_error:
            if _UNKNOWN_TOOL_PATTERN in content.lower():
                error_kind = ToolErrorKind.UNKNOWN_TOOL
            else:
                error_kind = ToolErrorKind.EXECUTION

        return ToolResult(content=content, is_error=is_error, error_kind=error_kind)

    async def __background_refresh_loop(self) -> None:
        while True:
            try:
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self.__refresh_event.wait(), timeout=_PERIODIC_REFRESH_TIMEOUT)
                self.__refresh_event.clear()

                logger.info("Refreshing MCP tools: url=%s, session_id=%s", self.__url, self.__session_id)
                _, tools_body = await self.__jsonrpc_post(
                    self.__client,
                    self.__url,
                    self.__session_id,
                    "tools/list",
                )
                if "error" not in tools_body:
                    new_tools = self.__parse_tools(tools_body.get("result", {}))
                    old_names = set(self.__tools.keys())
                    new_names = set(new_tools.keys())
                    added = new_names - old_names
                    removed = old_names - new_names
                    if added or removed:
                        logger.info(
                            "MCP tools changed (url=%s): added=%s, removed=%s",
                            self.__url,
                            sorted(added) if added else "none",
                            sorted(removed) if removed else "none",
                        )
                    else:
                        logger.info("MCP tools refreshed, no changes (url=%s, %d tools)", self.__url, len(new_tools))
                    self.__tools = new_tools
                    self.__removed_tools.clear()
                    if added or removed:
                        for callback in self.__on_tools_changed.values():
                            callback()
                else:
                    logger.warning(
                        "MCP tools/list refresh returned error (url=%s): %s",
                        self.__url,
                        tools_body["error"],
                    )
            except asyncio.CancelledError:
                raise
            except (httpx.HTTPStatusError, httpx.HTTPError):
                logger.warning("HTTP error during MCP tools refresh (url=%s), attempting reconnect", self.__url)
                await self.__reconnect()
            except Exception:
                logger.exception("Failed to refresh MCP tools (url=%s)", self.__url)

    @classmethod
    async def __handshake(
        cls,
        client: httpx.AsyncClient,
        url: str,
    ) -> tuple[str | None, dict[str, ToolDefinition]]:
        """Perform MCP initialize → initialized → tools/list sequence."""
        session_id, init_body = await cls.__jsonrpc_post(
            client,
            url,
            None,
            "initialize",
            {
                "protocolVersion": _PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "flowra", "version": "1.0.0"},
            },
        )
        if "error" in init_body:
            raise RuntimeError(f"MCP initialize failed: {init_body['error']}")

        await cls.__jsonrpc_notify(client, url, session_id, "notifications/initialized")

        session_id, tools_body = await cls.__jsonrpc_post(client, url, session_id, "tools/list")
        if "error" in tools_body:
            raise RuntimeError(f"MCP tools/list failed: {tools_body['error']}")

        tools = cls.__parse_tools(tools_body.get("result", {}))
        return session_id, tools

    @classmethod
    async def __jsonrpc_post(
        cls,
        client: httpx.AsyncClient,
        url: str,
        session_id: str | None,
        method: str,
        params: dict[str, Any] | None = None,
    ) -> tuple[str | None, dict[str, Any]]:
        request_id = random.randint(1, 2**31 - 1)

        body: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            body["params"] = params

        logger.info("JSON-RPC request: method=%s, url=%s, session_id=%s", method, url, session_id)
        response = await client.post(url, json=body, headers=cls.__build_headers(session_id))
        logger.info(
            "JSON-RPC response: method=%s, status=%d, content_type=%s",
            method,
            response.status_code,
            response.headers.get("content-type", ""),
        )
        response.raise_for_status()

        new_session_id = response.headers.get("mcp-session-id", session_id)

        content_type = response.headers.get("content-type", "")
        if "text/event-stream" in content_type:
            parsed = cls.__find_jsonrpc_response_in_sse(response.text, request_id)
        else:
            parsed = response.json()

        return new_session_id, parsed

    @classmethod
    async def __jsonrpc_notify(
        cls,
        client: httpx.AsyncClient,
        url: str,
        session_id: str | None,
        method: str,
    ) -> None:
        body: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        logger.info("JSON-RPC notify: method=%s, url=%s, session_id=%s", method, url, session_id)
        response = await client.post(url, json=body, headers=cls.__build_headers(session_id))
        logger.info("JSON-RPC notify response: method=%s, status=%d", method, response.status_code)
        if response.status_code not in (200, 202, 204):
            response.raise_for_status()

    @staticmethod
    def __build_headers(session_id: str | None) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if session_id is not None:
            headers["Mcp-Session-Id"] = session_id
        return headers

    @staticmethod
    def __find_jsonrpc_response_in_sse(text: str, request_id: int) -> dict[str, Any]:
        data_lines: list[str] = []
        for line in text.split("\n"):
            if line.startswith("data:"):
                data_lines.append(line[5:].strip())
            elif line == "" and data_lines:
                data = "\n".join(data_lines)
                data_lines.clear()
                try:
                    msg = json.loads(data)
                    if isinstance(msg, dict) and msg.get("id") == request_id:
                        return msg
                except json.JSONDecodeError:
                    continue
        if data_lines:
            data = "\n".join(data_lines)
            try:
                msg = json.loads(data)
                if isinstance(msg, dict) and msg.get("id") == request_id:
                    return msg
            except json.JSONDecodeError:
                pass
        raise RuntimeError(f"No JSON-RPC response for id={request_id} in SSE stream")

    @staticmethod
    def __parse_tools(result: dict[str, Any]) -> dict[str, ToolDefinition]:
        tools: dict[str, ToolDefinition] = {}
        for tool in result.get("tools", []):
            name = tool["name"]
            tools[name] = ToolDefinition(
                name=name,
                description=tool.get("description", ""),
                input_schema=tool.get("inputSchema"),
                output_schema=tool.get("outputSchema"),
            )
        return tools
