import dataclasses
from collections.abc import Callable
from typing import Any

from .local_tool import LocalTool, get_local_tool

__all__ = ["LocalToolGroup", "McpToolGroup", "ToolGroup", "create_local_tool_group"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LocalToolGroup:
    prefix: str | None = None
    tools: list[LocalTool]

    def __post_init__(self) -> None:
        names = [t.definition.name for t in self.tools]
        duplicates = {n for n in names if names.count(n) > 1}
        if duplicates:
            raise ValueError(f"Duplicate tool names: {sorted(duplicates)}")


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class McpToolGroup:
    prefix: str | None = None
    url: str = ""
    headers: dict[str, str] | None = None


type ToolGroup = LocalToolGroup | McpToolGroup


def create_local_tool_group(
    handlers: list[Callable[..., Any]],
    *,
    prefix: str | None = None,
) -> LocalToolGroup:
    tools = [get_local_tool(h) for h in handlers]
    return LocalToolGroup(prefix=prefix, tools=tools)
