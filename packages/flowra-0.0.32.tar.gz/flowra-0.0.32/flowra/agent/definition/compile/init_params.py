import dataclasses
import types
from typing import Annotated, Any, Union, get_args, get_origin

from .. import agent_arg
from .type_helpers import extract_service_type, get_type_hints, is_nullable

__all__ = ["InitParam", "compile_init"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class InitParam:
    name: str
    service_type: type
    nullable: bool = False
    is_spec: bool = False
    has_explicit_marker: bool = False


def compile_init(agent_cls: type) -> tuple[InitParam, ...]:
    """Extract __init__ parameters as service dependencies."""
    hints = get_type_hints(agent_cls.__init__)
    params: list[InitParam] = []
    for name, resolved in hints.items():
        if name == "return":
            continue
        explicit_marker = _find_agent_marker(resolved)
        service_type = extract_service_type(resolved)
        if service_type is not None:
            params.append(
                InitParam(
                    name=name,
                    service_type=service_type,
                    nullable=is_nullable(resolved),
                    is_spec=explicit_marker is agent_arg.SPEC,
                    has_explicit_marker=explicit_marker is not None,
                )
            )
    return tuple(params)


def _find_agent_marker(hint: Any) -> Any:
    """Find an agent_arg marker in an Annotated type hint."""
    if get_origin(hint) is Annotated:
        args = get_args(hint)
        for meta in args[1:]:
            if _is_agent_marker(meta):
                return meta
    if isinstance(hint, types.UnionType) or get_origin(hint) is Union:
        for arg in get_args(hint):
            if arg is type(None):
                continue
            if get_origin(arg) is Annotated:
                inner_args = get_args(arg)
                for meta in inner_args[1:]:
                    if _is_agent_marker(meta):
                        return meta
    return None


def _is_agent_marker(meta: Any) -> bool:
    return meta is agent_arg.SPEC or meta is agent_arg.SERVICE
