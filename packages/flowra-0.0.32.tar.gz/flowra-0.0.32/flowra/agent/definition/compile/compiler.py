import dataclasses
from typing import Any

from ...services import ServiceLocator
from ..model import AbstractAgent, AgentDefinition, AgentDefinitionRef, AgentInstance
from .contract import extract_agent_contract
from .init_params import compile_init
from .instance import create_instance
from .steps import compile_steps
from .type_registry import build_type_registry

__all__ = ["compile_agent"]


def compile_agent(
    agent_cls: type,
    subagents: dict[str, AgentDefinitionRef] | None = None,
) -> AgentDefinition:
    init_params = compile_init(agent_cls)
    compiled_steps, step_metas = compile_steps(agent_cls)
    entry_step, agent_spec_types, agent_result_types = extract_agent_contract(agent_cls, step_metas)
    type_registry = build_type_registry(agent_cls, agent_spec_types, agent_result_types)

    init_params = tuple(
        dataclasses.replace(ip, is_spec=True)
        if not ip.has_explicit_marker and not ip.is_spec and ip.service_type in agent_spec_types
        else ip
        for ip in init_params
    )

    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        return create_instance(agent_cls, init_params, compiled_steps, sl, agent_spec)

    return AgentDefinition(
        steps=step_metas,
        type_registry=type_registry,
        create_instance=create,
        subagents=subagents or {},
        entry_step=entry_step,
        spec_types=agent_spec_types,
        result_types=agent_result_types,
        source_type=agent_cls if issubclass(agent_cls, AbstractAgent) else None,
    )
