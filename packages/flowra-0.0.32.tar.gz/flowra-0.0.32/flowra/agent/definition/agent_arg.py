"""Annotated markers for agent constructor parameter binding.

Usage::

    from flowra.agent import agent_arg

    class Researcher(Agent[ResearchSpec, ResearchResult]):
        def __init__(
            self,
            spec: Annotated[ResearchSpec, agent_arg.SPEC],
            sl: Annotated[ServiceLocator, agent_arg.SERVICE],
        ) -> None: ...
"""

__all__ = [
    "SERVICE",
    "SPEC",
]

SPEC = object()
SERVICE = object()
