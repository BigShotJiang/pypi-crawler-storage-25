import abc
import dataclasses
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

__all__ = ["ChangeSet", "SessionStorage"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChangeSet:
    scalars: dict[str, Any]
    appends: dict[str, list[Any]]

    @property
    def empty(self) -> bool:
        return not self.scalars and not self.appends


class SessionStorage(abc.ABC):
    __slots__ = ()

    @abc.abstractmethod
    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        yield  # pragma: no cover

    @abc.abstractmethod
    async def save_execution(self, execution: dict[str, Any]) -> None: ...

    @abc.abstractmethod
    async def has_execution(self) -> bool: ...

    @abc.abstractmethod
    async def load_execution(self) -> dict[str, Any] | None: ...

    @abc.abstractmethod
    async def clear_execution(self) -> None: ...

    @abc.abstractmethod
    async def save_node_state(self, key: str, changes: ChangeSet) -> None: ...

    @abc.abstractmethod
    async def load_node_state(self, key: str) -> dict[str, Any] | None: ...
