import abc
import asyncio
import dataclasses

__all__ = [
    "InterruptControl",
    "InterruptToken",
    "InterruptTokenSource",
    "Interrupted",
    "InterruptedError",
]


class InterruptedError(Exception):
    """Raised when an operation is interrupted via :class:`InterruptToken`."""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Interrupted:
    """Typed result returned when an agent is interrupted.

    Flows through the execution tree as a normal result.
    Parent can handle it via step_arg.CHILD binding or let it auto-propagate.
    """


class InterruptToken(abc.ABC):
    __slots__ = ()

    @property
    @abc.abstractmethod
    def interrupted(self) -> bool: ...

    @abc.abstractmethod
    async def wait(self) -> None:
        """Block until interrupted. Returns immediately if already interrupted."""

    def check(self) -> None:
        """Raise :exc:`InterruptedError` if the token has been interrupted."""
        if self.interrupted:
            raise InterruptedError


class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("children", "event", "is_interrupted", "parent")

    def __init__(self) -> None:
        self.is_interrupted = False
        self.event = asyncio.Event()
        self.children: list[_InterruptTokenImpl] = []
        self.parent: _InterruptTokenImpl | None = None

    @property
    def interrupted(self) -> bool:
        return self.is_interrupted

    async def wait(self) -> None:
        await self.event.wait()

    def set(self) -> None:
        self.is_interrupted = True
        self.event.set()
        for child in self.children:
            child.set()

    def clear(self) -> None:
        self.is_interrupted = False
        self.event.clear()


class InterruptTokenSource:
    __slots__ = ("__token",)

    def __init__(self) -> None:
        self.__token = _InterruptTokenImpl()

    @property
    def token(self) -> InterruptToken:
        return self.__token

    def interrupt(self) -> None:
        self.__token.set()

    def clear(self) -> None:
        self.__token.clear()

    def create_child(self) -> "InterruptTokenSource":
        child = InterruptTokenSource()
        parent_impl = self.__token
        child_impl = child.__token
        parent_impl.children.append(child_impl)
        child_impl.parent = parent_impl
        if parent_impl.is_interrupted:
            child_impl.set()
        return child

    def interrupt_children(self) -> None:
        for child in self.__token.children:
            child.set()

    def dispose(self) -> None:
        impl = self.__token
        if impl.parent is not None:
            impl.parent.children.remove(impl)
            impl.parent = None


class InterruptControl:
    """Delegated interrupt capability — act, but don't own.

    Injected into agents via DI. Allows interrupting this agent's
    execution (self + children) or only its spawned children.
    """

    __slots__ = ("__source",)

    def __init__(self, source: InterruptTokenSource) -> None:
        self.__source = source

    def interrupt(self) -> None:
        """Interrupt this agent and all its children."""
        self.__source.interrupt()

    def interrupt_children(self) -> None:
        """Interrupt only spawned children, not this agent.

        Only affects children created via Spawn — call after the engine
        has processed the Spawn (i.e. from a tool or hook, not from __init__).
        """
        self.__source.interrupt_children()
