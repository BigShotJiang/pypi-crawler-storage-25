import logging
from collections.abc import Awaitable, Callable
from typing import Any, get_args, get_origin

from ..services import ServiceLocator
from ..state import AgentStore, AppendOnlyList, Scalar
from ..storage import ChangeSet

logger = logging.getLogger(__name__)

__all__ = ["FlushCallback", "RuntimeScope"]

type FlushCallback = Callable[[], Awaitable[None]]


class RuntimeScope(AgentStore, ServiceLocator):
    __slots__ = (
        "__append_only_lists",
        "__flush_callback",
        "__parent_services",
        "__scalars",
        "__services",
        "__slot_value_types",
    )

    def __init__(
        self,
        parent_services: dict[type, Any] | None = None,
    ) -> None:
        self.__parent_services: dict[type, Any] = parent_services or {}
        self.__services: dict[type, Any] = {}
        self.__scalars: dict[str, Scalar] = {}
        self.__append_only_lists: dict[str, AppendOnlyList] = {}
        self.__flush_callback: FlushCallback | None = None
        self.__slot_value_types: dict[str, type] = {}

    def slot(self, cls: Any, key: str) -> Any:
        origin = get_origin(cls) or cls
        args = get_args(cls)
        if origin is Scalar:
            if args:
                self.__slot_value_types[key] = args[0]
            return self.__create_scalar(key)
        if origin is AppendOnlyList:
            if args:
                self.__slot_value_types[key] = args[0]
            return self.__create_append_only(key)
        raise TypeError(f"slot() cls must be Scalar[T] or AppendOnlyList[T], got {cls!r}")

    def get_slot_value_types(self) -> dict[str, type]:
        return dict(self.__slot_value_types)

    def __create_scalar(self, key: str) -> Scalar:
        if key in self.__scalars:
            return self.__scalars[key]
        value: Scalar = Scalar()
        self.__scalars[key] = value
        return value

    def __create_append_only(self, key: str) -> AppendOnlyList:
        if key in self.__append_only_lists:
            return self.__append_only_lists[key]
        al: AppendOnlyList = AppendOnlyList()
        self.__append_only_lists[key] = al
        return al

    def _do_provide(self, service_type: type, instance: Any) -> None:
        if not isinstance(instance, service_type):
            raise TypeError(f"Expected instance of {service_type.__name__}, got {type(instance).__name__}")
        self.__services[service_type] = instance

    async def flush(self) -> None:
        if self.__flush_callback is not None:
            await self.__flush_callback()

    @property
    def services(self) -> dict[type, Any]:
        return self.get_services()

    def get_services(self) -> dict[type, Any]:
        return {**self.__parent_services, **self.__services}

    def get_inherited_services(self) -> dict[type, Any]:
        return dict(self.__parent_services)

    def set_flush_callback(self, callback: FlushCallback) -> None:
        self.__flush_callback = callback

    def fork(self, parent_services: dict[type, Any] | None = None) -> "RuntimeScope":
        child = RuntimeScope(parent_services=parent_services)
        for key, sv in self.__scalars.items():
            child_sv: Scalar = Scalar()
            if sv.has_value():
                child_sv.restore(sv.get())
            child.__scalars[key] = child_sv
        for key, al in self.__append_only_lists.items():
            child_al: AppendOnlyList = AppendOnlyList()
            child_al.restore(al.get_all())
            child.__append_only_lists[key] = child_al
        return child

    def get_changes(self) -> ChangeSet:
        scalars: dict[str, Any] = {}
        appends: dict[str, list[Any]] = {}
        for key, sv in self.__scalars.items():
            if sv.is_dirty():
                scalars[key] = sv.get()
        for key, al in self.__append_only_lists.items():
            unflushed = al.get_unflushed()
            if unflushed:
                appends[key] = unflushed
        return ChangeSet(scalars=scalars, appends=appends)

    def mark_clean(self) -> None:
        for sv in self.__scalars.values():
            sv.mark_clean()
        for al in self.__append_only_lists.values():
            al.mark_clean()

    def snapshot(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        for key, sv in self.__scalars.items():
            if sv.has_value():
                data[key] = sv.get()
        for key, al in self.__append_only_lists.items():
            data[key] = al.get_all()
        return data

    def hydrate(self, data: dict[str, Any]) -> None:
        for key, value in data.items():
            if key in self.__scalars:
                self.__scalars[key].restore(value)
            elif key in self.__append_only_lists:
                self.__append_only_lists[key].restore(value)
            else:
                logger.warning("hydrate: unknown key %r (not declared as scalar or append_only), skipping", key)
