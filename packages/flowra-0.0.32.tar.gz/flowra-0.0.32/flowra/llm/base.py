import dataclasses
from typing import Any, ClassVar

__all__ = ["LLMData", "ProviderExtra"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMData:
    metadata: dict[str, Any] = dataclasses.field(default_factory=dict)
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
    transient: bool = False


class ProviderExtra:
    """Base class for typed provider extra views.

    Subclass in each provider module to define the extra contract.
    Wraps a mutable dict inside ``LLMData.extra[KEY]``.
    """

    __slots__ = ("__data",)

    KEY: ClassVar[str]

    def __init__(self, obj: LLMData) -> None:
        self.__data: dict[str, Any] = obj.extra.setdefault(self.KEY, {})

    @classmethod
    def raw(cls, obj: LLMData) -> dict[str, Any]:
        return obj.extra.get(cls.KEY, {})

    def _get(self, key: str, default: Any = None) -> Any:  # Any: provider-specific JSON values
        return self.__data.get(key, default)

    def _set(self, key: str, value: Any) -> None:  # Any: provider-specific JSON values
        if value is None:
            self.__data.pop(key, None)
        else:
            self.__data[key] = value
