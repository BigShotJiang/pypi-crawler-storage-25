import base64
import dataclasses
import json
import re
from collections.abc import AsyncIterator
from typing import Any, ClassVar

import marshmallow_recipe as mr
from anthropic import AsyncAnthropicVertex, omit
from anthropic.types import Message as AnthropicMessage, StopReason as AnthropicStopReason, Usage as AnthropicUsage
from google.oauth2 import service_account

from ..base import ProviderExtra
from ..blocks import AssistantBlock, MediaBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock, UserBlock
from ..messages import AssistantMessage, SystemMessage, UserMessage
from ..pricing import estimate_cost as pricing_estimate_cost
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description, format_schema_for_llm
from ..schema_validation import validate_json_schema
from ..stream import ContentComplete, StreamEvent, TextDelta, ThinkingDelta
from ..tools import Tool

__all__ = [
    "ANTHROPIC_EXTRA_KEY",
    "AnthropicBlockExtra",
    "AnthropicCacheable",
    "AnthropicToolExtra",
    "AnthropicVertexAdditionalConfig",
    "AnthropicVertexProvider",
]

ANTHROPIC_EXTRA_KEY = "anthropic"


class AnthropicCacheable(ProviderExtra):
    """Cache control for any Anthropic-compatible LLMData object (tools or blocks)."""

    __slots__ = ()
    KEY: ClassVar[str] = ANTHROPIC_EXTRA_KEY

    @property
    def cache_control(self) -> dict[str, str] | None:
        return self._get("cache_control")

    @cache_control.setter
    def cache_control(self, value: dict[str, str] | None) -> None:
        self._set("cache_control", value)


class AnthropicToolExtra(ProviderExtra):
    __slots__ = ()
    KEY: ClassVar[str] = ANTHROPIC_EXTRA_KEY

    def __init__(self, obj: Tool) -> None:
        super().__init__(obj)

    @property
    def defer_loading(self) -> bool:
        return self._get("defer_loading", False)

    @defer_loading.setter
    def defer_loading(self, value: bool) -> None:
        self._set("defer_loading", value or None)

    @property
    def type(self) -> str | None:
        return self._get("type")

    @type.setter
    def type(self, value: str | None) -> None:
        self._set("type", value)


class AnthropicBlockExtra(ProviderExtra):
    __slots__ = ()
    KEY: ClassVar[str] = ANTHROPIC_EXTRA_KEY

    def __init__(self, obj: UserBlock | AssistantBlock) -> None:
        super().__init__(obj)

    @property
    def signature(self) -> str | None:
        return self._get("signature")

    @signature.setter
    def signature(self, value: str | None) -> None:
        self._set("signature", value)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AnthropicVertexAdditionalConfig:
    thinking_budget_tokens: int | None = None


class AnthropicVertexProvider(LLMProvider):
    __slots__ = ("__client", "__owns_client")

    __TOOL_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,128}$")

    __USAGE_KNOWN_FIELDS: ClassVar[set[str]] = {
        "input_tokens",
        "output_tokens",
        "cache_read_input_tokens",
        "cache_creation_input_tokens",
        "cache_creation",
    }

    def __init__(
        self,
        *,
        client: AsyncAnthropicVertex | None = None,
        project: str | None = None,
        location: str | None = None,
        credentials: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            self.__client = client
            self.__owns_client = owns_client
        elif project and location and credentials:
            self.__client = self.__create_client(project=project, location=location, credentials=credentials)
            self.__owns_client = True
        else:
            raise ValueError("Either 'client' or all of 'project', 'location', 'credentials' must be provided")

    async def aclose(self) -> None:
        if self.__owns_client:
            await self.__client.close()

    @staticmethod
    def __create_client(*, project: str, location: str, credentials: str) -> AsyncAnthropicVertex:
        creds_json = base64.b64decode(credentials.encode()).decode()
        creds_info = json.loads(creds_json)
        google_creds = service_account.Credentials.from_service_account_info(creds_info)
        google_creds = google_creds.with_scopes(["https://www.googleapis.com/auth/cloud-platform"])
        return AsyncAnthropicVertex(region=location, project_id=project, credentials=google_creds)

    async def call(self, request: LLMRequest) -> LLMResponse:
        response = await self.__call_llm(request)

        if request.json_schema is None or response.stop_reason != StopReason.END_TURN:
            return response

        # Validate + retry loop
        messages = list(request.messages)
        total_usage = response.usage

        for _attempt in range(request.max_schema_retries):
            text = self.__extract_text(response)
            error, cleaned = validate_json_schema(text, request.json_schema)
            if error is None:
                return LLMResponse(
                    message=self.__make_schema_message(cleaned),
                    stop_reason=response.stop_reason,
                    stop_sequence=response.stop_sequence,
                    usage=total_usage,
                )

            # Retry: append assistant response + validation error as user message
            messages.append(response.message)
            messages.append(
                UserMessage(
                    blocks=[
                        TextBlock(
                            text=f"Your response is not valid JSON conforming to the required schema.\n{error}\n"
                            f"Please fix and return ONLY the raw JSON object, without markdown code fences.",
                        )
                    ]
                )
            )
            retry_request = dataclasses.replace(request, messages=messages)
            response = await self.__call_llm(retry_request)
            if response.usage is not None and total_usage is not None:
                total_usage = total_usage + response.usage
            elif response.usage is not None:
                total_usage = response.usage

            if response.stop_reason != StopReason.END_TURN:
                return LLMResponse(
                    message=response.message,
                    stop_reason=response.stop_reason,
                    stop_sequence=response.stop_sequence,
                    usage=total_usage,
                )

        # Validate the final retry response
        text = self.__extract_text(response)
        error, cleaned = validate_json_schema(text, request.json_schema)
        if error is None:
            return LLMResponse(
                message=self.__make_schema_message(cleaned),
                stop_reason=response.stop_reason,
                stop_sequence=response.stop_sequence,
                usage=total_usage,
            )

        return LLMResponse(
            message=response.message,
            stop_reason=StopReason.SCHEMA_VALIDATION_FAILED,
            stop_sequence=response.stop_sequence,
            usage=total_usage,
        )

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        if request.json_schema is not None:
            # JSON schema needs retry loop — fall back to non-streaming
            response = await self.call(request)
            yield ContentComplete(response=response)
            return

        kwargs = self.__build_kwargs(request)

        async with self.__client.messages.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "content_block_delta":
                    if event.delta.type == "text_delta":
                        yield TextDelta(text=event.delta.text)
                    elif event.delta.type == "thinking_delta":
                        yield ThinkingDelta(text=event.delta.thinking)

            response = await api_stream.get_final_message()

        yield ContentComplete(response=self.__convert_response(response, request.model))

    async def __call_llm(self, request: LLMRequest) -> LLMResponse:
        kwargs = self.__build_kwargs(request)
        response = await self.__client.messages.create(**kwargs)
        return self.__convert_response(response, request.model)

    def __build_kwargs(self, request: LLMRequest) -> dict[str, Any]:
        system = self.__convert_system(request.system)

        if request.json_schema:
            schema_prompt = self.__format_schema_for_prompt(request.json_schema)
            if system is None:
                system = schema_prompt
            elif isinstance(system, str):
                system = f"{system}\n\n{schema_prompt}"
            else:
                system.append({"type": "text", "text": schema_prompt})

        anthropic_messages: list[dict[str, Any]] = [self.__convert_message(m) for m in request.messages]

        anthropic_tools: Any = omit  # omit is an untyped sentinel from the anthropic SDK
        if request.tools:
            anthropic_tools = [self.__convert_tool(tool) for tool in request.tools]

        anthropic_system: Any = omit  # omit is an untyped sentinel from the anthropic SDK
        if system:
            anthropic_system = system

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": anthropic_messages,
            "max_tokens": request.max_tokens or 4096,
            "system": anthropic_system,
            "tools": anthropic_tools,
            "temperature": request.temperature if request.temperature is not None else omit,
            "top_p": request.top_p if request.top_p is not None else omit,
            "stop_sequences": request.stop_sequences if request.stop_sequences else omit,
        }

        if request.additional_config:
            additional = mr.load(AnthropicVertexAdditionalConfig, request.additional_config)
            if additional.thinking_budget_tokens is not None:
                kwargs["thinking"] = {"type": "enabled", "budget_tokens": additional.thinking_budget_tokens}
                kwargs["temperature"] = 1  # Anthropic requirement for thinking

        return kwargs

    @staticmethod
    def __format_schema_for_prompt(schema: dict[str, Any]) -> str:
        schema_str = format_schema_for_llm(schema)
        return (
            f"You must respond with ONLY a valid JSON object that strictly conforms to this structure:\n"
            f"{schema_str}\n\n"
            f"IMPORTANT: Output ONLY the raw JSON object. "
            f"No markdown code fences, no explanations, no additional text before or after the JSON."
        )

    @classmethod
    def __convert_system(cls, system: list[SystemMessage]) -> str | list[dict[str, Any]] | None:
        system_blocks: list[TextBlock] = []
        for msg in system:
            system_blocks.extend(msg.blocks)

        if not system_blocks:
            return None

        if any(AnthropicBlockExtra.raw(b) for b in system_blocks):
            return [cls.__convert_text_block(b) for b in system_blocks]

        return "\n\n".join(b.text for b in system_blocks)

    @classmethod
    def __convert_message(cls, message: UserMessage | AssistantMessage) -> dict[str, Any]:
        match message:
            case UserMessage(blocks=blocks):
                content: list[dict[str, Any]] = []
                for block in blocks:
                    match block:
                        case TextBlock() as tb:
                            content.append(cls.__convert_text_block(tb))
                        case MediaBlock(data=data, media_type=media_type):
                            block_type = "image" if media_type.startswith("image/") else "document"
                            content.append(
                                {
                                    "type": block_type,
                                    "source": {
                                        "type": "base64",
                                        "media_type": media_type,
                                        "data": base64.b64encode(data).decode(),
                                    },
                                    **AnthropicBlockExtra.raw(block),
                                }
                            )
                        case ToolResultBlock(tool_use_id=tool_use_id, content=tool_content, is_error=is_error):
                            content.append(
                                {
                                    "type": "tool_result",
                                    "tool_use_id": tool_use_id,
                                    "content": tool_content,
                                    **({"is_error": True} if is_error else {}),
                                    **AnthropicBlockExtra.raw(block),
                                }
                            )
                return {"role": "user", "content": content}

            case AssistantMessage(blocks=blocks):
                content = []
                for block in blocks:
                    match block:
                        case TextBlock() as tb:
                            content.append(cls.__convert_text_block(tb))
                        case ToolUseBlock(id=id_, name=name, input=input_):
                            args = json.loads(input_) if isinstance(input_, str) else (input_ or {})
                            content.append(
                                {
                                    "type": "tool_use",
                                    "id": id_,
                                    "name": name,
                                    "input": args,
                                    **AnthropicBlockExtra.raw(block),
                                }
                            )
                        case ThinkingBlock(text=text):
                            content.append({"type": "thinking", "thinking": text, **AnthropicBlockExtra.raw(block)})
                return {"role": "assistant", "content": content}

    @staticmethod
    def __convert_text_block(block: TextBlock) -> dict[str, Any]:
        return {"type": "text", "text": block.text, **AnthropicBlockExtra.raw(block)}

    @classmethod
    def __convert_tool(cls, tool: Tool) -> dict[str, Any]:
        if not cls.__TOOL_NAME_RE.fullmatch(tool.name):
            raise ValueError(f"Tool name '{tool.name}' must match ^[a-zA-Z0-9_-]{{1,128}}$")

        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        return {
            "name": tool.name,
            "description": description,
            "input_schema": tool.input_schema or {"type": "object", "properties": {}},
            **AnthropicToolExtra.raw(tool),
        }

    @staticmethod
    def __convert_stop_reason(stop_reason: AnthropicStopReason | None) -> StopReason:
        match stop_reason:
            case "end_turn":
                return StopReason.END_TURN
            case "max_tokens":
                return StopReason.MAX_TOKENS
            case "tool_use":
                return StopReason.TOOL_USE
            case "stop_sequence":
                return StopReason.STOP_SEQUENCE
            case _:
                return StopReason.OTHER

    @classmethod
    def __convert_response(cls, response: AnthropicMessage, model: str) -> LLMResponse:
        blocks: list[AssistantBlock] = []
        for block in response.content:
            if block.type == "thinking":
                thinking_block = ThinkingBlock(text=block.thinking)
                AnthropicBlockExtra(thinking_block).signature = block.signature
                blocks.append(thinking_block)
            elif block.type == "text":
                blocks.append(TextBlock(text=block.text))
            elif block.type == "tool_use":
                blocks.append(ToolUseBlock(id=block.id, name=block.name, input=block.input))

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        return LLMResponse(
            message=AssistantMessage(blocks=blocks),
            stop_reason=cls.__convert_stop_reason(response.stop_reason),
            stop_sequence=response.stop_sequence,
            usage=usage,
            extra={"provider_stop_reason": response.stop_reason, "id": response.id},
        )

    @classmethod
    def __convert_usage(cls, usage_obj: AnthropicUsage, model: str) -> Usage:
        cache_read = usage_obj.cache_read_input_tokens or 0
        cache_creation_total = usage_obj.cache_creation_input_tokens or 0

        cc = usage_obj.cache_creation
        if cc:
            cache_creation_5m = cc.ephemeral_5m_input_tokens or 0
            cache_creation_1h = cc.ephemeral_1h_input_tokens or 0
        else:
            cache_creation_5m = cache_creation_total  # fallback: price at 5m rate
            cache_creation_1h = 0

        raw = usage_obj.model_dump(mode="json")
        extra: dict[str, Any] = {k: v for k, v in raw.items() if k not in cls.__USAGE_KNOWN_FIELDS and v is not None}
        if cache_creation_5m:
            extra["cache_creation_5m_input_tokens"] = cache_creation_5m
        if cache_creation_1h:
            extra["cache_creation_1h_input_tokens"] = cache_creation_1h

        cost = pricing_estimate_cost(
            model,
            provider="anthropic",
            input_tokens=usage_obj.input_tokens,
            output_tokens=usage_obj.output_tokens,
            cache_read_tokens=cache_read,
            cache_creation_tokens=cache_creation_5m,
            cache_creation_1h_tokens=cache_creation_1h,
        )
        return Usage(
            input_tokens=usage_obj.input_tokens,
            output_tokens=usage_obj.output_tokens,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_creation_total,
            cost_usd=cost.total if cost is not None else None,
            cost=cost,
            extra=extra,
        )

    @staticmethod
    def __extract_text(response: LLMResponse) -> str:
        for block in response.message.blocks:
            if isinstance(block, TextBlock):
                return block.text
        return ""

    @staticmethod
    def __make_schema_message(cleaned_text: str) -> AssistantMessage:
        return AssistantMessage(blocks=[TextBlock(text=cleaned_text)])
