import importlib
from types import ModuleType

__all__: list[str] = []

_MODULES = {"anthropic_vertex", "google_vertex", "openai", "openai_responses"}


def __getattr__(name: str) -> ModuleType:
    if name in _MODULES:
        return importlib.import_module(f".{name}", __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
