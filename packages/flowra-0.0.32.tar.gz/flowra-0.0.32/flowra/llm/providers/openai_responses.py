import base64
import json
from collections.abc import AsyncIterator
from typing import Any, ClassVar

from openai import AsyncOpenAI
from openai.types.responses import (
    Response as OpenAIResponse,
    ResponseFunctionToolCall,
    ResponseOutputMessage,
    ResponseOutputText,
)
from openai.types.responses.response_usage import ResponseUsage

from ..base import ProviderExtra
from ..blocks import AssistantBlock, MediaBlock, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, UserMessage
from ..openai_schema import make_schema_strict
from ..pricing import estimate_cost as pricing_estimate_cost
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description
from ..stream import ContentComplete, StreamEvent, TextDelta
from ..tools import Tool

__all__ = [
    "OPENAI_EXTRA_KEY",
    "OpenAIResponsesProvider",
    "OpenAIToolExtra",
]

OPENAI_EXTRA_KEY = "openai"


class OpenAIToolExtra(ProviderExtra):
    __slots__ = ()
    KEY: ClassVar[str] = OPENAI_EXTRA_KEY

    def __init__(self, obj: Tool) -> None:
        super().__init__(obj)

    @property
    def defer_loading(self) -> bool:
        return self._get("defer_loading", False)

    @defer_loading.setter
    def defer_loading(self, value: bool) -> None:
        self._set("defer_loading", value or None)

    @property
    def type(self) -> str | None:
        return self._get("type")

    @type.setter
    def type(self, value: str | None) -> None:
        self._set("type", value)


class OpenAIResponsesProvider(LLMProvider):
    """OpenAI provider using the Responses API.

    Supports all Responses API features including tool search with
    deferred tool loading. For the Chat Completions API, use
    ``OpenAIProvider`` instead.
    """

    __slots__ = ("__client", "__owns_client")

    def __init__(
        self,
        *,
        client: AsyncOpenAI | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        organization: str | None = None,
        owns_client: bool = False,
    ) -> None:
        if client is not None:
            self.__client = client
            self.__owns_client = owns_client
        elif api_key is not None:
            self.__client = AsyncOpenAI(api_key=api_key, base_url=base_url, organization=organization)
            self.__owns_client = True
        else:
            raise ValueError("Either 'client' or 'api_key' must be provided")

    async def aclose(self) -> None:
        if self.__owns_client:
            await self.__client.close()

    async def call(self, request: LLMRequest) -> LLMResponse:
        kwargs = self.__build_kwargs(request)
        response: OpenAIResponse = await self.__client.responses.create(**kwargs)
        return self.__convert_response(response, request.model)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        kwargs = self.__build_kwargs(request)
        async with self.__client.responses.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "response.output_text.delta":
                    yield TextDelta(text=event.delta)

            response = await api_stream.get_final_response()

        yield ContentComplete(response=self.__convert_response(response, request.model))

    def __build_kwargs(self, request: LLMRequest) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": request.model,
        }

        if request.system:
            kwargs["instructions"] = "\n\n".join("\n\n".join(b.text for b in msg.blocks) for msg in request.system)

        input_items = self.__convert_messages(request.messages)
        if input_items:
            kwargs["input"] = input_items

        if request.max_tokens is not None:
            kwargs["max_output_tokens"] = request.max_tokens

        if request.temperature is not None:
            kwargs["temperature"] = request.temperature

        if request.top_p is not None:
            kwargs["top_p"] = request.top_p

        if request.tools:
            kwargs["tools"] = [self.__convert_tool(tool) for tool in request.tools]

        if request.json_schema:
            kwargs["text"] = {
                "format": {
                    "type": "json_schema",
                    "name": "response",
                    "strict": True,
                    "schema": make_schema_strict(request.json_schema),
                },
            }

        return kwargs

    @classmethod
    def __convert_messages(
        cls,
        messages: list[UserMessage | AssistantMessage],
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []

        for message in messages:
            match message:
                case UserMessage(blocks=blocks):
                    content_parts: list[dict[str, Any]] = []
                    for block in blocks:
                        match block:
                            case TextBlock(text=text):
                                content_parts.append({"type": "input_text", "text": text})
                            case MediaBlock(data=data, media_type=media_type):
                                b64 = base64.b64encode(data).decode()
                                data_uri = f"data:{media_type};base64,{b64}"
                                if media_type.startswith("image/"):
                                    content_parts.append(
                                        {
                                            "type": "input_image",
                                            "image_url": data_uri,
                                        }
                                    )
                                else:
                                    content_parts.append(
                                        {
                                            "type": "input_file",
                                            "file_data": data_uri,
                                        }
                                    )
                            case ToolResultBlock(
                                tool_use_id=tool_use_id,
                                content=content,
                                is_error=is_error,
                            ):
                                if content_parts:
                                    items.append({"role": "user", "content": content_parts})
                                    content_parts = []
                                output = f"Error: {content}" if is_error else content
                                items.append(
                                    {
                                        "type": "function_call_output",
                                        "call_id": tool_use_id,
                                        "output": output,
                                    }
                                )
                    if content_parts:
                        items.append({"role": "user", "content": content_parts})

                case AssistantMessage(blocks=blocks):
                    text_parts: list[str] = []
                    for block in blocks:
                        match block:
                            case TextBlock(text=text):
                                text_parts.append(text)
                            case ToolUseBlock(id=id_, name=name, input=input_):
                                if text_parts:
                                    items.append(
                                        {
                                            "role": "assistant",
                                            "content": "\n".join(text_parts),
                                        }
                                    )
                                    text_parts = []
                                arguments = input_ if isinstance(input_, str) else json.dumps(input_ or {})
                                items.append(
                                    {
                                        "type": "function_call",
                                        "call_id": id_,
                                        "name": name,
                                        "arguments": arguments,
                                    }
                                )
                            case ThinkingBlock():
                                pass
                    if text_parts:
                        items.append(
                            {
                                "role": "assistant",
                                "content": "\n".join(text_parts),
                            }
                        )

        return items

    @staticmethod
    def __convert_tool(tool: Tool) -> dict[str, Any]:
        extra = OpenAIToolExtra.raw(tool)

        if extra.get("type") == "tool_search":
            return {"type": "tool_search"}

        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        entry: dict[str, Any] = {
            "type": "function",
            "name": tool.name,
            "description": description,
            "parameters": tool.input_schema or {"type": "object", "properties": {}},
            "strict": False,
        }

        if extra.get("defer_loading"):
            entry["defer_loading"] = True

        return entry

    @classmethod
    def __convert_response(cls, response: OpenAIResponse, model: str) -> LLMResponse:
        blocks: list[AssistantBlock] = []
        stop_reason = StopReason.OTHER
        has_tool_calls = False

        for item in response.output:
            if isinstance(item, ResponseOutputMessage):
                for content in item.content:
                    if isinstance(content, ResponseOutputText):
                        blocks.append(TextBlock(text=content.text))
            elif isinstance(item, ResponseFunctionToolCall):
                has_tool_calls = True
                blocks.append(
                    ToolUseBlock(
                        id=item.call_id,
                        name=item.name,
                        input=item.arguments,
                    )
                )

        match response.status:
            case "completed":
                stop_reason = StopReason.TOOL_USE if has_tool_calls else StopReason.END_TURN
            case "incomplete":
                stop_reason = StopReason.MAX_TOKENS
            case _:
                stop_reason = StopReason.OTHER

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        extra: dict[str, Any] = {}
        if response.id:
            extra["id"] = response.id
        if response.status:
            extra["provider_status"] = response.status

        return LLMResponse(
            message=AssistantMessage(blocks=blocks),
            stop_reason=stop_reason,
            usage=usage,
            extra=extra,
        )

    @classmethod
    def __convert_usage(cls, usage: ResponseUsage, model: str) -> Usage:
        cache_read = 0
        if usage.input_tokens_details and usage.input_tokens_details.cached_tokens:
            cache_read = usage.input_tokens_details.cached_tokens

        input_tokens = max(0, usage.input_tokens - cache_read)

        reasoning_tokens = 0
        extra: dict[str, Any] = {}
        if usage.output_tokens_details and usage.output_tokens_details.reasoning_tokens:
            reasoning_tokens = usage.output_tokens_details.reasoning_tokens
            extra["reasoning_tokens"] = reasoning_tokens

        cost = pricing_estimate_cost(
            model,
            provider="openai",
            input_tokens=input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_tokens=cache_read,
            reasoning_tokens=reasoning_tokens,
        )
        return Usage(
            input_tokens=input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_input_tokens=cache_read,
            cost_usd=cost.total if cost is not None else None,
            cost=cost,
            extra=extra,
        )
