import asyncio
import inspect
import time
from .http import HTTPClient
from .gateway import DiscordGateway
from .models import Message, Context, Member, Guild, Channel
from .intents import Intents

class Bot:
    def __init__(self, prefix, intents=None, status="online", activity_text=None):
        self.prefix = prefix
        self.intents = intents or Intents.default()
        self.init_status = status
        self.init_text = activity_text
        self.commands = {}
        self.events = {}
        self.cogs = {}
        self.cooldowns = {}
        self.checks = []
        self.gateway = None
        self.http = None
        self.user = None

    def command(self, name=None, cooldown=0):
        def dec(f):
            n = name or f.__name__
            self.commands[n] = {"func": f, "cd": cooldown}
            return f
        return dec

    def event(self, name=None):
        def dec(f):
            self.events[(name or f.__name__).upper()] = f
            return f
        return dec

    def check(self, f):
        self.checks.append(f)
        return f

    async def add_cog(self, cog_class):
        cog = cog_class(self)
        self.cogs[cog_class.__name__] = cog
        for name, method in inspect.getmembers(cog, predicate=inspect.ismethod):
            if hasattr(method, "_is_command"):
                self.commands[method._name] = {"func": method, "cd": method._cd}
        return cog

    async def dispatch(self, t, d):
        if t == "READY": 
            self.user = d.get("user")
            print(f"[Core] Logged in as {self.user['username']}")

        if t == "MESSAGE_CREATE":
            await self._process_commands(d)

        if t in self.events:
            asyncio.create_task(self.events[t](d))

    async def _process_commands(self, data):
        content = data.get("content", "")
        if not content.startswith(self.prefix): return

        parts = content[len(self.prefix):].strip().split()
        if not parts: return
        
        cmd_name = parts[0]
        if cmd_name in self.commands:
            cmd = self.commands[cmd_name]
            msg = Message(data, self)
            ctx = Context(msg, parts[1:], self)

            # Проверка кулдауна
            cd_key = f"{ctx.author.id}:{cmd_name}"
            now = time.time()
            if cd_key in self.cooldowns and now < self.cooldowns[cd_key]:
                return await ctx.send(f"⏳ Подождите {int(self.cooldowns[cd_key] - now)}с.")

            # Проверка чеков
            for check in self.checks:
                if not await check(ctx): return

            self.cooldowns[cd_key] = now + cmd["cd"]
            
            # Вызов команды
            try:
                sig = inspect.signature(cmd["func"])
                if len(sig.parameters) > 1:
                    await cmd["func"](ctx, *parts[1:len(sig.parameters)])
                else:
                    await cmd["func"](ctx)
            except Exception as e:
                print(f"[Error] In command {cmd_name}: {e}")

    async def send(self, ch_id, content=None, embed=None):
        return await self.http.send_message(ch_id, content, embed)

    async def fetch_guild(self, guild_id):
        data = await self.http.request("GET", f"/guilds/{guild_id}?with_counts=true")
        return Guild(data, self) if data else None

    def run(self, token):
        self.http = HTTPClient(token)
        self.gateway = DiscordGateway(token, self.dispatch, self.intents.value, self.init_status, self.init_text)
        loop = asyncio.get_event_loop()
        try:
            loop.run_until_complete(self.gateway.connect())
        except KeyboardInterrupt:
            pass