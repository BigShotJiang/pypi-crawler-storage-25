import asyncio
import aiohttp
import json
import sys
from .utils import to_json

class Route:
    def __init__(self, method, path, **parameters):
        self.method = method
        self.path = path
        self.url = f"https://discord.com/api/v10{path}".format(**parameters)
        self.channel_id = parameters.get("channel_id")
        self.guild_id = parameters.get("guild_id")

class HTTPClient:
    def __init__(self, token):
        self.token = token
        self.user_agent = f"DiscordBot (https://github.com/kotord, 1.2.0) Python/{sys.version_info.major}.{sys.version_info.minor}"
        self.__session = None

    async def get_session(self):
        if self.__session is None or self.__session.closed:
            self.__session = aiohttp.ClientSession(headers={
                "Authorization": f"Bot {self.token}",
                "User-Agent": self.user_agent
            })
        return self.__session

    async def request(self, route, **kwargs):
        method = route.method
        url = route.url
        session = await self.get_session()

        if "json" in kwargs:
            kwargs["headers"] = {"Content-Type": "application/json"}
            kwargs["data"] = to_json(kwargs.pop("json"))

        for try_count in range(5):
            async with session.request(method, url, **kwargs) as response:
                data = await response.json() if response.content_type == "application/json" else await response.text()

                if 300 > response.status >= 200:
                    return data

                if response.status == 429:
                    retry_after = data.get("retry_after", 1)
                    await asyncio.sleep(retry_after)
                    continue

                if response.status in [500, 502, 504]:
                    await asyncio.sleep(1 + try_count * 2)
                    continue

                return None

    async def send_message(self, channel_id, content=None, embed=None, components=None):
        payload = {}
        if content: payload["content"] = content
        if embed: payload["embeds"] = [embed.to_dict()]
        if components: payload["components"] = [c.to_dict() for c in components]
        return await self.request(Route("POST", "/channels/{channel_id}/messages", channel_id=channel_id), json=payload)

    async def edit_message(self, channel_id, message_id, content=None, embed=None, components=None):
        payload = {}
        if content: payload["content"] = content
        if embed: payload["embeds"] = [embed.to_dict()]
        if components: payload["components"] = [c.to_dict() for c in components]
        return await self.request(Route("PATCH", "/channels/{channel_id}/messages/{message_id}", channel_id=channel_id, message_id=message_id), json=payload)

    async def delete_message(self, channel_id, message_id):
        return await self.request(Route("DELETE", "/channels/{channel_id}/messages/{message_id}", channel_id=channel_id, message_id=message_id))

    async def create_guild_role(self, guild_id, name, color=0, permissions="0"):
        payload = {"name": name, "color": color, "permissions": permissions}
        return await self.request(Route("POST", "/guilds/{guild_id}/roles", guild_id=guild_id), json=payload)

    async def delete_guild_role(self, guild_id, role_id):
        return await self.request(Route("DELETE", "/guilds/{guild_id}/roles/{role_id}", guild_id=guild_id, role_id=role_id))

    async def add_role_to_member(self, guild_id, user_id, role_id):
        return await self.request(Route("PUT", "/guilds/{guild_id}/members/{user_id}/roles/{role_id}", guild_id=guild_id, user_id=user_id, role_id=role_id))

    async def remove_role_from_member(self, guild_id, user_id, role_id):
        return await self.request(Route("DELETE", "/guilds/{guild_id}/members/{user_id}/roles/{role_id}", guild_id=guild_id, user_id=user_id, role_id=role_id))

    async def close(self):
        if self.__session:
            await self.__session.close()