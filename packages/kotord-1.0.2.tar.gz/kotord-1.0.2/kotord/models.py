import datetime
from .utils import snowflake_time, color_to_int

class Color:
    BLURPLE = 0x5865F2
    GREEN = 0x57F287
    YELLOW = 0xFEE75C
    FUSCHIA = 0xEB459E
    RED = 0xED4245
    WHITE = 0xFFFFFF
    BLACK = 0x23272A

class Permissions:
    def __init__(self, value):
        self.value = int(value)
    def has(self, perm): return (self.value & perm) == perm

class BaseObject:
    def __init__(self, data):
        self.id = data.get("id")
        self._raw = data
    @property
    def created_at(self): return snowflake_time(self.id)

class User(BaseObject):
    def __init__(self, data):
        super().__init__(data)
        self.username = data.get("username")
        self.discriminator = data.get("discriminator")
        self.avatar = data.get("avatar")
        self.bot = data.get("bot", False)
        self.banner = data.get("banner")
    @property
    def avatar_url(self):
        if not self.avatar: return f"https://cdn.discordapp.com/embed/avatars/{int(self.id)%5}.png"
        return f"https://cdn.discordapp.com/avatars/{self.id}/{self.avatar}.png"

class Role(BaseObject):
    def __init__(self, data, guild_id):
        super().__init__(data)
        self.name = data.get("name")
        self.color = data.get("color")
        self.hoist = data.get("hoist")
        self.position = data.get("position")
        self.permissions = Permissions(data.get("permissions", 0))

class Channel(BaseObject):
    def __init__(self, data, bot):
        super().__init__(data)
        self.bot = bot
        self.name = data.get("name")
        self.type = data.get("type")
        self.guild_id = data.get("guild_id")
    async def send(self, content=None, embed=None):
        return await self.bot.send(self.id, content, embed)

class Guild(BaseObject):
    def __init__(self, data, bot):
        super().__init__(data)
        self.bot = bot
        self.name = data.get("name")
        self.owner_id = data.get("owner_id")
        self.member_count = data.get("approximate_member_count")
        self.roles = [Role(r, self.id) for r in data.get("roles", [])]

class Member(User):
    def __init__(self, data, guild_id, bot):
        super().__init__(data.get("user", data))
        self.guild_id = guild_id
        self.bot = bot
        self.nick = data.get("nick")
        self.roles_ids = data.get("roles", [])
    async def ban(self, reason=None):
        return await self.bot.http.request("PUT", f"/guilds/{self.guild_id}/bans/{self.id}", data={"reason": reason})
    async def kick(self, reason=None):
        return await self.bot.http.request("DELETE", f"/guilds/{self.guild_id}/members/{self.id}", data={"reason": reason})

class Attachment:
    def __init__(self, data):
        self.id = data.get("id")
        self.filename = data.get("filename")
        self.url = data.get("url")
        self.size = data.get("size")

class Embed:
    def __init__(self, title=None, description=None, color=Color.BLURPLE):
        self.title = title
        self.description = description
        self.color = color_to_int(color)
        self.fields = []
        self.image = None
        self.thumbnail = None
        self.footer = None
        self.author = None
    def add_field(self, name, value, inline=False):
        self.fields.append({"name": str(name), "value": str(value), "inline": inline}); return self
    def set_footer(self, text, icon_url=None):
        self.footer = {"text": text, "icon_url": icon_url}; return self
    def set_image(self, url): self.image = {"url": url}; return self
    def to_dict(self):
        d = {"title": self.title, "description": self.description, "color": self.color}
        if self.fields: d["fields"] = self.fields
        if self.footer: d["footer"] = self.footer
        if self.image: d["image"] = self.image
        return {k: v for k, v in d.items() if v is not None}

class Message(BaseObject):
    def __init__(self, data, bot):
        super().__init__(data)
        self.bot = bot
        self.content = data.get("content", "")
        self.channel_id = data.get("channel_id")
        self.guild_id = data.get("guild_id")
        self.author = User(data.get("author", {}))
        self.attachments = [Attachment(a) for a in data.get("attachments", [])]
    async def reply(self, content=None, embed=None):
        return await self.bot.send(self.channel_id, content, embed)

class Context:
    def __init__(self, message, args, bot):
        self.message = message
        self.author = message.author
        self.guild_id = message.guild_id
        self.channel_id = message.channel_id
        self.args = args
        self.bot = bot
    async def send(self, content=None, embed=None):
        return await self.bot.send(self.channel_id, content, embed)