import re
import datetime
import json

def parse_mention(text):
    if not text: return None
    res = re.search(r'<@!?(\d+)>', str(text))
    return res.group(1) if res else (text if str(text).isdigit() else None)

def parse_channel_mention(text):
    res = re.search(r'<#(\d+)>', str(text))
    return res.group(1) if res else None

def format_dt(dt, style='R'):
    if isinstance(dt, str):
        dt = datetime.datetime.fromisoformat(dt.replace('Z', '+00:00'))
    return f"<t:{int(dt.timestamp())}:{style}>"

class MISSING:
    def __bool__(self): return False
    def __repr__(self): return "..."

def to_json(obj):
    return json.dumps(obj, separators=(',', ':'), ensure_ascii=False)

def snowflake_time(id):
    return datetime.datetime.fromtimestamp(((int(id) >> 22) + 1420070400000) / 1000, datetime.timezone.utc)

def color_to_int(color):
    if isinstance(color, int): return color
    if isinstance(color, str): return int(color.lstrip('#'), 16)
    return 0