class ComponentType:
    ACTION_ROW = 1
    BUTTON = 2
    STRING_SELECT = 3
    TEXT_INPUT = 4
    USER_SELECT = 5
    ROLE_SELECT = 6
    MENTIONABLE_SELECT = 7
    CHANNEL_SELECT = 8

class ButtonStyle:
    PRIMARY = 1
    SECONDARY = 2
    SUCCESS = 3
    DANGER = 4
    LINK = 5

class Component:
    def to_dict(self):
        raise NotImplementedError

class ActionRow(Component):
    def __init__(self, *components):
        self.components = list(components)

    def add_component(self, component):
        if len(self.components) < 5:
            self.components.append(component)
        return self

    def to_dict(self):
        return {
            "type": ComponentType.ACTION_ROW,
            "components": [c.to_dict() for c in self.components]
        }

class Button(Component):
    def __init__(self, label=None, style=ButtonStyle.PRIMARY, custom_id=None, url=None, disabled=False, emoji=None):
        self.label = label
        self.style = style
        self.custom_id = custom_id
        self.url = url
        self.disabled = disabled
        self.emoji = emoji

    def to_dict(self):
        payload = {
            "type": ComponentType.BUTTON,
            "style": self.style,
            "disabled": self.disabled
        }
        if self.label: payload["label"] = self.label
        if self.custom_id: payload["custom_id"] = self.custom_id
        if self.url: payload["url"] = self.url
        if self.emoji: payload["emoji"] = self.emoji
        return payload

class SelectOption:
    def __init__(self, label, value, description=None, emoji=None, default=False):
        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self):
        d = {"label": self.label, "value": self.value, "default": self.default}
        if self.description: d["description"] = self.description
        if self.emoji: d["emoji"] = self.emoji
        return d

class SelectMenu(Component):
    def __init__(self, custom_id, options, placeholder=None, min_values=1, max_values=1, disabled=False):
        self.custom_id = custom_id
        self.options = options
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.disabled = disabled

    def to_dict(self):
        payload = {
            "type": ComponentType.STRING_SELECT,
            "custom_id": self.custom_id,
            "options": [o.to_dict() for o in self.options],
            "min_values": self.min_values,
            "max_values": self.max_values,
            "disabled": self.disabled
        }
        if self.placeholder: payload["placeholder"] = self.placeholder
        return payload