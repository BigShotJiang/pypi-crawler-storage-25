"""
kotord API Wrapper
~~~~~~~~~~~~~~~~~~~

Библиотека для создания Discord ботов на Python с поддержкой компонентов, 
продвинутой модерации и обработки Rate-limits.

:copyright: (c) 2026 YourName
:license: MIT, see LICENSE for more details.
"""

__title__ = 'kotord'
__author__ = 'YourName'
__license__ = 'MIT'
__copyright__ = 'Copyright 2026 YourName'
__version__ = '1.2.0'

# Основные классы бота
from .bot import Bot

# Инфраструктура и сеть
from .http import HTTPClient, Route
from .gateway import DiscordGateway

# Модели данных и объекты Discord
from .models import (
    Color,
    Permissions,
    BaseObject,
    User,
    Member,
    Role,
    Channel,
    Guild,
    Attachment,
    Embed,
    Message,
    Context
)

# Система интентов
from .intents import Intents

# Утилиты и конвертеры
from .utils import (
    parse_mention,
    parse_channel_mention,
    format_dt,
    snowflake_time,
    color_to_int
)

# Компоненты UI (Кнопки, Меню)
from .components import (
    ComponentType,
    ButtonStyle,
    ActionRow,
    Button,
    SelectOption,
    SelectMenu
)

# Список экспортируемых имен (помогает IDE и защищает от лишнего импорта)
__all__ = (
    'Bot',
    'HTTPClient',
    'Route',
    'DiscordGateway',
    'Intents',
    'Embed',
    'Color',
    'Permissions',
    'User',
    'Member',
    'Role',
    'Channel',
    'Guild',
    'Attachment',
    'Message',
    'Context',
    'parse_mention',
    'parse_channel_mention',
    'format_dt',
    'snowflake_time',
    'color_to_int',
    'ComponentType',
    'ButtonStyle',
    'ActionRow',
    'Button',
    'SelectOption',
    'SelectMenu',
)

import logging

# Настройка логирования по умолчанию для библиотеки
logging.getLogger(__name__).addHandler(logging.NullHandler())