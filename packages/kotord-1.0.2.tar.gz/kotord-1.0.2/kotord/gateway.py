import asyncio
import aiohttp
import json
import sys
import time

class DiscordGateway:
    def __init__(self, token, dispatcher, intents, status, activity):
        self.token = token
        self.dispatcher = dispatcher
        self.intents = intents
        self.status = status
        self.activity = activity
        self.ws = None
        self.sequence = None
        self.latency = 0
        self._last_hb = 0

    async def connect(self):
        async with aiohttp.ClientSession() as session:
            async with session.ws_connect("wss://gateway.discord.gg/?v=10&encoding=json") as ws:
                self.ws = ws
                async for msg in ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        data = json.loads(msg.data)
                        op = data.get("op")
                        if op == 10:
                            asyncio.create_task(self.heartbeat(data["d"]["heartbeat_interval"]/1000))
                            await self.identify()
                        elif op == 11:
                            self.latency = (time.perf_counter() - self._last_hb) * 1000
                        if data.get("t"):
                            await self.dispatcher(data["t"], data["d"])

    async def identify(self):
        await self.ws.send_json({
            "op": 2,
            "d": {
                "token": self.token, "intents": self.intents,
                "properties": {"os": sys.platform, "browser": "kotord", "device": "kotord"},
                "presence": {
                    "status": self.status, "afk": False,
                    "activities": [{"name": self.activity, "type": 0}] if self.activity else []
                }
            }
        })

    async def change_presence(self, status, text):
        if self.ws:
            await self.ws.send_json({
                "op": 3,
                "d": {
                    "since": None, "afk": False, "status": status,
                    "activities": [{"name": text, "type": 0}]
                }
            })

    async def heartbeat(self, interval):
        while not self.ws.closed:
            self._last_hb = time.perf_counter()
            await self.ws.send_json({"op": 1, "d": self.sequence})
            await asyncio.sleep(interval)