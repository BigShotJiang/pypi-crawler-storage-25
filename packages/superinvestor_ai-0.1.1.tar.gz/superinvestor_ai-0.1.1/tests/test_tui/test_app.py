from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from superinvestor.tui.app import SuperInvestorApp
from superinvestor.tui.screens.analysis import AnalysisScreen
from superinvestor.tui.screens.dashboard import DashboardScreen
from superinvestor.tui.screens.history import HistoryScreen


def _make_app() -> SuperInvestorApp:
    """Create an app with mocked backend so no real DB/API calls happen."""
    with patch("superinvestor.tui.app.Settings") as mock_settings_cls:
        mock_settings = MagicMock()
        mock_settings.db_path = Path(":memory:")
        mock_settings_cls.return_value = mock_settings
        app = SuperInvestorApp()
    return app


@pytest.fixture
def app() -> SuperInvestorApp:
    return _make_app()


class TestAppScreens:
    @pytest.mark.asyncio
    async def test_app_starts_on_dashboard(self, app: SuperInvestorApp) -> None:
        with (
            patch("superinvestor.tui.app.Database") as mock_db_cls,
            patch("superinvestor.tui.app.create_stack") as mock_stack,
        ):
            mock_db = MagicMock()
            mock_db.connect = AsyncMock(return_value=MagicMock())
            mock_db.close = AsyncMock()
            mock_db_cls.return_value = mock_db
            mock_stack_inst = MagicMock()
            mock_stack_inst.close = AsyncMock()
            mock_stack.return_value = mock_stack_inst

            # Patch _load_data on DashboardScreen to avoid real DB/API calls.
            with patch.object(DashboardScreen, "_load_data", new_callable=AsyncMock):
                async with app.run_test() as _pilot:
                    assert any(isinstance(s, DashboardScreen) for s in app.screen_stack)

    @pytest.mark.asyncio
    async def test_switch_to_analysis(self, app: SuperInvestorApp) -> None:
        with (
            patch("superinvestor.tui.app.Database") as mock_db_cls,
            patch("superinvestor.tui.app.create_stack") as mock_stack,
        ):
            mock_db = MagicMock()
            mock_db.connect = AsyncMock(return_value=MagicMock())
            mock_db.close = AsyncMock()
            mock_db_cls.return_value = mock_db
            mock_stack_inst = MagicMock()
            mock_stack_inst.close = AsyncMock()
            mock_stack.return_value = mock_stack_inst

            with patch.object(DashboardScreen, "_load_data", new_callable=AsyncMock):
                async with app.run_test() as pilot:
                    await pilot.press("a")
                    assert any(isinstance(s, AnalysisScreen) for s in app.screen_stack)

    @pytest.mark.asyncio
    async def test_switch_to_history(self, app: SuperInvestorApp) -> None:
        with (
            patch("superinvestor.tui.app.Database") as mock_db_cls,
            patch("superinvestor.tui.app.create_stack") as mock_stack,
        ):
            mock_db = MagicMock()
            mock_db.connect = AsyncMock(return_value=MagicMock())
            mock_db.close = AsyncMock()
            mock_db_cls.return_value = mock_db
            mock_stack_inst = MagicMock()
            mock_stack_inst.close = AsyncMock()
            mock_stack.return_value = mock_stack_inst

            with (
                patch.object(DashboardScreen, "_load_data", new_callable=AsyncMock),
                patch.object(HistoryScreen, "_load_recent", new_callable=AsyncMock),
            ):
                async with app.run_test() as pilot:
                    await pilot.press("h")
                    assert any(isinstance(s, HistoryScreen) for s in app.screen_stack)

    @pytest.mark.asyncio
    async def test_analysis_screen_has_input(self, app: SuperInvestorApp) -> None:
        with (
            patch("superinvestor.tui.app.Database") as mock_db_cls,
            patch("superinvestor.tui.app.create_stack") as mock_stack,
        ):
            mock_db = MagicMock()
            mock_db.connect = AsyncMock(return_value=MagicMock())
            mock_db.close = AsyncMock()
            mock_db_cls.return_value = mock_db
            mock_stack_inst = MagicMock()
            mock_stack_inst.close = AsyncMock()
            mock_stack.return_value = mock_stack_inst

            with patch.object(DashboardScreen, "_load_data", new_callable=AsyncMock):
                async with app.run_test() as pilot:
                    await pilot.press("a")
                    await pilot.pause()
                    from textual.widgets import Button, Input

                    screen = app.screen_stack[-1]
                    assert isinstance(screen, AnalysisScreen)
                    assert screen.query_one("#ticker-input", Input) is not None
                    assert screen.query_one("#run-btn", Button) is not None
