from __future__ import annotations

import logging

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, Header

from superinvestor.agents.registry import DataStack, create_stack
from superinvestor.config import Settings
from superinvestor.store.db import Database

logger = logging.getLogger(__name__)


class SuperInvestorApp(App):
    """Terminal UI for superinvestor."""

    TITLE = "superinvestor"

    CSS = """
    Screen {
        layout: vertical;
    }
    #main-area {
        height: 1fr;
    }
    #left-pane {
        width: 2fr;
    }
    #right-pane {
        width: 1fr;
    }
    #input-bar {
        height: auto;
        dock: top;
        padding: 1 2;
    }
    #input-bar Input {
        width: 1fr;
    }
    #input-bar Button {
        width: auto;
        min-width: 12;
    }
    #analysis-log {
        height: 1fr;
    }
    #history-table {
        height: 1fr;
    }
    #history-detail {
        height: auto;
        max-height: 40%;
        overflow-y: auto;
        padding: 1 2;
        border-top: solid $accent;
    }
    .section-label {
        padding: 0 1;
        color: $text-muted;
        text-style: bold;
    }
    """

    BINDINGS = [
        Binding("d", "switch_screen('dashboard')", "Dashboard", show=True),
        Binding("a", "switch_screen('analysis')", "Analysis", show=True),
        Binding("h", "switch_screen('history')", "History", show=True),
        Binding("q", "quit", "Quit", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._settings = Settings()
        self._database = Database(self._settings.db_path)
        self.stack: DataStack | None = None
        self.db_conn = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield Footer()

    async def on_mount(self) -> None:
        self.db_conn = await self._database.connect()
        self.stack = create_stack(self._settings)
        await self.action_switch_screen("dashboard")

    async def on_unmount(self) -> None:
        if self.stack:
            await self.stack.close()
        await self._database.close()

    async def action_switch_screen(self, name: str) -> None:
        from superinvestor.tui.screens import (
            AnalysisScreen,
            DashboardScreen,
            HistoryScreen,
        )

        screen_map = {
            "dashboard": DashboardScreen,
            "analysis": AnalysisScreen,
            "history": HistoryScreen,
        }
        screen_cls = screen_map.get(name)
        if screen_cls is None:
            return
        # Pop back to base, then push the new screen.
        while len(self.screen_stack) > 1:
            self.pop_screen()
        await self.push_screen(screen_cls())
