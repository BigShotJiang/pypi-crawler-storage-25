from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, Input, RichLog

from superinvestor.engine.pipeline import stream_analysis
from superinvestor.models.analysis import AnalysisResult
from superinvestor.models.enums import EventKind
from superinvestor.store.analysis_store import AnalysisStore

if TYPE_CHECKING:
    from superinvestor.tui.app import SuperInvestorApp

logger = logging.getLogger(__name__)


class AnalysisScreen(Screen):
    """Run AI analysis on a stock with streaming output."""

    def compose(self) -> ComposeResult:
        with Horizontal(id="input-bar"):
            yield Input(id="ticker-input", placeholder="Enter ticker (e.g. AAPL)")
            yield Button("Analyze", id="run-btn", variant="primary")
        with Vertical():
            yield RichLog(id="analysis-log", highlight=True, markup=True)

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "run-btn":
            self._start_analysis()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "ticker-input":
            self._start_analysis()

    def _start_analysis(self) -> None:
        ticker_input = self.query_one("#ticker-input", Input)
        ticker = ticker_input.value.strip().upper()
        if not ticker:
            return
        ticker_input.value = ""
        self.run_worker(self._run_analysis(ticker), exclusive=True)

    async def _run_analysis(self, ticker: str) -> None:
        app: SuperInvestorApp = self.app  # type: ignore[assignment]
        if app.stack is None:
            return

        log = self.query_one("#analysis-log", RichLog)
        log.clear()
        log.write(f"[bold]Analyzing {ticker}...[/bold]\n")

        text_buffer = ""
        full_text = ""

        try:
            async for event in stream_analysis(app.stack.provider, [ticker]):
                if event.kind == EventKind.AGENT_SWITCH:
                    # Flush any accumulated text before the switch.
                    if text_buffer:
                        log.write(text_buffer)
                        text_buffer = ""
                    log.write(f"\n[bold cyan]--- {event.content} ---[/bold cyan]")

                elif event.kind == EventKind.TEXT_DELTA:
                    text_buffer += event.content
                    full_text += event.content

                elif event.kind == EventKind.TOOL_CALL:
                    if text_buffer:
                        log.write(text_buffer)
                        text_buffer = ""
                    log.write(f"[dim]  tool: {event.tool_name}[/dim]")

                elif event.kind == EventKind.TOOL_RESULT:
                    log.write("[dim green]  done[/dim green]")

                elif event.kind == EventKind.ERROR:
                    if text_buffer:
                        log.write(text_buffer)
                        text_buffer = ""
                    log.write(f"[red]Error: {event.content}[/red]")

                elif event.kind == EventKind.DONE:
                    if text_buffer:
                        log.write(text_buffer)
                        text_buffer = ""

            log.write("\n[bold green]Analysis complete.[/bold green]")

            if app.db_conn is not None and full_text.strip():
                lines = full_text.strip().splitlines()
                title = lines[0][:100] if lines else f"Analysis of {ticker}"
                result = AnalysisResult(
                    ticker=ticker,
                    analysis_type="multi_agent",
                    title=title,
                    summary=full_text[:500].strip(),
                    details=full_text,
                    confidence=0.0,
                )
                try:
                    await AnalysisStore(app.db_conn).insert(result)
                except Exception as exc:
                    logger.error("Failed to persist analysis result: %s", exc)
        except Exception as exc:
            logger.error("Analysis failed: %s", exc, exc_info=True)
            if text_buffer:
                log.write(text_buffer)
            log.write(f"\n[red]Analysis failed: {exc}[/red]")
