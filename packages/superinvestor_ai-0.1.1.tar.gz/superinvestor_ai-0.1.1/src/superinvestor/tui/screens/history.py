from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Button, DataTable, Input, Static

from superinvestor.models.analysis import AnalysisResult
from superinvestor.store.analysis_store import AnalysisStore

if TYPE_CHECKING:
    from superinvestor.tui.app import SuperInvestorApp

logger = logging.getLogger(__name__)


class HistoryScreen(Screen):
    """Browse past analysis results."""

    BINDINGS = [("r", "refresh", "Refresh")]

    def __init__(self) -> None:
        super().__init__()
        self._results: list[AnalysisResult] = []

    def compose(self) -> ComposeResult:
        with Horizontal(id="input-bar"):
            yield Input(id="history-ticker", placeholder="Filter by ticker...")
            yield Button("Search", id="search-btn", variant="primary")
        with Vertical():
            yield DataTable(id="history-table")
            yield Static("Select a result to view details.", id="history-detail")

    async def on_mount(self) -> None:
        table = self.query_one("#history-table", DataTable)
        table.add_columns("Date", "Ticker", "Type", "Title", "Confidence")
        table.cursor_type = "row"
        await self._load_recent()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "search-btn":
            await self._search()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "history-ticker":
            await self._search()

    async def _search(self) -> None:
        ticker = self.query_one("#history-ticker", Input).value.strip().upper()
        await self._load_recent(ticker or None)

    async def _load_recent(self, ticker: str | None = None) -> None:
        app: SuperInvestorApp = self.app  # type: ignore[assignment]
        if app.db_conn is None:
            return

        store = AnalysisStore(app.db_conn)
        if ticker:
            self._results = await store.get_recent(ticker, limit=50)
        else:
            self._results = await store.query(order_by="created_at DESC", limit=50)

        table = self.query_one("#history-table", DataTable)
        table.clear()
        for i, result in enumerate(self._results):
            table.add_row(
                result.created_at.strftime("%Y-%m-%d %H:%M"),
                result.ticker,
                result.analysis_type,
                result.title[:60],
                f"{result.confidence:.0%}",
                key=str(i),
            )

        detail = self.query_one("#history-detail", Static)
        if not self._results:
            detail.update("No results found.")
        else:
            detail.update("Select a result to view details.")

    async def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None or event.row_key.value is None:
            return
        try:
            idx = int(event.row_key.value)
        except (ValueError, TypeError):
            return
        if 0 <= idx < len(self._results):
            result = self._results[idx]
            detail = self.query_one("#history-detail", Static)
            detail.update(result.details)

    async def action_refresh(self) -> None:
        await self._load_recent()
