from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import DataTable, Static
from textual_plotext import PlotextPlot

from superinvestor.store.watchlist_store import WatchlistStore

if TYPE_CHECKING:
    from superinvestor.tui.app import SuperInvestorApp

logger = logging.getLogger(__name__)


class DashboardScreen(Screen):
    """Watchlist, quotes, and a price chart."""

    BINDINGS = [("r", "refresh", "Refresh")]

    def compose(self) -> ComposeResult:
        with Horizontal(id="main-area"):
            with Vertical(id="left-pane"):
                yield Static("Watchlist", classes="section-label")
                yield DataTable(id="watchlist-table")
                yield Static("Quotes", classes="section-label")
                yield DataTable(id="quotes-table")
            with Vertical(id="right-pane"):
                yield Static("Price Chart", classes="section-label")
                yield PlotextPlot(id="chart")

    async def on_mount(self) -> None:
        wt = self.query_one("#watchlist-table", DataTable)
        wt.add_columns("Ticker", "Notes", "Tags")
        wt.cursor_type = "row"

        qt = self.query_one("#quotes-table", DataTable)
        qt.add_columns("Ticker", "Price", "Change", "Change%", "Volume")
        qt.cursor_type = "row"

        await self._load_data()

    async def _load_data(self) -> None:
        app: SuperInvestorApp = self.app  # type: ignore[assignment]
        if app.db_conn is None or app.stack is None:
            return

        store = WatchlistStore(app.db_conn)
        items = await store.get_all()

        wt = self.query_one("#watchlist-table", DataTable)
        wt.clear()
        for item in items:
            wt.add_row(item.ticker, item.notes, ", ".join(item.tags), key=item.ticker)

        qt = self.query_one("#quotes-table", DataTable)
        qt.clear()
        for item in items:
            try:
                quote = await app.stack.polygon.get_quote(item.ticker)
                qt.add_row(
                    quote.ticker,
                    f"${float(quote.price):.2f}",
                    f"{float(quote.change):+.2f}",
                    f"{float(quote.change_percent):+.2f}%",
                    f"{quote.volume:,}",
                    key=quote.ticker,
                )
            except Exception:
                logger.debug("Failed to fetch quote for %s", item.ticker, exc_info=True)
                qt.add_row(item.ticker, "N/A", "N/A", "N/A", "N/A", key=item.ticker)

    async def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None or event.row_key.value is None:
            return
        ticker = event.row_key.value
        await self._update_chart(ticker)

    async def _update_chart(self, ticker: str) -> None:
        app: SuperInvestorApp = self.app  # type: ignore[assignment]
        if app.stack is None:
            return
        try:
            bars = await app.stack.polygon.get_ohlcv(ticker, limit=90)
        except Exception:
            logger.debug("Failed to fetch OHLCV for %s", ticker, exc_info=True)
            return
        if not bars:
            return

        closes = [float(b.close) for b in bars]
        indices = list(range(len(closes)))

        chart = self.query_one("#chart", PlotextPlot)
        plt = chart.plt
        plt.clear_data()
        plt.clear_figure()
        plt.plot(indices, closes)
        plt.title(ticker)
        chart.refresh()

    async def action_refresh(self) -> None:
        await self._load_data()
