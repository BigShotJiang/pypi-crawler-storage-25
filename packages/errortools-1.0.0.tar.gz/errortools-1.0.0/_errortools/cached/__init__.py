"""Cache tools in `errortools`."""
