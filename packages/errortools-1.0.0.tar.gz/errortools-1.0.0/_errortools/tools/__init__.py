"""Tools for `errortools`."""
