# langchain-fluxvector

LangChain integration for [FluxVector](https://fluxvector.dev) — vector search API with built-in embeddings.

## Installation

```bash
pip install langchain-fluxvector
```

## Usage

```python
from langchain_fluxvector import FluxVectorStore

# FluxVector handles embeddings server-side — no OpenAI key needed
vs = FluxVectorStore(
    api_key="fv_live_...",
    collection="my-docs",
)

# Add documents
vs.add_texts([
    "FluxVector is a vector search API",
    "It supports 100+ languages",
    "Hybrid BM25 + vector search included",
])

# Search
results = vs.similarity_search("multilingual search", k=3)
for doc in results:
    print(doc.page_content, doc.metadata["score"])
```

## Why FluxVector?

- **No embedding model needed** — FluxVector embeds text server-side
- **Hybrid search** — BM25 + vector with RRF fusion, out of the box
- **100+ languages** — Multilingual-e5-large handles cross-lingual retrieval
- **$29/mo for 1M vectors** — Flat pricing, no per-query charges
- **Self-host free** — Same Docker image, your infrastructure

## With LangChain Chains

```python
from langchain_fluxvector import FluxVectorStore
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA

vs = FluxVectorStore(api_key="fv_live_...", collection="docs")
retriever = vs.as_retriever(search_kwargs={"k": 5})

qa = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(),
    retriever=retriever,
)
answer = qa.invoke("What languages does FluxVector support?")
```

## Links

- [FluxVector Docs](https://fluxvector.dev/docs)
- [FluxVector Console](https://fluxvector.dev/console)
- [Python SDK](https://pypi.org/project/fluxvector/)
