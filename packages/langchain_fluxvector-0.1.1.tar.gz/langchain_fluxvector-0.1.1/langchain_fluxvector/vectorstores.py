"""FluxVector vector store integration for LangChain."""
from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

from langchain_core.documents import Document
from langchain_core.vectorstores import VectorStore

logger = logging.getLogger(__name__)


class FluxVectorStore(VectorStore):
    """LangChain vector store backed by FluxVector.

    FluxVector handles embeddings server-side, so no separate embedding
    model is needed. Just send text — FluxVector embeds and indexes it.

    Example:
        .. code-block:: python

            from langchain_fluxvector import FluxVectorStore

            vs = FluxVectorStore(
                api_key="fv_live_...",
                collection="my-docs",
            )
            vs.add_texts(["Hello world", "FluxVector is great"])
            results = vs.similarity_search("greeting", k=3)
    """

    def __init__(
        self,
        api_key: str | None = None,
        collection: str = "default",
        base_url: str = "https://fluxvector.dev",
        **kwargs: Any,
    ):
        try:
            from fluxvector import FluxVector
        except ImportError:
            raise ImportError(
                "fluxvector package not installed. Run: pip install fluxvector"
            )

        self._client = FluxVector(
            api_key=api_key,
            base_url=base_url,
            **kwargs,
        )
        self._collection = collection
        self._ensure_collection()

    def _ensure_collection(self) -> None:
        """Create collection if it doesn't exist."""
        try:
            self._client.collections.get(self._collection)
        except Exception:
            try:
                self._client.collections.create(self._collection, dimension=1024)
            except Exception:
                pass  # Already exists or will fail on first upsert

    @property
    def embeddings(self) -> None:
        """FluxVector handles embeddings server-side. No local model needed."""
        return None

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[list[dict]] = None,
        ids: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> list[str]:
        """Add texts to the vector store.

        FluxVector embeds them server-side automatically.
        """
        texts_list = list(texts)
        vectors = []
        for i, text in enumerate(texts_list):
            vec_id = ids[i] if ids else str(i)
            meta = metadatas[i] if metadatas else {}
            vectors.append({"id": vec_id, "text": text, "metadata": meta})

        self._client.vectors.upsert(self._collection, vectors)
        return [v["id"] for v in vectors]

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        **kwargs: Any,
    ) -> list[Document]:
        """Search for similar documents by text query."""
        response = self._client.search(self._collection, query, top_k=k, filter=filter)

        docs = []
        for r in response.results:
            metadata = dict(r.metadata) if r.metadata else {}
            metadata["score"] = r.score
            metadata["id"] = r.id
            docs.append(Document(
                page_content=r.text or "",
                metadata=metadata,
            ))
        return docs

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        **kwargs: Any,
    ) -> list[tuple[Document, float]]:
        """Search and return (document, score) tuples."""
        response = self._client.search(self._collection, query, top_k=k, filter=filter)

        docs = []
        for r in response.results:
            metadata = dict(r.metadata) if r.metadata else {}
            metadata["id"] = r.id
            doc = Document(page_content=r.text or "", metadata=metadata)
            docs.append((doc, r.score))
        return docs

    @classmethod
    def from_texts(
        cls,
        texts: list[str],
        embedding: Any = None,
        metadatas: Optional[list[dict]] = None,
        **kwargs: Any,
    ) -> FluxVectorStore:
        """Create a FluxVectorStore from a list of texts."""
        store = cls(**kwargs)
        store.add_texts(texts, metadatas=metadatas)
        return store

    def delete(self, ids: Optional[list[str]] = None, **kwargs: Any) -> None:
        """Delete vectors by IDs."""
        if ids:
            self._client.vectors.delete(self._collection, ids=ids)
