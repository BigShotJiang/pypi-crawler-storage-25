"""Pipe processor for Junos CLI-style pipe commands."""

import re
import shlex
from pathlib import Path
from typing import Dict, List, Tuple


class PipeError(Exception):
    """Exception raised for pipe processing errors."""

    pass


class PipeCommand:
    """Base class for pipe commands."""

    def __init__(self, args: List[str]):
        """Initialize pipe command with arguments.

        Args:
            args: List of command arguments
        """
        self.args = args
        self.validate_args()

    def validate_args(self) -> None:
        """Validate command arguments. Override in subclasses."""
        pass

    def process(self, input_text: str) -> str:
        """Process input text and return transformed output.

        Args:
            input_text: Text to process

        Returns:
            Processed text

        Raises:
            PipeError: If processing fails
        """
        raise NotImplementedError("Subclasses must implement process()")


class NoMoreCommand(PipeCommand):
    """Disable paging for current command output."""

    def validate_args(self) -> None:
        """Validate that no-more takes no arguments."""
        if self.args:
            raise PipeError("no-more does not accept arguments")

    def process(self, input_text: str) -> str:
        """Return input unchanged - paging control handled at display level."""
        return input_text


class SaveCommand(PipeCommand):
    """Save output to file."""

    def validate_args(self) -> None:
        """Validate that save has exactly one filename argument."""
        if len(self.args) != 1:
            raise PipeError("save requires exactly one filename argument")

    def process(self, input_text: str) -> str:
        """Save input to file and return success message."""
        filename = self.args[0]
        try:
            # Resolve relative paths from current working directory
            file_path = Path(filename)

            # Create parent directories if they don't exist
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Write the content
            file_path.write_text(input_text, encoding="utf-8")

            return f"Output saved to {file_path.absolute()}"
        except OSError as e:
            raise PipeError(f"Failed to save to {filename}: {e}")


class CountCommand(PipeCommand):
    """Count lines in output."""

    def validate_args(self) -> None:
        """Validate that count takes no arguments."""
        if self.args:
            raise PipeError("count does not accept arguments")

    def process(self, input_text: str) -> str:
        """Count and return number of lines."""
        if not input_text.strip():
            return "0 lines"

        lines = input_text.split("\n")
        # Don't count trailing empty line from split if text ends with newline
        if lines and lines[-1] == "":
            lines.pop()

        line_count = len(lines)
        return f"{line_count} lines"


class MatchCommand(PipeCommand):
    """Filter lines matching a pattern."""

    def validate_args(self) -> None:
        """Validate that match has exactly one pattern argument."""
        if len(self.args) != 1:
            raise PipeError("match requires exactly one pattern argument")

    def process(self, input_text: str) -> str:
        """Return lines matching the pattern."""
        pattern = self.args[0]
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            raise PipeError(f"Invalid regex pattern '{pattern}': {e}")

        lines = input_text.split("\n")
        matching_lines = [line for line in lines if regex.search(line)]

        return "\n".join(matching_lines)


class ExceptCommand(PipeCommand):
    """Filter out lines matching a pattern."""

    def validate_args(self) -> None:
        """Validate that except has exactly one pattern argument."""
        if len(self.args) != 1:
            raise PipeError("except requires exactly one pattern argument")

    def process(self, input_text: str) -> str:
        """Return lines not matching the pattern."""
        pattern = self.args[0]
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            raise PipeError(f"Invalid regex pattern '{pattern}': {e}")

        lines = input_text.split("\n")
        non_matching_lines = [line for line in lines if not regex.search(line)]

        return "\n".join(non_matching_lines)


class LastCommand(PipeCommand):
    """Show last N lines."""

    def validate_args(self) -> None:
        """Validate that last has exactly one numeric argument."""
        if len(self.args) != 1:
            raise PipeError("last requires exactly one numeric argument")

        try:
            self.line_count = int(self.args[0])
            if self.line_count < 0:
                raise ValueError("negative number")
        except ValueError:
            raise PipeError(
                f"Invalid line count '{self.args[0]}': must be a non-negative integer"
            )

    def process(self, input_text: str) -> str:
        """Return last N lines."""
        if not input_text.strip():
            return ""

        lines = input_text.split("\n")
        # Remove trailing empty line if text ends with newline
        if lines and lines[-1] == "":
            lines.pop()

        last_lines = lines[-self.line_count :] if self.line_count > 0 else []
        return "\n".join(last_lines)


class FindCommand(PipeCommand):
    """Show output starting from first line matching pattern."""

    def validate_args(self) -> None:
        """Validate that find has exactly one pattern argument."""
        if len(self.args) != 1:
            raise PipeError("find requires exactly one pattern argument")

    def process(self, input_text: str) -> str:
        """Return lines from first match onward."""
        pattern = self.args[0]
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            raise PipeError(f"Invalid regex pattern '{pattern}': {e}")

        lines = input_text.split("\n")

        # Find first matching line
        start_index = None
        for i, line in enumerate(lines):
            if regex.search(line):
                start_index = i
                break

        if start_index is None:
            return ""  # No match found

        return "\n".join(lines[start_index:])


class TrimCommand(PipeCommand):
    """Remove N characters from left of each line."""

    def validate_args(self) -> None:
        """Validate that trim has exactly one numeric argument."""
        if len(self.args) != 1:
            raise PipeError("trim requires exactly one numeric argument")

        try:
            self.char_count = int(self.args[0])
            if self.char_count < 0:
                raise ValueError("negative number")
        except ValueError:
            raise PipeError(
                f"Invalid character count '{self.args[0]}': must be a non-negative integer"
            )

    def process(self, input_text: str) -> str:
        """Remove N characters from left of each line."""
        lines = input_text.split("\n")
        trimmed_lines = [
            line[self.char_count :] if len(line) > self.char_count else ""
            for line in lines
        ]
        return "\n".join(trimmed_lines)


class DisplaySetCommand(PipeCommand):
    """Convert configuration output to set commands (mock implementation)."""

    def validate_args(self) -> None:
        """Validate that display set takes no arguments."""
        if self.args:
            raise PipeError("display set does not accept arguments")

    def process(self, input_text: str) -> str:
        """Convert hierarchical config to set commands.

        If input is already in 'set ...' format, return it unchanged.
        """
        lines = input_text.split("\n")
        meaningful_lines = [
            ln for ln in lines if ln.strip() and not ln.lstrip().startswith("#")
        ]

        if meaningful_lines and all(ln.lstrip().startswith("set ") for ln in meaningful_lines):
            return "\n".join(meaningful_lines)

        set_commands = []
        block_stack = []

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            has_open = "{" in stripped
            close_count = stripped.count("}")

            if has_open:
                before = stripped.split("{", 1)[0].strip().rstrip(";")
                if before:
                    block_stack.append(before)

            if stripped.endswith(";") and not has_open:
                config_item = stripped.rstrip(";")
                path = " ".join(block_stack + [config_item])
                set_commands.append(f"set {path}")

            for _ in range(close_count):
                if block_stack:
                    block_stack.pop()

        if not set_commands:
            # Fallback for non-hierarchical config
            for line in meaningful_lines:
                set_commands.append(f"set configuration {line.strip()}")

        return "\n".join(set_commands)


class PipeProcessor:
    """Processes Junos CLI-style pipe commands."""

    # Registry of available pipe commands
    PIPE_COMMANDS: Dict[str, type] = {
        "no-more": NoMoreCommand,
        "save": SaveCommand,
        "count": CountCommand,
        "match": MatchCommand,
        "grep": MatchCommand,  # Hidden alias for match
        "except": ExceptCommand,
        "last": LastCommand,
        "find": FindCommand,
        "trim": TrimCommand,
        "display": {  # Subcommands
            "set": DisplaySetCommand,
        },
    }

    def __init__(self):
        """Initialize pipe processor."""
        self.disable_paging = False

    def has_pipes(self, command: str) -> bool:
        """Check if command contains pipe operators.

        Args:
            command: Command string to check

        Returns:
            True if command contains pipes, False otherwise
        """
        return "|" in command

    def parse_command(self, command: str) -> Tuple[str, List[Tuple[str, List[str]]]]:
        """Parse command with pipes into base command and pipe chain.

        Args:
            command: Full command string with pipes

        Returns:
            Tuple of (base_command, pipe_chain)
            pipe_chain is list of (pipe_command, args) tuples

        Raises:
            PipeError: If parsing fails
        """
        if not self.has_pipes(command):
            return command.strip(), []

        # Split on pipe character, being careful with quoted strings
        parts = []
        current_part = ""
        in_quotes = False
        quote_char = None

        for char in command:
            if char in ('"', "'") and not in_quotes:
                in_quotes = True
                quote_char = char
                current_part += char
            elif char == quote_char and in_quotes:
                in_quotes = False
                quote_char = None
                current_part += char
            elif char == "|" and not in_quotes:
                parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char

        if current_part.strip():
            parts.append(current_part.strip())

        if len(parts) < 2:
            raise PipeError("Invalid pipe syntax: no pipe commands found")

        base_command = parts[0]
        pipe_chain = []

        for pipe_part in parts[1:]:
            if not pipe_part:
                raise PipeError("Empty pipe command")

            try:
                # Use shlex to properly handle quoted arguments
                pipe_tokens = shlex.split(pipe_part)
            except ValueError as e:
                raise PipeError(f"Invalid pipe syntax: {e}")

            if not pipe_tokens:
                raise PipeError("Empty pipe command")

            pipe_cmd = pipe_tokens[0]
            pipe_args = pipe_tokens[1:]

            # Special case: "no-" expands to "no-more"
            if pipe_cmd == "no-":
                pipe_cmd = "no-more"
                
            # Handle display subcommands
            if pipe_cmd == "display" and pipe_args:
                display_subcmd = pipe_args[0]
                if display_subcmd in self.PIPE_COMMANDS["display"]:
                    pipe_chain.append((f"display {display_subcmd}", pipe_args[1:]))
                else:
                    raise PipeError(f"Unknown display subcommand: {display_subcmd}")
            elif pipe_cmd in self.PIPE_COMMANDS:
                pipe_chain.append((pipe_cmd, pipe_args))
            else:
                raise PipeError(f"Unknown pipe command: {pipe_cmd}")

        return base_command, pipe_chain

    def create_pipe_command(self, command_name: str, args: List[str]) -> PipeCommand:
        """Create pipe command instance.

        Args:
            command_name: Name of pipe command
            args: Command arguments

        Returns:
            PipeCommand instance

        Raises:
            PipeError: If command is unknown or invalid
        """
        if command_name.startswith("display "):
            # Handle display subcommands
            subcmd = command_name.split(" ", 1)[1]
            if subcmd in self.PIPE_COMMANDS["display"]:
                command_class = self.PIPE_COMMANDS["display"][subcmd]
                return command_class(args)
        elif command_name in self.PIPE_COMMANDS:
            command_class = self.PIPE_COMMANDS[command_name]
            return command_class(args)

        raise PipeError(f"Unknown pipe command: {command_name}")

    def process_pipes(
        self, output: str, pipe_chain: List[Tuple[str, List[str]]]
    ) -> str:
        """Process output through chain of pipe commands.

        Args:
            output: Initial command output
            pipe_chain: List of (command_name, args) tuples

        Returns:
            Final processed output

        Raises:
            PipeError: If any pipe command fails
        """
        current_output = output
        self.disable_paging = False

        for command_name, args in pipe_chain:
            try:
                pipe_cmd = self.create_pipe_command(command_name, args)

                # Check for paging control
                if isinstance(pipe_cmd, NoMoreCommand):
                    self.disable_paging = True

                current_output = pipe_cmd.process(current_output)

            except Exception as e:
                if isinstance(e, PipeError):
                    raise
                else:
                    raise PipeError(f"Error in pipe command '{command_name}': {e}")

        return current_output

    def should_disable_paging(self) -> bool:
        """Check if paging should be disabled for current command.

        Returns:
            True if paging should be disabled, False otherwise
        """
        return self.disable_paging

    def get_available_commands(self) -> List[str]:
        """Get list of available pipe commands.

        Returns:
            List of pipe command names (excludes hidden aliases)
        """
        commands = list(self.PIPE_COMMANDS.keys())
        # Remove hidden aliases from public command list
        commands.remove("grep")  # grep is a hidden alias for match
        # Add display subcommands
        commands.remove("display")
        for subcmd in self.PIPE_COMMANDS["display"]:
            commands.append(f"display {subcmd}")
        return sorted(commands)
