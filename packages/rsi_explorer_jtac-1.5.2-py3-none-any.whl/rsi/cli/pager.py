"""Pager utility for handling large CLI outputs."""

import os
import shutil
import sys
from typing import Optional
import termios
import tty


class Pager:
    """Smart pager that provides Junos-like paging behavior."""

    def __init__(
        self,
        enabled: bool = True,
        threshold_ratio: float = 0.8,
        less_options: Optional[str] = None,
        less_prompt: str = "---(more)---",
    ) -> None:
        """Initialize pager with configuration.

        Args:
            enabled: Whether paging is enabled
            threshold_ratio: Ratio of terminal height to trigger paging (0.0-1.0)
            less_options: Reserved for backward compatibility
            less_prompt: Prompt string shown by less while paging
        """
        self.enabled = enabled and self._is_paging_available()
        self.threshold_ratio = max(0.0, min(1.0, threshold_ratio))
        self.less_options = less_options or "-RFSXE"
        self.less_prompt = less_prompt
        self._terminal_height = self._get_terminal_height()

    def _is_paging_available(self) -> bool:
        """Check if paging is available and appropriate."""
        # Don't page if not in a TTY (e.g., piped output, redirected)
        if not sys.stdout.isatty():
            return False

        return True

    def _get_terminal_height(self) -> int:
        """Get current terminal height in lines."""
        try:
            return shutil.get_terminal_size().lines
        except OSError:
            return 24  # Fallback to reasonable default

    def _count_lines(self, text: str) -> int:
        """Count visible lines in text, accounting for ANSI escape sequences."""
        if not text:
            return 0

        lines = text.split("\n")
        return len(lines)

    def _should_page(self, text: str) -> bool:
        """Determine if text should be paged."""
        if not self.enabled:
            return False

        line_count = self._count_lines(text)
        threshold = int(self._terminal_height * self.threshold_ratio)

        return line_count > threshold

    def display(self, text: str) -> None:
        """Display text, using pager if appropriate.

        Args:
            text: Text to display, may contain ANSI escape sequences
        """
        if not text:
            return

        if self._should_page(text):
            self._page_text(text)
        else:
            self._direct_output(text)

    def _page_text(self, text: str) -> None:
        """Page text using an internal Junos-style pager."""
        lines = text.split("\n")
        total_lines = len(lines)
        page_size = max(1, self._terminal_height - 1)
        pos = 0

        try:
            while pos < total_lines:
                next_pos = min(pos + page_size, total_lines)
                page = "\n".join(lines[pos:next_pos])
                if page:
                    self._direct_output(page)
                pos = next_pos

                if pos >= total_lines:
                    break

                sys.stdout.write(self.less_prompt)
                sys.stdout.flush()
                key = self._read_single_key()
                sys.stdout.write("\r" + (" " * len(self.less_prompt)) + "\r")
                sys.stdout.flush()

                if key in ("q", "Q", "\x03"):  # q or Ctrl+C
                    break
                if key in ("\n", "\r"):  # Enter: one more line
                    page_size = 1
                else:  # Space/default: next page
                    page_size = max(1, self._terminal_height - 1)
        except KeyboardInterrupt:
            return

    def _read_single_key(self) -> str:
        """Read a single key press from stdin."""
        if not sys.stdin.isatty():
            return "q"
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def _direct_output(self, text: str) -> None:
        """Output text directly to stdout."""
        print(text, end="" if text.endswith("\n") else "\n")

    def is_enabled(self) -> bool:
        """Check if paging is currently enabled."""
        return self.enabled

    def set_enabled(self, enabled: bool) -> None:
        """Enable or disable paging.

        Args:
            enabled: Whether to enable paging
        """
        self.enabled = enabled and self._is_paging_available()

    def update_terminal_size(self) -> None:
        """Update cached terminal size (call after terminal resize)."""
        self._terminal_height = self._get_terminal_height()


# Global pager instance for CLI use
_default_pager: Optional[Pager] = None


def get_default_pager() -> Pager:
    """Get or create the default pager instance."""
    global _default_pager
    if _default_pager is None:
        # Check environment variables for configuration
        enabled = os.environ.get("RSI_PAGER", "1").lower() not in ("0", "false", "off")
        threshold = float(os.environ.get("RSI_PAGER_THRESHOLD", "0.8"))
        less_opts = os.environ.get("RSI_LESS_OPTIONS")
        less_prompt = os.environ.get("RSI_LESS_PROMPT", "---(more)---")

        _default_pager = Pager(
            enabled=enabled,
            threshold_ratio=threshold,
            less_options=less_opts,
            less_prompt=less_prompt,
        )

    return _default_pager


def display_text(text: str) -> None:
    """Convenience function to display text using the default pager.

    Args:
        text: Text to display
    """
    get_default_pager().display(text)


def is_paging_enabled() -> bool:
    """Check if paging is enabled on the default pager."""
    return get_default_pager().is_enabled()


def set_paging_enabled(enabled: bool) -> None:
    """Enable or disable paging on the default pager.

    Args:
        enabled: Whether to enable paging
    """
    get_default_pager().set_enabled(enabled)
