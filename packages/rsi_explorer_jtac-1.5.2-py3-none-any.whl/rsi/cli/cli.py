import re
import sys
import shlex
import shutil
import subprocess
import tempfile
import tarfile
import zipfile
from pathlib import Path
from typing import Generator, Optional, Tuple, List, Dict

from prompt_toolkit import prompt
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.shortcuts import print_formatted_text

from ..parser import RSIParseError, RSIParser
from ..rsi_xml_parser import RSIXMLParser
from ..device_client import create_device_client
from .command_tree import CommandTree
from .matcher import CommandMatcher
from .pager import display_text, is_paging_enabled, set_paging_enabled
from .pipe_processor import PipeError, PipeProcessor


class JunosCompleter(Completer):
    """Custom completer for Junos commands.

    Provides intelligent tab completion for Junos CLI commands based on
    the hierarchical command tree built from RSI data.
    """

    def __init__(self, command_tree: CommandTree) -> None:
        """Initialize completer with command tree.

        Args:
            command_tree: Hierarchical tree of available commands
        """
        self.command_tree = command_tree

    def get_completions(
        self, document, complete_event
    ) -> Generator[Completion, None, None]:
        """Get completions for the current input.

        Args:
            document: Current document being edited
            complete_event: Completion event details

        Yields:
            Completion objects for matching commands
        """
        text = document.text_before_cursor

        # Handle special case for '?' - remove the '?' and get completions
        if text.endswith("?"):
            text = text[:-1]

        # Check if we're completing after a pipe
        if "|" in text:
            yield from self._complete_pipe_commands(text, complete_event)
        else:
            # Regular command completion
            completions = self.command_tree.get_completions(text)

            for completion in completions:
                # Calculate how much of the current word to replace
                words = text.split()
                if words and not text.endswith(" "):
                    # There are words and text doesn't end with space
                    current_word = words[-1]
                    start_position = -len(current_word)
                else:
                    # No words or text ends with space - insert at cursor
                    start_position = 0

                yield Completion(completion, start_position=start_position)

    def _complete_pipe_commands(
        self, text: str, complete_event
    ) -> Generator[Completion, None, None]:
        """Complete pipe commands after | character.

        Args:
            text: Text before cursor
            complete_event: Completion event details

        Yields:
            Completion objects for pipe commands
        """
        # Find the last pipe position
        last_pipe_pos = text.rfind("|")
        if last_pipe_pos == -1:
            return

        # Preserve trailing-space state to decide whether we are completing
        # the current token or the next token.
        pipe_fragment = text[last_pipe_pos + 1 :]
        ends_with_space = pipe_fragment.endswith(" ")
        pipe_text = pipe_fragment.strip()
        tokens = pipe_text.split() if pipe_text else []

        top_level = [
            "no-more",
            "save",
            "count",
            "match",
            "grep",
            "except",
            "last",
            "find",
            "trim",
            "display",
        ]
        display_subcommands = ["set"]

        # No token yet: suggest all first-level pipe commands.
        if not tokens:
            for cmd in sorted(top_level):
                yield Completion(cmd, start_position=0)
            return

        # Completing first token (e.g., "| dis")
        if len(tokens) == 1 and not ends_with_space:
            prefix = tokens[0].lower()
            for cmd in sorted([c for c in top_level if c.startswith(prefix)]):
                yield Completion(cmd, start_position=-len(tokens[0]))
            return

        first = tokens[0].lower()
        if first != "display":
            return

        # "| display <TAB>" -> suggest subcommands
        if len(tokens) == 1 and ends_with_space:
            for sub in display_subcommands:
                yield Completion(sub, start_position=0)
            return

        # Completing display subcommand (e.g., "| display s")
        if len(tokens) >= 2 and not ends_with_space:
            sub_prefix = tokens[1].lower()
            for sub in [s for s in display_subcommands if s.startswith(sub_prefix)]:
                yield Completion(sub, start_position=-len(tokens[1]))
            return

        # "| display set <TAB>" — segment complete, suggest chaining another pipe
        if len(tokens) >= 2 and ends_with_space:
            for cmd in sorted(top_level):
                yield Completion("| " + cmd, start_position=0)
            return


class JunosCLI:
    """Main CLI interface for Junos simulation.

    Provides an interactive command-line interface that mimics a Juniper device
    CLI using commands and outputs from RSI files. Supports tab completion,
    command history, help system, and fuzzy command matching.
    """

    def __init__(
        self,
        rsi_parser: RSIParser,
        re_var_log_dirs: Optional[Dict[str, Path]] = None,
    ) -> None:
        """Initialize CLI with parsed RSI data.

        Args:
            rsi_parser: Initialized RSI parser containing commands and metadata
        """
        self.parser = rsi_parser
        self.command_tree = CommandTree(list(rsi_parser.get_commands().keys()))
        self.matcher = CommandMatcher(rsi_parser.get_commands(), rsi_parser)
        self.completer = JunosCompleter(self.command_tree)
        self.history = InMemoryHistory()
        self.pipe_processor = PipeProcessor()

        self._re_var_log_dirs: Dict[str, Path] = {
            k.lower(): v for k, v in (re_var_log_dirs or {}).items()
        }

        # Build prompt
        self._user = self.parser.get_user() or "user"
        raw_hostname = self.parser.get_hostname() or "device"
        hostname_match = re.match(r"^(.*?)(?:-(re[01]))?$", raw_hostname, flags=re.IGNORECASE)
        if hostname_match:
            self._base_hostname = hostname_match.group(1)
            suffix = hostname_match.group(2)
        else:
            self._base_hostname = raw_hostname
            suffix = None

        parser_master_raw = (
            self.parser.get_master_re_name()
            if hasattr(self.parser, "get_master_re_name")
            else None
        )
        parser_master = (
            parser_master_raw
            if isinstance(parser_master_raw, str)
            and parser_master_raw.lower() in {"re0", "re1"}
            else None
        )
        self._active_re_name: Optional[str] = (suffix or parser_master)
        # True while we are logged into the backup RE (exit should return to master)
        self._in_backup_re_session: bool = False

        self._prompt_op = ""
        self._prompt_cfg = ""
        self.prompt_text = ""
        self._update_prompts()

        # Config-mode state (mimic Junos configure/edit/show)
        self._mode: str = "op"  # "op" | "config"
        self._edit_path: List[str] = []
        self._cached_root_config_cmd: Optional[str] = None
        # key: flattened path tokens (lowercase); value: map(token_lower -> token_display)
        self._cached_config_tree: Optional[Dict[Tuple[str, ...], Dict[str, str]]] = None
        self._key_bindings = self._build_key_bindings()
        self._next_default_input: str = ""

    def _update_prompts(self) -> None:
        """Refresh prompt strings according to active RE context."""
        hostname = self._base_hostname
        role_prefix = ""
        if self._active_re_name:
            hostname = f"{hostname}-{self._active_re_name}"
            master_re = (
                self.parser.get_master_re_name()
                if hasattr(self.parser, "get_master_re_name")
                else None
            )
            if master_re and isinstance(master_re, str) and master_re.lower() in {"re0", "re1"}:
                role = "master" if self._active_re_name.lower() == master_re.lower() else "backup"
                role_prefix = f"{{{role}}}\n"

        self._prompt_op = f"{role_prefix}{self._user}@{hostname}> "
        self._prompt_cfg = f"{role_prefix}{self._user}@{hostname}# "
        mode = getattr(self, "_mode", "op")
        self.prompt_text = self._prompt_cfg if mode == "config" else self._prompt_op

    def _refresh_runtime_context(self) -> None:
        """Refresh matcher/completion state after command set changes."""
        self.command_tree = CommandTree(list(self.parser.get_commands().keys()))
        self.matcher = CommandMatcher(self.parser.get_commands(), self.parser)
        self.completer.command_tree = self.command_tree

    def _resolve_other_re_name(self) -> Optional[str]:
        """Return opposite RE name (re0<->re1) from current/master context."""
        current = self._active_re_name
        current_lower = current.lower() if isinstance(current, str) else None
        if current_lower not in {"re0", "re1"}:
            current = (
                self.parser.get_master_re_name()
                if hasattr(self.parser, "get_master_re_name")
                else None
            )
            current_lower = current.lower() if isinstance(current, str) else None
        if current_lower == "re0":
            return "re1"
        if current_lower == "re1":
            return "re0"
        return None

    def _maybe_switch_re_after_command(self, user_command: str, output: str) -> None:
        """Switch var-log context when user logs into other routing-engine."""
        resolved = self.matcher.find_best_match(user_command) or user_command
        if not re.match(
            r"^request\s+routing-engine\s+login\s+other-routing-engine(?:\s|$)",
            resolved,
            flags=re.IGNORECASE,
        ):
            return

        target_re = self._resolve_other_re_name()
        if not target_re:
            return

        target_dir = self._re_var_log_dirs.get(target_re)
        if not target_dir or not hasattr(self.parser, "load_var_log_dir"):
            return

        try:
            loaded = self.parser.load_var_log_dir(target_dir)
        except RSIParseError:
            loaded = False

        if loaded:
            self._active_re_name = target_re
            self._in_backup_re_session = True
            self._update_prompts()
            self._refresh_runtime_context()
            print_formatted_text(
                HTML(f"<ansiblue>Switched var logs to {target_re}: {target_dir}</ansiblue>")
            )

    def _exit_backup_re_session(self) -> None:
        """Exit backup RE session and return var-log context to master RE."""
        master_re = (
            self.parser.get_master_re_name()
            if hasattr(self.parser, "get_master_re_name")
            else None
        )
        target_re = master_re if master_re else self._resolve_other_re_name()
        target_dir = self._re_var_log_dirs.get(target_re) if target_re else None

        if target_re and target_dir and hasattr(self.parser, "load_var_log_dir"):
            try:
                self.parser.load_var_log_dir(target_dir)
            except RSIParseError:
                pass

        self._active_re_name = target_re
        self._in_backup_re_session = False
        self._update_prompts()
        self._refresh_runtime_context()
        print_formatted_text(
            HTML(f"<ansiblue>Returned to {target_re}: {target_dir}</ansiblue>")
        )

    def run(self) -> None:
        """Start the interactive CLI session."""
        print_formatted_text(HTML("<ansigreen>Junos CLI Simulator</ansigreen>"))
        print_formatted_text(
            HTML(
                f"<ansiblue>Loaded {len(self.parser.get_commands())} commands from RSI</ansiblue>"
            )
        )
        pager_status = "enabled" if is_paging_enabled() else "disabled"
        print_formatted_text(
            HTML(
                f"<ansibrightblack>Pager is {pager_status} (use 'pager on/off' to control)</ansibrightblack>"
            )
        )
        print_formatted_text("Type 'quit' or 'exit' to leave, '?' for help\n")

        while True:
            try:
                # In Junos, config mode shows [edit ...] above the prompt
                if self._mode == "config":
                    edit_suffix = " " + " ".join(self._edit_path) if self._edit_path else ""
                    print_formatted_text(HTML(f"<ansibrightblack>[edit{edit_suffix}]</ansibrightblack>"))
                used_default = self._next_default_input
                user_input = prompt(
                    self.prompt_text,
                    completer=self.completer,
                    history=self.history,
                    complete_while_typing=False,
                    key_bindings=self._key_bindings,
                    default=used_default,
                ).rstrip()
                # Only clear the default if it wasn't updated during the prompt
                # (e.g., '?' key binding sets _next_default_input for the next prompt).
                if self._next_default_input == used_default:
                    self._next_default_input = ""

                if not user_input.strip():
                    continue

                # Junos-style abbreviation expansion (e.g. 'sh' -> 'show', 'edit prot' -> 'edit protocols')
                user_input = self._expand_abbreviations(user_input)

                # Handle special commands
                if user_input.lower() in ["quit"]:
                    print_formatted_text("Goodbye!")
                    break
                # In operational mode, exit quits (or returns to master RE if in backup session).
                if user_input.lower() in ["exit"] and self._mode == "op":
                    if self._in_backup_re_session:
                        self._exit_backup_re_session()
                        continue
                    print_formatted_text("Goodbye!")
                    break

                # Handle pager control commands
                if user_input.lower() in ["set pager on", "pager on"]:
                    set_paging_enabled(True)
                    print_formatted_text("Pager enabled")
                    continue
                elif user_input.lower() in ["set pager off", "pager off"]:
                    set_paging_enabled(False)
                    print_formatted_text("Pager disabled")
                    continue

                # Handle help request
                if user_input.endswith("?"):
                    help_text = user_input[:-1]
                    ends_with_space = help_text.endswith(" ")
                    completed = self._complete_single_help_candidate(
                        help_text.strip(), ends_with_space=ends_with_space
                    )
                    if completed is not None:
                        self._next_default_input = completed
                        continue
                    self._show_help(help_text.strip(), ends_with_space=ends_with_space)
                    continue

                # Handle config-mode commands (configure/edit/show/exit/top/up)
                if self._handle_config_mode(user_input):
                    continue

                # Execute command (operational mode passthrough)
                self._execute_command(user_input)

            except (KeyboardInterrupt, EOFError):
                print_formatted_text("\nGoodbye!")
                break
            except Exception as e:
                print_formatted_text(HTML(f"<ansired>Error: {e}</ansired>"))

    def _handle_config_mode(self, command: str) -> bool:
        """Handle Junos-like configuration mode commands.

        Returns True if handled (no further execution should occur).
        """
        cmd = command.strip()
        low = cmd.lower()

        # Enter configuration mode
        if low in ["configure", "conf", "config"]:
            if self._mode != "config":
                self._mode = "config"
                self._edit_path = []
                self.prompt_text = self._prompt_cfg
                print_formatted_text("Entering configuration mode")
            return True

        # If not in config mode, nothing to do
        if self._mode != "config":
            return False

        # Exit / up / top behavior
        if low in ["top"]:
            self._edit_path = []
            return True
        if low in ["up", "exit"]:
            if self._edit_path:
                self._edit_path.pop()
            else:
                # Leave config mode
                self._mode = "op"
                self.prompt_text = self._prompt_op
                print_formatted_text("Exiting configuration mode")
            return True

        # edit <path...>
        if low.startswith("edit"):
            parts = cmd.split()
            if len(parts) == 1:
                return True
            # In Junos, 'edit <path>' is relative to current [edit ...] context.
            # Users can use 'top' first to jump back to root.
            rel = [p for p in parts[1:] if p]
            self._edit_path = self._edit_path + rel
            return True

        # In config mode, show/show <path> should resolve against configuration hierarchy.
        # Support pipes: show | match ..., show chassis | display set, etc.
        if self.pipe_processor.has_pipes(cmd):
            base_command, pipe_chain = self.pipe_processor.parse_command(cmd)
            base_tokens = self._split_like_junos(base_command.strip())
            if base_tokens and base_tokens[0].lower() == "show":
                config_path = self._edit_path + base_tokens[1:]
                base_output = self._get_config_output_for_path(config_path)
                if base_output is None:
                    print_formatted_text(HTML("<ansired>% No configuration found in RSI</ansired>"))
                    return True
                final_output = self.pipe_processor.process_pipes(base_output, pipe_chain)
                disable_paging = self.pipe_processor.should_disable_paging()
                self._display_output(final_output, force_no_paging=disable_paging)
                return True

        show_tokens = self._split_like_junos(cmd)
        if show_tokens and show_tokens[0].lower() == "show":
            config_path = self._edit_path + show_tokens[1:]
            output = self._get_config_output_for_path(config_path)
            if output is None:
                print_formatted_text(HTML("<ansired>% No configuration found in RSI</ansired>"))
                return True
            if not output.strip():
                print_formatted_text(
                    HTML("<ansibrightblack>% No configuration at this level</ansibrightblack>")
                )
                return True
            self._display_output(output)
            return True

        return False

    def _build_key_bindings(self) -> KeyBindings:
        """Key bindings to mimic Junos abbreviation behavior.

        In Junos, typing an unambiguous abbreviation followed by a space expands
        the token on the command line (e.g. 'edi pr<space>' -> 'edit protocols ').
        """
        kb = KeyBindings()

        @kb.add("tab")
        def _(event) -> None:
            """Trigger Junos-style completion list on Tab key."""
            buf = event.app.current_buffer
            current = buf.text
            # Mirror Junos behavior: show completions and keep current input.
            self._next_default_input = current
            buf.text = current + "?"
            buf.cursor_position = len(buf.text)
            buf.validate_and_handle()

        @kb.add(" ")
        def _(event) -> None:
            buf = event.app.current_buffer
            # Only operate on the text before cursor; keep it simple and only expand at end-of-line.
            if buf.cursor_position != len(buf.text):
                buf.insert_text(" ")
                return

            # If the user has just typed a trailing pipe (e.g. "|" at EOL),
            # don't run abbreviation expansion because it may normalize
            # spacing and remove the user's "|". Simply insert a space.
            text_rstripped = buf.text.rstrip()
            if text_rstripped.endswith("|"):
                buf.insert_text(" ")
                return

            # Normal abbreviation expansion
            expanded = self._expand_abbreviations(text_rstripped)
            if expanded != text_rstripped:
                buf.text = expanded
                buf.cursor_position = len(buf.text)
            buf.insert_text(" ")

        @kb.add("?")
        def _(event) -> None:
            """Trigger help without requiring Enter, safely.

            We avoid printing from inside the key event loop (can crash on some
            prompt_toolkit/python combos). Instead, we "submit" a synthetic
            input ending with '?' and let the main loop render help.

            To mimic Junos UX, we preserve the current input and prefill it on
            the next prompt.
            """
            buf = event.app.current_buffer
            current = buf.text  # full current input
            # After showing help, keep the original input on the line (without '?'),
            # like real Junos does.
            self._next_default_input = current
            buf.text = current + "?"
            buf.cursor_position = len(buf.text)
            buf.validate_and_handle()

        return kb

    def _expand_abbreviations(self, command: str) -> str:
        """Expand Junos-style abbreviations when unambiguous.

        Examples:
        - sh            -> show
        - sh ver        -> show version   (if unique in command tree)
        - conf/config   -> configure/configure (handled by config-mode handler)
        - edit prot     -> edit protocols (based on config tree, if available)
        """
        cmd = command.strip()
        if not cmd:
            return cmd

        # Handle pipe commands with support for partial pipe abbreviations
        # (e.g., '| dis' -> '| display', '| display s' -> '| display set').
        if self.pipe_processor.has_pipes(cmd):
            cmd = self._expand_pipe_abbreviations(cmd)
            try:
                base, pipe_chain = self.pipe_processor.parse_command(cmd)
            except Exception:
                return cmd

            expanded_base = self._expand_base_command(base)
            # Rebuild command while preserving pipe-argument boundaries.
            rebuilt = expanded_base
            for pipe_cmd, args in pipe_chain:
                rebuilt += " | " + " ".join([pipe_cmd] + [shlex.quote(a) for a in args])
            # If the original command ended with a trailing pipe (user typed
            # a '|' and hasn't added the next segment yet), preserve that
            # trailing separator so manual typing isn't lost when expansion
            # normalizes spacing.
            if cmd.rstrip().endswith("|"):
                rebuilt += " | "
            return rebuilt

        return self._expand_base_command(cmd)

    def _split_pipes_lax(self, command: str) -> List[str]:
        """Split command on '|' outside quotes, allowing partial pipe syntax."""
        parts: List[str] = []
        current_part = ""
        in_quotes = False
        quote_char = None

        for char in command:
            if char in ('"', "'") and not in_quotes:
                in_quotes = True
                quote_char = char
                current_part += char
            elif char == quote_char and in_quotes:
                in_quotes = False
                quote_char = None
                current_part += char
            elif char == "|" and not in_quotes:
                parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char

        parts.append(current_part.strip())
        return parts

    def _expand_pipe_abbreviations(self, command: str) -> str:
        """Expand the last pipe segment abbreviations for Junos-style space completion."""
        parts = self._split_pipes_lax(command)
        if len(parts) < 2:
            return command

        last = parts[-1].strip()
        if not last:
            return command

        tokens = last.split()
        if not tokens:
            return command

        top_level = [
            "no-more",
            "save",
            "count",
            "match",
            "grep",
            "except",
            "last",
            "find",
            "trim",
            "display",
        ]
        display_subcommands = ["set"]

        # First token expansion (e.g., dis -> display)
        first = tokens[0]
        first_matches = [opt for opt in top_level if opt.startswith(first.lower())]
        if len(first_matches) == 1:
            tokens[0] = first_matches[0]

        # display subcommand expansion (e.g., display s -> display set)
        if tokens[0].lower() == "display" and len(tokens) >= 2:
            second = tokens[1]
            second_matches = [
                opt for opt in display_subcommands if opt.startswith(second.lower())
            ]
            if len(second_matches) == 1:
                tokens[1] = second_matches[0]

        parts[-1] = " ".join(tokens)
        return " | ".join(parts)

    def _expand_base_command(self, base: str) -> str:
        # Config-mode built-ins should expand even if they are not in RSI command tree
        tokens = self._split_like_junos(base)
        if not tokens:
            return base

        first = tokens[0].lower()
        builtins = ["show", "edit", "configure", "config", "conf", "exit", "up", "top", "quit"]
        expanded_first = self._expand_unique_prefix(first, builtins)
        tokens[0] = expanded_first

        # In config mode, expand edit/show path tokens from current hierarchy.
        if self._mode == "config" and expanded_first in ["edit", "show"] and len(tokens) >= 2:
            tokens[1:] = self._expand_edit_path(tokens[1:], base_prefix=self._edit_path)
            return " ".join(tokens)

        # For operational commands, expand along the command tree (token by token)
        if self._mode == "op" and expanded_first not in ["edit"]:
            tokens = self._expand_tokens_via_command_tree(tokens)
            return " ".join(tokens)

        # In config mode, allow 'sh' -> 'show' etc via builtin expansion above.
        return " ".join(tokens)

    def _expand_tokens_via_command_tree(self, tokens: List[str]) -> List[str]:
        """Expand tokens using the command tree when unambiguous.

        For each token in sequence, attempt to expand it by asking the
        command tree for completions of the prefix built so far. If the
        command tree returns exactly one completion at that level, use it;
        otherwise keep the token as-is.
        """
        if not tokens:
            return tokens

        expanded: List[str] = []
        prefix = ""
        for tok in tokens:
            partial = (prefix + " " + tok).strip() if prefix else tok
            completions = self.command_tree.get_completions(partial)
            if len(completions) == 1:
                tok_exp = completions[0]
            else:
                tok_exp = tok
            expanded.append(tok_exp)
            prefix = (prefix + " " + tok_exp).strip()

        return expanded

    def _expand_unique_prefix(self, word: str, options: List[str]) -> str:
        matches = [o for o in options if o.startswith(word)]
        return matches[0] if len(matches) == 1 else word

    def _split_like_junos(self, command: str) -> List[str]:
        # Split like Junos: split on spaces outside quotes, preserving quoted tokens.
        parts: List[str] = []
        current = ""
        in_quotes = False
        quote_char = None

        for ch in command:
            if ch in ('"', "'") and not in_quotes:
                in_quotes = True
                quote_char = ch
                current += ch
            elif ch == quote_char and in_quotes:
                in_quotes = False
                quote_char = None
                current += ch
            elif ch == " " and not in_quotes:
                if current:
                    parts.append(current)
                    current = ""
                else:
                    # skip extra spaces
                    continue
            else:
                current += ch

        if current:
            parts.append(current)
        return parts

    def _expand_edit_path(
        self, path_tokens: List[str], base_prefix: Optional[List[str]] = None
    ) -> List[str]:
        """Expand edit path tokens based on configuration hierarchy (best effort)."""
        if not path_tokens:
            return path_tokens

        # Build or reuse a very small tree: (path_tuple) -> set(child_block_names)
        tree = self._get_config_tree()
        if not tree:
            return path_tokens

        expanded: List[str] = []
        cur_path: List[str] = [p.lower() for p in (base_prefix or [])]
        for tok in path_tokens:
            key = tuple(cur_path)
            children_map = tree.get(key, {})
            children = list(children_map.keys())
            # Only expand single-token blocks (e.g., protocols). If ambiguous or no children known, keep as-is.
            matches = [c for c in children if c.startswith(tok.lower())]
            if len(matches) == 1:
                tok_exp = children_map[matches[0]]
            else:
                tok_exp = tok
            expanded.append(tok_exp)
            cur_path.append(tok_exp.lower())
        return expanded

    def _get_config_tree(self) -> Optional[Dict[Tuple[str, ...], Dict[str, str]]]:
        """Parse root config once into a mapping of path -> child tokens.

        The key is a flattened path (lowercase tokens).
        The value maps token_lower -> token_display (preserve original case for help output).
        """
        if self._cached_config_tree is not None:
            return self._cached_config_tree

        root_cmd = self._pick_root_config_command()
        if not root_cmd:
            self._cached_config_tree = None
            return None
        root_out = self.matcher.get_command_output(root_cmd) or self.parser.get_command_output(root_cmd)
        if not root_out:
            self._cached_config_tree = None
            return None

        tree: Dict[Tuple[str, ...], Dict[str, str]] = {}
        # Track opened blocks as token lists, so braces pop correctly even for blocks like "fpc 0 {"
        block_stack: List[List[str]] = []

        def flatten_stack() -> List[str]:
            flat: List[str] = []
            for blk in block_stack:
                flat.extend(blk)
            return flat

        for raw in root_out.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            # Opening block: "<name> {" or "<name> <arg> {"
            if "{" in line:
                before = line.split("{", 1)[0].strip().rstrip(";")
                if not before:
                    pass
                else:
                    tokens_raw = before.split()
                    tokens = [t.lower() for t in tokens_raw]
                    key_prefix = flatten_stack()
                    # Add tokens as a chain so help/completion can work at any position.
                    # Example: "group external {" yields:
                    # - key=<...> children include "group"
                    # - key=<... group> children include "external"
                    for i, tok_lower in enumerate(tokens):
                        key = tuple(key_prefix + tokens[:i])
                        display = tokens_raw[i]
                        tree.setdefault(key, {})[tok_lower] = display
                    block_stack.append(tokens)

            # Close braces pop stack (handle lines that include both "{" and "}")
            close_count = line.count("}")
            for _ in range(close_count):
                if block_stack:
                    block_stack.pop()

        self._cached_config_tree = tree
        return tree

    def _pick_root_config_command(self) -> Optional[str]:
        """Pick best available 'show configuration' command from RSI."""
        if self._cached_root_config_cmd is not None:
            return self._cached_root_config_cmd

        commands = list(self.parser.get_commands().keys())
        # Prefer sanitized omit + except, then plain show configuration, then any show configuration*
        preferred = [
            'show configuration | except SECRET-DATA | display omit',
            'show configuration | except SECRET-DATA | display set',
            'show configuration | display set',
            'show configuration',
        ]
        for p in preferred:
            if p in commands:
                self._cached_root_config_cmd = p
                return p

        for c in commands:
            if c.lower().startswith("show configuration"):
                self._cached_root_config_cmd = c
                return c

        self._cached_root_config_cmd = None
        return None

    def _get_config_output_for_path(self, path: List[str]) -> Optional[str]:
        """Return configuration output scoped to an explicit configuration path."""
        # 1) Try exact 'show configuration <path...>' if RSI has it
        if path:
            direct_cmd = "show configuration " + " ".join(path)
            out = self.matcher.get_command_output(direct_cmd)
            if out is not None:
                return out

        # 2) Try root show configuration variants
        root_cmd = self._pick_root_config_command()
        if not root_cmd:
            return None
        root_out = self.matcher.get_command_output(root_cmd) or self.parser.get_command_output(root_cmd)
        if root_out is None:
            return None

        # 3) If we're at root, return it
        if not path:
            return root_out

        # 4) If output is display set, filter by prefix
        # Detect 'set ' lines
        lines = root_out.splitlines()
        set_lines = [ln for ln in lines if ln.lstrip().startswith("set ")]
        if set_lines:
            prefix = "set " + " ".join(path)
            filtered = [ln for ln in set_lines if ln.startswith(prefix + " ") or ln == prefix]
            return "\n".join(filtered) if filtered else ""

        # 5) Fallback: attempt naive hierarchical extraction by brace tracking
        return self._extract_hier_config_block(root_out, path)

    def _get_config_output_for_current_path(self) -> Optional[str]:
        """Return configuration output scoped to current [edit ...] path."""
        return self._get_config_output_for_path(self._edit_path)

    def _extract_hier_config_block(self, config_text: str, path: List[str]) -> str:
        """Best-effort extraction of hierarchical config block for given path."""
        if not path:
            return config_text

        target = [p.lower() for p in path]
        block_stack: List[List[str]] = []
        collecting = False
        block_depth_at_start: Optional[int] = None
        out_lines: List[str] = []

        def flatten_stack() -> List[str]:
            flat: List[str] = []
            for blk in block_stack:
                flat.extend(blk)
            return flat

        # Simple parser: each '{' pushes one block frame; each '}' pops one.
        # This keeps nesting correct even when block headers contain arguments (e.g., "unit 0 {").
        for raw in config_text.splitlines():
            line = raw.rstrip("\n")
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                if collecting:
                    out_lines.append(line)
                continue

            has_open = "{" in stripped
            close_count = stripped.count("}")

            # Opening block
            if has_open:
                # take token before '{' as block name (e.g. protocols {)
                before = stripped.split("{", 1)[0].strip().rstrip(";")
                if before:
                    block_stack.append([t.lower() for t in before.split()])
                if collecting:
                    out_lines.append(line)
                # Start collecting when flattened stack matches target prefix
                if not collecting and flatten_stack()[: len(target)] == target:
                    collecting = True
                    block_depth_at_start = len(block_stack)

            # Close braces pop blocks (also applies to mixed lines like "foo { }")
            if close_count:
                if collecting and not has_open:
                    out_lines.append(line)
                for _ in range(close_count):
                    if block_stack:
                        block_stack.pop()
                if collecting and block_depth_at_start is not None and len(block_stack) < block_depth_at_start:
                    break
                continue

            # Regular line
            if collecting and not has_open:
                out_lines.append(line)

        return "\n".join(out_lines)

    def _execute_command(self, command: str) -> None:
        """Execute a command and display output."""
        try:
            # Check for pipe commands
            if self.pipe_processor.has_pipes(command):
                self._execute_piped_command(command)
            else:
                self._execute_simple_command(command)
        except PipeError as e:
            print_formatted_text(HTML(f"<ansired>% Pipe error: {e}</ansired>"))

    def _execute_simple_command(self, command: str) -> None:
        """Execute a simple command without pipes."""
        output = self.matcher.get_command_output(command)

        if output is not None:
            # Check if this was handled as an interface command
            is_interface_command = self.matcher._looks_like_interface_command(command)

            if not is_interface_command:
                # For non-interface commands, show execution message if command was fuzzy matched
                best_match = self.matcher.find_best_match(command)
                if best_match and best_match != command:
                    print_formatted_text(
                        HTML(
                            f"<ansibrightblack>% Executing: {best_match}</ansibrightblack>"
                        )
                    )

            if output.strip():
                # Use pager for command output
                self._display_output(output)
            else:
                print_formatted_text(
                    HTML(
                        "<ansibrightblack>% Command completed successfully</ansibrightblack>"
                    )
                )

            # Runtime RE switch: when user logs into other RE, swap var-log source.
            self._maybe_switch_re_after_command(command, output)
        else:
            # Command not found
            print_formatted_text(
                HTML(f"<ansired>% Unknown command: {command}</ansired>")
            )

            # Suggest similar commands
            suggestions = self.matcher.suggest_commands(command)
            if suggestions:
                print_formatted_text(
                    HTML("<ansibrightblack>Did you mean:</ansibrightblack>")
                )
                for suggestion in suggestions[:3]:
                    print_formatted_text(
                        HTML(f"<ansibrightblack>  {suggestion}</ansibrightblack>")
                    )

    def _execute_piped_command(self, command: str) -> None:
        """Execute a command with pipe processing."""
        # Parse the command and pipes
        base_command, pipe_chain = self.pipe_processor.parse_command(command)

        # Execute the base command
        base_output = self.matcher.get_command_output(base_command)

        # For show configuration* pipelines, fall back to config extraction when
        # the exact base command is not present in RSI command keys.
        if base_output is None:
            tokens = self._split_like_junos(base_command)
            if tokens and tokens[0].lower() == "show" and len(tokens) >= 2:
                second = tokens[1].lower()
                if second in {"config", "configuration"}:
                    config_path = tokens[2:]
                    base_output = self._get_config_output_for_path(config_path)

        if base_output is None:
            print_formatted_text(
                HTML(f"<ansired>% Unknown command: {base_command}</ansired>")
            )

            # Suggest similar commands
            suggestions = self.matcher.suggest_commands(base_command)
            if suggestions:
                print_formatted_text(
                    HTML("<ansibrightblack>Did you mean:</ansibrightblack>")
                )
                for suggestion in suggestions[:3]:
                    print_formatted_text(
                        HTML(f"<ansibrightblack>  {suggestion}</ansibrightblack>")
                    )
            return

        # Show what command is being executed if it was fuzzy matched
        is_interface_command = self.matcher._looks_like_interface_command(base_command)

        if not is_interface_command:
            best_match = self.matcher.find_best_match(base_command)
            if best_match and best_match != base_command:
                print_formatted_text(
                    HTML(
                        f"<ansibrightblack>% Executing: {best_match}</ansibrightblack>"
                    )
                )

        # Process through pipe chain
        try:
            final_output = self.pipe_processor.process_pipes(base_output, pipe_chain)

            if final_output.strip():
                # Check if paging should be disabled by pipe commands
                disable_paging = self.pipe_processor.should_disable_paging()
                self._display_output(final_output, force_no_paging=disable_paging)
            else:
                print_formatted_text(
                    HTML(
                        "<ansibrightblack>% Command completed successfully</ansibrightblack>"
                    )
                )
        except PipeError as e:
            print_formatted_text(HTML(f"<ansired>% Pipe error: {e}</ansired>"))

    def _display_output(self, output: str, force_no_paging: bool = False) -> None:
        """Display command output using appropriate method (pager or direct).

        Args:
            output: Text to display
            force_no_paging: If True, disable paging for this output
        """
        if is_paging_enabled() and not force_no_paging:
            # Convert HTML formatting to ANSI for pager
            # For now, use the output directly since it's already plain text from RSI
            display_text(output)
        else:
            print_formatted_text(output)

    def _show_help(self, partial_command: str, ends_with_space: bool = False) -> None:
        """Show help for a partial command.

        In config mode, mimic Junos-style hierarchy help for 'edit ... ?'.
        In op mode, use RSI-derived command tree help (existing behavior).
        """
        lines = self._get_help_lines(partial_command, ends_with_space=ends_with_space)

        if lines:
            for line in lines:
                print_formatted_text(line)

        # Show pipe commands help if no partial command or if asking about pipes
        if not partial_command or "pipe" in partial_command.lower():
            self._show_pipe_help()

    def _complete_single_help_candidate(
        self, partial_command: str, ends_with_space: bool = False
    ) -> Optional[str]:
        """Return completed command when help has exactly one candidate."""
        if not partial_command:
            return None

        pipe_completed = self._complete_single_pipe_help_candidate(
            partial_command, ends_with_space=ends_with_space
        )
        if pipe_completed is not None:
            return pipe_completed

        # Config mode: support hierarchy completion for edit/show paths.
        if self._mode == "config":
            tree = self._get_config_tree()
            if tree:
                tokens = self._split_like_junos(partial_command)
                if tokens and tokens[0].lower() in ["edit", "show"]:
                    path_tokens = [t.lower() for t in tokens[1:]]
                    base_prefix = [p.lower() for p in self._edit_path]
                    if not path_tokens:
                        key = tuple(base_prefix)
                        prefix = ""
                    elif ends_with_space:
                        key = tuple(base_prefix + path_tokens)
                        prefix = ""
                    else:
                        key = tuple(base_prefix + path_tokens[:-1])
                        prefix = path_tokens[-1]

                    children_map = tree.get(key, {})
                    matched = sorted([k for k in children_map.keys() if k.startswith(prefix)])
                    if len(matched) == 1:
                        tok = children_map[matched[0]]
                        completed_tokens = tokens + [tok] if ends_with_space else tokens[:-1] + [tok]
                        return " ".join(completed_tokens) + " "

        # Operational mode (or config fallback): use command tree.
        completions = self.command_tree.get_completions(partial_command if not ends_with_space else partial_command + " ")
        tokens = self._split_like_junos(partial_command)
        if not tokens:
            return None

        if len(completions) == 1:
            tok = completions[0]
            # Already complete at this token; don't auto-complete to the same text.
            if not ends_with_space and tok.lower() == tokens[-1].lower():
                return None
            completed_tokens = tokens + [tok] if ends_with_space else tokens[:-1] + [tok]
            return " ".join(completed_tokens) + " "

        # Junos-like behavior: if multiple candidates share a longer common
        # prefix, auto-complete to that prefix without adding trailing space.
        if not ends_with_space and len(completions) > 1:
            common_prefix = self._longest_common_prefix(completions)
            current = tokens[-1]
            if (
                common_prefix
                and len(common_prefix) > len(current)
                and common_prefix.lower().startswith(current.lower())
            ):
                completed_tokens = tokens[:-1] + [common_prefix]
                return " ".join(completed_tokens)

        return None

    def _longest_common_prefix(self, values: List[str]) -> str:
        """Return case-insensitive longest common prefix across candidate tokens."""
        if not values:
            return ""

        prefix = values[0]
        for value in values[1:]:
            max_len = min(len(prefix), len(value))
            i = 0
            while i < max_len and prefix[i].lower() == value[i].lower():
                i += 1
            prefix = prefix[:i]
            if not prefix:
                break

        return prefix

    def _complete_single_pipe_help_candidate(
        self, partial_command: str, ends_with_space: bool = False
    ) -> Optional[str]:
        """Return completed piped command when the candidate is unique."""
        if "|" not in partial_command:
            return None

        parts = self._split_pipes_lax(partial_command)
        if len(parts) < 2:
            return None

        base = parts[0]
        current_pipe = parts[-1].strip()
        tokens = current_pipe.split() if current_pipe else []

        top_level = [
            "no-more",
            "save",
            "count",
            "match",
            "grep",
            "except",
            "last",
            "find",
            "trim",
            "display",
        ]
        display_subcommands = ["set"]

        # No pipe token yet -> ambiguous list, no auto-complete.
        if not tokens:
            return None

        # First token completion
        if len(tokens) == 1 and not ends_with_space:
            matches = [c for c in top_level if c.startswith(tokens[0].lower())]
            if len(matches) != 1:
                return None
            parts[-1] = matches[0]
            return " | ".join(parts) + " "

        first = tokens[0].lower()
        if first != "display":
            return None

        # After "display " complete subcommand
        if len(tokens) == 1 and ends_with_space:
            if len(display_subcommands) != 1:
                return None
            parts[-1] = f"display {display_subcommands[0]}"
            return " | ".join(parts) + " "

        # Complete second token (e.g., display s)
        if len(tokens) >= 2 and not ends_with_space:
            matches = [s for s in display_subcommands if s.startswith(tokens[1].lower())]
            if len(matches) != 1:
                return None
            tokens[1] = matches[0]
            parts[-1] = " ".join(tokens)
            return " | ".join(parts) + " "

        return None

    def _get_help_lines(self, partial_command: str, ends_with_space: bool = False) -> List[str]:
        """Return help output lines (formatted as plain strings)."""
        pipe_help = self._get_pipe_help_lines(partial_command, ends_with_space=ends_with_space)
        if pipe_help is not None:
            return pipe_help

        if self._mode == "config":
            cfg_lines = self._get_config_help_lines(partial_command, ends_with_space=ends_with_space)
            if cfg_lines is not None:
                return cfg_lines

        # Op-mode: "show interfaces [extensive|terse|queue] ?" -> list all interfaces from RSI
        if self._mode == "op" and self.parser and hasattr(self.parser, "get_available_interfaces"):
            low = partial_command.strip().lower()

            if low == "show log" and hasattr(self.parser, "has_var_logs") and self.parser.has_var_logs():
                return self.parser.get_log_help_lines()

            if (
                low.startswith("show log ")
                and hasattr(self.parser, "has_var_logs")
                and self.parser.has_var_logs()
            ):
                prefix = partial_command.strip()[len("show log ") :]
                files = [name for name in self.parser.get_log_files() if name.startswith(prefix)]
                if files:
                    return ["Possible completions:"] + [f"{name}" for name in files]
                return ["Possible completions:", "(no matching log files)"]

            if low in (
                "show interfaces",
                "show interfaces extensive",
                "show interfaces extensive no-forwarding",
                "show interfaces terse",
                "show interfaces queue",
                "show interfaces queue no-forwarding",
            ):
                ifaces = sorted(self.parser.get_available_interfaces())
                if ifaces:
                    return ["Possible completions:"] + [f"> {name}" for name in ifaces]
                return ["Possible completions:", "(no interfaces in RSI)"]

        # Op-mode / fallback
        help_lines = self.command_tree.get_help(partial_command)
        if help_lines:
            # get_help() returns "Unknown command: ..." when there are no matches;
            # strip that so we don't leak an error line inside "Possible completions:"
            if help_lines[0].startswith("Unknown command:"):
                return ["Possible completions:"]
            return ["Possible completions:"] + help_lines
        return ["Possible completions:"]

    def _get_pipe_help_lines(
        self, partial_command: str, ends_with_space: bool = False
    ) -> Optional[List[str]]:
        """Return pipe-specific help completions, or None when not in pipe context."""
        if "|" not in partial_command:
            return None

        parts = self._split_pipes_lax(partial_command)
        if len(parts) < 2:
            return None

        current_pipe = parts[-1].strip()
        tokens = current_pipe.split() if current_pipe else []

        top_level = [
            "no-more",
            "save",
            "count",
            "match",
            "grep",
            "except",
            "last",
            "find",
            "trim",
            "display",
        ]
        display_subcommands = ["set"]

        lines = ["Possible completions:"]

        if not tokens:
            return lines + [f"> {cmd}" for cmd in sorted(top_level)]

        if len(tokens) == 1 and not ends_with_space:
            prefix = tokens[0].lower()
            matches = [cmd for cmd in top_level if cmd.startswith(prefix)]
            return lines + [f"> {cmd}" for cmd in sorted(matches)]

        first = tokens[0].lower()
        if first != "display":
            return lines

        if len(tokens) == 1 and ends_with_space:
            return lines + [f"> {sub}" for sub in sorted(display_subcommands)]

        if len(tokens) >= 2 and not ends_with_space:
            prefix = tokens[1].lower()
            matches = [sub for sub in display_subcommands if sub.startswith(prefix)]
            return lines + [f"> {sub}" for sub in sorted(matches)]

        # "| display set ?" — segment complete, suggest chaining another pipe
        if len(tokens) >= 2 and ends_with_space:
            return lines + [f"> | {cmd}" for cmd in sorted(top_level)]

        return lines

    def _get_config_help_lines(
        self, partial_command: str, ends_with_space: bool = False
    ) -> Optional[List[str]]:
        """Return config-mode help lines, or None if not applicable."""
        tree = self._get_config_tree()
        if not tree:
            return None

        tokens = self._split_like_junos(partial_command)
        if not tokens or tokens[0].lower() not in ["edit", "show"]:
            return None

        path_tokens = [t.lower() for t in tokens[1:]]
        base_prefix = [p.lower() for p in self._edit_path]

        if not path_tokens:
            key = tuple(base_prefix)
            prefix = ""
        else:
            if ends_with_space:
                key = tuple(base_prefix + path_tokens)
                prefix = ""
            else:
                key = tuple(base_prefix + path_tokens[:-1])
                prefix = path_tokens[-1]

        children_map = tree.get(key, {})
        matched = sorted([k for k in children_map.keys() if k.startswith(prefix)])
        lines = ["Possible completions:"]
        for k in matched:
            lines.append(f"> {children_map[k]}")
        return lines

    def _show_pipe_help(self) -> None:
        """Show help for pipe commands."""
        print_formatted_text(
            HTML(
                "<ansibrightblack>\nAvailable pipe commands (use after |):</ansibrightblack>"
            )
        )

        pipe_help = [
            "  no-more          - Disable paging for this command",
            "  save <filename>   - Save output to file",
            "  count            - Count lines in output",
            "  match <pattern>   - Show lines matching pattern (regex)",
            "  except <pattern>  - Show lines NOT matching pattern (regex)",
            "  last <N>         - Show last N lines",
            "  find <pattern>    - Show from first matching line onward",
            "  trim <N>         - Remove N characters from left of each line",
            "  display set      - Convert config to set commands",
            "",
            "Examples:",
            "  show version | no-more",
            "  show config | save backup.conf",
            "  show interfaces | match ge-0/0/0",
            "  show config | display set | save commands.txt",
        ]

        for line in pipe_help:
            print_formatted_text(line)


def main() -> None:
    """Main entry point for CLI."""
    import argparse
    from importlib.metadata import PackageNotFoundError, version

    def resolve_cli_version() -> str:
        try:
            return version("rsi-explorer-jtac")
        except PackageNotFoundError:
            return "unknown"

    def build_remote_spec(host: str, path: str, user: Optional[str]) -> str:
        host_spec = f"{user}@{host}" if user else host
        return f"{host_spec}:{path}"

    def _safe_extract_archive(archive_path: Path, destination: Path) -> None:
        """Safely extract tar/zip archives without allowing path traversal."""

        def is_within_directory(base_dir: Path, target_path: Path) -> bool:
            try:
                base = base_dir.resolve()
                target = target_path.resolve()
                return str(target).startswith(str(base))
            except OSError:
                return False

        name_lower = archive_path.name.lower()
        if name_lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                for member_name in zf.namelist():
                    member_target = destination / member_name
                    if not is_within_directory(destination, member_target):
                        raise RSIParseError(
                            f"Unsafe path found while extracting archive: {archive_path}"
                        )
                zf.extractall(destination)
            return

        # tar-like archives: .tgz, .tar.gz, .tar
        with tarfile.open(archive_path, "r:*") as tar:
            for member in tar.getmembers():
                member_target = destination / member.name
                if not is_within_directory(destination, member_target):
                    raise RSIParseError(
                        f"Unsafe path found while extracting archive: {archive_path}"
                    )
            tar.extractall(destination)

    def _archive_folder_name(archive_name: str) -> str:
        """Return folder name derived from archive filename."""
        lower = archive_name.lower()
        suffixes = [".tar.gz", ".tgz", ".zip", ".tar"]
        for suffix in suffixes:
            if lower.endswith(suffix):
                return archive_name[: -len(suffix)]
        return Path(archive_name).stem

    def prepare_case_archives(case_dir: Path) -> List[Path]:
        """Prepare archive files under case_dir.

        For each `<name>.tgz/.tar.gz/.tar/.zip`:
        1) create `<name>/`
        2) move archive into that folder
        3) extract it there (idempotent if already extracted)
        """
        prepared_dirs: List[Path] = []
        archives = sorted(
            [
                p
                for p in case_dir.iterdir()
                if p.is_file()
                and p.name.lower().endswith((".tgz", ".tar.gz", ".tar", ".zip"))
            ],
            key=lambda p: p.name.lower(),
        )

        for archive in archives:
            target_dir = case_dir / _archive_folder_name(archive.name)
            target_dir.mkdir(parents=True, exist_ok=True)

            target_archive = target_dir / archive.name
            archive_to_use = archive

            if archive != target_archive:
                if not target_archive.exists():
                    shutil.move(str(archive), str(target_archive))
                archive_to_use = target_archive

            # If directory only contains the archive itself, assume not extracted yet.
            extracted_items = [
                p for p in target_dir.iterdir() if p.name != archive_to_use.name
            ]
            if not extracted_items:
                _safe_extract_archive(archive_to_use, target_dir)

            prepared_dirs.append(target_dir)

        # Idempotency: after first run, archives are moved into per-archive
        # directories and case root may no longer contain *.tgz files. In that
        # state, reuse existing subdirectories as scan roots for var-log lookup.
        if not prepared_dirs:
            prepared_dirs = [
                p
                for p in sorted(case_dir.iterdir(), key=lambda p: p.name.lower())
                if p.is_dir()
            ]

        return prepared_dirs

    def pick_rsi_file_from_case(case_dir: Path) -> Path:
        """Pick best RSI file from a case directory."""
        patterns = ["*RSI*.log", "*RSI*.txt", "*.log", "*.txt"]
        for pat in patterns:
            candidates = sorted(case_dir.glob(pat), key=lambda p: p.name.lower())
            if candidates:
                return candidates[0]
        raise RSIParseError(f"No RSI file found under case directory: {case_dir}")

    def find_var_log_dirs_from_prepared(prepared_dirs: List[Path]) -> Dict[str, Path]:
        """Build RE-tagged var-log map from prepared archive folders."""
        mapped: Dict[str, Path] = {}
        for base in prepared_dirs:
            scan_candidates = (
                base / "var-re0",
                base / "var" / "log",
                base / "var" / "var" / "log",
                base / "varlog",
            )
            for c in scan_candidates:
                if not (c.exists() and c.is_dir()):
                    continue
                marker = f"{str(base).lower()} {str(c).lower()}"
                if "re0" in marker and "re0" not in mapped:
                    mapped["re0"] = c
                elif "re1" in marker and "re1" not in mapped:
                    mapped["re1"] = c
        return mapped

    def find_var_log_dir_from_prepared(
        prepared_dirs: List[Path], preferred_re_name: Optional[str] = None
    ) -> Optional[Path]:
        """Find best var-log directory from prepared archive folders."""
        candidates: List[Path] = []
        for base in prepared_dirs:
            for c in (
                base / "var-re0",
                base / "var" / "log",
                base / "var" / "var" / "log",
                base / "varlog",
            ):
                if c.exists() and c.is_dir():
                    candidates.append(c)

        if not candidates:
            return None

        if preferred_re_name:
            preferred = [
                c
                for c in candidates
                if preferred_re_name.lower() in str(c.parent).lower()
                or preferred_re_name.lower() in str(c).lower()
            ]
            if preferred:
                return sorted(preferred, key=lambda p: str(p))[0]

        # Prefer RE0-like logs first for device-centric debug workflows.
        re0 = [c for c in candidates if "re0" in str(c).lower()]
        return sorted(re0 or candidates, key=lambda p: str(p))[0]

    def download_remote_rsi_file(
        remote_host: str,
        remote_path: str,
        remote_user: Optional[str],
        remote_port: int,
        destination_dir: str,
    ) -> str:
        scp_path = shutil.which("scp")
        if not scp_path:
            raise RSIParseError(
                "Remote download requires the `scp` command to be installed and available in PATH."
            )

        remote_spec = build_remote_spec(remote_host, remote_path, remote_user)
        local_name = Path(remote_path).name or "downloaded.rsi"
        local_path = Path(destination_dir) / local_name

        cmd = [scp_path]
        if remote_port != 22:
            cmd.extend(["-P", str(remote_port)])
        cmd.extend([remote_spec, str(local_path)])

        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "").strip()
            if detail:
                raise RSIParseError(
                    f"Failed to download remote RSI file from {remote_spec}: {detail}"
                ) from exc
            raise RSIParseError(
                f"Failed to download remote RSI file from {remote_spec}: scp exited with status {exc.returncode}"
            ) from exc

        return str(local_path)

    parser_arg = argparse.ArgumentParser(description="RSI CLI Simulator")
    parser_arg.add_argument(
        "--version", action="version", version=f"%(prog)s {resolve_cli_version()}"
    )
    parser_arg.add_argument(
        "rsi_file",
        help="Path to RSI file, or a case directory containing RSI logs and .tgz archives",
    )
    parser_arg.add_argument(
        "--no-pager", action="store_true", help="Disable pager for output"
    )
    parser_arg.add_argument(
        "--pager-threshold",
        type=float,
        default=0.8,
        help="Paging threshold as ratio of terminal height (0.0-1.0, default: 0.8)",
    )
    parser_arg.add_argument(
        "--xml-output",
        action="store_true",
        help="Enable XML output mode (requires device connectivity)",
    )
    parser_arg.add_argument(
        "--export-xml",
        metavar="DIR",
        help="Export all commands as XML files to specified directory",
    )
    parser_arg.add_argument(
        "--xml-report", action="store_true", help="Generate XML conversion report"
    )
    parser_arg.add_argument(
        "--build-xml-mappings",
        action="store_true",
        help="Build command to XMLRPC mappings using device (requires connectivity)",
    )
    parser_arg.add_argument(
        "--remote-host",
        help="Download RSI file from a remote host via scp before starting the CLI",
    )
    parser_arg.add_argument(
        "--remote-user",
        help="Remote username to use with --remote-host (defaults to current SSH user)",
    )
    parser_arg.add_argument(
        "--remote-port",
        type=int,
        default=22,
        help="SSH port for --remote-host downloads (default: 22)",
    )
    parser_arg.add_argument(
        "--download-dir",
        help="Directory to persist downloaded remote RSI files and reuse them on later runs",
    )
    parser_arg.add_argument(
        "--var-log-dir",
        help="Optional local directory for var logs (for example, /volume/.../var-re0)",
    )
    parser_arg.add_argument(
        "--refresh-download",
        action="store_true",
        help="Force re-downloading even when cached file exists in --download-dir",
    )

    args = parser_arg.parse_args()

    if args.remote_user and not args.remote_host:
        parser_arg.error("--remote-user requires --remote-host")
    if args.remote_port != 22 and not args.remote_host:
        parser_arg.error("--remote-port requires --remote-host")
    if args.download_dir and not args.remote_host:
        parser_arg.error("--download-dir requires --remote-host")
    if args.refresh_download and not args.download_dir:
        parser_arg.error("--refresh-download requires --download-dir")

    # Configure pager before creating CLI
    if args.no_pager:
        set_paging_enabled(False)

    try:
        temp_dir = None
        prepared_archive_dirs: List[Path] = []
        re_var_log_dirs: Dict[str, Path] = {}
        rsi_file_path = args.rsi_file

        # Local directory mode: auto-prepare archives and select RSI file.
        local_input_path = Path(args.rsi_file).expanduser()
        if not args.remote_host and local_input_path.exists() and local_input_path.is_dir():
            print_formatted_text(
                HTML(f"<ansiblue>Preparing case directory archives: {local_input_path}</ansiblue>")
            )
            prepared_archive_dirs = prepare_case_archives(local_input_path)
            selected_rsi = pick_rsi_file_from_case(local_input_path)
            rsi_file_path = str(selected_rsi)
            print_formatted_text(
                HTML(f"<ansiblue>Using RSI file: {selected_rsi}</ansiblue>")
            )

        if args.remote_host:
            remote_spec = build_remote_spec(args.remote_host, args.rsi_file, args.remote_user)
            if args.download_dir:
                persistent_dir = Path(args.download_dir).expanduser()
                persistent_dir.mkdir(parents=True, exist_ok=True)
                local_name = Path(args.rsi_file).name or "downloaded.rsi"
                persistent_path = persistent_dir / local_name

                if persistent_path.exists() and not args.refresh_download:
                    print_formatted_text(
                        HTML(
                            f"<ansiblue>Using cached RSI file: {persistent_path}</ansiblue>"
                        )
                    )
                    rsi_file_path = str(persistent_path)
                else:
                    print_formatted_text(
                        HTML(
                            f"<ansiblue>Downloading RSI file from {remote_spec} to {persistent_dir}...</ansiblue>"
                        )
                    )
                    rsi_file_path = download_remote_rsi_file(
                        args.remote_host,
                        args.rsi_file,
                        args.remote_user,
                        args.remote_port,
                        str(persistent_dir),
                    )
            else:
                temp_dir = tempfile.TemporaryDirectory(prefix="rsi-cli-")
                print_formatted_text(
                    HTML(f"<ansiblue>Downloading RSI file from {remote_spec}...</ansiblue>")
                )
                rsi_file_path = download_remote_rsi_file(
                    args.remote_host,
                    args.rsi_file,
                    args.remote_user,
                    args.remote_port,
                    temp_dir.name,
                )

        # Determine if XML functionality is needed
        needs_xml = (
            args.xml_output
            or args.export_xml
            or args.xml_report
            or args.build_xml_mappings
        )

        if needs_xml:
            # Create device client for XML functionality
            device_client = create_device_client()
            parser = RSIXMLParser(device_client, template_dir=None)
            print_formatted_text(
                HTML("<ansiblue>XML mode enabled - using Modular Template System</ansiblue>")
            )
        else:
            parser = RSIParser()

        parser.parse_file(rsi_file_path)

        # Optional explicit var-log directory (or rely on parser auto-discovery).
        if args.var_log_dir:
            parser.load_var_log_dir(args.var_log_dir)
        elif prepared_archive_dirs and hasattr(parser, "load_var_log_dir"):
            re_var_log_dirs = find_var_log_dirs_from_prepared(prepared_archive_dirs)
            preferred_re_name = (
                parser.get_master_re_name()
                if hasattr(parser, "get_master_re_name")
                else None
            )
            detected_var_log = find_var_log_dir_from_prepared(
                prepared_archive_dirs, preferred_re_name=preferred_re_name
            )
            if detected_var_log:
                parser.load_var_log_dir(detected_var_log)
                print_formatted_text(
                    HTML(
                        f"<ansiblue>Loaded var logs from: {detected_var_log}</ansiblue>"
                    )
                )

        # Handle XML-specific operations
        if needs_xml and isinstance(parser, RSIXMLParser):
            if args.build_xml_mappings:
                print_formatted_text(
                    HTML("<ansiblue>Building XML command mappings...</ansiblue>")
                )
                parser.build_xml_mappings()
                print_formatted_text(
                    HTML("<ansigreen>XML mappings built successfully!</ansigreen>")
                )

            if args.export_xml:
                print_formatted_text(
                    HTML(
                        f"<ansiblue>Exporting XML files to {args.export_xml}...</ansiblue>"
                    )
                )
                file_mapping = parser.export_xml_files(args.export_xml)
                print_formatted_text(
                    HTML(
                        f"<ansigreen>Exported {len(file_mapping)} XML files</ansigreen>"
                    )
                )
                for cmd, path in file_mapping.items():
                    print(f"  {cmd} -> {path}")

            if args.xml_report:
                print_formatted_text(
                    HTML("<ansiblue>Generating XML conversion report...</ansiblue>")
                )
                report = parser.get_conversion_report()
                print_formatted_text(
                    HTML("<ansicyan>XML Conversion Report:</ansicyan>")
                )
                print(f"Total commands: {report['total_commands']}")
                print(f"Successful conversions: {report['successful_conversions']}")
                print(f"Failed conversions: {report['failed_conversions']}")
                print(f"XMLRPC mapped: {report['xmlrpc_mapped']}")
                print(f"Conversion rate: {report['conversion_rate']:.1%}")
                print(f"Mapping rate: {report['mapping_rate']:.1%}")

                if report["failed_commands"]:
                    print_formatted_text(HTML("<ansired>Failed commands:</ansired>"))
                    for cmd in report["failed_commands"][:10]:  # Show first 10
                        print(f"  {cmd}")
                    if len(report["failed_commands"]) > 10:
                        print(f"  ... and {len(report['failed_commands']) - 10} more")

                # Exit after report if not in interactive mode
                if not args.xml_output:
                    return

        cli = JunosCLI(parser, re_var_log_dirs=re_var_log_dirs)
        cli.run()

    except RSIParseError as e:
        print(f"Error parsing RSI file: {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(f"RSI file not found: {args.rsi_file}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        if 'temp_dir' in locals() and temp_dir is not None:
            temp_dir.cleanup()


if __name__ == "__main__":
    main()
