#!/usr/bin/env python3
"""
ecat.py – embedded cat
"""
import os
import re
import subprocess
import sys
import urllib.request
from typing import List

from .common import get_question
from markdownify import markdownify as md


# --------------------------------------------------------------------------- #
#  Helpers
# --------------------------------------------------------------------------- #
def _is_url(token: str) -> bool:
    """Check if token is a valid HTTP/HTTPS URL"""
    url_pattern = r"^https?://"
    return bool(re.match(url_pattern, token))


def _read_file(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return f"```{path}\n{fh.read()}\n```"


def _read_stdin() -> str:
    content = get_question()
    if not content:
        sys.stderr.write("Error: No content provided\n")
        sys.stderr.flush()
        return ""
    return content.rstrip()


def _fetch_url(url: str) -> str:
    """Fetch URL and convert HTML to Markdown"""
    try:
        with urllib.request.urlopen(url) as response:
            html_content = response.read().decode("utf-8")
            markdown_content = md(html_content).strip()
            return f"```bash\n$ curl -s {url} | html2markdown\n{markdown_content.strip()}\n```"
    except Exception as e:
        sys.stderr.write(f"Error fetching {url}: {e}\n")
        sys.stderr.flush()
        return ""


def _run_command(cmd: str, shell: str = "bash") -> str:
    """Run cmd via shell; return merged stdout+stderr fenced as ```bash ...```"""
    env = os.environ.copy()
    env["HKATT_SHELL"] = shell
    try:
        completed = subprocess.run(
            [shell, "-c", cmd],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # merge stderr into stdout
            text=True,
            env=env,
        )
    except FileNotFoundError:
        sys.stderr.write(f"Error: shell '{shell}' not found\n")
        sys.stderr.flush()
        return ""

    if completed.returncode != 0:
        sys.stderr.write(
            f"Warning: command exited with status {completed.returncode}\n"
        )
        sys.stderr.flush()

    return f"```bash\n$ {cmd}\n{completed.stdout}```"


# --------------------------------------------------------------------------- #
#  Argument parsing
# --------------------------------------------------------------------------- #
def parse_args(args: List[str]):
    """Return (shell, remaining_args)."""
    shell = "bash"
    remaining = []
    it = iter(args)
    for arg in it:
        if arg in ("-s", "--shell"):
            try:
                shell = next(it)
            except StopIteration:
                sys.stderr.write("Error: --shell requires an argument\n")
                sys.stderr.flush()
                sys.exit(1)
        else:
            remaining.append(arg)
    return shell, remaining


# --------------------------------------------------------------------------- #
#  Main
# --------------------------------------------------------------------------- #
def build_blocks(argv: List[str], shell: str) -> List[str]:
    if not argv:
        argv = ["-"]
    blocks = []
    for token in argv:
        if token == "-":
            content = _read_stdin()
            if content:
                blocks.append(content)
        elif _is_url(token):
            content = _fetch_url(token)
            if content:
                blocks.append(content)
        elif os.path.isfile(token):
            blocks.append(_read_file(token))
        else:
            blocks.append(_run_command(token, shell=shell))
    return blocks


def main() -> None:
    shell, rest = parse_args(sys.argv[1:])
    blocks = build_blocks(rest, shell)
    sys.stdout.write("\n\n".join(blocks))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except ValueError as exc:
        sys.stderr.write(f"Error: {exc}")
        sys.stderr.flush()
        sys.exit(1)
