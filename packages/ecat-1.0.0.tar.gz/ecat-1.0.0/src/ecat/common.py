import os
import sys
import hashlib
import contextlib
import itertools
import threading
import time

from pathlib import Path


EMPTY_HASH = hashlib.sha256(b"").hexdigest()


def spinner_task(
    spinner_chars: itertools.cycle, done: threading.Event, label: str
) -> None:
    start = time.perf_counter()
    for char in spinner_chars:
        elapsed = time.perf_counter() - start
        sys.stderr.write(f"\r\033[K{label} {char} ({elapsed:.1f}s)")
        sys.stderr.flush()
        if done.wait(0.1):
            break
    elapsed = time.perf_counter() - start
    sys.stderr.write(f"\r\033[K{label} done ({elapsed:.1f}s)\n")
    sys.stderr.flush()


@contextlib.contextmanager
def spinning(label: str = "Working"):
    spinner = itertools.cycle("⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏")
    done_flag = threading.Event()
    thread = threading.Thread(
        target=spinner_task, args=(spinner, done_flag, label), daemon=True
    )
    thread.start()
    try:
        yield
    finally:
        done_flag.set()
        thread.join()


def ask_yes_no(prompt: str) -> bool:
    """Return True if the user answers 'y' or 'yes' (case-insensitive)."""
    answer = input(f"{prompt} [y/N] ").strip().lower()
    return answer.startswith("y")


def ask_filename(default: str) -> Path:
    """
    Ask for a filename.
    If the file already exists the user is asked whether to overwrite it.
    The question is repeated until a valid answer is given.
    """
    while True:
        name = input(f"\nFilename [{default}]: ").strip() or default

        if not os.path.exists(name):
            return Path(name)

        choice = input(f'File "{name}" exists. Overwrite? [y/N]: ').strip().lower()
        if choice in {"y", "yes"}:
            return Path(name)


def same_hash(path: Path, old_hash: str) -> bool:
    """True  -> file still has the same sha256 we saw when we loaded it."""
    return old_hash == hashlib.sha256(path.read_bytes()).hexdigest()


def get_question() -> str:
    """Read question from stdin"""
    question: str = ""
    if not sys.stdin.isatty():
        if sys.stderr.isatty():
            sys.stderr.write("Press Ctrl+D to submit\n\n")
            sys.stderr.flush()
        question = sys.stdin.read().strip()
        if sys.stderr.isatty():
            sys.stderr.write("\n")
            sys.stderr.flush()
    else:
        sys.stderr.write("Press Ctrl+D to submit\n\n")
        sys.stderr.flush()
        while True:
            try:
                try:
                    import readline
                except ImportError:
                    pass
                ask = input()
                question += ask + "\n"
            except EOFError:
                break
        question = question.strip()
        sys.stderr.write("\n")
        sys.stderr.flush()
    return question


def get_width() -> int:
    """Get terminal width"""
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


def prompt_preview(prompt: str):
    """Preview prompt with visual markers"""
    width = get_width()
    start = "[ PROMPT ] "
    end = "[ / PROMPT ] "
    asterisks_start = "*" * (width - len(start))
    asterisks_end = "*" * (width - len(end))
    sys.stderr.write(
        "\n".join(
            [start + asterisks_start, prompt.rstrip(), end + asterisks_end + "\n\n"]
        )
    )
    sys.stderr.flush()
