from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def seed_product_and_price(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201


def test_public_products_can_render_html_list(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Agentic AI Bootcamp" in html
    assert "/products/agentic-ai-bootcamp" in html
    assert "/commerce/admin" not in html


def test_public_product_can_render_html_detail(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Agentic AI Bootcamp" in html
    assert "Practical agentic AI training." in html
    assert "Standard" in html
    assert "EUR 299" in html
    assert "/commerce/admin" not in html


def test_public_product_json_still_works_by_default(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.get("/products/agentic-ai-bootcamp")

    assert response.status_code == 200
    assert response.is_json
    assert response.get_json()["slug"] == "agentic-ai-bootcamp"
