from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path, *, admin_api_key=None):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": admin_api_key,
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def test_admin_routes_require_key_when_configured(tmp_path):
    client = create_test_client(tmp_path, admin_api_key="secret-admin-key")

    response = client.get("/commerce/admin/categories")

    assert response.status_code == 401
    assert response.get_json()["error"] == "admin authentication required"


def test_admin_routes_accept_valid_key_when_configured(tmp_path):
    client = create_test_client(tmp_path, admin_api_key="secret-admin-key")

    response = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )

    assert response.status_code == 201
    assert response.get_json()["slug"] == "bootcamps"


def test_public_routes_do_not_require_admin_key(tmp_path):
    client = create_test_client(tmp_path, admin_api_key="secret-admin-key")

    response = client.get("/products")

    assert response.status_code == 200


def test_admin_routes_remain_available_when_no_key_is_configured(tmp_path):
    client = create_test_client(tmp_path, admin_api_key=None)

    response = client.get("/commerce/admin/categories")

    assert response.status_code == 200
