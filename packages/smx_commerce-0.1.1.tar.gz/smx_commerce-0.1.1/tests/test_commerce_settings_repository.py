import pytest

from smx_commerce.core import create_schema, make_engine, make_session_factory
from smx_commerce.core.settings_repository import CommerceSettingsRepository


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def test_settings_repository_set_and_get_all(session):
    repo = CommerceSettingsRepository(session)

    settings = repo.set_many(
        {
            "brand-name": "SyntaxMatrix",
            "support_email": "support@example.com",
            "public_base_url": "https://syntaxmatrix.com",
        }
    )

    assert settings.get("brand_name") == "SyntaxMatrix"
    assert settings.get("brand-name") == "SyntaxMatrix"
    assert settings.get("support_email") == "support@example.com"
    assert settings.as_dict()["public_base_url"] == "https://syntaxmatrix.com"


def test_settings_repository_rejects_sensitive_keys(session):
    repo = CommerceSettingsRepository(session)

    with pytest.raises(ValueError, match="setting is sensitive"):
        repo.set_many({"stripe_secret_key": "sk_test_should_not_store"})


def test_settings_repository_delete(session):
    repo = CommerceSettingsRepository(session)

    repo.set_many({"brand_name": "SyntaxMatrix"})

    settings = repo.delete("brand_name")

    assert settings.as_dict() == {}
