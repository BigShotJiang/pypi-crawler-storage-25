import json
from collections.abc import Mapping

from flask import Flask

from smx_commerce import init_commerce
from smx_commerce.payments import VerifiedPaymentEvent, WebhookVerificationError


class FakeVerifier:
    def verify(self, *, payload: bytes, headers: Mapping[str, str]) -> VerifiedPaymentEvent:
        if headers.get("Stripe-Signature") != "valid-test-signature":
            raise WebhookVerificationError("invalid webhook signature")

        data = json.loads(payload.decode("utf-8"))

        return VerifiedPaymentEvent(
            provider="stripe",
            provider_event_id=data["id"],
            event_type=data["type"],
            order_public_id=data.get("order_public_id"),
            payment_reference=data.get("payment_reference"),
            payload=data,
        )


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def test_admin_orders_renders_html_for_browser_request(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order = seed_order(client)

    response = client.get(
        "/commerce/admin/orders",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Orders" in html
    assert order["public_id"] in html
    assert "Bob Nti" in html
    assert "bob@example.com" in html
    assert "agentic-ai-bootcamp" in html
    assert "EUR 299" in html
    assert "pending" in html
    assert "/commerce/admin/orders.csv" in html


def test_admin_orders_json_still_works(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order = seed_order(client)

    response = client.get("/commerce/admin/orders?format=json")

    assert response.status_code == 200
    assert response.is_json
    assert response.get_json()[0]["public_id"] == order["public_id"]
