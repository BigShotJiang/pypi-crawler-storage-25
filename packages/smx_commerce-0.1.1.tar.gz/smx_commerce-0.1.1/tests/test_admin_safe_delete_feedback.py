from flask import Flask
from urllib.parse import unquote

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "local",
            "local_webhook_signature": "valid-test-signature",
            "email_provider": "memory",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_category_product_price_and_order(client):
    category = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
    )
    assert category.status_code == 201

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "category_slugs": ["bootcamps"],
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201

    checkout = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout.status_code == 201


def test_browser_blocked_product_delete_redirects_back_with_error(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price_and_order(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"].startswith(
        "/commerce/admin/products/agentic-ai-bootcamp?error="
    )
    assert "order%28s%29+reference+it" in response.headers["Location"]

    page = client.get(response.headers["Location"], headers={"Accept": "text/html"})
    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "product cannot be deleted" in html
    assert "order(s) reference it" in html


def test_browser_blocked_price_delete_redirects_back_with_error(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price_and_order(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"].startswith(
        "/commerce/admin/products/agentic-ai-bootcamp?error="
    )

    page = client.get(response.headers["Location"], headers={"Accept": "text/html"})
    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "price cannot be deleted" in html
    assert "order(s) reference it" in html


def test_browser_blocked_category_delete_redirects_back_with_error(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price_and_order(client)

    response = client.post(
        "/commerce/admin/categories/bootcamps/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"].startswith("/commerce/admin/categories?error=")

    page = client.get(response.headers["Location"], headers={"Accept": "text/html"})
    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "category cannot be deleted" in html
    assert "product(s) use it" in html


def test_api_blocked_delete_still_returns_json_409(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price_and_order(client)

    response = client.post("/commerce/admin/products/agentic-ai-bootcamp/delete")

    assert response.status_code == 409
    assert response.is_json
    assert "order(s) reference it" in response.get_json()["error"]
