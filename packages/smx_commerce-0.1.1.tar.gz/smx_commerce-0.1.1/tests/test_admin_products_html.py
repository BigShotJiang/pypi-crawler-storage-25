from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_products_renders_html_for_browser_request(tmp_path):
    client = create_client(tmp_path)

    login = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert login.status_code == 200

    create_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert create_response.status_code == 201

    response = client.get(
        "/commerce/admin/products",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Products" in html
    assert "Agentic AI Bootcamp" in html
    assert "agentic-ai-bootcamp" in html
    assert "/products/agentic-ai-bootcamp" in html
    assert "/commerce/admin/logout" in html


def test_admin_products_json_still_works_with_header_key(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin/products?format=json",
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )

    assert response.status_code == 200
    assert response.is_json
    assert response.get_json() == []
