from smx_commerce.catalog import Money
from smx_commerce.checkout import BuyerDetails, Order, OrderStatus
from smx_commerce.notifications import EmailMessage, OrderConfirmationEmailService


class FakeSender:
    def __init__(self):
        self.messages = []

    def send(self, message: EmailMessage) -> None:
        self.messages.append(message)


class FailingSender:
    def send(self, message: EmailMessage) -> None:
        raise RuntimeError("SMTP unavailable")


def make_paid_order():
    return Order(
        public_id="ord_test_123",
        product_slug="example-product",
        price_code="standard",
        buyer=BuyerDetails(full_name="Bob Nti", email="bob@example.com"),
        amount=Money(amount_cents=29900, currency="EUR"),
        status=OrderStatus.PAID,
        payment_provider="stripe",
        payment_reference="cs_test_123",
    )


def test_order_confirmation_email_service_builds_generic_message():
    sender = FakeSender()
    service = OrderConfirmationEmailService(
        sender,
        from_email="sales@example.com",
        brand_name="SyntaxMatrix",
    )

    result = service.send_order_paid_confirmation(make_paid_order())

    assert result.sent is True
    assert result.error_message == ""
    assert len(sender.messages) == 1

    message = sender.messages[0]

    assert message.to_email == "bob@example.com"
    assert message.from_email == "sales@example.com"
    assert message.subject == "Your SyntaxMatrix order is confirmed"
    assert "Order ID: ord_test_123" in message.body_text
    assert "Product: example-product" in message.body_text
    assert "Price option: standard" in message.body_text
    assert "Amount paid: EUR 299" in message.body_text


def test_order_confirmation_email_failure_is_returned_not_raised():
    service = OrderConfirmationEmailService(
        FailingSender(),
        brand_name="SyntaxMatrix",
    )

    result = service.send_order_paid_confirmation(make_paid_order())

    assert result.sent is False
    assert "SMTP unavailable" in result.error_message
