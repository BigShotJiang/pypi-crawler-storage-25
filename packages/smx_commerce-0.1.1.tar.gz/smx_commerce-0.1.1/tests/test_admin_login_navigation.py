from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_login_page_has_exit_navigation(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin/login",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Commerce Admin" in html
    assert 'href="/commerce"' in html
    assert "Cancel and return to commerce home" in html
    assert 'href="/products"' in html
    assert "Browse public products" in html


def test_wrong_admin_key_renders_login_error_with_exit_navigation(tmp_path):
    client = create_client(tmp_path)

    response = client.post(
        "/commerce/admin/login",
        data={"admin_api_key": "wrong-key"},
        content_type="application/x-www-form-urlencoded",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 401

    html = response.get_data(as_text=True)

    assert "Invalid admin key" in html
    assert 'href="/commerce"' in html
    assert 'href="/products"' in html


def test_json_wrong_admin_key_still_returns_json_401(tmp_path):
    client = create_client(tmp_path)

    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "wrong-key"},
    )

    assert response.status_code == 401
    assert response.is_json
    assert response.get_json()["error"] == "invalid admin key"
