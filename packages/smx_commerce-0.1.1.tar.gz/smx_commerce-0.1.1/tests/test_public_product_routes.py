from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def create_product(client, *, slug, name, status="active"):
    response = client.post(
        "/commerce/admin/products",
        json={
            "slug": slug,
            "name": name,
            "status": status,
            "summary": f"{name} summary",
            "description": f"{name} description",
        },
    )
    assert response.status_code == 201


def create_price(client, *, product_slug, code="standard", status="active"):
    response = client.post(
        f"/commerce/admin/products/{product_slug}/prices",
        json={
            "code": code,
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": status,
        },
    )
    assert response.status_code == 201


def test_public_products_list_only_active_products(tmp_path):
    client = create_test_client(tmp_path)

    create_product(client, slug="active-product", name="Active Product", status="active")
    create_product(client, slug="draft-product", name="Draft Product", status="draft")
    create_product(client, slug="paused-product", name="Paused Product", status="paused")

    response = client.get("/products")

    assert response.status_code == 200
    assert [item["slug"] for item in response.get_json()] == ["active-product"]


def test_public_product_detail_returns_active_product_with_active_prices_only(tmp_path):
    client = create_test_client(tmp_path)

    create_product(client, slug="active-product", name="Active Product", status="active")
    create_price(client, product_slug="active-product", code="standard", status="active")
    create_price(client, product_slug="active-product", code="old-price", status="inactive")

    response = client.get("/products/active-product")

    assert response.status_code == 200

    data = response.get_json()

    assert data["slug"] == "active-product"
    assert data["is_public"] is True
    assert data["is_purchasable"] is True
    assert [price["code"] for price in data["prices"]] == ["standard"]


def test_public_product_detail_hides_non_public_products(tmp_path):
    client = create_test_client(tmp_path)

    create_product(client, slug="draft-product", name="Draft Product", status="draft")

    response = client.get("/products/draft-product")

    assert response.status_code == 404


def test_public_product_response_does_not_expose_admin_urls(tmp_path):
    client = create_test_client(tmp_path)

    create_product(client, slug="active-product", name="Active Product", status="active")
    create_price(client, product_slug="active-product", code="standard", status="active")

    response = client.get("/products/active-product")

    assert response.status_code == 200
    assert "admin" not in str(response.get_json()).lower()


def test_public_products_can_filter_by_category(tmp_path):
    client = create_test_client(tmp_path)

    category_response = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
    )
    assert category_response.status_code == 201

    create_product(client, slug="bootcamp-product", name="Bootcamp Product", status="active")
    create_product(client, slug="uncategorized-product", name="Uncategorized Product", status="active")

    update_response = client.patch(
        "/commerce/admin/products/bootcamp-product",
        json={"category_slugs": ["bootcamps"]},
    )
    assert update_response.status_code == 200

    response = client.get("/products?category_slug=bootcamps")

    assert response.status_code == 200
    assert [item["slug"] for item in response.get_json()] == ["bootcamp-product"]
