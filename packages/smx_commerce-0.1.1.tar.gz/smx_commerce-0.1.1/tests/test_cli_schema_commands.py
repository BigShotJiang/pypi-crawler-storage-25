from smx_commerce.cli import main


def test_cli_check_schema_reports_missing_tables_before_init(tmp_path, capsys):
    db_file = tmp_path / "commerce.db"
    database_url = f"sqlite+pysqlite:///{db_file.as_posix()}"

    exit_code = main(["check-schema", "--database-url", database_url])

    captured = capsys.readouterr()

    assert exit_code == 2
    assert "Schema is not ready." in captured.out
    assert "smx_products" in captured.out


def test_cli_init_schema_then_check_schema(tmp_path, capsys):
    db_file = tmp_path / "commerce.db"
    database_url = f"sqlite+pysqlite:///{db_file.as_posix()}"

    init_exit_code = main(["init-schema", "--database-url", database_url])
    init_output = capsys.readouterr()

    assert init_exit_code == 0
    assert "Schema initialized." in init_output.out

    check_exit_code = main(["check-schema", "--database-url", database_url])
    check_output = capsys.readouterr()

    assert check_exit_code == 0
    assert "Schema is ready." in check_output.out


def test_cli_refuses_non_sqlite_create_all_without_explicit_flag(capsys):
    exit_code = main(
        [
            "init-schema",
            "--database-url",
            "postgresql+psycopg://user:pass@localhost:5432/commerce",
        ]
    )

    captured = capsys.readouterr()

    assert exit_code == 3
    assert "Refusing to run create_all()" in captured.err
    assert "production databases" in captured.err
