from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def create_category(client, slug="bootcamps", name="Bootcamps"):
    response = client.post(
        "/commerce/admin/categories",
        json={"slug": slug, "name": name},
    )
    assert response.status_code == 201


def test_product_admin_routes_create_read_update_archive(tmp_path):
    client = create_test_client(tmp_path)
    create_category(client)

    create_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "summary": "Practical agentic AI training",
            "description": "Full training product description",
            "status": "active",
            "category_slugs": ["bootcamps"],
            "sort_order": 10,
            "metadata": {"delivery": "online"},
        },
    )

    assert create_response.status_code == 201
    created = create_response.get_json()
    assert created["slug"] == "agentic-ai-bootcamp"
    assert created["status"] == "active"
    assert created["category_slugs"] == ["bootcamps"]
    assert created["prices"] == []

    list_response = client.get("/commerce/admin/products")

    assert list_response.status_code == 200
    assert [item["slug"] for item in list_response.get_json()] == ["agentic-ai-bootcamp"]

    get_response = client.get("/commerce/admin/products/agentic-ai-bootcamp")

    assert get_response.status_code == 200
    assert get_response.get_json()["name"] == "Agentic AI Bootcamp"

    update_response = client.patch(
        "/commerce/admin/products/agentic-ai-bootcamp",
        json={
            "name": "Updated Agentic AI Bootcamp",
            "summary": "Updated summary",
            "status": "paused",
            "metadata": {"delivery": "hybrid"},
        },
    )

    assert update_response.status_code == 200
    updated = update_response.get_json()
    assert updated["name"] == "Updated Agentic AI Bootcamp"
    assert updated["status"] == "paused"
    assert updated["metadata"]["delivery"] == "hybrid"

    archive_response = client.post("/commerce/admin/products/agentic-ai-bootcamp/archive")

    assert archive_response.status_code == 200
    assert archive_response.get_json()["status"] == "archived"

    list_after_archive_response = client.get("/commerce/admin/products")

    assert list_after_archive_response.status_code == 200
    assert list_after_archive_response.get_json() == []

    list_archived_response = client.get("/commerce/admin/products?include_archived=1")

    assert list_archived_response.status_code == 200
    assert list_archived_response.get_json()[0]["status"] == "archived"


def test_product_admin_rejects_missing_category(tmp_path):
    client = create_test_client(tmp_path)

    response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "category_slugs": ["missing-category"],
        },
    )

    assert response.status_code == 400
    assert "category does not exist" in response.get_json()["error"]


def test_product_admin_returns_404_for_missing_product(tmp_path):
    client = create_test_client(tmp_path)

    response = client.get("/commerce/admin/products/missing-product")

    assert response.status_code == 404
