import pytest

from smx_commerce.catalog import (
    Money,
    PriceStatus,
    Product,
    ProductPrice,
    ProductPriceRepository,
    ProductRepository,
    ProductStatus,
)
from smx_commerce.checkout import BuyerDetails, OrderRepository, OrderStatus
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def seed_product_and_price(session, *, product_status=ProductStatus.ACTIVE, price_status=PriceStatus.ACTIVE):
    ProductRepository(session).create(
        Product(
            slug="example-product",
            name="Example Product",
            status=product_status,
        )
    )

    ProductPriceRepository(session).create(
        "example-product",
        ProductPrice(
            code="standard",
            label="Standard",
            amount=Money.from_major("299.00", "EUR"),
            status=price_status,
        ),
    )


def buyer():
    return BuyerDetails(
        full_name="Bob Nti",
        email="BOB@example.com",
        phone="+353000000000",
        company="SyntaxMatrix",
        metadata={"role": "attendee"},
    )


def test_create_pending_order_preserves_price_amount_and_buyer(session):
    seed_product_and_price(session)
    repo = OrderRepository(session)

    order = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=buyer(),
        metadata={"source": "test"},
    )

    assert order.public_id.startswith("ord_")
    assert order.product_slug == "example-product"
    assert order.price_code == "standard"
    assert order.amount.amount_cents == 29900
    assert order.amount.currency == "EUR"
    assert order.status == OrderStatus.PENDING
    assert order.buyer.email == "bob@example.com"
    assert order.metadata["source"] == "test"


def test_read_order_by_public_id(session):
    seed_product_and_price(session)
    repo = OrderRepository(session)

    created = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=buyer(),
    )

    loaded = repo.get_by_public_id(created.public_id)

    assert loaded is not None
    assert loaded.public_id == created.public_id
    assert loaded.amount.amount_cents == 29900


def test_order_rejects_inactive_product(session):
    seed_product_and_price(session, product_status=ProductStatus.DRAFT)
    repo = OrderRepository(session)

    with pytest.raises(ValueError, match="product is not active"):
        repo.create_pending(
            product_slug="example-product",
            price_code="standard",
            buyer=buyer(),
        )


def test_order_rejects_inactive_price(session):
    seed_product_and_price(session, price_status=PriceStatus.INACTIVE)
    repo = OrderRepository(session)

    with pytest.raises(ValueError, match="price is not active"):
        repo.create_pending(
            product_slug="example-product",
            price_code="standard",
            buyer=buyer(),
        )


def test_mark_order_paid_sets_status_and_payment_reference(session):
    seed_product_and_price(session)
    repo = OrderRepository(session)

    created = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=buyer(),
    )

    paid = repo.mark_paid(created.public_id, payment_reference="cs_test_123")

    assert paid.status == OrderStatus.PAID
    assert paid.payment_reference == "cs_test_123"

    loaded = repo.get_by_payment_reference("cs_test_123")

    assert loaded is not None
    assert loaded.public_id == created.public_id


def test_cancel_order(session):
    seed_product_and_price(session)
    repo = OrderRepository(session)

    created = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=buyer(),
    )

    cancelled = repo.cancel(created.public_id)

    assert cancelled.status == OrderStatus.CANCELLED


def test_list_orders_by_status_and_product(session):
    seed_product_and_price(session)
    repo = OrderRepository(session)

    first = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=buyer(),
    )
    second = repo.create_pending(
        product_slug="example-product",
        price_code="standard",
        buyer=BuyerDetails(full_name="Jane Doe", email="jane@example.com"),
    )

    repo.mark_paid(first.public_id, payment_reference="cs_paid")

    pending_orders = repo.list(status=OrderStatus.PENDING)
    product_orders = repo.list(product_slug="example-product")

    assert [order.public_id for order in pending_orders] == [second.public_id]
    assert len(product_orders) == 2
