from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_category_and_product(client):
    category = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
    )
    assert category.status_code == 201

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "summary": "Old summary",
            "description": "Old description",
        },
    )
    assert product.status_code == 201


def test_admin_product_detail_has_edit_link(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_and_product(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert 'href="/commerce/admin/products/agentic-ai-bootcamp/edit"' in response.get_data(as_text=True)


def test_admin_product_edit_page_renders_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_and_product(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Edit product" in html
    assert 'name="name"' in html
    assert 'name="kind"' in html
    assert 'name="status"' in html
    assert 'name="category_slugs"' in html
    assert 'value="bootcamps"' in html
    assert "Old summary" in html


def test_admin_can_update_product_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_and_product(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/update",
        data={
            "name": "Updated Bootcamp",
            "kind": "service",
            "status": "paused",
            "category_slugs": "bootcamps",
            "summary": "Updated summary",
            "description": "Updated description",
            "sort_order": "7",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products/agentic-ai-bootcamp"

    product_response = client.get("/commerce/admin/products/agentic-ai-bootcamp?format=json")

    assert product_response.status_code == 200

    product = product_response.get_json()

    assert product["name"] == "Updated Bootcamp"
    assert product["kind"] == "service"
    assert product["status"] == "paused"
    assert product["category_slugs"] == ["bootcamps"]
    assert product["summary"] == "Updated summary"
    assert product["description"] == "Updated description"
    assert product["sort_order"] == 7
