from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_login_page_uses_client_branding(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin/login",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Admin Login" in html
    assert "Client Portal Admin" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html
    assert "Cancel and return to commerce home" in html
    assert "Browse public products" in html


def test_wrong_admin_key_preserves_branding_and_exit_links(tmp_path):
    client = create_client(tmp_path)

    response = client.post(
        "/commerce/admin/login",
        data={"admin_api_key": "wrong-key"},
        content_type="application/x-www-form-urlencoded",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 401

    html = response.get_data(as_text=True)

    assert "Invalid admin key" in html
    assert "Client Portal Admin" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'href="/commerce"' in html
    assert 'href="/products"' in html