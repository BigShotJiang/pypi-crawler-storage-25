import pytest

from smx_commerce.catalog import (
    Category,
    CategoryRepository,
    Product,
    ProductKind,
    ProductRepository,
    ProductStatus,
)
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def add_category(session, slug="ai-bootcamps", name="AI Bootcamps"):
    CategoryRepository(session).create(Category(slug=slug, name=name))


def test_product_create_and_read(session):
    add_category(session)

    repo = ProductRepository(session)

    created = repo.create(
        Product(
            slug="smxadk-bootcamp",
            name="smxADK Bootcamp",
            kind=ProductKind.EVENT,
            summary="Agentic AI training",
            status=ProductStatus.ACTIVE,
            category_slugs=["ai-bootcamps"],
            metadata={"delivery": "online"},
        )
    )

    loaded = repo.get_by_slug("smxadk-bootcamp")

    assert created.slug == "smxadk-bootcamp"
    assert loaded is not None
    assert loaded.name == "smxADK Bootcamp"
    assert loaded.kind == ProductKind.EVENT
    assert loaded.status == ProductStatus.ACTIVE
    assert loaded.category_slugs == ["ai-bootcamps"]
    assert loaded.metadata["delivery"] == "online"


def test_product_duplicate_slug_is_rejected(session):
    repo = ProductRepository(session)

    repo.create(Product(slug="example-product", name="Example Product"))

    with pytest.raises(ValueError, match="product already exists"):
        repo.create(Product(slug="example-product", name="Duplicate Product"))


def test_product_requires_existing_category(session):
    repo = ProductRepository(session)

    with pytest.raises(ValueError, match="category does not exist"):
        repo.create(
            Product(
                slug="example-product",
                name="Example Product",
                category_slugs=["missing-category"],
            )
        )


def test_product_list_filters_by_status_and_category(session):
    add_category(session, slug="bootcamps", name="Bootcamps")
    add_category(session, slug="services", name="Services")

    repo = ProductRepository(session)

    repo.create(
        Product(
            slug="active-bootcamp",
            name="Active Bootcamp",
            status=ProductStatus.ACTIVE,
            category_slugs=["bootcamps"],
        )
    )
    repo.create(
        Product(
            slug="draft-service",
            name="Draft Service",
            status=ProductStatus.DRAFT,
            category_slugs=["services"],
        )
    )

    active_products = repo.list(status=ProductStatus.ACTIVE)
    bootcamp_products = repo.list(category_slug="bootcamps")

    assert [product.slug for product in active_products] == ["active-bootcamp"]
    assert [product.slug for product in bootcamp_products] == ["active-bootcamp"]


def test_product_update(session):
    add_category(session, slug="bootcamps", name="Bootcamps")
    add_category(session, slug="services", name="Services")

    repo = ProductRepository(session)
    repo.create(Product(slug="example-product", name="Example Product"))

    updated = repo.update(
        "example-product",
        name="Updated Product",
        kind=ProductKind.SERVICE,
        summary="Updated summary",
        description="Updated description",
        status=ProductStatus.ACTIVE,
        category_slugs=["services"],
        sort_order=20,
        metadata={"owner": "admin"},
    )

    assert updated.name == "Updated Product"
    assert updated.kind == ProductKind.SERVICE
    assert updated.summary == "Updated summary"
    assert updated.description == "Updated description"
    assert updated.status == ProductStatus.ACTIVE
    assert updated.category_slugs == ["services"]
    assert updated.sort_order == 20
    assert updated.metadata["owner"] == "admin"


def test_product_archive_is_soft_delete(session):
    repo = ProductRepository(session)

    repo.create(Product(slug="example-product", name="Example Product"))

    archived = repo.archive("example-product")

    assert archived.status == ProductStatus.ARCHIVED
    assert repo.list() == []
    assert repo.list(include_archived=True)[0].slug == "example-product"
