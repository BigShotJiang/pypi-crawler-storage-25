import sys
from types import SimpleNamespace

import pytest

from smx_commerce.catalog import Money
from smx_commerce.checkout import BuyerDetails, Order
from smx_commerce.payments import PaymentCheckoutError, StripeCheckoutProvider


def make_order():
    return Order(
        public_id="ord_test_123",
        product_slug="example-product",
        price_code="standard",
        buyer=BuyerDetails(full_name="Bob Nti", email="bob@example.com"),
        amount=Money(amount_cents=29900, currency="EUR"),
    )


def test_stripe_checkout_provider_requires_api_key():
    with pytest.raises(ValueError, match="api_key is required"):
        StripeCheckoutProvider("")


def test_stripe_checkout_provider_creates_session_with_expected_payload(monkeypatch):
    captured = {}

    class FakeSession:
        @staticmethod
        def create(**kwargs):
            captured.update(kwargs)
            return {
                "id": "cs_test_123",
                "url": "https://checkout.stripe.test/session/cs_test_123",
            }

    fake_stripe = SimpleNamespace(
        api_key=None,
        checkout=SimpleNamespace(Session=FakeSession),
    )

    monkeypatch.setitem(sys.modules, "stripe", fake_stripe)

    provider = StripeCheckoutProvider(
        api_key="sk_test_fake",
        product_name_resolver=lambda order: "Example Product",
    )

    session = provider.create_checkout_session(
        order=make_order(),
        success_url="https://example.test/checkout/success",
        cancel_url="https://example.test/checkout/cancel",
    )

    assert fake_stripe.api_key == "sk_test_fake"
    assert session.provider == "stripe"
    assert session.session_id == "cs_test_123"
    assert session.checkout_url == "https://checkout.stripe.test/session/cs_test_123"
    assert session.metadata["order_public_id"] == "ord_test_123"

    assert captured["mode"] == "payment"
    assert captured["success_url"] == "https://example.test/checkout/success"
    assert captured["cancel_url"] == "https://example.test/checkout/cancel"
    assert captured["customer_email"] == "bob@example.com"
    assert captured["client_reference_id"] == "ord_test_123"
    assert captured["metadata"]["order_public_id"] == "ord_test_123"

    line_item = captured["line_items"][0]

    assert line_item["quantity"] == 1
    assert line_item["price_data"]["currency"] == "eur"
    assert line_item["price_data"]["unit_amount"] == 29900
    assert line_item["price_data"]["product_data"]["name"] == "Example Product"
    assert line_item["price_data"]["product_data"]["metadata"]["product_slug"] == "example-product"


def test_stripe_checkout_provider_requires_success_and_cancel_urls(monkeypatch):
    provider = StripeCheckoutProvider(api_key="sk_test_fake")

    with pytest.raises(ValueError, match="success_url is required"):
        provider.create_checkout_session(
            order=make_order(),
            success_url="",
            cancel_url="https://example.test/cancel",
        )

    with pytest.raises(ValueError, match="cancel_url is required"):
        provider.create_checkout_session(
            order=make_order(),
            success_url="https://example.test/success",
            cancel_url="",
        )


def test_stripe_checkout_provider_handles_missing_stripe_package(monkeypatch):
    monkeypatch.delitem(sys.modules, "stripe", raising=False)

    provider = StripeCheckoutProvider(api_key="sk_test_fake")

    with pytest.raises(PaymentCheckoutError, match="stripe package is not installed"):
        provider.create_checkout_session(
            order=make_order(),
            success_url="https://example.test/success",
            cancel_url="https://example.test/cancel",
        )
