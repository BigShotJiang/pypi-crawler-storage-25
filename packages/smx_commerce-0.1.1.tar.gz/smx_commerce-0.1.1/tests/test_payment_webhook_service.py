import pytest

from smx_commerce.catalog import Money, Product, ProductPrice, ProductPriceRepository, ProductRepository, ProductStatus
from smx_commerce.checkout import CheckoutService, OrderStatus, StartCheckoutRequest
from smx_commerce.core import create_schema, make_engine, make_session_factory
from smx_commerce.payments import PaymentEventRepository, PaymentEventStatus, PaymentWebhookService


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def seed_order(session):
    ProductRepository(session).create(
        Product(slug="example-product", name="Example Product", status=ProductStatus.ACTIVE)
    )

    ProductPriceRepository(session).create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00", "EUR")),
    )

    return CheckoutService(session).start_checkout(
        StartCheckoutRequest(
            product_slug="example-product",
            price_code="standard",
            buyer_full_name="Bob Nti",
            buyer_email="bob@example.com",
        )
    )


def test_payment_webhook_service_marks_order_paid_and_records_event(session):
    order = seed_order(session)
    service = PaymentWebhookService(session)

    result = service.process_order_paid(
        provider="stripe",
        provider_event_id="evt_test_1",
        event_type="checkout.session.completed",
        order_public_id=order.public_id,
        payment_reference="cs_test_123",
        payload={"type": "checkout.session.completed"},
    )

    assert result.idempotent is False
    assert result.order is not None
    assert result.order.status == OrderStatus.PAID
    assert result.order.payment_reference == "cs_test_123"
    assert result.event.status == PaymentEventStatus.PROCESSED
    assert result.event.order_public_id == order.public_id


def test_payment_webhook_service_is_idempotent_for_duplicate_event(session):
    order = seed_order(session)
    service = PaymentWebhookService(session)

    first_result = service.process_order_paid(
        provider="stripe",
        provider_event_id="evt_test_1",
        event_type="checkout.session.completed",
        order_public_id=order.public_id,
        payment_reference="cs_test_123",
        payload={"attempt": 1},
    )

    second_result = service.process_order_paid(
        provider="stripe",
        provider_event_id="evt_test_1",
        event_type="checkout.session.completed",
        order_public_id=order.public_id,
        payment_reference="cs_test_123",
        payload={"attempt": 2},
    )

    events = PaymentEventRepository(session).list(provider="stripe")

    assert first_result.idempotent is False
    assert second_result.idempotent is True
    assert second_result.order is not None
    assert second_result.order.status == OrderStatus.PAID
    assert len(events) == 1
    assert events[0].status == PaymentEventStatus.PROCESSED


def test_payment_webhook_service_can_ignore_non_payment_event(session):
    service = PaymentWebhookService(session)

    result = service.ignore_event(
        provider="stripe",
        provider_event_id="evt_unrelated",
        event_type="customer.created",
        payload={"type": "customer.created"},
        reason="unsupported event type",
    )

    assert result.idempotent is False
    assert result.order is None
    assert result.event.status == PaymentEventStatus.IGNORED
    assert result.event.error_message == "unsupported event type"


def test_payment_event_repository_does_not_duplicate_received_event(session):
    repo = PaymentEventRepository(session)

    first = repo.create_received(
        provider="stripe",
        provider_event_id="evt_same",
        event_type="checkout.session.completed",
        payload={"attempt": 1},
    )
    second = repo.create_received(
        provider="stripe",
        provider_event_id="evt_same",
        event_type="checkout.session.completed",
        payload={"attempt": 2},
    )

    events = repo.list(provider="stripe")

    assert first.provider_event_id == second.provider_event_id
    assert len(events) == 1
    assert events[0].payload["attempt"] == 1
