from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def create_category(client):
    response = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
        },
    )
    assert response.status_code == 201


def test_admin_products_page_contains_category_selector(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_category(client)

    response = client.get(
        "/commerce/admin/products",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert 'name="category_slugs"' in html
    assert 'value="bootcamps"' in html
    assert "Bootcamps" in html


def test_admin_can_assign_category_when_creating_product_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_category(client)

    response = client.post(
        "/commerce/admin/products",
        data={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "category_slugs": "bootcamps",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303

    product_response = client.get("/commerce/admin/products/agentic-ai-bootcamp?format=json")

    assert product_response.status_code == 200

    product = product_response.get_json()

    assert product["category_slugs"] == ["bootcamps"]


def test_admin_products_page_displays_product_categories(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_category(client)

    response = client.post(
        "/commerce/admin/products",
        data={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "category_slugs": "bootcamps",
        },
        content_type="application/x-www-form-urlencoded",
    )
    assert response.status_code == 303

    page = client.get(
        "/commerce/admin/products",
        headers={"Accept": "text/html"},
    )

    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "agentic-ai-bootcamp" in html
    assert "bootcamps" in html
