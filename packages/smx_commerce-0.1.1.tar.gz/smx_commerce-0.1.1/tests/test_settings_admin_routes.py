from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def test_settings_admin_routes_update_and_read(tmp_path):
    client = create_test_client(tmp_path)

    update_response = client.patch(
        "/commerce/admin/settings",
        json={
            "brand-name": "SyntaxMatrix",
            "support_email": "support@example.com",
            "public_base_url": "https://syntaxmatrix.com",
        },
    )

    assert update_response.status_code == 200
    assert update_response.get_json()["brand_name"] == "SyntaxMatrix"

    get_response = client.get("/commerce/admin/settings")

    assert get_response.status_code == 200
    assert get_response.get_json()["support_email"] == "support@example.com"


def test_settings_admin_routes_reject_sensitive_keys(tmp_path):
    client = create_test_client(tmp_path)

    response = client.patch(
        "/commerce/admin/settings",
        json={
            "stripe_secret_key": "sk_test_should_not_store",
        },
    )

    assert response.status_code == 400
    assert "setting is sensitive" in response.get_json()["error"]
