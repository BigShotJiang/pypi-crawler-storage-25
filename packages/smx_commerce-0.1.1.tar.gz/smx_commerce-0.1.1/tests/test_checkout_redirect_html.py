from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def seed_pending_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def test_checkout_success_renders_html_without_marking_paid(tmp_path):
    client = create_client(tmp_path)
    order = seed_pending_order(client)

    response = client.get(
        f"/checkout/success?order_id={order['public_id']}",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Checkout received" in html
    assert "verified payment webhook" in html
    assert order["public_id"] in html
    assert "pending" in html
    assert "paid" not in html.lower()


def test_checkout_cancel_renders_html_without_marking_paid(tmp_path):
    client = create_client(tmp_path)
    order = seed_pending_order(client)

    response = client.get(
        f"/checkout/cancel?order_id={order['public_id']}",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Checkout cancelled" in html
    assert order["public_id"] in html
    assert "pending" in html


def test_checkout_redirect_json_still_works(tmp_path):
    client = create_client(tmp_path)
    order = seed_pending_order(client)

    response = client.get(f"/checkout/success?order_id={order['public_id']}")

    assert response.status_code == 200
    assert response.is_json
    assert response.get_json()["payment_confirmation"] == "webhook_required"
    assert response.get_json()["order"]["status"] == "pending"
