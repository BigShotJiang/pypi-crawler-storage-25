from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_category(client):
    response = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "status": "active",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert response.status_code == 201


def test_admin_categories_list_uses_client_branding_and_keeps_actions(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category(client)

    response = client.get(
        "/commerce/admin/categories",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Commerce Categories Admin" in html
    assert "Manage product categories for Client Portal" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html

    assert 'href="/commerce/admin/products"' in html
    assert 'href="/commerce/admin/categories"' in html
    assert 'href="/commerce/admin/orders"' in html
    assert 'action="/commerce/admin/logout"' in html

    assert "Create category" in html
    assert 'name="parent_slug"' in html
    assert "Bootcamps" in html
    assert 'href="/commerce/admin/categories/bootcamps/edit"' in html
    assert 'action="/commerce/admin/categories/bootcamps/delete"' in html
    assert "Delete unused category" in html


def test_admin_categories_form_error_preserves_client_branding(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.post(
        "/commerce/admin/categories",
        data={
            "slug": "Invalid Slug",
            "name": "Bad Category",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Client Portal · Commerce Categories Admin" in html
    assert "Client Portal" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert "error" in html