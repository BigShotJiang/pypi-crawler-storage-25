from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def test_checkout_success_uses_client_branding(tmp_path):
    client = create_client(tmp_path)

    response = client.get("/checkout/success", headers={"Accept": "text/html"})

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Checkout received" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html
    assert "Payment is not confirmed by this page" in html
    assert "Back to products" in html

    assert 'href="/commerce/admin"' not in html
    assert "Open admin" not in html


def test_checkout_cancel_uses_client_branding(tmp_path):
    client = create_client(tmp_path)

    response = client.get("/checkout/cancel", headers={"Accept": "text/html"})

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Checkout cancelled" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html
    assert "No payment has been confirmed by this page" in html
    assert "Back to products" in html

    assert 'href="/commerce/admin"' not in html
    assert "Open admin" not in html