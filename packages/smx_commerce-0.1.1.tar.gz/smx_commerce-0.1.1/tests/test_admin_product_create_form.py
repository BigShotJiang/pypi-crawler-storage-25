from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def test_admin_products_page_contains_create_product_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.get(
        "/commerce/admin/products",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Create product" in html
    assert 'method="post" action="/commerce/admin/products"' in html
    assert 'name="slug"' in html
    assert 'name="name"' in html
    assert 'name="kind"' in html
    assert 'name="status"' in html


def test_admin_can_create_product_from_browser_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.post(
        "/commerce/admin/products",
        data={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products"

    products_response = client.get("/commerce/admin/products?format=json")

    assert products_response.status_code == 200
    assert products_response.get_json()[0]["slug"] == "agentic-ai-bootcamp"


def test_admin_product_form_error_renders_html(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.post(
        "/commerce/admin/products",
        data={
            "slug": "Invalid Slug",
            "name": "Bad Product",
            "kind": "event",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Create product" in html
    assert "slug must use lowercase letters" in html
