from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_public_commerce_home_does_not_advertise_admin_link(tmp_path):
    client = create_client(tmp_path)

    response = client.get("/commerce", headers={"Accept": "text/html"})

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Commerce" in html
    assert 'href="/products"' in html
    assert "Browse products" in html
    assert 'href="/commerce/admin"' not in html
    assert "Open admin" not in html


def test_admin_entrypoint_still_exists_but_requires_login(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin",
        headers={"Accept": "text/html"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/commerce/admin/login" in response.headers["Location"]
