import json

from flask import Flask

from smx_commerce import init_commerce


def test_init_commerce_exposes_clean_client_facing_api(tmp_path):
    db_file = tmp_path / "commerce.db"

    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "test-admin-key",
            "payment_provider": "local",
            "local_webhook_signature": "valid-test-signature",
            "email_provider": "memory",
            "brand_name": "SyntaxMatrix",
        },
        init_schema=True,
    )

    client = app.test_client()
    admin_headers = {"X-SMX-Commerce-Admin-Key": "test-admin-key"}

    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "status": "active",
        },
        headers=admin_headers,
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
        headers=admin_headers,
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    checkout_data = checkout_response.get_json()
    assert checkout_data["checkout_session"]["provider"] == "local"

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_clean_api_paid",
                "type": "checkout.session.completed",
                "order_public_id": checkout_data["public_id"],
                "payment_reference": "cs_clean_api_paid",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )
    assert webhook_response.status_code == 200
    assert webhook_response.get_json()["event_status"] == "processed"

    order_response = client.get(
        f"/commerce/admin/orders/{checkout_data['public_id']}",
        headers=admin_headers,
    )
    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "paid"
