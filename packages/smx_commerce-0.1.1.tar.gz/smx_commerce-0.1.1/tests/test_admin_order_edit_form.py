from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_order(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201

    checkout = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
            "buyer_phone": "123",
            "buyer_company": "SyntaxMatrix",
        },
    )
    assert checkout.status_code == 201

    return checkout.get_json()["public_id"]


def test_admin_orders_list_has_edit_link(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_order(client)

    response = client.get(
        "/commerce/admin/orders",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert f'href="/commerce/admin/orders/{order_id}/edit"' in html
    assert "Edit order" in html


def test_admin_order_edit_page_renders_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_order(client)

    response = client.get(
        f"/commerce/admin/orders/{order_id}/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Edit order" in html
    assert order_id in html
    assert 'name="buyer_full_name"' in html
    assert 'name="buyer_email"' in html
    assert 'name="buyer_phone"' in html
    assert 'name="buyer_company"' in html
    assert 'name="status"' in html
    assert 'name="notes"' in html
    assert "Bob Nti" in html
    assert "bob@example.com" in html


def test_admin_can_update_order_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_order(client)

    response = client.post(
        f"/commerce/admin/orders/{order_id}/update",
        data={
            "buyer_full_name": "Updated Buyer",
            "buyer_email": "updated@example.com",
            "buyer_phone": "999",
            "buyer_company": "Updated Company",
            "status": "cancelled",
            "notes": "Practice order cancelled.",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == f"/commerce/admin/orders/{order_id}"

    order_response = client.get(f"/commerce/admin/orders/{order_id}")

    assert order_response.status_code == 200

    order = order_response.get_json()

    assert order["buyer"]["full_name"] == "Updated Buyer"
    assert order["buyer"]["email"] == "updated@example.com"
    assert order["buyer"]["phone"] == "999"
    assert order["buyer"]["company"] == "Updated Company"
    assert order["status"] == "cancelled"
    assert order["notes"] == "Practice order cancelled."
    assert order["payment_reference"] is None


def test_admin_order_update_rejects_paid_status_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_order(client)

    response = client.post(
        f"/commerce/admin/orders/{order_id}/update",
        data={
            "buyer_full_name": "Updated Buyer",
            "buyer_email": "updated@example.com",
            "buyer_phone": "999",
            "buyer_company": "Updated Company",
            "status": "paid",
            "notes": "Should not set paid.",
        },
        content_type="application/x-www-form-urlencoded",
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "status can only be changed" in html

    order_response = client.get(f"/commerce/admin/orders/{order_id}")
    assert order_response.get_json()["status"] == "pending"
