import json

import pytest
from flask import Flask

from smx_commerce import init_commerce


def create_app(tmp_path, config):
    db_file = tmp_path / "commerce.db"

    app = Flask(__name__)

    resolved_config = {
        "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        **config,
    }

    init_commerce(
        app,
        config=resolved_config,
        init_schema=True,
    )

    return app


def seed_product_and_price(client, *, admin_key=None):
    headers = {}
    if admin_key:
        headers["X-SMX-Commerce-Admin-Key"] = admin_key

    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
        headers=headers,
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
        headers=headers,
    )
    assert price_response.status_code == 201


def test_init_commerce_can_run_without_payment_or_email_provider(tmp_path):
    app = create_app(
        tmp_path,
        config={
            "payment_provider": "none",
            "email_provider": "none",
        },
    )

    client = app.test_client()
    seed_product_and_price(client)

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )

    assert checkout_response.status_code == 201
    assert checkout_response.get_json()["checkout_session"] is None

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_no_provider",
                "type": "checkout.session.completed",
                "order_public_id": checkout_response.get_json()["public_id"],
                "payment_reference": "cs_no_provider",
            }
        ),
        content_type="application/json",
    )

    assert webhook_response.status_code == 503
    assert "verifier is not configured" in webhook_response.get_json()["error"]


def test_init_commerce_local_payment_provider_creates_checkout_session_and_accepts_verified_webhook(tmp_path):
    app = create_app(
        tmp_path,
        config={
            "admin_api_key": "local-admin-key",
            "payment_provider": "local",
            "local_webhook_signature": "valid-local-signature",
            "email_provider": "memory",
            "brand_name": "SyntaxMatrix",
        },
    )

    client = app.test_client()
    seed_product_and_price(client, admin_key="local-admin-key")

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )

    assert checkout_response.status_code == 201

    checkout_data = checkout_response.get_json()

    assert checkout_data["checkout_session"]["provider"] == "local"

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_local_paid",
                "type": "checkout.session.completed",
                "order_public_id": checkout_data["public_id"],
                "payment_reference": "cs_local_paid",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-local-signature"},
    )

    assert webhook_response.status_code == 200
    assert webhook_response.get_json()["event_status"] == "processed"
    assert webhook_response.get_json()["notification"]["sent"] is True

    order_response = client.get(
        f"/commerce/admin/orders/{checkout_data['public_id']}",
        headers={"X-SMX-Commerce-Admin-Key": "local-admin-key"},
    )

    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "paid"


def test_init_commerce_rejects_unsupported_payment_provider(tmp_path):
    with pytest.raises(ValueError, match="unsupported payment_provider"):
        create_app(
            tmp_path,
            config={
                "payment_provider": "unknown-provider",
            },
        )


def test_init_commerce_rejects_unsupported_email_provider(tmp_path):
    with pytest.raises(ValueError, match="unsupported email_provider"):
        create_app(
            tmp_path,
            config={
                "email_provider": "unknown-provider",
            },
        )
