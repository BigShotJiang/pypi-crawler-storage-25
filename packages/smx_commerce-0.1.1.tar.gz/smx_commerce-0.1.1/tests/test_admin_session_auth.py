from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_login_page_is_available_without_existing_session(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin/login",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert "Commerce Admin" in response.get_data(as_text=True)


def test_admin_json_route_still_accepts_header_key(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin/products",
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )

    assert response.status_code == 200


def test_admin_session_login_allows_browser_admin_access(tmp_path):
    client = create_client(tmp_path)

    blocked = client.get("/commerce/admin/products")
    assert blocked.status_code == 401

    login = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert login.status_code == 200
    assert login.get_json()["authenticated"] is True

    allowed = client.get("/commerce/admin/products")
    assert allowed.status_code == 200


def test_admin_session_login_rejects_wrong_key(tmp_path):
    client = create_client(tmp_path)

    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "wrong-key"},
    )

    assert response.status_code == 401
    assert response.get_json()["error"] == "invalid admin key"


def test_admin_logout_clears_session(tmp_path):
    client = create_client(tmp_path)

    login = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert login.status_code == 200

    allowed = client.get("/commerce/admin/products")
    assert allowed.status_code == 200

    logout = client.post("/commerce/admin/logout")
    assert logout.status_code == 200
    assert logout.get_json()["authenticated"] is False

    blocked = client.get("/commerce/admin/products")
    assert blocked.status_code == 401
