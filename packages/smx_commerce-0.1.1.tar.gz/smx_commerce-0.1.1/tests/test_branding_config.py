from smx_commerce.core import CommerceConfig
from smx_commerce.env_config import build_commerce_config_from_env


def test_branding_config_defaults_are_safe():
    config = CommerceConfig.from_mapping(
        {"database_url": "sqlite+pysqlite:///:memory:"}
    )

    assert config.site_title == "SyntaxMatrix"
    assert config.module_title == "smxCommerce"
    assert config.project_title == "smxCommerce"
    assert config.project_home_url == "/"
    assert config.assets_dir == "./smxcommerce/assets"
    assert config.logo_url == "/commerce/assets/logo.png"
    assert config.favicon_url == "/commerce/assets/favicon.png"


def test_branding_config_can_be_supplied_from_mapping():
    config = CommerceConfig.from_mapping(
        {
            "database_url": "sqlite+pysqlite:///:memory:",
            "site_title": "Client Site",
            "module_title": "Client Commerce",
            "project_home_url": "https://client.example.com",
            "assets_dir": "./client-assets",
            "logo_url": "/commerce/assets/logo.png",
            "favicon_url": "/commerce/assets/favicon.png",
        }
    )

    assert config.site_title == "Client Site"
    assert config.module_title == "Client Commerce"
    assert config.project_title == "Client Commerce"
    assert config.project_home_url == "https://client.example.com"
    assert config.assets_dir == "./client-assets"
    assert config.logo_url == "/commerce/assets/logo.png"
    assert config.favicon_url == "/commerce/assets/favicon.png"


def test_branding_config_can_be_loaded_from_env_file(tmp_path):
    env_file = tmp_path / ".smx_commerce.env"

    env_file.write_text(
        "\n".join(
            [
                "SMX_COMMERCE_DATABASE_URL=sqlite+pysqlite:///:memory:",
                "SMX_COMMERCE_SITE_TITLE=Client Site",
                "SMX_COMMERCE_MODULE_TITLE=Client Commerce",
                "SMX_COMMERCE_PROJECT_HOME_URL=https://client.example.com",
                "SMX_COMMERCE_ASSETS_DIR=./client-assets",
                "SMX_COMMERCE_LOGO_URL=/commerce/assets/logo.png",
                "SMX_COMMERCE_FAVICON_URL=/commerce/assets/favicon.png",
            ]
        ),
        encoding="utf-8",
    )

    values = build_commerce_config_from_env(env_file=env_file)
    config = CommerceConfig.from_mapping(values)

    assert values["site_title"] == "Client Site"
    assert values["module_title"] == "Client Commerce"
    assert values["project_home_url"] == "https://client.example.com"
    assert values["assets_dir"] == "./client-assets"
    assert values["logo_url"] == "/commerce/assets/logo.png"
    assert values["favicon_url"] == "/commerce/assets/favicon.png"

    assert "brand_name" not in values
    assert "project_title" not in values

    assert config.site_title == "Client Site"
    assert config.module_title == "Client Commerce"
    assert config.project_title == "Client Commerce"
    assert config.project_home_url == "https://client.example.com"
    assert config.assets_dir == "./client-assets"
    assert config.logo_url == "/commerce/assets/logo.png"
    assert config.favicon_url == "/commerce/assets/favicon.png"
