import pytest

from smx_commerce.payments import StripeWebhookVerifier, WebhookVerificationError


def test_stripe_webhook_verifier_requires_secret():
    with pytest.raises(ValueError, match="webhook_secret is required"):
        StripeWebhookVerifier("")


def test_stripe_webhook_verifier_rejects_missing_signature_header():
    verifier = StripeWebhookVerifier("whsec_test")

    with pytest.raises(WebhookVerificationError, match="missing Stripe-Signature header"):
        verifier.verify(payload=b"{}", headers={})
