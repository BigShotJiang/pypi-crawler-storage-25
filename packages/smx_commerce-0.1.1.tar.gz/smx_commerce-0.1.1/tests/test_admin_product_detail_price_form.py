from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def create_product(client):
    response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert response.status_code == 201


def test_admin_product_detail_contains_price_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_product(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Agentic AI Bootcamp" in html
    assert "Add price option" in html
    assert 'method="post" action="/commerce/admin/products/agentic-ai-bootcamp/prices"' in html
    assert 'name="code"' in html
    assert 'name="label"' in html
    assert 'name="amount_major"' in html
    assert 'name="currency"' in html


def test_admin_can_create_price_from_browser_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_product(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        data={
            "code": "standard",
            "label": "Standard",
            "amount_major": "299",
            "currency": "EUR",
            "billing_mode": "one_time",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products/agentic-ai-bootcamp"

    detail = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert detail.status_code == 200

    html = detail.get_data(as_text=True)

    assert "Standard" in html
    assert "standard" in html
    assert "EUR 299" in html


def test_admin_price_form_error_renders_product_detail(tmp_path):
    client = create_client(tmp_path)
    login(client)
    create_product(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        data={
            "code": "Invalid Code",
            "label": "Bad Price",
            "amount_major": "299",
            "currency": "EUR",
            "billing_mode": "one_time",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Add price option" in html
    assert "code must use lowercase letters" in html
