import json

from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "local",
            "local_webhook_signature": "valid-test-signature",
            "email_provider": "memory",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_category_product_price(client):
    category = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
    )
    assert category.status_code == 201

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "category_slugs": ["bootcamps"],
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201


def seed_order(client):
    checkout = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout.status_code == 201
    return checkout.get_json()


def test_can_delete_unused_price(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price(client)

    response = client.post("/commerce/admin/products/agentic-ai-bootcamp/prices/standard/delete")

    assert response.status_code == 200
    assert response.get_json()["deleted"] is True

    missing = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices/standard")
    assert missing.status_code == 404


def test_price_delete_is_blocked_when_order_references_it(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price(client)
    seed_order(client)

    response = client.post("/commerce/admin/products/agentic-ai-bootcamp/prices/standard/delete")

    assert response.status_code == 409
    assert "order(s) reference it" in response.get_json()["error"]


def test_can_delete_unused_product_and_related_setup_rows(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price(client)

    response = client.post("/commerce/admin/products/agentic-ai-bootcamp/delete")

    assert response.status_code == 200
    assert response.get_json()["deleted"] is True

    missing_product = client.get("/commerce/admin/products/agentic-ai-bootcamp")
    assert missing_product.status_code == 404

    prices = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices")
    assert prices.status_code == 200
    assert prices.get_json() == []


def test_product_delete_is_blocked_when_order_references_it(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price(client)
    seed_order(client)

    response = client.post("/commerce/admin/products/agentic-ai-bootcamp/delete")

    assert response.status_code == 409
    assert "order(s) reference it" in response.get_json()["error"]


def test_category_delete_is_blocked_when_product_uses_it(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_product_price(client)

    response = client.post("/commerce/admin/categories/bootcamps/delete")

    assert response.status_code == 409
    assert "product(s) use it" in response.get_json()["error"]


def test_can_delete_unused_category(tmp_path):
    client = create_client(tmp_path)
    login(client)

    category = client.post(
        "/commerce/admin/categories",
        json={"slug": "unused", "name": "Unused"},
    )
    assert category.status_code == 201

    response = client.post("/commerce/admin/categories/unused/delete")

    assert response.status_code == 200
    assert response.get_json()["deleted"] is True

    missing = client.get("/commerce/admin/categories/unused")
    assert missing.status_code == 404


def test_category_delete_is_blocked_when_child_category_uses_it_as_parent(tmp_path):
    client = create_client(tmp_path)
    login(client)

    parent = client.post(
        "/commerce/admin/categories",
        json={"slug": "training", "name": "Training"},
    )
    assert parent.status_code == 201

    child = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "parent_slug": "training",
        },
    )
    assert child.status_code == 201

    response = client.post("/commerce/admin/categories/training/delete")

    assert response.status_code == 409
    assert "child category" in response.get_json()["error"]
