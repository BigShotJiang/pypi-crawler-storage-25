from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def test_category_admin_routes_create_read_update_archive(tmp_path):
    client = create_test_client(tmp_path)

    create_response = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "description": "Training products",
            "metadata": {"audience": "developers"},
        },
    )

    assert create_response.status_code == 201
    assert create_response.get_json()["slug"] == "bootcamps"

    list_response = client.get("/commerce/admin/categories")

    assert list_response.status_code == 200
    assert [item["slug"] for item in list_response.get_json()] == ["bootcamps"]

    get_response = client.get("/commerce/admin/categories/bootcamps")

    assert get_response.status_code == 200
    assert get_response.get_json()["name"] == "Bootcamps"

    update_response = client.patch(
        "/commerce/admin/categories/bootcamps",
        json={
            "name": "AI Bootcamps",
            "sort_order": 10,
            "metadata": {"level": "advanced"},
        },
    )

    assert update_response.status_code == 200
    assert update_response.get_json()["name"] == "AI Bootcamps"
    assert update_response.get_json()["sort_order"] == 10
    assert update_response.get_json()["metadata"]["level"] == "advanced"

    archive_response = client.post("/commerce/admin/categories/bootcamps/archive")

    assert archive_response.status_code == 200
    assert archive_response.get_json()["status"] == "archived"

    list_after_archive_response = client.get("/commerce/admin/categories")

    assert list_after_archive_response.status_code == 200
    assert list_after_archive_response.get_json() == []

    list_archived_response = client.get("/commerce/admin/categories?include_archived=1")

    assert list_archived_response.status_code == 200
    assert list_archived_response.get_json()[0]["status"] == "archived"


def test_category_admin_create_rejects_duplicate_slug(tmp_path):
    client = create_test_client(tmp_path)

    client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Bootcamps"},
    )

    duplicate_response = client.post(
        "/commerce/admin/categories",
        json={"slug": "bootcamps", "name": "Duplicate"},
    )

    assert duplicate_response.status_code == 400
    assert "category already exists" in duplicate_response.get_json()["error"]


def test_category_admin_returns_404_for_missing_category(tmp_path):
    client = create_test_client(tmp_path)

    response = client.get("/commerce/admin/categories/missing-category")

    assert response.status_code == 404
