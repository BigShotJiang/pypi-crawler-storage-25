from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def create_active_product_and_price(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201


def test_checkout_start_creates_pending_order(tmp_path):
    client = create_test_client(tmp_path)
    create_active_product_and_price(client)

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "BOB@example.com",
            "buyer_phone": "+353000000000",
            "buyer_company": "SyntaxMatrix",
            "buyer_metadata": {"role": "attendee"},
            "order_metadata": {"source": "route-test"},
        },
    )

    assert response.status_code == 201

    data = response.get_json()

    assert data["public_id"].startswith("ord_")
    assert data["product_slug"] == "example-product"
    assert data["price_code"] == "standard"
    assert data["amount_cents"] == 29900
    assert data["currency"] == "EUR"
    assert data["status"] == "pending"
    assert data["payment_provider"] == "stripe"
    assert data["payment_reference"] is None
    assert data["buyer"]["email"] == "bob@example.com"
    assert data["buyer"]["metadata"]["role"] == "attendee"
    assert data["metadata"]["source"] == "route-test"


def test_checkout_start_rejects_missing_buyer_email(tmp_path):
    client = create_test_client(tmp_path)
    create_active_product_and_price(client)

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
        },
    )

    assert response.status_code == 400
    assert "email is required" in response.get_json()["error"]


def test_checkout_start_rejects_inactive_product(tmp_path):
    client = create_test_client(tmp_path)

    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "draft-product",
            "name": "Draft Product",
            "status": "draft",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/draft-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
        },
    )
    assert price_response.status_code == 201

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "draft-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )

    assert response.status_code == 400
    assert "product is not active" in response.get_json()["error"]


def test_checkout_start_rejects_inactive_price(tmp_path):
    client = create_test_client(tmp_path)

    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "inactive-price",
            "label": "Inactive Price",
            "amount_cents": 29900,
            "status": "inactive",
        },
    )
    assert price_response.status_code == 201

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "inactive-price",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )

    assert response.status_code == 400
    assert "price is not active" in response.get_json()["error"]


def test_old_product_register_route_does_not_exist(tmp_path):
    client = create_test_client(tmp_path)

    response = client.post("/products/example-product/register", json={})

    assert response.status_code == 404
