from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_categories(client):
    parent = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "training",
            "name": "Training",
            "status": "active",
        },
    )
    assert parent.status_code == 201

    child = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "status": "active",
            "description": "Old description",
            "sort_order": 1,
        },
    )
    assert child.status_code == 201


def test_admin_categories_page_has_edit_link(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_categories(client)

    response = client.get(
        "/commerce/admin/categories",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert 'href="/commerce/admin/categories/bootcamps/edit"' in html
    assert "Edit category" in html


def test_admin_category_edit_page_renders_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_categories(client)

    response = client.get(
        "/commerce/admin/categories/bootcamps/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Edit category" in html
    assert "Slug: bootcamps" in html
    assert 'name="name"' in html
    assert 'name="status"' in html
    assert 'name="parent_slug"' in html
    assert 'value="training"' in html
    assert "Old description" in html


def test_admin_can_update_category_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_categories(client)

    response = client.post(
        "/commerce/admin/categories/bootcamps/update",
        data={
            "name": "Updated Bootcamps",
            "status": "hidden",
            "parent_slug": "training",
            "description": "Updated description",
            "sort_order": "12",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/categories"

    category_response = client.get("/commerce/admin/categories/bootcamps")

    assert category_response.status_code == 200

    category = category_response.get_json()

    assert category["slug"] == "bootcamps"
    assert category["name"] == "Updated Bootcamps"
    assert category["status"] == "hidden"
    assert category["parent_slug"] == "training"
    assert category["description"] == "Updated description"
    assert category["sort_order"] == 12
