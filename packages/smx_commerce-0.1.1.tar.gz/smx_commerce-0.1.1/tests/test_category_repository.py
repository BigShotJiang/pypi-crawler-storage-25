import pytest

from smx_commerce.catalog import Category, CategoryRepository, CategoryStatus
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def test_category_create_and_read(session):
    repo = CategoryRepository(session)

    created = repo.create(
        Category(
            slug="ai-bootcamps",
            name="AI Bootcamps",
            description="Training products",
            metadata={"audience": "developers"},
        )
    )
    session.commit()

    loaded = repo.get_by_slug("ai-bootcamps")

    assert created.slug == "ai-bootcamps"
    assert loaded is not None
    assert loaded.name == "AI Bootcamps"
    assert loaded.description == "Training products"
    assert loaded.metadata["audience"] == "developers"


def test_category_duplicate_slug_is_rejected(session):
    repo = CategoryRepository(session)

    repo.create(Category(slug="ai-bootcamps", name="AI Bootcamps"))

    with pytest.raises(ValueError, match="category already exists"):
        repo.create(Category(slug="ai-bootcamps", name="Duplicate"))


def test_category_list_excludes_archived_by_default(session):
    repo = CategoryRepository(session)

    repo.create(Category(slug="active-category", name="Active Category"))
    repo.create(
        Category(
            slug="archived-category",
            name="Archived Category",
            status=CategoryStatus.ARCHIVED,
        )
    )

    categories = repo.list()

    assert [category.slug for category in categories] == ["active-category"]


def test_category_update(session):
    repo = CategoryRepository(session)

    repo.create(Category(slug="ai-bootcamps", name="AI Bootcamps"))

    updated = repo.update(
        "ai-bootcamps",
        name="AI and LLM Bootcamps",
        description="Updated description",
        sort_order=10,
        metadata={"level": "advanced"},
    )

    assert updated.name == "AI and LLM Bootcamps"
    assert updated.description == "Updated description"
    assert updated.sort_order == 10
    assert updated.metadata["level"] == "advanced"


def test_category_archive_is_soft_delete(session):
    repo = CategoryRepository(session)

    repo.create(Category(slug="ai-bootcamps", name="AI Bootcamps"))

    archived = repo.archive("ai-bootcamps")

    assert archived.status == CategoryStatus.ARCHIVED
    assert repo.list() == []

    all_categories = repo.list(include_archived=True)

    assert len(all_categories) == 1
    assert all_categories[0].slug == "ai-bootcamps"
    assert all_categories[0].status == CategoryStatus.ARCHIVED


def test_category_repository_works_with_sqlite_file(tmp_path):
    db_file = tmp_path / "commerce.db"
    engine = make_engine(f"sqlite+pysqlite:///{db_file.as_posix()}")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        repo = CategoryRepository(session)
        repo.create(Category(slug="services", name="Services"))
        session.commit()

    with SessionFactory() as session:
        repo = CategoryRepository(session)
        loaded = repo.get_by_slug("services")

    assert loaded is not None
    assert loaded.name == "Services"
