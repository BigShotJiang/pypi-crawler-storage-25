import pytest

from smx_commerce.notifications import EmailMessage, SMTPEmailSender


class FakeSMTP:
    instances = []

    def __init__(self, host, port, timeout):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.started_tls = False
        self.login_args = None
        self.sent_messages = []
        FakeSMTP.instances.append(self)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def starttls(self):
        self.started_tls = True

    def login(self, username, password):
        self.login_args = (username, password)

    def send_message(self, message):
        self.sent_messages.append(message)


def test_smtp_email_sender_sends_message_with_tls_and_login(monkeypatch):
    FakeSMTP.instances = []

    monkeypatch.setattr("smx_commerce.notifications.smtp_sender.smtplib.SMTP", FakeSMTP)

    sender = SMTPEmailSender(
        host="smtp.example.test",
        port=587,
        default_from_email="sales@example.test",
        username="user",
        password="pass",
        use_tls=True,
        use_ssl=False,
    )

    sender.send(
        EmailMessage(
            to_email="bob@example.com",
            subject="Order confirmed",
            body_text="Your order is confirmed.",
        )
    )

    smtp = FakeSMTP.instances[0]

    assert smtp.host == "smtp.example.test"
    assert smtp.port == 587
    assert smtp.started_tls is True
    assert smtp.login_args == ("user", "pass")
    assert len(smtp.sent_messages) == 1

    sent_message = smtp.sent_messages[0]

    assert sent_message["From"] == "sales@example.test"
    assert sent_message["To"] == "bob@example.com"
    assert sent_message["Subject"] == "Order confirmed"
    assert "Your order is confirmed." in sent_message.get_content()


def test_smtp_email_sender_can_use_message_from_email(monkeypatch):
    FakeSMTP.instances = []

    monkeypatch.setattr("smx_commerce.notifications.smtp_sender.smtplib.SMTP", FakeSMTP)

    sender = SMTPEmailSender(
        host="smtp.example.test",
        port=587,
        use_tls=False,
    )

    sender.send(
        EmailMessage(
            from_email="custom@example.test",
            to_email="bob@example.com",
            subject="Order confirmed",
            body_text="Confirmed.",
        )
    )

    sent_message = FakeSMTP.instances[0].sent_messages[0]

    assert sent_message["From"] == "custom@example.test"
    assert FakeSMTP.instances[0].started_tls is False


def test_smtp_email_sender_requires_from_email():
    sender = SMTPEmailSender(host="smtp.example.test")

    with pytest.raises(ValueError, match="from_email is required"):
        sender.send(
            EmailMessage(
                to_email="bob@example.com",
                subject="Order confirmed",
                body_text="Confirmed.",
            )
        )


def test_smtp_email_sender_rejects_tls_and_ssl_together():
    with pytest.raises(ValueError, match="use_tls and use_ssl cannot both be true"):
        SMTPEmailSender(
            host="smtp.example.test",
            use_tls=True,
            use_ssl=True,
        )
