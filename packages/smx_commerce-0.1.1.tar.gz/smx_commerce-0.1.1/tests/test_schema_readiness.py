import pytest

from smx_commerce.core import CommerceRuntime, REQUIRED_TABLES, SchemaNotReadyError


def test_runtime_reports_missing_tables_before_schema_init(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {"database_url": f"sqlite+pysqlite:///{db_file.as_posix()}"}
    )

    missing = runtime.get_missing_tables()

    assert set(REQUIRED_TABLES).issubset(set(missing))

    with pytest.raises(SchemaNotReadyError, match="database schema is not ready"):
        runtime.assert_schema_ready()


def test_runtime_schema_ready_after_init_schema(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {"database_url": f"sqlite+pysqlite:///{db_file.as_posix()}"}
    )

    runtime.init_schema()

    assert runtime.get_missing_tables() == []
    runtime.assert_schema_ready()
