import pytest

from smx_commerce.catalog import (
    Money,
    PriceStatus,
    Product,
    ProductPrice,
    ProductPriceRepository,
    ProductRepository,
    ProductStatus,
)
from smx_commerce.checkout import CheckoutService, OrderStatus, StartCheckoutRequest
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def seed_product_and_price(session, *, product_status=ProductStatus.ACTIVE, price_status=PriceStatus.ACTIVE):
    ProductRepository(session).create(
        Product(
            slug="example-product",
            name="Example Product",
            status=product_status,
        )
    )

    ProductPriceRepository(session).create(
        "example-product",
        ProductPrice(
            code="standard",
            label="Standard",
            amount=Money.from_major("299.00", "EUR"),
            status=price_status,
        ),
    )


def test_checkout_service_creates_pending_order(session):
    seed_product_and_price(session)

    service = CheckoutService(session)

    order = service.start_checkout(
        StartCheckoutRequest(
            product_slug="example-product",
            price_code="standard",
            buyer_full_name="Bob Nti",
            buyer_email="BOB@example.com",
            buyer_phone="+353000000000",
            buyer_company="SyntaxMatrix",
            buyer_metadata={"role": "attendee"},
            order_metadata={"source": "unit-test"},
        )
    )

    assert order.status == OrderStatus.PENDING
    assert order.product_slug == "example-product"
    assert order.price_code == "standard"
    assert order.amount.amount_cents == 29900
    assert order.amount.currency == "EUR"
    assert order.buyer.email == "bob@example.com"
    assert order.buyer.metadata["role"] == "attendee"
    assert order.metadata["source"] == "unit-test"


def test_checkout_service_rejects_inactive_product(session):
    seed_product_and_price(session, product_status=ProductStatus.PAUSED)

    service = CheckoutService(session)

    with pytest.raises(ValueError, match="product is not active"):
        service.start_checkout(
            StartCheckoutRequest(
                product_slug="example-product",
                price_code="standard",
                buyer_full_name="Bob Nti",
                buyer_email="bob@example.com",
            )
        )


def test_checkout_service_rejects_inactive_price(session):
    seed_product_and_price(session, price_status=PriceStatus.INACTIVE)

    service = CheckoutService(session)

    with pytest.raises(ValueError, match="price is not active"):
        service.start_checkout(
            StartCheckoutRequest(
                product_slug="example-product",
                price_code="standard",
                buyer_full_name="Bob Nti",
                buyer_email="bob@example.com",
            )
        )
