from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_product_and_price(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
            "billing_mode": "one_time",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert price.status_code == 201


def test_admin_price_edit_uses_client_branding_and_keeps_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product_and_price(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Edit Standard · Commerce Admin" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html

    assert 'href="/commerce/admin/products"' in html
    assert 'href="/commerce/admin/products/agentic-ai-bootcamp"' in html
    assert "Back to product" in html
    assert 'href="/commerce/admin/categories"' in html
    assert 'href="/commerce/admin/orders"' in html

    assert 'action="/commerce/admin/products/agentic-ai-bootcamp/prices/standard/update"' in html
    assert 'name="label"' in html
    assert 'name="amount_major"' in html
    assert 'value="299"' in html
    assert 'name="currency"' in html
    assert 'name="billing_mode"' in html
    assert 'name="billing_interval"' in html
    assert 'name="status"' in html
    assert 'name="sort_order"' in html
    assert "Save price changes" in html
    assert "Amount cents" not in html


def test_admin_price_edit_error_preserves_client_branding(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product_and_price(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/update",
        data={
            "label": "",
            "amount_major": "1",
            "currency": "EUR",
            "billing_mode": "one_time",
            "billing_interval": "",
            "status": "active",
            "sort_order": "1",
        },
        content_type="application/x-www-form-urlencoded",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Client Portal · Edit Standard · Commerce Admin" in html
    assert "Client Portal" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert "label is required" in html