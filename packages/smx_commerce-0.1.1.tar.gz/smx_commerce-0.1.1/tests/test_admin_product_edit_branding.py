from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_category_and_product(client):
    category = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "status": "active",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert category.status_code == 201

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
            "category_slugs": ["bootcamps"],
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert product.status_code == 201


def test_admin_product_edit_uses_client_branding_and_keeps_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_and_product(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Edit Agentic AI Bootcamp · Commerce Admin" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html

    assert 'href="/commerce/admin/products"' in html
    assert 'href="/commerce/admin/categories"' in html
    assert 'href="/commerce/admin/orders"' in html
    assert 'href="/commerce/admin/products/agentic-ai-bootcamp"' in html
    assert "Back to product" in html

    assert 'action="/commerce/admin/products/agentic-ai-bootcamp/update"' in html
    assert 'name="name"' in html
    assert 'name="kind"' in html
    assert 'name="status"' in html
    assert 'name="category_slugs"' in html
    assert 'name="summary"' in html
    assert 'name="description"' in html
    assert "Save product changes" in html
    assert "Bootcamps" in html


def test_admin_product_edit_error_preserves_client_branding(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_category_and_product(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/update",
        data={
            "name": "",
            "kind": "event",
            "status": "active",
            "summary": "Bad update",
            "description": "Missing name.",
            "category_slugs": ["bootcamps"],
        },
        content_type="application/x-www-form-urlencoded",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Client Portal · Edit Agentic AI Bootcamp · Commerce Admin" in html
    assert "Client Portal" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert "name is required" in html