from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
            "project_title": "Client Portal",
            "project_home_url": "/client-home",
            "logo_url": "/static/client/logo.png",
            "favicon_url": "/static/client/favicon.ico",
        },
        init_schema=True,
    )

    return app.test_client()


def seed_product_and_price(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
        headers={"X-SMX-Commerce-Admin-Key": "secret-admin-key"},
    )
    assert price.status_code == 201


def test_public_product_list_uses_client_branding(tmp_path):
    client = create_client(tmp_path)
    seed_product_and_price(client)

    response = client.get("/products", headers={"Accept": "text/html"})

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Products" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html
    assert "Agentic AI Bootcamp" in html

    assert 'href="/commerce/admin"' not in html
    assert "Open admin" not in html


def test_public_product_detail_uses_client_branding_and_checkout_form(tmp_path):
    client = create_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Client Portal · Agentic AI Bootcamp" in html
    assert 'href="/client-home"' in html
    assert "Back to Client Portal" in html
    assert 'src="/static/client/logo.png"' in html
    assert 'alt="Client Portal logo"' in html
    assert 'rel="icon" href="/static/client/favicon.ico"' in html

    assert 'method="post" action="/checkout/start"' in html
    assert 'name="product_slug"' in html
    assert 'name="price_code"' in html
    assert 'name="buyer_full_name"' in html
    assert 'name="buyer_email"' in html
    assert "Continue to checkout" in html

    assert 'href="/commerce/admin"' not in html
    assert "Open admin" not in html