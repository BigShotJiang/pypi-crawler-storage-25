from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_product_and_price(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "billing_mode": "one_time",
            "status": "active",
        },
    )
    assert price.status_code == 201


def test_admin_product_detail_has_price_edit_link(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product_and_price(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert 'href="/commerce/admin/products/agentic-ai-bootcamp/prices/standard/edit"' in html
    assert "Edit price" in html


def test_admin_price_edit_page_renders_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product_and_price(client)

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Edit price option" in html
    assert 'name="label"' in html
    assert 'name="amount_major"' in html
    assert 'name="currency"' in html
    assert 'name="billing_mode"' in html
    assert 'name="status"' in html
    assert "Standard" in html
    assert 'value="299"' in html
    assert "29900" not in html


def test_admin_can_update_price_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product_and_price(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/update",
        data={
            "label": "Early Bird",
            "amount_cents": "19900",
            "currency": "EUR",
            "billing_mode": "one_time",
            "billing_interval": "",
            "status": "inactive",
            "sort_order": "5",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products/agentic-ai-bootcamp"

    price_response = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices/standard")

    assert price_response.status_code == 200

    price = price_response.get_json()

    assert price["label"] == "Early Bird"
    assert price["amount_cents"] == 19900
    assert price["currency"] == "EUR"
    assert price["status"] == "inactive"
    assert price["sort_order"] == 5
