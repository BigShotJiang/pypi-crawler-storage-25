import json

from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "local",
            "local_webhook_signature": "valid-test-signature",
            "email_provider": "memory",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_product_price_order(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201

    checkout = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout.status_code == 201

    return checkout.get_json()["public_id"]


def mark_paid(client, order_id):
    webhook_payload = {
        "id": f"evt_{order_id}",
        "type": "checkout.session.completed",
        "order_public_id": order_id,
        "payment_reference": f"cs_{order_id}",
    }

    webhook = client.post(
        "/stripe/webhook",
        data=json.dumps(webhook_payload),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )

    assert webhook.status_code == 200


def test_admin_order_edit_page_has_delete_practice_order_button(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_product_price_order(client)

    response = client.get(
        f"/commerce/admin/orders/{order_id}/edit",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert f'action="/commerce/admin/orders/{order_id}/delete"' in html
    assert "Delete practice order" in html


def test_can_delete_pending_practice_order(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_product_price_order(client)

    response = client.post(f"/commerce/admin/orders/{order_id}/delete")

    assert response.status_code == 200
    assert response.get_json()["deleted"] is True

    missing = client.get(f"/commerce/admin/orders/{order_id}")
    assert missing.status_code == 404


def test_browser_can_delete_pending_practice_order_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_product_price_order(client)

    response = client.post(
        f"/commerce/admin/orders/{order_id}/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/orders"

    missing = client.get(f"/commerce/admin/orders/{order_id}")
    assert missing.status_code == 404


def test_paid_order_delete_is_blocked(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_product_price_order(client)
    mark_paid(client, order_id)

    response = client.post(f"/commerce/admin/orders/{order_id}/delete")

    assert response.status_code == 409
    assert "status is paid" in response.get_json()["error"]

    still_exists = client.get(f"/commerce/admin/orders/{order_id}")
    assert still_exists.status_code == 200
    assert still_exists.get_json()["status"] == "paid"


def test_browser_paid_order_delete_redirects_back_with_error(tmp_path):
    client = create_client(tmp_path)
    login(client)
    order_id = seed_product_price_order(client)
    mark_paid(client, order_id)

    response = client.post(
        f"/commerce/admin/orders/{order_id}/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"].startswith(
        f"/commerce/admin/orders/{order_id}/edit?error="
    )

    page = client.get(response.headers["Location"], headers={"Accept": "text/html"})
    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "order cannot be deleted" in html
    assert "status is paid" in html
