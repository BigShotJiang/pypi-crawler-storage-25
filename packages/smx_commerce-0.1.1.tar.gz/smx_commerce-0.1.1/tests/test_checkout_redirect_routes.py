from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def seed_pending_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def test_checkout_success_does_not_mark_order_paid(tmp_path):
    client = create_test_client(tmp_path)
    order = seed_pending_order(client)

    response = client.get(f"/checkout/success?order_id={order['public_id']}")

    assert response.status_code == 200

    data = response.get_json()

    assert data["checkout_status"] == "success_redirect_received"
    assert data["payment_confirmation"] == "webhook_required"
    assert data["order"]["public_id"] == order["public_id"]
    assert data["order"]["status"] == "pending"

    admin_response = client.get(f"/commerce/admin/orders/{order['public_id']}")

    assert admin_response.status_code == 200
    assert admin_response.get_json()["status"] == "pending"


def test_checkout_cancel_does_not_mark_order_paid(tmp_path):
    client = create_test_client(tmp_path)
    order = seed_pending_order(client)

    response = client.get(f"/checkout/cancel?order_id={order['public_id']}")

    assert response.status_code == 200

    data = response.get_json()

    assert data["checkout_status"] == "cancel_redirect_received"
    assert data["payment_confirmation"] == "not_confirmed"
    assert data["order"]["public_id"] == order["public_id"]
    assert data["order"]["status"] == "pending"


def test_checkout_success_returns_404_for_missing_order(tmp_path):
    client = create_test_client(tmp_path)

    response = client.get("/checkout/success?order_id=ord_missing")

    assert response.status_code == 404


def test_checkout_cancel_returns_generic_response_without_order_id(tmp_path):
    client = create_test_client(tmp_path)

    response = client.get("/checkout/cancel")

    assert response.status_code == 200
    assert response.get_json()["order"] is None
