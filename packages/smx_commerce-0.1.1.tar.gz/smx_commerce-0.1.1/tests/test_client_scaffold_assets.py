from flask import Flask

from smx_commerce import ensure_smxcommerce_scaffold, setup_commerce
from smx_commerce.core import CommerceConfig
from smx_commerce.env_config import build_commerce_config_from_env


def test_smxcommerce_scaffold_creates_assets_folder_and_default_assets(tmp_path):
    scaffold = ensure_smxcommerce_scaffold(project_root=tmp_path)

    assert scaffold.assets_dir == tmp_path / "smxcommerce" / "assets"
    assert scaffold.assets_dir.is_dir()

    assert scaffold.logo_file == tmp_path / "smxcommerce" / "assets" / "logo.png"
    assert scaffold.favicon_file == tmp_path / "smxcommerce" / "assets" / "favicon.png"

    assert scaffold.logo_file.is_file()
    assert scaffold.favicon_file.is_file()

    assert scaffold.logo_file.stat().st_size > 0
    assert scaffold.favicon_file.stat().st_size > 0


def test_smxcommerce_scaffold_env_contains_asset_defaults(tmp_path):
    scaffold = ensure_smxcommerce_scaffold(project_root=tmp_path)

    env_text = scaffold.env_file.read_text(encoding="utf-8")
    example_text = scaffold.env_example_file.read_text(encoding="utf-8")

    assert "SMX_COMMERCE_SITE_TITLE=SyntaxMatrix" in env_text
    assert "SMX_COMMERCE_MODULE_TITLE=smxCommerce" in env_text
    assert "SMX_COMMERCE_LOGO_URL=/commerce/assets/logo.png" in env_text
    assert "SMX_COMMERCE_FAVICON_URL=/commerce/assets/favicon.png" in env_text
    assert "SMX_COMMERCE_ASSETS_DIR=" in env_text

    assert "SMX_COMMERCE_SITE_TITLE=SyntaxMatrix" in example_text
    assert "SMX_COMMERCE_MODULE_TITLE=smxCommerce" in example_text
    assert "SMX_COMMERCE_ASSETS_DIR=./smxcommerce/assets" in example_text


def test_branding_config_understands_site_and_module_titles(tmp_path):
    env_file = tmp_path / ".smx_commerce.env"
    env_file.write_text(
        "\n".join(
            [
                "SMX_COMMERCE_DATABASE_URL=sqlite+pysqlite:///:memory:",
                "SMX_COMMERCE_SITE_TITLE=SyntaxMatrix",
                "SMX_COMMERCE_MODULE_TITLE=smxCommerce",
                "SMX_COMMERCE_ASSETS_DIR=./smxcommerce/assets",
                "SMX_COMMERCE_LOGO_URL=/commerce/assets/logo.png",
                "SMX_COMMERCE_FAVICON_URL=/commerce/assets/favicon.png",
            ]
        ),
        encoding="utf-8",
    )

    values = build_commerce_config_from_env(env_file=env_file)
    config = CommerceConfig.from_mapping(values)

    assert config.site_title == "SyntaxMatrix"
    assert config.module_title == "smxCommerce"
    assert config.project_title == "SyntaxMatrix"
    assert config.assets_dir == "./smxcommerce/assets"
    assert config.logo_url == "/commerce/assets/logo.png"
    assert config.favicon_url == "/commerce/assets/favicon.png"


def test_setup_commerce_serves_scaffold_assets(tmp_path):
    app = Flask(__name__)

    setup_commerce(
        app,
        project_root=tmp_path,
        init_schema=True,
    )

    client = app.test_client()

    logo_response = client.get("/commerce/assets/logo.png")
    favicon_response = client.get("/commerce/assets/favicon.png")

    assert logo_response.status_code == 200
    assert favicon_response.status_code == 200
    assert logo_response.data
    assert favicon_response.data