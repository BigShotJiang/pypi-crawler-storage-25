from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime
from smx_commerce.payments import PaymentCheckoutSession


class FakeCheckoutProvider:
    def create_checkout_session(self, *, order, success_url, cancel_url):
        return PaymentCheckoutSession(
            provider="fake",
            session_id=f"fake_{order.public_id}",
            checkout_url=f"https://payments.example.test/checkout/{order.public_id}",
            metadata={
                "order_public_id": order.public_id,
                "success_url": success_url,
                "cancel_url": cancel_url,
            },
        )


def create_test_client(tmp_path, *, checkout_provider=None):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
            payment_checkout_provider=checkout_provider,
        )
    )

    return app.test_client()


def seed_product_and_price(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201


def test_checkout_start_returns_order_only_when_no_provider_is_configured(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )

    assert response.status_code == 201

    data = response.get_json()

    assert data["order"]["status"] == "pending"
    assert data["order"]["amount_cents"] == 29900
    assert data["checkout_session"] is None


def test_checkout_start_returns_checkout_session_when_provider_is_configured(tmp_path):
    client = create_test_client(tmp_path, checkout_provider=FakeCheckoutProvider())
    seed_product_and_price(client)

    response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
            "success_url": "https://example.test/success",
            "cancel_url": "https://example.test/cancel",
        },
    )

    assert response.status_code == 201

    data = response.get_json()

    assert data["order"]["status"] == "pending"
    assert data["checkout_session"]["provider"] == "fake"
    assert data["checkout_session"]["session_id"] == f"fake_{data['order']['public_id']}"
    assert data["checkout_session"]["checkout_url"].endswith(data["order"]["public_id"])
    assert data["checkout_session"]["metadata"]["order_public_id"] == data["order"]["public_id"]
    assert data["checkout_session"]["metadata"]["success_url"] == "https://example.test/success"
    assert data["checkout_session"]["metadata"]["cancel_url"] == "https://example.test/cancel"
