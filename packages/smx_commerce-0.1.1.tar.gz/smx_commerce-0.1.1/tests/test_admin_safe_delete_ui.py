from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def test_product_detail_contains_safe_delete_product_and_price_buttons(tmp_path):
    client = create_client(tmp_path)
    login(client)

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201

    response = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert 'action="/commerce/admin/products/agentic-ai-bootcamp/delete"' in html
    assert "Delete unused product" in html
    assert 'action="/commerce/admin/products/agentic-ai-bootcamp/prices/standard/delete"' in html
    assert "Delete unused price" in html


def test_categories_page_contains_safe_delete_category_button(tmp_path):
    client = create_client(tmp_path)
    login(client)

    category = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "status": "active",
        },
    )
    assert category.status_code == 201

    response = client.get(
        "/commerce/admin/categories",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert 'action="/commerce/admin/categories/bootcamps/delete"' in html
    assert "Delete unused category" in html


def test_browser_can_delete_unused_price_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products/agentic-ai-bootcamp"

    missing = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices/standard")
    assert missing.status_code == 404


def test_browser_can_delete_unused_product_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/products"

    missing = client.get("/commerce/admin/products/agentic-ai-bootcamp")
    assert missing.status_code == 404


def test_browser_can_delete_unused_category_from_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    category = client.post(
        "/commerce/admin/categories",
        json={
            "slug": "unused",
            "name": "Unused",
            "status": "active",
        },
    )
    assert category.status_code == 201

    response = client.post(
        "/commerce/admin/categories/unused/delete",
        data={},
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/categories"

    missing = client.get("/commerce/admin/categories/unused")
    assert missing.status_code == 404
