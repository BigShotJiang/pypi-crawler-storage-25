import csv
from io import StringIO

from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def seed_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
            "buyer_phone": "+353000000000",
            "buyer_company": "SyntaxMatrix",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def parse_csv_response(response):
    text = response.data.decode("utf-8")
    return list(csv.DictReader(StringIO(text)))


def test_orders_csv_export_uses_actual_order_amount_not_current_price(tmp_path):
    client = create_test_client(tmp_path)
    order = seed_order(client)

    price_update_response = client.patch(
        "/commerce/admin/products/example-product/prices/standard",
        json={
            "amount_cents": 99900,
        },
    )
    assert price_update_response.status_code == 200

    response = client.get("/commerce/admin/orders.csv")

    assert response.status_code == 200
    assert response.mimetype == "text/csv"

    rows = parse_csv_response(response)

    assert len(rows) == 1
    assert rows[0]["public_id"] == order["public_id"]
    assert rows[0]["product_slug"] == "example-product"
    assert rows[0]["price_code"] == "standard"
    assert rows[0]["amount_cents"] == "29900"
    assert rows[0]["currency"] == "EUR"
    assert rows[0]["buyer_email"] == "bob@example.com"


def test_orders_csv_export_can_filter_by_status(tmp_path):
    client = create_test_client(tmp_path)
    seed_order(client)

    response = client.get("/commerce/admin/orders.csv?status=pending")

    assert response.status_code == 200

    rows = parse_csv_response(response)

    assert len(rows) == 1
    assert rows[0]["status"] == "pending"
