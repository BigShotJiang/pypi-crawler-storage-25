import json
from collections.abc import Mapping

from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime
from smx_commerce.payments import VerifiedPaymentEvent, WebhookVerificationError


class FakeStripeVerifier:
    def verify(self, *, payload: bytes, headers: Mapping[str, str]) -> VerifiedPaymentEvent:
        if headers.get("Stripe-Signature") != "valid-test-signature":
            raise WebhookVerificationError("invalid webhook signature")

        data = json.loads(payload.decode("utf-8"))

        return VerifiedPaymentEvent(
            provider="stripe",
            provider_event_id=data["id"],
            event_type=data["type"],
            order_public_id=data.get("order_public_id"),
            payment_reference=data.get("payment_reference"),
            payload=data,
        )


def create_test_client(tmp_path, *, verifier=None):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
            payment_webhook_verifier=verifier,
        )
    )

    return app.test_client()


def seed_pending_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def test_stripe_webhook_marks_order_paid_only_after_verified_event(tmp_path):
    client = create_test_client(tmp_path, verifier=FakeStripeVerifier())
    order = seed_pending_order(client)

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_test_paid",
                "type": "checkout.session.completed",
                "order_public_id": order["public_id"],
                "payment_reference": "cs_test_123",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )

    assert webhook_response.status_code == 200
    assert webhook_response.get_json()["event_status"] == "processed"
    assert webhook_response.get_json()["idempotent"] is False

    order_response = client.get(f"/commerce/admin/orders/{order['public_id']}")

    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "paid"
    assert order_response.get_json()["payment_reference"] == "cs_test_123"


def test_stripe_webhook_rejects_unverified_event_and_does_not_mark_paid(tmp_path):
    client = create_test_client(tmp_path, verifier=FakeStripeVerifier())
    order = seed_pending_order(client)

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_test_invalid",
                "type": "checkout.session.completed",
                "order_public_id": order["public_id"],
                "payment_reference": "cs_test_invalid",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "bad-signature"},
    )

    assert webhook_response.status_code == 400
    assert "invalid webhook signature" in webhook_response.get_json()["error"]

    order_response = client.get(f"/commerce/admin/orders/{order['public_id']}")

    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "pending"
    assert order_response.get_json()["payment_reference"] is None


def test_stripe_webhook_is_idempotent_for_duplicate_event(tmp_path):
    client = create_test_client(tmp_path, verifier=FakeStripeVerifier())
    order = seed_pending_order(client)

    payload = {
        "id": "evt_test_duplicate",
        "type": "checkout.session.completed",
        "order_public_id": order["public_id"],
        "payment_reference": "cs_test_duplicate",
    }

    first_response = client.post(
        "/stripe/webhook",
        data=json.dumps(payload),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )
    second_response = client.post(
        "/stripe/webhook",
        data=json.dumps(payload),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )

    assert first_response.status_code == 200
    assert first_response.get_json()["idempotent"] is False

    assert second_response.status_code == 200
    assert second_response.get_json()["idempotent"] is True


def test_stripe_webhook_without_configured_verifier_cannot_mark_paid(tmp_path):
    client = create_test_client(tmp_path, verifier=None)
    order = seed_pending_order(client)

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_no_verifier",
                "type": "checkout.session.completed",
                "order_public_id": order["public_id"],
                "payment_reference": "cs_no_verifier",
            }
        ),
        content_type="application/json",
    )

    assert webhook_response.status_code == 503

    order_response = client.get(f"/commerce/admin/orders/{order['public_id']}")

    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "pending"
