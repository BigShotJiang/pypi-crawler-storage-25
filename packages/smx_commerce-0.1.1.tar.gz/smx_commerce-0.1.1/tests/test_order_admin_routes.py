from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def seed_order(client, *, buyer_email="bob@example.com"):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": buyer_email,
            "buyer_phone": "+353000000000",
            "buyer_company": "SyntaxMatrix",
            "buyer_metadata": {"role": "attendee"},
            "order_metadata": {"source": "admin-route-test"},
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def test_order_admin_list_and_read(tmp_path):
    client = create_test_client(tmp_path)
    created_order = seed_order(client)

    list_response = client.get("/commerce/admin/orders")

    assert list_response.status_code == 200
    orders = list_response.get_json()
    assert len(orders) == 1
    assert orders[0]["public_id"] == created_order["public_id"]
    assert orders[0]["amount_cents"] == 29900
    assert orders[0]["buyer"]["email"] == "bob@example.com"

    read_response = client.get(f"/commerce/admin/orders/{created_order['public_id']}")

    assert read_response.status_code == 200
    assert read_response.get_json()["public_id"] == created_order["public_id"]


def test_order_admin_filters_by_status_and_product(tmp_path):
    client = create_test_client(tmp_path)
    created_order = seed_order(client)

    response = client.get("/commerce/admin/orders?status=pending&product_slug=example-product")

    assert response.status_code == 200
    assert [item["public_id"] for item in response.get_json()] == [created_order["public_id"]]


def test_order_admin_cancel_order(tmp_path):
    client = create_test_client(tmp_path)
    created_order = seed_order(client)

    response = client.post(f"/commerce/admin/orders/{created_order['public_id']}/cancel")

    assert response.status_code == 200
    assert response.get_json()["status"] == "cancelled"

    pending_response = client.get("/commerce/admin/orders?status=pending")

    assert pending_response.status_code == 200
    assert pending_response.get_json() == []


def test_order_admin_fail_order(tmp_path):
    client = create_test_client(tmp_path)
    created_order = seed_order(client)

    response = client.post(f"/commerce/admin/orders/{created_order['public_id']}/fail")

    assert response.status_code == 200
    assert response.get_json()["status"] == "failed"


def test_order_admin_returns_404_for_missing_order(tmp_path):
    client = create_test_client(tmp_path)

    response = client.get("/commerce/admin/orders/ord_missing")

    assert response.status_code == 404


def test_order_admin_does_not_have_mark_paid_route(tmp_path):
    client = create_test_client(tmp_path)
    created_order = seed_order(client)

    response = client.post(f"/commerce/admin/orders/{created_order['public_id']}/mark-paid")

    assert response.status_code == 404
