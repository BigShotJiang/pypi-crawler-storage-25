from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
        )
    )

    return app.test_client()


def create_product(client):
    response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert response.status_code == 201


def test_price_admin_routes_create_read_update_deactivate_archive(tmp_path):
    client = create_test_client(tmp_path)
    create_product(client)

    create_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "eur",
            "metadata": {"seats": "single"},
        },
    )

    assert create_response.status_code == 201
    created = create_response.get_json()
    assert created["code"] == "standard"
    assert created["amount_cents"] == 29900
    assert created["currency"] == "EUR"
    assert created["status"] == "active"

    list_response = client.get("/commerce/admin/products/example-product/prices")

    assert list_response.status_code == 200
    assert [item["code"] for item in list_response.get_json()] == ["standard"]

    get_response = client.get("/commerce/admin/products/example-product/prices/standard")

    assert get_response.status_code == 200
    assert get_response.get_json()["label"] == "Standard"

    update_response = client.patch(
        "/commerce/admin/products/example-product/prices/standard",
        json={
            "label": "Updated Standard",
            "amount_cents": 34900,
            "sort_order": 10,
            "metadata": {"cohort": "spring"},
        },
    )

    assert update_response.status_code == 200
    updated = update_response.get_json()
    assert updated["label"] == "Updated Standard"
    assert updated["amount_cents"] == 34900
    assert updated["sort_order"] == 10
    assert updated["metadata"]["cohort"] == "spring"

    deactivate_response = client.post(
        "/commerce/admin/products/example-product/prices/standard/deactivate"
    )

    assert deactivate_response.status_code == 200
    assert deactivate_response.get_json()["status"] == "inactive"

    archive_response = client.post(
        "/commerce/admin/products/example-product/prices/standard/archive"
    )

    assert archive_response.status_code == 200
    assert archive_response.get_json()["status"] == "archived"

    list_after_archive_response = client.get("/commerce/admin/products/example-product/prices")

    assert list_after_archive_response.status_code == 200
    assert list_after_archive_response.get_json() == []

    list_archived_response = client.get(
        "/commerce/admin/products/example-product/prices?include_archived=1"
    )

    assert list_archived_response.status_code == 200
    assert list_archived_response.get_json()[0]["status"] == "archived"


def test_price_admin_rejects_missing_product(tmp_path):
    client = create_test_client(tmp_path)

    response = client.post(
        "/commerce/admin/products/missing-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
        },
    )

    assert response.status_code == 400
    assert "product does not exist" in response.get_json()["error"]


def test_price_admin_returns_404_for_missing_price(tmp_path):
    client = create_test_client(tmp_path)
    create_product(client)

    response = client.get("/commerce/admin/products/example-product/prices/missing-price")

    assert response.status_code == 404
