from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def seed_product_and_price(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows with open-source LLM backends.",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201


def test_commerce_home_page_has_exit_navigation(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Commerce home" in html
    assert "Browse products" in html
    assert "Open admin" not in html
    assert 'href="/products"' in html
    assert 'href="/commerce/admin"' not in html


def test_products_list_page_has_navigation_without_admin_link(tmp_path):
    client = create_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Commerce home" in html
    assert 'href="/commerce"' in html
    assert "Products" in html
    assert "View product" in html
    assert "/commerce/admin" not in html


def test_product_detail_page_has_navigation_and_no_broken_arrow(tmp_path):
    client = create_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert "Commerce home" in html
    assert "Products" in html
    assert "Back to products" in html
    assert "Cancel and return to products" in html
    assert "/commerce/admin" not in html
    assert "? Products" not in html
    assert "← Products" not in html
