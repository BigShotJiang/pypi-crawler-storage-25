import pytest

from smx_commerce.catalog import (
    CatalogService,
    Category,
    Money,
    PriceStatus,
    Product,
    ProductPrice,
    ProductStatus,
)
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def test_catalog_service_manages_category_product_and_price(session):
    service = CatalogService(session)

    category = service.create_category(
        Category(slug="bootcamps", name="Bootcamps")
    )

    product = service.create_product(
        Product(
            slug="agentic-ai-bootcamp",
            name="Agentic AI Bootcamp",
            status=ProductStatus.ACTIVE,
            category_slugs=[category.slug],
        )
    )

    price = service.create_price(
        product.slug,
        ProductPrice(
            code="standard",
            label="Standard",
            amount=Money.from_major("299.00"),
        ),
    )

    loaded_product = service.get_product(product.slug)

    assert loaded_product is not None
    assert loaded_product.slug == "agentic-ai-bootcamp"
    assert loaded_product.category_slugs == ["bootcamps"]
    assert loaded_product.prices[0].code == price.code
    assert loaded_product.is_purchasable is True


def test_catalog_service_deactivates_price(session):
    service = CatalogService(session)

    service.create_product(
        Product(
            slug="example-product",
            name="Example Product",
            status=ProductStatus.ACTIVE,
        )
    )
    service.create_price(
        "example-product",
        ProductPrice(
            code="standard",
            label="Standard",
            amount=Money.from_major("299.00"),
        ),
    )

    service.deactivate_price("example-product", "standard")

    product = service.get_product("example-product")

    assert product is not None
    assert product.prices[0].status == PriceStatus.INACTIVE
    assert product.is_purchasable is False


def test_catalog_service_archives_product_softly(session):
    service = CatalogService(session)

    service.create_product(
        Product(slug="example-product", name="Example Product")
    )

    archived = service.archive_product("example-product")

    assert archived.status == ProductStatus.ARCHIVED
    assert service.list_products() == []
    assert service.list_products(include_archived=True)[0].slug == "example-product"
