import json
from collections.abc import Mapping

from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime
from smx_commerce.notifications import EmailMessage, OrderConfirmationEmailService
from smx_commerce.payments import VerifiedPaymentEvent, WebhookVerificationError


class FakeStripeVerifier:
    def verify(self, *, payload: bytes, headers: Mapping[str, str]) -> VerifiedPaymentEvent:
        if headers.get("Stripe-Signature") != "valid-test-signature":
            raise WebhookVerificationError("invalid webhook signature")

        data = json.loads(payload.decode("utf-8"))

        return VerifiedPaymentEvent(
            provider="stripe",
            provider_event_id=data["id"],
            event_type=data["type"],
            order_public_id=data.get("order_public_id"),
            payment_reference=data.get("payment_reference"),
            payload=data,
        )


class RecordingEmailSender:
    def __init__(self):
        self.messages = []

    def send(self, message: EmailMessage) -> None:
        self.messages.append(message)


class FailingEmailSender:
    def send(self, message: EmailMessage) -> None:
        raise RuntimeError("SMTP unavailable")


def create_test_client(tmp_path, *, sender):
    db_file = tmp_path / "commerce.db"
    runtime = CommerceRuntime.from_mapping(
        {"database_url": f"sqlite+pysqlite:///{db_file.as_posix()}"}
    )

    confirmation_service = OrderConfirmationEmailService(
        sender,
        from_email="sales@example.test",
        brand_name="SyntaxMatrix",
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
            payment_webhook_verifier=FakeStripeVerifier(),
            order_confirmation_service=confirmation_service,
        )
    )

    return app.test_client()


def seed_pending_order(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "example-product",
            "name": "Example Product",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/example-product/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "example-product",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
        },
    )
    assert checkout_response.status_code == 201

    return checkout_response.get_json()


def post_paid_webhook(client, order, *, event_id="evt_paid"):
    return client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": event_id,
                "type": "checkout.session.completed",
                "order_public_id": order["public_id"],
                "payment_reference": f"cs_{event_id}",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )


def test_verified_paid_webhook_sends_confirmation_email(tmp_path):
    sender = RecordingEmailSender()
    client = create_test_client(tmp_path, sender=sender)
    order = seed_pending_order(client)

    response = post_paid_webhook(client, order)

    assert response.status_code == 200
    assert response.get_json()["event_status"] == "processed"
    assert response.get_json()["notification"]["attempted"] is True
    assert response.get_json()["notification"]["sent"] is True
    assert response.get_json()["notification"]["error_message"] == ""

    assert len(sender.messages) == 1
    assert sender.messages[0].to_email == "bob@example.com"
    assert "Order ID" in sender.messages[0].body_text


def test_email_failure_does_not_fail_verified_webhook(tmp_path):
    sender = FailingEmailSender()
    client = create_test_client(tmp_path, sender=sender)
    order = seed_pending_order(client)

    response = post_paid_webhook(client, order)

    assert response.status_code == 200
    assert response.get_json()["event_status"] == "processed"
    assert response.get_json()["notification"]["attempted"] is True
    assert response.get_json()["notification"]["sent"] is False
    assert "SMTP unavailable" in response.get_json()["notification"]["error_message"]

    order_response = client.get(f"/commerce/admin/orders/{order['public_id']}")

    assert order_response.status_code == 200
    assert order_response.get_json()["status"] == "paid"


def test_duplicate_paid_webhook_does_not_resend_confirmation(tmp_path):
    sender = RecordingEmailSender()
    client = create_test_client(tmp_path, sender=sender)
    order = seed_pending_order(client)

    first_response = post_paid_webhook(client, order, event_id="evt_duplicate")
    second_response = post_paid_webhook(client, order, event_id="evt_duplicate")

    assert first_response.status_code == 200
    assert first_response.get_json()["idempotent"] is False

    assert second_response.status_code == 200
    assert second_response.get_json()["idempotent"] is True
    assert second_response.get_json()["notification"] is None

    assert len(sender.messages) == 1


def test_unverified_webhook_does_not_send_confirmation(tmp_path):
    sender = RecordingEmailSender()
    client = create_test_client(tmp_path, sender=sender)
    order = seed_pending_order(client)

    response = client.post(
        "/stripe/webhook",
        data=json.dumps(
            {
                "id": "evt_invalid",
                "type": "checkout.session.completed",
                "order_public_id": order["public_id"],
                "payment_reference": "cs_invalid",
            }
        ),
        content_type="application/json",
        headers={"Stripe-Signature": "bad-signature"},
    )

    assert response.status_code == 400
    assert sender.messages == []
