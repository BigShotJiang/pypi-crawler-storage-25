from flask import Flask

from smx_commerce import init_commerce


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"

    app = Flask(__name__)
    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "payment_provider": "local",
            "local_webhook_signature": "valid-local-signature",
            "email_provider": "memory",
        },
        init_schema=True,
    )

    return app.test_client()


def seed_product_and_price(client):
    product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "summary": "Practical agentic AI training.",
            "description": "Build and deploy agentic workflows.",
            "status": "active",
        },
    )
    assert product_response.status_code == 201

    price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price_response.status_code == 201


def test_product_detail_html_contains_package_owned_checkout_form(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.get(
        "/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200

    html = response.get_data(as_text=True)

    assert '<form method="post" action="/checkout/start">' in html
    assert 'name="product_slug" value="agentic-ai-bootcamp"' in html
    assert 'name="price_code"' in html
    assert 'name="buyer_full_name"' in html
    assert 'name="buyer_email"' in html
    assert "Continue to checkout" in html
    assert "/commerce/admin" not in html


def test_form_checkout_submission_redirects_to_provider_checkout_url(tmp_path):
    client = create_test_client(tmp_path)
    seed_product_and_price(client)

    response = client.post(
        "/checkout/start",
        data={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
            "success_url": "/checkout/success",
            "cancel_url": "/checkout/cancel",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"].startswith("https://local-payments.invalid/checkout/")
