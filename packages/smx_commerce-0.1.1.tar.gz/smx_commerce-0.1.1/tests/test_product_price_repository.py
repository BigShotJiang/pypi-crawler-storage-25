import pytest

from smx_commerce.catalog import (
    BillingMode,
    Money,
    PriceStatus,
    Product,
    ProductPrice,
    ProductPriceRepository,
    ProductRepository,
)
from smx_commerce.core.db import create_schema, make_engine, make_session_factory


@pytest.fixture()
def session():
    engine = make_engine("sqlite+pysqlite:///:memory:")
    create_schema(engine)

    SessionFactory = make_session_factory(engine)

    with SessionFactory() as session:
        yield session


def add_product(session, slug="example-product", name="Example Product"):
    ProductRepository(session).create(Product(slug=slug, name=name))


def test_price_create_and_read(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    created = repo.create(
        "example-product",
        ProductPrice(
            code="standard",
            label="Standard",
            amount=Money.from_major("299.00", "eur"),
            metadata={"seats": "single"},
        ),
    )

    loaded = repo.get_by_code("example-product", "standard")

    assert created.code == "standard"
    assert loaded is not None
    assert loaded.label == "Standard"
    assert loaded.amount.amount_cents == 29900
    assert loaded.amount.currency == "EUR"
    assert loaded.metadata["seats"] == "single"


def test_price_requires_existing_product(session):
    repo = ProductPriceRepository(session)

    with pytest.raises(ValueError, match="product does not exist"):
        repo.create(
            "missing-product",
            ProductPrice(
                code="standard",
                label="Standard",
                amount=Money.from_major("299.00"),
            ),
        )


def test_duplicate_price_code_per_product_is_rejected(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    repo.create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00")),
    )

    with pytest.raises(ValueError, match="price already exists"):
        repo.create(
            "example-product",
            ProductPrice(code="standard", label="Duplicate", amount=Money.from_major("399.00")),
        )


def test_price_update(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    repo.create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00")),
    )

    updated = repo.update(
        "example-product",
        "standard",
        label="Updated Standard",
        amount=Money.from_major("349.00", "EUR"),
        sort_order=10,
        metadata={"cohort": "spring"},
    )

    assert updated.label == "Updated Standard"
    assert updated.amount.amount_cents == 34900
    assert updated.sort_order == 10
    assert updated.metadata["cohort"] == "spring"


def test_recurring_price_can_be_created_and_updated(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    repo.create(
        "example-product",
        ProductPrice(
            code="monthly",
            label="Monthly",
            amount=Money.from_major("49.00"),
            billing_mode=BillingMode.RECURRING,
            billing_interval="month",
        ),
    )

    updated = repo.update(
        "example-product",
        "monthly",
        billing_mode=BillingMode.ONE_TIME,
        billing_interval=None,
    )

    assert updated.billing_mode == BillingMode.ONE_TIME
    assert updated.billing_interval is None


def test_recurring_update_requires_interval(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    repo.create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00")),
    )

    with pytest.raises(ValueError, match="billing_interval is required"):
        repo.update("example-product", "standard", billing_mode=BillingMode.RECURRING)


def test_deactivate_price_removes_it_from_product_active_prices(session):
    add_product(session)
    price_repo = ProductPriceRepository(session)
    product_repo = ProductRepository(session)

    price_repo.create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00")),
    )

    price_repo.deactivate("example-product", "standard")

    product = product_repo.get_by_slug("example-product")

    assert product is not None
    assert product.prices[0].status == PriceStatus.INACTIVE
    assert product.active_prices == []
    assert product.is_purchasable is False


def test_archive_price_is_soft_delete(session):
    add_product(session)
    repo = ProductPriceRepository(session)

    repo.create(
        "example-product",
        ProductPrice(code="standard", label="Standard", amount=Money.from_major("299.00")),
    )

    archived = repo.archive("example-product", "standard")

    assert archived.status == PriceStatus.ARCHIVED
    assert repo.list("example-product") == []
    assert repo.list("example-product", include_archived=True)[0].code == "standard"
