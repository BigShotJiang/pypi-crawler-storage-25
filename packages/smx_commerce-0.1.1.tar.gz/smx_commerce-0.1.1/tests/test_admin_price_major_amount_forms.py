from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def seed_product(client):
    product = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "status": "active",
        },
    )
    assert product.status_code == 201


def seed_price(client):
    price = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
    )
    assert price.status_code == 201


def test_admin_price_create_form_accepts_major_currency_amount(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        data={
            "code": "one-euro",
            "label": "One Euro",
            "amount_major": "1",
            "currency": "EUR",
            "billing_mode": "one_time",
            "billing_interval": "",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303

    price_response = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices/one-euro")
    assert price_response.status_code == 200

    price = price_response.get_json()

    assert price["amount_cents"] == 100
    assert price["currency"] == "EUR"


def test_admin_price_edit_form_accepts_major_currency_amount(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product(client)
    seed_price(client)

    response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/update",
        data={
            "label": "One Euro Updated",
            "amount_major": "1",
            "currency": "EUR",
            "billing_mode": "one_time",
            "billing_interval": "",
            "status": "active",
            "sort_order": "1",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303

    price_response = client.get("/commerce/admin/products/agentic-ai-bootcamp/prices/standard")
    assert price_response.status_code == 200

    price = price_response.get_json()

    assert price["label"] == "One Euro Updated"
    assert price["amount_cents"] == 100
    assert price["currency"] == "EUR"


def test_admin_price_forms_do_not_show_amount_cents_label(tmp_path):
    client = create_client(tmp_path)
    login(client)
    seed_product(client)
    seed_price(client)

    detail = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp",
        headers={"Accept": "text/html"},
    )
    assert detail.status_code == 200

    detail_html = detail.get_data(as_text=True)

    assert "Amount cents" not in detail_html
    assert 'name="amount_major"' in detail_html

    edit = client.get(
        "/commerce/admin/products/agentic-ai-bootcamp/prices/standard/edit",
        headers={"Accept": "text/html"},
    )
    assert edit.status_code == 200

    edit_html = edit.get_data(as_text=True)

    assert "Amount cents" not in edit_html
    assert 'name="amount_major"' in edit_html
    assert 'value="299"' in edit_html
