from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def login(client):
    response = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert response.status_code == 200


def test_admin_categories_page_contains_create_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.get(
        "/commerce/admin/categories",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    assert response.mimetype == "text/html"

    html = response.get_data(as_text=True)

    assert "Create category" in html
    assert 'method="post" action="/commerce/admin/categories"' in html
    assert 'name="slug"' in html
    assert 'name="name"' in html
    assert 'name="status"' in html
    assert 'name="description"' in html


def test_admin_can_create_category_from_browser_form(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.post(
        "/commerce/admin/categories",
        data={
            "slug": "bootcamps",
            "name": "Bootcamps",
            "status": "active",
            "description": "Training products.",
            "sort_order": "10",
        },
        content_type="application/x-www-form-urlencoded",
        follow_redirects=False,
    )

    assert response.status_code == 303
    assert response.headers["Location"] == "/commerce/admin/categories"

    page = client.get(
        "/commerce/admin/categories",
        headers={"Accept": "text/html"},
    )
    assert page.status_code == 200

    html = page.get_data(as_text=True)

    assert "Bootcamps" in html
    assert "bootcamps" in html
    assert "active" in html

    json_response = client.get("/commerce/admin/categories?format=json")
    assert json_response.status_code == 200
    assert json_response.get_json()[0]["slug"] == "bootcamps"


def test_admin_category_form_error_renders_html(tmp_path):
    client = create_client(tmp_path)
    login(client)

    response = client.post(
        "/commerce/admin/categories",
        data={
            "slug": "Invalid Slug",
            "name": "Bad Category",
            "status": "active",
        },
        content_type="application/x-www-form-urlencoded",
    )

    assert response.status_code == 400

    html = response.get_data(as_text=True)

    assert "Create category" in html
    assert "slug must use lowercase letters" in html
