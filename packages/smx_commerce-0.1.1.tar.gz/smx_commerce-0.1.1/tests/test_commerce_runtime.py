import pytest

from smx_commerce.catalog import CatalogService, Money, Product, ProductPrice, ProductStatus
from smx_commerce.core import CommerceRuntime


def test_runtime_creates_schema_and_commits_session(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )
    runtime.init_schema()

    with runtime.session_scope() as session:
        catalog = CatalogService(session)
        catalog.create_product(
            Product(
                slug="example-product",
                name="Example Product",
                status=ProductStatus.ACTIVE,
            )
        )
        catalog.create_price(
            "example-product",
            ProductPrice(
                code="standard",
                label="Standard",
                amount=Money.from_major("299.00"),
            ),
        )

    with runtime.session_scope() as session:
        catalog = CatalogService(session)
        product = catalog.get_product("example-product")

    assert product is not None
    assert product.slug == "example-product"
    assert product.is_purchasable is True


def test_runtime_rolls_back_on_error(tmp_path):
    db_file = tmp_path / "commerce.db"

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
        }
    )
    runtime.init_schema()

    with pytest.raises(RuntimeError):
        with runtime.session_scope() as session:
            catalog = CatalogService(session)
            catalog.create_product(
                Product(
                    slug="rollback-product",
                    name="Rollback Product",
                    status=ProductStatus.ACTIVE,
                )
            )
            raise RuntimeError("force rollback")

    with runtime.session_scope() as session:
        catalog = CatalogService(session)
        product = catalog.get_product("rollback-product")

    assert product is None
