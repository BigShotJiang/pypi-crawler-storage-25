from flask import Flask

from smx_commerce import init_commerce


def create_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    app = Flask(__name__)

    init_commerce(
        app,
        config={
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": "secret-admin-key",
            "flask_secret_key": "test-flask-secret",
            "payment_provider": "none",
            "email_provider": "none",
        },
        init_schema=True,
    )

    return app.test_client()


def test_admin_home_requires_login(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin",
        headers={"Accept": "text/html"},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert "/commerce/admin/login" in response.headers["Location"]


def test_admin_home_renders_dashboard_after_session_login(tmp_path):
    client = create_client(tmp_path)

    login = client.post(
        "/commerce/admin/login",
        json={"admin_api_key": "secret-admin-key"},
    )
    assert login.status_code == 200

    response = client.get(
        "/commerce/admin",
        headers={"Accept": "text/html"},
    )

    assert response.status_code == 200
    html = response.get_data(as_text=True)

    assert "Admin Dashboard" in html
    assert "Branding assets" in html
    assert 'href="/commerce/admin/products"' in html


def test_admin_home_accepts_header_key_and_renders_dashboard(tmp_path):
    client = create_client(tmp_path)

    response = client.get(
        "/commerce/admin",
        headers={
            "Accept": "text/html",
            "X-SMX-Commerce-Admin-Key": "secret-admin-key",
        },
    )

    assert response.status_code == 200
    assert "Admin Dashboard" in response.get_data(as_text=True)
