import json
from collections.abc import Mapping

from flask import Flask

from smx_commerce import create_commerce_blueprint
from smx_commerce.core import CommerceRuntime
from smx_commerce.notifications import EmailMessage, OrderConfirmationEmailService
from smx_commerce.payments import (
    PaymentCheckoutSession,
    VerifiedPaymentEvent,
    WebhookVerificationError,
)


ADMIN_KEY = "test-admin-key"


class FakeCheckoutProvider:
    def create_checkout_session(self, *, order, success_url, cancel_url):
        return PaymentCheckoutSession(
            provider="fake",
            session_id=f"fake_{order.public_id}",
            checkout_url=f"https://payments.example.test/checkout/{order.public_id}",
            metadata={
                "order_public_id": order.public_id,
                "success_url": success_url,
                "cancel_url": cancel_url,
            },
        )


class FakeStripeVerifier:
    def verify(self, *, payload: bytes, headers: Mapping[str, str]) -> VerifiedPaymentEvent:
        if headers.get("Stripe-Signature") != "valid-test-signature":
            raise WebhookVerificationError("invalid webhook signature")

        data = json.loads(payload.decode("utf-8"))

        return VerifiedPaymentEvent(
            provider="stripe",
            provider_event_id=data["id"],
            event_type=data["type"],
            order_public_id=data.get("order_public_id"),
            payment_reference=data.get("payment_reference"),
            payload=data,
        )


class RecordingEmailSender:
    def __init__(self):
        self.messages = []

    def send(self, message: EmailMessage) -> None:
        self.messages.append(message)


def create_test_client(tmp_path):
    db_file = tmp_path / "commerce.db"
    sender = RecordingEmailSender()

    runtime = CommerceRuntime.from_mapping(
        {
            "database_url": f"sqlite+pysqlite:///{db_file.as_posix()}",
            "admin_api_key": ADMIN_KEY,
        }
    )

    app = Flask(__name__)
    app.register_blueprint(
        create_commerce_blueprint(
            runtime=runtime,
            init_schema=True,
            payment_checkout_provider=FakeCheckoutProvider(),
            payment_webhook_verifier=FakeStripeVerifier(),
            order_confirmation_service=OrderConfirmationEmailService(
                sender,
                from_email="sales@example.test",
                brand_name="SyntaxMatrix",
            ),
        )
    )

    return app.test_client(), sender


def admin_headers():
    return {"X-SMX-Commerce-Admin-Key": ADMIN_KEY}


def test_full_package_workflow_without_client_project_or_live_providers(tmp_path):
    client, sender = create_test_client(tmp_path)

    unauthorized_admin_response = client.get("/commerce/admin/products")
    assert unauthorized_admin_response.status_code == 401

    create_product_response = client.post(
        "/commerce/admin/products",
        json={
            "slug": "agentic-ai-bootcamp",
            "name": "Agentic AI Bootcamp",
            "kind": "event",
            "summary": "Practical agentic AI training",
            "description": "Build and deploy agentic workflows.",
            "status": "active",
        },
        headers=admin_headers(),
    )

    assert create_product_response.status_code == 201

    create_price_response = client.post(
        "/commerce/admin/products/agentic-ai-bootcamp/prices",
        json={
            "code": "standard",
            "label": "Standard",
            "amount_cents": 29900,
            "currency": "EUR",
            "status": "active",
        },
        headers=admin_headers(),
    )

    assert create_price_response.status_code == 201

    public_product_response = client.get("/products/agentic-ai-bootcamp")

    assert public_product_response.status_code == 200
    assert public_product_response.get_json()["is_purchasable"] is True
    assert public_product_response.get_json()["prices"][0]["amount_cents"] == 29900

    checkout_response = client.post(
        "/checkout/start",
        json={
            "product_slug": "agentic-ai-bootcamp",
            "price_code": "standard",
            "buyer_full_name": "Bob Nti",
            "buyer_email": "bob@example.com",
            "success_url": "https://syntaxmatrix.com/checkout/success",
            "cancel_url": "https://syntaxmatrix.com/checkout/cancel",
        },
    )

    assert checkout_response.status_code == 201

    checkout_data = checkout_response.get_json()
    order_id = checkout_data["public_id"]

    assert checkout_data["status"] == "pending"
    assert checkout_data["checkout_session"]["provider"] == "fake"
    assert checkout_data["checkout_session"]["checkout_url"].endswith(order_id)

    success_response = client.get(f"/checkout/success?order_id={order_id}")

    assert success_response.status_code == 200
    assert success_response.get_json()["order"]["status"] == "pending"
    assert sender.messages == []

    webhook_payload = {
        "id": "evt_package_contract_paid",
        "type": "checkout.session.completed",
        "order_public_id": order_id,
        "payment_reference": "cs_package_contract_paid",
    }

    webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(webhook_payload),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )

    assert webhook_response.status_code == 200
    assert webhook_response.get_json()["event_status"] == "processed"
    assert webhook_response.get_json()["idempotent"] is False
    assert webhook_response.get_json()["notification"]["sent"] is True

    paid_order_response = client.get(
        f"/commerce/admin/orders/{order_id}",
        headers=admin_headers(),
    )

    assert paid_order_response.status_code == 200
    assert paid_order_response.get_json()["status"] == "paid"
    assert paid_order_response.get_json()["amount_cents"] == 29900
    assert paid_order_response.get_json()["payment_reference"] == "cs_package_contract_paid"

    assert len(sender.messages) == 1
    assert sender.messages[0].to_email == "bob@example.com"
    assert "Order ID" in sender.messages[0].body_text

    duplicate_webhook_response = client.post(
        "/stripe/webhook",
        data=json.dumps(webhook_payload),
        content_type="application/json",
        headers={"Stripe-Signature": "valid-test-signature"},
    )

    assert duplicate_webhook_response.status_code == 200
    assert duplicate_webhook_response.get_json()["idempotent"] is True
    assert duplicate_webhook_response.get_json()["notification"] is None
    assert len(sender.messages) == 1
