"""DeepDebug — iterative, multi-turn agentic error analysis.

A single :class:`LLMJudgeAnalyzer` pass is the *quick scan*. DeepDebug is the
*deep dive*: a small agent that plans → hypothesizes → verifies → refines →
reports, in the style of recent deep-research and agent-as-judge work.

Round structure (default ``max_rounds=3``)::

    R0 plan       : LLM proposes investigation focus
                    (which events / windows to examine first)
    R1 hypothesize: LLM produces candidate findings (mode + step + evidence)
    R2 verify     : per-hypothesis verifier checks evidence quality and
                    rates support (corroborated / weak / contradicted)
    R3 refine     : LLM merges, drops weak hypotheses, builds a causal chain
    Rfinal report : structured DiagnosticReport + DeepDebugTrace audit trail

The implementation is intentionally framework-agnostic: it consumes any
:class:`~agentdebug.llm.LLMClient`. Every round is recorded as a typed
:class:`DeepDebugRound` so users can audit *how* the diagnosis was reached.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from typing import cast

from agentdebug.llm import LLMClient, extract_json_block
from agentdebug.models import (
    AgentEvent,
    AgentTrajectory,
    DiagnosticReport,
    EventType,
    FailureFinding,
    FailureMode,
    new_id,
)
from agentdebug.taxonomy import SEED_FAILURE_MODES

LOG = logging.getLogger('agentdebug.deep')


# ---------------------------- prompts ---------------------------- #

_PLAN_PROMPT = """You are AgentDebugX-DeepDebug, planning the next move in a
deep, multi-turn error analysis of a failed agent trajectory.

You will be given the goal, framework, and a compact list of trajectory
events. Return ONLY a JSON object:

{
  "summary": "<one-line situational summary>",
  "focus_event_ids": ["<event_id>", ...],   // events to look at most carefully
  "open_questions": ["<question>", ...]      // 1-5 sharp questions to resolve
}

Be selective — prefer 3-7 focus events over scanning everything.
"""


_HYPOTHESIZE_PROMPT = """You are AgentDebugX-DeepDebug producing candidate
failure hypotheses for the focus events identified in the plan.

You will be given the goal, framework, the prior plan, and the focus event
details. Produce a JSON object:

{
  "hypotheses": [
    {
      "id": "h1",
      "event_id": "<event_id>",
      "step_index": <int or null>,
      "agent_name": "<agent_name>",
      "failure_mode_id": "<one of the allowed codes>",
      "rationale": "<one or two sentences>",
      "evidence": ["<short quoted snippet>", ...],
      "confidence_prior": <float in [0,1]>
    }
  ]
}

ALLOWED failure mode codes follow. Use only these:
"""


_VERIFY_PROMPT = """You are AgentDebugX-DeepDebug verifying a single
hypothesis. You will be given the goal, framework, the full trajectory
events, and ONE hypothesis. Decide whether the evidence in the trajectory
supports the hypothesis. Return ONLY:

{
  "verdict": "corroborated" | "weak" | "contradicted",
  "rationale": "<one to three sentences>",
  "extra_evidence": ["<short quoted snippet>", ...],
  "confidence_posterior": <float in [0,1]>,
  "cascading_from_event_id": "<event_id or null>"
}

Mark as 'contradicted' only if the trajectory explicitly conflicts with the
hypothesis. Mark as 'weak' if the trajectory is ambiguous. Otherwise
'corroborated'.
"""


_REFINE_PROMPT = """You are AgentDebugX-DeepDebug producing the final
DiagnosticReport from the verified hypothesis set.

You will be given the goal, framework, the trajectory events, and the
verified hypotheses with their verdicts. Drop or merge weak/contradicted
ones. Pick the SINGLE root cause (earliest non-redundant failure that the
other findings cascade from). Return:

{
  "summary": "<one or two sentence diagnosis>",
  "root_cause": {
    "event_id": "<event_id or null>",
    "step_index": <int or null>,
    "agent_name": "<agent_name or null>"
  },
  "findings": [
    {
      "event_id": "<event_id>",
      "step_index": <int or null>,
      "agent_name": "<agent_name>",
      "failure_mode_id": "<allowed code>",
      "confidence": <float in [0,1]>,
      "evidence": ["<short quoted snippet>", ...]
    }
  ]
}
"""


# ---------------------------- types ---------------------------- #

@dataclass
class Hypothesis:
    id: str
    event_id: Optional[str]
    step_index: Optional[int]
    agent_name: Optional[str]
    failure_mode_id: str
    rationale: str
    evidence: List[str]
    confidence_prior: float
    verdict: Optional[str] = None        # corroborated|weak|contradicted
    confidence_posterior: Optional[float] = None
    extra_evidence: List[str] = field(default_factory=list)
    cascading_from_event_id: Optional[str] = None


@dataclass
class DeepDebugRound:
    """One round of the deep-debug loop, recorded for audit."""

    name: str                           # plan|hypothesize|verify|refine
    request_summary: str
    response_summary: str
    duration_ms: int
    payload: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DeepDebugResult:
    report: DiagnosticReport
    rounds: List[DeepDebugRound]
    hypotheses: List[Hypothesis]


# ---------------------------- analyzer ---------------------------- #

class DeepDebugAnalyzer:
    """Iterative, multi-turn debugger.

    Compared to :class:`agentdebug.judges.LLMJudgeAnalyzer`:

    * Runs N rounds (default 3) instead of one shot.
    * Separates *hypothesize* from *verify* so weak findings are filtered.
    * Returns the audit trail so users can replay the reasoning.
    * Costs more — typically 1 plan + 1 hypothesize + K verify + 1 refine.

    The analyzer never re-executes the agent — verification reads the
    *existing* trajectory more carefully, it does not roll new actions.
    """

    def __init__(
        self,
        llm: LLMClient,
        *,
        max_focus_events: int = 7,
        max_hypotheses_to_verify: int = 6,
        max_tokens: int = 4096,
    ) -> None:
        self.llm = llm
        self.max_focus_events = max_focus_events
        self.max_hypotheses_to_verify = max_hypotheses_to_verify
        self.max_tokens = max_tokens

    def analyze(self, trajectory: AgentTrajectory) -> DeepDebugResult:
        rounds: List[DeepDebugRound] = []
        # Per-event-id lookup of the most recent verified cascade predecessor;
        # populated by _verify and consumed in _compose_report so the cascade
        # info survives the verify -> refine handoff even when the refine LLM
        # doesn't echo it back verbatim.
        self._cascade_lookup: Dict[str, str] = {}

        plan = self._plan(trajectory, rounds)
        raw_focus = plan.get('focus_event_ids') or []
        focus_ids: List[Any] = raw_focus if isinstance(raw_focus, list) else []
        focus_events = self._select_focus(
            trajectory, [str(e) for e in focus_ids]
        )

        hypotheses = self._hypothesize(trajectory, plan, focus_events, rounds)
        hypotheses = hypotheses[: self.max_hypotheses_to_verify]
        for h in hypotheses:
            self._verify(trajectory, h, rounds)

        verified = [
            h for h in hypotheses if h.verdict != 'contradicted'
        ]
        verified.sort(
            key=lambda x: (
                0 if x.verdict == 'corroborated' else 1,
                -(x.confidence_posterior or x.confidence_prior or 0.0),
            )
        )

        report = self._refine(trajectory, verified, rounds)
        return DeepDebugResult(report=report, rounds=rounds, hypotheses=hypotheses)

    # ---- rounds ----

    def _plan(
        self, trajectory: AgentTrajectory, rounds: List[DeepDebugRound]
    ) -> Dict[str, Any]:
        prompt = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'EVENTS:\n{self._render_events(trajectory.events, brief=True)}'
        )
        parsed = self._call('plan', _PLAN_PROMPT, prompt, rounds)
        return parsed or {}

    def _hypothesize(
        self,
        trajectory: AgentTrajectory,
        plan: Dict[str, Any],
        focus_events: List[AgentEvent],
        rounds: List[DeepDebugRound],
    ) -> List[Hypothesis]:
        modes_doc = '\n'.join(
            f'- {mid}: {m.description}' for mid, m in SEED_FAILURE_MODES.items()
        )
        prompt = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'PLAN: {plan}\n\n'
            f'FOCUS EVENTS:\n{self._render_events(focus_events, brief=False)}'
        )
        system = _HYPOTHESIZE_PROMPT + modes_doc
        parsed = self._call('hypothesize', system, prompt, rounds)
        out: List[Hypothesis] = []
        for raw in (parsed or {}).get('hypotheses', []) or []:
            if not isinstance(raw, dict):
                continue
            mid = str(raw.get('failure_mode_id') or '')
            if mid not in SEED_FAILURE_MODES:
                continue
            out.append(Hypothesis(
                id=str(raw.get('id') or new_id('h')),
                event_id=self._opt_str(raw.get('event_id')),
                step_index=self._opt_int(raw.get('step_index')),
                agent_name=self._opt_str(raw.get('agent_name')),
                failure_mode_id=mid,
                rationale=str(raw.get('rationale') or ''),
                evidence=self._str_list(raw.get('evidence')),
                confidence_prior=self._opt_float(raw.get('confidence_prior'), 0.5),
            ))
        return out

    def _verify(
        self,
        trajectory: AgentTrajectory,
        hypothesis: Hypothesis,
        rounds: List[DeepDebugRound],
    ) -> None:
        hypothesis_payload = {
            'id': hypothesis.id,
            'event_id': hypothesis.event_id,
            'step_index': hypothesis.step_index,
            'agent_name': hypothesis.agent_name,
            'failure_mode_id': hypothesis.failure_mode_id,
            'rationale': hypothesis.rationale,
            'evidence': hypothesis.evidence,
            'confidence_prior': hypothesis.confidence_prior,
        }
        prompt = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'HYPOTHESIS:\n{hypothesis_payload}\n\n'
            f'EVENTS:\n{self._render_events(trajectory.events, brief=False)}'
        )
        parsed = self._call(
            f'verify:{hypothesis.id}', _VERIFY_PROMPT, prompt, rounds
        ) or {}
        hypothesis.verdict = str(parsed.get('verdict') or 'weak')
        hypothesis.confidence_posterior = self._opt_float(
            parsed.get('confidence_posterior'), hypothesis.confidence_prior
        )
        hypothesis.extra_evidence = self._str_list(parsed.get('extra_evidence'))
        hypothesis.cascading_from_event_id = self._opt_str(
            parsed.get('cascading_from_event_id')
        )
        if hypothesis.event_id and hypothesis.cascading_from_event_id:
            self._cascade_lookup[hypothesis.event_id] = (
                hypothesis.cascading_from_event_id
            )

    def _refine(
        self,
        trajectory: AgentTrajectory,
        verified: List[Hypothesis],
        rounds: List[DeepDebugRound],
    ) -> DiagnosticReport:
        if not verified:
            return self._empty_report(trajectory)
        verified_payload = [
            {
                'id': h.id,
                'event_id': h.event_id,
                'step_index': h.step_index,
                'agent_name': h.agent_name,
                'failure_mode_id': h.failure_mode_id,
                'rationale': h.rationale,
                'evidence': h.evidence + h.extra_evidence,
                'confidence': h.confidence_posterior or h.confidence_prior,
                'verdict': h.verdict,
                'cascading_from_event_id': h.cascading_from_event_id,
            }
            for h in verified
        ]
        prompt = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'VERIFIED HYPOTHESES:\n{verified_payload}\n\n'
            f'EVENTS:\n{self._render_events(trajectory.events, brief=True)}'
        )
        parsed = self._call('refine', _REFINE_PROMPT, prompt, rounds) or {}
        return self._compose_report(trajectory, parsed)

    # ---- helpers ----

    def _call(
        self,
        name: str,
        system: str,
        user: str,
        rounds: List[DeepDebugRound],
    ) -> Optional[Dict[str, Any]]:
        import time

        started = time.perf_counter()
        messages = [
            {'role': 'system', 'content': system},
            {'role': 'user', 'content': user},
        ]
        try:
            result = self.llm.complete(messages=messages, max_tokens=self.max_tokens)
        except Exception as exc:  # pragma: no cover
            LOG.warning('deep round %s LLM call failed: %s', name, exc)
            rounds.append(DeepDebugRound(
                name=name,
                request_summary=user[:200],
                response_summary=f'<error: {exc}>',
                duration_ms=int((time.perf_counter() - started) * 1000),
            ))
            return None
        parsed = extract_json_block(result.text)
        rounds.append(DeepDebugRound(
            name=name,
            request_summary=user[:200],
            response_summary=(result.text or '')[:400],
            duration_ms=int((time.perf_counter() - started) * 1000),
            payload=parsed or {},
        ))
        if parsed is None:
            return None
        return cast(Dict[str, Any], parsed)

    def _render_events(
        self, events: List[AgentEvent], *, brief: bool
    ) -> str:
        rows: List[str] = []
        for e in events:
            base = (
                f'event_id={e.event_id} step={e.step_index} '
                f'agent={e.agent_name} type={self._etype(e.event_type)} '
                f'module={e.module}'
            )
            if brief:
                rows.append(base)
            else:
                rows.append(
                    base
                    + f' input={str(e.input)[:200]} output={str(e.output)[:200]} '
                    + f'error={str(e.error)[:200]} meta={str(e.metadata)[:120]}'
                )
        return '\n'.join(rows)

    def _select_focus(
        self, trajectory: AgentTrajectory, focus_event_ids: List[str]
    ) -> List[AgentEvent]:
        ids = set(focus_event_ids)
        if ids:
            picked = [e for e in trajectory.events if e.event_id in ids]
            if picked:
                return picked[: self.max_focus_events]
        # Fallback: events with errors, otherwise last N.
        with_err = [e for e in trajectory.events if e.error]
        if with_err:
            return with_err[: self.max_focus_events]
        tail: List[AgentEvent] = list(trajectory.events[-self.max_focus_events:])
        return tail

    def _compose_report(
        self, trajectory: AgentTrajectory, parsed: Dict[str, Any]
    ) -> DiagnosticReport:
        findings: List[FailureFinding] = []
        for raw in parsed.get('findings', []) or []:
            if not isinstance(raw, dict):
                continue
            mid = str(raw.get('failure_mode_id') or '')
            mode = SEED_FAILURE_MODES.get(mid)
            if mode is None:
                continue
            event_id = self._opt_str(raw.get('event_id'))
            # Carry the cascade predecessor we extracted in verify so the
            # AgentTraceback renderer can chain findings.
            cascade_from: Optional[str] = None
            if event_id is not None:
                cascade_from = self._cascade_lookup.get(event_id)
            cascade_from_raw = self._opt_str(raw.get('cascading_from_event_id'))
            if cascade_from_raw:
                cascade_from = cascade_from_raw
            finding_metadata: Dict[str, Any] = {'source': 'deep_debug'}
            if cascade_from:
                finding_metadata['cascading_from_event_id'] = cascade_from
            findings.append(FailureFinding(
                finding_id=new_id('finding'),
                failure_mode=mode,
                event_id=event_id,
                agent_name=self._opt_str(raw.get('agent_name')),
                step_index=self._opt_int(raw.get('step_index')),
                confidence=self._opt_float(raw.get('confidence'), 0.5),
                evidence=self._str_list(raw.get('evidence')),
                suggestion=self._suggestion(mode),
                metadata=finding_metadata,
            ))
        root = parsed.get('root_cause') or {}
        report = DiagnosticReport(
            trace_id=trajectory.trace_id,
            task_id=trajectory.task_id,
            findings=findings,
            suggestions=self._dedupe(
                f.suggestion for f in findings if f.suggestion is not None
            ),
            metadata={
                'analyzer': self.__class__.__name__,
                'model': self.llm.model,
            },
        )
        report.summary = (
            str(parsed.get('summary'))
            if parsed.get('summary')
            else 'No failure detected by DeepDebug.'
        )
        report.root_cause_event_id = self._opt_str(root.get('event_id'))
        report.root_cause_agent = self._opt_str(root.get('agent_name'))
        report.root_cause_step_index = self._opt_int(root.get('step_index'))
        return report

    def _empty_report(self, trajectory: AgentTrajectory) -> DiagnosticReport:
        return DiagnosticReport(
            trace_id=trajectory.trace_id,
            task_id=trajectory.task_id,
            findings=[],
            suggestions=[],
            summary='No corroborated findings after deep analysis.',
            metadata={
                'analyzer': self.__class__.__name__,
                'model': self.llm.model,
            },
        )

    def _suggestion(self, mode: FailureMode) -> Optional[str]:
        if mode.suggestion_templates:
            return str(mode.suggestion_templates[0])
        return None

    @staticmethod
    def _etype(t: EventType) -> str:
        v = getattr(t, 'value', t)
        return v if isinstance(v, str) else str(v)

    @staticmethod
    def _opt_str(value: Any) -> Optional[str]:
        if value is None:
            return None
        return str(value)

    @staticmethod
    def _opt_int(value: Any) -> Optional[int]:
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _opt_float(value: Any, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _str_list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value]
        return [str(value)]

    @staticmethod
    def _dedupe(values: Any) -> List[str]:
        seen: List[str] = []
        items = list(values)
        for v in items:
            sv = str(v)
            if sv not in seen:
                seen.append(sv)
        return seen


__all__ = [
    'DeepDebugAnalyzer',
    'DeepDebugResult',
    'DeepDebugRound',
    'Hypothesis',
]
