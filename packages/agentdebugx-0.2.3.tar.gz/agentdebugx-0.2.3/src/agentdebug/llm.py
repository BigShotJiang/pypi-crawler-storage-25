"""Thin LLM client abstraction.

AgentDebugX needs an LLM for the judge analyzer and for the All-at-Once
attributor. We use an OpenAI-compatible chat-completions interface so users can
point us at OpenAI, Anthropic via LiteLLM, the Gemini endpoint they hand us, or
a local vLLM/Ollama deployment.

The implementation deliberately avoids depending on the ``openai`` Python SDK:
a single ``httpx`` POST keeps the install lightweight and lets users target any
``/v1/chat/completions``-compatible URL.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol

import httpx

LOG = logging.getLogger('agentdebug.llm')


@dataclass
class CompletionResult:
    text: str
    raw: Dict[str, Any]


class LLMClient(Protocol):
    model: str

    def complete(
        self,
        messages: List[Dict[str, Any]],
        *,
        response_format: Optional[Dict[str, Any]] = None,
        temperature: float = 0.0,
        max_tokens: int = 2048,
        timeout: float = 60.0,
    ) -> CompletionResult:
        ...


class OpenAICompatClient:
    """OpenAI-compatible chat completions client.

    Works against:

    * OpenAI (``base_url='https://api.openai.com/v1'``)
    * LiteLLM proxy (any ``/v1`` URL)
    * The Gemini gateway used in this repo:
      ``https://compliant-wagner-simulations-coaches.trycloudflare.com/v1``
      with ``model='gemini-3-flash'``
    * vLLM / Ollama with their OpenAI-compat servers
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        default_max_tokens: int = 2048,
        timeout: float = 60.0,
    ) -> None:
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.model = model
        self.default_max_tokens = default_max_tokens
        self.timeout = timeout

    @classmethod
    def from_env(
        cls,
        *,
        env_prefix: str = 'AGENTDEBUG_LLM',
        model: Optional[str] = None,
    ) -> 'OpenAICompatClient':
        """Construct from environment variables.

        Reads ``<PREFIX>_BASE_URL``, ``<PREFIX>_API_KEY``, ``<PREFIX>_MODEL``.
        """
        base_url = os.environ[f'{env_prefix}_BASE_URL']
        api_key = os.environ[f'{env_prefix}_API_KEY']
        model_id: str = (
            model if model is not None
            else os.environ.get(f'{env_prefix}_MODEL', 'gpt-4o-mini')
        )
        return cls(base_url=base_url, api_key=api_key, model=model_id)

    def complete(
        self,
        messages: List[Dict[str, Any]],
        *,
        response_format: Optional[Dict[str, Any]] = None,
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> CompletionResult:
        body: Dict[str, Any] = {
            'model': self.model,
            'messages': messages,
            'temperature': temperature,
            'max_tokens': max_tokens or self.default_max_tokens,
        }
        if response_format is not None:
            body['response_format'] = response_format
        url = f'{self.base_url}/chat/completions'
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
        }
        resp = httpx.post(
            url, headers=headers, json=body, timeout=timeout or self.timeout
        )
        resp.raise_for_status()
        data: Dict[str, Any] = resp.json()
        choice = (data.get('choices') or [{}])[0]
        message = choice.get('message') or {}
        text = message.get('content') or ''
        if not text:
            LOG.warning(
                'empty content from %s (model=%s, finish_reason=%s, usage=%s)',
                url,
                self.model,
                choice.get('finish_reason'),
                data.get('usage'),
            )
        return CompletionResult(text=text, raw=data)


def extract_json_block(text: str) -> Optional[Dict[str, Any]]:
    """Extract the first top-level JSON object from a possibly-fenced response."""
    if not text:
        return None
    # Strip code fences if present.
    cleaned = text.strip()
    if cleaned.startswith('```'):
        # remove ``` or ```json prefix and trailing ```
        cleaned = cleaned.split('\n', 1)[1] if '\n' in cleaned else cleaned[3:]
        if cleaned.endswith('```'):
            cleaned = cleaned[: -len('```')]
        cleaned = cleaned.strip()
    # Try strict first.
    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass
    # Fallback: greedy slice between the first { and the last }.
    start = cleaned.find('{')
    end = cleaned.rfind('}')
    if start == -1 or end == -1 or end <= start:
        return None
    try:
        parsed = json.loads(cleaned[start : end + 1])
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        return None
    return None
