"""Optional dashboard for AgentDebugX.

Run with::

    pip install agentdebugx[ui]
    agentdebug serve --store-sqlite .agentdebug/errors.sqlite

The server is a single-file FastAPI app + a no-build HTML/JS frontend served
from ``GET /``. Everything is local-only (loopback) by default.
"""

from agentdebug.ui.server import build_app, serve

__all__ = ['build_app', 'serve']
