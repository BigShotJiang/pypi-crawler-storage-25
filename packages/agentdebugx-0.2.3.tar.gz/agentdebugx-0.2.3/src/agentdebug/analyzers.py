"""Trajectory analyzers."""

from __future__ import annotations

from typing import Iterable, List, Optional, Tuple

from agentdebug.models import (
    AgentEvent,
    AgentTrajectory,
    DiagnosticReport,
    EventType,
    FailureFinding,
    FailureMode,
)
from agentdebug.taxonomy import SEED_FAILURE_MODES


class HeuristicAnalyzer:
    """A deterministic baseline analyzer.

    This is intentionally simple: it gives projects an immediate local signal
    while future LLM judges, constraint synthesis, and learned attribution
    models share the same output schema.
    """

    def analyze(self, trajectory: AgentTrajectory) -> DiagnosticReport:
        findings = [finding for event in trajectory.events for finding in self._event_findings(event)]
        root = self._select_root_cause(findings)
        suggestions = self._dedupe(
            finding.suggestion for finding in findings if finding.suggestion is not None
        )

        report = DiagnosticReport(
            trace_id=trajectory.trace_id,
            task_id=trajectory.task_id,
            findings=findings,
            suggestions=suggestions,
            metadata={'analyzer': self.__class__.__name__},
        )
        if root is not None:
            report.root_cause_event_id = root.event_id
            report.root_cause_agent = root.agent_name
            report.root_cause_step_index = root.step_index
            report.summary = (
                f'Likely root cause: {root.failure_mode.name}'
                f' in {root.agent_name or "unknown agent"}'
                f' at step {root.step_index}.'
            )
        return report

    def _event_findings(self, event: AgentEvent) -> List[FailureFinding]:
        text = self._event_text(event)
        matched = self._match_failure_mode(event, text)
        if matched is None:
            return []

        failure_mode, confidence, evidence = matched
        return [
            FailureFinding(
                failure_mode=failure_mode,
                event_id=event.event_id,
                agent_name=event.agent_name,
                step_index=event.step_index,
                confidence=confidence,
                evidence=evidence,
                suggestion=self._suggestion(failure_mode),
                metadata={'event_type': self._event_type_value(event.event_type)},
            )
        ]

    def _match_failure_mode(
        self, event: AgentEvent, text: str
    ) -> Optional[Tuple[FailureMode, float, List[str]]]:
        lowered = text.lower()
        if event.error:
            if event.event_type in {EventType.TOOL_CALL, EventType.TOOL_RESULT}:
                return self._result('system.tool_execution_error', 0.86, [event.error])
            return self._result('system.environment_error', 0.72, [event.error])

        if self._contains(lowered, ['context length', 'rate limit', 'token limit']):
            return self._result('system.llm_limit', 0.82, ['limit signal in event payload'])
        if self._contains(lowered, ['json', 'schema', 'malformed', 'parse error']):
            return self._result('action.format_error', 0.78, ['format/schema signal in event payload'])
        if self._contains(lowered, ['missing parameter', 'invalid parameter', 'argument']):
            return self._result('action.parameter_error', 0.76, ['parameter signal in event payload'])
        if self._contains(lowered, ['unknown tool', 'wrong tool', 'tool mismatch']):
            return self._result('action.wrong_tool', 0.8, ['tool-selection signal in event payload'])
        if self._contains(lowered, ['loop', 'repeated', 'no progress', 'max steps']):
            return self._result('planning.inefficient_plan', 0.67, ['loop/progress signal in event payload'])
        if self._contains(lowered, ['policy violation', 'constraint ignored', 'must not']):
            return self._result('planning.constraint_ignorance', 0.74, ['constraint signal in event payload'])
        if self._contains(lowered, ['premature', 'early termination', 'not complete']):
            return self._result('verification.premature_stop', 0.71, ['termination signal in event payload'])
        if self._contains(lowered, ['handoff', 'lost context', 'missing context']):
            return self._result('multiagent.handoff_loss', 0.7, ['handoff/context signal in event payload'])
        if self._contains(lowered, ['screenshot', 'ocr', 'visual', 'ui element']):
            return self._result('multimodal.perception_error', 0.62, ['multimodal perception signal in event payload'])

        status = str(event.metadata.get('status', '')).lower()
        if status in {'failed', 'failure', 'error'}:
            return self._result('system.environment_error', 0.6, ['metadata status marks event as failed'])
        return None

    def _result(
        self, mode_id: str, confidence: float, evidence: List[str]
    ) -> Tuple[FailureMode, float, List[str]]:
        return SEED_FAILURE_MODES[mode_id], confidence, evidence

    def _select_root_cause(self, findings: List[FailureFinding]) -> Optional[FailureFinding]:
        if not findings:
            return None
        return sorted(
            findings,
            key=lambda finding: (
                finding.step_index is None,
                finding.step_index if finding.step_index is not None else 10**9,
                -finding.confidence,
            ),
        )[0]

    def _event_text(self, event: AgentEvent) -> str:
        parts = [
            self._event_type_value(event.event_type),
            event.module or '',
            str(event.input or ''),
            str(event.output or ''),
            event.error or '',
            str(event.metadata),
        ]
        return '\n'.join(parts)

    def _suggestion(self, failure_mode: FailureMode) -> Optional[str]:
        if not failure_mode.suggestion_templates:
            return None
        return str(failure_mode.suggestion_templates[0])

    def _contains(self, text: str, needles: Iterable[str]) -> bool:
        return any(needle in text for needle in needles)

    def _dedupe(self, values: Iterable[str]) -> List[str]:
        seen = set()
        result = []
        for value in values:
            if value in seen:
                continue
            seen.add(value)
            result.append(value)
        return result

    def _event_type_value(self, event_type: EventType) -> str:
        value = getattr(event_type, 'value', event_type)
        return str(value)
