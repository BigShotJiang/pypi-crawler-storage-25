"""Failure attribution.

v0.1 ships two backends, both behind the same :class:`Attributor` protocol:

* :class:`HeuristicAttributor` — uses the earliest finding (with confidence
  tie-break) from a ``DiagnosticReport`` to derive blame. Zero-cost; always
  available; matches what :class:`agentdebug.analyzers.HeuristicAnalyzer` does
  internally today.
* :class:`AllAtOnceAttributor` — feeds the full trajectory + findings to an
  LLM and asks for a single blame hypothesis. Uses the Who&When "All-at-Once"
  method from arXiv:2505.00212.

Both produce an :class:`AttributionResult` carrying a list of :class:`Blame`
hypotheses with confidence, rationale, and source attribution. Honest UX: we
always return ranked hypotheses, never single-point claims.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, cast


# Forward decl so BinarySearchAttributor.attribute can reference _EllipsisEvent
# from the helper render path; defined later in the module.

from agentdebug.llm import LLMClient, extract_json_block
from agentdebug.models import AgentEvent, AgentTrajectory, FailureFinding, new_id

LOG = logging.getLogger('agentdebug.attribution')


@dataclass
class Blame:
    span_id: Optional[str]
    step_index: Optional[int]
    agent_name: Optional[str]
    confidence: float
    rationale: str
    evidence: List[str] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)


@dataclass
class AttributionResult:
    method: str
    hypotheses: List[Blame]
    elapsed_ms: int = 0
    raw: Dict[str, Any] = field(default_factory=dict)


class Attributor(Protocol):
    id: str

    def attribute(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> AttributionResult:
        ...


class HeuristicAttributor:
    """Cheap, model-free fallback that picks the earliest highest-confidence finding."""

    id = 'heuristic'

    def attribute(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> AttributionResult:
        if not findings:
            return AttributionResult(method=self.id, hypotheses=[])
        ranked = sorted(
            findings,
            key=lambda f: (
                f.step_index is None,
                f.step_index if f.step_index is not None else 10**9,
                -f.confidence,
            ),
        )
        primary = ranked[0]
        return AttributionResult(
            method=self.id,
            hypotheses=[
                Blame(
                    span_id=primary.event_id,
                    step_index=primary.step_index,
                    agent_name=primary.agent_name,
                    confidence=primary.confidence,
                    rationale=(
                        f'Earliest finding with non-trivial confidence: '
                        f'{primary.failure_mode.name}'
                    ),
                    evidence=list(primary.evidence),
                    sources=[self.id],
                )
            ],
        )


_ATTR_SYSTEM_PROMPT = """You are AgentDebugX-Attributor. Given a failed agent
trajectory and the list of step-level failure findings already produced by a
judge, identify the single MOST RESPONSIBLE step (the decisive root cause).

Respond ONLY with a JSON object matching this schema (no prose, no markdown):

{
  "span_id": "<event_id from the input or null>",
  "step_index": <int or null>,
  "agent_name": "<agent_name from the input or null>",
  "confidence": <float between 0 and 1>,
  "rationale": "<one or two sentences justifying the choice>",
  "evidence": ["<short quoted evidence>", ...]
}

If the trajectory does not appear to have failed, return all fields as null and
confidence 0.
"""


class AllAtOnceAttributor:
    """LLM-based attributor mirroring Who&When's All-at-Once method."""

    id = 'all_at_once'

    def __init__(
        self,
        llm: LLMClient,
        *,
        fallback: Optional[Attributor] = None,
        max_findings: int = 20,
        max_tokens: int = 2048,
    ) -> None:
        self.llm = llm
        self.fallback: Attributor = fallback or HeuristicAttributor()
        self.max_findings = max_findings
        self.max_tokens = max_tokens

    def attribute(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> AttributionResult:
        prompt_user = self._render_prompt(trajectory, findings[: self.max_findings])
        messages = [
            {'role': 'system', 'content': _ATTR_SYSTEM_PROMPT},
            {'role': 'user', 'content': prompt_user},
        ]
        try:
            result = self.llm.complete(messages=messages, max_tokens=self.max_tokens)
        except Exception as exc:  # pragma: no cover - defensive
            LOG.warning('LLM attribution failed; falling back: %s', exc)
            return self.fallback.attribute(trajectory, findings)
        parsed = extract_json_block(result.text)
        if not parsed:
            LOG.info('LLM attributor returned no JSON; falling back')
            return self.fallback.attribute(trajectory, findings)
        blame = Blame(
            span_id=self._coerce_str(parsed.get('span_id')),
            step_index=self._coerce_int(parsed.get('step_index')),
            agent_name=self._coerce_str(parsed.get('agent_name')),
            confidence=self._coerce_float(parsed.get('confidence'), default=0.0),
            rationale=str(parsed.get('rationale') or ''),
            evidence=self._coerce_str_list(parsed.get('evidence')),
            sources=[self.id],
        )
        return AttributionResult(
            method=self.id,
            hypotheses=[blame],
            raw={'finding_count': len(findings)},
        )

    def _render_prompt(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> str:
        findings_doc = '\n'.join(self._render_finding(f) for f in findings) or '(none)'
        events_doc = '\n'.join(
            f'event_id={e.event_id} step={e.step_index} agent={e.agent_name} '
            f'type={getattr(e.event_type, "value", e.event_type)} '
            f'output={str(e.output)[:200]} error={str(e.error)[:200]}'
            for e in trajectory.events
        )
        return (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'JUDGE FINDINGS:\n{findings_doc}\n\n'
            f'EVENTS:\n{events_doc}\n'
        )

    def _render_finding(self, finding: FailureFinding) -> str:
        return (
            f'- mode={finding.failure_mode.mode_id} '
            f'agent={finding.agent_name} step={finding.step_index} '
            f'confidence={finding.confidence:.2f} '
            f'evidence={"; ".join(finding.evidence)[:200]}'
        )

    @staticmethod
    def _coerce_str(value: Any) -> Optional[str]:
        if value is None:
            return None
        return str(value)

    @staticmethod
    def _coerce_int(value: Any) -> Optional[int]:
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _coerce_float(value: Any, *, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _coerce_str_list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value]
        return [str(value)]


_BISECT_SYSTEM_PROMPT = """You are AgentDebugX-Attributor running the
Who&When "Binary-Search" attribution method (arXiv:2505.00212). You will be
shown a PREFIX of a failed agent trajectory truncated to its first N events.

Decide whether the failure has ALREADY occurred within this prefix, i.e.,
whether the trajectory is unrecoverable as of the last event shown.

Respond ONLY with a JSON object (no prose, no markdown):

{
  "failure_already_happened": true | false,
  "confidence": <float in [0,1]>,
  "rationale": "<one or two sentences>",
  "decisive_event_id": "<event_id or null>"
}

Be conservative: only return true when you can point to evidence in the
prefix that the agent has already taken (or omitted) the decisive step.
"""


_STEP_SYSTEM_PROMPT = """You are AgentDebugX-Attributor, scanning a failed
agent trajectory one step at a time (the Who&When "Step-by-Step" method,
arXiv:2505.00212).

You will be given the goal, framework, the prior judge findings, AND a
SINGLE step from the trajectory plus a short window of preceding steps for
context. Decide whether THIS step is the decisive failure step.

Respond ONLY with a JSON object matching this schema (no prose, no markdown):

{
  "is_failure_step": true | false,
  "confidence": <float in [0,1]>,
  "rationale": "<one sentence>",
  "evidence": ["<short quoted evidence>", ...]
}

Be CONSERVATIVE: only return true when the trajectory evidence on this step
specifically caused the cascading failure.
"""


class StepByStepAttributor:
    """LLM-based attributor mirroring Who&When's Step-by-Step method.

    Walks the trajectory in order, asking the LLM about each step. Returns
    every step that answered ``is_failure_step=true`` as a Blame hypothesis,
    sorted by step index. Costs O(N) LLM calls; pair with ``max_steps`` to
    bound the budget for long trajectories.
    """

    id = 'step_by_step'

    def __init__(
        self,
        llm: LLMClient,
        *,
        fallback: Optional[Attributor] = None,
        max_steps: int = 30,
        context_window: int = 3,
        max_tokens: int = 1024,
    ) -> None:
        self.llm = llm
        self.fallback: Attributor = fallback or HeuristicAttributor()
        self.max_steps = max_steps
        self.context_window = context_window
        self.max_tokens = max_tokens

    def attribute(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> AttributionResult:
        events = list(trajectory.events)
        if not events:
            return self.fallback.attribute(trajectory, findings)
        # Scan only the suffix of size max_steps so long traces stay affordable.
        budget = min(self.max_steps, len(events))
        scanned = events[-budget:]
        hypotheses: List[Blame] = []
        for idx, evt in enumerate(scanned):
            absolute_index = len(events) - budget + idx
            ctx_start = max(0, absolute_index - self.context_window)
            context = events[ctx_start:absolute_index]
            verdict = self._classify_step(
                trajectory, findings, evt, context=context
            )
            if verdict is None or not verdict.get('is_failure_step'):
                continue
            hypotheses.append(Blame(
                span_id=evt.event_id,
                step_index=evt.step_index,
                agent_name=evt.agent_name,
                confidence=self._coerce_float(verdict.get('confidence'), 0.5),
                rationale=str(verdict.get('rationale') or ''),
                evidence=self._coerce_str_list(verdict.get('evidence')),
                sources=[self.id],
            ))
        if not hypotheses:
            return AttributionResult(
                method=self.id,
                hypotheses=[],
                raw={'scanned_steps': len(scanned)},
            )
        hypotheses.sort(
            key=lambda h: (
                h.step_index is None,
                h.step_index if h.step_index is not None else 10**9,
            )
        )
        return AttributionResult(
            method=self.id,
            hypotheses=hypotheses,
            raw={'scanned_steps': len(scanned)},
        )

    def _classify_step(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
        event: 'AgentEvent',
        *,
        context: List['AgentEvent'],
    ) -> Optional[Dict[str, Any]]:
        findings_doc = '\n'.join(self._render_finding(f) for f in findings[:10]) \
            or '(no judge findings yet)'
        context_doc = '\n'.join(
            f'context event_id={e.event_id} step={e.step_index} agent={e.agent_name}'
            f' type={getattr(e.event_type, "value", e.event_type)}'
            f' output={str(e.output)[:120]} error={str(e.error)[:120]}'
            for e in context
        ) or '(no preceding context)'
        prompt = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'JUDGE FINDINGS:\n{findings_doc}\n\n'
            f'PRECEDING CONTEXT:\n{context_doc}\n\n'
            f'CANDIDATE STEP:\n'
            f'  event_id={event.event_id}\n'
            f'  step={event.step_index} agent={event.agent_name} '
            f'module={event.module}\n'
            f'  type={getattr(event.event_type, "value", event.event_type)}\n'
            f'  input={str(event.input)[:300]}\n'
            f'  output={str(event.output)[:300]}\n'
            f'  error={str(event.error)[:300]}\n'
        )
        try:
            result = self.llm.complete(
                messages=[
                    {'role': 'system', 'content': _STEP_SYSTEM_PROMPT},
                    {'role': 'user', 'content': prompt},
                ],
                max_tokens=self.max_tokens,
            )
        except Exception as exc:  # pragma: no cover
            LOG.warning('step_by_step LLM call failed at step %s: %s',
                        event.step_index, exc)
            return None
        parsed = extract_json_block(result.text)
        if parsed is None:
            return None
        return cast(Dict[str, Any], parsed)

    def _render_finding(self, finding: FailureFinding) -> str:
        return (
            f'- mode={finding.failure_mode.mode_id} '
            f'agent={finding.agent_name} step={finding.step_index} '
            f'confidence={finding.confidence:.2f}'
        )

    @staticmethod
    def _coerce_float(value: Any, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _coerce_str_list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v) for v in value]
        return [str(value)]


class BinarySearchAttributor:
    """LLM-based attributor implementing Who&When's Binary-Search method.

    Bisects the trajectory and asks the LLM whether the failure has already
    occurred in each prefix. Costs O(log N) LLM calls vs StepByStep's O(N).

    The contract:

    * Pre-condition: the trajectory is known to have failed overall.
    * Loop invariant: ``failure_already_happened`` is False at ``lo`` and
      True at ``hi``. The decisive step lives in ``(lo, hi]``.
    * Termination: ``hi - lo == 1``; ``hi - 1`` is the decisive index.

    Returns the event at the decisive index as the primary Blame hypothesis.
    Falls back to the configured ``fallback`` attributor when the trajectory
    is empty or the LLM responses are uninterpretable.
    """

    id = 'binary_search'

    def __init__(
        self,
        llm: LLMClient,
        *,
        fallback: Optional[Attributor] = None,
        max_tokens: int = 1024,
        context_window: int = 6,
    ) -> None:
        self.llm = llm
        self.fallback: Attributor = fallback or HeuristicAttributor()
        self.max_tokens = max_tokens
        # When formatting a prefix into the LLM prompt we only keep this many
        # events at the head + this many at the tail; the middle is elided.
        # Keeps cost bounded for very long trajectories.
        self.context_window = context_window

    def attribute(
        self,
        trajectory: AgentTrajectory,
        findings: List[FailureFinding],
    ) -> AttributionResult:
        n = len(trajectory.events)
        if n == 0:
            return self.fallback.attribute(trajectory, findings)
        lo, hi = 0, n
        probe_count = 0
        # Sanity: cap probes at ceil(log2(n)) + 2 to bound cost in pathological cases.
        import math
        max_probes = max(1, int(math.ceil(math.log2(max(n, 2)))) + 2)
        while hi - lo > 1 and probe_count < max_probes:
            mid = (lo + hi) // 2
            probe_count += 1
            verdict = self._probe(trajectory, mid)
            if verdict is None:
                # Uninterpretable response: fall back rather than guess.
                return self.fallback.attribute(trajectory, findings)
            already = bool(verdict.get('failure_already_happened'))
            if already:
                hi = mid
            else:
                lo = mid
        decisive_index = hi - 1
        decisive = trajectory.events[decisive_index]
        return AttributionResult(
            method=self.id,
            hypotheses=[Blame(
                span_id=decisive.event_id,
                step_index=decisive.step_index,
                agent_name=decisive.agent_name,
                confidence=0.6 + 0.1 * min(probe_count, 4),
                rationale=(
                    f'Binary search located the decisive step within '
                    f'{probe_count} probes over {n} events.'
                ),
                evidence=[
                    f'event_id={decisive.event_id}',
                    f'step={decisive.step_index}',
                ],
                sources=[self.id],
            )],
            raw={'probe_count': probe_count, 'trajectory_len': n},
        )

    def _probe(
        self, trajectory: AgentTrajectory, prefix_len: int
    ) -> Optional[Dict[str, Any]]:
        prefix = trajectory.prefix(prefix_len)
        # Render prefix with head + tail elision so long prefixes stay cheap.
        events_doc = self._render_prefix(prefix)
        user = (
            f'GOAL: {trajectory.goal!r}\n'
            f'FRAMEWORK: {trajectory.framework!r}\n\n'
            f'PREFIX (events 1..{prefix_len} of {len(trajectory.events)}):\n'
            f'{events_doc}'
        )
        try:
            result = self.llm.complete(
                messages=[
                    {'role': 'system', 'content': _BISECT_SYSTEM_PROMPT},
                    {'role': 'user', 'content': user},
                ],
                max_tokens=self.max_tokens,
            )
        except Exception as exc:  # pragma: no cover
            LOG.warning('binary_search probe at prefix_len=%s failed: %s',
                        prefix_len, exc)
            return None
        parsed = extract_json_block(result.text)
        if parsed is None:
            return None
        return cast(Dict[str, Any], parsed)

    def _render_prefix(self, prefix: AgentTrajectory) -> str:
        events = prefix.events
        if len(events) <= 2 * self.context_window:
            view = events
        else:
            head = events[: self.context_window]
            tail = events[-self.context_window:]
            elided = len(events) - 2 * self.context_window
            view = head + [_EVENT_ELLIPSIS(elided)] + tail
        return '\n'.join(self._render_event(e) for e in view)

    @staticmethod
    def _render_event(event: Any) -> str:
        if isinstance(event, _EllipsisEvent):
            return f'... ({event.count} events elided) ...'
        return (
            f'event_id={event.event_id} step={event.step_index} '
            f'agent={event.agent_name} '
            f'type={getattr(event.event_type, "value", event.event_type)} '
            f'output={str(event.output)[:200]} '
            f'error={str(event.error)[:200]}'
        )


@dataclass
class _EllipsisEvent:
    count: int


def _EVENT_ELLIPSIS(count: int) -> _EllipsisEvent:
    return _EllipsisEvent(count=count)


__all__ = [
    'Attributor', 'Blame', 'AttributionResult',
    'HeuristicAttributor', 'AllAtOnceAttributor', 'StepByStepAttributor',
    'BinarySearchAttributor',
]
