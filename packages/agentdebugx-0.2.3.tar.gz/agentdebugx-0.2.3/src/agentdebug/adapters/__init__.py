"""Framework adapters.

The base Protocol and status dataclass are always available. Concrete
adapters live in sibling modules and are imported lazily by name so that
``import agentdebug.adapters`` never pulls in optional framework deps.
"""

from agentdebug.adapters.base import AdapterStatus, FrameworkAdapter

__all__ = ['AdapterStatus', 'FrameworkAdapter']
