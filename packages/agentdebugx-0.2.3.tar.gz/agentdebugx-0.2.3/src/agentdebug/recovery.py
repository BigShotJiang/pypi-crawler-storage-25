"""Lightweight recovery suggestions.

v0.1 ships ``ReflexionSuggestion`` — a *suggest-only* recovery generator that
produces a structured retry-prompt artifact based on Reflexion (Shinn et al.,
NeurIPS 2023, arXiv:2303.11366). Heavier strategies (Self-Refine loop, CRITIC,
Saga rollback, MCTS) are deferred per the roadmap and will land behind the same
:class:`Recoverer` protocol.

By design, **nothing here re-executes the agent** — recovery proposals are
artifacts to be surfaced (CLI/UI/PR comment) or fed back into the next run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Protocol, Tuple

from agentdebug.models import (
    AgentTrajectory,
    DiagnosticReport,
    FailureFinding,
    new_id,
)


@dataclass
class FixProposal:
    proposal_id: str
    recoverer_id: str
    target_event_id: Optional[str]
    summary: str
    rationale: str
    confidence: float
    suggestion_text: str
    side_effects: List[str] = field(default_factory=list)
    requires_human_approval: bool = False


class Recoverer(Protocol):
    id: str

    def suggest(
        self,
        trajectory: AgentTrajectory,
        report: DiagnosticReport,
    ) -> List[FixProposal]:
        ...


class ReflexionSuggestion:
    """Emit a Reflexion-style retry reflection per finding.

    The output is purely textual — it can be appended to the agent's next
    system prompt, written to a project ``MANUAL.md``, or surfaced in the
    Console. There is no auto-apply.
    """

    id = 'reflexion'

    def suggest(
        self,
        trajectory: AgentTrajectory,
        report: DiagnosticReport,
    ) -> List[FixProposal]:
        if not report.findings:
            return []
        proposals: List[FixProposal] = []
        for finding in report.findings:
            proposals.append(self._build_proposal(trajectory, finding))
        return proposals

    def _build_proposal(
        self, trajectory: AgentTrajectory, finding: FailureFinding
    ) -> FixProposal:
        goal = trajectory.goal or '(no goal recorded)'
        framework = trajectory.framework or '(framework not declared)'
        evidence_block = '\n'.join(f'  - {e}' for e in finding.evidence) or '  (none)'
        suggestion_template = (
            finding.suggestion
            or (finding.failure_mode.suggestion_templates[0]
                if finding.failure_mode.suggestion_templates
                else 'Inspect the offending step and constrain the agent at that point.')
        )
        reflection = (
            f'Task: {goal}\n'
            f'Framework: {framework}\n'
            f'Observed failure mode: {finding.failure_mode.mode_id} '
            f'({finding.failure_mode.name})\n'
            f'Located at agent={finding.agent_name}, step={finding.step_index}, '
            f'event_id={finding.event_id}\n'
            f'Evidence:\n{evidence_block}\n'
            f'Next time, do the following:\n  {suggestion_template}\n'
        )
        return FixProposal(
            proposal_id=new_id('fix'),
            recoverer_id=self.id,
            target_event_id=finding.event_id,
            summary=(
                f'Reflexion retry hint for {finding.failure_mode.mode_id} '
                f'at step {finding.step_index}'
            ),
            rationale=(
                'Reflexion (Shinn et al., NeurIPS 2023) converts a failure '
                'into a verbal hint appended to next attempt.'
            ),
            confidence=min(0.9, max(0.1, finding.confidence)),
            suggestion_text=reflection,
            side_effects=['memory.write'],
            requires_human_approval=False,
        )


@dataclass(frozen=True)
class VerifierSpec:
    """A pattern describing a tool-grounded verifier that could have caught
    a particular family of failures.

    Used by :class:`CriticRecoverer` to recommend (not run) the addition of
    a verifier between the failing step and the next side-effect.
    """

    id: str
    description: str
    matches_families: tuple[str, ...]      # e.g. ('action',)
    matches_mode_prefixes: tuple[str, ...]  # e.g. ('action.format_error', 'action.parameter_error')
    suggested_code: str                      # short snippet showing how to add the guard
    rationale: str

    def matches(self, finding: 'FailureFinding') -> bool:
        if finding.failure_mode.family in self.matches_families:
            return True
        return any(
            finding.failure_mode.mode_id.startswith(p)
            for p in self.matches_mode_prefixes
        )


DEFAULT_VERIFIERS: List[VerifierSpec] = [
    VerifierSpec(
        id='json_schema_guard',
        description='Validate tool arguments against the tool JSON schema before execution.',
        matches_families=('action',),
        matches_mode_prefixes=('action.format_error', 'action.parameter_error'),
        suggested_code=(
            'from jsonschema import validate, ValidationError\n'
            'try:\n'
            '    validate(instance=tool_args, schema=tool.schema)\n'
            'except ValidationError as exc:\n'
            '    return handle_arg_error(exc, tool=tool, args=tool_args)\n'
        ),
        rationale=(
            'CRITIC (Gou et al., ICLR 2024): a tool-interactive verifier '
            'catches malformed/missing-argument failures before they hit '
            'the downstream API.'
        ),
    ),
    VerifierSpec(
        id='final_state_check',
        description='Independent final-state verifier confirms the task is satisfied before terminating.',
        matches_families=('verification', 'reflection'),
        matches_mode_prefixes=('verification.', 'reflection.progress_misjudge'),
        suggested_code=(
            'def verify_task_complete(goal: str, final_state: dict) -> bool:\n'
            '    # Check every explicit success criterion; do NOT trust the\n'
            '    # acting agent\'s self-report.\n'
            '    return all(criterion(final_state) for criterion in success_criteria(goal))\n'
            '\n'
            'if not verify_task_complete(goal, state):\n'
            '    trigger_recovery_planning(reason="task not verified complete")\n'
        ),
        rationale=(
            'MAST (Cemri et al., 2025) shows premature termination + missing '
            'task validation are dominant multi-agent failure modes. A '
            'verifier that does not trust the acting agent is the standard '
            'fix.'
        ),
    ),
    VerifierSpec(
        id='tool_result_typecheck',
        description='Type-check the tool result and require explicit handling of None / empty.',
        matches_families=('action', 'system'),
        matches_mode_prefixes=('action.wrong_tool', 'system.tool_execution_error'),
        suggested_code=(
            'result = tool.run(args)\n'
            'if result is None or result == {}:\n'
            '    return handle_empty_result(tool=tool, args=args)\n'
            'if not isinstance(result, tool.expected_return_type):\n'
            '    return handle_unexpected_type(result, tool=tool)\n'
        ),
        rationale=(
            'Tool outputs that the agent does not branch on (None, empty '
            'list, unexpected type) propagate as "agent hallucinated a '
            'fact" downstream. Force the agent to handle them at the call '
            'site.'
        ),
    ),
    VerifierSpec(
        id='handoff_context_contract',
        description='Require the receiving agent to restate critical constraints before proceeding.',
        matches_families=('multiagent',),
        matches_mode_prefixes=('multiagent.handoff_loss',),
        suggested_code=(
            'def handoff(payload: HandoffPayload, to_agent: Agent) -> None:\n'
            '    received = to_agent.read(payload)\n'
            '    if not received.restates(payload.constraints):\n'
            '        raise HandoffContractError(\n'
            '            "receiver did not restate constraints"\n'
            '        )\n'
        ),
        rationale=(
            'Who&When (Zhang et al., 2025): handoff context loss is the '
            'most common decisive multi-agent failure step. Typed handoff '
            'payloads + receiver restating prevent silent dropping.'
        ),
    ),
    VerifierSpec(
        id='loop_detector_guard',
        description='Detect repeated tool calls / no-progress windows and trigger replan.',
        matches_families=('planning',),
        matches_mode_prefixes=('planning.inefficient_plan',),
        suggested_code=(
            'from agentdebug.detectors import RepeatedToolCallDetector\n'
            'detector = RepeatedToolCallDetector(threshold=3)\n'
            'if detector.detect(current_trajectory):\n'
            '    return replan(reason="loop detected")\n'
        ),
        rationale=(
            'Loops are the canonical inefficient-plan failure. AgentDebugX '
            'ships an in-process detector you can call between steps.'
        ),
    ),
]


class CriticRecoverer:
    """Tool-grounded recovery suggestions modeled on CRITIC (arXiv:2305.11738).

    Unlike the paper's CRITIC loop (which re-runs the agent against a
    verifier until pass), this recoverer is suggest-only: for each finding
    it matches the failure mode against a registry of :class:`VerifierSpec`
    templates and emits a :class:`FixProposal` with the suggested verifier
    code + rationale. The user decides whether to add the verifier.

    Pair with :class:`ReflexionSuggestion` for full coverage: Reflexion
    tells the agent what went wrong; CriticRecoverer tells the developer
    what guard to add.
    """

    id = 'critic'

    def __init__(
        self,
        verifiers: Optional[List[VerifierSpec]] = None,
    ) -> None:
        self.verifiers = list(verifiers) if verifiers is not None else list(DEFAULT_VERIFIERS)

    def suggest(
        self,
        trajectory: AgentTrajectory,
        report: DiagnosticReport,
    ) -> List[FixProposal]:
        if not report.findings:
            return []
        proposals: List[FixProposal] = []
        seen: set[tuple[str, str]] = set()  # (event_id, verifier_id)
        for finding in report.findings:
            for verifier in self.verifiers:
                if not verifier.matches(finding):
                    continue
                key = (finding.event_id or '', verifier.id)
                if key in seen:
                    continue
                seen.add(key)
                proposals.append(self._build(finding, verifier))
        return proposals

    def _build(
        self, finding: FailureFinding, verifier: VerifierSpec,
    ) -> FixProposal:
        summary = (
            f'Add {verifier.id} before {finding.failure_mode.mode_id} '
            f'(step {finding.step_index}, agent {finding.agent_name})'
        )
        text = (
            f'Failure: {finding.failure_mode.mode_id} '
            f'({finding.failure_mode.name})\n'
            f'Located at agent={finding.agent_name}, step={finding.step_index}, '
            f'event_id={finding.event_id}\n\n'
            f'Recommended verifier: {verifier.id}\n'
            f'Rationale: {verifier.rationale}\n\n'
            f'Suggested code:\n'
            f'```python\n{verifier.suggested_code}\n```\n'
        )
        return FixProposal(
            proposal_id=new_id('fix'),
            recoverer_id=self.id,
            target_event_id=finding.event_id,
            summary=summary,
            rationale=verifier.rationale,
            confidence=max(0.3, min(0.85, finding.confidence)),
            suggestion_text=text,
            side_effects=[],
            requires_human_approval=False,
        )


__all__ = [
    'CriticRecoverer',
    'DEFAULT_VERIFIERS',
    'FixProposal',
    'Recoverer',
    'ReflexionSuggestion',
    'VerifierSpec',
]
