"""Persistence backends for traces and diagnostic reports."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import List, Optional, Protocol

from agentdebug.models import (
    AgentTrajectory,
    DiagnosticReport,
    model_to_json,
    report_from_json,
    trajectory_from_json,
    utc_now,
)


class TraceStore(Protocol):
    def save_trajectory(self, trajectory: AgentTrajectory) -> None:
        ...

    def load_trajectory(self, trace_id: str) -> Optional[AgentTrajectory]:
        ...

    def list_traces(self) -> List[str]:
        ...


class JsonlTraceStore:
    """Append-only local store for quick adoption and reproducible examples."""

    def __init__(self, path: str = '.agentdebug/traces.jsonl') -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def save_trajectory(self, trajectory: AgentTrajectory) -> None:
        with self.path.open('a', encoding='utf-8') as handle:
            handle.write(model_to_json(trajectory))
            handle.write('\n')

    def load_trajectory(self, trace_id: str) -> Optional[AgentTrajectory]:
        if not self.path.exists():
            return None
        match = None
        with self.path.open('r', encoding='utf-8') as handle:
            for line in handle:
                if not line.strip():
                    continue
                candidate = trajectory_from_json(line)
                if candidate.trace_id == trace_id:
                    match = candidate
        return match

    def list_traces(self) -> List[str]:
        if not self.path.exists():
            return []
        trace_ids = []
        with self.path.open('r', encoding='utf-8') as handle:
            for line in handle:
                if not line.strip():
                    continue
                trace_ids.append(trajectory_from_json(line).trace_id)
        return trace_ids


class SQLiteTraceStore:
    """Small embedded error database for local development and CI artifacts."""

    def __init__(self, path: str = '.agentdebug/agentdebug.sqlite') -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def save_trajectory(self, trajectory: AgentTrajectory) -> None:
        payload = model_to_json(trajectory)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO trajectories(trace_id, task_id, framework, updated_at, payload_json)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(trace_id) DO UPDATE SET
                    task_id=excluded.task_id,
                    framework=excluded.framework,
                    updated_at=excluded.updated_at,
                    payload_json=excluded.payload_json
                """,
                (
                    trajectory.trace_id,
                    trajectory.task_id,
                    trajectory.framework,
                    utc_now().isoformat(),
                    payload,
                ),
            )

    def load_trajectory(self, trace_id: str) -> Optional[AgentTrajectory]:
        with self._connect() as conn:
            row = conn.execute(
                'SELECT payload_json FROM trajectories WHERE trace_id = ?',
                (trace_id,),
            ).fetchone()
        if row is None:
            return None
        return trajectory_from_json(str(row[0]))

    def list_traces(self) -> List[str]:
        with self._connect() as conn:
            rows = conn.execute(
                'SELECT trace_id FROM trajectories ORDER BY updated_at DESC'
            ).fetchall()
        return [str(row[0]) for row in rows]

    def save_report(self, report: DiagnosticReport) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO diagnostic_reports(
                    report_id, trace_id, generated_at, payload_json
                )
                VALUES (?, ?, ?, ?)
                """,
                (
                    report.report_id,
                    report.trace_id,
                    report.generated_at.isoformat(),
                    model_to_json(report),
                ),
            )

    def list_reports(self, trace_id: Optional[str] = None) -> List[DiagnosticReport]:
        query = 'SELECT payload_json FROM diagnostic_reports'
        params: tuple[str, ...] = ()
        if trace_id is not None:
            query += ' WHERE trace_id = ?'
            params = (trace_id,)
        query += ' ORDER BY generated_at DESC'
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [report_from_json(str(row[0])) for row in rows]

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trajectories (
                    trace_id TEXT PRIMARY KEY,
                    task_id TEXT,
                    framework TEXT,
                    updated_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS diagnostic_reports (
                    report_id TEXT PRIMARY KEY,
                    trace_id TEXT NOT NULL,
                    generated_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                )
                """
            )
