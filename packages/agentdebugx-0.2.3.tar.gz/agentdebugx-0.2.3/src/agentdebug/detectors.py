"""Lightweight rule + anomaly detectors that don't need an LLM.

These were specified in `docs/06_detectors.md` but not implemented in the
initial v0.1 ship. The :class:`HeuristicAnalyzer` covers per-event string
matching; the detectors here cover *cross-event* signals (loops, repeated
tool calls, no-op streaks) which the heuristic analyzer cannot see in a
single pass.

Each detector implements :class:`Detector` and returns a list of
:class:`FailureFinding`. They compose with the existing analyzer pipeline
via :func:`run_detectors`.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional, Protocol

from agentdebug.models import (
    AgentEvent,
    AgentTrajectory,
    EventType,
    FailureFinding,
    FailureMode,
    new_id,
)
from agentdebug.taxonomy import SEED_FAILURE_MODES

LOG = logging.getLogger('agentdebug.detectors')


@dataclass
class DetectorConfig:
    """Tunables for the rule + anomaly detectors."""

    repeated_tool_call_threshold: int = 3
    repeated_state_window: int = 4
    repeated_state_threshold: int = 3
    step_count_limit: int = 50


class Detector(Protocol):
    id: str

    def detect(self, trajectory: AgentTrajectory) -> List[FailureFinding]:
        ...


# ---------------------------------------------------------------------------
# RepeatedToolCallDetector
# ---------------------------------------------------------------------------

class RepeatedToolCallDetector:
    """Flag a tool that's called with identical args >= threshold times.

    Matches ``FM-1.3 step_repetition`` / ``planning.inefficient_plan``.
    """

    id = 'repeated_tool_call'

    def __init__(self, *, threshold: int = 3) -> None:
        self.threshold = threshold

    def detect(self, trajectory: AgentTrajectory) -> List[FailureFinding]:
        counts: dict[tuple[str, str], List[AgentEvent]] = {}
        for evt in trajectory.events:
            if evt.event_type != EventType.TOOL_CALL:
                continue
            key = (evt.agent_name, _normalize(evt.input))
            counts.setdefault(key, []).append(evt)
        findings: List[FailureFinding] = []
        mode = SEED_FAILURE_MODES['planning.inefficient_plan']
        for (agent, signature), events in counts.items():
            if len(events) < self.threshold:
                continue
            target = events[-1]
            findings.append(
                FailureFinding(
                    finding_id=new_id('finding'),
                    failure_mode=mode,
                    event_id=target.event_id,
                    agent_name=target.agent_name,
                    step_index=target.step_index,
                    confidence=min(0.5 + 0.1 * len(events), 0.95),
                    evidence=[
                        f'{len(events)} identical TOOL_CALL events with '
                        f'signature={_truncate(signature, 80)} on agent={agent}',
                    ],
                    suggestion=_suggestion(mode),
                    metadata={'source': self.id, 'detected_count': len(events)},
                )
            )
        return findings


# ---------------------------------------------------------------------------
# RepeatedStateDetector
# ---------------------------------------------------------------------------

class RepeatedStateDetector:
    """Flag a sliding window where the agent's outputs/observations don't change.

    Catches no-progress loops the per-event matcher cannot see (e.g., agent
    keeps responding "checking..." or producing the same plan over several
    steps). Matches ``planning.inefficient_plan``.
    """

    id = 'repeated_state'

    def __init__(self, *, window: int = 4, threshold: int = 3) -> None:
        if threshold > window:
            raise ValueError('threshold must be <= window')
        self.window = window
        self.threshold = threshold

    def detect(self, trajectory: AgentTrajectory) -> List[FailureFinding]:
        events = [
            e for e in trajectory.events
            if e.event_type in {
                EventType.OBSERVATION,
                EventType.AGENT_STEP,
                EventType.PLAN,
                EventType.TOOL_RESULT,
            }
        ]
        findings: List[FailureFinding] = []
        if len(events) < self.window:
            return findings
        mode = SEED_FAILURE_MODES['planning.inefficient_plan']
        flagged_event_ids: set[str] = set()
        for i in range(len(events) - self.window + 1):
            window = events[i : i + self.window]
            sigs = [_normalize(_state_signature(e)) for e in window]
            most_common, count = _mode_count(sigs)
            if count < self.threshold:
                continue
            target = window[-1]
            if target.event_id in flagged_event_ids:
                continue
            flagged_event_ids.add(target.event_id)
            findings.append(
                FailureFinding(
                    finding_id=new_id('finding'),
                    failure_mode=mode,
                    event_id=target.event_id,
                    agent_name=target.agent_name,
                    step_index=target.step_index,
                    confidence=min(0.5 + 0.1 * count, 0.9),
                    evidence=[
                        f'state repeated {count}x within window of '
                        f'{self.window} events; signature={_truncate(most_common, 80)}',
                    ],
                    suggestion=_suggestion(mode),
                    metadata={
                        'source': self.id,
                        'window': self.window,
                        'repeated_count': count,
                    },
                )
            )
        return findings


# ---------------------------------------------------------------------------
# StepCountLimitDetector
# ---------------------------------------------------------------------------

class StepCountLimitDetector:
    """Flag a trajectory that exceeded a configured step budget.

    Matches ``AgentBench TLE`` and ``verification.premature_stop`` proxies.
    """

    id = 'step_count_limit'

    def __init__(self, *, max_steps: int = 50) -> None:
        self.max_steps = max_steps

    def detect(self, trajectory: AgentTrajectory) -> List[FailureFinding]:
        if len(trajectory.events) <= self.max_steps:
            return []
        target = trajectory.events[-1]
        mode = SEED_FAILURE_MODES['planning.inefficient_plan']
        return [FailureFinding(
            finding_id=new_id('finding'),
            failure_mode=mode,
            event_id=target.event_id,
            agent_name=target.agent_name,
            step_index=target.step_index,
            confidence=0.7,
            evidence=[
                f'{len(trajectory.events)} events exceeds configured '
                f'max_steps={self.max_steps}',
            ],
            suggestion=_suggestion(mode),
            metadata={'source': self.id, 'event_count': len(trajectory.events)},
        )]


# ---------------------------------------------------------------------------
# Pipeline runner
# ---------------------------------------------------------------------------

def default_detectors(config: Optional[DetectorConfig] = None) -> List[Detector]:
    cfg = config or DetectorConfig()
    return [
        RepeatedToolCallDetector(threshold=cfg.repeated_tool_call_threshold),
        RepeatedStateDetector(
            window=cfg.repeated_state_window,
            threshold=cfg.repeated_state_threshold,
        ),
        StepCountLimitDetector(max_steps=cfg.step_count_limit),
    ]


def run_detectors(
    trajectory: AgentTrajectory,
    detectors: Optional[List[Detector]] = None,
) -> List[FailureFinding]:
    """Run a list of detectors over a trajectory and return merged findings."""
    detectors = detectors or default_detectors()
    out: List[FailureFinding] = []
    for d in detectors:
        try:
            out.extend(d.detect(trajectory))
        except Exception as exc:  # pragma: no cover - defensive
            LOG.warning('detector %s raised: %s', d.id, exc)
    return out


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _state_signature(event: AgentEvent) -> str:
    """A compact, comparison-friendly view of an event's observable state."""
    return '|'.join([
        getattr(event.event_type, 'value', str(event.event_type)),
        str(event.agent_name or ''),
        str(event.module or ''),
        str(event.output or '')[:200],
        str(event.error or '')[:200],
    ])


def _normalize(value: object) -> str:
    text = '' if value is None else str(value)
    return ' '.join(text.split())


def _truncate(text: str, max_chars: int) -> str:
    if len(text) > max_chars:
        return text[:max_chars] + '…'
    return text


def _mode_count(items: List[str]) -> tuple[str, int]:
    counts: dict[str, int] = {}
    best: str = ''
    best_count = 0
    for it in items:
        counts[it] = counts.get(it, 0) + 1
        if counts[it] > best_count:
            best_count = counts[it]
            best = it
    return best, best_count


def _suggestion(mode: FailureMode) -> Optional[str]:
    if mode.suggestion_templates:
        return str(mode.suggestion_templates[0])
    return None


__all__ = [
    'Detector',
    'DetectorConfig',
    'RepeatedStateDetector',
    'RepeatedToolCallDetector',
    'StepCountLimitDetector',
    'default_detectors',
    'run_detectors',
]
