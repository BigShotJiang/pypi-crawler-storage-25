# 02 — System Architecture

AgentDebugX is organized as **seven layers**, each with a small, stable interface. Lower layers are framework-agnostic; only Layer 2 contains framework-specific code.

```
┌──────────────────────────────────────────────────────────────────────────┐
│ L7  UI / IDE / API                  Web Console · TUI · VSCode ext · REST│
├──────────────────────────────────────────────────────────────────────────┤
│ L6  Knowledge & Recommendation      Error DB · Similarity · Fix suggest │
├──────────────────────────────────────────────────────────────────────────┤
│ L5  Recovery                        Reflexion · Self-Refine · CRITIC ·  │
│                                     AutoManual · Saga rollback          │
├──────────────────────────────────────────────────────────────────────────┤
│ L4  Attribution                     All-at-Once · Step-by-Step · Bisect │
│                                     Counterfactual · SBFL · DeltaDebug  │
├──────────────────────────────────────────────────────────────────────────┤
│ L3  Detection                       Rule · Anomaly · LLM-Judge · Spec   │
├──────────────────────────────────────────────────────────────────────────┤
│ L2  Adapters & Capture              AutoGen · LangGraph · CrewAI ·      │
│                                     OpenAI Agents · OpenHands · …       │
├──────────────────────────────────────────────────────────────────────────┤
│ L1  Trace Substrate                 OTel GenAI spans · Event bus ·      │
│                                     Storage (SQLite/DuckDB/Parquet)     │
└──────────────────────────────────────────────────────────────────────────┘
```

The seven layers map to seven Python sub-packages under `agentdebugx/`.

## L1 — Trace substrate

**Responsibility:** capture, normalize, persist, and stream the canonical trace.

- **Wire format:** OpenTelemetry GenAI semantic conventions (`gen_ai.*` attributes). See [04_trace_schema.md](./04_trace_schema.md).
- **In-process event bus:** lightweight pub/sub for low-latency detectors that can't wait for OTel batch export. Modeled on CrewAI's `crewai_event_bus`.
- **Storage:** local SQLite (metadata) + DuckDB (queryable analytics) + Parquet (long-term archive). Optional sync to community corpus.
- **Exporters:** pluggable — OTLP (any OTel backend), Langfuse, AgentOps, Phoenix, OpenLLMetry, Weave, LangSmith.

**Key insight:** keep OTel spans for *export* and a parallel typed event bus for *introspection*. OTel SDK span processors are not ergonomic for "did the agent loop forever?" detection.

## L2 — Adapters & capture

**Responsibility:** translate each framework's native events into AgentDebugX events + OTel GenAI spans.

One adapter per framework, each ≤ 200 LOC, each using the framework's native extension point:

| Framework | Surface | LOC budget |
|---|---|---|
| AutoGen v0.4+ | `TracerProvider` parameter | 50 |
| AG2 | `register_hook` + OTel | 80 |
| LangChain / LangGraph | `BaseCallbackHandler` | 150 |
| CrewAI | `BaseEventListener` | 200 |
| OpenAI Agents SDK | `TracingProcessor` | 150 |
| OpenHands | `EventStream.subscribe` | 120 |
| smolagents | reuse `SmolagentsInstrumentor` | 30 |
| LlamaIndex | `Dispatcher` handlers | 150 |
| DSPy | `BaseCallback` | 80 |
| Pydantic-AI | `InstrumentationSettings` | 30 |
| MetaGPT | monkey-patch `Role`/`Environment` | 200 |
| Camel-AI | monkey-patch `ChatAgent.step` | 150 |
| Haystack | `tracing.Tracer` | 100 |
| ReAct/vanilla | OpenInference SDK instrumentors + `@trace_loop` decorator | 200 |

**Auto-detection:** `agentdebugx.init()` probes for installed frameworks (`try: import autogen ...`) and attaches matching adapters.

## L3 — Detection

**Responsibility:** scan trace + live event stream to produce `DetectedError` records.

Four detector families, all implementing a `Detector.detect(trace) -> list[DetectedError]` interface:

1. **Rule-based.** Static rules like *tool-name not in allowlist*, *args fail Pydantic validation*, *step count > N*, *repeated tool call with identical args > K times*. Cheapest; runs in process.
2. **Anomaly.** Perplexity over `(thought, action, observation)` units (TrajAD), repeated-state detection, embedding-novelty vs prior successful runs.
3. **LLM-as-Judge.** MAST-trained classifier + AgentDebug-trained classifier + custom user judges. Reuse MAST team's prompts.
4. **Spec / temporal logic** (v2). LTL assertions over event traces; LLM-synthesized monitors from natural-language specs (arXiv:2509.20364).

Each detector has a **cost class** (`free`, `cheap`, `expensive`) and a **trust score** (calibrated against AgentRewardBench). Default pipeline runs `free` → `cheap` → `expensive` and short-circuits when a high-confidence detection fires.

## L4 — Attribution

**Responsibility:** given a failing trace + detected errors, return ranked `Blame` hypotheses: `(agent_id, step_id, confidence, evidence, method)`.

Six backends behind one interface:

| Backend | Cost | Implementation |
|---|---|---|
| **All-at-Once** | $ | Single LLM call over whole trace |
| **Step-by-Step** | $$ | Sequential LLM calls per step |
| **Binary-Search** | $$ | Recursive bisection — `ddmin`-style |
| **Counterfactual-Replay** | $$$ | Re-rollout from candidate steps with oracle-corrected actions |
| **SBFL** (Tarantula/Ochiai) | $ | Suspiciousness scores from many passing/failing traces |
| **Delta-Debugging** (Zeller) | $$ | Minimize trace to smallest failing prefix |

All produce a unified `Blame` object. The pipeline can run multiple backends and merge via Bayesian or rank-aggregation (see [07_attribution.md](./07_attribution.md)).

## L5 — Recovery

**Responsibility:** given trace + errors + blame, propose or apply a fix.

| Strategy | Mechanism | When to use |
|---|---|---|
| **ReflexionMemory** | Verbal RL — write reflection to episodic memory for next attempt | Iterative per-task |
| **SelfRefineLoop** | Generator-critic-refiner cycle | Output-quality issues |
| **CRITIC** | Tool-grounded verification (search, code-exec, type-check) | Hallucination, factual errors |
| **AutoManualRules** | Extract rules from failures into a versioned manual | Long-term knowledge accumulation |
| **LangGraphRewind** | Replay from a checkpoint state | Crash / dead-end recovery |
| **SagaRollback** | Compensating actions for tool side-effects | Anything with real-world side effects |
| **MCTSBranchExploration** | LATS-style tree search with reflection | Combinatorial recovery |

Recovery is **suggest by default, apply opt-in**. Side-effect-touching tools must register a compensation function or AgentDebugX refuses to auto-apply.

## L6 — Knowledge & recommendation

**Responsibility:** store, search, and learn from the corpus of past errors.

- **Local corpus** (default): SQLite + DuckDB at `~/.agentdebugx/`.
- **Community corpus** (opt-in): hosted instance at `errors.agentdebugx.dev`. Versioned schema. PII-scrubbed by default.
- **Similarity search:** dual index — embedding (sentence-transformers) + structured (MAST FM + framework + tool involved).
- **Fix recommender:** for each new `DetectedError`, retrieve top-k similar past cases, surface their resolved fixes + an LLM-grounded synthesis.
- **Taxonomy induction:** background job runs TnT-LLM + BERTopic clustering on unlabeled corpus; surfaces candidate new failure modes for HITL review.

See [09_error_database.md](./09_error_database.md) and [10_taxonomy_induction.md](./10_taxonomy_induction.md).

## L7 — UI / IDE / API

- **REST + WebSocket API** under `agentdebugx.api`.
- **Web Console** — React + Vite app served by `agentdebugx serve`. Trace timeline, attribution panel, diff view (input vs counterfactual), error DB browser, taxonomy explorer.
- **TUI** — `agentdebugx tui` — terminal explorer (Textual).
- **VSCode extension** — inline trace browser, breakpoint-on-error, attribution overlay.
- **CLI** — `agentdebugx run`, `agentdebugx analyze`, `agentdebugx replay`, `agentdebugx publish`, `agentdebugx db search`.

See [12_ui_dashboard.md](./12_ui_dashboard.md).

---

## Data flow

```
┌─ user code ──┐    ┌── L2 adapter ──┐    ┌────── L1 substrate ─────┐
│ agent.run()  │ -> │ on_event(evt)   │ -> │ OTel span + event bus  │
└──────────────┘    └─────────────────┘    └────────┬───────────────┘
                                                    │
                                       ┌────────────┼────────────┐
                                       ▼            ▼            ▼
                                    L3 detect   L1 storage   L1 export
                                       │
                                       ▼
                                    DetectedError(s)
                                       │
                                       ▼
                                    L4 attribute
                                       │
                                       ▼
                                    Blame(s)
                                       │
                            ┌──────────┼──────────┐
                            ▼          ▼          ▼
                        L5 suggest  L6 similar  L7 UI
                                    cases
                                       │
                                       ▼
                                    Fix proposal
```

## Deployment modes

1. **Local-only** (default). All capture, storage, detection, attribution, recovery happen in-process or in a local sidecar (`agentdebugx serve`). No data leaves the user's machine.
2. **Hybrid.** Local execution + optional opt-in sync to community corpus (PII-scrubbed) for similarity search and corpus contribution.
3. **Self-hosted server.** Team deploys `agentdebugx-server` (Docker / Helm). Multiple agents push traces; central detection + UI; private error DB.
4. **Hosted (future).** Managed instance. Out of scope for v1.

## Process model

Default: in-process. `agentdebugx.init()` runs detectors inline via the event bus. For high-volume agents, switch to:

- **Sidecar mode** — adapters push to OTLP collector; collector runs detectors out-of-process.
- **Async pipeline** — detection deferred to a background worker (asyncio task queue or Celery).

Configured via `agentdebugx.init(mode="inline" | "sidecar" | "async")`.

## Thread / async safety

- All public APIs are async-safe.
- Adapters never block the agent's main loop — they emit into a bounded queue with backpressure metrics.
- LLM-judge detectors run asynchronously by default; rule detectors run inline.

## Failure isolation

AgentDebugX must **never break the host agent**. Every adapter wraps its hooks in a top-level `try/except` that logs to `agentdebugx.errors` and continues. A circuit-breaker disables a misbehaving adapter after N failures within a window.

## Runtime control plane

Claude Code's extension model suggests that AgentDebugX should not remain only
a passive trace collector. Long-term, it should expose a runtime control plane
with explicit lifecycle hooks, policy decisions, and context-budget accounting.
See [17_claude_code_design_patterns.md](./17_claude_code_design_patterns.md).

Key additions to fold into this architecture:

- **Lifecycle hooks:** `BeforeToolUse`, `AfterToolUse`, `BeforeHandoff`,
  `BeforeStop`, `BeforeRecoveryApply`, and related events.
- **Decision outcomes:** observe, annotate, block, escalate, rewrite, and retry.
- **Policy engine:** runtime-enforced allow/ask/deny rules, separate from model
  prompts.
- **Context budget ledger:** every detector, recoverer, taxonomy pack, and UI
  assistant declares load time, context cost, latency, and privacy surface.
- **Plugin packs:** adapters, detectors, attributors, recoverers, taxonomy axes,
  UI panels, MCP tools, and benchmark fixtures can ship outside core.
- **MCP server surface:** AgentDebugX should expose traces, reports, taxonomy,
  and similar-case search as MCP resources/tools so other agents can debug
  themselves through the same backend.
