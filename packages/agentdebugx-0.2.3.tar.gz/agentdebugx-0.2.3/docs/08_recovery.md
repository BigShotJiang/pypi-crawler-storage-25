# 08 — Recovery Strategies

## 1. Principles

- **Suggest by default, apply opt-in.** AgentDebugX always proposes; it applies only when the user explicitly enables `auto_apply=True` for a strategy.
- **No side-effect surprises.** Strategies that re-execute tools require explicit compensation registration. AgentDebugX refuses to retry write-class tools without a compensation.
- **Recovery emits explanation.** Every fix proposal includes the rationale, the source detector(s), and a confidence score.
- **Composable.** Recovery strategies chain: `Reflexion → Self-Refine → Re-run` is a common pattern.

## 2. Interface

```python
class Recoverer(Protocol):
    id: str
    applies_to: list[TaxonomyAxisId]  # which axes this strategy targets

    def suggest(self, trace: Trace, errors: list[DetectedError],
                blame: AttributionResult) -> list[FixProposal]:
        ...

    def apply(self, fix: FixProposal, ctx: ApplyContext) -> ApplyResult:
        ...

class FixProposal(BaseModel):
    id: str
    recoverer_id: str
    target_span_id: str
    summary: str                  # one-line description
    rationale: str
    confidence: float
    side_effects: list[SideEffect]
    requires_human_approval: bool
    apply_payload: dict           # opaque, recoverer-specific
    estimated_cost_usd: float | None
```

## 3. Strategies

### 3.1 ReflexionMemory

Verbal RL (Shinn et al. NeurIPS 2023, arXiv:2303.11366).

```python
class ReflexionMemory(Recoverer):
    id = "reflexion"
    applies_to = [TaxonomyAxisId.MAST_PATTERN, TaxonomyAxisId.AGENT_DEBUG]

    def suggest(self, trace, errors, blame):
        reflection = self._summarize_failure(trace, errors, blame)
        return [FixProposal(
            id=ULID(), recoverer_id=self.id,
            target_span_id=trace.root_span_id,
            summary=f"Add reflection to episodic memory: '{reflection[:60]}…'",
            rationale=reflection,
            confidence=0.6,
            side_effects=[SideEffect.MEMORY_WRITE],
            requires_human_approval=False,
            apply_payload={"reflection": reflection, "store": "episodic"},
        )]

    def apply(self, fix, ctx):
        ctx.memory_store.append(fix.apply_payload["reflection"])
        return ApplyResult(success=True)
```

### 3.2 SelfRefineLoop

Generator–critic–refiner (Madaan et al., NeurIPS 2023, arXiv:2303.17651).

Wraps a span's output in a critique → refine loop with configurable max-iters.

### 3.3 CRITIC (tool-grounded verification)

Gou et al., ICLR 2024, arXiv:2305.11738.

For output classes where an external tool can verify (search-grounded fact, code-exec for math, type-check for code), CRITIC invokes the tool and refines until pass-or-budget-exhausted.

```python
class CriticRecoverer(Recoverer):
    id = "critic"
    applies_to = [TaxonomyAxisId.GROUNDING, TaxonomyAxisId.AGENT_DEBUG]
    def __init__(self, verifiers: list[Verifier]): self.verifiers = verifiers
```

### 3.4 AutoManualRules

Chen et al., NeurIPS 2024, arXiv:2405.16247.

Persists learned-from-failure rules as a versioned "manual" — a `MANUAL.md` per project — auto-updated by AgentDebugX. The manual is injected into the agent's system prompt on the next run.

### 3.5 LangGraphRewind

For frameworks with native checkpointing (LangGraph today; others as they add it). Replays from the last stable checkpoint with a corrected next-step.

### 3.6 SagaRollback

For agents that touched real-world side effects. Each write-class tool registers a compensation function; SagaRollback unrolls in reverse order, invoking compensations.

```python
class SagaRollback(Recoverer):
    id = "saga_rollback"
    applies_to = [TaxonomyAxisId.TOOL_LAYER]
    def apply(self, fix, ctx):
        for action in reversed(ctx.trace.write_actions[:fix.apply_payload["up_to"]]):
            comp = action.tool.compensation
            if comp is None:
                return ApplyResult(success=False, reason="no compensation registered")
            comp(action.result)
```

### 3.7 MCTSBranchExploration

LATS (Zhou et al., ICML 2024, arXiv:2310.04406). Explores N alternative continuations from a candidate branch point; selects best by value model + reflection.

### 3.8 Recovery via similar-case retrieval (knowledge layer)

For each error, look up the top-k similar resolved cases in the error DB. Suggest the fix that resolved the most cases, plus an LLM-synthesized adaptation.

## 4. Strategy selection

```python
class Recoverer(Pipeline):
    strategies: list[Recoverer]

    def suggest(self, trace, errors, blame) -> list[FixProposal]:
        proposals = []
        for err in errors:
            for s in self.strategies:
                if _matches(s.applies_to, err.labels):
                    proposals.extend(s.suggest(trace, [err], blame))
        return _rank(proposals)
```

Default strategy mapping:

| Detected error axis | Default strategy |
|---|---|
| `M.MEM` / `FM-1.4` | ReflexionMemory + AutoManualRules |
| `M.REF` / FC3 | SelfRefineLoop + CriticRecoverer |
| `M.PLN` / FC1 | MCTSBranchExploration (if budget allows) else ReflexionMemory |
| `M.ACT` / `TL.*` | CriticRecoverer + similar-case retrieval |
| `M.SYS` | LangGraphRewind / SagaRollback |
| `SEC.*` | Surface to UI; never auto-apply |

## 5. Apply contexts

```python
class ApplyContext(BaseModel):
    framework: FrameworkId
    memory_store: MemoryStore | None     # for Reflexion / AutoManual
    runtime: RuntimeHandle | None        # for re-execution
    user_approval: ApprovalToken | None
```

Apply requires runtime access (a live agent or a re-runnable spec). For frameworks that don't support re-execution, AgentDebugX downgrades to suggest-only.

## 6. Auto-apply policy

```python
agentdebugx.init(
    recovery=RecoveryConfig(
        auto_apply=["reflexion", "self_refine"],   # safe — no external side effects
        require_approval=["critic", "mcts_branch"],
        never_auto=["saga_rollback"],
    )
)
```

Recovery apply should be policy-aware. A proposal can be safe in isolation but
unsafe in the current runtime because of tool permissions, user settings, side
effects, or organization policy. The apply pipeline should therefore run:

1. `BeforeRecoveryApply` hook.
2. Policy engine allow/ask/deny evaluation.
3. Human approval when the policy asks or the proposal declares side effects.
4. Compensation check for write/external tools.
5. Apply.
6. `AfterRecoveryApply` hook and `FixApplied` telemetry.

This mirrors the Claude Code separation between what the model wants to do and
what the runtime is allowed to execute. Prompt instructions can suggest caution,
but only the policy layer can authorize side effects.

## 7. Approval workflow

When `requires_human_approval=True`, the proposal is queued and surfaced in:

- The web Console (with diff view, click-to-approve).
- A Slack/Discord webhook (optional).
- The TUI.

After approval, `apply()` runs and the result is logged with audit trail.

## 8. Recovery telemetry

Every applied fix emits a `FixApplied` event:

```python
class FixAppliedEvent(BaseModel):
    fix_id: str
    recoverer_id: str
    applied_at: datetime
    success: bool
    follow_up_run_id: str | None
    outcome: Literal["improved", "no_change", "regressed", "unknown"]
```

The outcome is determined by the next run's error count vs baseline; this feeds back into the recommendation ranking — fixes that historically improved outcomes for similar errors rank higher.

## 9. The "no fix" case

For irreducible failures (e.g., model capability ceiling), AgentDebugX explicitly emits a `NoFixProposal`:

```python
NoFixProposal(
    rationale="No known recovery strategy applies. Recommended: switch to a stronger "
              "model, or add a manual review gate before commit.",
    references=[similar_unresolved_cases]
)
```

This is important — silently ranking nonsense fixes is worse than admitting we don't know.

## 10. StopGate recovery primitive

A `StopGate` prevents a run from being marked successful until required
conditions are satisfied. It is useful for premature-stop, missing-verification,
and false-success failures.

```python
class StopGate(Recoverer):
    id = "stop_gate"

    def before_stop(self, trace: Trace) -> DecisionRecord:
        """
        Return allow, block, escalate, or retry.
        """
```

Example checks:

- final success criteria all verified,
- no unresolved critical errors,
- required artifacts exist,
- final answer cites the necessary evidence,
- write-class actions have compensation or approval,
- user-facing answer matches tool-observed state.

When a stop gate blocks completion, the event becomes direct evidence for
attribution and recovery.
