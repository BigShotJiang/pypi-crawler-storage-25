# 14 — Public API Reference (Sketch)

This is the *user-facing contract* for `agentdebugx`. Anything not listed here is internal and may change between minor versions.

## 1. Init / lifecycle

```python
import agentdebugx

agentdebugx.init(
    project: str = "default",
    *,
    profile: Literal["fast","balanced","thorough","audit"] = "balanced",
    detect: list[str] | None = None,
    attribute: str | list[str] | None = "ensemble",
    recovery: RecoveryConfig | None = None,
    sync: SyncConfig | None = None,
    storage_dir: Path | None = None,
    mode: Literal["inline","sidecar","async"] = "inline",
    exporters: list[str] | None = None,
    llm: LLMConfig | None = None,
    context_budget: ContextBudgetConfig | None = None,
    policy: PolicyConfig | None = None,
) -> Tracer
```

```python
agentdebugx.shutdown() -> None
agentdebugx.is_active() -> bool
agentdebugx.tracer() -> Tracer       # current global tracer
agentdebugx.status() -> RuntimeStatus
```

## 1.1 Runtime hooks and policy

```python
from agentdebugx.runtime import (
    HookPoint, HookDecision, DecisionRecord,
    register_hook, PolicyConfig, PermissionRule,
)

@register_hook(HookPoint.BEFORE_TOOL_USE, matcher="send_email")
def require_approval(evt) -> HookDecision:
    return HookDecision.escalate("Email sends require approval")

agentdebugx.configure_policy(PolicyConfig(
    rules=[
        PermissionRule.deny("Bash", pattern="rm -rf *"),
        PermissionRule.ask("Tool", name="send_email"),
        PermissionRule.allow("Read"),
    ]
))
```

Hook decisions become trace records, so live controls are available to offline
detectors, attribution, and audit exports.

## 2. Inspecting runs

```python
agentdebugx.last_run() -> Run
agentdebugx.runs(limit: int = 50, project: str | None = None) -> list[Run]
agentdebugx.get_run(run_id: str) -> Run

Run.summary() -> str
Run.errors() -> list[DetectedError]
Run.blame() -> AttributionResult
Run.fixes() -> list[FixProposal]
Run.trace() -> Trace
Run.replay(from_step: int, **kw) -> Run
Run.open_in_console() -> None        # opens the web UI to this run
Run.to_json() -> dict
Run.to_parquet(path: Path) -> None
```

## 3. Vanilla-loop helpers

```python
@agentdebugx.trace_loop(name: str | None = None,
                        framework: FrameworkId = FrameworkId.VANILLA)
def my_loop(...): ...

agentdebugx.step(
    *,
    observation: Any = None,
    label: str | None = None,
    span_attributes: dict | None = None,
) -> None

agentdebugx.mark_done(result: Any = None) -> None
agentdebugx.mark_failed(reason: str) -> None
```

## 4. Detection

```python
from agentdebugx.detect import (
    Detector, DetectionPipeline, register,
    DetectContext, DetectedError, LabelSet, Severity,
)

# Run detection on a captured trace
pipeline = DetectionPipeline.from_profile("balanced")
errors = pipeline.run(run.trace())

# Register a custom detector
@register
class MyDetector(Detector): ...
```

## 5. Attribution

```python
from agentdebugx.attribute import (
    Attributor, EnsembleAttributor, AttributionBudget,
    AllAtOnceAttributor, StepByStepAttributor, BinarySearchAttributor,
    CounterfactualAttributor, SBFLAttributor, DeltaDebugAttributor,
)

attributor = EnsembleAttributor(backends=[
    AllAtOnceAttributor(model="gpt-4o"),
    StepByStepAttributor(model="gpt-4o-mini"),
    CounterfactualAttributor(n_rollouts=5),
], budget=AttributionBudget(max_usd=0.50))

result = attributor.attribute(run.trace(), run.errors())
for blame in result.hypotheses:
    print(blame.agent_id, blame.step_index, blame.confidence, blame.rationale)
```

## 6. Recovery

```python
from agentdebugx.recover import (
    Recoverer, ReflexionMemory, SelfRefineLoop, CriticRecoverer,
    AutoManualRules, LangGraphRewind, SagaRollback, MCTSBranchExploration,
)

recoverer = Recoverer(strategies=[
    ReflexionMemory(),
    SelfRefineLoop(max_iters=3),
    CriticRecoverer(verifiers=["search","code_exec"]),
])

proposals = recoverer.suggest(run.trace(), run.errors(), run.blame())

# Apply (with explicit consent for side-effects)
for p in proposals:
    if not p.requires_human_approval:
        result = recoverer.apply(p, ctx=run.apply_context())
```

## 7. Replay

```python
from agentdebugx.replay import Replayer

replayer = Replayer(trace=run.trace())
new_run = replayer.from_step(
    step_index=4,
    oracle_correction=lambda step: {"tool_args": {...}},  # callable or None
    mock=True,
)
```

## 8. Corpus

```python
from agentdebugx.corpus import Corpus

corpus = Corpus(backend="local")  # or "hosted"
corpus.add(run, labels=[LabelSet(...)])
hits = corpus.similar_to(run.trace(), k=10)
df = corpus.sql("SELECT framework, count(*) FROM records GROUP BY 1")
corpus.publish("rec_01J…")
```

## 9. Taxonomy

```python
from agentdebugx.taxonomy import Registry, TaxonomyAxis, TaxonomyCode

Registry.codes(axis="MAST_PATTERN") -> list[TaxonomyCode]
Registry.get("FM-2.3") -> TaxonomyCode
Registry.add_axis(TaxonomyAxis(id="biz", codes=[...]))
Registry.crosswalk("FM-2.3", to="AGENT_DEBUG_MODULE") -> list[str]
```

## 10. Server / UI

```python
agentdebugx.serve(port: int = 7777, host: str = "127.0.0.1") -> None
agentdebugx.tui() -> None

from agentdebugx.ui.embed import trace_widget
trace_widget(run_id="tr_01J…")
```

## 11. CLI surface

```bash
agentdebugx init
agentdebugx run <script.py> [args…]
agentdebugx attach <pid>
agentdebugx serve [--port 7777] [--host 127.0.0.1]
agentdebugx tui
agentdebugx analyze <run_id> [--detectors …] [--attributors …]
agentdebugx replay <run_id> [--from-step N] [--oracle-script F]
agentdebugx bench <suite> [--backend …]
agentdebugx publish <run_id|--since 7d> [--dry-run]
agentdebugx db search "<query>" [--limit N] [--axes …]
agentdebugx db export <path> [--format parquet|json]
agentdebugx taxonomy show [--axis MAST_PATTERN]
agentdebugx taxonomy export --format yaml|json|md
agentdebugx doctor
```

## 11.1 Current shipped `agentdebug` CLI surface

The public design above is the long-term `agentdebugx` contract. The current
package already ships a smaller but working `agentdebug` CLI:

```bash
agentdebug analyze <trajectory.json> [--suggest] [--traceback]
agentdebug list --store-sqlite .agentdebug/errors.sqlite
agentdebug show <trace_id> --store-sqlite .agentdebug/errors.sqlite
agentdebug judge <trajectory.json|trace_id> --attribute [--traceback]
agentdebug deep <trajectory.json|trace_id> [--traceback]
agentdebug hub push <trace_id> --to local:/tmp/hub --store-sqlite ...
agentdebug hub pull <spec> --bundle <bundle_id> --into .agentdebug/hub_pulls
agentdebug hub list <spec>
agentdebug integrations skill --target ~/.claude/skills --name agentdebug
agentdebug integrations openhands-microagent --target .openhands/microagents
agentdebug serve --store-sqlite .agentdebug/errors.sqlite --port 7777
agentdebug doctor
```

`--traceback` renders `AgentTraceback`, a Python-traceback-style cascade view
implemented by `agentdebug.traceback.format_traceback(report, trajectory)`.
DeepDebug can provide explicit cascade edges through
`finding.metadata['cascading_from_event_id']`; heuristic and single-pass judge
reports fall back to step-index ordering.

## 12. Configuration file

`~/.agentdebugx/settings.yaml`:

```yaml
project: my-agent
profile: balanced
storage_dir: ~/.agentdebugx
mode: inline

redaction:
  scrub_pii: true
  scrub_secrets: true

detectors:
  enabled:
    - repeated_tool_call
    - tool_arg_schema_violation
    - mast_judge
  thresholds:
    repeated_tool_call: 3
    step_count_exceeded: 30

attribution:
  default: ensemble
  ensemble:
    backends: [all_at_once, step_by_step, counterfactual]
    weights:  {all_at_once: 0.3, step_by_step: 0.3, counterfactual: 0.4}
  budget:
    max_usd: 0.50
    max_llm_calls: 20

recovery:
  auto_apply: [reflexion, self_refine]
  require_approval: [critic, mcts_branch]
  never_auto: [saga_rollback]

sync:
  enabled: false
  only_failed: true
  scrub_pii: true
  license: CC-BY-4.0

llm:
  judge_model: gpt-4o
  judge_temperature: 0.0
  embedding_model: text-embedding-3-small

exporters:
  - langfuse
  - phoenix
```

Environment variables follow the prefix `AGENTDEBUGX_*` and nested delimiter `__`:

```
AGENTDEBUGX_PROJECT=my-agent
AGENTDEBUGX_DETECTORS__ENABLED='["repeated_tool_call","mast_judge"]'
AGENTDEBUGX_ATTRIBUTION__BUDGET__MAX_USD=1.0
```

## 13. Stability guarantees

- **Stable since v0.1**: `init`, `last_run`, `Run`, `Trace`, `Span`, schema models, CLI commands listed above.
- **Experimental (`agentdebugx.experimental.*`)**: multimodal capture, LTL spec monitors, fine-tuned attributor, hosted corpus.
- **Internal (`agentdebugx._*`)**: no compatibility guarantees.

We follow semver. Breaking changes only on major version bumps with ≥ 1 minor of deprecation notice.
