# 01 — Literature Survey

This is the consolidated literature foundation for AgentDebugX. Every design decision in the rest of `docs/` cites work here. Citations were verified against arXiv / GitHub at survey time (May 2026); if you re-validate, flag any retracted or revised work.

---

## A. Core agent-debugging papers

### A.1 AgentDebug — "Where LLM Agents Fail and How They Can Learn From Failures"
- **Authors:** Zhu, Liu, Li, Tian, Yang, Zhang, Han, Xie, Cui, Zhang, Ma, Yu, Ramesh, Wu, Liu, Lu, Zou, You (UIUC ULab + collaborators)
- **arXiv:** 2509.25370 — Sep 2025
- **Repo:** https://github.com/ulab-uiuc/AgentDebug
- **Contributions:**
  - **AgentErrorTaxonomy** — 5-module failure taxonomy: *memory, reflection, planning, action, system*.
  - **AgentErrorBench** — annotated trajectories from ALFWorld, GAIA, WebShop.
  - "Detect → localize root cause → emit corrective feedback" loop. +24% all-correct, +17% step accuracy vs strongest baseline; +26% relative task success after feedback recovery.
  - Frames failures as **cascades** from a single early root cause.
- **AgentDebugX use:** ship the 5-module taxonomy as the **single-agent axis**; ship `AgentErrorBench` loaders as regression suite; mirror the cascade-detection loop as default detector pipeline.

### A.2 MAST — "Why Do Multi-Agent LLM Systems Fail?"
- **Authors:** Cemri, Pan, Yang, Agrawal, Chopra, Tiwari, Keutzer, Parameswaran, Klein, Ramchandran, Zaharia, Gonzalez, Stoica (Berkeley)
- **arXiv:** 2503.13657 — Mar 2025 (ICLR 2025)
- **Repo:** https://github.com/multi-agent-systems-failure-taxonomy/MAST
- **Dataset:** https://huggingface.co/datasets/mcemri/MAD (1,600+ traces, κ=0.88)
- **14 failure modes / 3 categories:**
  - **FC1 — Specification & System Design:** FM-1.1 Disobey task spec, FM-1.2 Disobey role spec, FM-1.3 Step repetition, FM-1.4 Loss of conversation history, FM-1.5 Unaware of termination conditions.
  - **FC2 — Inter-Agent Misalignment:** FM-2.1 Conversation reset, FM-2.2 Fail to ask for clarification, FM-2.3 Task derailment, FM-2.4 Information withholding, FM-2.5 Ignored other agent's input, FM-2.6 Reasoning–action mismatch.
  - **FC3 — Task Verification & Termination:** FM-3.1 Premature termination, FM-3.2 No/incomplete verification, FM-3.3 Incorrect verification.
- **Frameworks studied:** MetaGPT, ChatDev, HyperAgent, AppWorld, AG2, AutoKaggle, Multi-Agent Peer Review.
- **AgentDebugX use:** the MAS-level axis of AgentDebugX-Tax v0.1; reuse the LLM-as-Judge auto-labeler; ship `MAD` as MAS regression benchmark.

### A.3 "Which Agent Causes Task Failures and When?" (Who&When)
- **Authors:** Zhang, Yin, Zhang, Liu, Han, Zhang, Li, Wang, Wang, Chen, Wu (Penn State / Duke / UW / MSFT / OSU)
- **arXiv:** 2505.00212 — May 2025 (ICML 2025 Spotlight)
- **Repo:** https://github.com/mingyin1/Agents_Failure_Attribution
- **Three attribution methods:**
  - **All-at-Once** — feed whole trace, ask judge to point to blame.
  - **Step-by-Step** — sequential scan, "is this step the failure?"
  - **Binary Search** — recursive bisection of the trace.
- **Who&When dataset:** failure logs from 127 multi-agent systems with fine-grained agent + step labels.
- **Headline numbers:** best method ~53.5% agent ID, ~14.2% step ID — even o1 and DeepSeek-R1 are near random for step localization.
- **AgentDebugX use:** the three methods become three swappable `Attributor` backends; `Who&When` becomes attribution benchmark; honest reporting of low ceilings shapes UX (show confidence + counterfactual evidence, never single-point claims).

### A.4 AgenTracer — "Who Is Inducing Failure in the LLM Agentic Systems?"
- **arXiv:** 2509.03312 — Sep 2025
- **Contributions:**
  - **Counterfactual replay** — swap an agent's action with an oracle correction and re-simulate.
  - **Programmatic fault injection** — perturb successful traces to synthesize labeled failures.
  - **AgenTracer-8B** — small fine-tuned attributor beating Gemini-2.5-Pro and Claude-4-Sonnet by +18% on attribution.
  - +4.8–14.2% downstream task success when fed back to MetaGPT/MaAS.
- **AgentDebugX use:** counterfactual replay + fault injection are first-class debugging primitives; AgentDebugX v2 ships a fine-tuned attribution model.

---

## B. Self-correction / recovery

| Paper | Mechanism | AgentDebugX use |
|---|---|---|
| **Reflexion** — Shinn et al., NeurIPS 2023, arXiv:2303.11366, [repo](https://github.com/noahshinn/reflexion) | Verbal RL — evaluator → reflection → episodic memory | `ReflectionMemory` recovery component |
| **Self-Refine** — Madaan et al., NeurIPS 2023, arXiv:2303.17651, [repo](https://github.com/madaan/self-refine) | Generator–critic–refiner loop, no training | Generic refine-loop primitive |
| **CRITIC** — Gou et al., ICLR 2024, arXiv:2305.11738 | Tool-grounded self-critique (search/code/calculator) | Tool-grounded verifiers as first-class judges |
| **RCI** — Kim, Baldi, McAleer, arXiv:2303.17491, [repo](https://github.com/posgnu/rci-agent) | Recursive criticism & improvement on computer tasks | `patch_in_place` vs `regenerate_with_critique` recovery modes |
| **AutoManual** — Chen et al., NeurIPS 2024, arXiv:2405.16247, [repo](https://github.com/minghchen/automanual) | Planner+Builder+Formulator agents synthesize a learned manual; 97.4% ALFWorld | Persist learned rules as versioned manual artifact |
| **AgentVerse** — Chen et al., ICLR 2024, arXiv:2308.10848, [repo](https://github.com/OpenBMB/AgentVerse) | Dynamic group recomposition + verification phase | Verification phase as debug hook before commit |
| **LATS** — Zhou et al., ICML 2024, arXiv:2310.04406 | MCTS + LM value function + reflection | Counterfactual / branch-replay primitive |
| **ETO** — Song et al., ACL 2024, arXiv:2403.02502, [repo](https://github.com/Yifan-Song793/ETO) | Exploration-based Trajectory Optimization → (fail,success) pairs for DPO | Emit AgentDebugX failure traces in ETO-ready format |
| **RAP** — Hao et al., EMNLP 2023, arXiv:2305.14992 | LM-as-world-model + MCTS planning | MCTS counterfactual rollouts |
| **SagaLLM** — arXiv:2503.11951 | Saga pattern: compensating actions per node + semantic guards | Tool side-effect rollback layer |
| **Speculative Actions** — arXiv:2510.04371 | Idempotent/sandboxed speculative execution + repair paths | Latency-critical recovery |
| **Multi-Agent Debate** — Du, Li, Tenenbaum, Mordatch, arXiv:2305.14325 | Multiple agents argue toward consensus | Ship as **optional** recovery; 2025 follow-ups show it often underperforms self-consistency |

---

## C. Agent-as-a-Judge / LLM-as-a-Judge

- **Agent-as-a-Judge** — Zhuge et al. (Meta+KAUST), arXiv:2410.10934 — judge inspects intermediate steps + tool calls; DevAI benchmark (55 tasks, 365 hierarchical requirements).
- **AgentRewardBench** — arXiv:2504.08942 — calibrates web-agent trajectory evaluators against human annotators.
- **A Survey on LLM-as-a-Judge** — Li et al., EMNLP 2025, arXiv:2411.15594 — checklist for positional bias / self-bias / preference leakage.

**AgentDebugX use:** `AgentJudge` interface walks the trace (not just the final answer); built-in judges calibrated against AgentRewardBench / DevAI before release; reliability checklist enforced in `tests/judges/`.

---

## D. Benchmarks

| Benchmark | arXiv | Failure labels? |
|---|---|---|
| **GAIA** (Mialon et al., Meta) | 2311.12983 | Correctness only |
| **SWE-bench** (Jimenez et al.) | 2310.06770 | Patch correctness; Verified subset |
| **AppWorld** (Trivedi et al.) | 2407.18901 | State-based checks |
| **AgentBench** (Liu et al., THUDM) | 2308.03688 | Per-env mechanical codes (TLE/CLE/IF/IA) |
| **AgentBoard** (HKUST-NLP) | 2401.13178 | Capability dimensions (memory/planning/world-model/retrospection/grounding/spatial) |
| **Mind2Web** | 2306.06070 | Step correctness only |
| **WebArena** | 2307.13854 | Programmatic state checks |
| **OSWorld** | 2404.07972 | 369 real OS tasks; best model 12.2% vs human 72.4% |
| **τ-bench / τ²** (Sierra) | 2406.12045 | 4 auto-labels: goal-partial, wrong-tool, wrong-arg, unintended-action |
| **AgentErrorBench** | 2509.25370 | **5-class taxonomy** |
| **MAD** | 2503.13657 | **14-class MAST labels** |
| **Who&When** | 2505.00212 | **Agent + step blame labels** |

**AgentDebugX use:** ship loaders for all; project ad-hoc per-benchmark signals into AgentDebugX-Tax to produce the first unified cross-benchmark failure corpus.

---

## E. Observability tooling

| Tool | URL | Stance |
|---|---|---|
| **LangSmith** | https://www.langchain.com/langsmith | Closed-source SaaS; OTel exporter; tight LangChain coupling |
| **Langfuse** | https://github.com/langfuse/langfuse | OSS, OTel-native, 50+ connectors |
| **AgentOps** | https://github.com/AgentOps-AI/agentops | OSS, per-framework monkey-patching, 400+ LLM integrations |
| **Helicone** | https://github.com/Helicone/helicone | Apache-2.0 gateway |
| **Phoenix / Arize** | https://github.com/Arize-ai/phoenix | OpenInference (OTel) auto-instrumentors |
| **Opik (Comet)** | https://github.com/comet-ml/opik | OSS; OpenInference + native SDK |
| **Traceloop OpenLLMetry** | https://github.com/traceloop/openllmetry | Pure OTel SDK |
| **Weave (W&B)** | https://github.com/wandb/weave | Decorator-style + OpenInference compat |
| **DeepEval** | https://github.com/confident-ai/deepeval | Pytest-style LLM eval |
| **RAGAS** | https://github.com/explodinggradients/ragas | RAG metrics |
| **Inspect AI (UK AISI)** | https://github.com/UKGovernmentBEIS/inspect_ai | Reproducible eval framework; sandboxed exec; log viewer |

**Standard schema:** [OpenTelemetry GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/) — `gen_ai.*` namespace, currently *Development* stability. Multi-agent conventions tracked in OTel GenAI SIG.

**AgentDebugX use:** standardize on OTel GenAI semconv for the wire format; ship exporters for Langfuse, AgentOps, Phoenix, OpenLLMetry, Weave, LangSmith; integrate with Inspect AI for reproducible reruns.

---

## F. Agent framework targets

| Framework | Repo | Adapter strategy |
|---|---|---|
| **AutoGen v0.4+** | microsoft/autogen | Native OTel: pass `tracer_provider` to `SingleThreadedAgentRuntime`; stdlib loggers `TRACE_LOGGER_NAME`/`EVENT_LOGGER_NAME` |
| **AG2** | ag2ai/ag2 | `ConversableAgent.register_hook` + built-in OTel |
| **Microsoft Agent Framework (MAF)** | rolling | Plan target (AutoGen+Semantic Kernel successor) |
| **LangChain / LangGraph** | langchain-ai/langgraph | `BaseCallbackHandler` from `langchain_core.callbacks`; OTel via LangSmith exporter or OpenInference's `LangChainInstrumentor` |
| **CrewAI** | crewAIInc/crewAI | `BaseEventListener` + `crewai_event_bus` singleton; 50+ event types |
| **OpenAI Agents SDK** | openai/openai-agents-python | `agents.tracing.add_trace_processor` |
| **OpenAI Swarm** (archived) | openai/swarm | n/a — migrate users to Agents SDK |
| **OpenHands** (← user's "openclaw") | All-Hands-AI/OpenHands | `EventStream.subscribe(EventStreamSubscriber.MAIN, …)` |
| **smolagents** | huggingface/smolagents | `openinference.instrumentation.smolagents.SmolagentsInstrumentor().instrument()` |
| **LlamaIndex** | run-llama/llama_index | `llama_index.core.instrumentation.get_dispatcher()` + handlers |
| **Haystack 2.x** | deepset-ai/haystack | `haystack.tracing.Tracer` |
| **DSPy** | stanfordnlp/dspy | `dspy.configure(callbacks=[…])`; `BaseCallback` |
| **Pydantic-AI** | pydantic/pydantic-ai | `Agent.instrument_all(InstrumentationSettings(...))` — OTel-native |
| **MetaGPT** | FoundationAgents/MetaGPT | Monkey-patch `Role._think/_act` + `Environment.publish_message` |
| **ChatDev** | OpenBMB/ChatDev | Monkey-patch role hooks |
| **Camel-AI** | camel-ai/camel | Monkey-patch `ChatAgent.step` + model wrappers |
| **Mastra (TS)** | mastra-ai/mastra | OTel — future via OTel collector bridge |
| **Agency Swarm** | VRSEN/agency-swarm | Built on OpenAI Agents SDK — covered by that adapter |
| **ReAct** | (pattern) | Auto-instrument OpenAI/Anthropic SDKs via OpenInference; `@agentdebugx.trace_loop` decorator |

---

## G. Causal-attribution / fault-localization borrowed from non-agent fields

- **Delta Debugging** — Zeller & Hildebrandt, IEEE TSE 2002 — binary-bisection minimization of failure-inducing input. Direct analogue of Who&When's Binary-Search; AgentDebugX implements `ddmin` over agent traces with mocked env replay.
- **Spectrum-Based Fault Localization (SBFL):** Tarantula (Jones & Harrold, ICSE 2002), Ochiai (Abreu et al. 2007), DStar, Jaccard. Cheap, model-free suspiciousness scores per step from passing/failing traces of the same task. AgentDebugX ships SBFL as a baseline attribution backend.
- **RCAgent** — arXiv:2310.16340 — LLM-based root cause analysis in cloud incidents.
- **"Exploring LLM-based Agents for RCA"** — arXiv:2403.04123.
- **Microservices RCA survey** — arXiv:2408.00803.
- **"An Empirical Study of Bugs in Modern LLM Agent Frameworks"** — late 2025 — 998 bugs in CrewAI + LangChain; 15-cause × 7-symptom taxonomy across 5 lifecycle stages. Bundle as static + runtime check rulepack.

---

## H. Taxonomy induction

- **TnT-LLM** — Wan et al., KDD 2024, arXiv:2403.12173 — two-phase LLM-driven taxonomy proposal + classifier bootstrap. Applied to Bing Copilot intent discovery. **Novel for agent failures.**
- **BERTopic** (embed → UMAP → HDBSCAN → c-TF-IDF). De facto standard for unsupervised topic discovery; one-topic-per-doc limitation.
- **LLMs4SchemaDiscovery** — arXiv:2504.00752 — 3-stage HITL schema mining (LLM proposes, human refines, finalize). Adopted as AgentDebugX community-contributor pipeline.
- **LOGOS** — arXiv:2509.24294 — LLM-driven grounded theory.
- **Cost-aware Active Learning for LLMs** — ACL 2025, arXiv:2502.11767 — prioritization of which traces to label.

---

## I. Multimodal / GUI agent debugging

- **Claude Computer Use** (Anthropic, Oct 2024) — desktop-control reference + sandbox.
- **OpenAI CUA / Operator** (Jan 2025) — [openai/openai-cua-sample-app](https://github.com/openai/openai-cua-sample-app).
- **trycua** — https://github.com/trycua/cua — OSS CU sandboxes/benchmarks.
- **OSWorld** — 12.2% best vs 72.4% human; failure dominated by GUI grounding + operational knowledge gaps.
- **OSWorld-MCP** — arXiv:2510.24563 — adds MCP tool invocation axis.
- **NUS Show Lab** — third-party CU eval; failure clusters: visual grounding, action-after-state-change, modal confusion.

**AgentDebugX use:** v2 visual trace recorder (DOM/screenshot diff per step); perception/grounding/action/planning multimodal sub-taxonomy orthogonal to text taxonomy.

---

## J. Runtime detection — primary references

- **TrajAD** — arXiv:2602.06443 — perplexity over `(thought, action, observation)` units for trajectory anomaly. High false-positive on legitimate exploration.
- **SentinelAgent** — arXiv:2505.24201 — live execution-graph monitor.
- **NVIDIA NeMo Guardrails** — https://github.com/NVIDIA-NeMo/Guardrails — Colang DSL for input/output moderation, jailbreak detection, tool allowlist. Production-ready.
- **"Approach to Checking Correctness for Agentic Systems"** — arXiv:2509.20364 (RV 2025) — LTL over tool-call/state-transition events.
- **"The Power of Reframing"** (RV 2025) — LLM-synthesized RV monitors from natural-language specs.

---

## K. Synthesis — the gaps AgentDebugX fills

1. **No standard error taxonomy** → adopt MAST-14 + AgentDebug-5 as parallel axes, plus security/tool/grounding extensions.
2. **No common trace schema** → adopt OTel GenAI semconv; contribute back to OTel GenAI SIG on multi-agent extensions.
3. **Attribution methods never benchmarked together** → ship All-at-Once, Step-by-Step, Binary-Search, Counterfactual-Replay, SBFL, Delta-Debugging behind one interface and run head-to-head on Who&When + MAD + AgentErrorBench.
4. **Recovery is fragmented** → unified `Recoverer` interface dispatching to Reflexion / Self-Refine / CRITIC / AutoManual / Saga rollback.
5. **No cross-benchmark unified failure corpus** → project all loaded benchmarks into AgentDebugX-Tax.
6. **Multimodal failures under-taxonomized** → v2 perception/grounding sub-tree.
7. **Framework instrumentation is uneven** → 1-line `agentdebugx.init()` adapters for every major framework.
8. **No reproducible "agent regression test" workflow** → Inspect AI integration.

The clearest unmet need: **"plug AgentDebugX into any of the 12+ agent frameworks and get standardized, attributed, recoverable failure traces."**
