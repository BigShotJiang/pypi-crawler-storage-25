# Seed Error Taxonomy

AgentDebugX starts with a seed taxonomy and expects projects to extend it with
domain-specific labels. The initial set is intentionally broad enough to support
single-agent, multi-agent, tool-use, UI, and multimodal workflows.

## Families

- Memory: missing, stale, or hallucinated context.
- Reflection: bad self-evaluation or wrong causal explanation.
- Planning: flawed plans, ignored constraints, impossible actions, or loops.
- Action: wrong tool, invalid action, malformed output, or bad parameters.
- System: tool, environment, infrastructure, or model-limit failures.
- Multiagent: handoff loss, role drift, agent conflict, or coordination failure.
- Verification: missing final checks or premature termination.
- Multimodal: errors from screenshots, audio, video, UI trees, files, or visual
  grounding.

## Initial Modes

The live definitions are in `agentdebug.taxonomy.SEED_FAILURE_MODES`.

| Mode ID | Family | Purpose |
| --- | --- | --- |
| `memory.retrieval_failure` | memory | Relevant prior state or context was not retrieved. |
| `memory.hallucination` | memory | Invented state is treated as remembered fact. |
| `reflection.progress_misjudge` | reflection | The agent incorrectly judges task progress. |
| `reflection.causal_misattribution` | reflection | The agent blames the wrong cause. |
| `planning.constraint_ignorance` | planning | The plan ignores task, policy, or environment constraints. |
| `planning.impossible_action` | planning | The agent plans an unavailable action. |
| `planning.inefficient_plan` | planning | The agent loops or wastes steps without progress. |
| `action.wrong_tool` | action | The agent selects an inappropriate tool. |
| `action.invalid_action` | action | The selected action is invalid for the environment. |
| `action.format_error` | action | Output or arguments are malformed. |
| `action.parameter_error` | action | Tool parameters are missing, invalid, or hallucinated. |
| `system.tool_execution_error` | system | Tool/API/browser/environment execution failed. |
| `system.llm_limit` | system | Context, rate, token, refusal, or model capability limit. |
| `system.environment_error` | system | External environment changes or noisy observations misled the agent. |
| `multiagent.handoff_loss` | multiagent | Handoff dropped constraints, rationale, or evidence. |
| `multiagent.role_drift` | multiagent | Agent acts outside assigned responsibility. |
| `verification.missing_task_validation` | verification | Completion accepted without independent verification. |
| `verification.premature_stop` | verification | Agent stops before satisfying the task. |
| `multimodal.perception_error` | multimodal | Image, UI, audio, video, or file perception is wrong. |

## Taxonomy Generation Proposal

The automated taxonomy generator should:

1. Normalize incoming failed traces into the shared trajectory IR.
2. Run deterministic checks and existing classifiers.
3. Embed findings, evidence snippets, tool schemas, and final outcomes.
4. Cluster failures with similar symptoms and causal evidence.
5. Propose new labels only when existing labels have low confidence.
6. Produce label definitions with signals, counterexamples, and suggested fixes.
7. Ask a human maintainer to accept, merge, split, or reject proposals.
8. Track whether accepted labels improve future localization or recovery.

Generated taxonomy nodes should carry:

- `mode_id`
- `family`
- `description`
- `positive_signals`
- `negative_signals`
- `example_event_ids`
- `suggestion_templates`
- `source_trace_ids`
- `review_status`
- `version`
