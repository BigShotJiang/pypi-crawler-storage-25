# AgentDebugX Research Survey

This survey focuses on agentic error detection, failure attribution, recovery,
and observability. It is meant to guide implementation choices rather than act
as a complete literature review.

## Core Papers

### AgentDebug: where agents fail and how they learn

Reference: [Where LLM Agents Fail and How They can Learn From Failures](https://arxiv.org/abs/2509.25370)

Key takeaways:

- Agent failures cascade because root-cause mistakes propagate through memory,
  planning, reflection, tool use, and system operations.
- The paper introduces AgentErrorTaxonomy, AgentErrorBench, and AgentDebug.
- The taxonomy spans memory, reflection, planning, action, and system modules.
- The debugging pipeline identifies root-cause failures and generates targeted
  corrective feedback.
- AgentDebugX should preserve this modular view but generalize beyond the
  original benchmark environments into a reusable SDK and database layer.

Implementation implications:

- The canonical trace schema should include module-level fields.
- Reports should separate step-level findings from the critical root cause.
- Recovery feedback should be structured and reusable across repeated runs.

### MAST: why multi-agent LLM systems fail

Reference: [Why Do Multi-Agent LLM Systems Fail?](https://arxiv.org/abs/2503.13657)

Key takeaways:

- MAST-Data contains more than 1,600 annotated traces across seven multi-agent
  frameworks.
- MAST groups 14 failure modes into system design issues, inter-agent
  misalignment, and task verification failures.
- Many failures are structural and cannot be fixed only by stronger base models
  or superficial prompt edits.

Implementation implications:

- AgentDebugX needs first-class multi-agent events: handoffs, role boundaries,
  supervisor decisions, consensus, and final verification.
- Diagnostics must be able to blame orchestration and verification, not only an
  individual LLM response.
- Suggested fixes should include structural interventions such as changing
  ownership boundaries, adding verifiers, and improving handoff schemas.

### Who&When: agent and step attribution

Reference: [Which Agent Causes Task Failures and When?](https://arxiv.org/abs/2505.00212)

Related repo: [ag2ai/Agents_Failure_Attribution](https://github.com/ag2ai/Agents_Failure_Attribution)

Key takeaways:

- The paper formalizes automated failure attribution for LLM multi-agent
  systems.
- The Who&When dataset links failed runs to responsible agents and decisive
  error steps.
- Current models still struggle: identifying the failure step is much harder
  than identifying the responsible agent.

Implementation implications:

- AgentDebugX reports should always include `root_cause_agent`,
  `root_cause_step_index`, and `root_cause_event_id`.
- The UI should support "who" and "when" views, not just an event log.
- Evaluation should score agent attribution and step attribution separately.

### AgentRx: constraint-based diagnosis from trajectories

Reference: [AgentRx: Diagnosing AI Agent Failures from Execution Trajectories](https://arxiv.org/abs/2602.02475)

Related repo: [microsoft/AgentRx](https://github.com/microsoft/AgentRx)

Key takeaways:

- AgentRx normalizes raw logs into trajectory IR, synthesizes constraints,
  checks them step by step, and feeds an auditable validation log to an LLM
  judge.
- It focuses on the critical failure step: the point where the trajectory first
  becomes unrecoverable.
- The release covers structured API workflows, incident management, and
  open-ended web/file tasks.

Implementation implications:

- AgentDebugX should support a pluggable constraint-checker interface.
- Constraint violations should be stored as evidence artifacts, not buried in
  free-form text.
- The first production-grade analyzer should combine deterministic checks with
  optional LLM judging.

### AgenTracer: trained failure attribution

Reference: [AgenTracer: Who Is Inducing Failure in the LLM Agentic Systems?](https://arxiv.org/abs/2509.03312)

Key takeaways:

- AgenTracer uses counterfactual replay and programmed fault injection to build
  training data for failed multi-agent trajectories.
- A lightweight trained model can outperform large proprietary models on
  failure attribution.
- Actionable feedback to existing multi-agent systems can improve performance.

Implementation implications:

- AgentDebugX should make replay metadata and perturbation records part of the
  data model.
- The database should store labels and recovery outcomes so future learned
  analyzers can train on project-specific failures.

### AgentTrace: structured logging for security and accountability

Reference: [AgentTrace: A Structured Logging Framework for Agent System Observability](https://arxiv.org/abs/2602.10133)

Key takeaways:

- Structured telemetry needs operational, cognitive, and contextual surfaces.
- Trace capture is useful for debugging, benchmarking, security, accountability,
  and real-time monitoring.

Implementation implications:

- AgentDebugX should distinguish tool/runtime telemetry from agent reasoning
  state and context provenance.
- Sensitive data handling needs to be part of the schema and exporter design.

### AgentStepper: interactive debugging for software agents

Reference: [AgentStepper: Interactive Debugging of Software Development Agents](https://arxiv.org/abs/2602.06593)

Key takeaways:

- Software engineering agents need breakpoints, stepwise execution, prompt/tool
  editing, and code-change inspection.
- Interactive debugging operates at a higher abstraction than traditional
  program debugging.

Implementation implications:

- AgentDebugX UI should support timeline stepping and replay/forking.
- For coding agents, repository diffs should be first-class artifacts.

### AgentOps and system-level observability

References:

- [AgentOps: Enabling Observability of LLM Agents](https://arxiv.org/abs/2411.05285)
- [AgentSight: System-Level Observability for AI Agents Using eBPF](https://arxiv.org/abs/2508.02736)

Key takeaways:

- Agent observability is necessary for safety because agents are autonomous and
  nondeterministic.
- AgentSight highlights a semantic gap between high-level intent and low-level
  system effects.

Implementation implications:

- AgentDebugX should be compatible with OpenTelemetry and external traces.
- System effects such as file writes, shell commands, browser state, API writes,
  and database mutations should be attached to the causally responsible event.

## Related Open-Source Repositories

- [ulab-uiuc/AgentDebug](https://github.com/ulab-uiuc/AgentDebug): source
  implementation for AgentDebug, AgentErrorTaxonomy, and benchmark scripts.
- [ag2ai/Agents_Failure_Attribution](https://github.com/ag2ai/Agents_Failure_Attribution):
  Who&When benchmark implementation.
- [microsoft/AgentRx](https://github.com/microsoft/AgentRx): trajectory IR,
  invariant checks, and diagnostic reports for failed agent runs.
- [langfuse/langfuse](https://github.com/langfuse/langfuse): open-source LLM
  engineering platform with tracing, evals, prompt management, datasets, and
  playgrounds.
- [arize-ai/phoenix](https://github.com/arize-ai/phoenix): open-source AI
  observability and evaluation platform built around OpenTelemetry-style traces.
- [openlit/openlit](https://github.com/openlit/openlit): OpenTelemetry-native
  AI engineering platform with LLM observability, metrics, guardrails, evals,
  prompt management, and playgrounds.
- [OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/):
  emerging vendor-neutral conventions for model, agent, framework, exception,
  and metric spans.

## Product Gap

Existing observability systems are strong at traces, costs, latency, prompt
management, and eval workflows. The gap AgentDebugX should own is the diagnostic
layer on top of traces:

- portable agentic trajectory normalization,
- explicit error taxonomy and evolving project-specific labels,
- root-cause localization across agents and steps,
- causal evidence and constraint violations,
- multimodal artifacts and UI state,
- recovery suggestions and outcome tracking.
