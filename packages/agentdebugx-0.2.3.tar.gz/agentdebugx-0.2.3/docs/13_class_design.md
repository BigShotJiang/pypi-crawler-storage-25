# 13 — Detailed Class & Module Design

This document describes the **target architecture** for AgentDebugX (v1.0+). The actual v0.1 layout shipped on top of Codex's scaffold is much smaller — see doc 17 for the reconciliation. The current `src/agentdebug/` layout is summarized below.

## 0. v0.1 actual layout (shipping now, top-level `agentdebug`)

```
src/agentdebug/
├── __init__.py            # public re-exports
├── models.py              # AgentTrajectory, AgentEvent, Artifact, Modality,
│                          # FailureMode, FailureFinding, DiagnosticReport,
│                          # JSON shims (Pydantic v1+v2)
├── taxonomy.py            # SEED_FAILURE_MODES (19 modes)
├── storage.py             # TraceStore Protocol, JsonlTraceStore, SQLiteTraceStore
├── recorder.py            # AgentDebug, TraceSession
├── analyzers.py           # HeuristicAnalyzer (rule-based detector)
├── instrumentation.py     # traced_tool decorator
├── events.py              # EventBus, EventSubscription   (NEW v0.1)
├── llm.py                 # LLMClient, OpenAICompatClient (NEW v0.1)
├── judges.py              # LLMJudgeAnalyzer              (NEW v0.1)
├── attribution.py         # AllAtOnceAttributor + heuristic fallback (NEW v0.1)
├── recovery.py            # ReflexionSuggestion           (NEW v0.1)
├── cli.py                 # analyze | list | show | judge (EXPANDED v0.1)
└── adapters/
    ├── __init__.py
    ├── base.py            # FrameworkAdapter Protocol, AdapterStatus
    ├── raw.py             # trace_loop, mark_step          (NEW v0.1)
    ├── langgraph.py       # LangChainCallbackAdapter      (NEW v0.1)
    └── otel.py            # OTel GenAI export shim         (NEW v0.1, optional)
```

## 1. Target package layout (v1.0+, namespace name to be decided)

```
src/agentdebugx/
├── __init__.py                  # init(), trace_loop(), step(), last_run(), serve()
├── _version.py
├── config/
│   ├── __init__.py
│   ├── settings.py              # AgentDebugXSettings (pydantic-settings)
│   ├── profiles.py              # fast/balanced/thorough/audit
│   └── loader.py
├── schema/
│   ├── __init__.py
│   ├── run.py                   # Run, Session, SpanStatus
│   ├── span.py                  # Span, SpanEvent, SpanLink, AgentRef, ToolDef, Message, ToolCall, ContentPart
│   ├── error.py                 # DetectedError, LabelSet, Evidence, Severity
│   ├── blame.py                 # Blame, AttributionResult, Counterfactual
│   ├── fix.py                   # FixProposal, AppliedFix, SideEffect, ActionHint
│   ├── multimodal.py            # MultimodalArtifact
│   ├── corpus.py                # CorpusRecord
│   └── migrations/
│       └── v0_1_0.py
├── taxonomy/
│   ├── __init__.py
│   ├── registry.py              # Registry, TaxonomyAxis, TaxonomyCode
│   ├── codes.py                 # auto-generated Enums from registry.yaml
│   ├── crosswalk.py             # MAST <-> AgentDebug <-> per-benchmark
│   ├── registry.yaml            # source of truth
│   └── auto/                    # AUTO.* candidate codes
├── tracing/
│   ├── __init__.py
│   ├── tracer.py                # Tracer, RunContext
│   ├── event_bus.py             # EventBus, Event base class
│   ├── otel.py                  # OTel TracerProvider builder, exporters
│   ├── span_processor.py        # AgentDebugXSpanProcessor bridging OTel → bus
│   ├── exporters/
│   │   ├── otlp.py
│   │   ├── langfuse.py
│   │   ├── agentops.py
│   │   ├── phoenix.py
│   │   ├── openllmetry.py
│   │   ├── weave.py
│   │   └── langsmith.py
│   └── redactor.py              # Redactor (PII scrubbing)
├── storage/
│   ├── __init__.py
│   ├── sqlite.py                # SQLite metadata store
│   ├── duckdb.py                # DuckDB analytical store
│   ├── parquet.py               # Parquet trace files
│   └── artifact.py              # MultimodalArtifact storage
├── adapters/
│   ├── __init__.py              # ADAPTERS list, auto_attach()
│   ├── base.py                  # FrameworkAdapter Protocol, FrameworkId enum
│   ├── autogen.py
│   ├── ag2.py
│   ├── langgraph.py             # also covers langchain
│   ├── crewai.py
│   ├── openai_agents.py
│   ├── openhands.py
│   ├── smolagents.py
│   ├── llama_index.py
│   ├── dspy.py
│   ├── pydantic_ai.py
│   ├── haystack.py
│   ├── metagpt.py
│   ├── camel.py
│   └── vanilla.py
├── detect/
│   ├── __init__.py              # Detector Protocol, DetectionPipeline, register()
│   ├── context.py               # DetectContext
│   ├── rule/
│   │   ├── __init__.py
│   │   ├── repeated_tool_call.py
│   │   ├── step_count.py
│   │   ├── context_overflow.py
│   │   ├── tool_schema.py
│   │   ├── tool_unknown.py
│   │   ├── tool_null.py
│   │   ├── loss_of_history.py
│   │   ├── premature_finish.py
│   │   ├── handoff_unknown.py
│   │   ├── side_effect.py
│   │   ├── injection_heuristic.py
│   │   └── pii_leak.py
│   ├── anomaly/
│   │   ├── __init__.py
│   │   ├── perplexity.py        # TrajAD-style
│   │   ├── repeated_state.py
│   │   ├── tool_failure_rate.py
│   │   ├── latency.py
│   │   └── topic_drift.py
│   ├── judge/
│   │   ├── __init__.py
│   │   ├── base.py              # LLMJudgeDetector base
│   │   ├── mast_judge.py
│   │   ├── agent_debug_judge.py
│   │   ├── tau_bench_judge.py
│   │   ├── security_judge.py
│   │   └── prompts/             # Jinja templates
│   ├── spec/                    # v2 — LTL monitor
│   │   └── ltl.py
│   ├── static/
│   │   └── empirical_bugs.py    # from arXiv:2602.21806
│   └── calibration.py           # calibration_report()
├── attribute/
│   ├── __init__.py              # Attributor Protocol, register
│   ├── base.py
│   ├── all_at_once.py
│   ├── step_by_step.py
│   ├── binary_search.py
│   ├── counterfactual.py
│   ├── sbfl.py                  # Tarantula, Ochiai, DStar
│   ├── delta_debug.py           # Zeller ddmin
│   ├── ensemble.py
│   └── budget.py                # AttributionBudget
├── recover/
│   ├── __init__.py
│   ├── base.py                  # Recoverer Protocol
│   ├── reflexion.py
│   ├── self_refine.py
│   ├── critic.py
│   ├── auto_manual.py
│   ├── langgraph_rewind.py
│   ├── saga_rollback.py
│   ├── mcts.py                  # LATS-style
│   ├── retrieval.py             # similar-case retrieval
│   └── apply.py                 # ApplyContext, approval workflow
├── replay/
│   ├── __init__.py
│   ├── engine.py                # Replayer
│   ├── mocks.py                 # MockTool, ReplayLLM
│   └── env.py                   # EnvironmentReconstructor
├── corpus/
│   ├── __init__.py              # Corpus
│   ├── local.py
│   ├── hosted.py
│   ├── ingest.py
│   ├── dedup.py
│   ├── scrub.py
│   ├── publish.py
│   └── hf_export.py
├── induce/
│   ├── __init__.py
│   ├── pipeline.py
│   ├── partition.py             # goal-conditioned partitioning
│   ├── bertopic.py
│   ├── tnt_llm.py
│   ├── hitl_queue.py
│   ├── active_learning.py
│   └── drift.py
├── multimodal/
│   ├── __init__.py
│   ├── capture.py               # screenshot, DOM, click-trace
│   ├── detectors.py             # dom_diff, screenshot_diff, click_off_target, modal_present, vlm_judge
│   └── replay.py                # visual replay
├── llm/
│   ├── __init__.py
│   ├── client.py                # provider-agnostic Completion / Embedding clients
│   ├── openai.py
│   ├── anthropic.py
│   ├── litellm.py
│   └── cache.py
├── bench/
│   ├── __init__.py
│   ├── runner.py
│   ├── who_when.py
│   ├── mad.py
│   ├── agent_error_bench.py
│   └── reports.py
├── cli/
│   ├── __init__.py              # Click app
│   ├── run.py
│   ├── analyze.py
│   ├── replay.py
│   ├── serve.py
│   ├── tui.py
│   ├── publish.py
│   ├── db.py
│   ├── taxonomy.py
│   ├── bench.py
│   └── doctor.py
├── ui/
│   ├── __init__.py
│   ├── server.py                # FastAPI app
│   ├── api/
│   │   ├── runs.py
│   │   ├── errors.py
│   │   ├── corpus.py
│   │   ├── taxonomy.py
│   │   ├── stream.py            # WebSocket
│   │   └── replay.py
│   ├── webapp/                  # React + Vite project (built into static/)
│   ├── tui_app.py               # Textual TUI
│   └── embed.py                 # trace_widget()
├── plugins/                     # entry-point loader
│   └── loader.py
└── utils/
    ├── __init__.py
    ├── ids.py                   # ULID
    ├── time.py
    ├── async_utils.py
    └── logging.py
```

## 2. Top-level API (sketch)

```python
# agentdebugx/__init__.py

from .config.settings import AgentDebugXSettings
from .tracing.tracer import Tracer, RunContext
from .schema.run import Run
from .detect import Detector, DetectionPipeline
from .attribute import Attributor, EnsembleAttributor
from .recover import Recoverer
from .corpus import Corpus

_tracer: Tracer | None = None

def init(
    project: str = "default",
    *,
    profile: Literal["fast","balanced","thorough","audit"] = "balanced",
    detect: list[str] | None = None,
    attribute: str | list[str] | None = "ensemble",
    recovery: RecoveryConfig | None = None,
    sync: SyncConfig | None = None,
    storage_dir: Path | None = None,
    mode: Literal["inline","sidecar","async"] = "inline",
    **kwargs,
) -> Tracer:
    """Initialize AgentDebugX. Auto-detects and attaches framework adapters."""
    global _tracer
    settings = AgentDebugXSettings.load(project=project, profile=profile, **kwargs)
    _tracer = Tracer(settings)
    _tracer.start()
    return _tracer

def last_run() -> Run: ...
def serve(port: int = 7777, host: str = "127.0.0.1") -> None: ...
def trace_loop(name: str | None = None): ...   # decorator
def step(*, observation=None, label: str | None = None) -> None: ...
```

## 3. Selected class signatures

### 3.1 Tracer

```python
class Tracer:
    def __init__(self, settings: AgentDebugXSettings): ...
    def start(self) -> None:
        self.bus = EventBus()
        self.tracer_provider = build_tracer_provider(self.settings, self.bus)
        self.ctx = AdapterContext(
            tracer_provider=self.tracer_provider,
            event_bus=self.bus,
            project=self.settings.project,
            redactor=Redactor(self.settings.redaction),
            config=self.settings.adapters,
        )
        self.adapters = auto_attach(self.ctx)
        self.storage = StorageBackend(self.settings.storage_dir)
        self.pipeline = DetectionPipeline.from_profile(self.settings.profile)
        self.bus.subscribe(SpanEndEvent, self._on_span_end)
    def _on_span_end(self, evt): ...
    def stop(self) -> None: ...
    def current_run(self) -> Run | None: ...
    def all_runs(self, limit: int = 50) -> list[Run]: ...
```

### 3.2 EventBus

```python
class Event(BaseModel): event_type: str; timestamp: datetime

class EventBus:
    def __init__(self, maxsize: int = 10_000): ...
    def publish(self, evt: Event) -> None: ...
    def subscribe(self, evt_type: type[Event], handler: Callable[[Event], None]) -> SubscriptionHandle: ...
    def metrics(self) -> BusMetrics: ...
```

Backed by an asyncio queue per subscriber; bounded with drop-policy = log-and-count.

### 3.3 Detector / DetectionPipeline

```python
class Detector(Protocol):
    id: ClassVar[str]
    cost: ClassVar[Literal["free","cheap","expensive"]]
    axes: ClassVar[list[TaxonomyAxisId]]
    runs_inline: ClassVar[bool]
    def detect(self, ctx: DetectContext) -> list[DetectedError]: ...
    async def detect_async(self, ctx: DetectContext) -> list[DetectedError]: ...

class DetectionPipeline:
    def __init__(self, detectors: list[Detector]): ...
    @classmethod
    def from_profile(cls, profile: str) -> "DetectionPipeline": ...
    def run(self, trace: Trace) -> list[DetectedError]: ...
    async def run_async(self, trace: Trace) -> list[DetectedError]: ...
    def add(self, detector: Detector) -> None: ...
    def remove(self, detector_id: str) -> None: ...
```

### 3.4 Attributor / EnsembleAttributor

```python
class Attributor(Protocol):
    id: ClassVar[str]
    cost: ClassVar[Literal["cheap","moderate","expensive"]]
    def attribute(self, trace: Trace, errors: list[DetectedError]) -> AttributionResult: ...
    async def attribute_async(self, trace, errors) -> AttributionResult: ...

class EnsembleAttributor(Attributor):
    def __init__(self, backends: list[Attributor],
                 weights: dict[str, float] | None = None,
                 merge: Literal["borda","bayesian"] = "borda",
                 budget: AttributionBudget | None = None): ...
```

### 3.5 Recoverer

```python
class Recoverer(Protocol):
    id: ClassVar[str]
    applies_to: ClassVar[list[TaxonomyAxisId]]
    def suggest(self, trace, errors, blame) -> list[FixProposal]: ...
    def apply(self, fix: FixProposal, ctx: ApplyContext) -> ApplyResult: ...
```

### 3.6 Replayer

```python
class Replayer:
    def __init__(self, trace: Trace, env: EnvironmentReconstructor): ...
    def from_step(self, step_index: int,
                  *, oracle_correction: Callable | None = None,
                  mock: bool = True) -> Trace: ...
    async def from_step_async(self, ...) -> Trace: ...
    def n_rollouts(self, step_index: int, n: int, **kw) -> list[Trace]: ...
```

### 3.7 Corpus

```python
class Corpus:
    def __init__(self, backend: Literal["local","hosted"] = "local", **kw): ...
    def add(self, run: Run, labels: list[LabelSet], **kw) -> CorpusRecord: ...
    def get(self, record_id: str) -> CorpusRecord: ...
    def query(self, **filters) -> list[CorpusRecord]: ...
    def similar_to(self, trace: Trace, k: int = 10, **kw) -> list[CorpusRecord]: ...
    def sql(self, query: str) -> "duckdb.DuckDBPyRelation": ...
    def publish(self, record_id: str, *, license: str = "CC-BY-4.0") -> PublishResult: ...
    def takedown(self, record_id: str, *, reason: str) -> None: ...
```

### 3.8 InductionPipeline

```python
class InductionPipeline:
    def __init__(self, corpus: Corpus, llm: CompletionClient, settings: InductionSettings): ...
    def run(self) -> InductionRunReport: ...
    def review_queue(self) -> list[CandidateCode]: ...
    def promote(self, candidate_id: str, *, into: TaxonomyAxisId) -> RFC: ...
```

## 4. Plugin entry-points

`pyproject.toml`:

```toml
[project.entry-points."agentdebugx.detectors"]
my_detector = "my_pkg:MyDetector"

[project.entry-points."agentdebugx.attributors"]
my_attributor = "my_pkg:MyAttributor"

[project.entry-points."agentdebugx.recoverers"]
my_recoverer = "my_pkg:MyRecoverer"

[project.entry-points."agentdebugx.adapters"]
my_framework = "my_pkg.adapter:MyAdapter"

[project.entry-points."agentdebugx.exporters"]
my_exporter = "my_pkg.exporter:MyExporter"
```

`plugins/loader.py` iterates each group on `init()`.

## 5. Settings model

```python
class AgentDebugXSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AGENTDEBUGX_", env_nested_delimiter="__")

    project: str = "default"
    profile: Literal["fast","balanced","thorough","audit"] = "balanced"
    mode: Literal["inline","sidecar","async"] = "inline"
    storage_dir: Path = Path.home() / ".agentdebugx"

    redaction: RedactionConfig = RedactionConfig()
    adapters: AdapterConfigBundle = AdapterConfigBundle()
    detectors: DetectorsConfig = DetectorsConfig()
    attribution: AttributionConfig = AttributionConfig()
    recovery: RecoveryConfig = RecoveryConfig()
    sync: SyncConfig = SyncConfig()

    llm: LLMConfig = LLMConfig()
    exporters: ExportersConfig = ExportersConfig()
    induction: InductionSettings = InductionSettings()
    ui: UIConfig = UIConfig()
```

## 6. Threading / async model

- All public APIs work in both sync and async contexts.
- `EventBus` is internally async; sync `publish` schedules on the event loop or uses a thread-safe queue if no loop is available.
- LLM judges and attributors use `asyncio` + `httpx`; sync wrappers via `asyncio.run` if called from sync code.
- Adapters MUST NOT block; long work is offloaded to `agentdebugx.utils.async_utils.fire_and_forget`.

## 7. Errors and logging

- All AgentDebugX-emitted exceptions inherit `agentdebugx.AgentDebugXError`.
- Adapters never raise out — they log to `agentdebugx.adapter.errors` and increment a counter.
- A `doctor` CLI command summarizes adapter health and config issues.

## 8. Public types module

`agentdebugx.types` re-exports the most-used types so users only need one import:

```python
from agentdebugx.types import (
    Trace, Run, Span, Message, ToolCall, ToolDef,
    DetectedError, LabelSet, Severity,
    Blame, AttributionResult, Counterfactual,
    FixProposal, AppliedFix, SideEffect,
    FrameworkId, TaxonomyAxisId,
)
```

## 9. Testing structure

```
tests/
├── adapters/
│   ├── conftest.py              # shared fixtures: mini agents per framework
│   ├── test_autogen.py
│   ├── test_langgraph.py
│   ├── …
├── detect/
│   ├── test_rules.py
│   ├── test_anomaly.py
│   ├── test_judges.py           # against golden traces with expected labels
├── attribute/
│   ├── test_all_at_once.py
│   ├── test_counterfactual.py
│   ├── test_ensemble.py
├── recover/
│   ├── test_reflexion.py
│   ├── test_saga.py
├── corpus/
│   ├── test_ingest.py
│   ├── test_dedup.py
│   ├── test_scrub.py
├── schema/
│   ├── test_round_trip.py
├── bench/
│   ├── test_who_when_smoke.py
│   ├── test_mad_smoke.py
├── e2e/
│   ├── test_one_line_init.py
│   ├── test_replay.py
```

## 10. Typing posture

- `mypy --strict` (the existing template config) — keep.
- Beartype for runtime checks on public APIs.
- Pydantic v2 everywhere for schema-of-record.
- Protocols (`typing.Protocol`) for extension points (Detector, Attributor, Recoverer, FrameworkAdapter, Exporter).

## 11. Optional dependencies

To avoid forcing the install of every framework:

```toml
[project.optional-dependencies]
autogen = ["autogen-core", "autogen-agentchat"]
ag2 = ["pyautogen"]
langgraph = ["langgraph", "langchain"]
crewai = ["crewai"]
openai-agents = ["openai-agents"]
openhands = ["openhands-ai"]
smolagents = ["smolagents", "openinference-instrumentation-smolagents"]
llamaindex = ["llama-index"]
dspy = ["dspy-ai"]
pydantic-ai = ["pydantic-ai"]
haystack = ["haystack-ai"]
metagpt = ["metagpt"]
camel = ["camel-ai"]
otel = ["opentelemetry-api", "opentelemetry-sdk", "opentelemetry-exporter-otlp"]
ui = ["fastapi", "uvicorn", "textual"]
all = [<everything above>]
```

`agentdebugx.adapters` detects missing optional deps and gracefully no-ops the matching adapter.
