# 18 — Comparison: Codex Scaffold vs. Design Spec

The repository now contains **two converging contributions**:

- A working **scaffold by Codex** (commit `93d6670`): `import agentdebug`, 19 seed failure modes, JSONL/SQLite stores, heuristic analyzer, CLI, function decorator, 3 passing tests, mypy --strict clean.
- A **design spec** (docs 00–16): 7-layer architecture, 5-axis taxonomy, OTel GenAI alignment, 6 attribution backends, 8 recovery strategies, 14 framework adapters, community corpus, taxonomy induction, multimodal layer, UI.

This document records the comparison and the merged plan that drives v0.1 implementation. The design docs that follow have been rebased onto the merged plan; this file is the audit trail.

## 1. Side-by-side

| Area | Codex scaffold | Design spec | Merged v0.1 decision |
|---|---|---|---|
| **Package name (import)** | `agentdebug` | `agentdebugx` | **Codex wins.** Short import; repo stays `AgentDebugX`. PyPI distribution stays `agentdebugx`. |
| **Trace data model** | `AgentTrajectory` + `AgentEvent` (2 levels) | `Run / Session / Trace / Span` (4 levels) | **Codex wins for v0.1.** Simpler is right for first release. Spec's OTel-aligned hierarchy becomes an *export projection* (doc 04). |
| **Pydantic** | v1/v2 shim (`model_dump_json` fallback) | v2-only | **Codex wins.** Reality: env runs Pydantic 1.10. Keep shim. |
| **Event taxonomy of trace** | `EventType` enum: run, agent_step, llm.call, tool.*, memory.*, plan, reflection, handoff, guardrail, observation, error, human.feedback (16 types) | Implicit via OTel ops (`chat`, `execute_tool`, `invoke_agent`, …) | **Both.** Codex's enum stays primary internal vocabulary; OTel ops are derived. |
| **Failure taxonomy** | 19 seed modes in `SEED_FAILURE_MODES` dict, each with `family / signals / suggestion_templates / source` | 5-axis registry (MAST-14 + AgentDebug-5 + SEC + TL + GR + CAP) | **Hybrid.** Keep Codex's 19-mode dict as the runtime taxonomy. Layer the spec's "axes" as a *grouping* via the `family` field already present. Crosswalks to MAST/AgentDebug-5 are documented (doc 03). Custom axes via new families. |
| **Storage** | JSONL (default), SQLite | SQLite (metadata) + DuckDB (analytics) + Parquet (archive) + corpus sync | **Codex now, spec later.** Ship JSONL+SQLite in v0.1; DuckDB/Parquet/corpus deferred to v0.3 per roadmap. |
| **Analyzer** | `HeuristicAnalyzer` — string-pattern + metadata → seed mode | 4-family detector pipeline (rule/anomaly/LLM-judge/spec) + cost class + budget | **Both.** Codex's analyzer becomes the "rule" detector. Spec's pipeline, judge, and registry shipped on top. |
| **LLM judge** | None | `mast_judge`, `agent_debug_judge`, `tau_bench_judge`, `security_judge` | **Add now.** v0.1 ships ONE generic LLM judge wired to the Gemini endpoint, schemed to the 19 seed modes (not MAST-14 yet). MAST-prompted variant deferred to v0.2. |
| **Event bus** | None | `EventBus` in-process pub/sub | **Add now.** Required so detectors can stream over a live trace (not just post-hoc). |
| **Adapters** | `FrameworkAdapter` Protocol only | 14 framework adapters | **Add 2 real now.** v0.1 ships LangGraph callback handler + raw-loop helpers (`traced_tool` already exists, add `trace_loop`). Others deferred per roadmap. |
| **Attribution** | "earliest finding wins" heuristic inside the analyzer | 6 swappable backends (AllAtOnce / StepByStep / BinarySearch / Counterfactual / SBFL / DeltaDebug) | **Add 1 real now.** v0.1 ships `AllAtOnceAttributor` (LLM-based) on top of Codex's heuristic. Counterfactual + SBFL deferred. |
| **Recovery** | Per-mode `suggestion_templates` baked into taxonomy | 8 composable strategies + apply/suggest split | **Both.** Codex's templates are the default suggestions. Add a `ReflexionSuggestion` recoverer that emits a structured retry-prompt artifact (suggest-only, no auto-apply in v0.1). |
| **OTel GenAI** | Not mentioned | First-class wire format | **Defer to v0.2.** v0.1 emits Codex's native model + an optional OTel exporter shim if `opentelemetry-api` is installed (best-effort, non-blocking). |
| **Multimodal** | Schema supports `Artifact` with `Modality` enum | Capture pipeline + sub-taxonomy + visual replay | **Codex schema only.** v0.1 stores artifacts users provide; capture pipeline (screenshots, DOM diff) deferred to v1.1. `multimodal.perception_error` mode already shipped. |
| **UI** | None | Web Console + TUI + VSCode + REST | **Defer.** v0.1 ships CLI only (`agentdebug analyze`, `list`, `show`, `judge`). UI in v0.2+. |
| **Corpus / community** | Not present | ADBXCorpus with HF mirror | **Defer.** Local JSONL/SQLite stores are *de facto* per-project corpora. Hosted corpus in v0.3. |
| **Taxonomy induction** | "Generated taxonomy nodes" mentioned in docs only | TnT-LLM + BERTopic + HITL pipeline | **Defer to v0.4** per roadmap. |
| **Tests** | 3 passing tests covering recorder/store/context-manager | Full conformance suite | **Extend.** v0.1 adds tests for EventBus, AllAtOnce attributor (mocked LLM), LLM judge (mocked), trace_loop decorator. Live-Gemini test gated behind `AGENTDEBUG_LIVE_LLM=1`. |
| **Docs** | RESEARCH_SURVEY + DEV_PLAN + ERROR_TAXONOMY (3 docs) | 17 docs (00–16 plus this one) | **Coexist.** Codex's 3 docs are kept as the *narrative* layer (paper-style intro). Numbered docs are the *engineering* spec. README links to both. |

## 2. What Codex got right that the spec under-weighted

1. **Ship working code before more abstraction.** Codex's `HeuristicAnalyzer` returns useful findings on day 1 with no LLM. The spec's "ensemble of 6 attributors" delivers nothing until two backends ship.
2. **Decouple import name from project name.** `import agentdebug` reads naturally; `AgentDebugX` is the brand.
3. **2-level trace model is enough.** OTel's `Trace ⊃ Span` distinction is fine as an *export* format but not necessary as the in-memory model for v0.1.
4. **In-line suggestions on each `FailureMode`.** Beats a separate Recoverer for the common case. Keep both.
5. **AgentRx, AgentTrace, AgentStepper, AgentSight** were missed in my survey — Codex's lit review (RESEARCH_SURVEY.md) caught them and they belong (AgentRx in particular: constraint synthesis + LLM-judge-on-validation-log is *exactly* the rule + judge pipeline I designed, but published).
6. **Pydantic v1/v2 compat shim.** The deployment reality (anaconda env on Python 3.11 + Pydantic 1.10) would have broken my v2-only design out of the box.

## 3. What the spec adds that Codex's scaffold is missing

1. **EventBus + live detector pipeline** — Codex is post-hoc only.
2. **LLM judge** — Codex is string-pattern only; cannot diagnose semantic failures (goal drift, role spec violation, etc.).
3. **Attribution beyond "earliest finding"** — Codex's `_select_root_cause` ties go to the lowest step index, which is fragile.
4. **Concrete adapters** — Codex's `FrameworkAdapter` is an empty Protocol; no adapter ships.
5. **Replay primitives** — needed for counterfactual attribution and time-travel UX.
6. **OTel GenAI alignment** — required to interop with Phoenix/Langfuse/Datadog without per-vendor exporters.
7. **Recovery strategies separated from taxonomy templates** — Codex's suggestion templates are stuck inside `FailureMode`; the spec lets recoverers compose, retrieve from corpus, and track outcomes.
8. **Corpus + induction loop** — Codex stores traces but does not learn from them.
9. **Multi-axis taxonomy** — Codex's flat 19 modes cannot express "this trace is both a `FM-2.3 task_derailment` (MAST) and a `M.PLN` (AgentDebug-5) and tagged `SEC.PI`".
10. **UI / VSCode / REST** — Codex has CLI only.

## 4. The merged v0.1 plan (what we ship)

**Keep verbatim from Codex** (`src/agentdebug/`):

- `models.py` — `AgentTrajectory`, `AgentEvent`, `Artifact`, `Modality`, `FailureMode`, `FailureFinding`, `DiagnosticReport`, JSON shims.
- `taxonomy.py` — 19 `SEED_FAILURE_MODES`.
- `storage.py` — `JsonlTraceStore`, `SQLiteTraceStore`.
- `recorder.py` — `AgentDebug`, `TraceSession`.
- `analyzers.py` — `HeuristicAnalyzer` (renamed in role to "rule-based detector"; class name stays).
- `instrumentation.py` — `traced_tool`.
- `adapters/base.py` — `FrameworkAdapter` Protocol, `AdapterStatus`.
- `cli.py` — `agentdebug analyze`.

**Add now** (new modules):

- `src/agentdebug/events.py` — `EventBus`, `EventSubscription`, in-process pub/sub.
- `src/agentdebug/llm.py` — `LLMClient` Protocol + `OpenAICompatClient` impl (works against the Gemini endpoint, OpenAI, Anthropic-via-LiteLLM).
- `src/agentdebug/judges.py` — `LLMJudgeAnalyzer` schemed to the 19 seed modes; structured-output validated.
- `src/agentdebug/attribution.py` — `AllAtOnceAttributor` (LLM-based blame); falls back to Codex's heuristic if no LLM configured.
- `src/agentdebug/recovery.py` — `ReflexionSuggestion` (emits a structured retry-prompt artifact for the next attempt; suggest-only).
- `src/agentdebug/adapters/langgraph.py` — real `BaseCallbackHandler` adapter (gated on `langchain_core` import).
- `src/agentdebug/adapters/raw.py` — `trace_loop` decorator + `mark_step` helper for vanilla ReAct loops.
- `src/agentdebug/adapters/otel.py` — optional OTel GenAI export shim (gated on `opentelemetry-api` import).
- Expanded CLI: `agentdebug list`, `agentdebug show <trace_id>`, `agentdebug judge <trace>`.

**Defer** (per roadmap): DuckDB/Parquet, counterfactual replay, SBFL/DeltaDebug attributors, MAST/AgentDebug judges, additional adapters (AutoGen, CrewAI, OpenHands, …), corpus sync, taxonomy induction, Web UI, multimodal capture.

## 5. Why this merge maximizes value per LOC

- Codex's scaffold is the **fast path to adoption** — users get something working immediately.
- The spec's adds are the **highest-marginal-value pieces** the scaffold cannot evolve into without architectural changes (EventBus, LLM judge, multi-axis taxonomy crosswalk, real adapter, attribution interface).
- Everything else in the spec is correctly deferred — it would be premature without first-party users.

## 6. Doc-set reorganization

After this merge:

- `docs/00_overview.md` → import name updated to `agentdebug`, two-tier "narrative + spec" doc structure noted.
- `docs/02_architecture.md` → 7-layer diagram retained; called out as the *target* architecture, with v0.1 layers shipped.
- `docs/03_taxonomy.md` → primary v0.1 taxonomy is the 19 seed modes; MAST/AgentDebug-5 cross-walk preserved as the v0.2+ projection.
- `docs/04_trace_schema.md` → v0.1 schema is Codex's 2-level model; OTel 4-level retained as the export projection.
- `docs/05_adapters.md` → 14 frameworks listed as target; only LangGraph + raw-loop ship v0.1.
- `docs/13_class_design.md` → top of file pinned to Codex's actual layout; the broader package tree is the v0.2+ target.
- `docs/15_roadmap.md` → v0.1 scope re-pinned to "merged plan above"; later phases unchanged.

Codex's narrative docs (`README.md`, `RESEARCH_SURVEY.md`, `OPEN_SOURCE_DEVELOPMENT_PLAN.md`, `ERROR_TAXONOMY.md`) remain untouched.
