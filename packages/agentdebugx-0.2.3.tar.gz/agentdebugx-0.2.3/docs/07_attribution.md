# 07 — Failure Attribution

## 1. The problem

Given a failing trace and a set of detected errors, **which agent and which step caused the failure?**

Published SOTA (Zhang et al. "Who & When" arXiv:2505.00212, AgenTracer arXiv:2509.03312) reaches ~53% agent-level accuracy and ~14% step-level accuracy. AgentDebugX must be honest about this ceiling: we return **ranked hypotheses with confidence and evidence**, never a single authoritative answer.

## 2. Interface

```python
class Attributor(Protocol):
    id: str
    cost: Literal["cheap", "moderate", "expensive"]
    def attribute(self, trace: Trace, errors: list[DetectedError]) -> AttributionResult: ...
    async def attribute_async(self, trace, errors) -> AttributionResult: ...

class AttributionResult(BaseModel):
    method: str
    hypotheses: list[Blame]
    elapsed_ms: int
    cost_estimate: float           # USD if LLM was used

class Blame(BaseModel):
    agent_id: str | None
    span_id: str
    step_index: int | None
    confidence: float
    rationale: str
    evidence: list[Evidence]
    counterfactual: Counterfactual | None
    sources: list[str]             # which attributors voted for this
```

## 3. Backends

### 3.1 All-at-Once

Single LLM call: feed the entire trace, ask "which agent and step is responsible for the failure?"

```python
class AllAtOnceAttributor(Attributor):
    id = "all_at_once"; cost = "cheap"
    async def attribute_async(self, trace, errors):
        prompt = render("all_at_once.j2", trace=trace, errors=errors)
        resp = await self._llm.complete(prompt, response_format=AOResponse)
        return AttributionResult(method=self.id, hypotheses=[
            Blame(span_id=resp.span_id, agent_id=resp.agent_id,
                  step_index=resp.step, confidence=resp.confidence,
                  rationale=resp.rationale, evidence=[...], sources=[self.id])
        ], ...)
```

**Strengths:** cheapest; sees global context. **Weaknesses:** loses precision on long traces; bias toward final steps.

### 3.2 Step-by-Step

Sequential scan; for each step, ask "is this the failure?"

```python
class StepByStepAttributor(Attributor):
    id = "step_by_step"; cost = "moderate"
    async def attribute_async(self, trace, errors):
        steps = trace.steps()
        hypotheses = []
        for i, step in enumerate(steps):
            verdict = await self._classify(step, context=steps[max(0,i-3):i])
            if verdict.is_failure:
                hypotheses.append(Blame(...))
        return AttributionResult(...)
```

**Strengths:** precise localization. **Weaknesses:** O(N) LLM calls; no global view.

### 3.3 Binary-Search (Zeller-style ddmin)

```python
class BinarySearchAttributor(Attributor):
    id = "binary_search"; cost = "moderate"
    async def attribute_async(self, trace, errors):
        # Bisect step list, replaying with mocked env, asking judge if failure persists
        lo, hi = 0, len(trace.steps())
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if await self._still_fails(trace, range_end=mid):
                hi = mid
            else:
                lo = mid
        return AttributionResult(...)
```

**Strengths:** O(log N) calls. **Weaknesses:** requires mock-replay (only some frameworks support it).

### 3.4 Counterfactual replay (AgenTracer-style)

```python
class CounterfactualAttributor(Attributor):
    id = "counterfactual"; cost = "expensive"
    async def attribute_async(self, trace, errors):
        candidates = self._rank_candidate_steps(trace, errors)
        results = []
        for step in candidates[:5]:
            replays = await self._replay_n(trace, branch_at=step, n=5,
                                            oracle_correction=True)
            success_rate = sum(r.succeeded for r in replays) / len(replays)
            results.append((step, success_rate))
        # Step whose oracle-correction yields highest success-rate uplift = blame.
        return AttributionResult(...)
```

**Strengths:** strongest evidence (causal). **Weaknesses:** expensive; requires a replayable framework + oracle.

### 3.5 SBFL (spectrum-based fault localization)

```python
class SBFLAttributor(Attributor):
    id = "sbfl"; cost = "cheap"
    def attribute(self, trace, errors):
        # Requires a corpus of passing + failing traces of the same task
        sims = self._lookup_similar_traces(trace.task_signature)
        suspiciousness = {}
        for step in trace.steps():
            ef = sum(1 for t in sims.failing if step.signature in t)
            ep = sum(1 for t in sims.passing if step.signature in t)
            # Ochiai
            suspiciousness[step.id] = ef / math.sqrt((ef+sims.n_failed) * (ef+ep))
        ranked = sorted(suspiciousness.items(), key=lambda x: -x[1])
        return AttributionResult(...)
```

**Strengths:** free at inference time; model-free. **Weaknesses:** needs corpus of similar tasks.

### 3.6 Delta-debugging (Zeller)

Minimize the trace to its smallest failing prefix using `ddmin`. Requires mock replay.

```python
class DeltaDebugAttributor(Attributor):
    id = "delta_debug"; cost = "moderate"
    async def attribute_async(self, trace, errors):
        steps = trace.steps()
        minimized = await ddmin(steps, predicate=self._still_fails)
        # The step at the end of `minimized` is the most likely blame.
        ...
```

**Strengths:** principled minimization; produces tiny reproducer. **Weaknesses:** replay dependence; can be slow.

### 3.7 Fine-tuned small attributor (v2 — AgenTracer-style)

Train an 8B model on synthesized + Who&When + MAD failure traces. Ship as `agentdebugx.attribute.fine_tuned`. Optional download.

## 4. Ensemble & aggregation

```python
class EnsembleAttributor(Attributor):
    id = "ensemble"
    def __init__(self, backends: list[Attributor], weights: dict[str, float] | None = None):
        self.backends = backends
        self.weights = weights or {b.id: 1.0 for b in backends}

    async def attribute_async(self, trace, errors):
        results = await asyncio.gather(*[b.attribute_async(trace, errors) for b in self.backends])
        return self._merge(results)

    def _merge(self, results: list[AttributionResult]) -> AttributionResult:
        # Borda count by (span_id, step_index)
        # OR Bayesian combination treating each backend as an independent noisy classifier
        ...
```

Default ensemble: `[AllAtOnceAttributor, StepByStepAttributor, CounterfactualAttributor]` with weights `[0.3, 0.3, 0.4]`. Counterfactual gets the highest weight because it provides causal evidence.

## 5. Cost and budget controls

```python
attributor = EnsembleAttributor(backends=[...], budget=AttributionBudget(
    max_llm_calls=20, max_replay_rollouts=10, max_usd=0.50, timeout_s=30,
))
```

If budget is exceeded, return partial results with a `truncated=True` flag.

## 6. Honest UX

The UI MUST surface:

- Confidence score per hypothesis.
- Source attributors (so the user sees consensus vs disagreement).
- Counterfactual evidence if available ("oracle-correcting step 4 raised success from 0/5 to 4/5").
- Calibration metrics from latest benchmark run ("AgentDebugX ensemble achieves 51% agent / 19% step on Who&When v1").

Never display a single "the agent at step X caused this" with no qualifier.

## 7. Multi-cause attribution

Some failures have multiple root causes. The result can carry multiple `Blame` entries; the UI groups them and lets the user see whether they're independent or causally chained.

## 8. Benchmarks

`scripts/benchmark_attribution.py` runs the ensemble + each backend individually against:

- Who&When (Zhang et al. 2025)
- MAD (Cemri et al. 2025)
- AgentErrorBench (Zhu et al. 2025)

Output: a markdown leaderboard in `docs/benchmarks/attribution.md` per release.

## 9. Replay primitives

For Counterfactual / Delta-Debug / Binary-Search, AgentDebugX needs to *re-execute* parts of a trace. The replay layer:

- Reconstructs the environment from stored span attributes (system prompts, tool definitions, model config).
- Mocks tools with their recorded outputs by default.
- Allows the user to register a real `Tool` for partial real-execution replay.
- Supports "oracle-correct this step" via a user-provided callable or an LLM-generated patch.

Replay is fundamentally framework-aware — each adapter declares whether it supports replay (`AdapterCapabilities.supports_replay`).
