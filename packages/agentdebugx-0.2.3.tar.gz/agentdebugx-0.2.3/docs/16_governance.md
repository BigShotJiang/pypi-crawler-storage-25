# 16 — Governance & RFC Process

## 1. Project status

AgentDebugX is a community-driven open-source project under the Apache 2.0 license. Initial maintainer set is the original authors at UIUC ULab; the project is structured to accept additional maintainers via the process below.

## 2. Roles

| Role | Responsibilities |
|---|---|
| **Contributor** | Anyone who opens issues or PRs |
| **Maintainer** | Reviews PRs, merges, votes on RFCs, manages releases |
| **Taxonomy steward** | Subset of maintainers responsible for AgentDebugX-Tax versioning |
| **Corpus steward** | Subset of maintainers responsible for ADBXCorpus moderation |

Becoming a maintainer requires ≥ 3 months of regular contribution and a 2/3 vote of existing maintainers.

## 3. Decision-making

- **Routine PRs** (bug fixes, adapter additions, doc updates): 1 maintainer approval.
- **Substantive code changes** (new public API, new layer): 2 maintainer approvals.
- **RFCs** (taxonomy changes, schema breaking changes, governance changes): 2/3 maintainer vote; 7-day comment window.

## 4. RFC process

RFCs live as GitHub issues using `.github/ISSUE_TEMPLATE/`:

- `rfc_taxonomy.yml` — add / rename / deprecate a code; promote `AUTO.*` to curated namespace.
- `rfc_schema.yml` — change a Pydantic model field or semver-bump the schema.
- `rfc_api.yml` — change a public API signature.
- `rfc_governance.yml` — change this document.

Each RFC must include:

1. **Motivation** — what problem; what evidence (corpus stats, user issues, papers).
2. **Detailed design** — proposed change with examples.
3. **Backward compatibility** — migration plan; aliases; deprecation timeline.
4. **Alternatives considered** — at least one alternative + why rejected.
5. **Open questions** — explicit list.

After 7 days + 2/3 maintainer approval, the RFC merges as a doc PR; implementation lands as separate PRs referencing the RFC.

## 5. Taxonomy versioning

- **MAJOR** (`v1 → v2`): structural changes (split / merge axes; rename categories with no alias path). Ships with one-shot LLM-assisted re-labeling migrator.
- **MINOR** (`v0.1 → v0.2`): add codes; promote `AUTO.*` codes; refine descriptions with semantic preservation.
- **PATCH** (`v0.1.0 → v0.1.1`): typo fixes; example additions; non-semantic edits.

Old codes are aliased forward for ≥ 1 minor version. Removed codes raise a `DeprecationWarning` for ≥ 1 minor then become hard errors.

## 6. Schema versioning

Same semver rules. Pydantic models carry `schema_version`. Migrations live in `agentdebugx.schema.migrations.<from>_to_<to>` and run automatically on read.

## 7. Releases

- Cut from `main` on a calendar cadence (target: monthly for v0.x; quarterly for v1+).
- Each release: CHANGELOG entry, benchmark report regenerated, calibration reports refreshed.
- Pre-releases on PyPI (`agentdebugx==0.2.0rc1`) for major-API-touching changes; 1-week soak before final.

## 8. Corpus governance

### Submitter rights

By submitting, the contributor:
- Affirms they have the right to publish under the chosen license (default CC-BY-4.0).
- Grants the project a perpetual right to use the record for taxonomy induction and benchmarks.
- May request takedown via signed email within their org's domain.

### Moderation

- Anomaly detection on new uploads (spam, near-duplicate, suspicious bursts).
- High-impact records (e.g., new "canonical fix" referenced by recommender) enter a moderation queue with 7-day review.
- Take-downs are honored within 5 business days; record cryptographically erased and a tombstone left in the audit log.

### Re-licensing

A record's license may be changed by the original submitter at any time; the change applies prospectively (older copies under the prior license remain governed by it).

## 9. Code of Conduct

This project adopts the Contributor Covenant 2.1. See `CODE_OF_CONDUCT.md`.

## 10. Conflict resolution

- Technical disagreements escalate through: comment thread → public RFC → maintainer vote.
- Interpersonal / community issues escalate to the Code of Conduct committee (rotating 3-maintainer subset; anonymized reports honored).

## 11. Transparency

- All maintainer votes recorded as GitHub PR comments or in `MAINTAINERS.md`.
- Corpus moderation log published quarterly (record counts; take-down counts; appeal outcomes — never individual record content).
- Benchmark results reproducible from `agentdebugx bench` outputs; raw logs published per release.

## 12. Funding / sponsorship

- AgentDebugX accepts grants and sponsorships through a fiscal host (TBD).
- Sponsors do **not** receive influence over RFCs, taxonomy, or corpus moderation.
- Sponsor list published in `README.md` and on the docs site.

## 13. Trademark

The name "AgentDebugX" and associated logos are project marks. Forks may use the name only in the form "fork of AgentDebugX." Derivative names should not include "AgentDebugX" as the primary identifier.

## 14. Evolution of governance

This document evolves via `rfc_governance.yml` with a 14-day comment window and 2/3 maintainer approval.
