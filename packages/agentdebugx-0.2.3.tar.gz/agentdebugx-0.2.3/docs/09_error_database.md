# 09 — Community Error Database (ADBXCorpus)

## 1. Vision

A community-curated, versioned corpus of LLM-agent failure trajectories — think *CWE for agents* combined with a Hugging Face dataset of trace + label + resolved-fix triples.

Local-first by default. Users explicitly opt in to upload (with automatic PII scrubbing). The corpus serves three purposes:

1. **Similar-case retrieval** for fix recommendation.
2. **Benchmark** for attribution / detection / recovery research.
3. **Taxonomy induction** input — new failure modes surfaced from raw traces.

## 2. Record schema

```python
class CorpusRecord(BaseModel):
    record_id: str                   # ULID
    schema_version: str = "0.1.0"
    submitted_at: datetime
    submitter_org: str | None        # opt-in attribution
    license: SPDXLicense             # default: CC-BY-4.0; user-overridable per record

    # The trace
    trace: Trace                     # canonical schema (04_trace_schema.md)
    framework: FrameworkId
    framework_version: str

    # Labels
    labels: list[LabelSet]
    label_provenance: Literal["human", "llm_judge", "rule", "ensemble"]
    label_agreement: float | None    # kappa if multiple annotators

    # Fix (if resolved)
    resolved: bool
    fix_history: list[AppliedFix]    # each: recoverer_id, payload, outcome

    # Metadata
    task_domain: str | None          # e.g., "web_browsing", "code_generation"
    benchmark: str | None            # e.g., "GAIA", "AgentErrorBench"
    benchmark_task_id: str | None
    tags: list[str]

    # Search index helpers
    embedding: list[float] | None    # 768-dim sentence-transformers
    task_signature: str              # hash of normalized task description
```

## 3. Storage layout

### 3.1 Local

```
~/.agentdebugx/
├── runs.db              # SQLite metadata index
├── corpus.duckdb        # DuckDB analytic table over local + synced records
├── traces/              # Parquet, one file per run
│   └── tr_01J…/run.parquet
├── manuals/             # AutoManual rule artifacts per project
├── settings.yaml
└── cache/               # embedding cache, dedup hashes
```

### 3.2 Hosted (errors.agentdebugx.dev)

- PostgreSQL for metadata + auth.
- Object storage (S3-compatible) for Parquet traces.
- pgvector for embedding similarity.
- Read-only public mirror published to Hugging Face Datasets monthly.

## 4. Ingestion

### 4.1 Local ingestion (always on)

Every traced run lands in the local SQLite + Parquet store.

### 4.2 Community upload (opt-in)

```python
agentdebugx.init(
    sync=SyncConfig(
        enabled=False,                    # opt in explicitly
        only_failed=True,                 # don't upload successful runs by default
        scrub_pii=True,
        scrub_secrets=True,
        max_per_day=100,
        license="CC-BY-4.0",
    )
)
```

CLI:

```bash
agentdebugx publish tr_01J…       # publish one trace
agentdebugx publish --since 7d    # publish all failed traces from past 7 days
```

### 4.3 Dedup

Before upload, AgentDebugX computes a `task_signature` (hash of normalized task + framework + key tool sequence) and an embedding. The server rejects near-duplicates (cosine > 0.95 + same task_signature) and returns the canonical record ID instead.

### 4.4 Scrubbing

Two passes:

1. **Tool-arg redaction** — every `ToolDef` declares which args are sensitive; those fields are replaced with `<redacted:type>`.
2. **Presidio-style PII detection** over all free-text fields (system prompts, messages, tool outputs).

## 5. Query API

```python
from agentdebugx.corpus import Corpus

corpus = Corpus(backend="local")  # or "hosted"

# Structured query
results = corpus.query(
    labels__contains=["FM-2.3"],
    framework="langgraph",
    resolved=True,
    limit=20,
)

# Semantic query
results = corpus.similar_to(my_trace, k=10, axes=["FM-*"])

# SQL escape hatch (DuckDB)
df = corpus.sql("SELECT framework, labels, count(*) FROM records GROUP BY 1,2")
```

REST endpoints mirror the Python API.

## 6. Hugging Face mirror

Monthly snapshot pushed to `huggingface.co/datasets/agentdebugx/ADBXCorpus-vYYYY.MM`. Schema is the same Pydantic models serialized to Parquet. License: CC-BY-4.0 (records may override).

## 7. Versioning

Each release of the schema bumps `schema_version`. The hosted server keeps all historical schemas behind compatibility shims; the Python client auto-upgrades on read.

Taxonomy versioning is independent — a record carries `(schema_version, taxonomy_version)`. Old records can be re-labeled under newer taxonomies through the induction pipeline.

## 8. Governance

- **Submitter agreement**: by uploading, the submitter affirms the right to share the trace under the chosen license. Default CC-BY-4.0; "internal-only" records can be marked `do_not_publish=True` for local corpus only.
- **Takedown**: submitter (and org if applicable) can request deletion via signed email. Process documented in `docs/16_governance.md`.
- **Provenance audit**: every record carries cryptographic chain-of-custody (submitter signature, server timestamp, hash).

## 9. Privacy threat model

Worst-case: a trace contains a private API key or proprietary business logic. Mitigations:

- **Default scrub on upload**, never disable silently.
- **Local-only mode** is the default; cloud is opt-in.
- **Encryption at rest** for hosted store (envelope encryption per submitter).
- **Audit logs** for every read of a private record.

## 10. Anti-abuse

- Rate-limited per IP / per token.
- Spam detection: embedding-cluster + identical-trace abuse → flagged for moderation.
- Adversarial submissions (e.g., poisoning the corpus): every record has a moderation queue for high-impact upserts (e.g., new "canonical fix"); standard submissions are auto-accepted but flagged by anomaly detection.

## 11. Bench harness integration

`agentdebugx.bench` provides one-command benchmarking:

```bash
agentdebugx bench attribution --against who-when --backend ensemble
agentdebugx bench detection --against MAD --judges mast_judge,agent_debug_judge
agentdebugx bench recovery --against AgentErrorBench --strategies reflexion,critic
```

Results land in `docs/benchmarks/*.md` per release and feed into the `calibration_report()` surfaces.
