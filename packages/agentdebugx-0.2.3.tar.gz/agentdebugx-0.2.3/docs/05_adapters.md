# 05 — Framework Adapters

## 1. Adapter contract

Every adapter implements:

```python
class FrameworkAdapter(Protocol):
    framework_id: FrameworkId

    @classmethod
    def detect(cls) -> bool:
        """Return True if this framework is importable in the current env."""

    def attach(self, ctx: AdapterContext) -> None:
        """Register hooks / callbacks / OTel processors. Idempotent."""

    def detach(self) -> None:
        """Remove all hooks. Restore monkey-patched symbols if any."""

    def emit(self, evt: NativeEvent) -> None:
        """Translate native event → AgentDebugX Event + OTel span."""
```

`AdapterContext` carries:

```python
class AdapterContext(BaseModel):
    tracer_provider: TracerProvider
    event_bus: EventBus
    project: str
    redactor: Redactor
    config: AdapterConfig
```

## 2. Auto-detection

```python
# agentdebugx/adapters/__init__.py
ADAPTERS: list[type[FrameworkAdapter]] = [
    AutoGenAdapter, AG2Adapter, LangGraphAdapter, CrewAIAdapter,
    OpenAIAgentsAdapter, OpenHandsAdapter, SmolagentsAdapter,
    LlamaIndexAdapter, DSPyAdapter, PydanticAIAdapter,
    HaystackAdapter, MetaGPTAdapter, CamelAIAdapter,
    ClaudeCodeAdapter,
    VanillaLoopAdapter,   # always last; auto-instruments openai/anthropic SDKs
]

def auto_attach(ctx: AdapterContext) -> list[FrameworkAdapter]:
    attached = []
    for cls in ADAPTERS:
        if cls.detect():
            a = cls()
            a.attach(ctx)
            attached.append(a)
    return attached
```

## 3. Reference adapters

### 3.1 AutoGen v0.4+

```python
class AutoGenAdapter:
    framework_id = FrameworkId.AUTOGEN

    @classmethod
    def detect(cls) -> bool:
        try:
            import autogen_core  # noqa
            return True
        except ImportError:
            return False

    def attach(self, ctx):
        # AutoGen v0.4+ accepts a tracer_provider on SingleThreadedAgentRuntime.
        # We install ours globally and also register a log handler.
        from autogen_core import logging as ac_logging, EVENT_LOGGER_NAME
        import logging
        logging.getLogger(EVENT_LOGGER_NAME).addHandler(
            _BridgeHandler(ctx.event_bus, framework=self.framework_id)
        )
        # The user code path: pass ctx.tracer_provider to their runtime constructor.
        # We surface a helper:
        from agentdebugx.adapters.autogen import build_tracer_provider
        build_tracer_provider._configure(ctx.tracer_provider)
```

User code:
```python
from autogen_core import SingleThreadedAgentRuntime
from agentdebugx.adapters.autogen import build_tracer_provider
runtime = SingleThreadedAgentRuntime(tracer_provider=build_tracer_provider())
```

### 3.2 AG2 (autogen v0.2 fork)

```python
class AG2Adapter:
    framework_id = FrameworkId.AG2

    @classmethod
    def detect(cls) -> bool:
        try:
            import autogen
            return hasattr(autogen, "ConversableAgent") and not hasattr(autogen, "agentchat")
        except ImportError:
            return False

    def attach(self, ctx):
        from autogen import ConversableAgent
        bus = ctx.event_bus

        for site in ("update_agent_state", "process_last_received_message",
                     "process_all_messages_before_reply"):
            ConversableAgent.register_hook(
                hookable_method=site,
                hook=_make_hook(site, bus, self.framework_id),
            )
        # Plus: AG2 emits OTel; install our processor on its TracerProvider.
        _install_otel_processor(ctx.tracer_provider)
```

### 3.3 LangGraph / LangChain

```python
from langchain_core.callbacks import BaseCallbackHandler

class LangGraphAdapter(BaseCallbackHandler):
    framework_id = FrameworkId.LANGGRAPH

    @classmethod
    def detect(cls) -> bool:
        try:
            import langgraph  # noqa
            return True
        except ImportError:
            return False

    def attach(self, ctx):
        from langchain.globals import set_handler
        self._ctx = ctx
        set_handler(self)

    def on_chain_start(self, serialized, inputs, run_id, parent_run_id=None, **kw):
        self._ctx.event_bus.publish(SpanStartEvent(
            framework=self.framework_id, span_id=str(run_id),
            parent_span_id=str(parent_run_id) if parent_run_id else None,
            operation="invoke_agent" if _is_agent_chain(serialized) else "invoke_workflow",
            attributes=_normalize_chain_attrs(serialized, inputs),
        ))
    # … on_chain_end, on_tool_start/end, on_llm_start/end, on_agent_action, on_agent_finish
```

### 3.4 CrewAI

```python
from crewai.events import BaseEventListener, crewai_event_bus
from crewai.events import (
    LLMCallStartedEvent, LLMCallCompletedEvent,
    ToolUsageStartedEvent, ToolUsageFinishedEvent,
    TaskStartedEvent, TaskCompletedEvent, AgentExecutionCompletedEvent,
)

class _CrewListener(BaseEventListener):
    def __init__(self, ctx): super().__init__(); self._ctx = ctx
    def setup_listeners(self, bus):
        @bus.on(LLMCallStartedEvent)
        def _(s, e): self._ctx.event_bus.publish(_to_span_start(e, op="chat"))
        @bus.on(LLMCallCompletedEvent)
        def _(s, e): self._ctx.event_bus.publish(_to_span_end(e))
        @bus.on(ToolUsageStartedEvent)
        def _(s, e): self._ctx.event_bus.publish(_to_span_start(e, op="execute_tool"))
        # …

class CrewAIAdapter:
    framework_id = FrameworkId.CREWAI
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("crewai") is not None
    def attach(self, ctx): self._listener = _CrewListener(ctx)   # MUST keep ref to avoid GC
```

### 3.5 OpenAI Agents SDK

```python
from agents.tracing import add_trace_processor, TracingProcessor

class _OpenAIProcessor(TracingProcessor):
    def __init__(self, ctx): self._ctx = ctx
    def on_trace_start(self, trace): self._ctx.event_bus.publish(_to_run_start(trace))
    def on_trace_end(self, trace):   self._ctx.event_bus.publish(_to_run_end(trace))
    def on_span_start(self, span):   self._ctx.event_bus.publish(_translate_span_start(span))
    def on_span_end(self, span):     self._ctx.event_bus.publish(_translate_span_end(span))

class OpenAIAgentsAdapter:
    framework_id = FrameworkId.OPENAI_AGENTS
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("agents") is not None
    def attach(self, ctx): add_trace_processor(_OpenAIProcessor(ctx))
```

### 3.6 OpenHands

```python
from openhands.events import EventStreamSubscriber

class OpenHandsAdapter:
    framework_id = FrameworkId.OPENHANDS
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("openhands") is not None

    def attach(self, ctx):
        self._ctx = ctx
        # OpenHands is event-stream-per-conversation; user must call:
        #   adapter.bind(conversation)
        # We can't auto-bind because EventStream is per-Conversation, not global.

    def bind(self, conversation):
        conversation.event_stream.subscribe(
            EventStreamSubscriber.MAIN, self._on_event, subscriber_id="agentdebugx"
        )

    def _on_event(self, event):
        self._ctx.event_bus.publish(_openhands_event_to_span(event))
```

### 3.7 smolagents

```python
class SmolagentsAdapter:
    framework_id = FrameworkId.SMOLAGENTS
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("smolagents") is not None
    def attach(self, ctx):
        from openinference.instrumentation.smolagents import SmolagentsInstrumentor
        SmolagentsInstrumentor().instrument(tracer_provider=ctx.tracer_provider)
        # Plus subscribe our SpanProcessor to bridge to our bus.
        _install_otel_processor(ctx.tracer_provider)
```

### 3.8 LlamaIndex

```python
class LlamaIndexAdapter:
    framework_id = FrameworkId.LLAMAINDEX
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("llama_index") is not None
    def attach(self, ctx):
        from llama_index.core.instrumentation import get_dispatcher
        from llama_index.core.instrumentation.event_handlers import BaseEventHandler

        class H(BaseEventHandler):
            def handle(self_, event): ctx.event_bus.publish(_li_event_to_span(event))

        d = get_dispatcher()
        d.add_event_handler(H())
        d.add_span_handler(_LiSpanHandler(ctx))
```

### 3.9 DSPy

```python
class DSPyAdapter:
    framework_id = FrameworkId.DSPY
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("dspy") is not None
    def attach(self, ctx):
        import dspy
        from dspy.utils.callback import BaseCallback

        class Cb(BaseCallback):
            def on_module_start(self_, ev): ctx.event_bus.publish(_to_span_start(ev))
            def on_module_end(self_, ev): ctx.event_bus.publish(_to_span_end(ev))
            def on_lm_start(self_, ev): ctx.event_bus.publish(_to_span_start(ev, op="chat"))
            def on_lm_end(self_, ev): ctx.event_bus.publish(_to_span_end(ev))
            def on_tool_start(self_, ev): ctx.event_bus.publish(_to_span_start(ev, op="execute_tool"))
            def on_tool_end(self_, ev): ctx.event_bus.publish(_to_span_end(ev))

        dspy.configure(callbacks=[Cb()])
```

### 3.10 Pydantic-AI

```python
class PydanticAIAdapter:
    framework_id = FrameworkId.PYDANTIC_AI
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("pydantic_ai") is not None
    def attach(self, ctx):
        from pydantic_ai import Agent, InstrumentationSettings
        Agent.instrument_all(InstrumentationSettings(tracer_provider=ctx.tracer_provider))
        _install_otel_processor(ctx.tracer_provider)
```

### 3.11 MetaGPT (monkey-patch fallback)

```python
class MetaGPTAdapter:
    framework_id = FrameworkId.METAGPT
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("metagpt") is not None
    def attach(self, ctx):
        from metagpt.roles.role import Role
        from metagpt.environment import Environment
        self._orig_role_think = Role._think
        self._orig_role_act = Role._act
        self._orig_env_pub = Environment.publish_message
        Role._think = _wrap_role_think(self._orig_role_think, ctx)
        Role._act = _wrap_role_act(self._orig_role_act, ctx)
        Environment.publish_message = _wrap_env_publish(self._orig_env_pub, ctx)
    def detach(self):
        # restore
        ...
```

### 3.12 Camel-AI

```python
class CamelAIAdapter:
    framework_id = FrameworkId.CAMEL
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("camel") is not None
    def attach(self, ctx):
        from camel.agents import ChatAgent
        self._orig_step = ChatAgent.step
        ChatAgent.step = _wrap_chat_step(self._orig_step, ctx)
```

### 3.13 Haystack 2.x

```python
class HaystackAdapter:
    framework_id = FrameworkId.HAYSTACK
    @classmethod
    def detect(cls): import importlib.util; return importlib.util.find_spec("haystack") is not None
    def attach(self, ctx):
        from haystack import tracing
        tracing.tracer.actual_tracer = _BridgeTracer(ctx)
```

### 3.14 Vanilla loop (ReAct / raw SDK)

```python
class VanillaLoopAdapter:
    framework_id = FrameworkId.VANILLA
    @classmethod
    def detect(cls):
        # Always returns True — this is the fallback. But only emits if
        # the OpenAI / Anthropic / LiteLLM SDKs are present.
        return True

    def attach(self, ctx):
        try:
            from openinference.instrumentation.openai import OpenAIInstrumentor
            OpenAIInstrumentor().instrument(tracer_provider=ctx.tracer_provider)
        except ImportError: pass
        try:
            from openinference.instrumentation.anthropic import AnthropicInstrumentor
            AnthropicInstrumentor().instrument(tracer_provider=ctx.tracer_provider)
        except ImportError: pass
        try:
            from openinference.instrumentation.litellm import LiteLLMInstrumentor
            LiteLLMInstrumentor().instrument(tracer_provider=ctx.tracer_provider)
        except ImportError: pass
        _install_otel_processor(ctx.tracer_provider)
```

Plus a decorator for step boundaries the user controls:

```python
@agentdebugx.trace_loop(name="react_agent")
def run(query): ...
agentdebugx.step(observation=resp)  # marks a step boundary inside the loop
```

### 3.15 Claude Code / coding-agent CLI

Claude Code is useful as a design reference even before AgentDebugX ships a
full adapter. A future adapter should support two modes:

1. **Passive import:** ingest exported transcripts, tool-call logs, file diffs,
   and local project state into the canonical trace schema.
2. **Live integration:** provide hook handlers or an MCP server so Claude Code
   can call AgentDebugX during a session.

Design targets:

- Capture lifecycle events such as session start/end, pre-tool use,
  post-tool use, permission request, subagent start/stop, compaction, and file
  change when available.
- Preserve permission decisions as `DecisionRecord` objects.
- Preserve subagent delegation prompts and return contracts as
  `HandoffContract` objects.
- Expose AgentDebugX resources over MCP:
  `trace://{run_id}`, `report://{report_id}`, `taxonomy://{code}`, and
  `corpus://similar/{run_id}`.
- Provide tools such as `analyze_trace`, `search_errors`, `propose_fix`, and
  `export_repro_bundle`.

## 4. Conformance test suite

Each adapter ships with a `tests/adapters/test_<framework>.py` that:

1. Starts a minimal agent in the target framework.
2. Asserts the adapter emits the expected sequence of spans.
3. Validates every span against `agentdebugx.schema`.
4. Verifies OTel attributes follow GenAI semconv.

A shared "golden trace" replay fixture ensures all adapters can round-trip through the same canonical scenarios (single-LLM call, tool call, multi-agent handoff, failure).

## 5. Adapter capabilities matrix

Some features require framework support. AgentDebugX declares per-adapter capabilities:

```python
class AdapterCapabilities(BaseModel):
    supports_checkpointing: bool       # for time-travel debugging
    supports_step_intercept: bool      # can pause agent at a step?
    supports_replay: bool              # can re-execute from a saved state?
    emits_native_otel: bool
    has_event_bus: bool
```

Detectors / Recoverers query the matrix before requesting features that may not be available.

## 6. Error budget

When an adapter fails to emit (e.g., framework version mismatch), AgentDebugX:

1. Logs once at WARN level.
2. Increments a `adapter.emit.errors` counter.
3. After 50 errors in 60s, the adapter is auto-detached. The agent keeps running.

This guarantees AgentDebugX **never breaks the host agent**.
