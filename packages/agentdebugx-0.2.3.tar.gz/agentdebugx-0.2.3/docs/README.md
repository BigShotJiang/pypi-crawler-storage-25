# AgentDebugX — Design Documentation

AgentDebugX is an open-source Python library that brings **standardized error analysis, debugging, attribution, and recovery** to *any* LLM agent framework. Import it, attach one line, and your existing agent (AutoGen, LangGraph, CrewAI, OpenAI Agents SDK, OpenHands, smolagents, LlamaIndex, DSPy, Pydantic-AI, MetaGPT, Camel-AI, or a raw ReAct loop) emits a uniform trajectory, gets continuously checked for known and emerging failure modes, contributes to a community error database, and receives concrete fix suggestions.

This `docs/` directory contains the full design specification.

## Document map

| # | File | Topic |
|---|------|-------|
| 00 | [00_overview.md](./00_overview.md) | Vision, problem statement, scope, north-star UX |
| 01 | [01_literature_survey.md](./01_literature_survey.md) | Consolidated lit review (papers + repos AgentDebugX builds on) |
| 02 | [02_architecture.md](./02_architecture.md) | System architecture — 7 layers, data flow, deployment modes |
| 03 | [03_taxonomy.md](./03_taxonomy.md) | The AgentDebugX-Tax v0.1 error taxonomy (MAST + AgentDebug-5 + extensions) |
| 04 | [04_trace_schema.md](./04_trace_schema.md) | Canonical trace data model (OTel GenAI semconv aligned) |
| 05 | [05_adapters.md](./05_adapters.md) | Per-framework adapter contracts and reference implementations |
| 06 | [06_detectors.md](./06_detectors.md) | Runtime + offline error detectors (rule, anomaly, LLM-judge, spec) |
| 07 | [07_attribution.md](./07_attribution.md) | Failure attribution backends (All-at-Once, Step-by-Step, Binary-Search, Counterfactual, SBFL, Delta-Debugging) |
| 08 | [08_recovery.md](./08_recovery.md) | Recovery strategies (Reflexion, Self-Refine, CRITIC, AutoManual, Saga rollback) |
| 09 | [09_error_database.md](./09_error_database.md) | Community error database — schema, ingestion, dedup, search |
| 10 | [10_taxonomy_induction.md](./10_taxonomy_induction.md) | Auto-taxonomy induction (TnT-LLM, BERTopic, goal-conditioned, HITL) |
| 11 | [11_multimodal.md](./11_multimodal.md) | Multimodal & GUI-agent debugging (screenshots, DOM diff, click-trace) |
| 12 | [12_ui_dashboard.md](./12_ui_dashboard.md) | Web UI / TUI / IDE-extension design |
| 13 | [13_class_design.md](./13_class_design.md) | Detailed Python class & module design |
| 14 | [14_api_reference.md](./14_api_reference.md) | Public API surface — what users import |
| 15 | [15_roadmap.md](./15_roadmap.md) | v0 → v1 → v2 roadmap, milestones, gates |
| 16 | [16_governance.md](./16_governance.md) | Open-source governance, RFCs, taxonomy versioning |
| 17 | [17_claude_code_design_patterns.md](./17_claude_code_design_patterns.md) | Claude Code-inspired runtime patterns: hooks, permissions, skills, subagents, MCP, plugins |
| 18 | [18_comparison_codex_vs_design.md](./18_comparison_codex_vs_design.md) | Comparison of the working Codex scaffold and the expanded design spec |
| 18 | [18_comparison_codex_vs_design.md](./18_comparison_codex_vs_design.md) | Reconciliation of the Codex scaffold with this design spec — the merged v0.1 plan |
| 19 | [19_error_hub.md](./19_error_hub.md) | **Error Hub** — bundle format, Local / Git / HF backends, scrubbing |
| 20 | [20_deep_debug.md](./20_deep_debug.md) | **DeepDebug** — iterative multi-turn analysis (plan → hypothesize → verify → refine) |
| 21 | [21_integrations.md](./21_integrations.md) | **Claude Code Skill** + **OpenHands** microagent + EventStream bridge |
| 22 | [22_industry_track_paper_eval_plan.md](./22_industry_track_paper_eval_plan.md) | EMNLP Industry Track writing strategy + benchmark / human-study evaluation plan |
| 23 | [23_status_v0_2.md](./23_status_v0_2.md) | **Capability + test coverage status (v0.2.2)** — what's implemented, what's tested, what's specced but not built |

Plus three **narrative** docs that pre-dated this engineering spec and are kept for paper-style framing:

- [RESEARCH_SURVEY.md](./RESEARCH_SURVEY.md) — concise paper-by-paper narrative survey (AgentDebug, MAST, Who&When, AgentRx, AgenTracer, AgentTrace, AgentStepper, AgentOps, AgentSight)
- [OPEN_SOURCE_DEVELOPMENT_PLAN.md](./OPEN_SOURCE_DEVELOPMENT_PLAN.md) — mission / principles / SDK milestones in prose
- [ERROR_TAXONOMY.md](./ERROR_TAXONOMY.md) — readable rendering of the live 19 seed modes in `agentdebug.taxonomy`

## Status

`v0.1-design+impl` — engineering spec (docs 00–16) reconciled with the Codex scaffold (commit `93d6670`) per doc 17. Reference implementation lives in `src/agentdebug/`.

## How to read this

- **First-time reader:** start with [00_overview.md](./00_overview.md), then [02_architecture.md](./02_architecture.md), then [14_api_reference.md](./14_api_reference.md).
- **Researcher / paper author:** read [01_literature_survey.md](./01_literature_survey.md), [03_taxonomy.md](./03_taxonomy.md), [07_attribution.md](./07_attribution.md), [10_taxonomy_induction.md](./10_taxonomy_induction.md), and [22_industry_track_paper_eval_plan.md](./22_industry_track_paper_eval_plan.md).
- **Framework integrator:** read [04_trace_schema.md](./04_trace_schema.md), [05_adapters.md](./05_adapters.md), [13_class_design.md](./13_class_design.md).
- **UI / product:** read [12_ui_dashboard.md](./12_ui_dashboard.md), [09_error_database.md](./09_error_database.md).
- **Runtime / agent UX designer:** read [17_claude_code_design_patterns.md](./17_claude_code_design_patterns.md), then [02_architecture.md](./02_architecture.md), [08_recovery.md](./08_recovery.md), and [14_api_reference.md](./14_api_reference.md).
