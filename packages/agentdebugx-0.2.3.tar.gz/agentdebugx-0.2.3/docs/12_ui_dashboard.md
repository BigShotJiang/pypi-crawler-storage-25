# 12 — UI / Dashboard / IDE

## 1. Surfaces

| Surface | Audience | Tech |
|---|---|---|
| **Web Console** | All users | React 18 + Vite + Tailwind + shadcn/ui; served by `agentdebugx serve` (FastAPI backend) |
| **TUI** | CLI-heavy users, SSH-only sessions | Textual |
| **VSCode extension** | Developers in their IDE | TypeScript + Webview API |
| **CLI** | Automation, CI | Click + Rich |
| **REST + WebSocket API** | Custom integrations, dashboards | FastAPI; OpenAPI 3.1 schema |

## 2. Web Console — information architecture

```
┌─ Sidebar ─────────────┐ ┌─ Main ────────────────────────────────────┐
│ Projects              │ │                                            │
│   ▸ my-agent          │ │   Runs · Errors · Taxonomy · Corpus · Bench│
│   ▸ research-bot      │ │                                            │
│ Recent Runs           │ │                                            │
│ Saved Filters         │ │                                            │
│ Detectors             │ │                                            │
│ Recoverers            │ │                                            │
│ Settings              │ │                                            │
└───────────────────────┘ └────────────────────────────────────────────┘
```

### Tabs (per project)

#### a) Runs

- Table view (run_id, started, framework, status, duration, #errors, top-error).
- Filters: status, framework, label, severity, date range, text search.
- Drill into a run → **Trace view**.

#### b) Trace view (the centerpiece)

```
┌─ Step timeline (vertical) ─┐ ┌─ Detail pane ──────────────────────┐
│ 1. invoke_workflow         │ │  Span: 7 · invoke_agent(researcher)│
│ 2. invoke_agent researcher │ │  Started: 14:02:13                  │
│ 3. chat (gpt-4o)           │ │  Duration: 3.2s                     │
│ 4. execute_tool search ✕   │ │  Model: gpt-4o                      │
│ 5. chat                    │ │  Tokens: 1402 in / 287 out          │
│ 6. handoff → writer        │ │                                     │
│ 7. invoke_agent writer ⚠   │ │  Detected errors:                   │
│ 8. chat                    │ │   • FM-2.3 task_derailment HIGH 0.78│
│ 9. execute_tool publish    │ │     [evidence] [counterfactual]     │
│10. <end>                   │ │                                     │
│                            │ │  Blame:                             │
│   [errors panel]           │ │   step 4 (counterfactual, 0.71)     │
│   [blame panel]            │ │                                     │
│   [fix proposals]          │ │  Suggested fixes:                   │
│   [similar cases]          │ │   1. Tighten search_web JSON schema │
│                            │ │   2. Add clarification loop         │
└────────────────────────────┘ └─────────────────────────────────────┘
```

- **Time-travel slider**: rewind to any step; replay forward with different model / different counterfactual.
- **Diff view**: counterfactual rollout vs actual; side-by-side messages.
- **Multimodal panel** (if present): screenshots, DOM diffs, click overlays.
- **Raw OTel**: collapsible JSON of the raw span — escape hatch for power users.

#### c) Errors

- Cross-run error browser.
- Group by label (any axis), framework, severity, recency.
- Click into an aggregated card → list of runs exhibiting that error, fix history.

#### d) Taxonomy

- Tree view of AgentDebugX-Tax v0.1.
- Each code: description, examples, detector coverage, recoverer coverage, related papers.
- "Propose new code" button → opens RFC issue prefilled with telemetry.

#### e) Corpus

- Search the local + (opt-in) community corpus.
- Embedding similarity slider.
- Bulk publish controls (with PII-scrubbing diff preview).
- Take-down / re-license tools.

#### f) Bench

- Render latest `docs/benchmarks/*.md` content.
- Trigger a benchmark run (Who&When, MAD, AgentErrorBench) with progress live-streamed.

#### g) Runtime Control

Inspired by Claude Code's operational surfaces, AgentDebugX should expose a
control-plane view for live debugging:

- Hooks: enabled lifecycle hooks, recent decisions, failures, latency.
- Permissions: allow/ask/deny rules and which rule matched each blocked action.
- Plugins: loaded adapters, detector packs, taxonomy packs, MCP tools, and UI
  panels.
- Context budget: which components add model-visible context and when.
- Stop gates: final-validation checks that blocked or allowed completion.
- Retention: raw artifact lifetime, scrubbed-summary lifetime, purge status.

## 3. TUI

```
agentdebugx tui
```

Three-pane layout (Textual):

- Left: runs list.
- Middle: step timeline.
- Right: detail / errors / blame / fixes.

Keyboard-driven. Shortcuts: `/` search, `e` errors, `b` blame, `f` fixes, `r` replay, `q` quit.

## 4. VSCode extension

- Tree view in the activity bar: projects → recent runs.
- Inline annotations in source code that called `agent.run()`: gutter icons show the latest run's status and a click opens the trace.
- Webview embedding the trace view (shared React components).
- "Breakpoint-on-error" (v2): registers a Python `sys.settrace` hook so that on a configured error code, execution pauses and the trace view opens inline.

## 5. CLI

```
agentdebugx --help
  init                    # create config + DB
  run [program] …         # run a script with full instrumentation
  attach <pid>            # attach to a running process (best-effort)
  serve [--port 7777]     # start the web Console
  tui                     # start the TUI
  analyze <run_id>        # offline analysis pipeline
  replay <run_id>         # replay with optional counterfactuals
  bench <suite>           # run a benchmark
  publish <run_id>        # publish to community corpus
  db search <query>       # full-text + semantic search
  taxonomy show           # print taxonomy tree
  taxonomy export         # YAML / JSON / docs.md
  doctor                  # diagnose adapter / config issues
  status                  # show runtime state, active adapters, DB path
  hooks test              # dry-run hook handlers against a fixture event
  plugin validate         # validate a detector/recoverer/taxonomy pack
  plugin reload           # reload local plugin packs during development
  project purge           # delete local traces/artifacts, with --dry-run
  privacy scan            # scan local trace DB for secrets/PII
```

All CLI commands also work in non-interactive (JSON output) mode for CI / scripting.

## 6. REST + WebSocket API

OpenAPI 3.1 schema generated from FastAPI. Key resources:

```
GET    /v1/projects
GET    /v1/projects/{project}/runs
GET    /v1/runs/{run_id}
GET    /v1/runs/{run_id}/trace
GET    /v1/runs/{run_id}/errors
GET    /v1/runs/{run_id}/blame
GET    /v1/runs/{run_id}/fixes
POST   /v1/runs/{run_id}/replay
POST   /v1/runs/{run_id}/publish
GET    /v1/corpus/search
GET    /v1/taxonomy
WS     /v1/projects/{project}/stream    # live trace + error events
```

WebSocket events follow the same Pydantic models as the Python API.

## 7. Auth

- Local mode: no auth (loopback only by default).
- Self-hosted: pluggable (OIDC, GitHub OAuth, basic auth). API tokens for CI.
- Hosted mode (future): OAuth + per-org RBAC.

## 8. Theming & accessibility

- WCAG 2.1 AA target.
- Dark mode by default; light mode toggle.
- Keyboard navigation through every interactive element.
- Screen-reader labels on all timeline + diff elements.

## 9. Performance budget

- Trace view: render < 1s for runs with ≤ 1000 spans.
- Lazy-load span detail; virtualized timeline.
- For runs > 1000 spans (long-horizon agents): collapse by subtree; show a minimap.

## 10. Telemetry (opt-in)

Console-level telemetry (events fired, latency) is **disabled by default**. Users opt in to help calibrate Console performance. No trace content ever leaves without explicit publish.

## 11. Embeddable widget

For users who want to embed AgentDebugX views into their own dashboard (Streamlit, Gradio, internal portal):

```python
from agentdebugx.ui.embed import trace_widget
trace_widget(run_id="tr_01J…")  # returns an IFrame / HTML component
```
