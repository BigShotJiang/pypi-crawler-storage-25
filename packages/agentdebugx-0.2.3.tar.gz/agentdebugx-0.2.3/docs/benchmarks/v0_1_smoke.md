# AgentDebugX v0.1 Live Smoke Benchmark

Cases: **6**.  Model: `gemini-3-flash`.  Run-by: `scripts/eval_v0_1.py`.

## Aggregate

| Metric | Score |
|---|---|
| Rule-baseline family match | 50% |
| LLM-judge family match | 67% |
| LLM-judge step localization | 50% |
| All-at-Once blame step localization | 50% |

All-at-Once mirrors the **Who&When** All-at-Once method (arXiv:2505.00212); published step localization is ~14%, so expect modest absolute numbers here too.

## Per-case results

| Case | Expected family / step | Rule fam | Judge fam | Judge step | Blame step | Conf | Lat (s) |
|---|---|---|---|---|---|---|---|
| `action_format_error` | action / s3 | ✗ system | ✓ action | ✗ s2 | ✗ s2 | 1.00 | 8.5 |
| `planning_inefficient_loop` | planning / s2 | ✓ planning | ✓ planning | ✗ s3 | ✗ s3 | 1.00 | 14.4 |
| `verification_premature_stop` | verification / s2 | ✗ — | ✗ reflection | ✓ s2 | ✓ s2 | 0.95 | 18.5 |
| `system_tool_execution_error` | system / s3 | ✓ system | ✗ planning | ✗ s1 | ✗ s1 | 0.90 | 17.4 |
| `multiagent_handoff_loss` | multiagent / s2 | ✓ multiagent | ✓ multiagent | ✓ s2 | ✓ s2 | 1.00 | 9.2 |
| `memory_retrieval_failure` | memory / s1 | ✗ — | ✓ memory | ✓ s1 | ✓ s1 | 0.90 | 11.0 |

## Findings detail (judge)

### `action_format_error` — Find the latest AgentDebug paper and summarize the method

- `action.parameter_error` family=`action` step=2 confidence=1.00

### `planning_inefficient_loop` — Submit the form to complete checkout

- `planning.inefficient_plan` family=`planning` step=3 confidence=1.00
- `planning.inefficient_plan` family=`planning` step=4 confidence=1.00
- `planning.inefficient_plan` family=`planning` step=5 confidence=1.00
- `planning.inefficient_plan` family=`planning` step=6 confidence=1.00

### `verification_premature_stop` — Summarize the paper thoroughly

- `reflection.progress_misjudge` family=`reflection` step=2 confidence=0.95

### `system_tool_execution_error` — Book a refundable flight from CHI to NYC

- `planning.constraint_ignorance` family=`planning` step=1 confidence=0.90
- `action.parameter_error` family=`action` step=2 confidence=0.90
- `system.tool_execution_error` family=`system` step=3 confidence=1.00

### `multiagent_handoff_loss` — Find the best paper and summarize it

- `multiagent.handoff_loss` family=`multiagent` step=2 confidence=1.00

### `memory_retrieval_failure` — Plan a respectful gift respecting user constraints

- `memory.retrieval_failure` family=`memory` step=1 confidence=1.00
- `planning.constraint_ignorance` family=`planning` step=2 confidence=1.00

