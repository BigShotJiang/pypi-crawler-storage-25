# 11 — Multimodal & GUI Agent Debugging

## 1. Scope

Computer-use / browser-use / GUI-agent failures cannot be diagnosed from text alone. AgentDebugX adds (v2) multimodal trace recording and a perception/grounding/action sub-taxonomy.

Targets:

- **Anthropic Claude Computer Use** (desktop sandbox).
- **OpenAI CUA / Operator** ([openai/openai-cua-sample-app](https://github.com/openai/openai-cua-sample-app)).
- **OpenHands browser agent**.
- **Playwright/Selenium-driven custom agents**.
- **trycua / OSWorld** style sandboxes.

OSWorld (arXiv:2404.07972) reports best-model 12.2% vs human 72.4% — almost all failures are perception + grounding + operational knowledge, which is what this section addresses.

## 2. Sub-taxonomy (multimodal extension to AgentDebugX-Tax)

| Code | Name | Description |
|---|---|---|
| `MM.PER.OCR` | OCR misread | Text on screen was read incorrectly |
| `MM.PER.OBJ` | Object miscount / misclassify | Agent miscounted or mislabeled a visual element |
| `MM.GR.CLK` | Click on wrong element | Coordinates landed off-target |
| `MM.GR.SC` | Scroll past target | Did not stop at target element |
| `MM.GR.MOD` | Modal-dialog confusion | Did not recognize a modal blocking input |
| `MM.GR.STA` | Stale state | Acted on screenshot taken before state change |
| `MM.ACT.SEQ` | Wrong action sequence order | e.g., submitted form before filling required field |
| `MM.ACT.TIM` | Timing race | Acted before page/app finished rendering |
| `MM.ACT.KEY` | Wrong keyboard input | Typed in wrong field or modifier key error |

These overlay onto the existing `M.ACT` / `GR.*` axes — a multimodal click error gets `[M.ACT, MM.GR.CLK]` labels.

## 3. Trace recording

Augment the `Span` schema with optional multimodal artifacts:

```python
class MultimodalArtifact(BaseModel):
    span_id: str
    timestamp: datetime
    kind: Literal["screenshot", "dom_snapshot", "accessibility_tree",
                  "video_frame", "audio_clip", "click_trace", "keystroke_log"]
    storage_uri: str             # local path or s3://
    sha256: str
    mime_type: str
    metadata: dict               # resolution, focused window, etc.
```

Artifacts live in `~/.agentdebugx/artifacts/<run_id>/` and are reference-counted with the parent run.

Adapters for computer-use frameworks register a *capture hook* that snapshots after every action:

```python
class ComputerUseAdapter:
    def on_action_complete(self, action):
        artifact = capture_screenshot(self.driver)
        self.ctx.event_bus.publish(MultimodalArtifactEvent(
            span_id=current_span_id(), kind="screenshot",
            storage_uri=artifact.path, sha256=artifact.sha256,
        ))
```

## 4. Storage budgets

Screenshots are large. Defaults:

- Resolution downscaled to 1280×720 by default.
- WebP / AVIF compression.
- TTL: 30 days for local artifacts.
- Sync to community corpus: opt-in per artifact kind (screenshots default OFF for upload — high PII risk).

## 5. Multimodal detectors

| Detector | Method |
|---|---|
| `dom_diff` | Diff DOM snapshots across steps; flag agent action that did not change DOM (suspected misclick) |
| `screenshot_diff` | Perceptual diff; if action expected a visual change and none occurred → flag |
| `click_off_target` | Compare reported click coords vs accessibility-tree bounding box of intended element |
| `modal_present` | Detect modal dialogs in screenshot via heuristic / small vision model |
| `vlm_judge` | VLM (vision LLM) judges step success against intent — expensive but powerful |

Adopted from third-party CU evaluations (NUS Show Lab) and OSWorld error analyses.

## 6. Replay

Multimodal replay is harder than text — full environment reconstruction is usually impossible. AgentDebugX supports:

- **Visual replay** (UI only): walk the screenshot timeline in the Console with action overlays. Always available.
- **Functional replay** (re-execute on a sandboxed snapshot): requires the framework + a snapshot-capable environment (e.g., trycua sandboxes). Gated by `AdapterCapabilities.supports_visual_replay`.

## 7. Multimodal recovery hints

Recoverer strategies that consume multimodal evidence:

- **GroundingRetry** — if `MM.GR.CLK`, re-query for element coords via accessibility tree before retry.
- **WaitForRender** — if `MM.ACT.TIM`, inject an explicit wait-for-stable-DOM step.
- **ModalDismissThenRetry** — if `MM.GR.MOD`, dismiss the modal and replay the original action.

## 8. UI

The web Console renders:

- A vertical step timeline with thumbnail screenshots per step.
- Click-overlay (red dot at reported coord, green box at expected element).
- DOM diff side-by-side.
- Optional video playback if a frame stream was captured.

## 9. Out of scope for v1

Audio agents, robotics, and embodied agents are deferred. The schema reserves space (`audio_clip`, `accessibility_tree`) but no first-party adapter ships in v1.
