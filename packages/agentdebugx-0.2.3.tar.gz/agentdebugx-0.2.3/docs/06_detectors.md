# 06 — Error Detectors

## 1. Detector interface

```python
class Detector(Protocol):
    id: str
    cost: Literal["free", "cheap", "expensive"]
    axes: list[TaxonomyAxisId]    # which taxonomy axes this detector emits
    runs_inline: bool             # safe to run inside the agent's hot path?

    def detect(self, ctx: DetectContext) -> list[DetectedError]:
        ...

    async def detect_async(self, ctx: DetectContext) -> list[DetectedError]:
        ...
```

```python
class DetectContext(BaseModel):
    trace: Trace                   # full or partial trace
    last_n_steps: int | None       # for streaming detectors
    framework: FrameworkId
    config: DetectorConfig

class DetectedError(BaseModel):
    id: str                        # ULID
    detector_id: str
    span_id: str                   # where it manifested
    step_index: int | None
    labels: LabelSet               # see 03_taxonomy.md
    summary: str                   # one-line human-readable
    evidence: list[Evidence]       # quoted span attrs / tool args / msgs
    confidence: float              # 0.0 — 1.0
    severity: Severity
    suggested_actions: list[ActionHint]   # downstream Recoverers may consume
```

## 2. Detector families

### 2.1 Rule-based detectors (`agentdebugx.detect.rule`)

Fast, deterministic, free to run inline. Each rule is < 100 LOC.

| Rule | What it detects | Taxonomy mapping |
|---|---|---|
| `repeated_tool_call` | Same tool with identical args called > K times | `FM-1.3` + `M.PLN` |
| `step_count_exceeded` | Run exceeds configured step budget | AgentBench-like TLE |
| `context_overflow` | Token count approaches/exceeds model max | AgentBench-like CLE |
| `tool_arg_schema_violation` | Tool args fail Pydantic validation | `TL.SCH` + `M.ACT` |
| `tool_unknown` | Agent called a tool not in its registry | `TL.AMB` + `M.ACT` |
| `tool_result_null_unhandled` | Tool returned `None`/empty and agent did not branch on it | `TL.NUL` |
| `loss_of_history` | Conversation rolled to system message only | `FM-1.4` + `M.MEM` |
| `premature_finish` | Agent emitted final answer with no verification step | `FM-3.1` + `M.REF` |
| `handoff_to_unknown_agent` | Multi-agent handoff target id absent in registry | MAS coordination |
| `tool_side_effect_no_compensation` | Write-class tool ran but had no compensation registered | `TL.SE` |
| `injection_heuristic` | Untrusted content matched injection pattern (NeMo Guardrails import) | `SEC.PI` |
| `pii_leak` | Output contains scrubber-flagged PII | `SEC.EX` |

Rules are configured via a single YAML:

```yaml
# ~/.agentdebugx/rules.yaml
defaults:
  step_count_exceeded:
    max_steps: 30
  repeated_tool_call:
    threshold: 3
overrides:
  per_project:
    my-agent:
      step_count_exceeded:
        max_steps: 60
```

### 2.2 Anomaly detectors (`agentdebugx.detect.anomaly`)

Statistical, framework-agnostic. Higher false-positive than rules — used to *propose*, not assert.

| Detector | Method | Notes |
|---|---|---|
| `trajectory_perplexity` | TrajAD (arXiv:2602.06443) — per-step LM perplexity on `(thought, action, observation)` | Set baseline from successful runs of the same project |
| `repeated_state_embedding` | Embedding-novelty score across steps — flags loops the rule misses | Uses sentence-transformers all-MiniLM by default |
| `tool_failure_rate_spike` | Compare tool error rate vs rolling baseline | Per-tool, per-project |
| `latency_spike` | Step latency > p99 of historical baseline | Catches runtime issues |
| `topic_drift` | Embedding cosine drift across consecutive assistant messages | Pairs with `FM-2.3 task_derailment` |

Each emits `confidence ∈ [0,1]`. The default pipeline only surfaces anomalies above a per-detector threshold.

### 2.3 LLM-judge detectors (`agentdebugx.detect.judge`)

Most expressive, slowest, most expensive.

| Judge | Taxonomy | Source |
|---|---|---|
| `mast_judge` | MAST-14 | Prompts adapted from MAST paper |
| `agent_debug_judge` | AgentDebug-5 | Prompts adapted from AgentDebug paper |
| `tau_bench_judge` | τ-bench 4 labels | For tool-call-heavy domains |
| `security_judge` | SEC.* | Prompt-injection / jailbreak / exfil |
| `custom_judge` | User-defined | Users supply a Pydantic-typed schema |

Implementation pattern:

```python
class MASTJudge(Detector):
    id = "mast_judge"
    cost = "expensive"
    axes = [TaxonomyAxisId.MAST_PATTERN]
    runs_inline = False

    def __init__(self, model: str = "gpt-4o", temperature: float = 0.0):
        self.model = model
        self.temperature = temperature

    async def detect_async(self, ctx) -> list[DetectedError]:
        prompt = render_template("mast_judge.j2", trace=ctx.trace)
        resp = await self._llm.complete(prompt, response_format=MASTJudgeResponse)
        return [self._to_detected(e) for e in resp.errors]
```

Calibration: every judge MUST pass an `AgentRewardBench`-style calibration test before being shipped in a release. Calibration results are surfaced in `agentdebugx.detect.judge.calibration_report()`.

### 2.4 Spec / temporal-logic detectors (`agentdebugx.detect.spec`)

v2 feature.

- LTL assertions over event traces (e.g., `□(execute_tool("send_email") → ◇verify_recipient)`).
- LLM-synthesized monitors from natural-language specs (arXiv:2509.20364, "The Power of Reframing").
- Gated behind opt-in spec elicitation — most users won't write LTL.

### 2.5 Static-analysis detectors

Runs before the agent starts (or in CI):

- Tool registry sanity (descriptions present, schemas valid).
- Prompt anti-patterns (e.g., role spec absent, no termination criteria stated).
- Empirical-bug rule pack from "Empirical Study of Bugs in Modern LLM Agent Frameworks" (15-cause × 7-symptom).

## 3. Pipeline

```python
class DetectionPipeline:
    def __init__(self, detectors: list[Detector]): self.detectors = detectors

    def run(self, trace: Trace) -> list[DetectedError]:
        ordered = sorted(self.detectors, key=_cost_order)
        out: list[DetectedError] = []
        for d in ordered:
            errs = d.detect(DetectContext(trace=trace, framework=trace.framework))
            out.extend(errs)
            if any(e.severity == Severity.CRITICAL for e in errs):
                break  # short-circuit on critical
        return _dedupe(out)
```

Default profiles:

| Profile | Detectors enabled | Latency budget |
|---|---|---|
| `fast` | rule-based only | < 10 ms per step |
| `balanced` (default) | rule + cheap anomaly | < 100 ms per step |
| `thorough` | rule + anomaly + 1 LLM judge | unconstrained |
| `audit` | everything | offline only |

`agentdebugx.init(profile="balanced")` sets the default.

## 4. Live vs offline

- **Live mode**: detectors with `runs_inline=True` execute synchronously inside the host agent's hot path (rules only, default).
- **Streaming mode**: cheap detectors run on partial traces every N steps via an async worker. Useful for early-exit on bad runs.
- **Offline mode**: all detectors run after the trace is complete.

Mode is configured per-detector and per-deployment.

## 5. Deduplication & ranking

Detectors often emit overlapping errors (e.g., a step is flagged by `repeated_tool_call` AND `trajectory_perplexity`). Dedup:

1. Group by `span_id`.
2. Cluster by label set intersection ≥ 0.5 Jaccard.
3. Merge into a single `DetectedError` with a `sources` field listing all detectors that fired.
4. Confidence = `1 − Π(1 − conf_i)` (independent-evidence assumption).

Ranking by `severity × confidence` for UI surfacing.

## 6. Suggested-action emission

Each `DetectedError` may include `suggested_actions` — small hints for the downstream Recoverer:

```python
class ActionHint(BaseModel):
    type: Literal[
        "rewrite_tool_schema",
        "add_clarification_step",
        "tighten_termination_condition",
        "split_prompt",
        "shorten_context",
        "register_compensation",
        "retry_with_reflection",
    ]
    rationale: str
    target_span_id: str | None
    payload: dict | None
```

Hints flow to the Recovery layer ([08_recovery.md](./08_recovery.md)) which decides whether to act, suggest, or surface in UI.

## 7. Extensibility

Users register custom detectors:

```python
from agentdebugx.detect import Detector, register

@register
class MyDetector(Detector):
    id = "my_detector"
    cost = "cheap"
    axes = [TaxonomyAxisId.CUSTOM_BIZ]
    runs_inline = True
    def detect(self, ctx): ...
```

The plugin system uses Python entry points (`agentdebugx.detectors` group in `pyproject.toml`) so third-party packages can ship detector plugins.
