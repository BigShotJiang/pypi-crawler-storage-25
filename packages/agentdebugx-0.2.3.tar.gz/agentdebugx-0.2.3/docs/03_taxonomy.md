# 03 — Error Taxonomy: AgentDebugX-Tax v0.1

## 1. Design rationale

The field has two strong taxonomies that **complement, not compete**:

- **AgentDebug-5** (Zhu et al., arXiv:2509.25370) — taxonomy by *agent module*: where in the agent's architecture the failure manifests.
- **MAST-14** (Cemri et al., arXiv:2503.13657) — taxonomy by *failure pattern*: which observable behavior went wrong.

Plus three orthogonal axes the literature lacks but agents need:

- **Security / adversarial** — prompt injection, tool-permission escalation, exfiltration.
- **Tool-layer** — argument format, side-effect-without-rollback, result misinterpretation.
- **Grounding** — visual / UI grounding errors, stale context, fabricated citations.

And one orthogonal capability axis from **AgentBoard** (arXiv:2401.13178): *memory, planning, world-model, retrospection, grounding, spatial-nav* — used to mark *where progress flatlined*.

AgentDebugX-Tax v0.1 is the union of all five, schemaed as a **labeled directed graph** so users can attach multiple tags per error and query by any axis.

## 2. The schema

Every detected error gets a `LabelSet`:

```
LabelSet = {
  primary: MAST FM code         # mandatory for MAS, mapped from AgentDebug-5 for single-agent
  module: AgentDebug-5 code     # mandatory
  capability: AgentBoard axis   # optional, "where did progress stall"
  tags: list[Tag]               # security/tool/grounding/etc.
  severity: low | medium | high | critical
  confidence: 0.0 — 1.0
  source: detector_id
}
```

## 3. Axis A — AgentDebug-5 (Module)

| Code | Module | Description |
|---|---|---|
| `M.MEM` | Memory | Loss, corruption, stale retrieval, hallucinated recall |
| `M.REF` | Reflection | Failed self-evaluation, false confidence, missed self-correction |
| `M.PLN` | Planning | Goal decomposition errors, invalid plan, missing dependency |
| `M.ACT` | Action | Wrong tool, wrong arg, malformed call, side-effect mismatch |
| `M.SYS` | System | Framework / runtime / infra (timeout, OOM, network) |

## 4. Axis B — MAST-14 (Pattern)

### FC1 — Specification & System Design
- `FM-1.1` Disobey task specification
- `FM-1.2` Disobey role specification
- `FM-1.3` Step repetition / infinite loop
- `FM-1.4` Loss of conversation history
- `FM-1.5` Unaware of termination conditions

### FC2 — Inter-Agent Misalignment
- `FM-2.1` Conversation reset
- `FM-2.2` Fail to ask for clarification
- `FM-2.3` Task derailment
- `FM-2.4` Information withholding
- `FM-2.5` Ignored other agent's input
- `FM-2.6` Reasoning–action mismatch

### FC3 — Task Verification & Termination
- `FM-3.1` Premature termination
- `FM-3.2` No / incomplete verification
- `FM-3.3` Incorrect verification

## 5. Axis C — Security / Adversarial

- `SEC.PI` Prompt injection (direct, indirect, multi-turn)
- `SEC.TE` Tool permission escalation
- `SEC.EX` Data exfiltration
- `SEC.JB` Jailbreak / safety bypass
- `SEC.PO` Policy violation

## 6. Axis D — Tool layer

- `TL.FMT` Tool argument format error
- `TL.SCH` Schema violation
- `TL.MIS` Tool result misinterpretation
- `TL.SE` Side effect without rollback
- `TL.AMB` Ambiguous tool selection
- `TL.NUL` Tool selected but returned null/empty without handling
- `TL.OOM` Tool output overflow

## 7. Axis E — Grounding

- `GR.VIS` Visual / UI grounding error
- `GR.STL` Stale context
- `GR.FAB` Fabricated citation / source
- `GR.NUM` Numerical grounding error
- `GR.TEM` Temporal grounding error (wrong "now")

## 8. Axis F — Capability dimension (AgentBoard)

Used as a *progress-flatlined-here* tag, not a failure type by itself.

`CAP.MEM` · `CAP.PLN` · `CAP.WM` · `CAP.RET` · `CAP.GRD` · `CAP.SP`

## 9. Cross-walks (registry)

AgentDebugX ships a **default cross-walk** between AgentDebug-5 and MAST-14 so users labeling at one axis can auto-derive the other (default values, overridable):

| MAST FM | Default AgentDebug-5 |
|---|---|
| FM-1.1, FM-1.2 | `M.PLN` |
| FM-1.3 | `M.PLN` + `M.REF` |
| FM-1.4 | `M.MEM` |
| FM-1.5, FM-3.1 | `M.REF` |
| FM-2.1 | `M.MEM` |
| FM-2.2, FM-2.4, FM-2.5 | `M.PLN` (coordination) |
| FM-2.3 | `M.PLN` |
| FM-2.6 | `M.REF` + `M.ACT` |
| FM-3.2, FM-3.3 | `M.REF` |

Plus a **per-benchmark cross-walk** projecting AgentBench TLE/CLE/IF/IA, τ-bench's 4 labels, SWE-bench's execution/semantic split, and Galileo's 7 modes into AgentDebugX-Tax. This produces the first unified cross-benchmark failure corpus.

## 10. Per-mode metadata

Each code in the registry has a structured entry:

```yaml
code: FM-2.3
name: task_derailment
axis: pattern
category: FC2-inter-agent-misalignment
description: >
  One or more agents drift from the assigned task into adjacent or unrelated work,
  often after a tool call returned partial information.
typical_triggers:
  - ambiguous user request
  - low-confidence tool result not flagged
  - long context with topic drift
detectors:
  - llm_judge_mast
  - rule_step_topic_drift
recovery_strategies:
  - self_refine
  - critic_with_search
similar_modes:
  - FM-1.1
  - M.PLN
references:
  - arxiv: 2503.13657
example_trace_ids:
  - mad/0042
```

The full registry lives at `src/agentdebugx/taxonomy/registry.yaml` and is auto-generated into Python `Enum`s and Pydantic models at build time.

## 11. Versioning

`AgentDebugX-Tax v0.1` follows semantic versioning. **Adding** a code is a minor bump. **Renaming or removing** a code requires a major bump and ships a deprecation alias for ≥ 1 minor.

Auto-derived codes from taxonomy induction (see [10_taxonomy_induction.md](./10_taxonomy_induction.md)) land under namespace `AUTO.*` and stay there until an RFC promotes them to the curated namespace.

## 12. Custom taxonomies

Users register their own taxonomies via the registry API:

```python
from agentdebugx.taxonomy import Registry, TaxonomyAxis

Registry.add_axis(TaxonomyAxis(
    id="biz",
    codes=[
        ("BIZ.REF", "refund_policy_violation", "Agent issued a refund outside policy"),
        ("BIZ.UPS", "missed_upsell_opportunity", "Agent did not surface a relevant upsell"),
    ],
))
```

Custom axes coexist with the canonical ones. Detectors can target any axis.
