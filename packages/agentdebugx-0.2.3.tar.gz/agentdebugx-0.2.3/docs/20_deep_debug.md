# 20 — DeepDebug: Iterative Multi-Turn Error Analysis

## 1. Why a deeper loop

A one-shot LLM judge (`LLMJudgeAnalyzer`) is fast but biased:

- It tends to flag *manifestations* (tool exceptions, system errors) and miss
  *root causes* (planner ignored a constraint, agent dropped handoff context).
- It does not separate "I see a finding" from "the trajectory actually supports
  this finding."
- It returns a flat list, not a causal chain.

DeepDebug is the **deep-research-style** counterpart, modeled after recent
agent-as-judge and deep-research methods. The cost is higher (multiple LLM
calls per trace) and the quality is higher.

## 2. Loop structure

```
R0 plan        — LLM proposes investigation focus (which event_ids, what questions)
R1 hypothesize — LLM produces candidate findings on the focus set
R2 verify (per-h) — LLM re-reads the trajectory and rates each hypothesis:
                    corroborated / weak / contradicted
R3 refine      — LLM merges, drops weak/contradicted, picks single root cause
Rfinal report  — DiagnosticReport + DeepDebugTrace audit trail
```

Each round is recorded as a typed `DeepDebugRound`:

```python
@dataclass
class DeepDebugRound:
    name: str                # plan | hypothesize | verify:<h_id> | refine
    request_summary: str
    response_summary: str
    duration_ms: int
    payload: dict
```

This audit trail is the point. Users can replay *how* the diagnosis was
reached, not just *what* it is.

## 3. Public API

```python
from agentdebug.deep import DeepDebugAnalyzer
from agentdebug.llm import OpenAICompatClient

llm = OpenAICompatClient(base_url=..., api_key=..., model='gpt-4o-mini',
                        default_max_tokens=8192, timeout=180.0)

result = DeepDebugAnalyzer(
    llm=llm,
    max_focus_events=7,
    max_hypotheses_to_verify=6,
    max_tokens=4096,
).analyze(trajectory)

print(result.report.summary)
for r in result.rounds:                       # audit trail
    print(r.name, r.duration_ms, 'ms')
for h in result.hypotheses:                   # all hypotheses, verified or not
    print(h.id, h.verdict, h.confidence_posterior)
```

CLI:

```bash
agentdebug deep <trajectory.json> --out deep.json
agentdebug deep <trace_id> --store-sqlite .agentdebug/errors.sqlite \
    --base-url https://.../v1 --api-key sk-... --model gemini-3-flash
```

## 4. Cost and latency model

Per trace: roughly `1 plan + 1 hypothesize + K verify + 1 refine` calls,
where `K ≤ max_hypotheses_to_verify`. For a 4-event trace with K=3 against
Gemini-3-flash we observed 6 rounds in ~29 seconds. Use:

- `LLMJudgeAnalyzer` for inline / per-step quick scans.
- `DeepDebugAnalyzer` for postmortems, escalations, hard regressions.

## 5. What "verify" actually does

Crucially, **verification does not re-execute the agent's tools**. It re-reads
the *existing* trajectory more carefully against the specific hypothesis.
Verdict choices:

- `corroborated` — trajectory evidence supports the hypothesis.
- `weak`         — trajectory is ambiguous; no clear support either way.
- `contradicted` — trajectory explicitly conflicts with the hypothesis.

Counterfactual replay (where the agent IS re-rolled to test causality) is a
separate v2 feature; it composes with DeepDebug but is not required for it.

## 6. Live result (v0.1, gemini-3-flash, 4-event trace)

DeepDebug on a synthetic trace where the planner called `search_web` with
`args={}` and then summarized a fabricated answer:

```
summary       : "The search agent failed to provide a query parameter to the
                 search tool, and the planner subsequently ignored this failure,
                 hallucinated a result, and terminated the task without emailing
                 the summary as required."
findings      : action.parameter_error (s2, 1.00)
                reflection.progress_misjudge (s4, 1.00)
                verification.premature_stop (s4, 1.00)
root_cause    : step=2, agent=search
rounds        : plan (4.6s) hypothesize (11.0s)
                verify:h1 (2.0s) verify:h2 (2.4s) verify:h3 (2.7s)
                refine (6.4s)
```

The single-pass `LLMJudgeAnalyzer` on the same trace returned only the first
finding. DeepDebug recovered the full cascade and selected the upstream cause.

## 6.1 AgentTraceback — Python-traceback-style cascade view

Once DeepDebug has populated `finding.metadata['cascading_from_event_id']`,
`agentdebug.traceback.format_traceback(report, trajectory)` renders the
cascade in a layout that mirrors Python's `Traceback (most recent call last)`
— root cause first, manifested failure last, with arrows between hops:

```text
AgentTraceback (root cause first, manifested failure last):
    trace_id=trace_…  framework=live-cascade-demo  goal='Find latest paper, summarize, then email …'

      File "root cause", in trajectory
        Step 3  agent=search  mode=action.parameter_error  confidence=1.00
          module=action
          error>  JSON schema validation failed: missing parameter query
          evidence:
            - args={}
          suggested: Validate parameters against tool schemas before execution.
    ↓ cascaded to
      File "cascade depth 1", in trajectory
        Step 4  agent=planner  mode=verification.premature_stop  confidence=1.00
          output> Final answer: AgentDebug is a popular paper.
    ↓ cascaded to
      File "cascade depth 1", in trajectory
        Step 4  agent=planner  mode=memory.hallucination  confidence=0.95
          output> Final answer: AgentDebug is a popular paper.

AgentFailure[memory.hallucination]: The search agent failed to provide the
required 'query' parameter in its tool call, leading to a tool error. The
planner then hallucinated a generic fact about the paper and prematurely
terminated the task without completing the summary or email steps.
```

CLI:

```bash
agentdebug deep <trajectory.json> --traceback         # render to stdout
agentdebug analyze <trajectory.json> --traceback      # works for rule analyzer too
agentdebug judge <traj|trace_id> --attribute --traceback
```

When DeepDebug isn't available (heuristic analyzer or single-pass judge),
the renderer falls back to **step-index ordering** — the earliest finding
becomes the root and later findings cascade from it. This means
`--traceback` works on any analyzer in the pipeline, not just DeepDebug.

## 7. Failure modes

- **Cost blowout** — if `max_hypotheses_to_verify` is high and verify is
  expensive, costs scale linearly. Pin a budget.
- **Hypothesis fishing** — the LLM may invent hypotheses to look thorough.
  The verify round filters most of these (`contradicted` / `weak`); the
  refine round drops any low-confidence stragglers.
- **Thinking-token budgets** — Gemini-3-flash and o-series models spend a
  large fraction of `max_tokens` on reasoning. Default `max_tokens=4096` is
  conservative; raise to 8192 for long traces or fine-grained verifiers.

## 8. Roadmap

- Counterfactual-replay round (re-roll oracle-corrected step + re-judge).
- Step-by-step verifier mode (Who&When-style sweep).
- Adaptive K — decide how many hypotheses to verify based on round-1 spread.
- Specialized verifiers (tool-call-arg verifier, multi-agent handoff verifier).
- Persistent reasoning cache so re-runs on the same trace skip re-thought.
