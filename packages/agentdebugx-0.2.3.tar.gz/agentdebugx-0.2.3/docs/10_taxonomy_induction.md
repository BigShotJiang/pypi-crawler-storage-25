# 10 — Automated Taxonomy Induction

## 1. Why we need this

The seed taxonomy ([03_taxonomy.md](./03_taxonomy.md)) is the published-literature consensus as of 2026. New failure modes emerge as:

- New frameworks ship (multi-modal agents, MCP-tool agents, long-horizon agents).
- Production agents hit edge cases not seen in benchmarks.
- The community corpus grows beyond what any individual paper covered.

AgentDebugX bakes in a continuous induction pipeline that proposes new codes for taxonomy maintainers to review.

## 2. Pipeline

```
Raw traces (corpus)
     │
     ▼
Embedding (sentence-transformers all-mpnet-base-v2)
     │
     ▼
Goal-conditioned partitioning  ◄── task_signature / task_domain
     │
     ▼
Per-partition:
  ├── BERTopic (UMAP → HDBSCAN → c-TF-IDF)        [coarse clustering]
  └── TnT-LLM (LLM proposes + refines categories)  [fine-grained labels]
     │
     ▼
Candidate axis  ──► HITL review queue
     │
     ▼
Promoted axis ──► RFC ──► AgentDebugX-Tax minor bump
```

## 3. Stages

### 3.1 Goal-conditioned partitioning

The literature (Galileo, MAST) notes that failure distributions differ sharply by task domain — code-gen failures look nothing like web-browsing failures. Partition first:

- Cluster by `task_signature` embedding.
- Group by `task_domain` / `framework` / `benchmark`.
- Run induction within each partition; surface partition-specific axes.

This is **novel** — no published taxonomy work applies this lens to agent failures.

### 3.2 BERTopic (coarse discovery)

Pipeline: embed → UMAP → HDBSCAN → c-TF-IDF → LLM-named labels. Limitations: one topic per doc, hyperparameter sensitivity. Use as a *starting set* of candidate groups, not as the final taxonomy.

### 3.3 TnT-LLM (refinement, Wan et al. KDD 2024, arXiv:2403.12173)

Two-phase prompt program:

- **Phase 1**: LLM iteratively proposes and refines a label taxonomy from samples.
- **Phase 2**: LLM-as-labeler bootstraps a lightweight classifier (logistic regression or small Transformer) for scale.

Designed exactly for "we have unstructured corpus → coherent taxonomy." Applied to Bing Copilot intent discovery in original work. Applying to agent failures is novel for AgentDebugX.

### 3.4 HITL review (LLMs4SchemaDiscovery 3-stage, arXiv:2504.00752)

For each candidate code surfaced by TnT-LLM:

1. **LLM-proposed**: code, description, 5 example traces, suggested detector heuristic.
2. **Human refines**: rename, merge with existing code, reject, or accept-as-AUTO.
3. **Finalize**: promote to `AUTO.*` namespace; tag for taxonomy RFC consideration.

The HITL surface lives in the web Console (review tab). Maintainers and community contributors get a queue.

### 3.5 RFC promotion

A code in `AUTO.*` can be promoted to a curated namespace (`M.*`, `FM-*`, `SEC.*`, `TL.*`, `GR.*`, `CAP.*`) via an RFC:

- GitHub issue with template (`.github/ISSUE_TEMPLATE/taxonomy_rfc.yml`).
- Two maintainer approvals.
- Auto-merged into `registry.yaml` on next minor release.

## 4. Active learning

Not every unlabeled trace is equally valuable to label. AgentDebugX prioritizes:

- Traces with **high embedding distance** to all existing labeled traces (novelty).
- Traces where the **detector ensemble disagrees** (uncertainty).
- Traces matching a **frequently-failing task signature** (impact).

Borrows cost-aware active-learning ideas from ACL 2025 survey (arXiv:2502.11767).

## 5. Schema evolution

A new minor release of AgentDebugX-Tax may add, deprecate-with-alias, or refine descriptions. Never break existing codes. The corpus is migrated lazily — on read, old labels are mapped to the latest taxonomy via the alias table.

When a major release changes structure (e.g., split an axis), AgentDebugX ships a one-shot migrator that re-labels the corpus with LLM assistance, with manual review for low-confidence remappings.

## 6. Distribution drift monitoring

`agentdebugx.corpus.drift_report()` produces:

- Daily / weekly failure-mode distribution per partition.
- Drift score (KL divergence vs prior window).
- Top-K rising modes (early warning of emergent failure patterns).

Useful as a production SRE signal — "we're seeing 3x more `FM-2.3 task_derailment` after the model upgrade."

## 7. Quality gates

Before any `AUTO.*` code is shown to users as a *detection target*:

- ≥ 50 supporting examples in the corpus.
- ≥ 0.7 LLM-as-judge agreement on a held-out sample.
- ≥ 1 maintainer review.

This prevents premature noise from polluting the user-visible label set.

## 8. Outputs

Each induction run emits:

- `taxonomy/auto/<run-id>/proposed_codes.yaml` — candidate codes with examples + heuristic.
- `taxonomy/auto/<run-id>/distribution.md` — corpus breakdown.
- `taxonomy/auto/<run-id>/conflicts.md` — overlaps / merges with existing codes.

The maintainer reviews via the Console and writes RFCs.
