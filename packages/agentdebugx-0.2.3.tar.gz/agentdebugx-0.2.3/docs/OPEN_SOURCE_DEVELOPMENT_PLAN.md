# AgentDebugX Open-Source Development Plan

## Mission

AgentDebugX should become the default debugging layer for agentic systems:

```python
import agentdebug
```

From that import, users should be able to record agent trajectories, build an
error database, diagnose root causes, generate or refine failure taxonomies, and
feed actionable suggestions back into humans or agents.

## Design Principles

- Portable first: the core schema must work across OpenAI Agents SDK, LangGraph,
  AutoGen/AG2, CrewAI, LlamaIndex, custom ReAct loops, browser agents, coding
  agents, and future frameworks.
- Trace compatible: AgentDebugX should ingest/export OpenTelemetry-style spans
  and OpenInference/Langfuse/Phoenix traces where possible.
- Diagnosis over logging: the project should not compete as another generic
  tracing UI. It should add root cause, taxonomy, attribution, and recovery.
- Evidence grounded: every finding should cite event IDs, artifacts, constraint
  violations, or replay results.
- Human and agent usable: output should be readable by developers and structured
  enough for self-healing agents.
- Local by default: JSONL/SQLite should work immediately; Postgres/vector stores
  can come later.
- Multimodal ready: screenshots, audio, video, UI trees, files, diffs, and
  environment snapshots should be first-class artifacts.

## Core Architecture

### 1. SDK and Trace IR

Implemented now:

- `AgentTrajectory`
- `AgentEvent`
- `Artifact`
- `FailureMode`
- `FailureFinding`
- `DiagnosticReport`
- `AgentDebug`
- `TraceSession`

Next:

- Add `ConstraintViolation`, `RecoveryAttempt`, `RunOutcome`, and
  `TaxonomyProposal` models.
- Add schema versioning and JSON Schema export.
- Add provenance fields for prompts, memory reads, retrieved documents, tool
  schemas, environment snapshots, and side effects.

### 2. Error Database

Implemented now:

- Append-only JSONL store for quick adoption.
- Embedded SQLite store for local error databases and CI artifacts.

Proposed:

- Postgres backend for production deployments.
- Vector index for similar failure retrieval.
- Object storage for multimodal artifacts.
- Dataset export to Hugging Face, Parquet, JSONL, and OpenTelemetry traces.
- Versioned labels: human labels, analyzer labels, generated taxonomy labels,
  and final accepted labels should not overwrite one another.

Suggested tables:

- `traces`
- `events`
- `artifacts`
- `diagnostic_reports`
- `findings`
- `failure_modes`
- `taxonomy_proposals`
- `constraint_violations`
- `recovery_attempts`
- `evaluations`

### 3. Analyzer Stack

Implemented now:

- `HeuristicAnalyzer`: deterministic baseline for obvious errors such as tool
  execution failures, schema issues, context limits, and handoff loss signals.

Proposed analyzer layers:

- Rule checks: schema validation, tool result validity, loop detection, state
  transition checks, side-effect checks, final success criteria.
- Constraint synthesis: AgentRx-style tool and policy invariant generation.
- LLM judge: grounded step classification using trajectory snippets and
  validation logs.
- Multi-agent attribution: Who&When-style responsible agent and decisive step.
- Taxonomy generator: cluster unlabeled failures, propose labels, map them to
  existing taxonomy, and ask humans to accept/merge/reject.
- Recovery planner: propose concrete prompt, tool, schema, memory, verifier, or
  orchestration changes.

### 4. Framework Adapters

Current status:

- Adapter interface only.

Priority adapters:

- OpenAI Agents SDK trace processor.
- LangGraph/LangChain callback handler.
- AutoGen/AG2 conversation observer.
- CrewAI event listener.
- LlamaIndex instrumentation.
- Browser and UI agents: Playwright trace, accessibility tree, screenshot, DOM
  diff, network log.
- Coding agents: shell command logs, file diffs, test outputs, repository state.

Adapter requirements:

- Map framework-specific events into `AgentEvent`.
- Preserve parent/child causality.
- Avoid storing sensitive data by default when users opt out.
- Allow custom metadata without schema forks.

### 5. Multimodal Support

Current status:

- `Artifact` can represent image, audio, video, UI, file, tool, state, and other
  payloads.

Proposed:

- Local artifact store with hashing and deduplication.
- Screenshot plus accessibility tree pairing for UI tasks.
- Audio transcript plus confidence metadata.
- Video segment references for long screen recordings.
- File and diff artifacts for coding/data agents.
- Multimodal perception checks: compare model claims against OCR, object
  detection, UI tree, or metadata.

### 6. UI

Not implemented.

Proposed views:

- Timeline: spans/events grouped by agent, module, and parent-child causality.
- Failure attribution: "who caused the failure" and "when it became
  unrecoverable".
- Evidence panel: constraints, artifacts, screenshots, logs, and state deltas.
- Taxonomy workbench: cluster, label, merge, split, and publish failure modes.
- Recovery workbench: suggestions, applied changes, rerun outcomes, and
  regression tracking.
- Dataset builder: curate traces into public/private benchmarks.

Suggested stack:

- Backend: FastAPI over SQLite/Postgres.
- Frontend: React + Vite + timeline/graph visualization.
- Optional: notebook widgets for research workflows.

### 7. Evaluation

Metrics:

- Step localization accuracy.
- Agent attribution accuracy.
- Failure mode classification accuracy.
- Root-cause exact match and family-level match.
- Suggestion usefulness rated by human or downstream improvement.
- Recovery success delta after applying suggestions.
- Analyzer latency and cost.

Benchmarks to ingest:

- AgentErrorBench from AgentDebug.
- MAST-Data.
- Who&When.
- AgentRx failed trajectories.
- Project-specific production traces.

### 8. Governance and Open Source

Recommended repository practices:

- Keep core SDK dependency-light.
- Place heavyweight integrations behind extras such as `agentdebug[langchain]`.
- Maintain a stable schema contract with migration scripts.
- Add privacy docs and redaction APIs before production telemetry examples.
- Separate public benchmark data from user/private trace stores.
- Encourage contribution of new adapters, analyzers, taxonomy packs, and UI
  plugins.

## Milestones

### Milestone 0: Skeleton

Status: in progress.

- Package imports as `agentdebug`.
- Core IR, seed taxonomy, JSONL/SQLite stores.
- Baseline analyzer and CLI.
- Development docs and research survey.

### Milestone 1: Useful Local Debugging

- Add JSON Schema export.
- Add sample traces and richer CLI.
- Add deterministic loop/schema/final-verification checks.
- Add report rendering in Markdown and JSON.
- Add unit tests for storage, taxonomy, analyzer, and instrumentation.

### Milestone 2: Framework Integrations

- OpenAI Agents SDK trace processor.
- LangGraph/LangChain callback handler.
- AutoGen/AG2 adapter.
- CrewAI adapter.
- Ingest Langfuse/Phoenix/OpenTelemetry traces.

### Milestone 3: Agentic Error Database

- Normalize SQLite tables rather than storing only JSON payloads.
- Add Postgres backend.
- Add vector similarity retrieval.
- Add taxonomy proposal lifecycle.
- Add benchmark import/export.

### Milestone 4: Automated Diagnosis and Recovery

- Constraint synthesis and checker interface.
- LLM judge with auditable evidence.
- Multi-agent attribution model hooks.
- Recovery suggestion generation and rerun tracking.

### Milestone 5: UI and Multimodal Debugging

- FastAPI service.
- Timeline and attribution UI.
- Multimodal artifact viewer.
- Taxonomy workbench.
- Recovery outcome dashboard.

## Open Questions

- Should the PyPI package be `agentdebugx` with import `agentdebug`, or should
  the distribution eventually become `agentdebug`?
- Which trace schema should be treated as canonical: native AgentDebugX,
  OpenTelemetry GenAI, OpenInference, or a bidirectional mapping?
- How much raw prompt/completion data should be stored by default?
- What is the minimum useful taxonomy generator that does not overfit to noisy
  labels?
- Should recovery suggestions be purely advisory first, or should the SDK expose
  safe automatic patch hooks for agent prompts and tool schemas?
