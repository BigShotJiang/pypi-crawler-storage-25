# 15 — Roadmap

## v0 — Design baseline + Codex scaffold (merged)

`docs/` (engineering spec) + `src/agentdebug/` working scaffold from commit `93d6670`. See doc 17 for the reconciliation.

## v0.1 — MVP (the actively shipping milestone)

Shipped on top of Codex's scaffold:

- `EventBus` (in-process pub/sub) — `agentdebug.events`
- `LLMClient` + `OpenAICompatClient` — `agentdebug.llm` (works against the user's Gemini endpoint, OpenAI, LiteLLM)
- `LLMJudgeAnalyzer` schemed to the 19 seed modes — `agentdebug.judges`
- `AllAtOnceAttributor` (LLM-based blame, falls back to heuristic) — `agentdebug.attribution`
- `ReflexionSuggestion` (suggest-only recovery, emits retry-prompt artifact) — `agentdebug.recovery`
- Real `LangGraphAdapter` (`BaseCallbackHandler`) — `agentdebug.adapters.langgraph`
- `trace_loop` decorator + `mark_step` helper for raw ReAct loops — `agentdebug.adapters.raw`
- Optional OTel GenAI export shim — `agentdebug.adapters.otel`
- Expanded CLI: `agentdebug analyze | list | show | judge`
- Tests: EventBus, judge (mocked LLM), attributor (mocked + live-gated), trace_loop, OTel shim

Already present from Codex (kept verbatim): `models`, `taxonomy` (19 modes), `storage` (JSONL+SQLite), `recorder`, `analyzers` (`HeuristicAnalyzer` = rule-based detector), `instrumentation` (`traced_tool`), `cli`.

Acceptance:
- `pip install agentdebugx`, `from agentdebug import AgentDebug, ...`, record events, run `HeuristicAnalyzer` *or* `LLMJudgeAnalyzer`, get an attributed `DiagnosticReport` with a suggestion.
- `pytest` and `mypy --strict` both green.
- Live LLM judge demonstrably routes a failing trace to one of the 19 seed modes (test gated by `AGENTDEBUG_LIVE_LLM=1`).

## v0.2 — Coverage + UI (4 weeks)

Already shipped in the v0.2/v0.2.1 line:

- Error Hub bundle format + Local/Git/Hugging Face backends.
- DeepDebug iterative analysis loop.
- Claude Code Skill generator and OpenHands microagent/EventStream bridge.
- `AgentTraceback` cascade renderer and CLI `--traceback` support.
- FastAPI local console with native-trace + error-trace alignment for human
  review.

Remaining scope from the original v0.2 plan:

- Adapters: CrewAI, OpenHands, smolagents, LlamaIndex, DSPy, Pydantic-AI.
- Detectors: anomaly family (perplexity, repeated-state, topic-drift).
- Attribution: `BinarySearchAttributor`, `CounterfactualAttributor`, `EnsembleAttributor`.
- Web Console v1 (React + FastAPI): runs table, trace view, errors panel, similar-cases.
- TUI minimum.
- Per-framework conformance tests.

Acceptance:
- All 9 adapters pass conformance.
- Console renders 1000-span traces in < 1s.
- Counterfactual attribution beats All-at-Once on a curated subset of Who&When.

## v0.3 — Recovery + community sync (4 weeks)

- Recovery: `CriticRecoverer`, `AutoManualRules`, `LangGraphRewind`, `SagaRollback` (with required compensation registration).
- Approval workflow (UI + webhooks).
- Community Corpus sync (opt-in), PII scrubber, dedup-on-upload.
- HF Datasets monthly export.
- Replay engine v1 (LangGraph + AutoGen).

Acceptance:
- A user can opt into community sync, publish a failing trace, and retrieve similar resolved cases.
- Auto-apply of `ReflexionMemory` improves Who&When-style attribution accuracy on the next run.

## v0.4 — Taxonomy induction + benchmarks (4 weeks)

- `InductionPipeline`: goal-conditioned partition + BERTopic + TnT-LLM + HITL queue.
- HITL review UI in Console.
- `agentdebugx bench` for Who&When, MAD, AgentErrorBench with leaderboard outputs.
- Calibration reports per detector and attributor surfaced in UI.

Acceptance:
- Induction surfaces ≥ 3 candidate `AUTO.*` codes on a 1000-trace corpus.
- Public leaderboard published with reproducible scripts.

## v1.0 — Stability + adapter complete (4 weeks)

- Remaining adapters: AG2, Haystack, MetaGPT, Camel-AI, vanilla loop.
- API stability declared (semver).
- Documentation site published.
- VSCode extension v1.
- Full Inspect AI integration (re-run failing traces under new models).

Acceptance:
- 12+ adapters; one-line init succeeds in all.
- API stability commitment with deprecation policy.
- ≥ 50 community-contributed corpus records.

## v1.1 — Multimodal (6 weeks)

- Multimodal capture (screenshots, DOM, click-trace) for Claude Computer Use, OpenAI CUA, OpenHands browser, Playwright.
- Multimodal sub-taxonomy (`MM.*`).
- Multimodal detectors (`dom_diff`, `click_off_target`, `vlm_judge`).
- Visual replay in Console.

Acceptance:
- A Claude Computer Use run produces a screenshot timeline with click overlays in Console.
- VLM judge catches `MM.GR.CLK` on an OSWorld-like task set.

## v1.2 — Spec monitors + saga (4 weeks)

- LTL spec monitors (`agentdebugx.detect.spec`).
- LLM-synthesized monitors from NL specs.
- Saga compensation tooling matured; compensation library for common patterns (HTTP, SQL, S3, Slack).

## v2.0 — Fine-tuned attributor + MCTS recovery

- AgenTracer-8B–style small attributor model + training scripts.
- LATS-style MCTS recovery with reflection.
- Hosted corpus production launch (errors.agentdebugx.dev).

## Cross-cutting tracks (all versions)

### Quality gates per release

- All adapter conformance tests pass.
- `mypy --strict` clean.
- Coverage ≥ 80% for `agentdebugx.detect`, `attribute`, `recover`, `schema`.
- Benchmarks (`Who&When`, `MAD`, `AgentErrorBench`) re-run; no regression > 2 pp.
- Calibration reports for all judges and attributors published.

### Documentation

- Every new public class/function lands with docstring + an example in `examples/`.
- `docs/benchmarks/*.md` regenerated each release.
- Release notes follow keep-a-changelog format.

### Security

- Threat model reviewed each minor.
- Scrubber regex set audited; presidio rules updated.
- Hosted-corpus security review before launch.

### Community

- RFC process for taxonomy changes (≥ 2 maintainer approvals).
- Monthly office hours.
- Annual report: corpus size, top failure modes, leaderboard movement.

## Explicit non-goals (will not ship)

- A managed multi-tenant SaaS in v1 — too much ops burden for early stage.
- A first-party agent framework — we're additive, not a competitor.
- "AgentDebugX-as-a-judge" certification scheme — we report calibration, not certify.
- Auto-applying side-effect-touching fixes without compensation — never.

## Risks

| Risk | Mitigation |
|---|---|
| OTel GenAI semconv still in Development; breaking changes upstream | Pin to a snapshot; normalize layer absorbs renames |
| Attribution accuracy ceiling (~50%/15%) leads users to over-trust | Confidence + evidence-first UX; calibration prominently displayed |
| Recovery side-effects | Compensation gating; never auto-apply for non-idempotent tools |
| Corpus contamination (adversarial submissions) | Moderation queue for high-impact records; anomaly flagging |
| Framework API churn (LangGraph, AutoGen, OpenAI Agents iterate fast) | Adapter conformance suite in CI; version pin matrix |
| PII leakage on corpus upload | Default scrubbing; opt-in only; local-first |
| LLM judge bias (positional, self-bias) | Calibration tests required before release; ensemble across judges |
| Engineering scope | Each layer has its own LOC budget; defer multimodal + spec to v1.1+ |

## Success metrics

- **Adoption**: ≥ 1k GitHub stars by v1.0, ≥ 5k by v2.0.
- **Coverage**: 12+ framework adapters, all green in CI.
- **Corpus**: ≥ 10k labeled records by v2.0; ≥ 3 published research papers using ADBXCorpus.
- **Accuracy**: AgentDebugX ensemble matches or exceeds published SOTA on Who&When and MAD by v1.0.
- **Operability**: median p95 detection latency < 50ms in `balanced` profile.
- **Reproducibility**: every benchmark run reproducible via one CLI command.
