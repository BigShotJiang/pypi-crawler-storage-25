# 19 — Error Hub

## 1. What it solves

A team-or-community channel for **packaging a failing agent trajectory + its
analysis** and pushing it to a backend (Git remote, Hugging Face Datasets
repo, or a local directory), plus pulling and listing what others have
shared. The Hub is how AgentDebugX makes the trace your colleague is staring
at into the regression case your CI rejects.

## 2. Unit of share — the `Bundle`

```
bundle_<id>/
├── manifest.json     # typed metadata (BundleManifest, schema 1.0.0)
├── trajectory.json   # AgentTrajectory JSON
├── report.json       # DiagnosticReport JSON (optional)
├── artifacts/        # binary attachments (screenshots, files) — optional
└── README.md         # auto-generated human summary
```

`BundleManifest` carries: `bundle_id`, `trace_id`, `framework`, `goal_summary`
(truncated, post-scrub), `failure_families`, `failure_mode_ids`,
`root_cause_step_index`, `root_cause_agent`, `n_events`, `has_report`,
`has_artifacts`, `license`, `contributor`, `contributor_org`, `scrubbed`,
`scrubber_version`, `notes`.

The directory layout is intentionally framework-, language-, and
storage-agnostic — anything that can read JSON can ingest a bundle.

## 3. Backends — `HubBackend` Protocol

| Scheme | Class | Dependencies | Use for |
|---|---|---|---|
| `local:/path` | `LocalHubBackend` | stdlib only | tests, air-gapped envs, NFS shares |
| `git:<remote>[#<subpath>]` | `GitHubBackend` | `git` CLI | GitHub / GitLab / Gitea / self-hosted git |
| `hf:<repo_id>[#<subpath>]` | `HuggingFaceBackend` | `huggingface_hub` (`[hub-hf]` extra) | community datasets, discoverable corpora |

All three implement:

```python
class HubBackend(Protocol):
    scheme: str
    def push(self, bundle: Bundle, *, message: str | None = None) -> str: ...
    def pull(self, bundle_id: str, *, into: Path) -> Path: ...
    def list_bundles(self, *, limit: int = 100) -> list[str]: ...
```

`backend_from_spec("git:...#...")` dispatches by scheme prefix; the CLI
calls this so a single `--to` arg can target any backend.

## 4. Privacy: scrubbing is default-on

Every `agentdebug hub push` runs `Scrubber.scrub_trajectory` first. The
default `DEFAULT_REDACTIONS` cover:

- API keys: OpenAI, Anthropic, AWS access key + secret, Google, GitHub, PyPI
- Bearer tokens, URL-embedded credentials
- PII: emails, E.164 phone numbers, US SSNs, credit cards

Opt-out via `--no-scrub` for trusted internal hubs only — the CLI prints a
warning when used. The scrubber is **idempotent** (running it twice changes
nothing), versioned (`SCRUBBER_VERSION` is recorded in the manifest), and
produces an audit report (`ScrubReport.replacements`).

For higher recall, drop in a Microsoft Presidio backend via a custom
`Scrubber` subclass — the architecture is built for replacement.

## 5. CLI

```bash
# Push to a local hub
agentdebug hub push <trace_id> \
    --to local:/srv/agentdebug-hub \
    --store-sqlite .agentdebug/errors.sqlite

# Push to a Git remote (any SSH/HTTPS git host)
agentdebug hub push <trace_id> \
    --to git:git@github.com:your-org/agentdebug-bundles.git#bundles \
    --store-sqlite .agentdebug/errors.sqlite \
    --message "Customer escalation 2026-05-16"

# Push to a Hugging Face dataset (requires HF_TOKEN)
agentdebug hub push <trace_id> \
    --to hf:your-org/agentdebug-bundles \
    --store-sqlite .agentdebug/errors.sqlite \
    --license CC-BY-4.0

# Pull a bundle from anywhere
agentdebug hub pull git:git@github.com:org/repo.git#bundles \
    --bundle bundle_01ABCD --into .agentdebug/hub_pulls

# List what's there
agentdebug hub list hf:your-org/agentdebug-bundles --limit 100
```

## 6. Authentication

By design, AgentDebugX never holds credentials.

- Git: relies on `git` being configured (SSH key, credential helper, env-based
  PAT). Whatever lets you `git push` works.
- Hugging Face: relies on `HF_TOKEN` or `huggingface-cli login`. Standard.
- Local: filesystem permissions.

This keeps the security surface small and lets ops teams use their existing
key-management.

## 7. Programmatic API

```python
from agentdebug.hub import (
    Bundle, build_manifest, backend_from_spec, scrub_trajectory,
)
from agentdebug.analyzers import HeuristicAnalyzer

scrub_trajectory(trajectory)  # mutates in place
report = HeuristicAnalyzer().analyze(trajectory)
manifest = build_manifest(trajectory, report=report, scrubbed=True)
backend = backend_from_spec("local:/srv/hub")
ref = backend.push(Bundle(manifest=manifest, trajectory=trajectory, report=report))
```

## 8. Discoverability + Hugging Face

The HF backend uploads each bundle under `bundles/<bundle_id>/` in a Datasets
repo. Once a project accumulates enough bundles, generate a Parquet roll-up
of the manifests (planned for v0.3) so you can search by failure family,
framework, or root-cause step in the HF dataset viewer.

## 9. Status (v0.1)

Shipping:

- `Bundle`, `BundleManifest`, `pack_bundle`, `unpack_bundle`
- `Scrubber` + `DEFAULT_REDACTIONS` (12 patterns) + `ScrubReport`
- `LocalHubBackend` (stdlib only)
- `GitHubBackend` (via `git` CLI; tested against a local bare repo in CI)
- `HuggingFaceBackend` (gated on `huggingface_hub`)
- CLI: `hub push | pull | list`

Roadmap:

- Bundle signing + provenance (Sigstore)
- Parquet manifest roll-up for fast `hub search`
- Community moderation queue + take-down workflow
- Differential bundles (push only what changed since last push)
- Dataset card auto-generation for HF uploads
