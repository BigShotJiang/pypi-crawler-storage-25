# 17 — Claude Code Design Patterns Worth Borrowing

This note extracts design ideas from Claude Code and maps them to AgentDebugX.
The goal is not to clone Claude Code. The useful lesson is how a coding-agent
runtime becomes practical: it offers small, composable control surfaces with
clear scope, context cost, permission behavior, and extension packaging.

Primary references:

- Claude Code feature overview: https://code.claude.com/docs/en/features-overview
- Hooks reference: https://code.claude.com/docs/en/hooks
- Agent SDK hooks: https://code.claude.com/docs/en/agent-sdk/hooks
- Subagents: https://code.claude.com/docs/en/sub-agents
- Agent SDK subagents: https://code.claude.com/docs/en/agent-sdk/subagents
- Skills / slash commands: https://code.claude.com/docs/en/slash-commands
- Memory: https://code.claude.com/docs/en/memory
- MCP: https://code.claude.com/docs/en/mcp
- Permissions: https://code.claude.com/docs/en/permissions
- Plugins: https://code.claude.com/docs/en/plugins
- Plugin reference: https://code.claude.com/docs/en/plugins-reference

## 1. Extension surfaces should have explicit context cost

Claude Code splits extension mechanisms by when they load and what they cost:

- Memory files: always-on project/user/org context.
- Skills: lightweight descriptions at startup, full instructions only when used.
- MCP: external tools/resources with schemas fetched when needed.
- Subagents: isolated context windows with explicit task prompts.
- Hooks: external automation with no context cost unless they return context.

AgentDebugX design implication:

- Add a **Context Budget Ledger** to the architecture. Every detector, judge,
  recoverer, taxonomy pack, and UI helper should declare:
  - `load_time`: startup, per-run, per-step, on-demand, offline.
  - `context_cost`: none, metadata-only, bounded excerpt, full trace.
  - `latency_budget_ms`.
  - `privacy_surface`: local-only, model-visible, external-service-visible.
- Default AgentDebugX behavior should be low-noise: record structured traces
  always, load expensive diagnosis context only on demand or after failure.

## 2. Hooks are not just callbacks; they are decision points

Claude Code hooks run at lifecycle points such as session start, pre-tool use,
post-tool use, stop, subagent stop, permission request, file change, compaction,
and task lifecycle. Some hook outcomes can block or alter behavior; others only
log or add context.

AgentDebugX design implication:

- Treat runtime hook points as first-class schema and API concepts:
  `BeforeToolUse`, `AfterToolUse`, `BeforeAgentStep`, `AfterAgentStep`,
  `BeforeHandoff`, `AfterHandoff`, `BeforeStop`, `AfterStop`,
  `BeforeRecoveryApply`, `AfterRecoveryApply`, `BeforeMemoryWrite`, and
  `BeforeExternalSideEffect`.
- Distinguish passive observation from active decisions:
  `observe`, `annotate`, `block`, `escalate`, `rewrite`, and `retry`.
- Add a `DecisionRecord` model so every block/allow/escalate decision is
  attributable and replayable.

This would make AgentDebugX useful as both an observability SDK after a failure
and a live guardrail/debug controller before a failure becomes irreversible.

## 3. Permissions must be runtime-enforced, not prompt-enforced

Claude Code separates model instructions from permission rules. Permission
settings decide what tools can run, while prompts merely influence what the
model tries to do.

AgentDebugX design implication:

- Add a `PolicyEngine` that recoverers and live detectors must respect.
- Model policy as trace data:
  - requested tool/action,
  - matching allow/ask/deny rule,
  - decision source,
  - human approval token if any,
  - whether the action was executed, rewritten, or blocked.
- Recovery strategies should compile into policy-aware plans:
  - safe memory writes can be auto-applied,
  - prompt/tool schema edits can be staged,
  - external side effects require approval or compensation,
  - destructive tool calls are denied unless explicitly configured.

This reinforces the existing "suggest by default, apply opt-in" principle in
[08_recovery.md](./08_recovery.md).

## 4. Subagents need provenance and handoff contracts

Claude Code subagents work in isolated contexts. The parent must pass the task,
paths, errors, and decisions the subagent needs; the child does not inherit the
whole parent transcript by default.

AgentDebugX design implication:

- Multi-agent traces should record more than `source_agent -> target_agent`.
  Add handoff fields:
  - `delegation_prompt`
  - `expected_output_contract`
  - `tool_surface`
  - `context_scope`
  - `omitted_context_summary`
  - `return_payload`
  - `stop_reason`
- Attribution should classify handoff failures into:
  - bad delegation prompt,
  - missing context,
  - over-broad tool access,
  - wrong subagent selection,
  - invalid return contract,
  - parent integration failure.

This should strengthen the Who&When-style "which agent and when" layer by
separating subagent-local failures from parent-orchestration failures.

## 5. Skills suggest a packaging model for debug knowledge

Claude Code skills package procedural instructions and optional scripts. They
load only when relevant or explicitly invoked.

AgentDebugX design implication:

- Introduce **Debug Skills** or **Diagnosis Packs**:
  - detector prompt templates,
  - taxonomy extensions,
  - recovery playbooks,
  - benchmark fixtures,
  - schema validators,
  - example traces,
  - redaction rules.
- Packs should be discoverable by metadata:
  - `applies_to_frameworks`
  - `applies_to_taxonomy`
  - `required_artifacts`
  - `privacy_requirements`
  - `cost_profile`
- Example packs:
  - `browser-gui-debug`
  - `coding-agent-debug`
  - `multiagent-handoff-debug`
  - `tool-schema-debug`
  - `security-prompt-injection-debug`

This avoids putting every specialized detector into core while still keeping the
ecosystem easy to install and test.

## 6. MCP should be both an adapter target and a product surface

Claude Code uses MCP for external tools, resources, prompts, dynamic capability
updates, and interactive elicitation.

AgentDebugX design implication:

- **As a captured target:** trace MCP tool calls, resource reads, server
  reconnects, dynamic tool-list changes, and elicitation prompts.
- **As a product surface:** expose AgentDebugX itself as an MCP server:
  - resources: `trace://{run_id}`, `report://{report_id}`,
    `taxonomy://{code}`, `corpus://similar/{run_id}`.
  - tools: `analyze_trace`, `search_errors`, `propose_fix`,
    `export_repro_bundle`, `open_dashboard`.
  - prompts: `debug_this_trace`, `write_recovery_plan`,
    `classify_failure_mode`.

This would let Claude Code, OpenAI Agents, IDE agents, and future MCP-compatible
agents debug themselves through the same AgentDebugX backend.

## 7. Plugin-style packaging is better than one giant core

Claude Code plugins can package skills, agents, hooks, MCP servers, LSP servers,
monitors, binaries, settings, and persistent data. The important pattern is not
the exact directory layout; it is component-level packaging with local testing
and reload.

AgentDebugX design implication:

- Define an `agentdebugx-plugin.yaml` manifest:
  - `adapters`
  - `detectors`
  - `attributors`
  - `recoverers`
  - `taxonomy_axes`
  - `ui_panels`
  - `mcp_tools`
  - `redactors`
  - `benchmarks`
  - `example_traces`
- Provide development commands:
  - `agentdebugx plugin validate`
  - `agentdebugx plugin load --dir ./plugin`
  - `agentdebugx plugin reload`
  - `agentdebugx plugin test --trace examples/failure.json`
- Keep core small and stable; let domain specialists ship packs.

## 8. Memory should split human-authored rules from learned notes

Claude Code distinguishes persistent human-authored context from auto memory
learned from corrections and project experience.

AgentDebugX design implication:

- Split recovery memory into:
  - `ManualRule`: human-reviewed, versioned, durable.
  - `LearnedFailureNote`: generated from traces, lower trust, expires or needs
    confirmation.
  - `AgentLocalMemory`: scoped to a subagent/role.
  - `ProjectMemory`: shared across runs in one repo or service.
  - `OrganizationPolicy`: centrally managed, not overwritten by local learning.
- Every learned note should carry:
  - source trace IDs,
  - failure mode,
  - confidence,
  - last validated date,
  - outcome statistics after use.

This prevents the error database from becoming a pile of unreviewed reflections.

## 9. Local state lifecycle is a first-class UX problem

Claude Code exposes project-level data management and status/debug commands.
AgentDebugX will collect more sensitive data than most agent frameworks:
prompts, tool arguments, outputs, screenshots, files, diffs, and recovery
outcomes.

AgentDebugX design implication:

- Add CLI lifecycle commands:
  - `agentdebugx status`
  - `agentdebugx doctor`
  - `agentdebugx project purge --dry-run`
  - `agentdebugx privacy scan`
  - `agentdebugx retention set`
  - `agentdebugx export repro-bundle`
- Add retention policies:
  - keep raw artifacts for N days,
  - keep redacted summaries indefinitely,
  - keep accepted taxonomy labels,
  - delete rejected sensitive traces.

This should be documented before public corpus upload exists.

## 10. Stop gates are a missing but important recovery primitive

Claude Code can run lifecycle hooks when the agent tries to stop. The broader
pattern is valuable: a runtime should be able to block completion if critical
requirements are not satisfied.

AgentDebugX design implication:

- Add `StopGate` as a detector/recoverer hybrid:
  - checks final success criteria,
  - verifies required artifacts,
  - enforces no unresolved critical errors,
  - prevents "premature success" from being recorded as success,
  - triggers a repair prompt or human approval.
- Store stop-gate decisions as trace events so premature-stop attribution has
  direct evidence.

## Proposed additions to the existing design

| Area | Add |
| --- | --- |
| Architecture | Runtime control plane alongside passive trace substrate |
| Trace schema | `DecisionRecord`, `PolicyDecision`, `HandoffContract`, `ContextBudget`, `ExtensionRef` |
| Detectors | Live hook-compatible detectors and stop gates |
| Attribution | Handoff-contract blame and subagent context-scope blame |
| Recovery | Policy-aware apply pipeline and approval tokens |
| Error DB | Human-reviewed memory vs generated learned notes |
| UI | Permissions, hooks, plugin status, retention, and purge views |
| API | Plugin/pack registry and MCP server surface |

## Near-term priority

For v0.1, do not implement all of this. The minimal useful addition is:

1. Add trace schema fields for policy decisions and handoff contracts.
2. Add a lightweight hook API with `observe`, `block`, and `escalate`.
3. Add `agentdebugx doctor` and `agentdebugx status` to make installation and
   adapter debugging feel reliable.
4. Document AgentDebugX as an MCP server so other agents can query traces and
   failure reports.
