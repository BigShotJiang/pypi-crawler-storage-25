The core helper package used in many other packages of the **GALACTIC** ecosystem.
