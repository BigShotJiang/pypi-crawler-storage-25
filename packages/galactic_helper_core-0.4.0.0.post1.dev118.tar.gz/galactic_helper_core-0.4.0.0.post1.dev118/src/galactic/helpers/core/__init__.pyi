from collections.abc import Mapping
from pathlib import Path

def detect_plugins(group: str = "galactic", name: str | None = None) -> None: ...
def default_repr(
    item: object,
    *,
    class_name: str | None = None,
    module_name: str | None = None,
) -> str: ...
def resolve_pip_config_path(*, env: Mapping[str, str] | None = None) -> Path: ...
