"""
Defines three helper functions.

* :func:`detect_plugins` for detecting plugins
* :func:`default_repr` for providing a unified string representation of objects
* :func:`resolve_pip_config_path` for resolving the pip config file path
"""

from ._config import resolve_pip_config_path
from ._plugins import detect_plugins
from ._repr import default_repr

__all__ = ("detect_plugins", "default_repr", "resolve_pip_config_path")
