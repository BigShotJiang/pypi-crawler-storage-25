from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_list_response import WorkspaceListResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    path: str | Unset = "",
    limit: int | Unset = 1000,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["path"] = path

    params["limit"] = limit

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/workspace/files",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkspaceListResponse | None:
    if response.status_code == 200:
        response_200 = WorkspaceListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkspaceListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    path: str | Unset = "",
    limit: int | Unset = 1000,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceListResponse]:
    """List Workspace Items

     List files and folders in the project workspace.

    Args:
        path (str | Unset): Directory path relative to project root Default: ''.
        limit (int | Unset): Max items to return Default: 1000.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceListResponse]
    """

    kwargs = _get_kwargs(
        path=path,
        limit=limit,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    path: str | Unset = "",
    limit: int | Unset = 1000,
    project_id: str,
) -> HTTPValidationError | WorkspaceListResponse | None:
    """List Workspace Items

     List files and folders in the project workspace.

    Args:
        path (str | Unset): Directory path relative to project root Default: ''.
        limit (int | Unset): Max items to return Default: 1000.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceListResponse
    """

    return sync_detailed(
        client=client,
        path=path,
        limit=limit,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    path: str | Unset = "",
    limit: int | Unset = 1000,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceListResponse]:
    """List Workspace Items

     List files and folders in the project workspace.

    Args:
        path (str | Unset): Directory path relative to project root Default: ''.
        limit (int | Unset): Max items to return Default: 1000.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceListResponse]
    """

    kwargs = _get_kwargs(
        path=path,
        limit=limit,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    path: str | Unset = "",
    limit: int | Unset = 1000,
    project_id: str,
) -> HTTPValidationError | WorkspaceListResponse | None:
    """List Workspace Items

     List files and folders in the project workspace.

    Args:
        path (str | Unset): Directory path relative to project root Default: ''.
        limit (int | Unset): Max items to return Default: 1000.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceListResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            path=path,
            limit=limit,
            project_id=project_id,
        )
    ).parsed
