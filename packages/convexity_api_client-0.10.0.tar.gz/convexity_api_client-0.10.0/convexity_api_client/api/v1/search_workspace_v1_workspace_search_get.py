from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_search_response import WorkspaceSearchResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    q: str,
    path: str | Unset = "",
    limit: int | Unset = 200,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["q"] = q

    params["path"] = path

    params["limit"] = limit

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/workspace/search",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkspaceSearchResponse | None:
    if response.status_code == 200:
        response_200 = WorkspaceSearchResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkspaceSearchResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    path: str | Unset = "",
    limit: int | Unset = 200,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceSearchResponse]:
    """Search Workspace

     Search for files/folders whose path matches the query.

    Args:
        q (str): Search query
        path (str | Unset): Directory scope Default: ''.
        limit (int | Unset): Max results Default: 200.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceSearchResponse]
    """

    kwargs = _get_kwargs(
        q=q,
        path=path,
        limit=limit,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    path: str | Unset = "",
    limit: int | Unset = 200,
    project_id: str,
) -> HTTPValidationError | WorkspaceSearchResponse | None:
    """Search Workspace

     Search for files/folders whose path matches the query.

    Args:
        q (str): Search query
        path (str | Unset): Directory scope Default: ''.
        limit (int | Unset): Max results Default: 200.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceSearchResponse
    """

    return sync_detailed(
        client=client,
        q=q,
        path=path,
        limit=limit,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    path: str | Unset = "",
    limit: int | Unset = 200,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceSearchResponse]:
    """Search Workspace

     Search for files/folders whose path matches the query.

    Args:
        q (str): Search query
        path (str | Unset): Directory scope Default: ''.
        limit (int | Unset): Max results Default: 200.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceSearchResponse]
    """

    kwargs = _get_kwargs(
        q=q,
        path=path,
        limit=limit,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    q: str,
    path: str | Unset = "",
    limit: int | Unset = 200,
    project_id: str,
) -> HTTPValidationError | WorkspaceSearchResponse | None:
    """Search Workspace

     Search for files/folders whose path matches the query.

    Args:
        q (str): Search query
        path (str | Unset): Directory scope Default: ''.
        limit (int | Unset): Max results Default: 200.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceSearchResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            q=q,
            path=path,
            limit=limit,
            project_id=project_id,
        )
    ).parsed
