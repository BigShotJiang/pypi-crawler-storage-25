from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_item import WorkspaceItem
from ...types import UNSET, Response


def _get_kwargs(
    *,
    path: str,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["path"] = path

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/workspace/files/info",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkspaceItem | None:
    if response.status_code == 200:
        response_200 = WorkspaceItem.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkspaceItem]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    path: str,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceItem]:
    """Get Workspace Item Info

     Get metadata about a single workspace file or folder.

    Args:
        path (str): File path to inspect
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceItem]
    """

    kwargs = _get_kwargs(
        path=path,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    path: str,
    project_id: str,
) -> HTTPValidationError | WorkspaceItem | None:
    """Get Workspace Item Info

     Get metadata about a single workspace file or folder.

    Args:
        path (str): File path to inspect
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceItem
    """

    return sync_detailed(
        client=client,
        path=path,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    path: str,
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceItem]:
    """Get Workspace Item Info

     Get metadata about a single workspace file or folder.

    Args:
        path (str): File path to inspect
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceItem]
    """

    kwargs = _get_kwargs(
        path=path,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    path: str,
    project_id: str,
) -> HTTPValidationError | WorkspaceItem | None:
    """Get Workspace Item Info

     Get metadata about a single workspace file or folder.

    Args:
        path (str): File path to inspect
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceItem
    """

    return (
        await asyncio_detailed(
            client=client,
            path=path,
            project_id=project_id,
        )
    ).parsed
