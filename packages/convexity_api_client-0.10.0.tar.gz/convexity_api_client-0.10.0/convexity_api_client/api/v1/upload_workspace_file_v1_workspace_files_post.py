from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_upload_workspace_file_v1_workspace_files_post import BodyUploadWorkspaceFileV1WorkspaceFilesPost
from ...models.http_validation_error import HTTPValidationError
from ...models.workspace_upload_response import WorkspaceUploadResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: BodyUploadWorkspaceFileV1WorkspaceFilesPost,
    path: str | Unset = "",
    project_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["path"] = path

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/workspace/files",
        "params": params,
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkspaceUploadResponse | None:
    if response.status_code == 201:
        response_201 = WorkspaceUploadResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkspaceUploadResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyUploadWorkspaceFileV1WorkspaceFilesPost,
    path: str | Unset = "",
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceUploadResponse]:
    """Upload Workspace File

     Upload a file to the project workspace.

    Args:
        path (str | Unset): Destination directory (relative to project root) Default: ''.
        project_id (str):
        body (BodyUploadWorkspaceFileV1WorkspaceFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        path=path,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: BodyUploadWorkspaceFileV1WorkspaceFilesPost,
    path: str | Unset = "",
    project_id: str,
) -> HTTPValidationError | WorkspaceUploadResponse | None:
    """Upload Workspace File

     Upload a file to the project workspace.

    Args:
        path (str | Unset): Destination directory (relative to project root) Default: ''.
        project_id (str):
        body (BodyUploadWorkspaceFileV1WorkspaceFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceUploadResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        path=path,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyUploadWorkspaceFileV1WorkspaceFilesPost,
    path: str | Unset = "",
    project_id: str,
) -> Response[HTTPValidationError | WorkspaceUploadResponse]:
    """Upload Workspace File

     Upload a file to the project workspace.

    Args:
        path (str | Unset): Destination directory (relative to project root) Default: ''.
        project_id (str):
        body (BodyUploadWorkspaceFileV1WorkspaceFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkspaceUploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        path=path,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: BodyUploadWorkspaceFileV1WorkspaceFilesPost,
    path: str | Unset = "",
    project_id: str,
) -> HTTPValidationError | WorkspaceUploadResponse | None:
    """Upload Workspace File

     Upload a file to the project workspace.

    Args:
        path (str | Unset): Destination directory (relative to project root) Default: ''.
        project_id (str):
        body (BodyUploadWorkspaceFileV1WorkspaceFilesPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkspaceUploadResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            path=path,
            project_id=project_id,
        )
    ).parsed
