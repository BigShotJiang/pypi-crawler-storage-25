from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AppSettings")


@_attrs_define
class AppSettings:
    """App-related project settings.

    Attributes:
        installed_app_ids (list[str] | None | Unset): List of installed app IDs. None means all apps are installed
            (default behavior).
    """

    installed_app_ids: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        installed_app_ids: list[str] | None | Unset
        if isinstance(self.installed_app_ids, Unset):
            installed_app_ids = UNSET
        elif isinstance(self.installed_app_ids, list):
            installed_app_ids = self.installed_app_ids

        else:
            installed_app_ids = self.installed_app_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if installed_app_ids is not UNSET:
            field_dict["installedAppIds"] = installed_app_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_installed_app_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                installed_app_ids_type_0 = cast(list[str], data)

                return installed_app_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        installed_app_ids = _parse_installed_app_ids(d.pop("installedAppIds", UNSET))

        app_settings = cls(
            installed_app_ids=installed_app_ids,
        )

        app_settings.additional_properties = d
        return app_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
