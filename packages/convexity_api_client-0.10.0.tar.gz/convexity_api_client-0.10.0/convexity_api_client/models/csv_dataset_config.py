from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CsvDatasetConfig")


@_attrs_define
class CsvDatasetConfig:
    r"""Configuration for CSV/TSV sourced from the project workspace.

    The ``file_path`` is a relative path inside the project workspace
    managed by :class:`WorkspaceService`.  For example ``data/sales.csv``.

        Attributes:
            file_path (str): Relative path to the CSV file inside the project workspace
            delimiter (str | Unset): Column delimiter (use '\t' for TSV) Default: ','.
            has_header (bool | Unset): Whether first row is header Default: True.
            encoding (str | Unset): File encoding Default: 'utf-8'.
            quote_char (str | Unset): Quote character Default: '\\"'.
            skip_rows (int | Unset): Number of rows to skip Default: 0.
            null_values (list[str] | Unset): Values to treat as null
            infer_types (bool | Unset): Whether to infer column types. If false, all columns are strings. Otherwise, types
                are inferred from data. Default: True.
            max_rows (int | None | Unset): Maximum rows to import
    """

    file_path: str
    delimiter: str | Unset = ","
    has_header: bool | Unset = True
    encoding: str | Unset = "utf-8"
    quote_char: str | Unset = '\\"'
    skip_rows: int | Unset = 0
    null_values: list[str] | Unset = UNSET
    infer_types: bool | Unset = True
    max_rows: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_path = self.file_path

        delimiter = self.delimiter

        has_header = self.has_header

        encoding = self.encoding

        quote_char = self.quote_char

        skip_rows = self.skip_rows

        null_values: list[str] | Unset = UNSET
        if not isinstance(self.null_values, Unset):
            null_values = self.null_values

        infer_types = self.infer_types

        max_rows: int | None | Unset
        if isinstance(self.max_rows, Unset):
            max_rows = UNSET
        else:
            max_rows = self.max_rows

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "filePath": file_path,
            }
        )
        if delimiter is not UNSET:
            field_dict["delimiter"] = delimiter
        if has_header is not UNSET:
            field_dict["hasHeader"] = has_header
        if encoding is not UNSET:
            field_dict["encoding"] = encoding
        if quote_char is not UNSET:
            field_dict["quoteChar"] = quote_char
        if skip_rows is not UNSET:
            field_dict["skipRows"] = skip_rows
        if null_values is not UNSET:
            field_dict["nullValues"] = null_values
        if infer_types is not UNSET:
            field_dict["inferTypes"] = infer_types
        if max_rows is not UNSET:
            field_dict["maxRows"] = max_rows

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_path = d.pop("filePath")

        delimiter = d.pop("delimiter", UNSET)

        has_header = d.pop("hasHeader", UNSET)

        encoding = d.pop("encoding", UNSET)

        quote_char = d.pop("quoteChar", UNSET)

        skip_rows = d.pop("skipRows", UNSET)

        null_values = cast(list[str], d.pop("nullValues", UNSET))

        infer_types = d.pop("inferTypes", UNSET)

        def _parse_max_rows(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_rows = _parse_max_rows(d.pop("maxRows", UNSET))

        csv_dataset_config = cls(
            file_path=file_path,
            delimiter=delimiter,
            has_header=has_header,
            encoding=encoding,
            quote_char=quote_char,
            skip_rows=skip_rows,
            null_values=null_values,
            infer_types=infer_types,
            max_rows=max_rows,
        )

        csv_dataset_config.additional_properties = d
        return csv_dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
