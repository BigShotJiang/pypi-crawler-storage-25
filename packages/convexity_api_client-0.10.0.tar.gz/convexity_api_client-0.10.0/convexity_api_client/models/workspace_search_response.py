from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.workspace_item import WorkspaceItem


T = TypeVar("T", bound="WorkspaceSearchResponse")


@_attrs_define
class WorkspaceSearchResponse:
    """Response for searching workspace files.

    Attributes:
        query (str): The search query that was used
        total_count (int): Number of matching items
        items (list[WorkspaceItem] | Unset): Matching files and folders
    """

    query: str
    total_count: int
    items: list[WorkspaceItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        query = self.query

        total_count = self.total_count

        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "query": query,
                "totalCount": total_count,
            }
        )
        if items is not UNSET:
            field_dict["items"] = items

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workspace_item import WorkspaceItem

        d = dict(src_dict)
        query = d.pop("query")

        total_count = d.pop("totalCount")

        _items = d.pop("items", UNSET)
        items: list[WorkspaceItem] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = WorkspaceItem.from_dict(items_item_data)

                items.append(items_item)

        workspace_search_response = cls(
            query=query,
            total_count=total_count,
            items=items,
        )

        workspace_search_response.additional_properties = d
        return workspace_search_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
