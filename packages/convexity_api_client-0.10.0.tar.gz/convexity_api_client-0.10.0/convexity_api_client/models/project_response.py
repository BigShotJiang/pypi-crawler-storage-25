from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.project_settings import ProjectSettings


T = TypeVar("T", bound="ProjectResponse")


@_attrs_define
class ProjectResponse:
    """Response model for a project.

    Attributes:
        id (str):
        name (str):
        slug (str):
        organization_id (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        general_system_prompt (None | str | Unset):
        settings (None | ProjectSettings | Unset): Versioned project settings
        organization_name (None | str | Unset):
    """

    id: str
    name: str
    slug: str
    organization_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    general_system_prompt: None | str | Unset = UNSET
    settings: None | ProjectSettings | Unset = UNSET
    organization_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project_settings import ProjectSettings

        id = self.id

        name = self.name

        slug = self.slug

        organization_id = self.organization_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        general_system_prompt: None | str | Unset
        if isinstance(self.general_system_prompt, Unset):
            general_system_prompt = UNSET
        else:
            general_system_prompt = self.general_system_prompt

        settings: dict[str, Any] | None | Unset
        if isinstance(self.settings, Unset):
            settings = UNSET
        elif isinstance(self.settings, ProjectSettings):
            settings = self.settings.to_dict()
        else:
            settings = self.settings

        organization_name: None | str | Unset
        if isinstance(self.organization_name, Unset):
            organization_name = UNSET
        else:
            organization_name = self.organization_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "slug": slug,
                "organizationId": organization_id,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if general_system_prompt is not UNSET:
            field_dict["generalSystemPrompt"] = general_system_prompt
        if settings is not UNSET:
            field_dict["settings"] = settings
        if organization_name is not UNSET:
            field_dict["organizationName"] = organization_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_settings import ProjectSettings

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        slug = d.pop("slug")

        organization_id = d.pop("organizationId")

        created_at = isoparse(d.pop("createdAt"))

        updated_at = isoparse(d.pop("updatedAt"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_general_system_prompt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        general_system_prompt = _parse_general_system_prompt(d.pop("generalSystemPrompt", UNSET))

        def _parse_settings(data: object) -> None | ProjectSettings | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_0 = ProjectSettings.from_dict(data)

                return settings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ProjectSettings | Unset, data)

        settings = _parse_settings(d.pop("settings", UNSET))

        def _parse_organization_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        organization_name = _parse_organization_name(d.pop("organizationName", UNSET))

        project_response = cls(
            id=id,
            name=name,
            slug=slug,
            organization_id=organization_id,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            general_system_prompt=general_system_prompt,
            settings=settings,
            organization_name=organization_name,
        )

        project_response.additional_properties = d
        return project_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
