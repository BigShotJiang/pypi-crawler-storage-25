from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkspaceItem")


@_attrs_define
class WorkspaceItem:
    """A file or folder entry in the workspace.

    Attributes:
        name (str): File or folder name (e.g. 'input.csv' or 'data/')
        key (str): Full path relative to project root
        is_folder (bool): Whether this item is a folder
        size (int | None | Unset): Size in bytes (None for folders)
        last_modified (None | str | Unset): Last modification timestamp
        content_type (None | str | Unset): MIME content type
    """

    name: str
    key: str
    is_folder: bool
    size: int | None | Unset = UNSET
    last_modified: None | str | Unset = UNSET
    content_type: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        key = self.key

        is_folder = self.is_folder

        size: int | None | Unset
        if isinstance(self.size, Unset):
            size = UNSET
        else:
            size = self.size

        last_modified: None | str | Unset
        if isinstance(self.last_modified, Unset):
            last_modified = UNSET
        else:
            last_modified = self.last_modified

        content_type: None | str | Unset
        if isinstance(self.content_type, Unset):
            content_type = UNSET
        else:
            content_type = self.content_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "key": key,
                "isFolder": is_folder,
            }
        )
        if size is not UNSET:
            field_dict["size"] = size
        if last_modified is not UNSET:
            field_dict["lastModified"] = last_modified
        if content_type is not UNSET:
            field_dict["contentType"] = content_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        key = d.pop("key")

        is_folder = d.pop("isFolder")

        def _parse_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        size = _parse_size(d.pop("size", UNSET))

        def _parse_last_modified(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_modified = _parse_last_modified(d.pop("lastModified", UNSET))

        def _parse_content_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_type = _parse_content_type(d.pop("contentType", UNSET))

        workspace_item = cls(
            name=name,
            key=key,
            is_folder=is_folder,
            size=size,
            last_modified=last_modified,
            content_type=content_type,
        )

        workspace_item.additional_properties = d
        return workspace_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
