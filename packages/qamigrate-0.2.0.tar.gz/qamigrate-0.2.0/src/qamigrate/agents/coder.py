"""
Coder Agent.

LLM-powered Playwright code generation.
Uses Anthropic SDK directly with tool use for structured output.
"""

import json
from pathlib import Path
from typing import Any

import structlog
from anthropic import Anthropic
from pydantic import BaseModel, Field

from qamigrate.core.config import CoderConfig

logger = structlog.get_logger(__name__)


class MethodDefinition(BaseModel):
    """Generated method with migration notes."""

    name: str = Field(description="Method name")
    signature: str = Field(description="Full method signature with return type and parameters")
    implementation: str = Field(description="Complete method implementation")
    migration_note: str | None = Field(default=None, description="Note about migration changes")


class PlaywrightCode(BaseModel):
    """Structured output schema for generated Playwright code."""

    package_name: str = Field(description="Java package name")
    imports: list[str] = Field(description="Required import statements")
    class_declaration: str = Field(description="Class signature with extends/implements")
    fields: list[str] = Field(description="Class field declarations")
    constructor: str = Field(description="Constructor with Page injection")
    methods: list[MethodDefinition] = Field(description="Method implementations")


SYSTEM_PROMPT = """You are an expert Java developer specializing in test automation migration.
Your task is to convert Selenium test code to Playwright Java, following these principles:

## Playwright Java Patterns

1. **Page Object Model**: All page objects receive `Page` via constructor injection
2. **Locators**: Use `page.locator()` with CSS selectors (preferred) or XPath
3. **Auto-waiting**: Remove all explicit waits - Playwright handles automatically
4. **Assertions**: Use Playwright's `assertThat()` with expect-style assertions
5. **Actions**: Replace Selenium Actions with `locator.click()`, `locator.fill()`, etc.

## Migration Rules

### Locators
- @FindBy(id="x") → private Locator fieldName; (initialized in constructor as page.locator("#x"))
- @FindBy(css="x") → page.locator("x")
- @FindBy(xpath="x") → page.locator("xpath=x")
- By.id("x") → page.locator("#x")
- By.className("x") → page.locator(".x")
- By.name("x") → page.locator("[name='x']")
- By.linkText("x") → page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("x"))

### Interactions
- element.sendKeys("text") → locator.fill("text")
- element.click() → locator.click()
- element.clear() → (removed, fill() clears automatically)
- new Select(element).selectByValue("x") → locator.selectOption("x")
- element.getText() → locator.textContent()
- element.getAttribute("x") → locator.getAttribute("x")

### Waits (REMOVE - Playwright auto-waits)
- WebDriverWait → REMOVE entirely
- ExpectedConditions.visibilityOf() → REMOVE
- ExpectedConditions.elementToBeClickable() → REMOVE
- Thread.sleep() → REMOVE (or page.waitForTimeout() only if absolutely necessary)

### Assertions
- assertTrue(element.isDisplayed()) → assertThat(locator).isVisible()
- assertEquals(expected, element.getText()) → assertThat(locator).hasText(expected)
- assertFalse(element.isDisplayed()) → assertThat(locator).isHidden()

### Driver Management
- WebDriver driver → Page page (injected via constructor)
- driver.get(url) → page.navigate(url)
- driver.findElement(By.x) → page.locator(selector)
- driver.getTitle() → page.title()
- driver.getCurrentUrl() → page.url()

### TestNG Lifecycle → Playwright/JUnit 5
- @BeforeClass → @BeforeAll static void beforeAll() { ... }
- @AfterClass → @AfterAll static void afterAll() { ... }
- @BeforeMethod → @BeforeEach void setUp() { ... }
- @AfterMethod → @AfterEach void tearDown() { ... }
- @Test → @Test (from org.junit.jupiter.api.Test)
- Remove testng.Assert imports → use org.junit.jupiter.api.Assertions or PlaywrightAssertions

### Test Class Structure
For TEST CLASSES (not page objects):
```java
import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class ExampleTest {
    static Playwright playwright;
    static Browser browser;
    BrowserContext context;
    Page page;

    @BeforeAll
    static void beforeAll() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch();
    }

    @AfterAll
    static void afterAll() {
        playwright.close();
    }

    @BeforeEach
    void setUp() {
        context = browser.newContext();
        page = context.newPage();
    }

    @AfterEach
    void tearDown() {
        context.close();
    }

    @Test
    void testExample() {
        // Test implementation
    }
}
```

### Page Object Structure
For PAGE OBJECTS (not test classes):
```java
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class ExamplePage {
    private final Page page;
    private final Locator someElement;

    public ExamplePage(Page page) {
        this.page = page;
        this.someElement = page.locator("#selector");
    }

    public void doAction() {
        someElement.click();
    }
}
```

## Code Style Requirements

- Use meaningful variable names
- Add brief comments explaining significant migration decisions
- Preserve original test intent and business logic
- Follow Java naming conventions (camelCase for methods/variables, PascalCase for classes)
- Use proper indentation (4 spaces)

## ⚠️ CRITICAL OUTPUT RULES - READ CAREFULLY ⚠️

1. **EXACTLY ONE class declaration** - Never repeat the class definition
2. **EXACTLY ONE constructor** - Generate only a single constructor, never duplicates
3. **Each field declared EXACTLY ONCE** - No duplicate field declarations
4. **Each method implemented EXACTLY ONCE** - No repeated method implementations
5. **COMPLETE, COMPILABLE code** - All braces must match, all semicolons included
6. **Package statement MUST match original** - Use exact same package name
7. **NO PARTIAL CODE** - Every method body must be complete
8. **NO PLACEHOLDER COMMENTS** - Replace all "..." or "// implementation" with actual code

## Pre-Output Checklist (VERIFY BEFORE RESPONDING)

Before generating output, mentally verify:
☐ Is there only ONE constructor?
☐ Is each field declared only ONCE?
☐ Is each method defined only ONCE?
☐ Are all braces {} properly matched?
☐ Does every statement end with a semicolon?
☐ Is the package name correct?

If any answer is NO, fix it before outputting."""


class CoderAgent:
    """
    LLM-powered Playwright code generation.

    Uses Anthropic SDK directly with tool use for structured output.
    """

    # Tool schema for structured output via Anthropic tool use
    _TOOL_SCHEMA = {
        "name": "generate_playwright_code",
        "description": "Generate structured Playwright Java code from Selenium source.",
        "input_schema": {
            "type": "object",
            "required": [
                "package_name",
                "imports",
                "class_declaration",
                "fields",
                "constructor",
                "methods",
            ],
            "properties": {
                "package_name": {
                    "type": "string",
                    "description": "Java package name",
                },
                "imports": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Required import statements",
                },
                "class_declaration": {
                    "type": "string",
                    "description": "Class signature with extends/implements",
                },
                "fields": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Class field declarations",
                },
                "constructor": {
                    "type": "string",
                    "description": "Constructor with Page injection",
                },
                "methods": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "signature", "implementation"],
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Method name",
                            },
                            "signature": {
                                "type": "string",
                                "description": "Full method signature",
                            },
                            "implementation": {
                                "type": "string",
                                "description": "Complete method implementation",
                            },
                            "migration_note": {
                                "type": "string",
                                "description": "Note about migration changes",
                            },
                        },
                    },
                    "description": "Method implementations",
                },
            },
        },
    }

    def __init__(self, config: CoderConfig | None = None) -> None:
        """Initialize coder agent with configuration."""
        self.config = config or CoderConfig()
        self.client = Anthropic()
        self.model = self.config.model

    def _parse_tool_response(self, response: Any) -> PlaywrightCode:
        """Parse Anthropic tool use response into PlaywrightCode."""
        for block in response.content:
            if block.type == "tool_use":
                data = block.input
                methods = [
                    MethodDefinition(
                        name=m["name"],
                        signature=m["signature"],
                        implementation=m["implementation"],
                        migration_note=m.get("migration_note"),
                    )
                    for m in data.get("methods", [])
                ]
                return PlaywrightCode(
                    package_name=data["package_name"],
                    imports=data["imports"],
                    class_declaration=data["class_declaration"],
                    fields=data["fields"],
                    constructor=data["constructor"],
                    methods=methods,
                )

        raise ValueError("No tool_use block found in response")

    def generate(self, utom: dict[str, Any], original_code: str) -> PlaywrightCode:
        """
        Generate Playwright code from UTOM representation.

        Args:
            utom: UTOM JSON representation of the test/page object
            original_code: Original Selenium source code

        Returns:
            PlaywrightCode structured output
        """
        logger.info(
            "Generating Playwright code",
            test_id=utom.get("test_id") or utom.get("page_id"),
        )

        prompt = self._build_prompt(utom, original_code)

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.config.max_tokens,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                tools=[self._TOOL_SCHEMA],
                tool_choice={"type": "tool", "name": "generate_playwright_code"},
            )

            result = self._parse_tool_response(response)
            logger.info("Code generation successful")
            return result

        except Exception as e:
            logger.error("Code generation failed", error=str(e))
            raise

    def generate_from_class_info(
        self,
        class_info: dict[str, Any],
        original_code: str,
        patterns: list[dict[str, Any]],
    ) -> PlaywrightCode:
        """
        Generate Playwright code directly from class info.

        Args:
            class_info: Parsed class information from Scanner
            original_code: Original Selenium source code
            patterns: Detected Selenium patterns

        Returns:
            PlaywrightCode structured output
        """
        # Build context from class info
        context = {
            "class_name": class_info.get("class_name"),
            "package": class_info.get("package"),
            "is_page_object": any(
                "@FindBy" in str(f.get("annotations", [])) for f in class_info.get("fields", [])
            ),
            "methods": class_info.get("methods", []),
            "fields": class_info.get("fields", []),
            "patterns_detected": [p.get("pattern_type") for p in patterns],
        }

        prompt = f"""Convert this Selenium Java class to Playwright Java.

## Class Context
```json
{json.dumps(context, indent=2)}
```

## Original Selenium Code
```java
{original_code}
```

## Detected Patterns Requiring Migration
{chr(10).join(f"- {p.get('pattern_type')}: {p.get('migration_strategy')}" for p in patterns[:10])}

## Requirements
1. Generate complete, compilable Playwright Java code
2. Preserve all business logic and test intent
3. Use Page Object pattern with constructor injection
4. Add migration comments for significant changes
5. Follow Playwright Java idioms

Generate the Playwright code now using the generate_playwright_code tool."""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.config.max_tokens,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                tools=[self._TOOL_SCHEMA],
                tool_choice={"type": "tool", "name": "generate_playwright_code"},
            )
            return self._parse_tool_response(response)

        except Exception as e:
            logger.error("Code generation failed", error=str(e))
            raise

    def _build_prompt(self, utom: dict[str, Any], original_code: str) -> str:
        """Construct the generation prompt with full context."""
        return f"""Convert this Selenium test to Playwright Java.

## UTOM (Universal Test Object Model)
```json
{json.dumps(utom, indent=2)}
```

## Original Selenium Code
```java
{original_code}
```

## Requirements
1. Generate complete, compilable Playwright Java code
2. Preserve all test logic and assertions
3. Use Page Object pattern with constructor injection
4. Add migration comments for significant changes
5. Follow Playwright Java idioms
6. Generate EXACTLY ONE constructor - no duplicates
7. Generate each method EXACTLY ONCE - no repeated implementations

Generate the Playwright code now."""

    def validate_generated_code(self, code: PlaywrightCode) -> list[str]:
        """
        Validate generated code for common issues.
        
        Returns:
            List of error messages, empty if valid
        """
        errors: list[str] = []
        
        # Check for duplicate method names
        method_names = [m.name for m in code.methods]
        seen_methods = set()
        for name in method_names:
            if name in seen_methods:
                errors.append(f"Duplicate method: {name}")
            seen_methods.add(name)
        
        # Check constructor for duplicates (multiple constructor definitions)
        constructor_count = code.constructor.count("public " + code.class_declaration.split()[-1].rstrip("{").strip() + "(")
        if constructor_count > 1:
            errors.append(f"Multiple constructor definitions found: {constructor_count}")
        
        # Check for unmatched braces in constructor
        open_braces = code.constructor.count("{")
        close_braces = code.constructor.count("}")
        if open_braces != close_braces:
            errors.append(f"Unmatched braces in constructor: {open_braces} open, {close_braces} close")
        
        # Check each method for unmatched braces
        for method in code.methods:
            open_b = method.implementation.count("{")
            close_b = method.implementation.count("}")
            if open_b != close_b:
                errors.append(f"Unmatched braces in method {method.name}: {open_b} open, {close_b} close")
        
        return errors

    @staticmethod
    def _reindent_block(text: str, base_indent: int = 1) -> list[str]:
        """
        Reindent a Java code block using brace-depth tracking.

        Args:
            text: Java source code block (constructor, method, etc.)
            base_indent: Starting indent level (1 = class member level = 4 spaces)

        Returns:
            List of properly indented lines
        """
        result: list[str] = []
        depth = base_indent

        for raw_line in text.split("\n"):
            stripped = raw_line.strip()
            if not stripped:
                continue

            # Closing brace decreases depth before printing
            close_count = stripped.count("}")
            open_count = stripped.count("{")

            # Lines that start with } should be at the outer depth
            if stripped.startswith("}"):
                depth -= 1

            indent = "    " * max(depth, 0)
            result.append(f"{indent}{stripped}")

            # Adjust depth after the line
            depth += open_count - close_count
            # If we already decremented for a leading }, undo the double-count
            if stripped.startswith("}"):
                depth += 1  # we pre-decremented, the close_count handles it

        return result

    def assemble_file(self, code: PlaywrightCode) -> str:
        """
        Assemble structured output into complete Java file.
        Includes deduplication logic to prevent common LLM output issues.

        Args:
            code: PlaywrightCode structured output

        Returns:
            Complete Java source file as string
        """
        lines: list[str] = []

        # Package declaration
        lines.append(f"package {code.package_name};")
        lines.append("")

        # Deduplicate imports
        unique_imports = []
        seen_imports = set()
        for imp in code.imports:
            # Normalize import
            if not imp.startswith("import "):
                imp = f"import {imp}"
            if not imp.endswith(";"):
                imp = f"{imp};"
            
            # Extract the import path for deduplication
            import_path = imp.replace("import ", "").replace(";", "").strip()
            if import_path not in seen_imports:
                seen_imports.add(import_path)
                unique_imports.append(imp)
        
        for imp in unique_imports:
            lines.append(imp)
        lines.append("")

        # Class declaration - ensure no duplicates
        class_decl = code.class_declaration.strip()
        if not class_decl.endswith("{"):
            lines.append(class_decl + " {")
        else:
            lines.append(class_decl)
        lines.append("")

        # Deduplicate fields
        unique_fields = []
        seen_field_names = set()
        for field_def in code.fields:
            # Extract field name (last word before = or ;)
            field_parts = field_def.replace(";", "").replace("=", " ").split()
            field_name = field_parts[-1] if field_parts else field_def
            
            if field_name not in seen_field_names:
                seen_field_names.add(field_name)
                field_line = field_def.strip()
                if not field_line.endswith(";"):
                    field_line += ";"
                unique_fields.append(field_line)
        
        for field_def in unique_fields:
            lines.append(f"    {field_def}")
        if unique_fields:
            lines.append("")

        # Constructor - reindent using brace-depth tracking
        lines.extend(self._reindent_block(code.constructor, base_indent=1))
        lines.append("")

        # Deduplicate methods
        seen_method_names = set()
        for method in code.methods:
            if method.name in seen_method_names:
                logger.warning(f"Skipping duplicate method: {method.name}")
                continue
            seen_method_names.add(method.name)

            if method.migration_note:
                lines.append(f"    // Migration: {method.migration_note}")

            # Build full method text: signature + implementation
            impl = method.implementation.strip()
            sig = method.signature.strip() if method.signature else ""

            # If implementation doesn't start with a method keyword or annotation,
            # it's just the body -- prepend the signature.
            impl_starts_with_sig = (
                impl.startswith("public ")
                or impl.startswith("private ")
                or impl.startswith("protected ")
                or impl.startswith("static ")
                or impl.startswith("void ")
                or impl.startswith("@")
            )

            if not impl_starts_with_sig and sig:
                full_method = f"{sig} {impl}"
            else:
                full_method = impl

            lines.extend(self._reindent_block(full_method, base_indent=1))
            lines.append("")

        lines.append("}")

        return "\n".join(lines)

    def save_generated_code(
        self,
        code: PlaywrightCode,
        output_path: Path,
    ) -> Path:
        """
        Save generated code to file.

        Args:
            code: PlaywrightCode structured output
            output_path: Path to save the file

        Returns:
            Path to the saved file
        """
        content = self.assemble_file(code)

        # Ensure directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Write file
        output_path.write_text(content, encoding="utf-8")

        logger.info("Saved generated code", path=str(output_path))
        return output_path
