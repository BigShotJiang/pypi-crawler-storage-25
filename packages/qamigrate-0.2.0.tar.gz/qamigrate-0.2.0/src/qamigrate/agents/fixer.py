"""
Fixer Agent.

Analyzes compilation errors and applies targeted fixes to generated code.
Uses rule-based fixes first, then LLM fallback for complex errors.
"""

import re
from typing import Any

import structlog
from anthropic import Anthropic

from qamigrate.agents.compiler import CompilerError, ErrorType
from qamigrate.core.config import FixerConfig

logger = structlog.get_logger(__name__)


# Common Playwright imports for auto-fixing
PLAYWRIGHT_IMPORTS: dict[str, str] = {
    "Page": "com.microsoft.playwright.Page",
    "Locator": "com.microsoft.playwright.Locator",
    "Browser": "com.microsoft.playwright.Browser",
    "BrowserContext": "com.microsoft.playwright.BrowserContext",
    "BrowserType": "com.microsoft.playwright.BrowserType",
    "Playwright": "com.microsoft.playwright.Playwright",
    "PlaywrightAssertions": "com.microsoft.playwright.assertions.PlaywrightAssertions",
    "AriaRole": "com.microsoft.playwright.options.AriaRole",
    "SelectOption": "com.microsoft.playwright.options.SelectOption",
    "FileChooser": "com.microsoft.playwright.FileChooser",
    "Dialog": "com.microsoft.playwright.Dialog",
    "Download": "com.microsoft.playwright.Download",
    "Frame": "com.microsoft.playwright.Frame",
    "ElementHandle": "com.microsoft.playwright.ElementHandle",
    "JSHandle": "com.microsoft.playwright.JSHandle",
    "Route": "com.microsoft.playwright.Route",
    "Request": "com.microsoft.playwright.Request",
    "Response": "com.microsoft.playwright.Response",
    "TimeoutError": "com.microsoft.playwright.TimeoutError",
    "PlaywrightException": "com.microsoft.playwright.PlaywrightException",
}

FIXER_SYSTEM_PROMPT = """You are an expert Java developer fixing Playwright test code compilation errors.

## Your Task
Analyze the compilation error and fix ONLY the specific issue. Do not refactor unrelated code.

## Common Playwright Java Fixes

### Missing Imports
```java
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;
```

### Type Mismatches
- Locator methods return void for actions: `locator.click()` not `WebElement e = locator.click()`
- Use `locator.textContent()` to get String from element
- Use `locator.getAttribute("value")` for input values
- Use `locator.inputValue()` for form input values

### Method Signatures
- `page.locator(selector)` not `page.findElement()`
- `locator.fill(text)` not `locator.sendKeys()`
- `locator.selectOption(value)` for dropdowns
- `locator.check()` / `locator.uncheck()` for checkboxes
- `locator.press("Enter")` for key presses

### Assertions
- Use `assertThat(locator).isVisible()` not `assertTrue(locator.isVisible())`
- Use `assertThat(locator).hasText("expected")` for text comparison

## Output Format
Return ONLY the fixed code section. Include enough context (3-5 lines before/after) for precise replacement.
Do not include explanations or markdown code fences - just the raw fixed code.
"""


class FixerAgent:
    """
    LLM-powered error remediation.

    Uses Claude 3.5 Sonnet with error context for targeted fixes.
    """

    def __init__(self, config: FixerConfig | None = None) -> None:
        """Initialize fixer agent with configuration."""
        self.config = config or FixerConfig()
        self.client = Anthropic()
        self.model = self.config.model
        self.use_rule_based_first = self.config.use_rule_based_first
        self.group_similar_errors = getattr(self.config, 'group_similar_errors', True)

    def _group_errors_by_type(
        self,
        errors: list[CompilerError],
    ) -> dict[str, list[CompilerError]]:
        """
        Group similar errors together for batch fixing.
        
        Returns:
            Dictionary mapping error type to list of errors
        """
        groups: dict[str, list[CompilerError]] = {}
        for error in errors:
            key = f"{error.error_type.value}:{error.message[:50]}"
            if key not in groups:
                groups[key] = []
            groups[key].append(error)
        return groups

    def fix(
        self,
        code: str,
        errors: list[CompilerError],
        retry_count: int = 0,
    ) -> tuple[str, list[str]]:
        """
        Apply fixes for compilation errors.

        Args:
            code: Current code with errors
            errors: List of compilation errors
            retry_count: Current retry attempt number

        Returns:
            Tuple of (fixed_code, list_of_changes_made)
        """
        logger.info(
            "Fixing code",
            error_count=len(errors),
            retry_count=retry_count,
        )

        fixed_code = code
        changes: list[str] = []

        # Sort errors by line number (fix from bottom to preserve line numbers)
        sorted_errors = sorted(errors, key=lambda e: e.line_number, reverse=True)

        for error in sorted_errors:
            # Try rule-based fix first (if enabled and first attempt)
            if self.use_rule_based_first and retry_count == 0:
                fixed_code, change = self._apply_rule_based_fix(fixed_code, error)
                if change:
                    changes.append(change)
                    continue

            # Fall back to LLM fix
            fixed_code, change = self._apply_llm_fix(fixed_code, error)
            if change:
                changes.append(change)

        # Apply deduplication to clean up any duplicates from LLM fixes
        fixed_code, dedup_changes = self.deduplicate_code(fixed_code)
        changes.extend(dedup_changes)

        logger.info("Fixes applied", change_count=len(changes))
        return fixed_code, changes

    def _apply_rule_based_fix(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        """
        Apply rule-based fix for common errors.

        Returns:
            Tuple of (fixed_code, change_description) or (code, None) if no fix
        """
        if error.error_type == ErrorType.MISSING_IMPORT:
            return self._fix_missing_import(code, error)

        if error.error_type == ErrorType.MISSING_CLASS:
            return self._fix_missing_import(code, error)

        if error.error_type == ErrorType.TYPE_MISMATCH:
            return self._fix_type_mismatch(code, error)

        if error.error_type == ErrorType.SYNTAX:
            return self._fix_syntax_error(code, error)

        return code, None

    def _fix_missing_import(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        """Add missing import statement."""
        # Extract class name from error
        match = re.search(r"cannot find symbol.*(?:class|variable)\s+(\w+)", error.message)
        if not match:
            return code, None

        class_name = match.group(1)

        # Check if we know the import
        if class_name not in PLAYWRIGHT_IMPORTS:
            return code, None

        import_stmt = f"import {PLAYWRIGHT_IMPORTS[class_name]};"

        # Check if already imported
        if import_stmt in code:
            return code, None

        # Find package declaration and add import after
        lines = code.split("\n")
        insert_index = 0

        for i, line in enumerate(lines):
            if line.startswith("package "):
                insert_index = i + 1
                break
            if line.startswith("import "):
                insert_index = i
                break

        # Find the last import to add after it
        for i, line in enumerate(lines):
            if line.startswith("import "):
                insert_index = i + 1

        lines.insert(insert_index, import_stmt)

        return "\n".join(lines), f"Added import: {import_stmt}"

    def _fix_type_mismatch(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        """Fix type mismatch errors."""
        lines = code.split("\n")

        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        # Common pattern: void method assigned to variable
        # e.g., "WebElement e = locator.click();"
        if "click()" in line and "=" in line:
            # Remove the assignment, keep just the method call
            match = re.match(r"(\s*).*=\s*(.*\.click\(\).*)$", line)
            if match:
                indent = match.group(1)
                method_call = match.group(2)
                lines[line_idx] = f"{indent}{method_call}"
                return "\n".join(lines), f"Fixed void assignment at line {error.line_number}"

        # Pattern: fill() returns void
        if "fill(" in line and "=" in line:
            match = re.match(r"(\s*).*=\s*(.*\.fill\(.*\).*)$", line)
            if match:
                indent = match.group(1)
                method_call = match.group(2)
                lines[line_idx] = f"{indent}{method_call}"
                return "\n".join(lines), f"Fixed void assignment at line {error.line_number}"

        return code, None

    def _fix_syntax_error(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        """Fix simple syntax errors."""
        lines = code.split("\n")

        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        # Missing semicolon
        if "';' expected" in error.message:
            if not line.rstrip().endswith(";") and not line.rstrip().endswith("{"):
                lines[line_idx] = line.rstrip() + ";"
                return "\n".join(lines), f"Added missing semicolon at line {error.line_number}"

        return code, None

    def _apply_llm_fix(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        """Use LLM for complex fixes."""
        lines = code.split("\n")

        # Extract context around error
        start = max(0, error.line_number - 6)
        end = min(len(lines), error.line_number + 5)
        context = "\n".join(lines[start:end])

        prompt = f"""Fix this compilation error in Playwright Java code.

## Error
File: {error.file_path}
Line: {error.line_number}
Type: {error.error_type.value}
Message: {error.message}

## Code Context (lines {start + 1}-{end})
{context}

## Compiler Output
{error.code_context}

Return the fixed version of the code context shown above.
Only return the fixed code, no explanations or markdown."""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1024,
                system=FIXER_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )

            fixed_context = response.content[0].text.strip()

            # Clean up response (remove markdown fences if present)
            fixed_context = self._clean_code_response(fixed_context)

            # Replace context in original code
            lines[start:end] = fixed_context.split("\n")

            return "\n".join(lines), f"LLM fix applied at line {error.line_number}"

        except Exception as e:
            logger.error("LLM fix failed", error=str(e))
            return code, None

    def _clean_code_response(self, response: str) -> str:
        """Clean up LLM response by removing markdown fences."""
        # Remove ```java and ``` if present
        response = re.sub(r"^```(?:java)?\n?", "", response)
        response = re.sub(r"\n?```$", "", response)
        return response.strip()

    def suggest_fixes(
        self,
        errors: list[CompilerError],
    ) -> list[dict[str, Any]]:
        """
        Generate fix suggestions without applying them.

        Args:
            errors: List of compilation errors

        Returns:
            List of suggested fixes with descriptions
        """
        suggestions: list[dict[str, Any]] = []

        for error in errors:
            suggestion: dict[str, Any] = {
                "error": error.to_dict(),
                "suggestion": None,
                "confidence": "low",
            }

            if error.error_type == ErrorType.MISSING_IMPORT:
                match = re.search(r"class (\w+)", error.message)
                if match and match.group(1) in PLAYWRIGHT_IMPORTS:
                    suggestion["suggestion"] = f"Add import: {PLAYWRIGHT_IMPORTS[match.group(1)]}"
                    suggestion["confidence"] = "high"

            elif error.error_type == ErrorType.TYPE_MISMATCH:
                suggestion["suggestion"] = "Check return types - Playwright methods like click() return void"
                suggestion["confidence"] = "medium"

            elif error.error_type == ErrorType.SYNTAX:
                suggestion["suggestion"] = "Check for missing semicolons or brackets"
                suggestion["confidence"] = "medium"

            suggestions.append(suggestion)

        return suggestions

    def deduplicate_code(self, code: str) -> tuple[str, list[str]]:
        """
        Remove duplicate class declarations, constructors, and methods.

        Args:
            code: Java source code potentially with duplicates

        Returns:
            Tuple of (cleaned_code, list_of_removals)
        """
        changes: list[str] = []
        lines = code.split("\n")
        
        # Track what we've seen
        seen_class_declarations: set[str] = set()
        seen_constructors: set[str] = set()
        seen_methods: set[str] = set()
        seen_fields: set[str] = set()
        
        result_lines: list[str] = []
        i = 0
        brace_depth = 0
        in_class = False
        
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            
            # Track class declarations
            class_match = re.match(r'^(public\s+)?class\s+(\w+)', stripped)
            if class_match:
                class_name = class_match.group(2)
                if class_name in seen_class_declarations and in_class:
                    # Skip this duplicate class and all its content
                    changes.append(f"Removed duplicate class: {class_name}")
                    depth = 1
                    i += 1
                    while i < len(lines) and depth > 0:
                        if '{' in lines[i]:
                            depth += lines[i].count('{')
                        if '}' in lines[i]:
                            depth -= lines[i].count('}')
                        i += 1
                    continue
                seen_class_declarations.add(class_name)
                in_class = True
            
            # Track constructors
            constructor_match = re.match(r'^\s*(public\s+)?(\w+)\s*\([^)]*\)\s*\{?\s*$', stripped)
            if constructor_match and in_class:
                method_name = constructor_match.group(2)
                # Check if it's a constructor (matches a seen class name)
                if method_name in seen_class_declarations:
                    constructor_sig = stripped.split('{')[0].strip()
                    if constructor_sig in seen_constructors:
                        # Skip duplicate constructor
                        changes.append(f"Removed duplicate constructor: {method_name}")
                        if '{' in stripped:
                            depth = 1
                            i += 1
                            while i < len(lines) and depth > 0:
                                if '{' in lines[i]:
                                    depth += lines[i].count('{')
                                if '}' in lines[i]:
                                    depth -= lines[i].count('}')
                                i += 1
                        else:
                            i += 1
                        continue
                    seen_constructors.add(constructor_sig)
            
            # Track field declarations (private/public final fields)
            field_match = re.match(r'^\s*(private|public)\s+(final\s+)?(\w+)\s+(\w+)\s*[;=]', stripped)
            if field_match and in_class:
                field_name = field_match.group(4)
                if field_name in seen_fields:
                    changes.append(f"Removed duplicate field: {field_name}")
                    i += 1
                    continue
                seen_fields.add(field_name)
            
            # Track method declarations
            method_match = re.match(r'^\s*(public|private|protected)?\s*(\w+)\s+(\w+)\s*\([^)]*\)', stripped)
            if method_match and in_class and not stripped.startswith('//'):
                method_name = method_match.group(3)
                # Skip if it's a constructor
                if method_name not in seen_class_declarations:
                    method_sig = stripped.split('{')[0].strip()
                    if method_sig in seen_methods:
                        changes.append(f"Removed duplicate method: {method_name}")
                        if '{' in stripped or (i + 1 < len(lines) and '{' in lines[i + 1]):
                            depth = 0
                            if '{' in stripped:
                                depth = 1
                            i += 1
                            while i < len(lines) and (depth > 0 or '{' not in lines[i-1]):
                                if '{' in lines[i]:
                                    depth += lines[i].count('{')
                                if '}' in lines[i]:
                                    depth -= lines[i].count('}')
                                if depth <= 0:
                                    break
                                i += 1
                            i += 1
                        else:
                            i += 1
                        continue
                    seen_methods.add(method_sig)
            
            # Handle unmatched braces (clean up orphaned closing braces)
            if stripped == '}':
                brace_depth -= 1
                if brace_depth < 0:
                    changes.append("Removed orphaned closing brace")
                    brace_depth = 0
                    i += 1
                    continue
            
            if '{' in stripped:
                brace_depth += stripped.count('{') - stripped.count('}')
            
            result_lines.append(line)
            i += 1
        
        # Clean up multiple empty lines
        cleaned_lines: list[str] = []
        prev_empty = False
        for line in result_lines:
            is_empty = line.strip() == ''
            if is_empty and prev_empty:
                continue
            cleaned_lines.append(line)
            prev_empty = is_empty
        
        if changes:
            logger.info("Deduplication applied", removals=len(changes))
        
        return "\n".join(cleaned_lines), changes
