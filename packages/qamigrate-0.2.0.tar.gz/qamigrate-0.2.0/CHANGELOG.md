# Changelog

All notable changes to QAMigrate are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-15

**Theme: Trust & Evidence.** You no longer just get migrated code — you get proof of what changed, how confident we are, and how much time you saved.

### Added
- **Migration Report** in three formats: HTML, JSON, and Markdown
  - Per-file records with detected patterns, confidence score, compilation status, and before/after diff
  - Batch-level metrics: files succeeded/failed, patterns handled, average confidence, estimated hours saved
  - HTML report includes side-by-side diff viewer (stdlib `difflib`) with dark theme
- **`--dry-run` flag** on `qamigrate migrate`: scan all target files and preview patterns without calling the LLM or writing output
- **`--report <dir>` flag** on `qamigrate migrate`: writes `report.html`, `report.json`, `report.md` to the specified directory
- **`compiler.skip`** config option: skip compilation validation when Playwright JARs aren't available locally
- **Confidence scoring** per file (0-100) derived from success + compilation attempts
- **Time-saved estimate** based on ~15 min of manual effort per pattern

### Changed
- Simplified pipeline: `SupervisorConfig` renamed to `PipelineConfig`
- `QAMigrateConfig` now uses `pipeline.max_retries` instead of `supervisor.max_retries`
- `run_migration()` now returns a `MigrationResult` with an attached `MigrationRecord`
- CLI `migrate` command output: per-file status with confidence score, summary table with batch metrics

### Removed
- Dead modules: `supervisor.py`, `visual.py`, `utom.py`, `test_cleanup.py`, `languages.py`, `pdf_reports.py`, `dependencies.py`, `parallel.py`, `security.py`, `reports.py`, `database.py`, `integrations/jira_client.py`, `cli/interactive.py`
- Old web server (`server/`) and React dashboard (`dashboard/`) — will return in v0.3.0 once backed by the new report format
- CLI commands: `verify` (visual agent was mocked), `export` (superseded by `migrate --report`), `dashboard` (temporarily removed)
- Unused config sections: `visual`, `docker`, `server`, `quality_gates`
- Unused dependencies: `httpx`, `email-validator`, `fastapi`, `uvicorn`, `websockets`, `docker`, `opencv-python`, `pillow`, `imagehash`, `numpy`, `openai`

### Fixed
- `datetime.utcnow()` deprecation warnings on Python 3.12+ (now using `datetime.now(timezone.utc)`)
- Maven `pom.xml` element truthiness deprecation warnings in scanner
- CLI `--all` no longer requires the optional `DependencyAnalyzer` — walks `src/test` then `src/` directly

### Developer experience
- Added `tests/test_report.py` (13 new tests covering report rendering and confidence scoring)
- All 25 tests pass with no warnings

---

## [0.1.0] - 2026-04-14

### Added
- Initial release.
- Selenium Java -> Playwright Java migration pipeline:
  - **Scanner** (Tree-sitter, 70+ pattern queries)
  - **Coder** (Claude tool use for structured output)
  - **Compiler** (javac validation)
  - **Fixer** (rule-based + LLM error remediation with up to 3 retries)
- CLI commands: `init`, `scan`, `migrate`
- Validated end-to-end on real Selenium files covering `@FindBy`, `PageFactory`, `WebDriverWait`, `Actions`, `Select`, alerts, iframes, `JavascriptExecutor`, file uploads, TestNG inheritance, and `@DataProvider`.
