package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Dashboard page with complex interactions:
 * - Dropdowns (Select)
 * - Hover menus (Actions)
 * - Dynamic lists
 * - iframes
 * - Alerts
 */
public class DashboardPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    @FindBy(id = "user-menu")
    private WebElement userMenu;

    @FindBy(css = ".notification-badge")
    private WebElement notificationBadge;

    @FindBy(id = "search-input")
    private WebElement searchInput;

    @FindBy(css = "table.data-table tbody tr")
    private WebElement tableRows;

    @FindBy(id = "timezone-select")
    private WebElement timezoneDropdown;

    @FindBy(css = ".sidebar-nav a")
    private WebElement sidebarLinks;

    @FindBy(id = "chart-iframe")
    private WebElement chartIframe;

    @FindBy(xpath = "//button[contains(@class, 'btn-export')]")
    private WebElement exportButton;

    @FindBy(css = ".modal-overlay")
    private WebElement modalOverlay;

    @FindBy(id = "confirm-btn")
    private WebElement confirmButton;

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    // Hover interaction
    public void hoverUserMenu() {
        Actions actions = new Actions(driver);
        actions.moveToElement(userMenu).perform();
    }

    public void clickLogout() {
        hoverUserMenu();
        WebElement logoutLink = wait.until(
            ExpectedConditions.elementToBeClickable(By.linkText("Logout"))
        );
        logoutLink.click();
    }

    // Dropdown interaction
    public void selectTimezone(String timezone) {
        Select select = new Select(timezoneDropdown);
        select.selectByVisibleText(timezone);
    }

    public String getSelectedTimezone() {
        Select select = new Select(timezoneDropdown);
        return select.getFirstSelectedOption().getText();
    }

    // Search with keyboard
    public void searchFor(String query) {
        searchInput.clear();
        searchInput.sendKeys(query);
        searchInput.sendKeys(org.openqa.selenium.Keys.ENTER);
    }

    // Dynamic list
    public List<String> getTableData() {
        List<WebElement> rows = driver.findElements(By.cssSelector("table.data-table tbody tr"));
        return rows.stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public int getRowCount() {
        List<WebElement> rows = driver.findElements(By.cssSelector("table.data-table tbody tr"));
        return rows.size();
    }

    // iframe interaction
    public void switchToChartFrame() {
        driver.switchTo().frame(chartIframe);
    }

    public void switchToMainContent() {
        driver.switchTo().defaultContent();
    }

    // Alert handling
    public void clickExportAndAcceptAlert() {
        exportButton.click();
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();
    }

    public void clickExportAndDismissAlert() {
        exportButton.click();
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().dismiss();
    }

    // Modal interaction
    public void waitForModalAndConfirm() {
        wait.until(ExpectedConditions.visibilityOf(modalOverlay));
        wait.until(ExpectedConditions.elementToBeClickable(confirmButton));
        confirmButton.click();
        wait.until(ExpectedConditions.invisibilityOf(modalOverlay));
    }

    // Notification badge
    public int getNotificationCount() {
        String text = notificationBadge.getText().trim();
        return text.isEmpty() ? 0 : Integer.parseInt(text);
    }

    public boolean isNotificationBadgeVisible() {
        try {
            return notificationBadge.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    // Sidebar navigation
    public List<String> getSidebarLinkTexts() {
        List<WebElement> links = driver.findElements(By.cssSelector(".sidebar-nav a"));
        return links.stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public void clickSidebarLink(String linkText) {
        List<WebElement> links = driver.findElements(By.cssSelector(".sidebar-nav a"));
        for (WebElement link : links) {
            if (link.getText().equals(linkText)) {
                link.click();
                return;
            }
        }
        throw new RuntimeException("Sidebar link not found: " + linkText);
    }
}
