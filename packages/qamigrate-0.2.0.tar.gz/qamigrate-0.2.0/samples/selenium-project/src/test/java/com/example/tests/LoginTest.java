package com.example.tests;

import com.example.pages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class LoginTest {

    private WebDriver driver;
    private LoginPage loginPage;
    private static final String BASE_URL = "https://example.com/login";

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        loginPage = new LoginPage(driver);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testSuccessfulLogin() {
        loginPage.navigateTo(BASE_URL);
        loginPage.login("admin@example.com", "SecurePass123!");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("/dashboard"));

        Assert.assertEquals(driver.getCurrentUrl(), "https://example.com/dashboard");
        Assert.assertEquals(driver.getTitle(), "Dashboard - MyApp");
    }

    @Test
    public void testInvalidCredentials() {
        loginPage.navigateTo(BASE_URL);
        loginPage.login("wrong@example.com", "wrongpassword");

        String errorMsg = loginPage.getErrorMessage();
        Assert.assertEquals(errorMsg, "Invalid email or password");
        Assert.assertTrue(loginPage.isErrorDisplayed());
    }

    @Test
    public void testEmptyUsername() {
        loginPage.navigateTo(BASE_URL);
        loginPage.enterPassword("somepassword");
        loginPage.clickLogin();

        Assert.assertTrue(loginPage.isErrorDisplayed());
    }

    @Test
    public void testEmptyPassword() {
        loginPage.navigateTo(BASE_URL);
        loginPage.enterUsername("admin@example.com");
        loginPage.clickLogin();

        Assert.assertTrue(loginPage.isErrorDisplayed());
    }

    @Test
    public void testForgotPasswordLink() {
        loginPage.navigateTo(BASE_URL);
        loginPage.clickForgotPassword();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlContains("/forgot-password"));

        Assert.assertTrue(driver.getCurrentUrl().contains("/forgot-password"));
    }

    @Test
    public void testRememberMeCheckbox() {
        loginPage.navigateTo(BASE_URL);
        loginPage.toggleRememberMe();

        WebElement checkbox = driver.findElement(By.id("remember-me"));
        Assert.assertTrue(checkbox.isSelected());
    }

    @Test
    public void testPageTitle() {
        loginPage.navigateTo(BASE_URL);
        Assert.assertEquals(loginPage.getPageTitle(), "Login - MyApp");
    }

    @Test
    public void testMultipleLoginAttempts() {
        loginPage.navigateTo(BASE_URL);

        for (int i = 0; i < 3; i++) {
            loginPage.login("wrong@example.com", "wrong");
            Assert.assertTrue(loginPage.isErrorDisplayed());
        }

        // After 3 failed attempts, check for lockout message
        String errorMsg = loginPage.getErrorMessage();
        Assert.assertTrue(errorMsg.contains("locked") || errorMsg.contains("too many attempts"));
    }

    @Test
    public void testLoginButtonState() {
        loginPage.navigateTo(BASE_URL);
        Assert.assertTrue(loginPage.isLoginButtonEnabled());
    }

    @Test
    public void testNavigationLinks() {
        loginPage.navigateTo(BASE_URL);

        List<WebElement> links = driver.findElements(By.tagName("a"));
        Assert.assertTrue(links.size() > 0, "Expected navigation links on login page");

        boolean hasRegisterLink = false;
        for (WebElement link : links) {
            if (link.getText().contains("Register") || link.getText().contains("Sign up")) {
                hasRegisterLink = true;
                break;
            }
        }
        Assert.assertTrue(hasRegisterLink, "Expected a registration link");
    }
}
