package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Registration page with:
 * - File upload
 * - JavaScript execution
 * - Multiple form fields
 * - Scroll operations
 * - Conditional waits
 */
public class RegistrationPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;

    @FindBy(id = "first-name")
    private WebElement firstNameInput;

    @FindBy(id = "last-name")
    private WebElement lastNameInput;

    @FindBy(id = "email")
    private WebElement emailInput;

    @FindBy(id = "password")
    private WebElement passwordInput;

    @FindBy(id = "confirm-password")
    private WebElement confirmPasswordInput;

    @FindBy(id = "country-select")
    private WebElement countryDropdown;

    @FindBy(id = "terms-checkbox")
    private WebElement termsCheckbox;

    @FindBy(id = "avatar-upload")
    private WebElement avatarUpload;

    @FindBy(css = "button[type='submit']")
    private WebElement submitButton;

    @FindBy(css = ".field-error")
    private WebElement fieldError;

    @FindBy(id = "success-message")
    private WebElement successMessage;

    @FindBy(css = ".password-strength-meter")
    private WebElement passwordStrengthMeter;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    public void navigateTo(String url) {
        driver.get(url);
        wait.until(ExpectedConditions.visibilityOf(firstNameInput));
    }

    public void fillRegistrationForm(String firstName, String lastName, String email,
                                     String password, String confirmPassword) {
        firstNameInput.clear();
        firstNameInput.sendKeys(firstName);
        lastNameInput.clear();
        lastNameInput.sendKeys(lastName);
        emailInput.clear();
        emailInput.sendKeys(email);
        passwordInput.clear();
        passwordInput.sendKeys(password);
        confirmPasswordInput.clear();
        confirmPasswordInput.sendKeys(confirmPassword);
    }

    public void selectCountry(String country) {
        Select select = new Select(countryDropdown);
        select.selectByVisibleText(country);
    }

    public void acceptTerms() {
        if (!termsCheckbox.isSelected()) {
            termsCheckbox.click();
        }
    }

    public void uploadAvatar(String filePath) {
        avatarUpload.sendKeys(filePath);
    }

    // JavaScript scroll
    public void scrollToSubmitButton() {
        js.executeScript("arguments[0].scrollIntoView(true);", submitButton);
    }

    // JavaScript to set hidden field
    public void setHiddenFieldValue(String fieldId, String value) {
        js.executeScript(
            "document.getElementById('" + fieldId + "').value = '" + value + "';"
        );
    }

    // JavaScript to get computed style
    public String getPasswordStrengthColor() {
        return (String) js.executeScript(
            "return window.getComputedStyle(arguments[0]).backgroundColor;",
            passwordStrengthMeter
        );
    }

    public void submitForm() {
        scrollToSubmitButton();
        wait.until(ExpectedConditions.elementToBeClickable(submitButton));
        submitButton.click();
    }

    public boolean isSubmitButtonEnabled() {
        return submitButton.isEnabled();
    }

    public String getFieldError() {
        wait.until(ExpectedConditions.visibilityOf(fieldError));
        return fieldError.getText();
    }

    public String getSuccessMessage() {
        wait.until(ExpectedConditions.visibilityOf(successMessage));
        return successMessage.getText();
    }

    public boolean isSuccessMessageDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOf(successMessage));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getFieldAttribute(String fieldId, String attribute) {
        WebElement field = driver.findElement(By.id(fieldId));
        return field.getAttribute(attribute);
    }
}
