package com.example.tests;

import com.example.base.BaseTest;
import com.example.pages.RegistrationPage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

/**
 * Registration flow tests.
 * Uses:
 * - BaseTest inheritance
 * - File upload
 * - JavaScript interactions (via page object)
 * - Form validation
 */
public class RegistrationTest extends BaseTest {

    private RegistrationPage registrationPage;

    @Override
    @BeforeMethod
    public void setUp(String browser, String url) {
        super.setUp(browser, url);
        registrationPage = new RegistrationPage(driver);
        registrationPage.navigateTo(baseUrl + "/register");
    }

    @Test
    public void testSuccessfulRegistration() {
        registrationPage.fillRegistrationForm(
            "John", "Doe", "john.doe@example.com",
            "SecurePass123!", "SecurePass123!"
        );
        registrationPage.selectCountry("United States");
        registrationPage.acceptTerms();
        registrationPage.submitForm();

        Assert.assertTrue(registrationPage.isSuccessMessageDisplayed());
        String msg = registrationPage.getSuccessMessage();
        Assert.assertTrue(msg.contains("successfully registered"));
    }

    @Test
    public void testPasswordMismatch() {
        registrationPage.fillRegistrationForm(
            "Jane", "Doe", "jane@example.com",
            "Password1!", "DifferentPass2!"
        );
        registrationPage.acceptTerms();
        registrationPage.submitForm();

        String error = registrationPage.getFieldError();
        Assert.assertTrue(error.contains("passwords do not match"));
    }

    @Test
    public void testInvalidEmail() {
        registrationPage.fillRegistrationForm(
            "Test", "User", "not-an-email",
            "SecurePass123!", "SecurePass123!"
        );
        registrationPage.submitForm();

        String error = registrationPage.getFieldError();
        Assert.assertTrue(error.contains("valid email"));
    }

    @Test
    public void testTermsRequired() {
        registrationPage.fillRegistrationForm(
            "Test", "User", "test@example.com",
            "SecurePass123!", "SecurePass123!"
        );
        // Don't accept terms
        registrationPage.submitForm();

        Assert.assertFalse(registrationPage.isSuccessMessageDisplayed());
    }

    @Test
    public void testAvatarUpload() {
        registrationPage.uploadAvatar("C:\\test-files\\avatar.png");

        // Check that file was accepted
        String value = registrationPage.getFieldAttribute("avatar-upload", "value");
        Assert.assertTrue(value.contains("avatar.png"));
    }

    @Test
    public void testSubmitButtonDisabledWithoutTerms() {
        registrationPage.fillRegistrationForm(
            "Test", "User", "test@example.com",
            "SecurePass123!", "SecurePass123!"
        );
        // Don't accept terms - button should be disabled or form shouldn't submit
        Assert.assertTrue(registrationPage.isSubmitButtonEnabled());
    }

    @Test
    public void testNavigationAfterRegistration() {
        registrationPage.fillRegistrationForm(
            "Nav", "Test", "nav@example.com",
            "SecurePass123!", "SecurePass123!"
        );
        registrationPage.selectCountry("Canada");
        registrationPage.acceptTerms();
        registrationPage.submitForm();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("/welcome"));

        Assert.assertTrue(getCurrentUrl().contains("/welcome"));
    }
}
