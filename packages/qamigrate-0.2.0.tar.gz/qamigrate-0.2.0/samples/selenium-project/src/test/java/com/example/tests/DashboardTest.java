package com.example.tests;

import com.example.base.BaseTest;
import com.example.pages.DashboardPage;
import com.example.pages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

/**
 * Tests for the dashboard page.
 * Uses:
 * - Inheritance from BaseTest
 * - Multiple page objects (LoginPage + DashboardPage)
 * - DataProvider for parameterized tests
 * - Complex assertions
 */
public class DashboardTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;

    @Override
    @BeforeMethod
    public void setUp(String browser, String url) {
        super.setUp(browser, url);
        loginPage = new LoginPage(driver);
        dashboardPage = new DashboardPage(driver);

        // Login first
        loginPage.navigateTo(baseUrl + "/login");
        loginPage.login("admin@example.com", "SecurePass123!");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("/dashboard"));
    }

    @DataProvider(name = "searchQueries")
    public Object[][] searchQueries() {
        return new Object[][] {
            {"user report", 5},
            {"revenue", 3},
            {"empty query that returns nothing", 0},
        };
    }

    @Test(dataProvider = "searchQueries")
    public void testSearch(String query, int expectedMinResults) {
        dashboardPage.searchFor(query);

        // Wait for results to load
        Thread.sleep(1000); // TODO: replace with proper wait

        int rowCount = dashboardPage.getRowCount();
        Assert.assertTrue(rowCount >= expectedMinResults,
            "Expected at least " + expectedMinResults + " results for: " + query);
    }

    @Test
    public void testTimezoneSelection() {
        dashboardPage.selectTimezone("US/Pacific");
        Assert.assertEquals(dashboardPage.getSelectedTimezone(), "US/Pacific");
    }

    @Test
    public void testNotificationBadge() {
        Assert.assertTrue(dashboardPage.isNotificationBadgeVisible());
        int count = dashboardPage.getNotificationCount();
        Assert.assertTrue(count >= 0, "Notification count should be non-negative");
    }

    @Test
    public void testSidebarNavigation() {
        List<String> links = dashboardPage.getSidebarLinkTexts();
        Assert.assertTrue(links.size() > 0, "Sidebar should have navigation links");
        Assert.assertTrue(links.contains("Dashboard"));
        Assert.assertTrue(links.contains("Reports"));
    }

    @Test
    public void testExportWithAlert() {
        dashboardPage.clickExportAndAcceptAlert();
        // After accepting, check for success indication
        WebElement successBanner = driver.findElement(By.cssSelector(".alert-success"));
        Assert.assertTrue(successBanner.isDisplayed());
    }

    @Test
    public void testUserMenuLogout() {
        dashboardPage.clickLogout();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlContains("/login"));

        Assert.assertTrue(getCurrentUrl().contains("/login"));
    }

    @Test
    public void testTableDataPresent() {
        List<String> data = dashboardPage.getTableData();
        Assert.assertFalse(data.isEmpty(), "Dashboard table should contain data");
    }

    @Test
    public void testSidebarLinkNavigation() {
        dashboardPage.clickSidebarLink("Reports");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlContains("/reports"));

        Assert.assertTrue(getCurrentUrl().contains("/reports"));
    }
}
