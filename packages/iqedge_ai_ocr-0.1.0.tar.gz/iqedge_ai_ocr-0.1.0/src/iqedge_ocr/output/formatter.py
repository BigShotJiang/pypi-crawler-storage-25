"""Output format dispatcher — routes to the correct formatter."""
from __future__ import annotations

import json
import csv
import io
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import Document, RegionType, TableBlock, ImageBlock

if TYPE_CHECKING:
    pass

log = logging.getLogger("iqedge_ocr")


def format_output(doc: Document, fmt: str = "text", output_path: str | None = None) -> str:
    """Format a Document and optionally write to file.

    fmt: "text", "json", "csv", "pdf"
    Returns the formatted string (except for PDF which returns the file path).
    """
    formatters = {
        "text": format_text,
        "json": format_json,
        "csv": format_csv,
        "pdf": format_searchable_pdf,
    }

    if fmt not in formatters:
        raise ValueError(f"Unknown format: {fmt}. Use: {', '.join(formatters)}")

    result = formatters[fmt](doc)

    if output_path:
        mode = "wb" if fmt == "pdf" else "w"
        encoding = None if fmt == "pdf" else "utf-8"
        with open(output_path, mode, encoding=encoding) as f:
            if fmt == "pdf":
                f.write(result)
            else:
                f.write(result)
        log.info(f"Output written to {output_path}")

    return result


def format_text(doc: Document) -> str:
    """Plain text output preserving structure."""
    parts = []

    for page in doc.pages:
        if doc.page_count > 1:
            parts.append(f"--- Page {page.page_num} ---")

        for region in page.regions:
            if region.region_type == RegionType.TEXT:
                parts.append(region.content.text)
            elif region.region_type == RegionType.TABLE and isinstance(region.content, TableBlock):
                # Render table as aligned columns
                table = region.content
                if table.cells:
                    col_widths = [0] * table.cols
                    for row in table.cells:
                        for i, cell in enumerate(row):
                            col_widths[i] = max(col_widths[i], len(cell))

                    for row in table.cells:
                        line = " | ".join(
                            cell.ljust(col_widths[i]) for i, cell in enumerate(row)
                        )
                        parts.append(line)
                    parts.append("")
            elif region.region_type == RegionType.IMAGE:
                parts.append("[Image]")

        parts.append("")

    return "\n".join(parts).strip()


def format_json(doc: Document) -> str:
    """Structured JSON output with full detail."""
    return json.dumps(doc.to_dict(), indent=2, ensure_ascii=False)


def format_csv(doc: Document) -> str:
    """CSV output — text lines and table cells."""
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow(["page", "region_type", "confidence", "content"])

    for page in doc.pages:
        for region in page.regions:
            if region.region_type == RegionType.TEXT:
                for line in region.content.lines:
                    if line.text.strip():
                        writer.writerow([
                            page.page_num,
                            "text",
                            f"{line.confidence:.3f}",
                            line.text,
                        ])
            elif region.region_type == RegionType.TABLE and isinstance(region.content, TableBlock):
                for row_idx, row in enumerate(region.content.cells):
                    writer.writerow([
                        page.page_num,
                        f"table_row_{row_idx}",
                        f"{region.confidence:.3f}",
                        " | ".join(row),
                    ])

    return output.getvalue()


def format_searchable_pdf(doc: Document) -> bytes:
    """Create a searchable PDF with text overlay on original images.

    Requires: pip install fpdf2
    """
    try:
        from fpdf import FPDF
    except ImportError:
        raise ImportError(
            "fpdf2 is required for PDF output. Install: pip install fpdf2"
        )

    pdf = FPDF()
    pdf.set_auto_page_break(auto=False)

    for page in doc.pages:
        pdf.add_page()

        # Add text (invisible, for searchability)
        pdf.set_font("Helvetica", size=1)  # tiny invisible text
        pdf.set_text_color(255, 255, 255)  # white (invisible)

        for region in page.regions:
            if region.region_type == RegionType.TEXT:
                for line in region.content.lines:
                    if line.text.strip():
                        # Position text at approximate location
                        x = line.bbox[0] * 0.352778  # px to mm at 72 DPI
                        y = line.bbox[1] * 0.352778
                        pdf.set_xy(x, y)
                        try:
                            pdf.cell(text=line.text)
                        except Exception:
                            pass

    return pdf.output()
