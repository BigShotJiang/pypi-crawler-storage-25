"""Multi-pass OCR controller — escalates DPI for low-confidence regions.

Pass 1: 200 DPI — fast scan, extract everything possible
Pass 2: 300 DPI — re-OCR only low-confidence regions
Pass 3: 400 DPI — re-OCR remaining stubborn regions
Pass 4: Post-processing — learned corrections, patterns, dictionary

Only re-renders and re-OCRs the regions that need it, not the whole page.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import (
    Page, Region, RegionType, TextBlock, Word, PageType,
)
from iqedge_ocr.analysis.layout import analyze_layout

if TYPE_CHECKING:
    from iqedge_ocr.core.renderer import PDFRenderer
    from iqedge_ocr.core.ocr_engine import OCREngineBase
    from iqedge_ocr.correction.postprocessor import PostProcessor

log = logging.getLogger("iqedge_ocr")

# DPI for each pass
PASS_DPI = {1: 200, 2: 300, 3: 400, 4: 400}


def multipass_ocr(
    renderer: PDFRenderer,
    engine: OCREngineBase,
    page_num: int,
    lang: str = "eng",
    max_passes: int = 4,
    confidence_threshold: float = 0.80,
    postprocessor: PostProcessor | None = None,
    detect_tables: bool = True,
) -> Page:
    """Run multi-pass OCR on a single page.

    Returns a fully populated Page with regions, confidence scores,
    and correction history.
    """
    # === Pass 1: Fast scan at 200 DPI ===
    dpi = PASS_DPI[1]
    log.info(f"  Page {page_num} — Pass 1 @ {dpi} DPI")

    image = renderer.render_page(page_num, dpi=dpi)
    regions = analyze_layout(image, engine, lang=lang, detect_tables=detect_tables)

    page = Page(
        page_num=page_num,
        width=image.width,
        height=image.height,
        page_type=PageType.SCANNED,
        regions=regions,
        dpi_used=dpi,
    )

    # Tag all regions with pass info
    for region in page.regions:
        region.pass_number = 1
        region.dpi_used = dpi

    if max_passes < 2:
        return page

    # === Pass 2 & 3: Re-OCR low-confidence regions at higher DPI ===
    for pass_num in range(2, min(max_passes, 4) + 1):
        target_dpi = PASS_DPI[pass_num]
        low_regions = _find_low_confidence_regions(page, confidence_threshold)

        if not low_regions:
            log.info(f"  Page {page_num} — Pass {pass_num}: all regions above threshold, skipping")
            break

        log.info(
            f"  Page {page_num} — Pass {pass_num} @ {target_dpi} DPI: "
            f"re-OCRing {len(low_regions)} low-confidence regions"
        )

        for region_idx, region in low_regions:
            if region.region_type != RegionType.TEXT:
                continue
            if not isinstance(region.content, TextBlock):
                continue

            # Get low-confidence word clusters within this region
            low_bboxes = region.content.low_confidence_regions(confidence_threshold)

            if not low_bboxes:
                continue

            for bbox in low_bboxes:
                # Re-render this region at higher DPI
                region_img = renderer.render_region(
                    page_num, bbox, dpi=target_dpi, source_dpi=PASS_DPI[1],
                )

                # Re-OCR
                new_words = engine.ocr_image(region_img, lang=lang, psm=6)

                # Offset new words to original coordinates
                scale = PASS_DPI[1] / target_dpi
                for w in new_words:
                    wx, wy, ww, wh = w.bbox
                    w.bbox = (
                        int(wx * scale) + bbox[0],
                        int(wy * scale) + bbox[1],
                        int(ww * scale),
                        int(wh * scale),
                    )

                # Merge: replace words only if new confidence is higher
                _merge_words(region.content, new_words, bbox, confidence_threshold)

            region.pass_number = pass_num
            region.dpi_used = target_dpi

    # Free intermediate DPI caches
    renderer.clear_cache(keep_dpi=PASS_DPI[1])

    # === Pass 4: Post-processing corrections ===
    if max_passes >= 4 and postprocessor:
        log.info(f"  Page {page_num} — Pass 4: post-processing corrections")
        for region in page.regions:
            if region.region_type == RegionType.TEXT and isinstance(region.content, TextBlock):
                postprocessor.correct_textblock(region.content)
                region.pass_number = 4

    page.dpi_used = max(r.dpi_used for r in page.regions) if page.regions else dpi
    return page


def _find_low_confidence_regions(
    page: Page, threshold: float
) -> list[tuple[int, Region]]:
    """Find regions with confidence below threshold."""
    result = []
    for i, region in enumerate(page.regions):
        if region.confidence < threshold:
            result.append((i, region))
    return result


def _merge_words(
    text_block: TextBlock,
    new_words: list[Word],
    source_bbox: tuple[int, int, int, int],
    threshold: float,
) -> None:
    """Merge new higher-confidence words into existing text block.

    Only replaces words that:
    1. Fall within the source_bbox area
    2. Have higher confidence in the new OCR result
    """
    sx, sy, sw, sh = source_bbox

    for line in text_block.lines:
        for i, existing_word in enumerate(line.words):
            # Check if this word is in the re-OCR'd region
            wx, wy, ww, wh = existing_word.bbox
            word_cx = wx + ww // 2
            word_cy = wy + wh // 2

            if not (sx <= word_cx <= sx + sw and sy <= word_cy <= sy + sh):
                continue

            if existing_word.confidence >= threshold:
                continue  # already good enough

            # Find the best matching new word by position
            best_match = _find_closest_word(existing_word, new_words)
            if best_match and best_match.confidence > existing_word.confidence:
                existing_word.correct(best_match.text, best_match.confidence)


def _find_closest_word(target: Word, candidates: list[Word]) -> Word | None:
    """Find the candidate word closest to the target position."""
    if not candidates:
        return None

    tx, ty = target.bbox[0] + target.bbox[2] // 2, target.bbox[1] + target.bbox[3] // 2

    best = None
    best_dist = float("inf")

    for w in candidates:
        cx, cy = w.bbox[0] + w.bbox[2] // 2, w.bbox[1] + w.bbox[3] // 2
        dist = ((tx - cx) ** 2 + (ty - cy) ** 2) ** 0.5
        if dist < best_dist:
            best_dist = dist
            best = w

    # Only match if reasonably close (within 50 pixels at 200 DPI)
    return best if best_dist < 50 else None
