"""Pass 4 — Post-processing corrections using learned patterns.

Applies:
1. Character confusion corrections (l→1, O→0, rn→m)
2. Dictionary-based word correction
3. Pattern enforcement (dates, numbers, IDs)
4. Language-specific fixes
"""
from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import TextBlock, Word

if TYPE_CHECKING:
    from iqedge_ocr.training.store import TrainingStore

log = logging.getLogger("iqedge_ocr")

# Common Tesseract OCR confusions (character level)
DEFAULT_CHAR_FIXES = {
    "rn": "m",
    "vv": "w",
    "cl": "d",
    "cI": "d",
    "|": "l",
    "0": "O",  # context-dependent, only in word context
    "1": "l",  # context-dependent
}

# Common word-level fixes
DEFAULT_WORD_FIXES = {
    "tbe": "the",
    "tlie": "the",
    "tne": "the",
    "ot": "of",
    "fo": "of",
    "arid": "and",
    "ihe": "the",
    "Narne": "Name",
    "Namo": "Name",
    "Falher": "Father",
    "Falners": "Fathers",
    "Famale": "Female",
    "Husoand": "Husband",
    "Kolher": "Mother",
}


class PostProcessor:
    """Applies learned corrections to OCR output."""

    def __init__(
        self,
        training_store: TrainingStore | None = None,
        char_fixes: dict[str, str] | None = None,
        word_fixes: dict[str, str] | None = None,
        min_confidence_to_skip: float = 0.95,
    ):
        self.char_fixes = {**DEFAULT_CHAR_FIXES, **(char_fixes or {})}
        self.word_fixes = {**DEFAULT_WORD_FIXES, **(word_fixes or {})}
        self.min_confidence_to_skip = min_confidence_to_skip
        self.store = training_store

        # Load learned corrections from training store
        if self.store:
            learned_word = self.store.get_word_corrections()
            self.word_fixes.update(learned_word)
            learned_char = self.store.get_char_confusions()
            self.char_fixes.update(learned_char)

    def correct_textblock(self, block: TextBlock) -> int:
        """Apply corrections to all words in a text block.

        Returns number of corrections made.
        """
        corrections = 0
        for line in block.lines:
            for word in line.words:
                if word.confidence >= self.min_confidence_to_skip:
                    continue
                if self._correct_word(word):
                    corrections += 1
        return corrections

    def _correct_word(self, word: Word) -> bool:
        """Try to correct a single word. Returns True if corrected."""
        original = word.text

        # 1. Exact word-level fix
        if original in self.word_fixes:
            word.correct(self.word_fixes[original], min(word.confidence + 0.1, 0.95))
            return True

        # 2. Case-insensitive word fix
        lower = original.lower()
        for wrong, right in self.word_fixes.items():
            if lower == wrong.lower():
                # Preserve original casing pattern
                corrected = _match_case(right, original)
                word.correct(corrected, min(word.confidence + 0.1, 0.95))
                return True

        # 3. Character-level substitutions
        corrected = original
        for wrong, right in self.char_fixes.items():
            if wrong in corrected:
                corrected = corrected.replace(wrong, right)

        if corrected != original:
            word.correct(corrected, min(word.confidence + 0.05, 0.90))
            return True

        # 4. Pattern enforcement
        corrected = self._enforce_patterns(word.text)
        if corrected != original:
            word.correct(corrected, min(word.confidence + 0.15, 0.95))
            return True

        return False

    def _enforce_patterns(self, text: str) -> str:
        """Enforce known patterns (dates, numbers, IDs)."""
        # Date patterns: DD-MM-YYYY with common OCR errors
        m = re.match(r"^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$", text)
        if m:
            return f"{m.group(1):>02}-{m.group(2):>02}-{m.group(3)}"

        # Indian phone numbers (10 digits)
        digits_only = re.sub(r"\D", "", text)
        if len(digits_only) == 10 and digits_only[0] in "6789":
            return digits_only

        # Indian PIN codes (6 digits, starts with 1-9)
        if len(digits_only) == 6 and digits_only[0] != "0":
            return digits_only

        return text


def _match_case(replacement: str, original: str) -> str:
    """Match the casing pattern of the original to the replacement."""
    if original.isupper():
        return replacement.upper()
    if original.islower():
        return replacement.lower()
    if original and original[0].isupper():
        return replacement[0].upper() + replacement[1:] if replacement else replacement
    return replacement
