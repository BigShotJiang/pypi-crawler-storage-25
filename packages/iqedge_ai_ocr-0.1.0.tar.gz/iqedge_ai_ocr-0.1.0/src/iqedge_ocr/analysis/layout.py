"""Layout analysis — detect text blocks, images, and tables in a page image.

Uses morphological operations (with OpenCV if available) or
Tesseract bounding box analysis as fallback.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import (
    Region, RegionType, TextBlock, ImageBlock, TableBlock,
    Line, Word,
)

if TYPE_CHECKING:
    from PIL import Image
    from iqedge_ocr.core.ocr_engine import OCREngineBase

log = logging.getLogger("iqedge_ocr")


def analyze_layout(
    image: Image.Image,
    engine: OCREngineBase,
    lang: str = "eng",
    detect_tables: bool = True,
) -> list[Region]:
    """Analyze a page image and return typed regions.

    Returns regions sorted top-to-bottom, left-to-right.
    """
    # Try OpenCV-based analysis first (more accurate)
    try:
        return _analyze_with_opencv(image, engine, lang, detect_tables)
    except ImportError:
        pass

    # Fallback: Tesseract-based analysis
    return _analyze_with_tesseract(image, engine, lang, detect_tables)


def _analyze_with_opencv(
    image: Image.Image,
    engine: OCREngineBase,
    lang: str,
    detect_tables: bool,
) -> list[Region]:
    """Layout analysis using OpenCV morphological operations."""
    import cv2
    import numpy as np

    img_array = np.array(image.convert("L"))  # grayscale
    h, w = img_array.shape

    # Adaptive threshold
    binary = cv2.adaptiveThreshold(
        img_array, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 15, 10,
    )

    regions = []

    # Table detection via line intersection
    if detect_tables:
        table_regions = _detect_tables_opencv(binary, w, h)
        for bbox in table_regions:
            table = _ocr_table_region(image, bbox, engine, lang)
            if table:
                regions.append(Region(
                    region_type=RegionType.TABLE,
                    bbox=bbox,
                    content=table,
                ))

    # Find text blocks via connected components
    # Dilate to merge nearby characters into blocks
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 5))
    dilated = cv2.dilate(binary, kernel, iterations=2)

    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    text_bboxes = []
    image_bboxes = []

    for cnt in contours:
        x, y, bw, bh = cv2.boundingRect(cnt)

        # Skip tiny noise
        if bw < 20 or bh < 10:
            continue

        # Skip regions already covered by tables
        if any(_bbox_overlap_ratio((x, y, bw, bh), tr) > 0.5 for tr in
               [r.bbox for r in regions if r.region_type == RegionType.TABLE]):
            continue

        bbox = (x, y, bw, bh)
        area = bw * bh

        # Heuristic: text blocks have many small components, images are solid
        roi = binary[y:y+bh, x:x+bw]
        white_ratio = np.sum(roi > 0) / area if area > 0 else 0

        if white_ratio > 0.01 and white_ratio < 0.6:
            # Likely text (10-60% ink coverage)
            text_bboxes.append(bbox)
        elif white_ratio >= 0.6 or (bw > w * 0.3 and bh > h * 0.3):
            # Dense region or large area → likely an image
            image_bboxes.append(bbox)
        else:
            text_bboxes.append(bbox)  # default to text

    # OCR text regions
    for bbox in sorted(text_bboxes, key=lambda b: (b[1], b[0])):
        words = engine.ocr_region(image, bbox, lang=lang, psm=6)
        if words:
            text_block = _words_to_textblock(words, bbox)
            regions.append(Region(
                region_type=RegionType.TEXT,
                bbox=bbox,
                content=text_block,
            ))

    # Extract image regions
    for bbox in image_bboxes:
        x, y, bw, bh = bbox
        cropped = image.crop((x, y, x + bw, y + bh))
        import io
        buf = io.BytesIO()
        cropped.save(buf, format="PNG")
        regions.append(Region(
            region_type=RegionType.IMAGE,
            bbox=bbox,
            content=ImageBlock(
                image_data=buf.getvalue(),
                width=bw, height=bh,
                format="png",
            ),
        ))

    # Sort regions top-to-bottom, left-to-right
    regions.sort(key=lambda r: (r.bbox[1], r.bbox[0]))
    return regions


def _detect_tables_opencv(binary, w: int, h: int) -> list[tuple[int, int, int, int]]:
    """Detect tables by finding horizontal and vertical line intersections."""
    import cv2
    import numpy as np

    # Detect horizontal lines
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (w // 8, 1))
    h_lines = cv2.morphologyEx(binary, cv2.MORPH_OPEN, h_kernel)

    # Detect vertical lines
    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, h // 8))
    v_lines = cv2.morphologyEx(binary, cv2.MORPH_OPEN, v_kernel)

    # Combine
    table_mask = cv2.add(h_lines, v_lines)

    # Find contours of table regions
    contours, _ = cv2.findContours(table_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    tables = []
    for cnt in contours:
        x, y, bw, bh = cv2.boundingRect(cnt)
        # Tables should be reasonably large
        if bw > w * 0.2 and bh > h * 0.05:
            tables.append((x, y, bw, bh))

    return tables


def _analyze_with_tesseract(
    image: Image.Image,
    engine: OCREngineBase,
    lang: str,
    detect_tables: bool,
) -> list[Region]:
    """Fallback layout analysis using only Tesseract bounding boxes."""
    # OCR the full page
    words = engine.ocr_image(image, lang=lang, psm=3)

    if not words:
        return []

    # Group words into blocks using Tesseract's block_num
    blocks: dict[int, list[Word]] = {}
    for word in words:
        blocks.setdefault(word.block_num, []).append(word)

    regions = []
    for block_num, block_words in sorted(blocks.items()):
        if not block_words:
            continue

        # Calculate block bounding box
        x1 = min(w.bbox[0] for w in block_words)
        y1 = min(w.bbox[1] for w in block_words)
        x2 = max(w.bbox[0] + w.bbox[2] for w in block_words)
        y2 = max(w.bbox[1] + w.bbox[3] for w in block_words)
        bbox = (x1, y1, x2 - x1, y2 - y1)

        text_block = _words_to_textblock(block_words, bbox)
        regions.append(Region(
            region_type=RegionType.TEXT,
            bbox=bbox,
            content=text_block,
        ))

    regions.sort(key=lambda r: (r.bbox[1], r.bbox[0]))
    return regions


def _words_to_textblock(words: list[Word], bbox: tuple[int, int, int, int]) -> TextBlock:
    """Convert a list of words into a structured TextBlock with lines."""
    # Group words by line number
    lines_dict: dict[tuple[int, int, int], list[Word]] = {}
    for w in words:
        key = (w.block_num, w.par_num, w.line_num)
        lines_dict.setdefault(key, []).append(w)

    lines = []
    for key in sorted(lines_dict.keys()):
        line_words = sorted(lines_dict[key], key=lambda w: w.bbox[0])
        if line_words:
            lx = min(w.bbox[0] for w in line_words)
            ly = min(w.bbox[1] for w in line_words)
            lx2 = max(w.bbox[0] + w.bbox[2] for w in line_words)
            ly2 = max(w.bbox[1] + w.bbox[3] for w in line_words)
            lines.append(Line(words=line_words, bbox=(lx, ly, lx2 - lx, ly2 - ly)))

    return TextBlock(lines=lines, bbox=bbox)


def _ocr_table_region(
    image: Image.Image,
    bbox: tuple[int, int, int, int],
    engine: OCREngineBase,
    lang: str,
) -> TableBlock | None:
    """OCR a detected table region into a TableBlock."""
    x, y, w, h = bbox
    table_img = image.crop((x, y, x + w, y + h))

    # Simple approach: OCR the whole table region
    words = engine.ocr_image(table_img, lang=lang, psm=6)
    if not words:
        return None

    # Try to detect grid structure from word positions
    # Group by rows (y-coordinate clusters)
    rows = _cluster_by_y(words, tolerance=10)
    if not rows:
        return None

    # Detect columns from x-coordinate clusters across all rows
    col_boundaries = _detect_columns(words, w)

    cells = []
    cell_confidences = []
    for row_words in rows:
        row_cells = [""] * len(col_boundaries)
        row_confs = [0.0] * len(col_boundaries)

        for word in row_words:
            col_idx = _word_to_column(word, col_boundaries)
            if row_cells[col_idx]:
                row_cells[col_idx] += " "
            row_cells[col_idx] += word.text
            # Average confidence for this cell
            if row_confs[col_idx] == 0:
                row_confs[col_idx] = word.confidence
            else:
                row_confs[col_idx] = (row_confs[col_idx] + word.confidence) / 2

        cells.append(row_cells)
        cell_confidences.append(row_confs)

    return TableBlock(
        rows=len(cells),
        cols=len(col_boundaries),
        cells=cells,
        cell_confidences=cell_confidences,
        bbox=bbox,
    )


def _cluster_by_y(words: list[Word], tolerance: int = 10) -> list[list[Word]]:
    """Cluster words into rows by y-coordinate."""
    if not words:
        return []

    sorted_words = sorted(words, key=lambda w: w.bbox[1])
    rows = [[sorted_words[0]]]

    for word in sorted_words[1:]:
        last_row_y = sum(w.bbox[1] for w in rows[-1]) / len(rows[-1])
        if abs(word.bbox[1] - last_row_y) <= tolerance:
            rows[-1].append(word)
        else:
            rows.append([word])

    return rows


def _detect_columns(words: list[Word], total_width: int) -> list[tuple[int, int]]:
    """Detect column boundaries from word x-positions.

    Returns list of (start_x, end_x) for each column.
    """
    if not words:
        return [(0, total_width)]

    # Find gaps in x-coordinates
    x_positions = sorted(set(w.bbox[0] for w in words))

    if len(x_positions) < 2:
        return [(0, total_width)]

    # Find significant gaps (> median word width)
    median_width = sorted(w.bbox[2] for w in words)[len(words) // 2]
    gap_threshold = max(median_width * 2, 30)

    boundaries = [0]
    for i in range(1, len(x_positions)):
        if x_positions[i] - x_positions[i - 1] > gap_threshold:
            mid = (x_positions[i - 1] + x_positions[i]) // 2
            boundaries.append(mid)
    boundaries.append(total_width)

    return [(boundaries[i], boundaries[i + 1]) for i in range(len(boundaries) - 1)]


def _word_to_column(word: Word, col_boundaries: list[tuple[int, int]]) -> int:
    """Determine which column a word belongs to."""
    cx = word.bbox[0] + word.bbox[2] // 2
    for i, (start, end) in enumerate(col_boundaries):
        if start <= cx < end:
            return i
    return len(col_boundaries) - 1


def _bbox_overlap_ratio(a: tuple, b: tuple) -> float:
    """Calculate overlap ratio between two bboxes."""
    ax1, ay1, aw, ah = a
    bx1, by1, bw, bh = b

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax1 + aw, bx1 + bw)
    iy2 = min(ay1 + ah, by1 + bh)

    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0

    intersection = (ix2 - ix1) * (iy2 - iy1)
    area_a = aw * ah
    return intersection / area_a if area_a > 0 else 0.0
