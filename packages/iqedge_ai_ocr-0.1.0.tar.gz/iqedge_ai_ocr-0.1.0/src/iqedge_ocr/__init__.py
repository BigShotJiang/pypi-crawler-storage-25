"""IQEdge.ai OCR — PDF to Text converter with multi-pass self-correction.

Extract text from scanned PDFs, images, and books.
63 languages including Hindi, Telugu, Tamil, Arabic, Chinese, Japanese.
Preserves document structure: text as text, images as images, tables as tables.

Usage:
    from iqedge_ocr import OCRAgent
    doc = OCRAgent().process("input.pdf")
    print(doc.text())
"""

__version__ = "0.1.0"
__author__ = "IQEdge"

from iqedge_ocr.core.pipeline import OCRAgent

__all__ = ["OCRAgent", "__version__"]
