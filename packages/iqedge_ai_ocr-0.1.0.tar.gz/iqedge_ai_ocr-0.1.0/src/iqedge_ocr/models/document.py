"""Core data models for IQEdge.ai OCR.

All OCR results flow through these structures. The pipeline builds Documents
containing Pages, each with typed Regions (text, image, table).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class RegionType(str, Enum):
    TEXT = "text"
    IMAGE = "image"
    TABLE = "table"


class PageType(str, Enum):
    TEXT_NATIVE = "text_native"  # has extractable text (digitally created)
    SCANNED = "scanned"         # image-based, needs OCR
    MIXED = "mixed"             # some text + some images


@dataclass
class Word:
    """A single word with position and confidence."""
    text: str
    confidence: float          # 0.0 - 1.0
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)  # x, y, w, h
    block_num: int = 0
    par_num: int = 0
    line_num: int = 0
    word_num: int = 0
    corrections: list[str] = field(default_factory=list)  # history across passes

    @property
    def is_low_confidence(self) -> bool:
        return self.confidence < 0.80

    def correct(self, new_text: str, new_confidence: float) -> None:
        """Apply a correction, preserving history."""
        if new_text != self.text:
            self.corrections.append(self.text)
            self.text = new_text
        if new_confidence > self.confidence:
            self.confidence = new_confidence


@dataclass
class Line:
    """A line of text composed of words."""
    words: list[Word] = field(default_factory=list)
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)

    @property
    def text(self) -> str:
        return " ".join(w.text for w in self.words if w.text.strip())

    @property
    def confidence(self) -> float:
        confs = [w.confidence for w in self.words if w.text.strip()]
        return sum(confs) / len(confs) if confs else 0.0


@dataclass
class TextBlock:
    """A block of text containing multiple lines."""
    lines: list[Line] = field(default_factory=list)
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)
    language: str = ""

    @property
    def text(self) -> str:
        return "\n".join(line.text for line in self.lines if line.text.strip())

    @property
    def words(self) -> list[Word]:
        return [w for line in self.lines for w in line.words]

    @property
    def confidence(self) -> float:
        confs = [w.confidence for w in self.words if w.text.strip()]
        return sum(confs) / len(confs) if confs else 0.0

    def low_confidence_regions(self, threshold: float = 0.80) -> list[tuple[int, int, int, int]]:
        """Return bounding boxes of contiguous low-confidence word clusters."""
        low_words = [w for w in self.words if w.confidence < threshold and w.text.strip()]
        if not low_words:
            return []
        return _cluster_bboxes([w.bbox for w in low_words])


@dataclass
class TableBlock:
    """A detected table with rows, columns, and cell contents."""
    rows: int = 0
    cols: int = 0
    cells: list[list[str]] = field(default_factory=list)
    cell_confidences: list[list[float]] = field(default_factory=list)
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)

    @property
    def confidence(self) -> float:
        all_confs = [c for row in self.cell_confidences for c in row if c > 0]
        return sum(all_confs) / len(all_confs) if all_confs else 0.0

    def to_csv_rows(self) -> list[list[str]]:
        return self.cells

    def low_confidence_cells(self, threshold: float = 0.80) -> list[tuple[int, int]]:
        """Return (row, col) indices of low-confidence cells."""
        result = []
        for r, row in enumerate(self.cell_confidences):
            for c, conf in enumerate(row):
                if conf < threshold:
                    result.append((r, c))
        return result


@dataclass
class ImageBlock:
    """An embedded image region (preserved, not OCR'd)."""
    image_data: bytes = b""    # PNG bytes
    format: str = "png"
    bbox: tuple[int, int, int, int] = (0, 0, 0, 0)
    alt_text: str = ""
    width: int = 0
    height: int = 0

    @property
    def confidence(self) -> float:
        return 1.0  # images are always "confident"


@dataclass
class Region:
    """A region on a page — either text, image, or table."""
    region_type: RegionType
    bbox: tuple[int, int, int, int]  # x, y, w, h
    content: TextBlock | TableBlock | ImageBlock | None = None
    pass_number: int = 1    # which pass produced this result
    dpi_used: int = 200

    @property
    def confidence(self) -> float:
        if self.content:
            return self.content.confidence
        return 0.0


@dataclass
class Page:
    """A single page in a document."""
    page_num: int
    width: int = 0
    height: int = 0
    page_type: PageType = PageType.SCANNED
    regions: list[Region] = field(default_factory=list)
    dpi_used: int = 200

    @property
    def text(self) -> str:
        """Extract all text from this page, preserving region order."""
        parts = []
        for region in self.regions:
            if region.region_type == RegionType.TEXT and isinstance(region.content, TextBlock):
                parts.append(region.content.text)
            elif region.region_type == RegionType.TABLE and isinstance(region.content, TableBlock):
                for row in region.content.cells:
                    parts.append("\t".join(row))
        return "\n\n".join(parts)

    @property
    def confidence(self) -> float:
        confs = [r.confidence for r in self.regions if r.confidence > 0]
        return sum(confs) / len(confs) if confs else 0.0

    @property
    def images(self) -> list[ImageBlock]:
        return [
            r.content for r in self.regions
            if r.region_type == RegionType.IMAGE and isinstance(r.content, ImageBlock)
        ]

    @property
    def tables(self) -> list[TableBlock]:
        return [
            r.content for r in self.regions
            if r.region_type == RegionType.TABLE and isinstance(r.content, TableBlock)
        ]

    def low_confidence_regions(self, threshold: float = 0.80) -> list[Region]:
        return [r for r in self.regions if r.confidence < threshold]


@dataclass
class Document:
    """The top-level OCR result for an entire PDF."""
    source_path: str = ""
    pages: list[Page] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    languages: list[str] = field(default_factory=lambda: ["eng"])
    total_passes: int = 1

    @property
    def text(self) -> str:
        """Full document text."""
        return "\n\n".join(page.text for page in self.pages if page.text.strip())

    @property
    def page_count(self) -> int:
        return len(self.pages)

    @property
    def confidence(self) -> float:
        confs = [p.confidence for p in self.pages if p.confidence > 0]
        return sum(confs) / len(confs) if confs else 0.0

    @property
    def word_count(self) -> int:
        count = 0
        for page in self.pages:
            for region in page.regions:
                if isinstance(region.content, TextBlock):
                    count += len(region.content.words)
        return count

    def to_dict(self) -> dict:
        """Serialize to dictionary for JSON output."""
        return {
            "source": self.source_path,
            "page_count": self.page_count,
            "languages": self.languages,
            "confidence": round(self.confidence, 3),
            "total_passes": self.total_passes,
            "word_count": self.word_count,
            "metadata": self.metadata,
            "pages": [_page_to_dict(p) for p in self.pages],
        }


# -- Helpers --

def _page_to_dict(page: Page) -> dict:
    return {
        "page_num": page.page_num,
        "width": page.width,
        "height": page.height,
        "page_type": page.page_type.value,
        "confidence": round(page.confidence, 3),
        "dpi_used": page.dpi_used,
        "regions": [_region_to_dict(r) for r in page.regions],
    }


def _region_to_dict(region: Region) -> dict:
    d = {
        "type": region.region_type.value,
        "bbox": list(region.bbox),
        "confidence": round(region.confidence, 3),
        "pass_number": region.pass_number,
        "dpi_used": region.dpi_used,
    }
    if region.region_type == RegionType.TEXT and isinstance(region.content, TextBlock):
        d["text"] = region.content.text
        d["lines"] = [
            {
                "text": line.text,
                "confidence": round(line.confidence, 3),
                "words": [
                    {"text": w.text, "confidence": round(w.confidence, 3), "bbox": list(w.bbox)}
                    for w in line.words if w.text.strip()
                ],
            }
            for line in region.content.lines if line.text.strip()
        ]
    elif region.region_type == RegionType.TABLE and isinstance(region.content, TableBlock):
        d["rows"] = region.content.rows
        d["cols"] = region.content.cols
        d["cells"] = region.content.cells
    elif region.region_type == RegionType.IMAGE and isinstance(region.content, ImageBlock):
        d["width"] = region.content.width
        d["height"] = region.content.height
        d["format"] = region.content.format
        d["alt_text"] = region.content.alt_text
    return d


def _cluster_bboxes(
    bboxes: list[tuple[int, int, int, int]], margin: int = 20
) -> list[tuple[int, int, int, int]]:
    """Cluster nearby bounding boxes into larger regions for re-OCR.

    Groups boxes that are within `margin` pixels of each other into
    merged bounding boxes. This avoids many tiny Tesseract calls.
    """
    if not bboxes:
        return []

    # Sort by vertical position, then horizontal
    sorted_boxes = sorted(bboxes, key=lambda b: (b[1], b[0]))

    clusters: list[list[tuple[int, int, int, int]]] = [[sorted_boxes[0]]]

    for box in sorted_boxes[1:]:
        merged = False
        for cluster in clusters:
            # Check if this box is close to any box in the cluster
            for cb in cluster:
                if _boxes_overlap(box, cb, margin):
                    cluster.append(box)
                    merged = True
                    break
            if merged:
                break
        if not merged:
            clusters.append([box])

    # Merge each cluster into one bounding box
    result = []
    for cluster in clusters:
        x1 = min(b[0] for b in cluster) - margin
        y1 = min(b[1] for b in cluster) - margin
        x2 = max(b[0] + b[2] for b in cluster) + margin
        y2 = max(b[1] + b[3] for b in cluster) + margin
        result.append((max(0, x1), max(0, y1), x2 - x1, y2 - y1))

    return result


def _boxes_overlap(
    a: tuple[int, int, int, int],
    b: tuple[int, int, int, int],
    margin: int,
) -> bool:
    """Check if two boxes are within margin pixels of each other."""
    ax1, ay1, aw, ah = a
    bx1, by1, bw, bh = b
    return not (
        ax1 + aw + margin < bx1
        or bx1 + bw + margin < ax1
        or ay1 + ah + margin < by1
        or by1 + bh + margin < ay1
    )
