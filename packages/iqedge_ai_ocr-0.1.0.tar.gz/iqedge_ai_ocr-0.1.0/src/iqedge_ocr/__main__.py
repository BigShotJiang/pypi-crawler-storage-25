"""Allow running as: python -m iqedge_ocr"""
from iqedge_ocr.cli import main

if __name__ == "__main__":
    main()
