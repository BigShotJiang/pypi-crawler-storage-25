"""PDF to image rendering with region-level re-rendering support."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from PIL import Image
from pdf2image import convert_from_path
from pdf2image.pdf2image import pdfinfo_from_path

if TYPE_CHECKING:
    pass

log = logging.getLogger("iqedge_ocr")


class PDFRenderer:
    """Renders PDF pages to images at configurable DPI.

    Supports:
    - Full page rendering at any DPI
    - Region-level re-rendering (crop coordinates → higher DPI render of just that area)
    - Page count detection
    - Caching to avoid re-rendering the same page/DPI combination
    """

    def __init__(self, pdf_path: str, poppler_path: str | None = None):
        self.pdf_path = str(pdf_path)
        self.poppler_path = poppler_path
        self._page_count: int | None = None
        self._cache: dict[tuple[int, int], Image.Image] = {}  # (page, dpi) -> Image

    @property
    def page_count(self) -> int:
        if self._page_count is None:
            try:
                info = pdfinfo_from_path(
                    self.pdf_path, poppler_path=self.poppler_path
                )
                self._page_count = info["Pages"]
            except Exception:
                # Fallback: render page 1 and count
                log.warning(f"Could not get page count for {self.pdf_path}, using fallback")
                self._page_count = self._count_pages_fallback()
        return self._page_count

    def render_page(self, page_num: int, dpi: int = 200) -> Image.Image:
        """Render a full page as a PIL Image."""
        cache_key = (page_num, dpi)
        if cache_key in self._cache:
            return self._cache[cache_key]

        kwargs = {"first_page": page_num, "last_page": page_num, "dpi": dpi}
        if self.poppler_path:
            kwargs["poppler_path"] = self.poppler_path

        images = convert_from_path(self.pdf_path, **kwargs)
        if not images:
            raise RuntimeError(f"Failed to render page {page_num} at {dpi} DPI")

        img = images[0]
        self._cache[cache_key] = img
        return img

    def render_region(
        self,
        page_num: int,
        bbox: tuple[int, int, int, int],
        dpi: int,
        source_dpi: int = 200,
    ) -> Image.Image:
        """Render a specific region at higher DPI.

        bbox is in coordinates of source_dpi. The region is re-rendered
        at the target dpi by rendering the full page and cropping.
        For efficiency, we scale the bbox coordinates to the target DPI.
        """
        # Render full page at target DPI
        img = self.render_page(page_num, dpi)

        # Scale bbox from source_dpi coordinates to target_dpi coordinates
        scale = dpi / source_dpi
        x, y, w, h = bbox
        crop_box = (
            int(x * scale),
            int(y * scale),
            int((x + w) * scale),
            int((y + h) * scale),
        )

        # Clamp to image bounds
        crop_box = (
            max(0, crop_box[0]),
            max(0, crop_box[1]),
            min(img.width, crop_box[2]),
            min(img.height, crop_box[3]),
        )

        return img.crop(crop_box)

    def clear_cache(self, keep_dpi: int | None = None) -> None:
        """Clear the image cache. Optionally keep images at a specific DPI."""
        if keep_dpi is None:
            self._cache.clear()
        else:
            self._cache = {
                k: v for k, v in self._cache.items() if k[1] == keep_dpi
            }

    def _count_pages_fallback(self) -> int:
        """Count pages by trying to render progressively."""
        # Try a reasonable upper bound
        for n in [100, 50, 20, 10, 5, 1]:
            try:
                kwargs = {"first_page": n, "last_page": n, "dpi": 72}
                if self.poppler_path:
                    kwargs["poppler_path"] = self.poppler_path
                convert_from_path(self.pdf_path, **kwargs)
                return n  # at least n pages
            except Exception:
                continue
        return 1
