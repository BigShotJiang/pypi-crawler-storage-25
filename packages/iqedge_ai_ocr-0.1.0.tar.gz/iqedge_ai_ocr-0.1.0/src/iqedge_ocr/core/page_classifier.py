"""Classify PDF pages as text-native, scanned (image), or mixed.

Text-native pages have extractable text (digitally created) — no OCR needed.
Scanned pages are images — full OCR required.
Mixed pages have some text + some images.
"""
from __future__ import annotations

import logging
from pathlib import Path

from iqedge_ocr.models.document import PageType

log = logging.getLogger("iqedge_ocr")


def classify_page(pdf_path: str, page_num: int) -> PageType:
    """Determine if a page is text-native, scanned, or mixed.

    Strategy:
    1. Extract text with pdfminer. If substantial text exists → text_native or mixed
    2. Check for images. If images exist + text → mixed. Only images → scanned.
    3. No text and no images → scanned (blank or very light scan)
    """
    text = extract_native_text(pdf_path, page_num)
    has_text = len(text.strip()) > 20  # more than a few characters

    has_images = page_has_images(pdf_path, page_num)

    if has_text and not has_images:
        return PageType.TEXT_NATIVE
    elif has_text and has_images:
        return PageType.MIXED
    else:
        return PageType.SCANNED


def extract_native_text(pdf_path: str, page_num: int) -> str:
    """Extract text from a PDF page using pdfminer (no OCR).

    Returns empty string if page is image-based.
    """
    try:
        from pdfminer.high_level import extract_text
        from pdfminer.layout import LAParams

        text = extract_text(
            pdf_path,
            page_numbers=[page_num - 1],  # pdfminer uses 0-indexed
            laparams=LAParams(),
        )
        return text or ""
    except Exception as e:
        log.debug(f"pdfminer extraction failed for page {page_num}: {e}")
        return ""


def page_has_images(pdf_path: str, page_num: int) -> bool:
    """Check if a PDF page contains embedded images."""
    try:
        from pdfminer.high_level import extract_pages
        from pdfminer.layout import LTImage, LTFigure

        for page_layout in extract_pages(pdf_path, page_numbers=[page_num - 1]):
            for element in page_layout:
                if isinstance(element, (LTImage, LTFigure)):
                    return True
                # Recurse into figures
                if hasattr(element, "__iter__"):
                    for child in element:
                        if isinstance(child, (LTImage, LTFigure)):
                            return True
        return False
    except Exception:
        return False


def classify_document(pdf_path: str, sample_pages: int = 5) -> PageType:
    """Quick classification of the entire document by sampling pages.

    Samples up to `sample_pages` pages and returns the dominant type.
    """
    from pdf2image.pdf2image import pdfinfo_from_path

    try:
        info = pdfinfo_from_path(pdf_path)
        total = info["Pages"]
    except Exception:
        total = 1

    pages_to_check = min(total, sample_pages)
    # Check first, middle, and last pages
    if pages_to_check <= 3:
        check_nums = list(range(1, pages_to_check + 1))
    else:
        check_nums = [1, total // 2, total]
        # Add a couple more evenly spaced
        step = total // pages_to_check
        check_nums.extend(range(step, total, step))
        check_nums = sorted(set(check_nums))[:sample_pages]

    types = [classify_page(pdf_path, p) for p in check_nums]

    # If any page is scanned, treat as scanned (conservative)
    if PageType.SCANNED in types:
        return PageType.SCANNED
    if PageType.MIXED in types:
        return PageType.MIXED
    return PageType.TEXT_NATIVE
