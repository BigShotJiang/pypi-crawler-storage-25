"""OCRAgent — the main entry point for IQEdge.ai OCR.

Usage:
    from iqedge_ocr import OCRAgent

    agent = OCRAgent(lang="tel+eng", max_passes=4)
    doc = agent.process("input.pdf")
    print(doc.text)
    print(doc.confidence)
    print(doc.to_dict())
"""
from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import (
    Document, Page, Region, RegionType, TextBlock, PageType,
)
from iqedge_ocr.core.renderer import PDFRenderer
from iqedge_ocr.core.ocr_engine import create_engine, OCREngineBase
from iqedge_ocr.core.page_classifier import classify_page, extract_native_text
from iqedge_ocr.correction.multipass import multipass_ocr
from iqedge_ocr.correction.postprocessor import PostProcessor
from iqedge_ocr.utils.platform import (
    find_tesseract, find_poppler, resolve_language,
)

if TYPE_CHECKING:
    pass

log = logging.getLogger("iqedge_ocr")


class OCRAgent:
    """Main OCR agent — processes PDFs with multi-pass self-correction.

    Supports:
    - Any PDF (text-native, scanned, mixed)
    - 35 languages (10 Indian + 25 global)
    - Multi-pass DPI escalation (200 → 300 → 400)
    - Pluggable engines (Tesseract, Google Vision, EasyOCR)
    - Trainable post-processing
    """

    def __init__(
        self,
        lang: str = "eng",
        max_passes: int = 4,
        confidence_threshold: float = 0.80,
        engine: str = "tesseract",
        tesseract_cmd: str | None = None,
        poppler_path: str | None = None,
        detect_tables: bool = True,
        training_db: str | None = None,
    ):
        # Resolve language codes
        self.lang = resolve_language(lang)
        self.max_passes = max_passes
        self.confidence_threshold = confidence_threshold
        self.detect_tables = detect_tables

        # Auto-detect binaries if not provided
        if not tesseract_cmd and engine == "tesseract":
            tesseract_cmd = find_tesseract()
            if not tesseract_cmd:
                raise RuntimeError(
                    "Tesseract not found. Install it or set TESSERACT_CMD env var.\n"
                    "  Windows: https://github.com/UB-Mannheim/tesseract/wiki\n"
                    "  Linux:   sudo apt install tesseract-ocr\n"
                    "  macOS:   brew install tesseract"
                )

        self.poppler_path = poppler_path or find_poppler()

        # Auto-download missing language packs on first use
        from iqedge_ocr.utils.setup import ensure_languages
        ensure_languages(tesseract_cmd=tesseract_cmd, verbose=True)

        # Create OCR engine
        self.engine: OCREngineBase = create_engine(
            engine_type=engine,
            tesseract_cmd=tesseract_cmd,
        )

        # Post-processor
        self.postprocessor: PostProcessor | None = None
        if max_passes >= 4:
            store = None
            if training_db:
                from iqedge_ocr.training.store import TrainingStore
                store = TrainingStore(training_db)
            self.postprocessor = PostProcessor(training_store=store)

    def process(
        self,
        pdf_path: str,
        pages: list[int] | str | None = None,
    ) -> Document:
        """Process a PDF file and return structured OCR results.

        Args:
            pdf_path: Path to the PDF file
            pages: Page numbers to process. Can be:
                   - None: all pages
                   - list[int]: specific pages [1, 3, 5]
                   - str: range like "1-5,8,10-12"

        Returns:
            Document with full OCR results
        """
        start_time = time.time()
        log.info(f"Processing: {pdf_path}")
        log.info(f"  Language: {self.lang} | Passes: {self.max_passes} | "
                 f"Threshold: {self.confidence_threshold}")

        renderer = PDFRenderer(pdf_path, poppler_path=self.poppler_path)
        total_pages = renderer.page_count

        # Resolve page numbers
        page_nums = self._resolve_pages(pages, total_pages)
        log.info(f"  Pages: {len(page_nums)} of {total_pages}")

        doc = Document(
            source_path=pdf_path,
            languages=self.lang.split("+"),
            total_passes=self.max_passes,
        )

        for page_num in page_nums:
            log.info(f"  Page {page_num}/{total_pages}")

            # Classify page type
            page_type = classify_page(pdf_path, page_num)

            if page_type == PageType.TEXT_NATIVE:
                # No OCR needed — extract text directly
                log.info(f"    Text-native page — extracting directly")
                page = self._extract_native_page(pdf_path, page_num, renderer)
            else:
                # OCR with multi-pass
                page = multipass_ocr(
                    renderer=renderer,
                    engine=self.engine,
                    page_num=page_num,
                    lang=self.lang,
                    max_passes=self.max_passes,
                    confidence_threshold=self.confidence_threshold,
                    postprocessor=self.postprocessor,
                    detect_tables=self.detect_tables,
                )
                page.page_type = page_type

            doc.pages.append(page)

            # Clear renderer cache between pages to save memory
            renderer.clear_cache()

        elapsed = time.time() - start_time
        log.info(
            f"Done: {len(doc.pages)} pages, {doc.word_count:,} words, "
            f"confidence={doc.confidence:.1%}, {elapsed:.1f}s"
        )

        return doc

    def _extract_native_page(
        self, pdf_path: str, page_num: int, renderer: PDFRenderer
    ) -> Page:
        """Extract text from a text-native PDF page (no OCR needed)."""
        text = extract_native_text(pdf_path, page_num)

        # Create a simple text region
        from iqedge_ocr.models.document import Line, Word

        words = []
        for word_text in text.split():
            words.append(Word(text=word_text, confidence=1.0))

        lines = []
        for line_text in text.splitlines():
            if line_text.strip():
                line_words = [Word(text=w, confidence=1.0) for w in line_text.split() if w]
                if line_words:
                    lines.append(Line(words=line_words))

        text_block = TextBlock(lines=lines)

        region = Region(
            region_type=RegionType.TEXT,
            bbox=(0, 0, 0, 0),
            content=text_block,
            pass_number=0,  # no OCR pass needed
            dpi_used=0,
        )

        # Get page dimensions
        try:
            img = renderer.render_page(page_num, dpi=72)
            width, height = img.width, img.height
        except Exception:
            width, height = 0, 0

        return Page(
            page_num=page_num,
            width=width,
            height=height,
            page_type=PageType.TEXT_NATIVE,
            regions=[region],
            dpi_used=0,
        )

    def _resolve_pages(
        self, pages: list[int] | str | None, total: int
    ) -> list[int]:
        """Resolve page specification to list of page numbers."""
        if pages is None:
            return list(range(1, total + 1))

        if isinstance(pages, list):
            return [p for p in pages if 1 <= p <= total]

        # Parse string like "1-5,8,10-12"
        result = []
        for part in str(pages).split(","):
            part = part.strip()
            if "-" in part:
                start, end = part.split("-", 1)
                start, end = int(start.strip()), int(end.strip())
                result.extend(range(max(1, start), min(total, end) + 1))
            else:
                n = int(part)
                if 1 <= n <= total:
                    result.append(n)

        return sorted(set(result))
