"""Pluggable OCR engine — supports Tesseract and Google Cloud Vision.

Engine interface:
    engine.ocr_image(image, lang) -> list[Word]
    engine.ocr_region(image, bbox, lang) -> list[Word]

Tesseract is the default (free, offline).
Google Vision is optional (cloud, higher accuracy for complex scripts).
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from iqedge_ocr.models.document import Word

if TYPE_CHECKING:
    from PIL import Image

log = logging.getLogger("iqedge_ocr")


class OCREngineBase(ABC):
    """Abstract base for OCR engines."""

    @abstractmethod
    def ocr_image(
        self, image: Image.Image, lang: str = "eng", psm: int = 3
    ) -> list[Word]:
        """OCR a full image, returning words with confidence and positions."""
        ...

    def ocr_region(
        self, image: Image.Image, bbox: tuple[int, int, int, int],
        lang: str = "eng", psm: int = 6,
    ) -> list[Word]:
        """OCR a specific region of an image."""
        x, y, w, h = bbox
        cropped = image.crop((x, y, x + w, y + h))
        words = self.ocr_image(cropped, lang=lang, psm=psm)
        # Offset word positions back to original image coordinates
        for word in words:
            wx, wy, ww, wh = word.bbox
            word.bbox = (wx + x, wy + y, ww, wh)
        return words


class TesseractEngine(OCREngineBase):
    """Tesseract OCR engine via pytesseract.

    Uses image_to_data (not image_to_string) to get per-word confidence scores.
    This is critical for the multi-pass strategy.
    """

    def __init__(self, tesseract_cmd: str | None = None, config: str = ""):
        import pytesseract

        if tesseract_cmd:
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
        self._pytesseract = pytesseract
        self._config = config

    def ocr_image(
        self, image: Image.Image, lang: str = "eng", psm: int = 3
    ) -> list[Word]:
        config = f"--psm {psm} {self._config}".strip()

        data = self._pytesseract.image_to_data(
            image, lang=lang, config=config,
            output_type=self._pytesseract.Output.DICT,
        )

        words = []
        n = len(data["text"])
        for i in range(n):
            text = data["text"][i].strip()
            if not text:
                continue

            conf = data["conf"][i]
            # Tesseract returns -1 for non-text elements
            if conf < 0:
                conf = 0
            confidence = conf / 100.0  # normalize to 0.0-1.0

            words.append(Word(
                text=text,
                confidence=confidence,
                bbox=(
                    data["left"][i],
                    data["top"][i],
                    data["width"][i],
                    data["height"][i],
                ),
                block_num=data["block_num"][i],
                par_num=data["par_num"][i],
                line_num=data["line_num"][i],
                word_num=data["word_num"][i],
            ))

        return words

    def get_full_text(self, image: Image.Image, lang: str = "eng", psm: int = 3) -> str:
        """Get raw text output (for simple use cases)."""
        config = f"--psm {psm} {self._config}".strip()
        return self._pytesseract.image_to_string(image, lang=lang, config=config)


class GoogleVisionEngine(OCREngineBase):
    """Google Cloud Vision OCR engine.

    Requires: pip install google-cloud-vision
    And a service account key set via GOOGLE_APPLICATION_CREDENTIALS env var.

    More accurate for complex scripts (Arabic, CJK, Indic languages).
    """

    def __init__(self):
        try:
            from google.cloud import vision
            self._client = vision.ImageAnnotatorClient()
            self._vision = vision
        except ImportError:
            raise ImportError(
                "Google Cloud Vision not installed. "
                "Install with: pip install google-cloud-vision"
            )

    def ocr_image(
        self, image: Image.Image, lang: str = "eng", psm: int = 3
    ) -> list[Word]:
        import io

        # Convert PIL image to bytes
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        content = buf.getvalue()

        vision_image = self._vision.Image(content=content)

        # Use document_text_detection for better structured output
        response = self._client.document_text_detection(
            image=vision_image,
            image_context={"language_hints": lang.split("+")},
        )

        if response.error.message:
            raise RuntimeError(f"Google Vision error: {response.error.message}")

        words = []
        if not response.full_text_annotation:
            return words

        for page in response.full_text_annotation.pages:
            for block in page.blocks:
                for paragraph in block.paragraphs:
                    for word in paragraph.words:
                        text = "".join(s.text for s in word.symbols)
                        confidence = word.confidence  # already 0.0-1.0

                        # Bounding box
                        vertices = word.bounding_box.vertices
                        x = min(v.x for v in vertices)
                        y = min(v.y for v in vertices)
                        w = max(v.x for v in vertices) - x
                        h = max(v.y for v in vertices) - y

                        words.append(Word(
                            text=text,
                            confidence=confidence,
                            bbox=(x, y, w, h),
                        ))

        return words


class EasyOCREngine(OCREngineBase):
    """EasyOCR engine — good for handwriting and curved text.

    Requires: pip install easyocr
    """

    def __init__(self, languages: list[str] | None = None, gpu: bool = False):
        try:
            import easyocr
            langs = languages or ["en"]
            self._reader = easyocr.Reader(langs, gpu=gpu)
        except ImportError:
            raise ImportError(
                "EasyOCR not installed. Install with: pip install easyocr"
            )

    def ocr_image(
        self, image: Image.Image, lang: str = "eng", psm: int = 3
    ) -> list[Word]:
        import numpy as np

        img_array = np.array(image)
        results = self._reader.readtext(img_array)

        words = []
        for bbox_points, text, confidence in results:
            if not text.strip():
                continue

            # EasyOCR returns 4 corner points
            xs = [p[0] for p in bbox_points]
            ys = [p[1] for p in bbox_points]
            x, y = int(min(xs)), int(min(ys))
            w, h = int(max(xs) - x), int(max(ys) - y)

            words.append(Word(
                text=text.strip(),
                confidence=float(confidence),
                bbox=(x, y, w, h),
            ))

        return words


def create_engine(
    engine_type: str = "tesseract",
    tesseract_cmd: str | None = None,
    **kwargs,
) -> OCREngineBase:
    """Factory function to create an OCR engine.

    engine_type: "tesseract" (default), "google_vision", "easyocr"
    """
    if engine_type == "tesseract":
        return TesseractEngine(tesseract_cmd=tesseract_cmd, **kwargs)
    elif engine_type == "google_vision":
        return GoogleVisionEngine(**kwargs)
    elif engine_type == "easyocr":
        return EasyOCREngine(**kwargs)
    else:
        raise ValueError(f"Unknown engine: {engine_type}. Use: tesseract, google_vision, easyocr")
