"""IQEdge.ai OCR — Command Line Interface.

Usage:
    iqedge-ocr input.pdf                        # OCR to stdout
    iqedge-ocr input.pdf -o output.json         # structured JSON
    iqedge-ocr input.pdf --lang tel+eng         # Telugu + English
    iqedge-ocr input.pdf --passes 4             # full 4-pass correction
    iqedge-ocr input.pdf --engine google_vision # use Google Cloud Vision
    iqedge-ocr input.pdf --format csv -o out.csv
    iqedge-ocr input.pdf --pages 1-5,10
    iqedge-ocr train corpus_dir/                # train from documents
    iqedge-ocr info                             # show system info
"""
from __future__ import annotations

import argparse
import sys
import time


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # Setup logging
    from iqedge_ocr.utils.logging import setup_logging
    setup_logging(args.verbose)

    if args.command == "train":
        return cmd_train(args)
    elif args.command == "info":
        return cmd_info(args)
    elif args.command == "ocr":
        return cmd_ocr(args)
    else:
        parser.print_help()
        return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="iqedge-ai-ocr",
        description="IQEdge.ai OCR — PDF to Text converter with multi-pass self-correction. "
                     "63 languages. Table detection. Searchable PDF output.",
        epilog="14 Indian + 49 global languages. https://iqedge.ai/ocr",
    )

    parser.add_argument("-v", "--verbose", action="count", default=0)
    parser.add_argument("--version", action="version", version=f"iqedge-ai-ocr 0.1.0")

    subparsers = parser.add_subparsers(dest="command")

    # OCR subcommand (also works as default)
    ocr_parser = subparsers.add_parser("ocr", help="OCR a PDF file")
    ocr_parser.add_argument("input", help="PDF file to process")
    ocr_parser.add_argument("-o", "--output", help="Output file path")
    ocr_parser.add_argument("--format", "-f", choices=["text", "json", "csv", "pdf"], default=None)
    ocr_parser.add_argument("--lang", "-l", default="eng")
    ocr_parser.add_argument("--passes", "-p", type=int, default=4, choices=[1, 2, 3, 4])
    ocr_parser.add_argument("--confidence-threshold", "-t", type=float, default=0.80)
    ocr_parser.add_argument("--engine", "-e", choices=["tesseract", "google_vision", "easyocr"], default="tesseract")
    ocr_parser.add_argument("--pages", help="Page range: 1-5,8,10-12")
    ocr_parser.add_argument("--tesseract-cmd")
    ocr_parser.add_argument("--poppler-path")
    ocr_parser.add_argument("--no-tables", action="store_true")
    ocr_parser.add_argument("--training-db")
    ocr_parser.add_argument("-v", "--verbose", action="count", default=0)

    # Train subcommand
    train_parser = subparsers.add_parser("train", help="Train from corpus of PDF + ground-truth pairs")
    train_parser.add_argument("corpus_dir", help="Directory with PDF + .txt/.json pairs")
    train_parser.add_argument("--lang", default="eng", help="Language for training")
    train_parser.add_argument("--db", help="Training database path")
    train_parser.add_argument("-v", "--verbose", action="count", default=0)

    # Info subcommand
    info_parser = subparsers.add_parser("info", help="Show system info and capabilities")
    info_parser.add_argument("-v", "--verbose", action="count", default=0)

    return parser


def cmd_ocr(args) -> int:
    """Run OCR on a PDF file."""
    from iqedge_ocr.core.pipeline import OCRAgent
    from iqedge_ocr.output.formatter import format_output

    # Infer format from output extension
    fmt = args.format
    if not fmt and args.output:
        ext = args.output.rsplit(".", 1)[-1].lower()
        fmt = {"json": "json", "csv": "csv", "pdf": "pdf", "txt": "text"}.get(ext, "text")
    if not fmt:
        fmt = "text"

    try:
        agent = OCRAgent(
            lang=args.lang,
            max_passes=args.passes,
            confidence_threshold=args.confidence_threshold,
            engine=args.engine,
            tesseract_cmd=args.tesseract_cmd,
            poppler_path=args.poppler_path,
            detect_tables=not args.no_tables,
            training_db=args.training_db,
        )

        start = time.time()
        doc = agent.process(args.input, pages=args.pages)
        elapsed = time.time() - start

        result = format_output(doc, fmt=fmt, output_path=args.output)

        if not args.output:
            # Print to stdout
            if isinstance(result, bytes):
                sys.stdout.buffer.write(result)
            else:
                print(result)

        # Print summary to stderr
        print(
            f"\n[iqedge-ai-ocr] {doc.page_count} pages, {doc.word_count:,} words, "
            f"confidence={doc.confidence:.1%}, {elapsed:.1f}s",
            file=sys.stderr,
        )

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_train(args) -> int:
    """Train from a corpus directory."""
    from iqedge_ocr.training.trainer import Trainer
    from iqedge_ocr.training.store import TrainingStore

    try:
        store = TrainingStore(args.db) if args.db else TrainingStore()
        trainer = Trainer(store=store)

        stats = trainer.train_from_corpus(args.corpus_dir, lang=args.lang)

        print(f"Training complete:")
        print(f"  Documents:         {stats['pairs']}")
        print(f"  Char corrections:  {stats['char_corrections_learned']}")
        print(f"  Word corrections:  {stats['word_corrections_learned']}")
        print(f"  Database:          {store.db_path}")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_info(args) -> int:
    """Show system info."""
    from iqedge_ocr.utils.platform import (
        find_tesseract, find_poppler, get_tesseract_version,
        get_tesseract_languages, INDIAN_LANGUAGES, GLOBAL_LANGUAGES, ALL_LANGUAGES,
    )

    print("IQEdge.ai OCR v0.1.0")
    print("=" * 60)

    # Tesseract
    tess = find_tesseract()
    if tess:
        ver = get_tesseract_version(tess)
        installed = get_tesseract_languages(tess)
        print(f"Tesseract:  {ver}")
        print(f"  Path:     {tess}")
        print(f"  Installed: {len(installed)} language packs")
    else:
        print("Tesseract:  NOT FOUND")
        installed = []

    # Poppler
    poppler = find_poppler()
    print(f"Poppler:    {'Found at ' + poppler if poppler else 'NOT FOUND'}")

    # Supported languages — regional table
    print(f"\n{'='*60}")
    print(f"Supported Languages: {len(ALL_LANGUAGES)}")
    print(f"{'='*60}")

    regions = [
        ("Indian (14)", [
            ("Hindi", "hin"), ("Telugu", "tel"), ("Tamil", "tam"), ("Kannada", "kan"),
            ("Malayalam", "mal"), ("Bengali", "ben"), ("Gujarati", "guj"), ("Marathi", "mar"),
            ("Punjabi", "pan"), ("Odia", "ori"), ("Urdu", "urd"), ("Assamese", "asm"),
            ("Nepali", "nep"), ("Sanskrit", "san"),
        ]),
        ("Western Europe (9)", [
            ("English", "eng"), ("Spanish", "spa"), ("French", "fra"), ("German", "deu"),
            ("Italian", "ita"), ("Portuguese", "por"), ("Dutch", "nld"), ("Catalan", "cat"),
            ("Greek", "ell"),
        ]),
        ("Scandinavia (4)", [
            ("Swedish", "swe"), ("Norwegian", "nor"), ("Danish", "dan"), ("Finnish", "fin"),
        ]),
        ("Eastern Europe (13)", [
            ("Russian", "rus"), ("Polish", "pol"), ("Ukrainian", "ukr"), ("Czech", "ces"),
            ("Hungarian", "hun"), ("Romanian", "ron"), ("Bulgarian", "bul"), ("Croatian", "hrv"),
            ("Serbian", "srp"), ("Slovak", "slk"), ("Lithuanian", "lit"), ("Latvian", "lav"),
            ("Estonian", "est"),
        ]),
        ("Caucasus (3)", [
            ("Georgian", "kat"), ("Armenian", "hye"), ("Azerbaijani", "aze"),
        ]),
        ("Middle East (4)", [
            ("Arabic", "ara"), ("Hebrew", "heb"), ("Persian", "fas"), ("Turkish", "tur"),
        ]),
        ("East Asia (4)", [
            ("Chinese Simplified", "chi_sim"), ("Chinese Traditional", "chi_tra"),
            ("Japanese", "jpn"), ("Korean", "kor"),
        ]),
        ("Southeast Asia (9)", [
            ("Thai", "tha"), ("Vietnamese", "vie"), ("Indonesian", "ind"), ("Malay", "msa"),
            ("Filipino", "tgl"), ("Cebuano", "ceb"), ("Burmese", "mya"), ("Khmer", "khm"),
            ("Lao", "lao"),
        ]),
        ("Central Asia (1)", [("Uzbek", "uzb")]),
        ("Africa (2)", [("Swahili", "swa"), ("Amharic", "amh")]),
    ]

    installed_set = set(installed)
    total_ready = 0

    for region_name, langs in regions:
        names = []
        for name, code in langs:
            ready = code in installed_set
            if ready:
                total_ready += 1
            mark = "+" if ready else "-"
            names.append(f"{name}({mark})")
        print(f"\n  {region_name}:")
        # Wrap at ~70 chars
        line = "    "
        for n in names:
            if len(line) + len(n) > 70:
                print(line)
                line = "    "
            line += n + "  "
        if line.strip():
            print(line)

    print(f"\n  + = installed, - = needs download")
    print(f"  {total_ready}/{len(ALL_LANGUAGES)} languages ready")

    # OCR Engines
    print(f"\n{'='*60}")
    print("OCR Engines:")
    print("  Tesseract    (default)  — free, offline, 63 languages")
    print("  Google Vision(optional) — cloud, highest accuracy")
    print("  EasyOCR      (optional) — handwriting, curved text")

    # Dependencies
    print(f"\n{'='*60}")
    print("Dependencies:")
    for pkg, desc, status_label in [
        ("cv2", "Table detection", "opencv"),
        ("rapidfuzz", "Training alignment", "rapidfuzz"),
        ("fpdf2", "Searchable PDF output", "fpdf2"),
        ("google.cloud.vision", "Google Cloud Vision", "google-cloud-vision"),
        ("easyocr", "EasyOCR engine", "easyocr"),
    ]:
        try:
            __import__(pkg.split(".")[0])
            print(f"  {desc:30} installed")
        except ImportError:
            print(f"  {desc:30} pip install {status_label}")

    # Training data
    from iqedge_ocr.training.store import TrainingStore, DEFAULT_DB_PATH
    if DEFAULT_DB_PATH.exists():
        store = TrainingStore()
        stats = store.stats()
        print(f"\n{'='*60}")
        print(f"Training Data:")
        print(f"  {stats['char_confusions']} character confusions learned")
        print(f"  {stats['word_corrections']} word corrections learned")
        print(f"  {stats['training_runs']} training runs completed")
        store.close()

    print(f"\n{'='*60}")
    print("https://iqedge.ai/ocr")
    return 0


if __name__ == "__main__":
    sys.exit(main())
