"""Corpus-based training — learn OCR corrections from document pairs.

Usage:
    iqedge-ocr train corpus_dir/

Corpus directory structure:
    corpus_dir/
        document1.pdf + document1.txt   (ground truth as plain text)
        document2.pdf + document2.json  (ground truth as structured JSON)
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

from iqedge_ocr.training.store import TrainingStore

if TYPE_CHECKING:
    from iqedge_ocr.core.pipeline import OCRAgent

log = logging.getLogger("iqedge_ocr")


class Trainer:
    """Learn OCR corrections from a corpus of PDF + ground-truth pairs."""

    def __init__(self, store: TrainingStore | None = None):
        self.store = store or TrainingStore()

    def train_from_corpus(
        self,
        corpus_dir: str,
        agent: OCRAgent | None = None,
        lang: str = "eng",
    ) -> dict:
        """Process all PDF+ground-truth pairs in a directory.

        Returns training stats.
        """
        corpus_path = Path(corpus_dir)
        if not corpus_path.is_dir():
            raise FileNotFoundError(f"Corpus directory not found: {corpus_dir}")

        # Find PDF files with corresponding ground truth
        pairs = self._find_pairs(corpus_path)
        log.info(f"Found {len(pairs)} PDF + ground-truth pairs in {corpus_dir}")

        if not pairs:
            return {"pairs": 0, "corrections": 0}

        # Lazy import to avoid circular dependency
        if agent is None:
            from iqedge_ocr.core.pipeline import OCRAgent
            agent = OCRAgent(lang=lang, max_passes=1)  # single pass for training

        total_char_fixes = 0
        total_word_fixes = 0

        for pdf_path, truth_path in pairs:
            log.info(f"Training on: {pdf_path.name}")

            # OCR the PDF (single pass)
            doc = agent.process(str(pdf_path))
            ocr_text = doc.text

            # Load ground truth
            truth_text = self._load_ground_truth(truth_path)

            # Align and learn
            char_fixes, word_fixes = self._align_and_learn(ocr_text, truth_text, lang)
            total_char_fixes += char_fixes
            total_word_fixes += word_fixes

        stats = {
            "pairs": len(pairs),
            "char_corrections_learned": total_char_fixes,
            "word_corrections_learned": total_word_fixes,
        }

        self.store.log_training_run(
            corpus_path=str(corpus_dir),
            num_documents=len(pairs),
            accuracy_before=0.0,  # TODO: calculate
            accuracy_after=0.0,
        )

        log.info(f"Training complete: {stats}")
        return stats

    def _find_pairs(self, corpus_dir: Path) -> list[tuple[Path, Path]]:
        """Find PDF + ground-truth file pairs."""
        pairs = []
        for pdf in sorted(corpus_dir.glob("*.pdf")):
            stem = pdf.stem
            # Look for matching ground truth
            for ext in [".txt", ".json"]:
                truth = pdf.with_suffix(ext)
                if truth.exists():
                    pairs.append((pdf, truth))
                    break
        return pairs

    def _load_ground_truth(self, path: Path) -> str:
        """Load ground truth text from .txt or .json file."""
        if path.suffix == ".json":
            import json
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            # Support various JSON structures
            if isinstance(data, str):
                return data
            if isinstance(data, dict):
                return data.get("text", data.get("content", str(data)))
            return str(data)
        else:
            with open(path, encoding="utf-8") as f:
                return f.read()

    def _align_and_learn(self, ocr_text: str, truth_text: str, lang: str) -> tuple[int, int]:
        """Align OCR output with ground truth and learn corrections.

        Returns (char_corrections, word_corrections) count.
        """
        ocr_words = ocr_text.split()
        truth_words = truth_text.split()

        char_fixes = 0
        word_fixes = 0

        # Try fuzzy alignment
        try:
            from rapidfuzz import fuzz, process

            for ocr_word in ocr_words:
                if not ocr_word.strip():
                    continue

                # Find best match in truth
                matches = process.extract(ocr_word, truth_words, scorer=fuzz.ratio, limit=1)
                if not matches:
                    continue

                best_match, score, _ = matches[0]
                if score >= 70 and ocr_word != best_match:
                    # This is a correction
                    self.store.add_word_correction(ocr_word, best_match, lang)
                    word_fixes += 1

                    # Character-level: find specific character differences
                    for i, (oc, tc) in enumerate(zip(ocr_word, best_match)):
                        if oc != tc:
                            self.store.add_char_confusion(oc, tc, lang)
                            char_fixes += 1

        except ImportError:
            # Without rapidfuzz, do simple exact-position comparison
            min_len = min(len(ocr_words), len(truth_words))
            for i in range(min_len):
                if ocr_words[i] != truth_words[i]:
                    self.store.add_word_correction(ocr_words[i], truth_words[i], lang)
                    word_fixes += 1

        return char_fixes, word_fixes
