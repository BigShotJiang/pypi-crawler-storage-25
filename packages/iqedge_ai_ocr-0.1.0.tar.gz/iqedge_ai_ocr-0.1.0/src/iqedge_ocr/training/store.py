"""SQLite-based storage for training data (confusion matrices, word corrections).

Stored at ~/.iqedge-ai-ocr/training.db
"""
from __future__ import annotations

import logging
import os
import sqlite3
from pathlib import Path

log = logging.getLogger("iqedge_ocr")

DEFAULT_DB_PATH = Path.home() / ".iqedge-ai-ocr" / "training.db"


class TrainingStore:
    """Persistent storage for OCR training data."""

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_db()

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS char_confusion (
                from_char TEXT NOT NULL,
                to_char TEXT NOT NULL,
                count INTEGER DEFAULT 1,
                language TEXT DEFAULT '',
                PRIMARY KEY (from_char, to_char, language)
            );

            CREATE TABLE IF NOT EXISTS word_corrections (
                ocr_word TEXT NOT NULL,
                correct_word TEXT NOT NULL,
                count INTEGER DEFAULT 1,
                language TEXT DEFAULT '',
                PRIMARY KEY (ocr_word, correct_word, language)
            );

            CREATE TABLE IF NOT EXISTS patterns (
                pattern TEXT NOT NULL,
                replacement TEXT NOT NULL,
                count INTEGER DEFAULT 1,
                PRIMARY KEY (pattern, replacement)
            );

            CREATE TABLE IF NOT EXISTS training_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                corpus_path TEXT,
                num_documents INTEGER,
                accuracy_before REAL,
                accuracy_after REAL
            );
        """)
        conn.commit()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
        return self._conn

    def add_char_confusion(self, from_char: str, to_char: str, language: str = "") -> None:
        conn = self._get_conn()
        conn.execute(
            "INSERT INTO char_confusion (from_char, to_char, language, count) "
            "VALUES (?, ?, ?, 1) "
            "ON CONFLICT(from_char, to_char, language) DO UPDATE SET count = count + 1",
            (from_char, to_char, language),
        )
        conn.commit()

    def add_word_correction(self, ocr_word: str, correct_word: str, language: str = "") -> None:
        conn = self._get_conn()
        conn.execute(
            "INSERT INTO word_corrections (ocr_word, correct_word, language, count) "
            "VALUES (?, ?, ?, 1) "
            "ON CONFLICT(ocr_word, correct_word, language) DO UPDATE SET count = count + 1",
            (ocr_word, correct_word, language),
        )
        conn.commit()

    def get_char_confusions(self, language: str = "", min_count: int = 2) -> dict[str, str]:
        """Get character confusion map (from_char -> to_char) with sufficient evidence."""
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT from_char, to_char, count FROM char_confusion "
            "WHERE (language = ? OR language = '') AND count >= ? "
            "ORDER BY count DESC",
            (language, min_count),
        ).fetchall()
        return {row[0]: row[1] for row in rows}

    def get_word_corrections(self, language: str = "", min_count: int = 2) -> dict[str, str]:
        """Get word correction map (ocr_word -> correct_word) with sufficient evidence."""
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT ocr_word, correct_word, count FROM word_corrections "
            "WHERE (language = ? OR language = '') AND count >= ? "
            "ORDER BY count DESC",
            (language, min_count),
        ).fetchall()
        return {row[0]: row[1] for row in rows}

    def log_training_run(
        self, corpus_path: str, num_documents: int,
        accuracy_before: float, accuracy_after: float,
    ) -> None:
        from datetime import datetime
        conn = self._get_conn()
        conn.execute(
            "INSERT INTO training_runs (timestamp, corpus_path, num_documents, accuracy_before, accuracy_after) "
            "VALUES (?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), corpus_path, num_documents, accuracy_before, accuracy_after),
        )
        conn.commit()

    def stats(self) -> dict:
        conn = self._get_conn()
        char_count = conn.execute("SELECT COUNT(*) FROM char_confusion").fetchone()[0]
        word_count = conn.execute("SELECT COUNT(*) FROM word_corrections").fetchone()[0]
        runs = conn.execute("SELECT COUNT(*) FROM training_runs").fetchone()[0]
        return {
            "char_confusions": char_count,
            "word_corrections": word_count,
            "training_runs": runs,
            "db_path": str(self.db_path),
        }

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
