"""Structured logging setup for IQEdge OCR."""
from __future__ import annotations

import logging
import sys


def setup_logging(verbosity: int = 0) -> logging.Logger:
    """Configure logging based on verbosity level.

    0 = WARNING (quiet), 1 = INFO, 2+ = DEBUG
    """
    level = {0: logging.WARNING, 1: logging.INFO}.get(verbosity, logging.DEBUG)

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    ))

    logger = logging.getLogger("iqedge_ocr")
    logger.setLevel(level)
    logger.handlers = [handler]

    return logger
