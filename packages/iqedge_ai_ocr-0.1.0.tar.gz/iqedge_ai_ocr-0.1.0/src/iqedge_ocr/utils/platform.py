"""Cross-platform detection of Tesseract and Poppler binaries."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def find_tesseract() -> str | None:
    """Auto-detect Tesseract binary path."""
    # 1. Environment variable
    env_path = os.environ.get("TESSERACT_CMD")
    if env_path and Path(env_path).is_file():
        return env_path

    # 2. PATH
    found = shutil.which("tesseract")
    if found:
        return found

    # 3. Platform-specific common locations
    if sys.platform == "win32":
        candidates = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            Path.home() / "AppData" / "Local" / "Programs" / "Tesseract-OCR" / "tesseract.exe",
            # Chocolatey
            r"C:\ProgramData\chocolatey\bin\tesseract.exe",
            # Scoop
            Path.home() / "scoop" / "shims" / "tesseract.exe",
        ]
    elif sys.platform == "darwin":
        candidates = [
            "/opt/homebrew/bin/tesseract",
            "/usr/local/bin/tesseract",
        ]
    else:
        candidates = [
            "/usr/bin/tesseract",
            "/usr/local/bin/tesseract",
            "/snap/bin/tesseract",
        ]

    for path in candidates:
        p = Path(path)
        if p.is_file():
            return str(p)

    return None


def find_poppler() -> str | None:
    """Auto-detect Poppler binaries directory (containing pdftoppm)."""
    binary = "pdftoppm.exe" if sys.platform == "win32" else "pdftoppm"

    # 1. Environment variable
    env_path = os.environ.get("POPPLER_PATH")
    if env_path and Path(env_path).is_dir():
        if (Path(env_path) / binary).is_file():
            return env_path

    # 2. PATH
    found = shutil.which("pdftoppm")
    if found:
        return str(Path(found).parent)

    # 3. Platform-specific
    if sys.platform == "win32":
        candidates = [
            r"C:\Program Files\poppler\Library\bin",
            r"C:\Program Files\poppler\bin",
            Path.home() / "scoop" / "shims",
        ]
        # Search common install patterns
        for drive in ["C:", "D:", "E:"]:
            for pattern in [
                f"{drive}\\poppler*\\Library\\bin",
                f"{drive}\\poppler*\\bin",
            ]:
                import glob
                matches = glob.glob(pattern)
                if matches:
                    candidates.extend(matches)
    elif sys.platform == "darwin":
        candidates = [
            "/opt/homebrew/bin",
            "/usr/local/bin",
        ]
    else:
        candidates = [
            "/usr/bin",
            "/usr/local/bin",
        ]

    for path in candidates:
        p = Path(str(path))
        if p.is_dir() and (p / binary).is_file():
            return str(p)

    return None


def get_tesseract_version(tesseract_cmd: str) -> str | None:
    """Get Tesseract version string."""
    try:
        result = subprocess.run(
            [tesseract_cmd, "--version"],
            capture_output=True, text=True, timeout=5,
        )
        output = result.stdout or result.stderr
        for line in output.splitlines():
            if line.startswith("tesseract"):
                return line.strip()
        return output.splitlines()[0].strip() if output.strip() else None
    except Exception:
        return None


def get_tesseract_languages(tesseract_cmd: str) -> list[str]:
    """Get list of installed Tesseract language packs."""
    try:
        result = subprocess.run(
            [tesseract_cmd, "--list-langs"],
            capture_output=True, text=True, timeout=5,
        )
        output = result.stdout or result.stderr
        langs = []
        for line in output.splitlines():
            line = line.strip()
            if line and not line.startswith("List") and not line.startswith("tesseract"):
                langs.append(line)
        return langs
    except Exception:
        return []


# Supported languages with Tesseract codes
INDIAN_LANGUAGES = {
    "hindi": "hin",
    "telugu": "tel",
    "tamil": "tam",
    "kannada": "kan",
    "malayalam": "mal",
    "bengali": "ben",
    "gujarati": "guj",
    "marathi": "mar",
    "punjabi": "pan",
    "odia": "ori",
    "urdu": "urd",
    "assamese": "asm",
    "nepali": "nep",
    "sanskrit": "san",
}

GLOBAL_LANGUAGES = {
    # Western Europe
    "english": "eng",
    "spanish": "spa",
    "french": "fra",
    "german": "deu",
    "italian": "ita",
    "portuguese": "por",
    "dutch": "nld",
    "catalan": "cat",
    # Scandinavia
    "swedish": "swe",
    "norwegian": "nor",
    "danish": "dan",
    "finnish": "fin",
    # Eastern Europe
    "russian": "rus",
    "polish": "pol",
    "ukrainian": "ukr",
    "czech": "ces",
    "hungarian": "hun",
    "romanian": "ron",
    "bulgarian": "bul",
    "croatian": "hrv",
    "serbian": "srp",
    "slovak": "slk",
    "lithuanian": "lit",
    "latvian": "lav",
    "estonian": "est",
    # Caucasus
    "georgian": "kat",
    "armenian": "hye",
    "azerbaijani": "aze",
    # Middle East
    "arabic": "ara",
    "hebrew": "heb",
    "persian": "fas",
    "farsi": "fas",
    "turkish": "tur",
    # East Asia
    "chinese_simplified": "chi_sim",
    "chinese_traditional": "chi_tra",
    "japanese": "jpn",
    "korean": "kor",
    # Southeast Asia
    "thai": "tha",
    "vietnamese": "vie",
    "indonesian": "ind",
    "malay": "msa",
    "filipino": "tgl",
    "tagalog": "tgl",
    "cebuano": "ceb",
    "burmese": "mya",
    "myanmar": "mya",
    "khmer": "khm",
    "lao": "lao",
    # Central Asia
    "uzbek": "uzb",
    # Africa
    "swahili": "swa",
    "amharic": "amh",
    # Greek
    "greek": "ell",
}

ALL_LANGUAGES = {**INDIAN_LANGUAGES, **GLOBAL_LANGUAGES}


def resolve_language(lang_input: str) -> str:
    """Resolve a language name or code to Tesseract language code.

    Accepts: 'eng', 'english', 'tel', 'telugu', 'tel+eng', 'hindi+english'
    Returns: Tesseract lang string like 'tel+eng'
    """
    parts = lang_input.lower().replace(",", "+").split("+")
    resolved = []
    for part in parts:
        part = part.strip()
        if part in ALL_LANGUAGES:
            resolved.append(ALL_LANGUAGES[part])
        elif part in ALL_LANGUAGES.values():
            resolved.append(part)  # already a tesseract code
        else:
            resolved.append(part)  # pass through, let tesseract handle it
    return "+".join(resolved)
