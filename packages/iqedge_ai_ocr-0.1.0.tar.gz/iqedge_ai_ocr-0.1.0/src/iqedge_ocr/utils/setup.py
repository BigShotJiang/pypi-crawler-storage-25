"""Auto-setup: download missing Tesseract language packs on first run.

Called automatically when IQEdge.ai OCR detects missing language data.
"""
from __future__ import annotations

import logging
import os
import sys
import urllib.request
from pathlib import Path

log = logging.getLogger("iqedge_ocr")

TESSDATA_URL = "https://github.com/tesseract-ocr/tessdata/raw/main"

# All 35 supported languages (Tesseract codes)
REQUIRED_LANGS = [
    # 14 Indian
    "hin", "tel", "tam", "kan", "mal", "ben", "guj", "mar", "pan", "ori",
    "urd", "asm", "nep", "san",
    # 49 Global
    "eng", "spa", "fra", "deu", "ita", "por", "nld", "cat",
    "swe", "nor", "dan", "fin",
    "rus", "pol", "ukr", "ces", "hun", "ron", "bul", "hrv", "srp", "slk",
    "lit", "lav", "est",
    "kat", "hye", "aze",
    "ara", "heb", "fas", "tur",
    "chi_sim", "chi_tra", "jpn", "kor",
    "tha", "vie", "ind", "msa", "tgl", "ceb", "mya", "khm", "lao",
    "uzb",
    "swa", "amh",
    "ell",
]


def find_tessdata_dir(tesseract_cmd: str | None = None) -> Path | None:
    """Find the tessdata directory for the installed Tesseract."""
    # 1. TESSDATA_PREFIX env var
    env = os.environ.get("TESSDATA_PREFIX")
    if env:
        p = Path(env)
        if p.is_dir():
            return p
        # Some set it to parent dir
        if (p / "tessdata").is_dir():
            return p / "tessdata"

    # 2. Relative to tesseract binary
    if tesseract_cmd:
        tess_dir = Path(tesseract_cmd).parent
        tessdata = tess_dir / "tessdata"
        if tessdata.is_dir():
            return tessdata
        # One level up
        tessdata = tess_dir.parent / "tessdata"
        if tessdata.is_dir():
            return tessdata

    # 3. Common locations
    candidates = []
    if sys.platform == "win32":
        candidates = [
            Path(r"C:\Program Files\Tesseract-OCR\tessdata"),
            Path.home() / "AppData" / "Local" / "Programs" / "Tesseract-OCR" / "tessdata",
        ]
    elif sys.platform == "darwin":
        candidates = [
            Path("/opt/homebrew/share/tessdata"),
            Path("/usr/local/share/tessdata"),
        ]
    else:
        candidates = [
            Path("/usr/share/tesseract-ocr/5/tessdata"),
            Path("/usr/share/tesseract-ocr/4.00/tessdata"),
            Path("/usr/share/tessdata"),
        ]

    for p in candidates:
        if p.is_dir():
            return p

    return None


def ensure_languages(
    tesseract_cmd: str | None = None,
    languages: list[str] | None = None,
    verbose: bool = True,
) -> dict:
    """Download any missing Tesseract language packs.

    Returns dict with 'installed', 'already_present', 'failed' counts.
    """
    tessdata = find_tessdata_dir(tesseract_cmd)
    if not tessdata:
        if verbose:
            log.warning("Could not find tessdata directory. Skipping language pack setup.")
        return {"installed": 0, "already_present": 0, "failed": 0, "error": "tessdata not found"}

    langs_to_check = languages or REQUIRED_LANGS
    installed = 0
    already = 0
    failed = 0

    for lang in langs_to_check:
        traineddata = tessdata / f"{lang}.traineddata"
        if traineddata.exists():
            already += 1
            continue

        url = f"{TESSDATA_URL}/{lang}.traineddata"
        if verbose:
            log.info(f"Downloading language pack: {lang}")

        try:
            urllib.request.urlretrieve(url, str(traineddata))
            installed += 1
            if verbose:
                size_mb = traineddata.stat().st_size / 1024 / 1024
                log.info(f"  {lang}: installed ({size_mb:.1f} MB)")
        except Exception as e:
            failed += 1
            if verbose:
                log.warning(f"  {lang}: failed ({e})")

    result = {"installed": installed, "already_present": already, "failed": failed}

    if installed > 0 and verbose:
        log.info(
            f"Language setup complete: {installed} installed, "
            f"{already} already present, {failed} failed"
        )

    return result


def check_system_dependencies() -> dict:
    """Check all system dependencies and report status.

    Called on `iqedge-ocr info` or first run.
    """
    from iqedge_ocr.utils.platform import find_tesseract, find_poppler

    status = {
        "tesseract": None,
        "poppler": None,
        "tessdata": None,
        "missing_langs": [],
    }

    tess = find_tesseract()
    status["tesseract"] = tess

    poppler = find_poppler()
    status["poppler"] = poppler

    if tess:
        tessdata = find_tessdata_dir(tess)
        status["tessdata"] = str(tessdata) if tessdata else None

        if tessdata:
            missing = []
            for lang in REQUIRED_LANGS:
                if not (tessdata / f"{lang}.traineddata").exists():
                    missing.append(lang)
            status["missing_langs"] = missing

    return status
