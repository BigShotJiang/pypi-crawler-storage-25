ones_sdk/
│
├── ones/                     # main package
│   ├── __init__.py
│   │
│   ├── client.py            # main entry point
│   ├── transport.py         # HTTP layer
│   ├── exceptions.py        # custom errors
│   ├── constants.py         # endpoints, paths
│   │
│   ├── resources/           # API groups
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── user.py
│   │   ├── health.py
│   │   └── inventory.py
│   │
│   ├── utils/               # helpers
│   │   ├── __init__.py
│   │   └── parser.py        # json parsing helpers
│   │
│   └── models/              # (optional, later)
│       ├── __init__.py
│       └── user.py
│
├── tests/
│   ├── test_user.py
│   ├── test_health.py
│   └── test_inventory.py
│
├── examples/
│   └── basic_usage.py
│
├── requirements.txt
├── setup.py / pyproject.toml
└── README.md