"""CC-native tool executor — uses the original CC execution.py dispatch.

No async wrappers, no run_until_complete hacks.
Pure synchronous execution as the Rust original intended.
"""
from __future__ import annotations

import json
from typing import Any

from maestro_core.runtime.conversation import ToolExecutor, ToolError
from maestro_core.tools.execution import execute_tool_dispatch


    # Map our tool names to CC execution.py names
_NAME_MAP = {
    "file_read": "read_file",
    "file_write": "write_file",
    "file_edit": "edit_file",
    "glob": "glob_search",
    "grep": "grep_search",
    "web_fetch": "WebFetch",
    "todo_write": "TodoWrite",
    "notebook_edit": "NotebookEdit",
    "agent": "Agent",
    "code_search": "grep_search",  # fallback to grep
    "image_read": "read_file",     # fallback
    "pdf_read": "read_file",       # fallback
    "task_create": "TaskCreate",
    "task_list": "TaskList",
    "task_get": "TaskGet",
    "task_stop": "TaskStop",
    "task_update": "TaskUpdate",
    "task_output": "TaskOutput",
    "team_create": "TeamCreate",
    "team_delete": "TeamDelete",
    "send_message": "SendUserMessage",
    "git_status": "bash",
    "git_diff": "bash",
    "git_log": "bash",
    "git_add": "bash",
    "git_commit": "bash",
    "git_cleanup": "bash",
    "morpheus_beads": "bash",
    "morpheus_snapshot": "bash",
}

# Git tool → bash command mapping
_GIT_COMMANDS = {
    "git_status": "git status --porcelain -b",
    "git_diff": "git diff",
    "git_log": "git log --oneline -10",
    "git_add": None,  # uses args
    "git_commit": None,
    "git_cleanup": "git branch --merged | grep -v main | grep -v '\\*'",
}


class CCToolExecutor(ToolExecutor):
    """Uses the CC original synchronous tool dispatch.

    This is the REAL CC execution path — routes through execution.py
    which handles bash, file ops, tasks, teams, etc. all synchronously.

    Falls back to our async Tool classes for tools not in execution.py
    (MCP tools, custom tools, etc.)."""

    def __init__(self, context: dict[str, Any] | None = None, fallback_registry=None) -> None:
        self._context = context or {}
        self._fallback_registry = fallback_registry  # ToolRegistry for non-CC tools

    def execute(self, tool_name: str, input_str: str) -> str:
        try:
            args = json.loads(input_str) if input_str else {}
        except json.JSONDecodeError:
            args = {"input": input_str}

        # Handle git tools → convert to bash commands
        if tool_name in _GIT_COMMANDS:
            return self._execute_git(tool_name, args)

        # Map our names to CC names
        cc_name = _NAME_MAP.get(tool_name, tool_name)

        try:
            return execute_tool_dispatch(cc_name, args, self._context)
        except ValueError:
            # Tool not in CC dispatch — try fallback registry (async tools)
            if self._fallback_registry:
                return self._execute_fallback(tool_name, args)
            raise ToolError(f"unsupported tool: {tool_name}")
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"{tool_name} failed: {e}")

    def _execute_git(self, tool_name: str, args: dict) -> str:
        """Convert git tool calls to bash commands."""
        if tool_name == "git_add":
            files = args.get("files", [])
            cmd = f"git add {' '.join(files)}" if files else "git add -A"
        elif tool_name == "git_commit":
            msg = args.get("message", "commit")
            cmd = f'git commit -m "{msg}"'
        elif tool_name == "git_diff":
            staged = args.get("staged", False)
            file_arg = args.get("file", "")
            cmd = f"git diff {'--cached ' if staged else ''}{file_arg}".strip()
        elif tool_name == "git_log":
            count = args.get("count", 10)
            oneline = args.get("oneline", True)
            cmd = f"git log {'--oneline ' if oneline else ''}-{count}"
        else:
            cmd = _GIT_COMMANDS.get(tool_name, f"git {tool_name.replace('git_', '')}")

        return execute_tool_dispatch("bash", {"command": cmd}, self._context)

    def _execute_fallback(self, tool_name: str, args: dict) -> str:
        """Fallback to async Tool classes for non-CC tools (MCP, custom)."""
        import asyncio
        tool = self._fallback_registry.get(tool_name)
        if tool is None:
            raise ToolError(f"tool '{tool_name}' not found")
        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(tool.execute(args))
            if result.is_error:
                raise ToolError(result.content)
            return result.content
        finally:
            loop.close()
