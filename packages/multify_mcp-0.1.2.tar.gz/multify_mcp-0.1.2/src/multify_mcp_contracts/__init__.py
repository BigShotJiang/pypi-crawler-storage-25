"""Embedded Python contracts for the public multify-mcp package."""

from .auth import ApiKeyIntrospection
from .operations import (
    BulkItemError,
    BulkItemResult,
    BulkOperationResult,
    CollectionOperationResult,
    MembershipOperationResult,
    ResourceOperationResult,
)
from .resources import (
    Contact,
    ContactBulkCreateInput,
    ContactBulkUpdateInput,
    ContactBulkUpdateItem,
    ContactCreateInput,
    ContactUpdateInput,
    ListAddContactsInput,
    ListBulkAddContactsInput,
    ListBulkCreateInput,
    ListBulkMembershipItem,
    ListBulkUpdateInput,
    ListBulkUpdateItem,
    ListCreateInput,
    ListRemoveContactsInput,
    ListReplaceContactsInput,
    ListUpdateInput,
    WorkspaceList,
)
from .scopes import McpScope

__all__ = [
    "ApiKeyIntrospection",
    "BulkItemError",
    "BulkItemResult",
    "BulkOperationResult",
    "CollectionOperationResult",
    "Contact",
    "ContactBulkCreateInput",
    "ContactBulkUpdateInput",
    "ContactBulkUpdateItem",
    "ContactCreateInput",
    "ContactUpdateInput",
    "ListAddContactsInput",
    "ListBulkAddContactsInput",
    "ListBulkCreateInput",
    "ListBulkMembershipItem",
    "ListBulkUpdateInput",
    "ListBulkUpdateItem",
    "ListCreateInput",
    "ListRemoveContactsInput",
    "ListReplaceContactsInput",
    "ListUpdateInput",
    "McpScope",
    "MembershipOperationResult",
    "ResourceOperationResult",
    "WorkspaceList",
]
