from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .resources import Contact, WorkspaceList

ResourcePayload = Contact | WorkspaceList


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ResourceOperationResult(ContractModel):
    operation_id: str
    workspace_id: str
    resource: ResourcePayload


class CollectionOperationResult(ContractModel):
    operation_id: str
    workspace_id: str
    items: list[ResourcePayload] = Field(default_factory=list)
    total: int = Field(ge=0)


class BulkItemError(ContractModel):
    code: str
    message: str


class BulkItemResult(ContractModel):
    index: int = Field(ge=0)
    status: Literal["success", "error"]
    item_id: str | None = None
    resource: ResourcePayload | None = None
    error: BulkItemError | None = None


class BulkOperationResult(ContractModel):
    operation_id: str
    workspace_id: str
    total_count: int = Field(ge=0)
    succeeded_count: int = Field(ge=0)
    failed_count: int = Field(ge=0)
    results: list[BulkItemResult] = Field(default_factory=list)


class MembershipOperationResult(ContractModel):
    operation_id: str
    workspace_id: str
    affected_count: int = Field(ge=0)
    list_ids: list[str] = Field(default_factory=list)
