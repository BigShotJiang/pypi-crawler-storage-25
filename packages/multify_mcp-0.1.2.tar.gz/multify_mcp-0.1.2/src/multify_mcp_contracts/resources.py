from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ContactCreateInput(ContractModel):
    list_id: str
    full_name: str = Field(min_length=1, max_length=255)
    email: str = Field(min_length=1, max_length=320)
    phone: str | None = None
    whatsapp_number: str | None = None
    job_title: str | None = None
    company_name: str | None = None
    company_domain: str | None = None
    linkedin_url: str | None = None
    country: str | None = None
    source: str | None = None
    tags: list[str] = Field(default_factory=list)


class ContactUpdateInput(ContractModel):
    list_id: str | None = None
    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    email: str | None = Field(default=None, min_length=1, max_length=320)
    phone: str | None = None
    whatsapp_number: str | None = None
    job_title: str | None = None
    company_name: str | None = None
    company_domain: str | None = None
    linkedin_url: str | None = None
    country: str | None = None
    source: str | None = None
    tags: list[str] | None = None


class Contact(ContractModel):
    id: str
    workspace_id: str
    list_id: str
    full_name: str | None = None
    email: str | None = None
    phone: str | None = None
    whatsapp_number: str | None = None
    job_title: str | None = None
    company_name: str | None = None
    company_domain: str | None = None
    linkedin_url: str | None = None
    country: str | None = None
    source: str | None = None
    tags: list[str] = Field(default_factory=list)


class ContactBulkCreateInput(ContractModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    items: list[ContactCreateInput] = Field(min_length=1, max_length=500)


class ContactBulkUpdateItem(ContractModel):
    contact_id: str
    patch: ContactUpdateInput


class ContactBulkUpdateInput(ContractModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    items: list[ContactBulkUpdateItem] = Field(min_length=1, max_length=500)


class ListCreateInput(ContractModel):
    name: str = Field(min_length=1, max_length=255)
    description: str | None = None


class ListUpdateInput(ContractModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = None


class WorkspaceList(ContractModel):
    id: str
    workspace_id: str
    name: str
    description: str | None = None

    def to_create_input(self) -> ListCreateInput:
        return ListCreateInput(name=self.name, description=self.description)


class ListBulkCreateInput(ContractModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    items: list[ListCreateInput] = Field(min_length=1, max_length=500)


class ListBulkUpdateItem(ContractModel):
    list_id: str
    patch: ListUpdateInput


class ListBulkUpdateInput(ContractModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    items: list[ListBulkUpdateItem] = Field(min_length=1, max_length=500)


class ListAddContactsInput(ContractModel):
    list_id: str
    contact_ids: list[str] = Field(min_length=1, max_length=500)
    idempotency_key: str | None = None


class ListRemoveContactsInput(ContractModel):
    list_id: str
    contact_ids: list[str] = Field(min_length=1, max_length=500)
    idempotency_key: str | None = None


class ListReplaceContactsInput(ContractModel):
    list_id: str
    contact_ids: list[str] = Field(default_factory=list, max_length=500)
    idempotency_key: str | None = None


class ListBulkMembershipItem(ContractModel):
    list_id: str
    contact_ids: list[str] = Field(min_length=1, max_length=500)


class ListBulkAddContactsInput(ContractModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    items: list[ListBulkMembershipItem] = Field(min_length=1, max_length=500)
