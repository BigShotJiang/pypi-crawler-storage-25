from __future__ import annotations

from enum import StrEnum


class McpScope(StrEnum):
    CONTACTS_READ = "contacts.read"
    CONTACTS_CREATE = "contacts.create"
    CONTACTS_UPDATE = "contacts.update"
    CONTACTS_BULK_CREATE = "contacts.bulk_create"
    CONTACTS_BULK_UPDATE = "contacts.bulk_update"
    LISTS_READ = "lists.read"
    LISTS_CREATE = "lists.create"
    LISTS_UPDATE = "lists.update"
    LISTS_BULK_CREATE = "lists.bulk_create"
    LISTS_BULK_UPDATE = "lists.bulk_update"
    LISTS_MEMBERSHIP_WRITE = "lists.membership.write"


ALL_MCP_SCOPES = tuple(scope.value for scope in McpScope)
