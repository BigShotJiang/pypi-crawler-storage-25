from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ApiKeyIntrospection(ContractModel):
    key_id: str
    workspace_id: str
    actor_user_id: str
    scopes: list[str] = Field(default_factory=list)
    rate_limit_per_minute: int = Field(default=120, ge=1, le=10_000)
    active: bool = True
