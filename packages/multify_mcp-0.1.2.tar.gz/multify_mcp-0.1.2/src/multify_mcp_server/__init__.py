"""Remote streamable HTTP MCP server for Multify workspaces."""

from .app import create_app

DEFAULT_HOSTED_MCP_URL = "https://api.multifyco.com/mcp"

__all__ = ["DEFAULT_HOSTED_MCP_URL", "create_app"]
