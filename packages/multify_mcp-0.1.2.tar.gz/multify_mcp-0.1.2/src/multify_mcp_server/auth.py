from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from multify_mcp_contracts.auth import ApiKeyIntrospection

from .rate_limit import InMemoryRateLimiter


class AuthenticationError(RuntimeError):
    """Raised when a request cannot be authenticated."""


class ScopeError(RuntimeError):
    """Raised when a key is missing a required scope."""


class RateLimitExceededError(RuntimeError):
    """Raised when a key exceeds its configured request budget."""


class AuthGateway(Protocol):
    async def introspect_api_key(self, api_key: str) -> ApiKeyIntrospection: ...


@dataclass(frozen=True, slots=True)
class ApiKeyPrincipal:
    key_id: str
    workspace_id: str
    actor_user_id: str
    scopes: tuple[str, ...]
    rate_limit_per_minute: int

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes


class AuthService:
    def __init__(
        self,
        *,
        auth_gateway: AuthGateway,
        rate_limiter: InMemoryRateLimiter,
        default_rate_limit_per_minute: int = 120,
    ) -> None:
        self._auth_gateway = auth_gateway
        self._rate_limiter = rate_limiter
        self._default_rate_limit_per_minute = default_rate_limit_per_minute

    def build_principal(self, payload: ApiKeyIntrospection) -> ApiKeyPrincipal:
        rate_limit_per_minute = payload.rate_limit_per_minute or self._default_rate_limit_per_minute
        return ApiKeyPrincipal(
            key_id=payload.key_id,
            workspace_id=payload.workspace_id,
            actor_user_id=payload.actor_user_id,
            scopes=tuple(payload.scopes),
            rate_limit_per_minute=rate_limit_per_minute,
        )

    async def authenticate_bearer_token(self, token: str) -> ApiKeyPrincipal:
        if not token.strip():
            raise AuthenticationError("Missing bearer token")

        try:
            payload = await self._auth_gateway.introspect_api_key(token)
        except Exception as exc:  # pragma: no cover - normalized below
            raise AuthenticationError("Invalid API key") from exc

        if not payload.active:
            raise AuthenticationError("Inactive API key")

        principal = self.build_principal(payload)
        subject = f"{principal.workspace_id}:{principal.key_id}"
        if not self._rate_limiter.allow(subject, limit_per_window=principal.rate_limit_per_minute):
            raise RateLimitExceededError("Rate limit exceeded")
        return principal

    def require_scopes(self, principal: ApiKeyPrincipal, required_scopes: list[str]) -> None:
        for scope in required_scopes:
            if not principal.has_scope(scope):
                raise ScopeError(f"Missing required scope: {scope}")


def extract_bearer_token(authorization_header: str | None) -> str | None:
    if not authorization_header:
        return None
    scheme, _, token = authorization_header.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None
    return token.strip()
