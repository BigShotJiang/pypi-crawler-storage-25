from __future__ import annotations

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from time import monotonic


@dataclass
class InMemoryRateLimiter:
    window_seconds: float = 60.0
    clock: Callable[[], float] = monotonic
    _events: dict[str, deque[float]] = field(default_factory=dict)

    def allow(self, subject: str, *, limit_per_window: int) -> bool:
        if limit_per_window <= 0:
            return False

        now = self.clock()
        bucket = self._events.setdefault(subject, deque())
        while bucket and (now - bucket[0]) >= self.window_seconds:
            bucket.popleft()
        if len(bucket) >= limit_per_window:
            return False
        bucket.append(now)
        return True
