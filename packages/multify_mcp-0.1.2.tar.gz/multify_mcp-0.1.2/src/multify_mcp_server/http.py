from __future__ import annotations

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route
from starlette.types import ASGIApp, Receive, Scope, Send

from .auth import AuthenticationError, AuthService, RateLimitExceededError, extract_bearer_token


class McpAuthMiddleware:
    def __init__(self, app: ASGIApp, *, auth_service: AuthService) -> None:
        self._app = app
        self._auth_service = auth_service

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return

        path = scope.get("path", "")
        if not path.startswith("/mcp"):
            await self._app(scope, receive, send)
            return

        headers = {
            key.decode("latin-1"): value.decode("latin-1")
            for key, value in scope.get("headers", [])
        }
        token = extract_bearer_token(headers.get("authorization"))
        if token is None:
            await JSONResponse({"error": "missing_bearer_token"}, status_code=401)(
                scope, receive, send
            )
            return

        try:
            principal = await self._auth_service.authenticate_bearer_token(token)
        except RateLimitExceededError:
            await JSONResponse({"error": "rate_limit_exceeded"}, status_code=429)(
                scope, receive, send
            )
            return
        except AuthenticationError:
            await JSONResponse({"error": "invalid_api_key"}, status_code=401)(scope, receive, send)
            return

        state = scope.setdefault("state", {})
        state["principal"] = principal
        await self._app(scope, receive, send)


async def _health(_: Request) -> JSONResponse:
    return JSONResponse({"ok": True, "service": "multify-mcp"})


def build_http_app(*, mcp_asgi_app: ASGIApp, auth_service: AuthService) -> ASGIApp:
    app = Starlette(
        routes=[
            Route("/health", _health),
            Mount("/mcp", app=mcp_asgi_app),
        ]
    )
    return McpAuthMiddleware(app, auth_service=auth_service)
