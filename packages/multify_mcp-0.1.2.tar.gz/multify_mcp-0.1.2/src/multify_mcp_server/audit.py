from __future__ import annotations

import logging
from typing import Any

from .auth import ApiKeyPrincipal

logger = logging.getLogger("multify_mcp.audit")


class AuditLogger:
    def log_operation(
        self,
        *,
        principal: ApiKeyPrincipal,
        operation_id: str,
        operation_name: str,
        outcome: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        logger.info(
            "mcp_operation",
            extra={
                "operation_id": operation_id,
                "operation_name": operation_name,
                "outcome": outcome,
                "workspace_id": principal.workspace_id,
                "key_id": principal.key_id,
                "actor_user_id": principal.actor_user_id,
                "details": details or {},
            },
        )
