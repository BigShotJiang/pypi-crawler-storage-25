from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .app_client import HttpMultifyAppClient
from .audit import AuditLogger
from .auth import AuthService
from .config import Settings, get_settings
from .http import build_http_app
from .rate_limit import InMemoryRateLimiter
from .tools.contacts import ContactsToolService, register_contacts_tools
from .tools.lists import ListsToolService, register_lists_tools


def create_mcp_server(
    *,
    auth_service: AuthService,
    audit_logger: AuditLogger,
    app_client: HttpMultifyAppClient,
) -> FastMCP:
    mcp = FastMCP(
        "multify",
        instructions=(
            "Operate the authenticated Multify workspace only. "
            "Use read tools to inspect contacts and lists. "
            "Use write tools only when the user asked to mutate CRM data."
        ),
        json_response=True,
    )
    register_contacts_tools(
        mcp=mcp,
        auth_service=auth_service,
        audit_logger=audit_logger,
        service=ContactsToolService(contacts_gateway=app_client),
    )
    register_lists_tools(
        mcp=mcp,
        auth_service=auth_service,
        audit_logger=audit_logger,
        service=ListsToolService(lists_gateway=app_client),
    )
    return mcp


def create_app(*, settings: Settings | None = None):
    resolved_settings = settings or get_settings()
    app_client = HttpMultifyAppClient(resolved_settings)
    auth_service = AuthService(
        auth_gateway=app_client,
        rate_limiter=InMemoryRateLimiter(),
        default_rate_limit_per_minute=resolved_settings.default_rate_limit_per_minute,
    )
    audit_logger = AuditLogger()
    mcp = create_mcp_server(
        auth_service=auth_service,
        audit_logger=audit_logger,
        app_client=app_client,
    )
    return build_http_app(mcp_asgi_app=mcp.streamable_http_app(), auth_service=auth_service)
