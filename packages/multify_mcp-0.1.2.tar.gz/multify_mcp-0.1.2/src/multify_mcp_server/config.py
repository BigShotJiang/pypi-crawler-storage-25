from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="MULTIFY_MCP_",
        env_file=".env",
        extra="ignore",
    )

    service_name: str = "multify-mcp"
    log_level: str = "INFO"
    host: str = "0.0.0.0"
    port: int = 8765
    app_base_url: str = "http://127.0.0.1:8000"
    app_internal_token: str = ""
    request_timeout_seconds: float = 10.0
    default_rate_limit_per_minute: int = 120


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
