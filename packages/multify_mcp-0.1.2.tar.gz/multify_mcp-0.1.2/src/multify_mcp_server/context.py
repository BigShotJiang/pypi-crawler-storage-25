from __future__ import annotations

from mcp.server.fastmcp import Context

from .auth import ApiKeyPrincipal, AuthenticationError


def get_principal_from_context(ctx: Context) -> ApiKeyPrincipal:
    request = ctx.request_context.request
    state = getattr(request, "state", None)
    principal = getattr(state, "principal", None)
    if principal is None:
        raise AuthenticationError("Authenticated principal was not attached to the request")
    return principal
