from __future__ import annotations

from typing import Any

import httpx
from multify_mcp_contracts.auth import ApiKeyIntrospection
from multify_mcp_contracts.operations import (
    BulkOperationResult,
    CollectionOperationResult,
    MembershipOperationResult,
    ResourceOperationResult,
)
from multify_mcp_contracts.resources import (
    ContactBulkCreateInput,
    ContactBulkUpdateInput,
    ContactCreateInput,
    ContactUpdateInput,
    ListAddContactsInput,
    ListBulkAddContactsInput,
    ListBulkCreateInput,
    ListBulkUpdateInput,
    ListCreateInput,
    ListRemoveContactsInput,
    ListReplaceContactsInput,
    ListUpdateInput,
)

from .auth import ApiKeyPrincipal
from .config import Settings


class HttpMultifyAppClient:
    def __init__(self, settings: Settings, *, client: httpx.AsyncClient | None = None) -> None:
        self._settings = settings
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(
            base_url=settings.app_base_url.rstrip("/"),
            timeout=settings.request_timeout_seconds,
        )

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def introspect_api_key(self, api_key: str) -> ApiKeyIntrospection:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/auth/introspect",
            json={"api_key": api_key},
        )
        return ApiKeyIntrospection.model_validate(data)

    async def list_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str | None = None,
    ) -> CollectionOperationResult:
        data = await self._request(
            "GET",
            "/api/internal/mcp/v1/contacts",
            headers=self._service_headers(principal),
            params={"list_id": list_id} if list_id else None,
        )
        return CollectionOperationResult.model_validate(data)

    async def get_contact(
        self, *, principal: ApiKeyPrincipal, contact_id: str
    ) -> ResourceOperationResult:
        data = await self._request(
            "GET",
            f"/api/internal/mcp/v1/contacts/{contact_id}",
            headers=self._service_headers(principal),
        )
        return ResourceOperationResult.model_validate(data)

    async def create_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactCreateInput,
    ) -> ResourceOperationResult:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/contacts",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return ResourceOperationResult.model_validate(data)

    async def update_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        contact_id: str,
        payload: ContactUpdateInput,
    ) -> ResourceOperationResult:
        data = await self._request(
            "PATCH",
            f"/api/internal/mcp/v1/contacts/{contact_id}",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json", exclude_none=True),
        )
        return ResourceOperationResult.model_validate(data)

    async def bulk_create_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        items: list[ContactCreateInput],
        idempotency_key: str,
    ) -> BulkOperationResult:
        payload = ContactBulkCreateInput(idempotency_key=idempotency_key, items=items)
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/contacts:bulkCreate",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return BulkOperationResult.model_validate(data)

    async def bulk_update_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactBulkUpdateInput,
    ) -> BulkOperationResult:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/contacts:bulkUpdate",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return BulkOperationResult.model_validate(data)

    async def list_lists(self, *, principal: ApiKeyPrincipal) -> CollectionOperationResult:
        data = await self._request(
            "GET",
            "/api/internal/mcp/v1/lists",
            headers=self._service_headers(principal),
        )
        return CollectionOperationResult.model_validate(data)

    async def get_list(
        self, *, principal: ApiKeyPrincipal, list_id: str
    ) -> ResourceOperationResult:
        data = await self._request(
            "GET",
            f"/api/internal/mcp/v1/lists/{list_id}",
            headers=self._service_headers(principal),
        )
        return ResourceOperationResult.model_validate(data)

    async def create_list(
        self, *, principal: ApiKeyPrincipal, payload: ListCreateInput
    ) -> ResourceOperationResult:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/lists",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return ResourceOperationResult.model_validate(data)

    async def update_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str,
        payload: ListUpdateInput,
    ) -> ResourceOperationResult:
        data = await self._request(
            "PATCH",
            f"/api/internal/mcp/v1/lists/{list_id}",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json", exclude_none=True),
        )
        return ResourceOperationResult.model_validate(data)

    async def bulk_create_lists(
        self, *, principal: ApiKeyPrincipal, payload: ListBulkCreateInput
    ) -> BulkOperationResult:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/lists:bulkCreate",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return BulkOperationResult.model_validate(data)

    async def bulk_update_lists(
        self, *, principal: ApiKeyPrincipal, payload: ListBulkUpdateInput
    ) -> BulkOperationResult:
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/lists:bulkUpdate",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return BulkOperationResult.model_validate(data)

    async def add_contacts_to_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListAddContactsInput,
    ) -> MembershipOperationResult:
        data = await self._request(
            "POST",
            f"/api/internal/mcp/v1/lists/{payload.list_id}:addContacts",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return MembershipOperationResult.model_validate(data)

    async def remove_contacts_from_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListRemoveContactsInput,
    ) -> MembershipOperationResult:
        data = await self._request(
            "POST",
            f"/api/internal/mcp/v1/lists/{payload.list_id}:removeContacts",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return MembershipOperationResult.model_validate(data)

    async def replace_contacts_in_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListReplaceContactsInput,
    ) -> MembershipOperationResult:
        data = await self._request(
            "POST",
            f"/api/internal/mcp/v1/lists/{payload.list_id}:replaceContacts",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return MembershipOperationResult.model_validate(data)

    async def bulk_add_contacts_to_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        items: list[Any],
        idempotency_key: str,
    ) -> MembershipOperationResult:
        payload = ListBulkAddContactsInput(idempotency_key=idempotency_key, items=items)
        data = await self._request(
            "POST",
            "/api/internal/mcp/v1/lists:bulkAddContacts",
            headers=self._service_headers(principal),
            json=payload.model_dump(mode="json"),
        )
        return MembershipOperationResult.model_validate(data)

    def _service_headers(self, principal: ApiKeyPrincipal) -> dict[str, str]:
        headers = {
            "X-Multify-Workspace-Id": principal.workspace_id,
            "X-Multify-Actor-User-Id": principal.actor_user_id,
            "X-Multify-Key-Id": principal.key_id,
            "X-Multify-Scopes": ",".join(principal.scopes),
        }
        if self._settings.app_internal_token:
            headers["X-Multify-Internal-Key"] = self._settings.app_internal_token
        return headers

    async def _request(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        response = await self._client.request(
            method, path, headers=headers, params=params, json=json
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise RuntimeError(f"Expected dict payload from Multify app, got: {type(payload)!r}")
        return payload
