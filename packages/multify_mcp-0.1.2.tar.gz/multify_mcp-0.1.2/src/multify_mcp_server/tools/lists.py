from __future__ import annotations

from typing import Protocol

from mcp.server.fastmcp import Context, FastMCP
from multify_mcp_contracts.operations import (
    BulkOperationResult,
    CollectionOperationResult,
    MembershipOperationResult,
    ResourceOperationResult,
)
from multify_mcp_contracts.resources import (
    ListAddContactsInput,
    ListBulkAddContactsInput,
    ListBulkCreateInput,
    ListBulkUpdateInput,
    ListCreateInput,
    ListRemoveContactsInput,
    ListReplaceContactsInput,
    ListUpdateInput,
)
from multify_mcp_contracts.scopes import McpScope

from ..audit import AuditLogger
from ..auth import ApiKeyPrincipal, AuthService
from ..context import get_principal_from_context


class ListsGateway(Protocol):
    async def list_lists(self, *, principal: ApiKeyPrincipal) -> CollectionOperationResult: ...

    async def get_list(
        self, *, principal: ApiKeyPrincipal, list_id: str
    ) -> ResourceOperationResult: ...

    async def create_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListCreateInput,
    ) -> ResourceOperationResult: ...

    async def update_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str,
        payload: ListUpdateInput,
    ) -> ResourceOperationResult: ...

    async def bulk_create_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListBulkCreateInput,
    ) -> BulkOperationResult: ...

    async def bulk_update_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListBulkUpdateInput,
    ) -> BulkOperationResult: ...

    async def add_contacts_to_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListAddContactsInput,
    ) -> MembershipOperationResult: ...

    async def remove_contacts_from_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListRemoveContactsInput,
    ) -> MembershipOperationResult: ...

    async def replace_contacts_in_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListReplaceContactsInput,
    ) -> MembershipOperationResult: ...

    async def bulk_add_contacts_to_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        items,
        idempotency_key: str,
    ) -> MembershipOperationResult: ...


class ListsToolService:
    def __init__(self, *, lists_gateway: ListsGateway) -> None:
        self._lists_gateway = lists_gateway

    async def list_lists(self, *, principal: ApiKeyPrincipal) -> CollectionOperationResult:
        return await self._lists_gateway.list_lists(principal=principal)

    async def get_list(
        self, *, principal: ApiKeyPrincipal, list_id: str
    ) -> ResourceOperationResult:
        return await self._lists_gateway.get_list(principal=principal, list_id=list_id)

    async def create_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListCreateInput,
    ) -> ResourceOperationResult:
        return await self._lists_gateway.create_list(principal=principal, payload=payload)

    async def update_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str,
        payload: ListUpdateInput,
    ) -> ResourceOperationResult:
        return await self._lists_gateway.update_list(
            principal=principal,
            list_id=list_id,
            payload=payload,
        )

    async def bulk_create_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListBulkCreateInput,
    ) -> BulkOperationResult:
        return await self._lists_gateway.bulk_create_lists(principal=principal, payload=payload)

    async def bulk_update_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListBulkUpdateInput,
    ) -> BulkOperationResult:
        return await self._lists_gateway.bulk_update_lists(principal=principal, payload=payload)

    async def add_contacts_to_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListAddContactsInput,
    ) -> MembershipOperationResult:
        return await self._lists_gateway.add_contacts_to_list(principal=principal, payload=payload)

    async def remove_contacts_from_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListRemoveContactsInput,
    ) -> MembershipOperationResult:
        return await self._lists_gateway.remove_contacts_from_list(
            principal=principal, payload=payload
        )

    async def replace_contacts_in_list(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListReplaceContactsInput,
    ) -> MembershipOperationResult:
        return await self._lists_gateway.replace_contacts_in_list(
            principal=principal, payload=payload
        )

    async def bulk_add_contacts_to_lists(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ListBulkAddContactsInput,
    ) -> MembershipOperationResult:
        return await self._lists_gateway.bulk_add_contacts_to_lists(
            principal=principal,
            items=payload.items,
            idempotency_key=payload.idempotency_key,
        )


def register_lists_tools(
    *,
    mcp: FastMCP,
    auth_service: AuthService,
    audit_logger: AuditLogger,
    service: ListsToolService,
) -> None:
    async def _with_scope(
        ctx: Context,
        required_scopes: list[str],
    ) -> ApiKeyPrincipal:
        principal = get_principal_from_context(ctx)
        auth_service.require_scopes(principal, required_scopes)
        return principal

    @mcp.tool(
        name="lists_list",
        description="List workspace lists visible to the authenticated workspace.",
    )
    async def lists_list(ctx: Context | None = None) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_READ])
        result = await service.list_lists(principal=principal)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_list",
            outcome="success",
            details={"total": result.total},
        )
        return result.model_dump(mode="json")

    @mcp.tool(name="lists_get", description="Get a single list by ID.")
    async def lists_get(list_id: str, ctx: Context | None = None) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_READ])
        result = await service.get_list(principal=principal, list_id=list_id)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_get",
            outcome="success",
            details={"list_id": list_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(name="lists_create", description="Create a new list in the authenticated workspace.")
    async def lists_create(
        payload: ListCreateInput, ctx: Context | None = None
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_CREATE])
        result = await service.create_list(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_create",
            outcome="success",
            details={"name": payload.name},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="lists_update", description="Update a single list in the authenticated workspace."
    )
    async def lists_update(
        list_id: str,
        payload: ListUpdateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_UPDATE])
        result = await service.update_list(principal=principal, list_id=list_id, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_update",
            outcome="success",
            details={"list_id": list_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="lists_bulk_create", description="Create multiple lists in one idempotent operation."
    )
    async def lists_bulk_create(
        payload: ListBulkCreateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_BULK_CREATE])
        result = await service.bulk_create_lists(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_bulk_create",
            outcome="partial" if result.failed_count else "success",
            details={"total_count": result.total_count, "failed_count": result.failed_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="lists_bulk_update", description="Update multiple lists in one idempotent operation."
    )
    async def lists_bulk_update(
        payload: ListBulkUpdateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_BULK_UPDATE])
        result = await service.bulk_update_lists(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_bulk_update",
            outcome="partial" if result.failed_count else "success",
            details={"total_count": result.total_count, "failed_count": result.failed_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(name="lists_add_contacts", description="Add contacts to a single list.")
    async def lists_add_contacts(
        payload: ListAddContactsInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_MEMBERSHIP_WRITE])
        result = await service.add_contacts_to_list(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_add_contacts",
            outcome="success",
            details={"list_id": payload.list_id, "affected_count": result.affected_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(name="lists_remove_contacts", description="Remove contacts from a single list.")
    async def lists_remove_contacts(
        payload: ListRemoveContactsInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_MEMBERSHIP_WRITE])
        result = await service.remove_contacts_from_list(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_remove_contacts",
            outcome="success",
            details={"list_id": payload.list_id, "affected_count": result.affected_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="lists_replace_contacts",
        description="Replace all list membership with the supplied contact set.",
    )
    async def lists_replace_contacts(
        payload: ListReplaceContactsInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_MEMBERSHIP_WRITE])
        result = await service.replace_contacts_in_list(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_replace_contacts",
            outcome="success",
            details={"list_id": payload.list_id, "affected_count": result.affected_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="lists_bulk_add_contacts",
        description="Add contacts to multiple lists in one idempotent operation.",
    )
    async def lists_bulk_add_contacts(
        payload: ListBulkAddContactsInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.LISTS_MEMBERSHIP_WRITE])
        result = await service.bulk_add_contacts_to_lists(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="lists_bulk_add_contacts",
            outcome="success",
            details={"affected_count": result.affected_count, "list_ids": result.list_ids},
        )
        return result.model_dump(mode="json")
