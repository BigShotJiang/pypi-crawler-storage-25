"""Tool service implementations and MCP registrations."""
