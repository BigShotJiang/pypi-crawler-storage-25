from __future__ import annotations

from typing import Protocol

from mcp.server.fastmcp import Context, FastMCP
from multify_mcp_contracts.operations import (
    BulkOperationResult,
    CollectionOperationResult,
    ResourceOperationResult,
)
from multify_mcp_contracts.resources import (
    ContactBulkCreateInput,
    ContactBulkUpdateInput,
    ContactCreateInput,
    ContactUpdateInput,
)
from multify_mcp_contracts.scopes import McpScope

from ..audit import AuditLogger
from ..auth import ApiKeyPrincipal, AuthService
from ..context import get_principal_from_context


class ContactsGateway(Protocol):
    async def list_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str | None = None,
    ) -> CollectionOperationResult: ...

    async def get_contact(
        self, *, principal: ApiKeyPrincipal, contact_id: str
    ) -> ResourceOperationResult: ...

    async def create_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactCreateInput,
    ) -> ResourceOperationResult: ...

    async def update_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        contact_id: str,
        payload: ContactUpdateInput,
    ) -> ResourceOperationResult: ...

    async def bulk_create_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        items: list[ContactCreateInput],
        idempotency_key: str,
    ) -> BulkOperationResult: ...

    async def bulk_update_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactBulkUpdateInput,
    ) -> BulkOperationResult: ...


class ContactsToolService:
    def __init__(self, *, contacts_gateway: ContactsGateway) -> None:
        self._contacts_gateway = contacts_gateway

    async def list_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        list_id: str | None = None,
    ) -> CollectionOperationResult:
        return await self._contacts_gateway.list_contacts(principal=principal, list_id=list_id)

    async def get_contact(
        self, *, principal: ApiKeyPrincipal, contact_id: str
    ) -> ResourceOperationResult:
        return await self._contacts_gateway.get_contact(principal=principal, contact_id=contact_id)

    async def create_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactCreateInput,
    ) -> ResourceOperationResult:
        return await self._contacts_gateway.create_contact(principal=principal, payload=payload)

    async def update_contact(
        self,
        *,
        principal: ApiKeyPrincipal,
        contact_id: str,
        payload: ContactUpdateInput,
    ) -> ResourceOperationResult:
        return await self._contacts_gateway.update_contact(
            principal=principal,
            contact_id=contact_id,
            payload=payload,
        )

    async def bulk_create_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactBulkCreateInput,
    ) -> BulkOperationResult:
        return await self._contacts_gateway.bulk_create_contacts(
            principal=principal,
            items=payload.items,
            idempotency_key=payload.idempotency_key,
        )

    async def bulk_update_contacts(
        self,
        *,
        principal: ApiKeyPrincipal,
        payload: ContactBulkUpdateInput,
    ) -> BulkOperationResult:
        return await self._contacts_gateway.bulk_update_contacts(
            principal=principal, payload=payload
        )


def register_contacts_tools(
    *,
    mcp: FastMCP,
    auth_service: AuthService,
    audit_logger: AuditLogger,
    service: ContactsToolService,
) -> None:
    async def _with_scope(
        ctx: Context,
        required_scopes: list[str],
    ) -> ApiKeyPrincipal:
        principal = get_principal_from_context(ctx)
        auth_service.require_scopes(principal, required_scopes)
        return principal

    @mcp.tool(
        name="contacts_list",
        description="List contacts visible to the authenticated Multify workspace.",
    )
    async def contacts_list(
        list_id: str | None = None, ctx: Context | None = None
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_READ])
        result = await service.list_contacts(principal=principal, list_id=list_id)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_list",
            outcome="success",
            details={"total": result.total, "list_id": list_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(name="contacts_get", description="Get a single contact by ID.")
    async def contacts_get(contact_id: str, ctx: Context | None = None) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_READ])
        result = await service.get_contact(principal=principal, contact_id=contact_id)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_get",
            outcome="success",
            details={"contact_id": contact_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="contacts_create",
        description="Create a new contact inside the authenticated workspace.",
    )
    async def contacts_create(
        payload: ContactCreateInput, ctx: Context | None = None
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_CREATE])
        result = await service.create_contact(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_create",
            outcome="success",
            details={"list_id": payload.list_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="contacts_update",
        description="Update a single contact inside the authenticated workspace.",
    )
    async def contacts_update(
        contact_id: str,
        payload: ContactUpdateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_UPDATE])
        result = await service.update_contact(
            principal=principal, contact_id=contact_id, payload=payload
        )
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_update",
            outcome="success",
            details={"contact_id": contact_id},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="contacts_bulk_create",
        description="Create multiple contacts in one idempotent operation.",
    )
    async def contacts_bulk_create(
        payload: ContactBulkCreateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_BULK_CREATE])
        result = await service.bulk_create_contacts(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_bulk_create",
            outcome="partial" if result.failed_count else "success",
            details={"total_count": result.total_count, "failed_count": result.failed_count},
        )
        return result.model_dump(mode="json")

    @mcp.tool(
        name="contacts_bulk_update",
        description="Update multiple contacts in one idempotent operation.",
    )
    async def contacts_bulk_update(
        payload: ContactBulkUpdateInput,
        ctx: Context | None = None,
    ) -> dict[str, object]:
        assert ctx is not None
        principal = await _with_scope(ctx, [McpScope.CONTACTS_BULK_UPDATE])
        result = await service.bulk_update_contacts(principal=principal, payload=payload)
        audit_logger.log_operation(
            principal=principal,
            operation_id=result.operation_id,
            operation_name="contacts_bulk_update",
            outcome="partial" if result.failed_count else "success",
            details={"total_count": result.total_count, "failed_count": result.failed_count},
        )
        return result.model_dump(mode="json")
