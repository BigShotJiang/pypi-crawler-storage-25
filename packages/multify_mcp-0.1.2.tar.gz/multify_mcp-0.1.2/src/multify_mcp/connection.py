from __future__ import annotations

from dataclasses import asdict, dataclass
from shlex import join as shell_join
from typing import Literal
from urllib.parse import urlparse

DEFAULT_MULTIFY_MCP_URL = "https://api.multifyco.com/mcp"
DEFAULT_SERVER_NAME = "multify-mcp"
CLAUDE_CODE_SCOPES = ("local", "user", "project")
ClaudeCodeScope = Literal["local", "user", "project"]


@dataclass(frozen=True)
class RemoteMcpConnection:
    name: str
    transport: Literal["http"]
    url: str
    headers: dict[str, str]

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def get_multify_mcp_url(override: str | None = None) -> str:
    normalized = (override or "").strip()
    url = normalized or DEFAULT_MULTIFY_MCP_URL
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("url must be a valid HTTP or HTTPS URL")
    return url


def build_authorization_headers(api_key: str) -> dict[str, str]:
    normalized = api_key.strip()
    if not normalized:
        raise ValueError("api_key must be a non-empty string")
    return {"Authorization": f"Bearer {normalized}"}


def build_remote_mcp_connection(
    api_key: str,
    *,
    server_name: str = DEFAULT_SERVER_NAME,
    url: str | None = None,
) -> RemoteMcpConnection:
    normalized_name = server_name.strip()
    if not normalized_name:
        raise ValueError("server_name must be a non-empty string")
    return RemoteMcpConnection(
        name=normalized_name,
        transport="http",
        url=get_multify_mcp_url(url),
        headers=build_authorization_headers(api_key),
    )


def build_claude_code_add_args(
    api_key: str,
    *,
    scope: ClaudeCodeScope | None = None,
    server_name: str = DEFAULT_SERVER_NAME,
    url: str | None = None,
) -> list[str]:
    if scope is not None and scope not in CLAUDE_CODE_SCOPES:
        raise ValueError(f"scope must be one of: {', '.join(CLAUDE_CODE_SCOPES)}")
    connection = build_remote_mcp_connection(api_key, server_name=server_name, url=url)
    args = ["mcp", "add", "--transport", "http"]
    if scope is not None:
        args.extend(["--scope", scope])
    args.extend(
        [
            connection.name,
            connection.url,
            "--header",
            f"Authorization: {connection.headers['Authorization']}",
        ]
    )
    return args


def build_claude_code_add_command(
    api_key: str,
    *,
    scope: ClaudeCodeScope | None = None,
    server_name: str = DEFAULT_SERVER_NAME,
    url: str | None = None,
) -> str:
    args = build_claude_code_add_args(
        api_key,
        scope=scope,
        server_name=server_name,
        url=url,
    )
    return shell_join(["claude", *args])
