# multify-mcp

Hosted Multify MCP runtime package.

This package is the Python runtime behind the single hosted Multify MCP product. Users should think about it as one MCP server, not as separate contacts/lists MCPs or separate Python packages.

This hosted MCP is client-agnostic. Any remote MCP client that supports HTTP should connect with the same endpoint and the same workspace MCP key.

## Install

```bash
pip install multify-mcp
```

## Hosted usage

Hosted endpoint:

```text
https://api.multifyco.com/mcp
```

Auth header:

```text
Authorization: Bearer YOUR_MULTIFY_MCP_KEY
```

Python helper example:

```python
from multify_mcp import build_remote_mcp_connection

connection = build_remote_mcp_connection("YOUR_MULTIFY_MCP_KEY")

print(connection.url)
print(connection.headers["Authorization"])
print(connection.as_dict())
```

Claude Code example:

```bash
claude mcp add --transport http multify-mcp https://api.multifyco.com/mcp \
  --header "Authorization: Bearer YOUR_MULTIFY_MCP_KEY"
```

The hosted endpoint is fixed on the Multify API host and the user-specific input is only the workspace MCP key.
