import contextvars
import json
import logging
import os
import httpx
from datetime import datetime, timezone
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

logger = logging.getLogger("wayforth-mcp")

VERSION = "0.2.4"

load_dotenv()

API_BASE = os.getenv("WAYFORTH_API_URL", "https://gateway.wayforth.io")
WAYFORTH_API_KEY = os.getenv("WAYFORTH_API_KEY", "")

_PORT = int(os.getenv("PORT", "8080"))
_HOST = os.getenv("HOST", "0.0.0.0")

# Per-request API key extracted by ApiKeyMiddleware (HTTP transports only)
_api_key_var: contextvars.ContextVar[str] = contextvars.ContextVar("wayforth_api_key")


def _get_api_key() -> str:
    """Return the API key for the current request, falling back to env var."""
    try:
        return _api_key_var.get()
    except LookupError:
        return WAYFORTH_API_KEY


class ApiKeyMiddleware:
    """ASGI middleware that extracts WAYFORTH_API_KEY from query params or headers."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            from urllib.parse import parse_qs
            method = scope.get("method", "")
            path = scope.get("path", "")
            query = scope.get("query_string", b"").decode()
            raw_headers = scope.get("headers", [])
            header_keys = [k.decode(errors="replace") for k, _ in raw_headers]
            logger.info("REQUEST: %s %s%s headers=%s", method, path, f"?{query}" if query else "", header_keys)

            qs = parse_qs(query)
            headers = {k.lower(): v for k, v in raw_headers}
            key = (
                qs.get("WAYFORTH_API_KEY", [None])[0]
                or headers.get(b"authorization", b"").decode().removeprefix("Bearer ").strip()
                or headers.get(b"x-api-key", b"").decode()
                or headers.get(b"x-wayforth-api-key", b"").decode()
                or WAYFORTH_API_KEY
            )
            key_source = "query" if qs.get("WAYFORTH_API_KEY") else \
                         "auth-header" if headers.get(b"authorization") else \
                         "x-api-key" if headers.get(b"x-api-key") else \
                         "env"
            logger.info("API_KEY source=%s present=%s", key_source, bool(key))
            token = _api_key_var.set(key)
            try:
                await self.app(scope, receive, send)
            finally:
                _api_key_var.reset(token)
        else:
            await self.app(scope, receive, send)


mcp = FastMCP(
    "wayforth",
    host=_HOST,
    port=_PORT,
    streamable_http_path="/",
    instructions="Search 300+ verified APIs, pay via card or crypto, execute with managed keys. Get your API key at wayforth.io/signup.",
)


@mcp.custom_route("/health", methods=["GET"])
async def health_check(request):
    from starlette.responses import JSONResponse
    return JSONResponse({"status": "ok", "service": "wayforth-mcp"})


@mcp.custom_route("/.well-known/mcp/server-card.json", methods=["GET"])
async def server_card(request):
    from starlette.responses import JSONResponse
    return JSONResponse({
        "name": "wayforth",
        "version": VERSION,
        "description": "The search engine AI agents use to find and pay for APIs. 300+ verified APIs ranked by WayforthRank v2.",
        "icon": "https://wayforth.io/favicon.png",
        "repository": "https://github.com/WayforthOfficial/wayforth",
        "homepage": "https://wayforth.io",
        "license": "BSL-1.1",
        "runtime": "http",
        "url": "https://mcp.wayforth.io",
        "transport": "streamable-http",
        "configSchema": {
            "type": "object",
            "properties": {
                "WAYFORTH_API_KEY": {
                    "type": "string",
                    "description": "Your Wayforth API key — get one free at wayforth.io",
                    "required": True,
                }
            },
        },
    })


@mcp.custom_route("/.well-known/oauth-authorization-server", methods=["GET"])
async def oauth_server(request):
    from starlette.responses import JSONResponse
    return JSONResponse({
        "issuer": "https://mcp.wayforth.io",
        "authorization_endpoint": "https://wayforth.io/login",
        "token_endpoint": "https://wayforth.io/api/token",
        "response_types_supported": ["code"],
    })


TIER_LABELS = {0: "free", 1: "basic", 2: "standard", 3: "premium"}

MEMORY_FILE = os.path.expanduser("~/.wayforth_memory.json")

_MANAGED_SLUGS = {
    "groq", "deepl", "openweather", "newsapi", "serper", "resend",
    "assemblyai", "stability", "tavily", "jina", "alphavantage", "elevenlabs",
}

_CATEGORY_PARAMS = {
    "translation": '{"text": "Hello world", "target_lang": "ES"}',
    "inference": '{"messages": [{"role": "user", "content": "Say hello"}]}',
    "data": '{"q": "New York"}',
    "search": '{"q": "your search query"}',
    "image": '{"prompt": "a futuristic city at night"}',
    "audio": '{"audio_url": "https://assembly.ai/sports_injuries.mp3"}',
    "communication": '{"from": "noreply@wayforth.io", "to": "you@example.com", "subject": "Test", "html": "<p>Hello</p>"}',
    "text-to-speech": '{"text": "Hello, I am your AI assistant.", "voice_id": "21m00Tcm4TlvDq8ikWAM"}',
}

_EXECUTE_NEXT_QUERIES = {
    "groq": ["run code analysis", "summarize a document", "answer a question"],
    "deepl": ["translate to French", "translate to Japanese", "translate to German"],
    "openweather": ["weather in London", "weather in Tokyo", "weather in Paris"],
    "newsapi": ["latest AI news", "crypto news today", "tech startup news"],
    "serper": ["search for competitors", "find API documentation", "search recent papers"],
    "resend": ["send a newsletter", "send a confirmation email", "send an alert"],
    "assemblyai": ["transcribe a podcast", "transcribe a meeting", "transcribe an interview"],
    "stability": ["generate a logo", "generate a landscape", "generate a portrait"],
    "tavily": ["search for AI agent frameworks", "find recent research papers", "search competitor pricing"],
    "jina": ["read a documentation page", "extract content from a blog post", "parse a landing page"],
    "alphavantage": ["get MSFT stock price", "get GOOGL stock price", "get TSLA stock data"],
    "elevenlabs": ["generate audio for a podcast intro", "convert blog post to audio", "create a voice notification"],
}
_EXECUTE_NEXT_DEFAULT = ["search for translation APIs", "search for inference APIs", "search for data APIs"]


def _load_memory() -> dict:
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE) as f:
            return json.load(f)
    return {"services": []}


def _save_memory(data: dict) -> None:
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f, indent=2)


async def _fetch_services(category: str = None, tier_min: int = None, limit: int = 100) -> list[dict] | None:
    """Paginate through /services to collect all results."""
    all_results: list[dict] = []
    offset = 0
    page_size = min(limit, 100)
    params: dict = {"limit": page_size}
    if category:
        params["category"] = category
    if tier_min is not None:
        params["tier"] = tier_min
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            while True:
                params["offset"] = offset
                r = await client.get(f"{API_BASE}/services", params=params)
                r.raise_for_status()
                data = r.json()
                page = data.get("results", [])
                all_results.extend(page)
                if len(all_results) >= limit or len(all_results) >= data.get("total", 0) or not page:
                    break
                offset += page_size
    except Exception:
        return None
    return all_results[:limit]


def _format_ranked_service(idx: int, s: dict) -> str:
    tier = TIER_LABELS.get(s.get("coverage_tier", 0), str(s.get("coverage_tier")))
    price = (s.get("pricing") or {}).get("per_call_usd") or s.get("pricing_usdc")
    price_str = f"${float(price):.4f}/req" if price else "free"
    score = s.get("score", 0)
    reason = s.get("reason", "")
    service_id = s.get("service_id", "")
    sid_line = f"\n   Service ID: {service_id} (use with wayforth_pay)" if service_id else ""
    return (
        f"{idx}. {s['name']} (score: {score}) — Reason: {reason}\n"
        f"   Tier: {tier} | Price: {price_str} | Endpoint: {s.get('endpoint_url', 'N/A')}"
        f"{sid_line}"
    )


def _format_service(s: dict) -> str:
    tier = TIER_LABELS.get(s.get("coverage_tier", 0), str(s.get("coverage_tier")))
    price = (s.get("pricing") or {}).get("per_call_usd") or s.get("pricing_usdc")
    price_str = f"${float(price):.4f}/req" if price else "free"
    return (
        f"**{s['name']}** [{s.get('category', 'unknown')} / tier {tier}]\n"
        f"  {s.get('description') or 'No description'}\n"
        f"  Pricing: {price_str} | Endpoint: {s.get('endpoint_url', 'N/A')}"
    )


# ── Tool 1: run (one-call runtime) ───────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False))
async def wayforth_run(
    intent: str = Field(
        description="Natural language description of what you need. Example: 'translate this text to Spanish', 'get weather in Tokyo', 'search the web for AI news', 'get stock price for AAPL'"
    ),
    input: dict = Field(
        default={},
        description="The actual content to process. Example: {'text': 'Hello world'} for translation, {'city': 'Tokyo'} for weather, {'query': 'AI news'} for search, {'symbol': 'AAPL'} for stocks",
    ),
    category: str = Field(
        default=None,
        description="Optional: filter by service category. Options: translation, inference, data, image, audio, communication",
    ),
    rail: str = Field(
        default="managed",
        description="Payment rail. 'managed' uses Wayforth's keys (recommended, zero setup). 'byok' uses your stored key.",
    ),
) -> str:
    """The Wayforth runtime. One call does everything: searches for the best API,
    picks the top-ranked service by WayforthRank v2, maps your input to the
    service's params, and executes it — returning the result directly.

    Use this instead of wayforth_search + wayforth_execute when you just want the result.
    Supports: translation, weather, news, stock prices, web search, image generation,
    speech-to-text, text-to-speech, email, and 300+ more catalog services.
    """
    api_key = _get_api_key()
    if not api_key:
        return "No API key provided. Get one free at wayforth.io — 100 credits, no card required."

    body: dict = {"intent": intent, "input": input}
    if category or rail != "managed":
        body["preferences"] = {}
        if category:
            body["preferences"]["category"] = category
        if rail != "managed":
            body["preferences"]["rail"] = rail

    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(
                f"{API_BASE}/run",
                headers={"X-Wayforth-API-Key": api_key, "Content-Type": "application/json"},
                json=body,
            )
    except Exception as e:
        return f"Wayforth API is not reachable at {API_BASE}."

    if resp.status_code == 402:
        d = resp.json().get("detail", {})
        return (
            f"Insufficient credits. Balance: {d.get('current_balance_credits', 0)} credits "
            f"({d.get('current_balance_calls', 0)} calls). Top up at wayforth.io/billing"
        )
    if resp.status_code == 422:
        d = resp.json().get("detail", {})
        err = d.get("error", "")
        if err == "missing_param":
            return (
                f"Missing required params for {d.get('service_selected', 'service')}.\n"
                f"Missing: {d.get('missing', [])}\n"
                f"Hint: {d.get('hint', '')}"
            )
        if err == "no_managed_service":
            top = d.get("top_result", {})
            return (
                f"No managed service found for: {intent!r}\n"
                f"Top catalog result: {top.get('name')} (slug: {top.get('slug')})\n"
                f"Add your API key via: POST /call/keys/add"
            )
        return f"Run error 422: {resp.text[:300]}"
    if resp.status_code == 503:
        d = resp.json().get("detail", {})
        fb = d.get("fallback", {})
        msg = d.get("message", "Service unavailable.")
        if fb:
            msg += f" Fallback: try {fb.get('slug')} ({fb.get('message','')})"
        return msg
    if resp.status_code != 200:
        return f"Run error {resp.status_code}: {resp.text[:300]}"

    data = resp.json()
    svc = data.get("service_used", {})
    ctx = data.get("search_context", {})

    return json.dumps({
        "result": data.get("result"),
        "service_used": svc,
        "search_context": ctx,
        "credits_remaining": data.get("credits_remaining"),
        "calls_remaining": data.get("calls_remaining"),
        "execution_ms": data.get("execution_ms"),
    }, indent=2)


# ── Tool 2: execute (direct, slug required) ───────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
async def wayforth_execute(
    service_slug: str = Field(description="Service to call: groq, deepl, openweather, newsapi, serper, resend, assemblyai, stability, tavily, jina, alphavantage, elevenlabs — or any custom slug for BYOK"),
    params: dict = Field(description="Service-specific parameters as a JSON object (e.g. {'text': 'Hello', 'target_lang': 'ES'} for DeepL)"),
    key_source: str = Field(default="managed", description="Key source: 'managed' (use Wayforth's key, default) or 'byok' (use your stored key)"),
) -> str:
    """Execute any API service instantly.
    12 managed services run with zero API keys —
    Wayforth holds the credentials.
    The fastest way to add any API capability
    to your agent.
    """
    api_key = _get_api_key()
    if not api_key:
        return "No API key provided. Get one free at wayforth.io — 100 credits, no card required."
    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(
                f"{API_BASE}/execute",
                headers={"X-Wayforth-API-Key": api_key, "Content-Type": "application/json"},
                json={"service_slug": service_slug, "params": params, "key_source": key_source},
            )
    except Exception as e:
        return f"Wayforth API not reachable: {e}"
    if resp.status_code == 402:
        d = resp.json().get("detail", {})
        return (
            f"Insufficient credits. Balance: {d.get('credits_balance', 0)}, "
            f"needed: {d.get('credits_needed', 0)}. Top up at wayforth.io/dashboard"
        )
    if resp.status_code == 404:
        return resp.json().get("detail", {}).get("error", "Service key not found. Add one at /call/keys/add")
    if resp.status_code != 200:
        detail = resp.json().get("detail", {})
        if isinstance(detail, dict) and detail.get("status") == "error":
            return f"Service error ({service_slug}): {detail.get('error', 'unknown')}"
        return f"Execute error {resp.status_code}: {resp.text[:300]}"
    data = resp.json()
    result_str = json.dumps({
        "service": data.get("service"),
        "result": data.get("result"),
        "credits_deducted": data.get("credits_deducted"),
        "credits_remaining": data.get("credits_remaining"),
        "execution_ms": data.get("execution_ms"),
    }, indent=2)

    credits_ded = data.get("credits_deducted", "?")
    credits_rem = data.get("credits_remaining", "—")
    queries = _EXECUTE_NEXT_QUERIES.get(service_slug, _EXECUTE_NEXT_DEFAULT)
    suggestions = (
        f"\n---\n"
        f"✅ Done · {credits_ded} credit(s) used · {credits_rem} remaining\n\n"
        f"Try next:\n"
        + "".join(f'- wayforth_search("{q}")\n' for q in queries)
        + "---"
    )
    return result_str + suggestions


# ── Tool 2: search ───────────────────────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_search(
    query: str = Field(description="Natural language description of the API service you need (e.g. 'translate text to Spanish', 'generate images')"),
    limit: int = Field(default=5, description="Number of results to return (1–20)"),
    tier_min: int = Field(default=2, description="Minimum coverage tier: 0=all, 1=tested, 2=verified (default), 3=premium"),
    category: str = Field(default=None, description="Optional category filter: inference, data, translation, image, code, audio, embeddings"),
) -> str:
    """Search 300+ verified APIs ranked by
    WayforthRank — real agent payment signals,
    not ads. Use this when you don't know
    which service to execute.
    """
    params = {"q": query, "limit": min(limit, 20), "tier": tier_min}
    if category:
        params["category"] = category
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(f"{API_BASE}/search", params=params)
            r.raise_for_status()
            data = r.json()
    except Exception:
        return f"Wayforth API is not reachable at {API_BASE}."

    results = data.get("results", [])
    if not results:
        return f"No services found for '{query}'. Try broader terms or set tier_min=0."

    lines = [f"Found {len(results)} services for '{query}':\n"]
    for i, svc in enumerate(results, 1):
        tier = svc.get("coverage_tier", 0)
        tier_label = "✅ Tier 2 Verified" if tier >= 2 else f"Tier {tier}"
        price = (svc.get("pricing") or {}).get("per_call_usd") or svc.get("pricing_usdc")
        price_str = f"${float(price):.6f}/req" if price else "Free"
        wri = svc.get("wri", "N/A")
        wayforth_id = svc.get("wayforth_id", "")
        lines.append(
            f"{i}. {svc['name']} — Score: {svc.get('score', 0)}/100 | WRI: {wri} | {tier_label}\n"
            f"   {svc.get('reason', svc.get('description', ''))[:120]}\n"
            f"   Price: {price_str} | ID: {wayforth_id}\n"
            f"   To pay: wayforth_pay(service_id='{svc.get('service_id', '')}', ...)\n"
        )

    lines.append(f"\nQuery ID: {data.get('query_id', '')} (use in wayforth_pay for conversion tracking)")

    top = results[0]
    wayforth_id = top.get("wayforth_id", "")
    slug = wayforth_id.split("://")[1].split("/")[0] if "://" in wayforth_id else top.get("service_id", "unknown")
    top_name = top.get("name", "")
    top_wri = top.get("wri", "N/A")
    cat_key = (top.get("category") or "").lower().split("/")[0]
    raw_credits = data.get("credits_remaining") or data.get("credits_balance")

    if slug in _MANAGED_SLUGS:
        example_params = _CATEGORY_PARAMS.get(cat_key, "{}")
        credits_per_call = (top.get("pricing") or {}).get("credits_per_call", 1)
        credits_line = (
            f"💳 Cost: {credits_per_call} credit(s) · You have {raw_credits} remaining."
            if raw_credits is not None
            else f"💳 Cost: {credits_per_call} credit(s) · Check balance at wayforth.io/dashboard"
        )
        next_step = (
            f"\n---\n"
            f"⚡ Top pick: {top_name} (WRI: {top_wri})\n\n"
            f"Run this to execute instantly:\n"
            f'wayforth_execute(\n'
            f'  service_slug="{slug}",\n'
            f'  params={example_params},\n'
            f'  key_source="managed"\n'
            f')\n\n'
            f"{credits_line}\n"
            f"---"
        )
    else:
        next_step = (
            f"\n---\n"
            f"⚡ Top pick: {top_name} (WRI: {top_wri})\n\n"
            f"To execute this service, add your own API key:\n"
            f'wayforth_keys(\n'
            f'  action="add",\n'
            f'  service_slug="{slug}",\n'
            f'  service_name="{top_name}",\n'
            f'  api_key_value="your_api_key_here"\n'
            f')\n'
            f'Then call: wayforth_execute(service_slug="{slug}",\n'
            f'                            params={{...}},\n'
            f'                            key_source="byok")\n\n'
            f'Or search for a managed alternative:\n'
            f'wayforth_search("{cat_key} API managed")\n'
            f"---"
        )

    lines.append(next_step)
    return "\n".join(lines)


# ── Tool 3: query (WayforthQL) ───────────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_query(
    query: str = Field(description="Natural language query describing the API you need (e.g. 'fast cheap translation', 'image generation under $0.01')"),
    tier_min: int = Field(default=2, description="Minimum coverage tier: 0=all, 1=tested, 2=verified (default), 3=premium"),
    category: str = Field(default=None, description="Filter by category: inference, translation, data, search, audio, image, etc."),
    price_max: float = Field(default=None, description="Maximum price per API call in USD (e.g. 0.001 for $0.001/call)"),
    protocol: str = Field(default=None, description="Payment protocol filter (e.g. 'x402' for HTTP 402 native services)"),
    sort_by: str = Field(default="wri", description="Sort order: 'wri' (WayforthRank score, default), 'price' (cheapest first), 'tier' (highest tier first)"),
    limit: int = Field(default=5, description="Number of results to return (1–50)"),
    x402_only: bool = Field(default=False, description="When true, return only x402-native services"),
    provider: str = Field(default=None, description="Filter by provider name substring (e.g. 'openai', 'google')"),
    verified_only: bool = Field(default=False, description="When true, return only tier-2+ verified services"),
    offset: int = Field(default=0, description="Pagination offset — skip this many results"),
) -> str:
    """Structured service discovery using WayforthQL v2.
    More precise than wayforth_search — supports price caps, protocol filters,
    x402-only, provider filtering, and explicit sort order.
    Use when you need deterministic filtering rather than pure semantic ranking.
    """
    api_key = _get_api_key()
    if not api_key:
        return "No API key provided. Get one free at wayforth.io — 100 credits, no card required."
    body: dict = {
        "query": query,
        "tier_min": tier_min,
        "limit": limit,
        "sort_by": sort_by,
        "x402_only": x402_only,
        "verified_only": verified_only,
        "offset": offset,
    }
    if category:
        body["category"] = category
    if price_max is not None:
        body["price_max"] = price_max
    if protocol:
        body["protocol"] = protocol
    if provider:
        body["provider"] = provider
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"{API_BASE}/query",
                headers={"X-Wayforth-API-Key": api_key, "Content-Type": "application/json"},
                json=body,
            )
    except Exception as e:
        return f"Wayforth API not reachable: {e}"
    if resp.status_code == 402:
        d = resp.json().get("detail", {})
        return f"Insufficient credits. Balance: {d.get('balance', 0)}. Top up at wayforth.io/dashboard"
    if resp.status_code != 200:
        return f"WayforthQL error {resp.status_code}: {resp.text[:300]}"
    data = resp.json()
    results = data.get("results", [])
    if not results:
        return "No services matched your WayforthQL query. Try relaxing tier_min or price_max."
    lines = [f"WayforthQL results for: {query!r}\n"]
    for i, s in enumerate(results, 1):
        lines.append(_format_ranked_service(i, s))
    lines.append(f"\n{len(results)} result(s) · offset: {data.get('offset', 0)} · protocol: {data.get('protocol', 'WayforthQL/2.0')}")
    return "\n".join(lines)


# ── Tool 4: pay ──────────────────────────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
async def wayforth_pay(
    service_id: str = Field(description="Service ID from wayforth_search results (e.g. 'wayforth://deepl/...')"),
    amount_usd: float = Field(description="Amount to pay in USD (e.g. 0.001)"),
    track: str = Field(default="card", description="Payment track: 'card' (Stripe Treasury credits) or 'crypto' (Base USDC, non-custodial)"),
    query_id: str = Field(default=None, description="Optional query ID from wayforth_search for conversion tracking"),
) -> str:
    """
    Pay for a service through Wayforth.

    Two payment tracks:

    track='card' (default — no crypto needed):
      - Deducts from your Wayforth credit balance
      - Stripe Treasury processes the payment to the service
      - Get credits at wayforth.io/dashboard → Billing → Card Track

    track='crypto' (non-custodial — your wallet):
      - Returns Base calldata for you to broadcast
      - Your USDC, your wallet, fully on-chain
      - Non-custodial — Wayforth never holds your funds

    Routing fee: 1.5% on all tracks
    30% of fee allocated to $WAYF burn

    Args:
        service_id: Service to pay (from wayforth_search results)
        amount_usd: Amount to pay in USD (e.g. 0.001)
        track: Payment track — 'card' or 'crypto' (default: 'card')
        query_id: Optional query ID from wayforth_search for WayforthRank signal
    """
    api_key = _get_api_key()
    if not api_key:
        return "No API key provided. Get one free at wayforth.io — 100 credits, no card required."

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            f"{API_BASE}/pay",
            headers={
                "X-Wayforth-API-Key": api_key,
                "Content-Type": "application/json",
            },
            json={
                "service_id": service_id,
                "amount_usd": amount_usd,
                "track": track,
                "query_id": query_id,
            },
        )

    if resp.status_code == 402:
        data = resp.json().get("detail", {})
        balance = data.get("credits_balance", 0)
        needed = data.get("credits_needed", 0)
        return (
            f"Insufficient credits for card track.\n"
            f"Balance: {balance} credits. Needed: {needed} credits.\n"
            f"Top up at wayforth.io/dashboard\n"
            f"Or switch to crypto track: wayforth_pay('{service_id}', {amount_usd}, track='crypto')"
        )

    if resp.status_code != 200:
        return f"Payment error {resp.status_code}: {resp.text[:200]}"

    data = resp.json()
    payment_track = data.get("payment_track", "unknown")
    service_name = data.get("service_name", service_id)
    routing_fee = data.get("routing_fee_usd", 0)
    burn = data.get("wayf_burn_allocation_usd", 0)

    if payment_track == "card":
        credits_left = data.get("credits_remaining", 0)
        tx_ref = data.get("tx_ref", "")
        return (
            f"Card payment processed — {service_name}\n\n"
            f"Amount: ${amount_usd}\n"
            f"Routing fee (1.5%): ${routing_fee}\n"
            f"$WAYF burn allocation: ${burn}\n"
            f"Credits deducted: {data.get('credits_deducted', 0)}\n"
            f"Credits remaining: {credits_left}\n"
            f"Reference: {tx_ref}"
        )

    if payment_track == "crypto":
        return (
            f"Crypto calldata ready — {service_name}\n\n"
            f"Amount: ${amount_usd} USDC\n"
            f"Routing fee (1.5%): ${routing_fee}\n"
            f"$WAYF burn allocation: ${burn}\n"
            f"Network: Base Sepolia\n\n"
            f"Step 1 — Approve USDC:\n{data.get('approve_calldata', '')}\n\n"
            f"Step 2 — Route payment:\n{data.get('payment_calldata', '')}\n\n"
            f"Broadcast both transactions from your wallet."
        )

    if payment_track == "x402":
        return (
            f"x402 payment ready — {service_name}\n\n"
            f"Amount: ${amount_usd} USDC\n"
            f"Routing fee (1.5%): ${routing_fee}\n"
            f"Protocol: x402 via Coinbase facilitator\n\n"
            f"Use x402 client library to complete payment."
        )

    return f"Payment processed: {data}"


# ── Tool 5: keys ─────────────────────────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
async def wayforth_keys(
    action: str = Field(description="Action to perform: 'list' (show stored keys), 'add' (store a new key), or 'delete' (remove a key)"),
    service_slug: str = Field(default=None, description="Service identifier slug (required for 'add'/'delete'), e.g. 'openai', 'anthropic', 'stripe'"),
    api_key_value: str = Field(default=None, description="The API key to encrypt and store (required for action='add')"),
    service_name: str = Field(default=None, description="Human-readable label for the service (optional for 'add', defaults to service_slug)"),
) -> str:
    """Manage BYOK (Bring Your Own Key) stored service keys.
    Store encrypted API keys for any service and call them via wayforth_execute with key_source='byok'.
    Keys are encrypted at rest with AES-128 and never returned in plaintext.
    """
    wayforth_key = _get_api_key()
    if not wayforth_key:
        return "No API key provided. Get one free at wayforth.io — 100 credits, no card required."
    headers = {"X-Wayforth-API-Key": wayforth_key, "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            if action == "list":
                resp = await client.get(f"{API_BASE}/call/keys", headers=headers)
                if resp.status_code != 200:
                    return f"Error listing keys: {resp.status_code} {resp.text[:200]}"
                data = resp.json()
                keys = data.get("service_keys", [])
                if not keys:
                    return "No BYOK keys stored. Use action='add' to store one."
                lines = [f"{len(keys)} stored key(s):\n"]
                for k in keys:
                    last = k.get("last_used_at") or "never"
                    lines.append(
                        f"  {k['service_slug']} ({k.get('service_name', '')}) "
                        f"— preview: {k.get('key_preview', '???')} "
                        f"— calls: {k.get('total_calls', 0)} — last used: {last}"
                    )
                lines.append("\nCall with: wayforth_execute(service_slug=..., key_source='byok')")
                return "\n".join(lines)

            elif action == "add":
                if not service_slug or not api_key_value:
                    return "Error: service_slug and api_key_value are required for action='add'"
                resp = await client.post(
                    f"{API_BASE}/call/keys/add",
                    headers=headers,
                    json={"service_slug": service_slug, "service_name": service_name or service_slug, "api_key": api_key_value},
                )
                if resp.status_code != 200:
                    return f"Error storing key: {resp.status_code} {resp.text[:200]}"
                data = resp.json()
                return (
                    f"Key stored for '{service_slug}' · preview: {data.get('key_preview', '???')}\n"
                    f"Call it: wayforth_execute(service_slug='{service_slug}', params={{...}}, key_source='byok')"
                )

            elif action == "delete":
                if not service_slug:
                    return "Error: service_slug is required for action='delete'"
                resp = await client.delete(f"{API_BASE}/call/keys/{service_slug}", headers=headers)
                if resp.status_code == 404:
                    return f"No active key found for '{service_slug}'"
                if resp.status_code != 200:
                    return f"Error deleting key: {resp.status_code} {resp.text[:200]}"
                return f"Key for '{service_slug}' deactivated."

            else:
                return "Error: action must be 'list', 'add', or 'delete'"
    except Exception as e:
        return f"Wayforth API not reachable: {e}"


# ── Tools 6+: supporting tools ───────────────────────────────────────────────

@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_list(
    category: str = Field(default=None, description="Filter by category: inference, data, translation, image, code, audio, embeddings"),
    tier_min: int = Field(default=2, description="Minimum coverage tier: 0=all, 1=tested, 2=verified (default), 3=premium"),
    limit: int = Field(default=10, description="Number of services to return (1–100)"),
) -> str:
    """Browse the Wayforth service catalog."""
    services = await _fetch_services(category=category, tier_min=tier_min, limit=limit)
    if services is None:
        return f"Wayforth API is not reachable at {API_BASE}."

    if not services:
        return "No services found" + (f" in category '{category}'" if category else "")

    header = "Wayforth services" + (f" — category: {category}" if category else "")
    lines = [f"{header} ({len(services)} total):\n"]
    lines += [_format_service(s) for s in services]
    return "\n\n".join(lines)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_stats() -> str:
    """Get current Wayforth catalog statistics."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{API_BASE}/stats")
            r.raise_for_status()
            data = r.json()
    except Exception:
        return f"Wayforth API is not reachable at {API_BASE}."

    total = data.get("total_services", 0)
    by_tier = data.get("by_tier", {})
    by_category = data.get("by_category", {})
    last_updated = data.get("last_updated", "unknown")
    tier2_count = by_tier.get("2", 0)

    tier_lines = "\n".join(
        f"  Tier {t} ({TIER_LABELS.get(int(t), '?')}): {count}"
        for t, count in sorted(by_tier.items(), key=lambda x: int(x[0]))
    )
    cat_lines = "\n".join(
        f"  {cat}: {count}" for cat, count in sorted(by_category.items())
    )

    return (
        f"Wayforth catalog: {total:,} services total\n"
        f"{tier2_count} Tier 2 (executable)\n\n"
        f"By tier:\n{tier_lines}\n\n"
        f"By category:\n{cat_lines}\n\n"
        f"Last updated: {last_updated}"
    )


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_status() -> str:
    """Return API health and catalog statistics."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            health_r = await client.get(f"{API_BASE}/health")
            health = health_r.json().get("status", "unknown") if health_r.status_code == 200 else "degraded"
            stats_r = await client.get(f"{API_BASE}/stats")
            stats_r.raise_for_status()
            data = stats_r.json()
    except Exception:
        return f"API health: UNREACHABLE ({API_BASE})"

    total = data.get("total_services", 0)
    by_category = data.get("by_category", {})
    by_tier = data.get("by_tier", {})

    cat_lines = "\n".join(
        f"  {cat}: {count}" for cat, count in sorted(by_category.items())
    )
    tier_lines = "\n".join(
        f"  tier {t} ({TIER_LABELS.get(int(t), '?')}): {count}"
        for t, count in sorted(by_tier.items(), key=lambda x: int(x[0]))
    )

    return (
        f"API health: {health} ({API_BASE})\n"
        f"Total services: {total}\n\n"
        f"By category:\n{cat_lines}\n\n"
        f"By tier:\n{tier_lines}"
    )


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
async def wayforth_remember(
    service_id: str = Field(description="Service ID or wayforth:// identifier from search results"),
    service_name: str = Field(description="Human-readable name of the service to save"),
    note: str = Field(default="", description="Optional note about why you saved this service"),
    agent_id: str = Field(default="", description="Agent identifier (wallet address or session ID) for cross-session persistence"),
) -> str:
    """Save a service to agent memory for quick access later."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.post(
                f"{API_BASE}/memory",
                json={"service_id": service_id, "service_name": service_name, "note": note, "agent_id": agent_id},
            )
            r.raise_for_status()
            data = r.json()
            return f"Saved '{data['service_name']}' to memory (persisted in Wayforth DB)."
    except Exception:
        # Fallback to local file if API unavailable
        mem = _load_memory()
        mem["services"] = [s for s in mem["services"] if s["service_id"] != service_id]
        mem["services"].append({
            "service_id": service_id,
            "service_name": service_name,
            "note": note,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        })
        _save_memory(mem)
        return f"Saved '{service_name}' to local memory (API unavailable). You have {len(mem['services'])} saved service(s)."


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_recall(
    query: str = Field(default="", description="Optional filter to search saved services by name or note"),
    agent_id: str = Field(default="", description="Agent identifier used when saving — required for cross-session memory retrieval"),
) -> str:
    """Recall services previously saved to memory."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            params: dict = {}
            if agent_id:
                params["agent_id"] = agent_id
            if query:
                params["q"] = query
            r = await client.get(f"{API_BASE}/memory", params=params)
            r.raise_for_status()
            data = r.json()
            services = data.get("services", [])
            if not services:
                return "No saved services found. Use wayforth_search to find services and wayforth_remember to save them."
            lines = [f"- {s['service_name']} ({s['service_id']}) — {s.get('note', 'no note')}" for s in services]
            return f"Your saved services ({len(services)}):\n" + "\n".join(lines)
    except Exception:
        # Fallback to local file if API unavailable
        mem = _load_memory()
        services = mem["services"]
        if query:
            q = query.lower()
            services = [s for s in services if q in s["service_name"].lower() or q in s.get("note", "").lower()]
        if not services:
            return "No saved services found. Use wayforth_search to find services and wayforth_remember to save them."
        lines = [f"- {s['service_name']} ({s['service_id']}) — {s.get('note', 'no note')}" for s in services]
        return f"Your saved services ({len(services)}) [local fallback]:\n" + "\n".join(lines)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_similar(
    service_id: str = Field(description="Service ID or wayforth:// identifier to find co-used services for"),
) -> str:
    """Find services similar to or commonly used alongside a given service.
    Returns co-usage patterns from real agent behavior.
    """
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{API_BASE}/graph/{service_id}")
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        return f"Could not fetch graph for {service_id}: {e}"

    related = data.get("related_services", [])
    if not related:
        return f"No co-usage data found for service {service_id}."

    lines = [f"Services co-used with {service_id}:"]
    for svc in related:
        lines.append(
            f"  • {svc['name']} ({svc.get('category', '')}) — {svc.get('co_search_count', 0)} co-searches"
        )
    return "\n".join(lines)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_identity(
    agent_id: str = Field(description="Your unique agent identifier — wallet address or any stable session ID"),
) -> str:
    """Get or create your agent identity on Wayforth.
    Returns your trust score, reputation tier, and usage history.
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        r = await client.get(f"{API_BASE}/identity/{agent_id}")
        if r.status_code == 200:
            d = r.json()
            return (
                f"Agent Identity: {d['agent_id'][:16]}...\n"
                f"Trust Score: {d['trust_score']}/100 ({d['reputation_tier']})\n"
                f"Searches: {d['total_searches']} | Payments: {d['total_payments']}\n"
                f"Member since: {d['member_since'][:10]}"
            )
        r2 = await client.post(
            f"{API_BASE}/identity/register",
            json={"agent_id": agent_id},
        )
        d2 = r2.json()
        return f"New identity registered. Trust score: {d2['trust_score']}/100. Start searching to build reputation."


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False))
async def wayforth_quickstart() -> str:
    """
    Get the Wayforth developer quickstart guide.
    Returns step-by-step instructions for using Wayforth in an agent.
    """
    return """Wayforth — Discovery and Payment Rail for AI Agents

STEP 1 — Install (one time):
  uvx wayforth-mcp
  # or: claude mcp add wayforth -- uvx wayforth-mcp

  Set your API key:
  export WAYFORTH_API_KEY=wf_live_...
  (Get free key at wayforth.io/dashboard)

STEP 2 — Execute instantly (12 managed services, no API keys needed):
  wayforth_execute(
    service_slug="deepl",
    params={"text": "Hello world", "target_lang": "ES"},
    key_source="managed"
  )
  → {"translated_text": "Hola mundo", ...}

STEP 3 — Discover (when you don't know which service to use):
  wayforth_search("translate text to Spanish")
  → DeepL        WRI:82  Tier 2  $0.00003/call
  → LibreTranslate  WRI:71  Tier 2  Free

STEP 4 — Pay (choose your track):

  Card track (no crypto needed):
    wayforth_pay("deepl", 0.001, track="card")
    → Credits deducted, Stripe Treasury pays service

  Crypto track (your wallet, non-custodial):
    wayforth_pay("deepl", 0.001, track="crypto")
    → Returns Base calldata → broadcast from your wallet

PAYMENT SETUP:
  Card:   wayforth.io/dashboard → Billing → Card Track → Add card
  Crypto: Fund a Base wallet with USDC, connect at wayforth.io/dashboard

CREDITS (for search quota):
  1 credit = $0.001 USD
  100 free on signup
  Buy more: $19/50K · $99/300K · $299/1M

ROUTING FEE: 1.5% flat on all payments

300+ verified APIs · 256 Tier 2 · 18 categories

All tools (in recommended order):
  wayforth_execute     — call 12 managed services instantly (no API key needed)
  wayforth_search      — semantic service discovery
  wayforth_query       — WayforthQL v2 structured discovery (tier/price/x402/provider filters)
  wayforth_pay         — pay via card or crypto (dual-track)
  wayforth_keys        — manage BYOK encrypted service keys
  wayforth_list        — browse catalog with filters
  wayforth_similar     — co-used services (Service Graph)
  wayforth_identity    — agent trust score and reputation
  wayforth_remember    — save a service to agent memory
  wayforth_recall      — retrieve saved services
  wayforth_stats       — catalog statistics
  wayforth_status      — API health check
  wayforth_quickstart  — this guide
"""


def _fetch_credits_sync() -> int | None:
    api_key = os.getenv("WAYFORTH_API_KEY", "")
    if not api_key:
        return None
    try:
        with httpx.Client(timeout=5.0) as client:
            r = client.get(
                f"{API_BASE}/keys/usage",
                headers={"X-Wayforth-API-Key": api_key},
            )
            if r.status_code == 200:
                d = r.json()
                return d.get("credits_balance") or d.get("credits_remaining")
    except Exception:
        pass
    return None


def main():
    import sys
    import argparse

    parser = argparse.ArgumentParser(description="Wayforth MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default=os.getenv("MCP_TRANSPORT", "stdio"),
        help="Transport to use: stdio (default), sse, or streamable-http",
    )
    args, _ = parser.parse_known_args()

    banner = (
        "╔════════════════════════════════════════╗\n"
        "║         WAYFORTH MCP SERVER            ║\n"
        "║   Execute · Search · Pay · Repeat      ║\n"
        "╚════════════════════════════════════════╝"
    )
    print(banner, file=sys.stderr)

    if args.transport != "stdio":
        print(f"\nTransport: {args.transport}  host={_HOST}  port={_PORT}", file=sys.stderr)

    api_key = os.getenv("WAYFORTH_API_KEY", "")
    if api_key:
        if args.transport == "stdio":
            credits = _fetch_credits_sync()
            if credits is not None:
                print(f"\nYour credits: {credits} · wayforth.io/dashboard", file=sys.stderr)
            else:
                print("\nCredits unavailable · wayforth.io/dashboard", file=sys.stderr)
            print(
                '\nStart here:\n'
                '  wayforth_execute(service_slug="deepl",\n'
                '                   params={"text": "Hello", "target_lang": "ES"},\n'
                '                   key_source="managed")\n\n'
                'Or discover new services:\n'
                '  wayforth_search("translate text to Spanish")\n\n'
                'Need more credits? → wayforth.io/pricing\n',
                file=sys.stderr,
            )
    else:
        print(
            '\n  Set your API key: export WAYFORTH_API_KEY=wf_live_...\n'
            '  Get one free at: wayforth.io/signup\n',
            file=sys.stderr,
        )

    if args.transport in ("sse", "streamable-http"):
        # Wrap the Starlette app with ApiKeyMiddleware so query-param keys work
        import anyio
        import uvicorn
        if args.transport == "streamable-http":
            starlette_app = mcp.streamable_http_app()
        else:
            starlette_app = mcp.sse_app()
        config = uvicorn.Config(
            ApiKeyMiddleware(starlette_app),
            host=_HOST,
            port=_PORT,
            log_level="info",
        )
        anyio.run(uvicorn.Server(config).serve)
    else:
        mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
