"""Calibration for IMU sensors."""

import argparse
import time
from pathlib import Path

from loguru import logger

from imu_python.base_classes import IMUSensorTypes
from imu_python.calibration.ellipsoid_fitting import FittingAlgorithmNames
from imu_python.calibration.mag_calibration import MagCalibration
from imu_python.definitions import (
    DEFAULT_LOG_LEVEL,
    LogLevel,
)
from imu_python.factory import IMUFactory
from imu_python.sensor_manager import IMUManager
from imu_python.utils import setup_logger


def has_magnetometer(manager: IMUManager) -> bool:  # pragma: no cover
    """Check if the IMUManager has a magnetometer sensor.

    :param manager: IMUManager instance
    :return: True if magnetometer is present, False otherwise
    """
    return IMUSensorTypes.mag in manager.imu_wrapper.role_to_device_map


def collect_calibration_data() -> list[Path]:  # pragma: no cover
    """Collect magnetometer calibration data of all connected IMUs and save to files.

    :return: List of paths to the saved calibration data files.
    """
    sensor_managers = IMUFactory.detect_and_create(
        free_threading=True,
        log_data=True,
        calibration_mode=True,
    )

    files = []
    if len(sensor_managers) == 0:
        logger.info("No devices detected")
        return files

    for manager in sensor_managers:
        if has_magnetometer(manager):
            manager.start()

    logger.info("Started magnetometer calibration. Press ctrl+C to stop.")
    try:
        while True:
            time.sleep(0.1)
    except KeyboardInterrupt:
        for manager in sensor_managers:
            file = manager.stop()
            if file is not None:
                files.append(file)

        time.sleep(1.0)  # wait for file write
        return files


def main(
    log_level: str,
    stderr_level: str,
    algorithm: str,
    filepath: Path | None = None,
):  # pragma: no cover
    """Run magnetometer calibration.

    :param log_level: Log level for logger.
    :param stderr_level: Std err level for logger.
    :param filepath: Optional path to IMU data file for calibration.
    :param algorithm: The ellipsoid fitting algorithm to use.
    """
    setup_logger(
        log_level=log_level, stderr_level=stderr_level, filename="calibration_log"
    )

    if filepath:
        MagCalibration(filepath=filepath, algorithm=algorithm)
    else:
        cal_files = collect_calibration_data()

        # Iterate through files in the calibration directory and calculate calibration
        for cal_file in cal_files:
            MagCalibration(filepath=cal_file, algorithm=algorithm)


if __name__ == "__main__":  # pragma: no cover
    parser = argparse.ArgumentParser("Run the pipeline.")
    parser.add_argument(
        "--log-level",
        "-l",
        default=DEFAULT_LOG_LEVEL,
        choices=list(LogLevel()),
        help="Set the log level.",
        type=str,
    )
    parser.add_argument(
        "--stderr-level",
        "-s",
        default=DEFAULT_LOG_LEVEL,
        choices=list(LogLevel()),
        help="Set the std err level.",
        type=str,
    )
    parser.add_argument(
        "--filepath",
        "-f",
        type=Path,
        help="Path to the IMU data file for calibration.",
    )
    parser.add_argument(
        "--algorithm",
        "-a",
        type=str,
        default=FittingAlgorithmNames.LS,
        choices=list(a for a in FittingAlgorithmNames),
        help="The ellipsoid fitting algorithm to use",
    )
    args = parser.parse_args()

    main(
        log_level=args.log_level,
        stderr_level=args.stderr_level,
        filepath=args.filepath,
        algorithm=args.algorithm,
    )
