# adaline-client

Official Python SDK for [Adaline](https://adaline.ai) - Prompt management, testing, evaluation, and monitoring.

## Installation

```bash
pip install adaline-client
```

## Usage

```python
import asyncio
from adaline import Adaline

async def main():
    # Initialize client (reads ADALINE_API_KEY and ADALINE_BASE_URL from environment)
    client = Adaline()

    # Get latest deployment
    deployment = await client.get_latest_deployment(
        prompt_id="your-prompt-id",
        deployment_environment_id="your-env-id"
    )
    print(f"Model: {deployment.prompt.config.model}")

    # Close the client
    await client.client.close()

asyncio.run(main())
```

## Environment Variables

- `ADALINE_API_KEY` - Your Adaline API key
- `ADALINE_BASE_URL` - API base URL (defaults to `https://api.adaline.ai/v2`)

## Requirements

- Python >= 3.11

## License

MIT
