import re
from typing import Union, Dict

from adaline_api.models.prompt_snapshot import PromptSnapshot
from adaline_api.models.message_content import MessageContent
from adaline_api.models.text_content import TextContent
from adaline_api.models.image_content import ImageContent
from adaline_api.models.pdf_content import PdfContent

ContentVariable = Union[ImageContent, PdfContent]
VariableValue = Union[str, ContentVariable]

PLACEHOLDER_PATTERN = re.compile(r"\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}")
EXACT_PLACEHOLDER_PATTERN = re.compile(r"^\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}$")


def _is_content_variable(value: VariableValue) -> bool:
    return isinstance(value, (ImageContent, PdfContent))


def inject_variables(
    *,
    prompt: PromptSnapshot,
    variables: Dict[str, VariableValue],
) -> PromptSnapshot:
    prompt = prompt.model_copy(deep=True)

    text_vars: Dict[str, str] = {}
    content_vars: Dict[str, ContentVariable] = {}

    for name, value in variables.items():
        if _is_content_variable(value):
            content_vars[name] = value
        else:
            text_vars[name] = value

    for message in prompt.messages:
        new_content = []
        for content_item in message.content:
            inner = content_item.actual_instance

            if not isinstance(inner, TextContent):
                new_content.append(content_item)
                continue

            text = inner.value
            exact_match = EXACT_PLACEHOLDER_PATTERN.match(text)

            if exact_match:
                var_name = exact_match.group(1)

                if var_name in content_vars:
                    new_content.append(
                        MessageContent(actual_instance=content_vars[var_name])
                    )
                    continue

                if var_name in text_vars:
                    inner.value = text_vars[var_name]
                    new_content.append(content_item)
                    continue

                new_content.append(content_item)
                continue

            if "{{" in text:

                def _replace(m: re.Match) -> str:
                    var_name = m.group(1)
                    return text_vars.get(var_name, m.group(0))

                inner.value = PLACEHOLDER_PATTERN.sub(_replace, text)

            new_content.append(content_item)

        message.content = new_content

    return prompt
