from typing import Optional, List, Union, Any, Dict
import logging
from tenacity import (
    retry,
    stop_after_delay,
    wait_exponential,
    wait_random,
    retry_if_exception,
)
import asyncio
from uuid import uuid4
from datetime import datetime, timezone
from adaline_api import LogsApi
from adaline_api.rest import ApiException
from adaline_api.models.create_log_trace_request import CreateLogTraceRequest
from adaline_api.models.create_log_trace_request_trace import (
    CreateLogTraceRequestTrace,
)
from adaline_api.models.create_log_span_request import CreateLogSpanRequest
from adaline_api.models.create_log_span_request_span import (
    CreateLogSpanRequestSpan,
)
from adaline_api.models.log_span_content import LogSpanContent
from adaline_api.models.log_span_other_content import LogSpanOtherContent
from adaline_api.models.log_attributes_value import LogAttributesValue

from .clients.errors import format_api_error as _format_api_error


BufferedEntry = Union["Trace", "Span"]


def _wrap_attributes(
    attributes: Optional[Dict[str, Any]],
) -> Optional[Dict[str, LogAttributesValue]]:
    """Wrap raw attribute values into ``LogAttributesValue`` instances."""
    if attributes is None:
        return None
    return {k: LogAttributesValue(v) for k, v in attributes.items()}


class Monitor:
    """
    Buffers traces and spans, flushing them to the Adaline API in the background.

    Follows the OpenTelemetry error handling principle: telemetry failures
    never propagate to the user's application. Items that fail after retries
    are dropped and counted, not stored.
    """

    def __init__(
        self,
        *,
        api: LogsApi,
        project_id: str,
        flush_interval_seconds: int = 1,
        max_buffer_size: int = 1000,
        default_content: Optional[LogSpanContent] = None,
        logger: Optional[logging.Logger] = None,
    ):
        """Initialize the Monitor and start the background flush loop.

        Args:
            api: Adaline API client used to send traces and spans.
            project_id: Project identifier for grouping telemetry data.
            flush_interval_seconds: Seconds between automatic flushes.
            max_buffer_size: Maximum buffered items before oldest are dropped.
            default_content: Fallback span content when none is provided.
            logger: Optional logger; defaults to the ``adaline`` logger.

        Attributes:
            buffer: List of buffered trace/span entries awaiting flush.
            sent_count: Total items successfully sent to the API.
            dropped_count: Total items dropped due to errors or overflow.
        """
        self.api = api
        self.project_id = project_id
        self.flush_interval_seconds = flush_interval_seconds
        self.max_buffer_size = max_buffer_size

        if default_content is not None:
            self.default_content = default_content
        else:
            other_content = LogSpanOtherContent(type="Other", input="{}", output="{}")
            self.default_content = LogSpanContent(actual_instance=other_content)

        self._logger = logger or logging.getLogger("adaline")

        self.buffer: List = []
        self.sent_count: int = 0
        self.dropped_count: int = 0

        self._stopped = False
        self._is_flushing = False
        self._flush_task = asyncio.create_task(self._flush_loop())

    @staticmethod
    def is_retryable_api_exception(exception: Exception) -> bool:
        if isinstance(exception, ApiException):
            status = getattr(exception, "status", None)
            return status is not None and 500 <= status < 600
        return False

    adaline_api_retry = retry(
        retry=retry_if_exception(is_retryable_api_exception),
        wait=wait_exponential(multiplier=1, min=1, max=10) + wait_random(0, 1),
        stop=stop_after_delay(20),
        reraise=True,
    )

    async def _flush_loop(self):
        while not self._stopped:
            await self.flush()
            await asyncio.sleep(self.flush_interval_seconds)

    def stop(self):
        """Stop the background flush loop and cancel the flush task."""
        self._stopped = True
        if self._flush_task is not None:
            self._flush_task.cancel()
            self._flush_task = None

    @adaline_api_retry
    async def _flush_trace(self, trace):
        return await self.api.create_log_trace(trace)

    @adaline_api_retry
    async def _flush_span(self, span):
        return await self.api.create_log_span(span)

    def _enforce_buffer_limit(self):
        """Drop oldest items when buffer exceeds max_buffer_size."""
        while len(self.buffer) > self.max_buffer_size:
            dropped = self.buffer.pop(0)
            self.dropped_count += 1
            self._logger.warning("Buffer overflow: dropped %s", dropped["category"])

    async def flush(self):
        """Flush all ready items from the buffer to the API.

        Sends each ready trace or span concurrently. Successfully sent items
        are removed from the buffer and counted. Failures are dropped and
        counted via ``dropped_count``. Skips if a flush is already in progress.
        """
        if self._is_flushing:
            return
        self._is_flushing = True

        try:
            ready_items: List = [item for item in self.buffer if item["ready"]]
            if not ready_items:
                return

            self._logger.debug("Flushing %d items", len(ready_items))

            async def process_item(item):
                try:
                    if item["category"] == "trace":
                        response = await self._flush_trace(item["data"].trace)
                        item["data"].trace_id = response.trace_id
                        self._logger.info(
                            "Trace sent: referenceId=%s, traceId=%s",
                            item["data"].trace.trace.reference_id,
                            response.trace_id,
                        )
                    else:
                        await self._flush_span(item["data"].span)
                        self._logger.info(
                            "Span sent: referenceId=%s",
                            item["data"].span.span.reference_id,
                        )
                    self.sent_count += 1
                    return True
                except Exception as err:
                    self._logger.warning(
                        "Dropped %s: %s",
                        item["category"],
                        _format_api_error(err),
                    )
                    self.dropped_count += 1
                    return False

            await asyncio.gather(
                *(process_item(item) for item in ready_items),
            )

            self.buffer = [item for item in self.buffer if item not in ready_items]
            self._logger.debug(
                "Flush complete: %d sent, %d dropped",
                self.sent_count,
                self.dropped_count,
            )

        except Exception as err:
            self._logger.warning("Flush error: %s", _format_api_error(err))

        finally:
            self._is_flushing = False

    def log_trace(
        self,
        *,
        name: str,
        status: str = "unknown",
        session_id: Optional[str] = None,
        reference_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> "Trace":
        """Create a new Trace and append it to the buffer.

        Args:
            name: Display name for the trace.
            status: Trace status (default ``"unknown"``).
            session_id: Optional session identifier for grouping traces.
            reference_id: Client-side ID; auto-generated UUID if omitted.
            tags: Optional list of string tags.
            attributes: Optional key-value metadata.

        Returns:
            The newly created Trace instance.
        """
        if reference_id is None:
            reference_id = str(uuid4())

        new_trace = Trace(
            monitor=self,
            name=name,
            status=status,
            reference_id=reference_id,
            session_id=session_id,
            tags=tags,
            attributes=attributes,
        )

        self.buffer.append({"ready": False, "data": new_trace, "category": "trace"})
        self._enforce_buffer_limit()
        self._logger.debug("Trace created: %s", reference_id)

        return new_trace


class Trace:
    """Represents a single trace that groups related spans.

    A trace is buffered in the Monitor and flushed to the API when ended.
    Child spans are automatically ended when the parent trace ends.
    """

    def __init__(
        self,
        *,
        monitor: "Monitor",
        name: str,
        status: str = "unknown",
        reference_id: Optional[str] = None,
        session_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ):
        """Initialize a Trace.

        Args:
            monitor: Parent Monitor managing the buffer and flush loop.
            name: Display name for the trace.
            status: Trace status (default ``"unknown"``).
            reference_id: Client-side ID; auto-generated UUID if omitted.
            session_id: Optional session identifier.
            tags: Optional list of string tags.
            attributes: Optional key-value metadata.
        """
        self.monitor = monitor
        self.trace_id: Optional[str] = None
        self._end_method_invoked = False

        trace_kwargs: dict = {
            "name": name,
            "status": status,
            "reference_id": reference_id,
            "started_at": int(datetime.now(timezone.utc).timestamp() * 1000),
        }
        if session_id is not None:
            trace_kwargs["session_id"] = session_id
        if tags is not None:
            trace_kwargs["tags"] = tags
        if attributes is not None:
            trace_kwargs["attributes"] = _wrap_attributes(attributes)
        trace_object = CreateLogTraceRequestTrace(**trace_kwargs)

        self.trace = CreateLogTraceRequest(
            project_id=self.monitor.project_id,
            trace=trace_object,
        )

    def update(self, updates: dict) -> "Trace":
        """Update trace fields in place.

        Only the keys ``"name"``, ``"status"``, ``"tags"``, and
        ``"attributes"`` are applied; all other keys are silently ignored.

        Returns:
            Self, for method chaining.
        """
        allowed_keys = {"name", "status", "tags", "attributes"}
        for key, value in updates.items():
            if key in allowed_keys:
                if key == "attributes":
                    value = _wrap_attributes(value)
                setattr(self.trace.trace, key, value)
        return self

    def log_span(
        self,
        *,
        name: str,
        status: str = "unknown",
        reference_id: Optional[str] = None,
        prompt_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
        run_evaluation: Optional[bool] = None,
        tags: Optional[list[str]] = None,
        attributes: Optional[dict] = None,
        content: Optional[LogSpanContent] = None,
    ) -> "Span":
        """Create a child Span under this trace and buffer it.

        Args:
            name: Display name for the span.
            status: Span status (default ``"unknown"``).
            reference_id: Client-side ID; auto-generated UUID if omitted.
            prompt_id: Optional prompt identifier.
            deployment_id: Optional deployment identifier.
            run_evaluation: Whether to run evaluation on this span.
            tags: Optional list of string tags.
            attributes: Optional key-value metadata.
            content: Span content; falls back to the monitor's default.

        Returns:
            The newly created Span instance.
        """
        content = content or self.monitor.default_content
        if reference_id is None:
            reference_id = str(uuid4())

        new_span = Span(
            monitor=self.monitor,
            trace=self,
            name=name,
            status=status,
            content=content,
            reference_id=reference_id,
            prompt_id=prompt_id,
            deployment_id=deployment_id,
            run_evaluation=run_evaluation,
            tags=tags,
            attributes=attributes,
        )

        self.monitor.buffer.append(
            {"ready": False, "data": new_span, "category": "span"}
        )
        self.monitor._enforce_buffer_limit()
        self.monitor._logger.debug(
            "Span created: %s (trace: %s)",
            reference_id,
            self.trace.trace.reference_id,
        )

        return new_span

    def end(self) -> Optional[str]:
        """End the trace and mark it as ready for flushing.

        Idempotent: subsequent calls return the reference ID without
        side effects. Automatically ends all child spans belonging
        to this trace.

        Returns:
            The trace's reference_id.
        """
        if self._end_method_invoked:
            return self.trace.trace.reference_id
        self._end_method_invoked = True

        ended_at = int(datetime.now(timezone.utc).timestamp() * 1000)
        if ended_at <= self.trace.trace.started_at:
            ended_at = self.trace.trace.started_at + 1
        self.trace.trace.ended_at = ended_at

        trace_buffer_item = next(
            (
                item
                for item in self.monitor.buffer
                if item["category"] == "trace" and item["data"] is self
            ),
            None,
        )
        if trace_buffer_item is not None:
            trace_buffer_item["ready"] = True

        for item in self.monitor.buffer:
            if item["category"] == "span" and item["data"].trace is self:
                item["data"].end()

        return self.trace.trace.reference_id


class Span:
    """Represents a single span within a trace.

    A span is buffered in the Monitor and flushed to the API when ended.
    Child spans are automatically ended when the parent span ends.
    """

    def __init__(
        self,
        *,
        monitor: "Monitor",
        trace: "Trace",
        name: str,
        status: str,
        content: LogSpanContent,
        reference_id: str,
        prompt_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
        run_evaluation: Optional[bool] = None,
        tags: Optional[List[str]] = None,
        attributes: Optional[Dict] = None,
        parent_reference_id: Optional[str] = None,
        parent_span: Optional["Span"] = None,
    ):
        """Initialize a Span.

        Args:
            monitor: Parent Monitor managing the buffer and flush loop.
            trace: The Trace this span belongs to.
            name: Display name for the span.
            status: Span status.
            content: Span content payload.
            reference_id: Client-side unique identifier.
            prompt_id: Optional prompt identifier.
            deployment_id: Optional deployment identifier.
            run_evaluation: Whether to run evaluation on this span.
            tags: Optional list of string tags.
            attributes: Optional key-value metadata.
            parent_reference_id: Reference ID of the parent span, if nested.
            parent_span: Direct reference to the parent Span object, if nested.
        """
        self.monitor = monitor
        self.trace = trace
        self._parent_span = parent_span
        self._end_method_invoked = False

        span_kwargs: dict = {
            "name": name,
            "status": status,
            "content": content,
            "started_at": int(datetime.now(timezone.utc).timestamp() * 1000),
            "ended_at": int(datetime.now(timezone.utc).timestamp() * 1000),
        }
        if reference_id is not None:
            span_kwargs["reference_id"] = reference_id
        session_id_val = trace.trace.trace.session_id
        if session_id_val is not None:
            span_kwargs["session_id"] = session_id_val
        if trace.trace_id is not None:
            span_kwargs["trace_id"] = trace.trace_id
        if trace.trace.trace.reference_id is not None:
            span_kwargs["trace_reference_id"] = trace.trace.trace.reference_id
        if prompt_id is not None:
            span_kwargs["prompt_id"] = prompt_id
        if deployment_id is not None:
            span_kwargs["deployment_id"] = deployment_id
        if run_evaluation is not None:
            span_kwargs["run_evaluation"] = run_evaluation
        if tags is not None:
            span_kwargs["tags"] = tags
        if attributes is not None:
            span_kwargs["attributes"] = _wrap_attributes(attributes)
        if parent_reference_id is not None:
            span_kwargs["parent_reference_id"] = parent_reference_id
        span_object = CreateLogSpanRequestSpan(**span_kwargs)

        self.span = CreateLogSpanRequest(
            project_id=self.monitor.project_id, span=span_object
        )

    def update(self, updates: dict) -> "Span":
        """Update span fields in place.

        Only the keys ``"name"``, ``"status"``, ``"tags"``, ``"attributes"``,
        ``"run_evaluation"``, and ``"content"`` are applied; all other keys
        are silently ignored.

        Returns:
            Self, for method chaining.
        """
        allowed_keys = {
            "name",
            "status",
            "tags",
            "attributes",
            "run_evaluation",
            "content",
        }
        for key in allowed_keys:
            if key in updates:
                value = updates[key]
                if key == "attributes":
                    value = _wrap_attributes(value)
                setattr(self.span.span, key, value)
        return self

    def log_span(
        self,
        *,
        name: str,
        status: str = "unknown",
        reference_id: Optional[str] = None,
        prompt_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
        run_evaluation: Optional[bool] = None,
        tags: Optional[list[str]] = None,
        attributes: Optional[Dict[str, Any]] = None,
        content: Optional[LogSpanContent] = None,
    ) -> "Span":
        """Create a child Span nested under this span and buffer it.

        Args:
            name: Display name for the span.
            status: Span status (default ``"unknown"``).
            reference_id: Client-side ID; auto-generated UUID if omitted.
            prompt_id: Optional prompt identifier.
            deployment_id: Optional deployment identifier.
            run_evaluation: Whether to run evaluation on this span.
            tags: Optional list of string tags.
            attributes: Optional key-value metadata.
            content: Span content; falls back to the monitor's default.

        Returns:
            The newly created child Span instance.
        """
        content = content or self.monitor.default_content
        if reference_id is None:
            reference_id = str(uuid4())

        new_span = Span(
            monitor=self.monitor,
            trace=self.trace,
            name=name,
            status=status,
            content=content,
            reference_id=reference_id,
            prompt_id=prompt_id,
            deployment_id=deployment_id,
            run_evaluation=run_evaluation,
            tags=tags,
            attributes=attributes,
            parent_reference_id=self.span.span.reference_id,
            parent_span=self,
        )

        self.monitor.buffer.append(
            {"ready": False, "data": new_span, "category": "span"}
        )
        self.monitor._enforce_buffer_limit()
        self.monitor._logger.debug(
            "Span created: %s (trace: %s)",
            reference_id,
            self.trace.trace.trace.reference_id,
        )

        return new_span

    def end(self) -> Optional[str]:
        """End the span and mark it as ready for flushing.

        Idempotent: subsequent calls return the reference ID without
        side effects. Automatically ends all child spans whose
        ``parent_reference_id`` matches this span.

        Returns:
            The span's reference_id.
        """
        if self._end_method_invoked:
            return self.span.span.reference_id
        self._end_method_invoked = True

        ended_at = int(datetime.now(timezone.utc).timestamp() * 1000)
        if ended_at <= self.span.span.started_at:
            ended_at = self.span.span.started_at + 1
        self.span.span.ended_at = ended_at

        for item in self.monitor.buffer:
            if item["category"] == "span" and item["data"] is self:
                item["ready"] = True
                break

        for item in self.monitor.buffer:
            if item["category"] == "span" and item["data"]._parent_span is self:
                item["data"].end()

        return self.span.span.reference_id
