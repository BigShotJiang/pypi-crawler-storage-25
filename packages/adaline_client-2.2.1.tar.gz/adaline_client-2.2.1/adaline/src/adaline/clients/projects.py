import logging
from typing import Optional

from adaline_api import ProjectsApi
from adaline_api.models.list_projects_response import ListProjectsResponse
from adaline_api.models.project import Project
from adaline_api.models.update_project_request import UpdateProjectRequest

from .retry import adaline_api_retry


class ProjectsClient:
    """Namespaced wrapper around ``ProjectsApi`` with retry built in."""

    def __init__(self, api: ProjectsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(self) -> ListProjectsResponse:
        """List projects in the workspace."""
        return await self._api.list_projects()

    @adaline_api_retry
    async def get(self, *, project_id: str) -> Project:
        """Get a project by ID."""
        return await self._api.get_project(project_id)

    @adaline_api_retry
    async def update(
        self, *, project_id: str, project: UpdateProjectRequest
    ) -> Project:
        """Update a project's metadata (title, icon)."""
        return await self._api.update_project(project_id, project)
