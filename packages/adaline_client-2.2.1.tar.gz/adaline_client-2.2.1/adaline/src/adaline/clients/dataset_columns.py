import logging
from typing import List, Optional

from adaline_api import DatasetsApi
from adaline_api.models.add_dataset_columns_request import AddDatasetColumnsRequest
from adaline_api.models.add_dataset_columns_request_columns_inner import (
    AddDatasetColumnsRequestColumnsInner,
)
from adaline_api.models.add_dataset_columns_response import AddDatasetColumnsResponse
from adaline_api.models.dataset_column import DatasetColumn
from adaline_api.models.fetch_dynamic_columns_request import FetchDynamicColumnsRequest
from adaline_api.models.fetch_dynamic_columns_response import (
    FetchDynamicColumnsResponse,
)
from adaline_api.models.update_dataset_column_request import UpdateDatasetColumnRequest

from .retry import adaline_api_retry


class DatasetColumnsClient:
    """Column-level operations on a dataset. Exposed as ``client.datasets.columns``."""

    def __init__(self, api: DatasetsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def create(
        self,
        *,
        dataset_id: str,
        columns: List[AddDatasetColumnsRequestColumnsInner],
    ) -> AddDatasetColumnsResponse:
        """Add columns to a dataset (batch)."""
        return await self._api.add_dataset_columns(
            dataset_id, AddDatasetColumnsRequest(columns=columns)
        )

    @adaline_api_retry
    async def update(
        self,
        *,
        dataset_id: str,
        column_id: str,
        column: UpdateDatasetColumnRequest,
    ) -> DatasetColumn:
        """Update a single column."""
        return await self._api.update_dataset_column(dataset_id, column_id, column)

    @adaline_api_retry
    async def delete(self, *, dataset_id: str, column_id: str) -> None:
        """Delete a single column."""
        return await self._api.delete_dataset_column(dataset_id, column_id)

    @adaline_api_retry
    async def fetch_dynamic(
        self, *, dataset_id: str, query: FetchDynamicColumnsRequest
    ) -> FetchDynamicColumnsResponse:
        """Trigger dynamic-column resolution for the requested columns / rows."""
        return await self._api.fetch_dynamic_columns(dataset_id, query)
