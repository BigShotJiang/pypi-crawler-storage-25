import logging
from typing import Optional

from adaline_api import LogsApi
from adaline_api.models.list_logs_response import ListLogsResponse

from .log_spans import LogSpansClient
from .log_traces import LogTracesClient
from .retry import LogSort, LogStatus, adaline_api_retry


class LogsClient:
    """Read-side log operations. Owns ``.traces`` and ``.spans`` sub-clients."""

    def __init__(self, api: LogsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")
        self.traces = LogTracesClient(api, self._logger)
        self.spans = LogSpansClient(api, self._logger)

    @adaline_api_retry
    async def list(
        self,
        *,
        project_id: str,
        started_after: Optional[int] = None,
        started_before: Optional[int] = None,
        status: Optional[LogStatus] = None,
        name: Optional[str] = None,
        reference_id: Optional[str] = None,
        session_id: Optional[str] = None,
        sort: Optional[LogSort] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        filters: Optional[str] = None,
    ) -> ListLogsResponse:
        """List traces in a project (lightweight metadata, no span bodies)."""
        return await self._api.list_logs(
            project_id,
            started_after,
            started_before,
            status,
            name,
            reference_id,
            session_id,
            sort,
            limit,
            cursor,
            filters,
        )
