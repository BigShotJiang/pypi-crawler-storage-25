"""Per-resource namespace clients for the Adaline SDK.

Each sub-module defines one ``FooClient`` class that wraps the corresponding
``adaline_api.FooApi`` with the shared ``adaline_api_retry`` decorator and
named-keyword ergonomics. This package's ``__init__`` re-exports everything so
``from adaline.clients import DatasetsClient`` keeps working.
"""

from .errors import ApiError, ApiErrorDetails, extract_api_error
from .retry import (
    EvaluationStatusInput,
    LogFilterType,
    LogSort,
    LogStatus,
    SortOrderInput,
    adaline_api_retry,
    with_retry,
)
from .datasets import DatasetsClient
from .dataset_columns import DatasetColumnsClient
from .dataset_rows import DatasetRowsClient
from .prompts import PromptsClient
from .prompt_draft import PromptDraftClient
from .prompt_playgrounds import PromptPlaygroundsClient
from .prompt_evaluators import PromptEvaluatorsClient
from .prompt_evaluations import PromptEvaluationsClient
from .evaluation_results import EvaluationResultsClient
from .providers import ProvidersClient
from .models import ModelsClient
from .projects import ProjectsClient
from .logs import LogsClient
from .log_traces import LogTracesClient
from .log_spans import LogSpansClient

__all__ = [
    "ApiError",
    "ApiErrorDetails",
    "extract_api_error",
    "EvaluationStatusInput",
    "LogFilterType",
    "LogSort",
    "LogStatus",
    "SortOrderInput",
    "adaline_api_retry",
    "with_retry",
    "DatasetsClient",
    "DatasetColumnsClient",
    "DatasetRowsClient",
    "PromptsClient",
    "PromptDraftClient",
    "PromptPlaygroundsClient",
    "PromptEvaluatorsClient",
    "PromptEvaluationsClient",
    "EvaluationResultsClient",
    "ProvidersClient",
    "ModelsClient",
    "ProjectsClient",
    "LogsClient",
    "LogTracesClient",
    "LogSpansClient",
]
