import logging
from typing import Optional

from adaline_api import PromptsApi
from adaline_api.models.list_playgrounds_response import ListPlaygroundsResponse
from adaline_api.models.playground_detail import PlaygroundDetail

from .retry import adaline_api_retry


class PromptPlaygroundsClient:
    """Playground-scoped operations on a prompt. Exposed as
    ``client.prompts.playgrounds``.
    """

    def __init__(self, api: PromptsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(self, *, prompt_id: str) -> ListPlaygroundsResponse:
        """List playgrounds attached to a prompt."""
        return await self._api.list_playgrounds(prompt_id)

    @adaline_api_retry
    async def get(self, *, prompt_id: str, playground_id: str) -> PlaygroundDetail:
        """Get a single playground for a prompt."""
        return await self._api.get_playground(prompt_id, playground_id)
