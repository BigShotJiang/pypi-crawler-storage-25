import logging
from typing import Optional

from adaline_api import LogsApi
from adaline_api.models.search_log_traces_request import SearchLogTracesRequest
from adaline_api.models.search_traces_response import SearchTracesResponse
from adaline_api.models.update_log_trace_request import UpdateLogTraceRequest

from .retry import adaline_api_retry


class LogTracesClient:
    """Trace-level log operations. Exposed as ``client.logs.traces``."""

    def __init__(self, api: LogsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def search(self, *, query: SearchLogTracesRequest) -> SearchTracesResponse:
        """Paginated trace search with typed filter objects."""
        return await self._api.search_log_traces(query)

    @adaline_api_retry
    async def update(self, *, trace: UpdateLogTraceRequest):
        """Retroactively patch a trace's status/endedAt and tags / attributes."""
        return await self._api.update_log_trace(trace)
