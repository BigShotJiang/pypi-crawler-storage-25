import logging
from typing import Optional

from adaline_api import LogsApi
from adaline_api.models.search_log_spans_request import SearchLogSpansRequest
from adaline_api.models.search_spans_response import SearchSpansResponse

from .retry import adaline_api_retry


class LogSpansClient:
    """Span-level log operations. Exposed as ``client.logs.spans``."""

    def __init__(self, api: LogsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def search(self, *, query: SearchLogSpansRequest) -> SearchSpansResponse:
        """Paginated span search with typed filter objects."""
        return await self._api.search_log_spans(query)
