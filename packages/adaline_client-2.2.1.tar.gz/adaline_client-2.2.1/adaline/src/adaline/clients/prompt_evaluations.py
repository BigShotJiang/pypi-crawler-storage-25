import logging
from typing import Optional

from adaline_api import EvaluationsApi
from adaline_api.models.create_evaluation_request import CreateEvaluationRequest
from adaline_api.models.evaluation import Evaluation
from adaline_api.models.list_evaluations_response import ListEvaluationsResponse

from .evaluation_results import EvaluationResultsClient
from .retry import EvaluationStatusInput, SortOrderInput, adaline_api_retry


class PromptEvaluationsClient:
    """Evaluation operations scoped to a prompt. Exposed as
    ``client.prompts.evaluations``.

    Owns the ``.results`` sub-client
    (``client.prompts.evaluations.results.list``).
    """

    def __init__(self, api: EvaluationsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")
        self.results = EvaluationResultsClient(api, self._logger)

    @adaline_api_retry
    async def list(
        self,
        *,
        prompt_id: str,
        status: Optional[EvaluationStatusInput] = None,
        evaluator_id: Optional[str] = None,
        dataset_id: Optional[str] = None,
        sort: Optional[SortOrderInput] = None,
        created_after: Optional[int] = None,
        created_before: Optional[int] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> ListEvaluationsResponse:
        """List evaluations for a prompt."""
        return await self._api.list_evaluations(
            prompt_id,
            status,
            evaluator_id,
            dataset_id,
            sort,
            created_after,
            created_before,
            limit,
            cursor,
        )

    @adaline_api_retry
    async def create(
        self, *, prompt_id: str, evaluation: CreateEvaluationRequest
    ) -> Evaluation:
        """Create a new evaluation run."""
        return await self._api.create_evaluation(prompt_id, evaluation)

    @adaline_api_retry
    async def get(self, *, prompt_id: str, evaluation_id: str) -> Evaluation:
        """Get an evaluation by ID."""
        return await self._api.get_evaluation(prompt_id, evaluation_id)

    @adaline_api_retry
    async def cancel(self, *, prompt_id: str, evaluation_id: str) -> Evaluation:
        """Cancel a running evaluation."""
        return await self._api.cancel_evaluation(prompt_id, evaluation_id)
