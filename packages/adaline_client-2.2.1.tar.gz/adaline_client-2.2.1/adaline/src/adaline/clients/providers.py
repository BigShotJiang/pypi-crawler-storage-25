import logging
from typing import Optional

from adaline_api import ProvidersApi
from adaline_api.models.get_provider_response import GetProviderResponse
from adaline_api.models.list_providers_response import ListProvidersResponse

from .retry import adaline_api_retry


class ProvidersClient:
    """Namespaced wrapper around ``ProvidersApi`` with retry built in."""

    def __init__(self, api: ProvidersApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(self) -> ListProvidersResponse:
        """List configured providers."""
        return await self._api.list_providers()

    @adaline_api_retry
    async def get(
        self, *, provider_id: str, include_models: Optional[bool] = None
    ) -> GetProviderResponse:
        """Get a provider by ID, optionally including its models."""
        return await self._api.get_provider(provider_id, include_models)
