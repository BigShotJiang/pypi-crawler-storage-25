"""Retry decorator + shared Literal type aliases used by every namespace client.

The ``@adaline_api_retry`` decorator wraps any async method on a namespace
client with the standard retry policy: 5xx errors retry with exponential
backoff + jitter, 4xx errors abort. On final failure — after retries are
exhausted or the first 4xx — the wrapped method auto-reports the error to
the owning client's ``self._logger`` as ``logger.error("[<op>] <msg>")``,
so call sites don't need a per-method try / except / log block.

The Literal aliases widen the autogen's string-enum types so callers can
pass either the enum member or the raw string value; pydantic coerces to
the enum at the HTTP boundary.
"""

import logging
from functools import wraps
from typing import Awaitable, Callable, Literal, TypeVar, Union

from tenacity import (
    retry,
    retry_if_exception,
    stop_after_delay,
    wait_exponential,
    wait_random,
)

from adaline_api.rest import ApiException
from adaline_api.models.sort_order import SortOrder
from adaline_api.models.evaluation_status import EvaluationStatus

from .errors import format_api_error


#: ``"createdAt:asc" | "createdAt:desc"`` — or the ``SortOrder`` enum member.
SortOrderInput = Union[SortOrder, Literal["createdAt:asc", "createdAt:desc"]]

#: Evaluation lifecycle status as either the enum member or its string value.
EvaluationStatusInput = Union[
    EvaluationStatus,
    Literal["queued", "running", "completed", "failed", "cancelled", "cancelling"],
]

#: Log status values accepted by the log search endpoints (mirrors TS ``LogStatus``).
LogStatus = Literal["success", "failure", "aborted", "cancelled", "pending", "unknown"]

#: Log sort values accepted by the log search endpoints (mirrors TS ``LogSort``).
LogSort = Literal["startedAt:asc", "startedAt:desc"]

#: Discriminator for a typed log-search filter (mirrors TS ``LogFilterType``).
LogFilterType = Literal["string", "number", "datetime", "arrayContains"]


T = TypeVar("T")


def _is_retryable_api_exception(exception: BaseException) -> bool:
    """Retry only on ApiException with a 5xx status."""
    if isinstance(exception, ApiException):
        status = getattr(exception, "status", None)
        return status is not None and 500 <= status < 600
    return False


# Tenacity retry policy shared by every wrapped call.
_tenacity_retry = retry(
    retry=retry_if_exception(_is_retryable_api_exception),
    wait=wait_exponential(multiplier=1, min=1, max=10) + wait_random(0, 1),
    stop=stop_after_delay(20),
    reraise=True,
)


def adaline_api_retry(fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """Wrap an async namespace-client method with retry + auto-logging.

    Derives the operation name from the wrapped method's module + name
    (e.g. ``datasets.list``, ``dataset_rows.create``). On final failure —
    whether from a 4xx abort or 5xx exhaustion — logs the full HTTP context
    to the owning instance's ``self._logger`` at ``error`` level, then
    re-raises the original exception unchanged (so callers can catch the
    autogen's ``ApiException`` and inspect ``.status`` / ``.body`` as always).
    """
    module = fn.__module__.rsplit(".", 1)[-1]
    op_name = f"{module}.{fn.__name__}"
    wrapped = _tenacity_retry(fn)

    @wraps(fn)
    async def inner(self, *args, **kwargs):
        try:
            return await wrapped(self, *args, **kwargs)
        except ApiException as err:
            logger = getattr(self, "_logger", None)
            if isinstance(logger, logging.Logger):
                logger.error("[%s] failed — %s", op_name, format_api_error(err))
            raise
        except Exception as err:
            logger = getattr(self, "_logger", None)
            if isinstance(logger, logging.Logger):
                logger.error("[%s] failed — %s", op_name, err)
            raise

    return inner


async def with_retry(fn: Callable[[], Awaitable[T]]) -> T:
    """Execute ``fn`` with the standard retry policy (no auto-logging).

    Useful when calling methods on the raw autogen API clients directly from
    outside a namespace-client context. For namespace-client methods, prefer
    ``@adaline_api_retry`` so failures are auto-logged.
    """
    wrapped = _tenacity_retry(fn)
    return await wrapped()
