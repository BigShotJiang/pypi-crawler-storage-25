import logging
from typing import List, Optional

from adaline_api import DatasetsApi
from adaline_api.models.add_dataset_rows_request import AddDatasetRowsRequest
from adaline_api.models.add_dataset_rows_response import AddDatasetRowsResponse
from adaline_api.models.dataset_row import DatasetRow
from adaline_api.models.dataset_row_input import DatasetRowInput
from adaline_api.models.list_dataset_rows_response import ListDatasetRowsResponse

from .retry import SortOrderInput, adaline_api_retry


class DatasetRowsClient:
    """Row-level operations on a dataset. Exposed as ``client.datasets.rows``."""

    def __init__(self, api: DatasetsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(
        self,
        *,
        dataset_id: str,
        columns: Optional[str] = None,
        sort: Optional[SortOrderInput] = None,
        created_after: Optional[int] = None,
        created_before: Optional[int] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> ListDatasetRowsResponse:
        """List rows in a dataset (paginated)."""
        return await self._api.get_dataset_rows(
            dataset_id, columns, sort, created_after, created_before, limit, cursor
        )

    @adaline_api_retry
    async def create(
        self,
        *,
        dataset_id: str,
        rows: List[DatasetRowInput],
        values_by: Optional[str] = None,
    ) -> AddDatasetRowsResponse:
        """Create rows in a dataset (batch, up to 100)."""
        return await self._api.add_dataset_rows(
            dataset_id, values_by, AddDatasetRowsRequest(rows=rows)
        )

    @adaline_api_retry
    async def update(
        self,
        *,
        dataset_id: str,
        row_id: str,
        row: DatasetRowInput,
        values_by: Optional[str] = None,
    ) -> DatasetRow:
        """Update a single row's cell values."""
        return await self._api.patch_dataset_row(dataset_id, row_id, values_by, row)

    @adaline_api_retry
    async def delete(self, *, dataset_id: str, row_id: str) -> None:
        """Delete a single row."""
        return await self._api.delete_dataset_row(dataset_id, row_id)
