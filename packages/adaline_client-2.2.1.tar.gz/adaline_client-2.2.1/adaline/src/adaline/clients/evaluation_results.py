import logging
from typing import Optional

from adaline_api import EvaluationsApi
from adaline_api.models.list_evaluation_results_response import (
    ListEvaluationResultsResponse,
)

from .retry import adaline_api_retry


class EvaluationResultsClient:
    """Results sub-client under an evaluation. Exposed as
    ``client.prompts.evaluations.results``.
    """

    def __init__(self, api: EvaluationsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(
        self,
        *,
        prompt_id: str,
        evaluation_id: str,
        grade: Optional[str] = None,
        expand: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> ListEvaluationResultsResponse:
        """Get paginated results for a completed / running evaluation."""
        return await self._api.get_evaluation_results(
            prompt_id, evaluation_id, grade, expand, sort, limit, cursor
        )
