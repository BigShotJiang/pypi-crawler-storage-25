import logging
from typing import Optional

from adaline_api import EvaluatorsApi
from adaline_api.models.create_evaluator_request import CreateEvaluatorRequest
from adaline_api.models.evaluator import Evaluator
from adaline_api.models.list_evaluators_response import ListEvaluatorsResponse
from adaline_api.models.update_evaluator_request import UpdateEvaluatorRequest

from .retry import SortOrderInput, adaline_api_retry


class PromptEvaluatorsClient:
    """Evaluator operations scoped to a prompt. Exposed as
    ``client.prompts.evaluators``.
    """

    def __init__(self, api: EvaluatorsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(
        self,
        *,
        prompt_id: str,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        sort: Optional[SortOrderInput] = None,
        created_after: Optional[int] = None,
        created_before: Optional[int] = None,
    ) -> ListEvaluatorsResponse:
        """List evaluators attached to a prompt."""
        return await self._api.list_evaluators(
            prompt_id, limit, cursor, sort, created_after, created_before
        )

    @adaline_api_retry
    async def create(
        self, *, prompt_id: str, evaluator: CreateEvaluatorRequest
    ) -> Evaluator:
        """Create a new evaluator on a prompt."""
        return await self._api.create_evaluator(prompt_id, evaluator)

    @adaline_api_retry
    async def get(self, *, prompt_id: str, evaluator_id: str) -> Evaluator:
        """Get an evaluator by ID."""
        return await self._api.get_evaluator(prompt_id, evaluator_id)

    @adaline_api_retry
    async def update(
        self,
        *,
        prompt_id: str,
        evaluator_id: str,
        evaluator: UpdateEvaluatorRequest,
    ) -> Evaluator:
        """Update an evaluator."""
        return await self._api.update_evaluator(prompt_id, evaluator_id, evaluator)

    @adaline_api_retry
    async def delete(self, *, prompt_id: str, evaluator_id: str) -> None:
        """Delete an evaluator."""
        return await self._api.delete_evaluator(prompt_id, evaluator_id)
