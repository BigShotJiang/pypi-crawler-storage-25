import logging
from typing import Optional

from adaline_api import ModelsApi
from adaline_api.models.list_models_response import ListModelsResponse

from .retry import adaline_api_retry


class ModelsClient:
    """Namespaced wrapper around ``ModelsApi`` with retry built in."""

    def __init__(self, api: ModelsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def list(self, *, provider_id: Optional[str] = None) -> ListModelsResponse:
        """List models, optionally filtered by provider."""
        return await self._api.list_models(provider_id)
