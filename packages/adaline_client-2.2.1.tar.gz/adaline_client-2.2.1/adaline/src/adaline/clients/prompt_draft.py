import logging
from typing import Optional

from adaline_api import PromptsApi
from adaline_api.models.prompt_draft import PromptDraft

from .retry import adaline_api_retry


class PromptDraftClient:
    """Draft-scoped operations on a prompt. Exposed as ``client.prompts.draft``."""

    def __init__(self, api: PromptsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")

    @adaline_api_retry
    async def get(self, *, prompt_id: str) -> PromptDraft:
        """Get the current draft for a prompt."""
        return await self._api.get_prompt_draft(prompt_id)
