"""Shared error-extraction helpers for the Adaline Python SDK.

The autogen raises :class:`adaline_api.rest.ApiException` with useful HTTP
status + response body on ``.status`` / ``.body``. This module normalizes that
into a consistent structured view and a human-readable one-liner so every
error bubbled up from the SDK is self-describing without callers having to
peel apart opaque fields.
"""

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ApiErrorDetails:
    """Structured view of an error raised by the autogen or a wrapper."""

    status_code: Optional[int]
    message: str
    body: Any
    headers: Optional[dict]
    #: Server-issued request id (from ``x-request-id``), when present.
    request_id: Optional[str]


def _pick_header(headers: Optional[dict], *names: str) -> Optional[str]:
    if not headers:
        return None
    for name in names:
        if name in headers:
            return headers[name]
    return None


def extract_api_error(err: BaseException) -> ApiErrorDetails:
    """Extract HTTP status, response body, headers, and reason from an autogen error.

    For ``adaline_api.rest.ApiException`` the ``status``/``reason``/``body``/
    ``headers`` attributes are populated directly; for other exceptions we
    fall back to ``str(err)`` for the message. ``ApiException.__str__``
    renders a multi-line block, so we deliberately avoid it when the
    structured fields are available.
    """
    status = getattr(err, "status", None)
    body = getattr(err, "body", None)
    reason = getattr(err, "reason", None)
    headers = getattr(err, "headers", None)
    # ApiException.headers may be urllib3.HTTPHeaderDict — normalize to plain dict.
    headers_dict = dict(headers) if headers is not None else None
    raw_cloud_trace = _pick_header(
        headers_dict, "x-cloud-trace-context", "X-Cloud-Trace-Context"
    )
    cloud_trace = (
        raw_cloud_trace.split("/", 1)[0].split(";", 1)[0] if raw_cloud_trace else None
    )
    request_id = (
        _pick_header(headers_dict, "x-request-id", "X-Request-Id") or cloud_trace
    )
    if reason:
        message = reason
    elif status is None and body is None:
        message = str(err) or type(err).__name__
    else:
        message = ""
    return ApiErrorDetails(
        status_code=status,
        message=message,
        body=body,
        headers=headers_dict,
        request_id=request_id,
    )


def format_api_error(err: BaseException) -> str:
    """Human-readable one-liner: ``HTTP <code> — <reason> — body=<json>``.

    When the error is an autogen ``ApiException`` the structured
    ``status``/``reason``/``body`` fields are used directly and the verbose
    multi-line ``__str__`` is skipped to avoid duplicating status + body.
    """
    details = extract_api_error(err)
    parts: list[str] = []
    if details.status_code is not None:
        parts.append(f"HTTP {details.status_code}")
    if details.message:
        parts.append(details.message)
    if details.body is not None:
        body_str = details.body if isinstance(details.body, str) else repr(details.body)
        parts.append(f"body={body_str}")
    if details.request_id:
        parts.append(f"requestId={details.request_id}")
    return " — ".join(parts) if parts else str(err) or type(err).__name__


class ApiError(Exception):
    """Exception subclass that carries the extracted HTTP status.

    Wraps an underlying :class:`adaline_api.rest.ApiException` (or any other
    exception). The ``message`` on this instance is the rich
    :func:`format_api_error` string; ``status_code`` is parsed for convenience.
    """

    def __init__(self, err: BaseException):
        details = extract_api_error(err)
        super().__init__(format_api_error(err))
        self.status_code = details.status_code
        self.body = details.body
        self.headers = details.headers
        self.request_id = details.request_id
        self.__cause__ = err
