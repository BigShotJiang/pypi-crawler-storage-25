import logging
from typing import Optional

from adaline_api import EvaluationsApi, EvaluatorsApi, PromptsApi
from adaline_api.models.create_prompt_request import CreatePromptRequest
from adaline_api.models.list_prompts_response import ListPromptsResponse
from adaline_api.models.patch_prompt_request import PatchPromptRequest
from adaline_api.models.prompt import Prompt

from .prompt_draft import PromptDraftClient
from .prompt_evaluations import PromptEvaluationsClient
from .prompt_evaluators import PromptEvaluatorsClient
from .prompt_playgrounds import PromptPlaygroundsClient
from .retry import SortOrderInput, adaline_api_retry


class PromptsClient:
    """Prompt-level operations. Owns ``.draft``, ``.playgrounds``,
    ``.evaluators``, and ``.evaluations`` sub-clients.
    """

    def __init__(
        self,
        api: PromptsApi,
        evaluators_api: EvaluatorsApi,
        evaluations_api: EvaluationsApi,
        logger: Optional[logging.Logger] = None,
    ):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")
        self.draft = PromptDraftClient(api, self._logger)
        self.playgrounds = PromptPlaygroundsClient(api, self._logger)
        self.evaluators = PromptEvaluatorsClient(evaluators_api, self._logger)
        self.evaluations = PromptEvaluationsClient(evaluations_api, self._logger)

    @adaline_api_retry
    async def list(
        self,
        *,
        project_id: str,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        sort: Optional[SortOrderInput] = None,
        created_after: Optional[int] = None,
        created_before: Optional[int] = None,
        fields: Optional[str] = None,
    ) -> ListPromptsResponse:
        """List prompts in a project."""
        return await self._api.list_prompts(
            project_id, limit, cursor, sort, created_after, created_before, fields
        )

    @adaline_api_retry
    async def create(self, *, prompt: CreatePromptRequest) -> Prompt:
        """Create a new prompt."""
        return await self._api.create_prompt(prompt)

    @adaline_api_retry
    async def get(
        self,
        *,
        prompt_id: str,
        expand: Optional[str] = None,
        fields: Optional[str] = None,
    ) -> Prompt:
        """Get a prompt by ID."""
        return await self._api.get_prompt(prompt_id, expand, fields)

    @adaline_api_retry
    async def update(
        self,
        *,
        prompt_id: str,
        prompt: PatchPromptRequest,
        playground_id: Optional[str] = None,
    ) -> Prompt:
        """Update a prompt (PATCH under the hood)."""
        return await self._api.patch_prompt(prompt_id, playground_id, prompt)

    @adaline_api_retry
    async def delete(self, *, prompt_id: str) -> None:
        """Delete a prompt."""
        return await self._api.delete_prompt(prompt_id)
