import logging
from typing import Optional

from adaline_api import DatasetsApi
from adaline_api.models.create_dataset_request import CreateDatasetRequest
from adaline_api.models.dataset import Dataset
from adaline_api.models.dataset_summary import DatasetSummary
from adaline_api.models.list_datasets_response import ListDatasetsResponse
from adaline_api.models.update_dataset_request import UpdateDatasetRequest

from .dataset_columns import DatasetColumnsClient
from .dataset_rows import DatasetRowsClient
from .retry import SortOrderInput, adaline_api_retry


class DatasetsClient:
    """Dataset-level operations. Owns ``.rows`` and ``.columns`` sub-clients."""

    def __init__(self, api: DatasetsApi, logger: Optional[logging.Logger] = None):
        self._api = api
        self._logger = logger or logging.getLogger("adaline")
        self.rows = DatasetRowsClient(api, self._logger)
        self.columns = DatasetColumnsClient(api, self._logger)

    @adaline_api_retry
    async def list(
        self,
        *,
        project_id: str,
        sort: Optional[SortOrderInput] = None,
        created_after: Optional[int] = None,
        created_before: Optional[int] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> ListDatasetsResponse:
        """List datasets in a project."""
        return await self._api.list_datasets(
            project_id, sort, created_after, created_before, limit, cursor
        )

    @adaline_api_retry
    async def create(self, *, dataset: CreateDatasetRequest) -> Dataset:
        """Create a new dataset."""
        return await self._api.create_dataset(dataset)

    @adaline_api_retry
    async def get(self, *, dataset_id: str) -> Dataset:
        """Get a dataset by ID."""
        return await self._api.get_dataset(dataset_id)

    @adaline_api_retry
    async def update(
        self, *, dataset_id: str, dataset: UpdateDatasetRequest
    ) -> DatasetSummary:
        """Update dataset metadata."""
        return await self._api.update_dataset(dataset_id, dataset)

    @adaline_api_retry
    async def delete(self, *, dataset_id: str) -> None:
        """Delete a dataset."""
        return await self._api.delete_dataset(dataset_id)
