"""Backend dispatch completeness guardrail.

Every MCP tool in server.py that calls `_call_backend_json("<method>", ...)`
must have a corresponding method on BOTH `LocalBackend` and `CloudBackend`.
Otherwise, the tool returns an `AttributeError` to every user who calls it.

This is the bug novyx-mcp==2.5.0 shipped with: 29 Runtime v2 MCP tools
dispatching to methods that existed only in the SDK, not in either
backend wrapper. Codex flagged it during PR review; this test is the
permanent fix. It walks server.py, pulls every dispatch call out by
regex, and asserts each method name is defined on both backend classes.

If you add a new @mcp.tool that dispatches through `_call_backend_json`,
you MUST also add a method with the same name to both LocalBackend and
CloudBackend (even if LocalBackend just raises CloudFeatureError).
This test will fail CI until you do.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from novyx_mcp.cloud_backend import CloudBackend
from novyx_mcp.local_backend import LocalBackend

PACKAGE_DIR = Path(__file__).resolve().parent.parent
SERVER_PY = PACKAGE_DIR / "novyx_mcp" / "server.py"


def _dispatched_method_names() -> set[str]:
    """Extract every method name passed to `_call_backend_json(...)`.

    Matches both positional-string and f-string forms, but intentionally
    does NOT match variables — you should never pass a computed method
    name to the dispatcher.
    """
    text = SERVER_PY.read_text(encoding="utf-8")
    pattern = re.compile(r'_call_backend_json\(\s*["\']([a-zA-Z_][a-zA-Z0-9_]*)["\']')
    return set(pattern.findall(text))


DISPATCHED_METHODS = sorted(_dispatched_method_names())


def test_at_least_one_dispatched_method_found():
    """Sanity check: if this returns 0, the regex broke, not the code."""
    assert DISPATCHED_METHODS, (
        "No _call_backend_json() calls found in server.py — regex is broken"
    )


@pytest.mark.parametrize("method_name", DISPATCHED_METHODS)
def test_local_backend_implements(method_name: str):
    """Every dispatched method must exist on LocalBackend."""
    assert hasattr(LocalBackend, method_name), (
        f"LocalBackend is missing method '{method_name}'. "
        f"server.py calls _call_backend_json('{method_name}', ...) but "
        f"LocalBackend does not define it. Either add a real implementation "
        f"or a CloudFeatureError stub (see existing cloud-only methods at "
        f"the bottom of local_backend.py)."
    )


@pytest.mark.parametrize("method_name", DISPATCHED_METHODS)
def test_cloud_backend_implements(method_name: str):
    """Every dispatched method must exist on CloudBackend."""
    assert hasattr(CloudBackend, method_name), (
        f"CloudBackend is missing method '{method_name}'. "
        f"server.py calls _call_backend_json('{method_name}', ...) but "
        f"CloudBackend does not define it. CloudBackend is a thin wrapper "
        f"around the Novyx SDK — add a delegation method that calls "
        f"self._client.{method_name}(...)."
    )
