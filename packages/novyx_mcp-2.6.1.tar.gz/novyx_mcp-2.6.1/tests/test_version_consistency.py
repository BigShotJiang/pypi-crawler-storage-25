"""Version + tool-count consistency guardrail for novyx-mcp.

Asserts that version strings and tool counts are coherent across
`pyproject.toml`, `novyx_mcp/__init__.py`, `server.json`, and
`.well-known/mcp.json`, and that the declared tool count actually matches
the number of `@mcp.tool` decorators in `novyx_mcp/server.py`.

If this test fails, someone shipped drift. The standalone
`novyxlabs/novyx-mcp` publishing mirror has gone stale four times on this
exact failure mode; this test is the pre-commit tripwire so it doesn't
happen a fifth time inside the monorepo itself.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

PACKAGE_DIR = Path(__file__).resolve().parent.parent
PYPROJECT = PACKAGE_DIR / "pyproject.toml"
INIT_PY = PACKAGE_DIR / "novyx_mcp" / "__init__.py"
SERVER_PY = PACKAGE_DIR / "novyx_mcp" / "server.py"
SERVER_JSON = PACKAGE_DIR / "server.json"
WELL_KNOWN_MCP_JSON = PACKAGE_DIR / ".well-known" / "mcp.json"
MONOREPO_ROOT = PACKAGE_DIR.parent.parent
MCP_DISTRIBUTION_DIR = MONOREPO_ROOT / "mcp-distribution"
DISTRIBUTION_SERVER_JSON = MCP_DISTRIBUTION_DIR / "server.json"
DISTRIBUTION_UNIVERSAL_DESCRIPTION = MCP_DISTRIBUTION_DIR / "universal-description.md"
DISTRIBUTION_AWESOME_LISTING = MCP_DISTRIBUTION_DIR / "awesome-mcp-listing.md"


def _pyproject_version() -> str:
    text = PYPROJECT.read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
    assert match, "pyproject.toml must define version under [project]"
    return match.group(1)


def _pyproject_description() -> str:
    text = PYPROJECT.read_text(encoding="utf-8")
    match = re.search(r'^description\s*=\s*"([^"]+)"', text, re.MULTILINE)
    assert match, "pyproject.toml must define description under [project]"
    return match.group(1)


def _init_version() -> str:
    text = INIT_PY.read_text(encoding="utf-8")
    match = re.search(r'__version__\s*=\s*"([^"]+)"', text)
    assert match, "novyx_mcp/__init__.py must define __version__"
    return match.group(1)


def _source_tool_count() -> int:
    """Count `@mcp.tool(...)` decorators at column 0 in server.py.

    The codebase uses `@mcp.tool(annotations=ToolAnnotations(...))`, which a
    naive `@mcp.tool()` grep would miss entirely. Use a word boundary.
    """
    text = SERVER_PY.read_text(encoding="utf-8")
    return len(re.findall(r"^@mcp\.tool\b", text, re.MULTILINE))


def _tool_count_from_description(desc: str) -> int:
    """Extract the `NNN MCP tools` count from a marketing description string."""
    match = re.search(r"(\d+)\s+MCP\s+tools", desc)
    assert match, f"description must mention 'N MCP tools': {desc!r}"
    return int(match.group(1))


# --- version consistency -------------------------------------------------


def test_init_version_matches_pyproject():
    assert _init_version() == _pyproject_version(), (
        f"novyx_mcp/__init__.py version ({_init_version()}) "
        f"does not match pyproject.toml ({_pyproject_version()})"
    )


def test_server_json_version_matches_pyproject():
    data = json.loads(SERVER_JSON.read_text(encoding="utf-8"))
    top_version = data.get("version")
    assert top_version == _pyproject_version(), (
        f"server.json version ({top_version}) does not match pyproject.toml "
        f"({_pyproject_version()})"
    )
    # packages[0].version (PyPI identifier) must also match
    packages = data.get("packages", [])
    assert packages, "server.json must declare at least one package"
    for pkg in packages:
        if pkg.get("identifier") == "novyx-mcp":
            assert pkg.get("version") == _pyproject_version(), (
                f"server.json packages[pypi].version ({pkg.get('version')}) "
                f"does not match pyproject.toml ({_pyproject_version()})"
            )


def test_well_known_mcp_json_version_matches_pyproject():
    data = json.loads(WELL_KNOWN_MCP_JSON.read_text(encoding="utf-8"))
    top_version = data.get("version")
    assert top_version == _pyproject_version(), (
        f".well-known/mcp.json version ({top_version}) does not match "
        f"pyproject.toml ({_pyproject_version()})"
    )
    pypi = data.get("packages", {}).get("pypi", {})
    assert pypi.get("version") == _pyproject_version(), (
        f".well-known/mcp.json packages.pypi.version ({pypi.get('version')}) "
        f"does not match pyproject.toml ({_pyproject_version()})"
    )


# --- tool-count consistency ----------------------------------------------


def test_pyproject_description_tool_count_matches_source():
    declared = _tool_count_from_description(_pyproject_description())
    actual = _source_tool_count()
    assert declared == actual, (
        f"pyproject.toml description claims {declared} MCP tools but "
        f"novyx_mcp/server.py has {actual} @mcp.tool decorators"
    )


def test_server_json_description_tool_count_matches_source():
    data = json.loads(SERVER_JSON.read_text(encoding="utf-8"))
    declared = _tool_count_from_description(data.get("description", ""))
    actual = _source_tool_count()
    assert declared == actual, (
        f"server.json description claims {declared} MCP tools but "
        f"novyx_mcp/server.py has {actual} @mcp.tool decorators"
    )


def test_well_known_mcp_json_description_tool_count_matches_source():
    data = json.loads(WELL_KNOWN_MCP_JSON.read_text(encoding="utf-8"))
    declared = _tool_count_from_description(data.get("description", ""))
    actual = _source_tool_count()
    assert declared == actual, (
        f".well-known/mcp.json description claims {declared} MCP tools but "
        f"novyx_mcp/server.py has {actual} @mcp.tool decorators"
    )


def test_mcp_distribution_server_json_matches_pyproject():
    data = json.loads(DISTRIBUTION_SERVER_JSON.read_text(encoding="utf-8"))
    actual = _source_tool_count()

    assert data.get("version") == _pyproject_version(), (
        f"mcp-distribution/server.json version ({data.get('version')}) "
        f"does not match pyproject.toml ({_pyproject_version()})"
    )
    assert _tool_count_from_description(data.get("description", "")) == actual

    packages = data.get("packages", [])
    assert packages, "mcp-distribution/server.json must declare at least one package"
    for pkg in packages:
        if pkg.get("identifier") == "novyx-mcp":
            assert pkg.get("version") == _pyproject_version(), (
                f"mcp-distribution/server.json package version ({pkg.get('version')}) "
                f"does not match pyproject.toml ({_pyproject_version()})"
            )


@pytest.mark.parametrize(
    "path",
    [
        DISTRIBUTION_UNIVERSAL_DESCRIPTION,
        DISTRIBUTION_AWESOME_LISTING,
    ],
)
def test_mcp_distribution_marketing_tool_counts_match_source(path):
    text = path.read_text(encoding="utf-8")
    actual = _source_tool_count()
    stale_counts = re.findall(r"(\d+)\s+MCP\s+tools|(\d+)\s+tools", text)
    declared = {int(left or right) for left, right in stale_counts}

    assert declared, f"{path} must mention the MCP tool count"
    assert declared == {actual}, (
        f"{path} declares tool counts {sorted(declared)} but "
        f"novyx_mcp/server.py has {actual} @mcp.tool decorators"
    )
