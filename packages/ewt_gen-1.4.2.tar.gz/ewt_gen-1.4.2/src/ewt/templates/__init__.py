"""HTML templates for EWT."""
