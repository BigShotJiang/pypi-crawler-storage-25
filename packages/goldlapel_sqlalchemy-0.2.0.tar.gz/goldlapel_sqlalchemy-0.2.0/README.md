# Deprecated — package consolidated

**This package has been merged into the main `goldlapel` package.**

**Install instead:**

```bash
pip install goldlapel[sqlalchemy]
```

**Source code:** https://github.com/goldlapel/goldlapel-python

This redirect package remains installable for backward compatibility — it
depends transitively on `goldlapel[sqlalchemy]` and re-exports the same API
so existing imports keep working — but emits a `DeprecationWarning` on
import. Update your code::

    from goldlapel.sqlalchemy import create_engine  # was: from goldlapel_sqlalchemy import create_engine

New development happens in the consolidated repo.

---

# goldlapel-sqlalchemy (legacy)

> **This package has been consolidated into [`goldlapel`](https://pypi.org/project/goldlapel/).**

Install with:

```bash
pip install goldlapel[sqlalchemy]
```

Then use `from goldlapel.sqlalchemy import create_engine`. See the [Gold Lapel docs](https://goldlapel.com/docs/sqlalchemy) for details.
