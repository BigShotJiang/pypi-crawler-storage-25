"""goldlapel-sqlalchemy — redirect package.

This package has been consolidated into the main goldlapel package.
Install via: pip install goldlapel[sqlalchemy]

Importing from goldlapel_sqlalchemy still works for backward compatibility,
but new code should import from goldlapel.sqlalchemy directly.
"""

import warnings

warnings.warn(
    "The goldlapel-sqlalchemy package has been consolidated into "
    "goldlapel[sqlalchemy]. Future development happens in "
    "https://github.com/goldlapel/goldlapel-python. "
    "Update your install: pip install goldlapel[sqlalchemy]. "
    "Update your imports: from goldlapel.sqlalchemy import create_engine. "
    "This redirect package may be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the canonical location so existing code like
#   from goldlapel_sqlalchemy import create_engine, init, ...
# keeps working unchanged.
from goldlapel.sqlalchemy import *  # noqa: F401, F403

# Explicitly re-export the public surface (some attributes are simple
# assignments rather than top-level definitions in the canonical module,
# so the star-import covers them, but we restate the names for clarity).
from goldlapel.sqlalchemy import (  # noqa: F401
    create_engine,
    create_async_engine,
    init,
    start,
    stop,
    proxy_url,
    GoldLapel,
    NativeCache,
    wrap,
)

try:
    from goldlapel.sqlalchemy import DEFAULT_PROXY_PORT  # noqa: F401
except ImportError:
    pass

# Older code may have imported the legacy DEFAULT_PORT name.
try:
    from goldlapel.sqlalchemy import DEFAULT_PORT  # noqa: F401
except ImportError:
    try:
        from goldlapel.sqlalchemy import DEFAULT_PROXY_PORT as DEFAULT_PORT  # noqa: F401
    except ImportError:
        pass

try:
    from goldlapel.sqlalchemy import __all__  # noqa: F401
except ImportError:
    pass
