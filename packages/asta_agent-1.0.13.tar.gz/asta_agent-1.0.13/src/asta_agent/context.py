"""AstaContext — the object task code uses to publish updates."""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from a2a.types import (
    Artifact,
    DataPart,
    Message,
    TaskArtifactUpdateEvent,
    TaskState,
    TaskStatus,
    TaskStatusUpdateEvent,
    TextPart,
)

from asta_agent.session import AstaSession
from asta_agent.step import RunState, StepProgress

logger = logging.getLogger(__name__)


class ArtifactRef:
    """Lightweight handle returned by :meth:`AstaContext.publish_artifact`.

    Provides the artifact ID and generates inline ``<artifact>`` tags
    for embedding in completion messages.
    """

    def __init__(self, artifact_id: str, name: str | None = None):
        self.id = artifact_id
        self.name = name

    def tag(self, label: str | None = None) -> str:
        """Return ``<artifact id="...">label</artifact>``."""
        display = label or self.name or self.id
        return f'<artifact id="{self.id}">{display}</artifact>'

    def __str__(self) -> str:
        return self.tag()

    def __repr__(self) -> str:
        return f"ArtifactRef(id={self.id!r}, name={self.name!r})"


class PaperRef:
    """Generates inline ``<paper>`` tags for step progress.

    Attributes are lowercase to match markdown-to-jsx prop delivery.
    """

    def __init__(self, title: str, corpus_id: str | int | None = None,
                 artifact_id: str | None = None):
        self.title = title
        self.corpus_id = str(corpus_id) if corpus_id else None
        self.artifact_id = artifact_id

    def tag(self) -> str | None:
        """Return ``<paper corpusid="..." artifactid="...">title</paper>`` or None."""
        attrs = []
        if self.corpus_id:
            attrs.append(f'corpusid="{self.corpus_id}"')
        if self.artifact_id:
            attrs.append(f'artifactid="{self.artifact_id}"')
        if attrs:
            return f'<paper {" ".join(attrs)}>{self.title}</paper>'
        return None

    def __str__(self) -> str:
        return self.tag() or self.title


class AstaContext:
    """Context object for reporting task progress, artifacts, and lifecycle.

    Async methods (``async_start_step``, ``async_complete``, etc.) are the source of truth.
    Sync methods (``start_step``, ``complete``, etc.) delegate to them via
    ``_run_async`` for use in threaded task functions.

    Updates are persisted directly to the TaskStore (get → mutate → save).
    Push notifications are sent as individual A2A events to webhook URLs.
    Sync-to-async bridge: task functions run in a thread via asyncio.to_thread(),
    so we use asyncio.run_coroutine_threadsafe() for async store operations.
    """

    def __init__(
        self,
        *,
        task_id: str,
        context_id: str,
        session: AstaSession,
        loop: asyncio.AbstractEventLoop,
    ):
        self.task_id = task_id
        self.context_id = context_id
        self._session = session
        self._loop = loop
        self._current_step: StepProgress | None = None
        self._children: dict[str, StepProgress] = {}  # step_id → running child steps
        self._step_lock: asyncio.Lock = asyncio.Lock()
        self._metadata: dict[str, Any] = {}
        self._terminal_sent: bool = False
        self._published_artifact_ids: set[str] = set()

    @property
    def _store(self) -> Any:
        return self._session.task_store

    @property
    def _push_config_store(self) -> Any:
        return self._session.push_config_store

    def _run_async(self, coro: Any) -> Any:
        """Submit a coroutine to the event loop and wait for it."""
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=30)

    # --- Store helpers ---

    async def _update_task_status(
        self, state: TaskState, message: Message | None = None,
        *, final: bool = False,
    ) -> None:
        """Get current task from store, update its status, save back."""
        task = await self._store.get(self.task_id)
        if task is None:
            logger.warning("Task %s not found in store", self.task_id)
            return
        status = TaskStatus(
            state=state,
            message=message,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        task.status = status
        await self._store.save(task)
        await self._push_status_event(status, final=final)

    async def _add_artifact_to_task(self, artifact: Artifact) -> None:
        """Get current task from store, append artifact, save back."""
        task = await self._store.get(self.task_id)
        if task is None:
            logger.warning("Task %s not found in store", self.task_id)
            return
        if task.artifacts is None:
            task.artifacts = []
        task.artifacts.append(artifact)
        task.status = TaskStatus(
            state=TaskState.working,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        await self._store.save(task)
        await self._push_artifact_event(artifact)

    async def _save_metadata(self) -> None:
        """Persist metadata dict on the task."""
        task = await self._store.get(self.task_id)
        if task is None:
            return
        task.metadata = self._metadata
        await self._store.save(task)

    # --- Push notification helpers ---

    async def get_webhook_urls(self) -> list[str]:
        """Return the registered webhook URLs for this task."""
        return await self._get_push_urls()

    async def _get_push_urls(self) -> list[str]:
        """Get webhook URLs from push config store."""
        if not self._push_config_store:
            return []
        try:
            configs = await self._push_config_store.get_info(self.task_id)
            return [c.url for c in configs if c.url]
        except Exception:
            logger.debug("No push configs for task %s", self.task_id)
            return []

    async def _get_http_client(self) -> Any:
        return await self._session.get_http_client()

    async def _push_status_event(
        self, status: TaskStatus, *, final: bool = False
    ) -> None:
        """Send a TaskStatusUpdateEvent to all registered webhook URLs."""
        urls = await self._get_push_urls()
        if not urls:
            return
        event = TaskStatusUpdateEvent(
            task_id=self.task_id,
            context_id=self.context_id,
            status=status,
            final=final,
        )
        await self._push_event(event, urls)

    async def _push_artifact_event(self, artifact: Artifact) -> None:
        """Send a TaskArtifactUpdateEvent to all registered webhook URLs."""
        urls = await self._get_push_urls()
        if not urls:
            return
        event = TaskArtifactUpdateEvent(
            task_id=self.task_id,
            context_id=self.context_id,
            artifact=artifact,
        )
        await self._push_event(event, urls)

    async def _push_event(self, event: Any, urls: list[str]) -> None:
        """POST an event to all webhook URLs."""
        client = await self._get_http_client()
        payload = event.model_dump(mode="json", exclude_none=True)
        for url in urls:
            try:
                resp = await client.post(url, json=payload)
                logger.debug(
                    "Push notification to %s: status=%s", url, resp.status_code
                )
            except Exception:
                logger.exception("Push notification to %s failed", url)

    # --- Async step helpers ---

    async def _async_publish_step(self, step: StepProgress) -> None:
        step_data = step.model_dump(exclude_none=True)
        step_data["kind"] = "step-progress"
        status_message = Message(
            message_id=str(uuid.uuid4()),
            role="agent",
            parts=[DataPart(data=step_data)],
            task_id=self.task_id,
            context_id=self.context_id,
        )
        await self._update_task_status(TaskState.working, message=status_message)

    async def _async_finish_all_children(self) -> None:
        now = datetime.now(timezone.utc)
        for child in list(self._children.values()):
            if child.run_state == RunState.RUNNING:
                child.finished_at = now
                child.run_state = RunState.SUCCEEDED
                await self._async_publish_step(child)
        self._children.clear()

    async def _async_finish_current_step(self, is_success: bool = True, error_message: str | None = None) -> None:
        if self._current_step is None or self._current_step.run_state != RunState.RUNNING:
            return
        self._current_step.finished_at = datetime.now(timezone.utc)
        self._current_step.run_state = RunState.SUCCEEDED if is_success else RunState.FAILED
        self._current_step.error_message = error_message
        await self._async_publish_step(self._current_step)

    # --- Public async API ---

    def set_metadata(self, key: str, value: Any) -> None:
        """Store metadata locally. Attached to the task on terminal events."""
        self._metadata[key] = value

    async def async_start_step(self, short_desc: str, parent: StepProgress | None = None) -> StepProgress | None:
        """Start a new step and return it.

        Args:
            short_desc: Short label for the step.
            parent: If provided, this step is nested under the parent and
                tracked in ``_children``. Multiple children can coexist.
                If None, this is a top-level step that auto-finishes
                the previous top-level step and all its children.

        Duplicate calls with the same description and parent are
        silently skipped.
        """
        async with self._step_lock:
            try:
                if parent is not None:
                    # Check for duplicate
                    for child in self._children.values():
                        if (child.short_desc == short_desc
                                and child.parent_step_id == parent.step_id
                                and child.run_state == RunState.RUNNING):
                            return child
                    child = StepProgress(
                        short_desc=short_desc,
                        task_id=self.task_id,
                        parent_step_id=parent.step_id,
                        run_state=RunState.RUNNING,
                        started_at=datetime.now(timezone.utc),
                    )
                    child._ctx = self
                    self._children[str(child.step_id)] = child
                    await self._async_publish_step(child)
                    return child
                else:
                    # Top-level step — auto-finish all children + previous step
                    if (self._current_step
                            and self._current_step.short_desc == short_desc
                            and self._current_step.run_state == RunState.RUNNING):
                        return self._current_step
                    await self._async_finish_all_children()
                    await self._async_finish_current_step()
                    self._current_step = StepProgress(
                        short_desc=short_desc,
                        task_id=self.task_id,
                        run_state=RunState.RUNNING,
                        started_at=datetime.now(timezone.utc),
                    )
                    self._current_step._ctx = self
                    await self._async_publish_step(self._current_step)
                    return self._current_step
            except Exception:
                logger.exception("start_step failed")
                return None

    async def async_update_step(self, long_desc: str | None = None, short_desc: str | None = None,
                           step: StepProgress | None = None) -> None:
        """Update a step's description and re-publish.

        Args:
            step: The step to update. If None, updates the current top-level step.
        """
        try:
            target = step or self._current_step
            if target is None or target.run_state != RunState.RUNNING:
                return
            if long_desc is not None:
                target.long_desc = long_desc
            if short_desc is not None:
                target.short_desc = short_desc
            await self._async_publish_step(target)
        except Exception:
            logger.exception("update_step failed")

    async def async_finish_step(self, is_success: bool = True, error_message: str | None = None,
                           step: StepProgress | None = None) -> None:
        """Finish a step. If step is None, finishes the current top-level step."""
        try:
            target = step or self._current_step
            if target is None or target.run_state != RunState.RUNNING:
                return
            target.finished_at = datetime.now(timezone.utc)
            target.run_state = RunState.SUCCEEDED if is_success else RunState.FAILED
            target.error_message = error_message
            await self._async_publish_step(target)
            sid = str(target.step_id)
            if sid in self._children:
                del self._children[sid]
        except Exception:
            logger.exception("finish_step failed")

    async def async_append_item(
        self,
        label: str,
        parent: StepProgress | None = None,
        is_success: bool = True,
    ) -> None:
        """Append a finished item under a parent step.

        Use for streaming lists — paper titles arriving during retrieval,
        log lines, search hits. Items render as a row under the parent and
        have no child controls. Unlike :meth:`async_start_step`, the item
        is finished immediately and the caller can't update or extend it.
        """
        item = await self.async_start_step(label, parent=parent)
        if item is not None:
            await self.async_finish_step(is_success=is_success, step=item)

    async def async_publish_artifact(self, artifact: Any, parent: StepProgress | None = None) -> ArtifactRef:
        """Publish an artifact and return a reference to it.

        Accepts ``asta.artifact.Artifact``, ``dict``, or ``a2a.types.Artifact``.
        Duplicate artifacts (same ID) are silently skipped.

        If ``parent`` is provided, also shows the artifact as a resolved child
        step with an inline ``<artifact>`` tag.
        """
        try:
            from asta_artifact.artifact import Artifact as AstaArtifact

            if isinstance(artifact, AstaArtifact):
                subtype = artifact.subtype
                content_type = (
                    f"application/vnd.asta.{subtype}+json" if subtype
                    else "application/asta-artifact"
                )
                type_tag = subtype or "asta-artifact"
                a2a_artifact = Artifact(
                    artifact_id=artifact.id,
                    name=artifact.name,
                    description=artifact.description,
                    parts=[DataPart(
                        data=artifact.to_dict(),
                        metadata={"contentType": content_type},
                    )],
                    metadata={"type": type_tag},
                )
            elif isinstance(artifact, dict):
                a2a_artifact = Artifact(
                    artifact_id=artifact.get("id", str(uuid.uuid4())),
                    parts=[DataPart(
                        data=artifact,
                        metadata={"contentType": "application/asta-artifact"},
                    )],
                    metadata={"type": "asta-artifact"},
                )
            elif isinstance(artifact, Artifact):
                a2a_artifact = artifact
            else:
                raise TypeError(f"Unsupported artifact type: {type(artifact)}")

            if a2a_artifact.artifact_id in self._published_artifact_ids:
                return ArtifactRef(a2a_artifact.artifact_id, a2a_artifact.name)
            self._published_artifact_ids.add(a2a_artifact.artifact_id)

            await self._add_artifact_to_task(a2a_artifact)
            ref = ArtifactRef(a2a_artifact.artifact_id, a2a_artifact.name)

            if parent and ref.id:
                child = await self.async_start_step(ref.tag(), parent=parent)
                if child:
                    await self.async_finish_step(step=child)

            return ref
        except Exception:
            logger.exception("publish_artifact failed")
            return ArtifactRef("", None)

    async def async_publish_data_artifact(
        self,
        artifact_id: str,
        name: str,
        data: dict,
        subtype: str,
        description: str | None = None,
        parent: StepProgress | None = None,
    ) -> ArtifactRef:
        """Publish a typed data artifact, deriving MIME and metadata from subtype.

        Constructs ``contentType: application/vnd.asta.{subtype}+json`` and
        ``metadata.type: {subtype}`` automatically, so callers only need to
        supply the short subtype token (e.g. ``"paper-store"``).
        """
        artifact = Artifact(
            artifact_id=artifact_id,
            name=name,
            description=description,
            parts=[DataPart(
                data=data,
                metadata={"contentType": f"application/vnd.asta.{subtype}+json"},
            )],
            metadata={"type": subtype},
        )
        return await self.async_publish_artifact(artifact, parent=parent)

    async def async_complete(self, message: str | None = None) -> None:
        """Mark task as completed."""
        try:
            await self._async_finish_all_children()
            if self._current_step and self._current_step.run_state == RunState.RUNNING:
                await self._async_finish_current_step(is_success=True)

            status_msg = None
            if message:
                status_msg = Message(
                    message_id=str(uuid.uuid4()),
                    role="agent",
                    parts=[TextPart(text=message)],
                    task_id=self.task_id,
                    context_id=self.context_id,
                )

            if self._metadata:
                await self._save_metadata()

            await self._update_task_status(TaskState.completed, message=status_msg, final=True)
            self._terminal_sent = True
        except Exception:
            logger.exception("complete failed")

    async def async_fail(self, error: str = "") -> None:
        """Mark task as failed."""
        try:
            await self._async_finish_all_children()
            if self._current_step and self._current_step.run_state == RunState.RUNNING:
                await self._async_finish_current_step(is_success=False, error_message=error or None)

            await self._update_task_status(TaskState.failed, final=True)
            self._terminal_sent = True
        except Exception:
            logger.exception("fail failed")

    # --- Sync API (delegates to async via _run_async for use in threads) ---

    def start_step(self, short_desc: str, parent: StepProgress | None = None) -> StepProgress | None:
        """Start a new step. See :meth:`async_start_step` for full docs."""
        return self._run_async(self.async_start_step(short_desc, parent))

    def update_step(self, long_desc: str | None = None, short_desc: str | None = None,
                    step: StepProgress | None = None) -> None:
        """Update a step's description. See :meth:`async_update_step` for full docs."""
        self._run_async(self.async_update_step(long_desc, short_desc, step))

    def finish_step(self, is_success: bool = True, error_message: str | None = None,
                    step: StepProgress | None = None) -> None:
        """Finish a step. See :meth:`async_finish_step` for full docs."""
        self._run_async(self.async_finish_step(is_success, error_message, step))

    def append_item(
        self,
        label: str,
        parent: StepProgress | None = None,
        is_success: bool = True,
    ) -> None:
        """Append a finished item under a parent step. See :meth:`async_append_item`."""
        self._run_async(self.async_append_item(label, parent, is_success))

    def publish_artifact(self, artifact: Any, parent: StepProgress | None = None) -> ArtifactRef:
        """Publish an artifact. See :meth:`async_publish_artifact` for full docs."""
        return self._run_async(self.async_publish_artifact(artifact, parent))

    def publish_data_artifact(
        self,
        artifact_id: str,
        name: str,
        data: dict,
        subtype: str,
        description: str | None = None,
        parent: StepProgress | None = None,
    ) -> ArtifactRef:
        """Publish a typed data artifact. See :meth:`async_publish_data_artifact` for full docs."""
        return self._run_async(self.async_publish_data_artifact(
            artifact_id, name, data, subtype, description, parent
        ))

    def complete(self, message: str | None = None) -> None:
        """Mark task as completed. See :meth:`async_complete` for full docs."""
        self._run_async(self.async_complete(message))

    def fail(self, error: str = "") -> None:
        """Mark task as failed. See :meth:`async_fail` for full docs."""
        self._run_async(self.async_fail(error))

class NullContext(AstaContext):
    """No-op context that silently discards all updates.

    Use as a default so task functions work without an injected context.
    """

    def __init__(self):
        self.task_id = ""
        self.context_id = ""
        self._session = None
        self._loop = None
        self._current_step = None
        self._metadata = {}
        self._terminal_sent = False

    def _run_async(self, coro: Any) -> None:
        pass

    def set_metadata(self, key: str, value: Any) -> None:
        pass

    def start_step(self, short_desc: str, parent: Any = None) -> None:
        pass

    def finish_step(self, is_success: bool = True, error_message: str | None = None, step: Any = None) -> None:
        pass

    def update_step(self, long_desc: str | None = None, short_desc: str | None = None, step: Any = None) -> None:
        pass

    def append_item(self, label: str, parent: Any = None, is_success: bool = True) -> None:
        pass

    def publish_artifact(self, artifact: Any, parent: Any = None) -> ArtifactRef:
        return ArtifactRef("", None)

    def complete(self, message: str | None = None) -> None:
        pass

    def fail(self, error: str = "") -> None:
        pass

    async def async_start_step(self, short_desc: str, parent: Any = None) -> None:
        pass

    async def async_update_step(self, long_desc: str | None = None, short_desc: str | None = None, step: Any = None) -> None:
        pass

    async def async_finish_step(self, is_success: bool = True, error_message: str | None = None, step: Any = None) -> None:
        pass

    async def async_append_item(self, label: str, parent: Any = None, is_success: bool = True) -> None:
        pass

    async def async_publish_artifact(self, artifact: Any, parent: Any = None) -> ArtifactRef:
        return ArtifactRef("", None)

    async def async_publish_data_artifact(self, artifact_id: str, name: str, data: dict,
                                          subtype: str, description: str | None = None,
                                          parent: Any = None) -> ArtifactRef:
        return ArtifactRef("", None)

    def publish_data_artifact(self, artifact_id: str, name: str, data: dict,
                               subtype: str, description: str | None = None,
                               parent: Any = None) -> ArtifactRef:
        return ArtifactRef("", None)

    async def async_complete(self, message: str | None = None) -> None:
        pass

    async def async_fail(self, error: str = "") -> None:
        pass
