"""Asta SDK — Build A2A-compatible AI agent servers."""

from __future__ import annotations

from typing import Any, Callable

from asta_agent.context import AstaContext, NullContext
from asta_agent.registry import TaskDef, extract_params
from asta_agent.step import RunState, StepProgress


class Asta:
    """Declarative agent builder.

    Example::

        asta = Asta("MyAgent", description="...", version="1.0.0")

        @asta.task("Greet")
        def greet(name: str, ctx: AstaContext):
            ctx.start_step("Greeting")
            ctx.complete(f"Hello, {name}!")

        # Local dev (SQLite)
        asta.run(port=9000, storage="sqlite:///tasks.db")

        # Production (returns FastAPI app for uvicorn/Modal)
        app = asta.build(storage=os.environ["DATABASE_URL"])
    """

    def __init__(
        self,
        name: str,
        *,
        description: str = "",
        version: str = "1.0.1",
        modal: dict[str, Any] | None = None,
    ):
        self.name = name
        self.description = description
        self.version = version
        self.modal = modal or {}
        self._tasks: list[TaskDef] = []
        self._app = None

    def task(self, fn_or_name=None):
        """Register a function as a named A2A skill.

        Supports both bare and parameterized forms:
            @asta.task
            def my_task(query: str, ctx: AstaContext): ...

            @asta.task("Custom Name")
            def my_task(query: str, ctx: AstaContext): ...
        """
        if callable(fn_or_name):
            return self._register_task(fn_or_name, name=None)
        else:
            name = fn_or_name
            def decorator(fn):
                return self._register_task(fn, name=name)
            return decorator

    def _register_task(self, fn: Callable, name: str | None) -> Callable:
        if name is None:
            name = fn.__name__.replace("_", " ").title()
        params, context_param = extract_params(fn)
        task_def = TaskDef(
            name=name,
            fn=fn,
            params=params,
            context_param=context_param,
        )
        self._tasks.append(task_def)
        return fn

    @property
    def app(self) -> Any:
        """Lazy-built ASGI application, configured from environment variables.

        Reads DATABASE_URL and API_KEY from the environment.
        Suitable for ``uvicorn module:asta.app`` without a separate entrypoint.
        """
        if self._app is None:
            import os
            self._app = self.build(
                storage=os.environ.get("DATABASE_URL"),
                api_key=os.environ.get("API_KEY"),
            )
        return self._app

    def build(
        self,
        *,
        storage: str | None = None,
        url: str = "",
        api_key: str | None = None,
    ) -> Any:
        """Build and return a FastAPI application.

        Args:
            storage: Task store backend. One of:
                - None → InMemoryTaskStore
                - "sqlite:///path" → DatabaseTaskStore (SQLite)
                - "postgresql://..." → DatabaseTaskStore (Postgres)
            url: The public URL of the agent (for the agent card).
            api_key: Optional bearer token for API authentication.
                When set, all requests (except /healthz) must include
                ``Authorization: Bearer <api_key>``.
        """
        from asta_agent.server import build_app

        return build_app(
            name=self.name,
            description=self.description,
            version=self.version,
            tasks=self._tasks,
            storage=storage,
            url=url,
            api_key=api_key,
        )

    def run(
        self,
        *,
        port: int = 9000,
        host: str = "0.0.0.0",
        storage: str | None = None,
        api_key: str | None = None,
    ) -> None:
        """Build and run the agent server with uvicorn.

        Convenience method for local development.
        """
        import uvicorn

        app = self.build(storage=storage, url=f"http://{host}:{port}", api_key=api_key)
        uvicorn.run(app, host=host, port=port)
