"""AstaSession — process-level resources for an Asta agent.

Owns the task store, push notification config store, DB engine, and HTTP
client. Mints per-task :class:`AstaContext` via :meth:`task_context`.

Two construction modes:

- Built from a database URL — for sidecar agents that own their resources
  (e.g. dv-core's Modal-side Driver)::

      session = AstaSession(
          database_url=url, pool_class=NullPool, create_table=False,
      )

- Wrapping pre-built stores — for callers that already own a task store
  (e.g. tests, or embedders sharing a store with another component)::

      session = AstaSession(
          task_store=existing_store, push_config_store=existing_push_store,
      )

The SDK's ``build_app`` uses the first mode and shares ``session.task_store``
with the a2a-sdk request handler.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import TYPE_CHECKING, Any, Optional

from a2a.types import (
    Message,
    PushNotificationConfig,
    Task,
    TaskState,
    TaskStatus,
    TextPart,
)

if TYPE_CHECKING:
    from asta_agent.context import AstaContext


class AstaSession:
    """Long-lived holder of the resources an Asta agent shares across tasks.

    Mints fresh :class:`AstaContext` instances via :meth:`task_context`.
    Call :meth:`close` at process shutdown to dispose owned resources.
    """

    def __init__(
        self,
        *,
        database_url: Optional[str] = None,
        task_store: Any = None,
        push_config_store: Any = None,
        pool_class: Any = None,
        create_table: bool = True,
    ):
        """Construct an AstaSession.

        Args:
            database_url: PostgreSQL or SQLite URL. Ignored when
                ``task_store`` is provided.
            task_store: Pre-built ``TaskStore``. When provided, the
                session does not build or own an engine.
            push_config_store: Pre-built push config store. Defaults to
                a fresh ``InMemoryPushNotificationConfigStore``.
            pool_class: Optional SQLAlchemy pool class for engines built
                here. Pass ``sqlalchemy.pool.NullPool`` for long-lived
                sidecar deployments where idle connections would
                accumulate; leave unset to use SQLAlchemy's standard pool
                for server deployments serving concurrent requests.
            create_table: When building a ``DatabaseTaskStore`` from
                ``database_url``, whether to auto-create the task table
                on :meth:`initialize`. Default ``True`` fits SDK users
                pointing at an empty DB; pass ``False`` when the schema
                is managed by external migrations.
        """
        from a2a.server.tasks import InMemoryTaskStore
        from a2a.server.tasks.inmemory_push_notification_config_store import (
            InMemoryPushNotificationConfigStore,
        )

        engine = None
        if task_store is None:
            if database_url:
                from a2a.server.tasks import DatabaseTaskStore
                from sqlalchemy.ext.asyncio import create_async_engine

                url = database_url
                if url.startswith("postgresql://"):
                    url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
                elif url.startswith("sqlite:///"):
                    url = url.replace("sqlite:///", "sqlite+aiosqlite:///", 1)

                engine_kwargs: dict[str, Any] = {}
                if pool_class is not None:
                    engine_kwargs["poolclass"] = pool_class
                engine = create_async_engine(url, **engine_kwargs)
                task_store = DatabaseTaskStore(engine, create_table=create_table)
            else:
                task_store = InMemoryTaskStore()

        if push_config_store is None:
            push_config_store = InMemoryPushNotificationConfigStore()

        self._task_store = task_store
        self._push_config_store = push_config_store
        self._engine = engine
        self._http_client: Any = None

    @property
    def task_store(self) -> Any:
        return self._task_store

    @property
    def push_config_store(self) -> Any:
        return self._push_config_store

    async def initialize(self) -> None:
        """Run async setup the underlying stores need.

        Idempotent. With ``DatabaseTaskStore``, this triggers the eager
        ``CREATE TABLE`` so the first batch of concurrent requests don't
        race the lazy initialization path.
        """
        if hasattr(self._task_store, "initialize"):
            await self._task_store.initialize()

    async def register_webhook(self, task_id: str, url: str) -> None:
        """Register a push-notification webhook for ``task_id``.

        Sidecar deployments (no a2a request handler in front of the
        session) call this before :meth:`task_context` so completion
        events have somewhere to go. SDK deployments don't call this —
        the a2a-sdk ``DefaultRequestHandler`` writes to the same
        ``push_config_store`` itself before the executor runs.
        """
        await self._push_config_store.set_info(
            task_id, PushNotificationConfig(url=url)
        )

    async def task_context(
        self,
        task_id: str,
        context_id: str,
    ) -> "AstaContext":
        """Mint a fresh :class:`AstaContext` for one task.

        Ensures a ``submitted`` Task row exists in the store for
        ``task_id`` (idempotent). Push-notification config is registered
        separately — either by the a2a request handler (SDK path) or by
        calling :meth:`register_webhook` (sidecar path) — so this method
        is concerned only with task-row and context lifecycle.
        """
        from asta_agent.context import AstaContext

        await self._ensure_task_row(task_id, context_id)

        return AstaContext(
            task_id=task_id,
            context_id=context_id,
            session=self,
            loop=asyncio.get_running_loop(),
        )

    async def _ensure_task_row(self, task_id: str, context_id: str) -> None:
        if await self._task_store.get(task_id):
            return
        await self._task_store.save(Task(
            id=task_id,
            context_id=context_id,
            status=TaskStatus(
                state=TaskState.submitted,
                message=Message(
                    message_id=str(uuid.uuid4()),
                    role="agent",
                    parts=[TextPart(text="Task accepted")],
                    task_id=task_id,
                    context_id=context_id,
                ),
            ),
            final=False,
        ))

    async def get_http_client(self) -> Any:
        """Lazily build a shared HTTP client for webhook delivery."""
        if self._http_client is None:
            import httpx
            self._http_client = httpx.AsyncClient(timeout=10)
        return self._http_client

    async def close(self) -> None:
        """Dispose owned resources. Safe to call more than once."""
        if self._http_client is not None:
            try:
                await self._http_client.aclose()
            finally:
                self._http_client = None
        if self._engine is not None:
            try:
                await self._engine.dispose()
            finally:
                self._engine = None
