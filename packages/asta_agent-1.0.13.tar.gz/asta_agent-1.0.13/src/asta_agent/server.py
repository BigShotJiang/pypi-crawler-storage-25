"""FastAPI server builder for Asta agents."""

from __future__ import annotations

from typing import TYPE_CHECKING

from a2a.server.apps.jsonrpc.fastapi_app import A2AFastAPIApplication
from a2a.server.request_handlers import DefaultRequestHandler

from asta_agent.executor import AstaAgentExecutor
from asta_agent.registry import build_agent_card, task_input_schema
from asta_agent.session import AstaSession

if TYPE_CHECKING:
    from fastapi import FastAPI

    from asta_agent.registry import TaskDef


def build_app(
    name: str,
    description: str,
    version: str,
    tasks: list[TaskDef],
    *,
    storage: str | None = None,
    url: str = "",
    api_key: str | None = None,
) -> FastAPI:
    """Build a FastAPI application for the given Asta agent configuration.

    Args:
        storage: One of:
            - ``None`` → in-memory task store
            - ``"sqlite:///path"`` → SQLite-backed task store
            - ``"postgresql://..."`` → Postgres-backed task store
    """
    agent_card = build_agent_card(
        name=name,
        description=description,
        version=version,
        url=url,
        tasks=tasks,
    )

    # The session owns the stores (and any DB engine); the request
    # handler shares them so it reads/writes the same backing state the
    # executor's per-task AstaContexts do.
    session = AstaSession(database_url=storage)

    executor = AstaAgentExecutor(tasks, session=session)
    handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=session.task_store,
        push_config_store=session.push_config_store,
    )
    a2a_app = A2AFastAPIApplication(
        agent_card=agent_card,
        http_handler=handler,
    )
    app = a2a_app.build()

    # Eagerly initialize the task store so the first batch of concurrent
    # requests don't all race CREATE TABLE. With DatabaseTaskStore, the
    # lazy _ensure_initialized path lets multiple coroutines reach
    # CREATE TABLE simultaneously; one wins and the rest fail with a
    # Postgres unique-violation on pg_type. The losers leave the store
    # in a state where subsequent task lookups return None — the task is
    # "submitted" forever even as the executor runs the work to completion.
    # Running initialize once at startup avoids that.
    @app.on_event("startup")
    async def _initialize_session() -> None:
        await session.initialize()

    @app.on_event("shutdown")
    async def _close_session() -> None:
        await session.close()

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    schemas_by_skill = {td.skill_id: task_input_schema(td) for td in tasks}

    @app.get("/skills/{skill_id}/input-schema.json")
    async def skill_input_schema(skill_id: str):
        from starlette.responses import JSONResponse
        schema = schemas_by_skill.get(skill_id)
        if schema is None:
            return JSONResponse(status_code=404, content={"error": f"unknown skill: {skill_id!r}"})
        return schema

    if api_key:
        from starlette.responses import JSONResponse

        @app.middleware("http")
        async def check_bearer_token(request, call_next):
            if request.url.path == "/healthz":
                return await call_next(request)
            auth = request.headers.get("authorization", "")
            if auth != f"Bearer {api_key}":
                return JSONResponse(status_code=401, content={"error": "Unauthorized"})
            return await call_next(request)

    return app
