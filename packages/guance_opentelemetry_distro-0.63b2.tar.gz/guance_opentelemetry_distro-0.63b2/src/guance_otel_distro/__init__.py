import os

from opentelemetry.instrumentation.distro import BaseDistro
from opentelemetry.sdk._configuration import _OTelSDKConfigurator


class GuanceConfigurator(_OTelSDKConfigurator):
    pass


class GuanceDistro(BaseDistro):
    def _configure(self, **kwargs):
        os.environ.setdefault("OTEL_TRACES_EXPORTER", "otlp")
        os.environ.setdefault("OTEL_METRICS_EXPORTER", "otlp")
        os.environ.setdefault("OTEL_LOGS_EXPORTER", "otlp")
        os.environ.setdefault("OTEL_EXPORTER_OTLP_PROTOCOL", "http/protobuf")
