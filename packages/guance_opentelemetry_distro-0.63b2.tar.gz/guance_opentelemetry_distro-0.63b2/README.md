# Guance OpenTelemetry Distro

This package provides a Guance-flavored OpenTelemetry Python distro that bundles the upstream distro, the OTLP exporter, and the contrib instrumentation metapackage.
