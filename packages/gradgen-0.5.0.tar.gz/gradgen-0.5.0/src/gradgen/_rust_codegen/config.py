"""Backend configuration for Rust code generation."""

from __future__ import annotations

from dataclasses import dataclass, replace
from collections.abc import Iterable

from .naming import (
    validate_cargo_dependency_name,
    validate_rust_ident,
)
from .validation import (
    validate_backend_mode,
    validate_crate_name,
    validate_scalar_type
)


RustBackendMode = str
RustScalarType = str
CargoDependency = tuple[str, str | None]
RustBuildProfile = str


@dataclass(frozen=True, slots=True)
class RustBackendConfig:
    """Configuration for generated Rust source and project layout."""

    backend_mode: RustBackendMode = "std"
    scalar_type: RustScalarType = "f64"
    crate_name: str | None = None
    function_name: str | None = None
    header: str | None = None
    emit_metadata_helpers: bool = True
    enable_python_interface: bool = False
    build_python_interface: bool = True
    build_crate: bool = False
    build_profile: RustBuildProfile = "release"
    additional_dependencies: tuple[CargoDependency, ...] = ()

    def with_backend_mode(self,
                          backend_mode: RustBackendMode) \
            -> RustBackendConfig:
        """Return a copy with a different Rust backend mode."""
        validate_backend_mode(backend_mode)
        return replace(self, backend_mode=backend_mode)

    def with_scalar_type(self, scalar_type: RustScalarType) \
            -> RustBackendConfig:
        """Return a copy with a different generated Rust scalar type."""
        validate_scalar_type(scalar_type)
        return replace(self, scalar_type=scalar_type)

    def with_crate_name(self, crate_name: str | None) -> RustBackendConfig:
        """Return a copy with a different generated crate name."""
        validate_crate_name(crate_name)
        return replace(self, crate_name=crate_name)

    def with_function_name(self, function_name: str | None) \
            -> RustBackendConfig:
        """Return a copy with a different generated Rust function name."""
        validate_rust_ident(function_name, label="function_name")
        return replace(self, function_name=function_name)

    def with_header(self, header: str | None) -> RustBackendConfig:
        """Return a copy with a custom Rust module header.

        Args:
            header: Extra Rust source to insert near the top of generated
                ``src/lib.rs``. The text is written after crate attributes such
                as ``#![no_std]`` and ``#![forbid(unsafe_code)]``. The header
                is rendered as a small Jinja2 template with variables such as
                ``scalar_type``, ``backend_mode``, and ``math_library``.

        Returns:
            A copy of the config with the provided header text.
        """
        return replace(self, header=header)

    def with_emit_metadata_helpers(self,
                                   emit_metadata_helpers: bool) \
            -> RustBackendConfig:
        """Return a copy with metadata helper emission enabled or disabled."""
        return replace(self, emit_metadata_helpers=emit_metadata_helpers)

    def with_enable_python_interface(self,
                                     enable_python_interface: bool = True) \
            -> RustBackendConfig:
        """
        Return a copy with optional PyO3-based Python bindings enabled.
        """
        return replace(self, enable_python_interface=enable_python_interface)

    def with_build_python_interface(self,
                                    build_python_interface: bool = True) \
            -> RustBackendConfig:
        """
        Return a copy with Python wrapper compilation enabled or disabled.
        """
        if build_python_interface and not self.enable_python_interface:
            return ValueError(
                "To use with_build_python_interface, you first need "
                "to call with_enable_python_interface"
            )
        return replace(self, build_python_interface=build_python_interface)

    def with_build_crate(self, build_crate: bool = True) -> RustBackendConfig:
        """Return a copy with crate compilation enabled or disabled.

        Args:
            build_crate: Whether Gradgen should compile the generated
                low-level Rust crate after writing it to disk.

        Returns:
            A copy of the config with crate compilation enabled or disabled.
        """
        return replace(self, build_crate=build_crate)

    def with_build_profile(
        self,
        build_profile: RustBuildProfile,
    ) -> RustBackendConfig:
        """Return a copy with a different Cargo build profile.

        Args:
            build_profile: Cargo profile used when ``build_crate`` is enabled.
                Supported values are ``"debug"`` and ``"release"``.

        Returns:
            A copy of the config with the requested build profile.
        """
        if build_profile not in {"debug", "release"}:
            raise ValueError(
                "build_profile must be either 'debug' or 'release'"
            )
        return replace(self, build_profile=build_profile)

    def with_additional_dependencies(
        self,
        dependencies: Iterable[str | CargoDependency],
    ) -> RustBackendConfig:
        """Return a copy with extra Cargo dependencies added.

        Args:
            dependencies: Additional dependencies to include in the generated
                ``Cargo.toml``. Each item may be either a dependency name, in
                which case the version defaults to ``"*"`` in Cargo syntax, or
                a ``(name, version)`` pair.

        Returns:
            A copy of the config with the normalized dependency list.
        """
        normalized: list[CargoDependency] = []
        for dependency in dependencies:
            if isinstance(dependency, str):
                name = dependency
                version = None
            else:
                name, version = dependency
            validate_cargo_dependency_name(name)
            if version is not None and not isinstance(version, str):
                raise TypeError(
                    "Cargo dependency versions must be strings or None"
                )
            normalized.append((name, version))
        return replace(self, additional_dependencies=tuple(normalized))
