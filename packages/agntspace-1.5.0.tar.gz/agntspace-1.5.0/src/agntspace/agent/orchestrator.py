"""Subagent orchestration: dispatch subagents with role-scoped prompts."""

from __future__ import annotations

import contextlib
import logging
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import aiosqlite

from agntspace.llm.base import LLMProvider, Message
from agntspace.vault.reader import VaultReader

if TYPE_CHECKING:
    from agntspace.security.contract import ContractEnforcer
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


@dataclass
class SubagentDef:
    """Parsed subagent definition from vault/system/agents/*.md."""

    name: str
    role: str
    personality: str
    capabilities: str
    boundaries: str
    skills: list[str] = field(default_factory=list)
    access: str = "read-only"
    status: str = "active"
    allowed_tools: list[str] = field(default_factory=list)  # explicit override (empty = auto-infer)
    agent_type: str = "specialist"  # "specialist" or "supervisor"
    team: list[str] = field(default_factory=list)  # agent keys this supervisor manages
    workflows: list[str] = field(default_factory=list)  # workflow IDs this supervisor runs
    model_tier: str = "capable"  # "reasoning", "capable", or "fast"


# ── Tool permission tiers ──
# Auto-inferred from access level. Each tier includes all tools from lower tiers.

_READ_TOOLS = frozenset({  # arch:deterministic — tool-registry classification (which built-in tools are structurally read-only); derived from the tool definitions themselves, not a user-tunable policy
    "search_vault", "read_vault_file", "list_tasks", "list_goals",
    "list_projects", "recall_memory", "query_memory_graph", "query_knowledge",
    "list_subagents",
    "read_inbox", "read_email", "get_inbox_count", "research_kb",
})

_DRAFT_TOOLS = _READ_TOOLS | frozenset({
    "save_draft", "journal_write", "create_task", "create_project",
    "add_project_milestone", "log_project_progress", "update_project",
})

_WRITE_TOOLS = _DRAFT_TOOLS | frozenset({
    "send_email", "correct_memory", "delegate_to_subagent",
})

ACCESS_TOOL_TIERS: dict[str, frozenset[str]] = {
    "read-only": _READ_TOOLS,
    "read-write-drafts": _DRAFT_TOOLS,
    "read-write": _WRITE_TOOLS,
}

# Skills that grant additional tools beyond the access tier.
# If a subagent has the skill, it gets these tools even if the tier
# wouldn't normally include them.
SKILL_TOOL_GRANTS: dict[str, list[str]] = {
    "email-drafter": ["save_draft", "read_inbox", "read_email"],
    "triage": ["read_inbox", "read_email", "get_inbox_count"],
    "report-generator": ["search_vault", "read_vault_file", "research_kb"],
    "vault-manager": ["search_vault", "read_vault_file", "correct_memory"],
    "daily-briefing": ["read_inbox", "get_inbox_count", "list_tasks", "list_goals", "list_projects"],
    "knowledge-taxonomy": ["research_kb", "search_vault"],
    "meeting-prep": ["read_inbox", "read_email", "list_tasks", "search_vault"],
    "review": ["read_vault_file", "search_vault"],
    "ontology": ["update_ontology", "query_knowledge", "query_memory_graph"],
    "epistemic-audit": ["query_knowledge", "query_memory_graph", "search_vault"],
    "conceptual-analysis": ["query_knowledge", "query_memory_graph", "search_vault"],
    "presentation": ["create_presentation", "ingest_output", "search_vault", "query_knowledge"],
}


@dataclass
class SubagentResult:
    """Result from a subagent dispatch."""

    agent_name: str
    content: str
    input_tokens: int = 0
    output_tokens: int = 0


class Orchestrator:
    """Loads subagent definitions and dispatches tasks to them."""

    def __init__(
        self,
        vault: VaultReader,
        llm: LLMProvider,
        skill_loader: SkillLoader | None = None,
        contract: ContractEnforcer | None = None,
        db: aiosqlite.Connection | None = None,
    ) -> None:
        self._vault = vault
        self._llm = llm
        self._skill_loader = skill_loader
        self._contract = contract
        self._db = db
        self._agents: dict[str, SubagentDef] = {}
        self._active_dispatches: dict[str, str] = {}  # agent_key → task
        self._active_tasks: dict[str, str] = {}  # background activity: agent_key → task
        self._registry: object | None = None  # injected post-hoc for tool access
        self._model_router: object | None = None  # injected post-hoc for tier resolution
        self._tool_executor: object | None = None  # injected post-hoc for tool execution
        self._heartbeat: object | None = None  # injected post-hoc for pulse recording
        self._writer: object | None = None  # injected post-hoc — VaultWriter for trusted_scope

    def load_agents(self) -> dict[str, SubagentDef]:
        """Load all subagent definitions from vault/system/agents/."""
        self._agents.clear()
        files = self._vault.list_files("system/agents", "*.md")

        for f in files:
            try:
                doc = self._vault.read(f"system/agents/{f.name}")
                meta = doc.metadata
                self._agents[f.stem] = SubagentDef(
                    name=meta.get("title", f.stem),
                    role=meta.get("role", ""),
                    personality=self._extract_section(doc.content, "Personality"),
                    capabilities=self._extract_section(doc.content, "Capabilities")
                        or self._extract_section(doc.content, "Domain Expertise"),
                    boundaries=self._extract_section(doc.content, "Boundaries"),
                    skills=meta.get("skills", []),
                    access=meta.get("access", "read-only"),
                    status=meta.get("status", "active"),
                    allowed_tools=meta.get("allowed_tools", []),
                    agent_type=meta.get("type", "specialist"),
                    team=meta.get("team", []),
                    workflows=meta.get("workflows", []),
                    model_tier=meta.get("model_tier", "capable"),
                )
            except Exception:
                log.warning("Failed to load agent: %s", f.name)

        log.debug("Loaded %d subagent definitions", len(self._agents))
        return self._agents

    @property
    def agents(self) -> dict[str, SubagentDef]:
        if not self._agents:
            self.load_agents()
        return self._agents

    def list_agents(self) -> list[dict]:
        """List available subagents for API/UI."""
        return [
            {
                "key": key,
                "name": a.name,
                "role": a.role,
                "status": a.status,
                "skills": a.skills,
                "access": a.access,
                "effective_tools": sorted(self.get_allowed_tools(key)),
                "type": a.agent_type,
                "team": a.team,
                "workflows": a.workflows,
            }
            for key, a in self.agents.items()
        ]

    def get_allowed_tools(self, agent_key: str) -> set[str]:
        """Compute the effective tool set for a subagent.

        Resolution order:
        1. If allowed_tools is explicitly set → use that (power-user override)
        2. Otherwise → access tier tools + skill-granted tools
        3. Intersect with contract-allowed tools (global ceiling)
        """
        agent_def = self.agents.get(agent_key)
        if not agent_def:
            return set()

        if agent_def.allowed_tools:
            # Explicit override
            tools = set(agent_def.allowed_tools)
        else:
            # Auto-infer from access tier
            tools = set(ACCESS_TOOL_TIERS.get(agent_def.access, _READ_TOOLS))

            # Add skill-granted tools (prefer skill's own tools_granted, fallback to hardcoded map)
            for skill_name in agent_def.skills:
                if self._skill_loader:
                    skill = self._skill_loader.get_skill(skill_name)
                    if skill and skill.tools_granted:
                        tools.update(skill.tools_granted)
                        continue
                grants = SKILL_TOOL_GRANTS.get(skill_name, [])
                tools.update(grants)

        # Add external MCP tools for read-write agents
        # (MCP tools are opaque — we can't know if they read or write,
        # so only full-access agents get them unless explicitly listed)
        if agent_def.access == "read-write" and self._registry and self._registry._mcp_client:
            for ext in self._registry._mcp_client.get_external_tool_definitions():
                tools.add(ext["name"])

        # Contract ceiling: remove any tool whose contract action is blocked
        if self._contract:
            from agntspace.agent.tools import TOOL_CONTRACT_MAP
            blocked = set()
            for tool_name in tools:
                action = TOOL_CONTRACT_MAP.get(tool_name)
                if action:
                    result = self._contract.check(action)
                    if not result.allowed:
                        blocked.add(tool_name)
            tools -= blocked

        return tools

    async def dispatch(
        self,
        agent_name: str,
        task: str,
        context: str = "",
        *,
        skill_scope: str | None = None,
    ) -> SubagentResult:
        """Dispatch a task to a specific subagent.

        Contract enforcement: the main agent's contract is always checked
        before dispatch and its rules are injected into the subagent's
        system prompt. Subagents inherit at least the same restrictions.

        Args:
            skill_scope: When set, constrains the tool definitions to
                ONLY the named skill's ``tools_granted`` + a minimal
                read-only base set (vault_search, query_knowledge). This
                prevents the access-tier's full tool set from confusing
                small local LLMs — they see 3 tools instead of 18 and
                are far more likely to call the right one. Used by
                ``Agent.invoke_skill()`` to focus the librarian on
                ``run_wiki_job`` instead of ``read_email``.
        """
        agent_def = self.agents.get(agent_name)
        if not agent_def:
            raise ValueError(f"Unknown subagent: {agent_name}")

        if agent_def.status != "active":
            raise ValueError(f"Subagent '{agent_name}' is not active")

        # Contract gate: check before any subagent runs
        if self._contract:
            result = self._contract.check("delegate_task")
            if not result.allowed:
                raise ValueError(f"Contract blocked delegation: {result.reason}")

        system = self._build_subagent_prompt(agent_name, agent_def, context)
        messages = [Message(role="user", content=task)]

        # Track active dispatch
        self._active_dispatches[agent_name] = task
        started = datetime.now(UTC).isoformat()
        t0 = time.monotonic()

        # Record dispatch start pulse
        if self._heartbeat and hasattr(self._heartbeat, "record_pulse"):
            try:
                await self._heartbeat.record_pulse(
                    "dispatch", details=f"{agent_name}: {task[:120]}"
                )
            except Exception:
                pass

        try:
            response = await self._dispatch_with_tools(
                agent_name, agent_def, messages, system,
                skill_scope=skill_scope,
            )
        finally:
            self._active_dispatches.pop(agent_name, None)

        duration_ms = int((time.monotonic() - t0) * 1000)

        log.info(
            "Subagent '%s' completed: %d input, %d output tokens (%dms)",
            agent_name,
            response.input_tokens,
            response.output_tokens,
            duration_ms,
        )

        # Log to database
        await self._log_dispatch(
            agent_key=agent_name,
            agent_name=agent_def.name,
            task=task,
            context=context,
            content=response.content,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            started_at=started,
            duration_ms=duration_ms,
        )

        # Log to activity logger
        if hasattr(self, "_activity") and self._activity:
            try:
                self._activity.log("dispatch", "completed",
                                   f"'{agent_name}' completed in {duration_ms}ms: {task[:80]}",
                                   {"agent": agent_name, "task": task[:200],
                                    "duration_ms": duration_ms,
                                    "tokens": response.input_tokens + response.output_tokens})
            except Exception:
                pass

        # Log to decision logger — record WHY this dispatch happened
        decisions = getattr(self, "_decisions", None)
        if decisions is not None:
            try:
                await decisions.record(
                    actor="main",
                    action_type="dispatch",
                    action_target=agent_name,
                    contract_action="delegate_task",
                    contract_result="allowed",
                    triggered_by="chat_tool",
                    context_skills=list(agent_def.skills or []),
                    rationale=f"Dispatched {agent_name} ({agent_def.name}): {task[:120]}",
                    details={
                        "task_preview": task[:200],
                        "duration_ms": duration_ms,
                        "input_tokens": response.input_tokens,
                        "output_tokens": response.output_tokens,
                        "agent_type": agent_def.type if hasattr(agent_def, "type") else "specialist",
                    },
                )
            except Exception:
                log.debug("Decision log record failed for dispatch %s", agent_name, exc_info=True)

        return SubagentResult(
            agent_name=agent_name,
            content=response.content,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
        )

    async def _dispatch_with_tools(
        self,
        agent_name: str,
        agent_def: SubagentDef,
        messages: list[Message],
        system: str,
        *,
        skill_scope: str | None = None,
    ) -> object:
        """Run a subagent dispatch with tool execution if tools are available.

        If the orchestrator has a registry and tool executor, subagents can
        call tools within their permission scope. Otherwise falls back to
        plain text completion.

        When ``skill_scope`` is set, the tool list is constrained to ONLY
        the named skill's ``tools_granted`` + a minimal read-only base
        (vault_search, query_knowledge, list_subagents). This dramatically
        reduces tool confusion on small local LLMs — the librarian sees 3
        relevant tools instead of 18 irrelevant ones.
        """
        import json as _json

        # Resolve model tier from agent definition (e.g., "fast" → "claude-haiku-4-5")
        resolved_model = None
        if agent_def.model_tier and self._model_router and hasattr(self._model_router, "resolve"):
            resolved_model = self._model_router.resolve(agent_def.model_tier)

        # Get filtered tool definitions for this agent.
        # When skill_scope is set (invoke_skill path), use ONLY the
        # skill's tools_granted instead of the full access tier — this
        # is the key fix for the librarian calling read_email instead
        # of run_wiki_job on small models. The minimal read base
        # ensures the agent can still search/query during the skill run.
        tool_defs = None
        if self._registry and self._tool_executor:
            if skill_scope and self._skill_loader:
                skill = self._skill_loader.get_skill(skill_scope)
                if skill and skill.tools_granted:
                    _MINIMAL_READ = {"vault_search", "query_knowledge", "list_subagents"}
                    allowed = set(skill.tools_granted) | _MINIMAL_READ
                else:
                    allowed = self.get_allowed_tools(agent_name)
            else:
                allowed = self.get_allowed_tools(agent_name)
            if allowed:
                all_tools = self._registry.get_tool_definitions()
                tool_defs = [t for t in all_tools if t["name"] in allowed]

        if tool_defs and self._tool_executor:
            # Tool-enabled dispatch — same loop pattern as Agent.process_task()
            # Wrap the entire tool loop in trusted_scope so every vault
            # write from tool handlers passes the runtime guard. Without
            # this, tools like update_ontology, correct_memory,
            # journal_write — which call writer.write() without
            # contract_action — raise ContractBypassError when called
            # inside a correlation scope (invoke_skill, channel webhook).
            from contextlib import ExitStack
            _exit_stack = ExitStack()
            _writer = getattr(self, "_writer", None)
            if _writer and hasattr(_writer, "trusted_scope"):
                _exit_stack.enter_context(_writer.trusted_scope("subagent_tool"))

            valid_tools = {t["name"] for t in tool_defs}
            max_rounds = 5

            with _exit_stack:
              for _ in range(max_rounds):
                response = await self._llm.complete_with_tools(
                    messages=messages,
                    tools=tool_defs,
                    system=system,
                    max_tokens=4096,
                    model=resolved_model,
                )

                if response.tool_calls:
                    # Validate tool names
                    invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                    if invalid:
                        log.warning(
                            "Subagent '%s' tried invalid tools: %s",
                            agent_name, ", ".join(tc.name for tc in invalid),
                        )
                        break  # fall through to return what we have

                    messages.append(Message(
                        role="assistant",
                        content=response.raw_content or response.content,
                    ))

                    for tc in response.tool_calls:
                        log.info("Subagent '%s' tool: %s", agent_name, tc.name)

                        # Per-tool contract enforcement
                        if self._contract:
                            from agntspace.agent.tools import TOOL_CONTRACT_MAP
                            contract_action = TOOL_CONTRACT_MAP.get(tc.name)
                            if not contract_action and self._registry:
                                tool_reg = self._registry._tools.get(tc.name)
                                if tool_reg:
                                    contract_action = getattr(tool_reg, "contract_action", None)
                            if contract_action:
                                check = self._contract.check(contract_action)
                                if not check.allowed:
                                    log.warning("Contract blocked subagent '%s' tool '%s': %s",
                                                agent_name, tc.name, check.reason)
                                    messages.append(Message(
                                        role="tool",
                                        content=f'{{"error": "Contract blocked: {check.reason}"}}',
                                        tool_call_id=tc.id,
                                    ))
                                    # Decision log — record the block with full context
                                    decisions = getattr(self, "_decisions", None)
                                    if decisions is not None:
                                        try:
                                            await decisions.record(
                                                actor=agent_name,
                                                action_type="tool",
                                                action_target=tc.name,
                                                contract_action=contract_action,
                                                contract_result="blocked",
                                                triggered_by="subagent",
                                                context_skills=list(agent_def.skills or []),
                                                rationale=f"Contract blocked: {check.reason}",
                                            )
                                        except Exception:
                                            pass
                                    continue

                        # Route MCP tools to the async MCP client
                        if tc.name.startswith("mcp_") and self._registry and self._registry._mcp_client:
                            try:
                                result = await self._registry._mcp_client.call_tool(tc.name, tc.input)
                            except Exception as e:
                                result = {"error": f"MCP tool failed: {e}"}
                        else:
                            # Try ToolExecutor first, fall back to registry for tools
                            # registered via register_tool() (e.g. heal_agents)
                            result = self._tool_executor.execute(tc.name, tc.input)
                            if result.get("error", "").startswith("Unknown tool:") and self._registry:
                                # Use async handler if available (we're already in async context)
                                tool_def = self._registry._tools.get(tc.name)
                                if tool_def and tool_def.async_handler:
                                    try:
                                        result = await tool_def.async_handler(tc.input)
                                    except Exception as e:
                                        log.exception("Async tool execution failed: %s", tc.name)
                                        result = {"error": str(e)}
                                else:
                                    result = self._registry.execute(tc.name, tc.input)
                        messages.append(Message(
                            role="tool",
                            content=_json.dumps(result),
                            tool_call_id=tc.id,
                        ))

                        # Decision log — record the successful subagent tool call
                        decisions = getattr(self, "_decisions", None)
                        if decisions is not None:
                            try:
                                await decisions.record(
                                    actor=agent_name,
                                    action_type="tool",
                                    action_target=tc.name,
                                    contract_action=contract_action or "",
                                    contract_result="allowed",
                                    triggered_by="subagent",
                                    context_skills=list(agent_def.skills or []),
                                    rationale=f"Subagent {agent_name} invoked {tc.name}",
                                    details={"input_keys": sorted(tc.input.keys()) if isinstance(tc.input, dict) else []},
                                )
                            except Exception:
                                pass
                    continue

                # No tool calls — final response
                return response

            # Exhausted rounds — return last response
            return response

        # Fallback: plain text completion (no tools available)
        return await self._llm.complete(
            messages=messages,
            system=system,
            max_tokens=4096,
            model=resolved_model,
        )

    async def dispatch_parallel(
        self,
        dispatches: list[tuple[str, str]],
        context: str = "",
    ) -> list[SubagentResult]:
        """Dispatch tasks to multiple subagents concurrently.

        Args:
            dispatches: list of (agent_name, task) tuples.
            context: shared context for all subagents.
        """
        import asyncio

        tasks = [
            self.dispatch(agent_name, task, context)
            for agent_name, task in dispatches
        ]
        return list(await asyncio.gather(*tasks))

    def select_agent(self, task_description: str) -> str | None:
        """Select the best subagent for a task based on role matching."""
        lower = task_description.lower()
        scores: dict[str, int] = {}

        for key, agent_def in self.agents.items():
            if agent_def.status != "active":
                continue
            score = 0
            role_words = agent_def.role.lower().split()
            for word in role_words:
                if word in lower:
                    score += 2
            cap_words = agent_def.capabilities.lower().split()
            for word in cap_words:
                if len(word) > 3 and word in lower:
                    score += 1
            if score > 0:
                scores[key] = score

        if not scores:
            return None
        return max(scores, key=lambda k: scores[k])

    def get_active_dispatches(self) -> dict[str, str]:
        """Get all currently active work: dispatches + background tasks."""
        merged = dict(self._active_tasks)
        merged.update(self._active_dispatches)  # dispatches take priority
        return merged

    @contextlib.contextmanager
    def track_activity(self, agent_key: str, task: str):
        """Context manager to track background activity (non-dispatch work).

        Makes background tasks (daily cycle, channel messages, etc.)
        visible in the constellation and workflow views.
        """
        self._active_tasks[agent_key] = task
        try:
            yield
        finally:
            self._active_tasks.pop(agent_key, None)

    @contextlib.asynccontextmanager
    async def track_activity_async(self, agent_key: str, task: str):
        """Async context manager to track background activity."""
        self._active_tasks[agent_key] = task
        # Record background activity as a pulse
        if self._heartbeat and hasattr(self._heartbeat, "record_pulse"):
            try:
                await self._heartbeat.record_pulse(
                    "dispatch", details=f"{agent_key}: {task[:120]}"
                )
            except Exception:
                pass
        try:
            yield
        finally:
            self._active_tasks.pop(agent_key, None)

    async def log_background_task(
        self,
        agent_key: str,
        task: str,
        context: str = "",
        content: str = "",
        input_tokens: int = 0,
        output_tokens: int = 0,
        started_at: str = "",
        duration_ms: int = 0,
    ) -> None:
        """Log a background task to dispatch_log for timeline visibility."""
        if not self._db:
            return
        agent_def = self._agents.get(agent_key)
        agent_name = agent_def.name if agent_def else agent_key
        await self._log_dispatch(
            agent_key=agent_key,
            agent_name=agent_name,
            task=task,
            context=context,
            content=content[:500] if content else "",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            started_at=started_at or datetime.now(UTC).isoformat(),
            duration_ms=duration_ms,
        )

    async def get_dispatch_log(self, limit: int = 50, agent_key: str | None = None) -> list[dict]:
        """Get recent dispatch history."""
        if not self._db:
            return []
        query = "SELECT * FROM dispatch_log"
        params: list = []
        if agent_key:
            query += " WHERE agent_key = ?"
            params.append(agent_key)
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        async with self._db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
        return [dict(r) for r in rows]

    async def get_agent_stats(self) -> list[dict]:
        """Get per-agent dispatch statistics."""
        if not self._db:
            return []
        query = """
            SELECT agent_key, agent_name,
                   COUNT(*) as total_dispatches,
                   SUM(input_tokens) as total_input_tokens,
                   SUM(output_tokens) as total_output_tokens,
                   AVG(duration_ms) as avg_duration_ms,
                   MAX(started_at) as last_dispatch
            FROM dispatch_log
            WHERE status = 'completed'
            GROUP BY agent_key
        """
        async with self._db.execute(query) as cursor:
            rows = await cursor.fetchall()
        return [dict(r) for r in rows]

    async def _log_dispatch(
        self,
        agent_key: str,
        agent_name: str,
        task: str,
        context: str,
        content: str,
        input_tokens: int,
        output_tokens: int,
        started_at: str,
        duration_ms: int,
    ) -> None:
        """Log a completed dispatch to the database."""
        if not self._db:
            return
        try:
            await self._db.execute(
                """INSERT INTO dispatch_log
                   (agent_key, agent_name, task, context, status, content,
                    input_tokens, output_tokens, started_at, completed_at, duration_ms)
                   VALUES (?, ?, ?, ?, 'completed', ?, ?, ?, ?, ?, ?)""",
                (
                    agent_key, agent_name, task, context, content,
                    input_tokens, output_tokens, started_at,
                    datetime.now(UTC).isoformat(), duration_ms,
                ),
            )
            await self._db.commit()
        except Exception:
            log.warning("Failed to log dispatch", exc_info=True)

    def _build_subagent_prompt(self, agent_key: str, agent_def: SubagentDef, context: str) -> str:
        """Build a role-scoped system prompt for a subagent.

        Injects:
        1. Tool permissions (auto-inferred from access + skills)
        2. The full body of each assigned skill
        3. The contract rules — subagents inherit the main agent's contract
        """
        # Compute effective tools for this subagent
        allowed = self.get_allowed_tools(agent_key)

        parts = [
            f"# Role: {agent_def.name}",
            f"You are the {agent_def.name}, a {agent_def.role}.",
            "",
            f"## Personality\n{agent_def.personality}",
            f"## Capabilities\n{agent_def.capabilities}",
            f"## Boundaries\n{agent_def.boundaries}",
            "",
            "## Rules",
            "- All output goes to the main agent, not directly to the human.",
            "- Stay within your defined capabilities and boundaries.",
            f"- Access level: {agent_def.access}.",
        ]
        # Tool permissions — explicit about what this subagent can and cannot do
        if allowed:
            parts.extend([
                "",
                "## Permitted Tools",
                f"You may ONLY reference or request these tools: {', '.join(sorted(allowed))}",
                "Do NOT suggest or attempt any action that requires a tool not in this list.",
            ])
        else:
            parts.extend([
                "",
                "## Tool Restrictions",
                "You have NO tool access. Provide analysis, recommendations, and text only.",
            ])
        # Contract rules — subagents are bound by the same contract as the main agent
        contract_text = self._get_contract_rules_text()
        if contract_text:
            parts.extend(["", "## Contract (BINDING — inherited from main agent)", ""])
            parts.append(contract_text)
        # Inject assigned skill bodies
        if agent_def.skills and self._skill_loader:
            skill_sections = []
            for skill_name in agent_def.skills:
                skill = self._skill_loader.get_skill(skill_name)
                if skill and skill.body.strip():
                    skill_sections.append(
                        f"### {skill.title} ({skill.name})\n{skill.body.strip()}"
                    )
            if skill_sections:
                parts.extend(["", "## Skills", ""])
                parts.append("\n\n".join(skill_sections))
        if context:
            parts.extend(["", f"## Context\n{context}"])
        return "\n".join(parts)

    def _get_contract_rules_text(self) -> str:
        """Build a human-readable summary of contract rules for subagent prompts."""
        if not self._contract:
            return ""
        rules = self._contract.rules
        lines = [
            f"Default policy: {rules.default}-deny (actions not listed below are forbidden).",
            "",
        ]
        if rules.block:
            lines.append("**Blocked actions** (NEVER do these):")
            for a in sorted(rules.block):
                lines.append(f"- {a}")
            lines.append("")
        if rules.confirm:
            lines.append("**Requires user confirmation** (do NOT proceed without approval):")
            for a in sorted(rules.confirm):
                lines.append(f"- {a}")
            lines.append("")
        if rules.allow:
            lines.append("**Allowed actions:**")
            for a in sorted(rules.allow):
                lines.append(f"- {a}")
            lines.append("")
        if rules.gated_dirs:
            lines.append("**Gated directories** (require confirmation before access):")
            for d in rules.gated_dirs:
                lines.append(f"- {d}/")
            lines.append("")
        lines.append(f"Proactivity level: {rules.proactivity}")
        lines.append(f"Privacy mode: {rules.privacy_mode}")
        return "\n".join(lines)

    @staticmethod
    def _extract_section(content: str, heading: str) -> str:
        """Extract content under a markdown heading."""
        import re

        pattern = rf"## {re.escape(heading)}\s*\n(.*?)(?=\n## |\Z)"
        match = re.search(pattern, content, re.DOTALL)
        return match.group(1).strip() if match else ""
