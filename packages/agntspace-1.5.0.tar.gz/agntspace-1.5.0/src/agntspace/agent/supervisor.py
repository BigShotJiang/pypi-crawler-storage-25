"""Workflow Supervisor — adaptive multi-agent workflow execution.

The supervisor sits between workflow definitions and the orchestrator.
It decides what to do next based on results, not a hardcoded sequence.

Architecture:
    Workflow definition (declarative steps)
      → Supervisor (LLM-powered coordinator)
        → Orchestrator (execution engine: dispatch, tools, contract)

The supervisor can:
- Execute steps sequentially or in parallel
- Loop back when quality is insufficient
- Skip steps that aren't needed
- Abort early on blocking issues
- Dynamically insert steps based on results
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from agntspace.llm.base import Message

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.llm.base import LLMProvider

log = logging.getLogger(__name__)

# Maximum supervisor iterations to prevent runaway loops
MAX_ITERATIONS = 15


@dataclass
class WorkflowStep:
    """A step in a workflow definition."""

    id: str
    agent_key: str
    label: str
    description: str
    skills: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)


@dataclass
class WorkflowDef:
    """Declarative workflow definition."""

    id: str
    name: str
    description: str
    supervisor: str = ""  # agent key of the supervisor for this workflow
    steps: list[WorkflowStep] = field(default_factory=list)


@dataclass
class StepResult:
    """Result from executing a single workflow step."""

    step_id: str
    agent_key: str
    content: str
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: int = 0
    iteration: int = 1  # which attempt (1 = first, 2+ = feedback loop)


@dataclass
class SupervisorDecision:
    """Parsed decision from the supervisor LLM."""

    action: str  # "dispatch", "parallel", "loop", "skip", "done", "abort"
    steps: list[str] = field(default_factory=list)  # step IDs to dispatch
    feedback: str = ""  # feedback context for loop actions
    reason: str = ""  # why this decision


@dataclass
class WorkflowExecution:
    """Full execution record for a workflow run."""

    workflow_id: str
    started_at: str = ""
    completed_at: str = ""
    status: str = "running"  # running, completed, aborted
    step_results: list[StepResult] = field(default_factory=list)
    supervisor_log: list[dict[str, Any]] = field(default_factory=list)
    total_iterations: int = 0


_SUPERVISOR_PROMPT = """You are {supervisor_name}, a {supervisor_role}.

{supervisor_personality}

{supervisor_expertise}

## Workflow: {workflow_name}
{workflow_description}

## Your Team
{team_description}

## Available Steps
{steps_description}

## Execution History
{execution_history}

## Actions
Based on the results so far and your domain expertise, decide what to do next:

- **dispatch <step_id>** — run a specific step next
- **parallel <step_id_1> <step_id_2>** — run multiple independent steps concurrently
- **loop <step_id> "<feedback>"** — re-run a step with feedback (quality was insufficient)
- **skip <step_id> "<reason>"** — skip a step that isn't needed based on results
- **done "<summary>"** — workflow is complete
- **abort "<reason>"** — stop early due to a blocking issue

## Rules
- You are the TEAM LEAD. Decide what your team does next — don't do the work yourself.
- Use your domain expertise to judge result quality — a generic "completed" is not enough.
- Don't loop more than 2 times on the same step — if it's still failing, move on and report.
- Parallelise when steps are genuinely independent.
- Skip steps when results make them unnecessary.
- Be efficient — don't run steps that won't add value.

## Output Format
Respond with EXACTLY ONE decision line, then a brief reason:

```decision
<action> <args>
```
reason: <why you chose this>"""


class WorkflowSupervisor:
    """LLM-powered workflow coordinator.

    Reads a workflow definition, dispatches steps through the orchestrator,
    and uses an LLM to decide what to do next based on results.
    """

    def __init__(
        self,
        orchestrator: Orchestrator,
        llm: LLMProvider,
    ) -> None:
        self._orchestrator = orchestrator
        self._llm = llm

    async def execute(
        self,
        workflow: WorkflowDef,
        context: str = "",
        on_step: Any | None = None,  # callback(step_id, status, result)
    ) -> WorkflowExecution:
        """Execute a workflow adaptively under supervisor control.

        Args:
            workflow: The workflow definition to execute.
            context: Additional context to provide to each step.
            on_step: Optional callback for real-time progress updates.

        Returns:
            WorkflowExecution with all step results and supervisor decisions.
        """
        execution = WorkflowExecution(
            workflow_id=workflow.id,
            started_at=datetime.now(UTC).isoformat(),
        )

        # Track which steps have been executed and how many times
        step_attempts: dict[str, int] = {s.id: 0 for s in workflow.steps}
        step_map = {s.id: s for s in workflow.steps}

        for iteration in range(MAX_ITERATIONS):
            execution.total_iterations = iteration + 1

            # Ask the supervisor what to do next
            decision = await self._decide(workflow, execution)
            execution.supervisor_log.append({
                "iteration": iteration + 1,
                "action": decision.action,
                "steps": decision.steps,
                "feedback": decision.feedback,
                "reason": decision.reason,
                "timestamp": datetime.now(UTC).isoformat(),
            })

            log.info(
                "Supervisor [%s] iter %d: %s %s — %s",
                workflow.id, iteration + 1, decision.action,
                " ".join(decision.steps), decision.reason,
            )

            if decision.action == "done":
                execution.status = "completed"
                execution.completed_at = datetime.now(UTC).isoformat()
                break

            if decision.action == "abort":
                execution.status = "aborted"
                execution.completed_at = datetime.now(UTC).isoformat()
                log.warning("Supervisor aborted workflow %s: %s", workflow.id, decision.reason)
                break

            if decision.action == "skip":
                for sid in decision.steps:
                    step_attempts[sid] = -1  # mark as skipped
                    if on_step:
                        on_step(sid, "skipped", decision.reason)
                continue

            if decision.action in ("dispatch", "loop"):
                for sid in decision.steps:
                    step = step_map.get(sid)
                    if not step:
                        log.warning("Supervisor referenced unknown step: %s", sid)
                        continue

                    step_attempts[sid] = step_attempts.get(sid, 0) + 1
                    if step_attempts[sid] > 3:
                        log.warning("Step %s exceeded max attempts, skipping", sid)
                        continue

                    if on_step:
                        on_step(sid, "running", None)

                    # Build task prompt with optional feedback
                    task = step.description
                    if decision.action == "loop" and decision.feedback:
                        task = (
                            f"REVISION REQUESTED — previous output was insufficient.\n\n"
                            f"Feedback: {decision.feedback}\n\n"
                            f"Original task: {step.description}\n\n"
                            f"Please address the feedback and produce an improved result."
                        )

                    result = await self._dispatch_step(step, task, context, step_attempts[sid])
                    execution.step_results.append(result)

                    if on_step:
                        on_step(sid, "completed", result.content[:200])

            elif decision.action == "parallel":
                # Dispatch multiple steps concurrently
                import asyncio

                tasks = []
                for sid in decision.steps:
                    step = step_map.get(sid)
                    if not step:
                        continue
                    step_attempts[sid] = step_attempts.get(sid, 0) + 1
                    if on_step:
                        on_step(sid, "running", None)
                    tasks.append(self._dispatch_step(step, step.description, context, step_attempts[sid]))

                if tasks:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    for r in results:
                        if isinstance(r, StepResult):
                            execution.step_results.append(r)
                            if on_step:
                                on_step(r.step_id, "completed", r.content[:200])
                        elif isinstance(r, Exception):
                            log.exception("Parallel step failed: %s", r)
        else:
            # Hit MAX_ITERATIONS
            execution.status = "completed"
            execution.completed_at = datetime.now(UTC).isoformat()
            log.warning("Supervisor hit max iterations for workflow %s", workflow.id)

        return execution

    async def _dispatch_step(
        self,
        step: WorkflowStep,
        task: str,
        context: str,
        attempt: int,
    ) -> StepResult:
        """Dispatch a single step through the orchestrator."""
        t0 = time.monotonic()
        try:
            result = await self._orchestrator.dispatch(
                agent_name=step.agent_key,
                task=task,
                context=context,
            )
            duration_ms = int((time.monotonic() - t0) * 1000)
            return StepResult(
                step_id=step.id,
                agent_key=step.agent_key,
                content=result.content,
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
                duration_ms=duration_ms,
                iteration=attempt,
            )
        except Exception as exc:
            duration_ms = int((time.monotonic() - t0) * 1000)
            log.exception("Step %s dispatch failed", step.id)
            return StepResult(
                step_id=step.id,
                agent_key=step.agent_key,
                content=f"[ERROR] Step failed: {exc}",
                duration_ms=duration_ms,
                iteration=attempt,
            )

    async def _decide(
        self,
        workflow: WorkflowDef,
        execution: WorkflowExecution,
    ) -> SupervisorDecision:
        """Ask the supervisor LLM what to do next."""
        # Build step descriptions
        steps_desc = []
        for s in workflow.steps:
            agent = self._orchestrator.agents.get(s.agent_key)
            agent_name = agent.name if agent else s.agent_key
            status = "available"
            # Check execution history
            attempts = sum(1 for r in execution.step_results if r.step_id == s.id)
            if attempts > 0:
                last = next(r for r in reversed(execution.step_results) if r.step_id == s.id)
                status = f"completed ({attempts}x)" if "[ERROR]" not in last.content else f"failed ({attempts}x)"
            # Check if skipped
            for log_entry in execution.supervisor_log:
                if log_entry["action"] == "skip" and s.id in log_entry["steps"]:
                    status = "skipped"
            steps_desc.append(
                f"- **{s.id}**: {s.label} (agent: {agent_name}) — {s.description}\n"
                f"  Status: {status}"
            )

        # Build execution history
        history_parts = []
        if not execution.step_results:
            history_parts.append("No steps executed yet. This is the beginning of the workflow.")
        else:
            for r in execution.step_results:
                step = next((s for s in workflow.steps if s.id == r.step_id), None)
                label = step.label if step else r.step_id
                # Truncate content for supervisor context
                content_preview = r.content[:500] if len(r.content) > 500 else r.content
                history_parts.append(
                    f"### Step: {label} ({r.step_id}) — attempt {r.iteration}\n"
                    f"Agent: {r.agent_key} | Duration: {r.duration_ms}ms | "
                    f"Tokens: {r.input_tokens}→{r.output_tokens}\n"
                    f"Result:\n{content_preview}"
                )

        # Resolve supervisor agent personality
        sup_agent = self._orchestrator.agents.get(workflow.supervisor) if workflow.supervisor else None
        if sup_agent:
            sup_name = sup_agent.name
            sup_role = sup_agent.role
            sup_personality = sup_agent.personality
            sup_expertise = sup_agent.capabilities
            team_desc = "\n".join(
                f"- **{self._orchestrator.agents[k].name}** ({k})" if k in self._orchestrator.agents
                else f"- {k} (not loaded)"
                for k in sup_agent.team
            ) or "No team defined."
        else:
            sup_name = "Workflow Supervisor"
            sup_role = "workflow coordinator"
            sup_personality = "Efficient and adaptive. Makes routing decisions based on results."
            sup_expertise = ""
            team_desc = "Team members defined per workflow step."

        prompt = _SUPERVISOR_PROMPT.format(
            supervisor_name=sup_name,
            supervisor_role=sup_role,
            supervisor_personality=sup_personality,
            supervisor_expertise=sup_expertise,
            workflow_name=workflow.name,
            workflow_description=workflow.description,
            team_description=team_desc,
            steps_description="\n".join(steps_desc),
            execution_history="\n\n".join(history_parts),
        )

        response = await self._llm.complete(
            messages=[Message(role="user", content="Decide the next action for this workflow.")],
            system=prompt,
            max_tokens=300,
            temperature=0.1,
        )

        return self._parse_decision(response.content)

    @staticmethod
    def _parse_decision(text: str) -> SupervisorDecision:
        """Parse the supervisor's decision from LLM output."""
        import re

        # Extract the decision block
        decision_match = re.search(r"```decision\s*\n(.+?)\n```", text, re.DOTALL)
        decision_line = decision_match.group(1).strip() if decision_match else text.strip()

        # Also try without code block — supervisor might just write the action
        if not decision_match:
            # Look for action keywords at start of any line
            for line in text.split("\n"):
                line = line.strip()
                if line.startswith(("dispatch ", "parallel ", "loop ", "skip ", "done ", "abort ")):
                    decision_line = line
                    break

        # Extract reason
        reason = ""
        reason_match = re.search(r"reason:\s*(.+)", text, re.IGNORECASE)
        if reason_match:
            reason = reason_match.group(1).strip()

        # Parse action
        parts = decision_line.split(maxsplit=1)
        action = parts[0].lower() if parts else "done"
        args = parts[1] if len(parts) > 1 else ""

        if action == "done":
            return SupervisorDecision(action="done", reason=reason or args.strip('" '))

        if action == "abort":
            return SupervisorDecision(action="abort", reason=reason or args.strip('" '))

        if action == "dispatch":
            return SupervisorDecision(action="dispatch", steps=[args.strip()], reason=reason)

        if action == "parallel":
            step_ids = args.split()
            return SupervisorDecision(action="parallel", steps=step_ids, reason=reason)

        if action == "loop":
            # loop step_id "feedback text"
            loop_match = re.match(r'(\S+)\s+"(.+)"', args)
            if loop_match:
                return SupervisorDecision(
                    action="loop",
                    steps=[loop_match.group(1)],
                    feedback=loop_match.group(2),
                    reason=reason,
                )
            # Fallback: just step_id
            return SupervisorDecision(action="loop", steps=[args.split()[0]] if args else [], reason=reason)

        if action == "skip":
            skip_match = re.match(r'(\S+)\s+"(.+)"', args)
            if skip_match:
                return SupervisorDecision(
                    action="skip",
                    steps=[skip_match.group(1)],
                    reason=reason or skip_match.group(2),
                )
            return SupervisorDecision(action="skip", steps=[args.split()[0]] if args else [], reason=reason)

        # Fallback: treat as dispatch
        return SupervisorDecision(action="dispatch", steps=[action], reason=reason)
