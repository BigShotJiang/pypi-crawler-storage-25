"""Health check endpoint."""

from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter, Request

router = APIRouter(tags=["health"])

def _get_version() -> str:
    # Installed package metadata (works from pip install)
    try:
        from importlib.metadata import version
        return version("agntspace")
    except Exception:
        pass
    # Dev repo fallback (works from source checkout)
    try:
        pyproject = Path(__file__).resolve().parents[4] / "pyproject.toml"
        text = pyproject.read_text(encoding="utf-8")
        m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "dev"


@router.get("/health")
async def health(request: Request) -> dict:
    setup_mode = getattr(request.app.state, "setup_mode", False)
    return {"status": "ok", "version": _get_version(), "setup_mode": setup_mode}
