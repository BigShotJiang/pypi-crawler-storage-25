"""Goals and coaching API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/goals", tags=["goals"])


class GoalCreateRequest(BaseModel):
    title: str
    description: str
    goal_type: str = "goal"
    target_date: str = ""


class GoalStatusRequest(BaseModel):
    status: str


class GoalUpdateRequest(BaseModel):
    description: str | None = None
    target_date: str | None = None


class GoalRenameRequest(BaseModel):
    title: str


@router.get("")
async def list_goals(request: Request, status: str | None = None) -> list[dict]:
    """List all goals."""
    coach = request.app.state.coach
    return coach.list_goals(status_filter=status)


@router.post("")
async def create_goal(request: Request, body: GoalCreateRequest) -> dict:
    """Create a new goal."""
    coach = request.app.state.coach
    path = coach.create_goal(
        title=body.title,
        description=body.description,
        goal_type=body.goal_type,
        target_date=body.target_date,
    )
    return {"path": path, "status": "active"}


@router.get("/nudges")
async def get_nudges(request: Request) -> list[str]:
    """Get coaching nudges for stalled goals and deadlines."""
    coach = request.app.state.coach
    return coach.generate_nudges()


@router.get("/stalls")
async def get_stalls(request: Request) -> list[dict]:
    """Detect stalled goals."""
    coach = request.app.state.coach
    return coach.detect_stalls()


@router.get("/{slug}")
async def get_goal(request: Request, slug: str) -> dict:
    """Get a single goal."""
    coach = request.app.state.coach
    goal = coach.get_goal(slug)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    return goal


@router.put("/{slug}")
async def update_goal(request: Request, slug: str, body: GoalUpdateRequest) -> dict:
    """Update a goal's description and/or target date."""
    coach = request.app.state.coach
    try:
        coach.update_goal(
            slug=slug,
            description=body.description,
            target_date=body.target_date,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": "updated"}


@router.post("/{slug}/rename")
async def rename_goal(request: Request, slug: str, body: GoalRenameRequest) -> dict:
    """Rename a goal: rewrite title, move file, update project references."""
    coach = request.app.state.coach
    try:
        result = coach.rename_goal(slug, body.title)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    activity = getattr(request.app.state, "activity_logger", None)
    if activity and result["slug"] != slug:
        activity.log(
            category="user_override",
            action="goal_renamed",
            summary=f"User renamed goal '{slug}' → '{result['slug']}' ('{body.title}')",
            details={"old_slug": slug, "new_slug": result["slug"], "projects_updated": result.get("projects_updated", 0)},
            importance="medium",
        )
    return {"slug": result["slug"], "projects_updated": result.get("projects_updated", 0)}


@router.patch("/{slug}/status")
async def update_goal_status(
    request: Request, slug: str, body: GoalStatusRequest
) -> dict:
    """Update a goal's status."""
    coach = request.app.state.coach
    try:
        coach.update_goal_status(slug, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}


@router.get("/{slug}/projects")
async def list_goal_projects(request: Request, slug: str) -> list[dict]:
    """Reverse lookup: list projects whose related_goals contains this goal."""
    project_svc = request.app.state.project_service
    projects = project_svc.list_projects()
    return [p for p in projects if slug in (p.get("related_goals") or [])]


@router.post("/{slug}/projects/{project_slug}")
async def attach_goal_to_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Attach this goal to a project (adds to project.related_goals)."""
    coach = request.app.state.coach
    if not coach.get_goal(slug):
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug in goals:
        return {"slug": slug, "project": project_slug, "status": "already_linked"}
    goals.append(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_attached_to_project",
            summary=f"User linked goal '{slug}' to project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "attached"}


@router.delete("/{slug}/projects/{project_slug}")
async def detach_goal_from_project(
    request: Request, slug: str, project_slug: str
) -> dict:
    """Detach this goal from a project (removes from project.related_goals)."""
    project_svc = request.app.state.project_service
    detail = project_svc.get_project_detail(project_slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_slug}")

    goals = list(detail.get("related_goals") or [])
    if slug not in goals:
        return {"slug": slug, "project": project_slug, "status": "not_linked"}
    goals.remove(slug)
    project_svc.update_project(slug=project_slug, related_goals=goals)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log(
            category="user_override",
            action="goal_detached_from_project",
            summary=f"User unlinked goal '{slug}' from project '{project_slug}'",
            details={"goal": slug, "project": project_slug},
            importance="medium",
        )
    return {"slug": slug, "project": project_slug, "status": "detached"}
