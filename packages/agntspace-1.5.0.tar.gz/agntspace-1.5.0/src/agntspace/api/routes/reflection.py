"""Reflection API endpoints.

Agent reflections are auto-generated (daily/weekly synthesis).
User reflections are user-written personal reflections.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/reflections", tags=["reflections"])


class UserReflectionRequest(BaseModel):
    text: str
    date: str | None = None


@router.get("")
async def list_reflections(request: Request, limit: int = 20) -> list[dict]:
    """List recent reflections (both user and agent)."""
    reflection_svc = request.app.state.reflection_service
    return reflection_svc.list_reflections(limit=limit)


@router.post("/daily")
async def run_daily_reflection(request: Request, date: str | None = None) -> dict:
    """Run agent daily reflection for a given date (defaults to today)."""
    reflection_svc = request.app.state.reflection_service
    return await reflection_svc.run_daily_reflection(date)


@router.post("/weekly")
async def run_weekly_reflection(request: Request, week_end: str | None = None) -> dict:
    """Run agent weekly reflection (defaults to current week)."""
    reflection_svc = request.app.state.reflection_service
    return await reflection_svc.run_weekly_reflection(week_end)


@router.post("/{path:path}/approve")
async def approve_reflection(request: Request, path: str) -> dict:
    """Approve an agent reflection and apply MEMORY.md updates."""
    reflection_svc = request.app.state.reflection_service
    try:
        await reflection_svc.approve_reflection(path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Record feedback for relationship learning
    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.record_feedback("approval", f"Reflection: {path}")

    return {"status": "approved", "path": path}


@router.post("/{path:path}/reject")
async def reject_reflection(request: Request, path: str) -> dict:
    """Reject a reflection — marks it as rejected with optional reason."""
    reader = request.app.state.vault
    writer = request.app.state.vault_writer

    if not reader.exists(path):
        raise HTTPException(status_code=404, detail=f"Reflection not found: {path}")

    doc = reader.read(path)
    content = doc.raw
    # Update status to rejected
    for old in ("status: pending", "status: approved"):
        content = content.replace(old, "status: rejected")
    writer.write(path, content)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.record_feedback("rejection", f"Reflection: {path}")

    return {"status": "rejected", "path": path}


@router.post("/{path:path}/unapprove")
async def unapprove_reflection(request: Request, path: str) -> dict:
    """Revert an approved reflection back to pending status."""
    reader = request.app.state.vault
    writer = request.app.state.vault_writer

    if not reader.exists(path):
        raise HTTPException(status_code=404, detail=f"Reflection not found: {path}")

    doc = reader.read(path)
    content = doc.raw.replace("status: approved", "status: pending")
    writer.write(path, content)

    activity = getattr(request.app.state, "activity_logger", None)
    if activity:
        activity.log("memory", "unapproved", f"Reflection reverted to pending: {path}",
                     importance="medium")

    return {"status": "unapproved", "path": path}


@router.post("/user")
async def write_user_reflection(request: Request, body: UserReflectionRequest) -> dict:
    """Write a personal reflection to today's journal Reflections section.

    User reflections now live in the journal, not as separate files.
    """
    journal = request.app.state.journal
    journal.append_reflection(body.text)
    return {"status": "ok", "section": "Reflections", "author": "user"}
