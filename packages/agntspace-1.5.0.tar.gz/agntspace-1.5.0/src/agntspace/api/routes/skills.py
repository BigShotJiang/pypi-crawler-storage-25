"""Skills and SkillSchool API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/skills", tags=["skills"])


class SkillUpdateRequest(BaseModel):
    content: str


class SkillCreateRequest(BaseModel):
    name: str
    title: str
    description: str
    category: str = "custom"
    triggers: list[str] = []
    instructions: str = ""
    author: str = "user"
    tools_granted: list[str] = []
    depends_on: list[str] = []
    priority: int = 0
    model_tier: str = ""
    examples: list[dict] = []
    output_format: str = ""


class SkillFileRequest(BaseModel):
    content: str


@router.get("")
async def list_skills(request: Request) -> list[dict]:
    """List all loaded skills."""
    skills = request.app.state.skills
    return skills.list_skills()


@router.post("/analyze")
async def analyze_patterns(request: Request) -> list[dict]:
    """Run SkillSchool pattern analysis on completed tasks."""
    skillschool = request.app.state.skillschool
    return await skillschool.analyze_patterns()


@router.get("/{skill_name}")
async def get_skill(request: Request, skill_name: str) -> dict:
    """Get a single skill's full content."""
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "name": skill.name,
        "title": skill.title,
        "description": skill.description,
        "category": skill.category,
        "status": skill.status,
        "triggers": skill.triggers,
        "body": skill.body,
        "path": str(skill.path),
        "files": skill.files,
        "author": skill.author,
        "tools_granted": skill.tools_granted,
        "depends_on": skill.depends_on,
        "priority": skill.priority,
        "model_tier": skill.model_tier,
        "examples": skill.examples,
        "output_format": skill.output_format,
        "version": skill.version,
        "signature": skill.signature,
        "publisher": skill.publisher,
        "content_hash": skill.content_hash,
        "signature_valid": _signature_valid(skill),
        "verification": _verification(skill),
    }


def _signature_valid(skill) -> bool | None:  # noqa: ANN001
    """Back-compat thin wrapper over `verify_signature` returning bool|None."""
    from agntspace.skills.signing import verify_signature
    status, _ = verify_signature(
        getattr(skill, "body", "") or "",
        getattr(skill, "signature", "") or "",
    )
    if status == "valid":
        return True
    if status == "invalid":
        return False
    return None  # unsigned or unknown scheme


def _verification(skill) -> dict:  # noqa: ANN001
    """Full verification report for the skill (gap #8)."""
    from agntspace.skills.signing import skill_verification_result
    return skill_verification_result(skill)


@router.put("/{skill_name}")
async def update_skill(request: Request, skill_name: str, body: SkillUpdateRequest) -> dict:
    """Update a skill's raw content (frontmatter + body)."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(f"system/skills/{skill.path}", body.content)
    skills.load_all()
    return {"status": "updated", "name": skill_name}


@router.post("/create")
async def create_skill(request: Request, body: SkillCreateRequest) -> dict:
    """Create a new custom skill."""
    import re

    settings = request.app.state.settings
    skills = request.app.state.skills

    slug = re.sub(r"[^a-z0-9-]", "", body.name.lower().replace(" ", "-"))[:60]
    if not slug:
        raise HTTPException(status_code=400, detail="Invalid skill name")

    # Build SKILL.md content
    triggers_yaml = "\n".join(f'  - "{t}"' for t in body.triggers) if body.triggers else '  - "' + slug + '"'
    tools_yaml = "\n".join(f'  - "{t}"' for t in body.tools_granted) if body.tools_granted else ""
    deps_yaml = "\n".join(f'  - "{d}"' for d in body.depends_on) if body.depends_on else ""

    # Build examples YAML
    examples_yaml = ""
    if body.examples:
        lines = []
        for ex in body.examples:
            lines.append(f'  - input: "{ex.get("input", "")}"')
            lines.append(f'    output: "{ex.get("output", "")}"')
        examples_yaml = "\n".join(lines)

    content = f"""---
name: {slug}
title: "{body.title}"
description: "{body.description}"
category: {body.category}
status: active
author: {body.author}
priority: {body.priority}
model_tier: "{body.model_tier}"
output_format: "{body.output_format}"
triggers:
{triggers_yaml}
tools_granted:
{tools_yaml}
depends_on:
{deps_yaml}
examples:
{examples_yaml}
---

## Instructions

{body.instructions or "Define the step-by-step instructions for this skill."}

## Rules

- Follow the user's preferences from PROFILE.md
- Check CONTRACT.md permissions before taking action
"""

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    path = f"system/skills/{body.category}/{slug}/SKILL.md"
    writer.write(path, content)
    skills.load_all()
    return {"status": "created", "name": slug, "path": path}


@router.get("/{skill_name}/files/{file_path:path}")
async def get_skill_file(request: Request, skill_name: str, file_path: str) -> dict:
    """Read an additional file from a skill folder (template, example, etc.)."""
    skills = request.app.state.skills
    content = skills.get_skill_file(skill_name, file_path)
    if content is None:
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    return {"path": file_path, "content": content}


@router.put("/{skill_name}/files/{file_path:path}")
async def update_skill_file(request: Request, skill_name: str, file_path: str, body: SkillFileRequest) -> dict:
    """Write an additional file to a skill folder."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from pathlib import Path as P

    skill_dir = P(skill.path).parent
    full_path = f"system/skills/{skill_dir}/{file_path}"

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(full_path, body.content)
    skills.load_all()
    return {"status": "updated", "path": full_path}
