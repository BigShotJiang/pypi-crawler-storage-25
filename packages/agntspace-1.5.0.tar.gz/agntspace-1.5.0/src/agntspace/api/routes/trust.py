"""Trust API — structured trust data and domain management."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/trust", tags=["trust"])


class TrustLevelUpdate(BaseModel):
    domain: str
    level: str


class DomainAdd(BaseModel):
    domain: str
    level: str = "Advisor"


@router.get("")
async def get_trust_data(request: Request) -> dict:
    """Get structured trust data with change log."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()
    changes = trust.get_recent_changes()
    return {
        "domains": rows,
        "changes": changes[-20:],  # last 20 changes
        "levels": ["Observer", "Advisor", "Assistant", "Partner"],
    }


@router.put("/level")
async def update_trust_level(request: Request, body: TrustLevelUpdate) -> dict:
    """Manually set trust level for a domain."""
    trust = request.app.state.trust_service
    if body.level not in ("Observer", "Advisor", "Assistant", "Partner"):
        raise HTTPException(status_code=400, detail=f"Invalid level: {body.level}")

    rows = trust.get_trust_data()
    found = False
    for row in rows:
        if row["domain"].lower() == body.domain.lower():
            old = row["level"]
            row["level"] = body.level
            found = True
            break

    if not found:
        raise HTTPException(status_code=404, detail=f"Domain not found: {body.domain}")

    trust._write_trust_table(rows)  # noqa: SLF001
    return {"domain": body.domain, "old_level": old, "new_level": body.level}


@router.post("/domain")
async def add_domain(request: Request, body: DomainAdd) -> dict:
    """Add a new trust domain."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()

    # Check duplicate
    for row in rows:
        if row["domain"].lower() == body.domain.lower():
            raise HTTPException(status_code=409, detail=f"Domain already exists: {body.domain}")

    rows.append({
        "domain": body.domain,
        "level": body.level,
        "completed": 0,
        "good": 0,
        "needs_improvement": 0,
        "redo": 0,
    })
    trust._write_trust_table(rows)  # noqa: SLF001
    return {"domain": body.domain, "level": body.level}


@router.delete("/domain/{domain}")
async def remove_domain(request: Request, domain: str) -> dict:
    """Remove a trust domain."""
    trust = request.app.state.trust_service
    rows = trust.get_trust_data()
    new_rows = [r for r in rows if r["domain"].lower() != domain.lower()]
    if len(new_rows) == len(rows):
        raise HTTPException(status_code=404, detail=f"Domain not found: {domain}")
    trust._write_trust_table(new_rows)  # noqa: SLF001
    return {"domain": domain, "status": "removed"}
