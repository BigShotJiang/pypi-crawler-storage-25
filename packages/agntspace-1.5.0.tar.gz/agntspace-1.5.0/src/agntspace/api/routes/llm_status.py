"""LLM status aggregator — one endpoint for the dashboard panel.

Combines live state (provider health, active model, pending work, last error)
with an error-pattern diagnosis so the UI can show actionable guidance instead
of raw tracebacks. Also exposes a manual "reconcile local tiers" action.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger(__name__)

router = APIRouter(prefix="/llm", tags=["llm"])


# ── Error pattern → diagnosis ──────────────────────────────────────────────
# Each pattern returns: code (stable id), headline, advice, action (optional).
# Actions map to repair buttons the UI can wire up.
_PATTERNS: list[dict[str, Any]] = [
    {
        "match": re.compile(r"model not found|does not exist|not found in ollama", re.I),
        "code": "model_missing",
        "headline": "The configured model isn't installed.",
        "advice": (
            "Your tier routing points at a model Ollama doesn't have. "
            "Click 'Reconcile tiers' to remap tiers to your installed models, "
            "or pull the missing model manually with `ollama pull <name>`."
        ),
        "action": "reconcile_tiers",
    },
    {
        "match": re.compile(r"connection refused|connect.*refused|cannot connect|connection error|failed to connect", re.I),
        "code": "provider_unreachable",
        "headline": "Can't reach the LLM provider.",
        "advice": (
            "For local mode: make sure Ollama is running (`ollama serve` in a terminal, "
            "or launch the Ollama app). For cloud mode: check your internet connection."
        ),
        "action": "retry",
    },
    {
        "match": re.compile(r"invalid api key|incorrect api key|authentication.*fail|401|unauthorized", re.I),
        "code": "bad_credentials",
        "headline": "API key is invalid or missing.",
        "advice": "Open Settings → LLM and update the API key for your provider.",
        "action": "open_settings",
    },
    {
        "match": re.compile(r"rate.?limit|too many requests|429", re.I),
        "code": "rate_limited",
        "headline": "Provider is rate-limiting requests.",
        "advice": (
            "Wait a few minutes for the limit to reset, or switch to a different "
            "provider/model in Settings. Queued work will retry automatically."
        ),
        "action": "retry_all",
    },
    {
        "match": re.compile(r"quota|insufficient.*credit|billing|payment required|402", re.I),
        "code": "quota_exceeded",
        "headline": "Out of credits / quota exceeded.",
        "advice": "Top up your provider account or switch to local mode in Settings → LLM.",
        "action": "open_settings",
    },
    {
        "match": re.compile(r"context.?length|context.?window|token.*limit|too.*long", re.I),
        "code": "context_too_long",
        "headline": "Input too large for this model's context window.",
        "advice": "Switch to a model with a larger context window, or split the task into smaller chunks.",
        "action": "open_settings",
    },
    {
        "match": re.compile(r"timeout|timed out", re.I),
        "code": "timeout",
        "headline": "LLM call timed out.",
        "advice": (
            "For local mode: the model may be too large for your hardware — try a smaller model. "
            "For cloud: transient network issue, retry usually works."
        ),
        "action": "retry",
    },
]


def _diagnose(error: str) -> dict[str, Any] | None:
    """Match an error message against known patterns. Returns None if no match."""
    if not error:
        return None
    for pat in _PATTERNS:
        if pat["match"].search(error):
            return {
                "code": pat["code"],
                "headline": pat["headline"],
                "advice": pat["advice"],
                "action": pat.get("action"),
            }
    return {
        "code": "unknown",
        "headline": "LLM error (unclassified).",
        "advice": "Check the full error in /logs. If it recurs, check provider status and Settings → LLM.",
        "action": None,
    }


@router.get("/status")
async def llm_status(request: Request) -> dict:
    """Aggregated LLM status for the dashboard panel."""
    from agntspace.infra.config import get_settings
    settings = get_settings()

    # LLM instance isn't cached on app.state — pull live state from the
    # agent's provider and the work queue (populated by heartbeat pings).
    agent = getattr(request.app.state, "agent", None)
    llm = getattr(agent, "_llm", None) if agent else None
    wq = getattr(request.app.state, "work_queue", None)
    error_logger = getattr(request.app.state, "error_logger", None)

    mode = settings.llm.mode
    provider = settings.llm.local_provider if mode == "local" else settings.llm.cloud_provider

    active_model = "unknown"
    last_error = ""
    provider_healthy = True
    if llm:
        active_model = getattr(llm, "model_name", "") or getattr(llm, "_model", "") or active_model
        last_error = getattr(llm, "last_error", "") or ""
        provider_healthy = bool(getattr(llm, "healthy", True))

    pending_jobs = 0
    wq_healthy = True
    if wq:
        wq_healthy = bool(getattr(wq, "llm_healthy", True))
        # Heartbeat writes the active model into the work queue; prefer it
        # when we don't have a better source.
        wq_model = getattr(wq, "active_model", "") or ""
        if (not active_model or active_model == "unknown") and wq_model:
            active_model = wq_model
        try:
            status = await wq.get_status()
            pending_jobs = int(status.get("total_pending", 0))
        except Exception:
            pass

    # Recent LLM-ish errors from the error log (non-blocking)
    recent_errors: list[dict[str, Any]] = []
    if error_logger:
        try:
            rows = await error_logger.get_errors(
                limit=5,
                source="llm",
                resolved=False,
            )
            recent_errors = [
                {
                    "id": r["id"],
                    "timestamp": r["timestamp"],
                    "level": r["level"],
                    "source": r["source"],
                    "message": r["message"],
                }
                for r in rows
            ]
        except Exception:
            pass

    # Fall back to the freshest recent error message if llm.last_error is empty
    if not last_error and recent_errors:
        last_error = recent_errors[0]["message"]

    # Tier map (local mode only)
    tier_map: dict[str, str] = {}
    try:
        from agntspace.llm.model_router import ModelRouter
        mr = ModelRouter(
            provider=provider,
            profile="local" if mode == "local" else settings.llm.quality_profile,
            default_model=settings.active_model,
            skills_dir=settings.skills_dir,
        )
        tier_map = mr.get_profile_summary() or {}
    except Exception:
        pass

    # Installed Ollama models (local mode only, cheap probe)
    installed_models: list[str] = []
    ollama_online = False
    if mode == "local":
        try:
            from agntspace.llm.ollama_discovery import _installed_models
            installed = _installed_models()
            installed_models = [m["name"] for m in installed]
            ollama_online = bool(installed_models)
        except Exception:
            pass

    healthy = provider_healthy and wq_healthy and not last_error
    diagnosis = _diagnose(last_error) if not healthy else None

    return {
        "mode": mode,
        "provider": provider,
        "active_model": active_model,
        "healthy": healthy,
        "provider_healthy": provider_healthy,
        "queue_healthy": wq_healthy,
        "last_error": last_error,
        "pending_jobs": pending_jobs,
        "tier_map": tier_map,
        "installed_models": installed_models,
        "ollama_online": ollama_online if mode == "local" else None,
        "recent_errors": recent_errors,
        "diagnosis": diagnosis,
    }


@router.post("/reconcile-tiers")
async def reconcile_tiers(request: Request) -> dict:
    """Re-run local tier reconciliation against the live Ollama instance.

    Rewrites `models.yaml` if any tier points to a missing model. Reloads the
    live `ModelRouter` so the change takes effect without a restart.
    """
    from agntspace.infra.config import get_settings
    settings = get_settings()

    if settings.llm.mode != "local":
        raise HTTPException(400, "Tier reconciliation only applies in local mode")

    from agntspace.llm.ollama_discovery import reconcile_local_tiers
    result = reconcile_local_tiers(settings.skills_dir)

    # Reload the running ModelRouter so background services see the new map
    mr = getattr(request.app.state, "model_router", None)
    if mr is not None and result.get("status") in ("updated", "unchanged"):
        try:
            mr._load(settings.skills_dir)  # noqa: SLF001
            result["router_reloaded"] = True
        except Exception as exc:
            log.warning("ModelRouter reload failed: %s", exc)
            result["router_reloaded"] = False

    return result
