"""Cost control — track LLM token usage, enforce budgets, alert on limits.

Tracks:
- Tokens per conversation, task, and day
- Estimated cost based on provider pricing
- Configurable daily/monthly budgets
- Hard stop when budget exceeded

No agent loop should be able to burn unlimited money.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime

import aiosqlite

log = logging.getLogger(__name__)

# Approximate pricing per 1M tokens (USD) — updated as needed
# Model names match what LiteLLM returns in response.model
PRICING = {
    # Anthropic (Claude 4.x)
    "claude-opus-4-20250514": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-20250514": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-20250414": {"input": 0.80, "output": 4.0},
    # Anthropic (Claude 3.x)
    "claude-3-7-sonnet-20250219": {"input": 3.0, "output": 15.0},
    "claude-3-5-sonnet-20241022": {"input": 3.0, "output": 15.0},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.0},
    # OpenAI (GPT-4.1)
    "gpt-4.1": {"input": 2.0, "output": 8.0},
    "gpt-4.1-mini": {"input": 0.40, "output": 1.60},
    "gpt-4.1-nano": {"input": 0.10, "output": 0.40},
    # OpenAI (GPT-4o)
    "gpt-4o": {"input": 2.5, "output": 10.0},
    "gpt-4o-mini": {"input": 0.15, "output": 0.6},
    # OpenAI (reasoning)
    "o3-mini": {"input": 1.10, "output": 4.40},
    # Legacy prefixed names (LiteLLM sometimes returns these)
    "anthropic/claude-sonnet-4-20250514": {"input": 3.0, "output": 15.0},
    "anthropic/claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "openai/gpt-4o": {"input": 2.5, "output": 10.0},
    "openai/gpt-4o-mini": {"input": 0.15, "output": 0.6},
    # Local (free)
    "ollama": {"input": 0, "output": 0},
    "_default": {"input": 3.0, "output": 15.0},
}


class CostTracker:
    """Tracks LLM token usage and enforces budget limits."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        daily_budget: float = 10.0,
        monthly_budget: float = 100.0,
    ) -> None:
        self._db = db
        self._daily_budget = daily_budget
        self._monthly_budget = monthly_budget
        # Budget-exceeded throttling: log WARNING on transition into the
        # exceeded state, then downgrade subsequent log lines to DEBUG so
        # overrun days don't fill the log with identical warnings.
        self._daily_exceeded_logged: str | None = None   # date string, or None
        self._monthly_exceeded_logged: str | None = None  # YYYY-MM, or None

    async def init_schema(self) -> None:
        """Create cost tracking tables."""
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS cost_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                model TEXT NOT NULL,
                input_tokens INTEGER NOT NULL,
                output_tokens INTEGER NOT NULL,
                estimated_cost REAL NOT NULL,
                conversation_id TEXT,
                action TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_cost_timestamp ON cost_log(timestamp);
        """)
        await self._db.commit()

    async def record(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        conversation_id: str | None = None,
        action: str | None = None,
    ) -> dict:
        """Record token usage and check budget.

        Returns dict with cost info and whether budget is exceeded.
        """
        cost = self._estimate_cost(model, input_tokens, output_tokens)
        now = datetime.now(UTC).isoformat()

        await self._db.execute(
            "INSERT INTO cost_log (timestamp, model, input_tokens, output_tokens, "
            "estimated_cost, conversation_id, action) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (now, model, input_tokens, output_tokens, cost, conversation_id, action),
        )
        await self._db.commit()

        # Check budgets
        daily = await self.get_daily_cost()
        monthly = await self.get_monthly_cost()

        budget_exceeded = False
        warning = None

        from datetime import datetime as _dt
        today = _dt.now().strftime("%Y-%m-%d")
        this_month = _dt.now().strftime("%Y-%m")

        if self._daily_budget > 0 and daily >= self._daily_budget:
            budget_exceeded = True
            warning = f"Daily budget exceeded: ${daily:.2f} / ${self._daily_budget:.2f}"
            if self._daily_exceeded_logged != today:
                log.warning(warning)
                self._daily_exceeded_logged = today
            else:
                log.debug(warning)

        if self._monthly_budget > 0 and monthly >= self._monthly_budget:
            budget_exceeded = True
            warning = f"Monthly budget exceeded: ${monthly:.2f} / ${self._monthly_budget:.2f}"
            if self._monthly_exceeded_logged != this_month:
                log.warning(warning)
                self._monthly_exceeded_logged = this_month
            else:
                log.debug(warning)

        # Alert at 80%
        if not warning and self._daily_budget > 0 and daily >= self._daily_budget * 0.8:
            warning = f"Approaching daily budget: ${daily:.2f} / ${self._daily_budget:.2f}"

        return {
            "cost": cost,
            "daily_total": daily,
            "monthly_total": monthly,
            "budget_exceeded": budget_exceeded,
            "warning": warning,
        }

    async def check_budget(self) -> dict:
        """Check if budget allows another request."""
        daily = await self.get_daily_cost()
        monthly = await self.get_monthly_cost()

        exceeded = False
        if self._daily_budget > 0 and daily >= self._daily_budget:
            exceeded = True
        if self._monthly_budget > 0 and monthly >= self._monthly_budget:
            exceeded = True

        return {
            "allowed": not exceeded,
            "daily_cost": daily,
            "daily_budget": self._daily_budget,
            "monthly_cost": monthly,
            "monthly_budget": self._monthly_budget,
            "daily_remaining": max(0, self._daily_budget - daily),
            "monthly_remaining": max(0, self._monthly_budget - monthly),
        }

    async def get_daily_cost(self) -> float:
        """Get total cost for today."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        cursor = await self._db.execute(
            "SELECT COALESCE(SUM(estimated_cost), 0) FROM cost_log WHERE timestamp >= ?",
            (f"{today}T00:00:00",),
        )
        row = await cursor.fetchone()
        return row[0] if row else 0.0

    async def get_monthly_cost(self) -> float:
        """Get total cost for this month."""
        month_start = datetime.now(UTC).strftime("%Y-%m-01")
        cursor = await self._db.execute(
            "SELECT COALESCE(SUM(estimated_cost), 0) FROM cost_log WHERE timestamp >= ?",
            (f"{month_start}T00:00:00",),
        )
        row = await cursor.fetchone()
        return row[0] if row else 0.0

    async def get_usage_summary(self, days: int = 7) -> dict:
        """Get usage summary for the dashboard."""
        from datetime import timedelta

        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
        cursor = await self._db.execute(
            "SELECT model, SUM(input_tokens), SUM(output_tokens), "
            "SUM(estimated_cost), COUNT(*) FROM cost_log "
            "WHERE timestamp >= ? GROUP BY model",
            (cutoff,),
        )
        rows = await cursor.fetchall()

        models = {}
        total_cost = 0
        total_requests = 0
        for row in rows:
            models[row[0]] = {
                "input_tokens": row[1],
                "output_tokens": row[2],
                "cost": row[3],
                "requests": row[4],
            }
            total_cost += row[3]
            total_requests += row[4]

        return {
            "period_days": days,
            "total_cost": total_cost,
            "total_requests": total_requests,
            "by_model": models,
            "daily_budget": self._daily_budget,
            "monthly_budget": self._monthly_budget,
            "daily_cost": await self.get_daily_cost(),
            "monthly_cost": await self.get_monthly_cost(),
        }

    def set_budgets(self, daily: float | None = None, monthly: float | None = None) -> None:
        """Update budget limits."""
        if daily is not None:
            self._daily_budget = daily
        if monthly is not None:
            self._monthly_budget = monthly
        log.info(
            "Budgets updated: daily=$%.2f, monthly=$%.2f",
            self._daily_budget, self._monthly_budget,
        )

    async def get_daily_bill(self, date: str | None = None) -> dict:
        """Get itemized daily bill — cost breakdown by action and model.

        Args:
            date: YYYY-MM-DD string. Defaults to today.

        Returns dict with:
        - date, total_cost, total_requests
        - by_action: {action: {model, requests, input_tokens, output_tokens, cost}}
        - by_model: {model: {requests, input_tokens, output_tokens, cost}}
        - items: chronological list of all calls
        """
        if not date:
            date = datetime.now(UTC).strftime("%Y-%m-%d")

        cursor = await self._db.execute(
            "SELECT timestamp, model, input_tokens, output_tokens, estimated_cost, "
            "conversation_id, action FROM cost_log "
            "WHERE timestamp >= ? AND timestamp < ? ORDER BY timestamp",
            (f"{date}T00:00:00", f"{date}T23:59:59"),
        )
        rows = await cursor.fetchall()

        by_action: dict[str, dict] = {}
        by_model: dict[str, dict] = {}
        items = []
        total_cost = 0.0

        for row in rows:
            ts, model, inp, out, cost, conv_id, action = row
            action = action or "unknown"
            total_cost += cost

            items.append({
                "time": ts,
                "model": model,
                "input_tokens": inp,
                "output_tokens": out,
                "cost": round(cost, 6),
                "action": action,
                "conversation_id": conv_id,
            })

            # Aggregate by action
            a = by_action.setdefault(action, {"requests": 0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0, "models": set()})
            a["requests"] += 1
            a["input_tokens"] += inp
            a["output_tokens"] += out
            a["cost"] += cost
            a["models"].add(model)

            # Aggregate by model
            m = by_model.setdefault(model, {"requests": 0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0})
            m["requests"] += 1
            m["input_tokens"] += inp
            m["output_tokens"] += out
            m["cost"] += cost

        # Convert sets to lists for JSON serialization
        for a in by_action.values():
            a["models"] = sorted(a["models"])
            a["cost"] = round(a["cost"], 4)
        for m in by_model.values():
            m["cost"] = round(m["cost"], 4)

        return {
            "date": date,
            "total_cost": round(total_cost, 4),
            "total_requests": len(rows),
            "by_action": by_action,
            "by_model": by_model,
            "items": items,
        }

    async def get_monthly_bill(self, month: str | None = None) -> dict:
        """Get monthly bill — daily totals + model breakdown.

        Args:
            month: YYYY-MM string. Defaults to current month.

        Returns dict with:
        - month, total_cost, total_requests
        - daily_totals: [{date, cost, requests}]
        - by_model: {model: {requests, input_tokens, output_tokens, cost}}
        - by_action: {action: {requests, cost}}
        """
        if not month:
            month = datetime.now(UTC).strftime("%Y-%m")

        month_start = f"{month}-01T00:00:00"
        # Calculate next month for upper bound
        year, mon = int(month[:4]), int(month[5:7])
        if mon == 12:
            next_month = f"{year + 1}-01-01T00:00:00"
        else:
            next_month = f"{year}-{mon + 1:02d}-01T00:00:00"

        # Daily totals
        cursor = await self._db.execute(
            "SELECT SUBSTR(timestamp, 1, 10) as day, "
            "SUM(estimated_cost), COUNT(*) "
            "FROM cost_log WHERE timestamp >= ? AND timestamp < ? "
            "GROUP BY day ORDER BY day",
            (month_start, next_month),
        )
        daily_rows = await cursor.fetchall()

        daily_totals = [
            {"date": row[0], "cost": round(row[1], 4), "requests": row[2]}
            for row in daily_rows
        ]

        # Model breakdown
        cursor = await self._db.execute(
            "SELECT model, SUM(input_tokens), SUM(output_tokens), "
            "SUM(estimated_cost), COUNT(*) FROM cost_log "
            "WHERE timestamp >= ? AND timestamp < ? GROUP BY model",
            (month_start, next_month),
        )
        model_rows = await cursor.fetchall()

        by_model = {}
        for row in model_rows:
            by_model[row[0]] = {
                "input_tokens": row[1],
                "output_tokens": row[2],
                "cost": round(row[3], 4),
                "requests": row[4],
            }

        # Action breakdown
        cursor = await self._db.execute(
            "SELECT action, SUM(estimated_cost), COUNT(*) FROM cost_log "
            "WHERE timestamp >= ? AND timestamp < ? GROUP BY action",
            (month_start, next_month),
        )
        action_rows = await cursor.fetchall()

        by_action = {}
        for row in action_rows:
            by_action[row[0] or "unknown"] = {
                "cost": round(row[1], 4),
                "requests": row[2],
            }

        total_cost = sum(d["cost"] for d in daily_totals)

        return {
            "month": month,
            "total_cost": round(total_cost, 4),
            "total_requests": sum(d["requests"] for d in daily_totals),
            "daily_totals": daily_totals,
            "by_model": by_model,
            "by_action": by_action,
            "budget": self._monthly_budget,
            "remaining": round(max(0, self._monthly_budget - total_cost), 4),
        }

    @staticmethod
    def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost based on model pricing."""
        pricing = PRICING.get(model, PRICING["_default"])
        # Handle Ollama/local (free)
        if "ollama" in model:
            return 0.0
        return (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000
