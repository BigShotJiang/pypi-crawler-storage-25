"""SQLite database connection and schema management."""

from __future__ import annotations

from pathlib import Path

import aiosqlite

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id),
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    token_count INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation
    ON messages(conversation_id, created_at);

CREATE VIRTUAL TABLE IF NOT EXISTS vault_fts USING fts5(
    path,
    title,
    content,
    tokenize='porter unicode61'
);

CREATE TABLE IF NOT EXISTS dispatch_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_key TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    task TEXT NOT NULL,
    context TEXT DEFAULT '',
    project TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'running',
    content TEXT DEFAULT '',
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    started_at TEXT NOT NULL,
    completed_at TEXT DEFAULT '',
    duration_ms INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_dispatch_agent
    ON dispatch_log(agent_key, started_at);

CREATE TABLE IF NOT EXISTS vault_index (
    path TEXT PRIMARY KEY,
    title TEXT,
    content_hash TEXT,
    indexed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dm_allowlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    approved_at TEXT NOT NULL,
    UNIQUE(channel, sender_id)
);

CREATE TABLE IF NOT EXISTS dm_pairing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    code TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    UNIQUE(channel, sender_id, code)
);

CREATE INDEX IF NOT EXISTS idx_dm_allowlist_lookup
    ON dm_allowlist(channel, sender_id);

CREATE TABLE IF NOT EXISTS canvas_items (
    id TEXT PRIMARY KEY,
    title TEXT DEFAULT '',
    content TEXT NOT NULL,
    content_type TEXT NOT NULL DEFAULT 'markdown',
    pinned INTEGER NOT NULL DEFAULT 0,
    collapsed INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    user_note TEXT DEFAULT '',
    pushed_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS canvas_snapshots (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    items_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""


async def get_db(db_path: Path) -> aiosqlite.Connection:
    """Open an async SQLite connection. Creates the file if needed."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(db_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA foreign_keys=ON")
    return db


async def init_schema(db: aiosqlite.Connection) -> None:
    """Create tables if they don't exist, and run migrations."""
    await db.executescript(_SCHEMA)
    # Migration: add archived column to conversations
    try:
        await db.execute("ALTER TABLE conversations ADD COLUMN archived INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass  # column already exists
    # Migration: add provenance column to messages (JSON — kind, source_channel, etc.)
    try:
        await db.execute("ALTER TABLE messages ADD COLUMN provenance TEXT DEFAULT NULL")
    except Exception:
        pass  # column already exists
    await db.commit()
