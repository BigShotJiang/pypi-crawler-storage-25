"""Encrypted credential store using Fernet (AES-128-CBC + HMAC).

Credentials are encrypted at rest. The encryption key is automatically
derived from your machine identity (hostname + username + install path).
No configuration needed — works out of the box.

No plaintext passwords ever touch disk.
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import logging
import os
import platform
import stat
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

log = logging.getLogger(__name__)


def _derive_key(master: str | None = None, home_dir: Path | None = None) -> bytes:
    """Derive a Fernet key automatically from machine identity.

    Uses hostname + OS username + install path to create a unique key
    per machine/user. No user configuration needed.

    The optional master param exists only for testing.
    """
    if master:
        seed = master
    else:
        parts = [
            platform.node(),
            os.getenv("USERNAME", os.getenv("USER", "agntspace")),
            str(home_dir or Path.home() / "agntspace"),
            "agntspace-credential-store-v1",
        ]
        seed = "|".join(parts)

    # SHA-256 → 32 bytes → base64-encode first 32 bytes for Fernet (needs url-safe base64)
    raw = hashlib.sha256(seed.encode("utf-8")).digest()
    return base64.urlsafe_b64encode(raw)


class CredentialStore:
    """Encrypted credential storage using Fernet symmetric encryption.

    All data is encrypted before writing to disk.
    Decrypted only in memory when needed.
    """

    def __init__(self, path: Path, master_key: str | None = None) -> None:
        self._path = path
        self._key = _derive_key(master=master_key, home_dir=path.parent.parent)
        self._fernet = Fernet(self._key)
        self._data: dict[str, dict] = {}
        self._load()

    def get(self, service: str) -> dict | None:
        """Get decrypted credentials for a service."""
        return self._data.get(service)

    def set(self, service: str, credentials: dict) -> None:
        """Encrypt and store credentials for a service."""
        self._data[service] = credentials
        self._save()
        log.info("Credentials saved (encrypted) for: %s", service)

    def delete(self, service: str) -> None:
        """Remove credentials for a service."""
        if service in self._data:
            del self._data[service]
            self._save()
            log.info("Credentials removed for: %s", service)

    def list_services(self) -> list[str]:
        """List services with stored credentials."""
        return list(self._data.keys())

    def has(self, service: str) -> bool:
        return service in self._data

    def _load(self) -> None:
        """Load and decrypt credentials from disk."""
        if not self._path.exists():
            self._data = {}
            return

        try:
            encrypted = self._path.read_bytes()
            decrypted = self._fernet.decrypt(encrypted)
            self._data = json.loads(decrypted.decode("utf-8"))
        except InvalidToken:
            log.error(
                "Failed to decrypt credentials — machine identity may have changed. "
                "Re-enter your integration credentials in the control panel, "
                "or delete %s to reset.",
                self._path,
            )
            self._data = {}
        except (json.JSONDecodeError, OSError):
            log.warning("Failed to load credentials from %s", self._path)
            self._data = {}

    def _save(self) -> None:
        """Encrypt and write credentials to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)

        plaintext = json.dumps(self._data).encode("utf-8")
        encrypted = self._fernet.encrypt(plaintext)
        self._path.write_bytes(encrypted)

        # Restrict file permissions (owner only read/write)
        with contextlib.suppress(OSError):
            os.chmod(self._path, stat.S_IRUSR | stat.S_IWUSR)
