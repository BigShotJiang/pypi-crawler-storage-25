"""Trust: domain-specific trust evolution from task feedback."""

from agntspace.trust.service import TrustService

__all__ = ["TrustService"]
