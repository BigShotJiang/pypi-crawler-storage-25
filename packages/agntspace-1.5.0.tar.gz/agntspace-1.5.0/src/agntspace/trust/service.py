"""Trust evolution engine: updates domain trust from task feedback."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

TRUST_LEVELS = ("Observer", "Advisor", "Assistant", "Partner")  # arch:deterministic -- structural ordering of the trust ladder; the level set is fixed by the contract system, only the thresholds between levels are user-tunable strategy

# Phase 4 (Rule 12) migration: thresholds previously hardcoded as
# module-level constants are now loaded from the trust-evolution skill
# config. The dataclass + setter pattern mirrors chunked_extract.py
# and integrations/browser.py -- a thin module-level holder updated
# at startup from main.py. Strategy lives in
# defaults/skills/core/trust-evolution/config/thresholds.yaml.


@dataclass
class TrustThresholds:
    """User-tunable promotion/demotion sensitivity for the trust ladder.

    Defaults match the pre-Phase-4 hardcoded constants exactly so the
    migration produces zero behavior change. Loaded at server startup
    from the trust-evolution skill config; falls back to these
    defaults when the YAML is missing.
    """
    promote_threshold: int = 5
    demote_threshold: int = 2
    min_completed_for_demotion: int = 3


_THRESHOLDS = TrustThresholds()  # arch:deterministic -- module-level config holder; the actual values come from set_trust_thresholds(skill YAML) at startup, see Phase 4 migration docstring


def set_trust_thresholds(cfg: dict | None) -> None:
    """Install trust evolution thresholds from the trust-evolution skill.

    Called once at server startup from main.py after the SkillLoader
    has loaded thresholds.yaml. Empty/missing config keeps the
    pre-Phase-4 defaults so degraded mode is behavior-neutral.
    """
    global _THRESHOLDS
    if not cfg or not isinstance(cfg, dict):
        return
    _THRESHOLDS = TrustThresholds(
        promote_threshold=int(cfg.get("promote_threshold", _THRESHOLDS.promote_threshold)),
        demote_threshold=int(cfg.get("demote_threshold", _THRESHOLDS.demote_threshold)),
        min_completed_for_demotion=int(
            cfg.get("min_completed_for_demotion", _THRESHOLDS.min_completed_for_demotion)
        ),
    )
    log.info(
        "Trust thresholds: promote=%d demote=%d min_completed=%d",
        _THRESHOLDS.promote_threshold,
        _THRESHOLDS.demote_threshold,
        _THRESHOLDS.min_completed_for_demotion,
    )


def get_trust_thresholds() -> TrustThresholds:
    """Return the current TrustThresholds (used by tests + diagnostics)."""
    return _THRESHOLDS


class TrustService:
    """Manages trust scores in vault/TRUST.md."""

    def __init__(self, vault_reader: VaultReader, vault_writer: VaultWriter) -> None:
        self._reader = vault_reader
        self._writer = vault_writer

    def _trust_path(self) -> str:
        """Resolve TRUST.md path."""
        return self._reader.resolve_identity_path("TRUST.md")

    def get_trust_data(self) -> list[dict]:
        """Parse trust.md into structured data."""
        path = self._trust_path()
        if not self._reader.exists(path):
            return []

        doc = self._reader.read(path)
        return self._parse_trust_table(doc.content)

    def get_domain_trust(self, domain: str) -> dict | None:
        """Get trust data for a specific domain."""
        for row in self.get_trust_data():
            if row["domain"].lower() == domain.lower():
                return row
        return None

    def record_feedback(self, domain: str, rating: str) -> dict:
        """Record task feedback and update trust score.

        Returns dict with domain, old_level, new_level, and whether it changed.
        """
        rows = self.get_trust_data()
        target = None
        for row in rows:
            if row["domain"].lower() == domain.lower():
                target = row
                break

        if not target:
            # Domain not in trust.md — add it
            target = {
                "domain": domain,
                "level": "Advisor",
                "completed": 0,
                "good": 0,
                "needs_improvement": 0,
                "redo": 0,
            }
            rows.append(target)

        old_level = target["level"]

        # Update counts
        target["completed"] += 1
        if rating == "good":
            target["good"] += 1
        elif rating == "needs_improvement":
            target["needs_improvement"] += 1
        elif rating == "redo":
            target["redo"] += 1

        # Check promotion. Threshold loaded from trust-evolution skill
        # config (Phase 4 / Rule 12 migration). Default 5 if no config.
        thresholds = _THRESHOLDS
        new_level = old_level
        if target["good"] >= thresholds.promote_threshold and target["redo"] == 0:
            level_idx = TRUST_LEVELS.index(old_level) if old_level in TRUST_LEVELS else 1
            if level_idx < len(TRUST_LEVELS) - 1:
                new_level = TRUST_LEVELS[level_idx + 1]
                # Reset counters after promotion
                target["good"] = 0

        # Check demotion. Both thresholds loaded from skill config.
        if target["completed"] >= thresholds.min_completed_for_demotion and target["redo"] >= thresholds.demote_threshold:
            level_idx = TRUST_LEVELS.index(old_level) if old_level in TRUST_LEVELS else 1
            if level_idx > 0:
                new_level = TRUST_LEVELS[level_idx - 1]
                # Reset redo counter after demotion
                target["redo"] = 0

        target["level"] = new_level

        # Write back
        self._write_trust_table(rows)

        # Log trust change events for memory synthesis
        if old_level != new_level:
            direction = "promoted" if TRUST_LEVELS.index(new_level) > TRUST_LEVELS.index(old_level) else "demoted"
            change_line = f"- {datetime.now(UTC).strftime('%Y-%m-%d %H:%M')} | {domain} {direction}: {old_level} → {new_level}\n"
            try:
                change_path = "system/identity/trust-changes.md"
                if not self._reader.exists(change_path):
                    self._writer.write(change_path, f"# Trust Change Log\n\n{change_line}")
                else:
                    self._writer.append(change_path, change_line)
                log.info("Trust %s: %s %s → %s", direction, domain, old_level, new_level)
            except Exception:
                log.debug("Failed to log trust change", exc_info=True)

        return {
            "domain": domain,
            "old_level": old_level,
            "new_level": new_level,
            "changed": old_level != new_level,
        }

    def get_recent_changes(self, since_date: str = "") -> list[str]:
        """Get trust change events since a date (YYYY-MM-DD)."""
        change_path = "system/identity/trust-changes.md"
        if not self._reader.exists(change_path):
            return []
        try:
            doc = self._reader.read(change_path)
            lines = [l.strip() for l in doc.content.split("\n") if l.strip().startswith("- ")]
            if since_date:
                lines = [l for l in lines if l.split("|")[0].strip("- ").strip() >= since_date]
            return lines
        except Exception:
            return []

    def _parse_trust_table(self, content: str) -> list[dict]:
        """Parse the markdown trust table into structured data."""
        rows = []
        # Find table rows (skip header and separator)
        table_lines = [
            line.strip()
            for line in content.split("\n")
            if line.strip().startswith("|") and "---" not in line and "Domain" not in line
        ]

        for line in table_lines:
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if len(cells) >= 6:
                rows.append({
                    "domain": cells[0],
                    "level": cells[1],
                    "completed": self._parse_int(cells[2]),
                    "good": self._parse_int(cells[3]),
                    "needs_improvement": self._parse_int(cells[4]),
                    "redo": self._parse_int(cells[5]),
                })
        return rows

    def _write_trust_table(self, rows: list[dict]) -> None:
        """Write trust data back to trust.md as a markdown table."""
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        lines = [
            "---",
            'title: "Trust Scores"',
            "description: Domain-specific trust levels, evolved from task outcomes",
            f"updated: {now}",
            "---",
            "",
            "| Domain | Trust Level | Tasks Completed | Good | Needs Improvement | Redo |",
            "|--------|------------|----------------|------|-------------------|------|",
        ]

        for row in rows:
            lines.append(
                f"| {row['domain']} "
                f"| {row['level']} "
                f"| {row['completed']} "
                f"| {row['good']} "
                f"| {row['needs_improvement']} "
                f"| {row['redo']} |"
            )

        lines.extend([
            "",
            "## How Trust Changes",
            "",
            f"- **Promote:** {_THRESHOLDS.promote_threshold} consecutive good ratings",
            f"- **Demote:** {_THRESHOLDS.demote_threshold} redo ratings within recent tasks",
            "- **No change:** needs_improvement (preference learned, trust stays)",
            "",
            "## Trust Levels",
            "",
            "- **Observer:** Agent will not act without explicit instruction",
            "- **Advisor:** Agent suggests but does not execute",
            "- **Assistant:** Agent executes routine tasks, asks for non-routine",
            "- **Partner:** Agent has full autonomy within contract boundaries",
        ])

        self._writer.write("system/identity/TRUST.md", "\n".join(lines))

    @staticmethod
    def _parse_int(s: str) -> int:
        try:
            return int(s.strip())
        except (ValueError, AttributeError):
            return 0
