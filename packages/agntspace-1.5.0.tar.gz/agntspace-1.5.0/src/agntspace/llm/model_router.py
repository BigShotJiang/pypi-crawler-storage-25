"""Model router — resolves agent model tiers to specific LLM models.

Architecture:
- Agents specify `model_tier` in their definition (reasoning, capable, fast)
- Users pick a `quality_profile` in Settings (quality, balanced, economy)
- This module resolves: profile + provider + tier → specific model name

Configuration loaded from skills/_meta/model-routing/config/models.yaml.
Falls back to hardcoded defaults if YAML not found.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

# Hardcoded fallback — used when YAML config not found
_FALLBACK_PROFILES: dict[str, dict[str, dict[str, str]]] = {
    "quality": {
        "anthropic": {
            "reasoning": "claude-opus-4-20250514",
            "capable": "claude-sonnet-4-20250514",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1",
            "capable": "gpt-4.1",
            "fast": "gpt-4.1-mini",
        },
    },
    "balanced": {
        "anthropic": {
            "reasoning": "claude-sonnet-4-20250514",
            "capable": "claude-sonnet-4-20250514",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1",
            "capable": "gpt-4.1-mini",
            "fast": "gpt-4.1-nano",
        },
    },
    "economy": {
        "anthropic": {
            "reasoning": "claude-sonnet-4-20250514",
            "capable": "claude-haiku-4-5-20251001",
            "fast": "claude-haiku-4-5-20251001",
        },
        "openai": {
            "reasoning": "gpt-4.1-mini",
            "capable": "gpt-4.1-mini",
            "fast": "gpt-4.1-nano",
        },
    },
}

_DEFAULT_TIER = "capable"


class ModelRouter:
    """Resolves model tiers to specific model names."""

    def __init__(
        self,
        provider: str = "anthropic",
        profile: str = "balanced",
        default_model: str = "",
        skills_dir: Path | None = None,
    ) -> None:
        self._provider = provider
        self._profile = profile
        self._default_model = default_model
        self._profiles: dict[str, Any] = {}
        self._load(skills_dir)

    def _load(self, skills_dir: Path | None) -> None:
        """Load model routing config from YAML, fall back to hardcoded."""
        if skills_dir:
            yaml_path = skills_dir / "_meta" / "model-routing" / "config" / "models.yaml"
            if yaml_path.is_file():
                try:
                    import yaml
                    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
                    self._profiles = data.get("profiles", {})
                    log.debug(
                        "Model routing loaded from YAML: %d profiles",
                        len(self._profiles),
                    )
                    return
                except Exception:
                    log.warning("Failed to load model routing YAML, using fallback")

        self._profiles = _FALLBACK_PROFILES

    def resolve(self, model_tier: str | None = None) -> str:
        """Resolve a model tier to a specific model name.

        Args:
            model_tier: "reasoning", "capable", or "fast". None → default tier.

        Returns:
            Specific model name (e.g., "claude-sonnet-4-20250514")
        """
        tier = model_tier or _DEFAULT_TIER

        profile_data = self._profiles.get(self._profile, {})
        provider_data = profile_data.get(self._provider, {})
        model = provider_data.get(tier)

        if model:
            return self._ensure_prefix(model)

        # Fallback chain: default model → capable tier → provider default
        if self._default_model:
            return self._ensure_prefix(self._default_model)

        capable = provider_data.get("capable")
        if capable:
            return self._ensure_prefix(capable)

        return self._ensure_prefix(self._default_model or "claude-sonnet-4-20250514")

    def _ensure_prefix(self, model: str) -> str:
        """Ensure model name has provider/ prefix for LiteLLM routing."""
        if "/" in model:
            return model
        return f"{self._provider}/{model}"

    @property
    def profile(self) -> str:
        return self._profile

    @profile.setter
    def profile(self, value: str) -> None:
        self._profile = value

    def get_profile_summary(self) -> dict[str, str]:
        """Get the model assignments for the current profile."""
        profile_data = self._profiles.get(self._profile, {})
        provider_data = profile_data.get(self._provider, {})
        return dict(provider_data)
