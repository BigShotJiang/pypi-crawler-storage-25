"""Telegram channel implementation using Bot API webhooks."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import httpx

from agntspace.channels.base import Channel, ChannelMessage

log = logging.getLogger(__name__)


class TelegramChannel(Channel):
    """Telegram Bot API channel."""

    name = "telegram"

    def __init__(self, bot_token: str, webhook_url: str = "") -> None:
        self._token = bot_token
        self._webhook_url = webhook_url
        self._base_url = f"https://api.telegram.org/bot{bot_token}"
        self._connected = False
        self._message_callback: Callable | None = None
        self._chat_id: str | None = None

    async def connect(self) -> None:
        """Set up webhook or verify bot token."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self._base_url}/getMe")
            data = resp.json()
            if not data.get("ok"):
                raise ConnectionError(f"Telegram bot token invalid: {data}")

            bot_info = data["result"]
            log.info("Telegram connected: @%s", bot_info.get("username"))

            if self._webhook_url:
                await client.post(
                    f"{self._base_url}/setWebhook",
                    json={"url": self._webhook_url},
                )
                log.info("Telegram webhook set: %s", self._webhook_url)

        self._connected = True

    async def disconnect(self) -> None:
        """Remove webhook."""
        if self._webhook_url:
            async with httpx.AsyncClient() as client:
                await client.post(f"{self._base_url}/deleteWebhook")
        self._connected = False
        log.info("Telegram disconnected")

    async def send_message(self, chat_id: str, text: str) -> None:
        """Send a text message."""
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self._base_url}/sendMessage",
                json={
                    "chat_id": chat_id,
                    "text": text,
                    "parse_mode": "Markdown",
                },
            )

    async def send_notification(self, chat_id: str, text: str) -> None:
        """Send a notification (same as message for Telegram)."""
        await self.send_message(chat_id, f"🔔 {text}")

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def handle_webhook(self, payload: dict[str, Any]) -> str | None:
        """Process an incoming Telegram webhook update.

        Returns the agent's response text, or None if not a text message.
        """
        message = payload.get("message", {})
        text = message.get("text", "")
        chat_id = str(message.get("chat", {}).get("id", ""))
        sender = message.get("from", {}).get("first_name", "User")

        if not text or not chat_id:
            return None

        self._chat_id = chat_id

        channel_msg = ChannelMessage(
            channel="telegram",
            sender=sender,
            text=text,
            metadata={"chat_id": chat_id},
        )

        if self._message_callback:
            response = await self._message_callback(channel_msg)
            if response:
                await self.send_message(chat_id, response)
            return response

        return None
