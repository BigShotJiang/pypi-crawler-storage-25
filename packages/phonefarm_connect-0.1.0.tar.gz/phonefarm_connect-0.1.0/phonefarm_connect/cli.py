"""
PhoneFarm Cloud — Device Connector (Python)
"""

import argparse
import asyncio
import io
import json
import subprocess
import sys

try:
    import websockets
    import websockets.exceptions
except ImportError:
    print("Missing: pip install websockets")
    sys.exit(1)

from phonefarm_connect import __version__

ADB = "adb"


# ── ADB helpers ───────────────────────────────────────────────────────────────


def run_adb(*args, timeout=8):
    try:
        r = subprocess.run(
            [ADB] + list(args), capture_output=True, text=True, timeout=timeout
        )
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except subprocess.TimeoutExpired:
        return "", "timeout", 1
    except FileNotFoundError:
        return "", "adb not found", 1


def get_devices():
    out, _, _ = run_adb("devices")
    return [
        line.split("\t")[0].strip()
        for line in out.splitlines()[1:]
        if "\t" in line and line.split("\t")[1].strip() == "device"
    ]


def get_device_info(serial):
    model, _, _ = run_adb("-s", serial, "shell", "getprop", "ro.product.model")
    android, _, _ = run_adb("-s", serial, "shell", "getprop", "ro.build.version.release")
    battery_out, _, _ = run_adb("-s", serial, "shell", "dumpsys", "battery")
    battery = -1
    for line in battery_out.splitlines():
        if "level:" in line:
            try:
                battery = int(line.split(":")[1].strip())
                break
            except ValueError:
                pass
    res_out, _, _ = run_adb("-s", serial, "shell", "wm", "size")
    resolution = "1080x1920"
    if "Physical size:" in res_out:
        resolution = res_out.split(":")[-1].strip()
    return {
        "serial": serial,
        "model": model or serial,
        "android_ver": android or "",
        "battery": battery,
        "resolution": resolution,
    }


def capture_frame(serial, scale=0.4, quality=35):
    try:
        r = subprocess.run(
            [ADB, "-s", serial, "exec-out", "screencap", "-p"],
            capture_output=True,
            timeout=6,
        )
        if r.returncode != 0 or len(r.stdout) < 100:
            return b""
        try:
            from PIL import Image

            img = Image.open(io.BytesIO(r.stdout))
            img = img.resize(
                (int(img.width * scale), int(img.height * scale)),
                Image.LANCZOS,
            )
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=quality, optimize=True)
            return buf.getvalue()
        except ImportError:
            return r.stdout
    except Exception:
        return b""


def execute_cmd(serial, msg):
    cmd = msg.get("cmd") or msg.get("type", "")
    p = msg
    try:
        if cmd == "tap":
            subprocess.Popen(
                [ADB, "-s", serial, "shell", "input", "tap",
                 str(int(p["x"])), str(int(p["y"]))],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "swipe":
            subprocess.Popen(
                [ADB, "-s", serial, "shell", "input", "swipe",
                 str(int(p["x1"])), str(int(p["y1"])),
                 str(int(p["x2"])), str(int(p["y2"])),
                 str(int(p.get("duration", 300)))],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "type":
            text = str(p.get("text", ""))
            escaped = text.replace(" ", "%s").replace("'", "\\'").replace('"', '\\"')
            subprocess.Popen(
                [ADB, "-s", serial, "shell", "input", "text", f"'{escaped}'"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "key":
            subprocess.Popen(
                [ADB, "-s", serial, "shell", "input", "keyevent", str(p.get("key", "home"))],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "longpress":
            x, y = str(int(p["x"])), str(int(p["y"]))
            dur = str(int(p.get("duration", 1000)))
            subprocess.Popen(
                [ADB, "-s", serial, "shell", "input", "swipe", x, y, x, y, dur],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "adb" and "command" in msg:
            subprocess.Popen(
                [ADB, "-s", serial] + msg["command"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        elif cmd == "fps":
            return ("fps", int(msg.get("value", 8)))
        elif cmd == "quality":
            return ("quality", int(msg.get("value", 35)))
        elif cmd == "scale":
            return ("scale", float(msg.get("value", 0.4)))
    except Exception as e:
        print(f"  ⚠ cmd error ({cmd}): {e}")
    return None


# ── Client loop ───────────────────────────────────────────────────────────────


async def run_client(server_url, code, serial, fps, quality, scale):
    uri = f"{server_url}/ws/connect/{code}"
    print(f"\n🔌 Connecting to {server_url} ...")
    delay = 2

    while True:
        try:
            async with websockets.connect(
                uri, ping_interval=20, ping_timeout=15, max_size=10 * 1024 * 1024
            ) as ws:
                print(f"✅ Connected  code={code}  device={serial}")
                print(f"🎥 {fps}fps  quality={quality}  scale={scale}  (Ctrl+C to quit)\n")
                delay = 2

                info = get_device_info(serial)
                await ws.send(json.dumps({"type": "register", "device": info}))

                settings = {"fps": fps, "quality": quality, "scale": scale}

                async def stream_frames():
                    while True:
                        frame = await asyncio.get_event_loop().run_in_executor(
                            None, capture_frame, serial,
                            settings["scale"], settings["quality"]
                        )
                        if frame:
                            await ws.send(frame)
                        await asyncio.sleep(1.0 / settings["fps"])

                async def recv_commands():
                    while True:
                        data = await ws.recv()
                        if isinstance(data, str):
                            try:
                                msg = json.loads(data)
                                result = execute_cmd(serial, msg)
                                cmd = msg.get("cmd") or msg.get("type", "?")
                                if result:
                                    k, v = result
                                    settings[k] = v
                                    print(f"  ← {k} → {v}")
                                else:
                                    extras = {k: v for k, v in msg.items() if k not in ("cmd", "type")}
                                    print(f"  ← {cmd} {json.dumps(extras) if extras else ''}")
                            except json.JSONDecodeError:
                                pass

                await asyncio.gather(stream_frames(), recv_commands())

        except websockets.exceptions.ConnectionClosed as e:
            print(f"  ⚠ Closed ({e.code}). Retry in {delay}s...")
        except (OSError, ConnectionRefusedError) as e:
            print(f"  ⚠ {e}. Retry in {delay}s...")
        except Exception as e:
            print(f"  ✗ {e}")

        await asyncio.sleep(delay)
        delay = min(delay * 2, 30)
        print("  🔄 Reconnecting...")


# ── Entry point ───────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="PhoneFarm Cloud — connect a local Android device to the platform",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--server", default="ws://localhost:8890",
                        help="Server WebSocket URL (default: ws://localhost:8890)")
    parser.add_argument("--code", required=True,
                        help="6-char connection code from the dashboard")
    parser.add_argument("--serial", default=None,
                        help="ADB device serial (auto-detects if omitted)")
    parser.add_argument("--fps", type=int, default=8, help="Stream FPS (default: 8)")
    parser.add_argument("--quality", type=int, default=35, help="JPEG quality 10-95 (default: 35)")
    parser.add_argument("--scale", type=float, default=0.4, help="Screen scale 0.1-1.0 (default: 0.4)")
    args = parser.parse_args()

    print("=" * 52)
    print(f"  PhoneFarm Cloud Connector  v{__version__}")
    print("=" * 52)

    out, _, code = run_adb("version")
    if code != 0:
        print("✗ ADB not found. Install Android Platform Tools and add to PATH.")
        sys.exit(1)
    print(f"✓ {out.splitlines()[0] if out else 'ADB found'}")

    serial = args.serial
    if not serial:
        devices = get_devices()
        if not devices:
            print("✗ No ADB devices found. Connect a phone and enable USB Debugging.")
            sys.exit(1)
        elif len(devices) == 1:
            serial = devices[0]
            print(f"✓ Device: {serial}")
        else:
            print(f"\n  {len(devices)} devices found:")
            for i, d in enumerate(devices):
                print(f"    [{i + 1}] {d}")
            while True:
                try:
                    choice = int(input("\n  Select device number: ").strip()) - 1
                    if 0 <= choice < len(devices):
                        serial = devices[choice]
                        break
                    print("  Invalid choice.")
                except (ValueError, EOFError):
                    pass
                except KeyboardInterrupt:
                    print("\nAborted.")
                    sys.exit(0)

    try:
        asyncio.run(run_client(args.server, args.code, serial, args.fps, args.quality, args.scale))
    except KeyboardInterrupt:
        print("\n\nDisconnected.")


if __name__ == "__main__":
    main()
