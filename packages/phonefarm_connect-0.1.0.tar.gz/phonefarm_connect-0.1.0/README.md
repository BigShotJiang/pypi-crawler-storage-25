# phonefarm-connect

Connect your local Android device to the [PhoneFarm Cloud](https://github.com/oyi77/1ai-phonefarm) platform.

## Install

```bash
pip install phonefarm-connect

# Optional: better JPEG compression (recommended)
pip install "phonefarm-connect[quality]"
```

## Usage

1. Go to the PhoneFarm dashboard → **Devices** → **Add Device** → **Cloud Relay**
2. Click **Generate Code** to get a 6-char code
3. Plug your Android phone into this PC via USB and enable **USB Debugging**
4. Run:

```bash
phonefarm-connect --server ws://yourserver:8890 --code ABCD12
```

The device will appear in your dashboard automatically.

## Options

```
--server   WebSocket URL of your PhoneFarm server  (default: ws://localhost:8890)
--code     6-char connection code from the dashboard  [required]
--serial   ADB device serial (auto-detects if only one device connected)
--fps      Screen stream FPS, 1-30  (default: 8)
--quality  JPEG quality 10-95  (default: 35)
--scale    Screen scale factor 0.1-1.0  (default: 0.4)
```

## Requirements

- Python 3.8+
- [Android Platform Tools](https://developer.android.com/tools/releases/platform-tools) (`adb` in PATH)
- USB Debugging enabled on the phone
