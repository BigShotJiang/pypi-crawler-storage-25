# codebase-neo4j-sync

Neo4j AST sync bridge (depends on **codebase-ast-core**).

## Install

```bash
pip install codebase-neo4j-sync
```

## CLI

```bash
codebase-sync-ast --repo-root /path/to/clone
```
