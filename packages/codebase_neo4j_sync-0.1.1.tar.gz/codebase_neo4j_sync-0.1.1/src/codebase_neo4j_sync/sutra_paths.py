"""AST core package root (no sys.path hacks)."""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def ast_core_root() -> Path:
    """Return installed codebase_ast_core package directory."""
    import codebase_ast_core

    return Path(codebase_ast_core.__file__).resolve().parent


def ensure_ast_core_config() -> Path:
    """Return ast-core root; sutra JSON config is applied via SUTRAKNOWLEDGE_CONFIG."""
    root = ast_core_root()
    logger.debug("codebase_ast_core root: %s", root)
    return root
