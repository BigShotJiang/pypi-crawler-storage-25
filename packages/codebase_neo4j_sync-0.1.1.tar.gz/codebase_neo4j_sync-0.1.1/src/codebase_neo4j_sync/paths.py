"""Git diff helpers for incremental Neo4j AST indexer sync."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Set, Tuple

logger = logging.getLogger(__name__)


def all_zero_sha(s: str) -> bool:
    t = (s or "").strip().lower().replace("0", "")
    return len(t) == 0 and len((s or "").strip()) > 0


def git_name_status(
    repo: Path, base_ref: str, head_ref: str
) -> list[tuple[str, str, str | None]]:
    """
    Return list of (status, path_a, path_b) where for renames path_b is the new path, else path_b is None.
    `status` is the raw first column (M, A, D, R100, ...).
    """
    p = subprocess.run(
        [
            "git",
            "-C",
            str(repo),
            "diff",
            "--name-status",
            base_ref,
            head_ref,
        ],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    out: list[tuple[str, str, str | None]] = []
    for raw in p.stdout.splitlines():
        line = raw.strip()
        if not line:
            continue
        if "\t" not in line:
            logger.debug("skip unparsed diff line: %s", line[:200])
            continue
        st, rest = line.split("\t", 1)
        st = st.strip()
        if st.startswith("R") or st.startswith("C"):
            if "\t" not in rest:
                continue
            a, b = rest.split("\t", 1)
            out.append((st, a.strip(), b.strip()))
        else:
            out.append((st, rest.strip(), None))
    return out


def classify_git_paths(
    repo: Path, base_ref: str, head_ref: str
) -> Tuple[Set[str], Set[str]]:
    """
    From git name-status, return (deleted_repo_relative_paths, touched_add_or_modify_paths).

    Touched = paths that need parse + insert in Neo4j (A, M, and rename target; also rename source is deleted).
    Paths are as reported by git (forward slashes, relative to repo).
    """
    deleted: Set[str] = set()
    touched: Set[str] = set()
    for st, a, b in git_name_status(repo, base_ref, head_ref):
        if st == "D":
            if a:
                deleted.add(a)
        elif st.startswith("R") or st.startswith("C"):
            if a:
                deleted.add(a)
            if b:
                touched.add(b)
        else:
            if a:
                touched.add(a)
    return deleted, touched


def to_absolute_under_repo(repo: Path, relpath: str) -> str:
    p = relpath.strip()
    if not p:
        return ""
    return str((repo / p).resolve())
