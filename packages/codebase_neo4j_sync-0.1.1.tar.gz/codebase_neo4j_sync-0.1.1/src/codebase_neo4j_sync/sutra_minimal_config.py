"""Write a minimal system.json so sutra ``config`` + Neo4j backend load without ~/.sutra."""

from __future__ import annotations

import json
import os
from pathlib import Path


def _reindex_logic_root() -> Path:
    return Path.cwd()


def build_minimal_system_dict(
    *,
    sutra_root: Path,
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
    neo4j_database: str,
    embedding_model_dir: str,
) -> dict:
    data_dir = _reindex_logic_root() / ".ci" / "sutra_data"
    data_dir.mkdir(parents=True, exist_ok=True)
    model_dir = Path(embedding_model_dir).expanduser().resolve()

    return {
        "database": {
            "knowledge_graph_db": str(data_dir / "graph.db"),
            "embeddings_db": str(data_dir / "embeddings.db"),
            "connection_timeout": 60,
            "max_retry_attempts": 3,
            "batch_size": 100,
            "neo4j": {
                "uri": neo4j_uri,
                "user": neo4j_user,
                "password": neo4j_password,
                "database": neo4j_database,
            },
        },
        "storage": {
            "data_dir": str(data_dir),
            "sessions_dir": str(data_dir / "sessions"),
            "file_changes_dir": str(data_dir / "file_changes"),
            "file_edits_dir": str(data_dir / "file_edits"),
            "parser_results_dir": str(data_dir / "parser_results"),
            "models_dir": str(sutra_root / "models"),
            "lsp_servers_dir": str(data_dir / "lsp"),
        },
        "embedding": {
            "model_path": str(model_dir),
            "tokenizer_max_length": 256,
            "max_tokens": 240,
            "overlap_tokens": 30,
            "inference_batch_size": 16,
        },
        "logging": {
            "level": "INFO",
            "format": "%(message)s",
            "logs_dir": str(data_dir / "logs"),
        },
        "web_search": {"api_key": "", "requests_per_minute": 0, "timeout": 30},
        "web_scrap": {
            "timeout": 30,
            "max_retries": 3,
            "delay_between_retries": 1.0,
            "include_comments": True,
            "include_tables": True,
            "include_images": True,
            "include_links": True,
            "trafilatura_config": {},
            "markdown_options": {},
        },
    }


def write_minimal_system_config(
    *,
    sutra_root: Path,
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
    neo4j_database: str,
    embedding_model_dir: str,
    out_path: Path | None = None,
) -> Path:
    out = out_path or (_reindex_logic_root() / ".ci" / "sutra_system.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    cfg = build_minimal_system_dict(
        sutra_root=sutra_root,
        neo4j_uri=neo4j_uri,
        neo4j_user=neo4j_user,
        neo4j_password=neo4j_password,
        neo4j_database=neo4j_database,
        embedding_model_dir=embedding_model_dir,
    )
    out.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return out


def apply_sutra_config_env(config_path: Path) -> None:
    os.environ["SUTRAKNOWLEDGE_CONFIG"] = str(config_path.resolve())
    try:
        from codebase_ast_core.config.settings import reload_config

        reload_config()
    except Exception:
        pass
