"""
AST extraction + Neo4j graph load + sentence-transformers embeddings (codebase-ast-core).
"""

from __future__ import annotations

import argparse
import importlib.util
import logging
import os
import subprocess
import sys
from pathlib import Path

from codebase_ast_core.indexer import extract_and_export_directory
from codebase_ast_core.settings import get_settings
from codebase_neo4j_sync.paths import (
    all_zero_sha,
    classify_git_paths,
    to_absolute_under_repo,
)
from codebase_neo4j_sync.sutra_minimal_config import (
    apply_sutra_config_env,
    write_minimal_system_config,
)
from codebase_neo4j_sync.sutra_paths import ensure_ast_core_config

logger = logging.getLogger(__name__)

_ST_DEFAULT_REPO = "sentence-transformers/all-MiniLM-L6-v2"


def _cache_base() -> Path:
    raw = os.environ.get("CODEBASE_CACHE_DIR", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.cwd() / ".cache"


def _st_model_ready(model_path: Path) -> bool:
    return (model_path / "config.json").is_file()


def _maybe_download_st_model(model_path: Path) -> bool:
    if _st_model_ready(model_path):
        return True
    flag = os.environ.get("REINDEX_AUTO_DOWNLOAD_MODEL", "1").strip().lower()
    if flag in ("0", "false", "no", "off"):
        return False
    model_path.mkdir(parents=True, exist_ok=True)
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        logger.warning("huggingface_hub not installed; cannot auto-download ST model")
        return False
    try:
        logger.info("Downloading %s -> %s", _ST_DEFAULT_REPO, model_path)
        snapshot_download(repo_id=_ST_DEFAULT_REPO, local_dir=str(model_path))
    except Exception as e:
        logger.warning("snapshot_download failed: %s", e)
        return False
    return _st_model_ready(model_path)


def _git_toplevel(cwd: Path) -> Path:
    r = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=str(cwd),
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return Path(r.stdout.strip()).resolve()


def _default_project_name(repo: Path) -> str:
    base = repo.name or "project"
    safe = "".join(c if c.isalnum() else "_" for c in base)[:48].strip("_") or "project"
    return f"reindex_{safe}"


def _parse_base_head(args: argparse.Namespace) -> tuple[str | None, str | None]:
    base = (args.base_ref or os.environ.get("SYNC_BASE_REF", "") or "").strip() or None
    head = (args.head_ref or os.environ.get("SYNC_HEAD_REF", "") or "").strip() or None
    return base, head


def _wants_incremental(
    base: str | None, head: str | None, args: argparse.Namespace
) -> bool:
    if getattr(args, "full", False) or os.environ.get("REINDEX_FULL", "").strip() in (
        "1",
        "true",
        "yes",
    ):
        return False
    if not base or not head:
        return False
    if all_zero_sha(base):
        return False
    v = os.environ.get("REINDEX_INCREMENTAL", "1").strip().lower()
    if v in ("0", "false", "no", "off"):
        return False
    return True


def _extraction_key_for_relpath(
    repo: Path, extraction_files: dict, relpath: str
) -> str | None:
    want = str((repo / relpath).resolve())
    for k in extraction_files:
        try:
            if str(Path(k).resolve()) == want:
                return k
        except (OSError, ValueError, RuntimeError):
            continue
    return None


def _run_full_import_and_embed(
    repo: Path,
    out_json: Path,
    project_name: str,
    keep_existing_project: bool,
    skip_embeddings: bool,
) -> int:
    from codebase_ast_core.graph.ast_to_neo4j_converter import ASTToNeo4jConverter
    from codebase_ast_core.graph.backend_factory import get_connection, reset_factory
    from codebase_ast_core.graph.project_indexer import ProjectIndexer

    reset_factory()
    conn = get_connection()
    if not keep_existing_project and conn.project_exists(project_name):
        logger.info("Deleting existing project %r", project_name)
        conn.delete_project(project_name)

    reset_factory()
    converter = ASTToNeo4jConverter()
    try:
        converter.convert_json_to_graph(
            json_file_path=out_json,
            project_path=repo,
            project_name=project_name,
            clear_existing=False,
        )
    finally:
        converter.close()

    reset_factory()

    if skip_embeddings:
        logger.info("Skipping indexer embedding pass.")
        return 0

    reset_factory()
    indexer = ProjectIndexer()
    indexer._generate_embeddings_for_project(out_json, project_name)  # noqa: SLF001
    logger.info("Indexer + Neo4j + embeddings completed for project %r.", project_name)
    return 0


def _run_incremental_file_sync(
    repo: Path,
    out_json: Path,
    project_name: str,
    base_ref: str,
    head_ref: str,
    skip_embeddings: bool,
) -> int:
    from codebase_ast_core.embeddings.embedding_engine import get_embedding_engine
    from codebase_ast_core.graph.backend_factory import (
        get_connection,
        get_graph_operations,
        reset_factory,
    )
    from codebase_ast_core.models.schema import ExtractionData
    from codebase_ast_core.utils.helpers import load_json_file

    deleted_rels, touched_rels = classify_git_paths(repo, base_ref, head_ref)
    logger.info(
        "Incremental sync: %d deleted path(s), %d added/modified path(s) (ref %s..%s)",
        len(deleted_rels),
        len(touched_rels),
        base_ref[:12],
        head_ref[:12],
    )
    if not deleted_rels and not touched_rels:
        logger.info("No file-level changes; Neo4j unchanged.")
        return 0

    json_data = load_json_file(out_json)
    extraction_data = ExtractionData(**json_data)
    fl = extraction_data.files
    if not fl:
        logger.error("Extraction has no files; cannot run incremental import.")
        return 1

    touched_keys: list[str] = []
    for relp in touched_rels:
        key = _extraction_key_for_relpath(repo, fl, relp)
        if key is None:
            logger.warning(
                "Touched file has no parse result in extraction (skip graph update): %r",
                relp,
            )
        else:
            touched_keys.append(key)

    if not deleted_rels and not touched_keys:
        logger.info("No extraction entries for any touched file; done.")
        return 0

    reset_factory()
    conn = get_connection()
    project = conn.get_project(project_name)
    if not project:
        logger.error("Project %r not found; run a full reindex first.", project_name)
        return 1
    project_id = int(project.id)

    graph_ops = get_graph_operations()
    embed_engine = get_embedding_engine() if not skip_embeddings else None

    def _purge_one_path(abs_path_str: str) -> None:
        fid = conn.resolve_file_id(project_id, abs_path_str)
        if fid is None:
            return
        nids = conn.collect_embedding_node_ids_for_file(int(fid))
        if embed_engine is not None and nids:
            embed_engine.delete_embeddings(nids, project_id)
        conn.delete_file_subgraph_by_id(int(fid))

    for relp in deleted_rels:
        abs_s = to_absolute_under_repo(repo, relp)
        _purge_one_path(abs_s)

    for relp in touched_rels:
        if _extraction_key_for_relpath(repo, fl, relp) is None:
            continue
        abs_s = to_absolute_under_repo(repo, relp)
        _purge_one_path(abs_s)

    if touched_keys:
        sub = {k: fl[k] for k in touched_keys if k in fl}
        if not sub:
            logger.warning("No matched file keys to insert after purge.")
        else:
            part = ExtractionData(metadata=extraction_data.metadata, files=sub)
            graph_ops.insert_extraction_data(part, project_id)

    if skip_embeddings or embed_engine is None:
        if touched_keys and not skip_embeddings and embed_engine is None:
            logger.warning("Embedding engine missing; graph updated without re-embed.")
        elif skip_embeddings and touched_keys:
            logger.info("Skip embeddings: graph updated for touched files only.")
        return 0

    to_embed = [fl[k] for k in touched_keys if k in fl]
    if to_embed:
        embed_engine.process_multiple_files(to_embed, project_id)
    logger.info(
        "Incremental indexer: updated %d file(s) in project %r.",
        len(touched_keys),
        project_name,
    )
    return 0


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    for stream in (sys.stdout, sys.stderr):
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError, AttributeError):
                pass

    parser = argparse.ArgumentParser(
        description="AST indexer -> Neo4j (codebase-ast-core + codebase-neo4j-sync).",
    )
    parser.add_argument("--repo-root", type=Path, default=None)
    parser.add_argument(
        "--project-name",
        default=os.environ.get("REINDEX_PROJECT_NAME", "").strip() or None,
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--skip-embeddings", action="store_true")
    parser.add_argument("--keep-existing-project", action="store_true")
    parser.add_argument("--base-ref", default=None)
    parser.add_argument("--head-ref", default=None)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()

    cwd = Path.cwd().resolve()
    if args.repo_root is not None:
        repo = args.repo_root.resolve()
        if not (repo / ".git").exists():
            logger.error("--repo-root is not a git checkout: %s", repo)
            return 1
    else:
        try:
            repo = _git_toplevel(cwd)
        except subprocess.CalledProcessError:
            logger.error("Not a git repository (run from repo root or pass --repo-root).")
            return 1

    rs = get_settings()
    sutra_root = ensure_ast_core_config()

    model_dir = os.environ.get("INDEXER_MODEL_PATH", "").strip()
    if not model_dir:
        try:
            model_dir = str(Path(rs.embed_model).expanduser().resolve())
        except Exception:
            model_dir = str(sutra_root / "models" / "all-MiniLM-L6-v2")
    model_path = Path(model_dir)
    skip_embeddings = args.skip_embeddings or args.dry_run
    if not skip_embeddings and not _st_model_ready(model_path):
        if _maybe_download_st_model(model_path):
            logger.info("Sentence-transformers model ready at %s", model_path)
        else:
            logger.warning(
                "Embedding model not found at %s — graph only (no EmbeddingChunk).",
                model_path,
            )
            skip_embeddings = True

    cfg_path = write_minimal_system_config(
        sutra_root=sutra_root,
        neo4j_uri=rs.neo4j_uri,
        neo4j_user=rs.neo4j_user,
        neo4j_password=rs.neo4j_password,
        neo4j_database=rs.neo4j_database,
        embedding_model_dir=str(model_path),
    )
    apply_sutra_config_env(cfg_path)
    logger.info("Sutra config: %s", cfg_path)

    project_name = args.project_name or _default_project_name(repo)
    cache_dir = _cache_base()
    cache_dir.mkdir(parents=True, exist_ok=True)
    out_json = cache_dir / "indexer_extraction.json"

    logger.info("Extracting from %s -> %s", repo, out_json)
    if not extract_and_export_directory(dir_path=repo, output_file=out_json, indent=2):
        logger.error("extract_and_export_directory failed.")
        return 1

    if args.dry_run:
        logger.info("Dry run: wrote %s", out_json)
        return 0

    from codebase_ast_core.graph.backend_factory import get_connection, reset_factory

    base, head = _parse_base_head(args)
    use_incremental = _wants_incremental(base, head, args)

    reset_factory()
    conn0 = get_connection()
    if use_incremental and not conn0.project_exists(project_name):
        logger.info("Project %r not in graph yet; using full reindex.", project_name)
        use_incremental = False
    if use_incremental and not (
        hasattr(conn0, "delete_file_subgraph_by_id") and hasattr(conn0, "resolve_file_id")
    ):
        logger.warning("Incremental reindex unavailable; running full import.")
        use_incremental = False

    if use_incremental and base and head:
        reset_factory()
        return _run_incremental_file_sync(
            repo, out_json, project_name, base, head, skip_embeddings
        )

    return _run_full_import_and_embed(
        repo,
        out_json,
        project_name,
        keep_existing_project=args.keep_existing_project,
        skip_embeddings=skip_embeddings,
    )


if __name__ == "__main__":
    raise SystemExit(main())
