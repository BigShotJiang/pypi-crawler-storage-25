"""Neo4j AST sync (depends on codebase-ast-core)."""

from codebase_neo4j_sync.sync import main

__all__ = ["main"]
__version__ = "0.1.0"
