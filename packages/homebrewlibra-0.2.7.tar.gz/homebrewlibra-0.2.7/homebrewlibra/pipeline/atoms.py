"""Atomic chain helpers for loop-based accumulation.

Each function is stateless — takes data/files in, returns data out.
Intermediate steps that should NOT overwrite the accumulated ``ddf``
return ``{"ddf2": ...}`` so the runner stores the result in
``ctx["ddf2"]`` and leaves ``ctx["ddf"]`` untouched.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import pandas as pd
from pandas import DataFrame

logger = logging.getLogger(__name__)


def _resolve_templates(value: Any, ctx: dict[str, Any]) -> Any:
    """Replace ``{var}`` placeholders inside strings using *ctx*."""
    if isinstance(value, str):
        def _repl(m: re.Match) -> str:
            key = m.group(1)
            return str(ctx.get(key, m.group(0)))
        return re.sub(r"\{([^}]+)\}", _repl, value)
    if isinstance(value, dict):
        return {
            _resolve_templates(k, ctx): _resolve_templates(v, ctx)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_resolve_templates(v, ctx) for v in value]
    return value


def _parse_rename_map(raw: str | dict[str, str] | None, ctx: dict[str, Any]) -> dict[str, str] | None:
    """Resolve rename_map from inline dict or comma-separated pairs."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        return _resolve_templates(raw, ctx)
    raw = str(raw).strip()
    if not raw:
        return None
    # Try eval first (inline dict literal)
    try:
        parsed = eval(raw, {"__builtins__": {}}, ctx)
        if isinstance(parsed, dict):
            return _resolve_templates(parsed, ctx)
    except Exception:
        pass
    # Fallback: comma-separated pairs  old_name:new_name, ...
    result: dict[str, str] = {}
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            logger.warning("rename_map entry missing colon: %s", part)
            continue
        src, dst = part.split(":", 1)
        result[src.strip()] = _resolve_templates(dst.strip(), ctx)
    return result if result else None


def _parse_fillna_rules(raw: str | dict[str, Any] | None, ctx: dict[str, Any]) -> dict[str, Any] | str | None:
    """Resolve fillna rules from inline dict, comma-separated pairs, or global string."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        return _resolve_templates(raw, ctx)
    raw = str(raw).strip()
    if not raw:
        return None
    # Simple global rule (ffill, bfill, median, mean)
    if raw in ("ffill", "bfill", "median", "mean"):
        return raw
    # Try eval first
    try:
        parsed = eval(raw, {"__builtins__": {}}, ctx)
        if isinstance(parsed, dict):
            return _resolve_templates(parsed, ctx)
        if isinstance(parsed, str):
            return parsed
    except Exception:
        pass
    # Fallback: comma-separated pairs  col:rule, ...
    result: dict[str, Any] = {}
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            logger.warning("fillna_rules entry missing colon: %s", part)
            continue
        col, rule = part.split(":", 1)
        rule = rule.strip()
        # Try numeric
        try:
            rule = int(rule)
        except ValueError:
            try:
                rule = float(rule)
            except ValueError:
                pass
        result[_resolve_templates(col.strip(), ctx)] = rule
    return result if result else None


def _resolve_func(func: str | Any) -> Any:
    """Resolve a string *func* to a callable.

    Supports:
    * ``module.submodule:function_name`` → import and return callable
    * plain string → ``eval`` in restricted context
    * already-callable → pass through
    """
    if callable(func):
        return func
    if not isinstance(func, str):
        raise TypeError(f"func must be callable or string, got {type(func).__name__}")
    func = func.strip()
    if not func:
        raise ValueError("func string is empty")
    # Import path syntax:  module:function_name
    if ":" in func:
        import importlib
        mod_path, func_name = func.split(":", 1)
        mod = importlib.import_module(mod_path)
        return getattr(mod, func_name)
    # Fallback: eval in restricted context
    try:
        return eval(func, {"__builtins__": {}}, {})
    except Exception as exc:
        raise ValueError(f"Cannot resolve func string {func!r}: {exc}")


# ---------------------------------------------------------------------------
# ddf2 loaders / transformers
# ---------------------------------------------------------------------------

def load_feather_to_ddf2(input_file: str | Path | None = None, **kwargs: Any) -> dict[str, DataFrame]:
    """Load a data file (extension-agnostic) and return ``{"ddf2": df}``.

    Parameters
    ----------
    input_file
        Path to the data file (resolved by runner templates).

    Returns
    -------
    dict[str, DataFrame]
        ``{"ddf2": loaded_df}`` — runner stores this in ``ctx["ddf2"]``.
    """
    from homebrewlibra.pipeline.io import load_data_to_ddf2

    return load_data_to_ddf2(input_file=input_file, **kwargs)


def rename_columns(
    ddf: DataFrame | None = None,
    rename_map: str | dict[str, str] | None = None,
    ctx: dict[str, Any] | None = None,
    **kwargs: Any,
) -> dict[str, DataFrame]:
    """Rename columns and return ``{"ddf2": df}``.

    Values in *rename_map* can contain template variables such as
    ``{ticker}`` or ``{period}`` — they are resolved at runtime.

    Parameters
    ----------
    ddf
        DataFrame to rename (typically ``ctx["ddf2"]`` via ``source_ddf = ddf2``).
    rename_map
        Either a dict literal, or comma-separated ``old:new`` pairs.
        Example: ``{'price': '{ticker}_price', 'amount': '{ticker}_volume'}``
        or ``price:{ticker}_price,amount:{ticker}_volume``.

    Returns
    -------
    dict[str, DataFrame]
        ``{"ddf2": renamed_df}``.
    """
    if ddf is None:
        raise ValueError("ddf is required")
    if ctx is None:
        ctx = kwargs
    resolved = _parse_rename_map(rename_map, ctx)
    if not resolved:
        logger.info("No rename_map provided — passing through")
        return {"ddf2": ddf}
    # Only rename columns that exist
    actual = {k: v for k, v in resolved.items() if k in ddf.columns}
    if actual:
        df = ddf.rename(columns=actual)
        logger.info("Renamed columns: %s", actual)
    else:
        df = ddf
        logger.info("No matching columns to rename")
    return {"ddf2": df}


def select_columns(
    ddf: DataFrame | None = None,
    columns: str | list[str] | None = None,
    ctx: dict[str, Any] | None = None,
    **kwargs: Any,
) -> dict[str, DataFrame]:
    """Keep only selected columns and return ``{"ddf2": df}``.

    Parameters
    ----------
    ddf
        DataFrame to filter.
    columns
        Comma-separated string or list of column names.
        Supports templates: ``{ticker}_price,{ticker}_volume,timestamp``.

    Returns
    -------
    dict[str, DataFrame]
        ``{"ddf2": filtered_df}``.
    """
    if ddf is None:
        raise ValueError("ddf is required")
    if columns is None:
        logger.info("No columns provided — passing through")
        return {"ddf2": ddf}
    if ctx is None:
        ctx = kwargs
    if isinstance(columns, str):
        columns = [c.strip() for c in columns.split(",") if c.strip()]
    columns = _resolve_templates(columns, ctx)
    if isinstance(columns, str):
        columns = [columns]
    missing = [c for c in columns if c not in ddf.columns]
    if missing:
        logger.warning("select_columns: missing %s — skipping them", missing)
    keep = [c for c in columns if c in ddf.columns]
    if not keep:
        raise ValueError(f"None of the requested columns exist: {columns}")
    df = ddf[keep].copy()
    logger.info("Selected %s columns: %s", len(keep), keep)
    return {"ddf2": df}


# ---------------------------------------------------------------------------
# Accumulation
# ---------------------------------------------------------------------------

def join_ddf(
    ddf: DataFrame | None = None,
    ddf2: DataFrame | None = None,
    join_on: str | list[str] | None = None,
    how: str = "outer",
    **kwargs: Any,
) -> DataFrame:
    """Merge ``ddf2`` into the accumulated ``ddf``.

    On the first iteration ``ddf`` is ``None`` — ``ddf2`` is returned as-is.

    Parameters
    ----------
    ddf
        Accumulated DataFrame from previous iterations.
    ddf2
        Current iteration's DataFrame.
    join_on
        Column(s) to align on. If ``None``, joins on the index.
    how
        Merge strategy: ``outer`` (default), ``left``, ``right``, ``inner``.

    Returns
    -------
    DataFrame
        The merged result — runner stores this in ``ctx["ddf"]``.
    """
    if ddf2 is None:
        raise ValueError("ddf2 is required")
    if ddf is None or ddf.empty:
        logger.info("First iteration — returning ddf2 as base (%s rows)", len(ddf2))
        return ddf2

    if join_on is None:
        # Index-based join
        df = ddf.join(ddf2, how=how, rsuffix="_r")
        # Drop auto-suffix columns if they exist (prefer left side)
        dup_cols = [c for c in df.columns if c.endswith("_r")]
        if dup_cols:
            df = df.drop(columns=dup_cols)
        logger.info("Index-joined: %s + %s → %s rows", len(ddf), len(ddf2), len(df))
    else:
        if isinstance(join_on, str):
            join_on = [c.strip() for c in join_on.split(",") if c.strip()]
        df = pd.merge(ddf, ddf2, on=join_on, how=how, suffixes=("", "_r"))
        dup_cols = [c for c in df.columns if c.endswith("_r")]
        if dup_cols:
            df = df.drop(columns=dup_cols)
        logger.info("Column-joined on %s: %s + %s → %s rows", join_on, len(ddf), len(ddf2), len(df))
    return df


def concat_vertical(
    ddf: DataFrame | None = None,
    ddf2: DataFrame | None = None,
    ignore_index: bool = False,
    **kwargs: Any,
) -> DataFrame:
    """Stack ``ddf2`` rows under the accumulated ``ddf``.

    On the first iteration ``ddf`` is ``None`` — ``ddf2`` is returned as-is.

    Parameters
    ----------
    ddf
        Accumulated DataFrame from previous iterations.
    ddf2
        Current iteration's DataFrame.
    ignore_index
        If ``True``, the resulting axis is relabeled 0, 1, …, n-1.
        If ``False`` (default), existing index values are kept.

    Returns
    -------
    DataFrame
        Vertical concatenation — runner stores this in ``ctx["ddf"]``.
    """
    if ddf2 is None:
        raise ValueError("ddf2 is required")
    if ddf is None or ddf.empty:
        logger.info("First iteration — returning ddf2 as base (%s rows)", len(ddf2))
        return ddf2

    df = pd.concat([ddf, ddf2], ignore_index=ignore_index)
    logger.info(
        "Vertically stacked: %s + %s → %s rows (ignore_index=%s)",
        len(ddf),
        len(ddf2),
        len(df),
        ignore_index,
    )
    return df


def fillna_rules(
    ddf: DataFrame | None = None,
    rules: str | dict[str, Any] | None = None,
    ctx: dict[str, Any] | None = None,
    **kwargs: Any,
) -> DataFrame:
    """Apply per-column NA fill rules.

    Parameters
    ----------
    ddf
        DataFrame to fill.
    rules
        Global rule string (``ffill``, ``bfill``, ``median``, ``mean``)
        or per-column mapping.
        Examples::

            ffill
            {'{ticker}_volume': 0, '{ticker}_close': 'ffill'}
            {ticker}_volume:0,{ticker}_close:ffill

    Returns
    -------
    DataFrame
        DataFrame with NAs filled.
    """
    if ddf is None:
        raise ValueError("ddf is required")
    if ctx is None:
        ctx = kwargs
    resolved = _parse_fillna_rules(rules, ctx)
    if not resolved:
        logger.info("No fillna rules — passing through")
        return ddf

    df = ddf.copy()
    filled: dict[str, str] = {}

    if isinstance(resolved, str):
        # Global rule
        method = resolved.lower()
        if method == "ffill":
            df = df.ffill()
            filled["*"] = "ffill"
        elif method == "bfill":
            df = df.bfill()
            filled["*"] = "bfill"
        elif method == "median":
            for col in df.select_dtypes(include="number").columns:
                if df[col].isna().any():
                    df[col] = df[col].fillna(df[col].median())
                    filled[col] = "median"
        elif method == "mean":
            for col in df.select_dtypes(include="number").columns:
                if df[col].isna().any():
                    df[col] = df[col].fillna(df[col].mean())
                    filled[col] = "mean"
    else:
        # Per-column rules
        for col, rule in resolved.items():
            if col not in df.columns:
                logger.warning("fillna_rules: column '%s' not found — skipping", col)
                continue
            if not df[col].isna().any():
                continue
            if rule == "ffill":
                df[col] = df[col].ffill()
            elif rule == "bfill":
                df[col] = df[col].bfill()
            elif rule == "median":
                df[col] = df[col].fillna(df[col].median())
            elif rule == "mean":
                df[col] = df[col].fillna(df[col].mean())
            elif isinstance(rule, (int, float)):
                df[col] = df[col].fillna(rule)
            else:
                logger.warning("Unknown fillna rule '%s' for column '%s' — skipping", rule, col)
                continue
            filled[col] = str(rule)

    if filled:
        logger.info("Filled NAs: %s", filled)
    return df


# ---------------------------------------------------------------------------
# Generic transforms
# ---------------------------------------------------------------------------

def apply_transform(
    ddf: DataFrame | None = None,
    column: str | None = None,
    func: str | Any | None = None,
    new_column: str | None = None,
    func_args: str | dict[str, Any] | None = None,
    ctx: dict[str, Any] | None = None,
    **kwargs: Any,
) -> DataFrame:
    """Apply a user-provided transform to a column and add the result.

    *func* receives the target Series and any extra keyword arguments.
    The result is stored under *new_column* in a copy of *ddf*.

    Parameters
    ----------
    ddf
        DataFrame to transform.
    column
        Existing column name to pass to *func*.
    func
        Callable or dotted-path string like ``module.submodule:function_name``.
        In config you can inject a callable via context (e.g. ``func = @sma_func``).
    new_column
        Name of the new column to create.
    func_args
        Extra keyword arguments passed to *func* (inline dict or dict literal).

    Returns
    -------
    DataFrame
        Copy of *ddf* with *new_column* added.

    Examples
    --------
    Config usage::

        [step_log_price]
        source_ddf = ddf
        column = price
        func = numpy:log
        new_column = log_price

        [step_rolling_mean]
        source_ddf = ddf
        column = price
        func = @my_sma       # injected via runner._ctx["my_sma"] = ta.trend.sma_indicator
        new_column = sma_7
        func_args = {'window': 7}
    """
    if ddf is None:
        raise ValueError("ddf is required")
    if column is None:
        raise ValueError("column is required")
    if func is None:
        raise ValueError("func is required")
    if new_column is None:
        raise ValueError("new_column is required")

    resolved_func = _resolve_func(func)

    if ctx is None:
        ctx = kwargs

    if isinstance(func_args, str):
        try:
            func_args = eval(func_args, {"__builtins__": {}}, ctx)
        except Exception as exc:
            raise ValueError(f"Cannot parse func_args {func_args!r}: {exc}")
    if func_args is None:
        func_args = {}
    if isinstance(func_args, dict):
        func_args = _resolve_templates(func_args, ctx)

    series = ddf[column]
    result = resolved_func(series, **func_args)

    if not isinstance(result, pd.Series):
        result = pd.Series(result, index=ddf.index)

    df = ddf.copy()
    df[new_column] = result
    logger.info(
        "Applied %s to '%s' → '%s' (%s rows)",
        getattr(resolved_func, "__name__", resolved_func),
        column,
        new_column,
        len(df),
    )
    return df


# ---------------------------------------------------------------------------
# Exchange-specific standardization
# ---------------------------------------------------------------------------

#: Column mappings from raw exchange names → canonical names.
# Canonical columns: price, volume, timestamp, side, type, misc, id
_EXCHANGE_COL_MAPS: dict[str, dict[str, str]] = {
    "kraken": {
        "price": "price",
        "amount": "volume",
        "timestamp": "timestamp",
        "buy/sell": "side",
        "market/limit": "type",
        "miscellaneous": "misc",
        "trade_id": "id",
    },
}


def _standardize_df(df: DataFrame, exchange: str = "kraken") -> DataFrame:
    """Rename and type-cast raw exchange columns to canonical format.

    Parameters
    ----------
    df
        Raw DataFrame from exchange API.
    exchange
        Exchange label (e.g. ``"kraken"``).

    Returns
    -------
    DataFrame
        Copy with canonical column names and correct dtypes.
    """
    rename_map = _EXCHANGE_COL_MAPS.get(exchange)
    if rename_map is None:
        raise ValueError(f"No column mapping for exchange: {exchange}")

    # Only rename columns that actually exist
    actual_map = {k: v for k, v in rename_map.items() if k in df.columns}
    df = df.rename(columns=actual_map)

    # Convert numeric columns
    for col in ("price", "volume"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Convert id to Int64
    if "id" in df.columns:
        df["id"] = df["id"].astype("Int64")

    # Parse unix timestamps (seconds since epoch)
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True)

    return df


def standardize_columns(
    ddf: DataFrame | None = None,
    exchange: str = "kraken",
    **kwargs: Any,
) -> dict[str, DataFrame]:
    """Atomic wrapper for ``_standardize_df``.

    Returns ``{"ddf2": df}`` so the runner stores it in ``ctx["ddf2"]``.

    Config example::

        [step_standardize]
        source_ddf = ddf2
        exchange = kraken
    """
    if ddf is None:
        raise ValueError("ddf is required")
    df = _standardize_df(ddf, exchange=exchange)
    logger.info("Standardized %s columns (%s rows)", exchange, len(df))
    return {"ddf2": df}
