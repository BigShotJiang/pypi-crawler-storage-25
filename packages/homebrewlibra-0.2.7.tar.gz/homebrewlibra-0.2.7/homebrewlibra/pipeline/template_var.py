"""Template variable system with type-aware masks and .next() iteration.

Replaces regex-based placeholder extraction with fixed-width masks,
eliminating ambiguity when placeholders are adjacent (e.g. {period}{sz}).
"""
from __future__ import annotations

import logging
import re
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)

__all__ = ["TemplateVar", "TemplateResolver"]


# ---------------------------------------------------------------------------
# TemplateVar
# ---------------------------------------------------------------------------

class TemplateVar:
    """A single template variable with mask, formatting, and iteration support."""

    def __init__(self, name: str, cfg: dict[str, str], default_value: str = ""):
        self.name = name
        self._type = cfg.get("type", "string")
        self.mask = cfg.get("mask", ".+?")
        self.format_str = cfg.get("format", "").replace("%%", "%")
        self.date_format = cfg.get("date_format", "").replace("%%", "%")
        self.increment = cfg.get("increment", "1")
        self._raw_values = cfg.get("values", "")

        self._value: str = default_value
        self._original: str = default_value
        self._list: list[str] = []
        self._idx: int = 0

        if self._type == "list" and self._raw_values:
            self._list = [v.strip() for v in self._raw_values.split(",") if v.strip()]
            if self._list:
                self._value = self._list[0]
                self._original = self._list[0]

    # -- properties --------------------------------------------------------

    @property
    def value(self) -> str:
        if self._type == "list" and self._list:
            return self._list[self._idx]
        return self._value

    @value.setter
    def value(self, v: str) -> None:
        self._value = v
        if not self._original:
            self._original = v
        if self._type == "list" and self._list:
            try:
                self._idx = self._list.index(v)
            except ValueError:
                pass

    # -- iteration ---------------------------------------------------------

    def first(self) -> str:
        """Reset to first value."""
        if self._type == "list" and self._list:
            self._idx = 0
            return self._list[0]
        self._value = self._original
        return self._value

    def next(self) -> str | None:
        """Advance value; return new value or None at end."""
        if self._type == "list":
            if self._idx + 1 < len(self._list):
                self._idx += 1
                return self._list[self._idx]
            return None

        if self._type == "date":
            return self._next_date()

        if self._type == "numeric":
            return self._next_numeric()

        # string / literal — no natural next
        return None

    def last(self) -> str:
        """Jump to the final value."""
        if self._type == "list" and self._list:
            self._idx = len(self._list) - 1
            return self._list[self._idx]
        self._value = self._original
        return self._value

    def _next_date(self) -> str | None:
        fmt = self.date_format or "%Y%m"
        try:
            dt = pd.to_datetime(self.value, format=fmt)
        except (ValueError, TypeError):
            return None

        inc = self.increment or "month"
        if inc == "month":
            nxt = dt + pd.DateOffset(months=1)
        elif inc == "day":
            nxt = dt + pd.DateOffset(days=1)
        else:
            try:
                nxt = dt + pd.DateOffset(months=int(inc))
            except ValueError:
                return None

        self._value = nxt.strftime(fmt)
        return self._value

    def _next_numeric(self) -> str | None:
        try:
            inc = int(self.increment or "1")
            val = int(self.value)
            nxt = val + inc
            self._value = self.format_str % nxt if self.format_str else str(nxt)
            return self._value
        except (ValueError, TypeError):
            return None

    # -- formatting / validation -------------------------------------------

    def formatted(self) -> str:
        if self._type == "numeric" and self.format_str:
            try:
                return self.format_str % int(self.value)
            except (ValueError, TypeError):
                pass
        return self.value

    def regex_fragment(self) -> str:
        return f"(?P<{self.name}>{self.mask})"

    def validate(self, v: str) -> bool:
        return bool(re.fullmatch(self.mask, v))

    # -- date component support --------------------------------------------

    _COMPONENT_MAP: dict[str, str] = {
        "year": "%Y",
        "month": "%m",
        "day": "%d",
        "hour": "%H",
        "minute": "%M",
        "second": "%S",
    }

    def has_component(self, method: str) -> bool:
        """Return True if *method* is a known date component for this variable."""
        return self._type == "date" and method in self._COMPONENT_MAP

    def get_component(self, method: str) -> str | None:
        """Extract a date component (year, month, day, …) from the current value."""
        if not self.has_component(method):
            return None
        fmt = self.date_format or "%Y%m"
        try:
            dt = pd.to_datetime(self.value, format=fmt)
        except (ValueError, TypeError):
            return None
        return dt.strftime(self._COMPONENT_MAP[method])


# ---------------------------------------------------------------------------
# TemplateResolver
# ---------------------------------------------------------------------------

class TemplateResolver:
    """Manages declared template variables and resolves/extracts templates."""

    def __init__(self, cfg: Any, defaults: dict[str, str] | None = None):
        self.vars: dict[str, TemplateVar] = {}
        self._ctx: dict[str, str] = dict(defaults or {})
        self._load(cfg)

    def _load(self, cfg: Any) -> None:
        if not cfg.has_section("variables"):
            return
        for var_name, section_name in cfg.items("variables"):
            var_name = var_name.strip()
            section_name = section_name.strip()
            default = self._ctx.get(var_name, "")
            # If the default equals the section name, it's a mapping entry
            # (e.g. period = var_period) rather than an actual value.
            if default == section_name:
                default = ""
            if cfg.has_section(section_name):
                self.vars[var_name] = TemplateVar(
                    var_name, dict(cfg.items(section_name)), default
                )
            else:
                # No metadata section — treat as plain string variable
                self.vars[var_name] = TemplateVar(
                    var_name, {"type": "string", "mask": ".+?"}, default
                )

    # -- context sync ------------------------------------------------------

    def set(self, **values: str) -> None:
        """Update variable values (and runner context mirror)."""
        for k, v in values.items():
            self._ctx[k] = v
            if k in self.vars:
                self.vars[k].value = v

    def get(self, key: str) -> str:
        return self._ctx.get(key, "")

    # -- regex / extraction ------------------------------------------------

    def _tokenize(self, template: str) -> list[str]:
        return re.split(r"(\{[^}]+\})", template)

    def build_regex(self, template: str) -> str:
        """Convert template to regex with named groups."""
        # Resolve literal variables first (e.g. {base_path}, {file_format})
        tmpl = self._resolve_constants(template)
        parts = self._tokenize(tmpl)
        out: list[str] = []
        for part in parts:
            if part.startswith("{") and part.endswith("}"):
                inner = part[1:-1].strip()
                # strip .next / .first suffixes
                var_name = inner.split(".")[0]
                if var_name in self.vars:
                    out.append(self.vars[var_name].regex_fragment())
                else:
                    out.append(re.escape(part))
            else:
                out.append(re.escape(part))
        return "".join(out) + "$"

    def extract(self, path: str, template: str) -> dict[str, str] | None:
        """Extract variable values from a concrete file path."""
        regex = self.build_regex(template)
        m = re.match(regex, path)
        if not m:
            return None
        return m.groupdict()

    # -- resolution --------------------------------------------------------

    def resolve(self, template: str, **overrides: str) -> str:
        """Expand {var} and {var.next} placeholders."""

        def _repl(m: re.Match) -> str:
            inner = m.group(1).strip()
            if "." in inner:
                var_name, method = inner.split(".", 1)
                if method == "next" and var_name in self.vars:
                    nxt = self.vars[var_name].next()
                    if nxt is not None:
                        return nxt
                if method == "first" and var_name in self.vars:
                    return self.vars[var_name].first()
                if method == "last" and var_name in self.vars:
                    return self.vars[var_name].last()
                # Date components: {period.year}, {period.month}, {period.day}, …
                if var_name in self.vars and self.vars[var_name].has_component(method):
                    comp = self.vars[var_name].get_component(method)
                    if comp is not None:
                        return comp
                # Fallback: full dotted key in context (e.g. _defaults.branch)
                if inner in self._ctx:
                    return str(self._ctx[inner])
            else:
                if inner in overrides:
                    return str(overrides[inner])
                if inner in self.vars:
                    return self.vars[inner].value
                if inner in self._ctx:
                    return str(self._ctx[inner])
            return m.group(0)

        result = re.sub(r"\{([^}]+)\}", _repl, template)
        if "{" in result and "}" in result:
            result = re.sub(r"\{([^}]+)\}", _repl, result)
        return result

    def resolve_with(self, template: str, **overrides: str) -> str:
        """Resolve template with temporary value overrides, then restore."""
        saved: dict[str, str] = {}
        for k in overrides:
            if k in self.vars:
                saved[k] = self.vars[k].value
        self.set(**overrides)
        result = self.resolve(template)
        for k, v in saved.items():
            self.vars[k].value = v
        return result

    # -- helpers for runner ------------------------------------------------

    def resolve_section_kwargs(self, cfg: Any, section_name: str) -> dict[str, Any]:
        """Turn a config section into resolved kwargs."""
        import configparser
        if not cfg.has_section(section_name):
            raise KeyError(f"Config section '{section_name}' not found")

        kwargs: dict[str, Any] = {}
        for key, raw in cfg.items(section_name):
            key = key.strip()
            raw = raw.strip()
            if not raw:
                continue
            # Templates stay raw for now
            if key in ("file_name", "file_pattern", "file_list",
                       "output_name", "output_pattern") or key.endswith("_template"):
                kwargs[key] = raw
            elif key in ("input_template", "zeros_file"):
                # Resolve constants but preserve variable placeholders
                kwargs[key] = self._resolve_constants(raw)
            else:
                kwargs[key] = self.resolve(raw)
        return kwargs

    def _resolve_constants(self, template: str) -> str:
        """Resolve literal and undeclared variables, preserving extractable ones."""
        result = template
        for name, val in self._ctx.items():
            # Skip declared extractable variables (period, ticker, sz, etc.)
            if name in self.vars and self.vars[name]._type != "literal":
                continue
            result = result.replace(f"{{{name}}}", str(val))
        return result
