"""Unified data I/O dispatcher.

Loads and saves DataFrames from/to feather, CSV, or parquet by inspecting
the file extension.  The pipeline config stays the same regardless of the
actual file format — only the ``{file_format}`` template variable changes.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pandas import DataFrame

logger = logging.getLogger(__name__)

# Extension → (loader_module, saver_module)
_REGISTRY: dict[str, tuple[str, str | None]] = {
    ".feather": (
        "homebrewlibra.helper_feather.feather_io_helper:load_feather_trades",
        "homebrewlibra.helper_feather.feather_io_helper:save_feather_trades",
    ),
    ".csv": (
        "homebrewlibra.helper_csv.csv_io_helper:load_csv_trades",
        "homebrewlibra.helper_csv.csv_io_helper:save_csv_trades",
    ),
    ".parquet": (
        "pandas:read_parquet",
        None,  # passthrough handled below
    ),
}


def _resolve_func(dotpath: str):
    """Import ``module:func_name`` and return the callable."""
    import importlib

    mod_path, func_name = dotpath.split(":", 1)
    mod = importlib.import_module(mod_path)
    return getattr(mod, func_name)


def _ext_from_path(path: str | Path) -> str:
    """Return lower-case extension including the dot."""
    ext = Path(path).suffix.lower()
    if not ext:
        raise ValueError(f"Cannot determine file format from path: {path}")
    return ext


def load_data(input_file: str | Path | None = None, **kwargs: Any) -> DataFrame:
    """Load a DataFrame from *input_file*, inferring format from extension.

    Supported formats: ``.feather``, ``.csv``, ``.parquet``.

    Parameters
    ----------
    input_file
        Path to the data file.

    Returns
    -------
    DataFrame
    """
    if input_file is None:
        raise ValueError("input_file is required")
    path = Path(input_file).expanduser()
    ext = _ext_from_path(path)

    if ext not in _REGISTRY:
        raise ValueError(
            f"Unsupported file format '{ext}' for {path}. "
            f"Supported: {', '.join(_REGISTRY.keys())}"
        )

    loader_dotpath, _ = _REGISTRY[ext]
    loader = _resolve_func(loader_dotpath)
    logger.info("Loading %s (%s)", path, ext)
    df = loader(path)
    logger.info("Loaded %s rows from %s", len(df), path.name)
    return df


def save_data(
    ddf: DataFrame | None = None,
    output_file: str | Path | None = None,
    **kwargs: Any,
) -> DataFrame:
    """Save *ddf* to *output_file*, inferring format from extension.

    Supported formats: ``.feather``, ``.csv``, ``.parquet``.

    Parameters
    ----------
    ddf
        DataFrame to save.
    output_file
        Destination path.

    Returns
    -------
    DataFrame
        The same DataFrame (passthrough for chaining).
    """
    if ddf is None:
        raise ValueError("ddf is required")
    if output_file is None:
        raise ValueError("output_file is required")
    path = Path(output_file).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = _ext_from_path(path)

    if ext not in _REGISTRY:
        raise ValueError(
            f"Unsupported file format '{ext}' for {path}. "
            f"Supported: {', '.join(_REGISTRY.keys())}"
        )

    _, saver_dotpath = _REGISTRY[ext]
    if saver_dotpath is None:
        # Fallback for formats without a dedicated helper (e.g. parquet)
        if ext == ".parquet":
            ddf.to_parquet(path, index=False)
        else:
            raise RuntimeError(f"No saver registered for {ext}")
    else:
        saver = _resolve_func(saver_dotpath)
        saver(ddf, path)

    logger.info("Saved %s rows to %s (%s)", len(ddf), path.name, ext)
    return ddf


def load_data_to_ddf2(input_file: str | Path | None = None, **kwargs: Any) -> dict[str, DataFrame]:
    """Load a file and return ``{"ddf2": df}`` for the runner.

    Parameters
    ----------
    input_file
        Path to the data file.

    Returns
    -------
    dict[str, DataFrame]
        ``{"ddf2": loaded_df}`` — runner stores this in ``ctx["ddf2"]``.
    """
    df = load_data(input_file=input_file, **kwargs)
    return {"ddf2": df}
