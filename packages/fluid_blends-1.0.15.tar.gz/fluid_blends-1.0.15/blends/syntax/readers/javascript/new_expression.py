from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.builders.object_creation import (
    build_object_creation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    constructor_id = args.ast_graph.nodes[args.n_id]["label_field_constructor"]
    name = node_to_str(args.ast_graph, constructor_id)
    arguments_id = args.ast_graph.nodes[args.n_id].get("label_field_arguments")
    if ctx.has_feature_flag("StackGraph"):
        args.generic(args.fork_n_id(constructor_id))
    return build_object_creation_node(args, name, arguments_id, None)
