from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.query import (
    match_ast_group_d,
)
from blends.syntax.builders.export_statement import (
    build_export_statement_node,
)
from blends.syntax.builders.import_module import (
    build_import_module_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    expression = None
    export_block = graph.nodes[args.n_id].get("label_field_declaration")

    if export_block and graph.nodes[export_block]["label_type"] in {
        "identifier",
        "string",
    }:
        expression = node_to_str(args.ast_graph, export_block)
        export_block = None

    if ctx.has_feature_flag("StackGraph") and (
        source_n_id := graph.nodes[args.n_id].get("label_field_source")
    ):
        module_path = node_to_str(graph, source_n_id)[1:-1]
        for clause_id in match_ast_group_d(graph, args.n_id, "export_clause"):
            for spec_n_id in match_ast_group_d(graph, clause_id, "export_specifier"):
                name_n_id = graph.nodes[spec_n_id].get("label_field_name")
                if name_n_id is None:
                    continue
                spec_name = graph.nodes[name_n_id].get("label_text", "")
                alias_n_id = graph.nodes[spec_n_id].get("label_field_alias")
                spec_alias = (
                    graph.nodes[alias_n_id].get("label_text")
                    if alias_n_id is not None
                    else spec_name
                )
                build_import_module_node(
                    args.fork_n_id(spec_n_id),
                    expression=f"{module_path}.{spec_name}",
                    alias=spec_alias,
                    module_path=module_path,
                )

    return build_export_statement_node(args, expression, export_block)
