from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)

_SANITIZING_OPERATORS = {"!"}


def build_unary_expression_node(
    args: SyntaxGraphArgs,
    operator: str,
    operand_id: NId,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        operator=operator,
        operand_id=operand_id,
        label_type="UnaryExpression",
    )

    sanitization_stack = (
        args.metadata.get("sanitization_stack")
        if ctx.has_feature_flag("SanitizationIndex")
        else None
    )
    promote_condition = (
        sanitization_stack is not None
        and sanitization_stack
        and sanitization_stack[-1][0] == "condition_pending"
        and operator in _SANITIZING_OPERATORS
    )
    if promote_condition and sanitization_stack is not None:
        condition_parent_id = sanitization_stack[-1][1]
        sanitization_stack.append(("condition", condition_parent_id))

    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(operand_id)),
        label_ast="AST",
    )

    if promote_condition and sanitization_stack is not None:
        sanitization_stack.pop()

    return args.n_id
