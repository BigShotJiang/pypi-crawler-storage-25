from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)

_LOGICAL_OPERATORS = {"and", "&&", "or", "||"}


def build_binary_operation_node(
    args: SyntaxGraphArgs,
    operator: str,
    left_id: NId | None,
    right_id: NId | None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        operator=operator,
        label_type="BinaryOperation",
    )

    sanitization_stack = (
        args.metadata.get("sanitization_stack")
        if ctx.has_feature_flag("SanitizationIndex")
        else None
    )
    promote_condition = (
        sanitization_stack is not None
        and sanitization_stack
        and sanitization_stack[-1][0] == "condition_pending"
        and operator not in _LOGICAL_OPERATORS
    )
    if promote_condition and sanitization_stack is not None:
        condition_parent_id = sanitization_stack[-1][1]
        sanitization_stack.append(("condition", condition_parent_id))

    if left_id:
        args.syntax_graph.update_node_attribute(args.n_id, "left_id", left_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(left_id)),
            label_ast="AST",
        )

    if right_id:
        args.syntax_graph.update_node_attribute(args.n_id, "right_id", right_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(right_id)),
            label_ast="AST",
        )

    if promote_condition and sanitization_stack is not None:
        sanitization_stack.pop()

    return args.n_id
