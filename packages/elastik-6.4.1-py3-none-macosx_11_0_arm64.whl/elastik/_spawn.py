"""Spawn the bundled elastik-core Rust binary as a child process.

This is the "NumPy ships C kernels in the wheel" trick. The Rust
binary lives at `elastik/_bin/elastik-core[.exe]`, was built once on a
build machine, and is shipped as `package_data`. `elastik.start()`
launches it in a subprocess and returns a pre-bound `Elastik` client.

The user does:

    import elastik
    e = elastik.start(write_token="x")
    e.put("/home/note", "hi")
    print(e.get("/home/note"))
    elastik.stop()

...and never sees a Cargo.toml.
"""
from __future__ import annotations

import atexit
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import warnings
from pathlib import Path
from typing import Optional


_proc: Optional[subprocess.Popen] = None
_live_url: str | None = None
_live_data_dir: str | None = None
_last_live_url: str | None = None
_last_live_data_dir: str | None = None


def _load_dotenv(path: str = ".env") -> None:
    """Minimal .env loader. KEY=VALUE per line, # comments, optional
    surrounding "..." or '...' on values. Existing env vars win; .env
    only fills in what isn't already set. No interpolation, no exports,
    no shell substitution. Stdlib-only, deliberately small.
    """
    p = Path(path)
    if not p.exists():
        return
    try:
        text = p.read_text(encoding="utf-8")
    except OSError:
        return
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip()
        if not k:
            continue
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        os.environ.setdefault(k, v)
    _warn_deprecated_elastik_token()


def _warn_deprecated_elastik_token() -> None:
    if os.getenv("ELASTIK_TOKEN") and not os.getenv("ELASTIK_WRITE_TOKEN"):
        warnings.warn(
            "ELASTIK_TOKEN is deprecated; rename it to ELASTIK_WRITE_TOKEN.",
            UserWarning,
            stacklevel=3,
        )


def _env_write_token() -> str:
    token = os.getenv("ELASTIK_WRITE_TOKEN", "")
    if token:
        return token
    legacy = os.getenv("ELASTIK_TOKEN", "")
    if legacy:
        _warn_deprecated_elastik_token()
    return legacy


def _binary_path() -> Path:
    """Locate the bundled binary inside the installed package."""
    here = Path(__file__).resolve().parent / "_bin"
    name = "elastik-core.exe" if sys.platform == "win32" else "elastik-core"
    return here / name


def _wait_for_port(host: str, port: int, deadline_s: float = 10.0) -> bool:
    """Poll until the server accepts a TCP connection or we give up."""
    connect_host = _connect_host(host)
    end = time.time() + deadline_s
    while time.time() < end:
        try:
            with socket.create_connection((connect_host, port), timeout=0.3):
                return True
        except OSError:
            time.sleep(0.05)
    return False


def _connect_host(host: str) -> str:
    """Host a local client should use for follow-up probes."""
    stripped = host.strip("[]")
    if stripped in ("", "0.0.0.0"):
        return "127.0.0.1"
    if stripped == "::":
        return "::1"
    return stripped


def _url_host(host: str) -> str:
    """Format a host for an http:// URL."""
    connect_host = _connect_host(host)
    if ":" in connect_host and not connect_host.startswith("["):
        return f"[{connect_host}]"
    return connect_host


def _client_url(host: str, port: int) -> str:
    """URL a local client should use after the core binds."""
    return f"http://{_url_host(host)}:{port}"


def _port_is_free(host: str, port: int) -> bool:
    """Best-effort preflight so start() does not attach to a stranger server.

    Use a client-style connect probe instead of a bind probe. On POSIX, a
    just-stopped local server can leave enough TCP state behind for a bind()
    preflight to report "busy" even though no process is listening. What we
    need to reject is simpler: an already-accepting server on the target URL.
    """
    try:
        with socket.create_connection((_connect_host(host), port), timeout=0.2):
            return False
    except OSError:
        return True


def _probe_core(host: str, port: int, token: str = "") -> bool:
    """Confirm that the accepting socket is actually elastik-core."""
    url = f"{_client_url(host, port)}/proc/version"
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=2) as r:
            body = r.read(128)
            return r.status == 200 and body.startswith(b"elastik-core ")
    except (OSError, urllib.error.URLError):
        return False


def _token_state(read_token: str, write_token: str, approve_token: str) -> str:
    return "\n".join(
        [
            "auth:",
            "  read:    "
            + (
                "token required"
                if read_token
                else "public (ELASTIK_READ_TOKEN not set)"
            ),
            "  write:   "
            + (
                "token required"
                if write_token
                else "disabled (ELASTIK_WRITE_TOKEN not set)"
            ),
            "  approve: "
            + (
                "token required"
                if approve_token
                else "disabled (ELASTIK_APPROVE_TOKEN not set)"
            ),
        ]
    )


def _warn_token_state(read_token: str, write_token: str, approve_token: str) -> None:
    if read_token and write_token and approve_token:
        return
    print(_token_state(read_token, write_token, approve_token), file=sys.stderr, flush=True)
    if not write_token:
        print(
            "warning: ELASTIK_WRITE_TOKEN not set; ordinary PUT/POST are disabled.",
            file=sys.stderr,
            flush=True,
        )
    if not approve_token:
        print(
            "warning: ELASTIK_APPROVE_TOKEN not set; DELETE and system writes are disabled.",
            file=sys.stderr,
            flush=True,
        )


def start(
    port: int | None = None,
    host: str | None = None,
    key: str | None = None,
    read_token: str | None = None,
    write_token: str | None = None,
    approve_token: str | None = None,
    data_dir: Optional[str] = None,
    quiet: bool = True,
    debug: bool | str = False,
):
    """Launch the bundled elastik-core. Returns a pre-bound Elastik client.

    All process state is the user's: port, key, tokens, data dir. `key` is
    required, either as an argument, in ELASTIK_KEY, or in .env. Token
    arguments are optional capability gates: no read_token means public reads,
    no write_token means ordinary writes are disabled, and no approve_token means
    delete/system writes are disabled. `debug=True` enables the returned
    client's SDK-side /tmp/debug request sink; it does not change core behavior.
    """
    global _proc, _live_url, _live_data_dir, _last_live_url, _last_live_data_dir
    if _proc is not None and _proc.poll() is None:
        raise RuntimeError(
            "elastik already running in this process; call elastik.stop() first"
        )

    host = host or os.getenv("ELASTIK_HOST", "127.0.0.1")
    if port is None:
        port = int(os.getenv("ELASTIK_PORT", "3105"))
    # ELASTIK_KEY: no constant default. The audit chain HMAC computed
    # against a publicly-known key is meaningless: anyone could forge
    # events. Caller passes `key=...`, the env provides ELASTIK_KEY,
    # or .env (already loaded by `import elastik`) supplies it.
    # Validate before checking the binary: a missing key is a config
    # error the user can fix; a missing binary is an install error.
    key = key or os.getenv("ELASTIK_KEY")
    if not key:
        raise RuntimeError(
            "ELASTIK_KEY required: set it in .env, export it in the shell, "
            "or pass key=... to elastik.start().\n"
            "Generate one with: "
            "python -c \"import secrets; print(secrets.token_hex(32))\""
        )

    binary = _binary_path()
    if not binary.exists():
        raise RuntimeError(
            f"bundled binary not found: {binary}\n"
            "If you're working from source, build and bundle it from the repo root:\n"
            "  cargo build --release --manifest-path core/Cargo.toml\n"
            "  mkdir -p sdk/src/elastik/_bin\n"
            "  cp core/target/release/elastik-core* sdk/src/elastik/_bin/\n"
            f"Expected binary directory: {binary.parent}"
        )
    if not _port_is_free(host, port):
        raise RuntimeError(f"port already in use before elastik start: {host}:{port}")
    read_token = (
        os.getenv("ELASTIK_READ_TOKEN", "") if read_token is None else read_token
    )
    write_token = _env_write_token() if write_token is None else write_token
    approve_token = (
        os.getenv("ELASTIK_APPROVE_TOKEN", "")
        if approve_token is None else approve_token
    )
    data_dir = data_dir if data_dir is not None else os.getenv("ELASTIK_DATA")

    env = os.environ.copy()
    env["ELASTIK_HOST"] = host
    env["ELASTIK_PORT"] = str(port)
    env["ELASTIK_KEY"] = key
    if read_token:
        env["ELASTIK_READ_TOKEN"] = read_token
    else:
        env.pop("ELASTIK_READ_TOKEN", None)
    if write_token:
        env["ELASTIK_WRITE_TOKEN"] = write_token
    else:
        env.pop("ELASTIK_WRITE_TOKEN", None)
    if approve_token:
        env["ELASTIK_APPROVE_TOKEN"] = approve_token
    else:
        env.pop("ELASTIK_APPROVE_TOKEN", None)
    if data_dir:
        env["ELASTIK_DATA"] = str(data_dir)
    else:
        env.pop("ELASTIK_DATA", None)

    out = subprocess.DEVNULL if quiet else None
    _proc = subprocess.Popen([str(binary)], env=env, stdout=out, stderr=out)
    atexit.register(stop)

    if not _wait_for_port(host, port):
        stop()
        raise RuntimeError(
            f"elastik-core failed to start on {host}:{port} within 10s"
        )
    if _proc is None or _proc.poll() is not None:
        code = None if _proc is None else _proc.returncode
        stop()
        raise RuntimeError(f"elastik-core exited during startup (code={code})")
    probe_token = approve_token or write_token or read_token
    if not _probe_core(host, port, probe_token):
        stop()
        raise RuntimeError(f"port {host}:{port} did not answer as elastik-core")
    if not quiet:
        _warn_token_state(read_token, write_token, approve_token)

    # Re-import here to dodge a circular import at module load
    from elastik.sdk import Elastik

    _live_url = _client_url(host, port)
    _live_data_dir = str(data_dir) if data_dir else None
    _last_live_url = _live_url
    _last_live_data_dir = _live_data_dir
    return Elastik(
        _live_url,
        bearer_token=approve_token or write_token or read_token,
        debug=debug,
    )


def stop() -> None:
    """Kill the launched binary, if any. Safe to call multiple times."""
    global _proc, _live_url, _live_data_dir
    if _proc is None:
        return
    try:
        _proc.terminate()
        try:
            _proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _proc.kill()
            _proc.wait(timeout=2)
    except OSError:
        pass
    _proc = None
    _live_url = None
    _live_data_dir = None


def is_running() -> bool:
    return _proc is not None and _proc.poll() is None


def live_info() -> dict[str, str]:
    """Runtime details for the child started by this Python process."""
    out = {}
    if is_running():
        if _live_url:
            out["url"] = _live_url
        if _live_data_dir:
            out["data_dir"] = _live_data_dir
        out["state"] = "running"
    elif _last_live_url:
        out["url"] = _last_live_url
        if _last_live_data_dir:
            out["data_dir"] = _last_live_data_dir
        out["state"] = "stopped"
    return out


def default_url() -> str:
    """Where the module-level `elastik.put`/`elastik.get` calls land by
    default. Override with `ELASTIK_URL`. Otherwise derive the Rust core
    URL from `ELASTIK_HOST` + `ELASTIK_PORT`."""
    explicit = os.getenv("ELASTIK_URL")
    if explicit:
        return explicit
    host = os.getenv("ELASTIK_HOST", "127.0.0.1")
    port = int(os.getenv("ELASTIK_PORT", "3105"))
    return _client_url(host, port)


def binary_info() -> dict:
    """Where is the bundled binary? How big? Does it exist? Useful
    for `python -m elastik` debugging."""
    p = _binary_path()
    return {
        "path": str(p),
        "exists": p.exists(),
        "size_bytes": p.stat().st_size if p.exists() else None,
        "platform": sys.platform,
    }
