import logging
import uuid
from typing import AsyncGenerator, Optional, Dict, Any

from ag_ui.core import (
    EventType,
    RunAgentInput,
    RunStartedEvent,
    RunFinishedEvent,
    RunErrorEvent,
    RawEvent,
    TextMessageStartEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    ToolCallStartEvent,
    ToolCallArgsEvent,
    ToolCallEndEvent,
    StateSnapshotEvent,
    StepStartedEvent,
    StepFinishedEvent,
)

logger = logging.getLogger(__name__)


def _unpack_stream_chunk(chunk) -> tuple[str | None, Any]:
    """Unpack a LangGraph SDK stream chunk into (stream_mode, data).

    LangGraph SDK streams return chunks as list/tuple: [stream_mode, data, ...]
    where stream_mode is one of: "messages", "events", "values", "metadata".

    Some older SDK versions return dict or object-style chunks.
    """
    if isinstance(chunk, (list, tuple)) and len(chunk) >= 2:
        return str(chunk[0]), chunk[1]
    if isinstance(chunk, dict):
        return chunk.get("event"), chunk.get("data")
    # Object-style (older SDK)
    return getattr(chunk, "event", None), getattr(chunk, "data", None)


def _extract_text_from_content(content) -> str:
    """Extract plain text from an AIMessageChunk content field.

    Content can be:
    - A string (simple case)
    - A list of blocks: [{"type": "text", "text": "...", "index": N}, ...]
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "".join(parts)
    return ""


class AGUILangGraphClient:
    """AG-UI Agent that connects to a LangGraph server via langgraph-sdk."""

    def __init__(
        self,
        langgraph_client,
        assistant_id: str,
        name: str = "LangGraphServerAgent",
        description: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        self.client = langgraph_client
        self.assistant_id = assistant_id
        self.name = name
        self.description = description
        self.config = config

    def clone(self):
        """Clone method to satisfy middleware expectations."""
        return AGUILangGraphClient(
            langgraph_client=self.client,
            assistant_id=self.assistant_id,
            name=self.name,
            description=self.description,
            config=self.config,
        )

    def _dispatch_event(self, event):
        return event

    async def run(self, input: RunAgentInput) -> AsyncGenerator[str, None]:
        thread_id = input.thread_id
        run_id = input.run_id or str(uuid.uuid4())

        if not thread_id:
            logger.warning(
                "AGUILangGraphClient requires a thread_id to join streams properly. "
                "Starting a fresh thread."
            )
            thread = await self.client.threads.create()
            thread_id = thread["thread_id"]

        # Check if there is an active run on this thread to rejoin
        active_runs = await self.client.runs.list(thread_id=thread_id, status="running")
        pending_runs = await self.client.runs.list(thread_id=thread_id, status="pending")
        all_active = active_runs + pending_runs
        active_run = all_active[0] if all_active else None

        yield self._dispatch_event(
            RunStartedEvent(
                type=EventType.RUN_STARTED,
                thread_id=thread_id,
                run_id=run_id,
            )
        )

        # Track text streaming state per message_id so we emit START/END correctly.
        active_text_messages: dict[str, str] = {}
        open_text_message_ids: list[str] = []

        # Track open steps for STEP_STARTED/STEP_FINISHED pairing.
        open_steps: list[str] = []
        # Names of steps that are currently active (to detect duplicates from subgraphs).
        active_step_names: set[str] = set()
        # run_ids of on_chain_start events we skipped (nested duplicate step names).
        # The matching on_chain_end must also be skipped to keep the stack balanced.
        skipped_step_run_ids: set[str] = set()

        try:
            if active_run:
                logger.info("Joining active stream for run %s", active_run["run_id"])
                stream = self.client.runs.join_stream(
                    thread_id=thread_id,
                    run_id=active_run["run_id"],
                    stream_mode=["messages", "values", "events"],
                )
            else:
                logger.info("Starting new stream for run %s", run_id)

                # Accurately map AG-UI Message types to LangGraph dicts
                messages = []
                if input.messages:
                    for msg in input.messages:
                        msg_dict = {"role": msg.role, "content": msg.content}
                        if hasattr(msg, "id") and msg.id:
                            msg_dict["id"] = msg.id

                        # Handle tool calls attached to Assistant messages
                        if msg.role == "assistant" and getattr(msg, "tool_calls", None):
                            msg_dict["tool_calls"] = [
                                {
                                    "name": tc.function.name,
                                    "args": tc.function.arguments, # Ensure string or parsed dict based on your AG-UI version
                                    "id": tc.id
                                } for tc in msg.tool_calls
                            ]

                        # Handle tool response messages
                        elif msg.role == "tool":
                            msg_dict["tool_call_id"] = getattr(msg, "tool_call_id", "")

                        messages.append(msg_dict)

                payload = {"messages": messages} if messages else None

                stream = self.client.runs.stream(
                    thread_id=thread_id,
                    assistant_id=self.assistant_id,
                    input=payload,
                    config=self.config,
                    stream_mode=["messages", "values", "events"],
                    on_disconnect="continue",
                )

            async for chunk in stream:
                stream_mode, data = _unpack_stream_chunk(chunk)

                # Always forward as RAW so the frontend can inspect all events.
                yield self._dispatch_event(RawEvent(type=EventType.RAW, event=chunk))

                # ----------------------------------------------------------------
                # Error
                # ----------------------------------------------------------------
                if stream_mode == "error":
                    msg = (
                        data.get("message", "Unknown LangGraph Server Error")
                        if isinstance(data, dict)
                        else "Unknown Error"
                    )
                    yield self._dispatch_event(
                        RunErrorEvent(type=EventType.RUN_ERROR, message=str(msg))
                    )
                    break

                # ----------------------------------------------------------------
                # Messages mode → TEXT_MESSAGE_* events
                # ----------------------------------------------------------------
                elif stream_mode in ("messages", "messages/partial"):
                    pass # We now rely on on_chat_model_stream for true token-by-token deltas

                # ----------------------------------------------------------------
                # Events mode → STEP_STARTED / STEP_FINISHED / TEXT_MESSAGE_*
                # ----------------------------------------------------------------
                elif stream_mode == "events":
                    if not isinstance(data, dict):
                        continue

                    event_name = data.get("event", "")
                    node_name = data.get("name", "")
                    tags = data.get("tags") or []
                    event_data = data.get("data", {})

                    # 1. Handle actual LLM token streaming
                    if event_name == "on_chat_model_stream":
                        chunk = event_data.get("chunk") or {}
                        
                        msg_id = None
                        if isinstance(chunk, dict):
                            msg_id = chunk.get("id")
                            content = chunk.get("content", [])
                        else:
                            msg_id = getattr(chunk, "id", None)
                            content = getattr(chunk, "content", [])

                        if not msg_id:
                            msg_id = str(uuid.uuid4())
                            
                        # LangGraph's on_chat_model_stream can contain full accumulated chunks or deltas depending on the model.
                        # We must slice it exactly like we did for messages/partial.
                        msg_type = chunk.get("type", "") if isinstance(chunk, dict) else getattr(chunk, "type", "")
                        if msg_type not in ("AIMessageChunk", "ai"):
                            continue
                            
                        text = _extract_text_from_content(content)
                        if text:
                            # Emit START the first time we see this message_id
                            if msg_id not in active_text_messages:
                                active_text_messages[msg_id] = ""
                                open_text_message_ids.append(msg_id)
                                yield self._dispatch_event(
                                    TextMessageStartEvent(
                                        type=EventType.TEXT_MESSAGE_START,
                                        message_id=msg_id,
                                        role="assistant",
                                    )
                                )

                            emitted_text = active_text_messages[msg_id]
                            if len(text) > len(emitted_text):
                                delta_text = text[len(emitted_text):]
                                active_text_messages[msg_id] = text

                                yield self._dispatch_event(
                                    TextMessageContentEvent(
                                        type=EventType.TEXT_MESSAGE_CONTENT,
                                        message_id=msg_id,
                                        delta=delta_text,  # Emits only the incremental difference
                                    )
                                )
                        continue

                    # 2. Handle step events for graph nodes (tagged graph:step:N)
                    is_graph_step = any(
                        isinstance(t, str) and t.startswith("graph:step:")
                        for t in tags
                    )
                    if not is_graph_step:
                        continue

                    event_run_id = data.get("run_id", "")

                    if event_name == "on_chain_start":
                        step_name = node_name or "step"
                        if step_name in active_step_names:
                            # Step already active — this is a nested subgraph node with
                            # the same name (e.g. an inner graph invoked from within an
                            # outer node of the same name). Skip it to avoid a duplicate
                            # STEP_STARTED; record the run_id so the matching
                            # on_chain_end is also skipped, keeping the stack balanced.
                            if event_run_id:
                                skipped_step_run_ids.add(event_run_id)
                        else:
                            active_step_names.add(step_name)
                            open_steps.append(step_name)
                            yield self._dispatch_event(
                                StepStartedEvent(
                                    type=EventType.STEP_STARTED,
                                    step_name=step_name,
                                )
                            )
                    elif event_name == "on_chain_end":
                        if event_run_id and event_run_id in skipped_step_run_ids:
                            # Matches a skipped start — discard without emitting.
                            skipped_step_run_ids.discard(event_run_id)
                        else:
                            step_name = open_steps.pop() if open_steps else (node_name or "step")
                            active_step_names.discard(step_name)
                            yield self._dispatch_event(
                                StepFinishedEvent(
                                    type=EventType.STEP_FINISHED,
                                    step_name=step_name,
                                )
                            )

                # ----------------------------------------------------------------
                # Values mode → STATE_SNAPSHOT
                # ----------------------------------------------------------------
                elif stream_mode == "values":
                    yield self._dispatch_event(
                        StateSnapshotEvent(
                            type=EventType.STATE_SNAPSHOT,
                            snapshot=data,
                        )
                    )

        except Exception as e:
            logger.error("Stream error: %s", e, exc_info=True)
            yield self._dispatch_event(
                RunErrorEvent(
                    type=EventType.RUN_ERROR,
                    message=f"Agent exception: {str(e)}",
                )
            )

        # Close any open text message streams
        for message_id in open_text_message_ids:
            yield self._dispatch_event(
                TextMessageEndEvent(
                    type=EventType.TEXT_MESSAGE_END,
                    message_id=message_id,
                )
            )

        yield self._dispatch_event(
            RunFinishedEvent(
                type=EventType.RUN_FINISHED,
                thread_id=thread_id,
                run_id=run_id,
            )
        )
