from langgraph_sdk._shared.utilities import _sse_to_v2_dict
import json

v1_event = "messages"
v1_data = json.dumps([{"id": "1", "content":"hello", "type":"AIMessageChunk"}, {"run_id": "r-123"}])

print("V2 equivalent:", _sse_to_v2_dict(v1_event, v1_data))