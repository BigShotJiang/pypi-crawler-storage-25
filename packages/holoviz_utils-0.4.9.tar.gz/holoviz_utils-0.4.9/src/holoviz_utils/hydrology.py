from calendar import monthrange
from collections import deque
import numpy as np
import pandas as pd

TERMINAL = {-888, -999}


def _period_days(dt):
    """Return the number of days in the dekadal period starting at *dt*.

    Day 1 or 11 → 10 days; day 21 → remaining days in the month.
    """
    day = dt.day
    if day in (1, 11):
        return 10
    if day == 21:
        return monthrange(dt.year, dt.month)[1] - 20
    raise ValueError(f"Unexpected start day {day} in {dt}")


def _topo_sort(routes, basin_ids):
    """Topological sort of basin_ids so upstream basins come first."""
    # Build upstream -> downstream edges, filtered to basins in df
    id_set = set(basin_ids)
    # routes keys are strings, values are ints
    downstream = {}
    upstream_of = {bid: [] for bid in id_set}
    in_degree = {bid: 0 for bid in id_set}

    for src_str, val in routes.items():
        src = int(src_str)
        if src not in id_set:
            continue
        dst = val[0]
        if dst in TERMINAL or dst not in id_set:
            downstream[src] = None
        else:
            downstream[src] = dst
            upstream_of[dst].append(src)
            in_degree[dst] += 1

    # Kahn's algorithm
    queue = deque(bid for bid, deg in in_degree.items() if deg == 0)
    order = []
    while queue:
        bid = queue.popleft()
        order.append(bid)
        ds = downstream.get(bid)
        if ds is not None:
            in_degree[ds] -= 1
            if in_degree[ds] == 0:
                queue.append(ds)

    if len(order) != len(id_set):
        missing = id_set - set(order)
        raise ValueError(f"Cycle detected or disconnected basins: {missing}")

    return order, upstream_of


def calc_runoff(df, routes, f_values=None, output="mixed_flux", spinup=2):
    """Calculate routed runoff using a linear reservoir model.

    Parameters
    ----------
    df : DataFrame
        Must have columns: SDG6_SB_ID, start_datetime, AETI (mm/day), PCP (mm/day).
    routes : dict
        Mapping basin_id (str) -> [downstream_id, area_km2] or downstream_id (int).
        -888/-999 = terminal basin.
    f_values : dict, optional
        Response factor per basin_id (int). Defaults to 0.1 for all.
    output : {"volume", "volume_flux", "depth", "depth_flux", "mixed", "mixed_flux"}, optional
        Controls output units (default "volume").
        - "volume": PCP, AETI, Q, ΔS, S in m³.
        - "volume_flux": PCP, AETI, Q, ΔS in m³/s; S in m³.
        - "depth": PCP, AETI, Q, ΔS, S in mm.
        - "depth_flux": PCP, AETI, Q, ΔS in mm/day; S in mm.
        - "mixed": PCP, AETI in mm; Q, ΔS, S in m³.
        - "mixed_flux": PCP, AETI in mm/day; Q, ΔS in m³/s; S in m³.
    spinup : int, optional
        Number of model passes (default 1). spinup=1 is identical to the
        previous behaviour (initial storage = 0 for all basins). For spinup > 1,
        the model runs spinup-1 warmup passes on data from the start date up to
        (but not including) the same calendar date in the final year of the
        dataset; each basin's storage at that cutoff seeds the next pass.
        The last pass always covers the full dataset.

    Returns
    -------
    DataFrame
        Input df with added columns depending on *output* mode.
    """
    df = df.sort_values(["SDG6_SB_ID", "start_datetime"]).reset_index(drop=True)

    if df.empty:
        for col in ("Q", "ΔS", "S"):
            df[col] = np.float64()
        return df

    basin_ids = df["SDG6_SB_ID"].unique()
    default_f = 0.1

    # Extract areas from routes (km² -> m²)
    areas = {}
    for src_str, val in routes.items():
        if isinstance(val, list) and len(val) >= 2:
            areas[int(src_str)] = val[1] * 1e6  # km² to m²

    if f_values is None:
        f_values = {}

    # Compute period length (days) for each row from start_datetime
    df["_period_days"] = df["start_datetime"].apply(_period_days)

    order, upstream_of = _topo_sort(routes, basin_ids)

    # Restrict to dates present in ALL basins (intersection of per-basin date ranges)
    if len(basin_ids) > 1:
        common_start = df.groupby("SDG6_SB_ID")["start_datetime"].min().max()
        common_end = df.groupby("SDG6_SB_ID")["start_datetime"].max().min()
        df = df[
            (df["start_datetime"] >= common_start) & (df["start_datetime"] <= common_end)
        ].reset_index(drop=True)

    # Unit conversion: mm/day → m³ per period (done once, before any spinup pass)
    for bid in order:
        mask = df["SDG6_SB_ID"] == bid
        idx = df.index[mask]
        area = areas.get(bid, 1e6)
        period_days = df.loc[idx, "_period_days"].values
        df.loc[idx, "PCP"] = df.loc[idx, "PCP"].values * period_days * area / 1e3
        df.loc[idx, "AETI"] = df.loc[idx, "AETI"].values * period_days * area / 1e3

    # Warmup cutoff: same calendar date as the first timestep, but in the last year
    # that still contains that date (e.g. first=2015-11-05, last=2021-05-01 →
    # 2021-11-05 doesn't exist in data, so step back to 2020-11-05).
    first_date = df["start_datetime"].min()
    last_date = df["start_datetime"].max()
    target_year = last_date.year
    while True:
        try:
            cutoff_date = first_date.replace(year=target_year)
        except ValueError:
            # first_date is Feb-29; fall back to Feb-28 in target year
            cutoff_date = first_date.replace(year=target_year, day=28)
        if cutoff_date <= last_date:
            break
        target_year -= 1
        if target_year < first_date.year:
            # Dataset spans less than one cycle; no warmup possible
            cutoff_date = first_date
            break
    warmup_mask = df["start_datetime"] < cutoff_date

    s0 = {}  # basin_id -> initial storage (m³) for the next pass; empty = 0 for all

    for spin_i in range(spinup):
        is_warmup = spin_i < spinup - 1

        df["QIN"] = 0.0
        df["Storage"] = 0.0
        df["Q"] = 0.0

        for bid in order:
            bid_mask = df["SDG6_SB_ID"] == bid
            idx = df.index[bid_mask & warmup_mask] if is_warmup else df.index[bid_mask]
            if len(idx) == 0:
                continue

            f = f_values.get(bid, default_f)

            # Qin: sum of upstream Qout per time step (m³ per period)
            ups = upstream_of[bid]
            if ups:
                up_mask = df["SDG6_SB_ID"].isin(ups)
                qin_series = df.loc[up_mask].groupby("start_datetime")["Q"].sum()
                qin = df.loc[idx, "start_datetime"].map(qin_series).fillna(0.0).values
            else:
                qin = 0.0

            # Net water input for this period (m³): inflow + precipitation - evapotranspiration
            balance = qin + df.loc[idx, "PCP"].values - df.loc[idx, "AETI"].values

            # Exact analytical solution of dS/dt = R - k*S over each period,
            # where R = balance/dt (m³/day) and k = f/10 (1/day).
            # This removes period-length artifacts: both steady-state storage
            # and average outflow flux are independent of dekad length.
            n = len(idx)
            storage = np.zeros(n, dtype="float64")
            qout = np.zeros(n, dtype="float64")
            period_days_arr = df.loc[idx, "_period_days"].values
            k = f / 10.0  # per-day drainage rate

            for t in range(n):
                s_prev = s0.get(bid, 0.0) if t == 0 else storage[t - 1]
                dt = period_days_arr[t]
                R = balance[t] / dt  # average daily net input (m³/day)
                if k > 0:
                    ekdt = np.exp(-k * dt)
                    s_end = s_prev * ekdt + (R / k) * (1.0 - ekdt)
                else:
                    s_end = s_prev + balance[t]
                s_end = max(0.0, s_end)
                storage[t] = s_end
                qout[t] = max(0.0, s_prev + balance[t] - s_end)

            df.loc[idx, "QIN"] = qin
            df.loc[idx, "Storage"] = storage
            df.loc[idx, "Q"] = qout

        # After each warmup pass, capture each basin's final storage for the next pass
        if is_warmup:
            s0 = {}
            for bid in order:
                warmup_idx = df.index[(df["SDG6_SB_ID"] == bid) & warmup_mask]
                if len(warmup_idx) > 0:
                    s0[bid] = df.loc[warmup_idx[-1], "Storage"]

    if output == "volume":
        # ΔS from water balance (m³); S in m³
        df["ΔS"] = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
    elif output == "volume_flux":
        period_s = df["_period_days"].values * 86400
        # ΔS from water balance (m³ → m³/s); S stays in m³
        delta_s = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
        df["PCP"] = df["PCP"].values / period_s
        df["AETI"] = df["AETI"].values / period_s
        df["Q"] = df["Q"].values / period_s
        df["ΔS"] = delta_s / period_s
    elif output == "depth":
        # m³ → mm: value_m3 / area_m2 * 1000; S in mm
        area_per_row = df["SDG6_SB_ID"].map(areas).values
        # ΔS from water balance (m³ → mm)
        delta_s = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
        for col in ("PCP", "AETI", "Q"):
            df[col] = df[col].values / area_per_row * 1e3
        df["ΔS"] = delta_s / area_per_row * 1e3
        df["Storage"] = df["Storage"].values / area_per_row * 1e3
    elif output == "depth_flux":
        # m³ → mm/day: value_m3 / area_m2 * 1000 / period_days; S in mm
        area_per_row = df["SDG6_SB_ID"].map(areas).values
        period_days = df["_period_days"].values
        # ΔS from water balance (m³ → mm/day)
        delta_s = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
        for col in ("PCP", "AETI", "Q"):
            df[col] = df[col].values / area_per_row * 1e3 / period_days
        df["ΔS"] = delta_s / area_per_row * 1e3 / period_days
        df["Storage"] = df["Storage"].values / area_per_row * 1e3
    elif output == "mixed":
        # PCP, AETI: m³ → mm; Q, ΔS, S remain in m³
        area_per_row = df["SDG6_SB_ID"].map(areas).values
        # ΔS from water balance (m³)
        delta_s = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
        for col in ("PCP", "AETI"):
            df[col] = df[col].values / area_per_row * 1e3
        df["ΔS"] = delta_s
    elif output == "mixed_flux":
        # PCP, AETI: m³ → mm/day; Q: m³ → m³/s; ΔS: m³ → m³/s; S stays in m³
        area_per_row = df["SDG6_SB_ID"].map(areas).values
        period_days = df["_period_days"].values
        period_s = period_days * 86400
        # ΔS from water balance (m³ → m³/s)
        delta_s = df["QIN"].values + df["PCP"].values - df["AETI"].values - df["Q"].values
        for col in ("PCP", "AETI"):
            df[col] = df[col].values / area_per_row * 1e3 / period_days
        df["Q"] = df["Q"].values / period_s
        df["ΔS"] = delta_s / period_s

    df.rename(columns={"Storage": "S"}, inplace=True)

    df.drop(columns=["_period_days", "QIN"], inplace=True)
    return df


if __name__ == "__main__":

    import json
    from pathlib import Path
    from holoviz_utils.hydrology import calc_runoff

    _routes = json.loads(
        Path(
            "/Users/hmcoerver/Library/Mobile Documents/com~apple~CloudDocs/Repositories/holoviz-utils/projects/wapor_discharge/fao_sb_ids.json"
        ).read_text()
    )

    df_in = pd.read_pickle(
        "/Users/hmcoerver/Library/Mobile Documents/com~apple~CloudDocs/Repositories/holoviz-utils/in_progress/runoff_routing/test_data.pickle"
    )

    df = calc_runoff(df_in, _routes)
