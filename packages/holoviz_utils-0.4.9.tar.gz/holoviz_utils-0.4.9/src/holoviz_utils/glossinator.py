import param
import panel as pn
import re
import markdown as _md
import requests
from html import unescape as _html_unescape
from urllib.parse import unquote


class Glossinator(param.Parameterized):

    glossary = param.Dict(default={}, constant=True, doc="A dictionary mapping terms to their tooltip content (HTML allowed).")

    markdown = param.String(default="", allow_refs=True, doc="Markdown text to display with glossary tooltips.")

    html = param.String(default="", doc="HTML content to display with glossary tooltips")
    html_pane = param.ClassSelector(class_=pn.pane.HTML, default=None, doc="The HTML pane displaying the glossary content.")

    tooltip_background_color = param.Color(default="#2d2d2d", doc="Tooltip background color.")
    tooltip_background_opacity = param.Integer(default=100, bounds=(0, 100), doc="Tooltip background opacity (0–100).")
    tooltip_text_color = param.Color(default="#f0f0f0", doc="Tooltip text color.")
    tooltip_max_width = param.Integer(default=280, bounds=(50, None), doc="Max tooltip width in pixels.")
    tooltip_border_radius = param.Integer(default=6, bounds=(0, None), doc="Tooltip border radius in pixels.")

    def __init__(self, **params):
        super().__init__(**params)
        self._resolved_glossary = self._resolve_glossary()
        self.param.watch(self._apply_glossary, ["markdown"])
        self.param.watch(self.make_pane, ["html"])
        self._apply_glossary(None)

    def _resolve_glossary(self) -> dict:
        """Return glossary with Wikipedia/Copernicus URLs replaced by fetched tooltip HTML."""
        resolved = {}
        _wiki_re = re.compile(r'https?://[a-z-]+\.wikipedia\.org/wiki/.+')
        _copernicus_re = re.compile(r'https?://[\w.-]+\.copernicus\.org/articles/.+')
        for term, value in self.glossary.items():
            if _wiki_re.match(value):
                try:
                    resolved[term] = Glossinator.wikipedia_tooltip(value)
                except Exception:
                    resolved[term] = f'<a href="{value}" target="_blank">{value}</a>'
            elif _copernicus_re.match(value):
                try:
                    resolved[term] = Glossinator.copernicus_tooltip(value)
                except Exception:
                    resolved[term] = f'<a href="{value}" target="_blank">{value}</a>'
            else:
                resolved[term] = value
        return resolved

    def _apply_glossary(self, event) -> str:
        """Convert markdown text to HTML and wrap glossary key occurrences in tooltip spans."""
        
        html = _md.markdown(self.markdown, extensions=["extra"])
        if not self.glossary:
            self.param.update(html=html)
            return
        # Build the overlay's inline style from params so no shadow-DOM CSS is needed.
        r_bg = int(self.tooltip_background_color[1:3], 16)
        g_bg = int(self.tooltip_background_color[3:5], 16)
        b_bg = int(self.tooltip_background_color[5:7], 16)
        bg_opacity = self.tooltip_background_opacity / 100
        overlay_style = (
            f"position:fixed;padding:8px 12px;"
            f"border-radius:{self.tooltip_border_radius}px;"
            f"font-size:0.85em;max-width:{self.tooltip_max_width}px;width:max-content;"
            f"background:rgba({r_bg},{g_bg},{b_bg},{bg_opacity});"
            f"color:{self.tooltip_text_color};"
            "z-index:99999;box-shadow:0 2px 8px rgba(0,0,0,0.3);"
            "line-height:1.5;white-space:normal;overflow-wrap:break-word;"
            "pointer-events:auto;top:0;left:0;"
            "visibility:hidden;opacity:0;transition:opacity 0.15s;"
        )
        # Portal approach: move overlay to document.body to escape shadow-DOM
        # overflow/containment clipping entirely.
        # Mouseenter cancels any pending hide timer so the cursor can move
        # from the term into the overlay and click links.
        enter_js = (
            "(function(term){"
            "if(window._hvGlsTimer){clearTimeout(window._hvGlsTimer);window._hvGlsTimer=null;}"
            "var ov=document.getElementById('hv-gls-ov');"
            "if(!ov){"
            "ov=document.createElement('div');ov.id='hv-gls-ov';document.body.appendChild(ov);"
            "ov.addEventListener('mouseenter',function(){if(window._hvGlsTimer){clearTimeout(window._hvGlsTimer);window._hvGlsTimer=null;}});"
            "ov.addEventListener('mouseleave',function(){window._hvGlsTimer=setTimeout(function(){ov.style.visibility='hidden';ov.style.opacity='0';},150);});"
            "}"
            "ov.setAttribute('style','" + overlay_style + "');"
            "var c=term.querySelector('.hv-gls-c');"
            "ov.innerHTML=c?c.innerHTML:'';"
            "ov.style.fontFamily=window.getComputedStyle(term).fontFamily;"
            "ov.style.visibility='visible';ov.style.opacity='1';"
            "var tr=term.getBoundingClientRect();"
            "var tw=ov.offsetWidth,th=ov.offsetHeight;"
            "var left=tr.left+tr.width/2-tw/2;"
            "var top=tr.top-th-4;"
            "if(left+tw>window.innerWidth-8)left=window.innerWidth-tw-8;"
            "if(left<8)left=8;"
            "if(top<8)top=tr.bottom+4;"
            "ov.style.left=left+'px';ov.style.top=top+'px';"
            "})(this)"
        )
        leave_js = (
            "window._hvGlsTimer=setTimeout(function(){"
            "var ov=document.getElementById('hv-gls-ov');"
            "if(ov){ov.style.visibility='hidden';ov.style.opacity='0';}"
            "},150);"
        )

        sorted_terms = sorted(self.glossary.keys(), key=len, reverse=True)
        combined_pattern = '|'.join(re.escape(t) for t in sorted_terms)
        lower_to_tip = {t.lower(): self._resolved_glossary[t] for t in sorted_terms}

        def replacer(m, _enter=enter_js, _leave=leave_js, _tips=lower_to_tip):
            matched = m.group(0)
            tip = _tips[matched.lower()]
            return (
                f'<span class="hv-glossary-term" onmouseenter="{_enter}" onmouseleave="{_leave}">{matched}'
                f'<span class="hv-gls-c" style="display:none">{tip}</span></span>'
            )

        # Split on HTML tags; even-index parts are text nodes, odd-index are tags
        parts = re.split(r'(<[^>]+>)', html)
        for idx, part in enumerate(parts):
            if idx % 2 == 1:
                continue  # skip HTML tags
            parts[idx] = re.sub(combined_pattern, replacer, part, flags=re.IGNORECASE)
        self.param.update(html=''.join(parts))

    def _build_css(self) -> str:
        return """
.hv-glossary-term {
    position: relative;
    display: inline-block;
    text-decoration: underline dotted;
    cursor: help;
}
"""

    def make_pane(self, event):
        if self.html_pane is None:
            self.param.update(html_pane=pn.pane.HTML(
                self.html,
                align="center",
                sizing_mode="stretch_both",
                styles={"font-size": "medium"},
                stylesheets=[self._build_css()],
            ))
        else:
            self.html_pane.object = self.html

    @staticmethod
    def _clean_wikitext(text: str) -> str:
        """Strip wikitext markup to plain text."""
        # Remove <ref>...</ref> and self-closing <ref ... />
        text = re.sub(r'<ref[^>]*>.*?</ref>', '', text, flags=re.DOTALL)
        text = re.sub(r'<ref[^/]*/>', '', text)
        # Remove {{efn|...}} (footnotes) — handle nested braces
        while '{{efn' in text.lower():
            start = text.lower().find('{{efn')
            if start == -1:
                break
            depth, i = 0, start
            while i < len(text):
                if text[i:i+2] == '{{':
                    depth += 1; i += 2
                elif text[i:i+2] == '}}':
                    depth -= 1; i += 2
                    if depth == 0:
                        break
                else:
                    i += 1
            text = text[:start] + text[i:]
        # Remove {{sfn|...}} (short footnotes)
        text = re.sub(r'\{\{sfn\|[^}]*\}\}', '', text, flags=re.IGNORECASE)
        # Resolve {{convert|num|from|to|...}} and {{cvt|...}}
        def _convert(m):
            parts = [p.strip() for p in m.group(1).split('|')]
            # Filter out named params like sp=us, abbr=on
            vals = [p for p in parts if '=' not in p]
            if len(vals) >= 2:
                return f"{vals[0]} {vals[1]}"
            return m.group(0)
        text = re.sub(r'\{\{(?:convert|cvt)\|(.+?)\}\}', _convert, text, flags=re.IGNORECASE)
        # Resolve {{Coord|...}} to readable text
        def _coord(m):
            parts = [p.strip() for p in m.group(1).split('|') if p.strip() and p.strip() not in ('display=inline', 'display=title')]
            return ' '.join(parts)
        text = re.sub(r'\{\{[Cc]oord\|(.+?)\}\}', _coord, text)
        # Resolve [[link|display]] → display, [[link]] → link
        text = re.sub(r'\[\[(?:[^|\]]*\|)?([^\]]+)\]\]', r'\1', text)
        # Resolve {{sup|...}} / {{super|...}} → superscript-like text
        text = re.sub(r'\{\{su(?:p|per)\|([^}]*)\}\}', r'\1', text, flags=re.IGNORECASE)
        # Remove remaining {{ ... }} templates (handle nested by repeating)
        prev = None
        while prev != text:
            prev = text
            text = re.sub(r'\{\{[^{}]*\}\}', '', text)
        # Remove wikitext italic/bold markup ('' and ''')
        text = re.sub(r"'{2,3}", '', text)
        # Clean up any remaining [[ or ]] or {{ or }} fragments
        text = text.replace('[[', '').replace(']]', '')
        text = text.replace('{{', '').replace('}}', '')
        # Clean HTML tags like <br>, <br/>, <sup>
        text = re.sub(r'<br\s*/?>', ', ', text)
        text = re.sub(r'</?su[bp]>', '', text)
        # Collapse whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    @staticmethod
    def _parse_infobox(wikitext: str) -> dict:
        """Extract key=value pairs from an {{Infobox ...}} template in wikitext."""
        start = wikitext.find('{{Infobox')
        if start == -1:
            return {}
        depth, i = 0, start
        while i < len(wikitext):
            if wikitext[i:i+2] == '{{':
                depth += 1; i += 2
            elif wikitext[i:i+2] == '}}':
                depth -= 1; i += 2
                if depth == 0:
                    break
            else:
                i += 1
        infobox = wikitext[start:i]
        # Split on top-level pipes (depth == 1 means inside the outermost {{ }})
        fields = {}
        depth = 0
        current = []
        i = 0
        while i < len(infobox):
            two = infobox[i:i+2]
            if two == '{{':
                depth += 1
                current.append('{{')
                i += 2
            elif two == '}}':
                depth -= 1
                current.append('}}')
                i += 2
            elif infobox[i] == '|' and depth == 1:
                part = ''.join(current).strip()
                if '=' in part:
                    key, _, val = part.partition('=')
                    fields[key.strip().lower()] = val.strip()
                current = []
                i += 1
            else:
                current.append(infobox[i])
                i += 1
        # Handle last field
        part = ''.join(current).strip().rstrip('}')
        if '=' in part:
            key, _, val = part.partition('=')
            fields[key.strip().lower()] = val.strip()
        return fields

    @staticmethod
    def _river_tooltip(summary_data: dict, lang: str, page_title: str) -> str:
        """Build a river-focused tooltip from Wikipedia infobox data."""
        _ua = {"User-Agent": "holoviz-utils/1.0"}
        title = summary_data.get("title", page_title)
        description = summary_data.get("description", "")
        article_url = summary_data["content_urls"]["desktop"]["page"]
        thumbnail = summary_data.get("thumbnail")

        # Fetch the lead section wikitext for the infobox
        r = requests.get(
            f"https://{lang}.wikipedia.org/w/api.php",
            params={
                "action": "query", "titles": page_title, "prop": "revisions",
                "rvprop": "content", "rvsection": "0", "format": "json",
            },
            headers=_ua,
        )
        r.raise_for_status()
        pages = r.json()["query"]["pages"]
        wikitext = next(iter(pages.values()))["revisions"][0]["*"]
        fields = Glossinator._parse_infobox(wikitext)
        clean = Glossinator._clean_wikitext

        # Build rows for physical characteristics
        rows = []
        label_map = [
            ("length",              "Length"),
            ("basin_size",          "Basin area"),
            ("discharge1_avg",      "Avg. discharge"),
            ("discharge1_location", "Discharge at"),
            ("depth_avg",           "Avg. depth"),
            ("depth_max",           "Max. depth"),
            ("width_avg",           "Avg. width"),
            ("width_max",           "Max. width"),
            ("source1",             "Source"),
            ("source1_elevation",   "Source elev."),
            ("mouth",               "Mouth"),
            ("mouth_location",      "Mouth location"),
        ]
        for key, label in label_map:
            val = fields.get(key, "").strip()
            if val:
                val = clean(val)
                if val:
                    rows.append(
                        f'<span style="display:block;font-size:0.85em;margin:1px 0;">'
                        f'<b style="color:#9db4c0;">{label}:</b> {val}</span>'
                    )

        # Countries
        countries = fields.get("subdivision_name1", "").strip()
        if countries:
            countries = clean(countries)
            if countries:
                rows.append(
                    f'<span style="display:block;font-size:0.85em;margin:1px 0;">'
                    f'<b style="color:#9db4c0;">Countries:</b> {countries}</span>'
                )

        # Tributaries
        for side in ("left", "right"):
            tribs = fields.get(f"tributaries_{side}", "").strip()
            if tribs:
                tribs = clean(tribs)
                if tribs:
                    rows.append(
                        f'<span style="display:block;font-size:0.85em;margin:1px 0;">'
                        f'<b style="color:#9db4c0;">Tributaries ({side}):</b> {tribs}</span>'
                    )

        # Assemble tooltip
        img = ""
        if thumbnail:
            img = (
                f'<img src="{thumbnail["source"]}" '
                f'style="float:right; max-width:80px; max-height:80px; '
                f'margin:0 0 6px 10px; border-radius:3px; object-fit:cover;" />'
            )

        desc = ""
        if description:
            desc = (
                f'<span style="display:block; color:#72777d; font-size:0.85em; '
                f'margin:2px 0 6px;">{description}</span>'
            )

        characteristics = ''.join(rows) if rows else (
            '<span style="display:block;font-size:0.85em;color:#72777d;">'
            'No physical characteristics available.</span>'
        )

        link = (
            f'<a href="{article_url}" target="_blank" '
            f'style="display:block; margin-top:8px; font-size:0.85em; color:#3366cc;">'
            f'Read on Wikipedia →</a>'
        )

        return f'{img}<b>{title}</b>{desc}{characteristics}{link}'

    @staticmethod
    def wikipedia_tooltip(url: str) -> str:
        m = re.match(r'https?://([a-z-]+)\.wikipedia\.org/wiki/(.+)', url)
        if not m:
            raise ValueError(f"Invalid Wikipedia URL: {url!r}")
        lang, page_title = m.group(1), unquote(m.group(2))
        api_url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{page_title}"
        r = requests.get(api_url, headers={"User-Agent": "holoviz-utils/1.0"})
        r.raise_for_status()
        data = r.json()

        # Detect river articles and use specialized tooltip
        description = data.get("description", "")
        if "river" in description.lower():
            return Glossinator._river_tooltip(data, lang, page_title)

        title       = data.get("title", page_title)
        extract_html = data.get("extract_html", "")
        # <p> inside a <span> is invalid HTML; replace with block-display spans
        extract_html = re.sub(r'<p\b[^>]*>', '<span style="display:block;margin:0.4em 0">', extract_html)
        extract_html = re.sub(r'</p>', '</span>', extract_html)
        article_url  = data["content_urls"]["desktop"]["page"]
        thumbnail    = data.get("thumbnail")

        img = ""
        if thumbnail:
            img = (
                f'<img src="{thumbnail["source"]}" '
                f'style="float:right; max-width:80px; max-height:80px; '
                f'margin:0 0 6px 10px; border-radius:3px; object-fit:cover;" />'
            )

        desc = ""
        if description:
            desc = (
                f'<span style="display:block; color:#72777d; font-size:0.85em; '
                f'margin:2px 0 6px;">{description}</span>'
            )

        link = (
            f'<a href="{article_url}" target="_blank" '
            f'style="display:block; margin-top:8px; font-size:0.85em; color:#3366cc;">'
            f'Read on Wikipedia →</a>'
        )

        return f'{img}<b>{title}</b>{desc}{extract_html}{link}'

    @staticmethod
    def copernicus_tooltip(url: str, max_abstract_chars: int = 300) -> str:
        """Fetch a Copernicus journal article page and return tooltip HTML
        with the title, authors, and a truncated abstract.

        Parameters
        ----------
        url : str
            Full URL to a Copernicus article, e.g.
            ``https://hess.copernicus.org/articles/19/3829/2015/``
        max_abstract_chars : int
            Maximum number of characters of the abstract to include.
        """
        r = requests.get(url, headers={"User-Agent": "holoviz-utils/1.0"})
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        html = r.text

        # --- title from citation_title meta tag ---
        title_m = re.search(
            r'<meta\s+name="citation_title"\s+content="([^"]+)"', html
        )
        title = title_m.group(1) if title_m else "Unknown title"

        # --- authors from citation_author meta tags ("Last, First" → "First Last") ---
        authors_raw = re.findall(
            r'<meta\s+name="citation_author"\s+content="([^"]+)"', html
        )
        authors = []
        for a in authors_raw:
            parts = [p.strip() for p in a.split(",", 1)]
            authors.append(" ".join(reversed(parts)) if len(parts) == 2 else a)
        authors_str = ", ".join(authors)

        # --- abstract from citation_abstract meta tag ---
        abstract_m = re.search(
            r'<meta\s+name="citation_abstract"\s+content="([^"]+)"', html
        )
        abstract = ""
        if abstract_m:
            raw = _html_unescape(abstract_m.group(1))
            abstract = re.sub(r'<[^>]+>', '', raw).strip()
            abstract = re.sub(r'^Abstract\.\s*', '', abstract)
            if len(abstract) > max_abstract_chars:
                abstract = abstract[:max_abstract_chars].rsplit(' ', 1)[0] + " …"

        # --- journal + year ---
        journal_m = re.search(
            r'<meta\s+name="citation_journal_title"\s+content="([^"]+)"', html
        )
        date_m = re.search(
            r'<meta\s+name="citation_publication_date"\s+content="([^"]+)"', html
        )
        journal = journal_m.group(1) if journal_m else ""
        year = date_m.group(1)[:4] if date_m else ""
        source = ", ".join(filter(None, [journal, year]))

        # --- build tooltip ---
        parts = [f'<b>{title}</b>']
        if authors_str:
            parts.append(
                f'<span style="display:block; color:#72777d; font-size:0.85em; '
                f'margin:2px 0 4px;">{authors_str}</span>'
            )
        if source:
            parts.append(
                f'<span style="display:block; color:#72777d; font-size:0.8em; '
                f'font-style:italic; margin-bottom:4px;">{source}</span>'
            )
        if abstract:
            parts.append(
                f'<span style="display:block; margin:4px 0 0; font-size:0.9em;">'
                f'{abstract}</span>'
            )
        parts.append(
            f'<a href="{url}" target="_blank" '
            f'style="display:block; margin-top:8px; font-size:0.85em; color:#3366cc;">'
            f'Continue reading →</a>'
        )
        return ''.join(parts)


if __name__ == "__main__":

    from holoviz_utils.dataviz import FloatingPane

    glossary = {
        "This": "An example term that will be explained in the tooltip.",
        "AETI": "https://en.wikipedia.org/wiki/Evapotranspiration",
        "Python": "A high-level programming language.",
        "Markdown": "A lightweight markup language for formatting text.",
        "HTML": "The standard markup language for creating web pages."
    }
    md_text = "This is a sample AETI text mentioning Python, Markdown, and AETI."
    
    gls = Glossinator(
        glossary=glossary, 
        markdown=md_text,
        tooltip_background_opacity=50,
        )
    
    fp = FloatingPane(
        background_pane = pn.Column(styles={"background-color": "green"}, sizing_mode="stretch_both"),
        append_params = False,
        floating_panel_content = [gls.html_pane],
    )

    fp.view.show()