import * as esbuild from "esbuild";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// lerc (a geotiff dependency) dynamically imports Node's built-in "module"
// package to detect whether it's running in Node.js. In browser builds this
// import is always unreachable, so we stub it out with an empty module.
const stubNodeModulePlugin = {
  name: "stub-node-module",
  setup(build) {
    build.onResolve({ filter: /^module$/ }, () => ({
      path: "module",
      namespace: "stub-node-module",
    }));
    build.onLoad({ filter: /.*/, namespace: "stub-node-module" }, () => ({
      contents: "export default {}; export const createRequire = () => {};",
      loader: "js",
    }));
  },
};

await esbuild.build({
  entryPoints: [path.join(__dirname, "entry.js")],
  bundle: true,
  minify: true,
  format: "esm",
  outfile: path.join(
    __dirname,
    "..",
    "src",
    "holoviz_utils",
    "vendor",
    "deckgl-bundle.min.js"
  ),
  target: ["esnext"],
  logLevel: "info",
  plugins: [stubNodeModulePlugin],
});
