# jsbuild

Builds the vendored JavaScript bundle used by `holoviz_utils`'s DeckGL panel widget.

## What it produces

`../src/holoviz_utils/vendor/deckgl-bundle.min.js` — a minified ESM bundle that
attaches the following libraries to `globalThis` so they are accessible as browser
globals inside the widget's ES module:

| Global | Package |
|---|---|
| `globalThis.deck` | `deck.gl` + `@deck.gl/json` + `COGLayer` from `@developmentseed/deck.gl-geotiff` |
| `globalThis.chroma` | `chroma-js` |

The bundle is consumed via a Panel import map (`import "deck-vendor"` in `deckgl.js`).

## Prerequisites

- [Node.js](https://nodejs.org/) ≥ 18

## Usage

```bash
# Install dependencies (first time or after changing package.json)
npm install

# Build the bundle
npm run build
```

The output file is committed to the repository so that the Python package can be
installed without Node.js.

## Updating dependencies

1. Edit the version constraints in `package.json`.
2. Delete `node_modules/` and `package-lock.json` to avoid stale resolution
   conflicts, then run `npm install`.
3. Run `npm run build` and commit both `package.json`, `package-lock.json`, and
   the updated bundle.

### Note on `@developmentseed/deck.gl-geotiff` ≥ 0.6

Versions ≥ 0.6 use top-level `await` (via `lzw-tiff-decoder`) and require
`@deck.gl/core ^9.3`. The build script uses esbuild's `esm` output format (instead
of `iife`) to support top-level await, and stubs out a Node.js-only dynamic import
inside `lerc` that is unreachable in browser builds.
