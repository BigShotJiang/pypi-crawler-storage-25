"""Astron Zhihu MCP server."""

from __future__ import annotations

import html as html_lib
import json
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any, Iterator
from urllib.parse import quote_plus, urlparse

import requests
from mcp.server.fastmcp import Context, FastMCP

from zhihu_mcp import __version__


HOME_URL = "https://www.zhihu.com/"
HOT_LIST_API_URL = "https://api.zhihu.com/topstory/hot-lists/total"
FEED_LIST_API_URL = "https://api.zhihu.com/topstory/recommend"
SEARCH_API_URL = "https://api.zhihu.com/search_v3"
SEARCH_SUGGEST_API_URL = "https://www.zhihu.com/api/v4/search/suggest"
SEARCH_WEB_URL = "https://www.zhihu.com/search?type=content&q={query}"
EXTERNAL_SEARCH_URL = "https://www.bing.com/search"
QUESTION_API_URL = "https://www.zhihu.com/api/v4/questions/{content_id}"
ANSWER_API_URL = "https://www.zhihu.com/api/v4/answers/{content_id}"
ARTICLE_API_URL = "https://zhuanlan.zhihu.com/api/articles/{content_id}"
MEMBER_API_URL = "https://www.zhihu.com/api/v4/members/{author_id}"
MEMBER_ANSWERS_API_URL = "https://www.zhihu.com/api/v4/members/{author_id}/answers"
MEMBER_ARTICLES_API_URL = "https://www.zhihu.com/api/v4/members/{author_id}/articles"
MEMBER_PINS_API_URL = "https://www.zhihu.com/api/v4/members/{author_id}/pins"
PEOPLE_ACTIVITIES_API_URL = "https://api.zhihu.com/people/{author_id}/activities"
QUESTION_URL_TEMPLATE = "https://www.zhihu.com/question/{content_id}"
ANSWER_URL_TEMPLATE = "https://www.zhihu.com/answer/{content_id}"
ARTICLE_URL_TEMPLATE = "https://zhuanlan.zhihu.com/p/{content_id}"
PEOPLE_URL_TEMPLATE = "https://www.zhihu.com/people/{author_id}"

QUESTION_RE = re.compile(r"/question[s]?/(\d+)")
ANSWER_RE = re.compile(r"/answer[s]?/(\d+)")
ARTICLE_RE = re.compile(r"zhuanlan\.zhihu\.com/p/(\d+)")
MEMBER_RE = re.compile(r"/(?:api/v4/)?(?:people|members)/([^/?#]+)")
TAG_RE = re.compile(r"<[^>]+>")
COUNT_RE = re.compile(r"[\d,.]+")
HOT_VALUE_RE = re.compile(r"([\d.]+)\s*([万亿]?)")
CJK_RE = re.compile(r"[\u4e00-\u9fff]+")


class _HTMLCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.title = ""
        self._in_title = False
        self.scripts: list[tuple[dict[str, str], str]] = []
        self._current_attrs: dict[str, str] | None = None
        self._current_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs_map = {key: value or "" for key, value in attrs}
        if tag == "title":
            self._in_title = True
            return
        if tag == "script":
            self._current_attrs = attrs_map
            self._current_parts = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        if self._current_attrs is not None:
            self._current_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
        if tag == "script" and self._current_attrs is not None:
            self.scripts.append((self._current_attrs, "".join(self._current_parts).strip()))
            self._current_attrs = None
            self._current_parts = []


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("ZHIHU_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("ZHIHU_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("ZHIHU_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("ZHIHU_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Zhihu-MCP/{__version__}"
    )


def get_prewarm_home_enabled() -> bool:
    raw = os.getenv("ZHIHU_MCP_PREWARM_HOME", "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def get_cookie_header() -> str:
    return os.getenv("ZHIHU_MCP_COOKIE", "").strip()


def _parse_cookie_header(cookie_header: str) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for segment in cookie_header.split(";"):
        token = segment.strip()
        if not token or "=" not in token:
            continue
        key, value = token.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        pairs[key] = value
    return pairs


def create_session() -> requests.Session:
    session = requests.Session()
    cookie_header = get_cookie_header()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
    )
    if cookie_header:
        session.headers["Cookie"] = cookie_header
        session.cookies.update(_parse_cookie_header(cookie_header))
    setattr(session, "_astron_prewarmed", False)
    return session


def _prewarm_home(session: requests.Session, *, force: bool = False) -> None:
    if not get_prewarm_home_enabled():
        return
    already = bool(getattr(session, "_astron_prewarmed", False))
    if already and not force:
        return
    try:
        response = session.get(
            HOME_URL,
            headers={
                "Referer": HOME_URL,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            timeout=get_timeout_seconds(),
        )
        if response.status_code in {200, 301, 302, 403}:
            setattr(session, "_astron_prewarmed", True)
    except requests.RequestException:
        pass


def get_cache_path() -> str:
    value = os.getenv("ZHIHU_MCP_CACHE_PATH", "").strip()
    if value:
        return value
    return "/tmp/zhihu_mcp_cache.json"


def get_cache_ttl_seconds() -> float:
    raw = os.getenv("ZHIHU_MCP_CACHE_TTL_SECONDS", "1800").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("ZHIHU_MCP_CACHE_TTL_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("ZHIHU_MCP_CACHE_TTL_SECONDS 必须大于 0")
    return value


def get_cache_max_items() -> int:
    raw = os.getenv("ZHIHU_MCP_CACHE_MAX_ITEMS", "800").strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError("ZHIHU_MCP_CACHE_MAX_ITEMS 必须是整数") from exc
    if value <= 0:
        raise RuntimeError("ZHIHU_MCP_CACHE_MAX_ITEMS 必须大于 0")
    return value


def get_fallback_feed_scan_pages() -> int:
    raw = os.getenv("ZHIHU_MCP_FALLBACK_FEED_SCAN_PAGES", "4").strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError("ZHIHU_MCP_FALLBACK_FEED_SCAN_PAGES 必须是整数") from exc
    return max(1, min(value, 12))


def get_fallback_feed_page_size() -> int:
    raw = os.getenv("ZHIHU_MCP_FALLBACK_FEED_PAGE_SIZE", "20").strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError("ZHIHU_MCP_FALLBACK_FEED_PAGE_SIZE 必须是整数") from exc
    return max(5, min(value, 50))


def _now_ts() -> float:
    return datetime.now(tz=timezone.utc).timestamp()


def _is_fresh(timestamp: Any) -> bool:
    ts = _to_int(timestamp)
    if ts is None:
        return False
    return (_now_ts() - float(ts)) <= get_cache_ttl_seconds()


def _default_cache() -> dict[str, Any]:
    return {
        "items": {},
        "item_index": [],
        "authors": {},
        "updated_at": int(_now_ts()),
    }


def _load_cache() -> dict[str, Any]:
    path = get_cache_path()
    if not os.path.exists(path):
        return _default_cache()
    try:
        with open(path, "r", encoding="utf-8") as fp:
            payload = json.load(fp)
    except (OSError, ValueError):
        return _default_cache()
    if not isinstance(payload, dict):
        return _default_cache()
    result = _default_cache()
    if isinstance(payload.get("items"), dict):
        result["items"] = payload["items"]
    if isinstance(payload.get("item_index"), list):
        result["item_index"] = [clean_text(key) for key in payload["item_index"] if clean_text(key)]
    if isinstance(payload.get("authors"), dict):
        result["authors"] = payload["authors"]
    result["updated_at"] = _to_int(payload.get("updated_at")) or int(_now_ts())
    return result


def _save_cache(cache: dict[str, Any]) -> None:
    path = get_cache_path()
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    cache["updated_at"] = int(_now_ts())
    try:
        with open(path, "w", encoding="utf-8") as fp:
            json.dump(cache, fp, ensure_ascii=False)
    except OSError:
        pass


def _item_cache_key(item: dict[str, Any]) -> str:
    item_id = clean_text(item.get("id", ""))
    if item_id:
        return item_id
    return clean_text(item.get("url", ""))


def _cache_items(items: list[dict[str, Any]]) -> None:
    if not items:
        return
    cache = _load_cache()
    cache_items = cache["items"]
    cache_index = cache["item_index"]
    max_items = get_cache_max_items()
    for item in items:
        key = _item_cache_key(item)
        if not key:
            continue
        cached_item = dict(item)
        cached_item["_cached_at"] = int(_now_ts())
        cache_items[key] = cached_item
        if key in cache_index:
            cache_index.remove(key)
        cache_index.append(key)
    while len(cache_index) > max_items:
        old_key = cache_index.pop(0)
        cache_items.pop(old_key, None)
    _save_cache(cache)


def _find_cached_item(content_id: str = "", url: str = "") -> dict[str, Any] | None:
    cache = _load_cache()
    cache_items = cache.get("items") if isinstance(cache.get("items"), dict) else {}
    targets: list[str] = []
    direct = clean_text(content_id)
    if direct:
        targets.append(direct)
    if url:
        from_url_id = _extract_content_target("", url)[1]
        if from_url_id:
            targets.append(clean_text(from_url_id))
    for key in targets:
        item = cache_items.get(key)
        if isinstance(item, dict) and _is_fresh(item.get("_cached_at")):
            restored = dict(item)
            restored.pop("_cached_at", None)
            return restored
    for item in cache_items.values():
        if not isinstance(item, dict) or not _is_fresh(item.get("_cached_at")):
            continue
        item_id = clean_text(item.get("id", ""))
        item_url = clean_text(item.get("url", ""))
        if direct and item_id == direct:
            restored = dict(item)
            restored.pop("_cached_at", None)
            return restored
        if url and item_url and item_url == clean_text(url):
            restored = dict(item)
            restored.pop("_cached_at", None)
            return restored
    return None


def _search_cached_items(keyword: str, *, limit: int, real_only: bool = False) -> list[dict[str, Any]]:
    normalized = clean_text(keyword).lower()
    if not normalized:
        return []
    cache = _load_cache()
    cache_items = cache.get("items") if isinstance(cache.get("items"), dict) else {}
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for key in reversed(cache.get("item_index", [])):
        item = cache_items.get(key)
        if not isinstance(item, dict) or not _is_fresh(item.get("_cached_at")):
            continue
        if real_only and clean_text(item.get("source_type", "")).lower() == "suggest":
            continue
        text = " ".join(
            [
                clean_text(item.get("title", "")),
                clean_text(item.get("summary", "")),
                clean_text(item.get("content", "")),
                clean_text(item.get("author_name", "")),
                " ".join(item.get("tags") or []),
            ]
        ).lower()
        if not _keyword_matches_text(text, normalized):
            continue
        item_id = clean_text(item.get("id", "")) or key
        if item_id in seen:
            continue
        seen.add(item_id)
        restored = dict(item)
        restored.pop("_cached_at", None)
        source_type = clean_text(restored.get("source_type", "")).lower()
        if source_type == "suggest":
            restored["content"] = ""
            restored["result_type"] = "suggest"
        elif not clean_text(restored.get("result_type", "")):
            content = clean_text(restored.get("content", ""))
            summary = clean_text(restored.get("summary", ""))
            title = clean_text(restored.get("title", ""))
            if not content or content == summary or content == title:
                restored["result_type"] = "preview"
            else:
                restored["result_type"] = "real"
        restored["rank"] = len(result) + 1
        result.append(restored)
        if len(result) >= limit:
            break
    return result


def _recent_cached_items(*, limit: int, offset: int = 0) -> list[dict[str, Any]]:
    cache = _load_cache()
    cache_items = cache.get("items") if isinstance(cache.get("items"), dict) else {}
    ordered_keys = list(reversed(cache.get("item_index", []))) if isinstance(cache.get("item_index"), list) else []
    staged: list[dict[str, Any]] = []
    seen: set[str] = set()
    for key in ordered_keys:
        item = cache_items.get(key)
        if not isinstance(item, dict) or not _is_fresh(item.get("_cached_at")):
            continue
        restored = dict(item)
        restored.pop("_cached_at", None)
        item_id = clean_text(restored.get("id", "")) or clean_text(restored.get("url", "")) or key
        if not item_id or item_id in seen:
            continue
        seen.add(item_id)
        staged.append(restored)
    staged.sort(
        key=lambda item: (
            0 if _has_real_author_identity(item) else 1,
            0 if clean_text(item.get("content", "")) else 1,
        )
    )
    result: list[dict[str, Any]] = []
    skipped = 0
    for restored in staged:
        if skipped < max(0, offset):
            skipped += 1
            continue
        restored["rank"] = len(result) + 1
        result.append(restored)
        if len(result) >= limit:
            break
    return result


def _author_from_cached_items(token: str, page_url: str) -> dict[str, Any] | None:
    norm_token = clean_text(token)
    if not norm_token:
        return None
    cache = _load_cache()
    cache_items = cache.get("items") if isinstance(cache.get("items"), dict) else {}
    cache_index = cache.get("item_index") if isinstance(cache.get("item_index"), list) else []
    for key in reversed(cache_index):
        item = cache_items.get(key)
        if not isinstance(item, dict) or not _is_fresh(item.get("_cached_at")):
            continue
        if clean_text(item.get("author_id", "")) != norm_token:
            continue
        name = clean_text(item.get("author_name", ""))
        if not name:
            continue
        return {
            "id": norm_token,
            "name": name,
            "url": page_url,
            "avatar": "",
            "bio": clean_text(item.get("summary", "") or item.get("content", "")),
            "follower_count": None,
            "following_count": None,
            "content_count": None,
        }
    return None


def _keyword_tokens(keyword: str) -> list[str]:
    normalized = clean_text(keyword).lower()
    if not normalized:
        return []
    tokens: list[str] = []
    for part in re.split(r"\s+", normalized):
        part = clean_text(part)
        if not part:
            continue
        tokens.append(part)
        for cjk_match in CJK_RE.finditer(part):
            chunk = cjk_match.group(0)
            if len(chunk) >= 3:
                for idx in range(len(chunk) - 1):
                    tokens.append(chunk[idx : idx + 2])
    unique: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique.append(token)
    return unique


def _keyword_matches_text(text: str, keyword: str) -> bool:
    body = clean_text(text).lower()
    query = clean_text(keyword).lower()
    if not body or not query:
        return False
    if query in body:
        return True
    tokens = _keyword_tokens(query)
    if not tokens:
        return False
    latin_tokens = [token for token in tokens if not CJK_RE.search(token)]
    cjk_tokens = [token for token in tokens if CJK_RE.search(token)]
    if latin_tokens and all(token in body for token in latin_tokens):
        return True
    if cjk_tokens:
        matches = sum(1 for token in cjk_tokens if token in body)
        needed = 1
        if matches >= needed:
            return True
    return False


def _cache_author_profile(token: str, author: dict[str, Any]) -> None:
    key = clean_text(token or author.get("id", ""))
    if not key:
        return
    cache = _load_cache()
    authors = cache.get("authors") if isinstance(cache.get("authors"), dict) else {}
    entry = authors.get(key) if isinstance(authors.get(key), dict) else {}
    entry["author"] = author
    entry["updated_at"] = int(_now_ts())
    authors[key] = entry
    cache["authors"] = authors
    _save_cache(cache)


def _get_cached_author_profile(token: str) -> dict[str, Any] | None:
    key = clean_text(token)
    if not key:
        return None
    cache = _load_cache()
    authors = cache.get("authors") if isinstance(cache.get("authors"), dict) else {}
    entry = authors.get(key)
    if not isinstance(entry, dict) or not _is_fresh(entry.get("updated_at")):
        return None
    author = entry.get("author")
    if isinstance(author, dict):
        return author
    return None


def _cache_author_items(token: str, author_name: str, items: list[dict[str, Any]]) -> None:
    if not items:
        return
    keys = [clean_text(token)]
    normalized_name = clean_text(author_name).lower()
    if normalized_name:
        keys.append(normalized_name)
    cache = _load_cache()
    authors = cache.get("authors") if isinstance(cache.get("authors"), dict) else {}
    for key in keys:
        if not key:
            continue
        entry = authors.get(key) if isinstance(authors.get(key), dict) else {}
        entry["items"] = items
        entry["updated_at"] = int(_now_ts())
        authors[key] = entry
    cache["authors"] = authors
    _save_cache(cache)


def _get_cached_author_items(token: str, author_name: str, *, limit: int) -> list[dict[str, Any]]:
    cache = _load_cache()
    authors = cache.get("authors") if isinstance(cache.get("authors"), dict) else {}
    keys = [clean_text(token), clean_text(author_name).lower()]
    for key in keys:
        if not key:
            continue
        entry = authors.get(key)
        if not isinstance(entry, dict) or not _is_fresh(entry.get("updated_at")):
            continue
        items = entry.get("items")
        if not isinstance(items, list):
            continue
        normalized_items = [dict(item) for item in items if isinstance(item, dict)]
        for index, item in enumerate(normalized_items, start=1):
            item["rank"] = index
        return normalized_items[:limit]
    return []


def clean_text(value: Any) -> str:
    text = html_lib.unescape(str(value or ""))
    text = TAG_RE.sub(" ", text)
    return " ".join(text.split())


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = clean_text(value)
    match = COUNT_RE.search(text)
    if not match:
        return None
    try:
        return int(float(match.group(0).replace(",", "")))
    except ValueError:
        return None


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _parse_offset_cursor(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value < 0:
        return 0
    return value


def _extract_hot_value(value: str) -> int | None:
    text = clean_text(value)
    if not text:
        return None
    match = HOT_VALUE_RE.search(text)
    if not match:
        return _to_int(text)
    number = float(match.group(1))
    unit = match.group(2)
    multiplier = {"": 1, "万": 10_000, "亿": 100_000_000}.get(unit, 1)
    return int(number * multiplier)


def _timestamp_to_iso(value: Any) -> str:
    if value in (None, ""):
        return ""
    timestamp = _to_int(value)
    if timestamp is None:
        return ""
    if timestamp > 10**12:
        timestamp = timestamp // 1000
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = HOME_URL,
) -> dict[str, Any]:
    _prewarm_home(session)
    for attempt in range(2):
        try:
            response = session.get(
                url,
                params=params,
                headers={
                    "Referer": referer,
                    "Accept": "application/json, text/plain, */*",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code in {401, 403, 412, 429} and attempt == 0:
            _prewarm_home(session, force=True)
            continue
        if response.status_code != 200:
            raise RuntimeError(
                f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc
        if isinstance(payload, dict):
            return payload
        if isinstance(payload, list):
            return {"data": payload}
        raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def _request_text(
    session: requests.Session,
    url: str,
    *,
    referer: str = HOME_URL,
) -> str:
    _prewarm_home(session)
    try:
        response = session.get(
            url,
            headers={
                "Referer": referer,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code in {401, 403, 412, 429}:
        _prewarm_home(session, force=True)
        try:
            response = session.get(
                url,
                headers={
                    "Referer": referer,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )
    return response.text


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    del raw
    if capability == "search":
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    result = {
        "platform": "zhihu",
        "capability": capability,
        "status": status,
        "update_time": _current_iso(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    del raw
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    result = {
        "platform": "zhihu",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    del raw
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    result = {
        "platform": "zhihu",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _extract_question_title(question: dict[str, Any] | None) -> str:
    if not isinstance(question, dict):
        return ""
    return clean_text(question.get("title", "") or question.get("detail", ""))


def _parse_topics(topics: Any) -> list[str]:
    tags: list[str] = []
    if isinstance(topics, list):
        for topic in topics:
            if isinstance(topic, dict):
                name = clean_text(topic.get("name", ""))
                if name:
                    tags.append(name)
    return tags


def _normalize_author_id(value: Any) -> str:
    text = clean_text(value)
    return "" if text == "0" else text


def _normalize_content_url(url: str, fallback_kind: str, fallback_id: str) -> str:
    text = clean_text(url)
    if text.startswith("https://api.zhihu.com/question/") or text.startswith("https://api.zhihu.com/questions/"):
        return QUESTION_URL_TEMPLATE.format(content_id=fallback_id or text.rsplit("/", 1)[-1])
    if text:
        return text
    if fallback_kind == "answer":
        return ANSWER_URL_TEMPLATE.format(content_id=fallback_id)
    if fallback_kind == "article":
        return ARTICLE_URL_TEMPLATE.format(content_id=fallback_id)
    return QUESTION_URL_TEMPLATE.format(content_id=fallback_id)


def _build_hot_item(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    target = entry.get("target") if isinstance(entry.get("target"), dict) else {}
    author = target.get("author") if isinstance(target.get("author"), dict) else {}
    children = target.get("children") if isinstance(target.get("children"), list) else []
    thumbnail = ""
    if children and isinstance(children[0], dict):
        thumbnail = clean_text(children[0].get("thumbnail", ""))
    target_id = clean_text(target.get("id", ""))
    summary = clean_text(target.get("excerpt", ""))
    return {
        "id": target_id,
        "title": clean_text(target.get("title", "")),
        "summary": summary,
        "content": summary,
        "url": _normalize_content_url(clean_text(target.get("url", "")), "question", target_id),
        "cover": thumbnail,
        "author_name": clean_text(author.get("name", "")),
        "author_id": _normalize_author_id(author.get("id", "") or author.get("url_token", "")),
        "publish_time": _timestamp_to_iso(target.get("created")),
        "rank": rank,
        "hot_value": _extract_hot_value(clean_text(entry.get("detail_text", ""))),
        "hot_text": clean_text(entry.get("detail_text", "")),
        "comment_count": _to_int(target.get("comment_count")),
        "like_count": _to_int(target.get("voteup_count")),
        "share_count": _to_int(target.get("share_count")),
        "collect_count": _to_int(target.get("favorite_count")),
        "view_count": _to_int(target.get("visited_count")),
        "source_type": clean_text(target.get("type", "") or "question"),
        "result_type": "real" if summary else "topic",
        "tags": _parse_topics(target.get("topics")),
    }


def _build_feed_item(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    target = entry.get("target") if isinstance(entry.get("target"), dict) else {}
    question = target.get("question") if isinstance(target.get("question"), dict) else {}
    author = target.get("author") if isinstance(target.get("author"), dict) else {}
    question_title = _extract_question_title(question)
    title = clean_text(
        question_title
        or target.get("title", "")
        or target.get("excerpt_new", "")
        or target.get("excerpt", "")
    )
    summary = clean_text(target.get("excerpt_new", "") or target.get("excerpt", ""))
    content = clean_text(target.get("content", ""))
    question_id = clean_text(question.get("id", ""))
    content_id = clean_text(target.get("id", "") or question_id)
    source_type = clean_text(target.get("answer_type", "") or target.get("type", "") or "answer")
    return {
        "id": content_id or clean_text(target.get("url", "")).rsplit("/", 1)[-1],
        "title": title,
        "summary": summary,
        "content": content,
        "url": _normalize_content_url(clean_text(target.get("url", "")), "question", question_id or content_id),
        "cover": clean_text(target.get("cover_url", "") or target.get("image_url", "")),
        "author_name": clean_text(author.get("name", "") or author.get("nickname", "")),
        "author_id": _normalize_author_id(author.get("id", "") or author.get("url_token", "")),
        "publish_time": _timestamp_to_iso(target.get("created_time") or target.get("updated_time") or question.get("created")),
        "rank": rank,
        "hot_value": _to_int(target.get("voteup_count")),
        "hot_text": f"{target.get('voteup_count')} 赞" if _to_int(target.get("voteup_count")) is not None else "",
        "comment_count": _to_int(target.get("comment_count") or question.get("comment_count")),
        "like_count": _to_int(target.get("voteup_count")),
        "share_count": _to_int(target.get("share_count")),
        "collect_count": _to_int(target.get("favorite_count")),
        "view_count": _to_int(target.get("visited_count")),
        "source_type": source_type,
        "result_type": "real" if content else "preview",
        "tags": _parse_topics(question.get("topics")),
    }


def _build_item_from_search_object(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    object_data = entry.get("object") if isinstance(entry.get("object"), dict) else {}
    question = object_data.get("question") if isinstance(object_data.get("question"), dict) else {}
    author = object_data.get("author") if isinstance(object_data.get("author"), dict) else {}
    source_type = clean_text(entry.get("type", "") or object_data.get("type", "") or "content")
    title = clean_text(
        object_data.get("title", "")
        or question.get("title", "")
        or object_data.get("excerpt", "")
        or object_data.get("content", "")
    )
    summary = clean_text(object_data.get("excerpt", "") or object_data.get("content", ""))
    content = clean_text(object_data.get("content", ""))
    content_id = clean_text(
        object_data.get("id", "")
        or object_data.get("question_id", "")
        or question.get("id", "")
    )
    url = clean_text(object_data.get("url", "") or question.get("url", ""))
    return {
        "id": content_id or url.rsplit("/", 1)[-1],
        "title": title,
        "summary": summary,
        "content": content,
        "url": _normalize_content_url(url, "question", content_id),
        "cover": clean_text(object_data.get("image_url", "") or object_data.get("thumbnail", "")),
        "author_name": clean_text(author.get("name", "") or author.get("nickname", "")),
        "author_id": _normalize_author_id(author.get("id", "") or author.get("url_token", "")),
        "publish_time": _timestamp_to_iso(object_data.get("created") or object_data.get("created_time") or object_data.get("updated_time")),
        "rank": rank,
        "hot_value": _to_int(object_data.get("voteup_count")),
        "hot_text": f"{object_data.get('voteup_count')} 赞" if _to_int(object_data.get("voteup_count")) is not None else "",
        "comment_count": _to_int(object_data.get("comment_count")),
        "like_count": _to_int(object_data.get("voteup_count")),
        "share_count": _to_int(object_data.get("share_count")),
        "collect_count": _to_int(object_data.get("favorite_count")),
        "view_count": _to_int(object_data.get("visited_count")),
        "source_type": source_type,
        "result_type": "real" if content else "preview",
        "tags": _parse_topics(question.get("topics") or object_data.get("topics")),
    }


def _has_real_author_identity(item: dict[str, Any]) -> bool:
    author_id = clean_text(item.get("author_id", ""))
    return bool(author_id and author_id != "0")


def _search_priority(item: dict[str, Any]) -> tuple[int, int, int]:
    source_type = clean_text(item.get("source_type", ""))
    type_rank = {
        "answer": 0,
        "article": 1,
        "pin": 2,
        "question": 3,
    }.get(source_type, 4)
    return (
        0 if _has_real_author_identity(item) else 1,
        type_rank,
        -len(clean_text(item.get("content", ""))),
    )


def _build_item_from_detail_payload(payload: dict[str, Any], kind: str, rank: int = 1) -> dict[str, Any]:
    author = payload.get("author") if isinstance(payload.get("author"), dict) else {}
    question = payload.get("question") if isinstance(payload.get("question"), dict) else {}
    content_id = clean_text(payload.get("id", "") or payload.get("question_id", ""))
    title = clean_text(payload.get("title", "") or question.get("title", "") or payload.get("excerpt", ""))
    summary = clean_text(payload.get("excerpt", "") or payload.get("detail", ""))
    content = clean_text(payload.get("content", ""))
    if not content and kind == "question":
        content = clean_text(payload.get("detail", "") or payload.get("excerpt", "") or payload.get("description", ""))
    if kind == "answer" and not title:
        title = clean_text(question.get("title", "") or summary)
    if kind == "article" and not title:
        title = clean_text(payload.get("title", "") or summary)
    raw_url = clean_text(payload.get("url", ""))
    return {
        "id": content_id,
        "title": title,
        "summary": summary,
        "content": content,
        "url": _normalize_content_url(raw_url, kind, content_id),
        "cover": clean_text(payload.get("cover_url", "") or payload.get("image_url", "")),
        "author_name": clean_text(author.get("name", "") or author.get("nickname", "")),
        "author_id": _normalize_author_id(author.get("id", "") or author.get("url_token", "")),
        "publish_time": _timestamp_to_iso(payload.get("created") or payload.get("created_time") or payload.get("updated_time")),
        "rank": rank,
        "hot_value": _to_int(payload.get("voteup_count") or payload.get("follower_count")),
        "hot_text": "",
        "comment_count": _to_int(payload.get("comment_count") or payload.get("answer_count")),
        "like_count": _to_int(payload.get("voteup_count")),
        "share_count": _to_int(payload.get("share_count")),
        "collect_count": _to_int(payload.get("favorite_count")),
        "view_count": _to_int(payload.get("visited_count")),
        "source_type": kind,
        "result_type": "real" if content else "preview",
        "tags": _parse_topics(payload.get("topics") or question.get("topics")),
    }


def _build_author_profile(data: dict[str, Any], url: str) -> dict[str, Any]:
    author_id = _normalize_author_id(data.get("id", "") or data.get("url_token", ""))
    name = clean_text(data.get("name", "") or data.get("nickname", ""))
    return {
        "id": author_id or url.rsplit("/", 1)[-1],
        "name": name,
        "url": clean_text(url) or PEOPLE_URL_TEMPLATE.format(author_id=author_id),
        "avatar": clean_text(data.get("avatar_url", "") or data.get("avatar", "")),
        "bio": clean_text(data.get("headline", "") or data.get("description", "") or data.get("bio", "")),
        "follower_count": _to_int(data.get("follower_count") or data.get("followers_count")),
        "following_count": _to_int(data.get("following_count") or data.get("followees_count")),
        "content_count": _to_int(data.get("answer_count") or data.get("articles_count") or data.get("content_count")),
    }


def _extract_content_target(content_id: str, url: str) -> tuple[str, str, str]:
    raw_id = clean_text(content_id)
    raw_url = clean_text(url)
    is_search_landing = False

    if raw_url:
        article_match = ARTICLE_RE.search(raw_url)
        if article_match:
            cid = article_match.group(1)
            return "article", cid, ARTICLE_URL_TEMPLATE.format(content_id=cid)
        question_match = QUESTION_RE.search(raw_url)
        answer_match = ANSWER_RE.search(raw_url)
        if answer_match:
            cid = answer_match.group(1)
            return "answer", cid, raw_url
        if question_match:
            cid = question_match.group(1)
            return "question", cid, QUESTION_URL_TEMPLATE.format(content_id=cid)
        parsed = urlparse(raw_url)
        if parsed.path.startswith("/search"):
            is_search_landing = True

    if raw_id:
        lowered = raw_id.lower()
        if lowered.startswith("answer:"):
            cid = raw_id.split(":", 1)[1].strip()
            return "answer", cid, ANSWER_URL_TEMPLATE.format(content_id=cid)
        if lowered.startswith("article:"):
            cid = raw_id.split(":", 1)[1].strip()
            return "article", cid, ARTICLE_URL_TEMPLATE.format(content_id=cid)
        if lowered.startswith("question:"):
            cid = raw_id.split(":", 1)[1].strip()
            return "question", cid, QUESTION_URL_TEMPLATE.format(content_id=cid)
        if raw_id.isdigit() and not is_search_landing:
            return "question", raw_id, QUESTION_URL_TEMPLATE.format(content_id=raw_id)

    return "", "", ""


def _extract_author_token(author_id: str, url: str) -> tuple[str, str]:
    text = _normalize_author_id(author_id)
    if text:
        return text, PEOPLE_URL_TEMPLATE.format(author_id=text)
    raw_url = clean_text(url)
    if raw_url:
        match = MEMBER_RE.search(raw_url)
        if match:
            token = clean_text(match.group(1))
            token = _normalize_author_id(token)
            return token, PEOPLE_URL_TEMPLATE.format(author_id=token)
        parsed = urlparse(raw_url)
        if parsed.path:
            match = MEMBER_RE.search(parsed.path)
            if match:
                token = clean_text(match.group(1))
                token = _normalize_author_id(token)
                return token, PEOPLE_URL_TEMPLATE.format(author_id=token)
    return "", ""


def _iter_dicts(value: Any) -> Iterator[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for nested in value.values():
            yield from _iter_dicts(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_dicts(item)


def _extract_json_block(script: str, marker: str) -> Any | None:
    index = script.find(marker)
    if index < 0:
        return None
    brace_index = -1
    for candidate in ("{", "["):
        pos = script.find(candidate, index)
        if pos >= 0 and (brace_index < 0 or pos < brace_index):
            brace_index = pos
    if brace_index < 0:
        return None
    opening = script[brace_index]
    closing = "}" if opening == "{" else "]"
    depth = 0
    in_string = False
    escaped = False
    end = brace_index
    while end < len(script):
        char = script[end]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        else:
            if char == '"':
                in_string = True
            elif char == opening:
                depth += 1
            elif char == closing:
                depth -= 1
                if depth == 0:
                    break
        end += 1
    if depth != 0:
        return None
    snippet = script[brace_index : end + 1]
    try:
        return json.loads(snippet)
    except json.JSONDecodeError:
        return None


def _html_payloads(html: str) -> tuple[str, list[Any]]:
    collector = _HTMLCollector()
    collector.feed(html)
    payloads: list[Any] = []
    for attrs, content in collector.scripts:
        if not content:
            continue
        script_type = attrs.get("type", "").lower()
        script_id = attrs.get("id", "")
        if script_type in {"application/ld+json", "application/json"} or script_id == "__NEXT_DATA__":
            try:
                payloads.append(json.loads(content))
            except json.JSONDecodeError:
                pass
        for marker in (
            "window.__INITIAL_STATE__",
            "window.__INITIAL_SSR_STATE__",
            "__INITIAL_STATE__",
            "__INITIAL_SSR_STATE__",
        ):
            extracted = _extract_json_block(content, marker)
            if extracted is not None:
                payloads.append(extracted)
    return clean_text(collector.title), payloads


def _find_best_content_payload(payloads: list[Any]) -> dict[str, Any] | None:
    for payload in payloads:
        for data in _iter_dicts(payload):
            if not data:
                continue
            has_content = any(key in data for key in ("title", "excerpt", "content", "detail"))
            has_stats = any(key in data for key in ("answer_count", "follower_count", "voteup_count", "comment_count"))
            if has_content and (has_stats or "author" in data):
                return data
    return None


def _find_best_author_payload(payloads: list[Any]) -> dict[str, Any] | None:
    for payload in payloads:
        for data in _iter_dicts(payload):
            if not data:
                continue
            has_identity = any(key in data for key in ("url_token", "follower_count", "headline", "avatar_url"))
            has_name = any(key in data for key in ("name", "nickname"))
            if has_identity and has_name:
                return data
            if "people" in data and isinstance(data["people"], dict):
                return data["people"]
    return None


def _extract_content_candidates_from_payloads(payloads: list[Any], *, limit: int, author_token: str = "") -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    normalized_author = clean_text(author_token)
    for payload in payloads:
        for data in _iter_dicts(payload):
            if not data:
                continue
            title = clean_text(data.get("title", "") or data.get("excerpt", ""))
            content_id = clean_text(data.get("id", "") or data.get("question_id", ""))
            if not title and not content_id:
                continue
            source_type = clean_text(data.get("type", "") or "content")
            author = data.get("author") if isinstance(data.get("author"), dict) else {}
            candidate_author = clean_text(author.get("url_token", "") or author.get("id", ""))
            if normalized_author and candidate_author and normalized_author != candidate_author:
                continue
            item = _build_item_from_detail_payload(data, source_type if source_type in {"question", "answer", "article"} else "question", rank=len(items) + 1)
            if not item.get("id"):
                continue
            if item["id"] in seen:
                continue
            seen.add(item["id"])
            item["rank"] = len(items) + 1
            items.append(item)
            if len(items) >= limit:
                return items
    return items


def _parse_author_content_from_activities(payload: dict[str, Any], *, limit: int) -> list[dict[str, Any]]:
    entries = payload.get("data") if isinstance(payload.get("data"), list) else []
    items: list[dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        target = entry.get("target") if isinstance(entry.get("target"), dict) else {}
        if not target:
            continue
        source_type = clean_text(target.get("type", "") or entry.get("type", "") or "content")
        normalized_type = source_type if source_type in {"question", "answer", "article"} else "answer"
        item = _build_item_from_detail_payload(target, normalized_type, rank=len(items) + 1)
        if item.get("id"):
            items.append(item)
            if len(items) >= limit:
                return items
    return items


def _parse_author_contents_from_member_lists(
    answers_payload: dict[str, Any],
    articles_payload: dict[str, Any],
    *,
    limit: int,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for payload, kind in ((answers_payload, "answer"), (articles_payload, "article")):
        entries = payload.get("data") if isinstance(payload.get("data"), list) else []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            item = _build_item_from_detail_payload(entry, kind, rank=len(items) + 1)
            item_id = clean_text(item.get("id", ""))
            if not item_id or item_id in seen:
                continue
            seen.add(item_id)
            item["rank"] = len(items) + 1
            items.append(item)
            if len(items) >= limit:
                return items
    return items


def _build_item_from_suggest_object(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    query = clean_text(entry.get("query", ""))
    if not query:
        query = clean_text(entry.get("display_query", ""))
    query_id = clean_text(entry.get("id", "") or entry.get("raw_id", ""))
    url = SEARCH_WEB_URL.format(query=quote_plus(query)) if query else HOME_URL
    return {
        "id": query_id or str(rank),
        "title": query,
        "summary": query,
        "content": "",
        "url": url,
        "cover": clean_text(entry.get("icon_url", "")),
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": rank,
        "hot_value": None,
        "hot_text": "",
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": None,
        "source_type": "suggest",
        "result_type": "suggest",
        "tags": [],
    }


def _fallback_search_suggest_items(session: requests.Session, *, keyword: str, limit: int) -> list[dict[str, Any]]:
    payload = _request_json(
        session,
        SEARCH_SUGGEST_API_URL,
        params={"q": keyword},
        referer=SEARCH_WEB_URL.format(query=quote_plus(keyword)),
    )
    entries = payload.get("suggest") if isinstance(payload.get("suggest"), list) else []
    result: list[dict[str, Any]] = []
    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict):
            continue
        item = _build_item_from_suggest_object(entry, rank=index)
        text = " ".join(
            [
                clean_text(item.get("title", "")),
                clean_text(item.get("summary", "")),
                clean_text(item.get("content", "")),
            ]
        )
        if not _keyword_matches_text(text, keyword):
            continue
        result.append(item)
        if len(result) >= limit:
            break
    for index, item in enumerate(result, start=1):
        item["rank"] = index
    return result


def _build_item_from_pin(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    author = entry.get("author") if isinstance(entry.get("author"), dict) else {}
    content = clean_text(entry.get("content", "") or entry.get("excerpt", ""))
    item_id = clean_text(entry.get("id", ""))
    updated = entry.get("updated") or entry.get("updated_time") or entry.get("created")
    pin_url = ""
    if item_id and author.get("url_token"):
        pin_url = f"https://www.zhihu.com/pin/{item_id}"
    return {
        "id": item_id or str(rank),
        "title": content[:60] if content else "想法",
        "summary": content,
        "content": content,
        "url": pin_url,
        "cover": "",
        "author_name": clean_text(author.get("name", "") or author.get("nickname", "")),
        "author_id": clean_text(author.get("id", "") or author.get("url_token", "")),
        "publish_time": _timestamp_to_iso(updated),
        "rank": rank,
        "hot_value": _to_int(entry.get("reaction_count") or entry.get("comment_count")),
        "hot_text": "",
        "comment_count": _to_int(entry.get("comment_count")),
        "like_count": _to_int(entry.get("reaction_count")),
        "share_count": _to_int(entry.get("share_count")),
        "collect_count": None,
        "view_count": _to_int(entry.get("view_count")),
        "source_type": "pin",
        "result_type": "real" if content else "preview",
        "tags": [],
    }


def _fallback_author_items_from_pins(
    session: requests.Session,
    *,
    author_id: str,
    offset: int,
    limit: int,
) -> tuple[list[dict[str, Any]], bool, dict[str, Any]]:
    payload = _request_json(
        session,
        MEMBER_PINS_API_URL.format(author_id=author_id),
        params={"limit": limit, "offset": offset},
        referer=PEOPLE_URL_TEMPLATE.format(author_id=author_id),
    )
    entries = payload.get("data") if isinstance(payload.get("data"), list) else []
    items: list[dict[str, Any]] = []
    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict):
            continue
        item = _build_item_from_pin(entry, rank=index)
        if not clean_text(item.get("id", "")):
            continue
        items.append(item)
        if len(items) >= limit:
            break
    paging = payload.get("paging") if isinstance(payload.get("paging"), dict) else {}
    has_more = not bool(paging.get("is_end")) and bool(paging.get("next") or len(entries) >= limit)
    return items, has_more, payload


def _fallback_hot_items(session: requests.Session, limit: int) -> list[dict[str, Any]]:
    payload = _request_json(session, HOT_LIST_API_URL, referer=HOME_URL)
    entries = payload.get("data") if isinstance(payload.get("data"), list) else []
    return [
        _build_hot_item(entry, rank=index)
        for index, entry in enumerate(entries[:limit], start=1)
        if isinstance(entry, dict)
    ]


def _fallback_feed_items(session: requests.Session, *, offset: int, limit: int) -> list[dict[str, Any]]:
    payload = _request_json(
        session,
        FEED_LIST_API_URL,
        params={"limit": limit, "offset": offset, "desktop": "true"},
        referer=HOME_URL,
    )
    entries = payload.get("data") if isinstance(payload.get("data"), list) else []
    return [
        _build_feed_item(entry, rank=index)
        for index, entry in enumerate(entries[:limit], start=1)
        if isinstance(entry, dict)
    ]


def _fallback_guest_pool_items(
    session: requests.Session,
    *,
    start_offset: int,
    pages: int,
    page_size: int,
    include_hot: bool = True,
) -> list[dict[str, Any]]:
    pool: list[dict[str, Any]] = []
    if include_hot:
        try:
            pool.extend(_fallback_hot_items(session, max(30, page_size * 2)))
        except RuntimeError:
            pass
    for step in range(max(1, pages)):
        offset = max(0, start_offset + step * page_size)
        try:
            items = _fallback_feed_items(session, offset=offset, limit=page_size)
        except RuntimeError:
            continue
        if not items:
            continue
        pool.extend(items)
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in pool:
        item_id = clean_text(item.get("id", ""))
        item_url = clean_text(item.get("url", ""))
        key = item_id or item_url
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(item)
    for index, item in enumerate(result, start=1):
        item["rank"] = index
    return result


def _search_from_hot_feed(
    session: requests.Session,
    *,
    keyword: str,
    offset: int,
    limit: int,
) -> list[dict[str, Any]]:
    keyword_lower = keyword.lower()
    pool = _fallback_guest_pool_items(
        session,
        start_offset=offset,
        pages=get_fallback_feed_scan_pages(),
        page_size=max(get_fallback_feed_page_size(), limit * 2),
        include_hot=True,
    )
    matched: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in pool:
        text = " ".join(
            [
                clean_text(item.get("title", "")),
                clean_text(item.get("summary", "")),
                clean_text(item.get("content", "")),
                clean_text(item.get("author_name", "")),
            ]
        ).lower()
        item_id = clean_text(item.get("id", ""))
        if not _keyword_matches_text(text, keyword_lower) or not item_id or item_id in seen:
            continue
        seen.add(item_id)
        matched.append(item)
        if len(matched) >= limit:
            break
    for index, item in enumerate(matched, start=1):
        item["rank"] = index
    return matched


def _fallback_external_search_items(keyword: str, *, limit: int) -> list[dict[str, Any]]:
    try:
        response = requests.get(
            EXTERNAL_SEARCH_URL,
            params={"q": f"site:zhihu.com {keyword} 知乎", "format": "rss"},
            headers={
                "User-Agent": get_user_agent(),
                "Accept-Language": "zh-CN,zh;q=0.9",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException:
        return []
    if response.status_code != 200:
        return []
    xml_text = response.text
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for block in re.findall(r"<item>(.*?)</item>", xml_text, re.S):
        link_match = re.search(r"<link>(.*?)</link>", block, re.S)
        title_match = re.search(r"<title>(.*?)</title>", block, re.S)
        desc_match = re.search(r"<description>(.*?)</description>", block, re.S)
        link = html_lib.unescape(clean_text(link_match.group(1))) if link_match else ""
        if not link.startswith(("https://www.zhihu.com/", "https://zhuanlan.zhihu.com/")):
            continue
        item_kind, item_id, normalized_url = _extract_content_target("", link)
        if not item_id or item_id in seen:
            continue
        seen.add(item_id)
        title = html_lib.unescape(clean_text(title_match.group(1))) if title_match else ""
        summary = html_lib.unescape(clean_text(desc_match.group(1))) if desc_match else ""
        text = " ".join([title, summary])
        if not _keyword_matches_text(text, keyword):
            continue
        item = {
            "id": item_id,
            "title": title or summary or item_id,
            "summary": summary or title,
            "content": summary or title,
            "url": normalized_url or link,
            "cover": "",
            "author_name": "",
            "author_id": "",
            "publish_time": "",
            "rank": len(items) + 1,
            "hot_value": None,
            "hot_text": "",
            "comment_count": None,
            "like_count": None,
            "share_count": None,
            "collect_count": None,
            "view_count": None,
            "source_type": item_kind or "external_search",
            "result_type": "real" if (summary or title) else "preview",
            "tags": [],
        }
        cached_item = _find_cached_item(item_id, normalized_url or link)
        if isinstance(cached_item, dict):
            item["author_name"] = clean_text(cached_item.get("author_name", "") or item.get("author_name", ""))
            item["author_id"] = _normalize_author_id(cached_item.get("author_id", "") or item.get("author_id", ""))
            if clean_text(cached_item.get("content", "")):
                item["content"] = clean_text(cached_item.get("content", ""))
            if clean_text(cached_item.get("summary", "")):
                item["summary"] = clean_text(cached_item.get("summary", ""))
        items.append(item)
        if len(items) >= limit:
            break
    return items


def _find_detail_from_hot_feed(
    session: requests.Session,
    *,
    kind: str,
    content_id: str,
    target_url: str,
) -> dict[str, Any] | None:
    candidates = _fallback_guest_pool_items(
        session,
        start_offset=0,
        pages=get_fallback_feed_scan_pages(),
        page_size=get_fallback_feed_page_size(),
        include_hot=True,
    )
    target_id = clean_text(content_id)
    normalized_url = clean_text(target_url)
    for item in candidates:
        item_id = clean_text(item.get("id", ""))
        item_url = clean_text(item.get("url", ""))
        if item_id and item_id == target_id:
            return item
        if target_id and item_url and target_id in item_url:
            return item
        if normalized_url and item_url and normalized_url == item_url:
            return item
        if kind == "question":
            question_match = QUESTION_RE.search(item_url)
            if question_match and question_match.group(1) == target_id:
                return item
    return None


def _fallback_author_items_from_cache(*, author_id: str, author_name: str, limit: int) -> list[dict[str, Any]]:
    cache = _load_cache()
    cache_items = cache.get("items") if isinstance(cache.get("items"), dict) else {}
    cache_index = cache.get("item_index") if isinstance(cache.get("item_index"), list) else []
    norm_author_id = clean_text(author_id)
    norm_author_name = clean_text(author_name).lower()
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for key in reversed(cache_index):
        candidate = cache_items.get(key)
        if not isinstance(candidate, dict) or not _is_fresh(candidate.get("_cached_at")):
            continue
        item_id = clean_text(candidate.get("id", "")) or clean_text(key)
        if not item_id or item_id in seen:
            continue
        candidate_author_id = clean_text(candidate.get("author_id", ""))
        candidate_author_name = clean_text(candidate.get("author_name", "")).lower()
        matched = False
        if norm_author_id and candidate_author_id and (
            norm_author_id == candidate_author_id
            or norm_author_id in candidate_author_id
            or candidate_author_id in norm_author_id
        ):
            matched = True
        if not matched and norm_author_name and candidate_author_name and (
            norm_author_name == candidate_author_name
            or norm_author_name in candidate_author_name
            or candidate_author_name in norm_author_name
        ):
            matched = True
        if not matched:
            continue
        restored = dict(candidate)
        restored.pop("_cached_at", None)
        items.append(restored)
        seen.add(item_id)
        if len(items) >= limit:
            break
    for index, item in enumerate(items, start=1):
        item["rank"] = index
    return items


def _author_items_from_hot_feed(
    session: requests.Session,
    *,
    author_id: str,
    author_name: str,
    offset: int,
    limit: int,
) -> list[dict[str, Any]]:
    pool = _fallback_guest_pool_items(
        session,
        start_offset=offset,
        pages=get_fallback_feed_scan_pages(),
        page_size=max(get_fallback_feed_page_size(), limit * 2),
        include_hot=True,
    )
    norm_author_id = clean_text(author_id)
    norm_author_name = clean_text(author_name).lower()
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in pool:
        item_author_id = clean_text(item.get("author_id", ""))
        item_author_name = clean_text(item.get("author_name", "")).lower()
        item_id = clean_text(item.get("id", ""))
        matched = False
        if norm_author_id and item_author_id and (
            norm_author_id == item_author_id
            or norm_author_id in item_author_id
            or item_author_id in norm_author_id
        ):
            matched = True
        if not matched and norm_author_name and item_author_name and (
            norm_author_name == item_author_name
            or norm_author_name in item_author_name
            or item_author_name in norm_author_name
        ):
            matched = True
        if not matched or not item_id or item_id in seen:
            continue
        seen.add(item_id)
        result.append(item)
        if len(result) >= limit:
            break
    for index, item in enumerate(result, start=1):
        item["rank"] = index
    return result


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    session = create_session()
    try:
        payload = _request_json(session, HOT_LIST_API_URL, referer=HOME_URL)
        entries = payload.get("data") if isinstance(payload.get("data"), list) else []
        items = [
            _build_hot_item(entry, rank=index)
            for index, entry in enumerate(entries[:safe_limit], start=1)
            if isinstance(entry, dict)
        ]
        if items:
            _cache_items(items)
            return _build_list_result("hot_list", items, payload)
    except RuntimeError as exc:
        payload = {"error": str(exc)}

    try:
        fallback_items = _fallback_guest_pool_items(
            session,
            start_offset=0,
            pages=max(1, get_fallback_feed_scan_pages()),
            page_size=max(30, safe_limit * 2),
            include_hot=True,
        )
        if fallback_items:
            fallback_items = fallback_items[:safe_limit]
            _cache_items(fallback_items)
            return _build_list_result("hot_list", fallback_items, {"source": "fallback_guest_pool", "payload": payload})
    except RuntimeError:
        pass

    cached_items = _recent_cached_items(limit=safe_limit, offset=0)
    if cached_items:
        return _build_list_result(
            "hot_list",
            cached_items,
            {"source": "recent_cache"},
            has_more=len(cached_items) >= safe_limit,
            next_cursor="",
        )

    return _build_list_result(
        "hot_list",
        [],
        {
            "source": "unavailable",
            "payload": payload,
            "message": "知乎游客态热榜当前受限",
        },
        has_more=False,
        next_cursor="",
    )


def fetch_feed_list_data(*, channel: str, cursor: str, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    normalized_channel = clean_text(channel).lower()
    allowed_channels = {"", "all", "recommend", "recommended", "hot", "推荐"}
    if normalized_channel not in allowed_channels:
        return _build_list_result(
            "feed_list",
            [],
            {
                "reason": "invalid_channel",
                "channel": clean_text(channel),
            },
            has_more=False,
            next_cursor="",
        )
    safe_limit = _normalize_limit(limit)
    offset = _parse_offset_cursor(cursor)
    session = create_session()
    try:
        payload = _request_json(
            session,
            FEED_LIST_API_URL,
            params={
                "limit": safe_limit,
                "offset": offset,
                "desktop": "true",
            },
            referer=HOME_URL,
        )
        entries = payload.get("data") if isinstance(payload.get("data"), list) else []
        items = [
            _build_feed_item(entry, rank=index)
            for index, entry in enumerate(entries[:safe_limit], start=1)
            if isinstance(entry, dict)
        ]
        if items:
            _cache_items(items)
            paging = payload.get("paging") if isinstance(payload.get("paging"), dict) else {}
            has_more = (not bool(paging.get("is_end"))) and bool(paging.get("next") or len(entries) >= safe_limit)
            next_cursor = str(offset + len(entries[:safe_limit])) if has_more else ""
            raw = dict(payload)
            raw["request"] = {"offset": offset}
            return _build_list_result("feed_list", items, raw, has_more=has_more, next_cursor=next_cursor)
    except RuntimeError as exc:
        payload = {"error": str(exc)}

    try:
        fallback_items = _fallback_guest_pool_items(
            session,
            start_offset=offset,
            pages=max(1, get_fallback_feed_scan_pages()),
            page_size=max(30, safe_limit * 2),
            include_hot=True,
        )
        if fallback_items:
            fallback_items = fallback_items[:safe_limit]
            _cache_items(fallback_items)
            return _build_list_result(
                "feed_list",
                fallback_items,
                {
                    "source": "fallback_guest_pool",
                    "payload": payload,
                    "request": {"offset": offset},
                },
                has_more=len(fallback_items) >= safe_limit,
                next_cursor=str(offset + len(fallback_items)) if len(fallback_items) >= safe_limit else "",
            )
    except RuntimeError:
        pass

    cached_items = _recent_cached_items(limit=safe_limit, offset=offset)
    if cached_items:
        return _build_list_result(
            "feed_list",
            cached_items,
            {
                "source": "recent_cache",
                "request": {"offset": offset},
            },
            has_more=len(cached_items) >= safe_limit,
            next_cursor=str(offset + len(cached_items)) if len(cached_items) >= safe_limit else "",
        )

    return _build_list_result(
        "feed_list",
        [],
        {
            "source": "unavailable",
            "payload": payload,
            "request": {"offset": offset},
            "message": "知乎游客态推荐流当前受限",
        },
        has_more=False,
        next_cursor="",
    )


def fetch_search_content_data(
    *,
    query: str,
    cursor: str,
    limit: int,
    real_only: bool = True,
    allow_fallback: bool = False,
) -> dict[str, Any]:
    keyword = clean_text(query)
    if not keyword:
        return _build_list_result(
            "search",
            [],
            {"query": "", "reason": "empty_query"},
            has_more=False,
            next_cursor="",
        )
    effective_real_only = bool(real_only) and not bool(allow_fallback)
    safe_limit = _normalize_limit(limit)
    offset = _parse_offset_cursor(cursor)
    session = create_session()
    payload: dict[str, Any] = {}
    entries: list[Any] = []
    source = "api"
    try:
        payload = _request_json(
            session,
            SEARCH_API_URL,
            params={
                "t": "general",
                "q": keyword,
                "correction": 1,
                "offset": offset,
                "limit": safe_limit,
                "lc_idx": 0,
                "show_all_topics": 0,
                "search_hash_id": 0,
            },
            referer=SEARCH_WEB_URL.format(query=quote_plus(keyword)),
        )
        entries = payload.get("data") if isinstance(payload.get("data"), list) else []
    except RuntimeError:
        payload = {"error": "search_api_failed"}
        source = "api_failed"
    items = [
        _build_item_from_search_object(entry, rank=index)
        for index, entry in enumerate(entries[:safe_limit], start=1)
        if isinstance(entry, dict)
    ]
    if not items:
        try:
            html = _request_text(
                session,
                SEARCH_WEB_URL.format(query=quote_plus(keyword)),
                referer=HOME_URL,
            )
            _, payloads = _html_payloads(html)
            items = _extract_content_candidates_from_payloads(payloads, limit=safe_limit)
            if items:
                source = "html"
        except RuntimeError:
            items = []
    if not items:
        items = _fallback_external_search_items(keyword, limit=safe_limit)
        if items:
            source = "public_search"
    if not items:
        try:
            items = _search_from_hot_feed(
                session,
                keyword=keyword,
                offset=offset,
                limit=safe_limit,
            )
            if items:
                source = "public_hot_feed_search"
        except RuntimeError:
            items = []
    if not items:
        items = _search_cached_items(keyword, limit=safe_limit, real_only=True)
        if items:
            source = "cache_exact_match"
    if items:
        keyword_lower = keyword.lower()
        matched_items: list[dict[str, Any]] = []
        for item in items:
            text = " ".join(
                [
                    clean_text(item.get("title", "")),
                    clean_text(item.get("summary", "")),
                    clean_text(item.get("content", "")),
                    clean_text(item.get("author_name", "")),
                ]
            ).lower()
            if keyword_lower in text:
                matched_items.append(item)
        if matched_items:
            items = matched_items
    if items:
        items = sorted(items, key=_search_priority)
        for index, item in enumerate(items, start=1):
            item["rank"] = index
    if not items:
        return _build_list_result(
            "search",
            [],
            {
                "source": "no_real_result" if effective_real_only else "no_result",
                "payload": payload,
                "request": {
                    "query": keyword,
                    "offset": offset,
                    "limit": safe_limit,
                    "real_only": effective_real_only,
                    "allow_fallback": allow_fallback,
                },
            },
            has_more=False,
            next_cursor="",
        )
    _cache_items(items)
    paging = payload.get("paging") if isinstance(payload.get("paging"), dict) else {}
    has_more = (not bool(paging.get("is_end"))) and (bool(paging.get("next")) or len(entries) >= safe_limit)
    next_cursor = str(offset + len(items)) if has_more else ""
    return _build_list_result(
        "search",
        items,
        {
            "source": source,
            "payload": payload,
            "request": {
                "query": keyword,
                "offset": offset,
                "limit": safe_limit,
                "real_only": effective_real_only,
                "allow_fallback": allow_fallback,
            },
        },
        has_more=has_more,
        next_cursor=next_cursor,
    )


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    kind, resolved_id, target_url = _extract_content_target(content_id, url)
    if not kind or not resolved_id:
        return _build_detail_result({}, {"reason": "empty_input"})

    session = create_session()
    detail_url = ""
    if kind == "question":
        detail_url = QUESTION_API_URL.format(content_id=resolved_id)
    elif kind == "answer":
        detail_url = ANSWER_API_URL.format(content_id=resolved_id)
    elif kind == "article":
        detail_url = ARTICLE_API_URL.format(content_id=resolved_id)

    if detail_url:
        try:
            payload = _request_json(session, detail_url, referer=target_url or HOME_URL)
            item = _build_item_from_detail_payload(payload, kind, rank=1)
            if item.get("id") or item.get("title"):
                if target_url:
                    item["url"] = target_url
                _cache_items([item])
                return _build_detail_result(item, {"source": "api", "payload": payload})
        except RuntimeError:
            pass

    try:
        html = _request_text(session, target_url, referer=HOME_URL)
        html_title, payloads = _html_payloads(html)
        best_payload = _find_best_content_payload(payloads)
        if isinstance(best_payload, dict):
            html_item = _build_item_from_detail_payload(best_payload, kind, rank=1)
            if target_url:
                html_item["url"] = target_url
                _cache_items([html_item])
                return _build_detail_result(html_item, {"source": "html", "html_title": html_title, "payloads": payloads})
    except RuntimeError:
        pass
    hot_feed_item = _find_detail_from_hot_feed(
        session,
        kind=kind,
        content_id=resolved_id,
        target_url=target_url,
    )
    if isinstance(hot_feed_item, dict) and hot_feed_item.get("id"):
        return _build_detail_result(
            hot_feed_item,
            {"source": "public_hot_feed_match", "content_id": resolved_id, "url": target_url},
        )
    cached_item = _find_cached_item(resolved_id, target_url)
    if isinstance(cached_item, dict) and cached_item.get("id"):
        return _build_detail_result(
            cached_item,
            {"source": "cache_match", "content_id": resolved_id, "url": target_url},
        )
    return _build_detail_result({}, {"reason": "content_blocked_or_unavailable", "content_id": resolved_id, "url": target_url})


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    token, page_url = _extract_author_token(author_id, url)
    if not token:
        return _build_author_result({}, {"reason": "empty_input"})

    session = create_session()
    member_url = MEMBER_API_URL.format(author_id=token)
    include_fields = "answer_count,articles_count,follower_count,following_count,badge[?(type=best_answerer)].topics"
    try:
        payload = _request_json(
            session,
            member_url,
            params={"include": include_fields},
            referer=page_url,
        )
        author = _build_author_profile(payload, page_url)
        _cache_author_profile(token, author)
        return _build_author_result(author, {"source": "api", "payload": payload})
    except RuntimeError as primary_error:
        try:
            html = _request_text(session, page_url, referer=HOME_URL)
            _, payloads = _html_payloads(html)
            data = _find_best_author_payload(payloads)
            if not isinstance(data, dict):
                raise RuntimeError("未能解析知乎作者主页")
            author = _build_author_profile(data, page_url)
            _cache_author_profile(token, author)
            return _build_author_result(author, {"source": "html", "payloads": payloads})
        except RuntimeError:
            cached_author = _get_cached_author_profile(token)
            if isinstance(cached_author, dict) and cached_author.get("id"):
                return _build_author_result(cached_author, {"source": "profile_cache"})
            cached_item_author = _author_from_cached_items(token, page_url)
            if cached_item_author is not None:
                return _build_author_result(cached_item_author, {"source": "content_cache"})
            return _build_author_result(
                {},
                {
                    "source": "unavailable",
                    "author_id": token,
                    "error": str(primary_error),
                    "message": "知乎游客态作者主页当前受限",
                },
            )


def fetch_author_content_list_data(*, author_id: str, url: str, cursor: str, limit: int) -> dict[str, Any]:
    token, page_url = _extract_author_token(author_id, url)
    if not token:
        return _build_list_result("author_content_list", [], {"reason": "empty_input"}, has_more=False, next_cursor="")

    profile_name = ""
    try:
        profile_result = fetch_author_profile_data(author_id=token, url=page_url)
        profile_name = clean_text(profile_result.get("author", {}).get("name", ""))
    except RuntimeError:
        profile_name = ""

    safe_limit = _normalize_limit(limit)
    offset = _parse_offset_cursor(cursor)
    session = create_session()
    source = ""

    activities_payload: dict[str, Any] = {}
    answers_payload: dict[str, Any] = {}
    articles_payload: dict[str, Any] = {}
    html_payloads: list[Any] = []
    html_title = ""

    items: list[dict[str, Any]] = []
    has_more = False

    try:
        activities_payload = _request_json(
            session,
            PEOPLE_ACTIVITIES_API_URL.format(author_id=token),
            params={"limit": safe_limit, "offset": offset},
            referer=page_url,
        )
        items = _parse_author_content_from_activities(activities_payload, limit=safe_limit)
        paging = activities_payload.get("paging") if isinstance(activities_payload.get("paging"), dict) else {}
        has_more = (not bool(paging.get("is_end"))) and (bool(paging.get("next")) or len(items) >= safe_limit)
        source = "activities_api"
    except RuntimeError:
        items = []

    if not items:
        try:
            answers_payload = _request_json(
                session,
                MEMBER_ANSWERS_API_URL.format(author_id=token),
                params={"limit": safe_limit, "offset": offset},
                referer=page_url,
            )
        except RuntimeError:
            answers_payload = {}
        try:
            articles_payload = _request_json(
                session,
                MEMBER_ARTICLES_API_URL.format(author_id=token),
                params={"limit": safe_limit, "offset": offset},
                referer=page_url,
            )
        except RuntimeError:
            articles_payload = {}

        items = _parse_author_contents_from_member_lists(
            answers_payload,
            articles_payload,
            limit=safe_limit,
        )
        answers_len = len(answers_payload.get("data") or []) if isinstance(answers_payload.get("data"), list) else 0
        articles_len = len(articles_payload.get("data") or []) if isinstance(articles_payload.get("data"), list) else 0
        has_more = answers_len >= safe_limit or articles_len >= safe_limit
        source = "member_api"

    if not items:
        try:
            html = _request_text(session, f"{page_url}/answers", referer=page_url)
            html_title, html_payloads = _html_payloads(html)
            items = _extract_content_candidates_from_payloads(
                html_payloads,
                limit=safe_limit,
                author_token=token,
            )
            has_more = len(items) >= safe_limit
            source = "html"
        except RuntimeError:
            items = []

    if not items:
        try:
            items, has_more, pins_payload = _fallback_author_items_from_pins(
                session,
                author_id=token,
                offset=offset,
                limit=safe_limit,
            )
            if items:
                source = "member_pins_api"
                answers_payload = {"pins_payload": pins_payload}
        except RuntimeError:
            items = []

    if not items:
        items = _fallback_author_items_from_cache(
            author_id=token,
            author_name=profile_name,
            limit=safe_limit,
        )
        if items:
            source = "cache_exact_author"
            has_more = False

    if items:
        norm_author_id = clean_text(token)
        norm_author_name = clean_text(profile_name).lower()
        filtered_items: list[dict[str, Any]] = []
        for item in items:
            item_author_id = clean_text(item.get("author_id", ""))
            item_author_name = clean_text(item.get("author_name", "")).lower()
            if item_author_id == "0":
                continue
            matched = False
            if norm_author_id and item_author_id and norm_author_id == item_author_id:
                matched = True
            if not matched and norm_author_name and item_author_name and norm_author_name == item_author_name:
                matched = True
            if matched:
                filtered_items.append(item)
        items = filtered_items

    if not items:
        return _build_list_result(
            "author_content_list",
            [],
            {
                "source": "unavailable",
                "reason": "author_content_blocked_or_unavailable",
                "author_id": token,
                "offset": offset,
                "activities_payload": activities_payload,
                "answers_payload": answers_payload,
                "articles_payload": articles_payload,
                "html_title": html_title,
                "html_payloads": html_payloads,
            },
            has_more=False,
            next_cursor="",
        )

    for index, item in enumerate(items, start=1):
        item["rank"] = index

    _cache_items(items)
    _cache_author_items(token, profile_name, items)

    return _build_list_result(
        "author_content_list",
        items,
        {
            "source": source,
            "author_id": token,
            "offset": offset,
            "activities_payload": activities_payload,
            "answers_payload": answers_payload,
            "articles_payload": articles_payload,
            "html_title": html_title,
            "html_payloads": html_payloads,
        },
        has_more=has_more,
        next_cursor=str(offset + len(items)) if has_more else "",
    )


mcp = FastMCP(
    "ZHIHU_MCP",
    instructions=(
        "Astron Zhihu MCP server，基于知乎游客态公开接口和公开页面提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(ctx: Context, limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    """
    获取知乎热榜。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取知乎推荐流。

    参数：
    - channel: 频道参数，当前保留。
    - cursor: 分页游标，按 offset 处理。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_feed_list_data(channel=channel, cursor=cursor, limit=limit, refresh=refresh)


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
    real_only: bool = True,
    allow_fallback: bool = False,
) -> dict[str, Any]:
    """
    搜索知乎公开内容。

    参数：
    - query: 搜索关键词。
    - cursor: 分页游标，按 offset 处理。
    - limit: 返回条数，范围建议 1-50。
    - real_only: 是否只返回真实搜索内容，默认 True。
    - allow_fallback: 兼容保留参数；当前默认实现不会用 suggest / 热榜 / 缓存回退顶替搜索结果。
    """
    del ctx
    return fetch_search_content_data(
        query=query,
        cursor=cursor,
        limit=limit,
        real_only=real_only,
        allow_fallback=allow_fallback,
    )


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取知乎内容详情。

    参数：
    - content_id: 内容 ID。支持 question/answer/article 前缀，例如 answer:123。
    - url: 内容完整 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取知乎作者主页。

    参数：
    - author_id: 作者 token。
    - url: 作者主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


def main() -> None:
    """Run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
