# Integration Digest for July 2025

![Cover image for Integration Digest for July 2025](https://media2.dev.to/dynamic/image/width=1000,height=420,fit=cover,gravity=auto,format=auto/https%3A%2F%2Fdev-to-uploads.s3.amazonaws.com%2Fuploads%2Farticles%2Fvnxysypltq4b1utvjfry.png)

## Articles

🔍 [10 Top API Testing Tools For 2025](https://nordicapis.com/10-top-api-testing-tools-for-2025/)

*Covers ten top API testing tools for 2025, including Postman, Katalon Studio, SoapUI, JMeter, and others, evaluating their benefits and drawbacks for different testing scenarios. The article emphasizes that the best tool depends on your specific needs and provides recommendations for choosing between different options.*

🔍 [3 Ways to String Multiple APIs Together](https://nordicapis.com/3-ways-to-string-multiple-apis-together/)

*Explores three approaches for connecting multiple APIs: serialized flows (piping output from one API to another), specification-driven sequences using Arazzo Specification for formal workflow definition, and AI-orchestrated connections using LLMs to determine next API calls. The article emphasizes that the choice depends on your system architecture and notes that API connectivity is rapidly evolving with new solutions like Model Context Protocol.*

🔍 [API Governance Made Simple: 8 Rules to Avoid API Chaos in Your System](https://medium.com/@neliia/api-governance-made-simple-8-rules-to-avoid-api-chaos-in-your-system-3bf45c24dc06)

*Presents eight key rules for effective API governance: centralization of standards, API contracts using specifications like OpenAPI, implementation guidelines for consistency, security policies, automation for compliance verification, versioning strategies, deprecation policies, and API discovery through centralized catalogs. The article emphasizes that proper governance keeps APIs consistent, secure, and reduces development costs while avoiding chaos in distributed systems.*

🔍 [API Specificity with Overlays and Enums](https://lornajane.net/posts/2025/api-specificity-with-overlays-and-enums)

*Demonstrates how to use OpenAPI Overlays to add enum constraints to generic API specifications, making them more specific for particular implementations. The article shows how to apply overlays using tools like Speakeasy CLI to transform a basic genre field into a constrained list of specific values.*

🔍 [Defining Mock Data Using OpenAPI Overlays](https://apichangelog.substack.com/p/defining-mock-data-using-openapi-overlays)

*Explores how OpenAPI Overlays can be used to add mock data examples to API specifications without modifying the original document. The approach allows teams to keep comprehensive examples separate from the core API definition while providing meaningful test data for documentation and testing.*

🔍 [Intruder Introduces Autoswagger: The Free Tool To Expose Hidden API Authorization Flaws](https://www.intruder.io/research/broken-authorization-apis-autoswagger)

*Introduces Autoswagger, a free tool for discovering and testing hidden API endpoints that may have authorization vulnerabilities. The tool analyzes Swagger/OpenAPI documentation to find undocumented endpoints and tests them for authorization flaws that could expose sensitive data.*

🔍 [Most RESTful APIs aren't really RESTful](https://florian-kraemer.net//software-architecture/2025/07/07/Most-RESTful-APIs-are-not-really-RESTful.html)

*Explains how most APIs labeled as "RESTful" fail to implement key REST principles, particularly HATEOAS (Hypermedia as the Engine of Application State). The article outlines Roy Fielding's six rules for true REST APIs and discusses why practical trade-offs often lead to simpler, documentation-driven approaches instead.*

🔍 [On the Behavior of OpenAPI's oneOf](https://apichangelog.substack.com/p/on-the-behavior-of-openapi-oneof)

*Explains how OpenAPI's oneOf keyword works for defining polymorphism, requiring data to validate against exactly one schema from a list. The article covers common challenges like avoiding multiple schema matches and recommends using discriminator properties and additionalProperties controls for better validation.*

🔍 [OpenAPI 3.0 vs. OpenAPI 3.1: What's Changed and Why It's Important](https://document360.com/blog/openapi-3-0-vs-openapi-3-1/)

*Compares OpenAPI 3.0 and 3.1, highlighting key improvements including full JSON Schema compatibility, better webhook support, and enhanced data modeling capabilities. The article explains why teams should consider upgrading to 3.1 for better tooling support and more flexible API documentation.*

🔍 [OpenAPI 3.2 - What to expect?](https://bump.sh/blog/openapi-3-2-what-to-expect/)

*Previews upcoming features in OpenAPI 3.2, which will be fully backwards compatible with 3.1 while adding new OAuth flow support, display name extensions, and additional HTTP methods. The release is expected in August 2025 and focuses on community-requested improvements.*

🔍 [The 5 Best API Docs Tools in 2025](https://apisyouwonthate.com/blog/top-5-best-api-docs-tools/)

*Reviews five leading API documentation tools including Redoc, Scalar, Stoplight Elements, Bump.sh, and ReadMe, comparing their features, pricing, and ideal use cases. The article emphasizes that the best choice depends on factors like team size, budget, and whether you need single or multiple API support.*

🔍 [The company that created Kafka is replacing it with a new solution](https://vutr.substack.com/p/the-company-that-created-kafka-is)

*Details how LinkedIn built Northguard as a replacement for Kafka to address scalability challenges at their massive scale of 150 clusters and 17PB of daily data. The new system uses segment-based replication instead of partition-based replication and includes Xinfra as a virtualization layer to enable gradual migration from Kafka.*

🔍 [The Role of AI Gateways and How They Work With APIs](https://nordicapis.com/the-role-of-ai-gateways-and-how-they-work-with-apis/)

*Explains how AI gateways act as middleware layers between applications and AI services, providing centralized access management, enhanced security, intelligent traffic routing, and cost control. The article covers practical use cases including enterprise AI platforms, multi-provider orchestration for SaaS products, mobile app content moderation, and government compliance scenarios, emphasizing their crucial role in production-scale AI deployments.*

🔍 [Why API Gateways Shouldn't Handle Identity Alone](https://nordicapis.com/why-api-gateways-shouldnt-handle-identity-alone/)

*Argues that API gateways should focus on traffic management rather than complex identity operations, which should be delegated to specialized identity providers. The article discusses patterns like token introspection, phantom tokens, and Backend-for-Frontend to maintain clean separation between transport and security concerns.*

### Apache Kafka

🔍 [Exploring Kafka Streams Internals](https://cefboud.com/posts/kafka-streams-internals/)

*Deep dives into Kafka Streams internal architecture, explaining how stream processing topology is built, how state stores work, and how rebalancing affects stream applications. The article provides insights into performance optimization and troubleshooting common issues with Kafka Streams applications.*

🔍 [Kafka 4.0 unveiled: Key changes and how they impact developers](https://www.instaclustr.com/blog/kafka-4-0-unveiled-key-changes-and-how-they-impact-developers/)

*Covers major changes in Kafka 4.0 including the deprecation of ZooKeeper, introduction of KRaft mode as default, improved performance, and enhanced security features. The article explains how these changes affect existing deployments and provides guidance for developers planning migrations.*

🔍 [Kafka Exactly-Once Semantics: How It Really Works](https://medium.com/@razkevich8/kafka-exactly-once-semantics-how-it-really-works-5bd4c3cd0178)

*Explains how Kafka implements exactly-once message processing through producer idempotency with sequence numbers, transactional APIs for multi-partition atomicity, and sophisticated broker coordination using Producer IDs and epoch numbers. The article covers the technical mechanisms from producer, broker, and consumer perspectives, including performance implications and when exactly-once semantics are truly necessary versus overkill.*

🔍 [Understanding Apache Kafka® Performance: Diskless Topics Deep Dive](https://aiven.io/blog/understanding-apache-kafka-performance-diskless-topics-deep-dive)

*Analyzes performance characteristics of Kafka's diskless topics that store data directly to object storage, showing how they achieve 80% cost reduction and nine-nines durability but require higher latency tolerance. The article provides detailed testing results, tuning recommendations, and explains the fundamental tradeoffs between throughput patterns, batching behavior, and end-to-end latency in diskless architecture.*

### Azure

🔍 [APIOps for Azure API Management](https://medium.com/versent-tech-blog/apiops-for-azure-api-management-bcd324a0117d)

*Introduces APIOps, an open-source project providing automated deployment pipelines for Azure API Management configurations through extractor and publisher pipelines. The approach enables consistent promotion of API configurations from development to production environments, supporting both direct configuration changes and source control-driven workflows while ensuring all environments reflect the same validated settings.*

### Kong

🔍 [Kong Service Catalog: The Producer Side of API Discovery](https://konghq.com/blog/product-releases/service-catalog-deep-dive)

*Introduces Kong's Service Catalog for API discovery, enabling development teams to publish, document, and share APIs across organizations. The feature helps bridge the gap between API producers and consumers by providing centralized visibility into available services and their documentation.*

## Mergers & Acquisitions

🤝 [Gravitee Acquires Ambassador](https://www.gravitee.io/blog/gravitee-acquires-ambassador-to-accelerate-agentic-api-event-management)

*Gravitee has acquired Ambassador to accelerate its vision for Agentic API and Event Management, adding Edge Stack and Blackbird to create a unified platform for building, securing, and governing APIs, event streams, and AI interactions. The acquisition strengthens Gravitee's leadership position and brings deep expertise with a strong North American footprint.*

## Releases

🚀 [Apache Camel 4.13](https://camel.apache.org/blog/2025/07/camel413-whatsnew/)

*Apache Camel 4.13 introduces a new Camel Launcher for self-contained executable JARs without JBang, improved REST DSL validation, YAML DSL standardization removing kebab-case, enhanced Kafka transaction support, and Micrometer metrics. The release includes Spring Boot 3.5.3 upgrade, better internal task management, and various connector improvements while maintaining focus on performance and developer experience.*

🚀 [Debezium 3.2](https://debezium.io/blog/2025/07/09/debezium-3-2-final-released/)

*Debezium 3.2 introduces support for Apache Kafka 4.0, enhanced Oracle LogMiner with new unbuffered adapter, improved schema history recovery performance, and OpenLineage integration for metadata tracking. The release includes breaking changes like deprecated configuration removal, new features such as PostgreSQL partition table publishing control, and multiple sink enhancements including Qdrant vector database support.*

🚀 [Traefik Proxy 3.5](https://traefik.io/blog/traefik-proxy-v3-5)

*Traefik Proxy 3.5 introduces an experimental Ingress NGINX Provider for seamless migration from ingress-nginx, a completely rebuilt React-based dashboard, and full Gateway API v1.3 support. The release includes post-quantum cryptography with X25519MLKEM768, enhanced ACME certificate management with OCSP stapling, and improved health check capabilities for better Kubernetes integration.*