# rotmat_to_quaternion
Calculate quaternion with rotation matrix.

## Installation

```bash
pip install rotmat_to_quaternion
```

## Usage

```python
from rotmat_to_quaternion import quaternion_to_rotation_matrix
from rotmat_to_quaternion import rotation_matrix_to_quaternion
import math

# Test quaternion: 90° rotation around Z-axis
q = [math.sqrt(2)/2, 0.0, 0.0, math.sqrt(2)/2]
print("Original quaternion [w,x,y,z]:")
print([round(v, 6) for v in q])

# Convert to rotation matrix
mat = quaternion_to_rotation_matrix(q)
print("\nQuaternion -> Rotation Matrix:")
for row in mat:
    print([round(v, 6) for v in row])

# Convert back to quaternion
q_recovered = rotation_matrix_to_quaternion(mat)
print("\nRotation Matrix -> Quaternion [w,x,y,z]:")
print([round(v, 6) for v in q_recovered])
```
