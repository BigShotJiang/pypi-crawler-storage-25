import math

def quaternion_to_rotation_matrix(q):
    """
    Convert quaternion [w, x, y, z] to 3x3 rotation matrix
    """
    w, x, y, z = q

    wx2 = 2 * w * x
    wy2 = 2 * w * y
    wz2 = 2 * w * z
    xx2 = 2 * x * x
    xy2 = 2 * x * y
    xz2 = 2 * x * z
    yy2 = 2 * y * y
    yz2 = 2 * y * z
    zz2 = 2 * z * z

    r00 = 1 - yy2 - zz2
    r01 = xy2 - wz2
    r02 = xz2 + wy2

    r10 = xy2 + wz2
    r11 = 1 - xx2 - zz2
    r12 = yz2 - wx2

    r20 = xz2 - wy2
    r21 = yz2 + wx2
    r22 = 1 - xx2 - yy2

    return [
        [r00, r01, r02],
        [r10, r11, r12],
        [r20, r21, r22]
    ]


def rotation_matrix_to_quaternion(mat):
    """
    Convert 3x3 rotation matrix to quaternion [w, x, y, z]
    Numerically stable Shoemake algorithm
    """
    r00, r01, r02 = mat[0]
    r10, r11, r12 = mat[1]
    r20, r21, r22 = mat[2]

    tr = r00 + r11 + r22

    if tr > 1e-6:
        s = math.sqrt(tr + 1.0) * 2.0
        w = 0.25 * s
        x = (r21 - r12) / s
        y = (r02 - r20) / s
        z = (r10 - r01) / s
    elif r00 > r11 and r00 > r22:
        s = math.sqrt(1.0 + r00 - r11 - r22) * 2.0
        w = (r21 - r12) / s
        x = 0.25 * s
        y = (r01 + r10) / s
        z = (r02 + r20) / s
    elif r11 > r22:
        s = math.sqrt(1.0 + r11 - r00 - r22) * 2.0
        w = (r02 - r20) / s
        x = (r01 + r10) / s
        y = 0.25 * s
        z = (r12 + r21) / s
    else:
        s = math.sqrt(1.0 + r22 - r00 - r11) * 2.0
        w = (r10 - r01) / s
        x = (r02 + r20) / s
        y = (r12 + r21) / s
        z = 0.25 * s

    return [w, x, y, z]


# ==================== Test ====================
if __name__ == "__main__":
    # Test quaternion: 90° rotation around Z-axis
    q = [math.sqrt(2)/2, 0.0, 0.0, math.sqrt(2)/2]
    print("Original quaternion [w,x,y,z]:")
    print([round(v, 6) for v in q])

    # Convert to rotation matrix
    mat = quaternion_to_rotation_matrix(q)
    print("\nQuaternion -> Rotation Matrix:")
    for row in mat:
        print([round(v, 6) for v in row])

    # Convert back to quaternion
    q_recovered = rotation_matrix_to_quaternion(mat)
    print("\nRotation Matrix -> Quaternion [w,x,y,z]:")
    print([round(v, 6) for v in q_recovered])
