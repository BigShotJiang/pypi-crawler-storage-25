from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="marathi-coref",

    version="0.1.2",

    author="Mansi Jangle",

    description="Marathi Coreference Resolution using Hypergraphs",

    long_description=long_description,

    long_description_content_type="text/markdown",

    url="https://github.com/mansijangle/Marathi_Coreference_Resolution",

    packages=find_packages(),

    install_requires=[
        "stanza"
    ],

    python_requires=">=3.9",
)