import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Any, Tuple

from supertable.query_plan_manager import QueryPlanManager
from supertable.engine.plan_stats import PlanStats
from supertable.monitoring_writer import MonitoringWriter

logger = logging.getLogger(__name__)


def _safe_json(obj: Any) -> str:
    """
    JSON-dump helper that never raises (keeps monitoring path robust).
    Falls back to string representation on failure.
    """
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:  # noqa: BLE001
        try:
            return json.dumps(str(obj), ensure_ascii=False)
        except Exception:  # noqa: BLE001
            return "{}"


def _read_local_json(path: str) -> Dict[str, Any]:
    """
    Read a JSON file from the local filesystem.

    DuckDB writes its profile JSON to a local disk path (via PRAGMA
    profile_output).  This helper reads it back using stdlib I/O,
    avoiding the remote-storage backend which operates on object-store
    keys (S3, MinIO) and would never find a local temp file.
    """
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def extend_execution_plan(
    query_plan_manager: QueryPlanManager,
    role_name: str,
    timing: Dict[str, float] | None,
    plan_stats: PlanStats,
    status: str,
    message: str | None,
    result_shape: Tuple[int, int] | None,
) -> None:
    """
    Extend the DuckDB profile JSON with app timings & stats,
    log a single metric through MonitoringLogger, then delete the raw plan.

    Robustness goals:
    - Never raise from this function (monitoring must not break reads).
    - Handle missing/invalid JSON profile gracefully.
    - Avoid gigantic payloads by JSON-encoding nested parts into strings.

    Note: the plan JSON is read from the *local filesystem* (where DuckDB
    wrote it via PRAGMA profile_output), not from the remote storage backend.
    """

    # Load the raw plan from local disk, if present
    base_plan: Dict[str, Any] = {}
    plan_path = getattr(query_plan_manager, "query_plan_path", None) if query_plan_manager else None
    try:
        if plan_path and os.path.isfile(plan_path):
            base_plan = _read_local_json(plan_path)
        elif plan_path:
            logger.debug("Plan JSON does not exist at %s", plan_path)
    except Exception as e:  # noqa: BLE001
        logger.warning("Could not read plan JSON (%s): %s", plan_path or "?", e)
        base_plan = {}

    # Normalize inputs
    timing = timing or {}
    message = message or ""
    result_shape = result_shape or (0, 0)

    # Stash the parsed plan onto the query_plan_manager so upstream callers
    # (e.g. execute.py API) can include it in the response without re-reading
    # the file (which is deleted below).
    if query_plan_manager is not None:
        query_plan_manager.query_profile = base_plan

    # Build extended (in-memory) representation
    extended_plan = {
        "execution_timings": timing,
        "profile_overview": plan_stats.summary() if hasattr(plan_stats, "summary") else plan_stats.stats,
        "query_profile": base_plan,
    }

    # Prepare flat metric payload for the monitoring table
    try:
        # Extract engine from plan_stats (stored as {"ENGINE": "duckdb_lite"} entry)
        _engine_used = "unknown"
        for _entry in (plan_stats.stats if hasattr(plan_stats, "stats") else []):
            if isinstance(_entry, dict) and "ENGINE" in _entry:
                _engine_used = str(_entry["ENGINE"])
                break

        stats = {
            "query_id": getattr(query_plan_manager, "query_id", ""),
            "query_hash": getattr(query_plan_manager, "query_hash", ""),
            "organization": getattr(query_plan_manager, "organization", ""),
            "super_name": getattr(query_plan_manager, "super_name", ""),
            "role_name": role_name,
            "source_type": getattr(query_plan_manager, "source_type", "api"),
            "recorded_at": datetime.now(timezone.utc).isoformat(),
            "table_name": getattr(query_plan_manager, "original_table", ""),
            "sql": getattr(query_plan_manager, "query", "")[:500],
            "engine": _engine_used,
            "status": status,
            "message": message,
            "result_rows": int(result_shape[0]),
            "result_columns": int(result_shape[1]),
            # Store complex parts as JSON strings to keep row schema flat
            "execution_timings": _safe_json(extended_plan["execution_timings"]),
            "profile_overview": _safe_json(extended_plan["profile_overview"]),
            "query_profile": _safe_json(extended_plan["query_profile"]),
        }
    except Exception as e:  # noqa: BLE001
        logger.error("Failed to build monitoring stats payload: %s", e)
        return  # nothing else to do safely

    # Log the metric (buffered; background writer flushes)
    try:
        with MonitoringWriter(
            super_name=query_plan_manager.super_name,
            organization=query_plan_manager.organization,
            monitor_type="plans",
        ) as monitor:
            monitor.log_metric(stats)
            logger.debug("Extended plan metrics queued for logging.")
    except Exception as e:  # noqa: BLE001
        logger.warning("Monitoring logging failed (non-fatal): %s", e)

    # Delete the raw plan JSON from local disk (best-effort)
    try:
        if plan_path and os.path.isfile(plan_path):
            os.remove(plan_path)
            logger.debug("Deleted plan JSON: %s", plan_path)
    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to delete plan JSON (non-fatal): %s", e)
