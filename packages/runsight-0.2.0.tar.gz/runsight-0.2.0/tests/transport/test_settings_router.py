from pathlib import Path
from unittest.mock import AsyncMock, Mock

from fastapi.testclient import TestClient

from runsight_api.data.filesystem.settings_repo import FileSystemSettingsRepo
from runsight_api.domain.entities.settings import AppSettingsConfig
from runsight_api.main import app
from runsight_api.transport.deps import (
    get_provider_service,
    get_settings_repo,
    get_settings_service,
)

client = TestClient(app)
ROUTER_SOURCE = (
    Path(__file__).resolve().parents[2] / "src/runsight_api/transport/routers/settings.py"
)


def _mock_provider(*, provider_id: str, name: str, models: list[str]):
    provider = Mock()
    provider.id = provider_id
    provider.name = name
    provider.type = "custom"
    provider.status = "active"
    provider.api_key = "configured-key"
    provider.base_url = None
    provider.models = models
    provider.created_at = None
    provider.updated_at = None
    provider.is_active = True
    return provider


def _assert_provider_test_contract(payload: dict):
    assert payload["success"] in (True, False)
    assert isinstance(payload["message"], str)
    assert isinstance(payload["model_count"], int)
    assert payload["model_count"] >= 0
    assert payload["latency_ms"] >= 0


def test_settings_providers_list():
    mock_service = Mock()
    mock_service.list_providers.return_value = [
        _mock_provider(provider_id="openai", name="OpenAI", models=["gpt-4.1", "gpt-4o"]),
        _mock_provider(provider_id="empty-provider", name="Empty Provider", models=[]),
    ]
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    response = client.get("/api/settings/providers")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 2
    assert data["items"][0]["model_count"] == 2
    assert data["items"][1]["model_count"] == 0
    app.dependency_overrides.clear()


def test_settings_providers_list_keeps_disabled_provider_visible_for_management():
    mock_service = Mock()
    disabled_provider = _mock_provider(
        provider_id="anthropic",
        name="Anthropic",
        models=["claude-sonnet-4"],
    )
    disabled_provider.is_active = False
    mock_service.list_providers.return_value = [disabled_provider]
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    try:
        response = client.get("/api/settings/providers")
        assert response.status_code == 200
        payload = response.json()
        assert payload["items"][0]["id"] == "anthropic"
        assert payload["items"][0]["is_active"] is False
    finally:
        app.dependency_overrides.clear()


def test_settings_providers_get_404():
    mock_service = Mock()
    mock_service.get_provider.return_value = None
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    response = client.get("/api/settings/providers/missing")
    assert response.status_code == 404
    app.dependency_overrides.clear()


def test_settings_providers_post():
    mock_service = Mock()
    mock_provider = _mock_provider(provider_id="openai", name="OpenAI", models=[])
    mock_service.create_provider.return_value = mock_provider
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    response = client.post(
        "/api/settings/providers",
        json={"name": "OpenAI", "api_key_env": "sk-xxx"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "openai"
    assert data["model_count"] == 0
    app.dependency_overrides.clear()


def test_settings_providers_post_422():
    app.dependency_overrides.clear()
    response = client.post("/api/settings/providers", json={})
    assert response.status_code == 422


def test_settings_providers_put_404():
    mock_service = Mock()
    mock_service.update_provider.return_value = None
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    response = client.put("/api/settings/providers/missing", json={"name": "Updated"})
    assert response.status_code == 404
    app.dependency_overrides.clear()


def test_settings_providers_delete_404():
    mock_service = Mock()
    mock_service.delete_provider.return_value = False
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    response = client.delete("/api/settings/providers/missing")
    assert response.status_code == 404
    app.dependency_overrides.clear()


def test_settings_providers_test():
    mock_service = Mock()
    mock_service.test_connection = AsyncMock(
        return_value={
            "success": True,
            "message": "Connected - 1 models available",
            "models": ["gpt-4o"],
        }
    )
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    try:
        response = client.post("/api/settings/providers/openai/test")
        assert response.status_code == 200
        _assert_provider_test_contract(response.json())
    finally:
        app.dependency_overrides.clear()


def test_settings_providers_test_credentials_returns_setup_contract_shape():
    mock_service = Mock()
    mock_service.test_credentials = AsyncMock(
        return_value={
            "success": False,
            "message": "Connection failed (HTTP 401)",
            "models": [],
        }
    )
    app.dependency_overrides[get_provider_service] = lambda: mock_service

    try:
        response = client.post(
            "/api/settings/providers/test",
            json={
                "provider_type": "openai",
                "api_key_env": "sk-test",
                "base_url": "https://api.openai.com/v1",
            },
        )
        assert response.status_code == 200
        _assert_provider_test_contract(response.json())
    finally:
        app.dependency_overrides.clear()


def test_settings_fallbacks_list():
    mock_service = Mock()
    mock_service.get_fallback_targets.return_value = [
        {
            "id": "openai",
            "provider_id": "openai",
            "provider_name": "OpenAI",
            "fallback_provider_id": "anthropic",
            "fallback_model_id": "claude-sonnet-4",
        }
    ]
    app.dependency_overrides[get_settings_service] = lambda: mock_service

    try:
        response = client.get("/api/settings/fallbacks")
        assert response.status_code == 200
        assert response.json() == {
            "items": [
                {
                    "id": "openai",
                    "provider_id": "openai",
                    "provider_name": "OpenAI",
                    "fallback_provider_id": "anthropic",
                    "fallback_model_id": "claude-sonnet-4",
                }
            ],
            "total": 1,
        }
        mock_service.get_fallback_targets.assert_called_once_with()
    finally:
        app.dependency_overrides.clear()


def test_settings_fallbacks_put_updates_fallback_pair():
    mock_service = Mock()
    mock_service.update_fallback_target.return_value = {
        "id": "openai",
        "provider_id": "openai",
        "provider_name": "OpenAI",
        "fallback_provider_id": "anthropic",
        "fallback_model_id": "claude-sonnet-4",
    }
    app.dependency_overrides[get_settings_service] = lambda: mock_service

    try:
        response = client.put(
            "/api/settings/fallbacks/openai",
            json={
                "fallback_provider_id": "anthropic",
                "fallback_model_id": "claude-sonnet-4",
            },
        )
        assert response.status_code == 200
        assert response.json()["fallback_provider_id"] == "anthropic"
        assert response.json()["fallback_model_id"] == "claude-sonnet-4"
        mock_service.update_fallback_target.assert_called_once_with(
            provider_id="openai",
            fallback_provider_id="anthropic",
            fallback_model_id="claude-sonnet-4",
        )
    finally:
        app.dependency_overrides.clear()


def test_settings_fallbacks_put_allows_clearing_with_empty_strings():
    mock_service = Mock()
    mock_service.update_fallback_target.return_value = {
        "id": "openai",
        "provider_id": "openai",
        "provider_name": "OpenAI",
        "fallback_provider_id": None,
        "fallback_model_id": None,
    }
    app.dependency_overrides[get_settings_service] = lambda: mock_service

    try:
        response = client.put(
            "/api/settings/fallbacks/openai",
            json={"fallback_provider_id": "", "fallback_model_id": ""},
        )
        assert response.status_code == 200
        assert response.json()["fallback_provider_id"] is None
        assert response.json()["fallback_model_id"] is None
    finally:
        app.dependency_overrides.clear()


def test_app_settings_get_returns_fallback_enabled_without_default_provider():
    mock_repo = Mock(spec=FileSystemSettingsRepo)
    mock_repo.get_settings.return_value = AppSettingsConfig(
        auto_save=True,
        onboarding_completed=True,
        fallback_enabled=False,
    )
    app.dependency_overrides[get_settings_repo] = lambda: mock_repo

    try:
        response = client.get("/api/settings/app")
        assert response.status_code == 200
        assert response.json()["auto_save"] is True
        assert response.json()["fallback_enabled"] is False
        assert "default_provider" not in response.json()
    finally:
        app.dependency_overrides.clear()


def test_app_settings_put_updates_fallback_enabled_without_default_provider():
    mock_repo = Mock(spec=FileSystemSettingsRepo)
    mock_repo.update_settings.return_value = AppSettingsConfig(
        auto_save=True,
        onboarding_completed=True,
        fallback_enabled=False,
    )
    app.dependency_overrides[get_settings_repo] = lambda: mock_repo

    try:
        response = client.put(
            "/api/settings/app",
            json={"auto_save": True, "fallback_enabled": False},
        )
        assert response.status_code == 200
        assert response.json()["fallback_enabled"] is False
        assert "default_provider" not in response.json()
        mock_repo.update_settings.assert_called_once_with(
            {"auto_save": True, "fallback_enabled": False}
        )
    finally:
        app.dependency_overrides.clear()


def test_router_source_mentions_fallback_settings_only():
    source = ROUTER_SOURCE.read_text()

    assert "/fallbacks" in source
    assert "fallback_enabled" in source
    assert "/settings/models" not in source
    assert "default_provider" not in source
