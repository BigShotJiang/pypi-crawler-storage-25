import{j as e,r as _,a as x,c as b,d as w,e as g,f as u,B as v,t as y}from"./index-C0qvGdqy.js";const k=`version: '1.0'
tools:
  - file_io
# REQUIRED BEFORE RUNNING:
# - Replace every PLACEHOLDER_PROVIDER_ID with one of your configured provider ids.
# - Replace every PLACEHOLDER_MODEL_NAME with a model that belongs to that provider.
# - Temperature defaults to 1 below. If your chosen model does not support temperature,
#   remove the temperature line for that soul.
souls:
  researcher:
    id: researcher
    role: Research File Writer
    system_prompt: >
      You are a fast research assistant.
      Use the user's task as the topic. If the task is blank or too generic,
      default to "Runsight onboarding starter workflow".
      Produce a concise markdown research note with a title, 3 to 5 concrete bullets,
      and a short "Next steps" section.
      If previous_round_context appears in the provided context, use it to improve the draft.
      Before finishing, you MUST call the file_io tool to write the markdown to
      custom/outputs/onboarding-research-brief.md.
      After the tool call succeeds, return the same markdown.
    tools:
      - file_io
    required_tool_calls:
      - file_io
    max_tool_iterations: 4
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: info
  reviewer:
    id: reviewer
    role: Quality Gate Reviewer
    system_prompt: >
      Review the draft research note.
      Return PASS if it is specific, structured, and actionable.
      Return FAIL: followed by one short paragraph of concrete fixes if it is too vague,
      generic, or missing the required structure.
    max_tool_iterations: 3
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: accent
  error_writer:
    id: error_writer
    role: Error Stub Writer
    system_prompt: >
      This block only runs after the review flow fails or errors.
      Write a short markdown stub to custom/outputs/onboarding-research-error.md.
      The stub should explain that the workflow did not produce a verified report yet
      and that the operator should inspect the latest run details.
      Before finishing, you MUST call the file_io tool to write the stub file.
      After the tool call succeeds, return one sentence with the file path.
    tools:
      - file_io
    required_tool_calls:
      - file_io
    max_tool_iterations: 3
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: warning
blocks:
  draft_report:
    type: linear
    soul_ref: researcher
  quality_gate:
    type: gate
    soul_ref: reviewer
    eval_key: draft_report
  review_loop:
    type: loop
    inner_block_refs:
      - draft_report
      - quality_gate
    max_rounds: 2
    break_on_exit: pass
    retry_on_exit: fail
    carry_context:
      enabled: true
      mode: all
      source_blocks:
        - draft_report
        - quality_gate
      inject_as: previous_round_context
    error_route: write_error_stub
  check_review_status:
    type: code
    timeout_seconds: 10
    code: |
      def main(data):
          loop_meta = data["shared_memory"].get("__loop__review_loop", {}) or {}
          break_reason = str(loop_meta.get("break_reason", ""))
          passed = "pass" in break_reason
          return {
              "status": "pass" if passed else "fail",
              "break_reason": break_reason,
              "exit_handle": "pass" if passed else "fail",
          }
  write_error_stub:
    type: linear
    soul_ref: error_writer
  finish:
    type: code
    timeout_seconds: 10
    code: |
      import json

      def _normalize(raw):
          if isinstance(raw, dict):
              return raw
          if isinstance(raw, str):
              try:
                  return json.loads(raw)
              except Exception:
                  return {"raw": raw}
          return {"raw": raw}

      def main(data):
          return {
              "status": "completed",
              "report_path": "custom/outputs/onboarding-research-brief.md",
              "error_stub_path": "custom/outputs/onboarding-research-error.md",
              "review_status": _normalize(data["results"].get("check_review_status", "")),
              "error_stub": _normalize(data["results"].get("write_error_stub", "")),
          }
workflow:
  name: Research & Review
  entry: review_loop
  transitions:
    - from: review_loop
      to: check_review_status
    - from: write_error_stub
      to: finish
  conditional_transitions:
    - from: check_review_status
      pass: finish
      fail: write_error_stub
      default: write_error_stub
`;function p({selected:r,onSelect:t,children:l,label:n,title:o,badge:s,description:c,footer:i}){return e.jsxs("div",{role:"radio","aria-checked":r,"aria-label":n,tabIndex:0,onClick:t,onKeyDown:a=>{(a.key==="Enter"||a.key===" ")&&(a.preventDefault(),t())},className:["flex flex-col gap-4 rounded-xl border p-5 cursor-pointer text-left","transition-[border-color,box-shadow] duration-200 ease-default",r?"border-accent-9 shadow-[0_0_0_1px_hsla(38,92%,55%,0.3)]":"border-border-subtle bg-surface-secondary hover:border-border-hover"].join(" "),children:[o&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-lg font-semibold text-heading",children:o}),s]}),c&&e.jsx("p",{className:"text-sm text-secondary leading-relaxed",children:c}),l,i]})}const j=[{label:"Research",category:"agent"},{label:"Write",category:"agent"},{label:"Review",category:"logic"}],E={agent:"bg-block-agent",logic:"bg-block-logic"};function R({label:r,category:t}){return e.jsxs("div",{className:"flex flex-col items-center gap-0.5 w-16 node-mini",children:[e.jsx("div",{className:"relative w-14 h-8 rounded-sm border border-border-subtle bg-surface-secondary overflow-hidden",children:e.jsx("div",{className:`absolute top-0 left-0 right-0 h-[3px] ${E[t]}`})}),e.jsx("span",{className:"font-mono text-[9px] text-muted uppercase tracking-wide",children:r})]})}function N(){return e.jsx("div",{className:"relative w-4 h-px bg-neutral-7 -mt-2.5",children:e.jsx("div",{className:"absolute -right-px -top-[3px] w-0 h-0",style:{borderLeft:"4px solid var(--neutral-7)",borderTop:"3px solid transparent",borderBottom:"3px solid transparent"}})})}function A(){return e.jsx("div",{className:"flex items-center justify-center gap-1.5 py-4 px-2 bg-surface-primary rounded-md border border-neutral-3","aria-hidden":"true",children:j.map((r,t)=>e.jsxs("div",{className:"contents",children:[t>0&&e.jsx(N,{}),e.jsx(R,{label:r.label,category:r.category})]},r.label))})}function D(){return e.jsx("div",{className:"flex items-center justify-center py-6 px-4 bg-surface-primary rounded-md border border-neutral-3","aria-hidden":"true",children:e.jsx("div",{className:"flex items-center justify-center w-[100px] h-14 rounded-md border-[1.5px] border-dashed border-border-subtle text-neutral-7",children:e.jsx("span",{className:"text-xl font-light text-neutral-9",children:"+"})})})}function P(){const[r,t]=_.useState("template"),l=x(),n=b(),o=w(),{data:s}=g(),i=((s==null?void 0:s.items)??[]).filter(d=>d.is_active??!0).length>0,a=n.isPending||o.isPending;async function m(){try{const d=r==="template"?"Research & Review":"Untitled Workflow",f=r==="template"?k:"",h=await n.mutateAsync({name:d,yaml:f,commit:!1});await o.mutateAsync({onboarding_completed:!0}),l(`/workflows/${h.id}/edit`,{replace:!0})}catch{y.error("Something went wrong. Please try again.")}}return e.jsx("main",{className:"flex items-center justify-center min-h-screen bg-surface-primary",children:e.jsxs("div",{className:"w-full max-w-[540px] px-4 py-12 flex flex-col gap-8 text-center",children:[e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("h1",{className:"text-3xl font-semibold text-heading tracking-tight",children:"How do you want to start?"}),e.jsx("p",{className:"text-md text-secondary",children:"You can always create more workflows later."})]}),e.jsxs("div",{role:"radiogroup","aria-label":"Starting point",className:"grid grid-cols-2 gap-3",children:[e.jsxs(p,{selected:r==="template",onSelect:()=>t("template"),label:"Start with a template",title:"Tutorial Template",badge:e.jsx(u,{variant:"accent",children:"Recommended"}),description:"A looped starter workflow with inline souls. It drafts a research brief, writes it to custom/outputs, and emits an error stub if review still fails.",footer:e.jsxs("div",{className:"flex items-center gap-1 font-mono text-2xs text-muted pt-3 border-t border-neutral-3",children:[e.jsx("span",{className:`inline-block w-1.5 h-1.5 rounded-full shrink-0 ${i?"bg-success":"bg-info"}`}),i?e.jsx("span",{children:"Ready to run"}):e.jsx("span",{children:"Add an API key in Settings to run this workflow"})]}),children:[i?e.jsx(u,{variant:"success",children:"Ready to run"}):e.jsx(u,{variant:"warning",children:"Explore mode"}),e.jsx(A,{})]}),e.jsx(p,{selected:r==="blank",onSelect:()=>t("blank"),label:"Start with a blank canvas",title:"Blank Canvas",description:"Start from scratch. Drag blocks from the palette to build your own workflow.",footer:e.jsxs("div",{className:"flex items-center gap-1 font-mono text-2xs text-muted pt-3 border-t border-neutral-3",children:[e.jsx("span",{className:"inline-block w-1.5 h-1.5 rounded-full shrink-0 bg-neutral-9"}),e.jsx("span",{children:"Full block palette available"})]}),children:e.jsx(D,{})})]}),e.jsx(v,{variant:"primary",size:"lg",loading:a,disabled:a,onClick:m,className:"w-full",children:"Start Building"})]})})}export{P as Component};
