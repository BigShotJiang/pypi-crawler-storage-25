"""Allow running as: python -m gemini_mcp_server"""

from gemini_mcp_server import mcp

if __name__ == "__main__":
    mcp.run()
