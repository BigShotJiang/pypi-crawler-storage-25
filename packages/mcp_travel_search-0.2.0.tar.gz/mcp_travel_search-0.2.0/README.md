# 旅行搜索与预订 MCP Server

智能旅行服务：酒店推荐、万豪搜索、景点门票、旅行规划，返回真实价格和可预订/购票链接。

## 功能

- **酒店智能推荐** — 根据目的地、预算、星级等条件搜索酒店
- **万豪酒店搜索** — 搜索万豪集团旗下酒店（万豪/喜来登/JW/威斯汀/丽思卡尔顿/万丽/万枫等）
- **景点门票搜索** — 搜索景点，返回门票价格和购票链接，支持5A景区筛选
- **旅行规划** — 自然语言输入需求，AI生成完整旅行方案（酒店+景点+行程安排+预算分配）

## 安装

```bash
pip install mcp-travel-search
```

或使用 uvx 直接运行：

```bash
uvx mcp-travel-search
```

## 配置

需要设置以下环境变量：

| 变量名 | 说明 | 获取方式 |
|--------|------|---------|
| FLYAI_API_KEY | FlyAI API密钥 | https://flyai.open.fliggy.com 注册获取 |
| FLYAI_SIGN_SECRET | FlyAI签名密钥 | 同上 |

## 使用

### 在 MCP 客户端中配置

```json
{
  "mcpServers": {
    "travel-search": {
      "command": "uvx",
      "args": ["mcp-travel-search"],
      "env": {
        "FLYAI_API_KEY": "你的API密钥",
        "FLYAI_SIGN_SECRET": "你的签名密钥"
      }
    }
  }
}
```

### 工具列表

#### search_hotels - 酒店智能推荐

根据目的地和条件搜索酒店，返回真实价格和可预订链接。

参数：
- `dest`（必填）：目的地，如"深圳""上海外滩"
- `max_price`：最高价格/晚
- `hotel_stars`：星级（5=豪华型/4=高档型/3=舒适型）
- `checkin`/`checkout`：入住/退房日期 YYYY-MM-DD
- `poi`：附近景点/地标
- `sort`：排序（rate_desc/price_asc/price_desc/distance_asc）
- `keywords`：关键词
- `limit`：返回数量，默认10

示例：搜索深圳400元以内的高档型酒店

#### search_marriott_hotels - 万豪酒店搜索

搜索万豪集团旗下酒店，返回真实价格和可预订链接。

参数：
- `dest`（必填）：目的地
- `max_price`：最高价格/晚
- `checkin`/`checkout`：入住/退房日期
- `sort`：排序方式
- `limit`：返回数量，默认10

示例：搜索上海800元以内的万豪酒店

#### search_poi - 景点门票搜索

搜索景点，返回门票价格和购票链接。

参数：
- `city`（必填）：城市
- `keyword`：景点关键词
- `category`：景点类型
- `level`：景区等级 1-5（5=5A级景区）
- `limit`：返回数量，默认10

示例：搜索北京的5A级景区

#### plan_travel - 旅行规划

根据自然语言需求智能规划旅行方案，涵盖酒店、景点、度假套餐和行程安排。

参数：
- `query`（必填）：自然语言旅行需求，如"三亚度蜜月预算1万怎么安排""国庆7天去云南路线""周末广州亲子游预算2000"

适用于需求模糊或复杂的场景：
- 不知道怎么安排行程
- 不知道去哪玩
- 有预算/时间等约束条件
- 需要跨品类整合（酒店+景点+行程）

示例：规划"带孩子去三亚玩5天，预算8000"

## 数据来源

数据来源于官方旅行商品库，价格实时更新，点击链接可直接预订/购票。

## License

MIT
