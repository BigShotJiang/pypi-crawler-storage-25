from mcp_travel_search import main

main()
