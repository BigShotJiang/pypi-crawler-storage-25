import{a as e}from"../chunks/CpfkSQgV.js";export{e as component};
