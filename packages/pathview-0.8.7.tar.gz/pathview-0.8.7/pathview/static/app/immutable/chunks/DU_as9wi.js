const s=globalThis.__sveltekit_1h9mhnf?.base??"",a=globalThis.__sveltekit_1h9mhnf?.assets??s??"";export{a,s as b};
