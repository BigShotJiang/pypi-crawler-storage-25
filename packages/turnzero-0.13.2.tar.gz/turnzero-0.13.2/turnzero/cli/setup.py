"""Onboarding, registration, and source management."""

from __future__ import annotations

import contextlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import typer

from turnzero.cli.base import (
    HTTP_OK,
    console,
    err_console,
    get_data_dir,
)
from turnzero.types import BLOCK_ID_PERSONAL_LIMIT_WARNING

source_app = typer.Typer(
    help="Enable or disable Expert Prior sources (local/community/team).",
    no_args_is_help=True,
)


def _generate_hook(data_dir: Path) -> str:
    """Load hook script template and substitute data directory path."""
    template_path = Path(__file__).parent.parent / "templates" / "hooks" / "turnzero_hook.py.template"
    return template_path.read_text(encoding="utf-8").replace("__DATA_DIR__", str(data_dir))


_TURNZERO_MD_BLOCK = """\

## TurnZero — Expert & Personal Prior Injection
TurnZero MCP is installed. Follow these rules to establish a consistent **Portable AI Identity** and domain-specific grounding:

### 1. Context Injection (Turn 0)
- **Rule:** ALWAYS call `list_suggested_blocks` before responding to ANY non-trivial user message.
- **Why:** This retrieves your **Personal Priors** (Always-On Identity) and relevant **Expert Priors** (Domain Knowledge).
- **Skip:** Only skip for pure chitchat — greetings, social acknowledgments ("thanks", "looks good", "got it"), or any message with no actionable content.

### 2. Creating Priors (`submit_candidate`)
- **Expert Priors (`is_personal=False`):** Use this for general technical truth, library "gotchas," or domain-specific rules (e.g., "SQLAlchemy 2.0 requires select()"). These are for the community.
- **Personal Priors (`is_personal=True`):** Use this for the user's idiosyncratic preferences, personal style, or specific project quirks (e.g., "I prefer 2-space indents," "Be extremely concise"). These are private.
- **Confidence:** Always set `auto_approve=True` for live session corrections.

### 3. Session Management (`reset_session`)
- **Rule:** Call `reset_session` if the user says "reset," "clear context," "forget everything," or starts a "new conversation."
- **Why:** This clears TurnZero's memory of what was already injected, ensuring the **Portable AI Identity** is re-suggested immediately.

### 4. Integration
- Use `inject_block` to retrieve the full text of relevant priors before answering.
- Call `get_stats` if the user asks about TurnZero's impact or library size.
"""

_TURNZERO_MD_MARKER = "## TurnZero — Expert & Personal Prior Injection"
_LEGACY_TURNZERO_MD_MARKER = "## TurnZero — Expert Prior injection"


def _strip_turnzero_block(existing: str) -> str:
    """Remove any existing TurnZero instruction block (current or legacy marker)."""
    lines = existing.splitlines(keepends=True)
    filtered: list[str] = []
    skip = False
    for line in lines:
        if _TURNZERO_MD_MARKER in line or _LEGACY_TURNZERO_MD_MARKER in line:
            skip = True
        elif (
            skip
            and line.startswith("## ")
            and _TURNZERO_MD_MARKER not in line
            and _LEGACY_TURNZERO_MD_MARKER not in line
        ):
            skip = False
        if not skip:
            filtered.append(line)
    return "".join(filtered).rstrip("\n")


def _write_md_file(md_path: Path, block: str, force: bool, con: Any) -> None:
    """Merge TurnZero instruction block into a markdown config file."""
    existing = md_path.read_text(encoding="utf-8") if md_path.exists() else ""
    if _TURNZERO_MD_MARKER in existing or _LEGACY_TURNZERO_MD_MARKER in existing:
        if not force and _TURNZERO_MD_MARKER in existing:
            con.print(f"[dim]✓ TurnZero rule already in {md_path.name}[/dim]")
            return
        existing = _strip_turnzero_block(existing)
    md_path.write_text(existing + block, encoding="utf-8")
    con.print(f"[green]✓[/green] TurnZero rule written to {md_path}")


def _mcp_json_entry(
    mcp_bin: str,
    data_dir: Path,
    *,
    disabled: bool | None = None,
) -> dict[str, object]:
    """Build a standard JSON MCP server entry dict."""
    entry: dict[str, object] = {
        "command": mcp_bin,
        "args": [],
        "env": {"TURNZERO_DATA_DIR": str(data_dir)},
    }
    if disabled is not None:
        entry["disabled"] = disabled
    return entry


def _setup_codex_mcp(
    mcp_bin: str,
    data_dir: Path,
    force: bool,
    con: Any,
    codex_dir: Path | None = None,
) -> None:
    """Register MCP server in ~/.codex/config.toml."""
    target_dir = codex_dir or Path.home() / ".codex"
    if not target_dir.exists():
        return

    config_path = target_dir / "config.toml"
    existing = config_path.read_text(encoding="utf-8") if config_path.exists() else ""

    if "[mcp_servers.turnzero]" in existing and not force:
        con.print("[dim]✓ MCP server already in ~/.codex/config.toml[/dim]")
        return

    new_block = f"""
[mcp_servers.turnzero]
command = "{mcp_bin}"
env = {{ TURNZERO_DATA_DIR = "{data_dir}" }}
"""
    if "[mcp_servers.turnzero]" in existing:
        # crude overwrite
        lines = existing.splitlines(keepends=True)
        filtered = []
        skip = False
        for line in lines:
            if line.strip() == "[mcp_servers.turnzero]":
                skip = True
                continue
            if skip and line.startswith("["):
                skip = False
            if not skip:
                filtered.append(line)
        config_path.write_text(
            "".join(filtered).rstrip("\n") + new_block, encoding="utf-8"
        )
    else:
        config_path.write_text(
            existing.rstrip("\n") + "\n" + new_block.lstrip("\n"),
            encoding="utf-8",
        )

    con.print(f"[green]✓[/green] MCP server registered in {config_path}")


def _setup_cursor_mcp(
    mcp_bin: str,
    data_dir: Path,
    force: bool,
    con: Any,
) -> None:
    """Register MCP server in Cursor config."""
    if platform.system() == "Darwin":
        config_path = (
            Path.home()
            / "Library/Application Support/Cursor/User/globalStorage/saoudrizwan.claude-dev/settings/mcp_servers.json"
        )
    elif platform.system() == "Windows":
        config_path = (
            Path(os.environ["APPDATA"])
            / "Cursor/User/globalStorage/saoudrizwan.claude-dev/settings/mcp_servers.json"
        )
    else:
        return

    if not config_path.parent.exists():
        return

    config: dict[str, Any] = {}
    if config_path.exists():
        with contextlib.suppress(json.JSONDecodeError):
            config = json.loads(config_path.read_text(encoding="utf-8"))

    mcp_servers = config.setdefault("mcpServers", {})
    if "turnzero" not in mcp_servers or force:
        mcp_servers["turnzero"] = _mcp_json_entry(mcp_bin, data_dir, disabled=False)
        config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
        con.print(f"[green]✓[/green] MCP server registered in Cursor ({config_path.name})")
    else:
        con.print("[dim]✓ MCP server already in Cursor[/dim]")


def _setup_claude_desktop_mcp(
    mcp_bin: str,
    data_dir: Path,
    force: bool,
    con: Any,
) -> None:
    """Register MCP server in Claude Desktop config."""
    if platform.system() == "Darwin":
        config_path = (
            Path.home()
            / "Library/Application Support/Claude/claude_desktop_config.json"
        )
    elif platform.system() == "Windows":
        config_path = Path(os.environ["APPDATA"]) / "Claude/claude_desktop_config.json"
    else:
        return

    if not config_path.parent.exists():
        return

    config: dict[str, Any] = {}
    if config_path.exists():
        with contextlib.suppress(json.JSONDecodeError):
            config = json.loads(config_path.read_text(encoding="utf-8"))

    mcp_servers = config.setdefault("mcpServers", {})
    if "turnzero" not in mcp_servers or force:
        mcp_servers["turnzero"] = _mcp_json_entry(mcp_bin, data_dir)
        config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
        con.print(f"[green]✓[/green] MCP server registered in Claude Desktop ({config_path.name})")
    else:
        con.print("[dim]✓ MCP server already in Claude Desktop[/dim]")


def _setup_gemini_mcp(
    mcp_bin: str,
    data_dir: Path,
    force: bool,
    con: Any,
) -> None:
    """Register MCP server in Gemini CLI config."""
    config_path = Path.home() / ".gemini" / "settings.json"
    if not config_path.parent.exists():
        return

    config: dict[str, Any] = {}
    if config_path.exists():
        with contextlib.suppress(json.JSONDecodeError):
            config = json.loads(config_path.read_text(encoding="utf-8"))

    mcp_servers = config.setdefault("mcpServers", {})
    if "turnzero" not in mcp_servers or force:
        mcp_servers["turnzero"] = _mcp_json_entry(mcp_bin, data_dir)
        config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
        con.print(f"[green]✓[/green] MCP server registered in Gemini CLI ({config_path.name})")
    else:
        con.print("[dim]✓ MCP server already in Gemini CLI[/dim]")


def _setup_claude_md(force: bool, con: Any, claude_dir: Path | None = None) -> None:
    """Write TurnZero instruction block to ~/.claude/CLAUDE.md."""
    target_dir = claude_dir or Path.home() / ".claude"
    if not target_dir.exists():
        return
    _write_md_file(target_dir / "CLAUDE.md", _TURNZERO_MD_BLOCK, force, con)


def _setup_codex_agents_md(
    force: bool, con: Any, codex_dir: Path | None = None
) -> None:
    """Write TurnZero instruction block to ~/.codex/AGENTS.md."""
    target_dir = codex_dir or Path.home() / ".codex"
    if not target_dir.exists():
        return
    _write_md_file(target_dir / "AGENTS.md", _TURNZERO_MD_BLOCK, force, con)


def _setup_gemini_md(force: bool, con: Any, gemini_dir: Path | None = None) -> None:
    """Write TurnZero instruction block to ~/.gemini/GEMINI.md."""
    target_dir = gemini_dir or Path.home() / ".gemini"
    if not target_dir.exists():
        return
    _write_md_file(target_dir / "GEMINI.md", _TURNZERO_MD_BLOCK, force, con)


_DEMO_PROMPT = "Building a FastAPI REST API with Pydantic models and async SQLAlchemy"


def _render_demo_results(prompt: str) -> None:
    """Run retrieval for prompt and print what TurnZero would inject."""
    from turnzero.mcp_server import _list_suggested_blocks

    try:
        all_results = [
            r
            for r in _list_suggested_blocks(prompt)
            if r.get("block_id") != BLOCK_ID_PERSONAL_LIMIT_WARNING
        ]
        if not all_results:
            console.print(
                "  [yellow]⚠ No blocks matched.[/yellow]\n"
                "  Run [cyan]turnzero verify[/cyan] to diagnose."
            )
            return

        personal = [r for r in all_results if "[personal" in r.get("preview", "")]
        expert = [r for r in all_results if "[personal" not in r.get("preview", "")]

        if personal:
            p_tokens = sum(r.get("context_weight", 0) for r in personal)
            console.print(
                "  [bold]Personal Priors[/bold]  [dim](your identity — injected every session)[/dim]"
            )
            console.print(
                f"  [dim]{len(personal)} rule{'s' if len(personal) != 1 else ''} · ~{p_tokens} tokens[/dim]\n"
            )

        if expert:
            console.print(
                "  [bold]Expert Priors[/bold]  [dim](domain knowledge — injected when relevant)[/dim]"
            )
            for r in expert:
                slug = r["block_id"]
                tokens = r.get("context_weight", 0)
                domain = r.get("domain", "")
                preview = r.get("preview", "")
                console.print(
                    f"  [green]✓[/green] [bold]{slug}[/bold]"
                    f"  [dim]{domain} · ~{tokens} tokens[/dim]"
                )
                if preview:
                    console.print(f"    [dim]{preview}[/dim]")

        total_tokens = sum(r.get("context_weight", 0) for r in all_results)
        console.print(
            f"\n  [bold]Total: ~{total_tokens} tokens[/bold] injected on Turn 0 "
            f"({len(personal)} personal + {len(expert)} expert)."
        )
        console.print(
            "  This context is added automatically — no prompt changes needed."
        )
    except Exception as e:
        console.print(
            f"  [yellow]⚠ Live demo skipped ({e}).[/yellow]\n"
            "  MCP server will inject priors normally when you start a session.\n"
            "  Run [cyan]turnzero verify[/cyan] to confirm retrieval is working."
        )


def _print_setup_finale(interactive: bool) -> None:
    """Show what TurnZero injects — user's own prompt if interactive, else demo."""
    prompt = ""

    if interactive:
        console.print("[bold]See your priors in action[/bold]\n")
        console.print(
            "  [dim]Type your typical opening message and see exactly what"
            " TurnZero will load into your AI session.[/dim]\n"
        )
        try:
            user_input = console.input("  [bold]>[/bold] ").strip()
            prompt = user_input
        except (EOFError, KeyboardInterrupt):
            pass

    if not prompt:
        if interactive:
            console.print(
                f"\n  [dim]Using demo prompt: {_DEMO_PROMPT}[/dim]"
            )
        else:
            console.print(
                f"[bold]Live demo[/bold] — what TurnZero injects:\n\n"
                f"  [dim]{_DEMO_PROMPT}[/dim]\n"
            )
        prompt = _DEMO_PROMPT
    else:
        console.print()

    _render_demo_results(prompt)


def setup(
    data_dir: Path = typer.Option(
        None,
        "--data-dir",
        "-d",
        help="Where to store blocks and index. Default: ~/.turnzero",
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite existing MCP config."
    ),
    with_hook: bool = typer.Option(
        False,
        "--with-hook",
        help="Also install the Claude Code UserPromptSubmit hook for guaranteed injection regardless of model behaviour.",
    ),
    openai_key: str = typer.Option(
        None,
        "--openai-key",
        help="OpenAI API key for cloud embedding fallback (stored at ~/.turnzero/openai_key).",
        envvar="OPENAI_API_KEY",
    ),
    interactive: bool = typer.Option(
        True,
        "--interactive/--no-interactive",
        help="Whether to prompt for actions like pulling models.",
    ),
) -> None:
    """One-command setup: register MCP server and build index.

    Registers the TurnZero MCP server globally. Any MCP-compatible AI client
    (Claude Code, Cursor, Claude Desktop) will automatically call
    list_suggested_blocks on Turn 0 and inject Expert Priors.

    Use --with-hook to also install the Claude Code UserPromptSubmit hook
    for guaranteed injection regardless of model behaviour.
    """
    claude_dir = Path.home() / ".claude"
    claude_dir.mkdir(exist_ok=True)

    resolved = (data_dir or Path.home() / ".turnzero").expanduser().resolve()

    console.print("\n[bold]TurnZero Setup[/bold]\n")
    console.print(f"Data directory: [cyan]{resolved}[/cyan]\n")

    # Persist OpenAI key if provided
    if openai_key:
        key_file = resolved / "openai_key"
        resolved.mkdir(parents=True, exist_ok=True)
        key_file.write_text(openai_key.strip(), encoding="utf-8")
        key_file.chmod(0o600)
        os.environ["OPENAI_API_KEY"] = openai_key.strip()
        console.print("[green]✓[/green] OpenAI API key saved\n")
    elif (resolved / "openai_key").exists():
        os.environ["OPENAI_API_KEY"] = (resolved / "openai_key").read_text().strip()
        console.print("[dim]✓ OpenAI API key loaded from previous setup[/dim]\n")

    # ── 1. Copy blocks ────────────────────────────────────────────────────
    # In refactored structure, turnzero/cli/setup.py is .
    # turnzero/ is .parent
    # turnzero/data/blocks is .parent / data / blocks
    pkg_blocks = Path(__file__).parent.parent / "data" / "blocks"
    # Repo blocks is .parent.parent.parent / data / blocks
    repo_blocks = Path(__file__).parent.parent.parent / "data" / "blocks"
    source_blocks = pkg_blocks if pkg_blocks.exists() else repo_blocks
    dest_blocks = resolved / "blocks"

    if source_blocks.exists():
        if not dest_blocks.exists() or force:
            dest_blocks.mkdir(parents=True, exist_ok=True)
            # Only sync tiers that are present in the source (e.g. 'community')
            # This preserves 'personal' and 'local' tiers created by the user.
            # We use a merge strategy instead of shutil.rmtree to ensure
            # user-added blocks in these tiers are not lost.
            for tier_dir in source_blocks.iterdir():
                if tier_dir.is_dir():
                    target_tier = dest_blocks / tier_dir.name
                    # Skip if the target directory is managed by a registry
                    if (target_tier / ".registry-managed").exists():
                        console.print(
                            f"[dim]  Skipping registry-managed tier: {tier_dir.name}[/dim]"
                        )
                        continue

                    target_tier.mkdir(parents=True, exist_ok=True)
                    # Merge contents: copy new/updated files, leave others
                    for item in tier_dir.rglob("*"):
                        if item.is_file():
                            rel_path = item.relative_to(tier_dir)
                            target_file = target_tier / rel_path
                            target_file.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(item, target_file)

            n = len(list(dest_blocks.rglob("*.yaml")))
            console.print(f"[green]✓[/green] Synchronized {n} blocks → {dest_blocks}")
        else:
            n = len(list(dest_blocks.rglob("*.yaml")))
            console.print(f"[dim]✓ {n} blocks already at {dest_blocks}[/dim]")
    else:
        console.print(
            "[yellow]⚠[/yellow]  Source blocks not found — "
            "copy your blocks/ directory to [cyan]{dest_blocks}[/cyan] manually."
        )

    # ── 1b. Install starter personal prior (first install only) ──────────
    personal_dir = dest_blocks / "personal"
    personal_dir.mkdir(parents=True, exist_ok=True)
    # Check recursively for any YAML files to handle domain subdirectories
    existing_personal = list(personal_dir.rglob("*.yaml"))
    if not existing_personal:
        pkg_templates = Path(__file__).parent.parent / "data" / "templates"
        repo_templates = Path(__file__).parent.parent.parent / "data" / "templates"
        source_templates = pkg_templates if pkg_templates.exists() else repo_templates
        template_src = source_templates / "personal" / "turnzero-guide.yaml"
        template_dst = personal_dir / "turnzero-guide.yaml"
        if template_src.exists() and not template_dst.exists():
            shutil.copy2(template_src, template_dst)
            console.print(
                "[green]✓[/green] Installed starter personal prior [cyan]turnzero-guide[/cyan]\n"
                "  Edit or replace it in [cyan]~/.turnzero/blocks/personal/[/cyan]"
            )

    # ── 2. Install ONNX embedding backend ────────────────────────────────────
    console.print()
    from turnzero.embed import (
        _is_onnx_available,
        download_onnx_model,
    )

    onnx_model_dir = resolved / "models" / "nomic-embed-text-v1.5"
    onnx_model_ready = (onnx_model_dir / "onnx" / "model.onnx").exists() and (
        onnx_model_dir / "tokenizer.json"
    ).exists()

    embedding_ok = False

    # 2a. Ensure onnxruntime + tokenizers are installed
    if not _is_onnx_available():
        console.print("Installing ONNX embedding backend…")
        install_result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "onnxruntime>=1.18",
                "tokenizers>=0.19",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if install_result.returncode == 0:
            import importlib as _importlib

            _importlib.invalidate_caches()
            console.print("[green]✓[/green] onnxruntime + tokenizers installed")
        else:
            console.print("[red]✗ ONNX backend installation failed.[/red]")

            # Check for common platform mismatch (Intel Mac + New Python)
            is_intel_mac = sys.platform == "darwin" and platform.machine() == "x86_64"
            if is_intel_mac:
                console.print(
                    "  [yellow]Note:[/yellow] Intel Macs often lack ONNX wheels for the very latest Python versions.\n"
                    "  [bold]Recommended fix:[/bold] Install TurnZero using [cyan]Python 3.13[/cyan] or [cyan]3.12[/cyan].\n"
                    "  Or, use [bold]Ollama[/bold] as your local backend instead."
                )
            else:
                console.print(
                    "  Run manually: [cyan]pip install onnxruntime tokenizers[/cyan]"
                )

            if install_result.stderr:
                console.print(f"[dim]{install_result.stderr.strip()}[/dim]")

    # 2b. Download model files if not present
    if _is_onnx_available():
        if onnx_model_ready:
            console.print("[dim]✓ ONNX model already downloaded[/dim]")
            embedding_ok = True
        else:
            console.print(
                "Downloading nomic-embed-text-v1.5 ONNX model (~520 MB, one-time)…"
            )
            try:
                download_onnx_model(onnx_model_dir)
                console.print(
                    "[green]✓[/green] Embedding backend: ONNX (nomic-embed-text-v1.5, in-process)"
                )
                embedding_ok = True
            except Exception as exc:
                console.print(f"[red]✗ Model download failed:[/red] {exc}")
                console.print(
                    "  Check your internet connection and re-run [cyan]turnzero setup[/cyan]."
                )
    else:
        console.print(
            "[yellow]⚠[/yellow] ONNX deps unavailable after install attempt.\n"
            "  Re-run [cyan]turnzero setup[/cyan] in a fresh shell."
        )

    # Fallback 1: Ollama
    if not embedding_ok:
        import httpx

        host = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
        try:
            with httpx.Client(timeout=1.0) as client:
                if client.get(f"{host}/api/tags").status_code == HTTP_OK:
                    # Check for model
                    result = subprocess.run(
                        ["ollama", "list"],
                        capture_output=True,
                        text=True,
                        timeout=5,
                        check=False,
                    )
                    if "nomic-embed-text" in result.stdout:
                        console.print(
                            "[green]✓[/green] Embedding backend: ollama (nomic-embed-text)"
                        )
                        embedding_ok = True
                    else:
                        console.print(
                            "[yellow]⚠[/yellow] ollama running, but 'nomic-embed-text' model missing.\n"
                            "  Run: [cyan]ollama pull nomic-embed-text[/cyan]"
                        )
        except Exception:
            pass

    # Fallback 2: accept OpenAI if user already has it configured
    if not embedding_ok and os.environ.get("OPENAI_API_KEY"):
        console.print("[green]✓[/green] Embedding backend: OpenAI API (fallback)")
        embedding_ok = True

    if not embedding_ok:
        console.print("\n[red]✗ No embedding backend available.[/red]")
        console.print("  Setup will continue, but querying will fail until resolved.")

    # ── 3. Build index (or copy pre-built) ────────────────────────────────
    console.print()
    index_path = resolved / "index.jsonl"
    index_ok = False

    # Check for bundled index first to avoid 20-25min build
    from turnzero.config import get_bundled_index_path

    bundled_index = get_bundled_index_path()

    if bundled_index.exists() and bundled_index != index_path:
        if not index_path.exists() or force:
            console.print("Installing pre-built embedding index…")
            shutil.copy2(bundled_index, index_path)
            # Also copy per-source index if it exists in bundle (usually index_community.jsonl)
            bundled_community = bundled_index.parent / "index_community.jsonl"
            if bundled_community.exists():
                shutil.copy2(bundled_community, resolved / "index_community.jsonl")

            console.print("[green]✓[/green] Pre-built index installed")
            index_ok = True
        else:
            console.print("[dim]✓ Index already exists[/dim]")
            index_ok = True
    elif embedding_ok and dest_blocks.exists():
        if not index_path.exists() or force:
            console.print("Building embedding index from scratch…")
            env = os.environ.copy()
            env["TURNZERO_DATA_DIR"] = str(resolved)
            try:
                subprocess.run(
                    [sys.executable, "-m", "turnzero", "index", "build"],
                    env=env,
                    check=True,
                )
                console.print("[green]✓[/green] Index built")
                index_ok = True
            except subprocess.CalledProcessError:
                console.print(
                    "[red]✗ Index build failed — check embedding backend is ready[/red]"
                )
        else:
            console.print("[dim]✓ Index already exists[/dim]")
            index_ok = True
    else:
        console.print(
            "[dim]Skipping index build. Once embedding backend is ready, run:[/dim]\n"
            f"  [cyan]TURNZERO_DATA_DIR={resolved} turnzero index build[/cyan]"
        )

    # ── 4. Write hook script (optional) ──────────────────────────────────
    console.print()
    if with_hook:
        hook_path = claude_dir / "turnzero-hook.py"
        if not hook_path.exists() or force:
            hook_path.write_text(_generate_hook(resolved), encoding="utf-8")
            hook_path.chmod(0o755)
            console.print(f"[green]✓[/green] Hook written → {hook_path}")
        else:
            console.print(
                f"[dim]✓ Hook already exists ({hook_path}) — use --force to regenerate[/dim]"
            )

        # ── 5. Register hook in ~/.claude/settings.json ───────────────────
        settings_path = claude_dir / "settings.json"
        settings: dict[str, Any] = {}
        if settings_path.exists():
            with contextlib.suppress(json.JSONDecodeError):
                settings = json.loads(settings_path.read_text(encoding="utf-8"))

        hook_command = f"{sys.executable} {hook_path}"
        hook_entry = {"type": "command", "command": hook_command, "timeout": 6}
        hooks = settings.setdefault("hooks", {})
        submit_hooks = hooks.setdefault("UserPromptSubmit", [{"hooks": []}])
        hook_list = submit_hooks[0].setdefault("hooks", [])
        already = any("turnzero-hook.py" in h.get("command", "") for h in hook_list)
        if not already:
            hook_list.append(hook_entry)
            settings_path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
            console.print(f"[green]✓[/green] Hook registered in {settings_path}")
        else:
            console.print("[dim]✓ Hook already registered in settings.json[/dim]")
    else:
        console.print(
            "[dim]Hook not installed (MCP server is enough for most clients — use --with-hook for Claude Code guarantee)[/dim]"
        )

    # ── 6. Register MCP in ~/.claude.json ────────────────────────────────
    claude_json = Path.home() / ".claude.json"
    cfg: dict[str, Any] = {}
    if claude_json.exists():
        with contextlib.suppress(json.JSONDecodeError):
            cfg = json.loads(claude_json.read_text(encoding="utf-8"))

    mcp_bin = str(Path(sys.executable).parent / "turnzero-mcp")
    mcp_entry = {
        "type": "stdio",
        "command": mcp_bin,
        "env": {"TURNZERO_DATA_DIR": str(resolved)},
    }
    servers = cfg.setdefault("mcpServers", {})
    if "turnzero" not in servers or force:
        servers["turnzero"] = mcp_entry
        claude_json.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        console.print(f"[green]✓[/green] MCP server registered in {claude_json}")
    else:
        console.print("[dim]✓ MCP server already registered in .claude.json[/dim]")

    # ── 6b. Register MCP in ~/.codex/config.toml (Codex CLI) ─────────────
    _setup_codex_mcp(mcp_bin, resolved, force, console)

    # ── 6c. Register MCP in Cursor ──────────────────────────────────────
    _setup_cursor_mcp(mcp_bin, resolved, force, console)

    # ── 6d. Register MCP in Claude Desktop ──────────────────────────────
    _setup_claude_desktop_mcp(mcp_bin, resolved, force, console)

    # ── 6e. Register MCP in Gemini CLI ──────────────────────────────────
    _setup_gemini_mcp(mcp_bin, resolved, force, console)

    # ── 6f. Write global instruction rules (makes AI invoke tools reliably) ─
    _setup_claude_md(force, console)
    _setup_codex_agents_md(force, console)
    _setup_gemini_md(force, console)

    # ── 7. Telemetry disclosure + anonymous_id generation ─────────────────
    import uuid as _uuid

    from turnzero.config import (
        DEFAULT_ACTIVE_DOMAINS,
        load_config,
        load_telemetry_config,
        save_config,
        save_telemetry_config,
    )
    from turnzero.telemetry import track_setup_completed

    tel_cfg = load_telemetry_config(resolved)
    first_run = not tel_cfg.get("anonymous_id")
    if first_run:
        tel_cfg["anonymous_id"] = str(_uuid.uuid4())
        save_telemetry_config(resolved, tel_cfg)
        # Write default domain set so new users get curated expert prior coverage
        app_cfg = load_config(resolved)
        if app_cfg.get("active_domains") is None:
            app_cfg["active_domains"] = list(DEFAULT_ACTIVE_DOMAINS)
            save_config(resolved, app_cfg)

    # Show disclosure only on first setup — prominent, not hidden.
    if first_run:
        console.print()
        console.print("[bold]Telemetry[/bold]")
        console.print(
            "TurnZero collects [bold]anonymous[/bold] usage data to understand how the tool is used.\n"
            "\n"
            "  Collected : event names, domain names, block counts, client version, OS type\n"
            "  Never sent: prompts, prior content, file paths, API keys, personal data\n"
            "\n"
            "Telemetry is [bold]enabled by default[/bold]. To opt out now or any time:\n"
            "\n"
            "  [cyan]turnzero telemetry off[/cyan]\n"
            "\n"
            "Or set [cyan]TURNZERO_TELEMETRY=0[/cyan] in your environment.\n"
            "Details: [cyan]https://github.com/turnzero-ai/turnzero#telemetry[/cyan]"
        )

    from turnzero.embed import _is_onnx_available as _onnx_avail

    if _onnx_avail():
        embedding_backend = "onnx"
    elif os.environ.get("OPENAI_API_KEY"):
        embedding_backend = "openai"
    else:
        embedding_backend = "none"
    clients: list[str] = []
    if (Path.home() / ".claude.json").exists():
        with contextlib.suppress(Exception):
            _cfg = json.loads((Path.home() / ".claude.json").read_text())
            if "turnzero" in _cfg.get("mcpServers", {}):
                clients.append("claude_code")
    if (Path.home() / ".codex" / "config.toml").exists():
        clients.append("codex")
    if (Path.home() / ".gemini" / "settings.json").exists():
        clients.append("gemini_cli")
    track_setup_completed(
        embedding_backend=embedding_backend, clients_registered=clients
    )

    # ── 8. Summary ────────────────────────────────────────────────────────
    console.print()
    if embedding_ok and index_ok:
        console.print("[bold green]✓ Setup complete![/bold green]\n")
        # Show active domains so user knows what's loaded
        from turnzero.config import get_active_domains
        active = get_active_domains(resolved)
        if active is not None:
            domains_str = "  ·  ".join(f"[cyan]{d}[/cyan]" for d in active)
            console.print(
                f"  Active domains ({len(active)}):  {domains_str}\n"
                f"  [dim]Add more: [/dim][cyan]turnzero domain add <name>[/cyan]"
                f"  [dim]Browse: [/dim][cyan]turnzero domain list[/cyan]\n"
            )
        _print_setup_finale(interactive)
        console.print(
            "\nAdd [cyan]--with-hook[/cyan] for an extra guarantee on Claude Code."
        )
    else:
        console.print("[bold yellow]Partial setup complete.[/bold yellow]\n")
        console.print(
            "Resolve the issues above, then re-run:\n\n  [cyan]turnzero setup --force[/cyan]"
        )


def feedback(
    prompt: str = typer.Option(
        ..., "--prompt", "-p", help="The opening prompt that was used."
    ),
    correction: str = typer.Option(
        ..., "--correction", "-c", help="The correction text (what the user clarified)."
    ),
    slug: str = typer.Option(
        None,
        "--slug",
        "-s",
        help="The slug of the block that was suggested/injected (optional).",
    ),
) -> None:
    """Log user feedback/correction when a suggestion was missed or incorrect."""

    feedback_data = {
        "timestamp": int(time.time()),
        "prompt": prompt,
        "correction": correction,
        "slug": slug,
    }

    feedback_file = get_data_dir() / "feedback.jsonl"
    get_data_dir().mkdir(parents=True, exist_ok=True)

    with feedback_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(feedback_data) + "\n")

    console.print(f"[green]✓ Feedback logged to {feedback_file}[/green]")
    console.print(
        "[dim]This data will be used to improve future Expert Prior extractions.[/dim]"
    )


@source_app.command("list")
def source_list() -> None:
    """List available Expert Prior sources and their status."""
    from turnzero.config import load_config

    cfg = load_config(get_data_dir())
    console.print("\n[bold]Expert Prior Sources[/bold]\n")
    for tier, enabled in cfg["sources"].items():
        status = "[green]enabled[/green]" if enabled else "[dim]disabled[/dim]"
        console.print(f"  • [bold]{tier:<12}[/bold] {status}")
    console.print()


@source_app.command("enable")
def source_enable(
    tier: str = typer.Argument(..., help="Tier to enable (local/community/team)."),
) -> None:
    """Enable a specific Expert Prior source."""
    from turnzero.config import load_config, save_config

    if tier not in ("local", "community", "team"):
        err_console.print(f"[red]Invalid tier: {tier}[/red]")
        raise typer.Exit(1)

    cfg = load_config(get_data_dir())
    cfg["sources"][tier] = True
    save_config(get_data_dir(), cfg)
    console.print(f"[green]✓ Source '[bold]{tier}[/bold]' enabled.[/green]")


@source_app.command("disable")
def source_disable(
    tier: str = typer.Argument(..., help="Tier to disable (local/community/team)."),
) -> None:
    """Disable a specific Expert Prior source."""
    from turnzero.config import load_config, save_config

    if tier == "local":
        err_console.print("[red]Cannot disable 'local' source.[/red]")
        raise typer.Exit(1)

    cfg = load_config(get_data_dir())
    cfg["sources"][tier] = False
    save_config(get_data_dir(), cfg)
    console.print(f"[dim]✓ Source '[bold]{tier}[/bold]' disabled.[/dim]")
