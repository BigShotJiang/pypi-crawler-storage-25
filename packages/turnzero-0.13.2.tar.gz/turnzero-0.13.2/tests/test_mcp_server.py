"""Tests for MCP server tool logic (pure functions, no live server required)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from turnzero.blocks import compute_confidence
from turnzero.mcp_server import (
    _get_block,
    _inject_block,
    _list_suggested_blocks,
    _log_mcp_injection,
    _log_tool_call,
    learn_from_session,
)

# ---------------------------------------------------------------------------
# list_suggested_blocks
# ---------------------------------------------------------------------------


def test_list_suggested_blocks_returns_correct_top_result() -> None:
    results = _list_suggested_blocks(
        "help me build a Next.js app with Supabase authentication"
    )
    assert len(results) >= 1
    # Any nextjs block in top results is correct — hash embeddings may rank differently
    # from production embeddings; we validate domain correctness not exact rank
    block_ids = [r["block_id"] for r in results]
    assert any(
        bid.startswith("nextjs") or bid.startswith("supabase") for bid in block_ids
    )


def test_list_suggested_blocks_result_shape() -> None:
    results = _list_suggested_blocks("build a FastAPI async REST API")
    assert len(results) >= 1
    first = results[0]
    assert "block_id" in first
    assert "score" in first
    assert "domain" in first
    assert "intent" in first
    assert "tags" in first
    assert "context_weight" in first
    assert "stale" in first
    assert "preview" in first


def test_list_suggested_blocks_scores_in_range() -> None:
    results = _list_suggested_blocks("set up Docker Compose for production")
    for item in results:
        # 2.0 indicates an Identity Prior, others are Expert (0-1)
        assert 0.0 <= item["score"] <= 2.0


def test_list_suggested_blocks_docker_top_result() -> None:
    results = _list_suggested_blocks(
        "set up Docker Compose for a production deployment"
    )
    # Identity priors are injected first, look for the first Expert Prior
    expert_ids = [r["block_id"] for r in results if r["score"] < 2.0]
    assert expert_ids[0] == "docker-compose-production-build"


def test_list_suggested_blocks_typescript_top_result() -> None:
    results = _list_suggested_blocks(
        "migrate my JavaScript codebase to TypeScript strict mode"
    )
    # Identity priors injected first
    expert_ids = [r["block_id"] for r in results if r["score"] < 2.0]
    assert expert_ids[0] == "typescript-migration-migrate"


def test_list_suggested_blocks_postgresql_top_result() -> None:
    results = _list_suggested_blocks(
        "review my PostgreSQL schema and queries for performance"
    )
    # Identity priors injected first
    expert_ids = [r["block_id"] for r in results if r["score"] < 2.0]
    assert expert_ids[0] == "postgresql-indexing-review"


def test_list_suggested_blocks_respects_top_k() -> None:
    results = _list_suggested_blocks("build something", top_k=1)
    # Saturation Logic returns ALL high-confidence (0.90+) matches.
    # If we want to strictly test top_k, we need to check if there are any low-conf matches.
    experts = [r for r in results if r["score"] < 2.0]
    assert len(experts) >= 1


def test_list_suggested_blocks_high_threshold_returns_fewer() -> None:
    results_low = _list_suggested_blocks("build a Next.js app", threshold=0.40)
    results_high = _list_suggested_blocks("build a Next.js app", threshold=0.95)
    assert len(results_low) >= len(results_high)


def test_list_suggested_blocks_unknown_prompt_graceful() -> None:
    # Should not raise — may return empty list
    results = _list_suggested_blocks("xyzzy florp bleep noop", threshold=0.99)
    assert isinstance(results, list)


# ---------------------------------------------------------------------------
# get_block
# ---------------------------------------------------------------------------


def test_get_block_returns_correct_fields() -> None:
    data = _get_block("nextjs15-approuter-build")
    assert data["id"] == "nextjs15-approuter-build"
    assert data["domain"] == "nextjs"
    assert data["intent"] == "build"
    assert isinstance(data["constraints"], list)
    assert isinstance(data["anti_patterns"], list)
    assert isinstance(data["doc_anchors"], list)
    assert isinstance(data["tags"], list)
    assert isinstance(data["context_weight"], int)
    assert isinstance(data["stale"], bool)


def test_get_block_doc_anchors_shape() -> None:
    data = _get_block("nextjs15-approuter-build")
    assert len(data["doc_anchors"]) > 0
    for anchor in data["doc_anchors"]:
        assert "url" in anchor
        assert "verified" in anchor


def test_get_block_not_found_raises_value_error() -> None:
    with pytest.raises(ValueError, match="not found"):
        _get_block("nonexistent-block-id")


def test_get_block_error_lists_available() -> None:
    with pytest.raises(ValueError, match="nextjs15-approuter-build"):
        _get_block("nonexistent-block-id")


# ---------------------------------------------------------------------------
# inject_block
# ---------------------------------------------------------------------------


def test_inject_block_returns_markdown() -> None:
    text = _inject_block("nextjs15-approuter-build")
    assert "# EXPERT_PRIOR_IDENTITY" in text
    assert "# SESSION_CONSTRAINTS" in text
    assert "# ANTI_PATTERNS" in text


def test_inject_block_contains_block_id() -> None:
    text = _inject_block("fastapi-async-build")
    assert "fastapi-async-build" in text


def test_inject_block_not_found_raises_value_error() -> None:
    with pytest.raises(ValueError, match="not found"):
        _inject_block("nonexistent-block-id")


# ---------------------------------------------------------------------------
# deduplication
# ---------------------------------------------------------------------------


def test_list_suggested_blocks_no_duplicates() -> None:
    results = _list_suggested_blocks(
        "Build a Next.js 15 app router page that fetches data from an API and deploys on Vercel"
    )
    ids = [r["block_id"] for r in results]
    assert len(ids) == len(set(ids)), f"Duplicate block_ids returned: {ids}"


# ---------------------------------------------------------------------------
# MCP injection logging
# ---------------------------------------------------------------------------


def test_log_mcp_injection_writes_hook_log(data_dir: Path) -> None:
    _log_mcp_injection(
        block_ids=["nextjs15-approuter-build"],
        domains=["nextjs"],
        prompt_words=12,
        tokens_injected=480,
    )
    log_path = data_dir / "hook_log.jsonl"
    assert log_path.exists()
    entry = json.loads(log_path.read_text().strip())
    assert entry["blocks"] == ["nextjs15-approuter-build"]
    assert entry["domains"] == ["nextjs"]
    assert entry["prompt_words"] == 12
    assert entry["source"] == "mcp"
    assert entry["tokens_injected"] == 480
    assert "ts" in entry


def test_log_mcp_injection_appends(data_dir: Path) -> None:
    _log_mcp_injection(["block-a"], ["fastapi"], 5)
    _log_mcp_injection(["block-b"], ["nextjs"], 8)
    lines = (data_dir / "hook_log.jsonl").read_text().strip().splitlines()
    assert len(lines) == 2


# ---------------------------------------------------------------------------
# learn_from_session honest message
# ---------------------------------------------------------------------------


def test_learn_from_session_returns_harvest_instruction(data_dir: Path) -> None:
    result = learn_from_session(transcript="some session text", session_name="test")
    assert "turnzero harvest" in result
    assert "daemon" not in result.lower()


def test_inject_block_all_seed_blocks(
    data_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Use empty data dir so active_domains=None (all domains active — backward compat).
    # Without this, the user's real ~/.turnzero config may filter domains in this test.
    seed_ids = [
        "nextjs15-approuter-build",
        "supabase-auth-pkce-build",
        "fastapi-async-build",
        "typescript-strict-build",
        "postgresql-patterns-build",
        "docker-compose-production-build",
        "react-native-expo-build",
        "langchain-lcel-build",
    ]
    for block_id in seed_ids:
        text = _inject_block(block_id)
        assert len(text) > 100, f"{block_id}: injection text too short"


# ---------------------------------------------------------------------------
# compute_confidence
# ---------------------------------------------------------------------------


def test_compute_confidence_minimal_signals() -> None:
    score = compute_confidence("x", ["one constraint"], [], [], "")
    assert score == pytest.approx(0.25, abs=0.01)


def test_compute_confidence_full_signals() -> None:
    score = compute_confidence(
        "nextjs15-approuter-auth-build",
        ["Use App Router", "Pin to Next.js 15"],
        ["Do not use Pages Router", "Do not use getServerSideProps"],
        ["nextjs", "auth"],
        "AI used deprecated Pages Router API in Next.js 15 project",
    )
    assert score == pytest.approx(0.95, abs=0.01)


def test_compute_confidence_caps_at_0_95() -> None:
    for _ in range(3):
        score = compute_confidence(
            "a-b-c-d",
            ["c1", "c2", "c3"],
            ["Do not do x", "Do not do y"],
            ["tag1", "tag2"],
            "long enough reason here to get bonus",
        )
    assert score <= 0.95


def test_compute_confidence_reason_bonus() -> None:
    without = compute_confidence("slug-a-b", ["c1", "c2"], ["Do not x"], ["t"], "")
    with_reason = compute_confidence(
        "slug-a-b", ["c1", "c2"], ["Do not x"], ["t"], "AI got this wrong in session"
    )
    assert with_reason > without


def test_submit_candidate_writes_confidence_and_archived(data_dir: Path) -> None:
    import turnzero.services.candidate_svc as cand_svc

    orig_data = cand_svc.get_data_dir
    orig_blocks = cand_svc.get_blocks_dir
    orig_index = cand_svc.get_index_path

    data_dir = data_dir / "data"
    blocks_dir = data_dir / "blocks"
    index_file = data_dir / "index.jsonl"
    data_dir.mkdir()
    blocks_dir.mkdir()

    cand_svc.get_data_dir = lambda: data_dir
    cand_svc.get_blocks_dir = lambda: blocks_dir
    cand_svc.get_index_path = lambda: index_file

    try:
        from turnzero.mcp_server import submit_candidate

        submit_candidate(
            block_id="test-confidence-build",
            domain="fastapi",
            intent="build",
            constraints=["Use async def", "Use Pydantic v2"],
            anti_patterns=["Do not use sync def in async context"],
            tags=["fastapi"],
            reason="AI used sync def in async FastAPI route",
            auto_approve=False,
        )
        candidate_path = data_dir / "candidates" / "test-confidence-build.yaml"
        assert candidate_path.exists()
        data = yaml.safe_load(candidate_path.read_text())
        assert "confidence" in data
        assert 0.0 < data["confidence"] <= 0.95
        assert data["archived"] is False
    finally:
        cand_svc.get_data_dir = orig_data
        cand_svc.get_blocks_dir = orig_blocks
        cand_svc.get_index_path = orig_index


# ---------------------------------------------------------------------------
# ONB-3: "First Correction" Nudge
# ---------------------------------------------------------------------------


def _make_candidate_svc_patcher(tmp_path: Path) -> tuple:
    import turnzero.services.candidate_svc as cand_svc

    data_dir = tmp_path / "data"
    blocks_dir = data_dir / "blocks"
    index_file = data_dir / "index.jsonl"
    data_dir.mkdir()
    blocks_dir.mkdir()

    orig = (cand_svc.get_data_dir, cand_svc.get_blocks_dir, cand_svc.get_index_path)
    cand_svc.get_data_dir = lambda: data_dir
    cand_svc.get_blocks_dir = lambda: blocks_dir
    cand_svc.get_index_path = lambda: index_file
    return cand_svc, orig


def test_onb3_nudge_on_new_candidate(data_dir: Path) -> None:
    cand_svc, orig = _make_candidate_svc_patcher(data_dir)
    try:
        from turnzero.mcp_server import submit_candidate

        result = submit_candidate(
            block_id="onb3-test-build",
            domain="fastapi",
            intent="build",
            constraints=["Use async def"],
            anti_patterns=["Do not use sync def in async context"],
            reason="AI used sync def",
            auto_approve=False,
        )
        assert "💡 Correction captured" in result
        assert "turnzero review" in result
    finally:
        cand_svc.get_data_dir, cand_svc.get_blocks_dir, cand_svc.get_index_path = orig


def test_onb3_no_nudge_on_duplicate_candidate(data_dir: Path) -> None:
    cand_svc, orig = _make_candidate_svc_patcher(data_dir)
    try:
        from turnzero.mcp_server import submit_candidate

        submit_candidate(
            block_id="onb3-dupe-build",
            domain="fastapi",
            intent="build",
            constraints=["Use async def"],
            anti_patterns=["Do not use sync def in async context"],
            reason="first submission",
            auto_approve=False,
        )
        result = submit_candidate(
            block_id="onb3-dupe-build",
            domain="fastapi",
            intent="build",
            constraints=["Use async def"],
            anti_patterns=["Do not use sync def in async context"],
            reason="second submission",
            auto_approve=False,
        )
        assert "💡 Correction captured" not in result
        assert "updated in review queue" in result
    finally:
        cand_svc.get_data_dir, cand_svc.get_blocks_dir, cand_svc.get_index_path = orig


# ---------------------------------------------------------------------------
# _log_tool_call
# ---------------------------------------------------------------------------


def test_log_tool_call_writes_tool_call_log(data_dir: Path) -> None:
    _log_tool_call(
        "inject_block", {"block_id": "fastapi-async-build"}, "some text output"
    )
    log_path = data_dir / "tool_call_log.jsonl"
    assert log_path.exists()
    entry = json.loads(log_path.read_text().strip())
    assert entry["tool"] == "inject_block"
    assert entry["tokens_in"] > 0
    assert entry["tokens_out"] > 0
    assert "ts" in entry


def test_log_tool_call_appends_multiple_tools(data_dir: Path) -> None:
    _log_tool_call("list_suggested_blocks", {"prompt": "build a fastapi app"}, [])
    _log_tool_call("inject_block", {"block_id": "fastapi-async-build"}, "text")
    _log_tool_call(
        "submit_candidate", {"block_id": "x"}, "saved", meta={"auto_approve": True}
    )
    lines = (data_dir / "tool_call_log.jsonl").read_text().strip().splitlines()
    assert len(lines) == 3
    tools = [json.loads(ln)["tool"] for ln in lines]
    assert tools == ["list_suggested_blocks", "inject_block", "submit_candidate"]


def test_log_tool_call_meta_persisted(data_dir: Path) -> None:
    _log_tool_call(
        "submit_candidate",
        {"block_id": "x"},
        "ok",
        meta={"auto_approve": True, "block_id": "x"},
    )
    entry = json.loads((data_dir / "tool_call_log.jsonl").read_text().strip())
    assert entry["auto_approve"] is True
    assert entry["block_id"] == "x"


def test_log_tool_call_token_estimate_scales_with_payload(data_dir: Path) -> None:
    short_out = "short"
    long_out = "x" * 4000
    _log_tool_call("inject_block", {}, short_out)
    _log_tool_call("inject_block", {}, long_out)
    lines = (data_dir / "tool_call_log.jsonl").read_text().strip().splitlines()
    e_short = json.loads(lines[0])
    e_long = json.loads(lines[1])
    assert e_long["tokens_out"] > e_short["tokens_out"]


def test_get_stats_includes_tool_call_counts(data_dir: Path) -> None:
    from turnzero.mcp_server import get_stats

    _log_tool_call("list_suggested_blocks", {"prompt": "test"}, [])
    _log_tool_call("inject_block", {"block_id": "b"}, "text")
    result = get_stats()
    assert "tool_calls" in result
    assert result["tool_calls"]["total"] >= 2
    assert "list_suggested_blocks" in result["tool_calls"]["by_tool"]
    assert "inject_block" in result["tool_calls"]["by_tool"]


def test_inject_block_text_includes_token_metadata() -> None:
    """inject_block output must include PRIOR_METADATA with token count (RET-3)."""
    result = _inject_block("fastapi-async-build")
    assert "# PRIOR_METADATA" in result
    assert "tokens" in result
    assert "fastapi-async-build" in result


def test_get_stats_includes_context_tokens_injected(data_dir: Path) -> None:
    from turnzero.mcp_server import get_stats

    _log_mcp_injection(["block-a"], ["fastapi"], 10, tokens_injected=800)
    _log_mcp_injection(["block-b"], ["nextjs"], 8, tokens_injected=480)
    result = get_stats()
    assert "context_tokens_injected" in result
    assert result["context_tokens_injected"]["total"] == 1280


def test_get_stats_includes_token_cost(data_dir: Path) -> None:
    from turnzero.mcp_server import get_stats

    _log_tool_call("inject_block", {"block_id": "b"}, "some output text here")
    _log_tool_call(
        "submit_candidate", {"block_id": "x"}, "saved", meta={"auto_approve": True}
    )
    result = get_stats()
    assert "token_cost" in result
    assert result["token_cost"]["total"] > 0
    assert result["token_cost"]["submit_candidate_total"] > 0
    assert result["token_cost"]["total_in"] >= 0
    assert result["token_cost"]["total_out"] >= 0


# ---------------------------------------------------------------------------
# WF-1: process-scoped auto session_id
# ---------------------------------------------------------------------------


def test_effective_session_id_returns_caller_id_when_provided() -> None:
    from turnzero.mcp_server import _effective_session_id

    assert _effective_session_id("my-session") == "my-session"


def test_effective_session_id_returns_stable_proc_id_when_none() -> None:
    from turnzero.mcp_server import _effective_session_id

    id1 = _effective_session_id(None)
    id2 = _effective_session_id(None)
    assert id1 == id2
    assert len(id1) == 36  # UUID4 format


def test_rotate_proc_session_changes_id() -> None:
    from turnzero.mcp_server import _effective_session_id, _rotate_proc_session

    before = _effective_session_id(None)
    _rotate_proc_session()
    after = _effective_session_id(None)
    assert before != after


# ---------------------------------------------------------------------------
# WF-2: turn field and Turn 0 vs Turn N personal prior suppression
# ---------------------------------------------------------------------------


def test_list_suggested_blocks_turn_field_present() -> None:
    results = _list_suggested_blocks("build a fastapi app with postgres")
    real = [r for r in results if r.get("block_id") != "personal-priors-limit-warning"]
    assert all("turn" in r for r in real)


def test_list_suggested_blocks_first_turn_without_session() -> None:
    """No session_id → no exclude_ids → always Turn 0."""
    results = _list_suggested_blocks("build a fastapi app with postgres")
    real = [r for r in results if r.get("block_id") != "personal-priors-limit-warning"]
    assert all(r["turn"] == "first" for r in real)


def test_list_suggested_blocks_subsequent_turn_skips_personal(data_dir: Path) -> None:
    """After inject_block records an injection, next list call is Turn N."""
    from turnzero.state import record_session_injection

    sid = "wf2-test-session"
    record_session_injection(sid, "fake-prior-already-injected")

    results = _list_suggested_blocks(
        "build a fastapi app with postgres", session_id=sid
    )
    real = [
        r for r in results if r.get("block_id") != "personal-priors-limit-warning"
    ]
    assert all(r["turn"] == "subsequent" for r in real)
    personal = [r for r in real if r.get("preview", "").startswith("[personal")]
    assert personal == []


# ---------------------------------------------------------------------------
# WF-3: inject_all flag
# ---------------------------------------------------------------------------


def test_list_suggested_blocks_inject_all_includes_full_text() -> None:
    results = _list_suggested_blocks(
        "build a fastapi app with postgres", inject_all=True
    )
    real = [r for r in results if r.get("block_id") != "personal-priors-limit-warning"]
    assert len(real) > 0
    assert all("full_text" in r for r in real)
    assert all(
        isinstance(r["full_text"], str) and len(r["full_text"]) > 0 for r in real
    )


def test_list_suggested_blocks_no_inject_all_has_no_full_text() -> None:
    results = _list_suggested_blocks("build a fastapi app with postgres")
    assert all("full_text" not in r for r in results)


# ---------------------------------------------------------------------------
# UX-1: "no priors matched" hint
# ---------------------------------------------------------------------------


def test_no_match_hint_fires_when_impl_prompt_returns_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Impl gate passes but no blocks match → hint entry returned."""
    import turnzero.mcp_server as srv
    import turnzero.retrieval as ret
    import turnzero.services.retrieval_svc as rsvc

    monkeypatch.setattr(rsvc, "list_suggested_blocks", lambda *a, **kw: [])
    monkeypatch.setattr(ret, "is_implementation_prompt", lambda *a, **kw: True)

    results = srv.list_suggested_blocks("write a kubernetes deployment manifest")
    hint = [r for r in results if r.get("block_id") == "no-match-hint"]
    assert hint, "hint entry missing when gate passes and results empty"
    assert "turnzero query" in hint[0]["preview"]


def test_no_match_hint_suppressed_for_chitchat(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Chitchat → gate fails → no hint even when results empty."""
    import turnzero.mcp_server as srv
    import turnzero.retrieval as ret
    import turnzero.services.retrieval_svc as rsvc

    monkeypatch.setattr(rsvc, "list_suggested_blocks", lambda *a, **kw: [])
    monkeypatch.setattr(ret, "is_implementation_prompt", lambda *a, **kw: False)

    results = srv.list_suggested_blocks("thanks looks good")
    hint = [r for r in results if r.get("block_id") == "no-match-hint"]
    assert not hint, "hint must not fire for chitchat"


def test_no_match_hint_not_added_when_results_exist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-empty results → no hint appended."""
    import turnzero.mcp_server as srv
    import turnzero.services.retrieval_svc as rsvc

    fake = [{"block_id": "py-build", "score": 0.85, "domain": "python",
             "intent": "build", "tags": [], "context_weight": 100,
             "stale": False, "turn": "first", "preview": "…"}]
    monkeypatch.setattr(rsvc, "list_suggested_blocks", lambda *a, **kw: fake)

    results = srv.list_suggested_blocks("write a python script")
    hint = [r for r in results if r.get("block_id") == "no-match-hint"]
    assert not hint
