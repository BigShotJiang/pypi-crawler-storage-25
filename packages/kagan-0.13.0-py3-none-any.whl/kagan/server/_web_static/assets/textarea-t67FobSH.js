import{l as o,j as a,m as i}from"./index-CHfwSRND.js";/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],s=o("chevron-down",t);function d({className:r,...e}){return a.jsx("textarea",{"data-slot":"textarea",className:i("flex field-sizing-content min-h-16 w-full border border-input bg-[color:var(--surface-1)] px-3 py-2 text-base shadow-[var(--inset-shadow)] transition-[border-color,color,box-shadow,background-color] outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 md:text-sm dark:aria-invalid:ring-destructive/40",r),...e})}export{s as C,d as T};
