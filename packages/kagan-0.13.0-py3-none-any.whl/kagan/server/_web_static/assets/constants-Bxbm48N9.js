import{l as a}from"./index-CHfwSRND.js";/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}],["path",{d:"M5 12.859a10 10 0 0 1 5.17-2.69",key:"1dl1wf"}],["path",{d:"M19 12.859a10 10 0 0 0-2.007-1.523",key:"4k23kn"}],["path",{d:"M2 8.82a15 15 0 0 1 4.177-2.643",key:"1grhjp"}],["path",{d:"M22 8.82a15 15 0 0 0-11.288-3.764",key:"z3jwby"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]],h=a("wifi-off",t);/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["path",{d:"M5 12.859a10 10 0 0 1 14 0",key:"1x1e6c"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}]],i=a("wifi",e),p={github:"https://github.com/kagan-sh/kagan",license:"https://github.com/kagan-sh/kagan/blob/main/LICENSE",makerx:"https://makerx.com.au",docs:"https://docs.kagan.sh",discord:"https://discord.gg/dB5AgMwWMy",pypi:"https://pypi.org/project/kagan/"},s={name:"Kagan",tagline:"AI Coding Agent Orchestrator",makerxName:"MakerX",license:"MIT",copyrightYear:new Date().getFullYear()};export{s as K,i as W,p as a,h as b};
