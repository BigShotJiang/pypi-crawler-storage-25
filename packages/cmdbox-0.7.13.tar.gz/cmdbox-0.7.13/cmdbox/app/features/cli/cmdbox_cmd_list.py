from cmdbox.app import common, feature
from cmdbox.app.auth import signin
from cmdbox.app.commons import resdata, testable, validator
from cmdbox.app.options import Options
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import glob
import logging
import pydantic


class CmdList(feature.OneshotResultEdgeFeature, validator.Validator, testable.UnitTestable):
    def get_mode(self) -> Union[str, List[str]]:
        """
        この機能のモードを返します

        Returns:
            Union[str, List[str]]: モード
        """
        return 'cmd'

    def get_cmd(self):
        """
        この機能のコマンドを返します

        Returns:
            str: コマンド
        """
        return 'list'
    
    def get_option(self):
        """
        この機能のオプションを返します

        Returns:
            Dict[str, Any]: オプション
        """
        return dict(
            use_redis=self.USE_REDIS_FALSE, nouse_webmode=False, use_agent=False,
            description_ja="データフォルダ配下のコマンドリストを取得します。",
            description_en="Obtains a list of commands under the data folder.",
            choice=[
                dict(opt="data", type=Options.T_DIR, default=self.default_data, required=True, multi=False, hide=False, choice=None, web="mask",
                     description_ja=f"省略した時は `$HONE/.{self.ver.__appid__}` を使用します。",
                     description_en=f"When omitted, `$HONE/.{self.ver.__appid__}` is used."),
                dict(opt="kwd", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                     description_ja=f"検索したい名前を指定します。中間マッチで検索します。",
                     description_en=f"Specify the name you want to search for. Searches for partial matches."),
                dict(opt="match_mode", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                     description_ja=f"検索したいコマンドのmode条件を指定します。中間マッチで検索します。",
                     description_en=f"Specify the mode condition of the command you want to search in. Searches for partial matches."),
                dict(opt="match_cmd", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                     description_ja=f"検索したいコマンドのcmd条件を指定します。中間マッチで検索します。",
                     description_en=f"Specify the cmd condition of the command you want to search in. Searches for partial matches."),
                dict(opt="match_opt", type=Options.T_STR, default=None, required=False, multi=True, hide=False, choice=None,
                     description_ja=f"検索したいコマンドのopt名を指定します。",
                     description_en=f"Specify the opt name of the command you want to search in."),
                dict(opt="signin_file", type=Options.T_FILE, default=f'.{self.ver.__appid__}/user_list.yml', required=True, multi=False, hide=False, choice=None, fileio="in", web="mask",
                     description_ja=f"サインイン可能なユーザーとパスワードを記載したファイルを指定します。通常 '.{self.ver.__appid__}/user_list.yml' を指定します。",
                     description_en=f"Specify a file containing users and passwords with which they can signin.Typically, specify '.{self.ver.__appid__}/user_list.yml'."),
                dict(opt="groups", type=Options.T_STR, default=None, required=False, multi=True, hide=False, choice=None, web="mask",
                     description_ja="`signin_file` を指定した場合に、このユーザーグループに許可されているコマンドリストを返すように指定します。",
                     description_en="Specifies that `signin_file`, if specified, should return the list of commands allowed for this user group."),
            ]
        )

    @validator.apprun_check
    def apprun(self, logger:logging.Logger, args:argparse.Namespace, tm:float, pf:List[Dict[str, float]]=[]) -> Tuple[int, Dict[str, Any], Any]:
        """
        この機能の実行を行います

        Args:
            logger (logging.Logger): ロガー
            args (argparse.Namespace): 引数
            tm (float): 実行開始時間
            pf (List[Dict[str, float]]): 呼出元のパフォーマンス情報

        Returns:
            Tuple[int, Dict[str, Any], Any]: 終了コード, 結果, オブジェクト
        """
        kwd = args.kwd
        if kwd is None or kwd == '':
            kwd = '*'
        if not hasattr(self, 'signin_file_data') or self.signin_file_data is None:
            self.signin_file_data = signin.Signin.load_signin_file(args.signin_file, None, self=self, logger=logger)
        paths = glob.glob(str(Path(args.data) / ".cmds" / f"cmd-{kwd}.json"))
        cmd_list = [common.loadopt(path, True) for path in paths]
        cmd_list = sorted(cmd_list, key=lambda cmd: cmd["title"])
        is_japan = common.is_japan(args=args)
        options = Options.getInstance()
        ret_list = []
        args.match_opt = [opt for opt in args.match_opt if opt] if args.match_opt is not None and isinstance(args.match_opt, list) else []
        for r in cmd_list:
            if args.match_mode is not None and args.match_mode != '' and args.match_mode not in r['mode']:
                continue
            if args.match_cmd is not None and args.match_cmd != '' and args.match_cmd not in r['cmd']:
                continue
            if args.match_cmd is not None and args.match_cmd != '' and args.match_cmd not in r['cmd']:
                continue
            if len([k for k in args.match_opt if k not in r]) > 0:
                continue
            scope = signin.get_request_scope()
            user_session = scope["req"].session.get('signin', {}) if scope and scope["req"] is not None else {}
            if not signin.Signin._check_cmd(signin_file_data=self.signin_file_data, user_groups=args.groups, mode=r['mode'], cmd=r['cmd'],
                                            opt=args.__dict__, user_name="unknown", user_session=user_session, logger=logger,
                                            appcls=self.appcls, ver=self.ver, language=self.language):
                continue
            row = dict(title=r.get('title',''),
                       mode=r['mode'],
                       cmd=r['cmd'],
                       description=r.get('description','') + str(options.get_cmd_attr(r['mode'], r['cmd'], 'description_ja' if is_japan else 'description_en')),
                       tag=r.get('tag',[]))
            ret_list.append(row)
        ret = dict(success=dict(data=ret_list))

        common.print_format(ret, args.format, tm, args.output_json, args.output_json_append, pf=pf)

        if 'success' not in ret:
            return self.RESP_WARN, ret, None

        return self.RESP_SUCCESS, ret, None

    def output_schema(self) -> type:
        class CmdRecord(resdata.Base):
            title: Union[str, None] = pydantic.Field(default=None, description="タイトル")
            mode: Union[str, None] = pydantic.Field(default=None, description="モード")
            cmd: Union[str, None] = pydantic.Field(default=None, description="コマンド")
            description: Union[str, None] = pydantic.Field(default=None, description="説明")
            tag: Union[List[str], None] = pydantic.Field(default=None, description="タグリスト")
        class Data(resdata.Data):
            data: Union[List[CmdRecord], None] = pydantic.Field(default=None, description="処理結果のデータ")
        class Result(resdata.Result):
            success: Union[Data, List[CmdRecord], None] = pydantic.Field(default=None, description="成功した場合の結果")
        return Result

    def create_tests(self, logger:logging.Logger, base_args:argparse.Namespace, tm:float, pf:List[Dict[str, float]]) -> List[testable.TestCase]:
        """
        テストケースを作成するためのメソッド
        Returns:
            List[testable.TestCase]: テストケースのリスト
        """
        tests = []
        _0_args = argparse.Namespace(**vars(base_args))
        tests.append(testable.TestCase(
            name="正常系テスト",
            description="これは正常系のケースです。",
            args=_0_args,
            output=(0, dict(success=dict(data="")), None),
        ))
        return tests

    def assertion(self, logger:logging.Logger, test_args:argparse.Namespace, tm:float, pf:List[Dict[str, float]], _bef:Any, _res:Tuple[int, Dict[str, Any], Any], output:Tuple[int, Dict[str, Any], Any]) -> None:
        """
        テスト結果を検証するためのメソッド
        Args:
            logger (logging.Logger): ロガーオブジェクト
            test_args (argparse.Namespace): コマンドの引数を含むNamespaceオブジェクト
            tm (float): コマンドの実行時間を測定するためのタイムスタンプ
            pf (List[Dict[str, float]]): コマンドの実行時間を測定するためのパフォーマンスデータのリスト
            _bef (Any): 前処理の結果
            _res (Tuple[int, Dict[str, Any], Any]): コマンドの実行結果(リターンコード、メッセージ、オブジェクト)
            output (Tuple[int, Dict[str, Any], Any]): 期待される出力(リターンコード、メッセージ、オブジェクト)
        Returns:
            None
        """
        logger.info("Running assertion...")
        assert output.get('success') is not None, "Output must contain 'success' key"
        assert output.get('success',{}).get('data',None) is not None, "Output 'success' must contain 'data' key"
        assert len(output.get('success',{}).get('data',[])) > 0, "Output 'success' 'data' must contain at least one command record"
