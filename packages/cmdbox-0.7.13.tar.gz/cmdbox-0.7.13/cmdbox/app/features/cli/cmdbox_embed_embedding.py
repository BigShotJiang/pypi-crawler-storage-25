from cmdbox.app import common, client, feature
from cmdbox.app.commons import convert, redis_client, resdata, validator
from cmdbox.app.options import Options
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import json
import numpy as np
import pydantic
import re


class EmbedEmbedding(feature.OneshotResultEdgeFeature, validator.Validator):
    def get_mode(self) -> Union[str, List[str]]:
        """
        この機能のモードを返します

        Returns:
            Union[str, List[str]]: モード
        """
        return 'embed'

    def get_cmd(self) -> str:
        """
        この機能のコマンドを返します

        Returns:
            str: コマンド
        """
        return 'embedding'

    def get_option(self) -> Dict[str, Any]:
        """
        この機能のオプションを返します

        Returns:
            Dict[str, Any]: オプション
        """
        return dict(
            use_redis=self.USE_REDIS_TRUE, nouse_webmode=False, use_agent=True,
            description_ja="入力情報の特徴量データを生成します。",
            description_en="Generates feature data from input information.",
            choice=[
                dict(opt="host", type=Options.T_STR, default=self.default_host, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスホストを指定します。",
                     description_en="Specify the service host of the Redis server."),
                dict(opt="port", type=Options.T_INT, default=self.default_port, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスポートを指定します。",
                     description_en="Specify the service port of the Redis server."),
                dict(opt="password", type=Options.T_PASSWD, default=self.default_pass, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja=f"Redisサーバーのアクセスパスワード(任意)を指定します。省略時は `{self.default_pass}` を使用します。",
                     description_en=f"Specify the access password of the Redis server (optional). If omitted, `{self.default_pass}` is used."),
                dict(opt="svname", type=Options.T_STR, default=self.default_svname, required=True, multi=False, hide=True, choice=None, web="readonly",
                     description_ja="サーバーのサービス名を指定します。",
                     description_en="Specify the service name of the inference server."),
                dict(opt="retry_count", type=Options.T_INT, default=3, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーへの再接続回数を指定します。",
                     description_en="Specifies the number of reconnections to the Redis server."),
                dict(opt="retry_interval", type=Options.T_INT, default=5, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーに再接続までの秒数を指定します。",
                     description_en="Specifies the number of seconds before reconnecting to the Redis server."),
                dict(opt="timeout", type=Options.T_INT, default=120, required=False, multi=False, hide=True, choice=None,
                     description_ja="サーバーの応答が返ってくるまでの最大待ち時間を指定。",
                     description_en="Specify the maximum waiting time until the server responds."),
                dict(opt="embed_name", type=Options.T_STR, default="ruri-v3-30m", required=True, multi=False, hide=False, choice=None,
                     description_ja="エンベッドモデルの登録名を指定します。",
                     description_en="Specify the registration name of the embed model."),
                 dict(opt="original_data", type=Options.T_TEXT, default=None, required=True, multi=True, hide=False, choice=None,
                    description_ja="特徴量を生成する元のデータを指定します。",
                    description_en="Specify the original data to generate feature vectors."),
            ]
        )

    @validator.apprun_check
    def apprun(self, logger: logging.Logger, args: argparse.Namespace, tm: float, pf: List[Dict[str, float]] = []) -> Tuple[int, Dict[str, Any], Any]:

        payload = dict(embed_name=args.embed_name, original_data=args.original_data)
        payload_b64 = convert.str2b64str(common.to_str(payload))

        cl = client.Client(logger, redis_host=args.host, redis_port=args.port, redis_password=args.password, svname=args.svname)
        ret = cl.redis_cli.send_cmd(self.get_svcmd(), [payload_b64],
                                    retry_count=args.retry_count, retry_interval=args.retry_interval, timeout=args.timeout, nowait=False)
        common.print_format(ret, args.format, tm, args.output_json, args.output_json_append, pf=pf)
        if 'success' not in ret:
            return self.RESP_WARN, ret, cl
        return self.RESP_SUCCESS, ret, cl

    def output_schema(self) -> type:
        class Data(resdata.Data):
            data: Union[List[Any], None] = pydantic.Field(default=None, description="処理結果のデータ")
        class Result(resdata.Result):
            success: Union[Data, None] = pydantic.Field(default=None, description="成功した場合の結果")
        return Result

    def is_cluster_redirect(self):
        return False

    def svrun(self, data_dir:Path, logger:logging.Logger, redis_cli:redis_client.RedisClient, msg:List[str],
              sessions:Dict[str, Dict[str, Any]]) -> int:
        reskey = msg[1]
        try:
            payload = json.loads(convert.b64str2str(msg[2]))
            embed_name = payload.get('embed_name', 'None')
            original_data = payload.get('original_data', [])

            if 'agent' not in sessions:
                sessions['agent'] = {}
            if 'embed_model' not in sessions['agent']:
                sessions['agent']['embed_model'] = {}
            if embed_name not in sessions['agent']['embed_model']:
                msg = dict(warn=f"Embed model '{embed_name}' is not loaded.")
                redis_cli.rpush(reskey, msg)
                return self.RESP_WARN

            from sentence_transformers import SentenceTransformer
            model:SentenceTransformer = sessions['agent']['embed_model'][embed_name]
            st, msg, _ = self.__class__._embedding(model, original_data)
            redis_cli.rpush(reskey, msg)
            if st != self.RESP_SUCCESS:
                return self.RESP_WARN
            return self.RESP_SUCCESS

        except Exception as e:
            msg = dict(warn=f"{self.get_mode()}_{self.get_cmd()}: {e}")
            logger.warning(f"{self.get_mode()}_{self.get_cmd()}: {e}", exc_info=True)
            redis_cli.rpush(reskey, msg)
            return self.RESP_WARN

    @classmethod
    def _embedding(cls, model, original_data:List[str]) -> Tuple[int, Dict[str, Any], List[str]]:
        embeddings:np.ndarray = model.encode(original_data, convert_to_numpy=True)
        list_data = []
        list_str = []
        for i,eb in enumerate(embeddings):
            b64str = convert.npy2b64str(eb)
            list_data.append(dict(data=original_data[i], embed=b64str, type=str(eb.dtype), shape=eb.shape))
            list_str.append(str(eb.tolist()))
        msg = dict(success=list_data)
        return cls.RESP_SUCCESS, msg, list_str
