from cmdbox.app import common, client, feature
from cmdbox.app.commons import cache, convert, redis_client, resdata, validator
from cmdbox.app.options import Options
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import json
import pydantic
import re


class AgentAgentLoad(feature.OneshotResultEdgeFeature, validator.Validator):
    def __init__(self, appcls, ver, language = None):
        super().__init__(appcls, ver, language)
        self._cache = cache.MemoryCache()

    def get_mode(self) -> Union[str, List[str]]:
        return 'agent'

    def get_cmd(self) -> str:
        return 'agent_load'

    def get_option(self) -> Dict[str, Any]:
        return dict(
            use_redis=self.USE_REDIS_TRUE, nouse_webmode=False, use_agent=False,
            description_ja="Agent 設定を読み込みます。",
            description_en="Loads agent configuration.",
            choice=[
                dict(opt="host", type=Options.T_STR, default=self.default_host, required=True, multi=False, hide=True, choice=None, web="mask",
                    description_ja="Redisサーバーのサービスホストを指定します。",
                    description_en="Specify the service host of the Redis server."),
                dict(opt="port", type=Options.T_INT, default=self.default_port, required=True, multi=False, hide=True, choice=None, web="mask",
                    description_ja="Redisサーバーのサービスポートを指定します。",
                    description_en="Specify the service port of the Redis server."),
                dict(opt="password", type=Options.T_PASSWD, default=self.default_pass, required=True, multi=False, hide=True, choice=None, web="mask",
                    description_ja=f"Redisサーバーのアクセスパスワード(任意)を指定します。省略時は `{self.default_pass}` を使用します。",
                    description_en=f"Specify the access password of the Redis server (optional). If omitted, `{self.default_pass}` is used."),
                dict(opt="svname", type=Options.T_STR, default=self.default_svname, required=True, multi=False, hide=True, choice=None, web="readonly",
                    description_ja="サーバーのサービス名を指定します。省略時は `server` を使用します。",
                    description_en="Specify the service name of the inference server. If omitted, `server` is used."),
                dict(opt="retry_count", type=Options.T_INT, default=3, required=False, multi=False, hide=True, choice=None,
                    description_ja="Redisサーバーへの再接続回数を指定します。0以下を指定すると永遠に再接続を行います。",
                    description_en="Specifies the number of reconnections to the Redis server.If less than 0 is specified, reconnection is forever."),
                dict(opt="retry_interval", type=Options.T_INT, default=5, required=False, multi=False, hide=True, choice=None,
                    description_ja="Redisサーバーに再接続までの秒数を指定します。",
                    description_en="Specifies the number of seconds before reconnecting to the Redis server."),
                dict(opt="timeout", type=Options.T_INT, default="60", required=False, multi=False, hide=True, choice=None,
                    description_ja="サーバーの応答が返ってくるまでの最大待ち時間を指定。",
                    description_en="Specify the maximum waiting time until the server responds."),
                 dict(opt="agent_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="読み込むAgent設定の名前を指定します。",
                     description_en="Specify the name of the agent configuration to load."),
                dict(opt="cache_timeout", type=Options.T_INT, default="60", required=False, multi=False, hide=False, choice=None,
                     description_ja="設定をキャッシュする時間を秒数で指定します。",
                     description_en="Specify the duration, in seconds, for which settings should be cached."),
            ]
       )

    @validator.apprun_check
    def apprun(self, logger: logging.Logger, args: argparse.Namespace, tm: float, pf: List[Dict[str, float]] = []) -> Tuple[int, Dict[str, Any], Any]:
        # キャッシュが有効で、かつキャッシュが存在し、有効期限が切れていない場合はキャッシュを返す
        cached = self._cache.get(args.agent_name)
        if cached is not None:
            ret = dict(success=cached)
            common.print_format(ret, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_SUCCESS, ret, None

        payload = dict(agent_name=args.agent_name)
        payload_b64 = convert.str2b64str(common.to_str(payload))

        cl = client.Client(logger, redis_host=args.host, redis_port=args.port, redis_password=args.password, svname=args.svname)
        ret = cl.redis_cli.send_cmd(self.get_svcmd(), [payload_b64],
                                    retry_count=args.retry_count, retry_interval=args.retry_interval, timeout=args.timeout, nowait=False)
        common.print_format(ret, args.format, tm, args.output_json, args.output_json_append, pf=pf)
        if 'success' not in ret:
            return self.RESP_WARN, ret, cl

        # 読み込んだ設定をキャッシュする
        self._cache.set(args.agent_name, ret.get('success', None), args.cache_timeout)
        return self.RESP_SUCCESS, ret, cl

    def output_schema(self) -> type:
        """
        コマンドの実行結果スキーマを表すクラスを返します

        Returns:
            type: 結果のスキーマクラス
        """
        class Data(resdata.Data):
            agent_name: str = pydantic.Field(default=None, description="エージェント名")
            agent_type: str = pydantic.Field(default=None, description="エージェントタイプ")
            use_planner: Union[bool, None] = pydantic.Field(default=None, description="プランナー使用フラグ")
            a2asv_baseurl: Union[str, None] = pydantic.Field(default=None, description="A2AサーバーのベースURL")
            a2asv_delegated_auth: Union[bool, None] = pydantic.Field(default=None, description="A2Aサーバーの委任認証フラグ")
            a2asv_apikey: Union[str, None] = pydantic.Field(default=None, description="A2AサーバーのAPIキー")
            llm: Union[str, None] = pydantic.Field(default=None, description="LLM名")
            mcpservers: Union[List[str], None] = pydantic.Field(default=None, description="MCPサーバーリスト")
            subagents: Union[List[str], None] = pydantic.Field(default=None, description="サブエージェントリスト")
            agent_description: Union[str, None] = pydantic.Field(default=None, description="エージェントの説明")
            agent_instruction: Union[str, None] = pydantic.Field(default=None, description="エージェントへの指示")
        class Result(resdata.Result):
            success: Data = pydantic.Field(description="成功した場合の結果")
        return Result

    def is_cluster_redirect(self):
        return False

    def svrun(self, data_dir:Path, logger:logging.Logger, redis_cli:redis_client.RedisClient, msg:List[str],
              sessions:Dict[str, Dict[str, Any]]) -> int:
        reskey = msg[1]
        try:
            payload = json.loads(convert.b64str2str(msg[2]))
            name = payload.get('agent_name')

            configure_path = data_dir / ".agent" / f"agent-{name}.json"
            if not configure_path.exists():
                msg = dict(warn=f"Specified agent configuration '{name}' not found on server at '{str(configure_path)}'.")
                redis_cli.rpush(reskey, msg)
                return self.RESP_WARN

            with configure_path.open('r', encoding='utf-8') as f:
                data = json.load(f)

            msg = dict(success=data)
            redis_cli.rpush(reskey, msg)
            return self.RESP_SUCCESS

        except Exception as e:
            msg = dict(warn=f"{self.get_mode()}_{self.get_cmd()}: {e}")
            logger.warning(f"{self.get_mode()}_{self.get_cmd()}: {e}", exc_info=True)
            redis_cli.rpush(reskey, msg)
            return self.RESP_WARN
