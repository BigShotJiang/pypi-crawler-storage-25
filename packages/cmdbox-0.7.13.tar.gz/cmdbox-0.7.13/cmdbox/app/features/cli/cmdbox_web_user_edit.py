from cmdbox.app import common, feature, web
from cmdbox.app.commons import resdata, validator
from cmdbox.app.options import Options
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import pydantic


class WebUserEdit(feature.UnsupportEdgeFeature, validator.Validator):
    def get_mode(self) -> Union[str, List[str]]:
        """
        この機能のモードを返します

        Returns:
            Union[str, List[str]]: モード
        """
        return 'web'

    def get_cmd(self):
        """
        この機能のコマンドを返します

        Returns:
            str: コマンド
        """
        return 'user_edit'
    
    def get_option(self):
        """
        この機能のオプションを返します

        Returns:
            Dict[str, Any]: オプション
        """
        return dict(
            use_redis=self.USE_REDIS_MEIGHT, nouse_webmode=False, use_agent=False,
            description_ja="Webモードのユーザーを編集します。",
            description_en="Edit users in Web mode.",
            choice=[
                dict(opt="user_id", type=Options.T_INT, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="ユーザーIDを指定します。",
                     description_en="Specify the user ID."),
                dict(opt="user_name", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="ユーザー名を指定します。他のユーザーと重複しないようにしてください。",
                     description_en="Specify a user name. Do not duplicate other users."),
                dict(opt="user_pass", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                     description_ja="ユーザーパスワードを指定します。",
                     description_en="Specify the user password."),
                dict(opt="user_pass_hash", type=Options.T_STR, default='sha1', required=False, multi=False, hide=False, choice=['oauth2', 'saml', 'plain', 'md5', 'sha1', 'sha256'],
                     description_ja="ユーザーパスワードのハッシュアルゴリズムを指定します。",
                     description_en="Specifies the hash algorithm for user passwords."),
                dict(opt="user_email", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None,
                     description_ja="ユーザーメールアドレスを指定します。 `user_pass_hash` が `oauth2` 又は `saml` の時は必須です。",
                     description_en="Specify the user email. Required when `user_pass_hash` is `oauth2` or `saml`."),
                dict(opt="user_group", type=Options.T_STR, default=None, required=True, multi=True, hide=False, choice=None,
                     description_ja="ユーザーが所属するグループを指定します。",
                     description_en="Specifies the groups to which the user belongs."),
                dict(opt="user_home", type=Options.T_STR, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="ユーザーのホームディレクトリを指定します。",
                     description_en="Specify the home directory for the user."),
                dict(opt="signin_file", type=Options.T_FILE, default=f'.{self.ver.__appid__}/user_list.yml', required=True, multi=False, hide=False, choice=None, fileio="in", web="mask",
                     description_ja=f"サインイン可能なユーザーとパスワードを記載したファイルを指定します。通常 '.{self.ver.__appid__}/user_list.yml' を指定します。",
                     description_en=f"Specify a file containing users and passwords with which they can signin.Typically, specify '.{self.ver.__appid__}/user_list.yml'."),
            ]
        )

    @validator.apprun_check
    def apprun(self, logger:logging.Logger, args:argparse.Namespace, tm:float, pf:List[Dict[str, float]]=[]) -> Tuple[int, Dict[str, Any], Any]:
        """
        この機能の実行を行います

        Args:
            logger (logging.Logger): ロガー
            args (argparse.Namespace): 引数
            tm (float): 実行開始時間
            pf (List[Dict[str, float]]): 呼出元のパフォーマンス情報

        Returns:
            Tuple[int, Dict[str, Any], Any]: 終了コード, 結果, オブジェクト
        """
        w = None
        try:
            w = web.Web(logger, self.default_data, appcls=self.appcls, ver=self.ver,
                        redis_host=self.default_host, redis_port=self.default_port, redis_password=self.default_pass, svname=self.default_svname,
                        signin_file=args.signin_file)
            user = dict(uid=args.user_id, name=args.user_name, password=args.user_pass, hash=args.user_pass_hash,
                        email=args.user_email, groups=args.user_group, home=args.user_home)
            w.user_edit(user)
            msg = dict(success=f"User ID {args.user_id} has been edited.")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_SUCCESS, msg, w
        except Exception as e:
            msg = dict(warn=f"{e}")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_WARN, msg, w

    def output_schema(self) -> type:
        class Data(resdata.Data):
            data: Union[str, None] = pydantic.Field(default=None, description="処理結果のデータ")
        class Result(resdata.Result):
            success: Union[Data, None] = pydantic.Field(default=None, description="成功した場合の結果")
        return Result
