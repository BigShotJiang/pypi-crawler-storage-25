"""
Asynchronous token validation with TTL-based JWKS and discovery caching.

This module provides asynchronous token validation using discovery and JWKS,
with automatic cache expiry and forced JWKS refresh on key rotation.
"""

import asyncio
import time

from ..core.discovery_policy import DiscoveryPolicy
from ..core.jwks_cache import (
    DiscoCacheEntry,
    JwksCacheEntry,
    apply_disco_cache_outcome,
    apply_jwks_cache_outcome,
    is_cache_expired,
    should_attempt_kid_miss_refresh,
)
from ..core.models import (
    DiscoveryDocumentRequest,
    DiscoveryDocumentResponse,
    JwksRequest,
    JwksResponse,
    TokenValidationConfig,
)
from ..core.parsers import (
    extract_jwt_header_fields,
    find_key_by_kid,
)
from ..core.token_validation_logic import (
    build_resolved_config,
    decode_with_config,
    log_validation_start,
    log_validation_success,
    validate_async_claims,
    validate_config_for_manual_validation,
    validate_disco_response,
    validate_jwks_response,
    validate_jwks_uri,
)
from ..core.validators import validate_token_config
from ..exceptions import ConfigurationException, SignatureVerificationException
from ..logging_config import logger
from .discovery import get_discovery_document
from .jwks import get_jwks
from .managed_client import AsyncHTTPClient


# ============================================================================
# Discovery TTL cache
# ============================================================================

# Discovery TTL cache — keyed by (address, require_https) to prevent policy bypass
_disco_cache: dict[tuple[str, bool], DiscoCacheEntry] = {}
# Brief CPU-only write lock; does NOT span the upstream HTTP fetch. See
# the sync module for the full rationale and the cache-aside pattern.
_disco_cache_write_lock = asyncio.Lock()
# Per-URI fetch locks (striped). Allows two coroutines waiting on
# discovery for *different* addresses to run in parallel rather than
# serializing on a single global lock held across an awaited HTTP call.
_DISCO_LOCK_STRIPES = 32
_disco_fetch_locks: list[asyncio.Lock] = [
    asyncio.Lock() for _ in range(_DISCO_LOCK_STRIPES)
]


def _get_disco_fetch_lock(cache_key: tuple[str, bool]) -> asyncio.Lock:
    return _disco_fetch_locks[hash(cache_key) % _DISCO_LOCK_STRIPES]


async def _get_disco_response(
    disco_doc_address: str | None,
    require_https: bool = True,
) -> DiscoveryDocumentResponse:
    """Cached async discovery document fetching with TTL.

    Cache-aside with per-URI single-flight: a fresh cached entry returns
    without acquiring any lock; only the upstream fetch on a cache miss
    is serialized, and only against other requests for the same address.
    """
    if disco_doc_address is None:
        raise ConfigurationException(
            "disco_doc_address is required when perform_disco is True"
        )

    cache_key = (disco_doc_address, require_https)
    entry = _disco_cache.get(cache_key)
    if entry is not None and not is_cache_expired(entry):
        return entry.response

    fetch_lock = _get_disco_fetch_lock(cache_key)
    async with fetch_lock:
        entry = _disco_cache.get(cache_key)
        if entry is not None and not is_cache_expired(entry):
            return entry.response

        policy = DiscoveryPolicy(require_https=require_https)
        response = await get_discovery_document(
            DiscoveryDocumentRequest(address=disco_doc_address, policy=policy),
        )
        async with _disco_cache_write_lock:
            apply_disco_cache_outcome(_disco_cache, cache_key, response, time.time())
        return response


def clear_discovery_cache() -> None:
    """Clear the discovery cache."""
    _disco_cache.clear()


# ============================================================================
# TTL-aware JWKS cache (replaces @alru_cache for JWKS)
# ============================================================================

_jwks_cache: dict[str, JwksCacheEntry] = {}
_jwks_cache_write_lock = asyncio.Lock()
_JWKS_LOCK_STRIPES = 32
_jwks_fetch_locks: list[asyncio.Lock] = [
    asyncio.Lock() for _ in range(_JWKS_LOCK_STRIPES)
]

# See sync._kid_miss_last_attempt for rationale. Guarded by _jwks_cache_write_lock.
_kid_miss_last_attempt: dict[str, float] = {}


def _get_jwks_fetch_lock(jwks_uri: str) -> asyncio.Lock:
    return _jwks_fetch_locks[hash(jwks_uri) % _JWKS_LOCK_STRIPES]


async def _get_cached_jwks(jwks_uri: str) -> JwksResponse:
    """Return cached JWKS response if fresh, otherwise fetch and cache.

    Cache-aside with per-URI single-flight (see ``_get_disco_response``).
    """
    entry = _jwks_cache.get(jwks_uri)
    if entry is not None and not is_cache_expired(entry):
        return entry.response

    fetch_lock = _get_jwks_fetch_lock(jwks_uri)
    async with fetch_lock:
        entry = _jwks_cache.get(jwks_uri)
        if entry is not None and not is_cache_expired(entry):
            return entry.response

        response = await get_jwks(JwksRequest(address=jwks_uri))
        async with _jwks_cache_write_lock:
            apply_jwks_cache_outcome(
                _jwks_cache,
                jwks_uri,
                response,
                time.time(),
                cooldown=_kid_miss_last_attempt,
            )
        return response


async def _refresh_jwks(jwks_uri: str) -> JwksResponse:
    """Force re-fetch JWKS and update cache (key rotation).

    Uses the per-URI fetch lock to coalesce concurrent refreshes for the
    same URI while leaving unrelated URIs unblocked. The ``request_time``
    guard catches the case where another coroutine for *this* URI completed
    a refresh while we were blocked.
    """
    request_time = time.time()
    fetch_lock = _get_jwks_fetch_lock(jwks_uri)
    async with fetch_lock:
        entry = _jwks_cache.get(jwks_uri)
        if entry is not None and entry.cached_at >= request_time:
            return entry.response

        logger.info("Forcing JWKS refresh for %s (possible key rotation)", jwks_uri)
        response = await get_jwks(JwksRequest(address=jwks_uri))
        async with _jwks_cache_write_lock:
            apply_jwks_cache_outcome(
                _jwks_cache,
                jwks_uri,
                response,
                time.time(),
                cooldown=_kid_miss_last_attempt,
            )
        return response


def clear_jwks_cache() -> None:
    """Clear the JWKS cache. Useful for testing."""
    _jwks_cache.clear()
    _kid_miss_last_attempt.clear()


# ============================================================================
# Token validation
# ============================================================================


async def _discover_and_resolve_key(
    jwt: str,
    disco_doc_address: str | None,
    http_client: AsyncHTTPClient | None,
    require_https: bool = True,
) -> tuple[dict, str, DiscoveryDocumentResponse, bool]:
    """Fetch discovery + JWKS and resolve the signing key.

    Returns (key_dict, alg, disco_response, is_cached_path).
    """
    if http_client is not None:
        if disco_doc_address is None:
            raise ConfigurationException(
                "disco_doc_address is required when perform_disco is True"
            )
        policy = DiscoveryPolicy(require_https=require_https)
        disco_doc_response = await get_discovery_document(
            DiscoveryDocumentRequest(address=disco_doc_address, policy=policy),
            http_client=http_client,
        )
        validate_disco_response(disco_doc_response)
        jwks_uri = validate_jwks_uri(disco_doc_response)
        jwks_response = await get_jwks(
            JwksRequest(address=jwks_uri), http_client=http_client
        )
        validate_jwks_response(jwks_response)
        kid, jwt_alg = extract_jwt_header_fields(jwt)
        key_dict, alg = find_key_by_kid(kid, jwks_response.keys or [], jwt_alg=jwt_alg)
        return key_dict, alg, disco_doc_response, False

    # Cached path with TTL
    disco_doc_response = await _get_disco_response(disco_doc_address, require_https)
    validate_disco_response(disco_doc_response)
    jwks_uri = validate_jwks_uri(disco_doc_response)
    jwks_response = await _get_cached_jwks(jwks_uri)
    validate_jwks_response(jwks_response)
    kid, jwt_alg = extract_jwt_header_fields(jwt)
    # OP key rotation: if the JWT's kid is not in the cached JWKS, the cache
    # is stale. Force a refresh before lookup so rotation is handled without
    # waiting for a signature failure on a key we don't have. The cooldown
    # gate prevents an unauthenticated attacker from amplifying inbound JWT
    # traffic into upstream JWKS fetches by spamming random kids.
    cached_keys = jwks_response.keys or []
    if kid is not None and not any(k.kid == kid for k in cached_keys):
        if should_attempt_kid_miss_refresh(
            _kid_miss_last_attempt,
            jwks_uri,
            has_cached_keys=bool(cached_keys),
            now=time.time(),
        ):
            logger.info(
                "kid %s not present in cached JWKS; refreshing (possible key rotation)",
                kid,
            )
            # See sync._discover_and_resolve_key for the rationale.
            jwks_response = await _refresh_jwks(jwks_uri)
            if jwks_response.is_successful:
                refreshed_keys = jwks_response.keys or []
                kid_found = any(k.kid == kid for k in refreshed_keys)
                async with _jwks_cache_write_lock:
                    if kid_found:
                        _kid_miss_last_attempt.pop(jwks_uri, None)
                    else:
                        _kid_miss_last_attempt[jwks_uri] = time.time()
            else:
                kid_found = False
            validate_jwks_response(jwks_response)
            if not kid_found:
                logger.warning(
                    "kid %s still absent after JWKS refresh of %s", kid, jwks_uri
                )
        else:
            logger.debug(
                "kid %s not in cached JWKS for %s but refresh cooldown active; "
                "falling through to no-matching-kid error",
                kid,
                jwks_uri,
            )
    key_dict, alg = find_key_by_kid(kid, jwks_response.keys or [], jwt_alg=jwt_alg)
    return key_dict, alg, disco_doc_response, True


async def _retry_with_refreshed_jwks(
    jwt: str,
    token_validation_config: TokenValidationConfig,
    disco_doc_response: DiscoveryDocumentResponse,
    http_client: AsyncHTTPClient | None = None,
) -> dict:
    """Re-fetch JWKS and retry decode once (key rotation recovery).

    See sync._retry_with_refreshed_jwks for the rationale. Shares
    ``_kid_miss_last_attempt`` with the kid-miss path so an attacker
    forging signatures against cached kids can't bypass the cooldown.
    """
    logger.warning("Signature verification failed; retrying with refreshed keys")
    jwks_uri = validate_jwks_uri(disco_doc_response)
    if http_client is not None:
        jwks_response = await get_jwks(
            JwksRequest(address=jwks_uri), http_client=http_client
        )
        validate_jwks_response(jwks_response)
        kid, jwt_alg = extract_jwt_header_fields(jwt)
        key_dict, alg = find_key_by_kid(kid, jwks_response.keys or [], jwt_alg=jwt_alg)
        resolved_config = build_resolved_config(token_validation_config, key_dict, alg)
        return decode_with_config(jwt, resolved_config, disco_doc_response.issuer)

    if not should_attempt_kid_miss_refresh(
        _kid_miss_last_attempt,
        jwks_uri,
        has_cached_keys=True,
        now=time.time(),
    ):
        logger.debug(
            "Signature-failure retry suppressed for %s: refresh cooldown active",
            jwks_uri,
        )
        raise SignatureVerificationException(
            "Signature verification failed; refresh cooldown active"
        )

    jwks_response = await _refresh_jwks(jwks_uri)
    # See sync._retry_with_refreshed_jwks — transient failures must not
    # stamp the cooldown.
    validate_jwks_response(jwks_response)

    try:
        kid, jwt_alg = extract_jwt_header_fields(jwt)
        key_dict, alg = find_key_by_kid(kid, jwks_response.keys or [], jwt_alg=jwt_alg)
        resolved_config = build_resolved_config(token_validation_config, key_dict, alg)
        decoded = decode_with_config(jwt, resolved_config, disco_doc_response.issuer)
    except Exception:
        async with _jwks_cache_write_lock:
            _kid_miss_last_attempt[jwks_uri] = time.time()
        raise
    async with _jwks_cache_write_lock:
        _kid_miss_last_attempt.pop(jwks_uri, None)
    return decoded


async def validate_token(
    jwt: str,
    token_validation_config: TokenValidationConfig,
    disco_doc_address: str | None = None,
    http_client: AsyncHTTPClient | None = None,
) -> dict:
    """
    Validate a JWT token (async).

    Args:
        jwt: The JWT token to validate
        token_validation_config: Token validation configuration
        disco_doc_address: Discovery document address (required if perform_disco=True)
        http_client: Optional managed HTTP client.  When ``None``, uses the
            module-level singleton with response caching.  When provided,
            caching is bypassed and the injected client is used directly.

    Returns:
        dict: Decoded token claims

    Raises:
        TokenValidationException: If token validation fails
        ConfigurationException: If configuration is invalid
    """
    log_validation_start(jwt, token_validation_config)
    validate_token_config(token_validation_config)

    if token_validation_config.perform_disco:
        key_dict, alg, disco_doc_response, _is_cached = await _discover_and_resolve_key(
            jwt, disco_doc_address, http_client, token_validation_config.require_https
        )
        resolved_config = build_resolved_config(token_validation_config, key_dict, alg)

        try:
            decoded_token = decode_with_config(
                jwt, resolved_config, disco_doc_response.issuer
            )
        except SignatureVerificationException:
            decoded_token = await _retry_with_refreshed_jwks(
                jwt, token_validation_config, disco_doc_response, http_client
            )
    else:
        validate_config_for_manual_validation(token_validation_config)
        decoded_token = decode_with_config(jwt, token_validation_config)

    await validate_async_claims(decoded_token, token_validation_config)
    log_validation_success(decoded_token)
    return decoded_token


__all__ = [
    "TokenValidationConfig",
    "clear_discovery_cache",
    "clear_jwks_cache",
    "validate_token",
]
