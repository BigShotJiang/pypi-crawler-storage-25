from __future__ import annotations

import base64
import copy
import hmac as _hmac
import json
import re
import secrets
import threading
import time as _time_mod
import uuid
from typing import Any, TYPE_CHECKING

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .errors import (
    E2EEDecryptFailedError,
    E2EEError,
    E2EEGroupCommitmentInvalidError,
    E2EEGroupDecryptFailedError,
    E2EEGroupEpochMismatchError,
    E2EEGroupNotMemberError,
    E2EEGroupSecretMissingError,
)

if TYPE_CHECKING:
    from .logger import AUNLogger, NullLogger

from .logger import NullLogger as _NullLogger

_null_logger = _NullLogger()
_group_secret_locks_guard = threading.Lock()
_group_secret_locks: dict[str, threading.RLock] = {}


def _debug_group_e2ee(message: str, **fields: Any) -> None:
    _ = (message, fields)


SUITE = "P256_HKDF_SHA256_AES_256_GCM"

# 加密模式
MODE_PREKEY_ECDH_V2 = "prekey_ecdh_v2"  # 四路 ECDH：prekey + identity
MODE_LONG_TERM_KEY = "long_term_key"    # 降级：长期公钥加密

# AAD 字段
AAD_FIELDS_OFFLINE = (
    "from", "to", "message_id", "timestamp",
    "encryption_mode", "suite", "ephemeral_public_key",
    "recipient_cert_fingerprint", "sender_cert_fingerprint",
    "prekey_id",
)
AAD_MATCH_FIELDS_OFFLINE = (
    "from", "to", "message_id",
    "encryption_mode", "suite", "ephemeral_public_key",
    "recipient_cert_fingerprint", "sender_cert_fingerprint",
    "prekey_id",
)

# prekey 私钥本地保留时间（秒）
PREKEY_RETENTION_SECONDS = 7 * 24 * 3600  # 7 天
PREKEY_MIN_KEEP_COUNT = 7

# AES-256-GCM 认证标签长度（字节），标准值 16 字节 = 128-bit
_AES_GCM_TAG_LEN = 16

_METADATA_AUTH_FIELD = "_auth"
_METADATA_AUTH_ALG = "HMAC-SHA256"
_METADATA_KEY_DOMAIN = b"aun-envelope-metadata-key-v1"
_PROTECTED_HEADERS_DOMAIN = b"aun-protected-headers-v1"
_PROTECTED_CONTEXT_DOMAIN = b"aun-protected-context-v1"


def _prekey_created_marker(prekey_data: dict[str, Any]) -> int:
    for key in ("created_at", "updated_at", "expires_at"):
        marker = prekey_data.get(key)
        if isinstance(marker, (int, float)):
            return int(marker)
    return 0


def _latest_prekey_ids(
    prekeys: dict[str, dict[str, Any]],
    keep_latest: int,
) -> set[str]:
    if keep_latest <= 0:
        return set()
    ordered: list[tuple[str, int]] = []
    for prekey_id, prekey_data in prekeys.items():
        if not isinstance(prekey_data, dict):
            continue
        ordered.append((prekey_id, _prekey_created_marker(prekey_data)))
    ordered.sort(key=lambda item: (item[1], item[0]), reverse=True)
    return {prekey_id for prekey_id, _marker in ordered[:keep_latest]}

# ── 群组 E2EE 常量 ──────────────────────────────────────────
MODE_EPOCH_GROUP_KEY = "epoch_group_key"

AAD_FIELDS_GROUP = (
    "group_id", "from", "message_id", "timestamp",
    "epoch", "encryption_mode", "suite",
)
AAD_MATCH_FIELDS_GROUP = (
    "group_id", "from", "message_id",
    "epoch", "encryption_mode", "suite",
)


class ProtectedHeaders:
    """端到端保护的信封元数据，语义接近 HTTP headers。"""

    def __init__(self, values: dict[str, Any] | None = None):
        self._items: dict[str, str] = {}
        if values:
            for key, value in values.items():
                self.set(key, value)

    @staticmethod
    def _normalize_key(key: object) -> str:
        value = str(key or "").strip().lower()
        if not value or not re.fullmatch(r"[a-z0-9_-]+", value):
            raise ValueError("protected header key must match [a-z0-9_-]+")
        if value == _METADATA_AUTH_FIELD:
            raise ValueError("protected header key is reserved")
        return value

    def set(self, key: str, value: object) -> "ProtectedHeaders":
        self._items[self._normalize_key(key)] = "" if value is None else str(value)
        return self

    def get(self, key: str, default: str | None = None) -> str | None:
        return self._items.get(self._normalize_key(key), default)

    def remove(self, key: str) -> "ProtectedHeaders":
        self._items.pop(self._normalize_key(key), None)
        return self

    def to_dict(self) -> dict[str, str]:
        return dict(self._items)

    @classmethod
    def from_dict(cls, values: dict[str, Any] | None) -> "ProtectedHeaders":
        return cls(values or {})


def _normalize_protected_headers(headers: object) -> dict[str, str]:
    if headers is None:
        return {}
    if isinstance(headers, ProtectedHeaders):
        return headers.to_dict()
    if not isinstance(headers, dict):
        raise ValueError("protected_headers must be an object")
    return ProtectedHeaders(headers).to_dict()


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _metadata_body(metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        str(key): copy.deepcopy(value)
        for key, value in metadata.items()
        if str(key) != _METADATA_AUTH_FIELD
    }


def _metadata_auth_tag(key: bytes, domain: bytes, body: dict[str, Any]) -> bytes:
    metadata_key = _hmac.digest(key, _METADATA_KEY_DOMAIN, "sha256")
    sign_input = domain + b"\0" + _canonical_json_bytes(body)
    return _hmac.digest(metadata_key, sign_input, "sha256")


def _with_metadata_auth(
    metadata: dict[str, Any],
    *,
    key: bytes,
    domain: bytes,
) -> dict[str, Any]:
    body = _metadata_body(metadata)
    if not body:
        return {}
    tag = _metadata_auth_tag(key, domain, body)
    result = copy.deepcopy(body)
    result[_METADATA_AUTH_FIELD] = {
        "alg": _METADATA_AUTH_ALG,
        "tag": base64.b64encode(tag).decode("ascii"),
    }
    return result


def _verify_metadata_auth(
    metadata: object,
    *,
    key: bytes,
    domain: bytes,
) -> bool:
    if metadata is None:
        return True
    if not isinstance(metadata, dict):
        return False
    auth = metadata.get(_METADATA_AUTH_FIELD)
    if not isinstance(auth, dict):
        return False
    if auth.get("alg") != _METADATA_AUTH_ALG:
        return False
    tag_b64 = auth.get("tag")
    if not isinstance(tag_b64, str) or not tag_b64:
        return False
    try:
        actual = base64.b64decode(tag_b64, validate=True)
    except Exception:
        return False
    body = _metadata_body(metadata)
    if not body:
        return False
    expected = _metadata_auth_tag(key, domain, body)
    return _hmac.compare_digest(actual, expected)


def _normalize_context_metadata(context: object) -> dict[str, Any]:
    if not isinstance(context, dict):
        return {}
    return _metadata_body(context)


def _exposed_envelope_metadata(metadata: object) -> dict[str, Any] | None:
    if not isinstance(metadata, dict):
        return None
    body = _metadata_body(metadata)
    return body or None


def _copy_optional_envelope_metadata(
    envelope: dict[str, Any],
    *,
    message_key: bytes,
    payload_type: object = None,
    protected_headers: object = None,
    context: object = None,
) -> None:
    headers = _normalize_protected_headers(protected_headers)
    ptype = str(payload_type or "").strip()
    if ptype:
        headers["payload_type"] = ptype
    if headers:
        envelope["protected_headers"] = _with_metadata_auth(
            headers,
            key=message_key,
            domain=_PROTECTED_HEADERS_DOMAIN,
        )
    context_meta = _normalize_context_metadata(context)
    if context_meta:
        envelope["context"] = _with_metadata_auth(
            context_meta,
            key=message_key,
            domain=_PROTECTED_CONTEXT_DOMAIN,
        )


def _aad_bytes_with_optional_fields(
    aad: dict[str, Any],
    base_fields: tuple[str, ...],
) -> bytes:
    body = {field: aad.get(field) for field in base_fields}
    return _canonical_json_bytes(body)


def _verify_envelope_metadata_auth(
    payload: dict[str, Any],
    message_key: bytes,
) -> bool:
    return (
        _verify_metadata_auth(
            payload.get("protected_headers"),
            key=message_key,
            domain=_PROTECTED_HEADERS_DOMAIN,
        )
        and _verify_metadata_auth(
            payload.get("context"),
            key=message_key,
            domain=_PROTECTED_CONTEXT_DOMAIN,
        )
    )


def _validate_decrypted_envelope_metadata(
    decoded: object,
    payload: dict[str, Any],
    message: dict[str, Any] | None = None,
) -> bool:
    headers = payload.get("protected_headers")
    if isinstance(headers, dict):
        header_body = _metadata_body(headers)
        if "payload_type" in header_body:
            if not isinstance(decoded, dict):
                return False
            if str(decoded.get("type") or "") != str(header_body.get("payload_type") or ""):
                return False

    protected_context = payload.get("context")
    if isinstance(protected_context, dict):
        context_body = _metadata_body(protected_context)
        outer_context = (message or {}).get("context")
        if not isinstance(outer_context, dict):
            return False
        if _normalize_context_metadata(outer_context) != context_body:
            return False
    return True



def _load_keystore_prekeys(
    keystore: Any,
    aid: str,
    device_id: str = "",
) -> dict[str, dict[str, Any]]:
    load_fn = getattr(keystore, "load_e2ee_prekeys", None)
    if callable(load_fn):
        result = load_fn(aid, device_id)
        return result if isinstance(result, dict) else {}
    raise AttributeError("keystore 缺少 load_e2ee_prekeys 方法")


def _save_keystore_prekey(
    keystore: Any,
    aid: str,
    device_id: str,
    prekey_id: str,
    prekey_data: dict[str, Any],
) -> None:
    save_fn = getattr(keystore, "save_e2ee_prekey", None)
    if callable(save_fn):
        save_fn(aid, prekey_id, prekey_data, device_id)
        return

    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 save_e2ee_prekey 方法")


def _cleanup_keystore_prekeys(
    keystore: Any,
    aid: str,
    device_id: str,
    cutoff_ms: int,
    keep_latest: int = PREKEY_MIN_KEEP_COUNT,
) -> list[str]:
    cleanup_fn = getattr(keystore, "cleanup_e2ee_prekeys", None)
    if callable(cleanup_fn):
        result = cleanup_fn(aid, cutoff_ms, keep_latest, device_id)
        return result if isinstance(result, list) else []

    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 cleanup_e2ee_prekeys 方法")


def _load_keystore_group_epoch(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int | None = None,
) -> dict[str, Any] | None:
    load_fn = getattr(keystore, "load_group_secret_epoch", None)
    if callable(load_fn):
        result = load_fn(aid, group_id, epoch)
        return result if isinstance(result, dict) else None
    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 load_group_secret_epoch 方法")


def _load_keystore_group_epochs(
    keystore: Any,
    aid: str,
    group_id: str,
) -> list[dict[str, Any]]:
    load_fn = getattr(keystore, "load_group_secret_epochs", None)
    if callable(load_fn):
        result = load_fn(aid, group_id)
        return [entry for entry in result if isinstance(entry, dict)] if isinstance(result, list) else []
    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 load_group_secret_epochs 方法")


def _store_keystore_group_transition(
    keystore: Any,
    aid: str,
    group_id: str,
    *,
    epoch: int,
    secret: str,
    commitment: str,
    member_aids: list[str],
    epoch_chain: str | None,
    pending_rotation_id: str,
    epoch_chain_unverified: bool | None,
    epoch_chain_unverified_reason: str | None,
) -> bool | None:
    store_fn = getattr(keystore, "store_group_secret_transition", None)
    if not callable(store_fn):
        return None
    return bool(store_fn(
        aid,
        group_id,
        epoch=epoch,
        secret=secret,
        commitment=commitment,
        member_aids=member_aids,
        epoch_chain=epoch_chain,
        pending_rotation_id=pending_rotation_id,
        epoch_chain_unverified=epoch_chain_unverified,
        epoch_chain_unverified_reason=epoch_chain_unverified_reason,
        old_epoch_retention_ms=OLD_EPOCH_RETENTION_SECONDS * 1000,
    ))


def _store_keystore_group_epoch(
    keystore: Any,
    aid: str,
    group_id: str,
    *,
    epoch: int,
    secret: str,
    commitment: str,
    member_aids: list[str],
    epoch_chain: str | None,
    pending_rotation_id: str,
    epoch_chain_unverified: bool | None,
    epoch_chain_unverified_reason: str | None,
) -> bool | None:
    store_fn = getattr(keystore, "store_group_secret_epoch", None)
    if not callable(store_fn):
        return None
    return bool(store_fn(
        aid,
        group_id,
        epoch=epoch,
        secret=secret,
        commitment=commitment,
        member_aids=member_aids,
        epoch_chain=epoch_chain,
        pending_rotation_id=pending_rotation_id,
        epoch_chain_unverified=epoch_chain_unverified,
        epoch_chain_unverified_reason=epoch_chain_unverified_reason,
        old_epoch_retention_ms=OLD_EPOCH_RETENTION_SECONDS * 1000,
    ))


def _cleanup_keystore_group_old_epochs(
    keystore: Any,
    aid: str,
    group_id: str,
    cutoff_ms: int,
) -> int:
    cleanup_fn = getattr(keystore, "cleanup_group_old_epochs_state", None)
    if callable(cleanup_fn):
        result = cleanup_fn(aid, group_id, cutoff_ms)
        return int(result or 0)

    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 cleanup_group_old_epochs_state 方法")


class E2EEManager:
    """端到端加密工具类 — 纯密码学操作，无 I/O 依赖。

    加密策略：prekey_ecdh_v2（双 ECDH）→ long_term_key 两层降级。
    I/O（获取 prekey、证书）由调用方（AUNClient）负责。
    内置本地防重放（seen set），裸 WebSocket 开发者无需额外实现。
    """

    def __init__(
        self,
        *,
        identity_fn: Any,
        device_id_fn: Any | None = None,
        keystore: Any,
        prekey_cache_ttl: float = 3600.0,
        replay_window_seconds: int = 300,
        logger: "AUNLogger | NullLogger | None" = None,
    ) -> None:
        from .logger import NullLogger as _NL
        self._log = logger or _NL()
        self._identity_fn = identity_fn
        self._device_id_fn = device_id_fn or (lambda: "")
        self._keystore_ref = keystore
        self._cache_lock = threading.RLock()
        self._prekey_load_lock = threading.Lock()
        # 本地防重放 seen set（值为 timestamp，支持 TTL 清理）
        self._seen_messages: dict[str, float] = {}
        self._seen_max_size = 50000
        self._seen_ttl = 300.0  # 5 分钟 TTL
        # 对方 prekey 内存缓存（TTL 默认 1 小时）
        self._prekey_cache: dict[str, tuple[dict[str, Any], float]] = {}
        self._prekey_cache_ttl = prekey_cache_ttl
        # 本地 prekey 私钥内存缓存 {prekey_id: EllipticCurvePrivateKey}
        self._local_prekey_cache: dict[str, ec.EllipticCurvePrivateKey] = {}
        # 已知不可恢复的 prekey_id（避免重复 warning）
        self._missing_prekey_ids: set[str] = set()
        # 防重放时间窗口（秒）
        self._replay_window_seconds = replay_window_seconds

    # ── 便利方法 ──────────────────────────────────────────────

    def encrypt_message(
        self,
        to_aid: str,
        payload: dict[str, Any],
        *,
        peer_cert_pem: bytes,
        prekey: dict[str, Any] | None = None,
        message_id: str | None = None,
        timestamp: int | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """加密消息（便利方法）。

        调用方负责提前获取 peer_cert_pem 和 prekey（可选）。
        有 prekey 时用 prekey_ecdh_v2（四路 ECDH），无 prekey 时降级为 long_term_key。
        返回 (envelope, result_info)，result_info 包含 encrypted/forward_secrecy/mode 等状态。
        """
        message_id = message_id or str(uuid.uuid4())
        timestamp = timestamp or int(_time_mod.time() * 1000)
        return self.encrypt_outbound(
            peer_aid=to_aid,
            payload=payload,
            peer_cert_pem=peer_cert_pem,
            prekey=prekey,
            message_id=message_id,
            timestamp=timestamp,
        )

    def decrypt_message(self, message: dict[str, Any], *, source: str = "") -> dict[str, Any] | None:
        """解密单条消息（便利方法，内置本地防重放 + timestamp 窗口）。"""
        payload = message.get("payload")
        if not isinstance(payload, dict):
            return message
        payload_type = payload.get("type")
        if payload_type != "e2ee.encrypted":
            return message
        if message.get("encrypted") is not True and "encrypted" in message:
            return message
        if not self._should_decrypt_for_current_aid(message, payload):
            return message

        # timestamp 窗口检查
        ts = message.get("timestamp") or (payload.get("aad") or {}).get("timestamp")
        if isinstance(ts, (int, float)) and self._replay_window_seconds > 0:
            now_ms = int(_time_mod.time() * 1000)
            diff_s = abs(now_ms - ts) / 1000
            if diff_s > self._replay_window_seconds:
                self._log.warn("e2ee", 
                    "消息 timestamp 超出窗口 (%.0fs > %ds)，拒绝: from=%s mid=%s",
                    diff_s, self._replay_window_seconds,
                    message.get("from"), message.get("message_id"),
                )
                return None

        # 本地防重放：检查通过后先预占，解密失败再释放，避免并发重复解密同一消息。
        message_id = message.get("message_id", "")
        from_aid = message.get("from", "")
        seen_key = ""
        reserved_seen = False
        if message_id and from_aid:
            seen_key = f"{from_aid}:{message_id}"
            with self._cache_lock:
                if seen_key in self._seen_messages:
                    return None  # 重放消息
                self._seen_messages[seen_key] = _time_mod.time()
                self._trim_seen_set_locked()
                reserved_seen = True

        try:
            result = self._decrypt_message(message, source=source)
        except Exception:
            if reserved_seen:
                with self._cache_lock:
                    self._seen_messages.pop(seen_key, None)
            raise
        if result is None and reserved_seen:
            with self._cache_lock:
                self._seen_messages.pop(seen_key, None)
        return result

    def _should_decrypt_for_current_aid(self, message: dict[str, Any], payload: dict[str, Any]) -> bool:
        """仅解密发给当前 AID 的消息，避免发送端回显消息误走接收端解密流程。"""
        if str(message.get("direction") or "").strip().lower() == "outbound_sync":
            return True
        current_aid = self._current_aid()
        if not current_aid:
            return True
        target_aid = (
            message.get("to")
            or (payload.get("aad") or {}).get("to")
            or payload.get("to")
        )
        if not target_aid:
            return True
        return str(target_aid) == str(current_aid)

    def _trim_seen_set(self) -> None:
        with self._cache_lock:
            self._trim_seen_set_locked()

    def _trim_seen_set_locked(self) -> None:
        # 先按 TTL 清理过期条目
        now = _time_mod.time()
        expired = [k for k, t in self._seen_messages.items() if now - t > self._seen_ttl]
        for k in expired:
            del self._seen_messages[k]
        # 再按数量上限裁剪：按时间戳从旧到新删除（而非插入顺序），
        # 避免误删仍在防重放窗口内的条目。
        if len(self._seen_messages) > self._seen_max_size:
            trim_count = len(self._seen_messages) - int(self._seen_max_size * 0.8)
            oldest_keys = sorted(
                self._seen_messages.items(), key=lambda kv: kv[1]
            )[:trim_count]
            for k, _ts in oldest_keys:
                del self._seen_messages[k]

    # ── Prekey 缓存 ────────────────────────────────────────────

    def clean_expired_caches(self) -> None:
        """清理过期的 prekey 缓存和 seen set 条目（供外部定时调用）"""
        with self._cache_lock:
            now = _time_mod.time()
            for k in list(self._prekey_cache):
                _, expire_at = self._prekey_cache[k]
                if now >= expire_at:
                    del self._prekey_cache[k]
            self._trim_seen_set_locked()

    def cache_prekey(self, peer_aid: str, prekey: dict[str, Any]) -> None:
        """缓存对方的 prekey（调用方获取后存入，后续 encrypt 自动复用）"""
        with self._cache_lock:
            self._prekey_cache[peer_aid] = (prekey, _time_mod.time() + self._prekey_cache_ttl)

    def get_cached_prekey(self, peer_aid: str) -> dict[str, Any] | None:
        """获取缓存的 prekey（过期返回 None）"""
        with self._cache_lock:
            cached = self._prekey_cache.get(peer_aid)
            if cached is None:
                return None
            prekey, expire_at = cached
            if _time_mod.time() >= expire_at:
                del self._prekey_cache[peer_aid]
                return None
            return prekey

    def invalidate_prekey_cache(self, peer_aid: str) -> None:
        """使指定 peer 的 prekey 缓存失效"""
        with self._cache_lock:
            self._prekey_cache.pop(peer_aid, None)

    # ── 加密 ─────────────────────────────────────────────────

    def encrypt_outbound(
        self,
        peer_aid: str,
        payload: dict[str, Any],
        *,
        peer_cert_pem: bytes,
        prekey: dict[str, Any] | None = None,
        message_id: str,
        timestamp: int,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """加密出站消息：有 prekey → prekey_ecdh_v2（四路 ECDH），无 prekey → long_term_key。

        返回 (envelope, result_info)，result_info 包含加密状态详情：
          encrypted: bool, forward_secrecy: bool, mode: str, degraded: bool
        prekey 传入时自动缓存；传入 None 时自动查缓存。
        """
        # 传入 prekey → 缓存；传入 None → 查缓存
        if prekey is not None:
            self.cache_prekey(peer_aid, prekey)
        else:
            prekey = self.get_cached_prekey(peer_aid)

        self._log.debug("e2ee", "encrypting outbound message: to=%s mid=%s has_prekey=%s", peer_aid, message_id, prekey is not None)

        if prekey:
            try:
                envelope, ok = self._encrypt_with_prekey(
                    peer_aid, payload, prekey, peer_cert_pem,
                    message_id=message_id, timestamp=timestamp,
                    protected_headers=protected_headers, context=context,
                )
                self._log.debug("e2ee", "prekey_ecdh_v2 encryption success: to=%s mid=%s", peer_aid, message_id)
                return envelope, {
                    "encrypted": True,
                    "forward_secrecy": True,
                    "mode": MODE_PREKEY_ECDH_V2,
                    "degraded": False,
                }
            except Exception as exc:
                self._log.warn("e2ee",
                    "prekey 加密失败，降级到 long_term_key（无前向保密）: to=%s err=%s", peer_aid, exc
                )

        envelope, ok = self._encrypt_with_long_term_key(
            peer_aid, payload, peer_cert_pem,
            message_id=message_id, timestamp=timestamp,
            protected_headers=protected_headers, context=context,
        )
        degraded = prekey is not None  # 有 prekey 但失败了才算降级
        self._log.debug("e2ee", "long_term_key encryption done: to=%s mid=%s degraded=%s", peer_aid, message_id, degraded)
        return envelope, {
            "encrypted": True,
            "forward_secrecy": False,
            "mode": MODE_LONG_TERM_KEY,
            "degraded": degraded,
            "degradation_reason": "prekey_encrypt_failed" if degraded else "no_prekey_available",
        }

    def _encrypt_with_prekey(
        self,
        peer_aid: str,
        payload: dict[str, Any],
        prekey: dict[str, Any],
        peer_cert_pem: bytes,
        *,
        message_id: str,
        timestamp: int,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any], bool]:
        """使用对方 prekey 加密（prekey_ecdh_v2 模式，四路 ECDH + 发送方签名）

        四路 ECDH:
          DH1 = ECDH(ephemeral, peer_prekey)
          DH2 = ECDH(ephemeral, peer_identity)
          DH3 = ECDH(sender_identity, peer_prekey)   ← 绑定发送方身份
          DH4 = ECDH(sender_identity, peer_identity)  ← 双方身份互绑
        """
        # 验证 prekey 签名
        cert = x509.load_pem_x509_certificate(
            peer_cert_pem if isinstance(peer_cert_pem, bytes) else peer_cert_pem.encode("utf-8")
        )
        expected_cert_fingerprint = str(prekey.get("cert_fingerprint", "") or "").strip().lower()
        if expected_cert_fingerprint:
            actual_cert_fingerprint = self._certificate_sha256_fingerprint(cert)
            if actual_cert_fingerprint != expected_cert_fingerprint:
                raise E2EEError("prekey cert fingerprint mismatch")
        peer_identity_public = cert.public_key()

        # 验证 prekey 签名（支持含/不含 created_at 的格式）
        created_at = prekey.get("created_at")
        if created_at is not None:
            sign_data = f"{prekey['prekey_id']}|{prekey['public_key']}|{created_at}".encode("utf-8")
        else:
            sign_data = f"{prekey['prekey_id']}|{prekey['public_key']}".encode("utf-8")
        signature_bytes = base64.b64decode(prekey["signature"])
        try:
            peer_identity_public.verify(signature_bytes, sign_data, ec.ECDSA(hashes.SHA256()))
        except Exception as exc:
            raise E2EEError(f"prekey signature verification failed: {exc}")

        # 导入对方 prekey 公钥
        peer_prekey_public = serialization.load_der_public_key(
            base64.b64decode(prekey["public_key"])
        )

        # 加载发送方自己的 identity 私钥
        sender_identity_private = self._load_sender_identity_private()

        # 生成临时 ECDH 密钥对
        ephemeral_private = ec.generate_private_key(ec.SECP256R1())
        ephemeral_public_bytes = ephemeral_private.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint,
        )

        # 四路 ECDH + HKDF
        dh1 = ephemeral_private.exchange(ec.ECDH(), peer_prekey_public)
        dh2 = ephemeral_private.exchange(ec.ECDH(), peer_identity_public)
        dh3 = sender_identity_private.exchange(ec.ECDH(), peer_prekey_public)
        dh4 = sender_identity_private.exchange(ec.ECDH(), peer_identity_public)
        combined = dh1 + dh2 + dh3 + dh4
        hkdf = HKDF(
            algorithm=hashes.SHA256(), length=32, salt=None,
            info=f"aun-prekey-v2:{prekey['prekey_id']}".encode("utf-8"),
        )
        message_key = hkdf.derive(combined)

        # AES-GCM 加密
        plaintext = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        nonce = secrets.token_bytes(12)
        aesgcm = AESGCM(message_key)

        sender_fingerprint = self._local_cert_sha256_fingerprint() or self._local_identity_fingerprint()
        recipient_fingerprint = self._fingerprint_cert_pem(peer_cert_pem)
        ephemeral_pk_b64 = base64.b64encode(ephemeral_public_bytes).decode("ascii")
        aad = {
            "from": self._current_aid(),
            "to": peer_aid,
            "message_id": message_id,
            "timestamp": timestamp,
            "encryption_mode": MODE_PREKEY_ECDH_V2,
            "suite": SUITE,
            "ephemeral_public_key": ephemeral_pk_b64,
            "recipient_cert_fingerprint": recipient_fingerprint,
            "sender_cert_fingerprint": sender_fingerprint,
            "prekey_id": prekey["prekey_id"],
        }
        envelope_meta: dict[str, Any] = {}
        _copy_optional_envelope_metadata(
            envelope_meta,
            message_key=message_key,
            payload_type=payload.get("type"),
            protected_headers=protected_headers,
            context=context,
        )
        ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, self._aad_bytes_offline(aad))
        ciphertext = ciphertext_with_tag[:-_AES_GCM_TAG_LEN]
        tag = ciphertext_with_tag[-_AES_GCM_TAG_LEN:]

        envelope = {
            "type": "e2ee.encrypted",
            "version": "1",
            "encryption_mode": MODE_PREKEY_ECDH_V2,
            "suite": SUITE,
            "prekey_id": prekey["prekey_id"],
            "ephemeral_public_key": ephemeral_pk_b64,
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
            "tag": base64.b64encode(tag).decode("ascii"),
            "aad": aad,
            **envelope_meta,
        }
        # 发送方签名：对 ciphertext + tag + aad_bytes 签名（不可否认性）
        sign_payload = ciphertext + tag + self._aad_bytes_offline(aad)
        envelope["sender_signature"] = self._sign_bytes(sign_payload)
        envelope["sender_cert_fingerprint"] = sender_fingerprint
        return envelope, True

    def _encrypt_with_long_term_key(
        self,
        peer_aid: str,
        payload: dict[str, Any],
        peer_cert_pem: bytes,
        *,
        message_id: str,
        timestamp: int,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any], bool]:
        """使用 2DH 加密（long_term_key 模式 + 发送方签名）

        2DH:
          DH1 = ECDH(ephemeral, peer_identity)   ← 前向保密（每消息）
          DH2 = ECDH(sender_identity, peer_identity) ← 绑定双方身份
        """
        cert = x509.load_pem_x509_certificate(
            peer_cert_pem if isinstance(peer_cert_pem, bytes) else peer_cert_pem.encode("utf-8")
        )
        peer_public_key = cert.public_key()

        if not isinstance(peer_public_key, ec.EllipticCurvePublicKey):
            raise E2EEError("Peer certificate does not contain EC public key")

        sender_identity_private = self._load_sender_identity_private()

        # 生成临时密钥对
        ephemeral_private = ec.generate_private_key(ec.SECP256R1())
        ephemeral_public_bytes = ephemeral_private.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint,
        )

        # 2DH + HKDF
        dh1 = ephemeral_private.exchange(ec.ECDH(), peer_public_key)
        dh2 = sender_identity_private.exchange(ec.ECDH(), peer_public_key)
        combined = dh1 + dh2
        hkdf = HKDF(
            algorithm=hashes.SHA256(), length=32, salt=None,
            info=b"aun-longterm-v2",
        )
        message_key = hkdf.derive(combined)

        plaintext = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        nonce = secrets.token_bytes(12)
        aesgcm = AESGCM(message_key)

        sender_fingerprint = self._local_cert_sha256_fingerprint() or self._local_identity_fingerprint()
        recipient_fingerprint = self._fingerprint_cert_pem(peer_cert_pem)
        ephemeral_pk_b64 = base64.b64encode(ephemeral_public_bytes).decode("ascii")
        aad = {
            "from": self._current_aid(),
            "to": peer_aid,
            "message_id": message_id,
            "timestamp": timestamp,
            "encryption_mode": MODE_LONG_TERM_KEY,
            "suite": SUITE,
            "ephemeral_public_key": ephemeral_pk_b64,
            "recipient_cert_fingerprint": recipient_fingerprint,
            "sender_cert_fingerprint": sender_fingerprint,
        }
        envelope_meta: dict[str, Any] = {}
        _copy_optional_envelope_metadata(
            envelope_meta,
            message_key=message_key,
            payload_type=payload.get("type"),
            protected_headers=protected_headers,
            context=context,
        )
        ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, self._aad_bytes_offline(aad))
        ciphertext = ciphertext_with_tag[:-_AES_GCM_TAG_LEN]
        tag = ciphertext_with_tag[-_AES_GCM_TAG_LEN:]

        envelope = {
            "type": "e2ee.encrypted",
            "version": "1",
            "encryption_mode": MODE_LONG_TERM_KEY,
            "suite": SUITE,
            "ephemeral_public_key": ephemeral_pk_b64,
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
            "tag": base64.b64encode(tag).decode("ascii"),
            "aad": aad,
            **envelope_meta,
        }
        # 发送方签名（不可否认性）
        sign_payload = ciphertext + tag + self._aad_bytes_offline(aad)
        envelope["sender_signature"] = self._sign_bytes(sign_payload)
        envelope["sender_cert_fingerprint"] = sender_fingerprint
        return envelope, True

    # ── 解密 ─────────────────────────────────────────────────

    def _verify_sender_signature(self, payload: dict[str, Any], message: dict[str, Any]) -> None:
        """验证发送方签名。无签名或验签失败直接抛异常。"""
        sender_sig_b64 = payload.get("sender_signature")
        if not sender_sig_b64:
            raise E2EEDecryptFailedError("sender_signature missing: 拒绝无发送方签名的消息")

        # 获取发送方证书公钥
        from_aid = message.get("from") or (payload.get("aad") or {}).get("from")
        if not from_aid:
            raise E2EEDecryptFailedError("from_aid missing in message")

        sender_cert_fingerprint = str(
            payload.get("sender_cert_fingerprint")
            or (payload.get("aad") or {}).get("sender_cert_fingerprint")
            or ""
        ).strip().lower()
        sender_cert_pem = self._get_sender_cert(from_aid, sender_cert_fingerprint or None)
        if sender_cert_pem is None:
            raise E2EEDecryptFailedError(f"sender cert not found for {from_aid}")

        cert = x509.load_pem_x509_certificate(
            sender_cert_pem if isinstance(sender_cert_pem, bytes) else sender_cert_pem.encode("utf-8")
        )
        sender_public_key = cert.public_key()

        # 重建签名载荷
        ciphertext = base64.b64decode(payload["ciphertext"])
        tag = base64.b64decode(payload["tag"])
        aad = payload.get("aad")
        aad_bytes = self._aad_bytes_offline(aad) if isinstance(aad, dict) else b""
        sign_payload = ciphertext + tag + aad_bytes

        sig_bytes = base64.b64decode(sender_sig_b64)
        try:
            sender_public_key.verify(sig_bytes, sign_payload, ec.ECDSA(hashes.SHA256()))
        except Exception as exc:
            raise E2EEDecryptFailedError(f"sender signature verification failed: {exc}")

    def _get_sender_cert(self, aid: str, cert_fingerprint: str | None = None) -> bytes | None:
        """从 keystore 或缓存获取发送方证书"""
        keystore = self._keystore()
        if keystore is None:
            return None
        try:
            cert_pem = keystore.load_cert(aid, cert_fingerprint)
        except TypeError:
            cert_pem = keystore.load_cert(aid)
        if cert_pem:
            return cert_pem.encode("utf-8") if isinstance(cert_pem, str) else cert_pem
        return None

    def _load_sender_public_key(self, aid: str | None, cert_fingerprint: str | None = None) -> ec.EllipticCurvePublicKey | None:
        """获取发送方的 identity 公钥（从本地证书缓存）"""
        if not aid:
            return None
        cert_pem = self._get_sender_cert(aid, cert_fingerprint)
        if cert_pem is None:
            return None
        try:
            cert = x509.load_pem_x509_certificate(cert_pem)
            pk = cert.public_key()
            if isinstance(pk, ec.EllipticCurvePublicKey):
                return pk
        except Exception as exc:
            self._log.error("e2ee", "failed to load sender %s cert public key: %s", aid, exc, err=exc)
        return None

    def _decrypt_message(self, message: dict[str, Any], *, source: str = "") -> dict[str, Any] | None:
        payload = message["payload"]
        if isinstance(payload, dict) and not self._should_decrypt_for_current_aid(message, payload):
            return message
        encryption_mode = payload.get("encryption_mode", "")

        self._log.debug("e2ee", "decrypting inbound message: mode=%s from=%s mid=%s source=%s",
                        encryption_mode, message.get("from"), message.get("message_id"), source or "-")

        # 验证发送方签名（适用于所有模式）
        try:
            self._verify_sender_signature(payload, message)
        except E2EEDecryptFailedError as exc:
            self._log.warn("e2ee", "sender signature verification failed: from=%s mid=%s err=%s",
                           message.get("from"), message.get("message_id"), exc)
            return None

        if encryption_mode == MODE_PREKEY_ECDH_V2:
            return self._decrypt_message_prekey_v2(message, source=source)
        elif encryption_mode == MODE_LONG_TERM_KEY:
            return self._decrypt_message_long_term(message)
        else:
            self._log.warn("e2ee", "unsupported encryption mode: %s from=%s mid=%s",
                           encryption_mode, message.get("from"), message.get("message_id"))
            return None

    def _decrypt_message_prekey_v2(self, message: dict[str, Any], *, source: str = "") -> dict[str, Any] | None:
        """解密 prekey_ecdh_v2 模式的消息（四路 ECDH：prekey + identity + sender_identity）"""
        payload = message["payload"]
        try:
            ephemeral_public_bytes = base64.b64decode(payload["ephemeral_public_key"])
            prekey_id = payload.get("prekey_id", "")
            nonce = base64.b64decode(payload["nonce"])
            ciphertext = base64.b64decode(payload["ciphertext"])
            tag = base64.b64decode(payload["tag"])

            keystore = self._keystore()
            if not keystore:
                raise E2EEError("Keystore unavailable")
            prekey_private_key = self._load_prekey_private_key(keystore, prekey_id)
            if prekey_private_key is None:
                src_tag = f" [{source}]" if source else ""
                should_log_missing = False
                with self._cache_lock:
                    if prekey_id not in self._missing_prekey_ids:
                        self._missing_prekey_ids.add(prekey_id)
                        should_log_missing = True
                if should_log_missing:
                    self._log.warn("e2ee", "prekey private key not found (unrecoverable)%s: prekey_id=%s mid=%s seq=%s from=%s",
                                      src_tag, prekey_id,
                                      message.get("message_id", "?"), message.get("seq", "?"),
                                      message.get("from", "?"))
                raise E2EEError(f"prekey not found: {prekey_id}")

            # 加载接收方自己的 identity 私钥
            my_aid = self._current_aid()
            key_pair = keystore.load_key_pair(my_aid)
            if not key_pair or "private_key_pem" not in key_pair:
                raise E2EEError("Identity private key not found")
            my_identity_private = serialization.load_pem_private_key(
                key_pair["private_key_pem"].encode("utf-8"), password=None
            )
            if not isinstance(my_identity_private, ec.EllipticCurvePrivateKey):
                raise E2EEError("Identity private key is not EC key")

            # 获取发送方公钥（四路 ECDH 需要）
            from_aid = message.get("from") or (payload.get("aad") or {}).get("from")
            sender_fp = str(
                payload.get("sender_cert_fingerprint")
                or (payload.get("aad") or {}).get("sender_cert_fingerprint")
                or ""
            ).strip().lower() or None
            sender_public_key = self._load_sender_public_key(from_aid, sender_fp)
            if sender_public_key is None:
                raise E2EEError(f"sender public key not found for {from_aid}")

            # 四路 ECDH + HKDF
            ephemeral_public = ec.EllipticCurvePublicKey.from_encoded_point(
                ec.SECP256R1(), ephemeral_public_bytes
            )
            dh1 = prekey_private_key.exchange(ec.ECDH(), ephemeral_public)
            dh2 = my_identity_private.exchange(ec.ECDH(), ephemeral_public)
            dh3 = prekey_private_key.exchange(ec.ECDH(), sender_public_key)
            dh4 = my_identity_private.exchange(ec.ECDH(), sender_public_key)
            combined = dh1 + dh2 + dh3 + dh4
            hkdf = HKDF(
                algorithm=hashes.SHA256(), length=32, salt=None,
                info=f"aun-prekey-v2:{prekey_id}".encode("utf-8"),
            )
            message_key = hkdf.derive(combined)

            # 验证 AAD 并解密
            aesgcm = AESGCM(message_key)
            aad = payload.get("aad")
            if isinstance(aad, dict):
                expected_aad = self._build_inbound_aad_offline(message, payload)
                if not self._aad_matches_offline(expected_aad, aad):
                    raise E2EEDecryptFailedError("aad mismatch")
                aad_bytes = self._aad_bytes_offline(aad)
            else:
                # SC-MSG-015: AAD 缺失或非 dict 时显式拒绝，不尝试用空 AAD 解密
                raise E2EEDecryptFailedError("missing or invalid aad field")
            if not _verify_envelope_metadata_auth(payload, message_key):
                raise E2EEDecryptFailedError("envelope metadata auth failed")
            plaintext = aesgcm.decrypt(nonce, ciphertext + tag, aad_bytes)

            decoded = json.loads(plaintext.decode("utf-8"))
            if not _validate_decrypted_envelope_metadata(decoded, payload, message):
                raise E2EEDecryptFailedError("envelope metadata mismatch")
            transformed = dict(message)
            transformed["payload"] = decoded
            transformed["encrypted"] = True
            e2ee = {
                "encryption_mode": MODE_PREKEY_ECDH_V2,
                "suite": payload.get("suite", SUITE),
                "prekey_id": prekey_id,
            }
            protected_headers = _exposed_envelope_metadata(payload.get("protected_headers"))
            if protected_headers is not None:
                e2ee["protected_headers"] = protected_headers
            context_meta = _exposed_envelope_metadata(payload.get("context"))
            if context_meta is not None:
                e2ee["context"] = context_meta
            transformed["e2ee"] = e2ee
            return transformed
        except E2EEError as exc:
            src_tag = f"[{source}] " if source else ""
            self._log.debug("e2ee", "%sprekey_ecdh_v2 decrypt failed: %s", src_tag, exc)
            return None
        except Exception as exc:
            self._log.error("e2ee", "prekey_ecdh_v2 decrypt error: %s", exc, err=exc)
            return None

    def _decrypt_message_long_term(self, message: dict[str, Any]) -> dict[str, Any] | None:
        """解密 long_term_key 模式的消息（2DH：ephemeral↔identity + sender_identity↔identity）"""
        payload = message["payload"]
        try:
            ephemeral_public_bytes = base64.b64decode(payload["ephemeral_public_key"])
            nonce = base64.b64decode(payload["nonce"])
            ciphertext = base64.b64decode(payload["ciphertext"])
            tag = base64.b64decode(payload["tag"])

            keystore = self._keystore()
            if not keystore:
                raise E2EEError("Keystore unavailable")
            my_aid = self._current_aid()
            key_pair = keystore.load_key_pair(my_aid)
            if not key_pair or "private_key_pem" not in key_pair:
                raise E2EEError("Private key not found")
            private_key = serialization.load_pem_private_key(
                key_pair["private_key_pem"].encode("utf-8"), password=None
            )
            if not isinstance(private_key, ec.EllipticCurvePrivateKey):
                raise E2EEError("Private key is not EC key")

            # 获取发送方公钥（2DH 需要）
            from_aid = message.get("from") or (payload.get("aad") or {}).get("from")
            sender_fp = str(
                payload.get("sender_cert_fingerprint")
                or (payload.get("aad") or {}).get("sender_cert_fingerprint")
                or ""
            ).strip().lower() or None
            sender_public_key = self._load_sender_public_key(from_aid, sender_fp)
            if sender_public_key is None:
                raise E2EEError(f"sender public key not found for {from_aid}")

            # 2DH + HKDF
            ephemeral_public = ec.EllipticCurvePublicKey.from_encoded_point(
                ec.SECP256R1(), ephemeral_public_bytes
            )
            dh1 = private_key.exchange(ec.ECDH(), ephemeral_public)
            dh2 = private_key.exchange(ec.ECDH(), sender_public_key)
            combined = dh1 + dh2
            hkdf = HKDF(
                algorithm=hashes.SHA256(), length=32, salt=None,
                info=b"aun-longterm-v2",
            )
            message_key = hkdf.derive(combined)

            aesgcm = AESGCM(message_key)
            aad = payload.get("aad")
            if isinstance(aad, dict):
                expected_aad = self._build_inbound_aad_offline(message, payload)
                if not self._aad_matches_offline(expected_aad, aad):
                    raise E2EEDecryptFailedError("aad mismatch")
                aad_bytes = self._aad_bytes_offline(aad)
            else:
                # SC-MSG-015: AAD 缺失或非 dict 时显式拒绝，不尝试用空 AAD 解密
                raise E2EEDecryptFailedError("missing or invalid aad field")
            if not _verify_envelope_metadata_auth(payload, message_key):
                raise E2EEDecryptFailedError("envelope metadata auth failed")
            plaintext = aesgcm.decrypt(nonce, ciphertext + tag, aad_bytes)

            decoded = json.loads(plaintext.decode("utf-8"))
            if not _validate_decrypted_envelope_metadata(decoded, payload, message):
                raise E2EEDecryptFailedError("envelope metadata mismatch")
            transformed = dict(message)
            transformed["payload"] = decoded
            transformed["encrypted"] = True
            e2ee = {
                "encryption_mode": MODE_LONG_TERM_KEY,
                "suite": payload["suite"],
            }
            protected_headers = _exposed_envelope_metadata(payload.get("protected_headers"))
            if protected_headers is not None:
                e2ee["protected_headers"] = protected_headers
            context_meta = _exposed_envelope_metadata(payload.get("context"))
            if context_meta is not None:
                e2ee["context"] = context_meta
            transformed["e2ee"] = e2ee
            return transformed
        except E2EEError as exc:
            self._log.warn("e2ee", "long_term_key decrypt failed (E2EE): %s", exc)
            return None
        except Exception as exc:
            self._log.error("e2ee", "long_term_key decrypt failed: %s", exc, err=exc)
            return None

    # ── AAD 工具 ─────────────────────────────────────────────

    @staticmethod
    def _aad_bytes_offline(aad: dict[str, Any]) -> bytes:
        return _aad_bytes_with_optional_fields(aad, AAD_FIELDS_OFFLINE)

    @staticmethod
    def _aad_matches_offline(expected: dict[str, Any], actual: dict[str, Any]) -> bool:
        return all(expected.get(field) == actual.get(field) for field in AAD_MATCH_FIELDS_OFFLINE)

    def _build_inbound_aad_offline(self, message: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
        return {
            "from": message.get("from"),
            "to": message.get("to"),
            "message_id": message.get("message_id"),
            "timestamp": message.get("timestamp"),
            "encryption_mode": payload.get("encryption_mode"),
            "suite": payload.get("suite", SUITE),
            "ephemeral_public_key": payload.get("ephemeral_public_key"),
            "recipient_cert_fingerprint": self._local_cert_fingerprint(),
            "sender_cert_fingerprint": payload.get("sender_cert_fingerprint") or (payload.get("aad") or {}).get("sender_cert_fingerprint"),
            "prekey_id": payload.get("prekey_id") or (payload.get("aad") or {}).get("prekey_id"),
        }

    # ── Prekey 生成 ──────────────────────────────────────────

    def generate_prekey(self) -> dict[str, Any]:
        """生成 prekey 材料并保存私钥到本地 keystore。

        返回 dict 包含 prekey_id、public_key、signature、created_at。
        如果本地 identity 已携带证书，也会附带 cert_fingerprint。
        调用方负责调 transport.call("message.e2ee.put_prekey", result) 上传。
        """
        keystore = self._keystore()
        if keystore is None:
            raise E2EEError("Keystore unavailable for prekey generation")
        aid = self._current_aid()
        if not aid:
            raise E2EEError("AID unavailable for prekey generation")
        device_id = self._current_device_id()

        # 生成新 prekey
        private_key = ec.generate_private_key(ec.SECP256R1())
        public_der = private_key.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        prekey_id = str(uuid.uuid4())
        public_key_b64 = base64.b64encode(public_der).decode("ascii")
        now_ms = int(_time_mod.time() * 1000)

        # 签名：prekey_id|public_key|created_at（绑定时间戳，防止旧 prekey 重放）
        sign_data = f"{prekey_id}|{public_key_b64}|{now_ms}".encode("utf-8")
        signature = self._sign_bytes(sign_data)

        # 保存私钥到本地 keystore
        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf-8")
        _save_keystore_prekey(
            keystore,
            aid,
            device_id,
            prekey_id,
            {
                "private_key_pem": private_key_pem,
                "created_at": now_ms,
                "updated_at": now_ms,
            },
        )
        self._log.info("e2ee", "prekey generated and saved: prekey_id=%s aid=%s device_id=%s", prekey_id, aid, device_id)

        # 内存缓存私钥（即使磁盘 metadata 被覆盖也不丢）
        with self._cache_lock:
            self._local_prekey_cache[prekey_id] = private_key

        # 清理超过保留窗口且不在最新 7 个内的旧 prekey 私钥
        self._cleanup_expired_prekeys(keystore, aid, device_id)

        result = {
            "prekey_id": prekey_id,
            "public_key": public_key_b64,
            "signature": signature,
            "created_at": now_ms,
        }
        cert_fingerprint = self._local_cert_sha256_fingerprint()
        if cert_fingerprint:
            result["cert_fingerprint"] = cert_fingerprint
        if device_id:
            result["device_id"] = device_id
        return result

    def _cleanup_expired_prekeys(self, keystore: Any, aid: str, device_id: str = "") -> None:
        """清理本地超过保留窗口且不在最新 7 个内的 prekey 私钥"""
        now_ms = int(_time_mod.time() * 1000)
        cutoff_ms = now_ms - PREKEY_RETENTION_SECONDS * 1000
        expired = _cleanup_keystore_prekeys(keystore, aid, device_id, cutoff_ms, PREKEY_MIN_KEEP_COUNT)
        if expired:
            with self._cache_lock:
                for pid in expired:
                    self._local_prekey_cache.pop(pid, None)  # 同步清理内存缓存

    def _load_prekey_private_key(self, keystore: Any, prekey_id: str) -> ec.EllipticCurvePrivateKey | None:
        """从内存缓存或 keystore 加载 prekey 私钥"""
        aid = self._current_aid()
        if not aid:
            self._log.warn("e2ee", "prekey %s lookup failed: AID unavailable", prekey_id)
            return None
        device_id = self._current_device_id()

        with self._cache_lock:
            cached = self._local_prekey_cache.get(prekey_id)
            if cached is not None:
                self._log.debug("e2ee", "prekey %s hit from memory cache", prekey_id)
                return cached

        with self._prekey_load_lock:
            with self._cache_lock:
                cached = self._local_prekey_cache.get(prekey_id)
                if cached is not None:
                    self._log.debug("e2ee", "prekey %s hit from memory cache", prekey_id)
                    return cached

            return self._load_prekey_private_key_uncached(keystore, aid, device_id, prekey_id)

    def _load_prekey_private_key_uncached(
        self,
        keystore: Any,
        aid: str,
        device_id: str,
        prekey_id: str,
    ) -> ec.EllipticCurvePrivateKey | None:
        # 优先按 prekey_id 单点查询（O(1) 数据库行级查询）。
        # 信封里都带 prekey_id，没必要全量加载所有 prekey（旧路径在 9000+ prekey 下要 ~430ms/次）。
        prekey_data = None
        by_id_loader = getattr(keystore, "load_e2ee_prekey_by_id", None)
        if callable(by_id_loader):
            try:
                prekey_data = by_id_loader(aid, prekey_id)
            except Exception as exc:
                self._log.warn("e2ee", "prekey %s by_id loader failed, falling back to full load: %s", prekey_id, exc)
                prekey_data = None
            if prekey_data:
                self._log.debug("e2ee", "prekey %s by_id lookup hit", prekey_id)

        # 回退：旧版 keystore 没有 by_id 方法，或单点查询未命中 → 全量扫描
        if not prekey_data:
            prekeys = _load_keystore_prekeys(keystore, aid, device_id)
            self._log.debug("e2ee", "prekey %s keystore lookup: aid=%s device_id=%s local_prekey_count=%d hit=%s",
                            prekey_id, aid, device_id, len(prekeys), prekey_id in prekeys)
            prekey_data = prekeys.get(prekey_id)
        if not prekey_data and device_id:
            # 回退：按 prekey_id 精确查找，不限 device_id（兼容旧数据）
            loader = getattr(keystore, "load_prekey_by_id", None)
            if callable(loader):
                prekey_data = loader(prekey_id)
                if prekey_data:
                    self._log.info("e2ee", "prekey %s hit via load_prekey_by_id fallback", prekey_id)
            if not prekey_data:
                # 再回退：加载全部 prekey（无 device_id 参数的旧 keystore）
                try:
                    prekeys_all = _load_keystore_prekeys(keystore, aid, "")
                    prekey_data = prekeys_all.get(prekey_id)
                    if prekey_data:
                        self._log.info("e2ee", "prekey %s hit in device_id='' fallback lookup", prekey_id)
                except Exception:
                    pass
        if not prekey_data:
            return None
        private_key_pem = prekey_data.get("private_key_pem")
        if not private_key_pem:
            return None

        try:
            pk = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
            if isinstance(pk, ec.EllipticCurvePrivateKey):
                with self._cache_lock:
                    self._local_prekey_cache[prekey_id] = pk
                return pk
        except Exception as exc:
            self._log.error("e2ee", "prekey %s private key PEM load failed: %s", prekey_id, exc, err=exc)
        return None

    # ── 证书指纹工具 ────────────────────────────────────────

    @classmethod
    def _fingerprint_cert_pem(cls, cert_pem: bytes) -> str:
        """从 PEM 证书计算证书 SHA-256 指纹"""
        cert_bytes = cert_pem if isinstance(cert_pem, bytes) else cert_pem.encode("utf-8")
        cert = x509.load_pem_x509_certificate(cert_bytes)
        return cls._certificate_sha256_fingerprint(cert)

    def _local_cert_fingerprint(self) -> str:
        return self._local_cert_sha256_fingerprint() or self._local_identity_fingerprint()

    def _local_cert_sha256_fingerprint(self) -> str:
        identity = self._identity_fn()
        cert_pem = identity.get("cert")
        if isinstance(cert_pem, str) and cert_pem:
            cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
            return self._certificate_sha256_fingerprint(cert)
        return ""

    def _sign_bytes(self, data: bytes) -> str:
        identity = self._identity_fn()
        private_key_pem = identity.get("private_key_pem")
        if not private_key_pem:
            raise E2EEError("identity private key unavailable")
        private_key = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
        signature = private_key.sign(data, ec.ECDSA(hashes.SHA256()))
        return base64.b64encode(signature).decode("ascii")

    def _load_sender_identity_private(self) -> ec.EllipticCurvePrivateKey:
        """加载发送方自己的 identity 私钥（用于四路 ECDH）"""
        identity = self._identity_fn()
        private_key_pem = identity.get("private_key_pem")
        if not private_key_pem:
            raise E2EEError("sender identity private key unavailable")
        pk = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
        if not isinstance(pk, ec.EllipticCurvePrivateKey):
            raise E2EEError("sender identity key is not EC key")
        return pk

    def _local_identity_fingerprint(self) -> str:
        """本地 identity 指纹（优先证书 DER SHA-256，缺失时回退到公钥指纹）"""
        identity = self._identity_fn()
        # 优先用证书指纹（与 PKI 一致）
        cert_pem = identity.get("cert")
        if isinstance(cert_pem, str) and cert_pem:
            cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
            return self._certificate_sha256_fingerprint(cert)
        # 无证书时回退到公钥 SPKI 指纹
        public_key_der_b64 = identity.get("public_key_der_b64")
        if isinstance(public_key_der_b64, str) and public_key_der_b64:
            return self._fingerprint_der_public_key(base64.b64decode(public_key_der_b64))
        private_key_pem = identity.get("private_key_pem")
        if isinstance(private_key_pem, str) and private_key_pem:
            private_key = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
            return self._fingerprint_public_key(private_key.public_key())
        raise E2EEError("identity fingerprint unavailable")

    @classmethod
    def _fingerprint_public_key(cls, public_key: Any) -> str:
        der = public_key.public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return cls._fingerprint_der_public_key(der)

    @staticmethod
    def _fingerprint_der_public_key(der: bytes) -> str:
        digest = hashes.Hash(hashes.SHA256())
        digest.update(der)
        return f"sha256:{digest.finalize().hex()}"

    @staticmethod
    def _certificate_sha256_fingerprint(cert: x509.Certificate) -> str:
        return f"sha256:{cert.fingerprint(hashes.SHA256()).hex()}"

    # ── 内部工具 ─────────────────────────────────────────────

    def _current_aid(self) -> str | None:
        identity = self._identity_fn()
        aid = identity.get("aid")
        return str(aid) if aid else None

    def _current_device_id(self) -> str:
        try:
            device_id = self._device_id_fn()
        except Exception:
            return ""
        return str(device_id or "").strip()

    def _keystore(self) -> Any | None:
        return self._keystore_ref


# ── 群组 E2EE 函数 ─────────────────────────────────────────


def _derive_group_msg_key(
    group_secret: bytes, group_id: str, message_id: str,
) -> bytes:
    """从 group_secret 派生单条群消息的加密密钥。"""
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=f"aun-group:{group_id}:msg:{message_id}".encode("utf-8"),
    )
    return hkdf.derive(group_secret)


def _aad_bytes_group(aad: dict[str, Any]) -> bytes:
    """群组 AAD 序列化（sorted keys, compact JSON）。"""
    return _aad_bytes_with_optional_fields(aad, AAD_FIELDS_GROUP)


def _aad_matches_group(expected: dict[str, Any], actual: dict[str, Any]) -> bool:
    """群组 AAD 字段匹配检查。"""
    return all(expected.get(f) == actual.get(f) for f in AAD_MATCH_FIELDS_GROUP)


def encrypt_group_message(
    group_id: str,
    epoch: int,
    group_secret: bytes,
    payload: dict[str, Any],
    *,
    from_aid: str,
    message_id: str,
    logger=_null_logger,
    timestamp: int,
    sender_private_key_pem: str | None = None,
    sender_cert_pem: bytes | str | None = None,
    protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """加密群组消息，返回 e2ee.group_encrypted 信封。

    sender_private_key_pem: 可选，传入时为密文附加发送方 ECDSA 签名（不可否认性）。
    """
    msg_key = _derive_group_msg_key(group_secret, group_id, message_id)
    plaintext = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    nonce = secrets.token_bytes(12)
    aesgcm = AESGCM(msg_key)

    aad = {
        "group_id": group_id,
        "from": from_aid,
        "message_id": message_id,
        "timestamp": timestamp,
        "epoch": epoch,
        "encryption_mode": MODE_EPOCH_GROUP_KEY,
        "suite": SUITE,
    }
    envelope_meta: dict[str, Any] = {}
    _copy_optional_envelope_metadata(
        envelope_meta,
        message_key=msg_key,
        payload_type=payload.get("type"),
        protected_headers=protected_headers,
        context=context,
    )
    ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, _aad_bytes_group(aad))
    ciphertext = ciphertext_with_tag[:-_AES_GCM_TAG_LEN]
    tag = ciphertext_with_tag[-_AES_GCM_TAG_LEN:]

    envelope = {
        "type": "e2ee.group_encrypted",
        "version": "1",
        "encryption_mode": MODE_EPOCH_GROUP_KEY,
        "suite": SUITE,
        "epoch": epoch,
        "nonce": base64.b64encode(nonce).decode("ascii"),
        "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        "tag": base64.b64encode(tag).decode("ascii"),
        "aad": aad,
        **envelope_meta,
    }

    # 发送方签名：对 ciphertext + tag + aad_bytes 签名（不可否认性）
    if sender_private_key_pem:
        try:
            pk = serialization.load_pem_private_key(
                sender_private_key_pem.encode("utf-8") if isinstance(sender_private_key_pem, str)
                else sender_private_key_pem,
                password=None,
            )
            sign_payload = ciphertext + tag + _aad_bytes_group(aad)
            sig = pk.sign(sign_payload, ec.ECDSA(hashes.SHA256()))
            envelope["sender_signature"] = base64.b64encode(sig).decode("ascii")
            if sender_cert_pem:
                sender_cert = x509.load_pem_x509_certificate(
                    sender_cert_pem.encode("utf-8") if isinstance(sender_cert_pem, str) else sender_cert_pem
                )
                envelope["sender_cert_fingerprint"] = E2EEManager._certificate_sha256_fingerprint(sender_cert)
        except Exception as exc:
            logger.warn("e2ee", "group msg sender signature failed: %s", exc)

    return envelope


def decrypt_group_message(
    message: dict[str, Any],
    group_secrets: dict[int, bytes],
    sender_cert_pem: bytes | None = None,
    *,
    require_signature: bool = True,
    logger=_null_logger,
) -> dict[str, Any] | None:
    """解密群组消息。

    group_secrets: {epoch: group_secret_bytes} 映射。
    sender_cert_pem: 发送方证书，用于验证签名。
    require_signature: 为 True 时（默认），若消息含签名但无证书可验证，或缺少签名，
        则拒绝消息（零信任模式）。设为 False 可退回旧的兼容行为（不推荐）。
    返回解密后的 message，或 None 表示失败。
    """
    payload = message.get("payload")
    if not isinstance(payload, dict):
        return None
    if payload.get("type") != "e2ee.group_encrypted":
        return None

    epoch = payload.get("epoch")
    if epoch is None:
        return None

    group_secret = group_secrets.get(epoch)
    if group_secret is None:
        return None

    try:
        # 优先从 AAD 读取 group_id 和 message_id（SDK 加密时的原始值）
        # 外层的 message_id 可能是 Group Service 重新生成的
        aad = payload.get("aad")
        outer_group_id = message.get("group_id", "")

        if isinstance(aad, dict):
            group_id = aad.get("group_id", outer_group_id)
            message_id = aad.get("message_id", message.get("message_id", ""))
            aad_from = aad.get("from", "")

            # 外层路由字段与 AAD 绑定校验：
            # group_id 必须一致（防止跨群路由篡改）
            if outer_group_id and group_id != outer_group_id:
                return None
            # from 和 sender_aid 都必须与 AAD 中的 from 一致（防止发送者冒充）
            if aad_from:
                outer_from = message.get("from", "")
                outer_sender = message.get("sender_aid", "")
                if outer_from and outer_from != aad_from:
                    return None
                if outer_sender and outer_sender != aad_from:
                    return None
        else:
            group_id = outer_group_id
            message_id = message.get("message_id", "")

        if not group_id or not message_id:
            return None

        msg_key = _derive_group_msg_key(group_secret, group_id, message_id)
        nonce = base64.b64decode(payload["nonce"])
        ciphertext = base64.b64decode(payload["ciphertext"])
        tag = base64.b64decode(payload["tag"])
        if not _verify_envelope_metadata_auth(payload, msg_key):
            return None

        # AAD 校验：直接用 payload 中的 AAD（因为加密时写入的就是这些值）
        if isinstance(aad, dict):
            aad_bytes = _aad_bytes_group(aad)
        else:
            aad_bytes = b""

        aesgcm = AESGCM(msg_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, aad_bytes)
        decoded = json.loads(plaintext.decode("utf-8"))
        if not _validate_decrypted_envelope_metadata(decoded, payload, message):
            return None

        result = dict(message)
        result["payload"] = decoded
        result["encrypted"] = True
        e2ee = {
            "encryption_mode": MODE_EPOCH_GROUP_KEY,
            "suite": SUITE,
            "epoch": epoch,
            "sender_verified": False,
        }
        protected_headers = _exposed_envelope_metadata(payload.get("protected_headers"))
        if protected_headers is not None:
            e2ee["protected_headers"] = protected_headers
        context_meta = _exposed_envelope_metadata(payload.get("context"))
        if context_meta is not None:
            e2ee["context"] = context_meta
        result["e2ee"] = e2ee

        # 发送方签名验证（零信任：默认强制要求签名 + 证书）
        sender_sig_b64 = payload.get("sender_signature")
        if require_signature:
            # 零信任模式：必须有签名且有证书可验证
            if not sender_sig_b64:
                logger.warn("e2ee", "reject group msg without sender signature (require_signature=True): group=%s from=%s", group_id, aad_from)
                return None
            if not sender_cert_pem:
                logger.warn("e2ee", 
                    "拒绝群消息：有签名但无发送方证书可验证（零信任模式禁止跳过验签）: group=%s from=%s",
                    group_id, aad_from,
                )
                return None
            try:
                sender_cert = x509.load_pem_x509_certificate(
                    sender_cert_pem if isinstance(sender_cert_pem, bytes)
                    else sender_cert_pem.encode("utf-8")
                )
                sender_pub = sender_cert.public_key()
                sig_bytes = base64.b64decode(sender_sig_b64)
                verify_payload = ciphertext + tag + aad_bytes
                sender_pub.verify(sig_bytes, verify_payload, ec.ECDSA(hashes.SHA256()))
                e2ee["sender_verified"] = True
            except Exception:
                logger.warn("e2ee", "group msg sender signature verification failed: group=%s from=%s", group_id, aad_from)
                return None
        elif sender_cert_pem:
            # 非零信任模式但提供了证书：有证书时强制验签
            if not sender_sig_b64:
                logger.warn("e2ee", "reject group msg without sender signature: group=%s from=%s", group_id, aad_from)
                return None
            try:
                sender_cert = x509.load_pem_x509_certificate(
                    sender_cert_pem if isinstance(sender_cert_pem, bytes)
                    else sender_cert_pem.encode("utf-8")
                )
                sender_pub = sender_cert.public_key()
                sig_bytes = base64.b64decode(sender_sig_b64)
                verify_payload = ciphertext + tag + aad_bytes
                sender_pub.verify(sig_bytes, verify_payload, ec.ECDSA(hashes.SHA256()))
                e2ee["sender_verified"] = True
            except Exception:
                logger.warn("e2ee", "group msg sender signature verification failed: group=%s from=%s", group_id, aad_from)
                return None

        return result
    except Exception as exc:
        logger.warn("e2ee-group", "decrypt_group_message wrapper failed: group=%s err=%s", group_id, exc)
        return None


# ── Membership Manifest（成员变更授权证明）──────────────


def build_membership_manifest(
    group_id: str,
    epoch: int,
    prev_epoch: int | None,
    member_aids: list[str],
    added: list[str] | None = None,
    removed: list[str] | None = None,
    initiator_aid: str = "",
) -> dict[str, Any]:
    """构建 Membership Manifest（未签名）。"""
    return {
        "manifest_version": 1,
        "group_id": group_id,
        "epoch": epoch,
        "prev_epoch": prev_epoch,
        "member_aids": sorted(member_aids),
        "added": sorted(added or []),
        "removed": sorted(removed or []),
        "initiator_aid": initiator_aid,
        "issued_at": int(_time_mod.time() * 1000),
    }


def _manifest_sign_data(manifest: dict[str, Any]) -> bytes:
    """序列化 manifest 为签名输入。"""
    # 固定字段顺序，确保签名确定性
    fields = [
        str(manifest.get("manifest_version", 1)),
        manifest.get("group_id", ""),
        str(manifest.get("epoch", 0)),
        str(manifest.get("prev_epoch", "")),
        "|".join(manifest.get("member_aids", [])),
        "|".join(manifest.get("added", [])),
        "|".join(manifest.get("removed", [])),
        manifest.get("initiator_aid", ""),
        str(manifest.get("issued_at", 0)),
    ]
    return "\n".join(fields).encode("utf-8")


def _group_key_response_sign_data(payload: dict[str, Any]) -> bytes:
    fields = [
        str(payload.get("response_version", 1)),
        str(payload.get("group_id", "")),
        str(payload.get("epoch", 0)),
        str(payload.get("requester_aid", "")),
        str(payload.get("request_id", "")),
        str(payload.get("responder_aid", "")),
        str(payload.get("commitment", "")),
        "|".join(sorted(str(item) for item in (payload.get("member_aids", []) or []))),
        str(payload.get("issued_at", 0)),
    ]
    return "\n".join(fields).encode("utf-8")


def sign_group_key_response(payload: dict[str, Any], private_key_pem: str) -> dict[str, Any]:
    pk = serialization.load_pem_private_key(
        private_key_pem.encode("utf-8") if isinstance(private_key_pem, str) else private_key_pem,
        password=None,
    )
    signed = dict(payload)
    signed.setdefault("response_version", 1)
    signed.setdefault("issued_at", int(_time_mod.time() * 1000))
    sig = pk.sign(_group_key_response_sign_data(signed), ec.ECDSA(hashes.SHA256()))
    signed["response_signature"] = base64.b64encode(sig).decode("ascii")
    return signed


def verify_group_key_response_signature(payload: dict[str, Any], responder_cert_pem: bytes | str) -> bool:
    sig_b64 = payload.get("response_signature")
    if not sig_b64:
        return False
    try:
        cert = x509.load_pem_x509_certificate(
            responder_cert_pem if isinstance(responder_cert_pem, bytes)
            else responder_cert_pem.encode("utf-8")
        )
        sig = base64.b64decode(sig_b64)
        cert.public_key().verify(sig, _group_key_response_sign_data(payload), ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


def sign_membership_manifest(
    manifest: dict[str, Any],
    private_key_pem: str,
) -> dict[str, Any]:
    """对 Membership Manifest 签名，返回带 signature 字段的新 manifest。"""
    pk = serialization.load_pem_private_key(
        private_key_pem.encode("utf-8") if isinstance(private_key_pem, str) else private_key_pem,
        password=None,
    )
    sign_data = _manifest_sign_data(manifest)
    sig = pk.sign(sign_data, ec.ECDSA(hashes.SHA256()))
    signed = dict(manifest)
    signed["signature"] = base64.b64encode(sig).decode("ascii")
    return signed


def verify_membership_manifest(
    manifest: dict[str, Any],
    initiator_cert_pem: bytes,
) -> bool:
    """验证 Membership Manifest 签名。"""
    sig_b64 = manifest.get("signature")
    if not sig_b64:
        return False
    try:
        cert = x509.load_pem_x509_certificate(
            initiator_cert_pem if isinstance(initiator_cert_pem, bytes)
            else initiator_cert_pem.encode("utf-8")
        )
        pub_key = cert.public_key()
        sig_bytes = base64.b64decode(sig_b64)
        sign_data = _manifest_sign_data(manifest)
        pub_key.verify(sig_bytes, sign_data, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


def compute_membership_commitment(
    member_aids: list[str], epoch: int, group_id: str,
    group_secret: bytes,
) -> str:
    """计算 Membership Commitment。

    commitment = SHA-256(sort(aids).join("|") + "|" + str(epoch) + "|" + group_id + "|" + SHA256(group_secret).hex())
    强制绑定 group_secret，防止恶意服务端替换密钥但保持 commitment 不变。
    """
    sorted_aids = sorted(member_aids)
    secret_hash = hashes.Hash(hashes.SHA256())
    secret_hash.update(group_secret)
    data = "|".join(sorted_aids) + "|" + str(epoch) + "|" + group_id + "|" + secret_hash.finalize().hex()
    digest = hashes.Hash(hashes.SHA256())
    digest.update(data.encode("utf-8"))
    return digest.finalize().hex()


# ── Epoch Transcript Chain ──────────────────────────────────

_EPOCH_CHAIN_GENESIS_PREFIX = b"aun-epoch-chain:genesis"


def compute_epoch_chain(
    prev_chain: str | None,
    epoch: int,
    commitment: str,
    rotator_aid: str,
) -> str:
    """计算当前 epoch 的 transcript chain hash。

    epoch_chain[1] = SHA-256(GENESIS_PREFIX | epoch_bytes(4BE) | commitment_utf8 | rotator_aid_utf8)
    epoch_chain[n] = SHA-256(prev_chain_bytes(32) | epoch_bytes(4BE) | commitment_utf8 | rotator_aid_utf8)

    链式绑定每个 epoch 的 commitment（含 group_secret 哈希）与操作者身份，
    可检测 epoch 回滚、分叉、phantom rotation 等攻击。
    """
    prefix = _EPOCH_CHAIN_GENESIS_PREFIX if prev_chain is None else bytes.fromhex(prev_chain)
    data = prefix + epoch.to_bytes(4, "big") + commitment.encode("utf-8") + rotator_aid.encode("utf-8")
    digest = hashes.Hash(hashes.SHA256())
    digest.update(data)
    return digest.finalize().hex()


# ── Group State Hash ──────────────────────────────────────


def compute_state_hash(
    *,
    group_id: str,
    state_version: int,
    key_epoch: int,
    members: list[dict],
    policy: dict,
    prev_state_hash: str,
) -> str:
    """计算群组状态哈希。

    state_hash = SHA-256(
        group_id | 0x00 |
        state_version (uint64 big-endian 8 bytes) | 0x00 |
        key_epoch (uint64 big-endian 8 bytes) | 0x00 |
        membership_block | 0x00 |
        policy_block | 0x00 |
        prev_state_hash (32 bytes, 全零表示创世)
    )

    membership_block: 按 AID 字典序排列 "{aid}:{role}"，用 "|" 拼接
    policy_block: JSON 规范化（key 字典序，无空格）
    """
    import json as _json

    # membership_block: 按 AID 字典序
    sorted_members = sorted(members, key=lambda m: m["aid"])
    membership_block = "|".join(f"{m['aid']}:{m['role']}" for m in sorted_members)

    # policy_block: 规范化 JSON
    policy_block = _json.dumps(policy, sort_keys=True, separators=(",", ":")) if policy else ""

    # prev_state_hash: 空字符串 → 32 字节零
    if prev_state_hash:
        prev_bytes = bytes.fromhex(prev_state_hash)
    else:
        prev_bytes = b"\x00" * 32

    # 拼接并计算 SHA-256
    data = (
        group_id.encode("utf-8") + b"\x00"
        + state_version.to_bytes(8, "big") + b"\x00"
        + key_epoch.to_bytes(8, "big") + b"\x00"
        + membership_block.encode("utf-8") + b"\x00"
        + policy_block.encode("utf-8") + b"\x00"
        + prev_bytes
    )
    digest = hashes.Hash(hashes.SHA256())
    digest.update(data)
    return digest.finalize().hex()


def verify_epoch_chain(
    epoch_chain: str,
    prev_chain: str | None,
    epoch: int,
    commitment: str,
    rotator_aid: str,
) -> bool:
    """验证 epoch_chain 是否与预期一致。"""
    expected = compute_epoch_chain(prev_chain, epoch, commitment, rotator_aid)
    return _hmac.compare_digest(expected.encode("utf-8"), epoch_chain.encode("utf-8"))


def verify_membership_commitment(
    commitment: str,
    member_aids: list[str],
    epoch: int,
    group_id: str,
    my_aid: str,
    group_secret: bytes,
) -> bool:
    """验证 Membership Commitment。

    1. 重算 commitment 是否匹配
    2. 检查 my_aid 是否在 member_aids 中
    """
    if my_aid not in member_aids:
        return False
    expected = compute_membership_commitment(member_aids, epoch, group_id, group_secret)
    return _hmac.compare_digest(expected.encode("utf-8"), commitment.encode("utf-8"))


# ── Group Secret 生命周期管理 ──────────────────────────────

# 旧 epoch 默认保留 7 天
OLD_EPOCH_RETENTION_SECONDS = 7 * 24 * 3600


def store_group_secret(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int,
    group_secret: bytes,
    commitment: str,
    member_aids: list[str],
    epoch_chain: str | None = None,
    pending_rotation_id: str = "",
    allow_pending_overwrite: bool = False,
    epoch_chain_unverified: bool | None = None,
    epoch_chain_unverified_reason: str | None = None,
) -> bool:
    """存储 group_secret 到 keystore。

    sqlite 主存时按 group_id 独立存取；自定义 keystore 未实现结构化接口时回退到 metadata。
    epoch_chain: 可选的 Epoch Transcript Chain hash，用于检测 epoch 回滚/分叉。
    """
    lock_key = f"{aid}:{group_id}"
    with _group_secret_locks_guard:
        lock = _group_secret_locks.setdefault(lock_key, threading.RLock())
    with lock:
        return _store_group_secret_locked(
            keystore, aid, group_id, epoch, group_secret, commitment, member_aids,
            epoch_chain=epoch_chain,
            pending_rotation_id=pending_rotation_id,
            allow_pending_overwrite=allow_pending_overwrite,
            epoch_chain_unverified=epoch_chain_unverified,
            epoch_chain_unverified_reason=epoch_chain_unverified_reason,
        )


def store_group_secret_epoch(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int,
    group_secret: bytes,
    commitment: str,
    member_aids: list[str],
    epoch_chain: str | None = None,
    pending_rotation_id: str = "",
    epoch_chain_unverified: bool | None = None,
    epoch_chain_unverified_reason: str | None = None,
) -> bool:
    """保存指定 epoch key。低于 current 时写入 old epoch，不覆盖 current。"""
    lock_key = f"{aid}:{group_id}"
    with _group_secret_locks_guard:
        lock = _group_secret_locks.setdefault(lock_key, threading.RLock())
    with lock:
        secret_b64 = base64.b64encode(group_secret).decode("ascii")
        epoch_i = int(epoch)
        members = sorted(member_aids)
        pending_id = str(pending_rotation_id or "").strip()
        row_result = _store_keystore_group_epoch(
            keystore,
            aid,
            group_id,
            epoch=epoch_i,
            secret=secret_b64,
            commitment=commitment,
            member_aids=members,
            epoch_chain=epoch_chain,
            pending_rotation_id=pending_id,
            epoch_chain_unverified=epoch_chain_unverified,
            epoch_chain_unverified_reason=epoch_chain_unverified_reason,
        )
        if row_result is not None:
            return row_result
        raise AttributeError(f"keystore {type(keystore).__name__} 缺少 store_group_secret_epoch 方法")


def discard_pending_group_secret(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int,
    rotation_id: str,
) -> bool:
    """丢弃指定 rotation 写入的本地 pending epoch key。"""
    rotation_id = str(rotation_id or "").strip()
    if not rotation_id:
        return False
    lock_key = f"{aid}:{group_id}"
    with _group_secret_locks_guard:
        lock = _group_secret_locks.setdefault(lock_key, threading.RLock())
    with lock:
        discard_fn = getattr(keystore, "discard_pending_group_secret_state", None)
        if callable(discard_fn):
            return bool(discard_fn(aid, group_id, epoch, rotation_id))
        raise AttributeError(f"keystore {type(keystore).__name__} 缺少 discard_pending_group_secret_state 方法")


def _store_group_secret_locked(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int,
    group_secret: bytes,
    commitment: str,
    member_aids: list[str],
    *,
    epoch_chain: str | None = None,
    pending_rotation_id: str = "",
    allow_pending_overwrite: bool = False,
    epoch_chain_unverified: bool | None = None,
    epoch_chain_unverified_reason: str | None = None,
) -> bool:
    transition_result = _store_keystore_group_transition(
        keystore,
        aid,
        group_id,
        epoch=epoch,
        secret=base64.b64encode(group_secret).decode("ascii"),
        commitment=commitment,
        member_aids=sorted(member_aids),
        epoch_chain=epoch_chain,
        pending_rotation_id=pending_rotation_id,
        epoch_chain_unverified=epoch_chain_unverified,
        epoch_chain_unverified_reason=epoch_chain_unverified_reason,
    )
    if transition_result is not None:
        return transition_result
    raise AttributeError(f"keystore {type(keystore).__name__} 缺少 store_group_secret_transition 方法")

def load_group_secret(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int | None = None,
) -> dict[str, Any] | None:
    """读取 group_secret。

    epoch=None 时返回最新 epoch。
    指定 epoch 时先查当前，再查 old_epochs。
    返回的 dict 包含 epoch, secret(bytes), commitment, member_aids。
    """
    entry = _load_keystore_group_epoch(keystore, aid, group_id, epoch)
    if entry is None:
        return None

    secret_str = entry.get("secret")
    if not secret_str:
        return None
    return {
        "epoch": entry["epoch"],
        "secret": base64.b64decode(secret_str),
        "commitment": entry.get("commitment"),
        "member_aids": entry.get("member_aids", []),
        "epoch_chain": entry.get("epoch_chain"),
        "pending_rotation_id": entry.get("pending_rotation_id"),
        "epoch_chain_unverified": entry.get("epoch_chain_unverified"),
        "epoch_chain_unverified_reason": entry.get("epoch_chain_unverified_reason"),
    }


def _assess_incoming_epoch_chain(
    keystore: Any,
    aid: str,
    group_id: str,
    epoch: int,
    commitment: str,
    incoming_chain: str | None,
    rotation_id: str,
    rotator_aid: str,
    source: str,
    logger=_null_logger,
) -> tuple[bool, bool | None, str | None]:
    incoming_chain = str(incoming_chain or "").strip()
    rotation_id = str(rotation_id or "").strip()
    rotator_aid = str(rotator_aid or "").strip()
    current_data = load_group_secret(keystore, aid, group_id)
    prev_data = load_group_secret(keystore, aid, group_id, int(epoch) - 1)
    current_chain_dbg = str(current_data.get("epoch_chain") or "") if current_data else ""
    prev_chain_dbg = str(prev_data.get("epoch_chain") or "") if prev_data else ""
    _debug_group_e2ee(
        "chain_assess_enter",
        aid=aid,
        group=group_id,
        epoch=epoch,
        rotation=rotation_id or "-",
        rotator=rotator_aid or "-",
        source=source,
        incoming=bool(incoming_chain),
        incoming_prefix=incoming_chain[:16] if incoming_chain else "-",
        current=bool(current_data),
        current_prefix=current_chain_dbg[:16] if current_chain_dbg else "-",
        prev=bool(prev_data),
        prev_prefix=prev_chain_dbg[:16] if prev_chain_dbg else "-",
        commitment=commitment[:16] if commitment else "-",
    )

    if rotation_id and not incoming_chain:
        logger.warn("e2ee", 
            "拒绝缺少 epoch_chain 的新 rotation key: source=%s group=%s epoch=%s rotation=%s",
            source, group_id, epoch, rotation_id,
        )
        _debug_group_e2ee(
            "chain_reject_missing_chain",
            aid=aid,
            group=group_id,
            epoch=epoch,
            rotation=rotation_id,
            source=source,
        )
        return False, None, None

    if current_data and int(current_data.get("epoch") or 0) == int(epoch):
        current_chain = str(current_data.get("epoch_chain") or "")
        current_pending_rotation_id = str(current_data.get("pending_rotation_id") or "")
        if incoming_chain and current_chain == incoming_chain:
            _debug_group_e2ee(
                "chain_accept_same_current",
                aid=aid,
                group=group_id,
                epoch=epoch,
                rotation=rotation_id or "-",
                source=source,
            )
            return True, None, None
        if rotation_id and incoming_chain and current_chain and current_chain != incoming_chain:
            if current_pending_rotation_id and current_pending_rotation_id != rotation_id:
                # 本地同 epoch 仍是未提交 pending secret。服务端可能因成员集变化废弃旧
                # rotation 并重新 begin 同一 target_epoch；继续用上一 epoch 校验 incoming。
                pass
            else:
                logger.warn("e2ee", 
                    "拒绝同 epoch 分叉 chain: source=%s group=%s epoch=%s rotation=%s",
                    source, group_id, epoch, rotation_id,
                )
                _debug_group_e2ee(
                    "chain_reject_same_epoch_fork",
                    aid=aid,
                    group=group_id,
                    epoch=epoch,
                    rotation=rotation_id,
                    source=source,
                    current_pending=current_pending_rotation_id or "-",
                )
                return False, None, None
        elif rotation_id and incoming_chain and current_pending_rotation_id == rotation_id and current_chain and current_chain != incoming_chain:
            logger.warn("e2ee", 
                "拒绝同 epoch 分叉 chain: source=%s group=%s epoch=%s rotation=%s",
                source, group_id, epoch, rotation_id,
            )
            _debug_group_e2ee(
                "chain_reject_same_rotation_fork",
                aid=aid,
                group=group_id,
                epoch=epoch,
                rotation=rotation_id,
                source=source,
            )
            return False, None, None

    prev_chain = str(prev_data.get("epoch_chain") or "") if prev_data else ""

    if not incoming_chain:
        _debug_group_e2ee(
            "chain_accept_compat_missing_chain",
            aid=aid,
            group=group_id,
            epoch=epoch,
            source=source,
        )
        return True, True, "missing_epoch_chain"
    if not prev_chain:
        _debug_group_e2ee(
            "chain_accept_unverified_missing_prev",
            aid=aid,
            group=group_id,
            epoch=epoch,
            rotation=rotation_id or "-",
            source=source,
        )
        return True, True, "missing_prev_chain"
    if not rotator_aid:
        if rotation_id:
            logger.warn("e2ee", 
                "拒绝缺少 rotator_aid 的新 rotation key: source=%s group=%s epoch=%s rotation=%s",
                source, group_id, epoch, rotation_id,
            )
            _debug_group_e2ee(
                "chain_reject_missing_rotator",
                aid=aid,
                group=group_id,
                epoch=epoch,
                rotation=rotation_id,
                source=source,
            )
            return False, None, None
        return True, True, "missing_rotator_aid"

    if not verify_epoch_chain(incoming_chain, prev_chain, epoch, commitment, rotator_aid):
        if rotation_id:
            logger.warn("e2ee", 
                "拒绝 epoch chain 验证失败的新 rotation key: source=%s group=%s epoch=%s rotation=%s",
                source, group_id, epoch, rotation_id,
            )
            _debug_group_e2ee(
                "chain_reject_verify_failed",
                aid=aid,
                group=group_id,
                epoch=epoch,
                rotation=rotation_id,
                rotator=rotator_aid,
                source=source,
                incoming_prefix=incoming_chain[:16],
                prev_prefix=prev_chain[:16],
                commitment=commitment[:16] if commitment else "-",
            )
            return False, None, None
        logger.warn("e2ee", 
            "epoch chain 验证失败，按兼容档接收并标记未验证: source=%s group=%s epoch=%s",
            source, group_id, epoch,
        )
        _debug_group_e2ee(
            "chain_accept_legacy_mismatch",
            aid=aid,
            group=group_id,
            epoch=epoch,
            source=source,
        )
        return True, True, "chain_mismatch_legacy"

    if not rotation_id:
        _debug_group_e2ee(
            "chain_accept_missing_rotation_id",
            aid=aid,
            group=group_id,
            epoch=epoch,
            source=source,
        )
        return True, True, "missing_rotation_id"
    _debug_group_e2ee(
        "chain_accept_verified",
        aid=aid,
        group=group_id,
        epoch=epoch,
        rotation=rotation_id,
        rotator=rotator_aid,
        source=source,
    )
    return True, False, None


def load_all_group_secrets(
    keystore: Any,
    aid: str,
    group_id: str,
) -> dict[int, bytes]:
    """加载某群组所有 epoch 的 group_secret。

    返回 {epoch: secret_bytes} 映射，可直接传入 decrypt_group_message。
    """
    result: dict[int, bytes] = {}
    for entry in _load_keystore_group_epochs(keystore, aid, group_id):
        secret_str = entry.get("secret")
        if secret_str and entry.get("epoch") is not None:
            result[int(entry["epoch"])] = base64.b64decode(secret_str)

    return result


def cleanup_old_epochs(
    keystore: Any,
    aid: str,
    group_id: str,
    retention_seconds: int = OLD_EPOCH_RETENTION_SECONDS,
) -> int:
    """清理过期的旧 epoch 记录。返回清理数量。"""
    cutoff_ms = int(_time_mod.time() * 1000) - retention_seconds * 1000
    return _cleanup_keystore_group_old_epochs(keystore, aid, group_id, cutoff_ms)


class GroupReplayGuard:
    """群组消息防重放守卫。

    key = "{group_id}:{sender_aid}:{message_id}"
    内置 LRU 裁剪。
    """

    def __init__(self, max_size: int = 50000) -> None:
        self._seen: dict[str, bool] = {}
        self._max_size = max_size

    def check_and_record(self, group_id: str, sender_aid: str, message_id: str) -> bool:
        """检查并记录。返回 True 表示首次（通过），False 表示重放（拒绝）。"""
        key = f"{group_id}:{sender_aid}:{message_id}"
        if key in self._seen:
            return False
        self._seen[key] = True
        self._trim()
        return True

    def is_seen(self, group_id: str, sender_aid: str, message_id: str) -> bool:
        """仅检查是否已记录，不修改状态。"""
        key = f"{group_id}:{sender_aid}:{message_id}"
        return key in self._seen

    def record(self, group_id: str, sender_aid: str, message_id: str) -> None:
        """仅记录，不检查。"""
        key = f"{group_id}:{sender_aid}:{message_id}"
        self._seen[key] = True
        self._trim()

    def _trim(self) -> None:
        if len(self._seen) > self._max_size:
            trim_count = len(self._seen) - int(self._max_size * 0.8)
            keys = list(self._seen.keys())[:trim_count]
            for k in keys:
                del self._seen[k]

    @property
    def size(self) -> int:
        return len(self._seen)


class GroupKeyRequestThrottle:
    """群组密钥请求/响应频率限制。

    同一 key 在 cooldown 秒内不允许重复操作。
    """

    def __init__(self, cooldown: float = 30.0) -> None:
        self._last: dict[str, float] = {}
        self._cooldown = cooldown

    def allow(self, key: str) -> bool:
        """检查是否允许操作。返回 True 并记录时间戳，或 False 表示被限制。"""
        now = _time_mod.time()
        last = self._last.get(key)
        if last is not None and (now - last) < self._cooldown:
            return False
        self._last[key] = now
        return True

    def reset(self, key: str) -> None:
        self._last.pop(key, None)


def check_epoch_downgrade(
    message_epoch: int,
    local_latest_epoch: int,
    *,
    allow_old_epoch: bool = False,
) -> bool:
    """检查 epoch 降级。

    返回 True 表示允许处理，False 表示拒绝。
    allow_old_epoch=True 时允许解密旧 epoch 消息（但 caller 应标记为历史消息）。
    """
    if message_epoch >= local_latest_epoch:
        return True
    return allow_old_epoch


# ── Group Key 分发与恢复协议 ──────────────────────────────

# ── ECIES：per-member epoch key 加密（服务端存储方案）──────

_ECIES_HKDF_INFO = b"aun-epoch-key-ecies"


def ecies_encrypt(peer_pubkey_bytes: bytes, plaintext: bytes) -> bytes:
    """P-256 ECDH + HKDF-SHA256 + AES-256-GCM 加密。

    peer_pubkey_bytes: 65 字节未压缩 P-256 公钥
    返回: ephemeral_pubkey(65B) || iv(12B) || ciphertext || tag(16B)
    """
    peer_pubkey = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), peer_pubkey_bytes)
    ephemeral_key = ec.generate_private_key(ec.SECP256R1())
    shared = ephemeral_key.exchange(ec.ECDH(), peer_pubkey)
    derived = HKDF(
        algorithm=hashes.SHA256(), length=32,
        salt=None, info=_ECIES_HKDF_INFO,
    ).derive(shared)
    iv = secrets.token_bytes(12)
    ciphertext_with_tag = AESGCM(derived).encrypt(iv, plaintext, None)
    ephemeral_pub_bytes = ephemeral_key.public_key().public_bytes(
        serialization.Encoding.X962,
        serialization.PublicFormat.UncompressedPoint,
    )
    return ephemeral_pub_bytes + iv + ciphertext_with_tag


def ecies_decrypt(own_privkey: ec.EllipticCurvePrivateKey, ciphertext: bytes) -> bytes:
    """ECIES 解密，对应 ecies_encrypt。

    ciphertext 格式: ephemeral_pubkey(65B) || iv(12B) || encrypted || tag(16B)
    """
    ephemeral_pub_bytes = ciphertext[:65]
    iv = ciphertext[65:77]
    encrypted_with_tag = ciphertext[77:]
    ephemeral_pubkey = ec.EllipticCurvePublicKey.from_encoded_point(
        ec.SECP256R1(), ephemeral_pub_bytes
    )
    shared = own_privkey.exchange(ec.ECDH(), ephemeral_pubkey)
    derived = HKDF(
        algorithm=hashes.SHA256(), length=32,
        salt=None, info=_ECIES_HKDF_INFO,
    ).derive(shared)
    return AESGCM(derived).decrypt(iv, encrypted_with_tag, None)


def generate_group_secret() -> bytes:
    """生成 32 字节随机 group_secret。"""
    return secrets.token_bytes(32)


def build_key_distribution(
    group_id: str,
    epoch: int,
    group_secret: bytes,
    member_aids: list[str],
    distributed_by: str,
    manifest: dict[str, Any] | None = None,
    epoch_chain: str | None = None,
) -> dict[str, Any]:
    """构建 group key 分发消息 payload。

    此 payload 应通过 P2P E2EE 通道逐个发送给每个群成员。
    manifest: 可选的已签名 Membership Manifest，附加后接收方可验证成员变更授权。
    epoch_chain: 可选的 Epoch Transcript Chain hash，附加后接收方可验证 epoch 连续性。
    """
    commitment = compute_membership_commitment(member_aids, epoch, group_id, group_secret)
    result = {
        "type": "e2ee.group_key_distribution",
        "group_id": group_id,
        "epoch": epoch,
        "group_secret": base64.b64encode(group_secret).decode("ascii"),
        "commitment": commitment,
        "member_aids": sorted(member_aids),
        "distributed_by": distributed_by,
        "distributed_at": int(_time_mod.time() * 1000),
    }
    if manifest:
        result["manifest"] = manifest
    if epoch_chain:
        result["epoch_chain"] = epoch_chain
    return result


def handle_key_distribution(
    message: dict[str, Any],
    keystore: Any,
    aid: str,
    initiator_cert_pem: bytes | None = None,
    logger=_null_logger,
) -> bool:
    """处理收到的 group key 分发消息。

    验证 manifest 签名 → 验证 commitment → 验证自己在 member_aids 中 → 存储 group_secret。
    initiator_cert_pem: 传入时强制要求 manifest 存在且签名有效。
    返回 True 表示成功处理，False 表示验证失败。
    """
    payload = message if "group_id" in message else message.get("payload", message)

    group_id = payload.get("group_id")
    epoch = payload.get("epoch")
    group_secret_b64 = payload.get("group_secret")
    commitment = payload.get("commitment")
    member_aids = payload.get("member_aids", [])

    logger.debug("e2ee", "handle_key_distribution start: group=%s epoch=%s aid=%s members=%d has_cert=%s",
                 group_id, epoch, aid, len(member_aids) if isinstance(member_aids, list) else 0, bool(initiator_cert_pem))

    if not all([group_id, epoch is not None, group_secret_b64, commitment]):
        logger.warn("e2ee", "reject key distribution: missing fields group=%s epoch=%s aid=%s", group_id, epoch, aid)
        return False

    # 验证 Membership Manifest 签名
    manifest = payload.get("manifest")
    if initiator_cert_pem:
        # 有验证能力时强制要求 manifest
        if not manifest:
            logger.warn("e2ee", "reject key distribution without manifest: group=%s epoch=%s", group_id, epoch)
            return False
        if not verify_membership_manifest(manifest, initiator_cert_pem):
            logger.warn("e2ee", "group key distribution manifest signature verification failed: group=%s epoch=%s", group_id, epoch)
            return False
        # 验证 manifest 与分发消息一致
        if manifest.get("group_id") != group_id or manifest.get("epoch") != epoch:
            return False
        if sorted(manifest.get("member_aids", [])) != sorted(member_aids):
            return False
    elif manifest:
        # 无验证能力但有 manifest → 只做字段一致性检查
        if manifest.get("group_id") != group_id or manifest.get("epoch") != epoch:
            return False
        if sorted(manifest.get("member_aids", [])) != sorted(member_aids):
            return False

    group_secret = base64.b64decode(group_secret_b64)

    # 验证 commitment（强制绑定 group_secret）
    if not verify_membership_commitment(commitment, member_aids, epoch, group_id, aid, group_secret):
        logger.warn("e2ee", "reject key distribution: commitment verification failed group=%s epoch=%s aid=%s", group_id, epoch, aid)
        return False

    incoming_chain = payload.get("epoch_chain")
    rotation_id = str(payload.get("rotation_id") or "")
    chain_ok, chain_unverified, chain_reason = _assess_incoming_epoch_chain(
        keystore, aid, group_id, int(epoch), commitment,
        str(incoming_chain or "") or None,
        rotation_id,
        str(payload.get("distributed_by") or payload.get("rotator_aid") or ""),
        "key_distribution",
        logger,
    )
    if not chain_ok:
        return False

    result = store_group_secret(
        keystore, aid, group_id, epoch, group_secret, commitment, member_aids,
        epoch_chain=str(incoming_chain or "") or None,
        pending_rotation_id=rotation_id,
        allow_pending_overwrite=bool(rotation_id),
        epoch_chain_unverified=chain_unverified,
        epoch_chain_unverified_reason=chain_reason,
    )
    if result:
        logger.debug("e2ee", "handle_key_distribution store ok: group=%s epoch=%s aid=%s", group_id, epoch, aid)
    else:
        logger.error("e2ee-group", "handle_key_distribution store failed: group=%s epoch=%s aid=%s", group_id, epoch, aid)
    return result


def build_key_request(
    group_id: str,
    epoch: int,
    requester_aid: str,
    request_id: str | None = None,
) -> dict[str, Any]:
    """构建密钥请求 payload。通过 P2P E2EE 通道发送。"""
    return {
        "type": "e2ee.group_key_request",
        "group_id": group_id,
        "epoch": epoch,
        "requester_aid": requester_aid,
        "request_id": request_id or str(uuid.uuid4()),
        "requested_at": int(_time_mod.time() * 1000),
    }


def handle_key_request(
    request: dict[str, Any],
    keystore: Any,
    aid: str,
    current_members: list[str],
    private_key_pem: str | None = None,
    logger=_null_logger,
) -> dict[str, Any] | None:
    """处理收到的密钥请求。

    验证请求者是群成员 → 查本地密钥 → 构建响应。
    返回响应 payload（通过 P2P E2EE 回复），或 None 表示拒绝。
    """
    payload = request if "group_id" in request else request.get("payload", request)

    requester_aid = payload.get("requester_aid")
    group_id = payload.get("group_id")
    epoch = payload.get("epoch")

    logger.debug("e2ee", "handle_key_request start: group=%s epoch=%s requester=%s aid=%s",
                 group_id, epoch, requester_aid, aid)

    if not all([requester_aid, group_id, epoch is not None]):
        logger.warn("e2ee", "reject key request: missing fields group=%s epoch=%s requester=%s", group_id, epoch, requester_aid)
        return None

    # 验证请求者是当前群成员
    if requester_aid not in current_members:
        logger.warn("e2ee", "reject key request: %s not in current member list group=%s", requester_aid, group_id)
        return None

    # 查本地密钥
    secret_data = load_group_secret(keystore, aid, group_id, epoch)
    if secret_data is None:
        logger.debug("e2ee", "reject key request: local missing epoch=%s key group=%s", epoch, group_id)
        return None

    # P0 历史隔离：请求者必须属于目标 epoch 的成员集，
    # 拒绝新成员获取加入前的旧 epoch key。
    member_aids = sorted(str(m) for m in (secret_data.get("member_aids", []) or []) if m)
    if member_aids and requester_aid not in member_aids:
        logger.warn("e2ee",
            "拒绝密钥恢复：%s 不属于 group=%s epoch=%s 的成员集",
            requester_aid, group_id, epoch,
        )
        return None

    commitment = secret_data.get("commitment", "")
    response_member_aids = member_aids or sorted(str(m) for m in (current_members or []) if m)
    if not commitment:
        commitment = compute_membership_commitment(response_member_aids, epoch, group_id, secret_data["secret"])

    response = {
        "type": "e2ee.group_key_response",
        "group_id": group_id,
        "epoch": epoch,
        "group_secret": base64.b64encode(secret_data["secret"]).decode("ascii"),
        "commitment": commitment,
        "member_aids": response_member_aids,
        "requester_aid": requester_aid,
        "request_id": payload.get("request_id", ""),
        "responder_aid": aid,
        "issued_at": int(_time_mod.time() * 1000),
    }
    epoch_chain = secret_data.get("epoch_chain")
    if epoch_chain:
        response["epoch_chain"] = epoch_chain
    if private_key_pem:
        response = sign_group_key_response(response, private_key_pem)
    logger.debug("e2ee", "handle_key_request response built: group=%s epoch=%s requester=%s signed=%s",
                 group_id, epoch, requester_aid, bool(private_key_pem))
    return response


def handle_key_response(
    response: dict[str, Any],
    keystore: Any,
    aid: str,
    *,
    expected_request: dict[str, Any] | None = None,
    logger=_null_logger,
    responder_cert_pem: bytes | str | None = None,
    current_members: list[str] | None = None,
    strict: bool = False,
) -> bool:
    """处理收到的密钥响应。

    验证 commitment → manifest 一致性校验 → 存储。返回 True 表示成功。
    """
    payload = response if "group_id" in response else response.get("payload", response)

    group_id = payload.get("group_id")
    epoch = payload.get("epoch")
    group_secret_b64 = payload.get("group_secret")
    commitment = payload.get("commitment")
    member_aids = payload.get("member_aids", [])

    logger.debug("e2ee", "handle_key_response start: group=%s epoch=%s aid=%s responder=%s strict=%s",
                 group_id, epoch, aid, payload.get("responder_aid"), strict)

    _debug_group_e2ee(
        "key_response_enter",
        aid=aid,
        group=group_id or "-",
        epoch=epoch if epoch is not None else "-",
        responder=str(payload.get("responder_aid") or "-"),
        requester=str(payload.get("requester_aid") or "-"),
        request_id=str(payload.get("request_id") or "-"),
        strict=strict,
        has_expected=expected_request is not None,
        has_cert=bool(responder_cert_pem),
        has_sig=bool(payload.get("response_signature")),
        members=len(member_aids) if isinstance(member_aids, list) else "-",
        commitment=str(commitment or "")[:16] if commitment else "-",
    )

    if not all([group_id, epoch is not None, group_secret_b64, commitment]):
        logger.warn("e2ee",
            "拒绝 group key response：字段不完整 aid=%s group=%s epoch=%s has_secret=%s has_commitment=%s",
            aid, group_id, epoch, bool(group_secret_b64), bool(commitment),
        )
        _debug_group_e2ee(
            "key_response_reject_incomplete",
            aid=aid,
            group=group_id or "-",
            epoch=epoch if epoch is not None else "-",
            has_secret=bool(group_secret_b64),
            has_commitment=bool(commitment),
        )
        return False

    # future-epoch 守卫：未带 expected_request 时，本地已有 epoch 的情况下拒绝高于本地最高 epoch 的响应。
    # 防止恶意/错误响应绕过轮换流程把本地推进到未来 epoch。
    # 本地完全没有 epoch（首次加群）时放行，由后续 commitment / chain 校验把关。
    if expected_request is None:
        try:
            entries = _load_keystore_group_epochs(keystore, aid, group_id)
            known_epochs = [int(e.get("epoch")) for e in entries if isinstance(e.get("epoch"), int)]
        except Exception:
            known_epochs = []
        if known_epochs:
            local_max_epoch = max(known_epochs)
            if int(epoch) > local_max_epoch:
                logger.warn("e2ee",
                    "拒绝 group key response：epoch 超出本地最高已知 epoch aid=%s group=%s epoch=%s local_max=%s",
                    aid, group_id, epoch, local_max_epoch,
                )
                _debug_group_e2ee(
                    "key_response_reject_future_epoch",
                    aid=aid,
                    group=group_id,
                    epoch=epoch,
                    local_max=local_max_epoch,
                )
                return False

    if expected_request is not None:
        if payload.get("requester_aid") != aid:
            logger.warn("e2ee", 
                "拒绝 group key response：requester 不匹配 aid=%s group=%s epoch=%s requester=%s",
                aid, group_id, epoch, payload.get("requester_aid"),
            )
            _debug_group_e2ee(
                "key_response_reject_requester_mismatch",
                aid=aid,
                group=group_id,
                epoch=epoch,
                requester=str(payload.get("requester_aid") or "-"),
            )
            return False
        expected_responder = str(expected_request.get("_expected_responder_aid") or "")
        if expected_responder and payload.get("responder_aid") != expected_responder:
            logger.warn("e2ee", 
                "拒绝 group key response：responder 不匹配 aid=%s group=%s epoch=%s expected=%s actual=%s",
                aid, group_id, epoch, expected_responder, payload.get("responder_aid"),
            )
            _debug_group_e2ee(
                "key_response_reject_responder_mismatch",
                aid=aid,
                group=group_id,
                epoch=epoch,
                expected=expected_responder or "-",
                actual=str(payload.get("responder_aid") or "-"),
            )
            return False
        if payload.get("request_id") != expected_request.get("request_id"):
            logger.warn("e2ee", 
                "拒绝 group key response：request_id 不匹配 aid=%s group=%s epoch=%s expected=%s actual=%s",
                aid, group_id, epoch, expected_request.get("request_id"), payload.get("request_id"),
            )
            _debug_group_e2ee(
                "key_response_reject_request_id_mismatch",
                aid=aid,
                group=group_id,
                epoch=epoch,
                expected=str(expected_request.get("request_id") or "-"),
                actual=str(payload.get("request_id") or "-"),
            )
            return False
        if payload.get("group_id") != expected_request.get("group_id"):
            logger.warn("e2ee", 
                "拒绝 group key response：group 不匹配 aid=%s expected=%s actual=%s",
                aid, expected_request.get("group_id"), payload.get("group_id"),
            )
            _debug_group_e2ee(
                "key_response_reject_group_mismatch",
                aid=aid,
                expected=str(expected_request.get("group_id") or "-"),
                actual=str(payload.get("group_id") or "-"),
            )
            return False
        if int(payload.get("epoch") or 0) != int(expected_request.get("epoch") or 0):
            logger.warn("e2ee", 
                "拒绝 group key response：epoch 不匹配 aid=%s group=%s expected=%s actual=%s",
                aid, group_id, expected_request.get("epoch"), payload.get("epoch"),
            )
            _debug_group_e2ee(
                "key_response_reject_epoch_mismatch",
                aid=aid,
                group=group_id,
                expected=str(expected_request.get("epoch") or "-"),
                actual=str(payload.get("epoch") or "-"),
            )
            return False

    responder_aid = str(payload.get("responder_aid") or "")
    if strict:
        if not responder_aid or not responder_cert_pem:
            logger.warn("e2ee", 
                "拒绝 group key response：responder 身份不可校验 aid=%s group=%s epoch=%s responder=%s has_cert=%s",
                aid, group_id, epoch, responder_aid, bool(responder_cert_pem),
            )
            _debug_group_e2ee(
                "key_response_reject_identity_unverifiable",
                aid=aid,
                group=group_id,
                epoch=epoch,
                responder=responder_aid or "-",
                has_cert=bool(responder_cert_pem),
                has_sig=bool(payload.get("response_signature")),
            )
            return False
        if current_members and responder_aid not in current_members:
            logger.warn("e2ee", 
                "拒绝 group key response：responder not in current member list aid=%s group=%s epoch=%s responder=%s current_members=%s",
                aid, group_id, epoch, responder_aid, current_members,
            )
            _debug_group_e2ee(
                "key_response_reject_responder_not_member",
                aid=aid,
                group=group_id,
                epoch=epoch,
                responder=responder_aid,
                current_members=",".join(current_members),
            )
            return False
        if not verify_group_key_response_signature(payload, responder_cert_pem):
            logger.warn("e2ee", 
                "拒绝 group key response：签名无效 aid=%s group=%s epoch=%s responder=%s",
                aid, group_id, epoch, responder_aid,
            )
            _debug_group_e2ee(
                "key_response_reject_bad_signature",
                aid=aid,
                group=group_id,
                epoch=epoch,
                responder=responder_aid,
            )
            return False
    elif responder_cert_pem is not None and payload.get("response_signature"):
        if not verify_group_key_response_signature(payload, responder_cert_pem):
            logger.warn("e2ee", 
                "拒绝 group key response：签名无效 aid=%s group=%s epoch=%s responder=%s strict=false",
                aid, group_id, epoch, responder_aid,
            )
            _debug_group_e2ee(
                "key_response_reject_bad_signature_non_strict",
                aid=aid,
                group=group_id,
                epoch=epoch,
                responder=responder_aid or "-",
            )
            return False

    group_secret = base64.b64decode(group_secret_b64)

    if not verify_membership_commitment(commitment, member_aids, epoch, group_id, aid, group_secret):
        logger.warn("e2ee", 
            "拒绝 group key response：membership commitment 无效 aid=%s group=%s epoch=%s member_aids=%s commitment=%s",
            aid, group_id, epoch, member_aids, str(commitment)[:16],
        )
        _debug_group_e2ee(
            "key_response_reject_commitment_verify",
            aid=aid,
            group=group_id,
            epoch=epoch,
            members=len(member_aids) if isinstance(member_aids, list) else "-",
            commitment=str(commitment)[:16],
        )
        return False

    # manifest 一致性校验（如果响应包含 manifest，验证其与 payload 匹配）
    manifest = payload.get("manifest")
    if manifest and isinstance(manifest, dict):
        if manifest.get("group_id") != group_id:
            logger.warn("e2ee", 
                "拒绝 group key response：manifest group 不匹配 aid=%s group=%s epoch=%s manifest_group=%s",
                aid, group_id, epoch, manifest.get("group_id"),
            )
            return False
        if manifest.get("epoch") != epoch:
            logger.warn("e2ee", 
                "拒绝 group key response：manifest epoch 不匹配 aid=%s group=%s epoch=%s manifest_epoch=%s",
                aid, group_id, epoch, manifest.get("epoch"),
            )
            return False
        manifest_members = manifest.get("member_aids", [])
        if manifest_members and sorted(manifest_members) != sorted(member_aids):
            logger.warn("e2ee", 
                "拒绝 group key response：manifest members 不匹配 aid=%s group=%s epoch=%s manifest_members=%s member_aids=%s",
                aid, group_id, epoch, manifest_members, member_aids,
            )
            return False

    incoming_chain = payload.get("epoch_chain")
    rotation_id = str(payload.get("rotation_id") or "")
    chain_ok, chain_unverified, chain_reason = _assess_incoming_epoch_chain(
        keystore, aid, group_id, int(epoch), commitment,
        str(incoming_chain or "") or None,
        rotation_id,
        str(payload.get("distributed_by") or payload.get("rotator_aid") or payload.get("responder_aid") or ""),
        "key_response",
        logger,
    )
    if not chain_ok:
        logger.warn("e2ee", 
            "拒绝 group key response：epoch chain 无效 aid=%s group=%s epoch=%s rotation=%s chain=%s",
            aid, group_id, epoch, rotation_id, str(incoming_chain or "")[:16],
        )
        _debug_group_e2ee(
            "key_response_reject_chain",
            aid=aid,
            group=group_id,
            epoch=epoch,
            responder=str(payload.get("responder_aid") or "-"),
            rotation=rotation_id or "-",
        )
        return False

    stored = store_group_secret_epoch(
        keystore, aid, group_id, epoch, group_secret, commitment, member_aids,
        epoch_chain=str(incoming_chain or "") or None,
        pending_rotation_id=rotation_id,
        epoch_chain_unverified=chain_unverified,
        epoch_chain_unverified_reason=chain_reason,
    )
    _debug_group_e2ee(
        "key_response_store_result",
        aid=aid,
        group=group_id,
        epoch=epoch,
        responder=str(payload.get("responder_aid") or "-"),
        stored=stored,
        unverified=chain_unverified,
        reason=chain_reason or "-",
    )
    if stored:
        logger.debug("e2ee", "handle_key_response store ok: group=%s epoch=%s aid=%s responder=%s",
                     group_id, epoch, aid, payload.get("responder_aid"))
    else:
        logger.warn("e2ee", "handle_key_response store failed: group=%s epoch=%s aid=%s", group_id, epoch, aid)
    return stored


# ── GroupE2EEManager ─────────────────────────────────────────


class GroupE2EEManager:
    """群组端到端加密工具类 — 纯密码学 + 本地状态，零 I/O 依赖。

    与 E2EEManager 平行：所有网络操作（P2P 发送、RPC 调用）由调用方负责。
    内置防重放、epoch 降级防护、密钥请求频率限制。

    裸 WebSocket 开发者用法::

        group_e2ee = GroupE2EEManager(
            identity_fn=lambda: my_identity,
            keystore=FileKeyStore(),
        )
        info = group_e2ee.create_epoch("grp_abc", ["alice.aid", "bob.aid"])
        for dist in info["distributions"]:
            p2p_send(dist["to"], dist["payload"])
        envelope = group_e2ee.encrypt("grp_abc", {"text": "hello"})
        decrypted = group_e2ee.decrypt(raw_group_message)
        group_e2ee.handle_incoming(decrypted_p2p_payload)
    """

    def __init__(
        self, *, identity_fn: Any, keystore: Any,
        request_cooldown: float = 30.0, response_cooldown: float = 30.0,
        sender_cert_resolver: Any = None,
        initiator_cert_resolver: Any = None,
        logger: "AUNLogger | NullLogger | None" = None,
    ) -> None:
        from .logger import NullLogger as _NL
        self._log = logger or _NL()
        self._identity_fn = identity_fn
        self._keystore_ref = keystore
        self._replay_guard = GroupReplayGuard()
        self._request_throttle = GroupKeyRequestThrottle(cooldown=request_cooldown)
        self._response_throttle = GroupKeyRequestThrottle(cooldown=response_cooldown)
        self._sender_cert_resolver = sender_cert_resolver
        self._initiator_cert_resolver = initiator_cert_resolver
        self._pending_key_requests: dict[str, dict[str, Any]] = {}

    # ── 密钥管理 ──────────────────────────────────────────

    def _sign_manifest(self, manifest: dict[str, Any]) -> dict[str, Any]:
        """用当前身份私钥签名 manifest，无私钥时返回原始 manifest。"""
        identity = self._identity_fn()
        pk_pem = identity.get("private_key_pem")
        if not pk_pem:
            return manifest
        return sign_membership_manifest(manifest, pk_pem)

    def create_epoch(self, group_id: str, member_aids: list[str]) -> dict[str, Any]:
        """创建首个 epoch。返回 {epoch, commitment, distributions: [{to, payload}]}。"""
        aid = self._current_aid()
        self._log.debug("e2ee", "create_epoch start: group=%s aid=%s members=%d", group_id, aid, len(member_aids))
        gs = generate_group_secret()
        epoch = 1
        commitment = compute_membership_commitment(member_aids, epoch, group_id, gs)
        epoch_chain = compute_epoch_chain(None, epoch, commitment, aid)
        store_group_secret(self._keystore(), aid, group_id, epoch, gs, commitment, member_aids,
                           epoch_chain=epoch_chain)
        manifest = self._sign_manifest(build_membership_manifest(
            group_id, epoch, None, member_aids, initiator_aid=aid,
        ))
        dist_payload = build_key_distribution(group_id, epoch, gs, member_aids, aid,
                                              manifest=manifest, epoch_chain=epoch_chain)
        self._log.debug("e2ee", "create_epoch done: group=%s epoch=%d distribution_targets=%d",
                        group_id, epoch, len(member_aids) - 1)
        return {
            "epoch": epoch, "commitment": commitment,
            "distributions": [{"to": m, "payload": dist_payload} for m in member_aids if m != aid],
        }

    def rotate_epoch(self, group_id: str, member_aids: list[str]) -> dict[str, Any]:
        """轮换 epoch（踢人/退出后调用）。返回格式与 create_epoch 相同。"""
        aid = self._current_aid()
        ks = self._keystore()
        current = load_group_secret(ks, aid, group_id)
        prev_epoch = current["epoch"] if current else None
        prev_chain = current.get("epoch_chain") if current else None
        new_epoch = (prev_epoch or 0) + 1
        gs = generate_group_secret()
        commitment = compute_membership_commitment(member_aids, new_epoch, group_id, gs)
        epoch_chain = compute_epoch_chain(prev_chain, new_epoch, commitment, aid)
        stored = store_group_secret(ks, aid, group_id, new_epoch, gs, commitment, member_aids,
                                    epoch_chain=epoch_chain)
        if not stored:
            raise RuntimeError(f"group {group_id} epoch {new_epoch} secret already exists or is newer; abort distribution")
        manifest = self._sign_manifest(build_membership_manifest(
            group_id, new_epoch, prev_epoch, member_aids, initiator_aid=aid,
        ))
        dist_payload = build_key_distribution(group_id, new_epoch, gs, member_aids, aid,
                                              manifest=manifest, epoch_chain=epoch_chain)
        return {
            "epoch": new_epoch, "commitment": commitment,
            "distributions": [{"to": m, "payload": dist_payload} for m in member_aids if m != aid],
        }

    def rotate_epoch_to(
        self, group_id: str, target_epoch: int, member_aids: list[str], *,
        rotation_id: str = "", prev_chain_hint: str | None = None,
    ) -> dict[str, Any]:
        """指定目标 epoch 号轮换（配合服务端 CAS 使用）。"""
        aid = self._current_aid()
        self._log.debug("e2ee", "rotate_epoch_to start: group=%s target_epoch=%d members=%d rotation_id=%s",
                        group_id, target_epoch, len(member_aids), rotation_id or "-")
        ks = self._keystore()
        current = load_group_secret(ks, aid, group_id, target_epoch - 1) or load_group_secret(ks, aid, group_id)
        prev_chain = current.get("epoch_chain") if current else None
        if not prev_chain and prev_chain_hint:
            prev_chain = prev_chain_hint
        gs = generate_group_secret()
        commitment = compute_membership_commitment(member_aids, target_epoch, group_id, gs)
        epoch_chain = compute_epoch_chain(prev_chain, target_epoch, commitment, aid)
        stored = store_group_secret(ks, aid, group_id, target_epoch, gs, commitment, member_aids,
                                    epoch_chain=epoch_chain,
                                    pending_rotation_id=rotation_id,
                                    allow_pending_overwrite=bool(rotation_id))
        if not stored:
            self._log.warn("e2ee", "rotate_epoch_to store failed (epoch already exists or newer): group=%s target_epoch=%d",
                           group_id, target_epoch)
            raise RuntimeError(f"group {group_id} epoch {target_epoch} secret already exists or is newer; abort distribution")
        self._log.debug("e2ee", "rotate_epoch_to done: group=%s epoch=%d distribution_targets=%d",
                        group_id, target_epoch, len(member_aids) - 1)
        manifest = self._sign_manifest(build_membership_manifest(
            group_id, target_epoch, target_epoch - 1, member_aids, initiator_aid=aid,
        ))
        dist_payload = build_key_distribution(group_id, target_epoch, gs, member_aids, aid,
                                              manifest=manifest, epoch_chain=epoch_chain)
        if rotation_id:
            dist_payload["rotation_id"] = rotation_id
        return {
            "epoch": target_epoch, "commitment": commitment,
            "distributions": [{"to": m, "payload": dist_payload} for m in member_aids if m != aid],
        }

    def store_secret(
        self, group_id: str, epoch: int, group_secret_bytes: bytes,
        commitment: str, member_aids: list[str],
        epoch_chain: str | None = None,
        epoch_chain_unverified: bool | None = None,
        epoch_chain_unverified_reason: str | None = None,
    ) -> bool:
        """手动存储 group_secret。返回 False 表示 epoch 降级被拒。"""
        self._log.debug("e2ee", "store_secret: group=%s epoch=%d members=%d", group_id, epoch, len(member_aids))
        result = store_group_secret(
            self._keystore(), self._current_aid(), group_id, epoch,
            group_secret_bytes, commitment, member_aids,
            epoch_chain=epoch_chain,
            epoch_chain_unverified=epoch_chain_unverified,
            epoch_chain_unverified_reason=epoch_chain_unverified_reason,
        )
        if not result:
            self._log.warn("e2ee", "store_secret rejected (epoch downgrade): group=%s epoch=%d", group_id, epoch)
        return result

    def discard_pending_secret(self, group_id: str, epoch: int, rotation_id: str) -> bool:
        """仅回滚指定 pending rotation 的本地 target epoch key。"""
        return discard_pending_group_secret(
            self._keystore(), self._current_aid(), group_id, epoch, rotation_id,
        )

    def load_secret(self, group_id: str, epoch: int | None = None) -> dict[str, Any] | None:
        result = load_group_secret(self._keystore(), self._current_aid(), group_id, epoch)
        if result is None:
            self._log.debug("e2ee", "load_secret not found: group=%s epoch=%s", group_id, epoch)
        else:
            self._log.debug("e2ee", "load_secret success: group=%s epoch=%s", group_id, result.get("epoch"))
        return result

    def load_all_secrets(self, group_id: str) -> dict[int, bytes]:
        return load_all_group_secrets(self._keystore(), self._current_aid(), group_id)

    def cleanup(self, group_id: str, retention_seconds: int = OLD_EPOCH_RETENTION_SECONDS) -> int:
        return cleanup_old_epochs(self._keystore(), self._current_aid(), group_id, retention_seconds)

    # ── 加解密 ────────────────────────────────────────────

    def encrypt(
        self, group_id: str, payload: dict[str, Any], *,
        message_id: str | None = None, timestamp: int | None = None,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """加密群消息（含发送方签名）。无密钥时抛 E2EEGroupSecretMissingError。"""
        aid = self._current_aid()
        secret_data = load_group_secret(self._keystore(), aid, group_id)
        if secret_data is None:
            self._log.warn("e2ee", "group message encryption failed (no key): group=%s aid=%s", group_id, aid)
            raise E2EEGroupSecretMissingError(f"no group secret for {group_id}")
        self._log.debug("e2ee", "group message encryption: group=%s epoch=%d aid=%s", group_id, secret_data["epoch"], aid)
        return self._encrypt_with_secret_data(
            group_id, payload, secret_data,
            message_id=message_id, timestamp=timestamp,
            protected_headers=protected_headers, context=context,
        )

    def encrypt_with_epoch(
        self, group_id: str, epoch: int, payload: dict[str, Any], *,
        message_id: str | None = None, timestamp: int | None = None,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """使用指定 epoch 加密群消息。"""
        aid = self._current_aid()
        secret_data = load_group_secret(self._keystore(), aid, group_id, epoch)
        if secret_data is None:
            raise E2EEGroupSecretMissingError(f"no group secret for {group_id} epoch {epoch}")
        return self._encrypt_with_secret_data(
            group_id, payload, secret_data,
            message_id=message_id, timestamp=timestamp,
            protected_headers=protected_headers, context=context,
        )

    def _encrypt_with_secret_data(
        self, group_id: str, payload: dict[str, Any], secret_data: dict[str, Any], *,
        message_id: str | None = None, timestamp: int | None = None,
        protected_headers: dict[str, Any] | ProtectedHeaders | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        aid = self._current_aid()
        # 获取发送方私钥用于签名
        identity = self._identity_fn()
        sender_pk_pem = identity.get("private_key_pem") if identity else None
        sender_cert_pem = identity.get("cert") if identity else None
        return encrypt_group_message(
            group_id=group_id, epoch=secret_data["epoch"], group_secret=secret_data["secret"],
            payload=payload, from_aid=aid,
            message_id=message_id or f"gm-{uuid.uuid4()}",
            timestamp=timestamp or int(_time_mod.time() * 1000),
            sender_private_key_pem=sender_pk_pem,
            sender_cert_pem=sender_cert_pem,
            protected_headers=protected_headers,
            context=context,
            logger=self._log,
        )

    def decrypt(self, message: dict[str, Any], *, skip_replay: bool = False) -> dict[str, Any] | None:
        """解密单条群消息。内置防重放 + 发送方验签 + 外层字段校验。非加密消息原样返回。"""
        payload = message.get("payload")
        if not isinstance(payload, dict) or payload.get("type") != "e2ee.group_encrypted":
            return message
        group_id = message.get("group_id", "")
        sender = message.get("from", message.get("sender_aid", ""))

        # 防重放预检：优先使用 AAD 内 message_id（在 AEAD 保护范围内，不可被服务端篡改）
        aad = payload.get("aad")
        aad_msg_id = aad.get("message_id", "") if isinstance(aad, dict) else ""
        msg_id = aad_msg_id or message.get("message_id", "")
        if not skip_replay and group_id and sender and msg_id:
            if self._replay_guard.is_seen(group_id, sender, msg_id):
                self._log.debug("e2ee", "group message replay guard blocked: group=%s from=%s mid=%s", group_id, sender, msg_id)
                # 重放：返回原消息（不携带 e2ee 字段），与 decrypt_batch "or m" 语义一致。
                # 调用方可以通过缺失 e2ee 字段识别未解密。
                return message

        # 解析发送方证书（用于签名验证）— 零信任：无证书则拒绝
        sender_cert_pem = None
        if self._sender_cert_resolver and sender:
            raw = self._sender_cert_resolver(sender)
            if raw:
                sender_cert_pem = raw.encode("utf-8") if isinstance(raw, str) else raw
        if sender_cert_pem is None:
            self._log.warn("e2ee",
                "rejecting group message: cannot get sender %s cert (zero-trust mode forbids skipping signature verification): group=%s",
                sender, group_id,
            )
            return None

        all_secrets = load_all_group_secrets(self._keystore(), self._current_aid(), group_id)
        if not all_secrets:
            self._log.warn("e2ee", "group message decrypt failed (no local key): group=%s from=%s", group_id, sender)
            return None
        self._log.debug("e2ee", "group message decryption: group=%s from=%s epoch=%s local_epoch_count=%d",
                        group_id, sender, payload.get("epoch"), len(all_secrets))
        result = decrypt_group_message(message, all_secrets, sender_cert_pem=sender_cert_pem, logger=self._log)

        # 解密成功后，使用 AAD 内 message_id 记录防重放
        if result is not None and not skip_replay:
            # 从解密结果确认 AAD message_id
            final_msg_id = aad_msg_id or message.get("message_id", "")
            if group_id and sender and final_msg_id:
                self._replay_guard.record(group_id, sender, final_msg_id)
        if result is None:
            self._log.warn("e2ee", "group message decrypt failed: group=%s from=%s epoch=%s mid=%s",
                           group_id, sender, payload.get("epoch"), msg_id)
        return result

    def decrypt_batch(self, messages: list[dict[str, Any]], *, skip_replay: bool = False) -> list[dict[str, Any]]:
        return [self.decrypt(m, skip_replay=skip_replay) or m for m in messages]

    # ── 密钥协议消息处理 ──────────────────────────────────

    def handle_incoming(self, payload: dict[str, Any]) -> str | None:
        """处理已解密的 P2P 密钥消息。

        返回 "distribution"/"request"/"response" 表示已成功处理。
        返回 "distribution_rejected"/"response_rejected" 表示被拒绝（如 epoch 降级、manifest 验证失败）。
        返回 None 表示不是密钥消息。
        """
        if not isinstance(payload, dict):
            return None
        msg_type = payload.get("type", "")
        aid = self._current_aid()
        if msg_type == "e2ee.group_key_distribution":
            # 解析发起者证书用于 manifest 验证
            initiator_cert = None
            distributed_by = payload.get("distributed_by", "")
            if self._initiator_cert_resolver and distributed_by:
                raw = self._initiator_cert_resolver(distributed_by)
                _debug_group_e2ee(
                    "handle_incoming_distribution_resolver",
                    aid=aid,
                    group=str(payload.get("group_id") or "-"),
                    epoch=payload.get("epoch", "-"),
                    distributed_by=distributed_by or "-",
                    raw_type=type(raw).__name__ if raw is not None else "None",
                    raw_len=len(raw) if isinstance(raw, (bytes, str)) else "-",
                )
                if raw:
                    initiator_cert = raw.encode("utf-8") if isinstance(raw, str) else raw
            elif distributed_by:
                _debug_group_e2ee(
                    "handle_incoming_distribution_no_resolver",
                    aid=aid,
                    group=str(payload.get("group_id") or "-"),
                    epoch=payload.get("epoch", "-"),
                    distributed_by=distributed_by or "-",
                )
            _debug_group_e2ee(
                "handle_incoming_distribution",
                aid=aid,
                group=str(payload.get("group_id") or "-"),
                epoch=payload.get("epoch", "-"),
                distributed_by=distributed_by or "-",
                has_cert=bool(initiator_cert),
                rotation=str(payload.get("rotation_id") or "-"),
            )
            ok = handle_key_distribution(payload, self._keystore(), aid, initiator_cert_pem=initiator_cert, logger=self._log)
            _debug_group_e2ee(
                "handle_incoming_distribution_result",
                aid=aid,
                group=str(payload.get("group_id") or "-"),
                epoch=payload.get("epoch", "-"),
                ok=ok,
            )
            return "distribution" if ok else "distribution_rejected"
        if msg_type == "e2ee.group_key_response":
            pending_key = f"{payload.get('group_id', '')}:{payload.get('epoch', '')}:{payload.get('request_id', '')}"
            expected = self._pending_key_requests.get(pending_key)
            if expected is None:
                self._log.warn("e2ee", 
                    "拒绝 group key response：找不到匹配的 pending request aid=%s pending_key=%s pending_count=%s",
                    aid, pending_key, len(self._pending_key_requests),
                )
                return "response_rejected"
            responder = str(payload.get("responder_aid") or "")
            responder_cert = None
            if self._initiator_cert_resolver and responder:
                raw = self._initiator_cert_resolver(responder)
                _debug_group_e2ee(
                    "handle_incoming_response_resolver",
                    aid=aid,
                    group=str(payload.get("group_id") or "-"),
                    epoch=payload.get("epoch", "-"),
                    responder=responder or "-",
                    raw_type=type(raw).__name__ if raw is not None else "None",
                    raw_len=len(raw) if isinstance(raw, (bytes, str)) else "-",
                )
                if raw:
                    responder_cert = raw.encode("utf-8") if isinstance(raw, str) else raw
            elif responder:
                _debug_group_e2ee(
                    "handle_incoming_response_no_resolver",
                    aid=aid,
                    group=str(payload.get("group_id") or "-"),
                    epoch=payload.get("epoch", "-"),
                    responder=responder or "-",
                )
            _debug_group_e2ee(
                "handle_incoming_response",
                aid=aid,
                group=str(payload.get("group_id") or "-"),
                epoch=payload.get("epoch", "-"),
                responder=responder or "-",
                request_id=str(payload.get("request_id") or "-"),
                pending_count=len(self._pending_key_requests),
                has_expected=expected is not None,
                expected_responder=str(expected.get("_expected_responder_aid") or "-") if isinstance(expected, dict) else "-",
                has_resolver=bool(self._initiator_cert_resolver),
                has_cert=bool(responder_cert),
                has_sig=bool(payload.get("response_signature")),
            )
            ok = handle_key_response(
                payload, self._keystore(), aid,
                expected_request=expected,
                responder_cert_pem=responder_cert,
                current_members=self.get_member_aids(str(payload.get("group_id") or "")),
                strict=True,
                logger=self._log,
            )
            if ok and expected is not None:
                self._pending_key_requests.pop(pending_key, None)
            _debug_group_e2ee(
                "handle_incoming_response_result",
                aid=aid,
                group=str(payload.get("group_id") or "-"),
                epoch=payload.get("epoch", "-"),
                responder=responder or "-",
                ok=ok,
            )
            return "response" if ok else "response_rejected"
        if msg_type == "e2ee.group_key_request":
            return "request"
        return None

    def build_recovery_request(
        self, group_id: str, epoch: int, *, sender_aid: str | None = None,
    ) -> dict[str, Any] | None:
        """构建恢复请求。返回 {to, payload, fallback_targets} 或 None。

        优先向消息发送方请求（最可能拥有该 epoch），
        其次从本地成员列表中选取候选人。
        fallback_targets 提供额外候选人供调用方逐个尝试。
        """
        aid = self._current_aid()
        if not self._request_throttle.allow(f"request:{group_id}:{epoch}"):
            return None
        candidates: list[str] = []
        # 优先使用消息发送方（最可能有该 epoch 密钥）
        if sender_aid and sender_aid != aid:
            candidates.append(sender_aid)
        # 补充本地成员列表中的其他候选人
        secret_data = load_group_secret(self._keystore(), aid, group_id)
        if secret_data and secret_data.get("member_aids"):
            for m in secret_data["member_aids"]:
                if m != aid and m not in candidates:
                    candidates.append(m)
        if not candidates:
            return None
        payload = build_key_request(group_id, epoch, aid)
        self.remember_key_request(payload, expected_responder_aid=candidates[0])
        return {
            "to": candidates[0],
            "payload": payload,
            "fallback_targets": candidates[1:],
        }

    def remember_key_request(self, payload: dict[str, Any], expected_responder_aid: str | None = None) -> None:
        if payload.get("type") != "e2ee.group_key_request":
            return
        request_id = str(payload.get("request_id") or "")
        if not request_id:
            return
        key = f"{payload.get('group_id', '')}:{payload.get('epoch', '')}:{request_id}"
        pending = dict(payload)
        if expected_responder_aid:
            pending["_expected_responder_aid"] = expected_responder_aid
        self._pending_key_requests[key] = pending

    def handle_key_request_msg(
        self, request_payload: dict[str, Any], current_members: list[str],
    ) -> dict[str, Any] | None:
        """处理密钥请求。返回响应 payload（受频率限制 + 成员资格验证）。"""
        requester = request_payload.get("requester_aid", "")
        group_id = request_payload.get("group_id", "")
        if not requester or not group_id:
            return None
        # 成员资格验证：仅响应当前群成员的请求
        if requester not in current_members:
            self._log.warn("e2ee", 
                "拒绝密钥恢复请求：%s 不在群 %s 的当前成员列表中", requester, group_id,
            )
            return None
        if not self._response_throttle.allow(f"response:{group_id}:{requester}"):
            return None
        identity = self._identity_fn() or {}
        private_key_pem = identity.get("private_key_pem")
        if not private_key_pem:
            self._log.warn("e2ee", "rejecting key recovery response: local identity private key unavailable group=%s requester=%s", group_id, requester)
            return None
        return handle_key_request(
            request_payload, self._keystore(), self._current_aid(), current_members,
            private_key_pem=private_key_pem,
            logger=self._log,
        )

    # ── 状态查询 ──────────────────────────────────────────

    def has_secret(self, group_id: str) -> bool:
        return load_group_secret(self._keystore(), self._current_aid(), group_id) is not None

    def current_epoch(self, group_id: str) -> int | None:
        s = load_group_secret(self._keystore(), self._current_aid(), group_id)
        return s["epoch"] if s else None

    def get_member_aids(self, group_id: str) -> list[str]:
        s = load_group_secret(self._keystore(), self._current_aid(), group_id)
        return s.get("member_aids", []) if s else []

    def _current_aid(self) -> str:
        identity = self._identity_fn()
        aid = identity.get("aid")
        if not aid:
            raise E2EEError("AID unavailable")
        return str(aid)

    def _keystore(self) -> Any:
        return self._keystore_ref

    def clean_expired_caches(self) -> None:
        """清理过期缓存（replay guard 等），供外部定时调用"""
        self._replay_guard._trim()
