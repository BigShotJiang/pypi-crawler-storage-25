"""Preflight checks for services targeted by csrd-utils feature augmentation."""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DoctorReport:
    """Structured doctor output."""

    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def run_doctor(service_root: Path) -> DoctorReport:
    """Validate that a service is compatible with feature augmentation."""
    root = service_root.resolve()
    errors: list[str] = []
    warnings: list[str] = []

    required_dirs = ["src/app", "tests"]
    required_files = ["requirements.txt"]

    compose_candidates = [root / "docker-compose.yml"]
    if root.parent.name == "src" and (root.parent.parent / ".csrd-workspace").is_file():
        compose_candidates.append(root.parent.parent / "docker-compose.yml")

    for rel in required_dirs:
        if not (root / rel).is_dir():
            errors.append(f"Missing required directory: {rel}")

    for rel in required_files:
        if not (root / rel).is_file():
            errors.append(f"Missing required file: {rel}")

    if not any(path.is_file() for path in compose_candidates):
        errors.append("Missing required file: docker-compose.yml")

    marker_files = {
        "src/app/settings.py": "# [INSERT: fields]",
        "tests/conftest.py": "# [INSERT: fixtures]",
    }
    for rel, marker in marker_files.items():
        path = root / rel
        if path.exists():
            text = path.read_text(encoding="utf-8")
            if marker not in text:
                warnings.append(f"Optional insertion marker missing in {rel}: {marker}")

    return DoctorReport(ok=not errors, errors=errors, warnings=warnings)
