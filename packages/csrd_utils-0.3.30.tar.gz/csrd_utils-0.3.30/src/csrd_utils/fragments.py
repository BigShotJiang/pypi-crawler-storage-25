"""Fragment merger logic for combining feature files with existing service code."""

import re
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]


class FragmentMergeError(Exception):
    """Raised when fragment merge fails."""

    pass


class RequirementsMerger:
    """Merge requirements.txt fragments."""

    @staticmethod
    def merge(base_content: str, fragment_content: str) -> str:
        """
        Merge fragment requirements into base requirements.

        Deduplicates entries while preserving order (base first, then new).

        Parameters
        ----------
        base_content : str
            Existing requirements.txt content
        fragment_content : str
            Fragment requirements to add

        Returns
        -------
        str
            Merged requirements.txt content
        """
        base_lines = base_content.strip().split("\n")
        fragment_lines = fragment_content.strip().split("\n")

        # Normalize lines (strip comments, blank lines)
        seen = set()
        result = []

        for line in base_lines + fragment_lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Extract package name (before [, <, >, =, etc.)
            pkg_name = re.split(r"[\[\<\>=!~]", line)[0].strip().lower()
            if pkg_name not in seen:
                seen.add(pkg_name)
                result.append(line)

        return "\n".join(result) + "\n"


class DockerComposeMerger:
    """Deep merge docker-compose.yml fragments."""

    @staticmethod
    def merge(base: dict[str, Any], fragment: dict[str, Any]) -> dict[str, Any]:
        """
        Deep merge fragment docker-compose into base.

        For services: merges service defs (environment vars, ports, depends_on).
        For top-level: merges volumes, networks, etc.

        Parameters
        ----------
        base : dict
            Existing docker-compose content
        fragment : dict
            Fragment to merge

        Returns
        -------
        dict
            Merged docker-compose content
        """
        result = base.copy()

        for key, fragment_value in fragment.items():
            if key not in result:
                result[key] = fragment_value
            elif key == "services":
                # Merge service definitions
                result["services"] = {**result.get("services", {}), **fragment_value}
                # For each service, deep merge its config
                for svc_name, svc_config in fragment_value.items():
                    if svc_name in result["services"]:
                        result["services"][svc_name] = {
                            **result["services"][svc_name],
                            **svc_config,
                        }
            elif isinstance(fragment_value, dict) and isinstance(result[key], dict):
                result[key] = {**result[key], **fragment_value}
            elif isinstance(fragment_value, list) and isinstance(result[key], list):
                # For lists (e.g., volumes, ports), append without duplicates
                result[key] = result[key] + [
                    item for item in fragment_value if item not in result[key]
                ]
            else:
                result[key] = fragment_value

        return result


class PythonFileMerger:
    """Merge Python file fragments at marked sections."""

    MARKER_PATTERN = r"# \[FEATURE:\s*(\w+)\].*"
    INSERT_PATTERN = r"# \[INSERT:\s*(\w+)\].*"

    @staticmethod
    def find_insertion_point(content: str, marker: str) -> int | None:
        """
        Find line number where fragment should be inserted.

        Looks for `# [INSERT: <marker>]` comment.

        Parameters
        ----------
        content : str
            File content
        marker : str
            Marker to search for (e.g., "imports", "settings")

        Returns
        -------
        int | None
            Line index to insert at, or None if not found
        """
        for i, line in enumerate(content.split("\n")):
            if re.search(rf"# \[INSERT:\s*{marker}\]", line):
                return i
        return None

    @staticmethod
    def merge_at_marker(base_content: str, fragment_content: str, marker: str) -> str:
        """
        Insert fragment at marked position in base file.

        Parameters
        ----------
        base_content : str
            Base file content
        fragment_content : str
            Fragment to insert
        marker : str
            Marker name (e.g., "imports", "settings")

        Returns
        -------
        str
            Merged content

        Raises
        ------
        FragmentMergeError
            If marker not found
        """
        lines = base_content.split("\n")
        insert_idx = PythonFileMerger.find_insertion_point(base_content, marker)

        if insert_idx is None:
            raise FragmentMergeError(f"No [INSERT: {marker}] marker found in base file")

        # Insert fragment after the marker line
        fragment_lines = fragment_content.strip().split("\n")
        if fragment_lines and re.match(r"^# \[INSERT:\s*\w+\]", fragment_lines[0]):
            fragment_lines = fragment_lines[1:]
        for line in reversed(fragment_lines):
            lines.insert(insert_idx + 1, line)

        return "\n".join(lines)


class SettingsMerger:
    """Merge pydantic settings fragments."""

    @staticmethod
    def merge(base_content: str, fragment_content: str) -> str:
        """
        Merge settings fields into BaseSettings class.

        Fragment should contain field definitions. Merges into base at
        [INSERT: fields] marker.

        Parameters
        ----------
        base_content : str
            Base settings.py content
        fragment_content : str
            Fragment settings to add

        Returns
        -------
        str
            Merged settings content
        """
        return PythonFileMerger.merge_at_marker(base_content, fragment_content, "fields")


class ConfTestMerger:
    """Merge pytest conftest.py fixtures."""

    @staticmethod
    def merge(base_content: str, fragment_content: str) -> str:
        """
        Merge fixtures into conftest.py.

        Fragments should contain fixture function defs. Merges at
        [INSERT: fixtures] marker.

        Parameters
        ----------
        base_content : str
            Base conftest.py
        fragment_content : str
            Fragment fixtures to add

        Returns
        -------
        str
            Merged conftest.py
        """
        return PythonFileMerger.merge_at_marker(base_content, fragment_content, "fixtures")


class EnvironmentMerger:
    """Merge .env.example environment variables."""

    @staticmethod
    def merge(base_content: str, fragment_content: str) -> str:
        """
        Merge fragment env vars into .env.example.

        Deduplicates by VAR_NAME, preserving order (base first).

        Parameters
        ----------
        base_content : str
            Base .env.example
        fragment_content : str
            Fragment to add

        Returns
        -------
        str
            Merged .env.example
        """
        base_lines = base_content.strip().split("\n")
        fragment_lines = fragment_content.strip().split("\n")

        seen_keys = set()
        result = []

        for line in base_lines + fragment_lines:
            line = line.rstrip()
            if not line or line.startswith("#"):
                result.append(line)
                continue

            # Extract VAR_NAME (before =)
            var_name = line.split("=")[0].strip()
            if var_name not in seen_keys:
                seen_keys.add(var_name)
                result.append(line)

        return "\n".join(result) + "\n"


class ManifestLoader:
    """Load and validate feature manifests."""

    @staticmethod
    def load(manifest_path: Path) -> dict[str, Any]:
        """
        Load YAML manifest.

        Parameters
        ----------
        manifest_path : Path
            Path to manifest.yaml

        Returns
        -------
        dict
            Manifest data

        Raises
        ------
        FileNotFoundError
            If manifest doesn't exist
        """
        if not manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found: {manifest_path}")

        with open(manifest_path) as f:
            return yaml.safe_load(f) or {}

    @staticmethod
    def validate(manifest: dict[str, Any]) -> list[str]:
        """
        Validate manifest structure.

        Parameters
        ----------
        manifest : dict
            Loaded manifest

        Returns
        -------
        list[str]
            List of validation errors (empty if valid)
        """
        errors = []

        if "name" not in manifest:
            errors.append("Missing 'name' field")

        if "modifies" in manifest and not isinstance(manifest["modifies"], list):
            errors.append("'modifies' must be a list of file paths")

        if "creates" in manifest and not isinstance(manifest["creates"], list):
            errors.append("'creates' must be a list of file paths")

        if "requires" in manifest and not isinstance(manifest["requires"], dict):
            errors.append("'requires' must be a dict of requirements")

        return errors
