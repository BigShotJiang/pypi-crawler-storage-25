# [INSERT: fixtures]
@pytest.fixture  # noqa: F821
def cache_client(monkeypatch):
    """Fake cache client that uses an in-memory dict."""
    store: dict = {}

    class FakeRedis:
        def get(self, key):
            return store.get(key)

        def set(self, key, value, ex=None):
            store[key] = value

        def delete(self, key):
            store.pop(key, None)

        def ping(self):
            return True

    client = FakeRedis()
    monkeypatch.setattr("src.app.cache.get_cache_client", lambda: client)
    return client
