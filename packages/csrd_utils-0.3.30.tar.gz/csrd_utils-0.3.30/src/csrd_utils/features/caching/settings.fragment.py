# [INSERT: fields]
cache_host: str = "localhost"
cache_port: int = 6379
cache_ttl: int = 300  # seconds
