"""Tests for Redis caching layer."""


from unittest.mock import MagicMock, patch


def test_cache_get_returns_none_when_missing() -> None:
    fake = MagicMock()
    fake.get.return_value = None
    with patch("src.app.cache.get_cache_client", return_value=fake):
        from src.app.cache import cache_get

        assert cache_get("missing-key") is None


def test_cache_set_and_get_roundtrip() -> None:
    store: dict = {}
    fake = MagicMock()
    fake.get.side_effect = lambda k: store.get(k)
    fake.set.side_effect = lambda k, v, ex=None: store.update({k: v})

    with patch("src.app.cache.get_cache_client", return_value=fake):
        from src.app.cache import cache_get, cache_set

        cache_set("hello", "world")
        assert cache_get("hello") == "world"


def test_cache_delete_removes_key() -> None:
    store: dict = {"gone": "value"}
    fake = MagicMock()
    fake.delete.side_effect = lambda k: store.pop(k, None)
    fake.get.side_effect = lambda k: store.get(k)

    with patch("src.app.cache.get_cache_client", return_value=fake):
        from src.app.cache import cache_delete, cache_get

        cache_delete("gone")
        assert cache_get("gone") is None
