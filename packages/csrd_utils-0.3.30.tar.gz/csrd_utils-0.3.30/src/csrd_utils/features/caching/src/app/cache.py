"""Redis cache client."""


import redis

from .settings import settings

_client: redis.Redis | None = None


def get_cache_client() -> redis.Redis:
    """Return a shared Redis client, creating it on first call."""
    global _client
    if _client is None:
        _client = redis.Redis(
            host=settings.cache_host,
            port=settings.cache_port,
            decode_responses=True,
        )
    return _client


def cache_get(key: str) -> str | None:
    """Get a value from cache. Returns None if key missing."""
    return get_cache_client().get(key)


def cache_set(key: str, value: str, ttl: int | None = None) -> None:
    """Set a value in cache with optional TTL (seconds)."""
    ttl = ttl if ttl is not None else settings.cache_ttl
    get_cache_client().set(key, value, ex=ttl)


def cache_delete(key: str) -> None:
    """Delete a key from cache."""
    get_cache_client().delete(key)
