# [INSERT: fixtures]
@pytest.fixture  # noqa: F821
def metrics_registry():
    """Return the default Prometheus CollectorRegistry for test assertions."""
    from prometheus_client import REGISTRY

    return REGISTRY
