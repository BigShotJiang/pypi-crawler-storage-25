# [INSERT: fields]
metrics_enabled: bool = True
metrics_path: str = "/metrics"
