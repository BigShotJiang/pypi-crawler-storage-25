"""Tests for Prometheus metrics middleware."""


import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from src.app.middleware.metrics import MetricsMiddleware, metrics_response


@pytest.fixture
def app_with_metrics() -> FastAPI:
    app = FastAPI()
    app.add_middleware(MetricsMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ping": "pong"}

    @app.get("/metrics", include_in_schema=False)
    def metrics():
        return metrics_response()

    return app


@pytest.mark.anyio
async def test_metrics_endpoint_returns_200(app_with_metrics: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_metrics), base_url="http://test"
    ) as client:
        response = await client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]


@pytest.mark.anyio
async def test_metrics_endpoint_contains_prometheus_exposition(
    app_with_metrics: FastAPI,
) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_metrics), base_url="http://test"
    ) as client:
        response = await client.get("/metrics")
    # Prometheus text format always starts with comment lines (# HELP / # TYPE)
    assert response.text.startswith("#")


@pytest.mark.anyio
async def test_metrics_middleware_records_request_count(app_with_metrics: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_metrics), base_url="http://test"
    ) as client:
        await client.get("/ping")
        scrape = await client.get("/metrics")
    assert "http_requests_total" in scrape.text


@pytest.mark.anyio
async def test_metrics_middleware_records_request_duration(app_with_metrics: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_metrics), base_url="http://test"
    ) as client:
        await client.get("/ping")
        scrape = await client.get("/metrics")
    assert "http_request_duration_seconds" in scrape.text


@pytest.mark.anyio
async def test_metrics_endpoint_itself_not_instrumented(app_with_metrics: FastAPI) -> None:
    """The /metrics scrape path should not appear in its own counter labels."""
    async with AsyncClient(
        transport=ASGITransport(app=app_with_metrics), base_url="http://test"
    ) as client:
        # Hit /metrics several times; it should not appear as a labelled path
        for _ in range(3):
            await client.get("/metrics")
        scrape = await client.get("/metrics")
    # /ping requests may appear but /metrics should not be a recorded path
    assert 'path="/metrics"' not in scrape.text
