"""Prometheus metrics middleware and scrape endpoint."""

import time

from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Histogram,
    generate_latest,
)
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from ..settings import settings

# Module-level metric singletons — registered once per process on first import.
REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total HTTP request count",
    ["method", "path", "status_code"],
)

REQUEST_DURATION = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "path"],
)


class MetricsMiddleware(BaseHTTPMiddleware):
    """Record Prometheus metrics for every HTTP request.

    The scrape endpoint itself (``settings.metrics_path``) is excluded from
    instrumentation to avoid self-referential cardinality.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        # Skip instrumentation on the metrics scrape path.
        if not settings.metrics_enabled or request.url.path == settings.metrics_path:
            return await call_next(request)

        start = time.perf_counter()
        response = await call_next(request)
        duration = time.perf_counter() - start

        REQUEST_COUNT.labels(
            method=request.method,
            path=request.url.path,
            status_code=str(response.status_code),
        ).inc()
        REQUEST_DURATION.labels(
            method=request.method,
            path=request.url.path,
        ).observe(duration)

        return response


def metrics_response() -> Response:
    """Return a Prometheus text-format scrape response.

    Mount this on the path defined by ``settings.metrics_path``::

        @app.get(settings.metrics_path, include_in_schema=False)
        def metrics():
            return metrics_response()
    """
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST,
    )
