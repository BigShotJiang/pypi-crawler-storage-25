"""Tests for structured logging middleware."""


import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from src.app.middleware.logging import RequestLoggingMiddleware


@pytest.fixture
def app_with_logging() -> FastAPI:
    app = FastAPI()
    app.add_middleware(RequestLoggingMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ping": "pong"}

    return app


@pytest.mark.anyio
async def test_request_logging_middleware_adds_request_id(app_with_logging: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_logging), base_url="http://test"
    ) as client:
        response = await client.get("/ping")
    assert response.status_code == 200
    assert "x-request-id" in response.headers


@pytest.mark.anyio
async def test_request_logging_middleware_passes_response_unchanged(
    app_with_logging: FastAPI,
) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_logging), base_url="http://test"
    ) as client:
        response = await client.get("/ping")
    assert response.json() == {"ping": "pong"}
