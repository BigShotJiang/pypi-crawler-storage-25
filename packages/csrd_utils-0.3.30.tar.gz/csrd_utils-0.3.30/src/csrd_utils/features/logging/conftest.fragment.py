# [INSERT: fixtures]
@pytest.fixture(autouse=True)  # noqa: F821
def configure_structlog():
    """Configure structlog for plain test output."""
    import structlog

    structlog.configure(
        processors=[structlog.dev.ConsoleRenderer()],
        wrapper_class=structlog.make_filtering_bound_logger(20),
    )
