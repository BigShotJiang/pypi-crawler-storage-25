# [INSERT: fields]
log_level: str = "INFO"
log_json: bool = True
