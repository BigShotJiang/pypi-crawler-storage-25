# [INSERT: fields]
otel_service_name: str = "my-service"
otel_exporter_otlp_endpoint: str = "http://localhost:4318"
otel_enabled: bool = False
