# [INSERT: fixtures]
@pytest.fixture(autouse=True)  # noqa: F821
def restore_otel_provider():
    """Save and restore the OTel tracer provider around each test."""
    from opentelemetry import trace

    original = trace.get_tracer_provider()
    yield
    trace.set_tracer_provider(original)
