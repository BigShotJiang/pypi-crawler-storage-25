"""Tests for OpenTelemetry tracing middleware."""


import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from src.app.middleware.tracing import TracingMiddleware


@pytest.fixture
def app_with_tracing() -> FastAPI:
    app = FastAPI()
    app.add_middleware(TracingMiddleware)

    @app.get("/ping")
    async def ping():
        return {"ping": "pong"}

    return app


@pytest.mark.anyio
async def test_tracing_middleware_adds_trace_id(app_with_tracing: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_tracing), base_url="http://test"
    ) as client:
        response = await client.get("/ping")
    assert response.status_code == 200
    assert "x-trace-id" in response.headers
    assert len(response.headers["x-trace-id"]) == 32  # 128-bit hex


@pytest.mark.anyio
async def test_tracing_middleware_passes_response_unchanged(
    app_with_tracing: FastAPI,
) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_tracing), base_url="http://test"
    ) as client:
        response = await client.get("/ping")
    assert response.json() == {"ping": "pong"}


@pytest.mark.anyio
async def test_tracing_middleware_trace_id_is_unique(app_with_tracing: FastAPI) -> None:
    async with AsyncClient(
        transport=ASGITransport(app=app_with_tracing), base_url="http://test"
    ) as client:
        r1 = await client.get("/ping")
        r2 = await client.get("/ping")
    assert r1.headers["x-trace-id"] != r2.headers["x-trace-id"]
