"""OpenTelemetry distributed tracing middleware."""

import uuid

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from ..settings import settings

_tracer_provider = None


def configure_tracing() -> None:
    """Configure OpenTelemetry tracing for the application.

    Call this once at application startup (e.g. in the lifespan handler).
    Has no effect when ``settings.otel_enabled`` is ``False``.
    """
    global _tracer_provider

    if not settings.otel_enabled:
        return

    resource = Resource.create({"service.name": settings.otel_service_name})
    provider = TracerProvider(resource=resource)
    exporter = OTLPSpanExporter(endpoint=settings.otel_exporter_otlp_endpoint)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    _tracer_provider = provider


class TracingMiddleware(BaseHTTPMiddleware):
    """Attach a trace ID to every request and propagate spans when tracing is enabled.

    Adds an ``X-Trace-ID`` response header.  When a real OTel tracer provider is
    configured (via :func:`configure_tracing`) the ID is the 128-bit hex trace ID
    from the active span; otherwise a random UUID is used so that response header
    is always populated.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        tracer = trace.get_tracer(__name__)
        span_name = f"{request.method} {request.url.path}"

        with tracer.start_as_current_span(span_name) as span:
            ctx = span.get_span_context()
            # Use the OTel trace ID when the span context is valid (real provider),
            # otherwise fall back to a random identifier so the header is always set.
            trace_id = format(ctx.trace_id, "032x") if ctx.is_valid else uuid.uuid4().hex

            request.state.trace_id = trace_id
            response = await call_next(request)
            span.set_attribute("http.status_code", response.status_code)
            response.headers["X-Trace-ID"] = trace_id
            return response
