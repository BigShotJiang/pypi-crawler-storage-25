"""Tests for async workers."""


import pytest
from src.app.workers import example_task


@pytest.mark.asyncio
async def test_example_task() -> None:
    """Test example task execution."""
    task = example_task.apply_async(args=[1, 2])
    result = task.get(timeout=10)
    assert result == 3


def test_example_task_sync() -> None:
    """Test example task in eager mode."""
    result = example_task.apply(args=[5, 3]).get(timeout=10)
    assert result == 8
