# [INSERT: fixtures]
@pytest.fixture  # noqa: F821
def celery_config():
    """Celery config for tests."""
    return {
        "broker_url": "memory://",
        "result_backend": "cache+memory://",
    }


@pytest.fixture  # noqa: F821
def celery_enable_logging():
    """Enable celery logging in tests."""
    return True
