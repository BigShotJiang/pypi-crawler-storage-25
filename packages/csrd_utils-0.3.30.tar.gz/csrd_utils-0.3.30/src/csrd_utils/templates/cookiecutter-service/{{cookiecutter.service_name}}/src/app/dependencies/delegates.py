{%- if cookiecutter.has_delegates %}
from collections.abc import AsyncIterator


async def upstream_delegate_factory() -> AsyncIterator[list[str]]:
    upstreams = [entry.strip() for entry in "{{ cookiecutter.upstreams }}".split(",") if entry.strip()]
    yield upstreams


__all__ = ("upstream_delegate_factory",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
