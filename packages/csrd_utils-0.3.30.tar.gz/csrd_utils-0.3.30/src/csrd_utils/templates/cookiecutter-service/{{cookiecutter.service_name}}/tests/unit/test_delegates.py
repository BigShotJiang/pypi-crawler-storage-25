"""Unit tests for delegate dependency wiring."""

import asyncio

from app.dependencies.delegates import upstream_delegate_factory
from app.delegates.upstreams import configured_upstreams


async def _collect_upstreams() -> list[str]:
    async for upstreams in upstream_delegate_factory():
        return upstreams
    return []


def test_upstream_delegate_factory_returns_urls() -> None:
    upstreams = asyncio.run(_collect_upstreams())
    assert upstreams
    assert all(url.startswith("http") for url in upstreams)


def test_configured_upstreams_strips_and_filters() -> None:
    upstreams = configured_upstreams()
    assert upstreams
    assert all(entry == entry.strip() for entry in upstreams)
    assert all(entry for entry in upstreams)

