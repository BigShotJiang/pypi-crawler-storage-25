{%- if cookiecutter.has_delegates %}
from .upstreams import configured_upstreams

__all__ = ("configured_upstreams",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
