{%- if cookiecutter.has_database %}
import uuid
from datetime import UTC, datetime

from csrd.repository import BaseRepository, DBProtocol


class {{ cookiecutter.model_name }}Repository(BaseRepository):
    def __init__(self, adapter: DBProtocol) -> None:
        super().__init__(adapter)

    async def _init_schema(self) -> None:
        {%- if cookiecutter.database == "maria" %}
        query = """
        CREATE TABLE IF NOT EXISTS {{ cookiecutter.model_name_plural | lower | replace(' ', '_') }} (
            id VARCHAR(36) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            created_at VARCHAR(64) NOT NULL
        )
        """
        {%- else %}
        query = """
        CREATE TABLE IF NOT EXISTS {{ cookiecutter.model_name_plural | lower | replace(' ', '_') }} (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
        {%- endif %}
        await self.execute(query)

    async def create(self, name: str) -> dict[str, str]:
        record_id = str(uuid.uuid4())
        created_at = datetime.now(UTC).isoformat()
        await self._init_schema()
        result = await self.insert(
            "{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
            {"id": record_id, "name": name, "created_at": created_at},
        )
        return {
            "id": str(result.get("id", record_id)),
            "name": name,
            "created_at": created_at,
        }

    async def list(self) -> list[dict[str, str]]:
        await self._init_schema()
        rows = await self.fetch_all(
            "SELECT id, name, created_at FROM {{ cookiecutter.model_name_plural | lower | replace(' ', '_') }} ORDER BY created_at DESC"
        )
        return [
            {
                "id": str(row.get("id", "")),
                "name": str(row.get("name", "")),
                "created_at": str(row.get("created_at", "")),
            }
            for row in rows
        ]

    async def get(self, record_id: str) -> dict[str, str] | None:
        await self._init_schema()
        {%- if cookiecutter.database == "sqlite" %}
        query = "SELECT id, name, created_at FROM {{ cookiecutter.model_name_plural | lower | replace(' ', '_') }} WHERE id = :id"
        {%- else %}
        query = "SELECT id, name, created_at FROM {{ cookiecutter.model_name_plural | lower | replace(' ', '_') }} WHERE id = %(id)s"
        {%- endif %}
        row = await self.fetch_one(query, {"id": record_id})
        if row is None:
            return None
        return {
            "id": str(row.get("id", "")),
            "name": str(row.get("name", "")),
            "created_at": str(row.get("created_at", "")),
        }

    async def update(self, record_id: str, name: str) -> int:
        await self._init_schema()
        return await super().update(
            "{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", {"name": name}, {"id": record_id}
        )

    async def delete(self, record_id: str) -> int:
        await self._init_schema()
        return await super().delete("{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", {"id": record_id})

    async def upsert(self, record_id: str, name: str) -> int:
        await self._init_schema()
        created_at = datetime.now(UTC).isoformat()
        return await super().upsert(
            "{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}",
            {"name": name, "created_at": created_at},
            {"id": record_id},
        )
{%- endif %}
