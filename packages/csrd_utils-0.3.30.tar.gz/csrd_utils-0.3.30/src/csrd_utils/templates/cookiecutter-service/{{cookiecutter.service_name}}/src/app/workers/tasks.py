{%- if cookiecutter.has_workers %}
from celery import Celery

from ..settings import settings

celery_app = Celery("{{ cookiecutter._service_name_snake }}", broker=settings.worker_broker_url)


@celery_app.task(name="{{ cookiecutter._service_name_snake }}.ping")
def ping_task() -> str:
    return "pong"


__all__ = ("celery_app", "ping_task")
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
