from fastapi import APIRouter

router = APIRouter(tags=["Health Endpoints"])


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "{{ cookiecutter.service_name }}"}
