{%- if cookiecutter.has_delegates %}

def configured_upstreams() -> list[str]:
    return [entry.strip() for entry in "{{ cookiecutter.upstreams }}".split(",") if entry.strip()]


__all__ = ("configured_upstreams",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
