{%- if cookiecutter.has_structured_logging %}
import time
from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class RequestLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[..., Response]) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start) * 1000
        response.headers["X-Request-Duration-Ms"] = f"{duration_ms:.2f}"
        return response


__all__ = ("RequestLogMiddleware",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
