{%- if cookiecutter.has_workers %}
from .tasks import ping_task

__all__ = ("ping_task",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
