"""Acceptance tests for structured logging middleware behavior."""


def test_health_includes_request_duration_header(client) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert "X-Request-Duration-Ms" in response.headers
