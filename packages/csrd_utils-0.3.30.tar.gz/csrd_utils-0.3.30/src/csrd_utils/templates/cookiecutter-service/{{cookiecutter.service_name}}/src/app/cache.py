{%- if cookiecutter.has_caching %}
from redis import Redis

from .settings import settings


def build_cache_client() -> Redis:
    return Redis.from_url(settings.cache_url, decode_responses=True)


__all__ = ("build_cache_client",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
