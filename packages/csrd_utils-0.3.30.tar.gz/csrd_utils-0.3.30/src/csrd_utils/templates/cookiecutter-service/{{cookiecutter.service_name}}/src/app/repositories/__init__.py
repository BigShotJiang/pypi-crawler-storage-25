{%- if cookiecutter.has_database %}
from .item_repository import {{ cookiecutter.model_name }}Repository

__all__ = ("{{ cookiecutter.model_name }}Repository",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
