{%- if cookiecutter.has_database %}
from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends

{%- if cookiecutter.database == "sqlite" %}
from csrd.repository import SQLiteAdapter
{%- elif cookiecutter.database == "maria" %}
from csrd.repository import MariaAdapter
{%- else %}
from csrd.repository import PGAdapter
{%- endif %}

from ..repositories.item_repository import {{ cookiecutter.model_name }}Repository
from ..settings import settings


async def repository_factory() -> AsyncIterator[{{ cookiecutter.model_name }}Repository]:
    {%- if cookiecutter.database == "sqlite" %}
    adapter = SQLiteAdapter(settings.db_path)
    {%- elif cookiecutter.database == "maria" %}
    adapter = MariaAdapter(
        host=settings.db_host,
        port=3306,
        user=settings.db_user,
        password=settings.db_password,
        database=settings.db_name,
    )
    {%- else %}
    adapter = PGAdapter(
        host=settings.db_host,
        port=5432,
        user=settings.db_user,
        password=settings.db_password,
        database=settings.db_name,
    )
    {%- endif %}
    await adapter.connect()
    repo = {{ cookiecutter.model_name }}Repository(adapter)
    await repo._init_schema()
    try:
        yield repo
    finally:
        await adapter.close()


RepositoryDep = Annotated[{{ cookiecutter.model_name }}Repository, Depends(repository_factory)]


__all__ = ("RepositoryDep", "repository_factory")
{%- else %}
# Database is disabled for this generated service.
__all__: tuple[str, ...] = ()
{%- endif %}
