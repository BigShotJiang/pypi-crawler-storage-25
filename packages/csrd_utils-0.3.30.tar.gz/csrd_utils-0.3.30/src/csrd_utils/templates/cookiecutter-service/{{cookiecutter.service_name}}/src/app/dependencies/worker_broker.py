{%- if cookiecutter.has_workers %}
from ..settings import settings


def get_worker_broker_url() -> str:
    return settings.worker_broker_url


__all__ = ("get_worker_broker_url",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
