{%- if cookiecutter.has_structured_logging %}
from .logging import RequestLogMiddleware

__all__ = ("RequestLogMiddleware",)
{%- else %}
__all__: tuple[str, ...] = ()
{%- endif %}
