# Cookiecutter Service Starter

Generate a FastAPI service with composable feature toggles (database, delegates, workers, caching, structured logging).

## Generate a service

```bash
uvx cookiecutter . --directory packages/utils/src/csrd_utils/templates/cookiecutter-service
```

Key prompts:

- `service_name`
- `service_description`
- `has_database` + `database` (`sqlite`, `maria`, `postgres`)
- `has_delegates` + `upstreams`
- `has_workers` + `broker` (`redis`, `rabbitmq`)
- `has_caching`
- `has_structured_logging`
- `port`
- `model_name`

## Notes

- Adapter imports remain explicit via `from csrd.repository import ...`.
- Feature-specific files are conditionally included using template sections.
- `hooks/post_gen_project.py` validates incompatible feature combinations.
- This template is the baseline generation scaffold for `csrd-utils`.

## Example combinations

```bash
# DB-only SQLite service
uvx cookiecutter . --directory packages/utils/src/csrd_utils/templates/cookiecutter-service \
  --no-input service_name=inventory has_database=true database=sqlite \
  has_delegates=false has_workers=false has_caching=false

# Postgres + delegates + caching
uvx cookiecutter . --directory packages/utils/src/csrd_utils/templates/cookiecutter-service \
  --no-input service_name=pricing has_database=true database=postgres \
  has_delegates=true upstreams=http://inventory:8081 \
  has_workers=false has_caching=true

# Worker-focused service with RabbitMQ and no DB
uvx cookiecutter . --directory packages/utils/src/csrd_utils/templates/cookiecutter-service \
  --no-input service_name=jobs has_database=false has_workers=true broker=rabbitmq \
  has_delegates=false has_caching=false
```

## Next phase

- Phase 2 introduces standalone feature augmentation via `csrd feature`.
- See `packages/utils/docs/FUTURE_WORK.md` for remaining provider-specific CI future work.
