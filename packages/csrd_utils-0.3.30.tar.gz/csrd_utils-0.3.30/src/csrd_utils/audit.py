"""Security hardening audit checks for generated services."""

import re
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class AuditFinding:
    """A single hardening finding."""

    rule: str
    severity: str
    message: str
    file: str
    evidence: str
    remediation: str


@dataclass
class AuditReport:
    """Structured audit output."""

    ok: bool
    findings: list[AuditFinding] = field(default_factory=list)

    def to_payload(self) -> dict[str, object]:
        return {
            "ok": self.ok,
            "findings": [asdict(finding) for finding in self.findings],
            "summary": {
                "high": sum(1 for finding in self.findings if finding.severity == "high"),
                "medium": sum(1 for finding in self.findings if finding.severity == "medium"),
                "low": sum(1 for finding in self.findings if finding.severity == "low"),
            },
        }


_WEAK_PASSWORDS = r"(?:change_me|change_me_root|app|sandbox|password|root)"
_WEAK_IDENTIFIERS = r"(?:service_user|service_db|app|sandbox)"


def _scan_file(path: Path, root: Path) -> list[AuditFinding]:
    findings: list[AuditFinding] = []

    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return findings

    rel = str(path.relative_to(root))

    password_hits = re.findall(
        rf"(?:DB_PASSWORD|POSTGRES_PASSWORD|MYSQL_PASSWORD|MARIADB_PASSWORD)\s*[:=]\s*['\"]?({_WEAK_PASSWORDS})['\"]?",
        text,
        flags=re.IGNORECASE,
    )
    if password_hits:
        findings.append(
            AuditFinding(
                rule="weak-db-password-default",
                severity="high",
                message="Weak default database password is configured.",
                file=rel,
                evidence=password_hits[0],
                remediation="Set a strong DB password via environment configuration.",
            )
        )

    root_hits = re.findall(
        rf"(?:MYSQL_ROOT_PASSWORD|MARIADB_ROOT_PASSWORD)\s*[:=]\s*['\"]?({_WEAK_PASSWORDS})['\"]?",
        text,
        flags=re.IGNORECASE,
    )
    if root_hits:
        findings.append(
            AuditFinding(
                rule="weak-root-db-password-default",
                severity="high",
                message="Weak root database password is configured.",
                file=rel,
                evidence=root_hits[0],
                remediation="Set a strong root password and avoid shared defaults.",
            )
        )

    identifier_hits = re.findall(
        rf"(?:DB_USER|POSTGRES_USER|MYSQL_USER|MARIADB_USER|DB_NAME|POSTGRES_DB|MYSQL_DATABASE|MARIADB_DATABASE)\s*[:=]\s*['\"]?({_WEAK_IDENTIFIERS})['\"]?",
        text,
        flags=re.IGNORECASE,
    )
    if identifier_hits:
        findings.append(
            AuditFinding(
                rule="weak-db-identifier-default",
                severity="medium",
                message="Weak default DB user/database identifier is configured.",
                file=rel,
                evidence=identifier_hits[0],
                remediation="Set DB_USER and DB_NAME to service-specific values per environment.",
            )
        )

    if "include_actuator_endpoints=True" in text or "INCLUDE_ACTUATOR_ENDPOINTS=true" in text:
        findings.append(
            AuditFinding(
                rule="actuator-endpoints-enabled",
                severity="medium",
                message="Actuator endpoints are enabled by default.",
                file=rel,
                evidence="include_actuator_endpoints=True",
                remediation="Set INCLUDE_ACTUATOR_ENDPOINTS=false unless required on trusted networks.",
            )
        )

    if 'allow_origins=["*"]' in text or "allow_origins=['*']" in text:
        findings.append(
            AuditFinding(
                rule="cors-wildcard-origin",
                severity="medium",
                message="CORS wildcard origin is configured.",
                file=rel,
                evidence='allow_origins=["*"]',
                remediation="Restrict CORS to known trusted origins.",
            )
        )

    if "guest:guest" in text:
        findings.append(
            AuditFinding(
                rule="rabbitmq-guest-default",
                severity="medium",
                message="RabbitMQ guest credentials are configured.",
                file=rel,
                evidence="guest:guest",
                remediation="Set RABBITMQ_USER and RABBITMQ_PASSWORD explicitly.",
            )
        )

    if "--reload" in text:
        findings.append(
            AuditFinding(
                rule="dev-reload-usage",
                severity="low",
                message="Development reload mode appears in runnable commands.",
                file=rel,
                evidence="--reload",
                remediation="Avoid reload mode in production run commands.",
            )
        )

    return findings


def run_audit(service_root: Path) -> AuditReport:
    """Scan a service path for insecure defaults and weak auto-configuration."""
    root = service_root.resolve()
    findings: list[AuditFinding] = []

    if not root.exists() or not root.is_dir():
        findings.append(
            AuditFinding(
                rule="invalid-service-path",
                severity="high",
                message="Service path does not exist or is not a directory.",
                file=str(service_root),
                evidence=str(service_root),
                remediation="Provide a valid service root path.",
            )
        )
        return AuditReport(ok=False, findings=findings)

    candidates: list[Path] = []
    include_names = {"docker-compose.yml", ".env", ".env.example", "README.md", "settings.py"}

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.name in include_names or path.suffix in {".py", ".yml", ".yaml", ".env", ".md"}:
            candidates.append(path)

    seen: set[tuple[str, str, str]] = set()
    for path in candidates:
        for finding in _scan_file(path, root):
            key = (finding.rule, finding.file, finding.evidence)
            if key in seen:
                continue
            seen.add(key)
            findings.append(finding)

    has_high = any(finding.severity == "high" for finding in findings)
    return AuditReport(ok=not has_high, findings=findings)
