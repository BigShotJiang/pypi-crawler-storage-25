"""Service generation helpers backed by bundled cookiecutter templates."""

import os
import shutil
from pathlib import Path
from typing import Any

from cookiecutter.main import cookiecutter

from .resources import templates_path


def _build_context(
    *,
    name: str,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
) -> dict[str, Any]:
    return {
        "service_name": name,
        "service_description": description,
        "port": str(port),
        "model_name": model_name,
        "model_name_plural": model_name_plural,
        "has_database": has_database,
        "database": database,
        "has_delegates": has_delegates,
        "upstreams": upstreams,
        "has_workers": has_workers,
        "broker": broker,
        "has_caching": has_caching,
        "cache_backend": cache_backend,
        "has_structured_logging": has_structured_logging,
    }


def generate_service(
    *,
    name: str,
    output_dir: Path,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
    overwrite_if_exists: bool,
) -> Path:
    """Generate a service from the bundled cookiecutter-service template."""
    output_root = output_dir.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    target = output_root / name

    if target.exists() and any(target.iterdir()) and not overwrite_if_exists:
        raise FileExistsError(
            f"Target directory already exists and is not empty: {target}. Use --force to overwrite."
        )

    if has_delegates and not upstreams.strip():
        raise ValueError("--upstreams is required when --delegates is enabled")

    context = _build_context(
        name=name,
        description=description,
        port=port,
        model_name=model_name,
        model_name_plural=model_name_plural,
        has_database=has_database,
        database=database,
        has_delegates=has_delegates,
        upstreams=upstreams,
        has_workers=has_workers,
        broker=broker,
        has_caching=has_caching,
        cache_backend=cache_backend,
        has_structured_logging=has_structured_logging,
    )

    # Suppress bytecode generation during template rendering.
    old_dontwritebytecode = os.environ.get("PYTHONDONTWRITEBYTECODE")
    try:
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        with templates_path() as template_root:
            template = template_root / "cookiecutter-service"
            generated = cookiecutter(
                str(template),
                no_input=True,
                extra_context=context,
                output_dir=str(output_root),
                overwrite_if_exists=overwrite_if_exists,
            )
    finally:
        if old_dontwritebytecode is None:
            os.environ.pop("PYTHONDONTWRITEBYTECODE", None)
        else:
            os.environ["PYTHONDONTWRITEBYTECODE"] = old_dontwritebytecode

    # Clean up any __pycache__ that may have been created despite PYTHONDONTWRITEBYTECODE.
    generated_path = Path(generated).resolve()
    for pycache_dir in generated_path.rglob("__pycache__"):
        shutil.rmtree(pycache_dir, ignore_errors=True)

    return generated_path
