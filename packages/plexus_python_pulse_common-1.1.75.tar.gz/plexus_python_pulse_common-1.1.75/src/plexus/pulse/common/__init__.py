import importlib.metadata

try:
    __version__ = importlib.metadata.version("plexus-python-pulse-common")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"
