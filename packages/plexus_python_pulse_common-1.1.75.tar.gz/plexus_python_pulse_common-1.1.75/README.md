# Plexus Pulse Python Common Module

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/plexus-python-pulse-common?style=for-the-badge)
![PyPI - Version](https://img.shields.io/pypi/v/plexus-python-pulse-common?style=for-the-badge)
![Codecov](https://img.shields.io/codecov/c/github/ruyangshou/plexus-python-pulse-common?token=U8EPB2JZ70&style=for-the-badge)
