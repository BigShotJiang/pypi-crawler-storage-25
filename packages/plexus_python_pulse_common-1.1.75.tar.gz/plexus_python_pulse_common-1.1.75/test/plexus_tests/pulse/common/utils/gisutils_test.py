import math
import random
import unittest

import ddt
import numpy as np
import pydantic as pdt
import pyquaternion as pyquat
from plexus.common.utils.randutils import randomizer

from plexus.pulse.common.utils.gisutils import Coord, EQDCProj, UTMProj, WebMercProj
from plexus.pulse.common.utils.gisutils import Pose
from plexus.pulse.common.utils.gisutils import make_proj


@ddt.ddt
class PoseTest(unittest.TestCase):

    @staticmethod
    def random_pose() -> Pose:
        q = pyquat.Quaternion(axis=randomizer().random_unit_vector(3),
                              angle=math.pi * randomizer().next_float(0.0, 0.5))
        return Pose(0, np.array(randomizer().random_unit_vector(3)), q.normalised.elements)

    def assert_array_almost_equal(self, xs: np.ndarray, ys: np.ndarray, delta: float):
        self.assertEqual(len(xs), len(ys))
        for x, y in zip(xs, ys):
            self.assertAlmostEqual(x, y, delta=delta)

    def test_builtin_init(self):
        for _ in range(0, 10000):
            expect = PoseTest.random_pose()
            actual = Pose(0, expect.p, expect.q)

            self.assert_array_almost_equal(expect.p, actual.p, delta=1e-9)
            self.assert_array_almost_equal(expect.q, actual.q, delta=1e-9)

    def test_add_sub(self):
        for _ in range(0, 10000):
            pose = PoseTest.random_pose()
            delta = PoseTest.random_pose()

            result = Pose.sub(Pose.add(pose, delta), pose)

            self.assert_array_almost_equal(delta.p, result.p, delta=1e-9)
            self.assert_array_almost_equal(delta.q, result.q, delta=1e-9)

    def test_interpolate(self):
        for _ in range(0, 10000):
            t = randomizer().next_float()

            pose1 = PoseTest.random_pose()
            pose2 = PoseTest.random_pose()

            inter1 = Pose.interpolate(pose1, pose2, t)
            inter2 = Pose.interpolate(pose2, pose1, 1.0 - t)

            self.assert_array_almost_equal(inter1.p, inter2.p, delta=1e-9)
            self.assert_array_almost_equal(inter1.q, inter2.q, delta=1e-9)

    def test_matrix(self):
        for _ in range(0, 10000):
            point = np.array(randomizer().random_unit_vector(3))

            pose = PoseTest.random_pose()

            expect = pose.translate(pose.rotate(point))
            result = np.matmul(pose.matrix(), np.array([*point, 1.0])[:, None]).transpose()[0][:3]

            self.assert_array_almost_equal(expect, result, delta=1e-9)


@ddt.ddt
class ProjTest(unittest.TestCase):

    @ddt.data(
        ("eqdc:lat_1=0.0,lat_2=10.0", EQDCProj(lat_1=0.0, lat_2=10.0, lon_0=0.0)),
        ("eqdc:lat_1=0.0,lat_2=10.0,lon_0=0.0", EQDCProj(lat_1=0.0, lat_2=10.0, lon_0=0.0)),
        ("eqdc:lat_1=0.0,lat_2=10.0,lon_0=180.0", EQDCProj(lat_1=0.0, lat_2=10.0, lon_0=180.0)),
        ("eqdc:lat_1=0,lat_2=10,lon_0=180", EQDCProj(lat_1=0.0, lat_2=10.0, lon_0=180.0)),
        ("utm:zone=1", UTMProj(zone=1, south=False)),
        ("utm:zone=1,south=false", UTMProj(zone=1, south=False)),
        ("utm:zone=1,south=False", UTMProj(zone=1, south=False)),
        ("utm:zone=1,south=true", UTMProj(zone=1, south=True)),
        ("utm:zone=1,south=True", UTMProj(zone=1, south=True)),
        ("webmerc", WebMercProj(lon_0=0.0)),
        ("webmerc:lon_0=0.0", WebMercProj(lon_0=0.0)),
        ("webmerc:lon_0=180.0", WebMercProj(lon_0=180.0)),
        ("webmerc:lon_0=180", WebMercProj(lon_0=180.0)),
    )
    @ddt.unpack
    def test_make_proj(self, spec_str, expect):
        actual = make_proj(spec_str)
        self.assertEqual(actual.spec, expect.spec)

    @ddt.data(
        ("eqdc",),
        ("eqdc:lat_1=0.0",),
        ("eqdc:lat_1=0.0,lon_0=0.0",),
        ("eqdc:lat_1=0.0,lat_2=bad-value",),
        ("eqdc:lat_1=inf,lat_2=inf,lon_0=nan",),
        ("utm",),
        ("utm:zone=1,south=0",),
        ("utm:zone=1,south=1",),
        ("utm:zone=1.0,south=True",),
        ("utm:south=True",),
        ("webmerc:lon_0=bad-value",),
        ("webmerc:lon_0=nan",),
    )
    @ddt.unpack
    def test_make_proj__bad_spec_str(self, spec_str):
        with self.assertRaises(pdt.ValidationError):
            make_proj(spec_str)


@ddt.ddt
class EQDCProjTest(unittest.TestCase):

    def test_builtin_init(self):
        proj = EQDCProj(lat_1=0.0, lat_2=10.0)

        self.assertEqual(proj.spec.lat_1, 0.0)
        self.assertEqual(proj.spec.lat_2, 10.0)
        self.assertEqual(proj.spec.lon_0, 0.0)

    def test_to_string(self):
        proj = EQDCProj(lat_1=0.0, lat_2=10.0)

        self.assertEqual(proj.to_string(), "eqdc:lat_1=0.0,lat_2=10.0,lon_0=0.0")

    @ddt.data(
        (dict(),),
        (dict(lat_1=0.0),),
        (dict(lat_1="0.0", lat_2=10.0),),
        (dict(lat_1=0.0, lat_2="10.0"),),
        (dict(lat_1=0.0, lat_2=10.0, lon_0="0.0"),),
    )
    @ddt.unpack
    def test_builtin_init__with_exception(self, args):
        with self.assertRaises(pdt.ValidationError):
            EQDCProj(**args)

    def test_proj(self):
        proj = make_proj("eqdc:lat_1=0.0,lat_2=10.0")

        for _ in range(0, 1000000):
            lat = random.uniform(-80.0, 80.0)
            lon = random.uniform(-180.0, 180.0)

            x, y = proj.from_latlon(lat, lon)
            new_lat, new_lon = proj.to_latlon(x, y)

            coord = Coord.from_latlon(new_lat, new_lon, 0.0, proj)

            self.assertAlmostEqual(lat, new_lat, delta=1e-9)
            self.assertAlmostEqual(lon, new_lon, delta=1e-9)
            self.assertAlmostEqual(x, coord.x, delta=1e-3)
            self.assertAlmostEqual(y, coord.y, delta=1e-3)
            self.assertEqual(new_lat, coord.lat)
            self.assertEqual(new_lon, coord.lon)


@ddt.ddt
class UTMProjTest(unittest.TestCase):

    def test_builtin_init(self):
        proj = UTMProj(zone=31)

        self.assertEqual(proj.spec.zone, 31)
        self.assertEqual(proj.spec.south, False)

    def test_to_string(self):
        proj = UTMProj(zone=31)

        self.assertEqual(proj.to_string(), "utm:zone=31,south=False")

    @ddt.data(
        (dict(),),
        (dict(zone=31.0),),
        (dict(zone=31, south="false"),),
        (dict(zone="31", south=True),),
    )
    @ddt.unpack
    def test_builtin_init__with_exception(self, args):
        with self.assertRaises(pdt.ValidationError):
            UTMProj(**args)

    def test_proj(self):
        proj = make_proj("utm:zone=31")

        for _ in range(0, 1000000):
            lat = random.uniform(-80.0, 80.0)
            lon = random.uniform(0.0, 6.0)

            x, y = proj.from_latlon(lat, lon)
            new_lat, new_lon = proj.to_latlon(x, y)

            coord = Coord.from_latlon(new_lat, new_lon, 0.0, proj)

            self.assertAlmostEqual(lat, new_lat, delta=1e-9)
            self.assertAlmostEqual(lon, new_lon, delta=1e-9)
            self.assertAlmostEqual(x, coord.x, delta=1e-3)
            self.assertAlmostEqual(y, coord.y, delta=1e-3)
            self.assertEqual(new_lat, coord.lat)
            self.assertEqual(new_lon, coord.lon)


@ddt.ddt
class WebMercProjTest(unittest.TestCase):

    def test_builtin_init(self):
        proj = WebMercProj()

        self.assertEqual(proj.spec.lon_0, 0.0)

    def test_to_string(self):
        proj = WebMercProj()

        self.assertEqual(proj.to_string(), "webmerc:lon_0=0.0")

    @ddt.data(
        (dict(lon_0="0.0"),),
    )
    @ddt.unpack
    def test_builtin_init__with_exception(self, args):
        with self.assertRaises(pdt.ValidationError):
            WebMercProj(**args)

    def test_proj(self):
        proj = make_proj("webmerc")

        for _ in range(0, 1000000):
            lat = random.uniform(-80.0, 80.0)
            lon = random.uniform(-180.0, 180.0)

            x, y = proj.from_latlon(lat, lon)
            new_lat, new_lon = proj.to_latlon(x, y)

            coord = Coord.from_latlon(new_lat, new_lon, 0.0, proj)

            self.assertAlmostEqual(lat, new_lat, delta=1e-9)
            self.assertAlmostEqual(lon, new_lon, delta=1e-9)
            self.assertAlmostEqual(x, coord.x, delta=1e-3)
            self.assertAlmostEqual(y, coord.y, delta=1e-3)
            self.assertEqual(new_lat, coord.lat)
            self.assertEqual(new_lon, coord.lon)
