"""Tests for HttpRemoteScopeClient."""

from __future__ import annotations

import ssl
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from daimyo.domain import RemoteServerError
from daimyo.infrastructure.remote.remote_client import HttpRemoteScopeClient


class TestFlatKatasToNested:
    """Tests for _flat_katas_to_nested conversion."""

    @pytest.fixture
    def client(self) -> HttpRemoteScopeClient:
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    def test_single_top_level_category(self, client: HttpRemoteScopeClient) -> None:
        """Single flat key with no dots maps to a top-level nested dict."""
        flat = {"testing": {"when": "When testing", "katas": {"tdd-cycle": "step 1"}}}
        result = client._flat_katas_to_nested(flat)

        assert "testing" in result
        assert result["testing"]["when"] == "When testing"
        assert result["testing"]["katas"] == {"tdd-cycle": "step 1"}

    def test_dotted_key_produces_nesting(self, client: HttpRemoteScopeClient) -> None:
        """A dotted key is expanded into nested dicts."""
        flat = {
            "python.testing": {
                "when": "When writing Python tests",
                "katas": {"tdd-cycle": "1. Red 2. Green 3. Refactor"},
            }
        }
        result = client._flat_katas_to_nested(flat)

        assert "python" in result
        assert "testing" in result["python"]
        assert result["python"]["testing"]["katas"] == {
            "tdd-cycle": "1. Red 2. Green 3. Refactor"
        }

    def test_missing_when_defaults_to_none(self, client: HttpRemoteScopeClient) -> None:
        """A category without 'when' gets None in the nested dict."""
        flat = {"dev": {"katas": {"build": "step 1"}}}
        result = client._flat_katas_to_nested(flat)

        assert result["dev"]["when"] is None

    def test_empty_input_returns_empty_dict(self, client: HttpRemoteScopeClient) -> None:
        """Empty flat dict produces an empty nested dict."""
        assert client._flat_katas_to_nested({}) == {}

    def test_multiple_categories(self, client: HttpRemoteScopeClient) -> None:
        """Multiple flat keys produce sibling entries in the nested dict."""
        flat = {
            "python.testing": {"when": "Tests", "katas": {"tdd-cycle": "..."}},
            "python.web": {"when": "Web", "katas": {"build-api": "..."}},
        }
        result = client._flat_katas_to_nested(flat)

        assert "testing" in result["python"]
        assert "web" in result["python"]


class TestParseJsonWithKatas:
    """Tests for _parse_json kata parsing."""

    @pytest.fixture
    def client(self) -> HttpRemoteScopeClient:
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    def test_parse_json_includes_katas(self, client: HttpRemoteScopeClient) -> None:
        """Katas present in the JSON payload are parsed into the returned Scope."""
        json_payload = {
            "metadata": {"name": "test-scope", "description": "desc", "parent": None},
            "commandments": {},
            "suggestions": {},
            "katas": {
                "python.testing": {
                    "when": "When writing Python tests",
                    "katas": {"tdd-cycle": "1. Red\n2. Green\n3. Refactor"},
                }
            },
        }
        scope = client._parse_json(json_payload, "test-scope", "http://example.com")

        from daimyo.domain import CategoryKey

        cat_key = CategoryKey.from_string("python.testing")
        assert cat_key in scope.katas.categories
        category = scope.katas.categories[cat_key]
        assert "tdd-cycle" in category.katas
        assert category.katas["tdd-cycle"].procedure == "1. Red\n2. Green\n3. Refactor"

    def test_parse_json_no_katas_key_leaves_katas_empty(
        self, client: HttpRemoteScopeClient
    ) -> None:
        """A JSON payload without a 'katas' key results in an empty KataSet."""
        json_payload = {
            "metadata": {"name": "test-scope", "description": "desc", "parent": None},
            "commandments": {},
            "suggestions": {},
        }
        scope = client._parse_json(json_payload, "test-scope", "http://example.com")

        assert scope.katas.categories == {}


class TestHttpRemoteScopeClient:
    """Test suite for HttpRemoteScopeClient."""

    @pytest.fixture
    def client(self) -> HttpRemoteScopeClient:
        """Create client instance."""
        return HttpRemoteScopeClient(timeout=30, max_retries=3)

    @pytest.fixture
    def minimal_scope_json(self) -> dict:
        """Minimal valid JSON payload for a scope response."""
        return {
            "metadata": {"name": "test-scope", "description": "Test scope", "parent": None},
            "commandments": {},
            "suggestions": {},
            "katas": {},
        }

    def test_client_initialization_with_params(self) -> None:
        """Test client initialization with custom parameters."""
        client = HttpRemoteScopeClient(timeout=60, max_retries=5)

        assert client.timeout == 60
        assert client.max_retries == 5
        assert client.client is not None

    def test_client_initialization_with_defaults(self) -> None:
        """Test client initialization uses defaults from settings."""
        client = HttpRemoteScopeClient()

        assert client.timeout > 0
        assert client.max_retries >= 0

    def test_fetch_scope_success(
        self, client: HttpRemoteScopeClient, httpx_mock: object, minimal_scope_json: dict
    ) -> None:
        """Successful scope fetch returns a Scope with the expected name."""
        from pytest_httpx import HTTPXMock

        assert isinstance(httpx_mock, HTTPXMock)
        httpx_mock.add_response(  # type: ignore[union-attr]
            url="https://example.com/api/v1/scopes/test-scope/rules?debug=true",
            json=minimal_scope_json,
        )

        result = client.fetch_scope("https://example.com", "test-scope")

        assert result is not None
        assert result.metadata.name == "test-scope"

    def test_fetch_scope_404_returns_none(
        self, client: HttpRemoteScopeClient, httpx_mock: object
    ) -> None:
        """A 404 response causes fetch_scope to return None."""
        from pytest_httpx import HTTPXMock

        assert isinstance(httpx_mock, HTTPXMock)
        httpx_mock.add_response(  # type: ignore[union-attr]
            url="https://example.com/api/v1/scopes/nonexistent/rules?debug=true",
            status_code=404,
        )

        result = client.fetch_scope("https://example.com", "nonexistent")

        assert result is None

    def test_fetch_scope_500_raises_error(
        self, client: HttpRemoteScopeClient, httpx_mock: object
    ) -> None:
        """A 5xx response raises RemoteServerError."""
        from pytest_httpx import HTTPXMock

        assert isinstance(httpx_mock, HTTPXMock)
        httpx_mock.add_response(  # type: ignore[union-attr]
            url="https://example.com/api/v1/scopes/test-scope/rules?debug=true",
            status_code=500,
            text="Internal server error",
        )

        with pytest.raises(RemoteServerError):
            client.fetch_scope("https://example.com", "test-scope")

    def test_fetch_scope_timeout_raises_error(
        self, client: HttpRemoteScopeClient, httpx_mock: object
    ) -> None:
        """A timeout raises RemoteServerError mentioning 'Timeout'."""
        import httpx
        from pytest_httpx import HTTPXMock

        assert isinstance(httpx_mock, HTTPXMock)
        httpx_mock.add_exception(  # type: ignore[union-attr]
            httpx.TimeoutException("Request timed out"),
            url="https://example.com/api/v1/scopes/test-scope/rules?debug=true",
        )

        with pytest.raises(RemoteServerError) as exc_info:
            client.fetch_scope("https://example.com", "test-scope")

        assert "Timeout" in str(exc_info.value)

    def test_fetch_scope_connection_error_raises(
        self, client: HttpRemoteScopeClient, httpx_mock: object
    ) -> None:
        """A connection error raises RemoteServerError mentioning 'Connection error'."""
        import httpx
        from pytest_httpx import HTTPXMock

        assert isinstance(httpx_mock, HTTPXMock)
        httpx_mock.add_exception(  # type: ignore[union-attr]
            httpx.ConnectError("Cannot connect"),
            url="https://example.com/api/v1/scopes/test-scope/rules?debug=true",
        )

        with pytest.raises(RemoteServerError) as exc_info:
            client.fetch_scope("https://example.com", "test-scope")

        assert "Connection error" in str(exc_info.value)

    def test_fetch_scope_url_construction(self) -> None:
        """Test that API URL is constructed correctly."""
        base_url = "https://example.com"
        scope_name = "test-scope"

        expected_url = "https://example.com/api/v1/scopes/test-scope/rules"

        assert expected_url in f"{base_url}/api/v1/scopes/{scope_name}/rules"

    def test_fetch_scope_url_with_trailing_slash(self) -> None:
        """Test URL construction with trailing slash in base URL."""
        base_url = "https://example.com/"
        scope_name = "test-scope"

        expected_url = "https://example.com/api/v1/scopes/test-scope/rules"

        assert expected_url in f"{base_url.rstrip('/')}/api/v1/scopes/{scope_name}/rules"

    def test_client_closes_on_deletion(self) -> None:
        """Test that client closes httpx client on deletion."""
        import gc
        import weakref

        client = HttpRemoteScopeClient(timeout=30, max_retries=3)
        httpx_client = client.client

        weak_ref = weakref.ref(client)

        del client
        gc.collect()

        assert weak_ref() is None
        assert httpx_client.is_closed

    def test_fetch_scope_follows_redirects(self, client: HttpRemoteScopeClient) -> None:
        """Transport is created with at least one retry configured."""
        transport: Any = client.client._transport
        assert transport._pool._retries > 0


class TestHttpRemoteScopeClientSSL:
    """Tests for SSL/TLS configuration of HttpRemoteScopeClient.

    These tests verify that the correct `verify` value is forwarded to
    `httpx.HTTPTransport`, which is where httpx actually applies SSL settings.
    """

    def _get_verify_kwarg(self, **kwargs: Any) -> bool | str:
        """Instantiate the client with a patched HTTPTransport and return the verify kwarg.

        :param kwargs: Arguments forwarded to HttpRemoteScopeClient
        :returns: The value passed as `verify` to httpx.HTTPTransport
        :rtype: bool | str
        """
        with patch(
            "daimyo.infrastructure.remote.remote_client.httpx.HTTPTransport"
        ) as mock_transport_cls:
            mock_transport_cls.return_value = MagicMock()
            HttpRemoteScopeClient(**kwargs)
            _, ctor_kwargs = mock_transport_cls.call_args
            return ctor_kwargs["verify"]  # type: ignore[return-value]

    def test_default_ssl_verify_true(self) -> None:
        """Default config uses verify=True (system CA store)."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.REMOTE_SSL_CA_PATH = ""
            verify = self._get_verify_kwarg()
        assert verify is True

    def test_ssl_verify_disabled(self) -> None:
        """ssl_verify=False passes verify=False to httpx.HTTPTransport."""
        verify = self._get_verify_kwarg(ssl_verify=False, ssl_ca_bundle="")
        assert verify is False

    def test_ssl_verify_disabled_ca_bundle_ignored(self) -> None:
        """ssl_verify=False ignores ssl_ca_bundle and passes verify=False."""
        verify = self._get_verify_kwarg(ssl_verify=False, ssl_ca_bundle="/path/to/ca.pem")
        assert verify is False

    def test_custom_ca_bundle(self) -> None:
        """ssl_verify=True with a ca bundle path passes the path as verify."""
        verify = self._get_verify_kwarg(
            ssl_verify=True, ssl_ca_bundle="/etc/ssl/certs/company-ca.pem"
        )
        assert verify == "/etc/ssl/certs/company-ca.pem"

    def test_default_verify_true_no_bundle(self) -> None:
        """ssl_verify=True with empty ca bundle passes verify=True."""
        verify = self._get_verify_kwarg(ssl_verify=True, ssl_ca_bundle="")
        assert verify is True

    def test_config_defaults_used_when_params_omitted(self) -> None:
        """When no SSL params are passed, values are read from settings."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = "/from/config/ca.pem"
            mock_settings.REMOTE_SSL_CA_PATH = ""
            verify = self._get_verify_kwarg()
        assert verify == "/from/config/ca.pem"

    def test_config_default_verify_false(self) -> None:
        """When settings.REMOTE_SSL_VERIFY is False, verify=False is used."""
        with patch("daimyo.infrastructure.remote.remote_client.settings") as mock_settings:
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = False
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.REMOTE_SSL_CA_PATH = ""
            verify = self._get_verify_kwarg()
        assert verify is False

    def test_custom_ca_path(self, tmp_path: Path) -> None:
        """ssl_ca_path passes an ssl.SSLContext built from the directory."""
        verify = self._get_verify_kwarg(ssl_verify=True, ssl_ca_bundle="", ssl_ca_path=str(tmp_path))
        assert isinstance(verify, ssl.SSLContext)

    def test_ca_bundle_takes_precedence_over_ca_path(self, tmp_path: Path) -> None:
        """ssl_ca_bundle wins over ssl_ca_path when both are set."""
        verify = self._get_verify_kwarg(
            ssl_verify=True,
            ssl_ca_bundle="/etc/ssl/ca.pem",
            ssl_ca_path=str(tmp_path),
        )
        assert verify == "/etc/ssl/ca.pem"

    def test_ssl_verify_false_overrides_ca_path(self, tmp_path: Path) -> None:
        """ssl_verify=False disables verification even when ssl_ca_path is set."""
        verify = self._get_verify_kwarg(ssl_verify=False, ssl_ca_path=str(tmp_path))
        assert verify is False


class TestHttpRemoteScopeClientSSLContext:
    """End-to-end tests that inspect the actual ssl.SSLContext on the transport pool.

    These tests verify that SSL settings are truly applied — not just forwarded
    as arguments, but reflected in the underlying TLS configuration used for
    real connections.
    """

    def test_ssl_truly_disabled(self) -> None:
        """With ssl_verify=False the SSL context has CERT_NONE and check_hostname off."""
        client = HttpRemoteScopeClient(ssl_verify=False, ssl_ca_bundle="")
        try:
            transport: Any = client.client._transport
            ctx: ssl.SSLContext = transport._pool._ssl_context
            assert ctx.verify_mode == ssl.CERT_NONE, (
                f"verify_mode is {ctx.verify_mode!r}, expected CERT_NONE — "
                "SSL verification is not truly disabled"
            )
            assert not ctx.check_hostname, (
                "check_hostname is still True even though ssl_verify=False"
            )
        finally:
            client.client.close()

    def test_ssl_enabled_by_default(self) -> None:
        """With ssl_verify=True the SSL context does not use CERT_NONE."""
        client = HttpRemoteScopeClient(ssl_verify=True, ssl_ca_bundle="")
        try:
            transport: Any = client.client._transport
            ctx: ssl.SSLContext = transport._pool._ssl_context
            assert ctx.verify_mode != ssl.CERT_NONE, (
                "verify_mode is CERT_NONE even though ssl_verify=True — "
                "SSL verification is unexpectedly disabled"
            )
        finally:
            client.client.close()

    def test_ssl_context_from_ca_path(self, tmp_path: Path) -> None:
        """ssl_ca_path builds a real SSLContext with verification enabled."""
        client = HttpRemoteScopeClient(ssl_verify=True, ssl_ca_path=str(tmp_path))
        try:
            transport: Any = client.client._transport
            ctx: ssl.SSLContext = transport._pool._ssl_context
            assert ctx.verify_mode != ssl.CERT_NONE, (
                "verify_mode is CERT_NONE even though ssl_ca_path is set — "
                "SSL verification should remain enabled"
            )
        finally:
            client.client.close()

    @pytest.mark.parametrize(
        ("ssl_verify", "ssl_ca_bundle", "expected_cert_none"),
        [
            (False, "", True),
            (False, "/some/path.pem", True),
            (True, "", False),
        ],
    )
    def test_ssl_context_cert_none_parametrized(
        self,
        ssl_verify: bool,
        ssl_ca_bundle: str,
        expected_cert_none: bool,
    ) -> None:
        """SSL context CERT_NONE state matches the expected value for each combination."""
        client = HttpRemoteScopeClient(ssl_verify=ssl_verify, ssl_ca_bundle=ssl_ca_bundle)
        try:
            transport: Any = client.client._transport
            ctx: ssl.SSLContext = transport._pool._ssl_context
            is_cert_none = ctx.verify_mode == ssl.CERT_NONE
            assert is_cert_none == expected_cert_none, (
                f"ssl_verify={ssl_verify}, ssl_ca_bundle={ssl_ca_bundle!r}: "
                f"expected CERT_NONE={expected_cert_none}, got verify_mode={ctx.verify_mode!r}"
            )
        finally:
            client.client.close()
