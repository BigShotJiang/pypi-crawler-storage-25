"""Tests for SSL configuration propagation in ServiceContainer."""

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from daimyo.infrastructure.di.container import ServiceContainer


class TestServiceContainerSSL:
    """Tests verifying SSL settings are passed from ServiceContainer to HttpRemoteScopeClient."""

    def _get_client_ssl_kwargs(self, **container_overrides: Any) -> dict:
        """Instantiate ServiceContainer, call remote_client(), and return the SSL kwargs
        passed to HttpRemoteScopeClient.

        :param container_overrides: Keyword arguments forwarded to ServiceContainer
        :returns: Dict with ssl_verify, ssl_ca_bundle, and ssl_ca_path keys
        :rtype: dict
        """
        with patch("daimyo.infrastructure.di.container.HttpRemoteScopeClient") as mock_cls:
            mock_cls.return_value = MagicMock()
            container = ServiceContainer(**container_overrides)
            container.remote_client()
            _, ctor_kwargs = mock_cls.call_args
            return {
                "ssl_verify": ctor_kwargs["ssl_verify"],
                "ssl_ca_bundle": ctor_kwargs["ssl_ca_bundle"],
                "ssl_ca_path": ctor_kwargs["ssl_ca_path"],
            }

    @pytest.mark.parametrize(
        ("container_overrides", "expected_ssl_verify", "expected_ca_bundle", "expected_ca_path"),
        [
            (
                {"remote_ssl_verify": False, "remote_ssl_ca_bundle": "", "remote_ssl_ca_path": ""},
                False,
                "",
                "",
            ),
            (
                {
                    "remote_ssl_verify": True,
                    "remote_ssl_ca_bundle": "/etc/ssl/company-ca.pem",
                    "remote_ssl_ca_path": "",
                },
                True,
                "/etc/ssl/company-ca.pem",
                "",
            ),
            (
                {"remote_ssl_verify": True, "remote_ssl_ca_bundle": "", "remote_ssl_ca_path": ""},
                True,
                "",
                "",
            ),
            (
                {
                    "remote_ssl_verify": True,
                    "remote_ssl_ca_bundle": "",
                    "remote_ssl_ca_path": "/etc/ssl/certs",
                },
                True,
                "",
                "/etc/ssl/certs",
            ),
        ],
    )
    def test_ssl_settings_propagated_to_client(
        self,
        container_overrides: dict,
        expected_ssl_verify: bool,
        expected_ca_bundle: str,
        expected_ca_path: str,
    ) -> None:
        """SSL settings passed to ServiceContainer are forwarded to HttpRemoteScopeClient."""
        result = self._get_client_ssl_kwargs(**container_overrides)
        assert result["ssl_verify"] == expected_ssl_verify
        assert result["ssl_ca_bundle"] == expected_ca_bundle
        assert result["ssl_ca_path"] == expected_ca_path

    def test_default_ssl_settings_from_config(self) -> None:
        """When no SSL overrides are given, ServiceContainer reads defaults from settings."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.REMOTE_SSL_CA_PATH = ""
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is True
        assert result["ssl_ca_bundle"] == ""
        assert result["ssl_ca_path"] == ""

    def test_ssl_verify_false_from_config(self) -> None:
        """When settings.REMOTE_SSL_VERIFY is False, container passes ssl_verify=False."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = False
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.REMOTE_SSL_CA_PATH = ""
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is False

    def test_ca_bundle_from_config(self) -> None:
        """When settings.REMOTE_SSL_CA_BUNDLE is set, container passes it to the client."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = "/from/config/ca.pem"
            mock_settings.REMOTE_SSL_CA_PATH = ""
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is True
        assert result["ssl_ca_bundle"] == "/from/config/ca.pem"

    def test_ca_path_from_config(self) -> None:
        """When settings.REMOTE_SSL_CA_PATH is set, container passes it to the client."""
        with patch("daimyo.infrastructure.di.container.settings") as mock_settings:
            mock_settings.RULES_PATH = ".daimyo/rules"
            mock_settings.REMOTE_TIMEOUT_SECONDS = 5
            mock_settings.REMOTE_MAX_RETRIES = 3
            mock_settings.REMOTE_SSL_VERIFY = True
            mock_settings.REMOTE_SSL_CA_BUNDLE = ""
            mock_settings.REMOTE_SSL_CA_PATH = "/from/config/certs"
            mock_settings.MAX_INHERITANCE_DEPTH = 10
            result = self._get_client_ssl_kwargs()
        assert result["ssl_verify"] is True
        assert result["ssl_ca_path"] == "/from/config/certs"
