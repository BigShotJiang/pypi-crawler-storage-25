"""Tests for CLI query commands (get-category-index, get-rules, etc.)."""

from __future__ import annotations

from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from daimyo.__main__ import app
from daimyo.domain import (
    CategoryKey,
    Kata,
    KataCategory,
    KataSet,
    MergedScope,
    RuleSet,
    ScopeMetadata,
)

_MARKDOWN = "# Test Output\n\ncontent"


def _mock_container(merged_scope: MergedScope | None = None) -> Mock:
    """Build a mock DI container with pre-wired scope and filter services."""
    container = Mock()
    scope_service = Mock()
    scope_service.resolve_scope.return_value = merged_scope or Mock()
    container.scope_service.return_value = scope_service
    filter_service = Mock()
    filter_service.filter_from_string.return_value = merged_scope or Mock()
    container.category_filter_service.return_value = filter_service
    container.template_renderer.return_value = Mock()
    return container


def _make_scope(name: str = "test-scope") -> MergedScope:
    return MergedScope(
        metadata=ScopeMetadata(name=name, description="Test scope"),
        commandments=RuleSet(),
        suggestions=RuleSet(),
        sources=["local"],
    )


def _make_scope_with_kata(kata_name: str = "my-kata") -> MergedScope:
    kata = Kata(name=kata_name, procedure="Step 1.")
    kata_cat = KataCategory(key=CategoryKey.from_string("python.testing"), when="When testing")
    kata_cat.add_kata(kata)
    katas = KataSet()
    katas.add_category(kata_cat)
    return MergedScope(
        metadata=ScopeMetadata(name="test-scope", description="Test scope"),
        commandments=RuleSet(),
        suggestions=RuleSet(),
        katas=katas,
        sources=["local"],
    )


class TestGetCategoryIndex:
    """Tests for the get-category-index command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI test runner."""
        return CliRunner()

    @patch("daimyo.application.formatters.IndexMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success(self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner) -> None:
        """Prints markdown to stdout and exits 0 for a valid scope."""
        mock_get_container.return_value = _mock_container(_make_scope())
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-category-index", "test-scope"])

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.IndexMarkdownFormatter")
    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_uses_default_scope(
        self,
        mock_get_container: Mock,
        mock_settings: Mock,
        mock_formatter_cls: Mock,
        runner: CliRunner,
    ) -> None:
        """Falls back to DEFAULT_SCOPE when no scope argument is provided."""
        mock_settings.DEFAULT_SCOPE = "default-scope"
        scope = _make_scope("default-scope")
        mock_get_container.return_value = _mock_container(scope)
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-category-index"])

        assert result.exit_code == 0
        mock_get_container.return_value.scope_service.return_value.resolve_scope.assert_called_once_with(
            "default-scope"
        )

    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_no_scope_no_default_exits_1(
        self, mock_get_container: Mock, mock_settings: Mock, runner: CliRunner
    ) -> None:
        """Exits 1 with an error when no scope is given and DEFAULT_SCOPE is not configured."""
        mock_settings.DEFAULT_SCOPE = ""
        mock_get_container.return_value = _mock_container()

        result = runner.invoke(app, ["get-category-index"])

        assert result.exit_code == 1
        assert "Error" in result.output

    @patch("daimyo.infrastructure.di.get_container")
    def test_scope_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 with an error message when the scope cannot be resolved."""
        container = _mock_container()
        container.scope_service.return_value.resolve_scope.side_effect = Exception("Scope not found")
        mock_get_container.return_value = container

        result = runner.invoke(app, ["get-category-index", "missing"])

        assert result.exit_code == 1
        assert "Error" in result.output


class TestGetRules:
    """Tests for the get-rules command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI test runner."""
        return CliRunner()

    @patch("daimyo.application.formatters.MarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success(self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner) -> None:
        """Prints rules markdown to stdout and exits 0."""
        mock_get_container.return_value = _mock_container(_make_scope())
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-rules", "test-scope"])

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.MarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_with_categories_filter(
        self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner
    ) -> None:
        """Passes the --categories value to the filter service."""
        scope = _make_scope()
        container = _mock_container(scope)
        mock_get_container.return_value = container
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        runner.invoke(app, ["get-rules", "test-scope", "--categories", "python.testing"])

        container.category_filter_service.return_value.filter_from_string.assert_called_once_with(
            scope, "python.testing"
        )

    @patch("daimyo.application.formatters.MarkdownFormatter")
    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_uses_default_scope(
        self,
        mock_get_container: Mock,
        mock_settings: Mock,
        mock_formatter_cls: Mock,
        runner: CliRunner,
    ) -> None:
        """Falls back to DEFAULT_SCOPE when no scope argument is provided."""
        mock_settings.DEFAULT_SCOPE = "default-scope"
        mock_get_container.return_value = _mock_container(_make_scope("default-scope"))
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-rules"])

        assert result.exit_code == 0
        mock_get_container.return_value.scope_service.return_value.resolve_scope.assert_called_once_with(
            "default-scope"
        )

    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_no_scope_no_default_exits_1(
        self, mock_get_container: Mock, mock_settings: Mock, runner: CliRunner
    ) -> None:
        """Exits 1 with an error when no scope and no default scope are configured."""
        mock_settings.DEFAULT_SCOPE = ""
        mock_get_container.return_value = _mock_container()

        result = runner.invoke(app, ["get-rules"])

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.infrastructure.di.get_container")
    def test_scope_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the scope cannot be resolved."""
        container = _mock_container()
        container.scope_service.return_value.resolve_scope.side_effect = Exception("not found")
        mock_get_container.return_value = container

        result = runner.invoke(app, ["get-rules", "missing"])

        assert result.exit_code == 1
        assert "Error" in result.stderr


class TestGetKataCategoryIndex:
    """Tests for the get-kata-category-index command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI test runner."""
        return CliRunner()

    @patch("daimyo.application.formatters.KataIndexMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success(self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner) -> None:
        """Prints kata category index to stdout and exits 0."""
        mock_get_container.return_value = _mock_container(_make_scope())
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-kata-category-index", "test-scope"])

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.KataIndexMarkdownFormatter")
    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_uses_default_scope(
        self,
        mock_get_container: Mock,
        mock_settings: Mock,
        mock_formatter_cls: Mock,
        runner: CliRunner,
    ) -> None:
        """Falls back to DEFAULT_SCOPE when no scope argument is provided."""
        mock_settings.DEFAULT_SCOPE = "default-scope"
        mock_get_container.return_value = _mock_container(_make_scope("default-scope"))
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-kata-category-index"])

        assert result.exit_code == 0
        mock_get_container.return_value.scope_service.return_value.resolve_scope.assert_called_once_with(
            "default-scope"
        )

    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_no_scope_no_default_exits_1(
        self, mock_get_container: Mock, mock_settings: Mock, runner: CliRunner
    ) -> None:
        """Exits 1 when no scope argument and no DEFAULT_SCOPE configured."""
        mock_settings.DEFAULT_SCOPE = ""
        mock_get_container.return_value = _mock_container()

        result = runner.invoke(app, ["get-kata-category-index"])

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.infrastructure.di.get_container")
    def test_scope_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the scope cannot be resolved."""
        container = _mock_container()
        container.scope_service.return_value.resolve_scope.side_effect = Exception("not found")
        mock_get_container.return_value = container

        result = runner.invoke(app, ["get-kata-category-index", "missing"])

        assert result.exit_code == 1
        assert "Error" in result.stderr


class TestGetKatas:
    """Tests for the get-katas command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI test runner."""
        return CliRunner()

    @patch("daimyo.application.formatters.KataListMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success(self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner) -> None:
        """Prints available katas to stdout and exits 0."""
        mock_get_container.return_value = _mock_container(_make_scope())
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-katas", "test-scope"])

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.KataListMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_with_categories_filter(
        self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner
    ) -> None:
        """Passes the --categories value to the filter service."""
        scope = _make_scope()
        container = _mock_container(scope)
        mock_get_container.return_value = container
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        runner.invoke(app, ["get-katas", "test-scope", "--categories", "python"])

        container.category_filter_service.return_value.filter_from_string.assert_called_once_with(
            scope, "python"
        )

    @patch("daimyo.application.formatters.KataListMarkdownFormatter")
    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_uses_default_scope(
        self,
        mock_get_container: Mock,
        mock_settings: Mock,
        mock_formatter_cls: Mock,
        runner: CliRunner,
    ) -> None:
        """Falls back to DEFAULT_SCOPE when no scope argument is provided."""
        mock_settings.DEFAULT_SCOPE = "default-scope"
        mock_get_container.return_value = _mock_container(_make_scope("default-scope"))
        mock_formatter_cls.return_value.format.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-katas"])

        assert result.exit_code == 0

    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_no_scope_no_default_exits_1(
        self, mock_get_container: Mock, mock_settings: Mock, runner: CliRunner
    ) -> None:
        """Exits 1 when no scope argument and no DEFAULT_SCOPE configured."""
        mock_settings.DEFAULT_SCOPE = ""
        mock_get_container.return_value = _mock_container()

        result = runner.invoke(app, ["get-katas"])

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.infrastructure.di.get_container")
    def test_scope_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the scope cannot be resolved."""
        container = _mock_container()
        container.scope_service.return_value.resolve_scope.side_effect = Exception("not found")
        mock_get_container.return_value = container

        result = runner.invoke(app, ["get-katas", "missing"])

        assert result.exit_code == 1
        assert "Error" in result.stderr


class TestGetKata:
    """Tests for the get-kata command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI test runner."""
        return CliRunner()

    @patch("daimyo.application.formatters.KataMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success(self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner) -> None:
        """Prints the kata procedure to stdout and exits 0."""
        scope = _make_scope_with_kata("my-kata")
        mock_get_container.return_value = _mock_container(scope)
        mock_formatter_cls.return_value.format_kata.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-kata", "my-kata", "--scope", "test-scope"])

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.KataMarkdownFormatter")
    @patch("daimyo.infrastructure.di.get_container")
    def test_success_with_category(
        self, mock_get_container: Mock, mock_formatter_cls: Mock, runner: CliRunner
    ) -> None:
        """Disambiguates by --category when provided."""
        scope = _make_scope_with_kata("my-kata")
        mock_get_container.return_value = _mock_container(scope)
        mock_formatter_cls.return_value.format_kata.return_value = _MARKDOWN

        result = runner.invoke(
            app,
            ["get-kata", "my-kata", "--scope", "test-scope", "--category", "python.testing"],
        )

        assert result.exit_code == 0
        assert _MARKDOWN in result.stdout

    @patch("daimyo.application.formatters.KataMarkdownFormatter")
    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_uses_default_scope(
        self,
        mock_get_container: Mock,
        mock_settings: Mock,
        mock_formatter_cls: Mock,
        runner: CliRunner,
    ) -> None:
        """Falls back to DEFAULT_SCOPE when --scope is omitted."""
        mock_settings.DEFAULT_SCOPE = "default-scope"
        scope = _make_scope_with_kata("my-kata")
        mock_get_container.return_value = _mock_container(scope)
        mock_formatter_cls.return_value.format_kata.return_value = _MARKDOWN

        result = runner.invoke(app, ["get-kata", "my-kata"])

        assert result.exit_code == 0
        mock_get_container.return_value.scope_service.return_value.resolve_scope.assert_called_once_with(
            "default-scope"
        )

    @patch("daimyo.infrastructure.di.get_container")
    def test_kata_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the kata name does not exist anywhere in the scope."""
        mock_get_container.return_value = _mock_container(_make_scope_with_kata("real-kata"))

        result = runner.invoke(app, ["get-kata", "nonexistent", "--scope", "test-scope"])

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.infrastructure.di.get_container")
    def test_category_not_found_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the specified --category does not exist in the scope."""
        mock_get_container.return_value = _mock_container(_make_scope_with_kata("my-kata"))

        result = runner.invoke(
            app,
            ["get-kata", "my-kata", "--scope", "test-scope", "--category", "nonexistent"],
        )

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.infrastructure.di.get_container")
    def test_kata_not_in_category_exits_1(self, mock_get_container: Mock, runner: CliRunner) -> None:
        """Exits 1 when the kata is not found within the specified category."""
        mock_get_container.return_value = _mock_container(_make_scope_with_kata("other-kata"))

        result = runner.invoke(
            app,
            ["get-kata", "my-kata", "--scope", "test-scope", "--category", "python.testing"],
        )

        assert result.exit_code == 1
        assert "Error" in result.stderr

    @patch("daimyo.config.settings.settings")
    @patch("daimyo.infrastructure.di.get_container")
    def test_no_scope_no_default_exits_1(
        self, mock_get_container: Mock, mock_settings: Mock, runner: CliRunner
    ) -> None:
        """Exits 1 when --scope is omitted and no DEFAULT_SCOPE is configured."""
        mock_settings.DEFAULT_SCOPE = ""
        mock_get_container.return_value = _mock_container()

        result = runner.invoke(app, ["get-kata", "my-kata"])

        assert result.exit_code == 1
        assert "Error" in result.stderr

    def test_kata_name_required(self, runner: CliRunner) -> None:
        """Exits non-zero when the kata name positional argument is missing."""
        result = runner.invoke(app, ["get-kata"])

        assert result.exit_code != 0
