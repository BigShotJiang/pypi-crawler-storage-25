"""Markdown formatters for Katas."""

from typing import TYPE_CHECKING

from daimyo.application.formatters.helpers.template_aware import TemplateAwareMixin
from daimyo.application.formatters.tree_builder import CategoryTreeBuilder
from daimyo.domain import Kata, MergedScope

if TYPE_CHECKING:
    from daimyo.application.templating import TemplateRenderer

class KataIndexMarkdownFormatter(TemplateAwareMixin):
    """Format kata categories as a hierarchical markdown index."""

    def __init__(self, template_renderer: "TemplateRenderer | None" = None):
        """Initialize formatter.

        :param template_renderer: Optional template renderer
        :type template_renderer: TemplateRenderer | None
        """
        self.template_renderer = template_renderer
        from daimyo.config import settings
        self.settings = settings

    def format(self, scope: MergedScope) -> str:
        """Format kata categories index.

        :param scope: Merged scope
        :type scope: MergedScope
        :returns: Markdown-formatted index
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("KATAS_INDEX_MARKDOWN_PROLOGUE", "")
        if prologue:
            if self.template_renderer:
                rendered_prologue = self.template_renderer.render_prologue_epilogue(
                    prologue,
                    scope,
                    context_type="katas index markdown prologue",
                    failure_collector=scope,
                )
                lines.append(rendered_prologue)
            else:
                lines.append(prologue)
            lines.append("")

        lines.append(f"# Kata Categories for {scope.metadata.name}\n")

        category_list = []
        for cat in scope.katas.categories.values():
            when = self._get_when_with_hierarchical_fallback(
                cat.key,
                cat.when,
                scope.commandments,
                scope.suggestions,
                scope,
                failure_collector=scope,
            )
            category_list.append((str(cat.key), when))

        category_tree = CategoryTreeBuilder.build_index_tree(sorted(category_list))
        lines.extend(self._format_tree(category_tree, scope))

        epilogue = self.settings.get("KATAS_INDEX_MARKDOWN_EPILOGUE", "")
        if epilogue:
            lines.append("")
            if self.template_renderer:
                rendered_epilogue = self.template_renderer.render_prologue_epilogue(
                    epilogue,
                    scope,
                    context_type="katas index markdown epilogue",
                    failure_collector=scope,
                )
                lines.append(rendered_epilogue)
            else:
                lines.append(epilogue)

        return "\n".join(lines)

    def _format_tree(
        self,
        tree: dict,
        scope: MergedScope,
        depth: int = 0,
    ) -> list[str]:
        """Recursively format category tree.

        :param tree: Category tree
        :type tree: dict
        :param scope: Merged scope
        :type scope: MergedScope
        :param depth: Current depth
        :type depth: int
        :returns: Formatted lines
        :rtype: list[str]
        """
        result = []
        indent = "  " * depth

        for _, node in sorted(tree.items()):
            full_key = node["_key"]
            when_desc = node.get("_when", "")

            if when_desc:
                rendered_when = self._render_text(
                    when_desc, scope, None, failure_collector=scope
                )
                result.append(f"{indent}- `{full_key}`: {rendered_when}")
            else:
                result.append(f"{indent}- `{full_key}`")

            children = node.get("_children", {})
            if children:
                result.extend(self._format_tree(children, scope, depth + 1))

        return result


class KataListMarkdownFormatter(TemplateAwareMixin):
    """Format available katas as a markdown list."""

    def __init__(self, template_renderer: "TemplateRenderer | None" = None):
        """Initialize formatter.

        :param template_renderer: Optional template renderer
        :type template_renderer: TemplateRenderer | None
        """
        self.template_renderer = template_renderer
        from daimyo.config import settings
        self.settings = settings

    def format(self, scope: MergedScope) -> str:
        """Format list of katas.

        :param scope: Merged scope
        :type scope: MergedScope
        :returns: Markdown-formatted list
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("KATAS_LIST_MARKDOWN_PROLOGUE", "")
        if prologue:
            if self.template_renderer:
                rendered_prologue = self.template_renderer.render_prologue_epilogue(
                    prologue,
                    scope,
                    context_type="katas list markdown prologue",
                    failure_collector=scope,
                )
                lines.append(rendered_prologue)
            else:
                lines.append(prologue)
            lines.append("")

        lines.append(f"# Available Katas in {scope.metadata.name}\n")

        if not scope.katas.categories:
            lines.append("No katas found for the selected categories.")
        else:
            for cat_key, category in sorted(
                scope.katas.categories.items(), key=lambda x: str(x[0])
            ):
                lines.append(f"## {cat_key}\n")
                if category.when:
                    rendered_when = self._render_text(
                        category.when, scope, None, failure_collector=scope
                    )
                    lines.append(f"*{rendered_when}*\n")

                for kata_name in sorted(category.katas.keys()):
                    lines.append(f"- `{kata_name}`")
                lines.append("")

        epilogue = self.settings.get("KATAS_LIST_MARKDOWN_EPILOGUE", "")
        if epilogue:
            lines.append("")
            if self.template_renderer:
                rendered_epilogue = self.template_renderer.render_prologue_epilogue(
                    epilogue,
                    scope,
                    context_type="katas list markdown epilogue",
                    failure_collector=scope,
                )
                lines.append(rendered_epilogue)
            else:
                lines.append(epilogue)

        return "\n".join(lines)


class KataMarkdownFormatter(TemplateAwareMixin):
    """Format a single kata procedure as markdown."""

    def __init__(self, template_renderer: "TemplateRenderer | None" = None):
        """Initialize formatter.

        :param template_renderer: Optional template renderer
        :type template_renderer: TemplateRenderer | None
        """
        self.template_renderer = template_renderer
        from daimyo.config import settings
        self.settings = settings

    def format_kata(self, scope: MergedScope, kata: Kata) -> str:
        """Format a specific kata.

        :param scope: Merged scope
        :type scope: MergedScope
        :param kata: The kata to format
        :type kata: Kata
        :returns: Markdown-formatted procedure
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("KATA_MARKDOWN_PROLOGUE", "")
        if prologue:
            if self.template_renderer:
                rendered_prologue = self.template_renderer.render_prologue_epilogue(
                    prologue,
                    scope,
                    context_type=f"kata {kata.name} markdown prologue",
                    failure_collector=scope,
                )
                lines.append(rendered_prologue)
            else:
                lines.append(prologue)
            lines.append("")

        lines.append(f"# Kata: {kata.name}\n")

        if self.template_renderer:
            rendered_procedure = self.template_renderer.render_kata_procedure(
                kata.procedure,
                scope,
                kata_name=kata.name,
                failure_collector=scope,
            )
            lines.append(rendered_procedure)
        else:
            lines.append(kata.procedure)

        epilogue = self.settings.get("KATA_MARKDOWN_EPILOGUE", "")
        if epilogue:
            lines.append("")
            if self.template_renderer:
                rendered_epilogue = self.template_renderer.render_prologue_epilogue(
                    epilogue,
                    scope,
                    context_type=f"kata {kata.name} markdown epilogue",
                    failure_collector=scope,
                )
                lines.append(rendered_epilogue)
            else:
                lines.append(epilogue)

        return "\n".join(lines)
