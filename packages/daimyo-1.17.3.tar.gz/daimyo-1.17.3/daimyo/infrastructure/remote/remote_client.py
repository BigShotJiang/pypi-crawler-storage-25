"""HTTP client for fetching scopes from remote servers."""

from typing import Any
from urllib.parse import urljoin

import ssl

import httpx

from daimyo.application.validation import sanitize_error_message
from daimyo.config import settings
from daimyo.domain import RemoteServerError, RuleType, Scope, YAMLParseError
from daimyo.infrastructure.filesystem.yaml_parser import parse_katas, parse_metadata, parse_rules
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class HttpRemoteScopeClient:
    """HTTP client for fetching scopes from remote Daimyo servers.

    Fetches scopes via the REST API of remote servers.
    """

    def __init__(
        self,
        timeout: int | None = None,
        max_retries: int | None = None,
        ssl_verify: bool | None = None,
        ssl_ca_bundle: str | None = None,
        ssl_ca_path: str | None = None,
    ):
        """Initialize the HTTP client.

        :param timeout: Request timeout in seconds (defaults to config setting)
        :type timeout: Optional[int]
        :param max_retries: Maximum number of retries (defaults to config setting)
        :type max_retries: Optional[int]
        :param ssl_verify: Whether to verify SSL certificates (defaults to config setting)
        :type ssl_verify: Optional[bool]
        :param ssl_ca_bundle: Path to a custom CA bundle file in PEM format
            (defaults to config setting)
        :type ssl_ca_bundle: Optional[str]
        :param ssl_ca_path: Path to a directory of CA certificates in OpenSSL c_rehash format
            (defaults to config setting). Ignored when ssl_ca_bundle is set.
        :type ssl_ca_path: Optional[str]
        """
        self.timeout = timeout or settings.REMOTE_TIMEOUT_SECONDS
        self.max_retries = max_retries or settings.REMOTE_MAX_RETRIES

        effective_ssl_verify = ssl_verify if ssl_verify is not None else settings.REMOTE_SSL_VERIFY
        effective_ca_bundle = (
            ssl_ca_bundle if ssl_ca_bundle is not None else settings.REMOTE_SSL_CA_BUNDLE
        )
        effective_ca_path = (
            ssl_ca_path if ssl_ca_path is not None else settings.REMOTE_SSL_CA_PATH
        )

        if not effective_ssl_verify:
            verify: ssl.SSLContext | bool | str = False
        elif effective_ca_bundle:
            verify = effective_ca_bundle
        elif effective_ca_path:
            verify = ssl.create_default_context(capath=effective_ca_path)
        else:
            verify = True

        transport = httpx.HTTPTransport(retries=self.max_retries, verify=verify)
        self.client = httpx.Client(
            transport=transport,
            timeout=self.timeout,
            follow_redirects=True,
        )

    def fetch_scope(self, base_url: str, scope_name: str) -> Scope | None:
        """Fetch a scope from a remote server.

        :param base_url: Base URL of the remote server (e.g., "https://remote.com")
        :type base_url: str
        :param scope_name: Name of the scope to fetch
        :type scope_name: str
        :returns: Scope instance if found, None otherwise
        :rtype: Optional[Scope]
        :raises RemoteServerError: If the remote server is unreachable or returns an error
        """
        try:
            api_url = urljoin(
                base_url.rstrip("/") + "/",
                f"api/v1/scopes/{scope_name}/rules?debug=true",
            )

            logger.debug(f"Fetching scope '{scope_name}' from {api_url}")

            response = self.client.get(api_url, headers={"Accept": "application/json"})

            if response.status_code == 404:
                logger.debug(f"Scope '{scope_name}' not found at {base_url}")
                return None

            if response.status_code != 200:
                raise RemoteServerError(
                    f"Remote server returned status {response.status_code}: "
                    f"{sanitize_error_message(response.text, max_length=200)}"
                )

            json_content = response.json()
            scope = self._parse_json(json_content, scope_name, base_url)

            logger.info(f"Successfully fetched scope '{scope_name}' from {base_url}")
            return scope

        except httpx.TimeoutException as e:
            raise RemoteServerError(
                f"Timeout fetching scope '{scope_name}' from {base_url}: {e}",
                url=base_url,
                status_code=None,
            )
        except httpx.ConnectError as e:
            raise RemoteServerError(
                f"Connection error fetching scope '{scope_name}' from {base_url}: {e}",
                url=base_url,
                status_code=None,
            )
        except httpx.HTTPError as e:
            status_code = getattr(e, "response", None)
            status_code = getattr(status_code, "status_code", None) if status_code else None
            raise RemoteServerError(
                f"HTTP error fetching scope '{scope_name}' from {base_url}: {e}",
                url=base_url,
                status_code=status_code,
            )
        except YAMLParseError as e:
            raise RemoteServerError(
                f"Failed to parse scope '{scope_name}' from {base_url}: {e}",
                url=base_url,
                status_code=200,
            )
        except OSError as e:
            raise RemoteServerError(
                f"I/O error fetching scope '{scope_name}' from {base_url}: {e}",
                url=base_url,
                status_code=None,
            )
        except Exception as e:
            logger.exception(f"Unexpected error fetching scope '{scope_name}' from {base_url}")
            raise RemoteServerError(
                f"Unexpected error fetching scope '{scope_name}' from {base_url}: "
                f"{type(e).__name__}: {e}",
                url=base_url,
                status_code=None,
            )

    def list_scopes(self, base_url: str) -> list[str] | None:
        """List available scopes from a remote server.

        :param base_url: Base URL of the remote server
        :type base_url: str
        :returns: List of scope names if found, None on error
        :rtype: Optional[list[str]]
        :raises RemoteServerError: If the remote server is unreachable or returns an error
        """
        try:
            api_url = urljoin(
                base_url.rstrip("/") + "/",
                "api/v1/scopes",
            )

            logger.debug(f"Listing scopes from {api_url}")

            response = self.client.get(api_url, headers={"Accept": "application/json"})

            if response.status_code == 404:
                logger.debug(f"Scopes endpoint not found at {base_url}")
                return None

            if response.status_code != 200:
                raise RemoteServerError(
                    f"Remote server returned status {response.status_code}: "
                    f"{sanitize_error_message(response.text, max_length=200)}"
                )

            scopes = response.json()

            if not isinstance(scopes, list):
                raise RemoteServerError(
                    f"Invalid response format from {base_url}: expected list, got {type(scopes)}"
                )

            logger.info(f"Successfully listed {len(scopes)} scopes from {base_url}")
            return scopes

        except httpx.TimeoutException as e:
            raise RemoteServerError(
                f"Timeout listing scopes from {base_url}: {e}",
                url=base_url,
                status_code=None,
            )
        except httpx.ConnectError as e:
            raise RemoteServerError(
                f"Connection error listing scopes from {base_url}: {e}",
                url=base_url,
                status_code=None,
            )
        except httpx.HTTPError as e:
            status_code = getattr(e, "response", None)
            status_code = getattr(status_code, "status_code", None) if status_code else None
            raise RemoteServerError(
                f"HTTP error listing scopes from {base_url}: {e}",
                url=base_url,
                status_code=status_code,
            )
        except Exception as e:
            logger.exception(f"Unexpected error listing scopes from {base_url}")
            raise RemoteServerError(
                f"Unexpected error listing scopes from {base_url}: {type(e).__name__}: {e}",
                url=base_url,
                status_code=None,
            )

    def _parse_json(self, json_data: dict, scope_name: str, source_url: str) -> Scope:
        """Parse JSON response into a Scope.

        :param json_data: JSON data dictionary
        :type json_data: dict
        :param scope_name: Name of the scope
        :type scope_name: str
        :param source_url: Source URL for tracking
        :type source_url: str
        :returns: Parsed Scope instance
        :rtype: Scope
        :raises YAMLParseError: If parsing fails
        """
        try:
            metadata_dict = json_data.get("metadata", {})
            metadata = parse_metadata(metadata_dict, scope_name)

            scope = Scope(metadata=metadata, source=source_url)

            commandments_flat = json_data.get("commandments", {})
            if commandments_flat:
                commandments_nested = self._flat_to_nested(commandments_flat)
                scope.commandments = parse_rules(commandments_nested, RuleType.COMMANDMENT)

            suggestions_flat = json_data.get("suggestions", {})
            if suggestions_flat:
                suggestions_nested = self._flat_to_nested(suggestions_flat)
                scope.suggestions = parse_rules(suggestions_nested, RuleType.SUGGESTION)

            katas_flat = json_data.get("katas", {})
            if katas_flat:
                katas_nested = self._flat_katas_to_nested(katas_flat)
                scope.katas = parse_katas(katas_nested)

            return scope

        except Exception as e:
            raise YAMLParseError(f"Error parsing remote scope JSON data: {e}")

    def _flat_katas_to_nested(self, flat_dict: dict) -> dict:
        """Convert flat kata dictionary with dot-notation keys to nested structure.

        Input: {"python.testing": {"when": "...", "katas": {"tdd-cycle": "..."}}}
        Output: {"python": {"testing": {"when": "...", "katas": {"tdd-cycle": "..."}}}}

        :param flat_dict: Flat dictionary with dot-notation category keys
        :type flat_dict: dict
        :returns: Nested dictionary structure compatible with parse_katas
        :rtype: dict
        """
        result: dict[str, Any] = {}

        for key, value in flat_dict.items():
            parts = key.split(".")
            current = result

            for part in parts[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]

            last_part = parts[-1]
            current[last_part] = {
                "when": value.get("when"),
                "katas": value.get("katas", {}),
            }

        return result

    def _flat_to_nested(self, flat_dict: dict) -> dict:
        """Convert flat dictionary with dot-notation keys to nested structure.

        Input: {"coding": {"when": "...", "rules": [...]},
                "coding.python": {"when": "...", "rules": [...]}}
        Output: {"coding": {"when": "...", "ruleset": [...],
                           "python": {"when": "...", "ruleset": [...]}}}

        :param flat_dict: Flat dictionary with dot-notation keys
        :type flat_dict: dict
        :returns: Nested dictionary structure
        :rtype: dict
        """
        result: dict[str, Any] = {}

        for key, value in flat_dict.items():
            parts = key.split(".")
            current = result

            for i, part in enumerate(parts[:-1]):
                if part not in current:
                    current[part] = {}
                current = current[part]

            last_part = parts[-1]
            category_data = {
                "when": value.get("when"),
                "tags": value.get("tags", []),
                "ruleset": value.get("rules", []),
            }
            current[last_part] = category_data

        return result

    def __del__(self) -> None:
        """Close the HTTP client on deletion.

        :rtype: None
        """
        if hasattr(self, "client"):
            self.client.close()


__all__ = ["HttpRemoteScopeClient"]
