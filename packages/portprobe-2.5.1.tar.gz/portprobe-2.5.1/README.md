# PortProbe 2.5

**Advanced Network Reconnaissance & Vulnerability Scanning Tool for Penetration Testers**

PortProbe is a professional-grade network scanner written in pure Python, designed to be your go-to tool for reconnaissance, vulnerability detection, and service enumeration during penetration testing engagements.

## 🎯 Key Features

### Core Scanning Capabilities
- **Multi-protocol Scanning**: TCP and UDP port scanning with configurable timeouts
- **CIDR Range Scanning**: Scan entire subnets with automatic host expansion
- **Service Banner Grabbing**: Identify services by grabbing and analyzing banners
- **OS Detection**: TTL-based fingerprinting for operating system detection
- **High-Performance Threading**: Multi-threaded scanning with configurable thread counts (up to 200+)
- **Rate Limiting**: Control scan timing to avoid detection or network overload

### Vulnerability Detection & Risk Assessment
- **Vulnerability Database**: Pre-built database of known vulnerabilities and CVEs
- **Service Risk Scoring**: Automatic risk assessment for detected services
- **Banner Fingerprinting**: Service version detection from banner grabs
- **Vulnerability Reports**: Detailed risk assessment with severity levels (CRITICAL, HIGH, MEDIUM, LOW)
- **Exploit Database**: Information about known exploits for detected services

### Advanced Scanning Profiles
- **Stealth Profile**: Slow, evasive scans to avoid IDS detection
- **Aggressive Profile**: Fast, high-throughput scanning
- **Normal Profile**: Balanced default scanning
- **Intense Profile**: Thorough scanning with version detection
- **Quick Profile**: Rapid scanning of top 20 ports
- **Vulnerability Check Profile**: Focuses on known vulnerable services

### Multiple Output Formats
- **JSON**: Structured output for integration with other tools
- **XML**: Nmap-compatible XML format
- **HTML**: Beautiful, professional reports with risk visualization
- **Markdown**: Portable markdown reports
- **CSV**: Spreadsheet-compatible output
- **Simple Text**: Basic port/state listing
- **Table**: Colorized terminal output

### Port Presets (40+ categories)
- **Top Ports**: `top20`, `top100`, `top1000`
- **Protocol-Specific**: `ssh`, `ftp`, `smtp`, `pop3`, `imap`, `dns`, `ldap`, `snmp`, `telnet`
- **Database Services**: `db`, `mysql`, `postgresql`, `mssql`, `oracle`, `mongodb`, `redis`, `cassandra`, `elasticsearch`, `memcached`
- **Web Services**: `web`, `http`, `https`
- **Remote Access**: `rdp`, `vnc`, `ssh`
- **Windows Services**: `smb`, `netbios`, `rpc`
- **Other Services**: `ntp`, `iscsi`, `synbase`, `informix` and many more
- **All**: Complete 1-65535 port range scan

### Interactive Mode
- **Terminal Interface**: Full-featured interactive scanning menu
- **Profile Browser**: View available scan profiles
- **Quick Scans**: One-command vulnerability assessments
- **Dynamic Input**: Customize scans on-the-fly

### Additional Tools
- **TCP Ping**: Multi-packet connectivity checking with timing
- **DNS Resolution**: Hostname/IP resolution with reverse lookups
- **Service Lookup**: Port-to-service mapping with vulnerability indicators
- **Directory Scanning**: Probe common web paths such as `/admin/` and `/api/`
- **Batch Operations**: Process multiple targets with CIDR notation

## 🚀 Installation

### Via pip
```bash
pip install portprobe
```

### From Source
```bash
git clone <repository>
cd portprobe
pip install -e .
```

### Windows PATH Integration
Add PortProbe to Windows PATH (requires administrator privileges):
```bash
portprobe --path
```

## 📖 Usage

### Command Line Examples

#### Basic Port Scanning
```bash
# Scan top 100 ports
portprobe scan -u example.com

# Scan specific ports
portprobe scan -i 192.168.1.1 -p 22,80,443

# Scan port range
portprobe scan -u example.com -p 1-1024

# UDP scanning
portprobe scan -u example.com -p 53,5353,5355 --udp
```

#### Scan Profiles
```bash
# Stealth scan (slow, IDS evasion)
portprobe scan -u example.com --profile stealth

# Aggressive scan (fast, high threads)
portprobe scan -u example.com --profile aggressive --threads 200

# Vulnerability assessment
portprobe scan -u example.com --profile vuln_check --vulnerability

# Intense full scan
portprobe scan -u example.com --profile intense
```

#### Service Detection & Enumeration
```bash
# Grab service banners
portprobe scan -u example.com -p top100 --banners

# Detect OS via TTL
portprobe scan -i 192.168.1.1 --os-detect

# Verbose output with banner details
portprobe scan -u example.com --banners -v
```

#### Vulnerability Scanning
```bash
# Full vulnerability assessment
portprobe scan -u example.com --vulnerability

# Generate HTML report
portprobe scan -u example.com --vulnerability --html report.html

# Risk scoring and severity levels
portprobe scan -i 192.168.1.0/24 --vulnerability -o results.json
```

#### CIDR Range Scanning
```bash
# Scan entire subnet
portprobe scan -i 192.168.1.0/24 -p web --threads 150

# Large-scale scanning with custom timeout
portprobe scan -i 10.0.0.0/16 -p top100 --timeout 2.0 --threads 200
```

#### Output Formats
```bash
# JSON output
portprobe scan -u example.com --json -o scan.json

# HTML report with vulnerabilities
portprobe scan -u example.com --html -o report.html

# Nmap-compatible XML
portprobe scan -u example.com --xml -o scan.xml

# Markdown report
portprobe scan -u example.com --markdown -o report.md

# CSV for spreadsheet analysis
portprobe scan -u example.com --csv -o results.csv
```

#### Advanced Options
```bash
# High-performance scan with custom threading
portprobe scan -u example.com -p top1000 --threads 200 --timeout 0.5

# Randomized port order (stealth)
portprobe scan -i 192.168.1.1 --randomize

# Rate limiting (1 probe per 0.1 seconds)
portprobe scan -u example.com --rate 0.1

# Show all ports (including closed)
portprobe scan -u example.com --show-closed
```

#### Utility Commands
```bash
# TCP connectivity check
portprobe ping -u example.com -p 443 -c 5

# DNS resolution
portprobe resolve -u example.com

# Service port lookup
portprobe service 22 80 443 3306 5432

# Common web directory scan
portprobe dirs -u https://example.com

# Directory scan with the default remote SecLists wordlist
portprobe dirs -u https://example.com -w

# Directory scan with a custom newline-separated wordlist
portprobe dirs -u https://example.com -w wordlist.txt

# Interactive terminal mode
portprobe -terminal
```

### Interactive Mode
```bash
# Launch interactive menu
portprobe -terminal

# Available options:
# 1. Port Scan (advanced)
# 2. TCP Ping
# 3. DNS Resolve
# 4. Service Lookup
# 5. Vulnerability Assessment
# 6. View Scan Profiles
# 7. Run Quick Scan
# 8. Run Aggressive Scan
```

### Python Library Usage
```python
from portprobe import scan_target
from portprobe.vulnerabilities import generate_risk_report

# Basic scan
result = scan_target("example.com", [22, 80, 443], timeout=2.0)
print(result.to_dict())

# With vulnerability assessment
ports_dict = {p.port: p.state == "open" for p in result.ports}
risk_report = generate_risk_report(ports_dict)
print(f"Risk Score: {risk_report['overall_risk_score']}/10")
print(f"Critical Ports: {risk_report['critical_ports']}")
```

## 🛡️ Vulnerability Detection

PortProbe includes a comprehensive vulnerability database with:
- Known CVEs for identified services
- Risk severity levels (CRITICAL, HIGH, MEDIUM, LOW)
- Service-specific recommendations
- Banner-based version detection
- Vulnerability matching

Example vulnerability detection:
```
🛡️  VULNERABILITY ASSESSMENT
─────────────────────────────────
📊 Risk Score: 8/10 - CRITICAL

🔴 CRITICAL ISSUES (2):
  ├─ Port 21 (FTP): FTP sends credentials in plain text
  ├─ Port 3306 (MySQL): Database service should not be exposed

🟠 HIGH RISK ISSUES (3):
  ├─ Port 22 (SSH): Check for outdated SSH versions
  ├─ Port 139 (SMB): Null session allows anonymous enumeration
```

## 📊 Port Presets Reference

### Common Categories
- `top20` - Most critical 20 ports
- `top100` - Most common 100 ports
- `top1000` - Ports 1-1000
- `web` - HTTP/HTTPS services
- `db` - Database services
- `mail` - Email services

### Service-Specific Presets
- `ssh`, `ftp`, `telnet` - Remote access
- `mysql`, `postgresql`, `mssql`, `oracle` - Databases
- `http`, `https` - Web services
- `smtp`, `pop3`, `imap` - Email
- `ldap`, `dns`, `snmp` - Network services
- `rdp`, `vnc`, `smb` - Remote desktop/file sharing

## 🎓 Examples for Penetration Testers

### Reconnaissance Phase
```bash
# Quick target assessment
portprobe scan -u target.com --profile quick

# Full vulnerability scan with report
portprobe scan -u target.com --vulnerability --html pentesting_report.html

# Web server enumeration
portprobe scan -i 192.168.1.5 -p web --banners -v
```

### OSINT Phase
```bash
# DNS enumeration
portprobe resolve -u target.com

# Subnet discovery
portprobe scan -i 192.168.1.0/24 -p top20 --threads 150
```

### Service Enumeration
```bash
# Database detection
portprobe scan -i 192.168.1.1 -p db --banners --version-detect

# All services with banners
portprobe scan -u target.com --banners --verbose --os-detect
```

## ⚙️ Performance Tips

- **Quick Scans**: Use `--profile quick` or `--threads 200`
- **Stealth Scans**: Use `--profile stealth` for slow, evasive scans
- **Large Ranges**: Increase threads (`--threads 200`) and reduce timeout (`--timeout 0.5`)
- **Rate Limiting**: Use `--rate 0.1` to spread probes evenly

## 🔐 Security Notes

- Always obtain proper authorization before scanning
- Use stealth profiles to minimize detection
- Respect rate limiting and firewall configurations
- Consider network impact of aggressive scans
- Review and handle vulnerability data responsibly

## Requirements
- Python 3.6+
- Standard library only (no external dependencies!)

## Supported Platforms
- Windows
- Linux
- macOS

## 📝 License
MIT License - See LICENSE file

## 🤝 Contributing
Contributions welcome! Please submit pull requests or issues.

## 📞 Support
For issues, feature requests, or questions, please open an issue on the repository.

---

**PortProbe v2.5** - Your professional reconnaissance companion


- Python 3.6+
- No external dependencies (uses only standard library)

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
