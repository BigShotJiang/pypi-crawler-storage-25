import unittest

from portprobe.scan import parse_ports, scan_target


class TestScan(unittest.TestCase):
    def test_parse_ports_range_and_preset(self):
        self.assertEqual(parse_ports("22,80"), [22, 80])
        self.assertEqual(parse_ports("100-102"), [100, 101, 102])
        self.assertTrue(len(parse_ports("top100")) >= 100)

    def test_scan_target_returns_result(self):
        result = scan_target("127.0.0.1", [1, 22], timeout=0.5, threads=2)
        self.assertEqual(result.target, "127.0.0.1")
        self.assertIn(result.scan_type, ("tcp", "udp"))
        self.assertEqual(result.total_ports_scanned, 2)
        self.assertEqual(len(result.ports) <= 2, True)


if __name__ == "__main__":
    unittest.main()
