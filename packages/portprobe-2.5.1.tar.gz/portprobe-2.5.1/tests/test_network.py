import unittest

from portprobe.network import resolve_target, expand_cidr


class TestNetwork(unittest.TestCase):
    def test_resolve_ip_returns_same_ip(self):
        ip, hostname = resolve_target("127.0.0.1")
        self.assertEqual(ip, "127.0.0.1")
        self.assertTrue(hostname in ("localhost", ""))

    def test_expand_cidr(self):
        hosts = expand_cidr("127.0.0.0/30")
        self.assertEqual(hosts, ["127.0.0.1", "127.0.0.2"])


if __name__ == "__main__":
    unittest.main()
