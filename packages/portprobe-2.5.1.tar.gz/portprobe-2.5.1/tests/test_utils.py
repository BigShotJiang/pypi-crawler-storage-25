import unittest

from portprobe.utils import RateLimiter, cap_thread_count, chunk_iterable, normalize_targets


class TestUtils(unittest.TestCase):
    def test_cap_thread_count_defaults(self):
        self.assertEqual(cap_thread_count(None, 10), 10)
        self.assertEqual(cap_thread_count(None, 60), 50)
        self.assertEqual(cap_thread_count(None, 500), 100)

    def test_cap_thread_count_requested(self):
        self.assertEqual(cap_thread_count(5, 100), 5)
        self.assertEqual(cap_thread_count(500, 10), 10)

    def test_chunk_iterable(self):
        items = list(range(7))
        chunks = list(chunk_iterable(items, 3))
        self.assertEqual(chunks, [[0, 1, 2], [3, 4, 5], [6]])

    def test_normalize_targets(self):
        self.assertEqual(normalize_targets([" example.com ", ""]), ["example.com"])

    def test_rate_limiter(self):
        limiter = RateLimiter(0.01)
        start = None
        for _ in range(2):
            limiter.acquire()
            if start is None:
                start = limiter._last
        self.assertIsNotNone(start)


if __name__ == "__main__":
    unittest.main()
