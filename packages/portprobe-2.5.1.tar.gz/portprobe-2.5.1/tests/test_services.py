import unittest

from portprobe.service_parser import identify_service


class TestServices(unittest.TestCase):
    def test_identify_http(self):
        banner = "HTTP/1.1 200 OK\r\nServer: TestServer\r\nContent-Type: text/html\r\n\r\n<html><title>Hello</title></html>"
        fingerprint = identify_service(80, "tcp", banner, {})
        self.assertEqual(fingerprint.service_name, "http")
        self.assertEqual(fingerprint.details.get("server"), "TestServer")
        self.assertEqual(fingerprint.details.get("http_title"), "Hello")

    def test_identify_ssh(self):
        banner = "SSH-2.0-OpenSSH_8.0"
        fingerprint = identify_service(22, "tcp", banner, {})
        self.assertEqual(fingerprint.service_name, "ssh")
        self.assertEqual(fingerprint.details["ssh_banner"], "SSH-2.0-OpenSSH_8.0")


if __name__ == "__main__":
    unittest.main()
