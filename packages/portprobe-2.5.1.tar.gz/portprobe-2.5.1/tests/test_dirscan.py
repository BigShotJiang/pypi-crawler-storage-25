import threading
import unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer

from portprobe.cli import build_parser
from portprobe.dirscan import (
    SECLISTS_WORDLIST_SENTINEL,
    normalize_base_url,
    resolve_wordlist,
    scan_directories,
)


class DirectoryScanHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self._handle_request()

    def do_GET(self):
        self._handle_request()

    def log_message(self, format, *args):
        return

    def _send_response(self, status_code, body=b"", headers=None):
        headers = headers or {}
        self.send_response(status_code)
        for key, value in headers.items():
            self.send_header(key, value)
        if "Content-Length" not in headers:
            self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _handle_request(self):
        if self.path == "/admin/":
            self._send_response(200, b"admin area")
        elif self.path == "/private/":
            self._send_response(403, b"forbidden")
        elif self.path == "/panel/":
            self._send_response(301, headers={"Location": "/login/", "Content-Length": "0"})
        elif self.path == "/fallback/":
            if self.command == "HEAD":
                self._send_response(405, headers={"Content-Length": "0"})
            else:
                self._send_response(200, b"fallback page")
        elif self.path == "/robots.txt":
            self._send_response(200, b"User-agent: *\nDisallow:\n")
        else:
            self._send_response(404, b"missing")


class TestDirectoryScan(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(("127.0.0.1", 0), DirectoryScanHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base_url = "http://127.0.0.1:{port}".format(port=cls.server.server_port)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def test_normalize_base_url_removes_trailing_slash(self):
        self.assertEqual(normalize_base_url("http://example.com/app/"), "http://example.com/app")

    def test_scan_directories_discovers_expected_paths(self):
        result = scan_directories(
            self.base_url,
            words=["admin", "private", "panel", "missing", "fallback", "robots.txt"],
            timeout=1.0,
            threads=4,
        )

        findings = {finding.path: finding for finding in result.findings}

        self.assertEqual(result.scanned_paths, 6)
        self.assertEqual(findings["/admin/"].status_code, 200)
        self.assertEqual(findings["/private/"].status_code, 403)
        self.assertEqual(findings["/panel/"].status_code, 301)
        self.assertEqual(findings["/panel/"].location, "/login/")
        self.assertEqual(findings["/fallback/"].status_code, 200)
        self.assertEqual(findings["/robots.txt"].status_code, 200)
        self.assertNotIn("/missing/", findings)

    def test_build_parser_accepts_dirs_command(self):
        args = build_parser().parse_args(["dirs", "-u", "http://example.com", "--threads", "5"])
        self.assertEqual(args.command, "dirs")
        self.assertEqual(args.url, "http://example.com")
        self.assertEqual(args.threads, 5)

    def test_build_parser_supports_bare_wordlist_flag_for_seclists(self):
        args = build_parser().parse_args(["dirs", "-u", "http://example.com", "-w"])
        self.assertEqual(args.wordlist, SECLISTS_WORDLIST_SENTINEL)

    @patch("portprobe.dirscan.urlopen")
    def test_resolve_wordlist_fetches_seclists_when_requested(self, mocked_urlopen):
        mocked_urlopen.return_value.__enter__.return_value.read.return_value = b"admin\napi\n# comment\nlogin\n"

        selection = resolve_wordlist(SECLISTS_WORDLIST_SENTINEL)

        self.assertEqual(selection.words, ["admin", "api", "login"])
        self.assertIn("raw.githubusercontent.com", selection.source)
        self.assertEqual(selection.used_fallback, False)

    @patch("portprobe.dirscan.urlopen", side_effect=OSError("offline"))
    def test_resolve_wordlist_falls_back_when_seclists_is_unavailable(self, mocked_urlopen):
        selection = resolve_wordlist(SECLISTS_WORDLIST_SENTINEL)

        self.assertTrue(len(selection.words) > 0)
        self.assertEqual(selection.source, "built-in fallback")
        self.assertEqual(selection.used_fallback, True)


if __name__ == "__main__":
    unittest.main()
