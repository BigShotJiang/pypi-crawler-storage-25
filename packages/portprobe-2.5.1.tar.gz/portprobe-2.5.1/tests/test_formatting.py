import unittest

from portprobe.formatting import format_csv, format_json, format_simple, format_table
from portprobe.scan import PortResult, ScanResult


class TestFormatting(unittest.TestCase):
    def setUp(self):
        self.result = ScanResult(
            target="127.0.0.1",
            ip="127.0.0.1",
            hostname="localhost",
            ports=[
                PortResult(port=22, state="open", service="ssh", protocol="tcp", response_time_ms=10.5),
                PortResult(port=80, state="closed", service="http", protocol="tcp", response_time_ms=15.0),
            ],
            os_guess="Unknown",
            scan_duration=0.05,
            total_ports_scanned=2,
            scan_type="tcp",
        )

    def test_format_csv(self):
        csv_text = format_csv(self.result)
        self.assertIn("127.0.0.1", csv_text)
        self.assertIn("ssh", csv_text)

    def test_format_json(self):
        json_text = format_json(self.result)
        self.assertIn("schema_version", json_text)
        self.assertIn("127.0.0.1", json_text)

    def test_format_simple(self):
        simple_text = format_simple(self.result)
        self.assertIn("22/tcp", simple_text)
        self.assertNotIn("80/tcp", simple_text)

    def test_format_table(self):
        table_text = format_table(self.result)
        self.assertIn("PORT", table_text)
        self.assertIn("ssh", table_text)


if __name__ == "__main__":
    unittest.main()
