from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="portprobe",
    version="1.0.0",
    author="anc.w",
    author_email="ppparker163@gmail.com",
    description="PortProbe — Network scanner written in pure Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/anc-w/PortProbe",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: System :: Networking",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "portprobe=portprobe.cli:main",
        ],
    },
)