import ssl
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin, urlparse, urlunparse
from urllib.request import HTTPSHandler, HTTPRedirectHandler, Request, build_opener, urlopen


DEFAULT_DIRECTORY_WORDLIST: Sequence[str] = (
    "admin",
    "login",
    "dashboard",
    "api",
    "uploads",
    "assets",
    "static",
    "images",
    "img",
    "css",
    "js",
    "backup",
    "backups",
    "config",
    "test",
    "dev",
    "staging",
    "private",
    "portal",
    "panel",
    "docs",
    "robots.txt",
    ".git",
)

DEFAULT_DISCOVERY_STATUS_CODES: Set[int] = {200, 204, 301, 302, 307, 308, 401, 403}
SECLISTS_WORDLIST_SENTINEL = "__seclists__"
SECLISTS_DEFAULT_WORDLIST_URL = (
    "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/common.txt"
)


class NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@dataclass
class DirectoryFinding:
    path: str
    status_code: int
    url: str
    content_length: Optional[int] = None
    location: str = ""

    def to_dict(self) -> Dict[str, object]:
        return {
            "path": self.path,
            "status_code": self.status_code,
            "url": self.url,
            "content_length": self.content_length,
            "location": self.location,
        }


@dataclass
class DirectoryScanResult:
    base_url: str
    findings: List[DirectoryFinding] = field(default_factory=list)
    scan_duration: float = 0.0
    scanned_paths: int = 0

    def to_dict(self) -> Dict[str, object]:
        return {
            "base_url": self.base_url,
            "scan_duration_s": self.scan_duration,
            "scanned_paths": self.scanned_paths,
            "findings": [finding.to_dict() for finding in self.findings],
        }


@dataclass
class WordlistSelection:
    words: List[str]
    source: str
    used_fallback: bool = False


def normalize_base_url(base_url: str) -> str:
    candidate = base_url.strip()
    if not candidate:
        raise ValueError("A target URL is required")
    if "://" not in candidate:
        candidate = "https://" + candidate

    parsed = urlparse(candidate)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("Invalid URL. Example: https://example.com")

    path = parsed.path.rstrip("/")
    normalized = urlunparse((parsed.scheme, parsed.netloc, path, "", "", ""))
    return normalized.rstrip("/")


def _parse_wordlist_lines(lines: Iterable[str]) -> List[str]:
    words: List[str] = []
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        words.append(line)
    return words


def load_wordlist(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8") as handle:
        return _parse_wordlist_lines(handle)


def load_remote_wordlist(url: str = SECLISTS_DEFAULT_WORDLIST_URL, timeout: float = 10.0) -> List[str]:
    with urlopen(url, timeout=timeout) as response:
        body = response.read().decode("utf-8", errors="replace")
    return _parse_wordlist_lines(body.splitlines())


def resolve_wordlist(wordlist_source: Optional[str]) -> WordlistSelection:
    if not wordlist_source:
        return WordlistSelection(words=_normalize_words(DEFAULT_DIRECTORY_WORDLIST), source="built-in")

    if wordlist_source == SECLISTS_WORDLIST_SENTINEL:
        try:
            words = load_remote_wordlist(SECLISTS_DEFAULT_WORDLIST_URL)
            return WordlistSelection(words=_normalize_words(words), source=SECLISTS_DEFAULT_WORDLIST_URL)
        except (HTTPError, URLError, OSError, ValueError):
            return WordlistSelection(
                words=_normalize_words(DEFAULT_DIRECTORY_WORDLIST),
                source="built-in fallback",
                used_fallback=True,
            )

    if wordlist_source.startswith(("http://", "https://")):
        words = load_remote_wordlist(wordlist_source)
        return WordlistSelection(words=_normalize_words(words), source=wordlist_source)

    return WordlistSelection(words=_normalize_words(load_wordlist(wordlist_source)), source=wordlist_source)


def _normalize_words(words: Iterable[str]) -> List[str]:
    seen = set()
    normalized: List[str] = []
    for raw_word in words:
        word = raw_word.strip().strip("/")
        if not word or word in seen:
            continue
        seen.add(word)
        normalized.append(word)
    return normalized


def _build_probe_url(base_url: str, word: str) -> Tuple[str, str]:
    normalized_word = quote(word, safe="/.")
    suffix = normalized_word if "." in normalized_word.split("/")[-1] else normalized_word + "/"
    url = urljoin(base_url + "/", suffix)
    path = "/" + suffix
    return url, path


def _make_opener():
    ssl_context = ssl._create_unverified_context()
    opener = build_opener(HTTPSHandler(context=ssl_context), NoRedirectHandler())
    opener.addheaders = [
        ("User-Agent", "PortProbe/2.5 dirscan"),
        ("Accept", "*/*"),
    ]
    return opener


def _perform_request(url: str, timeout: float, method: str) -> Tuple[int, Dict[str, str]]:
    opener = _make_opener()
    request = Request(url, method=method)
    try:
        with opener.open(request, timeout=timeout) as response:
            return response.getcode(), dict(response.info())
    except HTTPError as exc:
        return exc.code, dict(exc.headers)


def _probe_directory(url: str, timeout: float) -> Tuple[Optional[int], Dict[str, str]]:
    try:
        status_code, headers = _perform_request(url, timeout, "HEAD")
        if status_code == 405:
            status_code, headers = _perform_request(url, timeout, "GET")
        return status_code, headers
    except URLError:
        return None, {}


def scan_directories(
    base_url: str,
    words: Optional[Iterable[str]] = None,
    timeout: float = 3.0,
    threads: int = 10,
    include_status_codes: Optional[Iterable[int]] = None,
) -> DirectoryScanResult:
    if timeout <= 0:
        raise ValueError("timeout must be greater than 0")
    if threads <= 0:
        raise ValueError("threads must be greater than 0")

    normalized_base_url = normalize_base_url(base_url)
    candidates = _normalize_words(words or DEFAULT_DIRECTORY_WORDLIST)
    if not candidates:
        raise ValueError("No directory words provided")

    allowed_status_codes = set(include_status_codes or DEFAULT_DISCOVERY_STATUS_CODES)
    result = DirectoryScanResult(base_url=normalized_base_url, scanned_paths=len(candidates))
    started_at = time.time()

    def probe(word: str) -> Optional[DirectoryFinding]:
        target_url, display_path = _build_probe_url(normalized_base_url, word)
        status_code, headers = _probe_directory(target_url, timeout)
        if status_code is None or status_code not in allowed_status_codes:
            return None

        content_length = None
        raw_length = headers.get("Content-Length")
        if raw_length:
            try:
                content_length = int(raw_length)
            except ValueError:
                content_length = None

        return DirectoryFinding(
            path=display_path,
            status_code=status_code,
            url=target_url,
            content_length=content_length,
            location=headers.get("Location", ""),
        )

    max_workers = min(threads, len(candidates))
    findings: List[DirectoryFinding] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(probe, word) for word in candidates]
        for future in as_completed(futures):
            finding = future.result()
            if finding is not None:
                findings.append(finding)

    findings.sort(key=lambda item: (item.status_code, item.path))
    result.findings = findings
    result.scan_duration = round(time.time() - started_at, 2)
    return result
