class PortProbeError(Exception):
    """Base exception for PortProbe."""


class TargetResolutionError(PortProbeError):
    """Raised when a target cannot be resolved."""


class PortSpecificationError(PortProbeError):
    """Raised when port input cannot be parsed."""


class ScanConfigurationError(PortProbeError):
    """Raised when the scan configuration is invalid."""


class BannerGrabError(PortProbeError):
    """Raised when banner grabbing fails in a reproducible way."""
