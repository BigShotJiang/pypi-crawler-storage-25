import csv
import json
from datetime import datetime
from io import StringIO
from typing import List

from .scan import PortResult, ScanResult
from .services import COMMON_SERVICES


def format_table(result: ScanResult, verbose: bool = False) -> str:
    lines = []
    col_port, col_state, col_service = 14, 16, 18
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines += ["", f"  Scan Report — {now}", "  " + "─" * 60,
              f"  Target  : {result.target}"]
    if result.ip and result.ip != result.target:
        lines.append(f"  IP      : {result.ip}")
    if result.hostname and result.hostname != result.target:
        lines.append(f"  Hostname: {result.hostname}")
    if result.os_guess:
        lines.append(f"  OS Guess: {result.os_guess}")
    lines += ["  " + "─" * 60, ""]

    display_ports = result.ports
    if not display_ports:
        lines.append("  No open ports found.")
    else:
        header = (f"  {'PORT':<{col_port}}  {'STATE':<{col_state}}  {'SERVICE':<{col_service}}")
        if verbose:
            header += f"  {'BANNER'}"
        lines += [header, "  " + "─" * 60]

        for pr in display_ports:
            port_str = f"{pr.port}/{pr.protocol}"
            state_str = pr.state
            service_str = pr.service or COMMON_SERVICES.get(pr.port, "unknown")
            row = (f"  {port_str:<{col_port}}  {state_str:<{col_state}}  {service_str:<{col_service}}")
            if verbose and pr.banner:
                row += f"  {pr.banner[:80]}"
            lines.append(row)

    open_ct = sum(1 for p in result.ports if p.state == "open")
    filtered_ct = sum(1 for p in result.ports if p.state in ("filtered", "open|filtered"))
    closed_ct = sum(1 for p in result.ports if p.state == "closed")

    lines += ["", "  " + "─" * 60,
              f"  Ports: {open_ct} open, {filtered_ct} filtered, {closed_ct} closed",
              f"  Scanned: {result.total_ports_scanned} ports in {result.scan_duration}s",
              ""]
    return "\n".join(lines)


def format_json(result: ScanResult) -> str:
    return json.dumps(result.to_dict(), indent=2, sort_keys=True)


def format_simple(result: ScanResult) -> str:
    return "\n".join(
        f"{p.port}/{p.protocol}\t{p.state}\t{p.service}"
        for p in result.ports if p.state == "open"
    )


def format_tsv(result: ScanResult) -> str:
    rows = ["target\tip\thostname\tport\tprotocol\tstate\tservice\tbanner\tresponse_time_ms\tservice_details"]
    for port in result.ports:
        rows.append(
            "\t".join([
                result.target,
                result.ip,
                result.hostname,
                str(port.port),
                port.protocol,
                port.state,
                port.service,
                port.banner.replace("\t", " "),
                str(port.response_time_ms),
                json.dumps(port.service_details, ensure_ascii=False),
            ])
        )
    return "\n".join(rows)


def format_csv(result: ScanResult) -> str:
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "target", "ip", "hostname", "port", "protocol", "state",
        "service", "banner", "response_time_ms", "service_details"
    ])
    for port in result.ports:
        writer.writerow([
            result.target,
            result.ip,
            result.hostname,
            port.port,
            port.protocol,
            port.state,
            port.service,
            port.banner,
            port.response_time_ms,
            json.dumps(port.service_details, ensure_ascii=False),
        ])
    return output.getvalue()
