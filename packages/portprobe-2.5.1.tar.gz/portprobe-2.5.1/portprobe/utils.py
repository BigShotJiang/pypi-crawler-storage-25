import time
from threading import Lock
from typing import Dict, Iterable, Iterator, List, Optional, Tuple


def cap_thread_count(requested: Optional[int], port_count: int, max_threads: int = 200) -> int:
    if requested is None:
        if port_count <= 50:
            return min(10, port_count) or 1
        if port_count <= 200:
            return min(50, port_count)
        return 100
    return max(1, min(requested, port_count, max_threads))


def normalize_targets(targets: Iterable[str]) -> List[str]:
    cleaned = []
    for item in targets:
        item = item.strip()
        if item:
            cleaned.append(item)
    return cleaned


def chunk_iterable(items: Iterable, chunk_size: int) -> Iterator[List]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    current = []
    for item in items:
        current.append(item)
        if len(current) >= chunk_size:
            yield current
            current = []
    if current:
        yield current


class RateLimiter:
    """A simple sleep-based rate limiter for evenly spaced probe submissions."""

    def __init__(self, interval_seconds: float = 0.0):
        self.interval_seconds = max(0.0, interval_seconds)
        self._lock = Lock()
        self._last: Optional[float] = None

    def acquire(self) -> None:
        if self.interval_seconds <= 0:
            self._last = time.monotonic()
            return
        with self._lock:
            now = time.monotonic()
            if self._last is None:
                self._last = now
                return
            elapsed = now - self._last
            if elapsed < self.interval_seconds:
                time.sleep(self.interval_seconds - elapsed)
            self._last = time.monotonic()
