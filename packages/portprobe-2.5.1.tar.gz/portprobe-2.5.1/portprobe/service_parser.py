import re
import ssl
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from .services import COMMON_SERVICES

TITLE_RE = re.compile(r"<title>([^<]+)</title>", re.IGNORECASE)
HEADER_RE = re.compile(r"^([^:]+):\s*(.*)$")
SSH_RE = re.compile(r"^SSH-\d+\.\d+.*")
SMTP_RE = re.compile(r"^220\s+", re.IGNORECASE)
FTP_RE = re.compile(r"^220\s+|^331\s+|^230\s+", re.IGNORECASE)


@dataclass
class ServiceFingerprint:
    service_name: str
    details: Dict[str, str]


def parse_http_response(banner: str) -> Dict[str, str]:
    details: Dict[str, str] = {}
    if not banner:
        return details

    lines = banner.splitlines()
    status_line = lines[0].strip() if lines else ""
    if status_line.startswith("HTTP/"):
        details["status_line"] = status_line
        for line in lines[1:]:
            if not line.strip():
                continue
            match = HEADER_RE.match(line)
            if match:
                key = match.group(1).lower().replace("-", "_")
                details[key] = match.group(2).strip()
        title_match = TITLE_RE.search(banner)
        if title_match:
            details["http_title"] = title_match.group(1).strip()
    return details


def parse_ssh_banner(banner: str) -> Dict[str, str]:
    details: Dict[str, str] = {}
    if SSH_RE.match(banner):
        parts = banner.split(" ", 1)
        details["ssh_banner"] = parts[0]
        if len(parts) > 1:
            details["ssh_server_version"] = parts[1].strip()
    return details


def parse_smtp_banner(banner: str) -> Dict[str, str]:
    details: Dict[str, str] = {}
    if SMTP_RE.match(banner):
        details["smtp_banner"] = banner.strip().split("\r\n", 1)[0]
        if "ESMTP" in banner.upper():
            details["smtp_protocol"] = "ESMTP"
    return details


def parse_ftp_banner(banner: str) -> Dict[str, str]:
    details: Dict[str, str] = {}
    if FTP_RE.match(banner):
        details["ftp_banner"] = banner.strip().split("\r\n", 1)[0]
    return details


def parse_tls_certificate(cert: Dict[str, object]) -> Dict[str, str]:
    details: Dict[str, str] = {}
    if not cert:
        return details
    subject = cert.get("subject")
    issuer = cert.get("issuer")
    if subject:
        details["tls_subject"] = ", ".join("=".join(item) for sub in subject for item in sub)
    if issuer:
        details["tls_issuer"] = ", ".join("=".join(item) for sub in issuer for item in sub)
    if cert.get("notAfter"):
        details["tls_not_after"] = cert["notAfter"]
    if cert.get("notBefore"):
        details["tls_not_before"] = cert["notBefore"]
    return details


def identify_service(port: int, protocol: str, banner: str, metadata: Dict[str, str]) -> ServiceFingerprint:
    service_name = COMMON_SERVICES.get(port, "unknown")
    details: Dict[str, str] = dict(metadata)

    if banner:
        if SSH_RE.match(banner):
            details.update(parse_ssh_banner(banner))
            service_name = service_name if service_name else "ssh"
        elif banner.startswith("HTTP/") or "HTTP/" in banner:
            details.update(parse_http_response(banner))
            service_name = service_name if service_name else "http"
        elif SMTP_RE.match(banner):
            details.update(parse_smtp_banner(banner))
            service_name = service_name if service_name else "smtp"
        elif FTP_RE.match(banner):
            details.update(parse_ftp_banner(banner))
            service_name = service_name if service_name else "ftp"
        elif "STARTTLS" in banner.upper() or "TLS" in banner.upper():
            details["tls_support_hint"] = "banner"

    if not service_name or service_name == "unknown":
        resolved_name = details.get("server") or details.get("ssh_banner") or details.get("smtp_banner")
        if resolved_name:
            service_name = resolved_name

    return ServiceFingerprint(service_name=service_name, details=details)
