import logging
import random
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Iterable, List, Optional

from .exceptions import PortSpecificationError, ScanConfigurationError
from .network import grab_banner, resolve_target
from .service_parser import identify_service
from .services import COMMON_SERVICES
from .utils import RateLimiter, cap_thread_count

logger = logging.getLogger("portprobe")


class PortState(Enum):
    open = "open"
    closed = "closed"
    filtered = "filtered"
    open_filtered = "open|filtered"


@dataclass
class PortResult:
    port: int
    state: str
    service: str = ""
    banner: str = ""
    protocol: str = "tcp"
    response_time_ms: float = 0.0
    service_details: Dict[str, str] = field(default_factory=dict)

    def is_open(self) -> bool:
        return self.state == PortState.open.value

    def is_filtered(self) -> bool:
        return self.state in (PortState.filtered.value, PortState.open_filtered.value)

    def to_dict(self) -> Dict:
        return {
            "port": self.port,
            "protocol": self.protocol,
            "state": self.state,
            "service": self.service,
            "banner": self.banner,
            "response_time_ms": self.response_time_ms,
            "service_details": self.service_details,
        }


@dataclass
class ScanResult:
    target: str
    ip: str = ""
    hostname: str = ""
    ports: List[PortResult] = field(default_factory=list)
    os_guess: str = ""
    scan_duration: float = 0.0
    total_ports_scanned: int = 0
    scan_type: str = "tcp"

    def to_dict(self) -> Dict:
        return {
            "schema_version": "1.0",
            "target": self.target,
            "ip": self.ip,
            "hostname": self.hostname,
            "scan_type": self.scan_type,
            "os_guess": self.os_guess,
            "scan_duration_s": self.scan_duration,
            "total_ports_scanned": self.total_ports_scanned,
            "ports": [port.to_dict() for port in self.ports],
        }

    def summary(self) -> Dict[str, int]:
        return {
            "open": sum(1 for p in self.ports if p.state == PortState.open.value),
            "filtered": sum(1 for p in self.ports if p.state in (PortState.filtered.value, PortState.open_filtered.value)),
            "closed": sum(1 for p in self.ports if p.state == PortState.closed.value),
        }


@dataclass
class ScanConfig:
    scan_type: str = "tcp"
    timeout: float = 1.0
    threads: Optional[int] = None
    grab_banners: bool = False
    os_detect: bool = False
    show_closed: bool = False
    randomize: bool = False
    rate_limit: float = 0.0
    debug: bool = False

    def validate(self) -> None:
        if self.scan_type not in ("tcp", "udp"):
            raise ScanConfigurationError("scan_type must be 'tcp' or 'udp'")
        if self.timeout <= 0:
            raise ScanConfigurationError("timeout must be greater than 0")
        if self.rate_limit < 0:
            raise ScanConfigurationError("rate_limit cannot be negative")
        if self.threads is not None and self.threads <= 0:
            raise ScanConfigurationError("threads must be greater than 0")


PORT_PRESETS = {
    "top20": [
        22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 179, 199, 389, 443,
        445, 465, 514, 515, 548, 554
    ],
    "top100": [
        21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 179, 199, 389,
        443, 445, 465, 500, 514, 515, 548, 554, 587, 593, 631, 636, 646,
        873, 902, 990, 993, 995, 1025, 1026, 1027, 1028, 1029, 1110, 1433, 1434, 1521, 1720, 1723,
        1755, 1900, 2000, 2001, 2049, 2121, 2717, 3000, 3128, 3306, 3389,
        3986, 4899, 5000, 5009, 5051, 5060, 5101, 5190, 5357, 5432, 5631,
        5666, 5800, 5900, 6000, 6001, 6646, 7070, 8000, 8008, 8080, 8443,
        8888, 9100, 9999, 10000, 32768, 49152, 49153, 49154, 49155, 49156,
        49157, 88, 119, 123, 161, 162, 427, 1080, 6379, 27017, 9200, 11211, 6443, 2375,
    ],
    "top1000": list(range(1, 1001)),
    "web": [80, 443, 8000, 8008, 8080, 8443, 8888, 3000, 4000, 5000, 9000, 9090, 9443, 10000],
    "db": [1433, 1521, 3306, 5432, 5984, 6379, 9200, 9300, 11211, 27017, 27018, 50000, 7001],
    "mail": [25, 110, 143, 465, 587, 993, 995, 2525],
    "ssh": [22, 2022, 2222, 2223],
    "ftp": [20, 21, 990, 8021],
    "rdp": [3389, 3390, 3391],
    "vnc": [5900, 5901, 5902, 5903],
    "smb": [139, 445, 137, 138],
    "dns": [53],
    "ntp": [123],
    "ldap": [389, 636, 3268, 3269],
    "snmp": [161, 162],
    "telnet": [23],
    "smtp": [25, 465, 587, 2525],
    "pop3": [110, 995],
    "imap": [143, 993],
    "http": [80, 8000, 8008, 8080, 8888],
    "https": [443, 8443, 9443],
    "netbios": [137, 138, 139],
    "rpc": [111, 135],
    "iscsi": [3260, 3261],
    "mongodb": [27017, 27018, 27019, 27020],
    "redis": [6379, 6380],
    "cassandra": [7000, 7001, 9042, 9160],
    "elasticsearch": [9200, 9300],
    "memcached": [11211],
    "postgresql": [5432],
    "mysql": [3306],
    "mariadb": [3306],
    "mssql": [1433],
    "oracle": [1521],
    "sybase": [5000],
    "informix": [9088],
    "all": list(range(1, 65536)),
}


def parse_ports(port_spec: str) -> List[int]:
    if port_spec in PORT_PRESETS:
        return PORT_PRESETS[port_spec]
    ports = set()
    for part in port_spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, end = part.split("-", 1)
            start_port = int(start)
            end_port = int(end)
            if not 1 <= start_port <= 65535 or not 1 <= end_port <= 65535:
                raise PortSpecificationError("Port numbers must be between 1 and 65535")
            if start_port > end_port:
                raise PortSpecificationError("Port range start must be less than or equal to end")
            ports.update(range(start_port, end_port + 1))
        else:
            port = int(part)
            if not 1 <= port <= 65535:
                raise PortSpecificationError("Port numbers must be between 1 and 65535")
            ports.add(port)
    return sorted(ports)


def _normalize_ports(ports: Iterable[int]) -> List[int]:
    return sorted(set(ports))


def _guess_os(ip: str) -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((ip, 80))
        ttl = None
        if hasattr(socket, "IP_TTL"):
            try:
                ttl = sock.getsockopt(socket.IPPROTO_IP, socket.IP_TTL)
            except OSError:
                pass
        sock.close()
        if ttl is not None:
            if ttl <= 64:
                return "Linux/Unix (TTL ~64)"
            if ttl <= 128:
                return "Windows (TTL ~128)"
            if ttl <= 255:
                return "Cisco/Network device (TTL ~255)"
    except Exception:
        pass
    return "Unknown"


def tcp_connect_scan(ip: str, port: int, timeout: float) -> PortResult:
    start = time.time()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        code = sock.connect_ex((ip, port))
        elapsed = (time.time() - start) * 1000
        sock.close()
        if code == 0:
            return PortResult(
                port=port,
                state=PortState.open.value,
                service=COMMON_SERVICES.get(port, ""),
                protocol="tcp",
                response_time_ms=round(elapsed, 2),
            )
        return PortResult(
            port=port,
            state=PortState.closed.value,
            service=COMMON_SERVICES.get(port, ""),
            protocol="tcp",
            response_time_ms=round(elapsed, 2),
        )
    except socket.timeout:
        return PortResult(
            port=port,
            state=PortState.filtered.value,
            protocol="tcp",
            response_time_ms=round((time.time() - start) * 1000, 2),
        )
    except OSError as exc:
        logger.debug("TCP scan exception for %s:%d: %s", ip, port, exc)
        return PortResult(port=port, state=PortState.filtered.value, protocol="tcp")


def udp_scan(ip: str, port: int, timeout: float) -> PortResult:
    start = time.time()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        sock.sendto(b"\x00", (ip, port))
        try:
            sock.recv(1024)
            elapsed = (time.time() - start) * 1000
            sock.close()
            return PortResult(
                port=port,
                state=PortState.open.value,
                service=COMMON_SERVICES.get(port, ""),
                protocol="udp",
                response_time_ms=round(elapsed, 2),
            )
        except socket.timeout:
            sock.close()
            return PortResult(
                port=port,
                state=PortState.open_filtered.value,
                service=COMMON_SERVICES.get(port, ""),
                protocol="udp",
                response_time_ms=round((time.time() - start) * 1000, 2),
            )
    except OSError as exc:
        logger.debug("UDP scan exception for %s:%d: %s", ip, port, exc)
        return PortResult(port=port, state=PortState.filtered.value, protocol="udp")


def scan_target(
    target: str,
    ports: Iterable[int],
    scan_type: str = "tcp",
    timeout: float = 1.0,
    threads: Optional[int] = None,
    grab_banners: bool = False,
    os_detect: bool = False,
    show_closed: bool = False,
    randomize: bool = False,
    rate_limit: float = 0.0,
    debug: bool = False,
) -> ScanResult:
    if debug:
        logger.setLevel(logging.DEBUG)
    ip, hostname = resolve_target(target)
    ports_list = _normalize_ports(ports)
    if randomize:
        ports_list = ports_list[:]
        random.shuffle(ports_list)

    if not ports_list:
        raise PortSpecificationError("No ports provided for scanning")

    result = ScanResult(target=target, ip=ip, hostname=hostname, scan_type=scan_type)
    result.total_ports_scanned = len(ports_list)
    thread_count = cap_thread_count(threads, len(ports_list))
    rate_limiter = RateLimiter(rate_limit)

    start_time = time.time()
    port_results: List[PortResult] = []
    lock = threading.Lock()

    def scan_port(port: int) -> PortResult:
        if scan_type == "udp":
            pr = udp_scan(ip, port, timeout)
        else:
            pr = tcp_connect_scan(ip, port, timeout)
        if grab_banners and pr.state == PortState.open.value:
            banner, metadata = grab_banner(ip, port, timeout)
            pr.banner = banner
            fingerprint = identify_service(port, scan_type, banner, metadata)
            pr.service = fingerprint.service_name
            pr.service_details = fingerprint.details
        return pr

    with ThreadPoolExecutor(max_workers=thread_count) as executor:
        futures = []
        for port in ports_list:
            rate_limiter.acquire()
            futures.append(executor.submit(scan_port, port))

        for future in as_completed(futures):
            pr = future.result()
            with lock:
                port_results.append(pr)

    port_results.sort(key=lambda x: x.port)
    if show_closed:
        result.ports = port_results
    else:
        result.ports = [pr for pr in port_results if pr.state in (PortState.open.value, PortState.open_filtered.value)]

    if os_detect:
        result.os_guess = _guess_os(ip)
    result.scan_duration = round(time.time() - start_time, 2)
    return result


def scan_targets(targets: Iterable[str], ports: Iterable[int], scan_type: str = "tcp", timeout: float = 1.0, threads: Optional[int] = None, grab_banners: bool = False, os_detect: bool = False, show_closed: bool = False, randomize: bool = False, rate_limit: float = 0.0, debug: bool = False) -> List[ScanResult]:
    normalized_targets = [target.strip() for target in targets if target and target.strip()]
    if not normalized_targets:
        raise ScanConfigurationError("No targets supplied for scan_targets")
    return [scan_target(
        target,
        ports,
        scan_type=scan_type,
        timeout=timeout,
        threads=threads,
        grab_banners=grab_banners,
        os_detect=os_detect,
        show_closed=show_closed,
        randomize=randomize,
        rate_limit=rate_limit,
        debug=debug,
    ) for target in normalized_targets]
