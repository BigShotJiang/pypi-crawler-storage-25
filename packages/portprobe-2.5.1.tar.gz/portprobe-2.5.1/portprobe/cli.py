import argparse
import logging
import os
import socket
import sys
import time

from .dirscan import SECLISTS_WORDLIST_SENTINEL, resolve_wordlist, scan_directories
from .formatting import format_csv, format_json, format_simple, format_table
from .network import resolve_target, expand_cidr
from .scan import parse_ports, scan_target
from .vulnerabilities import get_vulnerability_info, check_vulnerable_version, generate_risk_report
from .advanced_options import ScanProfile, ScanTechnique, get_scan_profile_description
from .report_formats import format_html, format_xml, format_markdown

logger = logging.getLogger("portprobe")


def print_banner() -> None:
    cyan = "\033[96m"
    bright = "\033[1m"
    dim = "\033[2m"
    reset = "\033[0m"

    def c(text: str, color: str) -> str:
        return f"{color}{text}{reset}" if hasattr(sys.stdout, "isatty") and sys.stdout.isatty() else text

    print(f"""
{c('  PortProbe v2.5 - Advanced Network Reconnaissance Tool', bright)}
{c('  Professional Penetration Testing Scanner', dim)}
{c('  ===================================================', cyan)}
{c('  Pure Python | Vulnerability Detection | Advanced Reconnaissance', dim)}
""")


def cmd_scan(args: argparse.Namespace) -> None:
    target_raw = args.url or args.ip
    scan_type = "udp" if args.udp else "tcp"
    targets = expand_cidr(args.ip) if args.ip and "/" in args.ip else [target_raw]

    if len(targets) > 254:
        print("  Warning: CIDR expands to {} hosts; this may take a while.".format(len(targets)))

    try:
        ports = parse_ports(args.ports)
    except Exception as exc:
        print(f"  Error parsing ports: {exc}")
        sys.exit(1)

    port_preview = ",".join(str(p) for p in ports[:5])
    if len(ports) > 5:
        port_preview += f",...+{len(ports)-5} more"
    print(f"\n  Starting {scan_type.upper()} scan on {target_raw}")
    print(f"  Ports: {port_preview}  |  Threads: {args.threads}")
    if args.vulnerability:
        print("  Vulnerability scanning: enabled")
    print()

    all_output = []
    for target in targets:
        try:
            result = scan_target(
                target=target,
                ports=ports,
                scan_type=scan_type,
                timeout=args.timeout,
                threads=args.threads,
                grab_banners=args.banners or args.verbose or args.vulnerability,
                os_detect=args.os_detect,
                show_closed=args.show_closed,
                randomize=args.randomize,
                rate_limit=args.rate,
                debug=args.debug,
            )
            
            # Generate appropriate output format
            if args.xml:
                out = format_xml(result)
            elif args.html:
                out = format_html(result, include_risk_assessment=args.vulnerability)
            elif args.markdown:
                out = format_markdown(result, include_risk_assessment=args.vulnerability)
            elif args.csv:
                out = format_csv(result)
            elif args.json:
                out = format_json(result)
            elif args.simple:
                out = format_simple(result)
            else:
                out = format_table(result, verbose=args.verbose)
            
            print(out)
            all_output.append(out)
            
            # Vulnerability assessment
            if args.vulnerability:
                print("\n" + "-" * 70)
                print("  VULNERABILITY ASSESSMENT")
                print("-" * 70)

                ports_dict = {p.port: p.state == "open" for p in result.ports}
                risk_report = generate_risk_report(ports_dict)

                print(f"\n  Risk Score: {risk_report['overall_risk_score']}/10 - {risk_report['risk_assessment']}")

                if risk_report['critical_ports']:
                    print(f"\n  CRITICAL ISSUES ({len(risk_report['critical_ports'])}):")
                    for port, service in risk_report['critical_ports']:
                        vuln_info = get_vulnerability_info(port)
                        print(f"      - Port {port} ({service}): {vuln_info.get('notes', 'N/A')}")

                if risk_report['high_risk_ports']:
                    print(f"\n  HIGH RISK ISSUES ({len(risk_report['high_risk_ports'])}):")
                    for port, service in risk_report['high_risk_ports']:
                        vuln_info = get_vulnerability_info(port)
                        print(f"      - Port {port} ({service}): {vuln_info.get('notes', 'N/A')}")

                # Check for vulnerable versions if banners were grabbed
                print("\n  Service Versions:")
                for port in result.ports:
                    if port.state == "open" and port.banner:
                        print(f"      - Port {port.port}: {port.banner[:60]}")

                print()

        except ValueError as exc:
            print(f"  Error: {exc}")
            if len(targets) == 1:
                sys.exit(1)

    if args.output and all_output:
        try:
            with open(args.output, "w", encoding="utf-8") as handle:
                handle.write("\n".join(all_output))
            print(f"  Saved results to {args.output}")
        except OSError as exc:
            print(f"  Could not save file: {exc}")


def cmd_ping(args: argparse.Namespace) -> None:
    target = args.url or args.ip
    print(f"\n  TCP Ping -> {target}:{args.port}\n")
    try:
        ip, _ = resolve_target(target)
    except ValueError as exc:
        print(f"  Error: {exc}")
        sys.exit(1)

    success, times = 0, []
    for i in range(1, args.count + 1):
        start = time.time()
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(args.timeout)
            code = sock.connect_ex((ip, args.port))
            elapsed = (time.time() - start) * 1000
            sock.close()
            if code == 0:
                print(f"  OK   [{i}/{args.count}] {ip}:{args.port} - reachable ({elapsed:.1f} ms)")
                success += 1
                times.append(elapsed)
            else:
                print(f"  FAIL [{i}/{args.count}] {ip}:{args.port} - refused ({elapsed:.1f} ms)")
        except Exception as exc:
            print(f"  FAIL [{i}/{args.count}] Error: {exc}")
        if i < args.count:
            time.sleep(0.5)

    print()
    if times:
        print(f"  Reachable: {success}/{args.count}  |  min {min(times):.1f}ms  avg {sum(times)/len(times):.1f}ms  max {max(times):.1f}ms\n")
    else:
        print(f"  Warning: Host unreachable on port {args.port}\n")


def cmd_resolve(args: argparse.Namespace) -> None:
    target = args.url or args.ip
    print(f"\n  DNS Lookup: {target}\n")
    try:
        if args.ip:
            hostname, _, _ = socket.gethostbyaddr(target)
            print(f"  IP       : {target}")
            print(f"  Hostname : {hostname}")
        else:
            ip = socket.gethostbyname(target)
            print(f"  Hostname : {target}")
            print(f"  IP       : {ip}")
            try:
                unique = sorted({str(a[4][0]) for a in socket.getaddrinfo(target, None)})
                if len(unique) > 1:
                    print(f"  All IPs  : {', '.join(unique)}")
            except Exception:
                pass
    except socket.herror as exc:
        print(f"  Reverse lookup failed: {exc}")
    except socket.gaierror as exc:
        print(f"  Resolution failed: {exc}")
        sys.exit(1)
    print()


def cmd_service(args: argparse.Namespace) -> None:
    print(f"\n  Service Lookup ({args.proto.upper()})\n")
    print(f"  {'PORT':<10}SERVICE")
    print("  " + "-" * 30)
    for port_str in args.ports:
        try:
            port = int(port_str)
            from .services import COMMON_SERVICES as SERVICES
            service = SERVICES.get(port, "")
            if not service:
                import socket as std_socket
                try:
                    service = std_socket.getservbyport(port, args.proto)
                except OSError:
                    service = "unknown"
            
            # Add vulnerability indicator
            vuln_info = get_vulnerability_info(port)
            risk_badge = ""
            if vuln_info:
                if vuln_info.get("risk_level") == "CRITICAL":
                    risk_badge = " [CRITICAL]"
                elif vuln_info.get("risk_level") == "HIGH":
                    risk_badge = " [HIGH]"
                elif vuln_info.get("risk_level") == "MEDIUM":
                    risk_badge = " [MEDIUM]"

            print(f"  {port:<10}{service}{risk_badge}")
        except ValueError:
            print(f"  Invalid port: {port_str}")
    print()


def cmd_dirs(args: argparse.Namespace) -> None:
    try:
        selection = resolve_wordlist(args.wordlist)
    except (OSError, ValueError) as exc:
        print(f"  Error loading wordlist: {exc}")
        sys.exit(1)

    if not selection.words:
        print("  Wordlist is empty.")
        sys.exit(1)

    print(f"\n  Directory scan -> {args.url}")
    print(f"  Wordlist: {selection.source}")
    if selection.used_fallback:
        print("  Note: SecLists was unavailable, so the built-in fallback list is being used.")
    print(f"  Timeout: {args.timeout}s  |  Threads: {args.threads}\n")

    try:
        result = scan_directories(
            base_url=args.url,
            words=selection.words,
            timeout=args.timeout,
            threads=args.threads,
        )
    except ValueError as exc:
        print(f"  Error: {exc}")
        sys.exit(1)

    if not result.findings:
        print("  No common subdirectories were discovered.\n")
        return

    print(f"  {'STATUS':<8}{'PATH':<24}DETAILS")
    print("  " + "-" * 60)
    for finding in result.findings:
        details = finding.location or (
            f"{finding.content_length} bytes" if finding.content_length is not None else finding.url
        )
        print(f"  {finding.status_code:<8}{finding.path:<24}{details}")

    print(f"\n  Found {len(result.findings)} paths from {result.scanned_paths} checks in {result.scan_duration:.2f}s.\n")


def interactive_menu() -> None:
    while True:
        print("\n  PortProbe Interactive Menu")
        print("  -----------------------------------------")
        print("  1. Port Scan (advanced)")
        print("  2. TCP Ping")
        print("  3. DNS Resolve")
        print("  4. Service Lookup")
        print("  5. Vulnerability Assessment")
        print("  6. View Scan Profiles")
        print("  7. Run Quick Scan (top 20)")
        print("  8. Run Aggressive Scan")
        print("  q. Quit")
        choice = input("  Choose an option (1-8, q): ").strip().lower()
        if choice == "1":
            interactive_scan()
        elif choice == "2":
            interactive_ping()
        elif choice == "3":
            interactive_resolve()
        elif choice == "4":
            interactive_service()
        elif choice == "5":
            interactive_vuln_scan()
        elif choice == "6":
            show_profiles()
        elif choice == "7":
            interactive_quick_scan()
        elif choice == "8":
            interactive_aggressive_scan()
        elif choice == "q":
            print("\n  Goodbye.\n")
            break
        else:
            print("  Invalid choice.")


def show_profiles() -> None:
    """Display available scan profiles and their descriptions."""
    print("\n  Available Scan Profiles\n")
    print("  " + "-" * 60)
    
    profiles = [
        ("stealth", "Slow, stealthy scan - Evades detection (IDS bypass)"),
        ("aggressive", "Fast aggressive scan - Maximum threads/throughput"),
        ("normal", "Balanced scan - Default recommended profile"),
        ("intense", "Thorough scan - All ports with version detection"),
        ("quick", "Fast scan - Top 20 ports only"),
        ("vuln_check", "Vulnerability focused - Targets common vulnerable services"),
    ]

    for profile, description in profiles:
        print(f"  - {profile:<15} - {description}")

    print("  " + "-" * 60 + "\n")


def interactive_scan() -> None:
    print("\n  Advanced Port Scan")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP/CIDR: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return
    ports = input("  Ports (default top100): ").strip() or "top100"
    timeout = float(input("  Timeout in seconds (default 1.0): ").strip() or 1.0)
    threads = int(input("  Threads (default 100): ").strip() or 100)
    banners = input("  Grab banners? (y/n, default n): ").strip().lower() == "y"
    vulnerability = input("  Enable vulnerability detection? (y/n, default n): ").strip().lower() == "y"
    udp = input("  UDP scan? (y/n, default n): ").strip().lower() == "y"
    
    args = argparse.Namespace(
        url=url,
        ip=ip,
        ports=ports,
        timeout=timeout,
        threads=threads,
        banners=banners,
        udp=udp,
        vulnerability=vulnerability,
        json=False,
        simple=False,
        csv=False,
        xml=False,
        html=False,
        markdown=False,
        output=None,
        os_detect=False,
        show_closed=False,
        randomize=False,
        rate=0.0,
        verbose=False,
        debug=False,
        profile="normal",
        version_detect=False,
    )
    cmd_scan(args)


def interactive_ping() -> None:
    print("\n  TCP Ping")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return
    port = int(input("  Port (default 80): ").strip() or 80)
    timeout = float(input("  Timeout (default 2.0): ").strip() or 2.0)
    count = int(input("  Count (default 4): ").strip() or 4)
    args = argparse.Namespace(url=url, ip=ip, port=port, timeout=timeout, count=count)
    cmd_ping(args)


def interactive_resolve() -> None:
    print("\n  DNS Resolve")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return
    args = argparse.Namespace(url=url, ip=ip)
    cmd_resolve(args)


def interactive_service() -> None:
    print("\n  Service Lookup")
    proto = input("  Protocol (tcp/udp, default tcp): ").strip().lower() or "tcp"
    ports = input("  Ports (space separated): ").strip().split()
    args = argparse.Namespace(ports=ports, proto=proto)
    cmd_service(args)


def interactive_vuln_scan() -> None:
    """Interactive vulnerability assessment scan."""
    print("\n  Vulnerability Assessment Scan")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP/CIDR: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return
    
    ports = "top100,135,139,445,3306,5432,6379,27017,8080,8443"  # Common vulnerable ports
    timeout = 2.0
    threads = 50
    
    args = argparse.Namespace(
        url=url,
        ip=ip,
        ports=ports,
        timeout=timeout,
        threads=threads,
        banners=True,
        udp=False,
        vulnerability=True,
        json=False,
        simple=False,
        csv=False,
        xml=False,
        html=False,
        markdown=False,
        output=None,
        os_detect=True,
        show_closed=False,
        randomize=False,
        rate=0.0,
        verbose=True,
        debug=False,
        profile="vuln_check",
        version_detect=True,
    )
    cmd_scan(args)


def interactive_quick_scan() -> None:
    """Quick scan of top 20 ports."""
    print("\n  Quick Scan (Top 20 Ports)")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return
    
    args = argparse.Namespace(
        url=url,
        ip=ip,
        ports="top20",
        timeout=0.5,
        threads=100,
        banners=True,
        udp=False,
        vulnerability=True,
        json=False,
        simple=False,
        csv=False,
        xml=False,
        html=False,
        markdown=False,
        output=None,
        os_detect=False,
        show_closed=False,
        randomize=False,
        rate=0.0,
        verbose=False,
        debug=False,
        profile="quick",
        version_detect=False,
    )
    cmd_scan(args)


def interactive_aggressive_scan() -> None:
    """Aggressive full scan."""
    print("\n  Aggressive Scan (1-65535)")
    target_type = input("  Target type (u for URL, i for IP): ").strip().lower()
    if target_type == "u":
        url = input("  URL: ").strip()
        ip = None
    elif target_type == "i":
        ip = input("  IP: ").strip()
        url = None
    else:
        print("  Invalid target type.")
        return

    print("  Warning: This will scan all 65535 ports (may take a long time)")
    confirm = input("  Continue? (y/n): ").strip().lower()
    if confirm != "y":
        return
    
    args = argparse.Namespace(
        url=url,
        ip=ip,
        ports="all",
        timeout=1.0,
        threads=200,
        banners=True,
        udp=False,
        vulnerability=True,
        json=False,
        simple=False,
        csv=False,
        xml=False,
        html=False,
        markdown=False,
        output=None,
        os_detect=True,
        show_closed=False,
        randomize=False,
        rate=0.0,
        verbose=False,
        debug=False,
        profile="aggressive",
        version_detect=True,
    )
    cmd_scan(args)


def _is_admin() -> bool:
    if os.name != "nt":
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def add_to_path() -> None:
    if os.name != "nt":
        print("  This feature is Windows only.")
        return
    if not _is_admin():
        print("  Please run as administrator to modify PATH.")
        return
    script_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        import ctypes
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE)
        current_path, _ = winreg.QueryValueEx(key, "Path")
        path_parts = current_path.split(";")
        if script_dir in path_parts:
            print(f"  PortProbe directory {script_dir} is already in PATH.")
            winreg.CloseKey(key)
            return
        if current_path and not current_path.endswith(";"):
            new_path = current_path + ";" + script_dir
        else:
            new_path = current_path + script_dir
        winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, new_path)
        winreg.CloseKey(key)
        bat_path = os.path.join(script_dir, "portprobe.bat")
        with open(bat_path, "w", encoding="utf-8") as handle:
            handle.write('@python -m portprobe %*\n')
        ctypes.windll.user32.PostMessageW(0xFFFF, 0x001A, 0, ctypes.c_wchar_p("Environment"))
        print(f"  Added {script_dir} to system PATH.")
        print("  Created portprobe.bat for command-line usage.")
    except Exception as exc:
        print(f"  Failed to update PATH: {exc}")


def remove_from_path() -> None:
    if os.name != "nt":
        print("  This feature is Windows only.")
        return
    if not _is_admin():
        print("  Please run as administrator to modify PATH.")
        return
    script_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        import ctypes
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE)
        current_path, _ = winreg.QueryValueEx(key, "Path")
        path_parts = [p for p in current_path.split(";") if p and p != script_dir]
        new_path = ";".join(path_parts)
        if new_path != current_path:
            winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, new_path)
            ctypes.windll.user32.PostMessageW(0xFFFF, 0x001A, 0, ctypes.c_wchar_p("Environment"))
            print(f"  Removed {script_dir} from system PATH.")
        else:
            print(f"  PortProbe directory {script_dir} was not in PATH.")
        winreg.CloseKey(key)
    except Exception as exc:
        print(f"  Failed to update PATH: {exc}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="portprobe",
        description="PortProbe 2.5 - Advanced Network Reconnaissance & Vulnerability Scanning Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
EXAMPLES:
========

  Basic Scans:
    portprobe scan -u example.com
    portprobe scan -i 192.168.1.1 -p 22,80,443
    portprobe scan -i 192.168.1.0/24 -p web
    
  Advanced Scanning:
    portprobe scan -u example.com --profile aggressive --threads 200
    portprobe scan -u example.com --profile stealth --timeout 5
    portprobe scan -u example.com --vulnerability --html report.html
    
  Output Formats:
    portprobe scan -u example.com --json -o scan.json
    portprobe scan -u example.com --html -o report.html
    portprobe scan -u example.com --xml -o scan.xml
    portprobe scan -u example.com --markdown -o report.md
    
  Service Enumeration:
    portprobe scan -u example.com --banners -v
    portprobe scan -u example.com -p 80,443,8080 --os-detect
    
  Utility Commands:
    portprobe ping -u example.com -p 443
    portprobe resolve -u example.com
    portprobe service 22 80 443 3306
    portprobe dirs -u https://example.com
    portprobe dirs -u https://example.com -w
    portprobe dirs -u https://example.com -w wordlist.txt
    
  Interactive Mode:
    portprobe -terminal
""",
    )
    parser.add_argument("--version", action="version", version="PortProbe 2.5.0")
    parser.add_argument("--no-banner", action="store_true", help="Suppress the ASCII banner")
    parser.add_argument("-terminal", action="store_true", help="Run in interactive terminal mode")
    parser.add_argument("--path", action="store_true", help="Add PortProbe to Windows PATH (requires admin)")
    parser.add_argument("--rpath", action="store_true", help="Remove PortProbe from Windows PATH (requires admin)")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging for troubleshooting")
    sub = parser.add_subparsers(dest="command", metavar="command")

    scan = sub.add_parser("scan", help="Scan ports and detect vulnerabilities on a target")
    tg = scan.add_mutually_exclusive_group(required=True)
    tg.add_argument("-u", "--url", metavar="HOST", help="Target hostname or URL")
    tg.add_argument("-i", "--ip", metavar="IP", help="Target IP or CIDR (e.g. 192.168.1.0/24)")
    
    # Port specification
    scan.add_argument("-p", "--ports", default="top100", metavar="PORTS",
                      help="Ports: number, range (80-443), list (22,80,443), or preset (default: top100)")
    
    # Protocol options
    scan.add_argument("--udp", action="store_true", help="UDP scan instead of TCP")
    
    # Performance options
    scan.add_argument("-t", "--timeout", type=float, default=1.0, metavar="SECS", help="Timeout per port (default: 1.0s)")
    scan.add_argument("--threads", type=int, default=100, metavar="N", help="Parallel threads (default: 100)")
    scan.add_argument("--rate", type=float, default=0.0, metavar="SECS", help="Delay between probes in seconds")
    
    # Scanning profiles
    scan.add_argument("--profile", choices=["stealth", "aggressive", "normal", "intense", "quick", "vuln_check"],
                      default="normal", help="Predefined scan profile (default: normal)")
    
    # Service detection options
    scan.add_argument("-b", "--banners", action="store_true", help="Grab service banners from open ports")
    scan.add_argument("-O", "--os-detect", action="store_true", help="OS detection via TTL fingerprinting")
    scan.add_argument("--version-detect", action="store_true", help="Detect service versions from banners")
    
    # Display options
    scan.add_argument("--show-closed", action="store_true", help="Show closed ports in results")
    scan.add_argument("--randomize", action="store_true", help="Randomize port scan order")
    scan.add_argument("-v", "--verbose", action="store_true", help="Verbose output with banners inline")
    
    # Vulnerability assessment
    scan.add_argument("--vulnerability", "--vuln", action="store_true", 
                      help="Enable vulnerability detection and risk assessment")
    
    # Output format options
    out = scan.add_mutually_exclusive_group()
    out.add_argument("--json", action="store_true", help="Output results as JSON")
    out.add_argument("--simple", action="store_true", help="Output as plain text (port/proto state service)")
    out.add_argument("--csv", action="store_true", help="Output results as CSV")
    out.add_argument("--xml", action="store_true", help="Output results as Nmap-style XML")
    out.add_argument("--html", action="store_true", help="Generate HTML report")
    out.add_argument("--markdown", action="store_true", help="Generate Markdown report")
    
    # File output
    scan.add_argument("-o", "--output", metavar="FILE", help="Save results to a file")

    # Ping command
    ping = sub.add_parser("ping", help="TCP ping/check host reachability")
    tg2 = ping.add_mutually_exclusive_group(required=True)
    tg2.add_argument("-u", "--url", metavar="HOST")
    tg2.add_argument("-i", "--ip", metavar="IP")
    ping.add_argument("-p", "--port", type=int, default=80, help="Port to probe (default: 80)")
    ping.add_argument("-t", "--timeout", type=float, default=2.0, help="Timeout in seconds (default: 2.0)")
    ping.add_argument("-c", "--count", type=int, default=4, help="Number of probes (default: 4)")

    # Resolve command
    resolve = sub.add_parser("resolve", help="DNS lookup and reverse DNS")
    tg3 = resolve.add_mutually_exclusive_group(required=True)
    tg3.add_argument("-u", "--url", metavar="HOST")
    tg3.add_argument("-i", "--ip", metavar="IP")

    # Service lookup command
    svc = sub.add_parser("service", help="Look up service name for port numbers")
    svc.add_argument("ports", nargs="+", metavar="PORT")
    svc.add_argument("--proto", default="tcp", choices=["tcp", "udp"], help="Protocol (default: tcp)")

    # Directory scan command
    dirs = sub.add_parser("dirs", help="Scan for common subdirectories on a web target")
    dirs.add_argument("-u", "--url", required=True, metavar="URL", help="Base URL to scan (example: https://example.com)")
    dirs.add_argument(
        "-w",
        "--wordlist",
        nargs="?",
        const=SECLISTS_WORDLIST_SENTINEL,
        metavar="FILE",
        help="Newline-separated local wordlist file. Use bare -w to fetch the default SecLists wordlist.",
    )
    dirs.add_argument("-t", "--timeout", type=float, default=3.0, metavar="SECS", help="Timeout per request (default: 3.0s)")
    dirs.add_argument("--threads", type=int, default=10, metavar="N", help="Parallel requests (default: 10)")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.debug:
        logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    if args.terminal:
        print_banner()
        interactive_menu()
        sys.exit(0)

    if args.path:
        add_to_path()
        sys.exit(0)

    if args.rpath:
        remove_from_path()
        sys.exit(0)

    if not args.no_banner and args.command in ("scan", None):
        print_banner()

    if not args.command:
        print_banner()
        parser.print_help()
        sys.exit(0)

    dispatch = {
        "scan": cmd_scan,
        "ping": cmd_ping,
        "resolve": cmd_resolve,
        "service": cmd_service,
        "dirs": cmd_dirs,
    }
    try:
        dispatch[args.command](args)
    except KeyboardInterrupt:
        print("\n\n  Scan interrupted by user.\n")
        sys.exit(0)
